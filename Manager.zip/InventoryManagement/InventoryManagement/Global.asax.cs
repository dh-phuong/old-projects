﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using InventoryManagement.DataAccess;
using InventoryManagement.Models;
using System.Collections;
using log4net;
using System.Threading;

namespace InventoryManagement
{
    public class MvcApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// Register Global Filters
        /// </summary>
        /// <param name="filters">GlobalFilterCollection</param>
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new InventoryManagement.Utility.ErrorLoggerAttribute());
            filters.Add(new ValidateInputAttribute(false));
        }

        /// <summary>
        /// Routers Register
        /// </summary>
        /// <param name="routes">RouteCollection</param>
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default", // ルート名
                "{controller}/{action}/{id}", // パラメーター付きの URL
                new { controller = "Account", action = "Index", id = UrlParameter.Optional } // パラメーターの既定値
            );

            //IgnoreRoute favicon icon
            routes.IgnoreRoute("{*favicon}", new { favicon = @"(.*/)?favicon.ico(/.*)" });
        }

        /// <summary>
        /// Appication start
        /// </summary>
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            RegisterGlobalFilters(GlobalFilters.Filters);
            RegisterRoutes(RouteTable.Routes);
            
            //Resis Unity - DependencyResolver
            DependencyResolver.SetResolver(new Utility.DependencyResolver(Utility.UnityConfigurator.GetContainer()));

            //Config Log4net
            log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(Server.MapPath("~/log4net.config")));
        }

        /// <summary>
        /// On Error
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Application_Error(object sender, EventArgs e)
        {
            //Write log
            Exception ex = Server.GetLastError();
            InventoryManagement.Utility.Log.WriteLog(ex);

            if (ex is HttpException && ((HttpException)ex).GetHttpCode() == 404)
            {
                Response.Redirect("/");
            }

            string cotrol = HttpContext.Current.Request.RawUrl.Split('/')[1];

            //Clear error
            Response.Clear();
            Server.ClearError();
            var routeData = new RouteData();
            RequestContext rc;
            switch (cotrol)
            {
                case "InboundDelivery":
                    routeData.Values["controller"] = "InboundDelivery";
                    routeData.Values["action"] = "Index";
                    IController cotrler = new InventoryManagement.Controllers.InboundDeliveryController(new TInventory_HService(),
                                                                                                  new TInventory_DService(),
                                                                                                 new  MProductService(),
                                                                                                 new MLocationService(),
                                                                                                 new TSequencesService(),
                                                                                                 new TBalanceInStoresService(),
                                                                                                 new MKind_DService(),
                                                                                                 new MCustomerService());
                    rc = new RequestContext(new HttpContextWrapper(Context), routeData);
                    cotrler.Execute(rc);
                    break;
                default:
                    routeData.Values["controller"] = "Errors";
                    routeData.Values["action"] = "Error";
                    routeData.Values["exception"] = ex;
                    IController errorsController = new InventoryManagement.Controllers.ErrorsController();
                    rc = new RequestContext(new HttpContextWrapper(Context), routeData);
                    errorsController.Execute(rc);
                    break;
            }

            //Redirect to Error page
            //var routeData = new RouteData();
            
        }                
    }
}
﻿using System.Collections;
using System.Collections.Generic;
using System;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.SqlClient;
using System.Data;

using System.Linq;

namespace InventoryManagement.DAC
{
    public class Report : Base
    {
        #region Stock List Report ***** Create Date: 05/08/2013 ***** Author: ISV-THUY

        private List<Models.StockListModels> FindListtockListReport(string cmdText, Hashtable paras)
        {
            List<Models.StockListModels> ret = new List<Models.StockListModels>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new Models.StockListModels(dr));
                        }
                    }

                }
            }

            return ret;
        }

        private List<double> FindListRow(string cmdText, Hashtable paras)
        {
            List<double> ret = new List<double>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(Convert.ToDouble(dr["numberRow"]));
                        }
                    }

                }
            }

            return ret;
        }

        private Hashtable SetParas(StockInquiryList model)
        {
            Hashtable paras = new Hashtable();

            //Add Para            
            paras.Add("@IN_StockStatus_DELI", Constant.STOCK_STATUS_DELIVERY);
            paras.Add("@IN_StockStatus_DELI_DEF", Constant.STOCK_STATUS_DELIVERY_DEFECTIVE);
            paras.Add("@IN_StockStatus_DELI_SCR", Constant.STOCK_STATUS_DELIVERY_SCRAP);
            paras.Add("@IN_StockStatus_ISSUE_INVEN", Constant.STOCK_STATUS_ISSUE_INVENTORY);
            paras.Add("@IN_StockStatus_REC_DEF", Constant.STOCK_STATUS_RECEIPT_DEFECTIVE);
            paras.Add("@IN_StockStatus_REC_NON_DEF", Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE);
            paras.Add("@IN_WarehouseCD", UserSession.Session.WarehouseCD);

            string tagNo = string.Empty;
            string branchTagNo = string.Empty;
            if (!string.IsNullOrEmpty(model.txt_TagNo))
            {
                string[] array = model.txt_TagNo.Split(Constant.HYPHEN_CHAR);
                if (array.Length == 2)
                {
                    tagNo = array[0];
                    branchTagNo = array[1];
                    paras.Add("@IN_BranchTagNo", branchTagNo);
                }
                else
                {
                    tagNo = model.txt_TagNo;
                    paras.Add("@IN_BranchTagNo", DBNull.Value);
                }

                paras.Add("@IN_TagNo", tagNo);
            }
            else
            {
                paras.Add("@IN_TagNo", DBNull.Value);
                paras.Add("@IN_BranchTagNo", DBNull.Value);
            }

            if (string.IsNullOrEmpty(model.txt_ProductCD))
            {
                paras.Add("@IN_ProductCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ProductCD", model.txt_ProductCD);
            }

            if (model.IsShowSuplier)
            {
                if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
                {
                    paras.Add("@IN_CustomerCD", DBNull.Value);
                }
                else
                {
                    paras.Add("@IN_CustomerCD", UserSession.Session.LoginInfo.User.CustomerCD);
                }
            }
            else
            {
                paras.Add("@IN_CustomerCD", DBNull.Value);
            }

            if (string.IsNullOrEmpty(model.txt_ProductName))
            {
                paras.Add("@IN_ProductName", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ProductName", model.txt_ProductName);
            }

            if (string.IsNullOrEmpty(model.txt_CategoryCD))
            {
                paras.Add("@IN_CategoryCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_CategoryCD", model.txt_CategoryCD);
            }

            if (string.IsNullOrEmpty(model.txtLocationCDFrom))
            {
                paras.Add("@IN_LocationCDFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_LocationCDFrom", model.txtLocationCDFrom);
            }

            if (string.IsNullOrEmpty(model.txtLocationCDTo))
            {
                paras.Add("@IN_LocationCDTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_LocationCDTo", model.txtLocationCDTo);
            }

            if (string.IsNullOrEmpty(model.txt_StoredDateFrom.DateValue()))
            {
                paras.Add("@IN_StoredDateFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_StoredDateFrom", model.txt_StoredDateFrom.DateValue());
            }

            if (string.IsNullOrEmpty(model.txt_StoredDateTo.DateValue()))
            {
                paras.Add("@IN_StoredDateTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_StoredDateTo", model.txt_StoredDateTo.DateValue());
            }

            if (string.IsNullOrEmpty(model.txt_LOT1))
            {
                paras.Add("@IN_Lot1", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot1", model.txt_LOT1);
            }

            if (string.IsNullOrEmpty(model.txt_LOT2From.DateValue()))
            {
                paras.Add("@IN_Lot2From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2From", model.txt_LOT2From.DateValue());
            }

            if (string.IsNullOrEmpty(model.txt_LOT2To.DateValue()))
            {
                paras.Add("@IN_Lot2To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2To", model.txt_LOT2To.DateValue());
            }

            if (string.IsNullOrEmpty(model.txt_LOT3From.DateValue()))
            {
                paras.Add("@IN_Lot3From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3From", model.txt_LOT3From.DateValue());
            }

            if (string.IsNullOrEmpty(model.txt_LOT3To.DateValue()))
            {
                paras.Add("@IN_Lot3To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3To", model.txt_LOT3To.DateValue());
            }

            if (string.IsNullOrEmpty(model.ddl_Status))
            {
                paras.Add("@IN_StockStatus", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_StockStatus", model.ddl_Status);
            }

            return paras;
        }

        public List<Models.StockListModels> StockInqReportNotGroup(StockInquiryList model)
        {
            string cmdText = "P_TInventory_D_StockInqReportNotGroup";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParas(model);

            //select
            return this.FindListtockListReport(cmdText, paras);
        }

        public List<Models.StockListModels> StockInqReportGroup(StockInquiryList model)
        {
            string cmdText = "P_TInventory_D_StockInqReportGroup";
            Hashtable paras = new Hashtable();
            paras = SetParas(model);

            //select
            return this.FindListtockListReport(cmdText, paras);
        }

        public List<double> StockInqCountRow(StockInquiryList model, PrintConditionTypeFlag printType)
        {
            string cmdText = string.Empty;
            if (model.chk_GroupBranchTagNo)
            {
                if (printType == PrintConditionTypeFlag.Location)
                {
                    cmdText = "P_TInventory_D_StockInqReportGroup_Location_CountRow";
                }
                else
                {
                    cmdText = "P_TInventory_D_StockInqReportGroup_Product_CountRow";
                }
            }
            else
            {
                if (printType == PrintConditionTypeFlag.Location)
                {
                    cmdText = "P_TInventory_D_StockInqReportNotGroup_Location_CountRow";
                }
                else
                {
                    cmdText = "P_TInventory_D_StockInqReportNotGroup_Product_CountRow";
                }
            }

            Hashtable paras = new Hashtable();
            paras = SetParas(model);

            //select
            return this.FindListRow(cmdText, paras);
        }

        #endregion

        #region OutBound Delivered Report ***** Create Date: 08/08/2013 ***** Author: ISV-THUY

        private List<Models.OutboundDeliveredReport> FindListOutboundDeliveredReport(string cmdText, Hashtable paras)
        {
            List<Models.OutboundDeliveredReport> ret = new List<Models.OutboundDeliveredReport>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new Models.OutboundDeliveredReport(dr));
                        }
                    }

                }
            }

            return ret;
        }

        private Hashtable SetParameters(OutboundDeliveredModels model)
        {
            Hashtable paras = new Hashtable();

            //Add Para    
            paras.Add("@IN_KindCD_Out_Kind", Constant.MKIND_KINDCD_OUTBOUND_KIND);
            paras.Add("@IN_DataCD_Normal", Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND);
            paras.Add("@IN_DataCD_WareHouse", Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE);
            paras.Add("@IN_DataCD_Scrap", Constant.MKIND_KINDCD_OUT_KIND_SCRAP);

            if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.WarehouseCD))
            {
                paras.Add("@IN_WarehouseCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_WarehouseCD", UserSession.Session.LoginInfo.WarehouseCD);
            }

            if (string.IsNullOrEmpty(model.txt_ProductCD))
            {
                paras.Add("@IN_ProductCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ProductCD", model.txt_ProductCD);
            }

            if (string.IsNullOrEmpty(model.shr_ShipDateFrom.DateValue()))
            {
                paras.Add("@IN_ShipDateFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ShipDateFrom", model.shr_ShipDateFrom.DateValue());
            }

            if (string.IsNullOrEmpty(model.shr_ShipDateTo.DateValue()))
            {
                paras.Add("@IN_ShipDateTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ShipDateTo", model.shr_ShipDateTo.DateValue());
            }

            if (string.IsNullOrEmpty(model.ddl_Kind))
            {
                paras.Add("@IN_Kind", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Kind", model.ddl_Kind);
            }

            if (string.IsNullOrEmpty(model.txt_CustomerCDFrom))
            {
                paras.Add("@IN_CustomerCDFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_CustomerCDFrom", model.txt_CustomerCDFrom);
            }

            if (string.IsNullOrEmpty(model.txt_CustomerCDTo))
            {
                paras.Add("@IN_CustomerCDTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_CustomerCDTo", model.txt_CustomerCDTo);
            }

            if (string.IsNullOrEmpty(model.txt_WarehouseCDFrom))
            {
                paras.Add("@IN_DestinationWarehouseCDFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_DestinationWarehouseCDFrom", model.txt_WarehouseCDFrom);
            }

            if (string.IsNullOrEmpty(model.txt_WarehouseCDTo))
            {
                paras.Add("@IN_DestinationWarehouseCDTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_DestinationWarehouseCDTo", model.txt_WarehouseCDTo);
            }

            if (string.IsNullOrEmpty(UserSession.Session.Language.ToString()))
            {
                paras.Add("@IN_Language", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Language", UserSession.Session.Language);
            }
            return paras;
        }

        public List<double> OutboundDeliveredCountRow(OutboundDeliveredModels model)
        {
            string cmdText = string.Empty;
            if (model.CheckDestination)
            {
                cmdText = "P_TOutboundDelivered_Report_Customer_CountRow";
            }
            else
            {
                cmdText = "P_TOutboundDelivered_Report_Product_CountRow";
            }


            Hashtable paras = new Hashtable();
            paras = SetParameters(model);

            //select
            return this.FindListRow(cmdText, paras);
        }

        public List<Models.OutboundDeliveredReport> OutboundDeliveredReport(OutboundDeliveredModels model)
        {
            string cmdText = "P_TOutBoundDelivered_GetDataForReport";
            Hashtable paras = new Hashtable();
            paras = SetParameters(model);

            //select
            return this.FindListOutboundDeliveredReport(cmdText, paras);
        }

        #endregion

        #region Balance In Stores Report === TRUC

        private IQueryable<Models.BalanceInStoresProduct> GetListProduct(string cmdText, Hashtable paras)
        {
            List<Models.BalanceInStoresProduct> ret = new List<Models.BalanceInStoresProduct>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new Models.BalanceInStoresProduct(dr));
                        }
                    }
                }
            }

            return ret.AsQueryable();
        }

        private IQueryable<Models.BalanceInStoresLocation> GetListLocation(string cmdText, Hashtable paras)
        {
            List<Models.BalanceInStoresLocation> ret = new List<Models.BalanceInStoresLocation>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new Models.BalanceInStoresLocation(dr));
                        }
                    }
                }
            }

            return ret.AsQueryable();
        }

        private Hashtable SetParameters(BalanceInStoresModels model)
        {
            Hashtable paras = new Hashtable();

            //Add Para    
            paras.Add("@IN_KindCD", Constant.MKIND_KINDCD_BALANCE_STATUS);
            if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.WarehouseCD))
            {
                paras.Add("@IN_WarehouseCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_WarehouseCD", UserSession.Session.LoginInfo.WarehouseCD);
            }

            if (string.IsNullOrEmpty(model.BalanceDateFrom.DateValue()))
            {
                paras.Add("@IN_BalanceDateFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_BalanceDateFrom", model.BalanceDateFrom.DateValue());
            }

            if (string.IsNullOrEmpty(model.BalanceDateTo.DateValue()))
            {
                paras.Add("@IN_BalanceDateTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_BalanceDateTo", model.BalanceDateTo.DateValue());
            }

            if (string.IsNullOrEmpty(model.LocationCDFrom))
            {
                paras.Add("@IN_LocationCDFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_LocationCDFrom", model.LocationCDFrom);
            }

            if (string.IsNullOrEmpty(model.LocationCDTo))
            {
                paras.Add("@IN_LocationCDTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_LocationCDTo", model.LocationCDTo);
            }

            if (string.IsNullOrEmpty(model.ProductCD))
            {
                paras.Add("@IN_ProductCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ProductCD", model.ProductCD);
            }

            if (string.IsNullOrEmpty(UserSession.Session.Language.ToString()))
            {
                paras.Add("@IN_Language", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Language", UserSession.Session.Language);
            }
            return paras;
        }

        public IQueryable<Models.BalanceInStoresProduct> GetBalanceInStoresProduct(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceInStores_GetListReportByProNoGrp";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListProduct(cmdText, paras);
        }

        public IQueryable<Models.BalanceInStoresLocation> GetBalanceInStoresLocation(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceInStores_GetListReportByLocationNoGrp";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListLocation(cmdText, paras);
        }

        private List<Models.BalanceInStoresCheckExcel> GetListOutOfRangeRow(string cmdText, Hashtable paras)
        {
            List<Models.BalanceInStoresCheckExcel> ret = new List<Models.BalanceInStoresCheckExcel>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new Models.BalanceInStoresCheckExcel(dr));
                        }
                    }
                }
            }

            return ret;
        }

        private double GetNumOfSheet(string cmdText, Hashtable paras)
        {
            double ret = 0;

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret = double.Parse(dr["NumOfSheet"].ToString());
                        }
                    }
                }
            }

            return ret;
        }

        public List<Models.BalanceInStoresCheckExcel> GetBalanceStoresOutOfRangeProduct(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceStores_GetGroupProOutOfRangeForExcel";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListOutOfRangeRow(cmdText, paras);
        }

        public List<Models.BalanceInStoresCheckExcel> GetBalanceStoresOutOfRangeLocation(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceStores_GetGroupLocationOutOfRangeForExcel";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListOutOfRangeRow(cmdText, paras);
        }

        public double GetBalanceStoresNumOfSheet(BalanceInStoresModels model, bool isProductView)
        {
            string storeName = "";
            if (isProductView)
            {
                storeName = "P_TBalanceStores_GetNumOfSheetProduct";
            }
            else
            {
                storeName = "P_TBalanceStores_GetNumOfSheetLocation";
            }
            string cmdText = storeName;

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetNumOfSheet(cmdText, paras);
        }

        #region new

        public List<double> GetBalanceStoresRowCountProduct(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceStores_GetListRowCountOfProduct";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListRow(cmdText, paras);
        }

        public List<double> GetBalanceStoresRowCountLocation(BalanceInStoresModels model)
        {
            string cmdText = "P_TBalanceStores_GetListRowCountOfLocation";

            Hashtable paras = new Hashtable();
            //Add Para 
            paras = SetParameters(model);

            //select
            return this.GetListRow(cmdText, paras);
        }

        private List<double> GetListRow(string cmdText, Hashtable paras)
        {
            List<double> ret = new List<double>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(double.Parse(dr["CountOfRow"].ToString()));
                        }
                    }
                }
            }

            return ret;
        }

        #endregion

        #endregion       
    }
}
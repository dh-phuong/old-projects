﻿using System.Collections;
using System.Collections.Generic;
using System;

using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;

namespace InventoryManagement.DAC
{
    /// <summary>
    /// TInventory Header DAC
    /// </summary>
    public class TInventory_H: Base
    {
        public ResultType InboundDeliveryInsert(InboundDeliveryModels model)
        {
            string cmdText = "P_Inbound_Delivery_Insert";
            Hashtable paras = new Hashtable();

            //Add Para
            if(string.IsNullOrEmpty(model.SuplierCD))
            {
                paras.Add("@IN_CustomerCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_CustomerCD", model.SuplierCD);
            }
            paras.Add("@IN_ProductCD", model.ProductCD);
            paras.Add("@IN_WarehouseCD", UserSession.Session.WarehouseCD);
            paras.Add("@IN_StoredCost", CommonUtil.ParseDecimal(model.StoredCost));
            paras.Add("@IN_QuantityPerUnit", CommonUtil.ParseDecimal(model.QuantityPerUnit));
            paras.Add("@IN_UnitQuantity", CommonUtil.ParseInteger(model.UnitQuantity));
            paras.Add("@IN_TotalCost", CommonUtil.ParseDecimal(model.TotalCost));
            if(string.IsNullOrEmpty(model.Lot1))
            {
                paras.Add("@IN_Lot1", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot1", model.Lot1);
            }
            if(string.IsNullOrEmpty(model.LOT2Date.DateValue()))
            {
                paras.Add("@IN_Lot2", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2", model.LOT2Date.DateValue());
            }
            if(string.IsNullOrEmpty(model.LOT3Date.DateValue()))
            {
                paras.Add("@IN_Lot3", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3", model.LOT3Date.DateValue());
            }
            if(string.IsNullOrEmpty(model.Memo))
            {
                paras.Add("@IN_Memo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Memo", model.Memo);
            }
            paras.Add("@IN_StockStatus", Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE);
            if(string.IsNullOrEmpty(model.LocationCD))
            {
                paras.Add("@IN_LocationCD", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_LocationCD", model.LocationCD);
            }
            paras.Add("@IN_CreateUCD", UserSession.Session.LoginInfo.User.UserCD);
            paras.Add("@IN_BalanceStatus", model.BalanceStatus);

            //Insert
            return base.ExecuteNonQuery(cmdText, paras);
        }
    }
}
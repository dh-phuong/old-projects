﻿using InventoryManagement.Common;
using InventoryManagement.Models;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace InventoryManagement.DAC
{
    /// <summary>
    /// TShippingInstruction DAC
    /// </summary>
    public class TShippingInstruction : Base
    {
        /// <summary>
        /// Find List Detail Result of Outbound Delivery Indication
        /// </summary>
        /// <param name="cmdText">command text</param>
        /// <param name="paras">params</param>
        /// <returns>List of OutboundDeliveryIndicationDetailResult</returns>
        private List<OutboundDeliveryIndicationDetailResult> FindListDetailResult(string cmdText, Hashtable paras)
        {
            List<OutboundDeliveryIndicationDetailResult> ret = new List<OutboundDeliveryIndicationDetailResult>();

            //Open Connect
            using (SqlConnection con = new SqlConnection(base.ConnectionString))
            {

                //Create Command
                using (SqlCommand cmd = con.CreateCommand())
                {

                    //Set command value
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = cmdText;

                    //Add Para
                    if (paras != null)
                    {
                        foreach (string key in paras.Keys)
                        {
                            cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                        }
                    }

                    //Open Connect
                    con.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            ret.Add(new OutboundDeliveryIndicationDetailResult(dr));
                        }
                    }

                }
            }

            return ret;
        }

        /// <summary>
        /// Find List Detail Result of Outbound Delivery Indication For show
        /// </summary>
        /// <param name="cmdText">command text</param>
        /// <param name="paras">params</param>
        /// <returns>List of OutboundDeliveryIndicationDetailResult</returns>
        public List<OutboundDeliveryIndicationDetailResult> GetListDetailResultForShow(OutboundDeliveryIndicationDetail gmModel)
        {
            string cmdText = "P_TShippingInstruction_Out_Indi_Detail_Show";

            Hashtable paras = new Hashtable();
            //Add Para         
            paras.Add("@IN_StockStatus_REC_NON_DEF", Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE);
            paras.Add("@IN_ProductCD", gmModel.txt_ProductCD);
            paras.Add("@IN_ShipNo", gmModel.ShipNo);
            paras.Add("@IN_SeqNum", gmModel.SeqNum);
	
            // TagNo
            if (string.IsNullOrEmpty(gmModel.txt_TagNo))
            {
                paras.Add("@IN_TagNo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_TagNo", gmModel.txt_TagNo);
            }

            // Arrival Date From
            if (string.IsNullOrEmpty(gmModel.ctr_ArrivalDateFrom.DateValue()))
            {
                paras.Add("@IN_ArrivalDateFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ArrivalDateFrom", gmModel.ctr_ArrivalDateFrom.DateValue());
            }

            // Arrival Date To
            if (string.IsNullOrEmpty(gmModel.ctr_ArrivalDateTo.DateValue()))
            {
                paras.Add("@IN_ArrivalDateTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ArrivalDateTo", gmModel.ctr_ArrivalDateTo.DateValue());
            }

            // Lot1
            if (string.IsNullOrEmpty(gmModel.txt_LOT1))
            {
                paras.Add("@IN_Lot1", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot1", gmModel.txt_LOT1);
            }

            // Lot2From
            if (string.IsNullOrEmpty(gmModel.ctr_LOT2DateFrom.DateValue()))
            {
                paras.Add("@IN_Lot2From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2From", gmModel.ctr_LOT2DateFrom.DateValue());
            }

            // Lot2To
            if (string.IsNullOrEmpty(gmModel.ctr_LOT2DateTo.DateValue()))
            {
                paras.Add("@IN_Lot2To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2To", gmModel.ctr_LOT2DateTo.DateValue());
            }

            // Lot3From
            if (string.IsNullOrEmpty(gmModel.ctr_LOT3DateFrom.DateValue()))
            {
                paras.Add("@IN_Lot3From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3From", gmModel.ctr_LOT3DateFrom.DateValue());
            }

            // Lot3To
            if (string.IsNullOrEmpty(gmModel.ctr_LOT3DateTo.DateValue()))
            {
                paras.Add("@IN_Lot3To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3To", gmModel.ctr_LOT3DateTo.DateValue());
            }

            //select
            return this.FindListDetailResult(cmdText, paras);
        }

        /// <summary>
        /// Find List Detail Result of Outbound Delivery Indication For show
        /// </summary>
        /// <param name="cmdText">command text</param>
        /// <param name="paras">params</param>
        /// <returns>List of OutboundDeliveryIndicationDetailResult</returns>
        public List<OutboundDeliveryIndicationDetailResult> GetListDetailResultForNewAndEdit(OutboundDeliveryIndicationDetail gmModel)
        {
            string cmdText = "P_TShippingInstruction_Out_Indicat_Detail";

            Hashtable paras = new Hashtable();
            //Add Para         
            paras.Add("@IN_StockStatus_REC_NON_DEF", Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE);
            paras.Add("@IN_WarehouseCD", UserSession.Session.WarehouseCD);
            paras.Add("@IN_ProductCD", gmModel.txt_ProductCD);
            paras.Add("@IN_SeqNum", gmModel.SeqNum);

            if (string.IsNullOrEmpty(gmModel.ShipNo))
            {
                paras.Add("@IN_ShipNo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ShipNo", gmModel.ShipNo);            
            }

            // TagNo
            if (string.IsNullOrEmpty(gmModel.txt_TagNo))
            {
                paras.Add("@IN_TagNo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_TagNo", gmModel.txt_TagNo);
            }

            // Arrival Date From
            if (string.IsNullOrEmpty(gmModel.ctr_ArrivalDateFrom.DateValue()))
            {
                paras.Add("@IN_ArrivalDateFrom", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ArrivalDateFrom", gmModel.ctr_ArrivalDateFrom.DateValue());
            }

            // Arrival Date To
            if (string.IsNullOrEmpty(gmModel.ctr_ArrivalDateTo.DateValue()))
            {
                paras.Add("@IN_ArrivalDateTo", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_ArrivalDateTo", gmModel.ctr_ArrivalDateTo.DateValue());
            }

            // Lot1
            if (string.IsNullOrEmpty(gmModel.txt_LOT1))
            {
                paras.Add("@IN_Lot1", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot1", gmModel.txt_LOT1);
            }

            // Lot2From
            if (string.IsNullOrEmpty(gmModel.ctr_LOT2DateFrom.DateValue()))
            {
                paras.Add("@IN_Lot2From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2From", gmModel.ctr_LOT2DateFrom.DateValue());
            }

            // Lot2To
            if (string.IsNullOrEmpty(gmModel.ctr_LOT2DateTo.DateValue()))
            {
                paras.Add("@IN_Lot2To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot2To", gmModel.ctr_LOT2DateTo.DateValue());
            }

            // Lot3From
            if (string.IsNullOrEmpty(gmModel.ctr_LOT3DateFrom.DateValue()))
            {
                paras.Add("@IN_Lot3From", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3From", gmModel.ctr_LOT3DateFrom.DateValue());
            }

            // Lot3To
            if (string.IsNullOrEmpty(gmModel.ctr_LOT3DateTo.DateValue()))
            {
                paras.Add("@IN_Lot3To", DBNull.Value);
            }
            else
            {
                paras.Add("@IN_Lot3To", gmModel.ctr_LOT3DateTo.DateValue());
            }

            paras.Add("@IN_OnSearch", gmModel.OnSearch);


            //select
            return this.FindListDetailResult(cmdText, paras);
        }
    }
}
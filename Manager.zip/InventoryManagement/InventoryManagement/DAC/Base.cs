﻿using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using InventoryManagement.Common;
using InventoryManagement.Utility;

namespace InventoryManagement.DAC
{
    public class Base
    {
        #region Constant

        private const string CONNECTIONSTRING_KEY_NORMAL = "InventoryManagementConnectionString";

        private const string CONNECTIONSTRING_KEY_ENCRYPT = "InventoryManagementConnectionString-Encrypt";

        #endregion

        #region Variable

        /// <summary>
        /// Connection string
        /// </summary>
        private string _connectionString;

        #endregion

        #region Contructor

        /// <summary>
        /// new
        /// </summary>
        public Base()
        {
            this._connectionString = System.Configuration.ConfigurationManager.ConnectionStrings[CONNECTIONSTRING_KEY_NORMAL].ConnectionString;
        }

        #endregion

        #region Property

        /// <summary>
        /// Connect String
        /// </summary>
        protected string ConnectionString
        {
            get
            {
                return _connectionString;
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Execute Non Query Not Connect
        /// </summary>
        /// <param name="con">connectring</param>
        /// <param name="trans">transaction</param>
        /// <param name="cmdText">command text</param>
        /// <param name="paras">pamrams</param>
        /// <returns>result type</returns>
        protected ResultType ExecuteNonQueryNotConnect(SqlConnection con, SqlTransaction trans, string cmdText, Hashtable paras)
        {
            int result;

            try
            {
                //Create command
                using (SqlCommand cmd = con.CreateCommand())
                {
                    //set trans
                    cmd.Transaction = trans;

                    //set command type
                    cmd.CommandType = CommandType.StoredProcedure;

                    //set command text
                    cmd.CommandText = cmdText;

                    //add param
                    foreach (string key in paras.Keys)
                    {
                        cmd.Parameters.Add(new SqlParameter(key, paras[key]));
                    }

                    result = cmd.ExecuteNonQuery();
                }

                //Data Changed By Orther User
                if (result == 0)
                {
                    return ResultType.DataChangedByOrther;
                }

                //success
                return ResultType.Success;
            }
            catch (SqlException ex)
            {
                //Duplicate Code
                if (ex.ErrorCode == -2146232060)
                {
                    return ResultType.DuplicateCode;
                }

                return ResultType.Fail;
            }
        }

        /// <summary>
        /// Execute Non Query
        /// </summary>
        /// <param name="cmdText">Command Text</param>
        /// <param name="paras">params</param>
        /// <returns>Result Type</returns>
        protected ResultType ExecuteNonQuery(string cmdText, Hashtable paras)
        {
            int result;

            try 
	        {
	            using(var con = new SqlConnection(this._connectionString))
	            {
                    //Create command
                    using(SqlCommand cmd = con.CreateCommand())
	                {
                        //open connect
                        con.Open();

                        //Begin transaction
                        using(SqlTransaction trans = con.BeginTransaction(IsolationLevel.Serializable))
                        {
                            //set transaction
                            cmd.Transaction = trans;

                            //Set Command Type
                            cmd.CommandType = CommandType.StoredProcedure;

                            //Set Command Text
                            cmd.CommandText = cmdText;

                            //Add Params
                            foreach (string key in paras.Keys)
	                        {
                                cmd.Parameters.Add(new SqlParameter(key, paras[key]));
	                        }

                            //Execute
                            result = cmd.ExecuteNonQuery();
                        
                            trans.Commit();
                        }
		 
	                }
		 
	            }

                //Data Changed By Orther User
                if (result == 0)
                {
                    return ResultType.DataChangedByOrther;
                }

                //Success
                return ResultType.Success;
		
	        }
	        catch (SqlException ex)
	        {
                Log.WriteLog(ex);

		        //Duplicate Code
                if (ex.ErrorCode == -2146232060)
                {
                    return ResultType.DuplicateCode;
                }
            
                //Update Fail
                return ResultType.Fail;
	        }
        }

        /// <summary>
        /// Execute Non Query
        /// </summary>
        /// <param name="cmdTextHeader">Command Text of Header</param>
        /// <param name="parasHeader">params of Header</param>
        /// <param name="cmdTextDetail">Command Text of Detail</param>
        /// <param name="parasDetail">params of Detail</param>
        /// <returns>Number Row Changed</returns>
        protected ResultType ExecuteNonQuery(string cmdTextHeader, Hashtable parasHeader , string cmdTextDetail,  IList<Hashtable> parasDetail)
        {
             int result;

            try 
	        {	        
		        //Open Connect
                using(var con = new SqlConnection(this._connectionString))
                {
                    //Create Command
                    using(SqlCommand cmd  = con.CreateCommand())
                    {
                        //Open Connect
                        con.Open();

                        //Begin Transaction
                        using(SqlTransaction trans = con.BeginTransaction(IsolationLevel.Serializable))
                        {
                            //Trans
                            cmd.Transaction = trans;

                            //Set command value
                            cmd.CommandType = CommandType.StoredProcedure;

                            //-----------------Header-------------------
                            cmd.CommandText = cmdTextHeader;

                            //add param Header
                            foreach (string key in parasHeader.Keys)
	                        {
                                cmd.Parameters.Add(new SqlParameter(key, parasHeader[key]));
	                        } 
                            
                            result = cmd.ExecuteNonQuery();

                            //-----------------Detail-------------------
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = cmdTextDetail;
                            foreach (Hashtable item in parasDetail)
	                        {
                                cmd.Parameters.Clear();
                                foreach (string key in item.Keys)
	                            {
                                    cmd.Parameters.Add(new SqlParameter(key, item[key]));
	                            }
                                cmd.ExecuteNonQuery();
		 
	                        }
                            trans.Commit();
                        }
                    }
                }

                //Data Changed By Orther User
                if(result == 0)
                {
                    return ResultType.DataChangedByOrther;
                }

                //Success
                return ResultType.Success;
	        }
	        catch (SqlException ex)
	        {
		        //Duplicate Code
                if(ex.ErrorCode == -2146232060)
                {
                    return ResultType.DuplicateCode;
                }

                //Update Fail
                return ResultType.Fail;
	        }
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.Practices.Unity;

namespace InventoryManagement.Utility
{
    /// <summary>
    /// Resolver dependency
    /// Author : ISV-PHUONG
    /// </summary>
    public class DependencyResolver :IDependencyResolver
    {
        IUnityContainer container = null;

        public DependencyResolver(IUnityContainer container)
        {
            this.container = container;
        }

        #region IDependencyResolver Members

        public object GetService(Type serviceType)
        {
            try
            {
                return container.Resolve(serviceType);
            }
            catch
            {
                return null;
            }
        }

        public IEnumerable<object> GetServices(Type serviceType)
        {
            try
            {
                return container.ResolveAll(serviceType);
            }
            catch
            {
                return new List<object>();
            }
        }
        #endregion
    }
}
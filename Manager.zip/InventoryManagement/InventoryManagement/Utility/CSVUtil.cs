﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;

namespace InventoryManagement.Utility
{
    /// <summary>
    /// CSV Writter
    /// Author: ISV-PHUONG
    /// </summary>
    public class CSVUtil
    {

        /// <summary>
        /// CSV Init
        /// </summary>
        /// <param name="FileNameOutPut">File name</param>
        /// <param name="Caption"></param>
        /// <param name="ShowCaption"></param>
        public CSVUtil(string FileNameOutPut, string[] Caption, bool ShowCaption)
        {
            this.Init(FileNameOutPut, Caption, ShowCaption);
        }

        /// <summary>
        /// CSV Init
        /// </summary>
        /// <param name="FileNameOutPut">File name</param>
        public CSVUtil(string FileNameOutPut)
        {
            this.Init(FileNameOutPut, null, false);
        }


        /// <summary>
        /// Column Name
        /// </summary>
        public string[] Caption;

        /// <summary>
        /// File name output
        /// </summary>
        public string FileName { get; private set; }

        /// <summary>
        /// Show caption
        /// </summary>
        public bool ShowCaption { get; set; }


        /// <summary>
        /// Write data
        /// </summary>
        /// <param name="Models">Data</param>
        /// <param name="ColumnNameAsString">Text column</param>
        /// <param name="HideColumnName">Hide column</param>
        /// <param name="ShowOriginalValue">True: 1, false: 0, Enum to int, ...</param>
        public byte[] Write(Array Models, string[] ColumnNameAsString, string[] HideColumnName, bool ShowOriginalValue = true)
        {
            if (ColumnNameAsString == default(string[]))
            {
                ColumnNameAsString = new string[] { };
            }

            using (System.IO.StreamWriter _StreamWriter = new System.IO.StreamWriter(this.FileName, false, System.Text.Encoding.UTF8))
            {

                if (this.ShowCaption && this.Caption != null)
                {
                    for (int index = 0; index <= this.Caption.Length - 1; index++)
                    {
                        if (index == this.Caption.Length - 1)
                        {
                            _StreamWriter.Write("\"" + this.Caption[index] + "\"" + Environment.NewLine);
                        }
                        else
                        {
                            _StreamWriter.Write("\"" + this.Caption[index] + "\",");
                        }

                    }
                }
                string StrTemplate = null;
                foreach (object item in Models)
                {
                    StrTemplate = string.Empty;
                    var Columns = item.GetType().GetProperties().ToList();
                    int Index = 0;
                    foreach (var info in Columns)
                    {
                        if (Array.BinarySearch(HideColumnName, info.Name) < 0)
                        {
                            if (Index == Columns.Count - 1)
                            {
                                if (Array.BinarySearch(ColumnNameAsString, info.Name) >= 0)
                                {
                                    StrTemplate += "=\"" + this.FormatData(info.GetValue(item, null), ShowOriginalValue) + "\"";
                                }
                                else
                                {
                                    StrTemplate += "\"" + this.FormatData(info.GetValue(item, null), ShowOriginalValue) + "\"";
                                }
                            }
                            else
                            {
                                if (Array.BinarySearch(ColumnNameAsString, info.Name) >= 0)
                                {
                                    StrTemplate += "=\"" + this.FormatData(info.GetValue(item, null), ShowOriginalValue) + "\",";
                                }
                                else
                                {
                                    StrTemplate += "\"" + this.FormatData(info.GetValue(item, null), ShowOriginalValue) + "\",";
                                }
                            }

                        }
                        Index += 1;
                    }                                     
                    _StreamWriter.WriteLine(StrTemplate);
                   
                }
                _StreamWriter.Close();
            }
            return ReadFile(this.FileName);
        }

        public static byte[] ReadFile(string filePath)
        {
            byte[] buffer;
            FileStream fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
            try
            {
                int length = (int)fileStream.Length;  // get file length
                buffer = new byte[length];            // create buffer
                int count;                            // actual number of bytes read
                int sum = 0;                          // total number of bytes read

                // read until Read method returns 0 (end of the stream has been reached)
                while ((count = fileStream.Read(buffer, sum, length - sum)) > 0)
                    sum += count;  // sum is a buffer offset for next reading
            }
            finally
            {
                fileStream.Close();
            }
            return buffer;
        }
     
        /// <summary>
        /// Init properties
        /// </summary>
        /// <param name="FileNameOutPut"></param>
        /// <param name="Caption"></param>
        /// <param name="ShowCaption"></param>
        private void Init(string FileNameOutPut, string[] Caption, bool ShowCaption)
        {
            this.FileName = FileNameOutPut;
            this.Caption = Caption;
            this.ShowCaption = ShowCaption;

            var fileinfo = new System.IO.FileInfo(this.FileName);
            if (!fileinfo.Directory.Exists)
            {
                fileinfo.Directory.Create();
            }
        }

        /// <summary>
        /// format data
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private string FormatData(object input, bool ShowOriginalValue)
        {
            const char DOUBLE_QUOTES = '\"';
            if (input == null)
            {
                return string.Empty;
            }

            //Get Data Input
            string ret = string.Empty;
            if (ShowOriginalValue)
            {
                if (input.GetType().Equals(typeof(bool)) || input.GetType().Equals(typeof(Enum)))
                {
                    ret = Convert.ToInt16(input).ToString();
                }
                else
                {
                    ret = input.ToString();
                }
            }
            else
            {
                ret = input.ToString();
            }

            //Replace " to "" 
            ret = ret.Replace(DOUBLE_QUOTES.ToString(), string.Format("{0}{0}", DOUBLE_QUOTES));

            return ret;
        }

        public byte[] FileContents()
        {
            if (System.IO.File.Exists(this.FileName))
            {
                return File.ReadAllBytes(this.FileName);
            }
            return null;
        }

    }
}
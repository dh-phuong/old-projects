﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Practices.Unity;
namespace InventoryManagement.Utility
{
    /// <summary>
    /// Register service
    /// Author : ISV-PHUONG
    /// </summary>
    public class UnityConfigurator
    {
        /// <summary>
        /// Get instance service
        /// </summary>
        /// <returns></returns>
        public static Microsoft.Practices.Unity.IUnityContainer GetContainer()
        {
            Microsoft.Practices.Unity.IUnityContainer container = new Microsoft.Practices.Unity.UnityContainer();  
            
            ////Map inteface service class
            //container.RegisterType<DataAccess.MUserService, DataAccess.MUserService>(new HttpContextLifetimeManager<DataAccess.MUserService>());
            //container.RegisterType<DataAccess.MMessageService, DataAccess.MMessageService>(new HttpContextLifetimeManager<DataAccess.MMessageService>());
            //container.RegisterType<DataAccess.MCustomerService, DataAccess.MCustomerService>(new HttpContextLifetimeManager<DataAccess.MCustomerService>());
            //container.RegisterType<DataAccess.MKind_HService, DataAccess.MKind_HService>(new HttpContextLifetimeManager<DataAccess.MKind_HService>());
            //container.RegisterType<DataAccess.MKind_DService, DataAccess.MKind_DService>(new HttpContextLifetimeManager<DataAccess.MKind_DService>());
            //container.RegisterType<DataAccess.MProductService, DataAccess.MProductService>(new HttpContextLifetimeManager<DataAccess.MProductService>());
            //container.RegisterType<DataAccess.MWarehouseService, DataAccess.MWarehouseService>(new HttpContextLifetimeManager<DataAccess.MWarehouseService>());
            //container.RegisterType<DataAccess.MLocationService, DataAccess.MLocationService>(new HttpContextLifetimeManager<DataAccess.MLocationService>());
            //container.RegisterType<DataAccess.MCompanyService, DataAccess.MCompanyService>(new HttpContextLifetimeManager<DataAccess.MCompanyService>());
            //container.RegisterType<DataAccess.TSequencesService, DataAccess.TSequencesService>(new HttpContextLifetimeManager<DataAccess.TSequencesService>());
            //container.RegisterType<DataAccess.TBalanceInStoresService, DataAccess.TBalanceInStoresService>(new HttpContextLifetimeManager<DataAccess.TBalanceInStoresService>());
            //container.RegisterType<DataAccess.TShippingInstructionService, DataAccess.TShippingInstructionService>(new HttpContextLifetimeManager<DataAccess.TShippingInstructionService>());
            //container.RegisterType<DataAccess.TShippingInstructionDetailsService, DataAccess.TShippingInstructionDetailsService>(new HttpContextLifetimeManager<DataAccess.TShippingInstructionDetailsService>());
            //container.RegisterType<DataAccess.TReserveService, DataAccess.TReserveService>(new HttpContextLifetimeManager<DataAccess.TReserveService>());
            //container.RegisterType<DataAccess.TPessimisticLockService, DataAccess.TPessimisticLockService>(new HttpContextLifetimeManager<DataAccess.TPessimisticLockService>());
            //container.RegisterType<DataAccess.MGroup_HService, DataAccess.MGroup_HService>(new HttpContextLifetimeManager<DataAccess.MGroup_HService>());
            //container.RegisterType<DataAccess.MGroup_DService, DataAccess.MGroup_DService>(new HttpContextLifetimeManager<DataAccess.MGroup_DService>());
            //container.RegisterType<DataAccess.TOutBoundDeliveredService, DataAccess.TOutBoundDeliveredService>(new HttpContextLifetimeManager<DataAccess.TOutBoundDeliveredService>());
            return container;
        }
    }
}
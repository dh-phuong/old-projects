﻿using System.ComponentModel.DataAnnotations;
using System;
using InventoryManagement.Utility;
using System.Globalization;
using InventoryManagement.Common;
using System.Web.Mvc;
using System.Web;
using InventoryManagement.DataAccess;
using System.Text.RegularExpressions;
using System.Reflection;
using System.ComponentModel;
using System.Linq;
using InventoryManagement.Models;

namespace InventoryManagement.Validation
{
    /// <summary>
    /// Compare Type
    /// Author: ISV-Vinh
    /// </summary>
    public enum CompareType
    {
        LessThan = 0,
        LessThanOrEqual,
        GreaterThan,
        GreaterThanOrEqual
    }

    /// <summary>
    /// Required Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class iRequiredAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public iRequiredAttribute()
            : base()
        {
            IgnoreOnEmpty = true;
        }

        public bool IgnoreOnEmpty { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null && value.GetType().Equals(typeof(DateControl)))
            {
                var dateCtr = value as DateControl;
                value = dateCtr.DateValue();                
            }
            if (value == default(object) || String.IsNullOrEmpty(value.ToString()) || (IgnoreOnEmpty && String.IsNullOrEmpty(value.ToString().Trim())))
            {
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0002);
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }
            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Integer Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iStringLengthAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="maximumLength">MaximumLength</param>
        public iStringLengthAttribute(int maximumLength, int minimumLength = 0)
            : base()
        {
            MaximumLength = maximumLength;
            MinimumLength = minimumLength;
        }

        public int MaximumLength { get; set; }
        public int MinimumLength { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != default(object))
            {
                string strValue = value.ToString();

                //MaximumLength and MinimumLength
                if (strValue.Length > MaximumLength || strValue.Length < MinimumLength)
                {
                    string message = string.Empty;
                    if (MaximumLength != MinimumLength)
                    {
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0007);
                        message = String.Format(message, validationContext.DisplayName, MaximumLength, MinimumLength);
                    }
                    else 
                    {
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0024);
                        message = String.Format(message, validationContext.DisplayName, MaximumLength);
                    }
                    
                    return new ValidationResult(message);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Compare Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="otherProperty">otherProperty</param>
        public iCompareAttribute(string otherProperty)
            : base()
        {
            if (otherProperty == null)
            {
                throw new ArgumentNullException("otherProperty");
            }
            OtherProperty = otherProperty;
        }

        public string OtherProperty { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //Get PropertyInfo Object  
            var otherPropertyInfo = validationContext.ObjectType.GetProperty(OtherProperty);
            if (otherPropertyInfo == null)
            {
                throw new ArgumentNullException("otherProperty");
            }

            //Get Value of the property  
            var otherValue = otherPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //Actual comparision  
            if (value != default(object) && otherValue != default(object) && !value.Equals(otherValue))
            {
                //Get Display name of other propertise
                string otherDisplayName = CommonUtil.GetNameFromPropertyInfo(this.OtherProperty, otherPropertyInfo);

                //Format Message
                var message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0001);
                message = String.Format(message, validationContext.DisplayName, otherDisplayName);
                return new ValidationResult(message);
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Compare Number Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iPatternAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="otherProperty">otherProperty</param>
        public iPatternAttribute(PatternType patternType)
            : base()
        {
            this.PatternType = patternType;
        }

        public PatternType PatternType { get; private set; }
        private string pattern;


        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == default(object) || string.IsNullOrEmpty(value.ToString()))
            {

                return null;
            }

            string strValue = value.ToString();
            switch (PatternType)
            {
                case PatternType.AlphaNumeric:
                    pattern = Constant.PATTERN_ANPHA_NUMERIC;
                    break;
                case PatternType.Email:
                    pattern = Constant.PATTERN_EMAIL;
                    break;
                case PatternType.HaflWidth:
                    pattern = Constant.PATTERN_HAFL_WIDTH;
                    break;
                case PatternType.Numeric:
                    pattern = Constant.PATTERN_NUMERIC;
                    break;
                case PatternType.Tel:
                    pattern = Constant.PATTERN_TEL;
                    break;
                case PatternType.NumbericSubstract:
                    pattern = Constant.PATTERN_NUMERIC_SUBTRACT;
                    break;
                case PatternType.UpperAlphaNumeric:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC;
                    strValue = strValue.ToUpper();
                    break;
                case PatternType.AlphaNumericFlashSpace:
                    pattern = Constant.PATTERN_ANPHA_NUMERIC_FLASH;
                    break;
                case PatternType.UpperAlphaNumericFlash:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC_FLASH;
                    strValue = strValue.ToUpper();
                    break;
                case PatternType.UpperAlphaNumericSubtract:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC_SUBTRACT;
                    strValue = strValue.ToUpper();
                    break;
                default:
                    pattern = string.Empty;
                    break;
            }

            Match match = Regex.Match(strValue, pattern, RegexOptions.Compiled);


            // Here we check the Match instance.
            if (!match.Success)
            {

                //Format Message
                string message;
                switch (PatternType)
                {
                    case PatternType.AlphaNumeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0003);
                        break;
                    case PatternType.Email:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0017);
                        break;
                    case PatternType.HaflWidth:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0014);
                        break;
                    case PatternType.Numeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0013);
                        break;
                    case PatternType.Tel:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0004);
                        break;
                    case PatternType.UpperAlphaNumeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0003);
                        break;
                    case PatternType.UpperAlphaNumericFlash:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0018);
                        break;
                    case PatternType.AlphaNumericFlashSpace:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0025);
                        break;
                    case PatternType.NumbericSubstract:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0023);
                        break;
                    case PatternType.UpperAlphaNumericSubtract:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0026);
                        break;
                    default:
                        message = string.Empty;
                        break;
                }
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Compare Number Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareNumberAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="otherProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iCompareNumberAttribute(string otherProperty, CompareType compareType)
            : base()
        {
            this.OtherProperty = otherProperty;
            this.CompareType = compareType;
        }

        public string OtherProperty { get; private set; }
        public CompareType CompareType { get; private set; }
        private string messageCD;

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //Get PropertyInfo Object  
            var otherPropertyInfo = validationContext.ObjectType.GetProperty(this.OtherProperty);
            if (otherPropertyInfo == null)
            {
                throw new ArgumentNullException("otherProperty");
            }

            //Get Value of the property  
            var otherValue = otherPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //Actual comparision  
            if (value != default(object) && otherValue != default(object))
            {
                //parse number value
                double dblValue = default(double);
                double dblOtherValue = default(double);
                if (CommonUtil.TryParseNumber(value.ToString(), ref dblValue) && CommonUtil.TryParseNumber(otherValue.ToString(), ref dblOtherValue))
                {
                    //comparision
                    if (!this.IsValid(dblValue, dblOtherValue))
                    {
                        //Get Display name of other propertise
                        string otherDisplayName = CommonUtil.GetNameFromPropertyInfo(this.OtherProperty, otherPropertyInfo);

                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(messageCD);
                        message = String.Format(message, validationContext.DisplayName, otherDisplayName);
                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid compare
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="otherValue">otherValue</param>
        /// <returns></returns>
        private bool IsValid(double value, double otherValue)
        {
            bool result;
            switch (this.CompareType)
            {
                case CompareType.LessThan:
                    result = value < otherValue;
                    //messageCD = Constant.MES_LESS_THAN;
                    break;

                case CompareType.LessThanOrEqual:
                    result = value <= otherValue;
                    messageCD = Constant.MES_E0005;
                    break;

                case CompareType.GreaterThan:
                    result = value > otherValue;
                    //messageCD = Constant.MES_GREATER_THAN;
                    break;

                default:
                    result = value >= otherValue;
                    //messageCD = Constant.MES_GREATER_EQUAL;
                    break;
            }

            return result;
        }
    }

    /// <summary>
    /// Compare Date Attribute
    /// Author: ISV-Thuy
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dayProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iCompareDateAttribute(string monthFromProperty, string yearFromProperty, string dayToProperty,
                                        string monthToProperty, string yearToProperty, CompareType compareType,
                                        string lblFrom, string lblTo)
            : base()
        {
            this.monthFromProperty = monthFromProperty;
            this.yearFromProperty = yearFromProperty;
            this.dayToProperty = dayToProperty;
            this.monthToProperty = monthToProperty;
            this.yearToProperty = yearToProperty;
            this.CompareType = compareType;
            this.lblFrom = lblFrom;
            this.lblTo = lblTo;
        }

        public string monthFromProperty { get; private set; }
        public string yearFromProperty { get; private set; }
        public string dayToProperty { get; private set; }
        public string monthToProperty { get; private set; }
        public string yearToProperty { get; private set; }
        public string lblFrom { get; private set; }
        public string lblTo { get; private set; }
        public CompareType CompareType { get; private set; }

        private string messageCD;

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //---------------------- month from -----------------------------------------
            //Get PropertyInfo Object  
            var monthFromPropertyInfo = validationContext.ObjectType.GetProperty(this.monthFromProperty);
            if (monthFromPropertyInfo == null)
            {
                throw new ArgumentNullException("monthFromProperty");
            }

            //Get Value of the property  
            var monthFromValue = monthFromPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------------- year from -----------------------------------------
            //Get PropertyInfo Object  
            var yearFromPropertyInfo = validationContext.ObjectType.GetProperty(this.yearFromProperty);
            if (yearFromPropertyInfo == null)
            {
                throw new ArgumentNullException("yearFromProperty");
            }

            //Get Value of the property  
            var yearFromValue = yearFromPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------------- day to -----------------------------------------
            //Get PropertyInfo Object  
            var dayToPropertyInfo = validationContext.ObjectType.GetProperty(this.dayToProperty);
            if (dayToPropertyInfo == null)
            {
                throw new ArgumentNullException("dayToProperty");
            }

            //Get Value of the property  
            var dayToValue = dayToPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------------- month to -----------------------------------------
            //Get PropertyInfo Object  
            var monthToPropertyInfo = validationContext.ObjectType.GetProperty(this.monthToProperty);
            if (monthToPropertyInfo == null)
            {
                throw new ArgumentNullException("dayToProperty");
            }

            //Get Value of the property  
            var monthToValue = monthToPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------------- year to -----------------------------------------
            //Get PropertyInfo Object  
            var yearToPropertyInfo = validationContext.ObjectType.GetProperty(this.yearToProperty);
            if (yearToPropertyInfo == null)
            {
                throw new ArgumentNullException("dayToProperty");
            }

            //Get Value of the property  
            var yearToValue = yearToPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------- comparision ----------------------------------------
            //Actual comparision  
            if (value != default(object) &&
                monthFromValue != default(object) &&
                yearFromValue != default(object) &&
                dayToValue != default(object) &&
                monthToValue != default(object) &&
                yearToValue != default(object))
            {
                string dateFrom = value + "/" + monthFromValue + "/" + yearFromValue;
                string dateTo = dayToValue + "/" + monthToValue + "/" + yearToValue;

                //parse number value
                DateTime datToValue = default(DateTime);
                DateTime datFromValue = default(DateTime);

                if (CommonUtil.TryParseDate(dateFrom, ref datFromValue) && CommonUtil.TryParseDate(dateTo, ref datToValue))
                {
                    //comparision
                    if (!this.IsValid(datFromValue, datToValue))
                    {
                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(messageCD);
                        message = String.Format(message, UserSession.Session.SysCache.GetLabel(lblTo), UserSession.Session.SysCache.GetLabel(lblFrom));
                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid compare
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="otherValue">otherValue</param>
        /// <returns></returns>
        private bool IsValid(DateTime value, DateTime otherValue)
        {
            bool result;
            switch (this.CompareType)
            {
                case CompareType.LessThan:
                    result = value < otherValue;
                    //messageCD = Constant.MES_LESS_THAN;
                    break;

                case CompareType.LessThanOrEqual:
                    result = value <= otherValue;
                    messageCD = Constant.MES_E0005;
                    break;

                case CompareType.GreaterThan:
                    result = value > otherValue;
                    //messageCD = Constant.MES_GREATER_THAN;
                    break;

                default:
                    result = value >= otherValue;
                    //messageCD = Constant.MES_GREATER_EQUAL;
                    break;
            }

            return result;
        }
    }

    /// <summary>
    /// Integer Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iIntegerAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public iIntegerAttribute()
            : base()
        {
            MinValue = int.MinValue;
            MaxValue = int.MaxValue;
        }

        /// <summary>
        /// Constructpr
        /// </summary>
        /// <param name="minValue">MinValue</param>
        /// <param name="maxValue">MaxValue</param>
        public iIntegerAttribute(int minValue, int maxValue)
            : base()
        {
            MinValue = minValue;
            MaxValue = maxValue;
        }

        public int MinValue { get; set; }
        public int MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != default(object))
            {
                //Check number
                int temp = default(int);
                if (!CommonUtil.TryParseInt(value.ToString(), ref temp))
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_M0004);
                    message = String.Format(message, validationContext.DisplayName);
                    return new ValidationResult(message);
                }

                //Check Min, Max
                if (temp < MinValue || temp > MaxValue)
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                    message = String.Format(message, validationContext.DisplayName, MinValue.ToString(Constant.FMT_INTEGER), MaxValue.ToString(Constant.FMT_INTEGER));
                    return new ValidationResult(message);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Decimal Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iDecimalAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructorr
        /// </summary>
        /// <param name="precision">precision</param>
        /// <param name="scale">scale</param>
        public iDecimalAttribute(int precision, int scale)
            : base()
        {
            Precision = precision;
            Scale = scale;

            //Set Min Max
            string maxStr = this.GetMaxString();
            MinValue = CommonUtil.ParseDecimal("-" + maxStr);
            MaxValue = CommonUtil.ParseDecimal(maxStr);
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="precision">precision</param>
        /// <param name="scale">scale</param>
        /// <param name="minValue">minValue</param>
        /// <param name="maxValue">maxValue</param>
        public iDecimalAttribute(int precision, int scale, string minValue, string maxValue)
            : base()
        {
            Precision = precision;
            Scale = scale;
            MinValue = CommonUtil.ParseDecimal(minValue);
            MaxValue = CommonUtil.ParseDecimal(maxValue);
        }

        public int Precision { get; private set; }
        public int Scale { get; private set; }
        public decimal MinValue { get; set; }
        public decimal MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != default(object))
            {
                //Check number
                decimal temp = default(decimal);
                if (!CommonUtil.TryParseDecimal(value.ToString(), ref temp))
                {
                    //must be a number
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0010);
                    message = String.Format(message, validationContext.DisplayName);
                    return new ValidationResult(message);
                }

                //Check Precision, Scale
                System.Data.SqlTypes.SqlDecimal x;
                x = new System.Data.SqlTypes.SqlDecimal(temp);
                if (x.Scale > Scale)
                {
                    //must in format
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0011);
                    message = String.Format(message, validationContext.DisplayName, Scale);
                    return new ValidationResult(message);
                }

                //Check Min, Max
                if (temp < MinValue || temp > MaxValue)
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                    message = String.Format(message, validationContext.DisplayName, FormatNum(MinValue), FormatNum(MaxValue));
                    return new ValidationResult(message);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Get max string
        /// </summary>
        /// <returns></returns>
        private string GetMaxString()
        {
            string ret = string.Empty;
            ret = ret.PadLeft(Precision, '9');
            ret = ret.Insert(Precision - Scale, Constant.DFT_DECIMAL_POINT);

            return ret;
        }

        /// <summary>
        /// Format num
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string FormatNum(decimal value)
        {
            return value.ToString(String.Format("N{0}", Scale), CultureInfo.CreateSpecificCulture(Constant.DFT_CULTURE_NAME));
        }
    }

    /// <summary>
    /// Display Name Attribute
    /// Author: ISV-Phuong
    /// </summary>
    public sealed class iDisplayNameAttribute : DisplayNameAttribute
    {
        public string DataFormatString { get; set; }
        public string Name { get; set; }

        /// <summary>
        /// Display name
        /// </summary>
        public override string DisplayName
        {
            get
            {
                //Get label
                var data = UserSession.Session.SysCache.GetLabel(this.Name);

                if (string.IsNullOrEmpty(data))
                {
                    if (!string.IsNullOrEmpty(this.DataFormatString))
                    {
                        return string.Format(DataFormatString, this.DisplayName);
                    }
                    return base.DisplayName;

                }
                if (string.IsNullOrEmpty(this.DataFormatString))
                {
                    return data;
                }
                return string.Format(DataFormatString, data);

            }
        }
    }

    /// <summary>
    /// No Cache Attribute
    /// Author: ISV-Vinh
    /// </summary>
    public class iNoCacheAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Clear all cache browser
        /// </summary>
        /// <param name="filterContext">ResultExecutingContext</param>
        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddDays(-1));
            filterContext.HttpContext.Response.Cache.SetValidUntilExpires(false);
            filterContext.HttpContext.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
            filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            filterContext.HttpContext.Response.Cache.SetNoStore();
            filterContext.HttpContext.Response.BufferOutput = true;

            base.OnResultExecuting(filterContext);
        }
    }

    /// <summary>
    /// HttpParamAction
    /// Author: ISV-Vinh
    /// </summary>
    public class iHttpParamActionAttribute : ActionNameSelectorAttribute
    {
        /// <summary>
        /// IsValidName
        /// </summary>
        /// <param name="controllerContext">controllerContext</param>
        /// <param name="actionName">actionName</param>
        /// <param name="methodInfo">methodInfo</param>
        /// <returns></returns>
        public override bool IsValidName(ControllerContext controllerContext, string actionName, MethodInfo methodInfo)
        {
            if (actionName.Equals(methodInfo.Name, StringComparison.InvariantCultureIgnoreCase) && controllerContext.Controller.ControllerContext.RouteData.Values["IsSelected"] == null)
            {
                return true;
            }

            if (!actionName.Equals("Action", StringComparison.InvariantCultureIgnoreCase))
            {
                return false;
            }

            var request = controllerContext.RequestContext.HttpContext.Request;
            if (request[methodInfo.Name] != null)
            {
                controllerContext.Controller.ControllerContext.RouteData.Values.Add("IsSelected",true);
                return true;
            }
            return false;
        }
    }

    /// <summary>
    /// Day Date Attribute
    /// Author : ISV-Thuy
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iDDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="monthProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iDDateAttribute(string monthProperty, string yearProperty)
            : base()
        {
            this.MonthProperty = monthProperty;
            this.YearProperty = yearProperty;
        }

        public string MonthProperty { get; private set; }
        public string YearProperty { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //------------------- month -------------------------------------
            //Get PropertyInfo Object  
            var monthPropertyInfo = validationContext.ObjectType.GetProperty(this.MonthProperty);
            if (monthPropertyInfo == null)
            {
                throw new ArgumentNullException("monthProperty");
            }

            //Get Value of the property  
            var monthValue = monthPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //------------------- year -------------------------------------
            //Get PropertyInfo Object  
            var yearPropertyInfo = validationContext.ObjectType.GetProperty(this.YearProperty);
            if (yearPropertyInfo == null)
            {
                throw new ArgumentNullException("yearProperty");
            }

            //Get Value of the property  
            var yearValue = yearPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //--------------- check require Month and year ----------------------
            if ((monthValue != default(object) || yearValue != default(object)) && value == null)
            {
                //Format Message
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0002);
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }

            //----------------check Date vaild-----------------------------
            if (value != default(object))
            {
                Match matchDay = Regex.Match(value.ToString(), Constant.PATTERN_NUMERIC, RegexOptions.Compiled);
                if (!matchDay.Success)
                {
                    //Format Message
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0013);
                    message = String.Format(message, validationContext.DisplayName);
                    return new ValidationResult(message);
                }

                if (monthValue != default(object) && yearValue != default(object))
                {
                    Match matchYear = Regex.Match(yearValue.ToString(), Constant.PATTERN_NUMERIC, RegexOptions.Compiled);
                    if (matchYear.Success && yearValue.ToString().Length == 4 && int.Parse(yearValue.ToString()) <= Constant.MAX_YEAR && int.Parse(yearValue.ToString()) >= Constant.MIN_YEAR)
                    {
                        string date = value + "/" + monthValue + "/" + yearValue;
                        DateTime dateTime = new DateTime();
                        if (!CommonUtil.TryParseDate(date, ref dateTime))
                        {
                            string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0020);
                            return new ValidationResult(message);
                        }
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Month Date Attribute
    /// Author : ISV-Thuy
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iYDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dayProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iYDateAttribute(string dayProperty, string monthProperty)
            : base()
        {
            this.DayProperty = dayProperty;
            this.MonthProperty = monthProperty;
        }

        public string DayProperty { get; private set; }
        public string MonthProperty { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //------------------- month -------------------------------------
            //Get PropertyInfo Object  
            var dayPropertyInfo = validationContext.ObjectType.GetProperty(this.DayProperty);
            if (dayPropertyInfo == null)
            {
                throw new ArgumentNullException("dayProperty");
            }

            //Get Value of the property  
            var dayValue = dayPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //------------------- year -------------------------------------
            //Get PropertyInfo Object  
            var monthPropertyInfo = validationContext.ObjectType.GetProperty(this.MonthProperty);
            if (monthPropertyInfo == null)
            {
                throw new ArgumentNullException("monthProperty");
            }

            //Get Value of the property  
            var monthValue = monthPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //--------------- check require year ----------------------
            if ((dayValue != default(object) || monthValue != default(object)) && value == null)
            {
                //Format Message
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0002);
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }

            //----------------check min < year < max ----------------------           
            if (value != default(object))
            {
                Match matchYear = Regex.Match(value.ToString(), Constant.PATTERN_NUMERIC, RegexOptions.Compiled);
                if (!matchYear.Success)
                {
                    //Format Message
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0013);
                    message = String.Format(message, validationContext.DisplayName);
                    return new ValidationResult(message);
                }

                if (int.Parse(value.ToString()) > Constant.MAX_YEAR || int.Parse(value.ToString()) < Constant.MIN_YEAR)
                {
                    //Format Message
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0021);
                    message = String.Format(message, validationContext.DisplayName, Constant.MIN_YEAR, Constant.MAX_YEAR);
                    return new ValidationResult(message);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Month Date Attribute
    /// Author : ISV-Thuy
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iMDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dayProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iMDateAttribute(string dayProperty, string yearProperty)
            : base()
        {
            this.DayProperty = dayProperty;
            this.YearProperty = yearProperty;
        }

        public string DayProperty { get; private set; }
        public string YearProperty { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //------------------- month -------------------------------------
            //Get PropertyInfo Object  
            var dayPropertyInfo = validationContext.ObjectType.GetProperty(this.DayProperty);
            if (dayPropertyInfo == null)
            {
                throw new ArgumentNullException("dayProperty");
            }

            //Get Value of the property  
            var dayValue = dayPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //------------------- year -------------------------------------
            //Get PropertyInfo Object  
            var yearPropertyInfo = validationContext.ObjectType.GetProperty(this.YearProperty);
            if (yearPropertyInfo == null)
            {
                throw new ArgumentNullException("yearProperty");
            }

            //Get Value of the property  
            var yearValue = yearPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //--------------- check require day and year ----------------------
            if ((dayValue != default(object) || yearValue != default(object)) && value == null)
            {
                //Format Message
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0002);
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Author : ISV-PHUONG
    /// </summary>
    public sealed class iAuthorize : AuthorizeAttribute
    {
        private const string URL_LOGIN = "/";
        private const string URL_TIMEOUT = "/Base/Timeout";
        /// <summary>
        /// On Authorization
        /// </summary>
        /// <param name="filterContext">Authorization Context</param>
        public override void OnAuthorization(
                         AuthorizationContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            if (!UserSession.Session.IsAuthenticated)
            {
                string redirectUrl = URL_LOGIN; // Default Login Url 
                string cotrollerName = Convert.ToString(filterContext.RequestContext.RouteData.Values["controller"]);
                if (cotrollerName == "Search")
                {
                    redirectUrl = URL_TIMEOUT;
                }

                string actioName = Convert.ToString(filterContext.RequestContext.RouteData.Values["action"]);
                if ((cotrollerName == "OutboundDeliveryIndication" && (actioName == "OutboundDeliveryIndicationDetail" || actioName == "OutboundDeliveryIndicationDetailConfirm")) ||
                    (cotrollerName == "MoveIndication" && (actioName == "MoveIndicationDetail" || actioName == "MoveIndicationDetailConfirm")))
                {
                    redirectUrl = URL_TIMEOUT;
                }

                filterContext.Result = new RedirectResult(redirectUrl);
            }
        }
    }

    /// <summary>
    /// Author : ISV-Vinh
    /// </summary>
    public sealed class iExistCache : AuthorizeAttribute
    {
        private const string URL_LOGIN = "/";

        /// <summary>
        /// On Authorization
        /// </summary>
        /// <param name="filterContext">Authorization Context</param>
        public override void OnAuthorization(
                         AuthorizationContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            if (UserSession.Session.SysCache == null)
            {
                filterContext.Result = new RedirectResult(URL_LOGIN);
            }
        }
    }

    /// <summary>
    /// Author : ISV-Vinh
    /// </summary>
    public sealed class iSinglePage : AuthorizeAttribute
    {
        private const string URL_NO_ACCESS = "/";

        /// <summary>
        /// On Authorization
        /// </summary>
        /// <param name="filterContext">Authorization Context</param>
        public override void OnAuthorization(
                         AuthorizationContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            if (filterContext.RequestContext.HttpContext.Request.UrlReferrer != null ||
                filterContext.RequestContext.HttpContext.Request.UrlReferrer.Authority != filterContext.RequestContext.HttpContext.Request.Url.Authority)
            {

            }
        }
    }


    /// <summary>
    /// Compare Date Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareDateTAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dayProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iCompareDateTAttribute(string dateToProperty, CompareType compareType,
                                        string lblFrom, string lblTo)
            : base()
        {
            this.dateToProperty = dateToProperty;
            this.CompareType = compareType;
            this.lblFrom = lblFrom;
            this.lblTo = lblTo;
        }

        public string dateToProperty { get; private set; }
        public string lblFrom { get; private set; }
        public string lblTo { get; private set; }
        public CompareType CompareType { get; private set; }

        private string messageCD;

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //---------------------- month from -----------------------------------------
            //Get PropertyInfo Object  
            var dateToPropertyInfo = validationContext.ObjectType.GetProperty(this.dateToProperty);
            if (dateToPropertyInfo == null)
            {
                throw new ArgumentNullException("dateToProperty");
            }

            //Get Value of the property  
            var dateToValue = dateToPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------- comparision ----------------------------------------
            //Actual comparision  
            if (value != default(object) &&
                dateToValue != default(object))
            {
                DateControl dateFromC = (DateControl)value;
                DateControl dateToC = (DateControl)dateToValue;

                string dateFrom = String.Format("{0}/{1}/{2}", dateFromC.Day, dateFromC.Month, dateFromC.Year);
                string dateTo = String.Format("{0}/{1}/{2}", dateToC.Day, dateToC.Month, dateToC.Year);

                //parse number value
                DateTime datToValue = default(DateTime);
                DateTime datFromValue = default(DateTime);

                if (CommonUtil.TryParseDate(dateFrom, ref datFromValue) && CommonUtil.TryParseDate(dateTo, ref datToValue))
                {
                    //comparision
                    if (!this.IsValid(datFromValue, datToValue))
                    {
                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(messageCD);
                        message = String.Format(message, UserSession.Session.SysCache.GetLabel(lblFrom), UserSession.Session.SysCache.GetLabel(lblTo));

                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid compare
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="otherValue">otherValue</param>
        /// <returns></returns>
        private bool IsValid(DateTime value, DateTime otherValue)
        {
            bool result;
            switch (this.CompareType)
            {
                case CompareType.LessThan:
                    result = value < otherValue;
                    //messageCD = Constant.MES_LESS_THAN;
                    break;

                case CompareType.LessThanOrEqual:
                    result = value <= otherValue;
                    messageCD = Constant.MES_E0005;
                    break;

                case CompareType.GreaterThan:
                    result = value > otherValue;
                    //messageCD = Constant.MES_GREATER_THAN;
                    break;

                default:
                    result = value >= otherValue;
                    //messageCD = Constant.MES_GREATER_EQUAL;
                    break;
            }

            return result;
        }
    }

    /// <summary>
    /// Compare String Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareStringTAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dayProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iCompareStringTAttribute(string conTrolToProperty, CompareType compareType,
                                        string lblFrom, string lblTo)
            : base()
        {
            this.conTrolToProperty = conTrolToProperty;
            this.CompareType = compareType;
            this.lblFrom = lblFrom;
            this.lblTo = lblTo;
        }

        public string conTrolToProperty { get; private set; }
        public string lblFrom { get; private set; }
        public string lblTo { get; private set; }
        public CompareType CompareType { get; private set; }

        private string messageCD;

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //---------------------- month from -----------------------------------------
            //Get PropertyInfo Object  
            var toPropertyInfo = validationContext.ObjectType.GetProperty(this.conTrolToProperty);
            if (toPropertyInfo == null)
            {
                throw new ArgumentNullException("conTrolToProperty");
            }

            //Get Value of the property  
            var stoValue = toPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //---------------- comparision ----------------------------------------
            //Actual comparision  
            if (value != default(object) &&
                stoValue != default(object))
            {
                string fromValue = (string)value;
                string toValue = (string)stoValue;


                if (!string.IsNullOrEmpty(fromValue) && !string.IsNullOrEmpty(toValue))
                {
                    //comparision
                    if (!this.IsValid(fromValue, toValue))
                    {
                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(messageCD);
                        message = String.Format(message, UserSession.Session.SysCache.GetLabel(lblFrom), UserSession.Session.SysCache.GetLabel(lblTo));

                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid compare
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="otherValue">otherValue</param>
        /// <returns></returns>
        private bool IsValid(string value, string otherValue)
        {
            bool result;
            switch (this.CompareType)
            {
                case CompareType.LessThan:
                    result = value.CompareTo(otherValue) < 0;
                    //messageCD = Constant.MES_LESS_THAN;
                    break;

                case CompareType.LessThanOrEqual:
                    result = value.CompareTo(otherValue) <= 0;
                    messageCD = Constant.MES_E0005;
                    break;

                case CompareType.GreaterThan:
                    result = value.CompareTo(otherValue) > 0;
                    //messageCD = Constant.MES_GREATER_THAN;
                    break;

                default:
                    result = value.CompareTo(otherValue) >= 0;
                    //messageCD = Constant.MES_GREATER_EQUAL;
                    break;
            }

            return result;
        }
    }

    /// <summary>
    /// Required Date Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class iRequiredDateAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public iRequiredDateAttribute()
            : base()
        {
        }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateControl dateValue = (DateControl)value;
            if (dateValue == default(DateControl) || String.IsNullOrEmpty(dateValue.DateValue()))
            {
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0002);
                message = String.Format(message, validationContext.DisplayName);
                return new ValidationResult(message);
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Date Range Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iDateRangeAttribute : ValidationAttribute
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public iDateRangeAttribute()
            : base()
        {
            MinValue = DateTime.MinValue;
            MaxValue = DateTime.MaxValue;
        }

        /// <summary>
        /// Constructpr
        /// </summary>
        /// <param name="minValue">MinValue(Format:dd/MM/yyyy)</param>
        /// <param name="maxValue">MaxValue(Format:dd/MM/yyyy)</param>
        public iDateRangeAttribute(string minValue, string maxValue)
            : base()
        {
            MinValue = CommonUtil.ParseDate(minValue);
            MaxValue = CommonUtil.ParseDate(maxValue);
        }

        public DateTime MinValue { get; set; }
        public DateTime MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateControl dateValue = (DateControl)value;
            if (dateValue != default(DateControl))
            {
                //Check number
                DateTime temp = default(DateTime);
                if (CommonUtil.TryParseDate(String.Format("{0}/{1}/{2}", dateValue.Day, dateValue.Month, dateValue.Year), ref temp))
                {
                    //Check Min, Max
                    if (temp < MinValue || temp > MaxValue)
                    {
                        //must in range
                        string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                        message = String.Format(message, validationContext.DisplayName, MinValue.ToString(Constant.FMT_DATE), MaxValue.ToString(Constant.FMT_DATE));
                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Between Number Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iBetweenNumberAttribute : ValidationAttribute
    {

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="fromValue">fromValue</param>
        /// <param name="toValue">toValue</param>
        public iBetweenNumberAttribute(string fromValue, string toValue)
            : base()
        {
            this.FromValue = fromValue;
            this.ToValue = toValue;
        }

        public string FromValue { get; private set; }
        public string ToValue { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //Get from value Object  
            var fromValueInfo = validationContext.ObjectType.GetProperty(this.FromValue);
            if (fromValueInfo == null)
            {
                throw new ArgumentNullException("fromValueInfo");
            }

            //Get PropertyInfo Object  
            var toValueInfo = validationContext.ObjectType.GetProperty(this.ToValue);
            if (toValueInfo == null)
            {
                throw new ArgumentNullException("toValueInfo");
            }

            //Get Value of the property  
            var fValue = fromValueInfo.GetValue(validationContext.ObjectInstance, null);
            var tValue = toValueInfo.GetValue(validationContext.ObjectInstance, null);

            //Actual comparision  
            if (value != default(object) && fValue != default(object) && tValue != default(object))
            {
                //parse number value
                double dblValue = default(double);
                double dblFrom = default(double);
                double dblTo = default(double);
                if (CommonUtil.TryParseNumber(value.ToString(), ref dblValue) && CommonUtil.TryParseNumber(fValue.ToString(), ref dblFrom) && CommonUtil.TryParseNumber(tValue.ToString(), ref dblTo))
                {
                    //comparision
                    if (!this.IsValid(dblValue, dblFrom, dblTo))
                    {
                        //Get Display name of other propertise
                        string formDisplayName = CommonUtil.GetNameFromPropertyInfo(this.FromValue, fromValueInfo);
                        string toDisplayName = CommonUtil.GetNameFromPropertyInfo(this.ToValue, toValueInfo);

                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0021);
                        message = String.Format(message, validationContext.DisplayName, formDisplayName, toDisplayName);
                        return new ValidationResult(message);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid Between
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="fromValue">fromValue</param>
        /// <param name="toValue">toValue</param>
        /// <returns></returns>
        private bool IsValid(double value, double fromValue, double toValue)
        {
            return value >= fromValue && value <= toValue;
        }
    }
}
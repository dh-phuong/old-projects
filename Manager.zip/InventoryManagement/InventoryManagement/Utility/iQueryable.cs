﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using InventoryManagement.Models;
using System.Linq.Expressions;

namespace InventoryManagement.iQueryable
{
    /// <summary>
    /// Quryable extension
    /// Author: ISV-Vinh
    /// </summary>
    public static class iQueryable
    {
        /// <summary>
        /// Order by command
        /// </summary>
        /// <typeparam name="TEntity">TEntity</typeparam>
        /// <param name="source">IQueryable</param>
        /// <param name="orderByProperty">property name</param>
        /// <param name="direction">ASC, DESC</param>
        /// <returns>IQueryable</returns>
        public static IQueryable<TEntity> iOrderBy<TEntity>(this IQueryable<TEntity> source, string orderByProperty, SortDirection direction)
        {
            string command = direction == SortDirection.Descending ? "OrderByDescending" : "OrderBy";
            var type = typeof(TEntity);
            var property = type.GetProperty(orderByProperty);
            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);
            var resultExpression = Expression.Call(typeof(Queryable), command, new Type[] { type, property.PropertyType },
                                          source.Expression, Expression.Quote(orderByExpression));
            return source.Provider.CreateQuery<TEntity>(resultExpression);
        }

        /// <summary>
        /// Then by
        /// </summary>
        /// <typeparam name="TEntity">TEntity</typeparam>
        /// <param name="source">IQueryable</param>
        /// <param name="thenByProperty">Thenby Property Name</param>
        /// <param name="direction">ASC, DESC</param>
        /// <returns>IQueryable</returns>
        public static IQueryable<TEntity> iThenBy<TEntity>(this IQueryable<TEntity> source, string thenByProperty, SortDirection direction)
        {
            string command = direction == SortDirection.Descending ? "ThenByDescending" : "ThenBy";
            var type = typeof(TEntity);
            var property = type.GetProperty(thenByProperty);
            var parameter = Expression.Parameter(type, "p");
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);
            var resultExpression = Expression.Call(typeof(Queryable), command, new Type[] { type, property.PropertyType },
                                          source.Expression, Expression.Quote(orderByExpression));
            return source.Provider.CreateQuery<TEntity>(resultExpression);
        }
    }
}
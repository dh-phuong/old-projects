﻿using System;
using System.Linq;
using System.Reflection;
using System.ComponentModel;
using System.Globalization;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using InventoryManagement.Validation;
using InventoryManagement.DataAccess;

using System.Collections.Generic;
using System.Web.Mvc;
using System.Web;
using System.Collections;

namespace InventoryManagement.Utility
{
    /// <summary>
    /// Common Utility
    /// </summary>
    public class CommonUtil
    {
        /// <summary>
        /// Cach resource
        /// Author: ISV-Phuong
        /// </summary>
        public static void InitCache()
        {
            var cache = new InventoryManagement.Cache();

            //Cache message
            using (MMessageService mMessage = new MMessageService())
            {
                var list = mMessage.GetList();
                cache.AddMessages(list);
            }

            //Cache label
            using (MLabelService mLabel = new MLabelService())
            {
                var list = mLabel.GetList();
                cache.AddLabels(list);
            }
            UserSession.Session.SetCacheSession(cache);
        }

        /// <summary>
        /// Get Description of Enum
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">Enum value</param>
        /// <returns>Description</returns>
        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(
                                                typeof(DescriptionAttribute), false);
            if (attributes != null && attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        /// <summary>
        /// Set value to session
        /// Author: ISV-PHUONG
        /// </summary>
        /// <typeparam name="ObjectType"></typeparam>
        /// <param name="Controller"></param>
        /// <param name="Value"></param>
        /// <returns>Session Key</returns>
        public static string SetValueToSession<ObjectType>(System.Web.Mvc.Controller Controller, ObjectType Value)
        {
            const string SESSION_PROPERTY_NAME = "SessionKey";

            var SessionKey = Guid.NewGuid().ToString().ToUpper();

            if (Value != null)
            {
                //set key to model
                var SessionProperty = Value.GetType().GetProperty(SESSION_PROPERTY_NAME);
                if (SessionProperty != null)
                {
                    SessionProperty.SetValue(Value, SessionKey, null);
                }
            }

            Controller.Session[SessionKey] = Value;

            return SessionKey;
        }

        /// <summary>
        /// To Querry String
        /// Author: ISV-PHUONG
        /// </summary>
        /// <param name="param"></param>
        /// <returns>QuerryString</returns>
        public static string ToQueryString(params System.Collections.Generic.KeyValuePair<string, object>[] param)
        {            
            System.Collections.Specialized.NameValueCollection QryStr = System.Web.HttpUtility.ParseQueryString(string.Empty);
            for (int i = 0; i <param.Length ; i++)
            {
                QryStr[param[i].Key] = Convert.ToString(param[i].Value);
                
            }
           return QryStr.ToString();
        }

        /// <summary>
        /// Check is integer
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>TRUE: Integer, FLASE: not integer</returns>
        public static bool IsInteger(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            int temp;
            return int.TryParse(value, NumberStyles.AllowThousands, new CultureInfo(Constant.DFT_CULTURE_NAME), out temp);
        }

        /// <summary>
        /// Get Current Language string
        /// </summary>
        /// <returns></returns>
        public static string GetLanguageStr()
        {
            switch (UserSession.Session.Language)
            {
                case LanguageFlag.English:
                    return "vn";
                case LanguageFlag.Vietnamese:
                    return "vn";
                case LanguageFlag.Japanese:
                    return "jp";
                default:
                    return "vn";
            }
        }

        /// <summary>
        /// Check is Number
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>TRUE: number, FLASE: not number</returns>
        public static bool IsNumber(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            double temp;
            return double.TryParse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME), out temp);
        }

        /// <summary>
        /// Check is data
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>TRUE: date, FLASE: not date</returns>
        public static bool IsDate(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length != Constant.FMT_DATE.Length)
            {
                return false;
            }

            DateTime temp;
            return DateTime.TryParseExact(value, Constant.FMT_DATE, new CultureInfo(Constant.DFT_CULTURE_NAME), DateTimeStyles.None, out temp);
        }

        /// <summary>
        /// Parse Integer
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>integer</returns>
        public static int ParseInteger(string value)
        {
            return int.Parse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME));
        }

        /// <summary>
        /// Try parse integer
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="result">out param int</param>
        /// <returns>TRUE: is Integer, FALSE: is not integer</returns>
        public static bool TryParseInt(string value, ref int result)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            if (int.TryParse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME), out result))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Try parse number
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="result">out param number</param>
        /// <returns>TRUE: is number, FALSE: is not number</returns>
        public static bool TryParseNumber(string value, ref double result)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            if (double.TryParse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME), out result))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Try parse decimal
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="result">out param decimal</param>
        /// <returns>TRUE: is decimal, FALSE: is not decimal</returns>
        public static bool TryParseDecimal(string value, ref decimal result)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            if (decimal.TryParse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME), out result))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Parse Decimal
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>decimal</returns>
        public static decimal ParseDecimal(string value)
        {
            return decimal.Parse(value, NumberStyles.Number, new CultureInfo(Constant.DFT_CULTURE_NAME));
        }

        /// <summary>
        /// Try parse Date
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="result">out param Date</param>
        /// <returns>TRUE: is Date, FALSE: is not Date</returns>
        public static bool TryParseDate(string value, ref DateTime result)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            if (DateTime.TryParseExact(value, Constant.FMT_DATE, new CultureInfo(Constant.DFT_CULTURE_NAME), DateTimeStyles.None, out result))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Check Scale decimal number 
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">decimal number </param>
        /// <param name="scale">scale</param>
        public static bool CheckScale(decimal value, int scale)
        {
            decimal temp = decimal.Parse(value.ToString("G29"));
            System.Data.SqlTypes.SqlDecimal x = new System.Data.SqlTypes.SqlDecimal(temp);
            return x.Scale <= scale;
        }

        /// <summary>
        /// Parse Date
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="value">string value</param>
        /// <returns>DateTime</returns>
        public static DateTime ParseDate(string value)
        {
            return DateTime.ParseExact(value, Constant.FMT_DATE, new CultureInfo(Constant.DFT_CULTURE_NAME), DateTimeStyles.None);
        }

        /// <summary>
        /// Parse Date
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="fromFormat">format</param>
        /// <returns>DateTime</returns>
        public static DateTime ParseDate(string value, string fromFormat)
        {
            return DateTime.ParseExact(value, fromFormat, new CultureInfo(Constant.DFT_CULTURE_NAME), DateTimeStyles.None);
        }

        /// <summary>
        /// Parse Date
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="value">string value</param>
        /// <param name="fromFormat">from format</param>
        /// <param name="toFormat">to format</param>
        /// <returns>string date</returns>
        public static string ParseDate(string value, string fromFormat, string toFormat)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }
            else {
                return DateTime.ParseExact(value, fromFormat, new CultureInfo(Constant.DFT_CULTURE_NAME), DateTimeStyles.None).ToString(toFormat);
            }
            
        }

        /// <summary>
        /// Get name from property info
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="attributeName">attribute Name</param>
        /// <param name="propertyInfo">Property Info</param>
        /// <returns>Name</returns>
        public static string GetNameFromPropertyInfo(string attributeName, PropertyInfo propertyInfo)
        {
            string result = attributeName;

            // First look into attributes on a type and it's parents
            iDisplayNameAttribute attr;
            attr = (iDisplayNameAttribute)propertyInfo.GetCustomAttributes(typeof(iDisplayNameAttribute), true).SingleOrDefault();

            // Look for [MetadataType] attribute in type hierarchy
            if (attr == null)
            {
                MetadataTypeAttribute metadataType = (MetadataTypeAttribute)propertyInfo.GetCustomAttributes(typeof(MetadataTypeAttribute), true).FirstOrDefault();
                if (metadataType != null)
                {
                    var property = metadataType.MetadataClassType.GetProperty(attributeName);
                    if (property != null)
                    {
                        attr = (iDisplayNameAttribute)property.GetCustomAttributes(typeof(iDisplayNameAttribute), true).SingleOrDefault();
                    }
                }
            }

            if (attr != null)
            {
                result = attr.DisplayName;
            }

            return result;
        }

        /// <summary>
        /// Get display name attribute of model
        /// Author: ISV-Loc
        /// </summary>
        /// <typeparam name="T">Model</typeparam>
        /// <typeparam name="U">Propertise</typeparam>
        /// <param name="exp">Expression</param>
        /// <returns>display name</returns>
        public static string GetDisplayName<T, U>(Expression<Func<T, U>> exp)
        {
            var me = exp.Body as MemberExpression;
            if (me == null)
                throw new ArgumentException("Must be a MemberExpression.", "exp");

            var attr = me.Member
                         .GetCustomAttributes(typeof(iDisplayNameAttribute), false)
                         .Cast<iDisplayNameAttribute>()
                         .SingleOrDefault();

            return (attr != null) ? attr.DisplayName : me.Member.Name;
        }

        ///Set RolesCD SelectList
        ///ISV-Loc
        ///</summary>
        public static List<SelectListItem> GetListMonths()
        {
            List<SelectListItem> items = new List<SelectListItem>();

            items.Add(new SelectListItem { Text = "01", Value = "01" });
            items.Add(new SelectListItem { Text = "02", Value = "02" });
            items.Add(new SelectListItem { Text = "03", Value = "03" });
            items.Add(new SelectListItem { Text = "04", Value = "04" });
            items.Add(new SelectListItem { Text = "05", Value = "05" });
            items.Add(new SelectListItem { Text = "06", Value = "06" });
            items.Add(new SelectListItem { Text = "07", Value = "07" });
            items.Add(new SelectListItem { Text = "08", Value = "08" });
            items.Add(new SelectListItem { Text = "09", Value = "09" });
            items.Add(new SelectListItem { Text = "10", Value = "10" });
            items.Add(new SelectListItem { Text = "11", Value = "11" });
            items.Add(new SelectListItem { Text = "12", Value = "12" });

            return items;
        }

        /// <summary>
        /// Create List DataKind for SortOrder
        /// ISV-Loc
        /// </summary>
        /// <returns></returns>
        public static List<SelectListItem> GetListSortOrder()
        {
            List<SelectListItem> items = new List<SelectListItem>();

            items.Add(new SelectListItem { Text = UserSession.Session.SysCache.GetLabel(InventoryManagement.Common.Constant.LBL_L0035), Value = ((int)InventoryManagement.Common.SortOrder.Ascending).ToString() });
            items.Add(new SelectListItem { Text = UserSession.Session.SysCache.GetLabel(InventoryManagement.Common.Constant.LBL_L0036), Value = ((int)InventoryManagement.Common.SortOrder.Descending).ToString() });
            return items;
        }

        /// <summary>
        /// encode unicode string
        /// Author: ISV-PHUONG
        /// </summary>
        /// <param name="text">string input</param>
        /// <returns>HtmlString</returns>
        public static HtmlString ConvertHTMLString(string text)
        {
            return new HtmlString(text);
        }

        /// <summary>
        /// Check Authority for Screen or Action
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="RolesCD">RolesCD</param>
        /// <param name="viewCD">Screen Code</param>
        /// <param name="listGroupDetail">List Group Detail</param>
        /// <returns></returns>
        public static bool CheckAuthority(string RolesCD, string viewCD)
        {
            if (UserSession.Session.LoginInfo.User.GroupCD == Constant.GROUP_SUPPER_ADMIN_CD)
            {
                return true;
            }

            bool result = false;
            List<Models.MGroup_D> listGroupDetail = UserSession.Session.LoginInfo.ListGroupDetail;
            string groupCD = UserSession.Session.LoginInfo.User.GroupCD;

            if (listGroupDetail == null)
            {
                return result;
            }
            result = listGroupDetail.Any(m => m.GroupCD.Equals(groupCD)
                                              && m.EnableFlag.Equals(true)
                                              && m.RolesCD.Equals(RolesCD)
                                              && m.ViewCD.Equals(viewCD));
            return result;
        }

        /// <summary>
        /// Get Group Authority
        /// </summary>
        /// <returns>Hashtable</returns>
        public static Hashtable GetGroupAuthority()
        {
            Hashtable ret = new Hashtable();

            // ユーザーマスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_USER_MASTER, ret);

            //  商品マスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_PRODUCT_MASTER, ret);

            //  出荷先マスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_CUSTOMER_MASTER, ret);

            //  自社マスタ
            CommonUtil.AddAuthority("11001000", Constant.GROUP_VIEW_COMPANY_MASTER, ret);

            //  ロケーションマスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_LOCATION_MASTER, ret);

            //  グループマスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_GROUP_MASTER, ret);

            //  カテゴリーマスタ
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_CATEGORY_MASTER, ret);

            //   入荷
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_INBOUND_DELIVERY, ret);

            //   入庫検品
            CommonUtil.AddAuthority("00000010", Constant.GROUP_VIEW_GOODS_RECEIPT_INSPECTION, ret);

            //   在庫照会
            CommonUtil.AddAuthority("01011000", Constant.GROUP_VIEW_STOCK_INQUIRY, ret);

            //   出荷指示
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION, ret);

            //   出庫検品
            CommonUtil.AddAuthority("00000010", Constant.GROUP_VIEW_GOODS_ISSUE_INSPECTION, ret);

            //    出荷検品
            CommonUtil.AddAuthority("00000011", Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION, ret);

            //    移動指示
            CommonUtil.AddAuthority("11111100", Constant.GROUP_VIEW_MOVE_INDICATION, ret);

            //    移動出庫検品
            CommonUtil.AddAuthority("00000010", Constant.GROUP_VIEW_MOVE_GOODS_ISSUE_INSPECTION, ret);

            //    移動出荷検品
            CommonUtil.AddAuthority("00000011", Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION, ret);

            //    棚卸宣言
            CommonUtil.AddAuthority("11011001", Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM, ret);

            //    棚卸検品
            CommonUtil.AddAuthority("00000010", Constant.GROUP_VIEW_STOCK_TAKING_DEF, ret);

            //    受払表印刷
            CommonUtil.AddAuthority("00010000", Constant.GROUP_VIEW_BALANCE_IN_STORE_PRINT, ret);

            //    出荷済照会
            CommonUtil.AddAuthority("01011000", Constant.GROUP_VIEW_OUTBOUND_DELIVERED_INQUIRY, ret);

            //出荷済一覧表出力
            CommonUtil.AddAuthority("00010000", Constant.GROUP_VIEW_OUTBOUND_DELIVERED_REPORT, ret);

            return ret;
        }

        /// <summary>
        /// Add Authority
        /// </summary>
        /// <param name="authority">authority</param>
        /// <param name="viewSreen">viewSreen</param>
        /// <param name="htb">Hashtable</param>
        private static void AddAuthority(string authority, string viewSreen, Hashtable htb)
        {
            for(int i = 0; i < authority.Length; i++)
            {
                if (authority[i].Equals('1'))
                {
                    string roleCD = string.Empty;
                    switch (i)
                    {
                        case 0:
                            roleCD = Constant.GROUP_ROLE_INSERT_CD;
                            break;

                        case 1:
                            roleCD = Constant.GROUP_ROLE_UPDATE_CD;
                            break;

                        case 2:
                            roleCD = Constant.GROUP_ROLE_DELETE_CD;
                            break;

                        case 3:
                            roleCD = Constant.GROUP_ROLE_EXPORT_CD;
                            break;

                        case 4:
                            roleCD = Constant.GROUP_ROLE_VIEW_CD;
                            break;

                        case 5:
                            roleCD = Constant.GROUP_ROLE_INCLUDE_DELETE_CD;
                            break;

                        case 6:
                            roleCD = Constant.GROUP_ROLE_PICKING;
                            break;

                        default:
                            roleCD = Constant.GROUP_ROLE_CANCEL;
                            break;
                    }
                    htb.Add(viewSreen + roleCD, true);
                }
            }
        }
    }
}
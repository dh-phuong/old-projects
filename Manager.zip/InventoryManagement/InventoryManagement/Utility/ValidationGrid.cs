﻿using System.ComponentModel.DataAnnotations;
using System;
using InventoryManagement.Utility;
using System.Globalization;
using InventoryManagement.Common;
using System.Web.Mvc;
using System.Web;
using InventoryManagement.DataAccess;
using System.Text.RegularExpressions;
using System.Reflection;
using System.ComponentModel;
using System.Linq;
using InventoryManagement.Models;

namespace InventoryManagement.Validation
{
    /// <summary>
    /// Required Date Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class iRequiredDateGridAttribute : ValidationAttribute
    {

        public string[] EmptyWhen { get; set; }
        public string[] DateConTrol { get; set; }
        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public iRequiredDateGridAttribute()
            : base()
        {
        }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {

            var instant = validationContext.ObjectInstance;
            if (EmptyWhen != default(string[]) && DateConTrol != default(string[]))
            {
                var empty = true;
                var props = instant.GetType().GetProperties();

                if (EmptyWhen != default(string[]))
                {
                    var tmp = props.Where(m => EmptyWhen.Contains(m.Name));
                    empty = !tmp.Any(m => m.GetValue(instant, null) != default(object));
                }
                if (DateConTrol != default(string[]))
                {
                    var tmpDate = props.Where(m => DateConTrol.Contains(m.Name));
                    empty &= !tmpDate.Any(m => ((DateControl)m.GetValue(instant, null)).DateValue() != string.Empty);
                }
                
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);
                if (!empty)
                {

                    DateControl dateValue = (DateControl)value;
                    if (dateValue == default(DateControl) || String.IsNullOrEmpty(dateValue.DateValue()))
                    {

                        string messageErr = String.Format(UserSession.Session.SysCache.GetMessage(Constant.MES_E0002), validationContext.DisplayName);
                        string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);

                        return new ValidationResult(messageErr + row);
                    }
                }
            }
            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Required Attribute
    /// Author: ISV-Phuong
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public class iRequiredGridAttribute : ValidationAttribute
    {
        public string[] EmptyWhen { get; set; }
        public string[] DateConTrol { get; set; }
        public string RowIndexName { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public iRequiredGridAttribute()
            : base()
        {
        }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var instant = validationContext.ObjectInstance;
            if (EmptyWhen != default(string[]) || DateConTrol != default(string[]))
            {
                var empty = true;
                var props = instant.GetType().GetProperties();

                if (EmptyWhen != default(string[])) 
                {
                    var tmp = props.Where(m => EmptyWhen.Contains(m.Name));
                    empty = !tmp.Any(m => m.GetValue(instant, null) != default(object));
                }
                if(DateConTrol != default(string[]))
                {
                    var tmpDate = props.Where(m => DateConTrol.Contains(m.Name));
                    empty &= !tmpDate.Any(m => ((DateControl)m.GetValue(instant, null)).DateValue() != string.Empty);
                }
        
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);
                if (!empty)
                {
                    if (value == default(object) || String.IsNullOrEmpty(value.ToString()))
                    {

                        string messageErr = String.Format( UserSession.Session.SysCache.GetMessage(Constant.MES_E0002), validationContext.DisplayName);

                        string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);

                        return new ValidationResult(messageErr + row);
                    }
                }

            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Integer Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iStringLengthGridAttribute : ValidationAttribute
    {

        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="maximumLength">MaximumLength</param>
        public iStringLengthGridAttribute(int maximumLength)
            : base()
        {
            MaximumLength = maximumLength;
            MinimumLength = 0;
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="maximumLength">MaximumLength</param>
        public iStringLengthGridAttribute(int maximumLength, int minimumLength)
            : base()
        {
            MaximumLength = maximumLength;
            MinimumLength = minimumLength;
        }

        public int MaximumLength { get; set; }
        public int MinimumLength { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var instant = validationContext.ObjectInstance;
            if (value != default(object))
            {
                var props = instant.GetType().GetProperties();
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);
                string strValue = value.ToString();

                //MaximumLength and MinimumLength
                if (strValue.Length > MaximumLength || strValue.Length < MinimumLength)
                {
                    string message = string.Empty;
                    if (MaximumLength != MinimumLength)
                    {
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0007);
                        message = String.Format(message, validationContext.DisplayName, MaximumLength, MinimumLength);
                    }
                    else 
                    {
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0024);
                        message = String.Format(message, validationContext.DisplayName, MaximumLength);
                    }
                     string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                     return new ValidationResult(message + row);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Compare Number Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iPatternGridAttribute : ValidationAttribute
    {

        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="otherProperty">otherProperty</param>
        public iPatternGridAttribute(PatternType patternType)
            : base()
        {
            this.PatternType = patternType;
        }

        public PatternType PatternType { get; private set; }
        private string pattern;


        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == default(object) || string.IsNullOrEmpty(value.ToString()))
            {

                return null;
            }

            string strValue = value.ToString();
            switch (PatternType)
            {
                case PatternType.AlphaNumeric:
                    pattern = Constant.PATTERN_ANPHA_NUMERIC;
                    break;
                case PatternType.Email:
                    pattern = Constant.PATTERN_EMAIL;
                    break;
                case PatternType.HaflWidth:
                    pattern = Constant.PATTERN_HAFL_WIDTH;
                    break;
                case PatternType.Numeric:
                    pattern = Constant.PATTERN_NUMERIC;
                    break;
                case PatternType.Tel:
                    pattern = Constant.PATTERN_TEL;
                    break;
                case PatternType.NumbericSubstract:
                    pattern = Constant.PATTERN_NUMERIC_SUBTRACT;
                    break;
                case PatternType.UpperAlphaNumeric:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC;
                    strValue = strValue.ToUpper();
                    break;
                case PatternType.AlphaNumericFlashSpace:
                    pattern = Constant.PATTERN_ANPHA_NUMERIC_FLASH;
                    break;
                case PatternType.UpperAlphaNumericFlash:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC_FLASH;
                    strValue = strValue.ToUpper();
                    break;
                case PatternType.UpperAlphaNumericSubtract:
                    pattern = Constant.PATTERN_UPPER_ANPHA_NUMERIC_SUBTRACT;
                    strValue = strValue.ToUpper();
                    break;
                default:
                    pattern = string.Empty;
                    break;
            }

            Match match = Regex.Match(strValue, pattern, RegexOptions.Compiled);


            // Here we check the Match instance.
            if (!match.Success)
            {
                var instant = validationContext.ObjectInstance;
                var props = instant.GetType().GetProperties();
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                //Format Message
                string message;
                switch (PatternType)
                {
                    case PatternType.AlphaNumeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0003);
                        break;
                    case PatternType.Email:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0017);
                        break;
                    case PatternType.HaflWidth:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0014);
                        break;
                    case PatternType.Numeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0013);
                        break;
                    case PatternType.Tel:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0004);
                        break;
                    case PatternType.UpperAlphaNumeric:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0003);
                        break;
                    case PatternType.UpperAlphaNumericFlash:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0018);
                        break;
                    case PatternType.AlphaNumericFlashSpace:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0025);
                        break;
                    case PatternType.NumbericSubstract:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0023);
                        break;
                    case PatternType.UpperAlphaNumericSubtract:
                        message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0026);
                        break;
                    default:
                        message = string.Empty;
                        break;
                }
                message = String.Format(message, validationContext.DisplayName);
                string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                return new ValidationResult(message + row);

            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Integer Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iIntegerGridAttribute : ValidationAttribute
    {
        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public iIntegerGridAttribute()
            : base()
        {
            MinValue = int.MinValue;
            MaxValue = int.MaxValue;
        }

        /// <summary>
        /// Constructpr
        /// </summary>
        /// <param name="minValue">MinValue</param>
        /// <param name="maxValue">MaxValue</param>
        public iIntegerGridAttribute(int minValue, int maxValue)
            : base()
        {
            MinValue = minValue;
            MaxValue = maxValue;
        }

        public int MinValue { get; set; }
        public int MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != default(object))
            {
                var instant = validationContext.ObjectInstance;
                var props = instant.GetType().GetProperties();
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                //Check number
                int temp = default(int);
                if (!CommonUtil.TryParseInt(value.ToString(), ref temp))
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_M0004);
                    message = String.Format(message, validationContext.DisplayName);
                    string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                    return new ValidationResult(message + row);
                }

                //Check Min, Max
                if (temp < MinValue || temp > MaxValue)
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                    message = String.Format(message, validationContext.DisplayName, MinValue.ToString(Constant.FMT_INTEGER), MaxValue.ToString(Constant.FMT_INTEGER));
                    string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                    return new ValidationResult(message + row);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Decimal Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iDecimalGridAttribute : ValidationAttribute
    {

        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructorr
        /// </summary>
        /// <param name="precision">precision</param>
        /// <param name="scale">scale</param>
        public iDecimalGridAttribute(int precision, int scale)
            : base()
        {
            Precision = precision;
            Scale = scale;

            //Set Min Max
            string maxStr = this.GetMaxString();
            MinValue = CommonUtil.ParseDecimal("-" + maxStr);
            MaxValue = CommonUtil.ParseDecimal(maxStr);
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="precision">precision</param>
        /// <param name="scale">scale</param>
        /// <param name="minValue">minValue</param>
        /// <param name="maxValue">maxValue</param>
        public iDecimalGridAttribute(int precision, int scale, string minValue, string maxValue)
            : base()
        {
            Precision = precision;
            Scale = scale;
            MinValue = CommonUtil.ParseDecimal(minValue);
            MaxValue = CommonUtil.ParseDecimal(maxValue);
        }

        public int Precision { get; private set; }
        public int Scale { get; private set; }
        public decimal MinValue { get; set; }
        public decimal MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != default(object))
            {
                var instant = validationContext.ObjectInstance;
                var props = instant.GetType().GetProperties();
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                //Check number
                decimal temp = default(decimal);
                if (!CommonUtil.TryParseDecimal(value.ToString(), ref temp))
                {
                    //must be a number
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0010);
                    message = String.Format(message, validationContext.DisplayName);
                    string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                    return new ValidationResult(message + row);
                }

                //Check Precision, Scale
                System.Data.SqlTypes.SqlDecimal x;
                x = new System.Data.SqlTypes.SqlDecimal(temp);
                if (x.Scale > Scale)
                {
                    //must in format
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0011);
                    message = String.Format(message, validationContext.DisplayName, Scale);
                    string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                    return new ValidationResult(message + row);
                }

                //Check Min, Max
                if (temp < MinValue || temp > MaxValue)
                {
                    //must in range
                    string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                    message = String.Format(message, validationContext.DisplayName, FormatNum(MinValue), FormatNum(MaxValue));
                    string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                    return new ValidationResult(message + row);
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Get max string
        /// </summary>
        /// <returns></returns>
        private string GetMaxString()
        {
            string ret = string.Empty;
            ret = ret.PadLeft(Precision, '9');
            ret = ret.Insert(Precision - Scale, Constant.DFT_DECIMAL_POINT);

            return ret;
        }

        /// <summary>
        /// Format num
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string FormatNum(decimal value)
        {
            return value.ToString(String.Format("N{0}", Scale), CultureInfo.CreateSpecificCulture(Constant.DFT_CULTURE_NAME));
        }
    }

    /// <summary>
    /// Date Range Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iDateRangeGridAttribute : ValidationAttribute
    {

         public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public iDateRangeGridAttribute()
            : base()
        {
            MinValue = DateTime.MinValue;
            MaxValue = DateTime.MaxValue;
        }

        /// <summary>
        /// Constructpr
        /// </summary>
        /// <param name="minValue">MinValue(Format:dd/MM/yyyy)</param>
        /// <param name="maxValue">MaxValue(Format:dd/MM/yyyy)</param>
        public iDateRangeGridAttribute(string minValue, string maxValue)
            : base()
        {
            MinValue = CommonUtil.ParseDate(minValue);
            MaxValue = CommonUtil.ParseDate(maxValue);
        }

        public DateTime MinValue { get; set; }
        public DateTime MaxValue { get; set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            DateControl dateValue = (DateControl)value;
            if (dateValue != default(DateControl))
            {
                var instant = validationContext.ObjectInstance;
                var props = instant.GetType().GetProperties();
                var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                //Check number
                DateTime temp = default(DateTime);
                if (CommonUtil.TryParseDate(String.Format("{0}/{1}/{2}", dateValue.Day, dateValue.Month, dateValue.Year), ref temp))
                {
                    //Check Min, Max
                    if (temp < MinValue || temp > MaxValue)
                    {
                        //must in range
                        string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0012);
                        message = String.Format(message, validationContext.DisplayName, MinValue.ToString(Constant.FMT_DATE), MaxValue.ToString(Constant.FMT_DATE));
                        string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                        return new ValidationResult(message+row);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }
    }

    /// <summary>
    /// Compare Number Attribute
    /// Author: ISV-Vinh
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iCompareNumberGridAttribute : ValidationAttribute
    {

        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="otherProperty">otherProperty</param>
        /// <param name="compareType">CompareType</param>
        public iCompareNumberGridAttribute(string otherProperty, CompareType compareType)
            : base()
        {
            this.OtherProperty = otherProperty;
            this.CompareType = compareType;
        }

        public string OtherProperty { get; private set; }
        public CompareType CompareType { get; private set; }
        private string messageCD;

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //Get PropertyInfo Object  
            var otherPropertyInfo = validationContext.ObjectType.GetProperty(this.OtherProperty);
            if (otherPropertyInfo == null)
            {
                throw new ArgumentNullException("otherProperty");
            }

            //Get Value of the property  
            var otherValue = otherPropertyInfo.GetValue(validationContext.ObjectInstance, null);

            //Actual comparision  
            if (value != default(object) && otherValue != default(object))
            {
                //parse number value
                double dblValue = default(double);
                double dblOtherValue = default(double);
                if (CommonUtil.TryParseNumber(value.ToString(), ref dblValue) && CommonUtil.TryParseNumber(otherValue.ToString(), ref dblOtherValue))
                {
                    //comparision
                    if (!this.IsValid(dblValue, dblOtherValue))
                    {
                        var instant = validationContext.ObjectInstance;
                        var props = instant.GetType().GetProperties();
                        var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                        //Get Display name of other propertise
                        string otherDisplayName = CommonUtil.GetNameFromPropertyInfo(this.OtherProperty, otherPropertyInfo);

                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(messageCD);
                        message = String.Format(message, validationContext.DisplayName, otherDisplayName);
                        string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                        return new ValidationResult(message + row);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid compare
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="otherValue">otherValue</param>
        /// <returns></returns>
        private bool IsValid(double value, double otherValue)
        {
            bool result;
            switch (this.CompareType)
            {
                case CompareType.LessThan:
                    result = value < otherValue;
                    //messageCD = Constant.MES_LESS_THAN;
                    break;

                case CompareType.LessThanOrEqual:
                    result = value <= otherValue;
                    messageCD = Constant.MES_E0005;
                    break;

                case CompareType.GreaterThan:
                    result = value > otherValue;
                    //messageCD = Constant.MES_GREATER_THAN;
                    break;

                default:
                    result = value >= otherValue;
                    //messageCD = Constant.MES_GREATER_EQUAL;
                    break;
            }

            return result;
        }
    }

    /// <summary>
    /// Between Number Attribute
    /// Author: ISV-Nho
    /// </summary>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class iBetweenNumberGridAttribute : ValidationAttribute
    {

        public string RowIndexName { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="fromValue">fromValue</param>
        /// <param name="toValue">toValue</param>
        public iBetweenNumberGridAttribute(string fromValue, string toValue)
            : base()
        {
            this.FromValue = fromValue;
            this.ToValue = toValue;
        }

        public string FromValue { get; private set; }
        public string ToValue { get; private set; }

        //Override IsValid  
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //Get from value Object  
            var fromValueInfo = validationContext.ObjectType.GetProperty(this.FromValue);
            if (fromValueInfo == null)
            {
                throw new ArgumentNullException("fromValueInfo");
            }

            //Get PropertyInfo Object  
            var toValueInfo = validationContext.ObjectType.GetProperty(this.ToValue);
            if (toValueInfo == null)
            {
                throw new ArgumentNullException("toValueInfo");
            }

            //Get Value of the property  
            var fValue = fromValueInfo.GetValue(validationContext.ObjectInstance, null);
            var tValue = toValueInfo.GetValue(validationContext.ObjectInstance, null);

            //Actual comparision  
            if (value != default(object) && fValue != default(object) && tValue != default(object))
            {
                //parse number value
                double dblValue = default(double);
                double dblFrom = default(double);
                double dblTo = default(double);
                if (CommonUtil.TryParseNumber(value.ToString(), ref dblValue) && CommonUtil.TryParseNumber(fValue.ToString(), ref dblFrom) && CommonUtil.TryParseNumber(tValue.ToString(), ref dblTo))
                {
                    //comparision
                    if (!this.IsValid(dblValue, dblFrom, dblTo))
                    {
                        var instant = validationContext.ObjectInstance;
                        var props = instant.GetType().GetProperties();
                        var rowIndex = (int)props.Where(m => m.Name.Equals(RowIndexName)).SingleOrDefault().GetValue(instant, null);

                        //Get Display name of other propertise
                        string formDisplayName = CommonUtil.GetNameFromPropertyInfo(this.FromValue, fromValueInfo);
                        string toDisplayName = CommonUtil.GetNameFromPropertyInfo(this.ToValue, toValueInfo);

                        //Format Message
                        string message = UserSession.Session.SysCache.GetMessage(Constant.MES_E0021);
                        message = String.Format(message, validationContext.DisplayName, formDisplayName, toDisplayName);
                        string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), rowIndex);
                        return new ValidationResult(message + row);
                    }
                }
            }

            //Default return - This means there were no validation error  
            return null;
        }

        /// <summary>
        /// Check Isvalid Between
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="fromValue">fromValue</param>
        /// <param name="toValue">toValue</param>
        /// <returns></returns>
        private bool IsValid(double value, double fromValue, double toValue)
        {
            return value >= fromValue && value <= toValue;
        }
    }
}
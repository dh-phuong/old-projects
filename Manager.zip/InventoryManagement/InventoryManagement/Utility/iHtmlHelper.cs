﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Web.Routing;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Globalization;
using System.Web.Helpers;
using System.Linq;
using System.Web;
using System.Data.Linq;

namespace InventoryManagement.iHtmlHelper
{
    /// <summary>
    /// Input Extensions 
    /// Author: ISV-Vinh
    /// </summary>
    public static class InputExtensions
    {

        private const string HTML_CLASS = "class";
        private const string HTML_MAXLENGHT = "maxlength";
        private const string HTML_ONBLUR = "onblur";
        private const int HTML_LEN_INT = 14;
        private const string HTML_READONLY = "readonly";

        #region iTextBoxFor

        /// <summary>
        /// iTextBoxFor
        /// </summary>
        public static MvcHtmlString iTextBoxFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression)
        {
            return htmlHelper.iTextBoxFor(expression, (IDictionary<string, object>)null);
        }

        /// <summary>
        /// iTextBoxFor
        /// </summary>
        /// <returns></returns>
        public static MvcHtmlString iTextBoxFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes)
        {
            return htmlHelper.iTextBoxFor(expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        /// <summary>
        /// iTextBoxFor
        /// </summary>
        public static MvcHtmlString iTextBoxFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, IDictionary<string, object> htmlAttributes)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
            string valueFormated = null;

            var memberExpression = (expression.Body as MemberExpression);
            if (memberExpression != null)
            {
                //Check is special pattern
                var iPattern = memberExpression.Member.GetCustomAttributes(typeof(iPatternAttribute), false);
                var paCss = string.Empty;
                var onblur = string.Empty;
                if (iPattern.Length != 0)
                {
                    InputExtensions.SetCSSAndJS(((iPatternAttribute)iPattern[0]).PatternType, ref paCss, ref onblur);
                    if (!String.IsNullOrEmpty(paCss))
                    {
                        InputExtensions.SetClass(ref htmlAttributes, paCss);
                    }
                    if (!String.IsNullOrEmpty(onblur))
                    {
                        InputExtensions.SetAttribute(ref htmlAttributes, HTML_ONBLUR, onblur);
                    }
                }

                var iPatternGrid = memberExpression.Member.GetCustomAttributes(typeof(iPatternGridAttribute), false);
                if (iPatternGrid.Length != 0)
                {
                    InputExtensions.SetCSSAndJS(((iPatternGridAttribute)iPatternGrid[0]).PatternType, ref paCss, ref onblur);
                    if (!String.IsNullOrEmpty(paCss))
                    {
                        InputExtensions.SetClass(ref htmlAttributes, paCss);
                    }
                    if (!String.IsNullOrEmpty(onblur))
                    {
                        InputExtensions.SetAttribute(ref htmlAttributes, HTML_ONBLUR, onblur);
                    }
                }

                bool process = true;

                //Set Maxlength Attribute
                var iStringLength = memberExpression.Member.GetCustomAttributes(typeof(iStringLengthAttribute), false);
                if (iStringLength.Length != 0)
                {
                    process = false;
                    InputExtensions.SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, ((iStringLengthAttribute)iStringLength[0]).MaximumLength);
                }

                //Set Day css
                var iDay = memberExpression.Member.GetCustomAttributes(typeof(iDDateAttribute), false);
                if (iDay.Length != 0)
                {
                    string dayText = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0130);
                    InputExtensions.SetAttribute(ref htmlAttributes, "placeholder", dayText);
                    SetClass(ref htmlAttributes, "day disableIme");
                }

                //Set Year css
                var iYear = memberExpression.Member.GetCustomAttributes(typeof(iYDateAttribute), false);
                if (iYear.Length != 0)
                {
                    string dayText = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0132);
                    InputExtensions.SetAttribute(ref htmlAttributes, "placeholder", dayText);
                    SetClass(ref htmlAttributes, "year disableIme");
                }

                //Set Interger attribute
                if (process)
                {
                    var iIntegerArr = memberExpression.Member.GetCustomAttributes(typeof(iIntegerAttribute), false);
                    if (iIntegerArr.Length != 0)
                    {
                        process = false;

                        //Format number
                        ModelState modelState = htmlHelper.ViewData.ModelState[metadata.PropertyName];
                        if (modelState != default(ModelState))
                        {
                            string attemptedValue = modelState.Value.AttemptedValue;
                            if (modelState.Errors.Count == 0 && !string.IsNullOrWhiteSpace(attemptedValue))
                            {
                                InputExtensions.SetNumFormat(ref valueFormated, attemptedValue);
                            }
                        }
                        else if (metadata.Model != null)
                        {
                            InputExtensions.SetNumFormat(ref valueFormated, metadata.Model.ToString());
                        }

                        SetClass(ref htmlAttributes, "integer disableIme");
                        InputExtensions.SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, HTML_LEN_INT);
                    }
                }

                //Set Decimal attribute
                if (process)
                {
                    var iDecimalArr = memberExpression.Member.GetCustomAttributes(typeof(iDecimalAttribute), false);
                    if (iDecimalArr.Length != 0)
                    {
                        process = false;

                        //Format number
                        iDecimalAttribute iDecimal = (iDecimalAttribute)iDecimalArr[0];
                        ModelState modelState = htmlHelper.ViewData.ModelState[metadata.PropertyName];
                        if (modelState != default(ModelState))
                        {
                            string attemptedValue = modelState.Value.AttemptedValue;
                            if (modelState.Errors.Count == 0 && !string.IsNullOrWhiteSpace(attemptedValue))
                            {
                                InputExtensions.SetNumFormat(ref valueFormated, attemptedValue);
                            }
                        }
                        else if (metadata.Model != null)
                        {
                            InputExtensions.SetNumFormat(ref valueFormated, metadata.Model.ToString());
                        }

                        //Set maxlength
                        int maxlength = iDecimal.Precision;
                        maxlength += (int)Math.Ceiling((double)(iDecimal.Precision - iDecimal.Scale) / 3);

                        SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, maxlength);
                        SetClass(ref htmlAttributes, "decimal disableIme");
                    }
                }
            }

            //Check require

            return TextBoxHelper(htmlHelper,
                                 metadata,
                                 metadata.Model,
                                 ExpressionHelper.GetExpressionText(expression),
                                 htmlAttributes,
                                 valueFormated);
        }

        /// <summary>
        /// Set Css class and javascript
        /// </summary>
        /// <param name="patternType">PatternType</param>
        /// <param name="paCss">css class</param>
        /// <param name="onblur">onblur string</param>
        private static void SetCSSAndJS(PatternType patternType, ref string paCss, ref string onblur)
        {
            switch (patternType)
            {
                case PatternType.Numeric:
                    paCss = "iNum disableIme";
                    break;
                case PatternType.AlphaNumeric:
                    paCss = "iAlpNumNone disableIme";
                    break;
                case PatternType.UpperAlphaNumeric:
                    paCss = "iAlpNum disableIme";
                    onblur = "UpperCaseCode(this);";
                    break;
                case PatternType.UpperAlphaNumericFlash:
                    paCss = "iAlpNumC disableIme";
                    onblur = "UpperCaseCode(this);";
                    break;
                case PatternType.UpperAlphaNumericSubtract:
                    paCss = "iAlpNumS disableIme";
                    onblur = "UpperCaseCode(this);";
                    break;
                case PatternType.Tel:
                    paCss = "iTel disableIme";
                    break;
                case PatternType.HaflWidth:
                    paCss = "iHafl";
                    break;
                case PatternType.NumbericSubstract:
//                    paCss = "iNumSub disableIme";
                    paCss = "disableIme";
                    break;
                case PatternType.Email:
                    paCss = "disableIme";
                    break;
                case PatternType.AlphaNumericFlashSpace:
                    paCss = "iDlvNo disableIme";
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Set Format number
        /// </summary>
        /// <param name="numFormat">Format number</param>
        /// <param name="value">value</param>
        private static void SetNumFormat(ref string numFormat, string value)
        {
            decimal number = default(decimal);
            if (CommonUtil.TryParseDecimal(value, ref number))
            {
                //Set value formated
                numFormat = String.Format(Constant.FMT_DECIMAL_FULL, number);
            }
        }

        /// <summary>
        /// TextBoxHelper
        /// </summary>
        private static MvcHtmlString TextBoxHelper(this HtmlHelper htmlHelper, ModelMetadata metadata, object model, string expression, IDictionary<string, object> htmlAttributes, string valueFormated)
        {
            return InputHelper(htmlHelper, InputType.Text, metadata, expression, model, false /* useViewData */, false /* isChecked */, true /* setId */, true /* isExplicitValue */, htmlAttributes, valueFormated);
        }

        /// <summary>
        /// InputHelper
        /// </summary>
        private static MvcHtmlString InputHelper(HtmlHelper htmlHelper, InputType inputType, ModelMetadata metadata, string name, object value, bool useViewData, bool isChecked, bool setId, bool isExplicitValue, IDictionary<string, object> htmlAttributes, string valueFormated)
        {
            string fullName = htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(name);
            if (String.IsNullOrEmpty(fullName))
            {
                throw new ArgumentException("HTML helper: can't not find name of model");
            }

            TagBuilder tagBuilder = new TagBuilder("input");
            tagBuilder.MergeAttributes(htmlAttributes);
            tagBuilder.MergeAttribute("type", HtmlHelper.GetInputTypeString(inputType));
            tagBuilder.MergeAttribute("name", fullName, true);

            string valueParameter = Convert.ToString(value, CultureInfo.CurrentCulture);
            switch (inputType)
            {
                case InputType.Password:
                    if (value != null)
                    {
                        tagBuilder.MergeAttribute("value", valueParameter, isExplicitValue);
                    }
                    tagBuilder.MergeAttribute("id", name);
                    break;
                default:

                    //Customer diplay value
                    //string attemptedValue = (string)GetModelStateValue(htmlHelper, fullName, typeof(string));
                    //string displayValue = valueFormated ?? attemptedValue ?? ((useViewData) ? EvalString(htmlHelper, fullName) : valueParameter);
                    string displayValue = valueFormated ?? ((useViewData) ? EvalString(htmlHelper, fullName) : valueParameter);
                    tagBuilder.MergeAttribute("value", displayValue, isExplicitValue);

                    if (setId)
                    {
                        tagBuilder.GenerateId(fullName);
                    }
                    break;
            }

            // If there are any errors for a named field, we add the css attribute.
            ModelState modelState;

            if (htmlHelper.ViewData.ModelState.TryGetValue(fullName, out modelState))
            {
                if (modelState.Errors.Count > 0)
                {
                    tagBuilder.AddCssClass(HtmlHelper.ValidationInputCssClassName);
                }
            }

            tagBuilder.MergeAttributes(htmlHelper.GetUnobtrusiveValidationAttributes(name, metadata));

            return tagBuilder.iToMvcHtmlString(TagRenderMode.SelfClosing);
        }

        /// <summary>
        /// GetModelStateValue
        /// </summary>
        private static object GetModelStateValue(HtmlHelper htmlHelper, string key, Type destinationType)
        {
            ModelState modelState;
            if (htmlHelper.ViewData.ModelState.TryGetValue(key, out modelState))
            {
                if (modelState.Value != null)
                {
                    return modelState.Value.ConvertTo(destinationType, null /* culture */);
                }
            }
            return null;
        }

        /// <summary>
        /// EvalString
        /// </summary>
        private static string EvalString(HtmlHelper htmlHelper, string key)
        {
            return Convert.ToString(htmlHelper.ViewData.Eval(key), CultureInfo.CurrentCulture);
        }

        /// <summary>
        /// iToMvcHtmlString
        /// </summary>
        private static MvcHtmlString iToMvcHtmlString(this TagBuilder tagBuilder, TagRenderMode renderMode)
        {
            return new MvcHtmlString(tagBuilder.ToString(renderMode));
        }

        /// <summary>
        /// Set Maxlength
        /// </summary>
        /// <param name="htmlAttributes">htmlAttributes</param>
        /// <param name="maxlength">maxlength</param>
        private static void SetAttribute(ref IDictionary<string, object> htmlAttributes, string key, object value)
        {
            if (htmlAttributes == null)
            {
                htmlAttributes = new RouteValueDictionary();
                htmlAttributes.Add(key, value);
            }
            else if (!htmlAttributes.ContainsKey(key))
            {
                htmlAttributes.Add(key, value);
            }
        }

        /// <summary>
        /// Set Css Class
        /// </summary>
        /// <param name="htmlAttributes">htmlAttributes</param>
        /// <param name="className">class name</param>
        private static void SetClass(ref IDictionary<string, object> htmlAttributes, string className)
        {
            if (htmlAttributes == null)
            {
                htmlAttributes = new RouteValueDictionary();
                htmlAttributes.Add(HTML_CLASS, className);
            }
            else if (!htmlAttributes.ContainsKey(HTML_CLASS))
            {
                htmlAttributes.Add(HTML_CLASS, className);
            }
            else
            {
                string listClass = htmlAttributes[HTML_CLASS].ToString();
                listClass = className + " " + listClass;

                htmlAttributes.Remove(HTML_CLASS);
                htmlAttributes.Add(HTML_CLASS, listClass);
            }
        }

        #endregion

        #region iPasswordFor

        /// <summary>
        /// iPasswordFor
        /// </summary>
        public static MvcHtmlString iPasswordFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression)
        {
            return iPasswordFor(htmlHelper, expression, null /* htmlAttributes */);
        }

        /// <summary>
        /// iPasswordFor
        /// </summary>
        public static MvcHtmlString iPasswordFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes)
        {
            return iPasswordFor(htmlHelper, expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        /// <summary>
        /// iPasswordFor
        /// </summary>
        public static MvcHtmlString iPasswordFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, IDictionary<string, object> htmlAttributes)
        {
            if (expression == null)
            {
                throw new ArgumentNullException("expression");
            }

            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
            var memberExpression = (expression.Body as MemberExpression);
            if (memberExpression != null)
            {
                //Set Maxlength Attribute
                var iStringLength = memberExpression.Member.GetCustomAttributes(typeof(iStringLengthAttribute), false);
                if (iStringLength.Length != 0)
                {
                    SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, ((iStringLengthAttribute)iStringLength[0]).MaximumLength);
                }
            }

            return PasswordHelper(htmlHelper,
                                  ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData),
                                  ExpressionHelper.GetExpressionText(expression),
                                  null /* value */,
                                  htmlAttributes);
        }

        /// <summary>
        /// PasswordHelper
        /// </summary>
        private static MvcHtmlString PasswordHelper(HtmlHelper htmlHelper, ModelMetadata metadata, string name, object value, IDictionary<string, object> htmlAttributes)
        {
            return InputHelper(htmlHelper, InputType.Password, metadata, name, value, false /* useViewData */, false /* isChecked */, true /* setId */, true /* isExplicitValue */, htmlAttributes, null);
        }

        #endregion

        #region iLabelFor

        public static MvcHtmlString iLabelFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, object htmlAttributes = null)
        {
            return iLabelFor<TModel, TValue>(html, expression, null, true, htmlAttributes);
        }

        public static MvcHtmlString iLabelFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, bool AutoRequired, object htmlAttributes = null)
        {
            return iLabelFor<TModel, TValue>(html, expression, null, AutoRequired, htmlAttributes);
        }

        public static MvcHtmlString iLabelFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, string labelText, bool AutoRequired, object htmlAttributes = null)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, html.ViewData);
            string htmlFieldName = ExpressionHelper.GetExpressionText(expression);

            var memberExpression = (expression.Body as MemberExpression);
            IDictionary<string, object> htmlAtt = default(RouteValueDictionary);
            if (htmlAttributes != null)
            {
                htmlAtt = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);
            }

            if (memberExpression != null)
            {
                //Check require
                if (AutoRequired)
                {
                    var iRequire = memberExpression.Member.GetCustomAttributes(typeof(iRequiredAttribute), false);
                    if (iRequire.Length != 0)
                    {
                        InputExtensions.SetClass(ref htmlAtt, "required");
                    }
                }

                ////Check search type
                //var iLike = memberExpression.Member.GetCustomAttributes(typeof(iLikeAttribute), false);
                //if (iLike.Length != 0)
                //{
                //    iLikeAttribute likeType = iLike.SingleOrDefault() as iLikeAttribute;
                //    string resolvedLabelText = labelText ?? metadata.DisplayName ?? metadata.PropertyName ?? htmlFieldName.Split('.').Last();

                //    switch (likeType.SearchType)
                //    {
                //        case LikeType.StartsWith:
                //            resolvedLabelText = string.Format("{0}{1}", "*", metadata.DisplayName);
                //            break;
                //        case LikeType.EndsWith:
                //            resolvedLabelText = string.Format("{1}{0}", "*", metadata.DisplayName);
                //            break;
                //        case LikeType.Contains:
                //            resolvedLabelText = string.Format("{0}{1}{0}", "*", metadata.DisplayName);
                //            break;
                //        default:
                //            break;
                //    }
                //    metadata.DisplayName = resolvedLabelText;
                //}
            }
            return LabelHelper(html,
                               metadata,
                               htmlFieldName,
                               htmlAtt,
                               labelText);
        }

        internal static MvcHtmlString LabelHelper(HtmlHelper html, ModelMetadata metadata, string htmlFieldName, IDictionary<string, object> htmlAttributes, string labelText = null)
        {
            string resolvedLabelText = labelText ?? metadata.DisplayName ?? metadata.PropertyName ?? htmlFieldName.Split('.').Last();
            if (String.IsNullOrEmpty(resolvedLabelText))
            {
                return MvcHtmlString.Empty;
            }

            TagBuilder tag = new TagBuilder("label");
            tag.Attributes.Add("for", TagBuilder.CreateSanitizedId(html.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(htmlFieldName)));
            tag.SetInnerText(resolvedLabelText);

            if (htmlAttributes != default(RouteValueDictionary))
            {
                tag.MergeAttributes(htmlAttributes);
            }

            return tag.iToMvcHtmlString(TagRenderMode.Normal);
        }

        #endregion

        #region iTextAreaFor

        // These values are similar to the defaults used by WebForms
        // when using <asp:TextBox TextMode="MultiLine"> without specifying
        // the Rows and Columns attributes.
        private const int TextAreaRows = 2;
        private const int TextAreaColumns = 20;
        private static Dictionary<string, object> implicitRowsAndColumns = new Dictionary<string, object> {
            { "rows", TextAreaRows.ToString(CultureInfo.InvariantCulture) },
            { "cols", TextAreaColumns.ToString(CultureInfo.InvariantCulture) },
        };

        private static Dictionary<string, object> GetRowsAndColumnsDictionary(int rows, int columns)
        {
            if (rows < 0)
            {
                throw new ArgumentOutOfRangeException("rows of TextArea Parameter Out Of Range");
            }
            if (columns < 0)
            {
                throw new ArgumentOutOfRangeException("columns of TextArea Parameter Out Of Range");
            }

            Dictionary<string, object> result = new Dictionary<string, object>();
            if (rows > 0)
            {
                result.Add("rows", rows.ToString(CultureInfo.InvariantCulture));
            }
            if (columns > 0)
            {
                result.Add("cols", columns.ToString(CultureInfo.InvariantCulture));
            }

            return result;
        }

        public static MvcHtmlString iTextAreaFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression)
        {
            return iTextAreaFor(htmlHelper, expression, (IDictionary<string, object>)null);
        }

        public static MvcHtmlString iTextAreaFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes)
        {
            return iTextAreaFor(htmlHelper, expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        public static MvcHtmlString iTextAreaFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, IDictionary<string, object> htmlAttributes)
        {
            if (expression == null)
            {
                throw new ArgumentNullException("expression");
            }

            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
            var memberExpression = (expression.Body as MemberExpression);
            if (memberExpression != null)
            {
                //Set Maxlength Attribute
                var iStringLength = memberExpression.Member.GetCustomAttributes(typeof(iStringLengthAttribute), false);
                if (iStringLength.Length != 0)
                {
                    InputExtensions.SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, ((iStringLengthAttribute)iStringLength[0]).MaximumLength);
                }
            }

            return TextAreaHelper(htmlHelper,
                                  metadata,
                                  ExpressionHelper.GetExpressionText(expression),
                                  implicitRowsAndColumns,
                                  htmlAttributes);
        }

        public static MvcHtmlString iTextAreaFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, int rows, int columns, object htmlAttributes)
        {
            return iTextAreaFor(htmlHelper, expression, rows, columns, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        public static MvcHtmlString iTextAreaFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, int rows, int columns, IDictionary<string, object> htmlAttributes)
        {
            if (expression == null)
            {
                throw new ArgumentNullException("expression");
            }

            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
            var memberExpression = (expression.Body as MemberExpression);
            if (memberExpression != null)
            {
                //Set Maxlength Attribute
                var iStringLength = memberExpression.Member.GetCustomAttributes(typeof(iStringLengthAttribute), false);
                if (iStringLength.Length != 0)
                {
                    InputExtensions.SetAttribute(ref htmlAttributes, HTML_MAXLENGHT, ((iStringLengthAttribute)iStringLength[0]).MaximumLength);
                }
            }

            return TextAreaHelper(htmlHelper,
                                  metadata,
                                  ExpressionHelper.GetExpressionText(expression),
                                  GetRowsAndColumnsDictionary(rows, columns),
                                  htmlAttributes);
        }

        private static MvcHtmlString TextAreaHelper(HtmlHelper htmlHelper, ModelMetadata modelMetadata, string name, IDictionary<string, object> rowsAndColumns, IDictionary<string, object> htmlAttributes)
        {
            string fullName = htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(name);
            if (String.IsNullOrEmpty(fullName))
            {
                throw new ArgumentException("name is null or empty");
            }

           
            TagBuilder tagBuilder = new TagBuilder("textarea");
            tagBuilder.GenerateId(fullName);
            tagBuilder.MergeAttributes(htmlAttributes, true);
            tagBuilder.MergeAttributes(rowsAndColumns, rowsAndColumns != implicitRowsAndColumns);  // Only force explicit rows/cols
            tagBuilder.MergeAttribute("name", fullName, true);

            // If there are any errors for a named field, we add the CSS attribute.
            ModelState modelState;
            if (htmlHelper.ViewData.ModelState.TryGetValue(fullName, out modelState) && modelState.Errors.Count > 0)
            {
                tagBuilder.AddCssClass(HtmlHelper.ValidationInputCssClassName);
            }

            tagBuilder.MergeAttributes(htmlHelper.GetUnobtrusiveValidationAttributes(name));

            string value;
            //if (modelState != null && modelState.Value != null)
            //{
            //    value = modelState.Value.AttemptedValue;
            //}
            //else if (modelMetadata.Model != null)
            //{
            //    value = modelMetadata.Model.ToString();
            //}
            if (modelMetadata.Model != null)
            {
                value = modelMetadata.Model.ToString();
            }
            else
            {
                value = String.Empty;
            }

            // The first newline is always trimmed when a TextArea is rendered, so we add an extra one
            // in case the value being rendered is something like "\r\nHello".
            tagBuilder.SetInnerText(Environment.NewLine + value);

            return tagBuilder.ToMvcHtmlString(TagRenderMode.Normal);
        }

        internal static MvcHtmlString ToMvcHtmlString(this TagBuilder tagBuilder, TagRenderMode renderMode)
        {
            return new MvcHtmlString(tagBuilder.ToString(renderMode));
        }

        #endregion

        #region iDate

        public static MvcHtmlString iDateControl(this HtmlHelper html, DateOption Option, object htmlAttributes)
        {
            var curDate = DateTime.Now;

            var optionValue = HtmlHelper.AnonymousObjectToHtmlAttributes(Option.OptionValue);

            #region DAY

            System.Text.StringBuilder opDay = new System.Text.StringBuilder();
            var dayOption = string.Empty;
            if (optionValue.ContainsKey("Day"))
            {
                dayOption = optionValue["Day"].ToString();
            }
            if (!string.IsNullOrEmpty(dayOption))
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode(dayOption)

                };
                opDay.AppendLine(builder.ToString(TagRenderMode.Normal));
            }
            for (int i = 0; i < 31; i++)
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode((i + 1).ToString("00"))

                };
                builder.Attributes["value"] = (i + 1).ToString("00");
                if (Option.DisplayCurrentDate && curDate.Day == (i + 1))
                {
                    builder.Attributes["selected"] = "selected";
                }
                opDay.AppendLine(builder.ToString(TagRenderMode.Normal));
            }

            TagBuilder tagDay = new TagBuilder("select")
            {
                InnerHtml = opDay.ToString()

            };
            tagDay.MergeAttribute("name", "Day", true /* replaceExisting */);
            tagDay.MergeAttribute("placeholder", "Day", true /* replaceExisting */);
            tagDay.GenerateId(Option.Name + "_Day");
            // If there are any errors for a named field, we add the css attribute.
            ModelState modelState;
            if (html.ViewData.ModelState.TryGetValue("Day", out modelState))
            {
                if (modelState.Errors.Count > 0)
                {
                    tagDay.AddCssClass(HtmlHelper.ValidationInputCssClassName);
                }
            }

            tagDay.MergeAttributes(html.GetUnobtrusiveValidationAttributes(Option.Name));

            #endregion

            #region MONTH

            System.Text.StringBuilder opMonth = new System.Text.StringBuilder();
            var monthOption = string.Empty;
            if (optionValue.ContainsKey("Month"))
            {
                monthOption = optionValue["Month"].ToString();
            }

            if (!string.IsNullOrEmpty(monthOption))
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode(monthOption)

                };
                opMonth.AppendLine(builder.ToString(TagRenderMode.Normal));
            }
            for (int i = 0; i < 12; i++)
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode((i + 1).ToString("00"))
                };
                builder.Attributes["value"] = (i + 1).ToString("00");
                if (Option.DisplayCurrentDate && curDate.Month == (i + 1))
                {
                    builder.Attributes["selected"] = "selected";
                }
                opMonth.AppendLine(builder.ToString(TagRenderMode.Normal));
            }

            TagBuilder tagMonth = new TagBuilder("select")
            {
                InnerHtml = opMonth.ToString()

            };

            tagMonth.MergeAttribute("name", "Month", true /* replaceExisting */);
            tagMonth.GenerateId(Option.Name + "_Month");
            // If there are any errors for a named field, we add the css attribute.            
            if (html.ViewData.ModelState.TryGetValue("Month", out modelState))
            {
                if (modelState.Errors.Count > 0)
                {
                    tagDay.AddCssClass(HtmlHelper.ValidationInputCssClassName);
                }
            }

            #endregion

            #region YEAR

            System.Text.StringBuilder opYear = new System.Text.StringBuilder();
            var yearOption = string.Empty;
            if (optionValue.ContainsKey("Year"))
            {
                yearOption = optionValue["Year"].ToString();
            }
            if (!string.IsNullOrEmpty(yearOption))
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode(yearOption)

                };
                opYear.AppendLine(builder.ToString(TagRenderMode.Normal));
            }

            var loopYear = (Option.MaxYear - Option.MinYear) + 1;
            for (int i = 0; i < loopYear; i++)
            {
                TagBuilder builder = new TagBuilder("option")
                {
                    InnerHtml = HttpUtility.HtmlEncode((Option.MinYear + i))
                };
                builder.Attributes["value"] = (Option.MinYear + i).ToString();
                if (Option.DisplayCurrentDate && curDate.Year == (Option.MinYear + i))
                {
                    builder.Attributes["selected"] = "selected";
                }
                opYear.AppendLine(builder.ToString(TagRenderMode.Normal));
            }

            TagBuilder tagYear = new TagBuilder("select")
            {
                InnerHtml = opYear.ToString()

            };

            tagYear.MergeAttribute("name", "Year", true /* replaceExisting */);
            tagYear.GenerateId(Option.Name + "_Year");
            // If there are any errors for a named field, we add the css attribute.            
            if (html.ViewData.ModelState.TryGetValue("Year", out modelState))
            {
                if (modelState.Errors.Count > 0)
                {
                    tagDay.AddCssClass(HtmlHelper.ValidationInputCssClassName);
                }
            }

            #endregion


            var day = tagDay.iToMvcHtmlString(TagRenderMode.Normal);
            var month = tagMonth.iToMvcHtmlString(TagRenderMode.Normal);
            var year = tagYear.iToMvcHtmlString(TagRenderMode.Normal);
            string dateLayout = string.Empty;
            switch (Option.Display)
            {
                case DateOption.DisplayType.YYYYMMDD:
                case DateOption.DisplayType.YYMMDD:
                    dateLayout = string.Format("{0} - {1} - {2}", year.ToHtmlString(), month.ToHtmlString(), day.ToHtmlString());
                    break;
                case DateOption.DisplayType.DDMMYYYY:
                case DateOption.DisplayType.DDMMYY:
                    dateLayout = string.Format("{0} - {1} - {2}", day.ToHtmlString(), month.ToHtmlString(), year.ToHtmlString());
                    break;
                case DateOption.DisplayType.MMDDYYYY:
                case DateOption.DisplayType.MMDDYY:
                    dateLayout = string.Format("{0} - {1} - {2}", month.ToHtmlString(), day.ToHtmlString(), year.ToHtmlString());
                    break;

                default:
                    break;
            }

            TagBuilder tagDIVContainer = new TagBuilder("div")
            {

                InnerHtml = dateLayout
            };
            tagDIVContainer.MergeAttribute("name", Option.Name, true /* replaceExisting */);
            tagDIVContainer.GenerateId(Option.Name);
            var attributes = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);
            tagDIVContainer.MergeAttributes(attributes);

            return tagDIVContainer.iToMvcHtmlString(TagRenderMode.Normal);
        }

        public class DateOption
        {
            public object OptionValue { get; set; }
            public string Name { get; set; }
            public int MinYear { get; set; }
            public int MaxYear { get; set; }

            public bool DisplayCurrentDate { get; set; }

            public DisplayType Display { get; set; }

            /// <summary>
            /// Display Type
            /// </summary>
            public enum DisplayType
            {
                /// <summary>
                /// YYYY - MM - DD
                /// </summary>
                YYYYMMDD = 0,

                /// <summary>
                /// DD - MM - YYYY
                /// </summary>
                DDMMYYYY,

                /// <summary>
                /// MM - DD - YYYY
                /// </summary>
                MMDDYYYY,

                /// <summary>
                /// YY - MM - DD
                /// </summary>
                YYMMDD,

                /// <summary>
                /// DD - MM - YY
                /// </summary>
                DDMMYY,

                /// <summary>
                /// MM - DD - YY
                /// </summary>
                MMDDYY
            }
        }

        #endregion

        #region iHidden
        
        public static MvcHtmlString iHidden(this HtmlHelper htmlHelper, string name)
        {
            return iHidden(htmlHelper, name, null /* value */, null /* htmlAttributes */);
        }

        public static MvcHtmlString iHidden(this HtmlHelper htmlHelper, string name, object value)
        {
            return iHidden(htmlHelper, name, value, null /* hmtlAttributes */);
        }

        public static MvcHtmlString iHidden(this HtmlHelper htmlHelper, string name, object value, object htmlAttributes)
        {
            return iHidden(htmlHelper, name, value, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        public static MvcHtmlString iHidden(this HtmlHelper htmlHelper, string name, object value, IDictionary<string, object> htmlAttributes)
        {
            return HiddenHelper(htmlHelper,
                                null,
                                value,
                                value == null /* useViewData */,
                                name,
                                htmlAttributes);
        }

        public static MvcHtmlString iHiddenFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression)
        {
            return iHiddenFor(htmlHelper, expression, (IDictionary<string, object>)null);
        }

        public static MvcHtmlString iHiddenFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, object htmlAttributes)
        {
            return iHiddenFor(htmlHelper, expression, HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes));
        }

        public static MvcHtmlString iHiddenFor<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, Expression<Func<TModel, TProperty>> expression, IDictionary<string, object> htmlAttributes)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
            return HiddenHelper(htmlHelper,
                                metadata,
                                metadata.Model,
                                false,
                                ExpressionHelper.GetExpressionText(expression),
                                htmlAttributes);
        }

        private static MvcHtmlString HiddenHelper(HtmlHelper htmlHelper, ModelMetadata metadata, object value, bool useViewData, string expression, IDictionary<string, object> htmlAttributes)
        {
            Binary binaryValue = value as Binary;
            if (binaryValue != null)
            {
                value = binaryValue.ToArray();
            }

            byte[] byteArrayValue = value as byte[];
            if (byteArrayValue != null)
            {
                value = Convert.ToBase64String(byteArrayValue);
            }

            return InputHelper(htmlHelper, InputType.Hidden, metadata, expression, value, useViewData, false /* isChecked */, true /* setId */, true /* isExplicitValue */, htmlAttributes, null);
        }

        #endregion

        #region iActionLink
        public static string ImageString(HtmlHelper helper, string url, string alternateText)
        {
            var builder = new TagBuilder("img");
            builder.MergeAttribute("src", url);
            builder.MergeAttribute("alt", alternateText);
            return builder.ToString(TagRenderMode.SelfClosing);
        }
        public static IHtmlString Image(this HtmlHelper helper, string url, string alternateText)
        {
            return MvcHtmlString.Create(ImageString( helper, url, alternateText));
        }
        public static IHtmlString ActionImage(this HtmlHelper html, string actionName, string controllerName, string imagePath, string alternateText, object htmlAttributes)
        {
            var url = new System.Web.Mvc.UrlHelper(HttpContext.Current.Request.RequestContext);
            var builder = new TagBuilder("a");
            builder.MergeAttribute("href", url.Action(actionName, controllerName));
            builder.InnerHtml = ImageString(html, imagePath, alternateText);

            IDictionary<string, object> htmlAtt = HtmlHelper.AnonymousObjectToHtmlAttributes(htmlAttributes);

            builder.MergeAttributes(htmlAtt);

            return MvcHtmlString.Create(builder.ToString(TagRenderMode.Normal));
            
        }
        #endregion
    }

    /// <summary>
    /// Paging helper
    /// </summary>
    public static class PagingHelpers
    {
        private const int MAX_PAGES = 10;

        /// <summary>
        /// Footer paging
        /// </summary>
        /// <param name="html">HtmlHelper</param>
        /// <param name="pagingInfo">PagingInfo</param>
        /// <param name="updateId">updateId</param>
        /// <param name="pageUrl">pageUrl</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="seqNum">Sequence Number</param>
        public static MvcHtmlString iPagingFooter(this HtmlHelper html, PagingInfo pagingInfo, string updateId, Func<int, string> pageUrl, SortingInfo sortInfo, int seqNum, string formSerialize = "", PageType pageType = PageType.Windows)
        {
            if (pagingInfo== null || pagingInfo.TotalPages == 0)
            {
                return MvcHtmlString.Empty;
            }

            //paging footer
            TagBuilder pagingFoot = new TagBuilder("div");
            pagingFoot.MergeAttribute("id", "pagingFooter");

            //paging number tag
            TagBuilder paging = new TagBuilder("div");
            paging.MergeAttribute("id", "paging");
            paging.MergeAttribute("class", "pagination");

            //List ul tag
            TagBuilder ulList = new TagBuilder("ul");

            //First Page
            if (pagingInfo.TotalPages != 0 && pagingInfo.CurrentPage != 1)
            {
                TagBuilder liTag = new TagBuilder("li");
                TagBuilder aTag = new TagBuilder("a");
                aTag.MergeAttribute("href", "#");
                aTag.InnerHtml = "<<";
                aTag.MergeAttribute("onclick", GetFunction(pageUrl(0), updateId, 0, true, false, sortInfo, seqNum, formSerialize, pageType));

                liTag.InnerHtml += aTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }
            else
            {
                TagBuilder liTag = new TagBuilder("li");
                liTag.MergeAttribute("class", "disabled");
                TagBuilder spanTag = new TagBuilder("span");
                spanTag.InnerHtml = "<<";

                liTag.InnerHtml += spanTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }

            //Prev Page
            if (pagingInfo.CurrentPage != 1 && pagingInfo.TotalPages > 1)
            {
                TagBuilder liTag = new TagBuilder("li");
                TagBuilder aTag = new TagBuilder("a");
                aTag.MergeAttribute("href", "#");
                aTag.InnerHtml = "<";
                aTag.MergeAttribute("onclick", GetFunction(pageUrl(0), updateId, pagingInfo.CurrentPage - 1, false, false, sortInfo, seqNum, formSerialize, pageType));
                
                liTag.InnerHtml += aTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }
            else
            {
                TagBuilder liTag = new TagBuilder("li");
                liTag.MergeAttribute("class", "disabled");
                TagBuilder spanTag = new TagBuilder("span");
                spanTag.InnerHtml = "<";

                liTag.InnerHtml += spanTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }

            //set start index, end index
            int startIndex = pagingInfo.CurrentPage - (MAX_PAGES / 2);
            int endIndex = pagingInfo.CurrentPage + (MAX_PAGES / 2) - 1;

            if (startIndex < 1)
            {
                startIndex = 1;
                endIndex = startIndex + MAX_PAGES - 1 > pagingInfo.TotalPages ? pagingInfo.TotalPages : startIndex + MAX_PAGES - 1;
            }
            else if (endIndex > pagingInfo.TotalPages)
            {
                endIndex = pagingInfo.TotalPages;
                startIndex = endIndex - MAX_PAGES + 1 < 1 ? 1 : endIndex - MAX_PAGES + 1;
            }

            //set Middle pages
            for (int i = startIndex; i <= endIndex; i++)
            {
                TagBuilder liTag = new TagBuilder("li");
                TagBuilder aTag;
                
                if (i == pagingInfo.CurrentPage)
                {
                    aTag = new TagBuilder("span");
                    aTag.InnerHtml = i.ToString();
                    liTag.AddCssClass("active");
                }
                else
                {
                    aTag = new TagBuilder("a");
                    aTag.InnerHtml = i.ToString();
                    aTag.MergeAttribute("href", "#");
                    aTag.MergeAttribute("onclick", GetFunction(pageUrl(0), updateId, i, false, false, sortInfo, seqNum, formSerialize, pageType));
                }

                liTag.InnerHtml += aTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }

            //Next Page
            if (pagingInfo.CurrentPage < pagingInfo.TotalPages && pagingInfo.TotalPages > 1)
            {
                TagBuilder liTag = new TagBuilder("li");
                TagBuilder aTag = new TagBuilder("a");
                aTag.MergeAttribute("href", "#");
                aTag.InnerHtml = ">";
                aTag.MergeAttribute("onclick", GetFunction(pageUrl(0), updateId, pagingInfo.CurrentPage + 1, false, false, sortInfo, seqNum, formSerialize, pageType));
                
                liTag.InnerHtml += aTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }
            else
            {
                TagBuilder liTag = new TagBuilder("li");
                liTag.MergeAttribute("class", "disabled");
                TagBuilder spanTag = new TagBuilder("span");
                spanTag.InnerHtml = ">";
                
                liTag.InnerHtml += spanTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }

            //Last Page
            if (pagingInfo.TotalPages > 1 && pagingInfo.CurrentPage != pagingInfo.TotalPages)
            {
                TagBuilder liTag = new TagBuilder("li");
                TagBuilder aTag = new TagBuilder("a");
                aTag.MergeAttribute("href", "#");
                aTag.InnerHtml = ">>";
                aTag.MergeAttribute("onclick", GetFunction(pageUrl(0), updateId, pagingInfo.TotalPages, false, true, sortInfo, seqNum, formSerialize, pageType));

                liTag.InnerHtml += aTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }
            else
            {
                TagBuilder liTag = new TagBuilder("li");
                liTag.MergeAttribute("class", "disabled");
                TagBuilder spanTag = new TagBuilder("span");
                spanTag.InnerHtml = ">>";
               
                liTag.InnerHtml += spanTag.ToString();
                ulList.InnerHtml += liTag.ToString();
            }

            paging.InnerHtml += ulList.ToString();

            //pageing current / page count
            if (pagingInfo.TotalPages != 0)
            {
                TagBuilder tag = new TagBuilder("span");
                tag.AddCssClass("right");
                tag.InnerHtml = pagingInfo.CurrentPage.ToString() + "/" + pagingInfo.TotalPages.ToString();

                paging.InnerHtml += tag.ToString();
            }
            pagingFoot.InnerHtml += paging.ToString();

            return MvcHtmlString.Create(pagingFoot.ToString());
        }

        /// <summary>
        /// Header paging
        /// </summary>
        /// <param name="html">HtmlHelper</param>
        /// <param name="pagingInfo">PagingInfo</param>
        public static MvcHtmlString iPagingHeader(this HtmlHelper html, PagingInfo pagingInfo)
        {
            if (pagingInfo == null || pagingInfo.TotalPages == 0)
            {
                return MvcHtmlString.Empty;
            }

            //paging number tag
            TagBuilder paging = new TagBuilder("div");
            paging.AddCssClass("left pagingItem");

            //pageing current / page count
            if (pagingInfo.TotalPages != 0)
            {
                //set total page info
                paging.InnerHtml = pagingInfo.StartIndex.ToString() + " ～ " + pagingInfo.EndIndex.ToString() + " / " + pagingInfo.TotalItems.ToString();
            }

            return MvcHtmlString.Create(paging.ToString());
        }

        /// <summary>
        /// Get function paging
        /// </summary>
        /// <param name="url">url</param>
        /// <param name="updateId">updateId</param>
        /// <param name="currentPage">currentPage</param>
        /// <param name="isFirst">isFirst</param>
        /// <param name="isLast">isLast</param>
        /// <param name="sortInfo">sortInfo</param>
        /// <param name="seqNum">Sequence Number</param>
        private static string GetFunction(string url, string updateId, int currentPage, bool isFirst, bool isLast, SortingInfo sortInfo, int seqNum, string formSerialize, PageType pageType)
        {
            //list params
            List<string> lstParam = new List<string>();

            //Paging params
            lstParam.Add("'" + url + "'");
            lstParam.Add("'" + updateId + "'");
            lstParam.Add(currentPage.ToString());
            lstParam.Add(isFirst.ToString().ToLower());
            lstParam.Add(isLast.ToString().ToLower());

            //Sorting
            lstParam.Add("'" + sortInfo.Url + "'");
            lstParam.Add("'" + sortInfo.SortField + "'");
            lstParam.Add(((int)sortInfo.Direction).ToString());          
            //Sequence Number
            lstParam.Add(seqNum.ToString());
            lstParam.Add("'" + formSerialize + "'");
            lstParam.Add("'" + Convert.ToInt16(pageType) + "'");

            ////Other Value
            //if (routeValue != null)
            //{
            //    foreach (var item in routeValue)
            //    {
            //        lstParam.Add("'" + item + "'");
            //    }
            //}

            return "Paging(" + String.Join(",", lstParam.ToArray()) + "); return false;";
        }
    }

    /// <summary>
    /// Sorting helper
    /// </summary>
    public static class SortingHelpers
    {
        /// <summary>
        /// iSortHeader
        /// </summary>
        public static MvcHtmlString iSortHeader<TModel, TProperty>(this HtmlHelper<TModel> htmlHelper, SortingInfo sortInfo, string updateId, Expression<Func<TModel, TProperty>> expression, int SeqNum,
                                                                   string formSerialize = "", PageType pageType = PageType.Windows)
        {
            if (sortInfo == default(SortingInfo))
            {
                return MvcHtmlString.Empty;
            }



            //Get propertive Key
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, htmlHelper.ViewData);
           
            TagBuilder divTag = new TagBuilder("a");
            divTag.AddCssClass("sort menu");
            divTag.MergeAttribute("href", "#");
            divTag.InnerHtml = metadata.DisplayName;

            var parentEx = ((MemberExpression)expression.Body).Expression;
            var field = parentEx.Type.GetProperty(metadata.PropertyName);
            if (field != null)
            {
                var labelCd = (iDisplayNameAttribute)field.GetCustomAttributes(true).Where(m => m.GetType().Equals(typeof(iDisplayNameAttribute))).SingleOrDefault();
                if (labelCd.Name.Equals(Constant.LBL_L0066))
                {
                    divTag.InnerHtml = "<i class='icon-trash' title='" + metadata.DisplayName + "'></i>";
                }

            }

            TagBuilder iTag = new TagBuilder("i");
            SortDirection direction = SortDirection.Ascending;
            if (metadata.PropertyName == sortInfo.SortField)
            {
                divTag.AddCssClass("sorted");
                string directCss;
                if (sortInfo.Direction == SortDirection.Ascending)
                {
                    direction = SortDirection.Descending;
                    directCss = "icon-arrow-up";
                }
                else
                {
                    direction = SortDirection.Ascending;
                    directCss = "icon-arrow-down";
                }
                iTag.AddCssClass(directCss);
            }
            else
            {
                iTag.AddCssClass("none");
            }

            divTag.InnerHtml += iTag.ToString();
            divTag.MergeAttribute("onclick", GetFunction(sortInfo.Url, updateId, metadata.PropertyName, direction, SeqNum, formSerialize, pageType));
            return MvcHtmlString.Create(divTag.ToString());
        }

        /// <summary>
        /// Get sorting function
        /// </summary>
        /// <param name="url">url</param>
        /// <param name="updateId">updateId</param>
        /// <param name="dataField">dataField</param>
        /// <param name="direction">direction</param>
        /// <param name="SeqNum">Sequence Number</param>
        private static string GetFunction(string url, string updateId, string dataField, SortDirection direction, int SeqNum, string formSerialize, PageType pageType)
        {
            //list params
            List<string> lstParam = new List<string>();
            lstParam.Add("'" + url + "'");
            lstParam.Add("'" + updateId + "'");
            lstParam.Add("'" + dataField + "'");
            lstParam.Add(((int)direction).ToString());
            lstParam.Add(SeqNum.ToString());
            lstParam.Add("'" + formSerialize + "'");
            lstParam.Add("'" + Convert.ToInt16(pageType) + "'");

            return "Sorting(" + String.Join(",", lstParam.ToArray()) + "); return false;";
        }
    }
}
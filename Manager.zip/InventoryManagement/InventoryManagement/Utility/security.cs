﻿using System;
using System.Web.Mvc;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace InventoryManagement.Utility
{
    /// <summary>
    /// Security Utility class
    /// Author: ISV-Vinh
    /// </summary>
    public static class Security
    {
        // This constant string is used as a "salt" value for the PasswordDeriveBytes function calls.
        // This size of the IV (in bytes) must = (keysize / 8).  Default keysize is 256, so the IV must be
        // 32 bytes long.  Using a 16 character string here gives us 32 bytes when converted to a byte array.
        private const string INIT_VECTOR = "tu89geji340t89u2";

        // This constant is used to determine the keysize of the encryption algorithm.
        private const int KEY_SIZE = 256;

        /// <summary>
        /// Secret phrase
        /// </summary>
        private const string SECRET_PHRASE = "ABDC1234";

        /// <summary>
        /// Encrypt
        /// </summary>
        /// <param name="plainText">plain plainTextText</param>
        /// <returns>Encrypt text</returns>
        public static string Encrypt(string plainText)
        {
            //Init
            byte[] initVectorBytes = Encoding.UTF8.GetBytes(INIT_VECTOR);
            byte[] plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(SECRET_PHRASE, null);
            byte[] keyBytes = password.GetBytes(KEY_SIZE / 8);

            //Create Rijndael Managed
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;

            //Encrypt
            ICryptoTransform encryptor = symmetricKey.CreateEncryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write);
            cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
            cryptoStream.FlushFinalBlock();
            byte[] cipherTextBytes = memoryStream.ToArray();
            memoryStream.Close();
            cryptoStream.Close();

            return Convert.ToBase64String(cipherTextBytes);
        }

        /// <summary>
        /// Decrypt
        /// </summary>
        /// <param name="cipherText">cipher Text</param>
        /// <returns>plain Text</returns>
        public static string Decrypt(string cipherText)
        {
            //Init
            byte[] initVectorBytes = Encoding.ASCII.GetBytes(INIT_VECTOR);
            byte[] cipherTextBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes password = new PasswordDeriveBytes(SECRET_PHRASE, null);
            byte[] keyBytes = password.GetBytes(KEY_SIZE / 8);

            //Create Rijndael Managed
            RijndaelManaged symmetricKey = new RijndaelManaged();
            symmetricKey.Mode = CipherMode.CBC;

            //Decrypt
            ICryptoTransform decryptor = symmetricKey.CreateDecryptor(keyBytes, initVectorBytes);
            MemoryStream memoryStream = new MemoryStream(cipherTextBytes);
            CryptoStream cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read);
            byte[] plainTextBytes = new byte[cipherTextBytes.Length];
            int decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
            memoryStream.Close();
            cryptoStream.Close();
           
            return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
        }
    }
}
       

﻿using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;

namespace InventoryManagement.UserSession
{
    /// <summary>
    /// ユーザセッション
    /// Author: ISV-Phuong
    /// </summary>
    public class Session
    {
        #region 定数

        /// <summary>
        /// セッションキー（LoginInfo）
        /// </summary>
        /// <remarks></remarks>
        private const string SESSION_KEY_LOGIN_INFO = "LoginInfo";

        /// <summary>
        /// セッションキー（Cache）
        /// </summary>
        /// <remarks></remarks>
        private const string SESSION_KEY_CACHE = "Cache";

        private const string SESSION_KEY_SEQUENCE = "SequenceNum";

        #endregion

        #region プロパティ

        /// <summary>
        /// Current Language
        /// </summary>
        public static LanguageFlag Language
        {
            get
            {
                if (System.Web.HttpContext.Current.Session != null && System.Web.HttpContext.Current.Session[Constant.CURRENT_LANGUAGE] != null)
                {
                    return (LanguageFlag)SessionManager.Get(HttpContext.Current.Session, Constant.CURRENT_LANGUAGE);
                }
                else
                {

                    if (HttpContext.Current.Request.UserLanguages != null && HttpContext.Current.Request.UserLanguages.Length != 0)
                    {
                        var langStr = HttpContext.Current.Request.UserLanguages[0].Substring(0, 2);
                        if (langStr == "vi")
                        {
                            return LanguageFlag.Vietnamese;
                        }
                        else if (langStr == "en")
                        {
                            return LanguageFlag.English;
                        }
                    }
                    return LanguageFlag.Japanese;
                }
            }
        }

        /// <summary>
        /// Current WareHouse
        /// </summary>
        public static string WarehouseCD
        {
            get
            {
                if (System.Web.HttpContext.Current.Session != null && System.Web.HttpContext.Current.Session[Constant.CURRENT_WAREHOUSE_CD] != null)
                {
                    return (string)SessionManager.Get(HttpContext.Current.Session, Constant.CURRENT_WAREHOUSE_CD);
                }
                return string.Empty;
            }
        }


        /// <summary>
        /// ユーザID（ログインID）
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public static LoginInfo LoginInfo
        {
            get
            {
                return (LoginInfo)SessionManager.Get(HttpContext.Current.Session, SESSION_KEY_LOGIN_INFO);
            }
        }

        /// <summary>
        /// ユーザID（ログインID）
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public static InventoryManagement.Cache SysCache
        {
            get
            {
                return (InventoryManagement.Cache)SessionManager.Get(HttpContext.Current.Session, SESSION_KEY_CACHE);
            }
        }

        /// <summary>
        /// Is Authenticated
        /// </summary>
        public static bool IsAuthenticated
        {
            get
            {
                return Session.LoginInfo != null;
            }
        }

        private static WareHouseMode _wareHouseMode = Common.WareHouseMode.Single;
        public static WareHouseMode WareHouseMode
        {
            get
            {
                return _wareHouseMode;
            }
            set
            {
                _wareHouseMode = value;
            }
        }

        #endregion

        #region Public method

        /// <summary>
        /// Logoff
        /// </summary>
        public static void LogOff()
        {
            SessionManager.InitializeSession(HttpContext.Current.Session);
        }

        /// <summary>
        /// Set user system language
        /// </summary>
        /// <param name="controller"></param>
        public static void SetLanguageSession(LanguageFlag Language)
        {
            SessionManager.Add(Constant.CURRENT_LANGUAGE, Language, InventoryManagement.Common.SessionLifecycle.Permanent);
        }

        /// <summary>
        ///  Set user system warehouse
        /// </summary>
        /// <param name="controller"></param>
        public static void SetWareHouseSession(string WareHouseCD)
        {
            SessionManager.Add(Constant.CURRENT_WAREHOUSE_CD, WareHouseCD, InventoryManagement.Common.SessionLifecycle.Permanent);

        }

        /// <summary>
        /// ユーザセッションを設定
        /// </summary>
        /// <param name="controller"></param>
        public static void SetLoginInfoSession(LoginInfo loginInfo)
        {
            SessionManager.Add(SESSION_KEY_LOGIN_INFO, loginInfo, InventoryManagement.Common.SessionLifecycle.Temporary);

        }

        /// <summary>
        /// ユーザセッションを設定
        /// </summary>
        /// <param name="controller"></param>
        public static void SetCacheSession(InventoryManagement.Cache cache)
        {
            SessionManager.Add(SESSION_KEY_CACHE, cache, InventoryManagement.Common.SessionLifecycle.Temporary);
        }

        /// <summary>
        /// Create Sequence Number
        /// Author: ISV-Vinh
        /// </summary>
        /// <returns>Sequence Number</returns>
        public static int CreateSequenceNumber()
        {
            int ret = 1;
            var SeqNum = SessionManager.Get(HttpContext.Current.Session, SESSION_KEY_SEQUENCE);
            if (SeqNum != null)
            {
                ret = (int)SeqNum;
                ret++;
                if (ret == int.MaxValue)
                {
                    ret = 1;
                }
            }
            SessionManager.Add(SESSION_KEY_SEQUENCE, ret, InventoryManagement.Common.SessionLifecycle.Permanent);
            return ret;
        }

        #endregion

    }
}
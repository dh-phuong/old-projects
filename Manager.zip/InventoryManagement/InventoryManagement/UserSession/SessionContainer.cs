﻿namespace InventoryManagement.UserSession
{
    /// <summary>
    /// Session Container
    /// Author: ISV-Phuong
    /// </summary>
    public class SessionContainer
    {
        private object _Object;
        private InventoryManagement.Common.SessionLifecycle _Lifecycle;
        
        /// <summary>
        /// 格納するオブジェクト
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public object Object
        {
            get { return _Object; }
            set { _Object = value; }
        }

        /// <summary>
        /// セッションの保持期間
        /// </summary>
        /// <value></value>
        /// <returns></returns>
        /// <remarks></remarks>
        public InventoryManagement.Common.SessionLifecycle Lifecycle
        {
            get { return _Lifecycle; }
            set { _Lifecycle = value; }
        }
    }
}
﻿using System.Web;

namespace InventoryManagement.UserSession
{
    /// <summary>
    /// セッション管理クラス
    /// Author: ISV-Phuong
    /// </summary>
    public class SessionManager
    {
        /// <summary>
        /// セッションに格納
        /// </summary>
        /// <param name="controler"></param>
        /// <param name="key"></param>
        /// <param name="data"></param>
        /// <param name="lifecycle"></param>
        public static void Add(string key, object data, InventoryManagement.Common.SessionLifecycle lifecycle)
        {
            // セッションコンテナ生成
            SessionContainer sc = new SessionContainer();
            sc.Lifecycle = lifecycle;
            sc.Object = data;
            //コンテナをセッションに追加
            HttpContext.Current.Session.Add(key, sc);
            
        }

        /// <summary>
        /// セッション取得
        /// </summary>
        /// <param name="session"></param>
        /// <param name="key"></param>
        /// <returns></returns>
        public static object Get(System.Web.SessionState.HttpSessionState session, string key)
        {
            //セッションを探す
            SessionContainer sc = session[key] as SessionContainer;
            if (sc != null) return sc.Object;

            // 取得できなければ何も返さない
            return null;
        }

        /// <summary>
        /// セッション初期化
        /// </summary>
        /// <param name="page"></param>
        /// <remarks></remarks>
        public static void InitializeSession(System.Web.SessionState.HttpSessionState session)
        {
            for (int i = session.Keys.Count - 1; i >= 0; i += -1)
            {
                string name = session.Keys[i];
                if ((session[name]) is SessionContainer)
                {
                    // ライフサイクルがTemporaryのセッションコンテナオブジェクトは破棄する
                    SessionContainer sc = default(SessionContainer);
                    sc = (SessionContainer)session[name];
                    if (sc.Lifecycle == InventoryManagement.Common.SessionLifecycle.Temporary)
                    {
                        session.Remove(name);
                    }
                }
                else
                {
                    // セッションコンテナオブジェクト以外は破棄する
                    // （直接セッションに格納される事を厳しくチェックする場合は例外を発行）
                    session.Remove(name);
                }
            }
        }

        /// <summary>
        ///  セッション情報削除
        /// </summary>
        /// <param name="page"></param>
        /// <param name="key"></param>
        public static void Remove(System.Web.HttpSessionStateBase session, string key)
        {
            if (session[key] != null)
            {
                session.Remove(key);
            }
        }

    }
}
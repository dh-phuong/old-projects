﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Pessimistic TOutBoundDelivered Service
    /// Author : ISV-Nho
    /// </summary>

    public class TOutBoundDeliveredService : DataAccess.Abstract.AbstractService<TOutBoundDelivered>
    {
        #region Get

        /// <summary>
        /// Get List Outbound Delivered Inquiry Results ByConditions
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredInquiryList</param>
        /// <returns>IQueryable OutboundDeliveredInquiryResults</returns>
        public IQueryable<OutboundDeliveredInquiryResults> GetListOutboundDeliveredInquiryResultsByConditions(OutboundDeliveredInquiryList gmModel)
        {
            string warehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            string shipDateFrom = gmModel.dCtr_ShipDateFrom.DateValue();
            string shipDateTo = gmModel.dCtr_ShipDateTo.DateValue();
            string lot2From = gmModel.dCtr_Lot2From.DateValue();
            string lot2To = gmModel.dCtr_Lot2To.DateValue();
            string lot3From = gmModel.dCtr_Lot3From.DateValue();
            string lot3To = gmModel.dCtr_Lot3To.DateValue();
            string customerCD = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);
            string customerNm = String.IsNullOrEmpty(gmModel.txt_CustomerName) ? String.Empty : gmModel.txt_CustomerName;
            string WareCD = String.IsNullOrEmpty(gmModel.txt_WareCDTo) ? String.Empty : gmModel.txt_WareCDTo;
            string WareNm = String.IsNullOrEmpty(gmModel.txt_WareNmTo) ? String.Empty : gmModel.txt_WareNmTo;
            gmModel.ddl_Kind = gmModel.ddl_Kind ?? string.Empty;

            return from oD in this.Context.TOutBoundDelivered
                    join sH in this.Context.TShippingInstruction on oD.ShippingNo equals sH.ShipNo
                    join iH in this.Context.TInventory_H on oD.TagNo equals iH.TagNo
                    join c in this.Context.MCustomer on sH.CustomerCD equals c.CustomerCD into C
                    from cu in C.DefaultIfEmpty()
                    join w in this.Context.MWarehouse on sH.DestinationWarehouseCD equals w.WarehouseCD into W
                    from wa in W.DefaultIfEmpty()
                    where sH.WarehouseCD.Equals(warehouseCD)
                        && (string.IsNullOrEmpty(gmModel.txt_ShipNo) || oD.ShippingNo.Equals(gmModel.txt_ShipNo))
                        && (string.IsNullOrEmpty(customerCD) || sH.CustomerCD.Equals(customerCD))
                        && (string.IsNullOrEmpty(customerNm) || cu.CustomerName.ToUpper().Contains(customerNm.ToUpper()))
                        && (string.IsNullOrEmpty(WareCD) || sH.DestinationWarehouseCD.StartsWith(WareCD))
                        && (string.IsNullOrEmpty(WareNm) || wa.WarehouseName.ToUpper().Contains(WareNm.ToUpper()))
                        && (string.IsNullOrEmpty(shipDateFrom) || sH.ShipDate.CompareTo(shipDateFrom) >= 0)
                        && (string.IsNullOrEmpty(shipDateTo) || sH.ShipDate.CompareTo(shipDateTo) <= 0)
                        && (string.IsNullOrEmpty(gmModel.txt_DeliveryNumber) || sH.DeliveryNumber.Contains(gmModel.txt_DeliveryNumber))

                        && (string.IsNullOrEmpty(gmModel.txt_Lot1) || iH.Lot1.Contains(gmModel.txt_Lot1))
                        && (string.IsNullOrEmpty(lot2From) || iH.Lot2.CompareTo(lot2From) >= 0)
                        && (string.IsNullOrEmpty(lot2To) || iH.Lot2.CompareTo(lot2To) <= 0)
                        && (string.IsNullOrEmpty(lot3From) || iH.Lot3.CompareTo(lot3From) >= 0)
                        && (string.IsNullOrEmpty(lot3To) || iH.Lot3.CompareTo(lot3To) <= 0)
                        && sH.DestinationLocationCD == null
                        && (
                                string.IsNullOrEmpty(gmModel.ddl_Kind)
                             || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND) && sH.CustomerCD != null)
                             || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE) && sH.DestinationWarehouseCD != null)
                             || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_SCRAP) && sH.CustomerCD == null && sH.DestinationWarehouseCD == null)
                           )

                    group new { oD, sH, cu, wa } by new { oD.ShippingNo } into grp
                    select new OutboundDeliveredInquiryResults
                    {
                        ShipNo = grp.Key.ShippingNo,
                        ShipDate = grp.Min(m=>m.sH.ShipDate),
                        DataCD = grp.Min(m => m.sH.CustomerCD) ?? grp.Min(m => m.sH.DestinationWarehouseCD),
                        DataName = grp.Min(m => m.cu.CustomerName) ?? grp.Min(m => m.wa.WarehouseName),
                        DeliveryNumber = grp.Min(m => m.sH.DeliveryNumber),
                        KindName = (from k in this.Context.MKind_D
                                    where k.KindCD.Equals(Constant.MKIND_KINDCD_OUTBOUND_KIND)
                                       && (
                                                (grp.Min(m => m.sH.CustomerCD) != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND))
                                             || (grp.Min(m => m.sH.DestinationWarehouseCD) != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE))
                                             || (grp.Min(m => m.sH.CustomerCD) == null && grp.Min(m => m.sH.DestinationWarehouseCD) == null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_SCRAP))
                                          )
                                       && k.Language.Equals(UserSession.Session.Language)
                                    select k.Value).SingleOrDefault()
                    };
        }

        /// <summary>
        /// Get Outbound Delivered Inquiry Header
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <returns>OutboundDeliveredInquiryHeader</returns>
        public OutboundDeliveredInquiryHeader GetOutboundDeliveredInquiryHeader(string shipNo)
        {
            return (from sH in this.Context.TShippingInstruction
                    join c in this.Context.MCustomer on sH.CustomerCD equals c.CustomerCD into C
                    from cu in C.DefaultIfEmpty()
                    join w in this.Context.MWarehouse on sH.DestinationWarehouseCD equals w.WarehouseCD into W
                    from wa in W.DefaultIfEmpty()
                    where sH.ShipNo.Equals(shipNo)
                    select new OutboundDeliveredInquiryHeader
                    {
                        txt_ShipNo = sH.ShipNo,
                        txt_ShipDate = CommonUtil.ParseDate(sH.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE),
                        txt_CustomerCD = sH.CustomerCD,
                        txt_CustomerName = cu.CustomerName,
                        Address1 = sH.Address1,
                        Address2 = sH.Address2,
                        Address3 = sH.Address3,
                        txt_DeliveryNumber = sH.DeliveryNumber,
                        txt_Memo = sH.Memo,
                        txt_WareCDTo = sH.DestinationWarehouseCD,
                        txt_WareNmTo = wa.WarehouseName,
                        UpdateDate = sH.UpdateDate,
                        txt_KindName = (from k in this.Context.MKind_D
                                        where k.KindCD.Equals(Constant.MKIND_KINDCD_OUTBOUND_KIND)
                                           && (
                                                    (sH.CustomerCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND))
                                                 || (sH.DestinationWarehouseCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE))
                                                 || (sH.CustomerCD == null && sH.DestinationWarehouseCD == null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_SCRAP))
                                              )
                                           && k.Language.Equals(UserSession.Session.Language)
                                        select k.Value).SingleOrDefault()
                    }).SingleOrDefault();
        }

        /// <summary>
        /// Get List Outbound Delivered Inquiry Detail
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <returns>IQueryable OutboundDeliveredInquiryDetail</returns>
        public IQueryable<OutboundDeliveredInquiryDetail> GetListOutboundDeliveredInquiryDetail(string shipNo)
        {
            return from oD in this.Context.TOutBoundDelivered
                    join iD in this.Context.TInventory_D on new { key1 = oD.TagNo, key2 = oD.BranchTagNo } equals new { key1 = iD.TagNo, key2 = iD.BranchTagNo }
                    join iH in this.Context.TInventory_H on oD.TagNo equals iH.TagNo
                    join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                   where oD.ShippingNo.Equals(shipNo)
                    select new OutboundDeliveredInquiryDetail
                    {
                        TagInfo = iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                        ProductCD = iH.ProductCD,
                        ProductName = p.ProductName,
                        LOT1 = iH.Lot1,
                        LOT2 = iH.Lot2,
                        LOT3 = iH.Lot3,
                    };
        }

        #region Outbound Delivered

        /// <summary>
        /// Get List Outbound Delivered for Report Detail
        /// Author : ISV-Loc
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <returns>IQueryable OutboundDeliveredInquiryDetail</returns>
        public IQueryable<OutboundDeliveredReport> GetListOutboundDeliveredForReport(OutboundDeliveredModels gmModel)
        {
            string warehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            string shipDateFrom = gmModel.shr_ShipDateFrom.DateValue();
            string shipDateTo = gmModel.shr_ShipDateTo.DateValue();

            gmModel.ddl_Kind = gmModel.ddl_Kind ?? string.Empty;
            if (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE))
            {
                gmModel.txt_CustomerCDFrom = string.Empty;
                gmModel.txt_CustomerCDTo = string.Empty;
            }
            else if (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND))
            {
                gmModel.txt_WarehouseCDFrom = string.Empty;
                gmModel.txt_WarehouseCDTo = string.Empty;
            }
            else
            {
                gmModel.txt_CustomerCDFrom = string.Empty;
                gmModel.txt_CustomerCDTo = string.Empty;
                gmModel.txt_WarehouseCDFrom = string.Empty;
                gmModel.txt_WarehouseCDTo = string.Empty;
            }
            return from oD in this.Context.TOutBoundDelivered
                   join sH in this.Context.TShippingInstruction on oD.ShippingNo equals sH.ShipNo//Get destination
                   join iH in this.Context.TInventory_H on oD.TagNo equals iH.TagNo // Get list product, lot
                   join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD//Get product name
                   join c in this.Context.MCustomer on sH.CustomerCD equals c.CustomerCD into C // Get destination with customer Name
                   from cu in C.DefaultIfEmpty()
                   join w in this.Context.MWarehouse on sH.DestinationWarehouseCD equals w.WarehouseCD into W// Get destination with warehouse Name
                   from wa in W.DefaultIfEmpty()
                   where sH.WarehouseCD.Equals(warehouseCD)
                       && (string.IsNullOrEmpty(gmModel.txt_ProductCD) || iH.ProductCD.Equals(gmModel.txt_ProductCD))//  productCD
                       && (string.IsNullOrEmpty(shipDateFrom) || sH.ShipDate.CompareTo(shipDateFrom) >= 0)//Start
                       && (string.IsNullOrEmpty(shipDateTo) || sH.ShipDate.CompareTo(shipDateTo) <= 0)//End
                       && sH.DestinationLocationCD == null// Not move location
                       && (
                               string.IsNullOrEmpty(gmModel.ddl_Kind)
                            || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND) && sH.CustomerCD != null//Outbound for customer
                                 && (string.IsNullOrEmpty(gmModel.txt_CustomerCDFrom) || sH.CustomerCD.CompareTo(gmModel.txt_CustomerCDFrom) >= 0)
                                 && (string.IsNullOrEmpty(gmModel.txt_CustomerCDTo) || sH.CustomerCD.CompareTo(gmModel.txt_CustomerCDTo) >= 0)
                                )
                            || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE) && sH.DestinationWarehouseCD != null //Move warehouse
                                 && (string.IsNullOrEmpty(gmModel.txt_WarehouseCDFrom) || sH.DestinationWarehouseCD.CompareTo(gmModel.txt_WarehouseCDFrom) >= 0)
                                 && (string.IsNullOrEmpty(gmModel.txt_WarehouseCDTo) || sH.DestinationWarehouseCD.CompareTo(gmModel.txt_WarehouseCDTo) >= 0)
                                )
                            || (gmModel.ddl_Kind.Equals(Constant.MKIND_KINDCD_OUT_KIND_SCRAP) && sH.CustomerCD == null && sH.DestinationWarehouseCD == null) //Scrap
                          )
                   select new OutboundDeliveredReport
                   {
                       DestinationCD = sH.CustomerCD ?? sH.DestinationWarehouseCD,
                       DestinationName = cu.CustomerName ?? wa.WarehouseName,

                       TagInfo = oD.TagNo + Constant.HYPHEN + oD.BranchTagNo.ToString().PadLeft(4, '0'),
                       ProductCD = iH.ProductCD,
                       ProductName = p.ProductName,
                       Lot1 = iH.Lot1,
                       Lot2 = CommonUtil.ParseDate(iH.Lot2, Constant.FMT_YMD, Constant.FMT_DATE),
                       Lot3 = CommonUtil.ParseDate(iH.Lot3, Constant.FMT_YMD, Constant.FMT_DATE),

                       ShipDate = sH.ShipDate,
                       ShipNo = oD.ShippingNo,
                       DeliveryNumber = sH.DeliveryNumber,

                       OutboundKind = (from k in this.Context.MKind_D
                                       where k.KindCD.Equals(Constant.MKIND_KINDCD_OUTBOUND_KIND)
                                       && (
                                               (sH.CustomerCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND))
                                            || (sH.DestinationWarehouseCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE))
                                            || (sH.CustomerCD == null && sH.DestinationWarehouseCD == null && k.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_SCRAP))
                                         )
                                       && k.Language.Equals(UserSession.Session.Language)
                                       select k.Value).SingleOrDefault()
                   };
        }
        
        #endregion

        #endregion

        #region Check

        #endregion

    }
}
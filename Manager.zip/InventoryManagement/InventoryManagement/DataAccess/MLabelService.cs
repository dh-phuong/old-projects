﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.DataAccess;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MLabel Context
    /// Author: ISV - PHUONG
    /// </summary>
    public class MLabelService : IDisposable
    {
        #region Common

        /// <summary>
        /// Context to access database
        /// </summary>
        public InventoryManagement.Models.DataClasses1DataContext Context { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public MLabelService()
        {
            this.Context = DbServices.CreateContext();
        }

        /// <summary>
        /// Reset
        /// </summary>
        public void Reset()
        {
            this.Context = DbServices.CreateContext();
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.Context = null;
        }

        #endregion

        #region public method

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="messageID">LabelCD</param>
        /// <returns>Label string</returns>
        public IQueryable<MLabel> GetList()
        {
            var list = from m in this.Context.MLabel
                       orderby m.LabelCD
                       select m;
            return list;
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="messageID">LabelCD</param>
        /// <returns>Label string</returns>
        public IQueryable<MLabel> GetListByLang(InventoryManagement.Common.LanguageFlag lang)
        {
            var list = from m in this.Context.MLabel
                       where m.Language.CompareTo((int)lang) == 0
                       orderby m.LabelCD
                       select m;
            return list;
        }

        #endregion
    }
}
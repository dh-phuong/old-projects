﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TShippingInstructionService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TShippingInstructionService : DataAccess.Abstract.AbstractService<TShippingInstruction>
    {

        /// <summary>
        /// Get By Primary Key
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        public TShippingInstruction GetByPk(string ShipNo)
        {
            IQueryable<TShippingInstruction> item = from c in this.Context.GetTable<TShippingInstruction>()
                                                    where c.ShipNo.Equals(ShipNo)
                                                    select c;
            return item.SingleOrDefault<TShippingInstruction>();
        }

        /// <summary>
        /// Get List By ShipNos
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="listShipNo">List ShipNo</param>
        /// <returns></returns>
        public IQueryable<TShippingInstruction> GetListByShipNos(List<string> listShipNo)
        {
            IQueryable<TShippingInstruction> items = from sh in this.Context.TShippingInstruction
                                                     where sh.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                        && listShipNo.Contains(sh.ShipNo)
                                                     select sh;
            return items;
        }
        
        /// <summary>
        /// Get List By Condition For Outbound Delivery Indication
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationResults> GetListByCondition(OutboundDeliveryIndicationList gmModel)
        {
            
            string dateFrom = gmModel.SrhShipDateFrom.DateValue();
            string dateTo = gmModel.SrhShipDateTo.DateValue();
            gmModel.txt_CustomerCD = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);

            IQueryable<OutboundDeliveryIndicationResults> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                                 join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD
                                                                 where (gmModel.chk_DeleteData || s.DeleteFlag.Equals(false))
                                                                 && s.ShippingCompleteFlag == false
                                                                 && s.CustomerCD != null
                                                                 && (!gmModel.cbk_NotGoodsIssueDataOnly || s.PickingCompleteFlag.Equals(false))
                                                                 && (!gmModel.cbk_NotPrintDataOnly || s.ShippingPrintFlag.Equals(false))
                                                                 && (string.IsNullOrEmpty(gmModel.txt_ShipNo) || s.ShipNo.Equals(gmModel.txt_ShipNo))
                                                                 && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                                                                 && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                                                                 && (string.IsNullOrEmpty(gmModel.txt_CustomerCD) || s.CustomerCD.Equals(gmModel.txt_CustomerCD))
                                                                 && (string.IsNullOrEmpty(gmModel.txt_DeliveryNumber) || s.DeliveryNumber.Contains(gmModel.txt_DeliveryNumber))
                                                                 && (s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                                                                 orderby s.ShipNo
                                                                 select new OutboundDeliveryIndicationResults
                                                                 {
                                                                     ShipNo = s.ShipNo,
                                                                     ShipDate = s.ShipDate,
                                                                     CustomerCD = s.CustomerCD,
                                                                     CustomerName = c.CustomerName,
                                                                     DeliveryNumber = s.DeliveryNumber,
                                                                     DeleteData = s.DeleteFlag,
                                                                     PickingCompleteFlag = s.PickingCompleteFlag,
                                                                     ShippingPrintFlag = s.ShippingPrintFlag,
                                                                     UpdateDate =s.UpdateDate
                                                                 };
            return list;
        }

        /// <summary>
        /// Get List By Condition For Move Indication
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">MoveIndicationList</param>
        /// <returns>IQueryable of MoveIndicationResults</returns>
        public IQueryable<MoveIndicationResults> GetListByConditionForMoveIndication(MoveIndicationList gmModel)
        {
            string moveKind = gmModel.ddl_MoveKind ?? string.Empty;
            string dateFrom = gmModel.SrhMoveDateFrom.DateValue();
            string dateTo = gmModel.SrhMoveDateTo.DateValue();
            string warehCD = UserSession.Session.WarehouseCD;
            IQueryable<MoveIndicationResults> list = from s in this.Context.TShippingInstruction
                                                     join l in this.Context.MLocation on new { key1 = s.DestinationLocationCD, key2 = warehCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                                                     from lo in L.DefaultIfEmpty()
                                                     join w in this.Context.MWarehouse on s.DestinationWarehouseCD equals w.WarehouseCD into W
                                                     from wa in W.DefaultIfEmpty()
                                                     where (gmModel.chk_DeleteData || !s.DeleteFlag)
                                                     && s.CustomerCD == null
                                                     && !s.ShippingCompleteFlag
                                                     && (!gmModel.cbk_NotGoodsIssueDataOnly || s.PickingCompleteFlag.Equals(false))
                                                     && (!gmModel.cbk_NotPrintDataOnly || s.ShippingPrintFlag.Equals(false))
                                                     && (string.IsNullOrEmpty(gmModel.txt_MoveNo) || s.ShipNo.Equals(gmModel.txt_MoveNo))
                                                     && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                                                     && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                                                     && (string.IsNullOrEmpty(gmModel.txt_WarehouseCDTo) || s.DestinationWarehouseCD.Equals(gmModel.txt_WarehouseCDTo))
                                                     && (string.IsNullOrEmpty(gmModel.txt_LocationCDTo) || s.DestinationLocationCD.Equals(gmModel.txt_LocationCDTo))
                                                     && (string.IsNullOrEmpty(gmModel.txt_DeliveryNumber) || s.DeliveryNumber.Contains(gmModel.txt_DeliveryNumber))
                                                     &&
                                                        (
                                                            string.IsNullOrEmpty(moveKind)
                                                         || (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION) && s.DestinationLocationCD != null)
                                                         || (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE) && s.DestinationWarehouseCD != null)
                                                         || (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP) && s.DestinationLocationCD == null && s.DestinationWarehouseCD == null)
                                                        )
                                                     && (s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                                                     orderby s.ShipNo
                                                     select new MoveIndicationResults
                                                     {
                                                         MoveNo = s.ShipNo,
                                                         MoveDate = s.ShipDate,
                                                         MoveKindDisp = (from k in this.Context.MKind_D
                                                                         where k.KindCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND)
                                                                            && 
                                                                            (
                                                                                (s.DestinationLocationCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
                                                                             || (s.DestinationWarehouseCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                                                                             || (s.DestinationLocationCD == null && s.DestinationWarehouseCD == null && k.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
                                                                            )
                                                                            && k.Language.Equals(UserSession.Session.Language)
                                                                        select k.Value).SingleOrDefault(),
                                                         MoveKind = s.DestinationLocationCD != null? Constant.MKIND_KINDCD_MOVE_KIND_LOCATION:
                                                                    s.DestinationWarehouseCD != null ? Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE:
                                                                    Constant.MKIND_KINDCD_MOVE_KIND_SCRAP,
                                                         DestinationCD = s.DestinationWarehouseCD ?? s.DestinationLocationCD,
                                                         DestinationName = wa.WarehouseName ?? lo.LocationName,
                                                         DeliveryNumber = s.DeliveryNumber,
                                                         DeleteData = s.DeleteFlag,
                                                         PickingCompleteFlag = s.PickingCompleteFlag,
                                                         ShippingPrintFlag = s.ShippingPrintFlag,
                                                         ddMoveKind = gmModel.ddl_MoveKind,
                                                         UpdateDate = s.UpdateDate
                                                     };
           
            return list;
        }
        
        ///// <summary>
        ///// Get List By Condition For Move Indication
        ///// Author: ISV-HUNG
        ///// </summary>
        ///// <param name="gmModel"></param>
        ///// <returns></returns>
        //public IQueryable<MoveIndicationResults> GetListByConditionForMoveLocation(MoveIndicationList gmModel)
        //{
            
        //    string dateFrom = gmModel.SrhMoveDateFrom.DateValue();
        //    string dateTo = gmModel.SrhMoveDateTo.DateValue();

        //    IQueryable<MoveIndicationResults> list = from s in this.Context.GetTable<TShippingInstruction>()
        //                                             join c in this.Context.GetTable<MLocation>() on new { key1 = s.DestinationLocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = c.LocationCD, key2 = c.WarehouseCD }
        //                                             where (gmModel.chk_DeleteData || !s.DeleteFlag)
        //                                             && !s.ShippingCompleteFlag
        //                                             && s.DestinationLocationCD != null
        //                                             && (!gmModel.cbk_NotPrintDataOnly || s.ShippingPrintFlag.Equals(false))
        //                                             && (string.IsNullOrEmpty(gmModel.txt_MoveNo) || s.ShipNo.Equals(gmModel.txt_MoveNo))
        //                                             && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
        //                                             && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
        //                                             && (string.IsNullOrEmpty(gmModel.txt_LocationCDTo) || s.DestinationLocationCD.Equals(gmModel.txt_LocationCDTo))
        //                                             && (s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
        //                                             orderby s.ShipNo
        //                                             select new MoveIndicationResults
        //                                             {
        //                                                 MoveNo = s.ShipNo,
        //                                                 MoveDate = s.ShipDate,
        //                                                 MoveKind = gmModel.ddl_MoveKind,
        //                                                 LocationCDTo = s.DestinationLocationCD,
        //                                                 LocationNameTo = c.LocationName,
        //                                                 DeleteData = s.DeleteFlag,
        //                                                 ShippingPrintFlag = s.ShippingPrintFlag,
        //                                                 UpdateDate = s.UpdateDate
        //                                             };
        //    return list;
        //}

        ///// <summary>
        ///// Get List By Condition For Move Indication
        ///// Author: ISV-HUNG
        ///// </summary>
        ///// <param name="gmModel"></param>
        ///// <returns></returns>
        //public IQueryable<MoveIndicationResults> GetListByConditionForMoveScrap(MoveIndicationList gmModel)
        //{

        //    string dateFrom = gmModel.SrhMoveDateFrom.DateValue();
        //    string dateTo = gmModel.SrhMoveDateTo.DateValue();

        //    IQueryable<MoveIndicationResults> list = from s in this.Context.GetTable<TShippingInstruction>()
        //                                             where (gmModel.chk_DeleteData || !s.DeleteFlag)
        //                                             && !s.ShippingCompleteFlag
        //                                             && s.DestinationLocationCD == null
        //                                             && s.DestinationWarehouseCD == null
        //                                             && s.CustomerCD == null
        //                                             && (!gmModel.cbk_NotGoodsIssueDataOnly || s.PickingCompleteFlag.Equals(false))
        //                                             && (!gmModel.cbk_NotPrintDataOnly || s.ShippingPrintFlag.Equals(false))
        //                                             && (string.IsNullOrEmpty(gmModel.txt_MoveNo) || s.ShipNo.Equals(gmModel.txt_MoveNo))
        //                                             && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
        //                                             && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
        //                                             && (s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
        //                                             orderby s.ShipNo
        //                                             select new MoveIndicationResults
        //                                             {
        //                                                 MoveNo = s.ShipNo,
        //                                                 MoveDate = s.ShipDate,
        //                                                 MoveKind = gmModel.ddl_MoveKind,
        //                                                 DeleteData = s.DeleteFlag,
        //                                                 PickingCompleteFlag = s.PickingCompleteFlag,
        //                                                 ShippingPrintFlag = s.ShippingPrintFlag,
        //                                                 UpdateDate = s.UpdateDate
        //                                             };
        //    return list;
        //}

        /// <summary>
        /// Get List By Condition For Move Goods Issue Inspection
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionList</param>
        /// <returns>IQueryable of MoveGoodsIssueInspectionResults</returns>
        public IQueryable<MoveGoodsIssueInspectionResults> GetListByConditionForMoveGoodsIssueInspection(MoveGoodsIssueInspectionList gmModel)
        {
            string dateFrom = gmModel.dCtr_ShipDateFrom.DateValue();
            string dateTo = gmModel.dCtr_ShipDateTo.DateValue();
            string locationCD = MLocation.FixCodeDB(gmModel.txt_LocationCDTo);
            string warehouseCD = gmModel.txt_WarehouseCDTo;
            string moveKind = gmModel.ddl_MoveKind;
            var ret = from s in this.Context.GetTable<TShippingInstruction>()
                      join lo in this.Context.GetTable<MLocation>() on new { key1 = s.DestinationLocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = lo.LocationCD, key2 = lo.WarehouseCD } into L
                      from l in L.DefaultIfEmpty()
                      join we in this.Context.GetTable<MWarehouse>() on s.DestinationWarehouseCD equals we.WarehouseCD into W
                      from w in W.DefaultIfEmpty()
                      where !s.PickingCompleteFlag && !s.DeleteFlag && s.CustomerCD == null
                          && s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                          && (string.IsNullOrEmpty(gmModel.txt_ShipNo) || s.ShipNo.Equals(gmModel.txt_ShipNo))
                          && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                          && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                          && (!(moveKind == Constant.MKIND_KINDCD_MOVE_KIND_LOCATION) ||
                              (s.DestinationLocationCD != null && (string.IsNullOrEmpty(locationCD) || s.DestinationLocationCD.Equals(locationCD))))
                          && (!(moveKind == Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE) ||
                              (s.DestinationWarehouseCD != null && (string.IsNullOrEmpty(warehouseCD) || s.DestinationWarehouseCD.Equals(warehouseCD))))
                          && (!(moveKind == Constant.MKIND_KINDCD_MOVE_KIND_SCRAP) ||
                              (s.DestinationLocationCD == null && s.DestinationWarehouseCD == null))
                      orderby s.ShipNo
                      let moveKindCd = s.DestinationLocationCD != null ? Constant.MKIND_KINDCD_MOVE_KIND_LOCATION : (s.DestinationWarehouseCD != null ? Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE : Constant.MKIND_KINDCD_MOVE_KIND_SCRAP)
                      select new MoveGoodsIssueInspectionResults
                      {
                          ShipNo = s.ShipNo,
                          ShipDate = s.ShipDate,
                          MoveKind = moveKindCd,
                          MoveKindDisplay = this.Context.MKind_D.Where(m => m.KindCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND) && m.DataCD.Equals(moveKindCd) && m.Language.Equals(UserSession.Session.Language)).Select(m => m.Value).SingleOrDefault(),
                          DestinationCD = s.DestinationWarehouseCD?? s.DestinationLocationCD,
                          DestinationNm = w.WarehouseName?? l.LocationName,
                          UpdateDate = s.UpdateDate
                      };
            return ret;
        }

        /// <summary>
        /// Get List By Condition For Goods Issue Inspection
        /// Author: ISV-Giam
        /// </summary>
        /// <param name="gmModel">GoodsIssueInspectionList</param>
        /// <returns>IQueryable of GoodsIssueInspectionResults</returns>
        public IQueryable<GoodsIssueInspectionResults> GetListByConditionForGoodsIssueInspection(GoodsIssueInspectionList gmModel)
        {
            string dateFrom = gmModel.dCtr_ShipDateFrom.DateValue();
            string dateTo = gmModel.dCtr_ShipDateTo.DateValue();
            string customerCd = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);

            IQueryable<GoodsIssueInspectionResults> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                      join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD into cs
                                                      from dd in cs.DefaultIfEmpty()
                                                      where (!s.PickingCompleteFlag) && (!s.DeleteFlag)
                                                        && s.CustomerCD != null
                                                        && (string.IsNullOrEmpty(gmModel.txt_ShipNo) || s.ShipNo.Equals(gmModel.txt_ShipNo))
                                                        && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                                                        && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                                                        && (string.IsNullOrEmpty(customerCd) || s.CustomerCD.Equals(customerCd))
                                                        && s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                      orderby s.ShipNo
                                                      select new GoodsIssueInspectionResults
                                                      {
                                                          ShipNo = s.ShipNo,
                                                          ShipDate = s.ShipDate,
                                                          CustomerCD = s.CustomerCD,
                                                          CustomerName = dd.CustomerName,
                                                          UpdateDate = s.UpdateDate
                                                      };
            return list;
        }

        /// <summary>
        /// Get List By Condition For Delivery Picking
        /// Author: ISV-Giam
        /// </summary>
        /// <param name="gmModel">DeliveryPickingList</param>
        /// <returns>IQueryable of DeliveryPickingResults</returns>
        public IQueryable<OutboundDeliveryResults> GetListByConditionForOutboundDelivery(OutboundDeliveryList gmModel)
        {
            string dateFrom = gmModel.dCtr_ShipDateFrom.DateValue();
            string dateTo = gmModel.dCtr_ShipDateTo.DateValue();
            string customerCd = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);

            IQueryable<OutboundDeliveryResults> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                      join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD
                                                      where (s.PickingCompleteFlag) && (!s.ShippingCompleteFlag)
                                                        && (string.IsNullOrEmpty(gmModel.txt_ShipNo) || s.ShipNo.Equals(gmModel.txt_ShipNo))
                                                        && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                                                        && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                                                        && (string.IsNullOrEmpty(customerCd) || s.CustomerCD.Equals(customerCd))
                                                        && s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                      orderby s.ShipNo
                                                      select new OutboundDeliveryResults
                                                      {
                                                          ShipNo = s.ShipNo,
                                                          ShipDate = s.ShipDate,
                                                          CustomerCD = s.CustomerCD,
                                                          CustomerName = c.CustomerName,
                                                          UpdateDate = s.UpdateDate,
                                                          ExistDelivery = this.Context.TInventory_D.Any(t => t.ShippingNo.Equals(s.ShipNo) && (bool)t.DeliveryFlag)
                                                      };
            return list;
        }

        /// <summary>
        /// Get header data for header
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns></returns>
        public OutboundDeliveryIndicationMain GetHeaderResultsByShipNo(string shipNo)
        {
            IQueryable<OutboundDeliveryIndicationMain> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                              join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD
                                                              where s.ShipNo.Equals(shipNo)
                                                              select new OutboundDeliveryIndicationMain
                                                              {
                                                                  PreShipNo = s.ShipNo,
                                                                  txt_ShipDate = s.ShipDate,
                                                                  txt_CustomerCD = s.CustomerCD,
                                                                  txt_CustomerName = c.CustomerName,
                                                                  Address1 = s.Address1,
                                                                  Address2 = s.Address2,
                                                                  Address3 = s.Address3,
                                                                  DeliveryNumber = s.DeliveryNumber,
                                                                  Memo = s.Memo,
                                                                  WarehouseCD = s.WarehouseCD,
                                                                  UpdateDate = s.UpdateDate,
                                                                  DeleteFlag = s.DeleteFlag,
                                                                  CompleteFlag = s.PickingCompleteFlag
                                                              };
            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get header data for header
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="moveNo"></param>
        /// <returns></returns>
        public MoveIndicationMain GetHeaderResultsByMoveNo(string moveNo)
        {
            IQueryable<MoveIndicationMain> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                            join w in this.Context.GetTable<MWarehouse>() on s.DestinationWarehouseCD equals w.WarehouseCD into wo
                                                            from dwo in wo.DefaultIfEmpty()
                                                            join l in this.Context.GetTable<MLocation>() on new { key1 = s.DestinationLocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into lo
                                                            from dlo in lo.DefaultIfEmpty()
                                                              where s.ShipNo.Equals(moveNo)
                                                              select new MoveIndicationMain
                                                              {
                                                                  PreMoveNo = s.ShipNo,
                                                                  txt_MoveDate = s.ShipDate,
                                                                  txt_WarehouseCDTo = s.DestinationWarehouseCD,
                                                                  txt_WarehouseName = dwo.WarehouseName,
                                                                  txt_LocationCDTo=s.DestinationLocationCD,
                                                                  txt_LocationName=dlo.LocationName,
                                                                  txt_DeliveryNumber = s.DeliveryNumber,
                                                                  Memo = s.Memo,
                                                                  UpdateDate = s.UpdateDate,
                                                                  DeleteFlag = s.DeleteFlag,
                                                                  CompleteFlag = s.PickingCompleteFlag
                                                              };
            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get By ShipNo
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>GoodsIssueInspectionHeader</returns>
        public GoodsIssueInspectionHeader GetByShipNo(string ShipNo, bool isCheckShipNo)
        {
            IQueryable<GoodsIssueInspectionHeader> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                          join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD
                                                          where !s.DeleteFlag
                                                          && s.ShipNo == ShipNo
                                                          && !s.PickingCompleteFlag
                                                          select new GoodsIssueInspectionHeader
                                                          {
                                                              txt_ShipNo = isCheckShipNo ? string.Empty : s.ShipNo,
                                                              ShipNoDB = s.ShipNo,
                                                              txt_ShipDate = CommonUtil.ParseDate(s.ShipDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                              txt_CustomerCD = s.CustomerCD,
                                                              txt_CustomerName = c.CustomerName,
                                                              UpdateDate = s.UpdateDate,
                                                              isCheckShipNo = isCheckShipNo
                                                          };
            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get By ShipNo For MoveGoodsIssueInspection
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns>MoveGoodsIssueInspectionHeader</returns>
        public MoveGoodsIssueInspectionHeader GetByShipNoForMoveHeader(string ShipNo, string moveKind, bool isCheckShipNo)
        {
            IQueryable<MoveGoodsIssueInspectionHeader> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                          join l in this.Context.GetTable<MLocation>() on new {key1 = s.DestinationLocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD} equals new {key1 = l.LocationCD, key2 = l.WarehouseCD} into L
                                                          from lo in L.DefaultIfEmpty()
                                                          join w in this.Context.GetTable<MWarehouse>() on s.DestinationWarehouseCD equals w.WarehouseCD into W
                                                          from wa in W.DefaultIfEmpty()
                                                          where !s.DeleteFlag
                                                          && s.ShipNo == ShipNo
                                                          && !s.PickingCompleteFlag
                                                          select new MoveGoodsIssueInspectionHeader
                                                          {
                                                              txt_ShipNo = isCheckShipNo ? string.Empty : s.ShipNo,
                                                              ShipNoDB = s.ShipNo,
                                                              txt_ShipDate = CommonUtil.ParseDate(s.ShipDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                              txt_LocationCDTo = s.DestinationLocationCD,
                                                              txt_LocationNameTo = lo.LocationName,
                                                              txt_WarehouseCDTo = s.DestinationWarehouseCD,
                                                              txt_WarehouseNameTo = wa.WarehouseName,
                                                              MoveKind = moveKind,
                                                              isCheckShipNo = isCheckShipNo
                                                          };
            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get Delivery Header By ShipNo
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>DeliveryPickingHeader</returns>
        public OutboundDeliveryHeader GetDeliveryHeaderByShipNo(string ShipNo, bool isCheckShipNo)
        {
            IQueryable<OutboundDeliveryHeader> list = from s in this.Context.GetTable<TShippingInstruction>()
                                                     join c in this.Context.GetTable<MCustomer>() on s.CustomerCD equals c.CustomerCD
                                                     where !s.DeleteFlag
                                                        && s.ShipNo.Equals(ShipNo)
                                                        && s.PickingCompleteFlag
                                                     select new OutboundDeliveryHeader
                                                     {
                                                         ShipNoDB = s.ShipNo,
                                                         txt_ShipNo = isCheckShipNo?string.Empty:s.ShipNo,
                                                         txt_ShipDate = CommonUtil.ParseDate(s.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE),
                                                         txt_CustomerCD = s.CustomerCD,
                                                         txt_CustomerName = c.CustomerName,
                                                         UpdateDate = s.UpdateDate,
                                                         ShippingCompleteFlag = s.ShippingCompleteFlag,
                                                         IsCheckShipNo = isCheckShipNo,
                                                     };
            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get Delivery Header By ShipNo
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>DeliveryPickingHeader</returns>
        public MoveOutboundDeliveryInspectionHeader GetMoveDeliveryHeaderByShipNo(string ShipNo, string MoveKind, bool isCheckShipNo)
        {
            IQueryable<MoveOutboundDeliveryInspectionHeader> list;
            if(MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                list = from s in this.Context.GetTable<TShippingInstruction>()
                                                      join w in this.Context.GetTable<MWarehouse>() on s.DestinationWarehouseCD equals w.WarehouseCD
                                                      where !s.DeleteFlag
                                                         && s.ShipNo.Equals(ShipNo)
                                                         && s.PickingCompleteFlag
                                                         && s.DestinationWarehouseCD != null
                                                      select new MoveOutboundDeliveryInspectionHeader
                                                      {
                                                          MoveNoDB = s.ShipNo,
                                                          txt_MoveNo = isCheckShipNo ? string.Empty : s.ShipNo,
                                                          txt_MoveDate = CommonUtil.ParseDate(s.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE), 
                                                          txt_WarehouseCDTo = s.DestinationWarehouseCD,
                                                          txt_WarehouseNameTo = w.WarehouseName,
                                                          UpdateDate = s.UpdateDate,
                                                          MoveKind = MoveKind,
                                                          IsCheckShipNo = isCheckShipNo,
                                                          ShippingCompleteFlag = s.ShippingCompleteFlag
                                                      };
            }
            else
            {
                list = from s in this.Context.GetTable<TShippingInstruction>()
                       where !s.DeleteFlag
                          && s.ShipNo.Equals(ShipNo)
                          && s.PickingCompleteFlag
                          && s.CustomerCD == null
                          && s.DestinationWarehouseCD == null
                       select new MoveOutboundDeliveryInspectionHeader
                       {
                           MoveNoDB = s.ShipNo,
                           txt_MoveNo = isCheckShipNo ? string.Empty : s.ShipNo,
                           txt_MoveDate = CommonUtil.ParseDate(s.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE), 
                           UpdateDate = s.UpdateDate,
                           MoveKind = MoveKind,
                           IsCheckShipNo = isCheckShipNo,
                           ShippingCompleteFlag = s.ShippingCompleteFlag
                       };
            }
            return list.SingleOrDefault();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns>OutboundDeliveryIndicationModel List</returns>
        public IQueryable<OutboundDeliveryIndicationModel> GetShippingInstructionList(List<string> ShipNo)
        {
            IQueryable<OutboundDeliveryIndicationModel> list = from d in this.Context.GetTable<TShippingInstructionDetails>()
                                                        join h in this.Context.GetTable<TShippingInstruction>() on new { key1 = d.ShipNo, key2 = false } equals new { key1 = h.ShipNo, key2 = h.DeleteFlag }
                                                        join c in this.Context.GetTable<MCustomer>() on h.CustomerCD equals c.CustomerCD into cs
                                                        from cus in cs.DefaultIfEmpty()
                                                        group new { d, h, cus} by new { h.ShipNo, h.CustomerCD } into gd
                                                        where ShipNo.Contains(gd.Key.ShipNo)
                                                        orderby gd.Key.ShipNo
                                                        select new OutboundDeliveryIndicationModel
                                                        {
                                                            ShipNo = gd.Key.ShipNo,
                                                            ShipDate = gd.Min(m => m.h.ShipDate),
                                                            InstructDate = gd.Min(m => m.h.InstructDate),
                                                            CustomerCD = gd.Key.CustomerCD,
                                                            CustomerName = gd.Min(m => m.cus.CustomerName),

                                                        };
            return list;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns>OutboundDeliveryIndicationModel List</returns>
        public IQueryable<OutboundDeliveryIndicationModel> GetSubShippingInstructionList(string ShipNo)
        {
            IQueryable<OutboundDeliveryIndicationModel> list = from d in this.Context.GetTable<TShippingInstructionDetails>()
                                                        join h in this.Context.GetTable<TShippingInstruction>() on new { key1 = d.ShipNo, key2 = false } equals new { key1 = h.ShipNo, key2 = h.DeleteFlag }
                                                        join id in this.Context.GetTable<TInventory_D>() on new { key1 = d.ShipNo, key2 = d.ShipDetailNo } equals new { key1 = id.ShippingNo, key2 = (int)id.ShippingDetailNo }
                                                        join ih in this.Context.GetTable<TInventory_H>() on id.TagNo equals ih.TagNo
                                                        join p in this.Context.GetTable<MProduct>() on d.ProductCD equals p.ProductCD into pr
                                                        from pro in pr.DefaultIfEmpty()
                                                        group new { d, h, id, ih, pro } by new { h.ShipNo, id.LocationCD, ih.TagNo, d.ProductCD } into gd
                                                        where ShipNo.Equals(gd.Key.ShipNo)

                                                        orderby gd.Key.ShipNo, gd.Key.LocationCD, gd.Key.TagNo, gd.Key.ProductCD

                                                               select new OutboundDeliveryIndicationModel

                                                        {
                                                            ShipNo = gd.Key.ShipNo,
                                                            LocationCD = gd.Key.LocationCD,
                                                            TagNo = gd.Key.TagNo,
                                                            ProductCD = gd.Key.ProductCD,
                                                            ProductName = gd.Min(m => m.pro.ProductName),
                                                            Lot1 = gd.Min(m => m.ih.Lot1),
                                                            Lot2 = gd.Min(m => m.ih.Lot2),
                                                            Lot3 = gd.Min(m => m.ih.Lot3),
                                                            Quantity = gd.Sum(m => m.d.InstructQuantity)
                                                        };
            return list;
        }

        #region Check

        /// <summary>
        /// Check ShipNo is Completed by Detail
        /// </summary>
        /// <param name="shipNo">Shipping No</param>
        /// <returns>True: all Shipping, False: any not Shipping</returns>
        public bool IsShipCompleteByDetail(string shipNo)
        {
            var lstDetail = this.Context.TInventory_D.Where(m => m.ShippingNo.Equals(shipNo));
            return lstDetail.All(m => (bool)m.DeliveryFlag);
        }

        /// <summary>
        /// Check ShipNo is Completed by ShipNo
        /// </summary>
        /// <param name="shipNo">Shipping No</param>
        /// <returns>Shipping Complete Flag</returns>
        public bool IsShipComplete(string shipNo)
        {
            return this.Context.TShippingInstruction.Where(m=>m.ShipNo.Equals(shipNo)).Select(m=>m.ShippingCompleteFlag).SingleOrDefault();
        }

        /// <summary>
        /// Check data changed
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns></returns>
        public bool CheckDataChangedNew(OutboundDeliveryIndicationMain gmModel)
        {
            return !Context.GetTable<TShippingInstruction>().Any(p => p.ShipNo.Trim().Equals(gmModel.PreShipNo)
                                                          && p.UpdateDate.Equals(gmModel.UpdateDate));
        }

        /// <summary>
        /// Check data changed for Move Indication
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public bool CheckDataChangeForMoveIndication(MoveIndicationMain gmModel)
        {
            return !Context.GetTable<TShippingInstruction>().Any(p => p.ShipNo.Trim().Equals(gmModel.PreMoveNo)
                                                                 && p.UpdateDate.Equals(gmModel.UpdateDate));
        }

        /// <summary>
        /// Check Deslocation is Exist
        /// </summary>
        /// <param name="locationCD">location code</param>
        /// <returns>True: Exist, False: not exist</returns>
        public bool IsExistDesLocation(string locationCD)
        {
            return this.ExistBy(s => s.DestinationLocationCD != null
                                     && s.DestinationLocationCD.Equals(locationCD)
                                     && s.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                                     && !s.DeleteFlag
                                     && !s.ShippingCompleteFlag);
        }

        /// <summary>
        /// Has Data not Picking complete (normal)
        /// </summary>
        /// <returns></returns>
        public bool IsExistRegist()
        {
            return this.Context.TShippingInstruction.Any(m => m.WarehouseCD.Equals(UserSession.Session.WarehouseCD) && !m.DeleteFlag && !m.PickingCompleteFlag);
        }

        /// <summary>
        /// Has Data Picking complete and Not Shipping complete
        /// </summary>
        /// <returns></returns>
        public bool IsExistRun()
        {
            return this.Context.TShippingInstruction.Any(m => m.WarehouseCD.Equals(UserSession.Session.WarehouseCD) && m.PickingCompleteFlag && !m.ShippingCompleteFlag && m.DestinationLocationCD == null);
        }

        /// <summary>
        /// Check exist LocationCD
        /// Author : ISV-Vinh
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool ExistByLocation(string WarehouseCD, string LocationCD)
        {
            bool result = this.ExistBy(s => s.DestinationLocationCD.Equals(LocationCD)
                                        && s.WarehouseCD.Equals(WarehouseCD)
                                        && !s.ShippingCompleteFlag);
            return result;
        }

        #endregion

        #region Print

        #region Header

        /// <summary>
        /// Get DataItem Print Header
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="listShipNo"></param>
        /// <returns>List Print_OutboundDeliveryIndication_Header</returns>
        public IQueryable<Print_OutboundDeliveryIndication_Header> GetDataItemPrintHeader(List<string> listShipNo)
        {
            IQueryable<Print_OutboundDeliveryIndication_Header> items = from sh in this.Context.TShippingInstruction
                                                                       join c in this.Context.MCustomer on sh.CustomerCD equals c.CustomerCD
                                                                       where !sh.DeleteFlag
                                                                          && sh.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                                          && listShipNo.Contains(sh.ShipNo)
                                                                       orderby sh.ShipNo
                                                                       select new Print_OutboundDeliveryIndication_Header
                                                                       {
                                                                           ShipNo = sh.ShipNo,
                                                                           ShipDate = sh.ShipDate,
                                                                           InstructDate = sh.InstructDate,
                                                                           CustomerCD = sh.CustomerCD,
                                                                           CustomerName = c.CustomerName,
                                                                           ShippingCompleteFlag = sh.ShippingCompleteFlag,
                                                                           DeliveryNumber = sh.DeliveryNumber,
                                                                           Address1 = sh.Address1,
                                                                           Address2 = sh.Address2,
                                                                           Address3 = sh.Address3,
                                                                       };
            return items;
        }

        /// <summary>
        /// Get DataItem Print Header
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="listShipNo"></param>
        /// <returns>List Print_MoveIndication_Header</returns>
        public IQueryable<Print_MoveIndication_Header> GetDataItemPrintHeaderForMoveIndication(List<string> listMoveNo)
        {
            IQueryable<Print_MoveIndication_Header> items = from sh in this.Context.TShippingInstruction
                                                                        join w in this.Context.MWarehouse on sh.DestinationWarehouseCD equals w.WarehouseCD into wh
                                                                        from ww in wh.DefaultIfEmpty()
                                                                        join lo in this.Context.MLocation on new { key1 = sh.DestinationLocationCD, key2 = UserSession.Session.WarehouseCD} equals new { key1 = lo.LocationCD, key2 = lo.WarehouseCD } into low
                                                                        from ll in low.DefaultIfEmpty()
                                                                        where !sh.DeleteFlag
                                                                           && sh.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                                           && listMoveNo.Contains(sh.ShipNo)
                                                                        orderby sh.ShipNo
                                                                        select new Print_MoveIndication_Header
                                                                        {
                                                                            ShipNo = sh.ShipNo,
                                                                            ShipDate = sh.ShipDate,
                                                                            DestinationWarehouseCD=sh.DestinationWarehouseCD,
                                                                            DestinationWarehouseCDNm=ww.WarehouseName,
                                                                            DestinationLocationCD=sh.DestinationLocationCD,
                                                                            DestinationLocationCDNm=ll.LocationName,
                                                                            InstructDate = sh.InstructDate,
                                                                            ShippingCompleteFlag = sh.ShippingCompleteFlag,
                                                                            DeliveryNumber = sh.DeliveryNumber
                                                                            
                                                                        };
            return items;
        }

        #endregion Header

        #region Detail

        /// <summary>
        /// Get DataList Print Detail
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <param name="ShippingCompleteFlag"></param>
        /// <returns>List Print_OutboundDeliveryIndication_Detail</returns>
        public IQueryable<Print_OutboundDeliveryIndication_Detail> GetDataListPrintDetail(string ShipNo, bool ShippingCompleteFlag)
        {
            if (!ShippingCompleteFlag)
            {
                return GetDataListPrintDetail_NotShippingComplete(ShipNo);
            }
            return GetDataListPrintDetail_ShippingComplete(ShipNo);
        }

        /// <summary>
        /// Get DataList Print Detail
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <param name="ShippingCompleteFlag"></param>
        /// <returns>List Print_MoveIndication_Detail</returns>
        public IQueryable<Print_MoveIndication_Detail> GetDataListPrintDetailForMoveIndication(string MoveNo, bool ShippingCompleteFlag, string locationTo)
        {
            //if (!ShippingCompleteFlag)
            //{
            //    return GetDataListPrintDetail_NotShippingCompleteForMoveIndication(MoveNo);
            //}
            //return GetDataListPrintDetail_ShippingCompleteForMoveIndication(MoveNo);
            IQueryable<Print_MoveIndication_Detail> items = from sD in this.Context.TShippingInstructionDetails
                                                            join iD in this.Context.TInventory_D on new { key1 = sD.TagNo , key2 = (int)sD.BranchTagNo } equals new { key1 = iD.TagNo, key2 = iD.BranchTagNo }
                                                            join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                                                            join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                                                            where sD.ShipNo.Equals(MoveNo)
                                                               && iH.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                                                            orderby iD.LocationCD,
                                                                    iD.TagNo,
                                                                    p.ProductCD,
                                                                    iH.Lot1,
                                                                    iH.Lot2,
                                                                    iH.Lot3
                                                            select new Print_MoveIndication_Detail
                                                            {
                                                                ShipNo = sD.ShipNo,
                                                                TagNo = iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                                LocationCD = iD.LocationCD,
                                                                ProductCD = iH.ProductCD,
                                                                ProductName = p.ProductName,
                                                                Lot1 = iH.Lot1,
                                                                Lot2 = iH.Lot2,
                                                                Lot3 = iH.Lot3,
                                                                IsDelied = iD.DeliveryFlag.Value || (!string.IsNullOrEmpty(locationTo) && iD.LocationCD.Equals(locationTo)),
                                                                Quantity = 1
                                                            };
            return items;
        }

        /// <summary>
        /// Get DataList Print Detail _ Not Shipping Complete
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>List Print_OutboundDeliveryIndication_Detail</returns>
        private IQueryable<Print_OutboundDeliveryIndication_Detail> GetDataListPrintDetail_NotShippingComplete(string ShipNo)
        {
            IQueryable<Print_OutboundDeliveryIndication_Detail> items = from r in this.Context.TReserve
                                                                        join h in this.Context.TInventory_H on r.TagNo equals h.TagNo
                                                                        join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                                                                        where r.ShipNo.Equals(ShipNo)
                                                                        orderby r.LocationCD,
                                                                                r.TagNo,
                                                                                p.ProductCD,
                                                                                p.ProductName,
                                                                                h.Lot1,
                                                                                h.Lot2,
                                                                                h.Lot3
                                                                        select new Print_OutboundDeliveryIndication_Detail
                                                                        {
                                                                           ShipNo = r.ShipNo,
                                                                           LocationCD = r.LocationCD,
                                                                           TagNo = r.TagNo,
                                                                           ProductCD = p.ProductCD,
                                                                           ProductName = p.ProductName,
                                                                           Lot1 = h.Lot1,
                                                                           Lot2 = h.Lot2,
                                                                           Lot3 = h.Lot3,
                                                                           Quantity = r.Quantity
                                                                        };
            return items;
        }

        /// <summary>
        /// Get DataList Print Detail _ Not Shipping Complete
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>List Print_MoveIndication_Detail</returns>
        private IQueryable<Print_MoveIndication_Detail> GetDataListPrintDetail_NotShippingCompleteForMoveIndication(string MoveNo)
        {
            IQueryable<Print_MoveIndication_Detail> items = from r in this.Context.TReserve
                                                                        join h in this.Context.TInventory_H on r.TagNo equals h.TagNo
                                                                        join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                                                                        where r.ShipNo.Equals(MoveNo)
                                                                        orderby r.LocationCD,
                                                                                r.TagNo,
                                                                                p.ProductCD,
                                                                                p.ProductName,
                                                                                h.Lot1,
                                                                                h.Lot2,
                                                                                h.Lot3
                                                                        select new Print_MoveIndication_Detail
                                                                        {
                                                                            ShipNo = r.ShipNo,
                                                                            LocationCD = r.LocationCD,
                                                                            TagNo = r.TagNo,
                                                                            ProductCD = p.ProductCD,
                                                                            ProductName = p.ProductName,
                                                                            Lot1 = h.Lot1,
                                                                            Lot2 = h.Lot2,
                                                                            Lot3 = h.Lot3,
                                                                            Quantity = r.Quantity
                                                                        };
            return items;
        }

        /// <summary>
        /// Get DataList Print Detail _ Shipping Complete
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>List Print_OutboundDeliveryIndication_Detail</returns>
        private IQueryable<Print_OutboundDeliveryIndication_Detail> GetDataListPrintDetail_ShippingComplete(string ShipNo)
        {
            IQueryable<Print_OutboundDeliveryIndication_Detail> items = from d in this.Context.TInventory_D
                                                                        join h in this.Context.TInventory_H on d.TagNo equals h.TagNo
                                                                        join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                                                                        where d.ShippingNo.Equals(ShipNo)
                                                                        orderby d.LocationCD,
                                                                                d.TagNo,
                                                                                p.ProductCD,
                                                                                p.ProductName,
                                                                                h.Lot1,
                                                                                h.Lot2,
                                                                                h.Lot3
                                                                        group new { d, h, p } by new { d.ShippingNo, d.TagNo, d.LocationCD } into grp
                                                                        select new Print_OutboundDeliveryIndication_Detail
                                                                        {
                                                                            ShipNo = grp.Key.ShippingNo,
                                                                            LocationCD = grp.Min(m =>m.d.LocationCD),
                                                                            TagNo = grp.Key.TagNo,
                                                                            ProductCD = grp.Min(m =>m.p.ProductCD),
                                                                            ProductName = grp.Min(m =>m.p.ProductName),
                                                                            Lot1 = grp.Min(m =>m.h.Lot1),
                                                                            Lot2 = grp.Min(m =>m.h.Lot2),
                                                                            Lot3 = grp.Min(m => m.h.Lot3),
                                                                            Quantity = grp.Count(m => m.d.TagNo.Equals(grp.Key.TagNo))
                                                                        };
            return items;
        }

        /// <summary>
        /// Get DataList Print Detail _ Shipping Complete
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="ShipNo"></param>
        /// <returns>List Print_MoveIndication_Detail</returns>
        private IQueryable<Print_MoveIndication_Detail> GetDataListPrintDetail_ShippingCompleteForMoveIndication(string MoveNo)
        {
            IQueryable<Print_MoveIndication_Detail> items = from d in this.Context.TInventory_D
                                                                        join h in this.Context.TInventory_H on d.TagNo equals h.TagNo
                                                                        join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                                                                        where d.ShippingNo.Equals(MoveNo)
                                                                        orderby d.LocationCD,
                                                                                d.TagNo,
                                                                                p.ProductCD,
                                                                                p.ProductName,
                                                                                h.Lot1,
                                                                                h.Lot2,
                                                                                h.Lot3
                                                                        group new { d, h, p } by new { d.ShippingNo, d.TagNo, d.LocationCD } into grp
                                                                        select new Print_MoveIndication_Detail
                                                                        {
                                                                            ShipNo = grp.Key.ShippingNo,
                                                                            LocationCD = grp.Min(m => m.d.LocationCD),
                                                                            TagNo = grp.Key.TagNo,
                                                                            ProductCD = grp.Min(m => m.p.ProductCD),
                                                                            ProductName = grp.Min(m => m.p.ProductName),
                                                                            Lot1 = grp.Min(m => m.h.Lot1),
                                                                            Lot2 = grp.Min(m => m.h.Lot2),
                                                                            Lot3 = grp.Min(m => m.h.Lot3),
                                                                            Quantity = grp.Count(m => m.d.TagNo.Equals(grp.Key.TagNo))
                                                                        };
            return items;
        }
        #endregion

        #endregion

        /// <summary>
        /// Get List By Condition For Move Outbound Delivery Inspection
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="gmModel">DeliveryPickingList</param>
        /// <returns>IQueryable of DeliveryPickingResults</returns>
        public IQueryable<MoveOutboundDeliveryInspectionResults> GetListMoveOutboundDeliveryByCondition(MoveOutboundDeliveryInspectionList gmModel)
        {
            string dateFrom = gmModel.dCtr_MoveDateFrom.DateValue();
            string dateTo = gmModel.dCtr_MoveDateTo.DateValue();
            IQueryable<MoveOutboundDeliveryInspectionResults> list;
            string moveKind = gmModel.ddl_MoveKind ?? string.Empty;
            string warehouseCd = gmModel.txt_WarehouseCDTo;                
            
            list = from s in this.Context.GetTable<TShippingInstruction>()
                    join w in this.Context.GetTable<MWarehouse>() on s.DestinationWarehouseCD equals w.WarehouseCD into W
                    from wa in W.DefaultIfEmpty()
                    where (s.PickingCompleteFlag) && (!s.ShippingCompleteFlag)
                    && (string.IsNullOrEmpty(gmModel.txt_MoveNo) || s.ShipNo.Equals(gmModel.txt_MoveNo))
                    && (string.IsNullOrEmpty(dateFrom) || s.ShipDate.CompareTo(dateFrom) >= 0)
                    && (string.IsNullOrEmpty(dateTo) || s.ShipDate.CompareTo(dateTo) <= 0)
                    && (string.IsNullOrEmpty(warehouseCd) || s.DestinationWarehouseCD.Equals(warehouseCd))
                    && s.CustomerCD == null
                    && s.DestinationLocationCD == null
                    &&
                    (
                        string.IsNullOrEmpty(moveKind)
                        || (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE) && s.DestinationWarehouseCD != null)
                        || (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP) && s.DestinationWarehouseCD == null)
                    )
                    && s.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                    orderby s.ShipNo
                    select new MoveOutboundDeliveryInspectionResults
                    {
                        MoveNo = s.ShipNo,
                        MoveDate = s.ShipDate,
                        WarehouseCD = s.DestinationWarehouseCD,
                        WarehouseName = wa.WarehouseName,
                        UpdateDate = s.UpdateDate,
                        ExistDelivery = this.Context.TInventory_D.Any(t => t.ShippingNo.Equals(s.ShipNo) && (bool)t.DeliveryFlag),
                        MoveKindDisp = (from k in this.Context.MKind_D
                                        where k.KindCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND)
                                           &&
                                           (
                                               (s.DestinationWarehouseCD != null && k.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                                            || (s.DestinationWarehouseCD == null && k.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
                                           )
                                           && k.Language.Equals(UserSession.Session.Language)
                                        select k.Value).SingleOrDefault(),
                        MoveKind = s.DestinationWarehouseCD != null ? Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE :
                                   Constant.MKIND_KINDCD_MOVE_KIND_SCRAP,
                    };
           
             
            return list;
        }
    }
}
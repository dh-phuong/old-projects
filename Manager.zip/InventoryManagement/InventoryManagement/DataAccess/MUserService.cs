﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MUser Context
    /// Author: ISV - Thuy
    /// </summary>
    public class MUserService : DataAccess.Abstract.AbstractService<MUser>
    {

        #region public method

        #region Get
        
        /// <summary>
        /// Get List User CSV
        /// </summary>
        /// <returns>IQueryable</returns>
        public IQueryable<UserListCSV> GetListUserCSV()
        {
            IQueryable<UserListCSV> list = from u in this.Context.GetTable<Models.MUser>()
                                           orderby u.UserCD
                                           select new UserListCSV
                                           {
                                               UserCD = u.UserCD,
                                               LoginID = u.LoginID,
                                               PassWord = u.Password,
                                               UserFullName = u.UserFullName,
                                               UserShortName = u.UserShortName,
                                               GroupCD = u.GroupCD,
                                               CustomerCD = u.CustomerCD,
                                               CreateDate = u.CreateDate,   
                                               CreateUCD = u.CreateUCD,
                                               UpdateDate = u.UpdateDate,                                               
                                               UpdateUCD = u.UpdateUCD,
                                               DeleteFlag = u.DeleteFlag                                               
                                           };

            return list;
        }

        /// <summary>
        /// Get User List
        /// </summary>
        /// <param name="gmModel">UserList</param>
        /// <returns>IQueryable of UserModels</returns>
        public IQueryable<UserResults> GetListByConditions(UserList gmModel)
        {
            string userCD = gmModel.txt_UserCD;
            if (string.IsNullOrEmpty(gmModel.txt_UserName))
            {
                gmModel.txt_UserName = string.Empty;
            }

            if (string.IsNullOrEmpty(gmModel.txt_LoginID)) {
                gmModel.txt_LoginID = string.Empty;
            }
            IQueryable<UserResults> list = from u in this.Context.GetTable<Models.MUser>()
                                           join g in this.Context.GetTable<Models.MGroup_H>() on new { key1 = u.GroupCD, key2 = false } equals new { key1 = g.GroupCD, key2 = g.DeleteFlag}
                                           join c in this.Context.MCustomer on u.CustomerCD equals c.CustomerCD into C
                                           from cu in C.DefaultIfEmpty()
                                           where (gmModel.chk_DeleteData || u.DeleteFlag == false)
                                                 && (string.IsNullOrEmpty(gmModel.txt_LoginID) || u.LoginID.ToUpper().StartsWith(gmModel.txt_LoginID.ToUpper()))
                                                 && (string.IsNullOrEmpty(userCD) || u.UserCD.StartsWith(userCD))
                                                 && (string.IsNullOrEmpty(gmModel.txt_GroupCD) || u.GroupCD.StartsWith(gmModel.txt_GroupCD))
                                                 && (string.IsNullOrEmpty(gmModel.txt_CustomerCD) || u.CustomerCD.StartsWith(gmModel.txt_CustomerCD))
                                                 && (string.IsNullOrEmpty(gmModel.txt_UserName) || u.UserFullName.ToUpper().Contains(gmModel.txt_UserName.ToUpper()) || u.UserShortName.ToUpper().Contains(gmModel.txt_UserName.ToUpper()))
                                                 && (UserSession.Session.LoginInfo.User.GroupCD.Equals(Common.Constant.GROUP_SUPPER_ADMIN_CD)
                                                        || !g.GroupCD.Equals(Common.Constant.GROUP_SUPPER_ADMIN_CD))

                                           select new UserResults
                                            {
                                                UserCD = u.UserCD.Substring(u.UserCD.Length - Common.Constant.MUSER_USER_CD_SHOW),
                                                LoginID = u.LoginID,
                                                UserFullName = u.UserFullName,
                                                UserShortName = u.UserShortName,
                                                UpdateDate = u.UpdateDate,
                                                GroupNm = g.GroupName,
                                                CustomerCD = u.CustomerCD,
                                                CustomerName = cu.CustomerName,
                                                DeleteFlag = u.DeleteFlag
                                            };

            return list;
        }

        /// <summary>
        /// Get User List
        /// Author: ISV-TRAM
        /// </summary>
        /// <param name="model">UserSearch</param>
        /// <returns>IQueryable of UserSearch</returns>
        public IQueryable<UserSearch> GetListByConditionsForSearch(UserSearch gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sUserName))
            {
                gmModel.sUserName = string.Empty; 
            }
            if (string.IsNullOrEmpty(gmModel.sLoginID))
            {
                gmModel.sLoginID = string.Empty;
            }

            IQueryable<UserSearch> list = from u in this.Context.GetTable<MUser>()
                                          join g in this.Context.GetTable<Models.MGroup_H>() on new { key1 = u.GroupCD, key2 = false } equals new { key1 = g.GroupCD, key2 = g.DeleteFlag }
                                          where (!u.DeleteFlag)
                                                && (string.IsNullOrEmpty(gmModel.sUserCD) || u.UserCD.StartsWith(gmModel.sUserCD))
                                                && (string.IsNullOrEmpty(gmModel.sLoginID) || u.LoginID.ToUpper().StartsWith(gmModel.sLoginID.ToUpper()))
                                                && (string.IsNullOrEmpty(gmModel.sUserName) || (u.UserShortName.ToUpper().Contains(gmModel.sUserName.ToUpper())) || (u.UserFullName.ToUpper().Contains(gmModel.sUserName.ToUpper())))
                                                && (string.IsNullOrEmpty(gmModel.sGroupCD) || u.GroupCD.StartsWith(gmModel.sGroupCD))

                                          select new UserSearch
                                          {
                                              sUserCD = u.UserCD,
                                              sLoginID = u.LoginID,
                                              sUserFullName = u.UserFullName,
                                              sUserName = u.UserShortName,
                                              sUserShortName = u.UserShortName,
                                              sGroupCD = u.GroupCD,
                                              sGroupName = g.GroupName
                                          };
            return list;
        }

        /// <summary>
        /// Get by Login Code
        /// </summary>
        /// <param name="loginID">loginID</param>
        /// <param name="languague">languague</param>
        /// <returns>IQueryable of UserModels</returns>
        public UserModels GetByLoginID(string loginID)
        //public UserModels GetByLoginID(string loginID, string languague)
        {
            IQueryable<UserModels> item = from u in this.Context.GetTable<MUser>()
                                          join g in this.Context.GetTable<Models.MGroup_H>() on new { key1 = u.GroupCD, key2 = false } equals new { key1 = g.GroupCD, key2 = g.DeleteFlag }
                                          join c in this.Context.MCustomer on u.CustomerCD equals c.CustomerCD into C
                                          from cu in C.DefaultIfEmpty()
                                        //join k in this.Context.GetTable<MKind_D>() on new { key1 = u.RolesCD, key2 = Common.Constant.MKIND_KINDCD_ROLES, key3 = languague } equals new { key1 = k.DataCD, key2 = k.KindCD.ToString(), key3 = Convert.ToString((int)k.Language) }
                                          where u.DeleteFlag == false && u.LoginID == loginID
                                          select new UserModels
                                          {
                                              UserCD = u.UserCD,
                                              UserFullName = u.UserFullName,
                                              UserShortName = u.UserShortName,
                                              LoginID = u.LoginID,
                                              Password = u.Password,
                                              GroupCD = u.GroupCD,
                                              GroupNm = g.GroupName,
                                              CustomerCD = u.CustomerCD,
                                              CustomerName = cu.CustomerName
                                          };
            //Decrypt Password
            UserModels ret = item.SingleOrDefault();
            if (ret != default(UserModels))
            {
                ret.Password = Security.Decrypt(ret.Password);
            }

            return ret;
        }

        /// <summary>
        /// Get by Login ID
        /// </summary>
        /// <param name="loginCD">loginID</param>
        /// <returns>IQueryable of UserModels</returns>
        public UserModels GetUserByLoginID(string loginID)
        {
           var item = from u in this.Context.GetTable<MUser>()
                      join g in this.Context.GetTable<MGroup_H>() on new { key1 = u.GroupCD, key2 = false } equals new { key1 = g.GroupCD, key2 = g.DeleteFlag }
                      join c in this.Context.MCustomer on u.CustomerCD equals c.CustomerCD into C
                      from cu in C.DefaultIfEmpty()                     
                      //join k in this.Context.GetTable<MKind_D>() on new { key1 = u.RolesCD, key2 = Common.Constant.MKIND_KINDCD_ROLES, key3 = Convert.ToString((int)UserSession.Session.Language) } equals new { key1 = k.DataCD, key2 = k.KindCD.ToString(), key3 = Convert.ToString((int)k.Language) }
                      where u.LoginID == loginID                                               
                      select new UserModels
                      {
                          UserCD = u.UserCD,
                          UserFullName = u.UserFullName,
                          UserShortName = u.UserShortName,
                          LoginID = u.LoginID,
                          Password = u.Password,
                          GroupCD = u.GroupCD,
                          GroupNm = g.GroupName,
                          CustomerCD = u.CustomerCD,
                          CustomerName = cu.CustomerName,
                          DeleteFlag = u.DeleteFlag
                      };

           //Decrypt Password
           UserModels ret = item.SingleOrDefault();
           if (ret != default(UserModels))
           {
               ret.Password = Security.Decrypt(ret.Password);
           }

           return ret;
        }

        /// <summary>
        /// Get User by Id
        /// </summary>
        /// <param name="userCd">Id of User</param>
        /// <returns>UserMaster</returns>
        public UserModels GetByUserCd(string userCd)
        {            
            var item = from u1 in this.Context.GetTable<MUser>()
                       join u2 in this.Context.GetTable<MUser>() on u1.UpdateUCD equals u2.UserCD into sub
                       join g in this.Context.GetTable<MGroup_H>() on new { key1 = u1.GroupCD, key2 = false } equals new { key1 = g.GroupCD, key2 = g.DeleteFlag }
                       join c in this.Context.MCustomer on u1.CustomerCD equals c.CustomerCD into C
                       from cu in C.DefaultIfEmpty()                    
                       //join k in this.Context.GetTable<MKind_D>() on new { key1 = u1.RolesCD, key2 = Common.Constant.MKIND_KINDCD_ROLES, key3 = Convert.ToString((int)UserSession.Session.Language) } equals new { key1 = k.DataCD, key2 = k.KindCD.ToString(), key3 = Convert.ToString((int)k.Language) }
                       from t in sub.DefaultIfEmpty()
                       where u1.UserCD == userCd
                       select new UserModels
                       {
                           UserCD = u1.UserCD.Substring(u1.UserCD.Length - Common.Constant.MUSER_USER_CD_SHOW),
                           LoginID = u1.LoginID,
                           Password = u1.Password,
                           UserFullName = u1.UserFullName,
                           UserShortName = u1.UserShortName,
                           GroupCD = u1.GroupCD,
                           GroupNm = g.GroupName,
                           CustomerCD = u1.CustomerCD,
                           CustomerName = cu.CustomerName,
                           UpdateDate = u1.UpdateDate,                           
                           DeleteFlag = u1.DeleteFlag,       
                           PreUserCD = u1.UserCD
                       };

            //Decrypt Password
            UserModels ret = item.SingleOrDefault();
            if (ret != default(UserModels))
            {
                ret.Password = Security.Decrypt(ret.Password);
            }

            return ret;
        }
              
        /// <summary>
        /// Get User by Cd and Update Date
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns>MUser</returns>
        public MUser GetByCdAndUpDate(string userCD, string updateDate)
        {

            IQueryable<MUser> item = from p in this.Context.MUser
                                        where (p.UserCD.Trim().Equals(userCD) && p.UpdateDate.Equals(updateDate))
                                        select p;

            return item.SingleOrDefault();
        }
        #endregion

        #region Check       
       
        
        /// <summary>
        /// Check data changed
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        public bool CheckDataChanged(UserModels gmModel)
        {

            return !Context.GetTable<MUser>().Any(p => p.UserCD.Equals(gmModel.UserCD)
                                               && p.UpdateDate.Equals(gmModel.UpdateDate));
        }

        /// <summary>
        /// Check exist DataCD in MUser
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMUser(string dataCD)
        {
            return this.ExistBy(k => k.GroupCD.Equals(dataCD));
            //return this.Context.GetTable<MUser>().Any(k => k.RolesCD.Equals(dataCD));
        }

        /// <summary>
        /// Check Group is exist in User table
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsGroupExist(string GroupCD)
        {
            return this.ExistBy(u => u.GroupCD.Equals(GroupCD));
        }

        #endregion

        #endregion
    }
}
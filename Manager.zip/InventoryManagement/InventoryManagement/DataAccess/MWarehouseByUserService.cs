﻿using System.Linq;
using InventoryManagement.Models;
using System.Collections.Generic;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Service of MWarehouseByUser
    /// Author : ISV-Loc
    /// </summary>

    public class MWarehouseByUserService : DataAccess.Abstract.AbstractService<MWarehouseByUser>
    {
        #region GET DATA

        /// <summary>
        /// Get Warehouse List By UserCD
        /// </summary>
        /// <param name="gmModel">userCD</param>
        /// <returns>List MWarehouseByUser</returns>
        public List<MWarehouseByUser> GetListByUserCD(string userCD)
        {
            IQueryable<MWarehouseByUser> list = from r in this.Context.GetTable<MWarehouseByUser>()
                                                where r.UserCD.Equals(userCD)
                                                select r;
           
            return list.ToList();
        }


        /// <summary>
        /// Get By Cd
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <returns>IQueryable WarehouseByUserGrid</returns>
        public IQueryable<WarehouseByUserGrid> GetListDetailByUserCD(string userCD)
        {
            IQueryable<WarehouseByUserGrid> items = from c in this.Context.GetTable<MWarehouseByUser>()
                                                   join w in this.Context.GetTable<MWarehouse>() on c.WarehouseCD equals w.WarehouseCD into warehouse
                                                   from leftW in warehouse.DefaultIfEmpty()
                                                   where c.UserCD.Equals(userCD)
                                                   select new WarehouseByUserGrid
                                               {
                                                   txt_WarehouseCD = c.WarehouseCD.Substring(c.WarehouseCD.Length - Common.Constant.MWAREHOUSE_WAREHOUSECD_SHOW),
                                                   txt_WarehouseName = leftW.WarehouseName
                                               };
            return items;
        }

        #endregion

        #region CHECK

        /// <summary>
        /// Check Exists
        /// Author:ISV-LOC
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <returns>True: Exist False:Not Exist</returns>
        public bool Exist(string userCD)
        {
            return this.Context.MWarehouseByUser.Any(m => m.UserCD.Equals(userCD));
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.Objects.SqlClient;
using InventoryManagement.Common;
using System.Collections;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TTakeInventory_D Service
    /// Author : ISV-LOC
    /// </summary>
    public class TTakeInventory_DService : DataAccess.Abstract.AbstractService<TTakeInventory_D>
    {
        #region public

        /// <summary>
        /// Get data by primary key
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="tagNo"></param>
        /// <returns></returns>
        public TTakeInventory_D GetByPK(string warehouseCD, string locationCD, string tagNo, string BranchTagNo)
        {
            int branchTagNo = CommonUtil.ParseInteger(BranchTagNo);
            IQueryable<TTakeInventory_D> item = from i in this.Context.GetTable<TTakeInventory_D>()
                                            where i.WarehouseCD.Equals(warehouseCD)
                                                  && i.LocationCD.Equals(locationCD)
                                                  && i.TagNo.Trim().Equals(tagNo)
                                                  && i.BranchTagNo.Equals(branchTagNo)
                                            select i;

            return item.SingleOrDefault<TTakeInventory_D>();
        }

        /// <summary>
        /// Get All By Location
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeInventory_D> GetAllByLocation(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeInventory_D> item = from i in this.Context.GetTable<TTakeInventory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                select i;

            return item;

        }

        /// <summary>
        /// Get List By Location
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <param name="LocationCD"></param>
        /// <param name="dc"></param>
        /// <returns>List TTakeInventory_D</returns>
        public List<TTakeInventory_D> GetListByLocation(string WarehouseCD, string LocationCD)
        {
            IQueryable<TTakeInventory_D> items = from td in this.Context.TTakeInventory_D
                                                 where td.LocationCD.Equals(LocationCD)
                                                    && td.WarehouseCD.Equals(WarehouseCD)
                                                 select td;
            return items.ToList();
        }

        /// <summary>
        /// Get List Deficit
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeInventory_D> GetListDeficit(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeInventory_D> item = from i in this.Context.GetTable<TTakeInventory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                      && i.TakeFlag ==false
                                                select i;

            return item;

        }

        /// <summary>
        /// Get List Surplus
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeInventory_D> GetListSurplus(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeInventory_D> item = from i in this.Context.GetTable<TTakeInventory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                      && i.TakeFlag == true
                                                      && i.TakeStatus == Constant.TAKE_STATUS_RECEIPTS
                                                select i;

            return item;

        }

        /// <summary>
        /// Get List Picking Results
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <param name="takeFlag">Take Flag</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<StockTakeInspectionResults> GetListPickingResults(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            var result = from t in this.Context.GetTable<TTakeInventory_D>()
                         join p in this.Context.GetTable<MProduct>() on new { key1 = t.ProductCD} equals new { key1 = p.ProductCD}
                         where !t.DeleteFlag && t.WarehouseCD.Equals(warehouseCD) && t.LocationCD.Equals(locationCd) && t.TakeFlag
                         select new StockTakeInspectionResults()
                         {
                             TakeFlag = t.TakeFlag,
                             TagNoAndBranchTagNo= t.TagNo + Constant.HYPHEN + t.BranchTagNo.ToString().PadLeft(4, '0'),
                             //TagNo = t.TagNo,
                             //BranchTagNo = t.BranchTagNo.ToString(),
                             //ProductCD = t.ProductCD,
                             //ProductName = p.ProductName,
                             //LOT1 = t.LOT1,
                             //LOT2 = t.LOT2,
                             //LOT3 = t.LOT3,
                             UpdateDate = t.UpdateDate,
                             TakeStatus = t.TakeStatus,
                         };

            return result;
            
        }

        /// <summary>
        /// Get List Picking Results
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <param name="takeFlag">Take Flag</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<StockTakeProclamationDetailResults> GetListStockTakeProclamationDetailResults(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            var result = from t in this.Context.GetTable<TTakeInventory_D>()
                         join p in this.Context.GetTable<MProduct>() on new { key1 = t.ProductCD } equals new { key1 = p.ProductCD }
                         where !t.DeleteFlag && t.WarehouseCD.Equals(warehouseCD) && t.LocationCD.Equals(locationCd)
                         select new StockTakeProclamationDetailResults()
                         {
                             TakeFlag = t.TakeFlag,
                             TakeStatus  = t.TakeStatus,
                             TagNoAndBranchTagNo = t.TagNo + Constant.HYPHEN + t.BranchTagNo.ToString().PadLeft(4, '0'),
                             TagNo = t.TagNo,
                             BranchTagNo = t.BranchTagNo.ToString(),
                             ProductCD = t.ProductCD,
                             ProductName = p.ProductName,
                             LOT1 = t.LOT1,
                             LOT2 = t.LOT2,
                             LOT3 = t.LOT3,
                             UpdateDate = t.UpdateDate
                         };

            return result;
        }
        
        #endregion

        #region Check

        ///// <summary>
        ///// Check exist LocationCD with TakeFlg = False  :"UnCompleted"
        ///// Author:ISV-LOC
        ///// </summary>
        ///// <param name="LocationCD">LocationCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistByLocationUnCompleted(string WarehouseCD, string LocationCD)
        //{
        //    return this.ExistBy(d => d.LocationCD.Equals(LocationCD) 
        //                          && d.WarehouseCD.Equals(WarehouseCD)
        //                          && d.DeleteFlag.Equals(false) 
        //                          && d.TakeFlag.Equals(false));
        //}

        #endregion

        #region private

        #endregion
    }
}
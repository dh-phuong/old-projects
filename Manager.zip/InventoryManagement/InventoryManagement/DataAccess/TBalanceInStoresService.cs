﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TInventoryService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TBalanceInStoresService : DataAccess.Abstract.AbstractService<TBalanceInStores>
    {
        #region Get

        public TBalanceInStores GetByConditionsForInboundDelivery(string TagNo, int BranchTagNo)
        {
            return this.Context.GetTable<TBalanceInStores>().Where(m => m.TagNo.Equals(TagNo)
                                                                     && m.BranchTagNo.Equals(BranchTagNo)
                                                                    && (m.BalanceStatus.Equals(Constant.BALANCE_STATUS_ARRIVAL)
                                                                    || m.BalanceStatus.Equals(Constant.BALANCE_STATUS_RETURN_ARRIVAL)
                                                                    || m.BalanceStatus.Equals(Constant.BALANCE_STATUS_MOVES_ARRIVAL))).FirstOrDefault();
        }

        /// <summary>
        /// Get BalanceStatus By Barcode
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <returns>TBalanceInStores</returns>
        public TBalanceInStores GetBalanceStatusByBarcode(string tagNo, int branchTagNo)
        {
            IQueryable<TBalanceInStores> list = from b in this.Context.GetTable<TBalanceInStores>()
                                                where b.TagNo.Equals(tagNo) && b.BranchTagNo.Equals(branchTagNo) && !b.DeleteFlag
                                                orderby b.BalanceNo descending
                                                select b;
            return list.FirstOrDefault();
        }

        /// <summary>
        /// Get Newest data
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <returns>TBalanceInStores</returns>
        public TBalanceInStores GetNewestData(string tagNo, int branchTagNo, List<string> statusList)
        {
            IQueryable<TBalanceInStores> list = from b in this.Context.GetTable<TBalanceInStores>()
                                                where b.TagNo.Equals(tagNo) && b.BranchTagNo.Equals(branchTagNo) && !b.DeleteFlag
                                                    && (statusList == null || statusList.Contains(b.BalanceStatus))
                                                orderby b.BalanceNo descending
                                                select b;
            return list.FirstOrDefault();
        }

        #endregion

        #region Check
        /// <summary>
        /// Check exist DataCD in TBalanceInStores
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInTBalanceInStores(string dataCD)
        {
            return this.ExistBy(k => k.BalanceStatus.Equals(dataCD));
        }
        #endregion

        #region Print --TRUC

        #region Product-Dataset

        /// <summary>
        /// Get List Balance By Product With TagNo
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        public IQueryable<BalanceInStoresProductDetail> GetListBalanceByProductTagNo(string ProductCD, BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();

            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));

            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                             && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                             && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                             && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                             && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                             && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0));

            IQueryable<BalanceInStoresProductDetail> list = from b in balance
                                                            join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                                                            join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD
                                                            join mk in kind on b.BalanceStatus equals mk.DataCD into K
                                                            from k in K.DefaultIfEmpty()
                                                            where string.IsNullOrEmpty(ProductCD) || ih.ProductCD.Equals(ProductCD)
                                                            group new { b, k, ih, p } by new { b.TagNo, b.BalanceStatus, b.BalanceDate, b.LocationCD } into info
                                                            select new BalanceInStoresProductDetail()
                                                            {
                                                                TypeReport = true,
                                                                LocationName = info.Key.LocationCD,
                                                                Quantity = info.Count(ba => ba.b.BranchTagNo != null).ToString(),
                                                                BalanceDate = info.Key.BalanceDate,
                                                                BalanceStatus = info.Key.BalanceStatus,
                                                                BalanceStatusName = info.Min(m => m.k.Value) ?? string.Empty,
                                                                Lot1 = info.Min(m => m.ih.Lot1) ?? string.Empty,
                                                                Lot2 = info.Min(m => m.ih.Lot2) ?? string.Empty,
                                                                Lot3 = info.Min(m => m.ih.Lot3) ?? string.Empty,
                                                                //TagNo = info.Key.TagNo
                                                            };
            return list;
        }

        /// <summary>
        /// Get List Balance By Product With BranchTagNo
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        public IQueryable<BalanceInStoresProductDetail> GetListBalanceByProductBranchTagNo(string ProductCD, BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();

            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));


            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                              && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                              && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                              && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                              && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                              && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0));

            IQueryable<BalanceInStoresProductDetail> list = from b in balance
                                                            join k in kind on b.BalanceStatus equals k.DataCD
                                                            join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                                                            join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD
                                                            //join l in this.Context.MLocation on new { key1 = b.LocationCD, key2 = b.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                                                            // from lo in L.DefaultIfEmpty()
                                                            where string.IsNullOrEmpty(ProductCD) || ih.ProductCD.Equals(ProductCD)
                                                            select new BalanceInStoresProductDetail()
                                                            {
                                                                TypeReport = false,
                                                                LocationName = b.LocationCD ?? string.Empty,
                                                                //BranchTagNo = b.BranchTagNo.ToString() ?? string.Empty,
                                                                BalanceDate = b.BalanceDate ?? string.Empty,
                                                                BalanceStatus = b.BalanceStatus ?? string.Empty,
                                                                BalanceStatusName = k.Value ?? string.Empty,
                                                                Lot1 = ih.Lot1 ?? string.Empty,
                                                                Lot2 = ih.Lot2 ?? string.Empty,
                                                                Lot3 = ih.Lot3 ?? string.Empty,
                                                                //TagNo = ih.TagNo ?? string.Empty,
                                                                TagInfo = b.TagNo + "-" + b.BranchTagNo.ToString().PadLeft(4, '0'),
                                                                BalanceNo = b.BalanceNo
                                                            };
            return list;
        }

        /// <summary>
        /// Get List Balance By Product For Header
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <param name="IsBranchTagNo">Is BranchTagNo</param>
        /// <returns></returns>
        public IQueryable<BalanceInStoresProductHeader> GetListBalanceByProductHeader(BalanceInStoresModels gmModel, bool IsBranchTagNo)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();

            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                              && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                              && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                              && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                              && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                              && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0));

            IQueryable<BalanceInStoresProductHeader> list = from b in balance
                                                            join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                                                            join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD
                                                            where string.IsNullOrEmpty(gmModel.ProductCD) || ih.ProductCD.Equals(gmModel.ProductCD)
                                                            group new { b, ih, p } by new { ih.ProductCD } into g
                                                            select new BalanceInStoresProductHeader()
                                                            {
                                                                TypeReport = IsBranchTagNo ? false : true,
                                                                BalanceDateFrom = gmModel.BalanceDateFrom.DateValue() ?? string.Empty,
                                                                BalanceDateTo = gmModel.BalanceDateTo.DateValue() ?? string.Empty,
                                                                ProductCD = g.Key.ProductCD ?? string.Empty,
                                                                ProductName = g.Min(m => m.p.ProductName) ?? string.Empty
                                                            };
            return list;
        }

        #endregion

        #region Report Excel
        public List<BalanceInStoresProduct> GetListByProductBranchTagNo(BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();
            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            //Get Kind Master
            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));

            //Get TBalanceInStores
            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                             && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                             && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                             && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                             && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                             && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0)
                                                            ).ToList();

            //Get Data
            var result = from b in balance
                         join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                         //join l in this.Context.MLocation on new { key1 = b.LocationCD, key2 = b.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                         //from lo in L.DefaultIfEmpty()
                         join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD into P
                         from po in P.DefaultIfEmpty()
                         join k in kind on b.BalanceStatus equals k.DataCD into K
                         from ko in K.DefaultIfEmpty()
                         where string.IsNullOrEmpty(gmModel.ProductCD) || ih.ProductCD.Equals(gmModel.ProductCD)
                         select new BalanceInStoresProduct
                         {
                             BalanceNo = b.BalanceNo,
                             TypeReport = false,
                             LocationCD = b.LocationCD,
                             // LocationName = lo.LocationName,
                             ProductCD = ih.ProductCD,
                             ProductName = po.ProductName,
                             Lot1 = ih.Lot1,
                             Lot2 = ih.Lot2,//CommonUtil.ParseDate(ih.Lot2, Constant.FMT_YMD, Constant.FMT_DATE),
                             Lot3 = ih.Lot3,//CommonUtil.ParseDate(ih.Lot3, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceDate = b.BalanceDate,//CommonUtil.ParseDate(b.BalanceDate, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceStatus = b.BalanceStatus,
                             BalanceStatusName = ko.Value,
                             TagInfo = b.TagNo + "-" + b.BranchTagNo.ToString().PadLeft(4, '0'),
                             Quantity = "1"
                         };
            return result.ToList();
        }

        public List<BalanceInStoresLocation> GetListByLocationBranchTagNo(BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();
            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            //Get Kind Master
            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));

            //Get TBalanceInStores
            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                             && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                             && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                             && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                             && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                             && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0)
                                                            ).ToList();

            //Get Data
            var result = from b in balance
                         join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                         join l in this.Context.MLocation on new { key1 = b.LocationCD, key2 = b.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                         from lo in L.DefaultIfEmpty()
                         join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD into P
                         from po in P.DefaultIfEmpty()
                         join k in kind on b.BalanceStatus equals k.DataCD into K
                         from ko in K.DefaultIfEmpty()
                         where string.IsNullOrEmpty(gmModel.ProductCD) || ih.ProductCD.Equals(gmModel.ProductCD)
                         select new BalanceInStoresLocation
                         {
                             BalanceNo = b.BalanceNo,
                             TypeReport = false,
                             LocationCD = b.LocationCD ?? string.Empty,
                             LocationName = lo == null ? string.Empty : lo.LocationName,
                             ProductCD = ih.ProductCD ?? string.Empty,
                             ProductName = po.ProductName ?? string.Empty,
                             Lot1 = ih.Lot1 ?? string.Empty,
                             Lot2 = ih.Lot2 ?? string.Empty,//CommonUtil.ParseDate(ih.Lot2, Constant.FMT_YMD, Constant.FMT_DATE),
                             Lot3 = ih.Lot3 ?? string.Empty,//CommonUtil.ParseDate(ih.Lot3, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceDate = b.BalanceDate ?? string.Empty,//CommonUtil.ParseDate(b.BalanceDate, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceStatus = b.BalanceStatus ?? string.Empty,
                             BalanceStatusName = ko.Value ?? string.Empty,
                             TagInfo = b.TagNo + "-" + b.BranchTagNo.ToString().PadLeft(4, '0'),
                             Quantity = "1"
                         };
            return result.ToList();
        }
        #endregion

        #region Location
        /// <summary>
        /// Get List Balance By Location With TagNo
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        public IQueryable<BalanceInStoresLocation> GetListBalanceByLocationTagNo(BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();
            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            //Get Kind Master
            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));

            //Get TBalanceInStores
            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                             && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                             && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                             && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                             && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                             && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0));

            //Get Data
            var result = from b in balance
                         join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                         join l in this.Context.MLocation on new { key1 = b.LocationCD, key2 = b.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                         from lo in L.DefaultIfEmpty()
                         join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD into P
                         from po in P.DefaultIfEmpty()
                         join k in kind on b.BalanceStatus equals k.DataCD into K
                         from ko in K.DefaultIfEmpty()
                         where string.IsNullOrEmpty(gmModel.ProductCD) || ih.ProductCD.Equals(gmModel.ProductCD)
                         group new { b, ih, lo, po, ko } by new { b.TagNo, b.BalanceDate, b.BalanceStatus, b.LocationCD } into grp
                         select new BalanceInStoresLocation
                         {
                             TypeReport = true,
                             LocationCD = grp.Key.LocationCD ?? string.Empty,
                             TagInfo = grp.Key.TagNo == null ? grp.Key.TagNo.ToString() : string.Empty,
                             LocationName = grp.Min(m => m.lo.LocationName) ?? string.Empty,
                             ProductCD = grp.Min(m => m.ih.ProductCD) ?? string.Empty,
                             ProductName = grp.Min(m => m.po.ProductName) ?? string.Empty,
                             Lot1 = grp.Min(m => m.ih.Lot1) ?? string.Empty,
                             Lot2 = grp.Min(m => m.ih.Lot2) ?? string.Empty,
                             Lot3 = grp.Min(m => m.ih.Lot3) ?? string.Empty,
                             BalanceStatus = grp.Key.BalanceStatus ?? string.Empty,
                             BalanceStatusName = grp.Min(m => m.ko.Value) ?? string.Empty,
                             BalanceDate = grp.Key.BalanceDate ?? string.Empty,
                             Quantity = grp.Count().ToString()

                         };

            return result;
        }

        /// <summary>
        /// Get List Balance By Location Branch TagNo
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        public List<BalanceInStoresLocation> GetListBalanceByLocationBranchTagNo(BalanceInStoresModels gmModel)
        {
            string dateFrom = gmModel.BalanceDateFrom.DateValue();
            string dateTo = gmModel.BalanceDateTo.DateValue();
            string locationFrom = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDFrom))
            {
                locationFrom = gmModel.LocationCDFrom.Trim();
            }
            string locationTo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.LocationCDTo))
            {
                locationTo = gmModel.LocationCDTo.Trim();
            }

            //Get Kind Master
            var kind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Constant.MKIND_KINDCD_BALANCE_STATUS) && k.Language.Equals(UserSession.Session.Language));

            //Get TBalanceInStores
            var balance = this.Context.TBalanceInStores.Where(b => !b.DeleteFlag
                                                             && b.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                             && (string.IsNullOrEmpty(dateFrom) || b.BalanceDate.CompareTo(dateFrom) >= 0)
                                                             && (string.IsNullOrEmpty(dateTo) || b.BalanceDate.CompareTo(dateTo) <= 0)
                                                             && (string.IsNullOrEmpty(locationFrom) || b.LocationCD.CompareTo(locationFrom) >= 0)
                                                             && (string.IsNullOrEmpty(locationTo) || b.LocationCD.CompareTo(locationTo) <= 0)).ToList();

            //Get Data
            var result = from b in balance
                         join ih in this.Context.TInventory_H on b.TagNo equals ih.TagNo
                         join l in this.Context.MLocation on new { key1 = b.LocationCD, key2 = b.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                         from lo in L.DefaultIfEmpty()
                         join p in this.Context.MProduct on ih.ProductCD equals p.ProductCD into P
                         from po in P.DefaultIfEmpty()
                         join k in kind on b.BalanceStatus equals k.DataCD into K
                         from ko in K.DefaultIfEmpty()
                         where (string.IsNullOrEmpty(gmModel.ProductCD) || ih.ProductCD.Equals(gmModel.ProductCD))
                         select new BalanceInStoresLocation()
                         {
                             BalanceNo = b.BalanceNo,
                             TypeReport = false,
                             LocationCD = b.LocationCD,
                             LocationName = lo == null ? string.Empty : lo.LocationName,
                             ProductCD = ih.ProductCD,
                             ProductName = po.ProductName,
                             Lot1 = ih.Lot1,
                             Lot2 = ih.Lot2,//CommonUtil.ParseDate(ih.Lot2, Constant.FMT_YMD, Constant.FMT_DATE),
                             Lot3 = ih.Lot3,//CommonUtil.ParseDate(ih.Lot3, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceDate = b.BalanceDate,//CommonUtil.ParseDate(b.BalanceDate, Constant.FMT_YMD, Constant.FMT_DATE),
                             BalanceStatus = b.BalanceStatus,
                             BalanceStatusName = ko.Value,
                             TagInfo = b.TagNo + "-" + b.BranchTagNo.ToString().PadLeft(4, '0'),
                             Quantity = "1"
                         };
            return result.ToList();
        }
        #endregion

        #endregion
    }
}
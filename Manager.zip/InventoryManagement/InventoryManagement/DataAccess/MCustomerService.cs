﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MCustomer Context
    /// Author: ISV-LOC
    /// </summary>
    public class MCustomerService :DataAccess.Abstract.AbstractService<MCustomer>
    {

        #region public method
        
        /// <summary>
        /// Get Customer by Code
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="customerCd">CustomerCd</param>
        /// <returns>CustomerModels</returns>
        public CustomerModels GetByCd(string customerCd)
        {
            customerCd = MCustomer.FixCodeDB(customerCd);
            IQueryable<CustomerModels> item = from c in this.Context.GetTable<MCustomer>()
                                              where c.CustomerCD.Equals(customerCd)
                                              select new CustomerModels
                                              {
                                                  CustomerCD = c.CustomerCD,
                                                  CustomerName = c.CustomerName,
                                                  Address1 = c.Address1,
                                                  Address2 = c.Address2,
                                                  Address3 = c.Address3,
                                                  Email = c.Email,
                                                  Tel = c.Tel,
                                                  Fax = c.Fax,
                                                  UpdateDate = c.UpdateDate,
                                                  DeleteFlag = c.DeleteFlag,
                                                  PreCustomerCD = c.CustomerCD,
                                              };
            return item.SingleOrDefault<CustomerModels>();
        }

        /// <summary>
        /// Get by customer code
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="customerCd">customerCd</param>
        /// <returns>MCustomer</returns>
        public MCustomer GetMCustomerByCd(string customerCd)
        {
            customerCd = MCustomer.FixCodeDB(customerCd);
            IQueryable<MCustomer> item = from c in this.Context.GetTable<MCustomer>()
                                              where c.CustomerCD.Equals(customerCd)
                                              select c;
            return item.SingleOrDefault<MCustomer>();
        }

        /// <summary>
        /// Get List Customer for CSV
        /// Author: ISV-LOC
        /// </summary>
        /// <returns></returns>
        public IQueryable<CustomerListCSV> GetListCustomerCSV()
        {
            IQueryable<CustomerListCSV> list = from c in this.Context.GetTable<Models.MCustomer>()
                                               orderby c.CustomerCD
                                               select new CustomerListCSV
                                               {
                                                    CustomerCD = c.CustomerCD,
                                                    CustomerName = c.CustomerName,
                                                    Address1 = c.Address1,
                                                    Address2 = c.Address2,
                                                    Address3 = c.Address3,
                                                    Email = c.Email,
                                                    Tel = c.Tel,
                                                    Fax = c.Fax,
                                                    DeleteFlag = c.DeleteFlag,
                                                    CreateDate = c.CreateDate,
                                                    CreateUCD = c.CreateUCD,
                                                    UpdateDate = c.UpdateDate,
                                                    UpdateUCD = c.UpdateUCD
                                               };

            return list;
        }

        /// <summary>
        /// get Customer List By Condition
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel">CustomerList</param>
        /// <returns>IQueryable of Customer</returns>
        public IQueryable<CustomerResults> GetListByConditions(CustomerList gmModel)
        {
            string customerCD = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);
            if (string.IsNullOrEmpty(gmModel.txt_CustomerName))
            {
                gmModel.txt_CustomerName = string.Empty;
            }
            IQueryable<CustomerResults> list = from c in this.Context.GetTable<MCustomer>()
                                               where (gmModel.chk_DeleteData == true || c.DeleteFlag.Equals(false))
                                                     && (string.IsNullOrEmpty(customerCD) || c.CustomerCD.StartsWith(customerCD))
                                                     && (string.IsNullOrEmpty(gmModel.txt_CustomerName) || c.CustomerName.ToLower().Contains(gmModel.txt_CustomerName.ToLower()))
                                               orderby c.UpdateDate descending
                                               select new CustomerResults
                                               {
                                                   CustomerCD = c.CustomerCD,
                                                   CustomerName = c.CustomerName,
                                                   Tel = c.Tel,
                                                   DeleteFlag = c.DeleteFlag,
                                                   UpdateDate = c.UpdateDate
                                               };
            return list;
        }

        /// <summary>
        /// get Customer List By Condition for Search
        /// </summary>
        /// <param name="gmModel">CustomerList</param>
        /// <returns>IQueryable of Customer</returns>
        public IQueryable<CustomerSearch> GetListByConditionsForSearch(CustomerSearch gmModel)
        {
            string customerCD = MCustomer.FixCodeDB(gmModel.sCustomerCD);
            if (string.IsNullOrEmpty(gmModel.sCustomerName))
            {
                gmModel.sCustomerName = string.Empty;
            }
            IQueryable<CustomerSearch> list = from c in this.Context.GetTable<MCustomer>()
                                               where (c.DeleteFlag.Equals(false))
                                                     && (string.IsNullOrEmpty(customerCD) || c.CustomerCD.StartsWith(customerCD))
                                                     && (string.IsNullOrEmpty(gmModel.sCustomerName) 
                                                        || c.CustomerName.ToLower().Contains(gmModel.sCustomerName.ToLower()))
                                               select new CustomerSearch
                                               {
                                                   sCustomerCD = c.CustomerCD,
                                                   sCustomerName = c.CustomerName,
                                                   sTel = c.Tel,
                                                   Address1 = c.Address1,
                                                   Address2 = c.Address2,
                                                   Address3 = c.Address3

                                               };
            return list;
        }

        /// <summary>
        /// Check exist customer code
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <param name="includeDelete">Include Delete</param>
        /// <returns></returns>
        public bool ExistCustomerCD(string customerCD, bool includeDelete)
        {
            if (string.IsNullOrEmpty(customerCD))
            {
                return true;
            }

            customerCD = MCustomer.FixCodeDB(customerCD);
            return this.Context.MCustomer.Any(m => m.CustomerCD.Equals(customerCD.ToUpper()) 
                                                && (includeDelete == true || m.DeleteFlag.Equals(false)));
        }

        /// <summary>
        /// Check exist in Shipping Instruction table
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="customerCD">Custoemr CD</param>
        /// <returns>TRUE: Exist, FLASE: not exist</returns>
        public bool IsExistInTShippingInstruction(string customerCD)
        {
            return this.Context.GetTable<TShippingInstruction>().Any(t => t.CustomerCD.Equals(customerCD.ToUpper()));
        }

        /// <summary>
        /// Check exist in User table
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="customerCD">Custoemr CD</param>
        /// <returns>TRUE: Exist, FLASE: not exist</returns>
        public bool IsExistInUser(string customerCD)
        {
            return this.Context.GetTable<MUser>().Any(t => t.CustomerCD.Equals(customerCD.ToUpper()));
        }

       #endregion
    }
}
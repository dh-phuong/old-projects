﻿using System;
using System.Linq;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MProduct Context
    /// Author: ISV - Nho
    /// </summary>
    public class MProductService : DataAccess.Abstract.AbstractService<MProduct>
    {
      
        #region public method

        #region Get

        /// <summary>
        /// Get Product List
        /// </summary>
        /// <param name="gmModel">ProductList</param>
        /// <returns>IQueryable of ProductResult</returns>
        public IQueryable<ProductResult> GetListByConditions(ProductList gmModel)
        {
            decimal CostFrom = string.IsNullOrEmpty(gmModel.txtCostFrom) ? 0 : CommonUtil.ParseDecimal(gmModel.txtCostFrom);
            decimal CostTo = string.IsNullOrEmpty(gmModel.txtCostTo) ? 0 : CommonUtil.ParseDecimal(gmModel.txtCostTo);
            if (string.IsNullOrEmpty(gmModel.txtProductName)) {
                gmModel.txtProductName = string.Empty;
            }

            IQueryable<ProductResult> list = from p in this.Context.GetTable<MProduct>()
                                             join c in this.Context.MCategory on p.CategoryCD equals c.CategoryCD into Catagory
                                             from CA in Catagory.DefaultIfEmpty()

                                             where (gmModel.IncludeDeleteData || !p.DeleteFlag )
                                                   && (string.IsNullOrEmpty(gmModel.txtProductCD) || p.ProductCD.Trim().StartsWith(gmModel.txtProductCD))
                                                   && (string.IsNullOrEmpty(gmModel.txtProductName) || p.ProductName.ToUpper().Contains(gmModel.txtProductName.ToUpper()))
                                                   && (string.IsNullOrEmpty(gmModel.txtCategoryCD) || p.CategoryCD.StartsWith(gmModel.txtCategoryCD))
                                                   && (string.IsNullOrEmpty(gmModel.txtCostFrom) || p.Cost >= CostFrom)
                                                   && (string.IsNullOrEmpty(gmModel.txtCostTo) || p.Cost <= CostTo)
                                             select new ProductResult
                                             {
                                                 ProductCD = p.ProductCD.Trim(),
                                                 ProductName = p.ProductName,
                                                 CategoryNm = CA.CategoryName,
                                                 QuantityPerUnit = p.QuantityPerUnit,
                                                 Cost = p.Cost,
                                                 TotalCost = p.Cost * p.QuantityPerUnit,
                                                 DeleteData = p.DeleteFlag,
                                                 UpdateDate = p.UpdateDate
                                             };

            return list;
        }

        /// <summary>
        /// Get Data CSV
        /// </summary>
        /// <returns>ProductListCsv</returns>
        public IQueryable<ProductListCsv> GetListCSV()
        {
            IQueryable<ProductListCsv> list = from p in this.Context.GetTable<Models.MProduct>()
                                              orderby p.ProductCD
                                              select new ProductListCsv
                                              {
                                                  ProductCD = p.ProductCD.Trim(),
                                                  ProductName = p.ProductName,
                                                  CategoryCD = p.CategoryCD,
                                                  Cost = p.Cost,
                                                  QuantityPerUnit = p.QuantityPerUnit,
                                                  DeleteFlag = p.DeleteFlag,
                                                  CreateDate = p.CreateDate,
                                                  CreateUCD = p.CreateUCD,
                                                  UpdateDate = p.UpdateDate,
                                                  UpdateUCD = p.UpdateUCD
                                              };

            return list;
                   

        }

        /// <summary>
        /// Get Product by Cd
        /// </summary>
        /// <param name="productCd">Cd</param>
        /// <returns>ProductModels</returns>
        public ProductModels GetByCd(string productCD)
        {

            IQueryable<ProductModels> item = from p in Context.GetTable<MProduct>()
                                             join c in this.Context.MCategory on p.CategoryCD equals c.CategoryCD into Catagory
                                             from CA in Catagory.DefaultIfEmpty()
                                             where p.ProductCD.Trim().Equals(productCD.ToUpper())
                                             select new ProductModels
                                              {
                                                  ProductCD = p.ProductCD.Trim(),
                                                  ProductName = p.ProductName,
                                                  CategoryCD = p.CategoryCD,
                                                  CategoryNm = CA.CategoryName,
                                                  QuantityPerUnit = String.Format(Common.Constant.FMT_DECIMAL_FULL, p.QuantityPerUnit),
                                                  Cost = String.Format(Common.Constant.FMT_DECIMAL_FULL, p.Cost),
                                                  TotalCost = String.Format(Common.Constant.FMT_DECIMAL_FULL, p.Cost * p.QuantityPerUnit),
                                                  UpdateDate = p.UpdateDate,
                                                  DeleteFlag = p.DeleteFlag,
                                                  PreProductCD = p.ProductCD.Trim()
                                              };
            return item.SingleOrDefault<ProductModels>();
        }

        /// <summary>
        /// Get Product by Cd and Update Date
        /// </summary>
        /// <param name="productCd">Cd</param>
        /// <param name="updateDate">Update Date</param>
        /// <returns>MProduct</returns>
        public IQueryable<MProduct> GetByCdAndUpDate(string productCD, string updateDate)
        {

            return from p in this.Context.MProduct
                   where (p.ProductCD.Trim().Equals(productCD) && p.UpdateDate.Equals(updateDate))
                                            select p;
        }

        /// <summary>
        /// Get Data For Search
        /// </summary>
        /// <param name="gmModel">ProductSearch</param>
        /// <returns></returns>
        public IQueryable<ProductSearch> GetListByConditionsForSearch(ProductSearch gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sProductName))
            {
                gmModel.sProductName = string.Empty;
            }
            IQueryable<ProductSearch> list = from p in this.Context.MProduct                                             
                                             join c in this.Context.MCategory on p.CategoryCD equals  c.CategoryCD into Catagory
                                             from co in Catagory.DefaultIfEmpty()
                                             where (!p.DeleteFlag)
                                                   && !co.DeleteFlag
                                                   && (string.IsNullOrEmpty(gmModel.sProductCD) || p.ProductCD.Trim().StartsWith(gmModel.sProductCD))
                                                   && (string.IsNullOrEmpty(gmModel.sProductName) || p.ProductName.ToLower().Contains(gmModel.sProductName.ToLower()))
                                                   && (string.IsNullOrEmpty(gmModel.sCategoryCD) || p.CategoryCD.StartsWith(gmModel.sCategoryCD))                                                                                                
                                             select new ProductSearch
                                             {
                                                 sProductCD = p.ProductCD.Trim(),
                                                 sProductName = p.ProductName,
                                                 sCategoryCD = p.CategoryCD,
                                                 CategoryNm = co.CategoryName,
                                                 sTotal = p.Cost * p.QuantityPerUnit,                                                 
                                             };

            return list;
        }

        /// <summary>
        /// Get Data For Search
        /// </summary>
        /// <param name="gmModel">ProductSearch</param>
        /// <returns></returns>
        public IQueryable<ProductSearch> GetListByConditionsForSearchStockOnly(ProductSearch gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sProductName))
            {
                gmModel.sProductName = string.Empty;
            }

            var list = from p in this.Context.MProduct
                       join c in this.Context.MCategory on p.CategoryCD equals c.CategoryCD
                       where (!p.DeleteFlag)
                           && (string.IsNullOrEmpty(gmModel.sProductCD) || p.ProductCD.StartsWith(gmModel.sProductCD))
                           && (string.IsNullOrEmpty(gmModel.sProductName) || p.ProductName.ToLower().Contains(gmModel.sProductName.ToLower()))
                           && (string.IsNullOrEmpty(gmModel.sCategoryCD) || p.CategoryCD.StartsWith(gmModel.sCategoryCD))
                       select new ProductSearch
                       {
                           sProductCD = p.ProductCD,
                           sProductName = p.ProductName,
                           sCategoryCD = p.CategoryCD,
                           CategoryNm = c.CategoryName,
                           sTotal = p.Cost * p.QuantityPerUnit,   
                       };

            var stocklist = from ih in this.Context.TInventory_H
                            join id in this.Context.TInventory_D on new { key1 = ih.TagNo, key2 = ih.WarehouseCD }  equals new { key1 = id.TagNo, key2 = UserSession.Session.LoginInfo.WarehouseCD }
                            join l in this.Context.MLocation on new { key1 = ih.WarehouseCD, key2 = id.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                            where (!ih.DeleteFlag) 
                                && !l.IssueProhibitionFlag
                                && (string.IsNullOrEmpty(gmModel.sProductCD) || ih.ProductCD.StartsWith(gmModel.sProductCD))
                                && (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                //&& (string.IsNullOrEmpty(gmModel.sLocationCDTo) || !id.LocationCD.Equals(gmModel.sLocationCDTo))
                                && (id.ShippingNo == null)
                            select new
                            {
                                ProductCD = ih.ProductCD,
                                TagNo = ih.TagNo,
                                LocationCD = id.LocationCD
                            };

            var relist = from ih in this.Context.TInventory_H
                         join re in this.Context.TReserve on new { key1 = ih.WarehouseCD, key2 = ih.TagNo } equals new { key1 = UserSession.Session.LoginInfo.WarehouseCD, key2 = re.TagNo }
                         where (!ih.DeleteFlag) 
                            && (string.IsNullOrEmpty(gmModel.sProductCD) || ih.ProductCD.StartsWith(gmModel.sProductCD))
                            //&& (string.IsNullOrEmpty(gmModel.sLocationCDTo) || !re.LocationCD.Equals(gmModel.sLocationCDTo))
                            && stocklist.Any(m => m.LocationCD.Equals(re.LocationCD))
                         select new
                         {
                             ProductCD = ih.ProductCD,
                             TagNo = ih.TagNo,
                             ShipNo = re.ShipNo,
                             Quantity = re.Quantity,
                             RemainQuantity = re.RemainQuantity
                         };

            var result = from p in list
                         where (stocklist.Where(m => p.sProductCD.Equals(m.ProductCD)).Count() - Context.IsNullInt(relist.Where(m => p.sProductCD.Equals(m.ProductCD)).Sum(t => t.RemainQuantity), 0)
                                + (string.IsNullOrEmpty(gmModel.sShipNo) ? 0 : Context.IsNullInt(relist.Where(m => p.sProductCD.Equals(m.ProductCD) && (m.ShipNo.Equals(gmModel.sShipNo))).Sum(x => x.Quantity), 0)) > 0)
                         select new ProductSearch
                         {
                             sProductCD = p.sProductCD,
                             sProductName = p.sProductName,
                             sCategoryCD = p.sCategoryCD,
                             CategoryNm = p.CategoryNm,
                             sTotal = p.sTotal,
                         };
            
            return result;
        }



        #endregion

        #region Check

        /// <summary>
        /// Check Exists ProductCD
        /// </summary>
        /// <param name="productCD">ProductCD</param>
        /// <returns></returns>
        public bool IsExistsProductCD(String productCD)
        {
            bool ret = this.Context.GetTable<MProduct>().Any(p => p.ProductCD.Trim().Equals(productCD));

            return ret;

        }

        /// <summary>
        /// Check Exists ProductCD
        /// </summary>
        /// <param name="productCD">ProductCD</param>
        /// <returns></returns>
        public bool IsExistsProduct(String productCD)
        {
            bool ret = this.Context.GetTable<MProduct>().Any(p => p.ProductCD.Trim().Equals(productCD) && !p.DeleteFlag);

            return ret;

        }

        /// <summary>
        /// check Exists ProductCd in Orther table
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <returns></returns>
        public bool IsExistsInOrtherTable(String ProductCD) {
            return this.Context.GetTable<TInventory_H>().Any(model => model.ProductCD.Trim().Equals(ProductCD));
        }

        /// <summary>
        /// Check Exists product Name
        /// </summary>
        /// <param name="productName">productName</param>
        /// <returns></returns>
        public bool IsExistsProductName(String productName)
        {
            if (string.IsNullOrEmpty(productName))
            {
                productName = string.Empty;
            }
            bool ret = this.Context.GetTable<MProduct>().Any(p => p.ProductName.ToUpper().Contains(productName.ToUpper()));

            return ret;
        }

        /// <summary>
        /// Check data changed
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        public bool CheckDataChanged(ProductModels gmModel)
        {
            return !Context.GetTable<MProduct>().Any(p => p.ProductCD.Trim().Equals(gmModel.PreProductCD)
                                               && p.UpdateDate.Equals(gmModel.UpdateDate));
        }

        /// <summary>
        /// Check exist DataCD in MProduct
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMProduct(string dataCD)
        {
            return this.ExistBy(k => k.CategoryCD.Equals(dataCD));
            //return this.Context.GetTable<MProduct>().Any(k => k.CategoryCD.Equals(dataCD));
        }

        /// <summary>
        /// Check Category is exist in Product table
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsCategoryExist(string CategoryCD)
        {
            return this.ExistBy(u => u.CategoryCD.Equals(CategoryCD));
        }

        #endregion

        #endregion
    }
}
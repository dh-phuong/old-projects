﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MShelf Context
    /// Author: ISV-PHUONG
    /// </summary>
    public class MLocationService : DataAccess.Abstract.AbstractService<Models.MLocation>
    {

        /// <summary>
        /// Get By Primary Key
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>MLocation</returns>
        public MLocation GetByPK(string WarehouseCD, string LocationCD)
        {
            LocationCD = MLocation.FixCodeDB(LocationCD);
            IQueryable<MLocation> items = from loc in this.Context.MLocation
                                          where loc.WarehouseCD.Equals(WarehouseCD)
                                            && loc.LocationCD.Equals(LocationCD)
                                            && !loc.DeleteFlag
                                          select loc;
            return items.SingleOrDefault();
        }

        /// <summary>
        /// Get data checked changed
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <param name="UpdateDate">UpdateDate</param>
        /// <returns></returns>
        public MLocation GetDataChanged(string WarehouseCD, string LocationCD, string UpdateDate)
        {
            LocationCD = MLocation.FixCodeDB(LocationCD);
            return this.GetBy(c =>
                                    c.WarehouseCD.Equals(WarehouseCD) &&
                                    c.LocationCD.Equals(LocationCD) &&
                                    c.UpdateDate.Equals(UpdateDate)
                              ).SingleOrDefault();
        }

        /// <summary>
        /// Get Location by Cd
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <param name="locationCD">locationCD</param>
        /// <returns>LocationModels</returns>
        public LocationModels GetByCd(string warehouseCD, string locationCD)
        {
            locationCD = MLocation.FixCodeDB(locationCD);
            IQueryable<LocationModels> item = from c in this.Context.GetTable<Models.MLocation>()
                                              join w in this.Context.GetTable<MWarehouse>() on c.WarehouseCD equals w.WarehouseCD into wh
                                              where c.WarehouseCD.Equals(warehouseCD) && c.LocationCD.Equals(locationCD)
                                              select new LocationModels
                                              {
                                                  WarehouseCD = c.WarehouseCD.Trim(),
                                                  LocationCD = c.LocationCD.Trim(),
                                                  LocationName = c.LocationName,
                                                  ReceiptProhibitionFlag = c.ReceiptProhibitionFlag,
                                                  IssueProhibitionFlag = c.IssueProhibitionFlag,
                                                  UpdateDate = c.UpdateDate,
                                                  DeleteFlag = c.DeleteFlag
                                              };
            return item.SingleOrDefault<LocationModels>();
        }


        /// <summary>
        /// Get List Location by Conditions
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <param name="locationCDFrom">locationCDFrom</param>
        /// <param name="locationCDTo">locationCDTo</param>
        /// <returns>List LocationModels</returns>
        public IQueryable<LocationModels> GetListByListLocationCD(string warehouseCD, List<string> listlocationCD)
        {
            IQueryable<LocationModels> items = from c in this.Context.GetTable<Models.MLocation>()
                                              join w in this.Context.GetTable<MWarehouse>() on c.WarehouseCD equals w.WarehouseCD into wh
                                              where c.WarehouseCD.Equals(warehouseCD)
                                              && (listlocationCD.Contains(c.LocationCD))
                                              && !c.DeleteFlag
                                              select new LocationModels
                                              {
                                                  WarehouseCD = c.WarehouseCD.Trim(),
                                                  LocationCD = c.LocationCD.Trim(),
                                                  LocationName = c.LocationName,
                                                  ReceiptProhibitionFlag = c.ReceiptProhibitionFlag,
                                                  IssueProhibitionFlag = c.IssueProhibitionFlag,
                                                  UpdateDate = c.UpdateDate,
                                                  DeleteFlag = c.DeleteFlag
                                              };
            return items;
        }


        /// <summary>
        /// get list by condition
        /// </summary>
        /// <param name="gmModel">LocationList</param>
        /// <returns>IQueryable of location</returns>
        public IQueryable<LocationResults> GetListByConditions(LocationList gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_LocationCD))
            {
                gmModel.txt_LocationCD = string.Empty;
            }
            gmModel.txt_LocationCD = MLocation.FixCodeDB(gmModel.txt_LocationCD);

            if (string.IsNullOrEmpty(gmModel.txt_LocationName))
            {
                gmModel.txt_LocationName = string.Empty;
            }
           

            IQueryable<LocationResults> list = from c in this.Context.GetTable<MLocation>()
                                               where (gmModel.chk_DeleteData || !c.DeleteFlag)
                                                     && (c.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                                                     && (string.IsNullOrEmpty(gmModel.txt_LocationCD) || c.LocationCD.StartsWith(gmModel.txt_LocationCD))
                                                     && (string.IsNullOrEmpty(gmModel.txt_LocationName) || c.LocationName.ToLower().Contains(gmModel.txt_LocationName.ToLower()))
                                               select new LocationResults
                                                {
                                                    LocationCD = c.LocationCD,
                                                    LocationName = c.LocationName,
                                                    ReceiptProhibitionFlag = c.ReceiptProhibitionFlag,
                                                    IssueProhibitionFlag = c.IssueProhibitionFlag,
                                                    DeleteFlag = c.DeleteFlag,
                                                    UpdateDate = c.UpdateDate
                                                };
            return list;
        }

        /// <summary>
        /// get list by condition (search)
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">LocationSearch</param>
        /// <returns>IQueryable of LocationSearch</returns>
        public IQueryable<Models.LocationSearch> GetListByConditionsForSearch(Models.LocationSearch gmModel)
        {
            string receiptOnlyFlag = string.Empty;
            string issueOnlyFlag = string.Empty;

            if (string.IsNullOrEmpty(gmModel.sLocationName))
            {
                gmModel.sLocationName = string.Empty;
            }
            if (!string.IsNullOrEmpty(gmModel.sReceiptOnlyFlag) && gmModel.sReceiptOnlyFlag.Equals(Common.Constant.MLOCATION_RECEIPT_ONLY_FLAG))
            {
                receiptOnlyFlag = Common.Constant.MLOCATION_RECEIPT_ONLY_FLAG;
            }
            if (!string.IsNullOrEmpty(gmModel.sIssueOnlyFlag) && gmModel.sIssueOnlyFlag.Equals(Common.Constant.MLOCATION_ISSUE_ONLY_FLAG))
            {
                issueOnlyFlag = Common.Constant.MLOCATION_ISSUE_ONLY_FLAG;
            }
            gmModel.sLocationCD = MLocation.FixCodeDB(gmModel.sLocationCD);

            IQueryable<LocationSearch> list = from k in this.Context.GetTable<MLocation>()
                                              where (!k.DeleteFlag)
                                                 && (string.IsNullOrEmpty(receiptOnlyFlag) || !k.ReceiptProhibitionFlag.Equals(receiptOnlyFlag))
                                                 && (string.IsNullOrEmpty(issueOnlyFlag) || !k.IssueProhibitionFlag.Equals(issueOnlyFlag))
                                                 && (k.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                                                 && (string.IsNullOrEmpty(gmModel.sLocationCD) || k.LocationCD.StartsWith(gmModel.sLocationCD))
                                                 && (string.IsNullOrEmpty(gmModel.sLocationName) || k.LocationName.ToLower().Contains(gmModel.sLocationName.ToLower()))
                                              select new LocationSearch
                                           {
                                               sLocationCD = k.LocationCD,
                                               sLocationName = k.LocationName,
                                               sUpdateDate = k.UpdateDate
                                           };
            return list;
        }

        /// <summary>
        /// Get list for CSV output
        /// </summary>
        /// <returns></returns>
        public IQueryable<LocationCSV> GetListCSV()
        {
            IQueryable<LocationCSV> list = from location in this.Context.GetTable<Models.MLocation>()
                                           orderby location.LocationCD
                                           where
                                                (location.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                                           select new LocationCSV
                                           {
                                               WarehouseCD = location.WarehouseCD.Trim(),
                                               LocationCD = location.LocationCD,
                                               LocationName = location.LocationName,
                                               CreateDate = location.CreateDate,
                                               CreateUCD = location.CreateUCD,
                                               UpdateDate = location.UpdateDate,
                                               UpdateUCD = location.UpdateUCD,
                                               DeleteFlag = location.DeleteFlag
                                           };

            return list;
        }

        /// <summary>
        /// Count item by warehouse
        /// </summary>
        /// <returns></returns>
        public int CountByWarehouseCD()
        {
            return this.CountBy(m => m.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD));
        }

        /// <summary>
        /// Exist by Key
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool Exist(string WarehouseCD, string LocationCD)
        {
            LocationCD = MLocation.FixCodeDB(LocationCD);
            return this.ExistBy(m => m.WarehouseCD.Equals(WarehouseCD) && m.LocationCD.Equals(LocationCD) && !m.DeleteFlag);
        }

        /// <summary>
        /// Exist by Key
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool ExistNotDelete(string WarehouseCD, string LocationCD)
        {
            LocationCD = MLocation.FixCodeDB(LocationCD);
            return this.ExistBy(m => m.WarehouseCD.Equals(WarehouseCD) && m.LocationCD.Equals(LocationCD));
        }
        
        /// <summary>
        /// Check Warehouse is exist in Location table
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsWarehouseExist(string WarehouseCD)
        {
            return this.ExistBy(u => u.WarehouseCD.Equals(WarehouseCD) && !u.DeleteFlag);
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Linq.Expressions;

namespace InventoryManagement.DataAccess.Abstract
{
    /// <summary>
    /// Abstract Service
    /// Author: ISV-Loc
    /// </summary>
    /// <typeparam name="TEntity">TEntity</typeparam>
    public abstract class AbstractService<TEntity>
    {
        #region Common

        /// <summary>
        /// Context to access database
        /// </summary>
        public Models.DataClasses1DataContext Context { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public AbstractService()
        {
            this.Context = DbServices.CreateContext();
        }


        /// <summary>
        /// Reset Context
        /// </summary>
        public void ResetContext()
        {
            this.Context = DbServices.CreateContext();
        }

        #endregion

        #region GET

        /// <summary>
        /// Get all
        /// Author : ISV-PHUONG
        /// </summary>
        /// <param name="query">Lamda expression</param>
        /// <returns></returns>
        public IQueryable<TEntity> Get()
        {
            return this.Context.GetTable(typeof(TEntity)).Cast<TEntity>();
        }

        /// <summary>
        /// Get By Conditons
        /// Author : ISV-PHUONG
        /// </summary>
        /// <param name="query">Lamda expression</param>
        /// <returns></returns>
        protected IQueryable<TEntity> GetBy(Expression<Func<TEntity, bool>> query)
        {
            return this.Get().Where(query);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert Single
        /// </summary>
        /// <param name="Entity"></param>
        public void Insert(TEntity Entity)
        {
            this.Context.GetTable(typeof(TEntity)).InsertOnSubmit(Entity);
        }

        /// <summary>
        /// Insert List
        /// </summary>
        /// <param name="Entites"></param>
        public void Insert(List<TEntity> Entites)
        {
            this.Context.GetTable(typeof(TEntity)).InsertAllOnSubmit(Entites);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete List
        /// </summary>
        /// <param name="Entites"></param>
        public void Delete(List<TEntity> Entites)
        {
            this.Context.GetTable(typeof(TEntity)).DeleteAllOnSubmit(Entites);
        }

        /// <summary>
        /// Delete Single
        /// </summary>
        /// <param name="Entity"></param>
        public void Delete(TEntity Entity)
        {
            this.Context.GetTable(typeof(TEntity)).DeleteOnSubmit(Entity);
        }

        #endregion

        #region Exist

        /// <summary>
        /// check exist by conditons
        /// Author : ISV-PHUONG
        /// </summary>
        /// <param name="query">Lamda expression</param>
        /// <returns></returns>
        protected bool ExistBy(Expression<Func<TEntity, bool>> query)
        {
            return this.Context.GetTable(typeof(TEntity)).Cast<TEntity>().Any(query);

        }

        #endregion

        #region Count

        /// <summary>
        /// Count By Conditons
        /// Author : ISV-PHUONG
        /// </summary>
        /// <param name="query">Lamda expression</param>
        /// <returns></returns>
        protected int CountBy(Expression<Func<TEntity, bool>> query)
        {
            return this.Context.GetTable(typeof(TEntity)).Cast<TEntity>().Where(query).Count();
        }

        /// <summary>
        /// Item Count
        /// Author : ISV-PHUONG
        /// </summary>
        public int Count
        {
            get
            {
                return this.Context.GetTable(typeof(TEntity)).Cast<TEntity>().Count();
            }
        }

        #endregion
    }
}
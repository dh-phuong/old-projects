﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TStockAllowance Context
    /// Author: ISV-LOC
    /// </summary>
    public class TStockAllowanceService : DataAccess.Abstract.AbstractService<TStockAllowance>
    {
        #region public method

        #region Get

        ///// <summary>
        ///// Get List By CustomerCd
        ///// </summary>
        ///// <param name="customerCd">Cd</param>
        ///// <returns>IOrderedQueryable<TStockAllowance></returns>
        //public IOrderedQueryable<TStockAllowance> GetListByCustomerCd(string customerCd)
        //{
        //    customerCd = MCustomer.FixCodeDB(customerCd);
        //    IOrderedQueryable<TStockAllowance> list = this.Context.TStockAllowance.Where(m => m.CustomerCD.Equals(customerCd)).OrderBy(m => m.ProvisionOrder);

        //    return list;
        //}
       
        /// <summary>
        /// Get List By CustomerCd
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="customerCd">customerCd</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public List<TStockAllowance> GetListByCustomerCd(string customerCd)
        {
            customerCd = MCustomer.FixCodeDB(customerCd);
            List<TStockAllowance> list = this.Context.TStockAllowance.Where(m => m.CustomerCD.Equals(customerCd)).OrderBy(m => m.ProvisionOrder).ToList();

            return list;
        }
        
        #endregion

        #region Check

        /// <summary>
        /// Check exist DataCD in TStockAllowance
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInTStockAllowance(string dataCD)
        {
            return this.ExistBy(k => k.DataCD.Equals(dataCD));
            //return this.Context.GetTable<TStockAllowance>().Any(k => k.DataCD.Equals(dataCD));
        }

        #endregion

        #endregion

        #region private method

        #endregion

       
        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MCompany Service
    /// Author : ISV-TRUC
    /// </summary>
    public class MCompanyService : DataAccess.Abstract.AbstractService<MCompany>
    {
        #region GET DATA
       
        /// <summary>
        /// Get By Cd
        /// </summary>
        /// <param name="companyCD">companyCD</param>
        /// <returns>CompanyModels</returns>
        public CompanyModels GetCompany()
        {
            IQueryable<CompanyModels> item = from c in this.Context.GetTable<MCompany>()
                                             select new CompanyModels
                                             {
                                                 CompanyCD = c.CompanyCD,
                                                 CompanyName1 = c.CompanyName1,
                                                 CompanyName2 = c.CompanyName2,
                                                 Address1 = c.Address1,
                                                 Address2 = c.Address2,
                                                 Address3 = c.Address3,
                                                 Tel = c.Tel,
                                                 Fax = c.Fax,
                                                 Email = c.Email,
                                                 UpdateDate = c.UpdateDate,
                                                 DeleteFlag = c.DeleteFlag
                                             };
            return item.SingleOrDefault();
        }

        /// <summary>
        /// Get Data For CSV
        /// </summary>
        /// <returns>IQueryable of CompanyListCSV</returns>
        public IQueryable<CompanyListCSV> GetListCSV()
        {
            IQueryable<CompanyListCSV> list = from w in this.Context.GetTable<MCompany>()
                                              orderby w.CompanyCD
                                              select new CompanyListCSV
                                             {
                                                 CompanyCD = w.CompanyCD,
                                                 CompanyName1 = w.CompanyName1,
                                                 CompanyName2 = w.CompanyName2,
                                                 Address1 = w.Address1,
                                                 Address2 = w.Address2,
                                                 Address3 = w.Address3,
                                                 Tel = w.Tel,
                                                 Fax = w.Fax,
                                                 Email = w.Email,
                                                 CreateDate = w.CreateDate,
                                                 CreateUCD = w.CreateUCD,
                                                 UpdateDate = w.UpdateDate,
                                                 UpdateUCD = w.UpdateUCD,
                                                 DeleteFlag = w.DeleteFlag
                                             };

            return list;
        }

        /// <summary>
        /// Get a company
        /// Author: ISV-TRAM
        /// </summary>
        /// <returns>MCompany</returns>
        public MCompany GetMCompany()
        {
            IQueryable<MCompany> item = from c in this.Context.MCompany
                                        select c;
            return item.FirstOrDefault();
        }
        #endregion

        #region CHECK
       
        /// <summary>
        /// IsExistsCompanyCD
        /// </summary>
        /// <param name="companyCD">companyCD</param>
        /// <param name="deleteData">deleteData</param>
        /// <returns>True:exists, False:not exists</returns>
        public bool IsExistsCompanyCD(string companyCD, bool deleteData)
        {
            if (deleteData)
            {
                return this.Context.MCompany.Any(d => d.CompanyCD.Equals(companyCD));
            }
            else
            {
                return this.Context.MCompany.Any(d => d.CompanyCD.Equals(companyCD) && !d.DeleteFlag);
            }

        }

        #endregion

    }
}
﻿using System.Linq;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Interface of MWarehouse
    /// Author : ISV-TRUC
    /// </summary>

    public class MWarehouseService : DataAccess.Abstract.AbstractService<MWarehouse>
    {
        #region GET DATA

        /// <summary>
        /// Get Warehouse List By Condition
        /// </summary>
        /// <param name="gmModel">WarehouseList</param>
        /// <returns>IQueryable of Warehouse</returns>
        public IQueryable<WarehouseResults> GetListByConditions(WarehouseList gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_WarehouseName))
            {
                gmModel.txt_WarehouseName = string.Empty;
            }

            IQueryable<WarehouseResults> list = from r in this.Context.GetTable<MWarehouse>()
                    where (gmModel.chk_IncludeDeleteData || !r.DeleteFlag)
                           && (string.IsNullOrEmpty(gmModel.txt_WarehouseCD) || r.WarehouseCD.StartsWith(gmModel.txt_WarehouseCD))
                           && (string.IsNullOrEmpty(gmModel.txt_WarehouseName) || r.WarehouseName.ToUpper().Contains(gmModel.txt_WarehouseName.ToUpper()))                           
                   select new WarehouseResults
                   {
                       WarehouseCD = r.WarehouseCD.Substring(r.WarehouseCD.Length - Common.Constant.MWAREHOUSE_WAREHOUSECD_SHOW),
                       WarehouseName = r.WarehouseName,
                       DeleteFlag = r.DeleteFlag,
                       UpdateDate = r.UpdateDate,
                   };

           
            return list;
        }

        /// <summary>
        /// Get Warehouse List
        /// </summary>
        /// <param name="gmModel">WarehouseSearch</param>
        /// <returns>IQueryable of WarehouseSearch</returns>
        public IQueryable<WarehouseSearch> GetListByConditionsForSearch(WarehouseSearch gmModel)
        {
            string warehouseCD = string.Empty;
            if(string.IsNullOrEmpty(gmModel.sWarehouseName))
            {
                gmModel.sWarehouseName=string.Empty;
            }
            IQueryable<WarehouseSearch> list = from k in this.Context.GetTable<MWarehouse>()
                                          where (!k.DeleteFlag)
                                                && (string.IsNullOrEmpty(gmModel.sWarehouseCD) || k.WarehouseCD.StartsWith(gmModel.sWarehouseCD))
                                                && (string.IsNullOrEmpty(gmModel.sWarehouseName) || k.WarehouseName.ToUpper().Contains(gmModel.sWarehouseName.ToUpper()))
                                                
                                               select new WarehouseSearch
                                              {
                                                  sWarehouseCD = k.WarehouseCD.Substring(k.WarehouseCD.Length - Common.Constant.MWAREHOUSE_WAREHOUSECD_SHOW),
                                                  sWarehouseName=k.WarehouseName,
                                                  sUpdateDate=k.UpdateDate
                                              };
            return list;
        }

        /// <summary>
        /// Get By Cd
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <returns>WarehouseModels</returns>
        public WarehouseModels GetByCd(string warehouseCD)
        {
            IQueryable<WarehouseModels> item = from c in this.Context.GetTable<MWarehouse>()
                                              where c.WarehouseCD.Equals(warehouseCD)
                                               select new WarehouseModels
                                              {
                                                  WarehouseCD = c.WarehouseCD,
                                                  WarehouseName = c.WarehouseName,
                                                                                               
                                                  UpdateDate = c.UpdateDate,
                                                  DeleteFlag = c.DeleteFlag
                                              };
            return item.SingleOrDefault<WarehouseModels>();
        }

        /// <summary>
        /// Get Data For CSV
        /// </summary>
        /// <returns></returns>
        public IQueryable<WarehouseCSV> GetListCSV()
        {
            IQueryable<WarehouseCSV> list = from w in this.Context.GetTable<MWarehouse>()
                                           orderby w.WarehouseCD
                                           select new WarehouseCSV
                                           {
                                               WarehouseCD = w.WarehouseCD.Trim(),
                                            WarehouseName = w.WarehouseName,
                                            CreateDate = w.CreateDate,
                                            CreateUID = w.CreateUCD,
                                            UpdateDate = w.UpdateDate,
                                            UpdateUCD = w.UpdateUCD,
                                            DeleteFlag = w.DeleteFlag
                                           };

            return list;
        }
        
        /// <summary>
        /// Get entity MWarehouse by code
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <returns>MWarehouse</returns>
        public MWarehouse GetMWarehouseByCd(string warehouseCD)
        {

            IQueryable<MWarehouse> item = from c in this.Context.GetTable<MWarehouse>()
                                          where c.WarehouseCD.Equals(warehouseCD)
                                          select c;
            return item.SingleOrDefault<MWarehouse>();
        }

        /// <summary>
        /// Get list
        /// Author: ISV-Vinh
        /// </summary>
        /// <returns>IQueryable of MWarehouse</returns>
        public IQueryable<WarehouseDropDown> GetList()
        {
            IQueryable<WarehouseDropDown> ret = from w in this.Context.MWarehouse
                                                where w.DeleteFlag.Equals(false)
                                                orderby w.WarehouseCD
                                                select new WarehouseDropDown {
                                                    WarehouseCD = w.WarehouseCD.Trim(),
                                                    WarehouseName = w.WarehouseCD.Trim() + Common.Constant.SYB_COLON + w.WarehouseName
                                                  };
            return ret;
        }

        #endregion

        #region CHECK
        /// <summary>
        /// Check Exists
        /// Author:ISV-PHUONG
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <returns>True: Exist False:Not Exist</returns>
        public bool Exist(string warehouseCD)
        {

            if (string.IsNullOrEmpty(warehouseCD))
            {
                return false;
            }

            return this.Context.MWarehouse.Any(m => m.WarehouseCD.Equals(warehouseCD) && !m.DeleteFlag);
        }

        /// <summary>
        /// isExistsWarehouseCD
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <param name="deleteData">deleteData</param>
        /// <returns>True:exists, False:not exists</returns>
        public bool IsExistsWarehouseCD(string warehouseCD, bool deleteData)
        {
            if (deleteData)
            {
                return this.Context.MWarehouse.Any(d => d.WarehouseCD.Equals(warehouseCD));
            }
            else
            {
                return this.Context.MWarehouse.Any(d => d.WarehouseCD.Equals(warehouseCD) && !d.DeleteFlag);
            }
            
        }
        
        /// <summary>
        /// Check warehouseCD exists in Shelf
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <returns>True:exists, False:not exists</returns>
        public bool IsExistsShelf(string warehouseCD)
        {         
            var result = this.Context.GetTable<MLocation>().Any(model => model.WarehouseCD.Trim().Equals(warehouseCD) && model.DeleteFlag == false);
            return result;
        }

        #endregion
    }
}
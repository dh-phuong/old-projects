﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TTakeHistory_HService
    /// Author: ISV-TIEN
    /// </summary>
    public class TTakeHistory_DService : DataAccess.Abstract.AbstractService<TTakeHistory_D>
    {
        #region public

        /// <summary>
        /// Get List Picking Results
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <param name="takeFlag">Take Flag</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<StockTakeProclamationDetailResults> GetListStockTakeProclamationDetailResults(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            var result = from t in this.Context.GetTable<TTakeHistory_D>()
                         join p in this.Context.GetTable<MProduct>() on new { key1 = t.ProductCD } equals new { key1 = p.ProductCD }
                         where !t.DeleteFlag && t.WarehouseCD.Equals(warehouseCD) && t.LocationCD.Equals(locationCd)
                         select new StockTakeProclamationDetailResults()
                         {
                             TakeFlag = t.TakeFlag,
                             TakeStatus =t.TakeStatus,
                             TagNoAndBranchTagNo = t.TagNo + Constant.HYPHEN + t.BranchTagNo.ToString().PadLeft(4, '0'),
                             TagNo = t.TagNo,
                             BranchTagNo = t.BranchTagNo.ToString(),
                             ProductCD = t.ProductCD,
                             ProductName = p.ProductName,
                             LOT1 = t.LOT1,
                             LOT2 = t.LOT2,
                             LOT3 = t.LOT3,
                             UpdateDate = t.UpdateDate
                         };

            return result;
        }

        /// <summary>
        /// Get All By Location
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeHistory_D> GetAllByLocation(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeHistory_D> item = from i in this.Context.GetTable<TTakeHistory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                select i;

            return item;

        }

        /// <summary>
        /// Get List Deficit
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeHistory_D> GetListDeficit(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeHistory_D> item = from i in this.Context.GetTable<TTakeHistory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                      && i.TakeFlag == false
                                                select i;

            return item;

        }

        /// <summary>
        /// Get List Surplus
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="warehouseCD">Warehouse CD</param>
        /// <param name="locationCd">Location CD</param>
        /// <returns>IOrderedQueryable<TStockAllowance></returns>
        public IQueryable<TTakeHistory_D> GetListSurplus(string warehouseCD, string locationCd)
        {
            locationCd = MLocation.FixCodeDB(locationCd);

            IQueryable<TTakeHistory_D> item = from i in this.Context.GetTable<TTakeHistory_D>()
                                                where i.DeleteFlag == false
                                                      && i.WarehouseCD.Equals(warehouseCD)
                                                      && i.LocationCD.Equals(locationCd)
                                                      && i.TakeFlag == true
                                                      && i.TakeStatus == Constant.TAKE_STATUS_RECEIPTS
                                                select i;

            return item;

        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TInventoryService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TSequencesService : DataAccess.Abstract.AbstractService<TSequences>
    {
        #region get

        /// <summary>
        /// Get TSequences by Pk
        /// </summary>
        /// <param name="TagNoDivision">TagNoDivision</param>
        /// <returns>TSequences</returns>
        public TSequences GetByPK(string TagNoDivision)
        {
            return (from s in this.Context.GetTable<TSequences>()
                   where s.TagNoDivision.Equals(TagNoDivision)
                   select s).SingleOrDefault();
        }

        /// <summary>
        /// Get MaxTagNo by TagNoDivision ISV-Nho
        /// </summary>
        /// <param name="TagNoDivision">TagNoDivision</param>
        /// <returns>MaxTagNo</returns>
        public string GetNewMaxTagNoByTagNoDivision(string TagNoDivision, string curDateYM)
        {
            string ret = string.Empty;

            TSequences item = this.GetByPK(TagNoDivision);
            if (item == null || item == default(TSequences))
            {
                ret = String.Format("{0}{1:000000}", curDateYM, 1);
                TSequences model = new TSequences();
                model.TagNoDivision = TagNoDivision;
                model.MaxTagNo = ret;

                base.Insert(model);
            }
            else
            {
                if (!curDateYM.Equals(item.MaxTagNo.ToString().Substring(0, 4)))
                {
                    ret = String.Format("{0}{1:000000}", curDateYM, 1);
                }
                else
                {
                    ret = String.Format("{0}{1:000000}", curDateYM, int.Parse(item.MaxTagNo.Substring(4)) + 1);
                }
                item.MaxTagNo = ret;
            }
            base.Context.SubmitChanges();

            return ret;
        }

        ///// <summary>
        ///// Create new MaxTagNo 
        ///// Author: ISV-Nho
        ///// </summary>
        ///// <param name="TagNoDivision">MaxTagNo</param>
        ///// <returns>MaxTagNo</returns>
        //public string CreateNewMaxTagNo(string MaxTagNo, string curDateYM)
        //{
        //    if (string.IsNullOrEmpty(MaxTagNo))
        //    {
        //        return String.Format("{0}{1:000000}", curDateYM, 1);
        //    }
        //    else
        //    {
        //        if (!curDateYM.Equals(MaxTagNo.Substring(0, 4)))
        //        {
        //            return String.Format("{0}{1:000000}", curDateYM, 1);
        //        }
        //        else
        //        {
        //            return String.Format("{0}{1:000000}", curDateYM, int.Parse(MaxTagNo.Substring(4)) + 1);
        //        }
        //    }
        //}

        #endregion

        #region Check

        

        #endregion
    }
}
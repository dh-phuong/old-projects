﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MKind_H Context
    /// Author: ISV - GIAM
    /// </summary>
    public class MKind_HService : DataAccess.Abstract.AbstractService<MKind_H>
    {
        #region GET

        /// <summary>
        /// Get Kind List By Condition
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="gmModel">KindHeaderList</param>
        /// <returns>IQueryable of KindHeaderResults</returns>
        public IQueryable<KindHeaderResults> GetListByConditions(KindHeaderList gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_KindName))
            {
                gmModel.txt_KindName = string.Empty;
            }
            IQueryable<KindHeaderResults> list = from g in this.Context.GetTable<MKind_H>()
                                                where (gmModel.chb_IncludeDeleteData || !g.DeleteFlag)
                                                    && (string.IsNullOrEmpty(gmModel.txt_KindCD) || g.KindCD.StartsWith(gmModel.txt_KindCD))
                                                    && (string.IsNullOrEmpty(gmModel.txt_KindName) || g.KindName.ToLower().Contains(gmModel.txt_KindName.ToLower()))
                                                select new KindHeaderResults
                                                {
                                                    KindCD = g.KindCD.Trim(),
                                                    KindName = g.KindName,
                                                    DeleteFlag = g.DeleteFlag,
                                                    UpdateDate = g.UpdateDate
                                                };
            return list;
        }

        /// <summary>
        /// Get list by condition for search
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<KindSearch> GetListByConditionsForSearch(KindSearch gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sValue))
            {
                gmModel.sValue = string.Empty;
            }
            IQueryable<KindSearch> list = from kh in this.Context.GetTable<MKind_H>()
                                          join kd in this.Context.GetTable<MKind_D>() on kh.KindCD equals kd.KindCD
                                          where (!kh.DeleteFlag)
                                                && (kd.Language.Equals(Convert.ToString((int)UserSession.Session.Language)))
                                                && (string.IsNullOrEmpty(gmModel.sDataKind) || kh.KindCD.StartsWith(gmModel.sDataKind))
                                                && (string.IsNullOrEmpty(gmModel.sDataCD) || kd.DataCD.StartsWith(gmModel.sDataCD))
                                                && (string.IsNullOrEmpty(gmModel.sValue) || kd.Value.ToUpper().Contains(gmModel.sValue.ToUpper()))
                                          select new KindSearch 
                                          {
                                              sDataKind = kh.KindCD,
                                              sDataKindNm = kh.KindName,
                                              sDataCD = kd.DataCD,
                                              sValue = kd.Value,
                                              sUpdateDate = kh.UpdateDate
                                          };
            return list;
 
        }

        /// <summary>
        /// Get Data Header By KindCD
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="kindCD">kindCD</param>
        /// <returns>KindHeaderResults</returns>
        public KindHeaderResults GetHeaderResultsByKindCD(string kindCD)
        {
            IQueryable<KindHeaderResults> list = from g in this.Context.GetTable<MKind_H>()
                                           where g.KindCD == kindCD
                                           select new KindHeaderResults
                                           {
                                               KindName = g.KindName,
                                               DeleteFlag = g.DeleteFlag,
                                               UpdateDate = g.UpdateDate
                                           };
            return list.SingleOrDefault();
        }
   
        /// <summary>
        /// Get Header by KindCD
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="kindCD">KindCD</param>
        /// <returns>MKind_H</returns>
        public MKind_H GetHeaderByKindCD(string kindCD)
        {
            IQueryable<MKind_H> items = from c in this.Context.GetTable<MKind_H>()
                                        where c.KindCD.Equals(kindCD)
                                        select c;
            return items.SingleOrDefault();
        }

        /// <summary>
        /// Get Header
        /// Author:ISV-HUNG
        /// </summary>
        /// <returns>MKind_H</returns>
        public IQueryable<MKind_H> GetHeader()
        {
            IQueryable<MKind_H> items = from c in this.Context.GetTable<MKind_H>()
                                        select c;
            return items;
        }

        /// <summary>
        /// Get List Kind for CSV
        /// Author: ISV-GIAM
        /// </summary>
        /// <returns></returns>
        public IQueryable<KindListCSV> GetListKindCSV()
        {
            IQueryable<KindListCSV> list = from h in this.Context.GetTable<Models.MKind_H>()
                                           join d in this.Context.GetTable<Models.MKind_D>() on h.KindCD equals (d.KindCD)
                                           orderby d.KindCD, d.DataCD, d.Language
                                              select new KindListCSV
                                           {
                                               KindCD = h.KindCD,
                                               KindName = h.KindName,
                                               DataCD = d.DataCD,
                                               Value = d.Value,
                                               Language = d.Language,
                                               DeleteFlag = h.DeleteFlag,
                                               CreateDate = h.CreateDate,
                                               CreateUCD = h.CreateUCD,
                                               UpdateDate = h.UpdateDate,
                                               UpdateUCD = h.UpdateUCD
                                           };

        return list;
        }

        /// <summary>
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns></returns>
        public IQueryable<GroupDetailModels> GetListGroupForInsert()
        {
            IQueryable<GroupDetailModels> list = from kh in this.Context.MKind_H
                                                 join kd in this.Context.MKind_D on kh.KindCD equals kd.KindCD
                                                 select new GroupDetailModels
                                                 {

                                                 };
            return list;
        }

        /// <summary>
        /// Is Show Customer
        /// </summary>
        /// <returns></returns>
        public bool IsShowCustomer()
        {
            string isShow = (from d in this.Context.MKind_D
                            where d.KindCD.Equals(Constant.MKIND_KINDCD_VIEW_CUS)
                               && d.DataCD.Equals(Constant.MKIND_DATACD_VIEW_CUS)
                               && d.Language.Equals(LanguageFlag.English)
                            select d.Value).SingleOrDefault();
            return isShow.ToUpper().Equals("true".ToUpper());
        }

        #endregion

        #region Check
        /// <summary>
        /// Check data changed
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        public bool CheckDataChanged(KindDetail gmModel)
        {
            return !Context.GetTable<MKind_H>().Any(p => p.KindCD.Trim().Equals(gmModel.PreKindCD)
                                               && p.UpdateDate.Equals(gmModel.UpdateDate));
        }
        #endregion
    }
}
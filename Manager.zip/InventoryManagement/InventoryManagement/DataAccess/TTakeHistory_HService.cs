﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TTakeHistory_HService
    /// Author: ISV-TIEN
    /// </summary>
    public class TTakeHistory_HService : DataAccess.Abstract.AbstractService<TTakeHistory_H>
    {
        /// <summary>
        /// Get  TTakeInventory_H By PK
        /// Author:ISV-TIEN
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <param name="Location"></param>
        /// <returns></returns>
        public TTakeHistory_H GetByPK(string WarehouseCD, string LocationCD)
        {
            IQueryable<TTakeHistory_H> item = from i in this.Context.GetTable<TTakeHistory_H>()
                                                where i.WarehouseCD.Trim().Equals(WarehouseCD)
                                                      && i.LocationCD.Trim().Equals(LocationCD)
                                                select i;
            return item.SingleOrDefault<TTakeHistory_H>();
        }

        /// <summary>
        /// Check exist LocationCD
        /// Author : ISV-Vinh
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool ExistByLocation(string WarehouseCD, string LocationCD)
        {
            bool result = this.ExistBy(d => d.LocationCD.Equals(LocationCD)
                                        && d.WarehouseCD.Equals(WarehouseCD));
            return result;
        }


        /// <summary>
        /// Get Data Source For InventoryCheckList Report
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        public List<DifferenceCheckList> GetDifferenceCheckList(string LocationCD)
        {
            var query = (from th in this.Context.TTakeHistory_H
                         join td in this.Context.TTakeHistory_D on new { th.WarehouseCD, th.LocationCD } equals new { td.WarehouseCD, td.LocationCD } into detail
                         from det in detail.DefaultIfEmpty()
                         join l in this.Context.MLocation on new { th.WarehouseCD, th.LocationCD } equals new { l.WarehouseCD, l.LocationCD }                         
                         join p in this.Context.MProduct on new { det.ProductCD } equals new { p.ProductCD } into P
                         from po in P.DefaultIfEmpty()
                         where
                             !th.DeleteFlag
                          && th.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                          && th.LocationCD.Equals(LocationCD)

                         select new DifferenceCheckList
                         {
                             LocationCD = th.LocationCD,
                             LocationName = l.LocationName,
                             TakeStartDate = th.TakeStartDate,
                             TakeEndDate = th.TakeEndDate ?? string.Empty,
                             TagInfo = det.TagNo + Constant.HYPHEN + det.BranchTagNo.ToString().PadLeft(4, '0'),
                             ProductCD = det.ProductCD ?? string.Empty,
                             ProductName = po.ProductName ?? string.Empty,
                             Lot1 = det.LOT1 ?? string.Empty,
                             Lot2 = det.LOT2 ?? string.Empty,
                             Lot3 = det.LOT3 ?? string.Empty,
                             TakeStatus = det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE,
                             TakeStatusIndex = (det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE) == Constant.TAKE_STATUS_NONE ? 1 : ((det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE) == Constant.BALANCE_STATUS_INVENTORY_ISSUE ? 3 : 2)
                         }).OrderBy(m => m.TakeStatusIndex).ThenBy(m => m.TagInfo);                         


            List<DifferenceCheckList> result = query.ToList<DifferenceCheckList>();
            return result;
        }
    }
}
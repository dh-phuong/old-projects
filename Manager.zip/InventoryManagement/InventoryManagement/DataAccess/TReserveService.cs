﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MUser Context
    /// Author: ISV - Nho
    /// </summary>
    public class TReserveService : DataAccess.Abstract.AbstractService<TReserve>
    {
        #region public method

        #region get

        /// <summary>
        /// Get data by primary key
        /// Author: ISV-TIEN
        /// </summary>
        // <param name="shipNo">shippingNo</param>
        /// <param name="tagNo">TagNo</param>
        /// <param name="locationCD">Location code</param>
        /// <returns>TReserve</returns>
        public TReserve GetByPK(string shipNo, string tagNo, string locationCD)
        {
            IQueryable<TReserve> item = from i in this.Context.GetTable<TReserve>()
                                        where i.ShipNo.Equals(shipNo) 
                                                  && i.TagNo.Equals(tagNo)
                                                  && i.LocationCD.Equals(locationCD)
                                            select i;

            return item.SingleOrDefault<TReserve>();
        }
        

        /// <summary>
        /// Get List by ShipNo
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>List TReserve</returns>
        public IQueryable<TReserve> GetListByShipNo(string shipNo) 
        {
            return this.Context.TReserve.Where(m => m.ShipNo.Equals(shipNo));
        }

        /// <summary>
        /// Get List
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>List TReserve</returns>
        public IQueryable<TReserve> GetListByConditionForOutDeliIndiDetail(OutboundDeliveryIndicationDetail gmModel)
        {
            string dateFrom = gmModel.ctr_ArrivalDateFrom.DateValue();
            string dateTo = gmModel.ctr_ArrivalDateTo.DateValue();

            string LOT2From = gmModel.ctr_LOT2DateFrom.DateValue();
            string LOT2To = gmModel.ctr_LOT2DateTo.DateValue();

            string LOT3From = gmModel.ctr_LOT3DateFrom.DateValue();
            string LOT3To = gmModel.ctr_LOT3DateTo.DateValue();
            if (string.IsNullOrEmpty(gmModel.ShipNo))
            {
                gmModel.ShipNo = string.Empty;
            }
            var result1 = from r in this.Context.TReserve
                          join h in this.Context.TInventory_H on r.TagNo equals h.TagNo
                          join d in this.Context.TInventory_D on r.TagNo equals d.TagNo
                          where
                                r.ShipNo.Equals(gmModel.ShipNo) &&
                               (string.IsNullOrEmpty(gmModel.txt_TagNo) || h.TagNo.Contains(gmModel.txt_TagNo)) &&
                               (string.IsNullOrEmpty(dateFrom) || h.ArrivalDate.CompareTo(dateFrom) >= 0) &&
                               (string.IsNullOrEmpty(dateTo) || h.ArrivalDate.CompareTo(dateTo) <= 0) &&
                               (string.IsNullOrEmpty(gmModel.txt_LOT1) || h.Lot1.Contains(gmModel.txt_LOT1)) &&
                               (string.IsNullOrEmpty(LOT2From) || h.Lot2.CompareTo(LOT2From) >= 0) &&
                               (string.IsNullOrEmpty(LOT2To) || h.Lot2.CompareTo(LOT2To) <= 0) &&
                               (string.IsNullOrEmpty(LOT3From) || h.Lot3.CompareTo(LOT3From) >= 0) &&
                               (string.IsNullOrEmpty(LOT3To) || h.Lot3.CompareTo(LOT3To) <= 0)
                           group r by new {r.TagNo, r.LocationCD} into gr
                           select gr.FirstOrDefault();

            return result1;
        }

        ///// <summary>
        ///// Get List For Move Indication
        ///// </summary>
        ///// <param name="shipNo">ShipNo</param>
        ///// <returns>List TReserve</returns>
        //public IQueryable<TReserve> GetListByConditionForMoveIndicationDetail(MoveIndicationDetail gmModel)
        //{
        //    string dateFrom = gmModel.ctr_ArrivalDateFrom.DateValue();
        //    string dateTo = gmModel.ctr_ArrivalDateTo.DateValue();

        //    string LOT2From = gmModel.ctr_LOT2DateFrom.DateValue();
        //    string LOT2To = gmModel.ctr_LOT2DateTo.DateValue();

        //    string LOT3From = gmModel.ctr_LOT3DateFrom.DateValue();
        //    string LOT3To = gmModel.ctr_LOT3DateTo.DateValue();
        //    if (string.IsNullOrEmpty(gmModel.MoveNo))
        //    {
        //        gmModel.MoveNo = string.Empty;
        //    }
        //    var result1 = from r in this.Context.TReserve
        //                  join h in this.Context.TInventory_H on r.TagNo equals h.TagNo
        //                  join d in this.Context.TInventory_D on r.TagNo equals d.TagNo
        //                  where
        //                        r.ShipNo.Equals(gmModel.MoveNo) &&
        //                       (string.IsNullOrEmpty(gmModel.txt_TagNo) || h.TagNo.Contains(gmModel.txt_TagNo)) &&
        //                       (string.IsNullOrEmpty(dateFrom) || h.ArrivalDate.CompareTo(dateFrom) >= 0) &&
        //                       (string.IsNullOrEmpty(dateTo) || h.ArrivalDate.CompareTo(dateTo) <= 0) &&
        //                       (string.IsNullOrEmpty(gmModel.txt_LOT1) || h.Lot1.Contains(gmModel.txt_LOT1)) &&
        //                       (string.IsNullOrEmpty(LOT2From) || h.Lot2.CompareTo(LOT2From) >= 0) &&
        //                       (string.IsNullOrEmpty(LOT2To) || h.Lot2.CompareTo(LOT2To) <= 0) &&
        //                       (string.IsNullOrEmpty(LOT3From) || h.Lot3.CompareTo(LOT3From) >= 0) &&
        //                       (string.IsNullOrEmpty(LOT3To) || h.Lot3.CompareTo(LOT3To) <= 0)
        //                  group r by new { r.TagNo, r.LocationCD } into gr
        //                  select gr.FirstOrDefault();

        //    return result1;
        //}

        /// <summary>
        /// Get List
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>List TReserve</returns>
        public IQueryable<TReserve> GetList()
        {
            return this.Get();
        }

        /// <summary>
        /// Get list by tabNo
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="tagNo"></param>
        /// <returns></returns>
        public IQueryable<TReserve> GetByTagNo(string tagNo)
        {
            return this.GetBy(m => m.TagNo.Equals(tagNo));

        }

        /// <summary>
        /// Get record for update
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="locationCD">locationCD</param>
        /// <returns>TReserve</returns>
        public TReserve GetForUpdate(string shipNo, string tagNo, string locationCD)
        {
            return this.Context.TReserve.Where(m => m.ShipNo.Equals(shipNo) && m.TagNo.Equals(tagNo) && m.LocationCD.Equals(locationCD)).SingleOrDefault();
        }

        /// <summary>
        /// Get list by ship No
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns></returns>
        public List<OutboundDeliveryIndicationDetailResult> GetListByShipNoForUpdate(string shipNo)
        {
            IQueryable<OutboundDeliveryIndicationDetailResult> result = from r in this.Context.GetTable<TReserve>()
                                                                  join h in this.Context.GetTable<TInventory_H>() on r.TagNo equals h.TagNo
                                                                  where r.ShipNo.Equals(shipNo)
                                                                  select new OutboundDeliveryIndicationDetailResult()
                                                                  {
                                                                      TagNo=h.TagNo
                                                                  };

            return result.ToList();
        }

        /// <summary>
        /// Get count quantity in reserve
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <param name="shipNoDetail"></param>
        /// <returns></returns>
        public int GetByShipNoDetail(string shipNo, string shipNoDetail,string productCD)
        {
            return (from r in this.Context.GetTable<TReserve>()
                    join h in this.Context.GetTable<TInventory_H>() on r.TagNo equals h.TagNo
                    where r.ShipNo.Equals(shipNo) && r.ShipDetailNo.Equals(shipNoDetail)
                    && h.ProductCD.Equals(productCD)
                    select r.Quantity).Count();
        }

        /// <summary>
        /// Get by shipNoDetail
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <param name="shipNoDetail"></param>
        /// <returns></returns>
        public IQueryable<TReserve> GetListByShipNoDetail(string shipNo, string shipNoDetail)
        {
            return from r in this.Context.GetTable<TReserve>()
                   where r.ShipNo.Equals(shipNo) && r.ShipDetailNo.Equals(shipNoDetail)
                   select r;
        }

        /// <summary>
        /// Get count remainQty
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public int GetCountRemainQty(OutboundDeliveryIndicationDetailResult gmModel)
        {
            return (from r in this.Context.GetTable<TReserve>()
                    where (r.TagNo.Equals(gmModel.TagNo)) &&
                     (r.LocationCD.Equals(gmModel.LocationCD))
                    select r).Count();
        }

        /// <summary>
        /// Get Count By conditions for Move Indication
        /// ISV-Nho
        /// </summary>
        /// <param name="shipNo">shippingNo</param>
        /// <param name="tagNo">TagNo</param>
        /// <param name="locationCD">Location code</param>
        /// <returns>count of TReserve</returns>
        public int GetCountByConditionsForMoveIndication(string shipNo, string tagNo, string locationCD)
        {
            return (from r in this.Context.TReserve
                    where (string.IsNullOrEmpty(shipNo) || !r.ShipNo.Equals(shipNo))
                       && r.TagNo.Equals(tagNo)
                       && r.LocationCD.Equals(locationCD)
                    group r by new {r.TagNo, r.LocationCD} into grp
                    select grp.Sum(m=>m.RemainQuantity)).SingleOrDefault();
        }

        /// <summary>
        /// Get List by locationCD
        /// </summary>
        /// <param name="locationCD">Location Code</param>
        /// <returns>List TReserve</returns>
        public IQueryable<TReserve> GetListByLocationCD(string locationCD)
        {
            return this.Context.TReserve.Where(m => m.LocationCD.Equals(locationCD));
        }

        #endregion

        #region Check

         /// <summary>
         /// Exist Location By ShipNo
         /// Author : ISV-LOC
         /// </summary>
         /// <param name="WarehouseCD">WarehouseCD</param>
         /// <param name="LocationCD">LocationCD</param>
         /// <returns></returns>
         public bool ExistLocationByShipNo(string LocationCD, string ShipNo)
         {
             IQueryable<TReserve> items = from r in this.Context.TReserve
                                          where r.ShipNo.Equals(ShipNo)
                                          && r.LocationCD.Equals(LocationCD)
                                          select r;

             return items.Any();
         }

         /// <summary>
         /// Check Exist Location for shipping
         /// Author: ISV-Vinh
         /// </summary>
         /// <param name="WarehouseCD">WarehouseCD</param>
         /// <param name="LocationCD">LocationCD</param>
         /// <returns>TRUE: Exist, FALSE: Not Exist</returns>
         public bool ExistLocationShipping(string WarehouseCD, string LocationCD)
         {
             var item = from r in this.Context.TReserve
                        join s in this.Context.TShippingInstruction on r.ShipNo equals s.ShipNo
                        where r.LocationCD.Equals(LocationCD)
                           && s.WarehouseCD.Equals(WarehouseCD)
                        select r.TagNo;

             return item.Any();
         }

         /// <summary>
         /// Check Exist Location for shipping in Register
         /// Author: ISV-Vinh
         /// </summary>
         /// <param name="WarehouseCD">WarehouseCD</param>
         /// <param name="LocationCD">LocationCD</param>
         /// <returns>TRUE: Exist, FALSE: Not Exist</returns>
         public bool ExistLocaShipInRegis(string WarehouseCD, string LocationCD)
         {
             var item = from r in this.Context.TReserve
                        join s in this.Context.TShippingInstruction on r.ShipNo equals s.ShipNo
                        where r.LocationCD.Equals(LocationCD)
                           && s.WarehouseCD.Equals(WarehouseCD)
                           && r.RemainQuantity > 0
                        select r.TagNo;

             return item.Any();
         }

        #endregion
        
        #endregion
    }
}
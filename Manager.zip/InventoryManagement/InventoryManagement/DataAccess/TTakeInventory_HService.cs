﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TTakeInventory_H Service
    /// Author: ISV-LOC
    /// </summary>
    public class TTakeInventory_HService : DataAccess.Abstract.AbstractService<TTakeInventory_H>
    {

        #region public 

        /// <summary>
        /// Get  TTakeInventory_H By PK
        /// Author:ISV-TIEN
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <param name="Location"></param>
        /// <returns></returns>
        public TTakeInventory_H GetByPK(string WarehouseCD, string LocationCD)
        {
            IQueryable<TTakeInventory_H> item = from i in this.Context.GetTable<TTakeInventory_H>()
                                                where i.WarehouseCD.Trim().Equals(WarehouseCD)
                                                      && i.LocationCD.Trim().Equals(LocationCD)
                                                select i;

            return item.SingleOrDefault<TTakeInventory_H>();
        }
        
        /// <summary>
        /// Get List StockTakeProclamation by Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <returns>List StockTakeProclamationResults</returns>
        public IQueryable<StockTakeProclamationResults> GetListStockTakeProclamationbyConditions(StockTakeProclamationList gmModel)
        {
            gmModel.txt_LocationCD = MLocation.FixCodeDB(gmModel.txt_LocationCD);
            string startDateFrom = gmModel.txt_TakeStartDateFrom.DateValue();
            string startDateTo = gmModel.txt_TakeStartDateTo.DateValue();
            string endDateFrom = gmModel.txt_TakeEndDateFrom.DateValue();
            string endDateTo = gmModel.txt_TakeEndDateTo.DateValue();
            IQueryable<StockTakeProclamationResults> items = from loc in this.Context.MLocation
                                                             join th in this.Context.TTakeInventory_H on new { key1 = loc.WarehouseCD, key2 = loc.LocationCD } equals new { key1 = th.WarehouseCD, key2 = th.LocationCD } into L_TH
                                                             from leftTH in L_TH.DefaultIfEmpty()
                                                             join thh in this.Context.TTakeHistory_H on new { key1 = loc.WarehouseCD, key2 = loc.LocationCD } equals new { key1 = thh.WarehouseCD, key2 = thh.LocationCD } into L_THH
                                                             from leftTHH in L_THH.DefaultIfEmpty()
                                                             where loc.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                                && !loc.DeleteFlag
                                                                && (string.IsNullOrEmpty(gmModel.txt_LocationCD) || loc.LocationCD.Equals(gmModel.txt_LocationCD))
                                                                && (string.IsNullOrEmpty(startDateFrom) 
                                                                    || (!leftTH.TakeStartDate.Equals(null) && leftTH.TakeStartDate.CompareTo(startDateFrom) >= 0)
                                                                    || (!leftTHH.TakeStartDate.Equals(null) && leftTHH.TakeStartDate.CompareTo(startDateFrom) >= 0))
                                                                && (string.IsNullOrEmpty(startDateTo) 
                                                                    || (!leftTH.TakeStartDate.Equals(null) && leftTH.TakeStartDate.CompareTo(startDateTo) <= 0)
                                                                    || (!leftTHH.TakeStartDate.Equals(null) && leftTHH.TakeStartDate.CompareTo(startDateTo) <= 0))
                                                                && (string.IsNullOrEmpty(endDateFrom) 
                                                                    || (!leftTH.TakeEndDate.Equals(null) && leftTH.TakeEndDate.CompareTo(endDateFrom) >= 0)
                                                                    || (!leftTHH.TakeEndDate.Equals(null) && leftTHH.TakeEndDate.CompareTo(endDateFrom) >= 0))
                                                                && (string.IsNullOrEmpty(endDateTo) 
                                                                    || (!leftTH.TakeEndDate.Equals(null) && leftTH.TakeEndDate.CompareTo(endDateTo) <= 0)
                                                                    || (!leftTHH.TakeEndDate.Equals(null) && leftTHH.TakeEndDate.CompareTo(endDateTo) <= 0))
                                                             orderby loc.LocationCD
                                                             select new StockTakeProclamationResults
                                                             {
                                                                 LocationCD = loc.LocationCD,
                                                                 LocationName = loc.LocationName,
                                                                 TakeStartDate = (!leftTH.TakeStartDate.Equals(null)) ? leftTH.TakeStartDate : leftTHH.TakeStartDate,
                                                                 TakeEndDate = (!leftTH.TakeStartDate.Equals(null)) ? leftTH.TakeEndDate : leftTHH.TakeEndDate,
                                                                 IsTakingFlag = !leftTH.TakeStartDate.Equals(null) ? true : false,
                                                                 haveDetail = (!leftTH.TakeStartDate.Equals(null) || !leftTHH.TakeStartDate.Equals(null)) ? true : false

                                                             };
            return items;
        }

        /// <summary>
        /// Get List TagNo By LocationCD For StockTakeProclamation
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        public List<string> GetListTagNoByLocationCDForStockTakeProclamation(string LocationCD)
        {
            List<string> items = (from ih in this.Context.TInventory_H
                                  where !ih.DeleteFlag
                                  && ih.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                  && this.Context.TInventory_D.Where(id => id.TagNo.Equals(ih.TagNo) //StockStatus ='10'
                                                             && id.LocationCD.Equals(LocationCD)
                                                             && id.StockStatus.Equals(Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)).Count() == 0
                                  && this.Context.TInventory_D.Where(id => id.TagNo.Equals(ih.TagNo)  //StockStatus ='20,25'
                                                              && id.LocationCD.Equals(LocationCD)
                                                              && (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                                                                || id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)) ).Count() >0
                                  && this.Context.TReserve.Where(tr => tr.LocationCD.Equals(LocationCD)//Shipping
                                                         && tr.TagNo.Equals(ih.TagNo)).Count() == 0
                                  && this.Context.TTakeInventory_H.Where(th => th.LocationCD.Equals(LocationCD)//Taking
                                                                 && th.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                                 && th.DeleteFlag.Equals(false)
                                                                 && th.TakeCompleteFlag.Equals(false)).Count() == 0
                                  select ih.TagNo).ToList();

            return items;
        }

        /// <summary>
        /// Get StockTakeResults by condition
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">StockTakeList</param>
        /// <returns>IQueryable StockTakeResults<DifferenceResults></returns>
        public IQueryable<StockTakeResults> GetListStockTakeResultsByConditions(StockTakeList gmModel)
        {
            string TakeStartDateFrom = gmModel.SrhTakeStartDateFrom.DateValue();
            string TakeStartDateTo = gmModel.SrhTakeStartDateTo.DateValue();
            string TakeEndDateFrom = gmModel.SrhTakeEndDateFrom.DateValue();
            string TakeEndDateTo = gmModel.SrhTakeEndDateTo.DateValue();

            var result = from th in this.Context.TTakeInventory_H
                         join l in this.Context.MLocation on new { key1 = th.WarehouseCD, key2 = th.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                         where
                            (!th.DeleteFlag) &&
                            th.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                            (string.IsNullOrEmpty(gmModel.txt_LocationCD) || th.LocationCD.Equals(gmModel.txt_LocationCD)) &&
                            (string.IsNullOrEmpty(TakeStartDateFrom) || th.TakeStartDate.CompareTo(TakeStartDateFrom) >= 0) &&
                            (string.IsNullOrEmpty(TakeStartDateTo) || th.TakeStartDate.CompareTo(TakeStartDateTo) <= 0) &&
                            (string.IsNullOrEmpty(TakeEndDateFrom) || th.TakeEndDate.CompareTo(TakeEndDateFrom) >= 0) &&
                            (string.IsNullOrEmpty(TakeEndDateTo) || th.TakeEndDate.CompareTo(TakeEndDateTo) <= 0)
                         select new StockTakeResults()
                         {
                             LocationCD = th.LocationCD,
                             LocationName = l.LocationName,
                             TakeStartDate = th.TakeStartDate,
                             UpdateDate = th.UpdateDate
                         };

            return result;

        }

        /// <summary>
        /// Get Data Source For InventoryCheckList Report
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        public List<InventoryCheckList> GetInventoryCheckList(string LocationCD)
        {

            var query = (from th in this.Context.TTakeInventory_H
                         join td in this.Context.TTakeInventory_D on new { th.WarehouseCD, th.LocationCD } equals new { td.WarehouseCD, td.LocationCD } into detail
                         from det in detail.DefaultIfEmpty()
                         join l in this.Context.MLocation on new { th.WarehouseCD, th.LocationCD } equals new { l.WarehouseCD, l.LocationCD }
                         join p in this.Context.MProduct on new { det.ProductCD } equals new { p.ProductCD } into P
                         from po in P.DefaultIfEmpty()            
                         where
                          !th.DeleteFlag
                          && th.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                          && th.LocationCD.Equals(LocationCD)
                         select new InventoryCheckList
                          {
                              LocationCD = th.LocationCD,
                              LocationName = l.LocationName,
                              TakeStartDate = th.TakeStartDate,
                              TagInfo = det.TagNo + Constant.HYPHEN + det.BranchTagNo.ToString().PadLeft(4, '0'),
                              ProductCD = det.ProductCD ?? string.Empty,
                              ProductName = po.ProductName ?? string.Empty,
                              Lot1 = det.LOT1 ?? string.Empty,
                              Lot2 = det.LOT2 ?? string.Empty,
                              Lot3 = det.LOT3 ?? string.Empty,
                          });


            List<InventoryCheckList> result = query.ToList<InventoryCheckList>();
            return result;
        }

        /// <summary>
        /// Get Data Source For InventoryCheckList Report
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        public List<DifferenceCheckList> GetDifferenceCheckList(string LocationCD)
        {

            var query = (from th in this.Context.TTakeInventory_H
                         join td in this.Context.TTakeInventory_D on new { th.WarehouseCD, th.LocationCD } equals new { td.WarehouseCD, td.LocationCD } into detail
                         from det in detail.DefaultIfEmpty()
                         join l in this.Context.MLocation on new { th.WarehouseCD, th.LocationCD } equals new { l.WarehouseCD, l.LocationCD }
                         join p in this.Context.MProduct on new { det.ProductCD } equals new { p.ProductCD } into P
                         from po in P.DefaultIfEmpty()
                         where
                          !th.DeleteFlag
                          && th.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                          && th.LocationCD.Equals(LocationCD)                         
                         select new DifferenceCheckList
                         {
                             LocationCD = th.LocationCD,
                             LocationName = l.LocationName,
                             TakeStartDate = th.TakeStartDate,
                             TakeEndDate = th.TakeEndDate ?? string.Empty,
                             TagInfo = det.TagNo + Constant.HYPHEN + det.BranchTagNo.ToString().PadLeft(4, '0'),
                             ProductCD = det.ProductCD ?? string.Empty,
                             ProductName = po.ProductName ?? string.Empty,
                             Lot1 = det.LOT1 ?? string.Empty,
                             Lot2 = det.LOT2 ?? string.Empty,
                             Lot3 = det.LOT3 ?? string.Empty,
                             TakeStatus = det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE,
                             TakeStatusIndex = (det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE) == Constant.TAKE_STATUS_NONE ? 1 : ((det.TakeStatus ?? Constant.BALANCE_STATUS_INVENTORY_ISSUE) == Constant.BALANCE_STATUS_INVENTORY_ISSUE ? 3 : 2)
                         }).OrderBy(m => m.TakeStatusIndex).ThenBy(m=> m.TagInfo);


            List<DifferenceCheckList> result = query.ToList<DifferenceCheckList>();
            return result;
        }
       
        #endregion

        #region Check

        /// <summary>
        /// Check exist LocationCD with TakeFlg = False  :"UnCompleted"
        /// Author:ISV-LOC
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistByLocationUnCompleted(string WarehouseCD, string LocationCD)
        {
            bool result = this.ExistBy(d => d.LocationCD.Equals(LocationCD)
                                  && d.WarehouseCD.Equals(WarehouseCD)
                                  && d.DeleteFlag.Equals(false)
                                  && d.TakeCompleteFlag.Equals(false));
            return result;
        }

        /// <summary>
        /// Check exist LocationCD
        /// Author : ISV-Vinh
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool ExistByLocation(string WarehouseCD, string LocationCD)
        {
            bool result = this.ExistBy(d => d.LocationCD.Equals(LocationCD)
                                        && d.WarehouseCD.Equals(WarehouseCD)
                                        && d.DeleteFlag.Equals(false));
            return result;
        }

        /// <summary>
        /// Check to show message in menu (Exist with WarehouseCD login)
        /// </summary>
        /// <returns></returns>
        public bool IsExistsInTakeInventory()
        {
             return this.ExistBy(k => k.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD));
        }

        #endregion

        #region private

        #endregion
    }
}
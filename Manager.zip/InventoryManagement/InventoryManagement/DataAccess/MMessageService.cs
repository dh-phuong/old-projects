﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;


namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MMessage Context
    /// Author: ISV - PHUONG
    /// </summary>
    public class MMessageService: IDisposable
    {
        #region Constant

        #endregion

        #region Common

        /// <summary>
        /// Context to access database
        /// </summary>
        public Models.DataClasses1DataContext Context { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public MMessageService()
        {
            this.Context = DbServices.CreateContext();
        }

        /// <summary>
        /// Reset
        /// </summary>
        public void Reset()
        {
            this.Context = DbServices.CreateContext();
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.Context = null;
        }

        #endregion
      
        #region public method

        /// <summary>
        /// Get list
        /// </summary>
        /// <param name="messageID">messageID</param>
        /// <returns>message string</returns>
        public IQueryable<MMessage> GetList()
        {
            var list = from m in this.Context.MMessage
                       orderby m.MessageID
                       select m;
            return list;
        }

        #endregion

        #region private method

        #endregion
    }
}
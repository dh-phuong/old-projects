﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.Objects.SqlClient;
using InventoryManagement.Common;
using System.Transactions;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TInventory_HService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TInventory_HService : DataAccess.Abstract.AbstractService<TInventory_H>
    {
        #region get

        /// <summary>
        /// Get list for TagInfo Search
        /// </summary>
        /// <param name="gmModel">TagInfoSearch Model</param>
        /// <returns>IQueryable of TagInfoSearch</returns>
        public IQueryable<TagInfoSearch> GetListForTagInfoSearch(TagInfoSearch gmModel)
        {
            List<string> listStatus = new List<string>();
            listStatus.Add(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE);
            if (!gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
            {
                listStatus.Add(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE);
            }
            if (!gmModel.IsShowSuplier)
            {
                gmModel.sPSupplierCD = string.Empty;
            }

            string warehouseCD = UserSession.Session.WarehouseCD;
            return from iH in this.Context.TInventory_H
                   join iD in this.Context.TInventory_D on iH.TagNo equals iD.TagNo
                   join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                   from s in C.DefaultIfEmpty()
                   join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                   join l in this.Context.MLocation on new { key1 = iD.LocationCD, key2 = warehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD }
                   join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                              equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                   where !iH.DeleteFlag
                      && iH.WarehouseCD.Equals(warehouseCD)
                      && (string.IsNullOrEmpty(gmModel.sPTagNo) || iD.TagNo.StartsWith(gmModel.sPTagNo))
                      && (string.IsNullOrEmpty(gmModel.sPSupplierCD) || iH.CustomerCD.StartsWith(gmModel.sPSupplierCD))
                      && (string.IsNullOrEmpty(gmModel.sPProductCD) || iH.ProductCD.StartsWith(gmModel.sPProductCD))
                      && (string.IsNullOrEmpty(gmModel.sPLocationCD) || iD.LocationCD.StartsWith(gmModel.sPLocationCD))
                      && (iD.ShippingNo == null || (!string.IsNullOrEmpty(gmModel.MoveNo) && iD.ShippingNo.Equals(gmModel.MoveNo)))
                      && listStatus.Contains(iD.StockStatus)
                   select new TagInfoSearch
                   {
                       sPTagInfo = iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                       sPSupplierCD = iH.CustomerCD,
                       sPSupplierName = s.CustomerName,
                       sPProductCD = iH.ProductCD,
                       sPProductName = p.ProductName,
                       sPLocationCD = iD.LocationCD,
                       sPLocationName = l.LocationName,
                       sPArrivalDate = iH.ArrivalDate,
                       sPLot1 = iH.Lot1,
                       sPLot2 = iH.Lot2,
                       sPLot3 = iH.Lot3,
                       sPStockStatus = k.Value,
                       IsShowSuplier = gmModel.IsShowSuplier,
                   };
        }

        /// <summary>
        /// Get Product List ISV-Nh1o
        /// </summary>
        /// <param name="gmModel">UserList</param>
        /// <returns>IQueryable of UserModels</returns>
        public IQueryable<InboundDeliveryResult> GetListInboundDeliveryByConditions(InboundDeliveryList gmModel)
        {
            string Lot1 = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.SrhLot1))
            {
                Lot1 = gmModel.SrhLot1;
            }
            string customerCD = string.Empty;
            if (gmModel.IsShowSuplier)
            {
                customerCD = gmModel.SrhSuplierCD ?? string.Empty;
            }
            string dateFrom = gmModel.SrhArrivalDateFrom.DateValue();
            string dateTo = gmModel.SrhArrivalDateTo.DateValue();
            string LOT2From = gmModel.LOT2DateFrom.DateValue();
            string LOT2To = gmModel.LOT2DateTo.DateValue();
            string LOT3From = gmModel.LOT3DateFrom.DateValue();
            string LOT3To = gmModel.LOT3DateTo.DateValue();

            IQueryable<InboundDeliveryResult> list = from iH in this.Context.TInventory_H
                                                        join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                        join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                        join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                        from cu in C.DefaultIfEmpty()
                                                        where (gmModel.IncludeDeleteData || !iH.DeleteFlag)
                                                            && (!gmModel.NotPrintingDataOnly || !(bool)iD.TagPrintFlag)
                                                            && (string.IsNullOrEmpty(dateFrom) || iH.ArrivalDate.CompareTo(dateFrom) >= 0)
                                                            && (string.IsNullOrEmpty(dateTo) || iH.ArrivalDate.CompareTo(dateTo) <= 0)
                                                            && (string.IsNullOrEmpty(customerCD) || iH.CustomerCD.Equals(customerCD))
                                                            && (string.IsNullOrEmpty(gmModel.SrhProductCD) || iH.ProductCD.Trim().Equals(gmModel.SrhProductCD))
                                                            && (string.IsNullOrEmpty(Lot1) || iH.Lot1.Trim().ToUpper().Contains(Lot1.ToUpper()))
                                                            && (string.IsNullOrEmpty(LOT2From) || iH.Lot2.CompareTo(LOT2From) >= 0)
                                                            && (string.IsNullOrEmpty(LOT2To) || iH.Lot2.CompareTo(LOT2To) <= 0)
                                                            && (string.IsNullOrEmpty(LOT3From) || iH.Lot3.CompareTo(LOT3From) >= 0)
                                                            && (string.IsNullOrEmpty(LOT3To) || iH.Lot3.CompareTo(LOT3To) <= 0)
                                                            && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                            && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                                        select new InboundDeliveryResult
                                                        {
                                                            TagNo = iH.TagNo,
                                                            BranchTagNo = iD.BranchTagNo,
                                                            TagInfo = iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                            ArrivalDate = iH.ArrivalDate,
                                                            SuplierCD = iH.CustomerCD,
                                                            SuplierName = cu.CustomerName,
                                                            ProductCD = iH.ProductCD.Trim(),
                                                            ProductName = p.ProductName,
                                                            Lot1 = iH.Lot1,
                                                            LOT2 = iH.Lot2,
                                                            LOT3 = iH.Lot3,
                                                            Printed = (bool)iD.TagPrintFlag,
                                                            DeleteData = iH.DeleteFlag,
                                                            UpdateDate = iD.UpdateDate,
                                                            IsShowSuplier = gmModel.IsShowSuplier
                                                        };

            return list;
            
        }

        /// <summary>
        /// Get Arrival Models by tag No ISV-Nho
        /// </summary>
        /// <param name="tagNo">Tag No</param>
        /// <returns>ArrivalModels</returns>
        public InboundDeliveryModels GetInboundDeliveryByTagNo(string tagNo)
        {
            IQueryable<InboundDeliveryModels> item = from iH in Context.GetTable<TInventory_H>()
                                                     join iD in Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                     join bs in Context.GetTable<TBalanceInStores>() on new { key1 = iD.TagNo, key2 = iD.BranchTagNo } equals new { key1 = bs.TagNo, key2 = (int)bs.BranchTagNo }
                                                     join k in Context.GetTable<MKind_D>() on new { key1 = Constant.MKIND_KINDCD_BALANCE_STATUS, key2 = bs.BalanceStatus, key3 = (byte)UserSession.Session.Language } equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                                                     join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                     join l in this.Context.GetTable<MLocation>() on new { key1 = iD.LocationCD, key2 = iH.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into L
                                                     from Lo in L.DefaultIfEmpty()
                                                     join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                     from cu in C.DefaultIfEmpty()
                                                     where iH.TagNo.Trim().Equals(tagNo)
                                                           && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                           && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                                     select new InboundDeliveryModels
                                                     {
                                                         TagNo = iH.TagNo,
                                                         DisTagNo = iH.TagNo,
                                                         BranchTagNo = iD.BranchTagNo,
                                                         BalanceStatus = bs.BalanceStatus,
                                                         BalanceStatusName = k.Value,
                                                         WarehouseCD = iH.WarehouseCD,
                                                         ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         SuplierCD = iH.CustomerCD,
                                                         SuplierName = cu.CustomerName,
                                                         ProductCD = iH.ProductCD.Trim(),
                                                         ProductName = p.ProductName,
                                                         LocationCD = iD.LocationCD,
                                                         LocationName = Lo.LocationName,
                                                         QuantityPerUnit = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.QuantityPerUnit),
                                                         StoredCost = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.StoredCost),
                                                         UnitQuantity = string.Format(Common.Constant.NUMBER_FORMAT_INT, iH.UnitQuantity),
                                                         TotalCost = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.TotalCost),
                                                         Lot1 = iH.Lot1,
                                                         Lot2 = CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         LOT2Date = new DateControl(iH.Lot2),
                                                         Lot3 = CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         LOT3Date = new DateControl(iH.Lot3),
                                                         Memo = iH.Memo,
                                                         DeleteFlag = iH.DeleteFlag,
                                                         TagPrintFlag = (bool)iD.TagPrintFlag,
                                                         UpdateDate = iD.UpdateDate,
                                                         StockStatus = iD.StockStatus
                                                     };
            InboundDeliveryModels ret = item.FirstOrDefault();

            if (ret != default(InboundDeliveryModels))
            {
                if (item.All(m => (bool)m.TagPrintFlag))
                {
                    ret.TagPrintFlag = true;
                }
                else
                {
                    ret.TagPrintFlag = false;
                }

                ret.UpdateDate = this.Context.GetTable<TInventory_D>().Where(m => m.TagNo.Equals(ret.TagNo) && m.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)).Select(m => m.UpdateDate).Max();
                ret.isNotArr = this.Context.GetTable<TInventory_D>().Any(m => m.TagNo.Equals(ret.TagNo) && !m.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE));
            }
            return ret;
        }

        /// <summary>
        /// Get list by TagNo ISV-Nho
        /// </summary>
        /// <param name="tagNo">TagNo</param>
        /// <returns>List TInventory</returns>
        public TInventory_H GetByTagNo(string tagNo)
        {
            return (from i in this.Context.GetTable<TInventory_H>()
                    where i.TagNo.Trim().Equals(tagNo)
                          && i.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                    select i).SingleOrDefault();
        }

        /// <summary>
        /// Get MoveIndicationDetailGrid By TagInfo
        /// ISV-Nho
        /// </summary>
        /// <param name="tagInfo">TagInfo</param>
        /// <returns>MoveIndicationDetailGrid</returns>
        public MoveIndicationDetailGrid GetMoveIndiDetailGridByTagInfo(string tagInfo)
        {
            return (from iD in this.Context.TInventory_D
                    join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                    join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                    join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                               equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                    where !iH.DeleteFlag
                       && (iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0')).Equals(tagInfo)
                       && iH.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                    select new MoveIndicationDetailGrid
                    {
                        txt_TagInfo = tagInfo,
                        txt_LocationCD = iD.LocationCD ?? string.Empty,
                        txt_ProductCD = iH.ProductCD,
                        txt_ProductName = p.ProductName,
                        txt_ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                        txt_Lot1 = iH.Lot1 ?? string.Empty,
                        txt_LOT2 = CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                        txt_LOT3 = CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                        StockStatus = iD.StockStatus,
                        txt_StockStatusDisp = k.Value,
                    }).SingleOrDefault();
        }

        #region loc

        /// <summary>
        /// Get List StockInquiry By Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel"></param>
        /// <param name="ViewBranchTagNo"></param>
        /// <returns></returns>
        public IQueryable<StockInquiryResults> GetListStockInquiryByConditions(StockInquiryList gmModel, bool groupBranchTagNo)
        {
            if (groupBranchTagNo)
            {
                return GetListForStockInquiryGroup(gmModel);
            }
            return GetListForStockInquiryBranch(gmModel);
        }

        /// <summary>
        /// Get data for StockInquiry Group
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <returns>list of GroupListDetail</returns>
        public List<GroupListDetail> GetDetailForStockInquiryGroup(string tagNo)
        {
            IQueryable<GroupListDetail> items = from iH in this.Context.GetTable<TInventory_H>()
                                                join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus } equals new { key1 = k.KindCD, key2 = k.DataCD }
                                                join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                from cu in C.DefaultIfEmpty()
                                                where !iH.DeleteFlag
                                                        && iH.TagNo.Equals(tagNo)
                                                        && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                        && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                                        && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                                        && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                                        && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                        && k.Language.Equals(UserSession.Session.Language)
                                                select new GroupListDetail
                                                {
                                                    TagNo = iH.TagNo,
                                                    BranchTagNo = iD.BranchTagNo.ToString(),
                                                    BranchTagNoDisp = iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                    SuplierCD = iH.CustomerCD,
                                                    SuplierName = cu.CustomerName,
                                                    LocationCD = iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? iD.LocationCD : string.Empty,
                                                    ProductCD = iH.ProductCD.Trim(),
                                                    ProductName = p.ProductName,
                                                    ArrivalDate = Utility.CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                    UnitQuantity = iH.UnitQuantity.ToString(),
                                                    TotalCost = iH.TotalCost.ToString(),
                                                    LOT1 = iH.Lot1,
                                                    LOT2 = iH.Lot2,
                                                    LOT3 = iH.Lot3,
                                                    StoredDate = iD.StoredDate,
                                                    StockStatus = iD.StockStatus,
                                                    StockStatusDisp = k.Value,
                                                    Memo = iH.Memo,
                                                    IsCanEdit = (iD.StockStatus == Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE || iD.StockStatus == Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) && iD.ShippingNo == null,
                                                };
            return items.ToList();
        }

        /// <summary>
        /// Get Max UpdateDate For StockInquiry Group
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo">TagNo</param>
        /// <returns>UpdateDate</returns>
        public string GetMaxUpdateDateForStockInquiryGroup(string tagNo)
        {
            string updateDate = (from iH in this.Context.GetTable<TInventory_H>()
                                 join iD in this.Context.TInventory_D on iH.TagNo equals iD.TagNo
                                 where !iH.DeleteFlag && iH.TagNo.Equals(tagNo)
                                     && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                 select iD.UpdateDate).Max();

            return updateDate;
        }

        /// <summary>
        /// Get data for StockInquiry Branch
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <returns>StockInquiryBranchModels</returns>
        public StockInquiryBranchModels GetDetailForStockInquiryBranch(string tagNo, string branchTagNo)
        {
            int branchTagNoInt;
            int.TryParse(branchTagNo, out branchTagNoInt);
            IQueryable<StockInquiryBranchModels> item = from iH in this.Context.GetTable<TInventory_H>()
                                                        join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                        join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus } equals new { key1 = k.KindCD, key2 = k.DataCD }
                                                        join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                        join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                        from cu in C.DefaultIfEmpty()
                                                        where !iH.DeleteFlag
                                                                && iH.TagNo.Trim().Equals(tagNo)
                                                                && iD.BranchTagNo == branchTagNoInt
                                                                && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                                && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                                                && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                                                && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                                                && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                                && k.Language.Equals(UserSession.Session.Language)
                                                        select new StockInquiryBranchModels
                                                        {
                                                            TagNoDisp = iH.TagNo + '-' + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                            TagNo = iH.TagNo,
                                                            BranchTagNo = iD.BranchTagNo.ToString(),
                                                            SuplierCD = iH.CustomerCD,
                                                            SuplierName = cu.CustomerName,
                                                            LocationCD = iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? iD.LocationCD : string.Empty,
                                                            ProductCD = iH.ProductCD.Trim(),
                                                            ProductName = p.ProductName,
                                                            ArrivalDate = Utility.CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            StoredDate = Utility.CommonUtil.ParseDate(iD.StoredDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            UnitQuantity = "1",
                                                            TotalCost = iH.StoredCost.ToString(),
                                                            LOT1 = iH.Lot1,
                                                            LOT2 = Utility.CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            LOT3 = Utility.CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            StockStatus = iD.StockStatus,
                                                            StockStatusDisp = k.Value,
                                                            Memo = iH.Memo,
                                                            UpdateDate = iD.UpdateDate,
                                                            canEditStatus = (iD.StockStatus == Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE || iD.StockStatus == Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) && iD.ShippingNo == null,
                                                        };
            return item.SingleOrDefault<StockInquiryBranchModels>();
        }

        /// <summary>
        /// Get data by primary key
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <returns>TInventory_H</returns>
        public TInventory_H GetByPK(string tagNo)
        {
            IQueryable<TInventory_H> item = from i in this.Context.GetTable<TInventory_H>()
                                            where !i.DeleteFlag
                                                  && i.TagNo.Equals(tagNo)
                                            select i;

            return item.SingleOrDefault<TInventory_H>();
        }

        /// <summary>
        /// Get List StockInquiry Group By Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        private IQueryable<StockInquiryResults> GetListForStockInquiryGroup(StockInquiryList gmModel)
        {
            string productName = gmModel.txt_ProductName;
            if (string.IsNullOrEmpty(productName))
            {
                productName = string.Empty;
            }
            string Lot1 = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.txt_LOT1))
            {
                Lot1 = gmModel.txt_LOT1;
            }
            string customerCD = string.Empty;
            if (gmModel.IsShowSuplier)
            {
                if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
                {
                    customerCD = gmModel.txt_SuplierCD ?? string.Empty;
                }
                else
                {
                    customerCD = UserSession.Session.LoginInfo.User.CustomerCD;
                }
            }
            string storedDateFrom = gmModel.txt_StoredDateFrom.DateValue();
            string storedDateTo = gmModel.txt_StoredDateTo.DateValue();
            string LOT2From = gmModel.txt_LOT2From.DateValue();
            string LOT2To = gmModel.txt_LOT2To.DateValue();
            string LOT3From = gmModel.txt_LOT3From.DateValue();
            string LOT3To = gmModel.txt_LOT3To.DateValue();
            string locationCDFrom = (gmModel.txtLocationCDFrom ?? string.Empty).Trim();
            string locationCDTo = (gmModel.txtLocationCDTo ?? string.Empty).Trim();
            bool noInputLocation = String.IsNullOrEmpty(gmModel.txtLocationCDFrom) && String.IsNullOrEmpty(gmModel.txtLocationCDTo);

            IQueryable<StockInquiryResults> list = from iH in this.Context.GetTable<TInventory_H>()
                                                   join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                   join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                   join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                   from cu in C.DefaultIfEmpty()
                                                   where !iH.DeleteFlag
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                                   && (string.IsNullOrEmpty(gmModel.txt_TagNo) || iH.TagNo.Equals(gmModel.txt_TagNo))
                                                   && (string.IsNullOrEmpty(customerCD) || iH.CustomerCD.Equals(customerCD))
                                                   && (string.IsNullOrEmpty(gmModel.txt_ProductCD) || iH.ProductCD.Equals(gmModel.txt_ProductCD))
                                                   && (string.IsNullOrEmpty(productName) || p.ProductName.ToUpper().Contains(productName.ToUpper()))
                                                   && (string.IsNullOrEmpty(gmModel.txt_CategoryCD) || p.CategoryCD.Equals(gmModel.txt_CategoryCD))
                                                   && (string.IsNullOrEmpty(locationCDFrom) || iD.LocationCD.CompareTo(locationCDFrom) >= 0)
                                                   && (string.IsNullOrEmpty(locationCDTo) || iD.LocationCD.CompareTo(locationCDTo) <= 0)
                                                   && (string.IsNullOrEmpty(storedDateFrom) || iD.StoredDate.CompareTo(storedDateFrom) >= 0)
                                                   && (string.IsNullOrEmpty(storedDateTo) || iD.StoredDate.CompareTo(storedDateTo) <= 0)
                                                   && (string.IsNullOrEmpty(Lot1) || iH.Lot1.ToUpper().Contains(Lot1.ToUpper()))
                                                   && (string.IsNullOrEmpty(LOT2From) || iH.Lot2.CompareTo(LOT2From) >= 0)
                                                   && (string.IsNullOrEmpty(LOT2To) || iH.Lot2.CompareTo(LOT2To) <= 0)
                                                   && (string.IsNullOrEmpty(LOT3From) || iH.Lot3.CompareTo(LOT3From) >= 0)
                                                   && (string.IsNullOrEmpty(LOT3To) || iH.Lot3.CompareTo(LOT3To) <= 0)
                                                   && (string.IsNullOrEmpty(gmModel.ddl_Status) || iD.StockStatus.Equals(gmModel.ddl_Status))
                                                   && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                   && (noInputLocation || iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                                                   group new { i = iH, p, c = cu } by new { iH.TagNo } into d
                                                   orderby d.Key.TagNo
                                                   select new StockInquiryResults
                                                   {
                                                       TagNo = d.Key.TagNo,
                                                       TagNoDisp = d.Key.TagNo,
                                                       SuplierCD = d.Min(e => e.i.CustomerCD),
                                                       SuplierName = d.Min(e => e.c.CustomerName),
                                                       ProductCD = d.Min(e => e.i.ProductCD),
                                                       ProductName = d.Min(e => e.p.ProductName),
                                                       ArrivalDate = d.Min(e => e.i.ArrivalDate),
                                                       Quantity = d.Count(),
                                                       //Quantity = this.Context.TInventory_D.Where(m => m.TagNo.Equals(d.Key.TagNo) && !m.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY)
                                                       //         && !m.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE) && !m.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP) 
                                                       //         && !m.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY)).Count(),
                                                       LOT1 = d.Min(e => e.i.Lot1),
                                                       LOT2 = d.Min(e => e.i.Lot2),
                                                       LOT3 = d.Min(e => e.i.Lot3),
                                                       IsShowSuplier = gmModel.IsShowSuplier,
                                                   };
            return list;
        }

        /// <summary>
        /// Get List StockInquiry Branch By Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <returns>IQueryable of StockInquiryResults</returns>
        private IQueryable<StockInquiryResults> GetListForStockInquiryBranch(StockInquiryList gmModel)
        {
            string productName = gmModel.txt_ProductName;
            if (string.IsNullOrEmpty(productName))
            {
                productName = string.Empty;
            }
            string Lot1 = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.txt_LOT1))
            {
                Lot1 = gmModel.txt_LOT1;
            }
            string tagNo = string.Empty;
            string branchTagNo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.txt_TagNo))
            {
                string[] array = gmModel.txt_TagNo.Split(Constant.HYPHEN_CHAR);
                if (array.Length == 2)
                {
                    tagNo = array[0];
                    branchTagNo = array[1];
                }
                else
                {
                    tagNo = gmModel.txt_TagNo;
                }
            }

            string customerCD = string.Empty;
            if (gmModel.IsShowSuplier)
            {
                if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
                {
                    customerCD = gmModel.txt_SuplierCD ?? string.Empty;
                }
                else
                {
                    customerCD = UserSession.Session.LoginInfo.User.CustomerCD;
                }
            }

            string storedDateFrom = gmModel.txt_StoredDateFrom.DateValue();
            string storedDateTo = gmModel.txt_StoredDateTo.DateValue();
            string LOT2From = gmModel.txt_LOT2From.DateValue();
            string LOT2To = gmModel.txt_LOT2To.DateValue();
            string LOT3From = gmModel.txt_LOT3From.DateValue();
            string LOT3To = gmModel.txt_LOT3To.DateValue();
            string locationCDFrom = (gmModel.txtLocationCDFrom ?? string.Empty).Trim();
            string locationCDTo = (gmModel.txtLocationCDTo ?? string.Empty).Trim();
            bool noInputLocation = String.IsNullOrEmpty(gmModel.txtLocationCDFrom) && String.IsNullOrEmpty(gmModel.txtLocationCDTo);

            IQueryable<StockInquiryResults> list = from iH in this.Context.GetTable<TInventory_H>()
                                                   join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                   join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                   join c in this.Context.MCustomer on iH.CustomerCD equals c.CustomerCD into C
                                                   from cu in C.DefaultIfEmpty()
                                                   where !iH.DeleteFlag
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                                   && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                                   && (string.IsNullOrEmpty(tagNo) || iH.TagNo.Equals(tagNo))
                                                   && (string.IsNullOrEmpty(branchTagNo) || iD.BranchTagNo.Equals(branchTagNo))
                                                   && (string.IsNullOrEmpty(customerCD) || iH.CustomerCD.Equals(customerCD))
                                                   && (string.IsNullOrEmpty(gmModel.txt_ProductCD) || iH.ProductCD.Equals(gmModel.txt_ProductCD))
                                                   && (string.IsNullOrEmpty(productName) || p.ProductName.ToUpper().Contains(productName.ToUpper()))
                                                   && (string.IsNullOrEmpty(gmModel.txt_CategoryCD) || p.CategoryCD.Equals(gmModel.txt_CategoryCD))
                                                   && (string.IsNullOrEmpty(locationCDFrom) || iD.LocationCD.CompareTo(locationCDFrom) >= 0)
                                                   && (string.IsNullOrEmpty(locationCDTo) || iD.LocationCD.CompareTo(locationCDTo) <= 0)
                                                   && (string.IsNullOrEmpty(storedDateFrom) || iD.StoredDate.CompareTo(storedDateFrom) >= 0)
                                                   && (string.IsNullOrEmpty(storedDateTo) || iD.StoredDate.CompareTo(storedDateTo) <= 0)
                                                   && (string.IsNullOrEmpty(Lot1) || iH.Lot1.ToUpper().Contains(Lot1.ToUpper()))
                                                   && (string.IsNullOrEmpty(LOT2From) || iH.Lot2.CompareTo(LOT2From) >= 0)
                                                   && (string.IsNullOrEmpty(LOT2To) || iH.Lot2.CompareTo(LOT2To) <= 0)
                                                   && (string.IsNullOrEmpty(LOT3From) || iH.Lot3.CompareTo(LOT3From) >= 0)
                                                   && (string.IsNullOrEmpty(LOT3To) || iH.Lot3.CompareTo(LOT3To) <= 0)
                                                   && (string.IsNullOrEmpty(gmModel.ddl_Status) || iD.StockStatus.Equals(gmModel.ddl_Status))
                                                   && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                   && (noInputLocation || iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                                                   orderby iH.TagNo, iD.BranchTagNo
                                                   select new StockInquiryResults
                                                   {
                                                       TagNo = iH.TagNo,
                                                       BranchTagNo = iD.BranchTagNo.ToString(),
                                                       TagNoDisp = iH.TagNo + '-' + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                       SuplierCD = iH.CustomerCD,
                                                       SuplierName = cu.CustomerName,
                                                       ProductCD = iH.ProductCD,
                                                       ProductName = p.ProductName,
                                                       LocationCD = iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? iD.LocationCD : string.Empty,
                                                       ArrivalDate = iH.ArrivalDate,
                                                       StoredDate = iD.StoredDate,
                                                       LOT1 = iH.Lot1,
                                                       LOT2 = iH.Lot2,
                                                       LOT3 = iH.Lot3,
                                                       StockStatus = iD.StockStatus,
                                                       StockStatusName = (from k in this.Context.GetTable<MKind_D>()
                                                                          where (k.KindCD.Equals(InventoryManagement.Common.Constant.MKIND_KINDCD_STOCK_STATUS)
                                                                                  && k.DataCD.Equals(iD.StockStatus)
                                                                                  && k.Language.Equals(UserSession.Session.Language))
                                                                          select new { k.Value }
                                                                               ).FirstOrDefault().Value,
                                                       IsShowSuplier = gmModel.IsShowSuplier,
                                                   };
            return list;
        }

        /// <summary>
        /// Get List StockInquiry Group By Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<StockInquiryGroupCSV> GetListStockInquiryGroupCSV()
        {
            IQueryable<StockInquiryGroupCSV> list = from iH in this.Context.GetTable<TInventory_H>()
                                                    join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                    join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                    where !iH.DeleteFlag
                                                    && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                    && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                    group new { i = iH, p } by new { iH.TagNo } into grp
                                                    orderby grp.Key.TagNo
                                                    select new StockInquiryGroupCSV
                                                    {
                                                        TagNo = grp.Key.TagNo,
                                                        ProductCD = grp.Min(e => e.i.ProductCD),
                                                        ProductName = grp.Min(e => e.p.ProductName),
                                                        //LocationCD = d.Min(e => e.i.LocationCD),
                                                        UnitQuantity = grp.Min(e => e.i.UnitQuantity.ToString()),
                                                        TotalCost = grp.Sum(e => e.i.UnitQuantity * e.i.StoredCost).ToString(),
                                                        //StoredDate = d.Min(e => e.i.StoredDate),
                                                        LOT1 = grp.Min(e => e.i.Lot1),
                                                        LOT2 = grp.Min(e => e.i.Lot2),
                                                        LOT3 = grp.Min(e => e.i.Lot3),
                                                        ArrivalDate = grp.Min(e => e.i.ArrivalDate)
                                                        //Memo = grp.Min(e => e.i.Memo)
                                                    };
            return list;
        }

        /// <summary>
        /// Get List StockInquiry Branch By Conditions
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<StockInquiryBranchCSV> GetListStockInquiryBranchCSV()
        {
            IQueryable<StockInquiryBranchCSV> list = from iH in this.Context.GetTable<TInventory_H>()
                                                     join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                     join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                     where !iH.DeleteFlag
                                                     && (!iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                     && iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                     orderby iH.TagNo, iD.BranchTagNo
                                                     select new StockInquiryBranchCSV
                                                     {
                                                         TagNo = iH.TagNo,
                                                         //BranchTagNo = iD.BranchTagNo.ToString(),
                                                         //TagNoDisp = iH.TagNo + '-' + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                         BranchTagNo = iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                         ProductCD = iH.ProductCD,
                                                         ProductName = p.ProductName,
                                                         LocationCD = iD.LocationCD,
                                                         ArrivalDate = iH.ArrivalDate,
                                                         //Quantity    = i.UnitQuantity.ToString(),
                                                         TotalCost = iH.StoredCost.ToString(),
                                                         StoredDate = iD.StoredDate,
                                                         LOT1 = iH.Lot1,
                                                         LOT2 = iH.Lot2,
                                                         LOT3 = iH.Lot3,
                                                         //Memo = iH.Memo,
                                                         //StockStatus = iD.StockStatus,
                                                         StockStatusName = (from k in this.Context.GetTable<MKind_D>()
                                                                            where (k.KindCD.Equals(InventoryManagement.Common.Constant.MKIND_KINDCD_STOCK_STATUS)
                                                                                    && k.DataCD.Equals(iD.StockStatus)
                                                                                    && k.Language.Equals(UserSession.Session.Language))
                                                                            select new { k.Value }
                                                                                 ).FirstOrDefault().Value
                                                     };
            return list;
        }

        #endregion

        #region Hung

        /// <summary>
        /// Get data for Receipt
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <returns>GoodsReceiptInspectionModels</returns>
        public GoodsReceiptInspectionModels GetForReceipt(string tagNo, int branchTagNo)
        {
            IQueryable<GoodsReceiptInspectionModels> item = from iH in this.Context.GetTable<TInventory_H>()
                                                            join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                            join p in this.Context.GetTable<MProduct>() on iH.ProductCD equals p.ProductCD
                                                            where !iH.DeleteFlag
                                                                   && iH.TagNo.Equals(tagNo)
                                                                   && iD.BranchTagNo.Equals(branchTagNo)
                                                            select new GoodsReceiptInspectionModels
                                                            {
                                                                txt_TagNo = iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                                //txt_BranchTagNo = iD.BranchTagNo.ToString().PadLeft(Constant.TINVENTORY_BRANCH_TAG_NO_LEN, '0') + Constant.SLASH + iH.UnitQuantity.ToString().PadLeft(Constant.TINVENTORY_BRANCH_TAG_NO_LEN, '0'),
                                                                hid_BranchTagNo = iD.BranchTagNo,
                                                                //txt_ProductCD = iH.ProductCD,
                                                                //txt_ProductName = p.ProductName,
                                                                //txt_LOT1 = iH.Lot1,
                                                                //txt_LOT2 = CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                                //txt_LOT3 = CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                                //txt_Memo = iH.Memo,
                                                                hid_UpdateDate = iD.UpdateDate,
                                                            };
            return item.SingleOrDefault();
        }

        /// <summary>
        /// Get list OutboundDeliveryIndication Detail (Search)
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailResult> GetListShippingInstructionDetail(OutboundDeliveryIndicationDetailGrid gmModel)
        {

            var result1 = from h in this.Context.TInventory_H
                          join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                          join l in this.Context.MLocation on new { key1 = h.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD } into L
                          from lo in L.DefaultIfEmpty()
                          where
                               !lo.IssueProhibitionFlag &&
                               h.ProductCD.Equals(gmModel.txt_ProductCD) &&
                               h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                               (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || (string.IsNullOrEmpty(gmModel.txt_ShipNo) || d.ShippingNo.Equals(gmModel.txt_ShipNo)))
                          group new { d, h } by new { d.TagNo, d.LocationCD } into grp

                          select new OutboundDeliveryIndicationDetailResult()
                          {
                              Reserve = "",
                              NumBoxes = grp.Count(),
                              PickingQuantity = grp.Count(m => m.d.PickingFlag.Value),
                              TagNo = grp.Key.TagNo,
                              LocationCD = grp.Key.LocationCD,
                              ArrivalDate = grp.Min(m => m.h.ArrivalDate),
                              Lot1 = grp.Min(m => m.h.Lot1),
                              Lot2 = grp.Min(m => m.h.Lot2),
                              Lot3 = grp.Min(m => m.h.Lot3),
                              StoredDate = grp.Min(m => m.d.StoredDate),
                              SeqNum = gmModel.SeqNum
                          };
            //return result1;
            return result1.Where(m => ((m.NumBoxes - (this.Context.IsNullInt(this.Context.TReserve
                                                                        .Where(t => t.TagNo.Equals(m.TagNo) && t.LocationCD.Equals(m.LocationCD) && !t.ShipNo.Equals(gmModel.txt_ShipNo))
                                                                        .Sum(s => s.RemainQuantity), 0)
                                                     )
                //+
                //(this.Context.TReserve
                //                   .Where(t => t.TagNo.Equals(m.TagNo) && t.LocationCD.Equals(m.LocationCD) && (!string.IsNullOrEmpty(gmModel.txt_ShipNo) || t.ShipNo.Equals(gmModel.txt_ShipNo)))
                //                   .Sum(s => s.Quantity) == null ?
                //                                                   0 :
                //                                                   this.Context.TReserve
                //                                                                       .Where(t => t.TagNo.Equals(m.TagNo) && t.LocationCD.Equals(m.LocationCD) && (!string.IsNullOrEmpty(gmModel.txt_ShipNo) || t.ShipNo.Equals(gmModel.txt_ShipNo)))
                //                                                                       .Sum(s => s.Quantity)
                //)
                                       ) > 0));

        }

        #endregion

        /// <summary>
        /// Get list OutboundDeliveryIndication Detail (Search)
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailResult> GetListShippingInstructionDetailNew(OutboundDeliveryIndicationDetail gmModel)
        {
            string dateFrom = gmModel.ctr_ArrivalDateFrom.DateValue();
            string dateTo = gmModel.ctr_ArrivalDateTo.DateValue();

            string LOT2From = gmModel.ctr_LOT2DateFrom.DateValue();
            string LOT2To = gmModel.ctr_LOT2DateTo.DateValue();

            string LOT3From = gmModel.ctr_LOT3DateFrom.DateValue();
            string LOT3To = gmModel.ctr_LOT3DateTo.DateValue();
            string shipNo = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.ShipNo))
            {
                shipNo = gmModel.ShipNo;
            }

            var result1 = from h in this.Context.TInventory_H
                          join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                          join l in this.Context.MLocation on new { key1 = UserSession.Session.LoginInfo.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                          where
                               h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                               h.ProductCD.Equals(gmModel.txt_ProductCD) &&
                               (
                                   (
                                       !l.IssueProhibitionFlag &&
                                       (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)) &&
                                       (string.IsNullOrEmpty(gmModel.txt_TagNo) || h.TagNo.Equals(gmModel.txt_TagNo)) &&
                                       (string.IsNullOrEmpty(dateFrom) || h.ArrivalDate.CompareTo(dateFrom) >= 0) &&
                                       (string.IsNullOrEmpty(dateTo) || h.ArrivalDate.CompareTo(dateTo) <= 0) &&
                                       (string.IsNullOrEmpty(gmModel.txt_LOT1) || h.Lot1.Contains(gmModel.txt_LOT1)) &&
                                       (string.IsNullOrEmpty(LOT2From) || h.Lot2.CompareTo(LOT2From) >= 0) &&
                                       (string.IsNullOrEmpty(LOT2To) || h.Lot2.CompareTo(LOT2To) <= 0) &&
                                       (string.IsNullOrEmpty(LOT3From) || h.Lot3.CompareTo(LOT3From) >= 0) &&
                                       (string.IsNullOrEmpty(LOT3To) || h.Lot3.CompareTo(LOT3To) <= 0) &&
                                       (d.ShippingNo == null)
                                   )
                                   ||
                                   (
                                        !string.IsNullOrEmpty(shipNo) && this.Context.TInventory_D.Any(m => m.TagNo.Equals(d.TagNo)
                                        && m.BranchTagNo.Equals(d.BranchTagNo)
                                        && m.ShippingNo.Equals(shipNo)
                                        && (bool)m.PickingFlag)
                                   )
                                )
                          group new { d, h } by new { d.TagNo, d.LocationCD } into grp

                          select new OutboundDeliveryIndicationDetailResult()
                          {
                              Reserve = "",
                              NumBoxes = grp.Count(m => m.d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)),
                              PickingQuantity = grp.Count(m => m.d.PickingFlag.Value),
                              TagNo = grp.Key.TagNo,
                              LocationCD = grp.Key.LocationCD,
                              ArrivalDate = grp.Min(m => m.h.ArrivalDate),
                              Lot1 = grp.Min(m => m.h.Lot1),
                              Lot2 = grp.Min(m => m.h.Lot2),
                              Lot3 = grp.Min(m => m.h.Lot3),
                              StoredDate = grp.Min(m => m.d.StoredDate),
                              SeqNum = gmModel.SeqNum
                          };

            return result1;

        }

        /// <summary>
        /// Get list Move Indication Move All
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<MoveIndicationAllResults> GetListForMoveAll(MoveIndicationAll gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                return null;
            }

            List<string> lstStatus = new List<string>();
            lstStatus.Add(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE);
            if (!gmModel.ddl_MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
            {
                lstStatus.Add(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE);
            }

            IQueryable<MoveIndicationAllResults> ret = from iH in this.Context.TInventory_H
                                                       join iD in this.Context.TInventory_D on iH.TagNo equals iD.TagNo
                                                       join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                                                       join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                                                                  equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                                                       where
                                                             iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                          && iD.LocationCD.Equals(gmModel.txt_LocationCDFrom)
                                                          && lstStatus.Contains(iD.StockStatus)
                                                       select new MoveIndicationAllResults()
                                                       {
                                                           TagInfo = iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                           ProductCD = iH.ProductCD,
                                                           ProductName = p.ProductName,
                                                           ArrivalDate = iH.ArrivalDate,
                                                           Lot1 = iH.Lot1,
                                                           LOT2 = iH.Lot2,
                                                           LOT3 = iH.Lot3,
                                                           StockStatus = iD.StockStatus,
                                                           StockStatusDisp = k.Value,
                                                           SeqNum = gmModel.SeqNum,

                                                       };
            return ret;
        }

        /// <summary>
        /// Get list Move Indication Move All
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<MoveIndicationAllResults> GetListReceiptDefectForMoveAll(MoveIndicationAll gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                return null;
            }

            IQueryable<MoveIndicationAllResults> ret = from iH in this.Context.TInventory_H
                                                       join iD in this.Context.TInventory_D on iH.TagNo equals iD.TagNo
                                                       join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                                                                  equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                                                       where
                                                             iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                          && iD.LocationCD.Equals(gmModel.txt_LocationCDFrom)
                                                          && iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
                                                          && iD.ShippingNo == null
                                                       select new MoveIndicationAllResults()
                                                       {
                                                           TagInfo = iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                           ProductCD = iH.ProductCD,
                                                           ArrivalDate = iH.ArrivalDate,
                                                           Lot1 = iH.Lot1,
                                                           LOT2 = iH.Lot2,
                                                           LOT3 = iH.Lot3,
                                                           StockStatus = iD.StockStatus,
                                                           StockStatusDisp = k.Value,
                                                           SeqNum = gmModel.SeqNum,

                                                       };
            return ret;
        }

        /// <summary>
        /// Get list Move Indication Move All
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<MoveIndicationAllResults> GetListReceiptForMoveAll(MoveIndicationAll gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                return null;
            }

            IQueryable<MoveIndicationAllResults> ret = from iH in this.Context.TInventory_H
                                                       join iD in this.Context.TInventory_D on iH.TagNo equals iD.TagNo
                                                       join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                                                                  equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                                                       where
                                                            iH.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                         && iD.LocationCD.Equals(gmModel.txt_LocationCDFrom)
                                                         && (iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                                         && iD.ShippingNo == null
                                                       select new MoveIndicationAllResults()
                                                       {
                                                           TagInfo = iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                           ProductCD = iH.ProductCD,
                                                           ArrivalDate = iH.ArrivalDate,
                                                           Lot1 = iH.Lot1,
                                                           LOT2 = iH.Lot2,
                                                           LOT3 = iH.Lot3,
                                                           StockStatus = iD.StockStatus,
                                                           StockStatusDisp = k.Value,
                                                           SeqNum = gmModel.SeqNum,
                                                       };
            return ret;
        }

        /// <summary>
        /// Get list OutboundDeliveryIndication Detail (Search)
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailResult> GetListShippingInstructionDetailNewAdd(TReserve item, string productCD, int seqNum)
        {
            var result1 = from h in this.Context.TInventory_H
                          join d in this.Context.TInventory_D on new { key1 = h.TagNo, key2 = item.LocationCD } equals new { key1 = d.TagNo, key2 = d.LocationCD } into D
                          from iD in D.DefaultIfEmpty()
                          where
                               h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                               h.TagNo.Equals(item.TagNo) &&
                               h.ProductCD.Equals(productCD)
                          group new { iD, h } by new { h.TagNo } into grp

                          select new OutboundDeliveryIndicationDetailResult()
                          {
                              Reserve = item.Quantity.ToString(),
                              NumBoxes = item.Quantity - item.RemainQuantity,
                              PickingQuantity = 0,
                              PickedFlag = false,
                              TagNo = grp.Key.TagNo,
                              LocationCD = item.LocationCD,
                              ArrivalDate = grp.Min(m => m.h.ArrivalDate),
                              Lot1 = grp.Min(m => m.h.Lot1),
                              Lot2 = grp.Min(m => m.h.Lot2),
                              Lot3 = grp.Min(m => m.h.Lot3),
                              StoredDate = grp.Min(m => m.iD.StoredDate),
                              SeqNum = seqNum
                          };

            return result1;

        }

        /// <summary>
        /// Get list OutboundDeliveryIndication Detail (Search)
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailResult> GetListShippingInstructionDetailNewAddOLD(TReserve item, string productCD, int seqNum)
        {
            var result1 = from h in this.Context.TInventory_H
                          join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                          join l in this.Context.MLocation on new { key1 = h.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD } into L
                          from lo in L.DefaultIfEmpty()
                          where
                               h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                               (d.TagNo.Equals(item.TagNo) && d.LocationCD.Equals(item.LocationCD)) &&
                               h.ProductCD.Equals(productCD)
                          group new { d, h } by new { d.TagNo, d.LocationCD } into grp

                          select new OutboundDeliveryIndicationDetailResult()
                          {
                              Reserve = item.Quantity.ToString(),
                              NumBoxes = item.Quantity - item.RemainQuantity,
                              PickingQuantity = 0,
                              PickedFlag = false,
                              TagNo = grp.Key.TagNo,
                              LocationCD = grp.Key.LocationCD,
                              ArrivalDate = grp.Min(m => m.h.ArrivalDate),
                              Lot1 = grp.Min(m => m.h.Lot1),
                              Lot2 = grp.Min(m => m.h.Lot2),
                              Lot3 = grp.Min(m => m.h.Lot3),
                              StoredDate = grp.Min(m => m.d.StoredDate),
                              SeqNum = seqNum
                          };

            return result1;

        }

        #endregion

        #region Private

        #endregion

        #region Check

        /// <summary>
        /// Check data changed ISV-Nho
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        public bool CheckDataChanged(InboundDeliveryModels gmModel)
        {
            return Context.GetTable<TInventory_D>().Any(iH => iH.TagNo.Equals(gmModel.TagNo)
                                               && iH.UpdateDate.CompareTo(gmModel.UpdateDate) > 0);
        }

        /// <summary>
        /// Check Exists
        /// Author : ISV-PHUONG
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool ExistByLocation(string WarehouseCD, string LocationCD)
        {
            var item = from h in this.Context.TInventory_H
                       join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                       where h.DeleteFlag == false
                          && h.WarehouseCD.Equals(WarehouseCD)
                          && d.LocationCD.Equals(LocationCD)
                       select d.BranchTagNo;

            return item.Any();
        }

        /// <summary>
        /// Check Exists
        /// Author : ISV-HUNG
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public int ExistByLocationTo(string productCD, string LocationCDTo, string shipNo)
        {
            int ret = 0;//Not exist
            if (string.IsNullOrEmpty(LocationCDTo))
            {
                LocationCDTo = string.Empty;
            }
            IQueryable<TInventory_D> list = from h in this.Context.TInventory_H
                                            join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                                            join l in this.Context.MLocation on new { key1 = h.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                                            where h.DeleteFlag == false
                                               && h.ProductCD.Equals(productCD)
                                               && (!l.IssueProhibitionFlag)
                                               && h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                                //&& !d.LocationCD.Equals(LocationCDTo)
                                               && (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
                                               ||
                                               (!string.IsNullOrEmpty(shipNo) && d.ShippingNo.Equals(shipNo) && d.PickingFlag.Value))
                                            select d;

            if (list.Count() > 0)
            {
                ret = 1;//Exists
                if (!string.IsNullOrEmpty(LocationCDTo))
                {
                    bool isAllInLocation = true;
                    foreach (var item in list)
                    {
                        if (!item.LocationCD.Equals(LocationCDTo))
                        {
                            isAllInLocation = false;
                            break;
                        }
                    }
                    if (isAllInLocation)
                    {
                        ret = 2;//Exists All In Location
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// Check Exists
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="productCD">Product code</param>
        /// <param name="shipNo">shipno</param>
        /// <returns>TRUE: Exist, FLASE: Not Exist</returns>
        public bool ExistByProductCD(string productCD, string shipNo)
        {
            var stocklist = from ih in this.Context.TInventory_H
                            join id in this.Context.TInventory_D on new { key1 = ih.TagNo, key2 = ih.WarehouseCD } equals new { key1 = id.TagNo, key2 = UserSession.Session.LoginInfo.WarehouseCD }
                            join l in this.Context.MLocation on new { key1 = ih.WarehouseCD, key2 = id.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                            where (!ih.DeleteFlag)
                                && !l.IssueProhibitionFlag
                                && ih.ProductCD.Equals(productCD)
                                && (id.ShippingNo == null || (!string.IsNullOrEmpty(shipNo) && id.ShippingNo.Equals(shipNo)))
                                && (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || (!string.IsNullOrEmpty(shipNo) && id.ShippingNo.Equals(shipNo) && id.PickingFlag.Value))
                            select id;

            var relist = from ih in this.Context.TInventory_H
                         join re in this.Context.TReserve on new { key1 = ih.WarehouseCD, key2 = ih.TagNo } equals new { key1 = UserSession.Session.LoginInfo.WarehouseCD, key2 = re.TagNo }
                         where (!ih.DeleteFlag)
                            && ih.ProductCD.Equals(productCD)
                            && (string.IsNullOrEmpty(shipNo) || !re.ShipNo.Equals(shipNo))
                         select re;

            var result = from s in stocklist
                         where (stocklist.Count() - Context.IsNullInt(relist.Sum(t => Context.IsNullInt(t.RemainQuantity, 0)), 0)) > 0
                         select s;

            return result.Any();
        }

        /// <summary>
        /// Check Exists for indication
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="productCD"></param>
        /// <returns></returns>
        public bool ExistByProductCDForMoveIndication(string productCD, string moveNo)
        {
            var result1 = from h in this.Context.TInventory_H
                          join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                          join l in this.Context.MLocation on new { key1 = h.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD }
                          where
                                h.DeleteFlag == false
                                && h.ProductCD.Equals(productCD) && !l.IssueProhibitionFlag
                                && h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                                (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ||
                                    (!string.IsNullOrEmpty(moveNo) && d.ShippingNo.Equals(moveNo) && d.PickingFlag.Value)
                                )
                          select h;
            return result1.Any();
        }

        /// <summary>
        /// Check Exist Location Moving
        /// </summary>
        /// <param name="warehouseCD">warehouseCD</param>
        /// <param name="locationCD">locationCD</param>
        /// <returns>TRUE: Exist, FALSE: Not Exist</returns>
        public bool CheckExistLocationMoving(string warehouseCD, string locationCD)
        {
            var temp = from h in this.Context.TInventory_H
                       join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                       join s in this.Context.TShippingInstruction on d.ShippingNo equals s.ShipNo
                       where h.WarehouseCD.Equals(warehouseCD)
                            && d.LocationCD.Equals(locationCD)
                            && !s.ShippingCompleteFlag
                       select d;
            return temp.Any();
        }

        /// <summary>
        /// Check Can Edit Infomation in Stock Inquiry
        /// </summary>
        /// <param name="TagNo">Tag No</param>
        /// <returns></returns>
        public bool IsEditCus(string TagNo)
        {
            return !(this.Context.TReserve.Any(m => m.TagNo.Equals(TagNo))
                || this.Context.TInventory_D.Any(m => m.TagNo.Equals(TagNo)
                                                   && m.ShippingNo != null
                                                   && this.Context.TShippingInstruction.Any(n => n.ShipNo.Equals(m.ShippingNo) && n.DestinationLocationCD == null)));
        }

        #endregion

        #region Print

        /// <summary>
        /// Get Arrival By TagInfo
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="tagInfo">Tag Info</param>
        /// <returns>ArrivalModels</returns>
        public InboundDeliveryModels GetByTagInfo(string tagInfo)
        {
            IQueryable<InboundDeliveryModels> list = from iH in this.Context.GetTable<TInventory_H>()
                                                     join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                     join p in this.Context.GetTable<MProduct>()
                                                        on iH.ProductCD equals p.ProductCD
                                                     join l in this.Context.GetTable<MLocation>()
                                                        on iD.LocationCD equals l.LocationCD into lo
                                                     from loc in lo.DefaultIfEmpty()
                                                     where (!iH.DeleteFlag)
                                                           && (string.IsNullOrEmpty(tagInfo) || (iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0')).Equals(tagInfo))
                                                           && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                                     select new InboundDeliveryModels
                                                     {
                                                         ProductCD = iH.ProductCD.Trim(),
                                                         ProductName = p.ProductName,
                                                         TagNo = iH.TagNo,
                                                         BranchTagNo = iD.BranchTagNo,
                                                         WarehouseCD = iH.WarehouseCD,
                                                         LocationCD = iD.LocationCD,
                                                         LocationName = loc.LocationName,
                                                         QuantityPerUnit = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.QuantityPerUnit),
                                                         StoredCost = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.StoredCost),
                                                         UnitQuantity = string.Format(Common.Constant.NUMBER_FORMAT_INT, iH.UnitQuantity),
                                                         TotalCost = string.Format(Common.Constant.NUMBER_FORMAT_DEC_2, iH.TotalCost),
                                                         ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         Lot1 = iH.Lot1,
                                                         Lot2 = CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         Lot3 = CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         Memo = iH.Memo,
                                                         DeleteFlag = iH.DeleteFlag,
                                                         UpdateDate = iD.UpdateDate,
                                                         TagPrintFlag = (bool)iD.TagPrintFlag
                                                     };
            return list.FirstOrDefault();
        }

        /// <summary>
        /// Get List ArrivalModels By List TagNo From List
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagNos">List Of TagNo</param>
        /// <returns>IQueryable Of ArrivalModels</returns>
        public IQueryable<InboundDeliveryModels> GetListByTagNosFromList(List<string> TagNos)
        {
            IQueryable<InboundDeliveryModels> list = from iH in this.Context.GetTable<TInventory_H>()
                                                     join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                     join p in this.Context.GetTable<MProduct>()
                                                        on iH.ProductCD equals p.ProductCD
                                                     join l in this.Context.GetTable<MLocation>()
                                                        on new { key1 = iD.LocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into lo
                                                     from loc in lo.DefaultIfEmpty()
                                                     where (!iH.DeleteFlag)
                                                           && TagNos.Contains(iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'))
                                                           && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                                     orderby iH.TagNo, iD.BranchTagNo
                                                     select new InboundDeliveryModels
                                                     {
                                                         ProductName = p.ProductName,
                                                         ProductCD = iH.ProductCD.Trim(),
                                                         TagNo = iH.TagNo,
                                                         BranchTagNo = iD.BranchTagNo,
                                                         WarehouseCD = iH.WarehouseCD,
                                                         LocationCD = iD.LocationCD,
                                                         LocationName = loc.LocationName,
                                                         StoredCost = iH.StoredCost.ToString(),
                                                         QuantityPerUnit = iH.QuantityPerUnit.ToString(),
                                                         UnitQuantity = iH.UnitQuantity.ToString(),
                                                         TotalCost = iH.TotalCost.ToString(),
                                                         ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         Lot1 = iH.Lot1,
                                                         Lot2 = iH.Lot2,
                                                         Lot3 = iH.Lot3,
                                                         Memo = iH.Memo,
                                                         DeleteFlag = iH.DeleteFlag,
                                                         UpdateDate = iD.UpdateDate,
                                                         TagPrintFlag = (bool)iD.TagPrintFlag
                                                     };
            return list;
        }

        /// <summary>
        /// Get List ArrivalModels By TagNo For Print From Detail
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagNos">TagNo</param>
        /// <returns>IQueryable Of ArrivalModels</returns>
        public IQueryable<InboundDeliveryModels> GetListByTagNoForPrint(string TagNo)
        {
            IQueryable<InboundDeliveryModels> list = from iH in this.Context.GetTable<TInventory_H>()
                                                     join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                     join p in this.Context.GetTable<MProduct>()
                                                        on iH.ProductCD equals p.ProductCD
                                                     join l in this.Context.GetTable<MLocation>()
                                                        on new { key1 = iD.LocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into lo
                                                     from loc in lo.DefaultIfEmpty()
                                                     where (!iH.DeleteFlag)
                                                           && (string.IsNullOrEmpty(TagNo) || iH.TagNo.Equals(TagNo))
                                                     //&& iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                                     orderby iH.TagNo, iD.BranchTagNo
                                                     select new InboundDeliveryModels
                                                     {
                                                         ProductName = p.ProductName,
                                                         ProductCD = iH.ProductCD.Trim(),
                                                         TagNo = iH.TagNo,
                                                         BranchTagNo = iD.BranchTagNo,
                                                         WarehouseCD = iH.WarehouseCD,
                                                         LocationCD = iD.LocationCD,
                                                         LocationName = loc.LocationName,
                                                         StoredCost = iH.StoredCost.ToString(),
                                                         QuantityPerUnit = iH.QuantityPerUnit.ToString(),
                                                         UnitQuantity = iH.UnitQuantity.ToString(),
                                                         TotalCost = iH.TotalCost.ToString(),
                                                         ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                         Lot1 = iH.Lot1,
                                                         Lot2 = iH.Lot2,
                                                         Lot3 = iH.Lot3,
                                                         Memo = iH.Memo,
                                                         DeleteFlag = iH.DeleteFlag,
                                                         UpdateDate = iD.UpdateDate,
                                                         TagPrintFlag = (bool)iD.TagPrintFlag
                                                     };
            return list;
        }

        /// <summary>
        /// Get List Entity By TagNo For Print
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="TagNo">TagNo</param>
        /// <returns>TInventory</returns>
        public TInventory_H GetForPrint(string TagNo)
        {
            return (this.Context.TInventory_H.Where(m => m.TagNo.Equals(TagNo) && !m.DeleteFlag)).SingleOrDefault();
        }

        /// <summary>
        /// Get Kind For Set Size Print
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="KindCD">KindCD</param>
        /// <param name="Language">Language</param>
        /// <returns>IQueryable Of KindForPrint</returns>
        public IQueryable<KindForPrint> GetKindForSetSizePrint(string KindCD, int Language)
        {
            IQueryable<KindForPrint> list = from h in this.Context.GetTable<MKind_H>()
                                            join d in this.Context.GetTable<MKind_D>()
                                               on h.KindCD equals d.KindCD

                                            where h.KindCD.Equals(KindCD) && ((string.IsNullOrEmpty(Language.ToString())) || d.Language == Language)

                                            select new KindForPrint
                                            {
                                                DataCD = d.DataCD,
                                                KindCD = h.KindCD,
                                                Value = d.Value
                                            };
            return list;
        }

        /// <summary>
        /// Get List Stock Inquiry By List Tag Info(TagNo + Branch TagNo)
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="BranchTags">List of BranchTags</param>
        /// <param name="TagNo">TagNo</param>
        /// <returns></returns>
        public IQueryable<StockInquiryPrintModels> GetListStockInquiryByListTagInfo(List<string> BranchTags, string TagNo)
        {
            List<string> listStatus = new List<string>();
            listStatus.Add(Constant.STOCK_STATUS_DELIVERY);
            listStatus.Add(Constant.STOCK_STATUS_DELIVERY_DEFECTIVE);
            listStatus.Add(Constant.STOCK_STATUS_DELIVERY_SCRAP);
            IQueryable<StockInquiryPrintModels> list = from iH in this.Context.GetTable<TInventory_H>()
                                                       join iD in this.Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                                       join p in this.Context.GetTable<MProduct>()
                                                          on iH.ProductCD equals p.ProductCD
                                                       join l in this.Context.GetTable<MLocation>()
                                                          on new { key1 = iD.LocationCD, key2 = UserSession.Session.LoginInfo.WarehouseCD } equals new { key1 = l.LocationCD, key2 = l.WarehouseCD } into lo
                                                       from loc in lo.DefaultIfEmpty()
                                                       where (!iH.DeleteFlag)
                                                             && iH.TagNo.Equals(TagNo)
                                                             && BranchTags.Contains(iD.BranchTagNo.ToString())
                                                             && (!listStatus.Contains(iD.StockStatus))
                                                       orderby iH.TagNo, iD.BranchTagNo
                                                       select new StockInquiryPrintModels
                                                    {
                                                        ProductName = p.ProductName,
                                                        ProductCD = iH.ProductCD.Trim(),
                                                        TagNo = iH.TagNo,
                                                        BranchTagNo = iD.BranchTagNo.ToString(),
                                                        // WarehouseCD = iH.WarehouseCD,
                                                        LocationCD = iD.LocationCD,
                                                        LocationName = loc.LocationName,
                                                        //StoredCost = iH.StoredCost.ToString(),
                                                        // QuantityPerUnit = iH.QuantityPerUnit.ToString(),
                                                        UnitQuantity = iH.UnitQuantity.ToString(),
                                                        //TotalCost = iH.TotalCost.ToString(),
                                                        StoredDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                        LOT1 = iH.Lot1,
                                                        LOT2 = iH.Lot2,
                                                        LOT3 = iH.Lot3,
                                                        QuantityPerUnit = iH.QuantityPerUnit.ToString(),
                                                        // Memo = iH.Memo,
                                                        UpdateDate = iD.UpdateDate,
                                                        TagPrintFlag = (bool)iD.TagPrintFlag
                                                    };
            return list;
        }



        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MGroup_D Service
    /// Author: ISV-Truc
    /// </summary>
    public class MGroup_DService : DataAccess.Abstract.AbstractService<MGroup_D>
    {
        #region Get

        /// <summary>
        /// Get List Master By GroupCD
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>IQueryable Of GroupDetailGrid</returns>
        public IQueryable<GroupDetailGrid> GetListMasterByGroupCD(string GroupCD)
        {
            //Get Master Screen
            var viewKind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Common.Constant.MGROUP_MASTER) && k.Language.Equals(UserSession.Session.Language));

            //Get group detail
            var gDetail = this.Context.MGroup_D.Where(g => g.GroupCD.Equals(GroupCD));

            //Map Master Screen width authority
            var ret = viewKind.Select(m => new GroupDetailGrid()
                                {
                                    GroupCD = GroupCD,
                                    ViewCD = m.DataCD,
                                    ViewName = m.Value,
                                    GridID = Common.Constant.MASTER_GRID,
                                    Insert = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_INSERT_CD)).Single().EnableFlag, false),
                                    Update = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_UPDATE_CD)).Single().EnableFlag, false),
                                    Delete = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_DELETE_CD)).Single().EnableFlag, false),
                                    Export = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_EXPORT_CD)).Single().EnableFlag, false),
                                    View = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_VIEW_CD)).Single().EnableFlag, false),
                                    IncludeDeleted = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_INCLUDE_DELETE_CD)).Single().EnableFlag, false),
                                    Picking = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_PICKING)).Single().EnableFlag, false),
                                    Cancel = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_CANCEL)).Single().EnableFlag, false)
                                });

            return ret;
        }

        /// <summary>
        /// Get List Process By GroupCD
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>IQueryable Of GroupDetailGrid</returns>
        public IQueryable<GroupDetailGrid> GetListProcessByGroupCD(string GroupCD)
        {
            //Get Process Screen
            var viewKind = this.Context.MKind_D.Where(k => k.KindCD.Equals(Common.Constant.MGROUP_PROCESS) && k.Language.Equals(UserSession.Session.Language));

            //Get group detail
            var gDetail = this.Context.MGroup_D.Where(g => g.GroupCD.Equals(GroupCD));

            //Map Process Screen width authority
            var ret = viewKind.Select(m => new GroupDetailGrid()
            {
                GroupCD = GroupCD,
                ViewCD = m.DataCD,
                ViewName = m.Value,
                GridID = Common.Constant.PROCESS_GRID,
                Insert = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_INSERT_CD)).Single().EnableFlag, false),
                Update = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_UPDATE_CD)).Single().EnableFlag, false),
                Delete = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_DELETE_CD)).Single().EnableFlag, false),
                Export = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_EXPORT_CD)).Single().EnableFlag, false),
                View = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_VIEW_CD)).Single().EnableFlag, false),
                IncludeDeleted = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_INCLUDE_DELETE_CD)).Single().EnableFlag, false),
                Picking = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_PICKING)).Single().EnableFlag, false),
                Cancel = this.Context.IsNullBool(gDetail.Where(g => g.ViewCD.Equals(m.DataCD) && g.RolesCD.Equals(Common.Constant.GROUP_ROLE_CANCEL)).Single().EnableFlag, false)
            });
           return ret;
        }
              
        /// <summary>
        /// Get List By Key
        /// Author : ISV-LOC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>MGroup_D</returns>
        public IQueryable<MGroup_D> GetListByKey(string GroupCD)
        {

            IQueryable<MGroup_D> items = from d in this.Context.MGroup_D
                                         where d.GroupCD.Equals(GroupCD)
                                         select d;
            return items;
        }

        #endregion

        #region Check

        /// <summary>
        /// Check exist DataCD in MGroupD By Roles
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMGroupDByRoles(string dataCD)
        {
            return this.ExistBy(k => k.RolesCD.Equals(dataCD));
        }

        /// <summary>
        /// Check exist DataCD in MGroupD By View1st (01->09)
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMGroupDByView1st(string dataCD) 
        {
            return this.ExistBy(k => k.ViewCD.Equals(dataCD) && (int.Parse(dataCD) >= 1 && int.Parse(dataCD) <= 9));
        }

        /// <summary>
        /// Check exist DataCD in MGroupD By View1st (20->39)
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMGroupDByView2nd(string dataCD)
        {
            return this.ExistBy(k => k.ViewCD.Equals(dataCD) && (int.Parse(dataCD) >= 20 && int.Parse(dataCD) <= 39));
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Database Service
    /// Author: ISV-Phuong
    /// </summary>
    public class DbServices
    {
        private const string CONNECTIONSTRING_KEY_NORMAL = "InventoryManagementConnectionString";

        private const string CONNECTIONSTRING_KEY_ENCRYPT = "InventoryManagementConnectionString-Encrypt";

        /// <summary>
        /// Connect String
        /// </summary>
        public static string ConnectionString 
        { 
            get
            {   //To do
                var ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings[CONNECTIONSTRING_KEY_NORMAL].ConnectionString;
                return ConnectionString;                
            }
        }

        /// <summary>
        /// Create new context
        /// </summary>
        /// <returns>Data Context</returns>
        public static Models.DataClasses1DataContext CreateContext()
        {
            return new Models.DataClasses1DataContext(ConnectionString);
        }        
    }
}
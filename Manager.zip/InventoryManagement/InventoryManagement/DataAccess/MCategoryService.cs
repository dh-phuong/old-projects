﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Interface of MCategory
    /// Author : ISV-TRUC
    /// </summary>

    public class MCategoryService : DataAccess.Abstract.AbstractService<MCategory>
    {
        #region GET DATA

        /// <summary>
        /// Get Data By key (Not deleted)
        /// </summary>
        /// <param name="CategoryCD"></param>
        /// <returns></returns>
        public MCategory GetByPK(string CategoryCD)
        {
            return this.GetBy(m => m.CategoryCD.Equals(CategoryCD) && !m.DeleteFlag).SingleOrDefault();
        }

        /// <summary>
        /// Get Category List By Condition
        /// </summary>
        /// <param name="gmModel">CategoryList</param>
        /// <returns>IQueryable of Category</returns>
        public IQueryable<CategoryResults> GetListByConditions(CategoryList gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_CategoryName))
            {
                gmModel.txt_CategoryName = string.Empty;
            }

            IQueryable<CategoryResults> list = from r in this.Context.MCategory
                                               where (gmModel.chk_IncludeDeleteData || r.DeleteFlag.Equals(false))
                                                      && (string.IsNullOrEmpty(gmModel.txt_CategoryCD) || r.CategoryCD.StartsWith(gmModel.txt_CategoryCD))
                                                      && (string.IsNullOrEmpty(gmModel.txt_CategoryName) || r.CategoryName.ToUpper().Contains(gmModel.txt_CategoryName.ToUpper()))
                                               select new CategoryResults
                                               {
                                                   CategoryCD = r.CategoryCD.Trim(),
                                                   CategoryName = r.CategoryName,
                                                   DeleteFlag = r.DeleteFlag,
                                                   UpdateDate = r.UpdateDate,
                                               };

            return list;
        }

        /// <summary>
        /// Get Category List
        /// </summary>
        /// <param name="gmModel">CategorySearch</param>
        /// <returns>IQueryable of CategorySearch</returns>
        public IQueryable<CategorySearch> GetListByConditionsForSearch(CategorySearch gmModel)
        {           
            if (string.IsNullOrEmpty(gmModel.sCategoryName))
            {
                gmModel.sCategoryName = string.Empty;
            }
          
            IQueryable<CategorySearch> list = from k in this.Context.MCategory
                                              where (!k.DeleteFlag)
                                                    && (string.IsNullOrEmpty(gmModel.sCategoryCD) || k.CategoryCD.StartsWith(gmModel.sCategoryCD))
                                                    && (string.IsNullOrEmpty(gmModel.sCategoryName) || k.CategoryName.ToUpper().Contains(gmModel.sCategoryName.ToUpper()))

                                              select new CategorySearch
                                             {
                                                 sCategoryCD = k.CategoryCD.Trim(),
                                                 sCategoryName = k.CategoryName,
                                                 sUpdateDate = k.UpdateDate
                                             };
            return list;
        }

        /// <summary>
        /// Get By Cd
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>CategoryModels</returns>
        public CategoryModels GetByCd(string CategoryCD)
        {
            IQueryable<CategoryModels> item = from c in this.Context.MCategory
                                              where c.CategoryCD.Equals(CategoryCD)
                                              select new CategoryModels
                                             {
                                                 CategoryCD = c.CategoryCD.Trim(),
                                                 CategoryName = c.CategoryName,

                                                 UpdateDate = c.UpdateDate,
                                                 DeleteFlag = c.DeleteFlag
                                             };
            return item.SingleOrDefault<CategoryModels>();
        }

        /// <summary>
        /// Get Data For CSV
        /// Author:ISV-TRUC
        /// </summary>
        /// <returns></returns>
        public IQueryable<CategoryCSV> GetListCSV()
        {
            IQueryable<CategoryCSV> list = from w in this.Context.MCategory
                                           orderby w.CategoryCD
                                           select new CategoryCSV
                                           {
                                               CategoryCD = w.CategoryCD.Trim(),
                                               CategoryName = w.CategoryName,
                                               CreateDate = w.CreateDate,
                                               CreateUID = w.CreateUCD,
                                               UpdateDate = w.UpdateDate,
                                               UpdateUCD = w.UpdateUCD,
                                               DeleteFlag = w.DeleteFlag
                                           };

            return list;
        }

        /// <summary>
        /// Get entity MCategory by code
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>MCategory</returns>
        public MCategory GetMCategoryByCd(string CategoryCD)
        {

            IQueryable<MCategory> item = from c in this.Context.MCategory
                                         where c.CategoryCD.Equals(CategoryCD)
                                         select c;
            return item.SingleOrDefault<MCategory>();
        }


        #endregion

        #region CHECK
        public bool IsExists(string CategoryCD, bool IncludeDeletedData = false)
        {
            if (IncludeDeletedData)
            {
            return this.ExistBy(m=> m.CategoryCD.Equals(CategoryCD));    
            }
            return this.ExistBy(m=> m.CategoryCD.Equals(CategoryCD) && !m.DeleteFlag);
        }
        #endregion
    }
}
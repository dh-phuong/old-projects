﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// MKind_D Context
    /// Author: ISV - GIAM
    /// </summary>
    public class MKind_DService : DataAccess.Abstract.AbstractService<MKind_D>
    {        
        /// <summary>
        /// Get by Kind Code
        /// Author : ISV-Thuy
        /// </summary>
        /// <param name="kindCd">kindCd</param>
        /// <returns></returns>
        public IOrderedQueryable<MKind_D> GetListByDataKind(string kindCd)
        {

            IOrderedQueryable<MKind_D> dropSrc = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCd)
                                                                                             && m.Language.Equals(UserSession.Session.Language)
                                                                                             ).OrderBy(m => m.DataCD);

            return dropSrc;

        }

        /// <summary>
        /// Is Show Customer
        /// </summary>
        /// <returns></returns>
        public bool IsShowCustomer()
        {
            string isShow = (from d in this.Context.MKind_D
                             where d.KindCD.Equals(Constant.MKIND_KINDCD_VIEW_CUS)
                                && d.DataCD.Equals(Constant.MKIND_DATACD_VIEW_CUS)
                                && d.Language.Equals(LanguageFlag.English)
                             select d.Value).SingleOrDefault();
            return isShow.ToUpper().Equals("true".ToUpper());
        }

        /// <summary>
        /// Is Check ShipNo
        /// </summary>
        /// <returns></returns>
        public bool IsChecKShipNo()
        {
            string isShow = (from d in this.Context.MKind_D
                             where d.KindCD.Equals(Constant.MKIND_KINDCD_CHECK_SHIPNO)
                                && d.DataCD.Equals(Constant.MKIND_DATACD_CHECK_SHIPNO)
                                && d.Language.Equals(LanguageFlag.English)
                             select d.Value).SingleOrDefault();
            return isShow.ToUpper().Equals("true".ToUpper());
        }

        #region Get

        /// <summary>
        /// Get Page Size of grid
        /// author: ISV-Nho
        /// </summary>
        /// <returns>Page size of grid</returns>
        public int GetPageSizeOfGrid()
        {
            int ret = 1;

            string value = (from d in this.Context.MKind_D
                            where d.KindCD.Equals(Constant.MKIND_KINDCD_PAGE_SIZE)
                                && d.DataCD.Equals(Constant.MKIND_DATACD_PAGE_SIZE)
                                && d.Language.Equals(LanguageFlag.English)
                             select d.Value).SingleOrDefault();
            if (!CommonUtil.TryParseInt(value, ref ret))
            {
                ret = 1;
            }
            if (ret < 1)
            {
                ret = 1;
            }
            if (ret > 100)
            {
                ret = 100;
            }
            return ret;
        }

        /// <summary>
        /// Get Max Row and Quantity of Page
        /// author: ISV-Nho
        /// </summary>
        /// <returns>Page size of grid</returns>
        public int GetMaxRowAndQuantity(string dataCD, int maxValue)
        {
            int ret = 1;

            string value = (from d in this.Context.MKind_D
                            where d.KindCD.Equals(Constant.MKIND_KINDCD_MAX_ROW_QTY)
                                && d.DataCD.Equals(dataCD)
                                && d.Language.Equals(LanguageFlag.English)
                                select d.Value).SingleOrDefault();
            if (!CommonUtil.TryParseInt(value, ref ret))
            {
                ret = 1;
            }
            if (ret < 1)
            {
                ret = 1;
            }
            if (ret > maxValue && maxValue != 0)
            {
                ret = maxValue;
            }
            return ret;
        }
        
        /// <summary>
        /// Get detail by kindCD
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="kindCD">KindCD</param>
        /// <returns>IQueryable of MKind_D</returns>
        public IQueryable<MKind_D> GetListDetailByKindCD(string kindCD)
        {
            IQueryable<MKind_D> items = from c in this.Context.GetTable<MKind_D>()
                                        where c.KindCD.Equals(kindCD)
                                        orderby c.DataCD
                                        select c;
            return items;
        }

        /// <summary>
        /// Get DataCD, Value for a KindCD
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="kindCD">kindCD</param>
        /// <returns>IQueryable of KindDetailGrid</returns>
        public IQueryable<KindDetailGrid> GetListValueByKindCD(string kindCD)
        {
            var aa = this.Context.GetTable<MKind_D>()
              .Where(a => a.KindCD.Equals(kindCD))
              .GroupBy(a => new { a.KindCD, a.DataCD })
              .Select(g => new KindDetailGrid
              {
                  DataCD = g.Key.DataCD,
                  EngValue = g.Where(c => c.Language.Equals(Common.LanguageFlag.English)).Select(c => c.Value).FirstOrDefault(),
                  VieValue = g.Where(c => c.Language.Equals(Common.LanguageFlag.Vietnamese)).Select(c => c.Value).FirstOrDefault(),
                  JapValue = g.Where(c => c.Language.Equals(Common.LanguageFlag.Japanese)).Select(c => c.Value).FirstOrDefault(),
              }
              );
            return aa;
        }

        /// <summary>
        /// Get detail data for update by KindCD, DataCD
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="kindCD">KindCD</param>
        /// <param name="dataCD">DataCD</param>
        /// <returns>List of MKind_D</returns>
        public List<MKind_D> GetDetailByKindCDAndDataCD(string kindCD, string dataCD)
        {
            IQueryable<MKind_D> items = from c in this.Context.GetTable<MKind_D>()
                                        where c.KindCD.Equals(kindCD) && c.DataCD.Equals(dataCD)
                                        select c;
            return items.ToList();
        }

        /// <summary>
        /// Get by Kind Code for StockInquiry
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="kindCd">kind code</param>
        /// <returns>MKind_D</returns>
        public IOrderedQueryable<MKind_D> GetListForStockInquiry(string kindCd)
        {

            IOrderedQueryable<MKind_D> items = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCd)
                                                                                             && m.Language.Equals(UserSession.Session.Language)
                                                                                             && (!m.DataCD.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                                                                             && (!m.DataCD.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                                                                             && (!m.DataCD.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                                                                             && (!m.DataCD.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                                                                             ).OrderBy(m => m.DataCD);
            return items;
        }

        /// <summary>
        /// Get List Move Kind for Move Indication
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="kindCd"></param>
        /// <returns></returns>
        public IOrderedQueryable<MKind_D> GetListByDataKindForMoveIndication(string kindCd)
        {
            Boolean isMultiWareHouse = UserSession.Session.WareHouseMode == WareHouseMode.Multiple;
            IOrderedQueryable<MKind_D> items = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCd)
                                                                                    && m.Language.Equals(UserSession.Session.Language)
                                                                                    && (isMultiWareHouse || !m.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                                                                                    ).OrderBy(m => m.DataCD);
            return items;
        }

        /// <summary>
        /// Get List Kind for Outbound Inquiry
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="kindCd"></param>
        /// <returns></returns>
        public IOrderedQueryable<MKind_D> GetListByKindForOutboundInquiry(string kindCD)
        {
            Boolean isMultiWareHouse = UserSession.Session.WareHouseMode == WareHouseMode.Multiple;
            IOrderedQueryable<MKind_D> items = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCD)
                                                                                    && m.Language.Equals(UserSession.Session.Language)
                                                                                    && (isMultiWareHouse || !m.DataCD.Equals(Constant.MKIND_KINDCD_OUT_KIND_WAREHOUSE))
                                                                                    ).OrderBy(m => m.DataCD);
            return items;
        }

        /// <summary>
        /// Get List Move Kind for Move Outbound
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="kindCd">Kind Code</param>
        /// <returns></returns>
        public IOrderedQueryable<MKind_D> GetListByDataKindForMoveOutbound(string kindCd, bool isMultiWareHouse)
        {
            IOrderedQueryable<MKind_D> items = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCd)
                                                                                    && m.Language.Equals(UserSession.Session.Language)
                                                                                    && (isMultiWareHouse || !m.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                                                                                    && !m.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION)
                                                                                    ).OrderBy(m => m.DataCD);
            return items;
        }

        /// <summary>
        /// Get by Kind Code for StockInquiry
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="dataKind"></param>
        /// <param name="includeDelete"></param>
        /// <returns></returns>
        public IOrderedQueryable<MKind_D> GetListByDataKindForDetailStockInquiry(string kindCd)
        {

            IOrderedQueryable<MKind_D> items = this.Context.GetTable<MKind_D>().Where(m => m.KindCD.Equals(kindCd)
                                                                                             && m.Language.Equals(UserSession.Session.Language)
                                                                                             && (m.DataCD.Equals(Common.Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) || m.DataCD.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                                                                             ).OrderBy(m => m.DataCD);
            return items;
        }

        /// <summary>
        /// Get Kind_D by Primary Key
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="kindCd"></param>
        /// <param name="dataCd"></param>
        /// <returns></returns>
        public MKind_D GetByPK(string kindCd, string dataCd)
        {
            IQueryable<MKind_D> item = from m in this.Context.GetTable<MKind_D>()
                                       join h in this.Context.GetTable<MKind_H>() on m.KindCD equals h.KindCD
                                       where m.KindCD.Equals(kindCd)
                                            && m.DataCD.Equals(dataCd)
                                            && m.Language.Equals(UserSession.Session.Language)
                                            && !h.DeleteFlag
                                       select m;
            return item.SingleOrDefault<MKind_D>();
        }

        #endregion

        #region Check

        /// <summary>
        /// Check exist in MKind_D
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dbDetailModel">IQueryable of MKind_D</param>
        /// <param name="dataCD">DataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInMKind_D(IQueryable<MKind_D> dbDetailModel, string dataCD)
        {
            return dbDetailModel.Any(m => m.DataCD.Equals(dataCD));
        }

        #endregion

        #region Change place later
        ///// <summary>
        ///// Check exist DataCD in MUser
        ///// Author:ISV-GIAM
        ///// </summary>
        ///// <param name="dataCD">dataCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistInMUser(string dataCD)
        //{
        //    return this.Context.GetTable<MUser>().Any(k => k.RolesCD.Equals(dataCD));
        //}

        ///// <summary>
        ///// Check exist DataCD in MProduct
        ///// Author:ISV-GIAM
        ///// </summary>
        ///// <param name="dataCD">dataCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistInMProduct(string dataCD)
        //{
        //    return this.Context.GetTable<MProduct>().Any(k => k.CategoryCD.Equals(dataCD));
        //}

        ///// <summary>
        ///// Check exist DataCD in TStockAllowance
        ///// Author:ISV-GIAM
        ///// </summary>
        ///// <param name="dataCD">dataCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistInTStockAllowance(string dataCD)
        //{
        //    return this.Context.GetTable<TStockAllowance>().Any(k => k.DataCD.Equals(dataCD));
        //}

        ///// <summary>
        ///// Check exist DataCD in TInventory by Stock status
        ///// Author:ISV-GIAM
        ///// </summary>
        ///// <param name="dataCD">dataCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistInTInventoryByStock(string dataCD)
        //{
        //    return this.Context.GetTable<TInventory_D>().Any(k => k.StockStatus.Equals(dataCD));
        //}

        ///// <summary>
        ///// Check exist DataCD in TInventory by Reserve status
        ///// Author:ISV-GIAM
        ///// </summary>
        ///// <param name="dataCD">dataCD</param>
        ///// <returns>True: exist - False: not exist</returns>
        //public bool IsExistInTInventoryByReserve(string dataCD)
        //{
        //    return this.Context.GetTable<TInventory_D>().Any(k => k.ReserveStatus.Equals(dataCD));
        //}
        #endregion

    }
}
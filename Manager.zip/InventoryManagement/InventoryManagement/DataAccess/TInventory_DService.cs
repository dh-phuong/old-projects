﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.Objects.SqlClient;
using InventoryManagement.Common;
using System.Collections;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TInventory_DService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TInventory_DService : DataAccess.Abstract.AbstractService<TInventory_D>
    {
        #region Get

        /// <summary>
        /// Get List Surplus Checked
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="ListTagNo">List TagNo</param>
        /// <param name="Context">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public int GetCountSurplusChecked(string warehouseCD, string locationCd)
        {
            IQueryable<TInventory_D> list = from iD in Context.GetTable<TInventory_D>()
                                            join iT in Context.GetTable<TTakeInventory_D>() on new { key1 = iD.TagNo, key2 = iD.BranchTagNo } equals new { key1 = iT.TagNo, key2 = iT.BranchTagNo }
                                            join iS in Context.GetTable<TShippingInstruction>() on new { key1 = iD.ShippingNo } equals new { key1 = iS.ShipNo }
                                            where (!iT.DeleteFlag)
                                                  && iT.WarehouseCD.Trim().Equals(warehouseCD)
                                                  && iT.LocationCD.Trim().Equals(locationCd)
                                                  && iT.TakeFlag
                                                  && iT.TakeStatus == Constant.TAKE_STATUS_RECEIPTS
                                                  && (iD.StockStatus == Constant.STOCK_STATUS_DELIVERY || iD.StockStatus == Constant.STOCK_STATUS_DELIVERY_DEFECTIVE || iD.StockStatus == Constant.STOCK_STATUS_DELIVERY_SCRAP)
                                                  && iS.ShippingCompleteFlag == false
                                            select iD;
            return list.Count();
        }

        /// <summary>
        /// Get List Surplus Checked
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="ListTagNo">List TagNo</param>
        /// <param name="Context">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListSurplusChecked(string warehouseCD, string locationCd)
        {
            IQueryable<TInventory_D> list = from iD in Context.GetTable<TInventory_D>()
                                            join iT in Context.GetTable<TTakeInventory_D>() on new { key1 = iD.TagNo, key2 = iD.BranchTagNo } equals new { key1 = iT.TagNo, key2 = iT.BranchTagNo }
                                            where (!iT.DeleteFlag)
                                                  && iT.WarehouseCD.Trim().Equals(warehouseCD)
                                                  && iT.LocationCD.Trim().Equals(locationCd)
                                                  && iT.TakeFlag
                                                  && iT.TakeStatus == Constant.TAKE_STATUS_RECEIPTS
                                            select iD;
            return list;
        }

        /// <summary>
        /// Get List Normal Checked
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="ListTagNo">List TagNo</param>
        /// <param name="Context">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListNormalChecked(string warehouseCD, string locationCd)
        {
            IQueryable<TInventory_D> list = from iD in Context.GetTable<TInventory_D>()
                                            join iT in Context.GetTable<TTakeInventory_D>() on new { key1 = iD.TagNo, key2 = iD.BranchTagNo } equals new { key1 = iT.TagNo, key2 = iT.BranchTagNo }
                                            where (!iT.DeleteFlag)
                                                  && iT.WarehouseCD.Trim().Equals(warehouseCD)
                                                  && iT.LocationCD.Trim().Equals(locationCd)
                                                  && iT.TakeFlag
                                                  && iT.TakeStatus == Constant.TAKE_STATUS_NONE
                                            select iD;
            return list;
        }

        /// <summary>
        /// Get List Picking Not Checked
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="ListTagNo">List TagNo</param>
        /// <param name="Context">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListPickingNotChecked(string warehouseCD, string locationCd)
        {
            IQueryable<TInventory_D> list = from iH in Context.GetTable<TInventory_H>()
                                            join iD in Context.GetTable<TInventory_D>() on new { key1 = iH.TagNo } equals new { key1 = iD.TagNo }
                                            join iT in Context.GetTable<TTakeInventory_D>() on new { key1 = iD.TagNo, key2 = iD.BranchTagNo } equals new { key1 = iT.TagNo, key2 = iT.BranchTagNo }
                                            where (!iT.DeleteFlag)
                                                  && iT.WarehouseCD.Trim().Equals(warehouseCD)
                                                  && iT.LocationCD.Trim().Equals(locationCd)
                                                  && iH.WarehouseCD.Trim().Equals(warehouseCD)
                                                  && iD.LocationCD.Trim().Equals(locationCd)
                                                  && !iT.TakeFlag
                                            select iD;
            return list;
        }

        /// <summary>
        /// Get list by TagNo ISV-Nho
        /// </summary>
        /// <param name="tagNo">TagNo</param>
        /// <returns>List TInventory_D</returns>
        public IQueryable<TInventory_D> GetListByTagNo(string tagNo)
        {
            return from i in this.Context.GetTable<TInventory_D>()
                   where i.TagNo.Trim().Equals(tagNo)
                   select i;
        }

        /// <summary>
        /// Get List Entity By TagNo For Print
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="TagNos">List TagNo</param>
        /// <returns>IQueryable Of TInventory</returns>
        public IQueryable<TInventory_D> GetListByTagNoBranchTagNo(List<string> ListTagNo)
        {
            IQueryable<TInventory_D> list = from iH in Context.GetTable<TInventory_H>()
                                            join iD in Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                            where (!iH.DeleteFlag)
                                                  &&
                                                   ListTagNo.Contains(iH.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'))
                                                    && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)

                                            select iD;
            return list;
        }

        /// <summary>
        /// Get List TInventory_D By List TagNo
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="ListTagNo">List TagNo</param>
        /// <param name="Context">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListEntityByTagNo(string TagNo)
        {
            IQueryable<TInventory_D> list = from iH in Context.GetTable<TInventory_H>()
                                            join iD in Context.GetTable<TInventory_D>() on iH.TagNo equals iD.TagNo
                                            where (!iH.DeleteFlag)
                                                  &&
                                                  iD.TagNo.Equals(TagNo)
                                                    && iD.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)

                                            select iD;
            return list;
        }

        /// <summary>
        /// Get data by primary key
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="BranchTagNo">Branch TagNo</param>
        /// <returns>TInventory_D</returns>
        public TInventory_D GetByPK(string tagNo, int BranchTagNo)
        {
            IQueryable<TInventory_D> item = from h in this.Context.TInventory_H
                                            join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                                            where d.TagNo.Equals(tagNo)
                                                  && d.BranchTagNo.Equals(BranchTagNo)
                                                  && !h.DeleteFlag
                                                  && h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)
                                            select d;

            return item.SingleOrDefault<TInventory_D>();
        }

        /// <summary>
        /// GetList For StockInquiry ByTagNo
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="tagNo"></param>
        /// <returns></returns>
        public IQueryable<TInventory_D> GetListStockInquiryByTagNo(string tagNo)
        {
            IQueryable<TInventory_D> items = from i in this.Context.GetTable<TInventory_D>()
                                             where i.TagNo.Trim().Equals(tagNo)
                                             && (!i.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY))
                                             && (!i.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_DEFECTIVE))
                                             && (!i.StockStatus.Equals(Common.Constant.STOCK_STATUS_DELIVERY_SCRAP))
                                             && (!i.StockStatus.Equals(Common.Constant.STOCK_STATUS_ISSUE_INVENTORY))
                                             select i;

            return items;
        }

        /// <summary>
        /// Get List TInventory_D By TagNo For Print
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="tagNo">Tag No</param>
        /// <param name="dc">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListByTagNoForPrint(string tagNo)
        {
            return from i in this.Context.GetTable<TInventory_D>()
                   where i.TagNo.Trim().Equals(tagNo) && i.StockStatus.Equals(Common.Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                   select i;
        }

        /// <summary>
        /// Get List By Location
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>List TTakeInventory_D</returns>
        public IQueryable<StockTakeProclamationDetail> GetListByLocationForStockTakeProclamation(string WarehouseCD, string LocationCD)
        {
            IQueryable<StockTakeProclamationDetail> items = from ih in this.Context.TInventory_H
                                                            join id in this.Context.TInventory_D on ih.TagNo equals id.TagNo
                                                            where ih.WarehouseCD.Equals(WarehouseCD)
                                                               && id.LocationCD.Equals(LocationCD)
                                                               && !ih.DeleteFlag
                                                               && (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                                                                || id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                                                            select new StockTakeProclamationDetail
                                                            {
                                                                TagNo = ih.TagNo,
                                                                BranchTagNo = id.BranchTagNo,
                                                                ProductCD = ih.ProductCD,
                                                                StoredCost = ih.StoredCost,
                                                                QuantityPerUnit = ih.QuantityPerUnit,
                                                                UnitQuantity = ih.UnitQuantity,
                                                                TotalCost = ih.TotalCost,
                                                                LOT1 = ih.Lot1,
                                                                LOT2 = ih.Lot2,
                                                                LOT3 = ih.Lot3

                                                            };
            return items;
        }

        /// <summary>
        /// Get list Move Goods Issue Inspection Detail
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns> List Move Goods Issue Inspection Detail</returns>
        public IQueryable<MoveGoodsIssueInspectionDetail> GetListMoveDetail(string ShipNo)
        {
            var result = from h in this.Context.TInventory_H
                         join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                         join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                         where !h.DeleteFlag
                         && d.ShippingNo.Equals(ShipNo)
                         select new MoveGoodsIssueInspectionDetail()
                         {
                             TagNo = d.TagNo + Constant.HYPHEN + d.BranchTagNo.ToString().PadLeft(Constant.TINVENTORY_BRANCH_TAG_NO_LEN, '0'),
                             LocationCD = d.LocationCD,
                             ArrivalDate = h.ArrivalDate,
                             LOT1 = h.Lot1,
                             LOT2 = h.Lot2,
                             LOT3 = h.Lot3,
                             ProductCD = h.ProductCD,
                             ProductName = p.ProductName,
                             Checked = d.PickingFlag ?? false,
                             ShipDetailNo = d.ShippingDetailNo.Value,
                             UpdateDate = d.UpdateDate
                         };

            return result;
        }

        /// <summary>
        /// Get list Shipment Picking Detail
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns> List GoodsIssueInspectionDetail</returns>
        public IQueryable<GoodsIssueInspectionDetail> GetListGoodsIssueInspectionDetailOld(string ShipNo)
        {
            var result = from r in this.Context.GetTable<TReserve>()
                         join d in this.Context.GetTable<TInventory_D>() on new { key1 = r.TagNo, key2 = r.LocationCD } equals new { key1 = d.TagNo, key2 = d.LocationCD }
                         join h in this.Context.GetTable<TInventory_H>() on new { key1 = d.TagNo } equals new { key1 = h.TagNo }
                         where !h.DeleteFlag
                         && r.ShipNo.Equals(ShipNo)
                         && (d.ShippingNo.Equals(ShipNo) || d.ShippingNo.Equals(null))
                         && (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)//20
                            || d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) //25
                            || d.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE)) //40
                         group new { d, h, r } by new { r.TagNo, r.LocationCD } into grp
                         select new GoodsIssueInspectionDetail()
                         {
                             TagNo = grp.Key.TagNo,
                             LocationCD = grp.Key.LocationCD,
                             ArrivalDate = grp.Min(m => m.h.ArrivalDate),
                             LOT1 = grp.Min(m => m.h.Lot1),
                             LOT2 = grp.Min(m => m.h.Lot2),
                             LOT3 = grp.Min(m => m.h.Lot3),
                             ProductCD = grp.Min(m => m.h.ProductCD),
                             CheckedQuantity = grp.Count(m => m.d.PickingFlag.Equals(true)),
                             DeliveryQuantity = grp.Min(m => m.r.Quantity),
                             ShipDetailNo = grp.Min(m => m.r.ShipDetailNo),
                             //UpdateDate = grp.Max(m => m.d.UpdateDate)
                         };

            return result;
        }

        /// <summary>
        /// Get list Shipment Picking Detail
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns> List GoodsIssueInspectionDetail</returns>
        public IQueryable<GoodsIssueInspectionDetail> GetListGoodsIssueInspectionDetail(string ShipNo)
        {
            var result = from r in this.Context.GetTable<TReserve>()
                         join h in this.Context.GetTable<TInventory_H>() on new { key1 = r.TagNo } equals new { key1 = h.TagNo }
                         join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                         where !h.DeleteFlag
                         && r.ShipNo.Equals(ShipNo)
                         select new GoodsIssueInspectionDetail()
                         {
                             TagNo = r.TagNo,
                             LocationCD = r.LocationCD,
                             ArrivalDate = h.ArrivalDate,
                             LOT1 = h.Lot1,
                             LOT2 = h.Lot2,
                             LOT3 = h.Lot3,
                             ProductCD = h.ProductCD,
                             ProductName = p.ProductName,
                             CheckedQuantity = r.Quantity - r.RemainQuantity,
                             DeliveryQuantity = r.Quantity,
                             ShipDetailNo = r.ShipDetailNo,
                         };

            return result;
        }

        /// <summary>
        /// Get list Delivery Picking Detail
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">Conditions</param>
        /// <returns> List DeliveryPickingDetail</returns>
        public IQueryable<OutboundDeliveryDetail> GetListOutboundDeliveryDetail(string ShipNo)
        {
            var result = from d in this.Context.GetTable<TInventory_D>()
                         join h in this.Context.GetTable<TInventory_H>() on new { key1 = d.TagNo } equals new { key1 = h.TagNo }
                         join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                         where !h.DeleteFlag
                         && d.ShippingNo.Equals(ShipNo)
                         && (d.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE)          //40
                            || d.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY))    //50
                         select new OutboundDeliveryDetail()
                         {
                             TagInfo = h.TagNo + Constant.HYPHEN + d.BranchTagNo.ToString().PadLeft(4, '0'),
                             ProductCD = h.ProductCD,
                             ProductName = p.ProductName,
                             ArrivalDate = h.ArrivalDate,
                             LOT1 = h.Lot1,
                             LOT2 = h.Lot2,
                             LOT3 = h.Lot3,
                             DeliveryFlag = d.DeliveryFlag.Value,
                             UpdateDate = d.UpdateDate
                         };

            return result;
        }

        /// <summary>
        /// Get list Move Delivery Picking Detail
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns> List Move DeliveryPickingDetail</returns>
        public IQueryable<MoveOutboundDeliveryInspectionDetail> GetListMoveOutboundDeliveryDetail(string ShipNo, string MoveKind)
        {
            List<string> lstStatus = new List<string>();

            //Add Stock Status for Move Warehouse
            if (MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                lstStatus.Add(Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE);     //45: 出庫（庫内移動）
                lstStatus.Add(Constant.STOCK_STATUS_ISSUE_DEFECTIVE);       //47:「移動出庫(不良品)」
                lstStatus.Add(Constant.STOCK_STATUS_DELIVERY);              //50: 出荷
                lstStatus.Add(Constant.STOCK_STATUS_DELIVERY_DEFECTIVE);    //57:「出荷(不良品)」
            }
            else //For move Scrap
            {
                lstStatus.Add(Constant.STOCK_STATUS_ISSUE_SCRAP);           //48:「破棄出庫」
                lstStatus.Add(Constant.STOCK_STATUS_DELIVERY_SCRAP);        //58:「破棄出荷」
            }

            var result = from d in this.Context.GetTable<TInventory_D>()
                         join h in this.Context.GetTable<TInventory_H>() on new { key1 = d.TagNo } equals new { key1 = h.TagNo }
                         join p in this.Context.MProduct on h.ProductCD equals p.ProductCD
                         where !h.DeleteFlag
                         && d.ShippingNo.Equals(ShipNo)
                         && lstStatus.Contains(d.StockStatus)
                         select new MoveOutboundDeliveryInspectionDetail()
                         {
                             TagInfo = h.TagNo + Constant.HYPHEN + d.BranchTagNo.ToString().PadLeft(4, '0'),
                             ProductCD = h.ProductCD,
                             ProductName = p.ProductName,
                             ArrivalDate = h.ArrivalDate,
                             LOT1 = h.Lot1,
                             LOT2 = h.Lot2,
                             LOT3 = h.Lot3,
                             DeliveryFlag = d.DeliveryFlag.Value,
                             UpdateDate = d.UpdateDate
                         };

            return result;
        }

        /// <summary>
        /// Get list for OutboundDeliveryIndication insert
        /// Authot: ISV-HUNG
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public List<TInventory_D> GetDataForShippingInstruction(OutboundDeliveryIndicationDetailResult gmModel)
        {
            int countRow = 0;
            int.TryParse(gmModel.Reserve, out countRow);
            IQueryable<TInventory_D> items = from id in this.Context.GetTable<TInventory_D>()
                                             where id.TagNo.Trim().Equals(gmModel.TagNo)
                                             && id.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                                             && id.LocationCD.Equals(gmModel.LocationCD)
                                             && id.StoredDate.Equals(gmModel.StoredDate)
                                             select id;

            return items.Take(countRow).ToList();
        }

        /// <summary>
        /// Get list for OutboundDeliveryIndication insert
        /// Authot: ISV-HUNG
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailResult> GetDataForShippingInstruction(string productCD)
        {
            IQueryable<OutboundDeliveryIndicationDetailResult> items = from h in this.Context.TInventory_H
                                                                       join d in this.Context.TInventory_D on h.TagNo equals d.TagNo
                                                                       join l in this.Context.MLocation on new { key1 = h.WarehouseCD, key2 = d.LocationCD } equals new { key1 = l.WarehouseCD, key2 = l.LocationCD } into L
                                                                       from lo in L.DefaultIfEmpty()
                                                                       where
                                                                            !lo.IssueProhibitionFlag &&
                                                                            h.ProductCD.Equals(productCD) &&
                                                                            h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD) &&
                                                                            d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                                                                       group new { d, h } by new { d.TagNo, d.LocationCD, h.ArrivalDate } into grp
                                                                       select new OutboundDeliveryIndicationDetailResult()
                                                                       {
                                                                           NumBoxes = grp.Count(),
                                                                           //RemainQuantity = (grp.Count() - grp.Count(m => m.d.PickingFlag.Value)),
                                                                           TagNo = grp.Key.TagNo,
                                                                           LocationCD = grp.Key.LocationCD,
                                                                           ArrivalDate = grp.Key.ArrivalDate,
                                                                           Lot1 = grp.Min(m => m.h.Lot1),
                                                                           Lot2 = grp.Min(m => m.h.Lot2),
                                                                           Lot3 = grp.Min(m => m.h.Lot3),
                                                                           StoredDate = grp.Min(m => m.d.StoredDate),
                                                                       };

            return items;
        }

        /// <summary>
        /// Get list for OutboundDeliveryIndication search
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public List<OutboundDeliveryIndicationDetailResult> GetListByShippingNo(OutboundDeliveryIndicationDetailGrid gmModel)
        {
            IQueryable<OutboundDeliveryIndicationDetailResult> list = from ih in this.Context.GetTable<TInventory_H>()
                                                                      join id in this.Context.GetTable<TInventory_D>() on ih.TagNo equals id.TagNo
                                                                      where (string.IsNullOrEmpty(gmModel.txt_ShipNo) || id.ShippingNo.Equals(gmModel.txt_ShipNo))
                                                                      && (string.IsNullOrEmpty(gmModel.txt_ShipNoDetail) || id.ShippingDetailNo.Equals(gmModel.txt_ShipNoDetail))
                                                                      && ih.ProductCD.Equals(gmModel.txt_ProductCD)
                                                                      select new OutboundDeliveryIndicationDetailResult()
                                                               {
                                                                   TagNo = ih.TagNo,
                                                                   LocationCD = id.LocationCD,
                                                                   ArrivalDate = ih.ArrivalDate,
                                                                   Lot1 = ih.Lot1,
                                                                   Lot2 = ih.Lot2,
                                                                   Lot3 = ih.Lot3,
                                                                   StoredDate = id.StoredDate,
                                                                   SeqNum = gmModel.SeqNum
                                                               };
            return list.ToList();

        }

        /// <summary>
        /// Get list By Ship No
        /// Author:ISV-Nho
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public IQueryable<TInventory_D> GetListByShipNo(string shipNo)
        {
            return this.Context.TInventory_D.Where(m => m.ShippingNo.Equals(shipNo));
        }

        /// <summary>
        /// Get quantity in inventory not picking
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="productCD"></param>
        /// <returns></returns>
        public int GetCountProduct(OutboundDeliveryIndicationDetailResult gmModel)
        {
            return (from h in this.Context.GetTable<TInventory_H>()
                    join d in this.Context.GetTable<TInventory_D>() on h.TagNo equals d.TagNo
                    where !h.DeleteFlag
                     && !(bool)d.PickingFlag &&
                     (h.TagNo.Equals(gmModel.TagNo)) &&
                     (d.LocationCD.Equals(gmModel.LocationCD)) &&
                     (h.ArrivalDate.Equals(gmModel.ArrivalDate)) &&
                     (d.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                    select d).Count();
        }

        public IQueryable<OutboundDeliveryIndicationDetailResult> GetPickingResultByShipNo(string ShipNo)
        {
            var result = this.GetBy(m => m.ShippingNo.Equals(ShipNo))
                             .GroupBy(m => new { TagNo = m.TagNo, LocationCD = m.LocationCD })
                             .Select(m => new OutboundDeliveryIndicationDetailResult
                             {
                                 TagNo = m.Key.TagNo,
                                 LocationCD = m.Key.LocationCD,
                                 PickingQuantity = m.Count()
                             });
            return result;
        }

        /// <summary>
        /// Get count picking by tagNo and locationCD
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="tagNo"></param>
        /// <param name="locationCD"></param>
        /// <returns></returns>
        public int GetCountListPicking(string shipNo, string tagNo, string locationCD)
        {
            return (this.Context.TInventory_D.Where(m => m.ShippingNo.Equals(shipNo) && m.TagNo.Equals(tagNo) && m.LocationCD.Equals(locationCD) && m.PickingFlag.Equals(true))).Count();

        }

        /// <summary>
        /// GetStockListReportData
        /// Auhthor : ISV - THUY
        /// Create date : 2013/06/11
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="IsTagNo">BranchTagNo</param>
        /// <returns></returns>
        public List<StockListModels> GetStockListReportData(StockInquiryList gmModel, bool IsTagNo)
        {
            string productName = gmModel.txt_ProductName;
            if (string.IsNullOrEmpty(productName))
            {
                productName = string.Empty;
            }
            string productCd = (gmModel.txt_ProductCD ?? string.Empty).Trim();
            string locationCDFrom = (gmModel.txtLocationCDFrom ?? string.Empty).Trim();
            string locationCDTo = (gmModel.txtLocationCDTo ?? string.Empty).Trim();
            string Lot1 = string.Empty;
            if (!string.IsNullOrEmpty(gmModel.txt_LOT1))
            {
                Lot1 = gmModel.txt_LOT1;
            }

            string customerCD = string.Empty;
            if (gmModel.IsShowSuplier)
            {
                if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
                {
                    customerCD = gmModel.txt_SuplierCD ?? string.Empty;
                }
                else
                {
                    customerCD = UserSession.Session.LoginInfo.User.CustomerCD;
                }
            }

            string storedDateFrom = gmModel.txt_StoredDateFrom.DateValue();
            string storedDateTo = gmModel.txt_StoredDateTo.DateValue();
            string LOT2From = gmModel.txt_LOT2From.DateValue();
            string LOT2To = gmModel.txt_LOT2To.DateValue();
            string LOT3From = gmModel.txt_LOT3From.DateValue();
            string LOT3To = gmModel.txt_LOT3To.DateValue();
            bool noInputLocation = String.IsNullOrEmpty(gmModel.txtLocationCDFrom) && String.IsNullOrEmpty(gmModel.txtLocationCDTo);

            if (!IsTagNo)
            {
                string tagNo = string.Empty;
                string branchTagNo = string.Empty;
                if (!string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    string[] array = gmModel.txt_TagNo.Split(Constant.HYPHEN_CHAR);
                    if (array.Length == 2)
                    {
                        tagNo = array[0];
                        branchTagNo = array[1];
                    }
                    else
                    {
                        tagNo = gmModel.txt_TagNo;
                    }
                }
                return (from ih in this.Context.TInventory_H
                        join id in this.Context.TInventory_D on ih.TagNo equals id.TagNo
                        join pro in this.Context.MProduct on ih.ProductCD equals pro.ProductCD into product
                        from prod in product.DefaultIfEmpty()
                        join loc in this.Context.MLocation on new { Key1 = id.LocationCD, Key2 = ih.WarehouseCD } equals new { Key1 = loc.LocationCD, Key2 = loc.WarehouseCD } into location
                        from loca in location.DefaultIfEmpty()
                        where !ih.DeleteFlag &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_DEFECTIVE) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_SCRAP) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE_INVENTORY) &&
                        ih.WarehouseCD.Equals(UserSession.Session.WarehouseCD) &&
                        (string.IsNullOrEmpty(tagNo) || ih.TagNo.Equals(tagNo)) &&
                        (string.IsNullOrEmpty(branchTagNo) || id.BranchTagNo.Equals(branchTagNo)) &&
                        (string.IsNullOrEmpty(productCd) || ih.ProductCD.Equals(productCd)) &&
                        (string.IsNullOrEmpty(customerCD) || ih.CustomerCD.Equals(customerCD)) &&
                        (string.IsNullOrEmpty(productName) || prod.ProductName.ToUpper().Contains(productName.ToUpper())) &&
                        (string.IsNullOrEmpty(gmModel.txt_CategoryCD) || prod.CategoryCD.Equals(gmModel.txt_CategoryCD)) &&
                        (string.IsNullOrEmpty(locationCDFrom) || id.LocationCD.CompareTo(locationCDFrom) >= 0) &&
                        (string.IsNullOrEmpty(locationCDTo) || id.LocationCD.CompareTo(locationCDTo) <= 0) &&
                        (string.IsNullOrEmpty(storedDateFrom) || id.StoredDate.CompareTo(storedDateFrom) >= 0) &&
                        (string.IsNullOrEmpty(storedDateTo) || id.StoredDate.CompareTo(storedDateTo) <= 0) &&
                        (string.IsNullOrEmpty(Lot1) || ih.Lot1.ToUpper().Equals(Lot1.ToUpper())) &&
                        (string.IsNullOrEmpty(LOT2From) || ih.Lot2.CompareTo(LOT2From) >= 0) &&
                        (string.IsNullOrEmpty(LOT2To) || ih.Lot2.CompareTo(LOT2To) <= 0) &&
                        (string.IsNullOrEmpty(LOT3From) || ih.Lot3.CompareTo(LOT3From) >= 0) &&
                        (string.IsNullOrEmpty(LOT3To) || ih.Lot3.CompareTo(LOT3To) <= 0) &&
                        (string.IsNullOrEmpty(gmModel.ddl_Status) || id.StockStatus.Equals(gmModel.ddl_Status))&&
                        (noInputLocation || id.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || id.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                        orderby ih.TagNo
                        select new StockListModels
                        {
                            locationCd = (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? id.LocationCD : string.Empty),
                            locationName = (id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || id.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? loca.LocationName : string.Empty),
                            TagNo = ih.TagNo + Constant.HYPHEN + id.BranchTagNo.ToString().PadLeft(4, '0'),
                            Lot1 = ih.Lot1,
                            Lot2 = CommonUtil.ParseDate(ih.Lot2, Constant.FMT_YMD, Constant.FMT_DATE),
                            Lot3 = CommonUtil.ParseDate(ih.Lot3, Constant.FMT_YMD, Constant.FMT_DATE),
                            ProductCd = ih.ProductCD,
                            ProductName = prod.ProductName,
                            QuantityPerUnit = ih.QuantityPerUnit == null ? 0 : (decimal)ih.QuantityPerUnit,
                            StoredCost = ih.StoredCost == null ? 0 : (decimal)ih.StoredCost,
                            //strQuantityPerUnit = string.Format(Constant.NUMBER_FORMAT_DEC_2, ih.QuantityPerUnit == null ? 0 : (decimal)ih.QuantityPerUnit),
                            //strStoredCost = string.Format(Constant.NUMBER_FORMAT_DEC_2, ih.StoredCost == null ? 0 : (decimal)ih.StoredCost),
                        }).ToList();
            }
            else
            {
                return (from ih in this.Context.TInventory_H
                        join id in this.Context.TInventory_D on ih.TagNo equals id.TagNo
                        join pro in this.Context.MProduct on ih.ProductCD equals pro.ProductCD into product
                        from prod in product.DefaultIfEmpty()
                        join loc in this.Context.MLocation on new { Key1 = id.LocationCD, Key2 = ih.WarehouseCD } equals new { Key1 = loc.LocationCD, Key2 = loc.WarehouseCD } into location
                        from loca in location.DefaultIfEmpty()
                        where !ih.DeleteFlag &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_DEFECTIVE) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_SCRAP) &&
                        !id.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE_INVENTORY) &&
                        ih.WarehouseCD.Equals(UserSession.Session.WarehouseCD) &&
                        (string.IsNullOrEmpty(gmModel.txt_TagNo) || ih.TagNo.Equals(gmModel.txt_TagNo)) &&
                        (string.IsNullOrEmpty(customerCD) || ih.CustomerCD.Equals(customerCD)) &&
                        (string.IsNullOrEmpty(productCd) || ih.ProductCD.Equals(productCd)) &&
                        (string.IsNullOrEmpty(productName) || prod.ProductName.ToUpper().Contains(productName.ToUpper())) &&
                        (string.IsNullOrEmpty(gmModel.txt_CategoryCD) || prod.CategoryCD.Equals(gmModel.txt_CategoryCD)) &&
                         (string.IsNullOrEmpty(locationCDFrom) || id.LocationCD.CompareTo(locationCDFrom) >= 0) &&
                         (string.IsNullOrEmpty(locationCDTo) || id.LocationCD.CompareTo(locationCDTo) <= 0) &&
                         (string.IsNullOrEmpty(storedDateFrom) || id.StoredDate.CompareTo(storedDateFrom) >= 0) &&
                         (string.IsNullOrEmpty(storedDateTo) || id.StoredDate.CompareTo(storedDateTo) <= 0) &&
                         (string.IsNullOrEmpty(Lot1) || ih.Lot1.ToUpper().Equals(Lot1.ToUpper())) &&
                         (string.IsNullOrEmpty(LOT2From) || ih.Lot2.CompareTo(LOT2From) >= 0) &&
                         (string.IsNullOrEmpty(LOT2To) || ih.Lot2.CompareTo(LOT2To) <= 0) &&
                         (string.IsNullOrEmpty(LOT3From) || ih.Lot3.CompareTo(LOT3From) >= 0) &&
                         (string.IsNullOrEmpty(LOT3To) || ih.Lot3.CompareTo(LOT3To) <= 0) &&
                         (string.IsNullOrEmpty(gmModel.ddl_Status) || id.StockStatus.Equals(gmModel.ddl_Status)) &&
                         (noInputLocation || id.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || id.StockStatus.Equals(Common.Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))

                        group new { ih, id, prod, loca } by new { ih.TagNo, id.LocationCD } into grTagNo
                        select new StockListModels
                        {
                            locationCd = (grTagNo.Min(m => m.id.StockStatus).Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || grTagNo.Min(m => m.id.StockStatus).Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? grTagNo.Key.LocationCD : string.Empty),
                            locationName = (grTagNo.Min(m => m.id.StockStatus).Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || grTagNo.Min(m => m.id.StockStatus).Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ? grTagNo.Min(m => m.loca.LocationName) : string.Empty),
                            TagNo = grTagNo.Key.TagNo,
                            ProductCd = grTagNo.Min(m => m.ih.ProductCD),
                            Lot1 = grTagNo.Min(m => m.ih.Lot1),
                            Lot2 = CommonUtil.ParseDate(grTagNo.Min(m => m.ih.Lot2), Constant.FMT_YMD, Constant.FMT_DATE),
                            Lot3 = CommonUtil.ParseDate(grTagNo.Min(m => m.ih.Lot3), Constant.FMT_YMD, Constant.FMT_DATE),
                            ProductName = grTagNo.Min(m => m.prod.ProductName),
                            UnitQuantity = grTagNo.Count(),
                            QuantityPerUnit = grTagNo.Min(m => m.ih.QuantityPerUnit == null ? 0 : (decimal)m.ih.QuantityPerUnit),
                            StoredCost = grTagNo.Min(m => m.ih.StoredCost == null ? 0 : (decimal)m.ih.StoredCost),
                            TotalCost = (grTagNo.Count() * grTagNo.Min(m => m.ih.StoredCost == null ? 0 : (decimal)m.ih.StoredCost)),
                            //strUnitQuantity = string.Format(Constant.NUMBER_FORMAT_INT, grTagNo.Count()),
                            //strQuantityPerUnit = string.Format(Constant.NUMBER_FORMAT_DEC_2, grTagNo.Min(m => m.ih.QuantityPerUnit == null ? 0 : (decimal)m.ih.QuantityPerUnit)),
                            //strStoredCost = string.Format(Constant.NUMBER_FORMAT_DEC_2, grTagNo.Min(m => m.ih.StoredCost == null ? 0 : (decimal)m.ih.StoredCost)),
                            //strTotalCost = string.Format(Constant.NUMBER_FORMAT_DEC_2, (grTagNo.Count() * grTagNo.Min(m => m.ih.StoredCost == null ? 0 : (decimal)m.ih.StoredCost)))
                        }).OrderBy(m => m.TagNo).ToList();
            }
        }

        /// <summary>
        /// get Tag Printed By Tag No And Branch TagNo
        /// </summary>
        /// <param name="TagNo">TagNo</param>
        /// <param name="BranchTagNo">BranchTagNo</param>
        /// <returns></returns>
        public bool GetTagPrintedByTagInfo(string TagNo, string BranchTagNo)
        {
            var result = this.Context.TInventory_D.Where(m => m.TagNo.Equals(TagNo) && m.BranchTagNo.Equals(BranchTagNo)).Select(m => m.TagPrintFlag);
            return (bool)result.SingleOrDefault();
        }

        /// <summary>
        /// Get List TInventory_D By TagNo For Print
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="tagNo">Tag No</param>
        /// <param name="dc">Data Context</param>
        /// <returns>IQueryable Of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListByTagInfoForPrintStock(string tagNo, List<string> lstBranchTagNo)
        {
            return from i in this.Context.GetTable<TInventory_D>()
                   where i.TagNo.Trim().Equals(tagNo) && lstBranchTagNo.Contains(i.BranchTagNo.ToString())
                   select i;
        }

        /// <summary>
        /// Get Count By Conditions For Move Indication
        /// </summary>
        /// <param name="shipNo">shipping no</param>
        /// <param name="tagNo">TagNo</param>
        /// <param name="locationCD">Location code</param>
        /// <returns>count of TInventory_D</returns>
        public int GetCountByConditionsForMoveIndication(string shipNo, string tagNo, string locationCD)
        {
            return (from iD in this.Context.TInventory_D
                    join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                    where iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                       && iD.ShippingNo == null
                       && iD.TagNo.Equals(tagNo)
                       && iD.LocationCD.Equals(locationCD)
                       && iH.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                    select iD).Count()
                    +
                    (from iD in this.Context.TInventory_D
                     join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                     where iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                        && !string.IsNullOrEmpty(shipNo)
                        && iD.ShippingNo.Equals(shipNo)
                        && iH.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                     select iD).Count();

        }

        /// <summary>
        /// Get List TInventory_D by list TagInfo
        /// </summary>
        /// <param name="listTagInfo">list TagInfo</param>
        /// <returns>IQueryable of TInventory_D</returns>
        public IQueryable<TInventory_D> GetListByListTagInfo(List<string> listTagInfo)
        {
            return from iD in this.Context.TInventory_D
                   where listTagInfo.Contains(iD.TagNo + Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'))
                   select iD;
        }

        #endregion

        #region Private

        #endregion

        #region Check

        /// <summary>
        /// Check Exists
        /// Author : ISV-HUNG
        /// </summary>
        /// <param name="shipingNo"></param>
        /// <param name="shippingDetailNo"></param>
        /// <returns></returns>
        public bool IsExists(string shipingNo, string shippingDetailNo)
        {
            return this.Context.TInventory_D.Any(t => t.ShippingNo.Trim().Equals(shipingNo)
                                                                 && t.ShippingDetailNo.ToString().Equals(shippingDetailNo));

        }

        /// <summary>
        /// Check exist DataCD in TInventory
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dataCD">dataCD</param>
        /// <returns>True: exist - False: not exist</returns>
        public bool IsExistInTInventory(string dataCD)
        {
            return this.ExistBy(k => k.StockStatus.Equals(dataCD));
        }

        /// <summary>
        /// Check Exist Delivery
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>True: exist, False: not exist</returns>
        public bool IsExistShipDelivery(string shipNo)
        {
            bool isLocateMove = this.Context.TShippingInstruction.Any(m => m.ShipNo.Equals(shipNo) && m.DestinationLocationCD != null);
            if (isLocateMove)
            {
                return this.Context.TInventory_D.Count(m => m.ShippingNo.Equals(shipNo)) != this.Context.TShippingInstructionDetails.Where(m => m.ShipNo.Equals(shipNo)).Sum(m => m.InstructQuantity);
            }
            else
            {
                return this.ExistBy(s => s.ShippingNo.Equals(shipNo) && s.DeliveryFlag.Value);
            }
        }

        /// <summary>
        /// Check is move to location completed
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>True: exist, False: not exist</returns>
        public bool IsMoveLocationComplete(string shipNo)
        {
            return !this.ExistBy(s => s.ShippingNo.Equals(shipNo));
        }

        /// <summary>
        /// Is Exist Location In TInventory
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <param name="StockStatus">StockStatus</param>
        /// <returns></returns>
        public bool IsExistLocation(string WarehouseCD, string LocationCD, string StockStatus)
        {
            var temp = from ih in this.Context.TInventory_H
                       join id in this.Context.TInventory_D on ih.TagNo equals id.TagNo
                       where !ih.DeleteFlag
                            && id.LocationCD.Equals(LocationCD)
                            && ih.WarehouseCD.Equals(WarehouseCD)
                            && id.StockStatus.Equals(StockStatus)
                       select ih;
            return temp.Any();
        }

        /// <summary>
        /// Check Exist Location which include tagno selected for moving
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>TRUE: Exist, FALSE: not exist</returns>
        public bool IsExistLocationForMoving(string WarehouseCD, string LocationCD)
        {
            var temp = from ih in this.Context.TInventory_H
                       join id in this.Context.TInventory_D on ih.TagNo equals id.TagNo
                       join sH in this.Context.TShippingInstruction on id.ShippingNo equals sH.ShipNo
                       where !ih.DeleteFlag
                            && (
                                id.LocationCD.Equals(LocationCD)
                                || (sH.DestinationLocationCD != null && sH.DestinationLocationCD.Equals(LocationCD))
                                )
                            && ih.WarehouseCD.Equals(WarehouseCD)
                            && id.ShippingNo != null
                            && !sH.ShippingCompleteFlag
                       select ih;
            return temp.Any();
        }

        /// <summary>
        /// Is Exist Location In TInventory
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns></returns>
        public bool IsExistLocation(string WarehouseCD, string LocationCD)
        {
            return this.ExistBy(id => id.LocationCD.Equals(LocationCD)
                                   && this.Context.TInventory_H.Where(ih => ih.TagNo.Equals(id.TagNo)
                                                                         && !ih.DeleteFlag
                                                                         && ih.WarehouseCD.Equals(WarehouseCD)).Count() > 0


                                );
        }

        /// <summary>
        /// Check to show message in menu (Exist with Stock status=10)
        /// </summary>
        /// <returns></returns>
        public bool IsExistsArrivalNonDefective()
        {
            return this.ExistBy(k => k.StockStatus.Equals(Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                                     && this.Context.TInventory_H.Where(h => h.TagNo.Equals(k.TagNo)
                                                                        && !h.DeleteFlag
                                                                        && h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)).Count() > 0)
                 || this.Context.TShippingInstruction.Any(m => m.DestinationLocationCD != null
                                                            && m.PickingCompleteFlag
                                                            && !m.ShippingCompleteFlag
                                                            && m.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD));
        }

        /// <summary>
        /// Is Exist In Register of move
        /// </summary>
        /// <param name="locationCD">Location code</param>
        /// <returns></returns>
        public bool IsExistInRegisMove(string locationCD)
        {
            var list = from iD in this.Context.TInventory_D
                       join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                       where iD.LocationCD.Equals(locationCD)
                          && iH.WarehouseCD.Equals(UserSession.Session.WarehouseCD)
                          && iD.ShippingNo != null
                          && (iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
                            || iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                       select iD;
            return list.Any();
        }

        /// <summary>
        /// Check to show message in menu (Exist with Stock status=40 or 45)
        /// </summary>
        /// <returns></returns>
        public bool IsExistsIssueOrIssueInsideMove()
        {
            return this.ExistBy(k => (k.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE)
                                     || k.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE)
                                     || k.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE_DEFECTIVE)
                                     || k.StockStatus.Equals(Constant.STOCK_STATUS_ISSUE_SCRAP))
                                     && (this.Context.TInventory_H.Where(h => h.TagNo.Equals(k.TagNo)
                                                                        && !h.DeleteFlag
                                                                        && h.WarehouseCD.Equals(UserSession.Session.LoginInfo.WarehouseCD)).Count() > 0));
        }
        #endregion
    }
}
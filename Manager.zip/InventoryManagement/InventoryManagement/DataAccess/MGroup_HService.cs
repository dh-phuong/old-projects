﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class MGroup_HService : DataAccess.Abstract.AbstractService<MGroup_H>
    {

        /// <summary>
        /// GetByPK
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>MGroup_H</returns>
        public MGroup_H GetActiveByPK(string GroupCD)
        {
            IQueryable<MGroup_H> item = from gh in this.Context.GetTable<MGroup_H>()
                                        where gh.GroupCD.Equals(GroupCD)
                                        && !gh.DeleteFlag
                                        select gh;
            return item.SingleOrDefault<MGroup_H>();
        }

        /// <summary>
        /// GetByPK
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>MGroup_H</returns>
        public MGroup_H GetByPK(string GroupCD)
        {
            IQueryable<MGroup_H> item = from gh in this.Context.GetTable<MGroup_H>()
                                        where gh.GroupCD.Equals(GroupCD)
                                        select gh;
            return item.SingleOrDefault<MGroup_H>();
        }

        /// <summary>
        /// Get List By Conditions For Search
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">GroupSearch</param>
        /// <returns>List of GroupSearch</returns>
        public IQueryable<GroupSearch> GetListByConditionsForSearch(GroupSearch gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sGroupName))
            {
                gmModel.sGroupName = string.Empty;
            }
            IQueryable<GroupSearch> ret =  from g in this.Context.MGroup_H
                                           where !g.DeleteFlag
                                                 && (string.IsNullOrEmpty(gmModel.sGroupCD) || g.GroupCD.StartsWith(gmModel.sGroupCD))
                                                 && (string.IsNullOrEmpty(gmModel.sGroupName) || g.GroupName.ToUpper().Contains(gmModel.sGroupName.ToUpper()))
                                                 && (!g.GroupCD.Equals(Common.Constant.GROUP_SUPPER_ADMIN_CD))
                                           select new GroupSearch
                                           {
                                               sGroupCD = g.GroupCD.Trim(),
                                               sGroupName = g.GroupName
                                           };
            return ret;
        }

        /// <summary>
        /// Get List By Search Conditions
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="gmModel">GroupHeaderList</param>
        /// <returns>IQueryable Of GroupHeaderResul</returns>
        public IQueryable<GroupHeaderResult> GetListByConditions(GroupHeaderList gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_GroupName))
            {
                gmModel.txt_GroupName = string.Empty;
            }
            IQueryable<GroupHeaderResult> list = from g in this.Context.GetTable<MGroup_H>()
                                                 where (gmModel.chb_IncludeDeleteData || !g.DeleteFlag)
                                                    && (string.IsNullOrEmpty(gmModel.txt_GroupCD) || g.GroupCD.StartsWith(gmModel.txt_GroupCD))
                                                    && (string.IsNullOrEmpty(gmModel.txt_GroupName) || g.GroupName.ToLower().Contains(gmModel.txt_GroupName.ToLower()))
                                                    && (UserSession.Session.LoginInfo.User.GroupCD.Equals(Common.Constant.GROUP_SUPPER_ADMIN_CD) 
                                                        || !g.GroupCD.Equals(Common.Constant.GROUP_SUPPER_ADMIN_CD))
                                                 select new GroupHeaderResult
                                            {
                                                GroupCD = g.GroupCD.Trim(),
                                                GroupName = g.GroupName,
                                                DeleteFlag = g.DeleteFlag,
                                                UpdateDate = g.UpdateDate
                                            };
            return list;
        }

        /// <summary>
        /// Get Title For Grid
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns>IQueryable Of MKind_D</returns>
        public IQueryable<MKind_D> GetTitleForGrid()
        {

            IQueryable<MKind_D> list = from kD1 in Context.GetTable<MKind_D>()
                                       where kD1.Language.Equals((byte)UserSession.Session.Language) && kD1.KindCD.Equals(Common.Constant.MGROUP_ROLE_CD)
                                       select kD1;

            return list;
        }

        /// <summary>
        /// GetHeaderResultByKey
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>GroupHeaderResult</returns>
        public GroupHeaderResult GetHeaderResultByKey(string GroupCD)
        {

            IQueryable<GroupHeaderResult> list = from g in Context.GetTable<MGroup_H>()
                                                 where g.GroupCD.Equals(GroupCD)
                                                 select new GroupHeaderResult()
                                                 {
                                                     GroupCD = g.GroupCD.Trim(),
                                                     GroupName = g.GroupName,
                                                     DeleteFlag = g.DeleteFlag,
                                                     UpdateDate = g.UpdateDate
                                                 };

            return list.SingleOrDefault();
        }

        /// <summary>
        /// Get Header Entity By Key
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <returns>MGroup_H</returns>
        public MGroup_H GetHeaderEntityByKey(string GroupCD)
        {
            IQueryable<MGroup_H> items = from c in this.Context.GetTable<MGroup_H>()
                                        where c.GroupCD.Equals(GroupCD)
                                        select c;
            return items.SingleOrDefault();
        }
        
        /// <summary>
        /// Get List Group Grid For Insert
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="optionList">List Of GroupDetailGrid : Master or Process </param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>IQueryable Of GroupDetailGrid</returns>
        public IQueryable<GroupDetailGrid> GetListGroupGridForInsert(string optionList, int SeqNum)
        {
            IQueryable<GroupDetailGrid> list = from kd in this.Context.MKind_D
                                               where kd.Language.Equals((byte)UserSession.Session.Language)
                                               && kd.KindCD.Equals(optionList)
                                               select new GroupDetailGrid()
                                                 {
                                                     ViewCD = kd.DataCD,
                                                     ViewName = kd.Value,
                                                     GridID = optionList.Equals(Common.Constant.MGROUP_MASTER) ? Common.Constant.MASTER_GRID : Common.Constant.PROCESS_GRID,
                                                     Insert = false,
                                                     Update = false,
                                                     Delete = false,
                                                     Export = false,
                                                     View = false,
                                                     IncludeDeleted = false,
                                                     Picking = false,
                                                     Cancel = false,
                                                     SeqNum = SeqNum
                                                 };
            return list;
        }

        /// <summary>
        /// Get List CSV
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns>IQueryable Of GroupCSV</returns>
        public IQueryable<GroupCSV> GetListCSV()
        {
            IQueryable<GroupCSV> list = from gh in this.Context.MGroup_H
                                        join gd in this.Context.MGroup_D on gh.GroupCD equals gd.GroupCD                                       
                                        orderby gh.GroupCD                              
                                        select new GroupCSV()
                                                 {
                                                     GroupCD = gh.GroupCD.Trim(),
                                                     GroupName = gh.GroupName,
                                                     CreateDate = gh.CreateDate,
                                                     CreateUCD = gh.CreateUCD,
                                                     UpdateDate = gh.UpdateDate,
                                                     UpdateUCD = gh.UpdateUCD,
                                                     DeleteFlag=gh.DeleteFlag,
                                                     ViewCD = gd.ViewCD,                                                    
                                                     RoleCD = gd.RolesCD,                                                    
                                                     EnableFlag = gd.EnableFlag
                                                 };
            return list;
        }
        
    }
}
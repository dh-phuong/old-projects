﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// Pessimistic Lock Service
    /// Author : ISV-Vinh
    /// </summary>

    public class TPessimisticLockService : DataAccess.Abstract.AbstractService<TPessimisticLock>
    {
        #region Get

        /// <summary>
        /// Get for insert
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="tagNo"></param>
        /// <returns></returns>
        public TPessimisticLock GetByTagNo(string tagNo)
        {
            return this.Context.TPessimisticLock.Where(m => m.TagNo.Equals(tagNo)).SingleOrDefault();
        }

        #endregion

        #region Check

        /// <summary>
        /// Check exits in TPessimisticLock
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="tagNo"></param>
        /// <returns></returns>
        public bool IsExistInTPessimisticLock(string tagNo)
        {
            return this.Context.TPessimisticLock.Any(p => p.TagNo.Equals(tagNo));
        }

        #endregion

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using InventoryManagement.Common;

namespace InventoryManagement.DataAccess
{
    /// <summary>
    /// TShippingInstructionDetailService Context
    /// Author : ISV-HUNG
    /// </summary>
    public class TShippingInstructionDetailsService : DataAccess.Abstract.AbstractService<TShippingInstructionDetails>
    {
        #region Get

        /// <summary>
        /// Get List By Ship No
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns></returns>
        public IQueryable<MoveIndicationDetailGrid> GetListByMoveNo(string moveNo, int seqNum, bool completeFlag, string locationTo)
        {
            string warehouseCD = UserSession.Session.WarehouseCD;
            IQueryable<MoveIndicationDetailGrid> list = from s in this.Context.TShippingInstructionDetails
                                                        join iD in this.Context.TInventory_D on new { key1 = s.TagNo, key2 = (int)s.BranchTagNo } equals new { key1 = iD.TagNo, key2 = iD.BranchTagNo }
                                                        join iH in this.Context.TInventory_H on iD.TagNo equals iH.TagNo
                                                        join p in this.Context.MProduct on iH.ProductCD equals p.ProductCD
                                                        join k in this.Context.MKind_D on new { key1 = Constant.MKIND_KINDCD_STOCK_STATUS, key2 = iD.StockStatus, key3 = (byte)UserSession.Session.Language }
                                                                                   equals new { key1 = k.KindCD, key2 = k.DataCD, key3 = k.Language }
                                                        where s.ShipNo == moveNo
                                                        orderby iD.TagNo, iD.BranchTagNo
                                                        select new MoveIndicationDetailGrid
                                                        {
                                                            txt_TagInfo = iD.TagNo + Common.Constant.HYPHEN + iD.BranchTagNo.ToString().PadLeft(4, '0'),
                                                            txt_LocationCD = iD.LocationCD,
                                                            txt_ProductCD = iH.ProductCD,
                                                            txt_ProductName = p.ProductName,
                                                            txt_ArrivalDate = CommonUtil.ParseDate(iH.ArrivalDate, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            txt_Lot1 = iH.Lot1,
                                                            txt_LOT2 = CommonUtil.ParseDate(iH.Lot2, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            txt_LOT3 = CommonUtil.ParseDate(iH.Lot3, Common.Constant.FMT_YMD, Common.Constant.FMT_DATE),
                                                            StockStatus = iD.StockStatus,
                                                            txt_StockStatusDisp = k.Value,
                                                            SeqNum = seqNum,
                                                            CompleteFlag = completeFlag,
                                                            IsDelied = iD.DeliveryFlag.Value || (!string.IsNullOrEmpty(locationTo) &&iD.LocationCD == locationTo),
                                                            IsPicked = !iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) 
                                                                    && !iD.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                                                        };
            return list;
        }

        /// <summary>
        /// Get List By Ship No for detail
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="shipNo"></param>
        /// <returns></returns>
        public IQueryable<OutboundDeliveryIndicationDetailGrid> GetListByShipNo(string shipNo)
        {
            IQueryable<OutboundDeliveryIndicationDetailGrid> list = from s in this.Context.GetTable<TShippingInstructionDetails>()
                                                                    join p in this.Context.GetTable<MProduct>() on s.ProductCD equals p.ProductCD
                                                                    where s.ShipNo == shipNo
                                                                    select new OutboundDeliveryIndicationDetailGrid
                                                                    {
                                                                        txt_ShipNo = s.ShipNo,
                                                                        txt_ShipNoDetail = s.ShipDetailNo.ToString(),
                                                                        txt_ProductCD = s.ProductCD,
                                                                        txt_ProductName = p.ProductName,
                                                                        txt_InstructQuantity = s.InstructQuantity.ToString(),

                                                                    };
            return list;
        }

        /// <summary>
        /// Get detail by shipNo
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <returns>IQueryable of TShippingInstructionDetails</returns>
        public IQueryable<TShippingInstructionDetails> GetListDetailByShipNo(string shipNo)
        {
            IQueryable<TShippingInstructionDetails> items = from c in this.Context.GetTable<TShippingInstructionDetails>()
                                        where c.ShipNo.Equals(shipNo)
                                        orderby c.ShipDetailNo
                                        select c;
            return items;
        }

        /// <summary>
        /// Get by pk
        /// </summary>
        /// <param name="shipNo"></param>
        /// <param name="shipNoDetail"></param>
        /// <returns></returns>
        public TShippingInstructionDetails GetByPK(string shipNo, string shipNoDetail)
        {
            IQueryable<TShippingInstructionDetails> items = from c in this.Context.GetTable<TShippingInstructionDetails>()
                                               where c.ShipNo.Equals(shipNo) && c.ShipDetailNo.Equals(shipNoDetail)
                                               select c;
            return items.FirstOrDefault();
        }

        #endregion
        
        #region Check

        /// <summary>
        /// Check picking data
        /// </summary>
        /// <param name="shipNo"></param>
        /// <param name="shipNoDetail"></param>
        /// <returns></returns>
        public bool CheckPickingData(string shipNo, string shipNoDetail)
        {
            //return this.Context.GetTable<TInventory_D>().Any(k => k.ShippingNo.Equals(shipNo) && k.ShippingDetailNo.Equals(shipNoDetail) && k.PickingFlag == true);
            return this.Context.TReserve.Any(k => k.ShipNo.Equals(shipNo) && k.ShipDetailNo.Equals(shipNoDetail) && k.Quantity != k.RemainQuantity);
        }

        /// <summary>
        /// Check exist in Detail
        /// </summary>
        /// <param name="dbDetailModel"></param>
        /// <param name="shipNo"></param>
        /// <param name="shipNoDetail"></param>
        /// <returns></returns>
        public bool IsExistInDetail(IQueryable<TShippingInstructionDetails> dbDetailModel,string productCD)
        {
            return dbDetailModel.Any(m => m.ProductCD.Equals(productCD));
        }

        #endregion
        
    }

}
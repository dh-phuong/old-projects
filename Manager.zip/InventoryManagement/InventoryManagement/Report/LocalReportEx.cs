﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Reporting.WebForms;

namespace InventoryManagement.Report
{
    /// <summary>
    /// Extends Local Report
    /// Author : ISV-PHUONG
    /// </summary>
    public static class LocalReportEx
    {
        /// <summary>
        /// Set Label
        /// </summary>
        /// <param name="Report">Local Report</param>
        /// <param name="Labels">Key Label  & Key Value</param>
        public static void SetLabelFromCache(this LocalReport Report, params KeyValuePair<string, string>[] Labels)
        {
            for (int i = 0; i < Labels.Length; i++)
            {
                Report.SetLabelValue(Labels[i].Key, UserSession.Session.SysCache.GetLabel(Labels[i].Value));
            }
        }

        /// <summary>
        /// Set Label
        /// </summary>
        /// <param name="Report">Local Report</param>
        /// <param name="LabelName">Label Name</param>
        /// <param name="LabelValue">Text Value</param>
        public static void SetLabelValue(this LocalReport Report, string LabelName, string LabelValue)
        {
            Report.SetParameters(new ReportParameter(LabelName, LabelValue));
        }
    }
}
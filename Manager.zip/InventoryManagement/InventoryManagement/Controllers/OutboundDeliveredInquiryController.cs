﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.Common;
using InventoryManagement.Validation;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Utility;
using System.Transactions;
using Microsoft.Reporting.WebForms;
using System.Drawing;
using System.IO;
using System.Data;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// MoveGoodsIssueInspection Controller
    /// Author: ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class OutboundDeliveredInquiryController : BaseController
    {
        #region Common
        
        private DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MCompanyService mCompanyService;
        private int pageSize = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tOutBoundDeliveredService">tOutBoundDeliveredService</param>
        /// <param name="mCustomerService">mCustomerService</param>
        /// <param name="mProductService">mProductService</param>
        /// <paparam name="mKind_DService">MKind_DService</paparam>
        /// <paparam name="mWarehouseService">MWarehouseService</paparam>
        public OutboundDeliveredInquiryController(DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService,
                                                  DataAccess.TShippingInstructionService tShippingInstructionService,
                                                  DataAccess.MCustomerService mCustomerService,
                                                  DataAccess.MProductService mProductService,
                                                  DataAccess.MKind_DService mKind_DService,
                                                  DataAccess.MWarehouseService mWarehouseService,
                                                  DataAccess.MCompanyService mCompanyService)
        {
            this.tOutBoundDeliveredService = tOutBoundDeliveredService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.mCustomerService = mCustomerService;
            this.mProductService = mProductService;
            this.mKind_DService = mKind_DService;
            this.mWarehouseService = mWarehouseService;
            this.mCompanyService = mCompanyService;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region PDF

        //Detail table
        private DataTable dtMain = null;
        private DataTable dtDetail = null;
        private int count = 0;

        /// <summary>
        /// Enum Fields Datatable Main
        /// </summary>
        private enum FieldsMain
        {
            ShipNo = 0,
            Barcode,
            ShipDate,
            InstructDate,
            CustomerCD,
            CustomerName,
            ShippingCompleteFlag,
            DeliveryNumber,
            Address1,
            Address2,
            Address3,
            TotalPage
        }

        /// <summary>
        /// Enum Fields Datatable Main
        /// </summary>
        private enum FieldsMainMove
        {
            ShipNo = 0,
            ShipDate,
            InstructDate,
            DestinationWarehouseCD,
            DestinationWarehouseName,
            TotalPage,
            Barcode,
            ShippingCompleteFlag,
            DestinationLocationCD,
            DestinationLocationName,
            DestinationLocationCDLabel,
            DestinationLocationNameLabel,
            DestinationWarehouseCDLabel,
            DestinationWarehouseNameLabel,
            WarehouseLabel,
            LocationLabel,
            DeliveryNumber
        }

        /// <summary>
        /// Enum Fields Datatable Detail(Sub)
        /// </summary>
        private enum FieldsDetail
        {
            ShipNo = 0,
            OrderNo,
            LocationCD,
            TagNo,
            ProductCD,
            ProductName,
            Lot1,
            Lot2,
            Lot3,
            Quantity,
            TotalLabel,
            RowCount,
            IsDelied
        }

        #endregion

        #region Constant

        private const string PARTIAL_LIST = "_List";
        private const string PARTIAL_DETAIL_LIST = "_DetailList";

        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_DETAIL = "Detail";

        private const string SEARCH_FOCUS_SHIP_NO = "txt_ShipNo";
        private const string SEARCH_FOCUS_NOT_VIEW_TAGNO = "txt_ProductCD";

        private const string DETAIL_FOCUS_DEFAULT = "btnBack";

        private const string SORT_DEFAULT = "ShipNo";
        private const string SORT__DETAIL_DEFAULT = "TagInfo";
        private const string SORT_URL_LIST = "/OutboundDeliveredInquiry/Sorting";
        private const string SORT_URL_PICKING_DETAIL = "/OutboundDeliveredInquiry/SortingDetail";
        private const string PRINT_ACTION_URL = "/OutboundDeliveredInquiry/PrintAction";

        private const string PDF_FILENAME_NOR = "OutboundDeliveryIndication_{0}.pdf";
        private const string PDF_PATH_MAIN_LOCALREPORT_NOR = "~/Report/ShippingInstruction.rdlc";
        private const string PDF_PATH_SUB_LOCALREPORT_NOR = "~/Report/SubShippingInstruction.rdlc";
        private const string PDF_REPORTDATASOURCE_MAIN_NOR = "ShippingInstruction";
        private const string PDF_REPORTDATASOURCE_DETAIL_NOR = "SubShippingInstruction";

        private const string PDF_FILENAME_MOVE = "MoveIndication_{0}.pdf";
        private const string PDF_PATH_MAIN_LOCALREPORT_MOVE = "~/Report/MoveIndication.rdlc";
        private const string PDF_PATH_SUB_LOCALREPORT_MOVE = "~/Report/SubMoveIndication.rdlc";
        private const string PDF_REPORTDATASOURCE_MAIN_MOVE = "MoveIndicationDataSet";
        private const string PDF_REPORTDATASOURCE_DETAIL_MOVE = "SubMoveIndicationDataSet";

        private const int PDF_NUMBER_ROW_PER_FIRST_PAGE = 15;
        private const int PDF_NUMBER_ROW_PER_NEXT_PAGE = 20;

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Event

        #region Index

        /// <summary>
        /// List
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(OutboundDeliveredInquiryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERED_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            if (!String.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
            {
                gmModel.IsUserCustomer = true;
                gmModel.txt_CustomerCD = UserSession.Session.LoginInfo.User.CustomerCD;
                gmModel.txt_CustomerName = UserSession.Session.LoginInfo.User.CustomerName;

                gmModel.ddl_Kind = Constant.MKIND_KINDCD_OUT_KIND_OUTBOUND;
            }
            
            //Sort model state
            this.SortModelState(typeof(OutboundDeliveredInquiryList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                OutboundDeliveredInquiryList oldModel = (OutboundDeliveredInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(OutboundDeliveredInquiryList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<OutboundDeliveredInquiryResults> results = this.tOutBoundDeliveredService.GetListOutboundDeliveredInquiryResultsByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<OutboundDeliveredInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_FOCUS_SHIP_NO);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Set list value of Dropdown list
            this.SetDropDownlist(gmModel.ddl_Kind);

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<OutboundDeliveredInquiryResults> results = this.tOutBoundDeliveredService.GetListOutboundDeliveredInquiryResultsByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL_LIST,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<OutboundDeliveredInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                SetFocusId(SEARCH_FOCUS_SHIP_NO);
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveredInquiryResults> list = (IQueryable<OutboundDeliveredInquiryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<OutboundDeliveredInquiryResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveredInquiryResults> list = (IQueryable<OutboundDeliveredInquiryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<OutboundDeliveredInquiryResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView(PARTIAL_LIST);
        }

        #endregion
        
        #region Detail

        /// <summary>
        /// Sorting Picking List
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult SortingDetail(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveredInquiryDetail> list = (IQueryable<OutboundDeliveredInquiryDetail>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<OutboundDeliveredInquiryDetail>(list, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);

            
            this.Session[Constant.SESSION_LIST_DETAIL_RESULT_VIEW + SeqNum.ToString()] = ViewBag.Result;
            this.Session[Constant.SESSION_DETAIL_SORTING + SeqNum.ToString()] = sortInfo;
            this.Session[Constant.SESSION_DETAIL_PAGING + SeqNum.ToString()] = ViewBag.PagingInfo;

            return PartialView(PARTIAL_DETAIL_LIST);
        }

        /// <summary>
        /// PagingDetail
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult PagingDetail(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveredInquiryDetail> list = (IQueryable<OutboundDeliveredInquiryDetail>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<OutboundDeliveredInquiryDetail>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);
            
            this.Session[Constant.SESSION_LIST_DETAIL_RESULT_VIEW + SeqNum.ToString()] = ViewBag.Result;
            this.Session[Constant.SESSION_DETAIL_SORTING + SeqNum.ToString()] = sortInfo;
            this.Session[Constant.SESSION_DETAIL_PAGING + SeqNum.ToString()] = ViewBag.PagingInfo;

            return PartialView(PARTIAL_DETAIL_LIST);
        }

        /// <summary>
        /// Get Data of Detail
        /// </summary>
        /// <param name="shipNo">Shipping No</param>
        /// <param name="seqNum">Sequence Number</param>
        private void GetDetailData(string shipNo, int seqNum)
        {
            //Search data
            IQueryable<OutboundDeliveredInquiryDetail> results = this.tOutBoundDeliveredService.GetListOutboundDeliveredInquiryDetail(shipNo);

            this.Session[Constant.SESSION_LIST_DETAIL_RESULT + seqNum.ToString()] = results;

            //Create sorting info
            SortingInfo sortInfo = new SortingInfo
            {
                Url = SORT_URL_PICKING_DETAIL,
                SortField = SORT__DETAIL_DEFAULT,
                Direction = SortDirection.Ascending,
            };
            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<OutboundDeliveredInquiryDetail>(ref results, pageRequest, sortInfo, seqNum, pageSize: this.pageSize, notStore: true);
            this.Session[Constant.SESSION_DETAIL_SORTING + seqNum.ToString()] = sortInfo;
            this.Session[Constant.SESSION_DETAIL_PAGING + seqNum.ToString()] = ViewBag.PagingInfo;

            this.Session[Constant.SESSION_LIST_DETAIL_RESULT_VIEW + seqNum.ToString()] = results;
        }

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(int SeqNum, string ShipNo)
        {
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0278);

            //Get info Header
            OutboundDeliveredInquiryHeader model = this.tOutBoundDeliveredService.GetOutboundDeliveredInquiryHeader(ShipNo);

            //Check exclusion
            if (model == default(OutboundDeliveredInquiryHeader))
            {
                return this.ExclusionProcess(SeqNum, null);
            }

            if (string.IsNullOrEmpty(model.txt_CustomerCD))
            {
                this.Session[Constant.SESSION_TITLE + SeqNum.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0255);
            }
            
            model.SeqNum = SeqNum;
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = model;

            this.SetMode(Common.Mode.Show, SeqNum);

            this.GetDetailData(ShipNo, SeqNum);

            //Set focus
            this.SetFocusId(DETAIL_FOCUS_DEFAULT);

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], model.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View(SCREEN_DETAIL, model);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="DataKey">DataKey</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            OutboundDeliveredInquiryHeader gmModel = (OutboundDeliveredInquiryHeader)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            OutboundDeliveredInquiryHeader dbModel = this.tOutBoundDeliveredService.GetOutboundDeliveredInquiryHeader(gmModel.txt_ShipNo);

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0305);

            //Check Exclusion
            if (dbModel == default(OutboundDeliveredInquiryHeader) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum, null);
            }

            if (string.IsNullOrEmpty(gmModel.txt_CustomerCD))
            {
                this.Session[Constant.SESSION_TITLE + SeqNum.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0257);
            }
            
            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set focusId
            this.SetFocusId("txt_DeliveryNumber");

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(OutboundDeliveredInquiryHeader gmModel)
        {
            //calculate Total cost
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveredInquiry/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequen Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            OutboundDeliveredInquiryHeader gmModel = (OutboundDeliveredInquiryHeader)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            
            //Update check
            if (!this.UpdateCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }
            //Update data
            ActionResult ret = default(ActionResult);
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/OutboundDeliveredInquiry/Show", gmModel.SeqNum.ToString(), gmModel.txt_ShipNo);
                    ret = View(SCREEN_DETAIL, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0011));
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredInquiry Header</param>
        /// <returns></returns>
        private bool UpdateCheck(OutboundDeliveredInquiryHeader gmModel)
        {
            TShippingInstruction dbModel = this.tShippingInstructionService.GetByPk(gmModel.txt_ShipNo);

            //Check data changed
            if (dbModel == default(TShippingInstruction) || !dbModel.UpdateDate.Equals(gmModel.UpdateDate))
            {
                //Show error Message
                this.ShowMessageExclusion("/OutboundDeliveredInquiry/Show", gmModel.SeqNum.ToString(), gmModel.txt_ShipNo);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredInquiryHeader</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(OutboundDeliveredInquiryHeader gmModel)
        {
            try
            {
                TShippingInstruction dbModel = this.tShippingInstructionService.GetByPk(gmModel.txt_ShipNo);
                if (dbModel == default(TShippingInstruction) || !dbModel.UpdateDate.Equals(gmModel.UpdateDate))
                {
                    return CommitFlag.DataChanged;
                }

                dbModel.UpdateDate = this.GetCurrentDate();
                dbModel.DeliveryNumber = gmModel.txt_DeliveryNumber;
                dbModel.Memo = gmModel.txt_Memo;

                this.tShippingInstructionService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        #endregion Update

        #region Print

        /// <summary>
        /// Print
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Print(OutboundDeliveredInquiryHeader gmModel)
        {
            //Get model
            TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(gmModel.txt_ShipNo);
            if (shipH == default(TShippingInstruction) || shipH.DeleteFlag)
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }

            this.ShowMessageForPrint(gmModel.SeqNum);


            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="value1">Form From</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        public ActionResult PrintAction(string value1, string value3)
        {
            var gmModel = (OutboundDeliveredInquiryHeader)this.Session[Constant.SESSION_DETAIL_MODEL + value3.ToString()];

            #region download
            var SelectedRows = new List<string>();
            SelectedRows.Add(gmModel.txt_ShipNo);

            //Report
            LocalReport mainLocalReport = new LocalReport();
            LocalReport subLocalReport = new LocalReport();

            if (!string.IsNullOrEmpty(gmModel.txt_CustomerCD))
            {
                //Report dataset
                Report.DataObject.ShippingInstructionDataSet DataSet = new Report.DataObject.ShippingInstructionDataSet();

                //Report Source
                dtMain = DataSet._ShippingInstructionDataSet.Clone();

                //Get data for Header
                IQueryable<Print_OutboundDeliveryIndication_Header> listHeader = this.tShippingInstructionService.GetDataItemPrintHeader(SelectedRows);

                foreach (Print_OutboundDeliveryIndication_Header header in listHeader)
                {
                    DataRow dtMainRow = dtMain.NewRow();
                    InitDataForRowMain(ref dtMainRow, header);
                    dtMain.Rows.Add(dtMainRow);
                }

                //Report path
                mainLocalReport.ReportPath = Server.MapPath(PDF_PATH_MAIN_LOCALREPORT_NOR);
                subLocalReport.ReportPath = Server.MapPath(PDF_PATH_SUB_LOCALREPORT_NOR);

                //Report source
                ReportDataSource ShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_MAIN_NOR, dtMain);

                // Add a handler for SubreportProcessing.
                mainLocalReport.SubreportProcessing +=
                            new SubreportProcessingEventHandler(SubreportProcessingEventHandler);

                mainLocalReport.DataSources.Add(ShippingInstructionTable);

                //Set parameter
                mainLocalReport.SetParameters(this.InitParamsForMainReport());
            }
            else
            {
                Report.DataObject.MoveIndicationDataSet DataSet = new Report.DataObject.MoveIndicationDataSet();

                //Report Source
                dtMain = DataSet._MoveIndicationDataSet.Clone();

                //Get data for Header
                IQueryable<Print_MoveIndication_Header> listHeader = this.tShippingInstructionService.GetDataItemPrintHeaderForMoveIndication(SelectedRows);

                foreach (Print_MoveIndication_Header header in listHeader)
                {
                    DataRow dtMainRow = dtMain.NewRow();
                    InitDataForRowMainMove(ref dtMainRow, header);
                    dtMain.Rows.Add(dtMainRow);

                }

                //Report path
                mainLocalReport.ReportPath = Server.MapPath(PDF_PATH_MAIN_LOCALREPORT_MOVE);
                subLocalReport.ReportPath = Server.MapPath(PDF_PATH_SUB_LOCALREPORT_MOVE);

                //Report source
                ReportDataSource ShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_MAIN_MOVE, dtMain);

                // Add a handler for SubreportProcessing.
                mainLocalReport.SubreportProcessing +=
                            new SubreportProcessingEventHandler(SubreportProcessingEventHandlerMove);

                mainLocalReport.DataSources.Add(ShippingInstructionTable);

                //Set parameter
                mainLocalReport.SetParameters(this.InitParamsForMainReportMove());
 
            }

            //Set Printed Flag      
            CommitFlag UpdateResult = CommitFlag.Success;

            UpdateResult = UpdateShippingPrintFlag(gmModel.txt_ShipNo);

            //Output file for download
            if (UpdateResult == CommitFlag.Success)
            {
                string fileName = string.IsNullOrEmpty(gmModel.txt_CustomerCD) ? PDF_FILENAME_MOVE : PDF_FILENAME_NOR;
                //out put pdf
                FileContentResult file = this.PDFOutPut(mainLocalReport, string.Format(fileName, DateTime.Now.ToString(Constant.FMT_DMY)), Common.ReportType.Business, false);
                TempData[TMP_DOWNLOAD_FILE] = file;
            }

            return Show(int.Parse(value3), gmModel.txt_ShipNo);

            #endregion
        }

        #region Normal

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_OutboundDeliveryIndication_Header</param>
        private void InitDataForRowMain(ref System.Data.DataRow Row, Print_OutboundDeliveryIndication_Header header)
        {
            Row[FieldsMain.ShipNo.ToString()] = header.ShipNo;

            string barCode = header.ShipNo;
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row[FieldsMain.Barcode.ToString()] = Stream.ToArray();
            Row[FieldsMain.ShipDate.ToString()] = string.IsNullOrEmpty(header.ShipDate) ? string.Empty : CommonUtil.ParseDate(header.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.InstructDate.ToString()] = string.IsNullOrEmpty(header.InstructDate) ? string.Empty : CommonUtil.ParseDate(header.InstructDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.CustomerCD.ToString()] = header.CustomerCD;
            Row[FieldsMain.CustomerName.ToString()] = header.CustomerName;
            Row[FieldsMain.ShippingCompleteFlag.ToString()] = header.ShippingCompleteFlag;

            Row[FieldsMain.DeliveryNumber.ToString()] = header.DeliveryNumber;
            Row[FieldsMain.Address1.ToString()] = header.Address1;
            Row[FieldsMain.Address2.ToString()] = header.Address2;
            Row[FieldsMain.Address3.ToString()] = header.Address3;

            IQueryable<Print_OutboundDeliveryIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetail(header.ShipNo, header.ShippingCompleteFlag);
            Row[FieldsMain.TotalPage.ToString()] = this.GetTotalPage(listDetail.Count()).ToString();
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_OutboundDeliveryIndication_Detail</param>
        /// <param name="RowIndex">RowIndex</param>
        private void InitDataForRowDetail(ref System.Data.DataRow Row, Print_OutboundDeliveryIndication_Detail Data, int RowIndex, int RowCount)
        {
            Row[FieldsDetail.ShipNo.ToString()] = Data.ShipNo;
            Row[FieldsDetail.OrderNo.ToString()] = RowIndex;
            Row[FieldsDetail.LocationCD.ToString()] = Data.LocationCD;
            Row[FieldsDetail.TagNo.ToString()] = Data.TagNo;
            Row[FieldsDetail.ProductCD.ToString()] = Data.ProductCD;
            Row[FieldsDetail.ProductName.ToString()] = Data.ProductName;
            Row[FieldsDetail.Lot1.ToString()] = Data.Lot1;
            Row[FieldsDetail.Lot2.ToString()] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Lot3.ToString()] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Quantity.ToString()] = Data.Quantity;
            Row[FieldsDetail.TotalLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0175);
            Row[FieldsDetail.RowCount.ToString()] = RowCount;
        }

        /// <summary>
        /// Create Detail Data
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <param name="ShippingCompleteFlg">ShippingCompleteFlg</param>
        /// <returns>DataTable</returns>
        private DataTable CreateDetailData(string shipNo, bool ShippingCompleteFlg)
        {
            //Set data for detail table
            dtDetail = new DataTable();
            Report.DataObject.SubShippingInstructionDataSet SubDataSet = new Report.DataObject.SubShippingInstructionDataSet();
            dtDetail = SubDataSet._SubShippingInstructionDataSet.Clone();
            List<Print_OutboundDeliveryIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetail(shipNo, ShippingCompleteFlg).ToList();
            int count = listDetail.Count();
            for (int j = 0; j < count; j++)
            {
                var dtRow = dtDetail.NewRow();
                InitDataForRowDetail(ref dtRow, listDetail[j], j + 1, count);
                dtDetail.Rows.Add(dtRow);

            }
            return dtDetail;
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRAM
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForMainReport()
        {
            //Set Parameters
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;
            string space = "";
            ReportParameter titleReport = new ReportParameter("titleReport", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0170));
            ReportParameter companyName = new ReportParameter("companyName", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            ReportParameter shipNo = new ReportParameter("shipNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0171));
            ReportParameter shipDate = new ReportParameter("shipDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0147));
            ReportParameter instructDate = new ReportParameter("instructDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0173));
            ReportParameter customerCD = new ReportParameter("customerCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
            ReportParameter customerName = new ReportParameter("customerNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0029));
            ReportParameter page = new ReportParameter("pageLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172));
            ReportParameter orderNo = new ReportParameter("orderNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0151));
            ReportParameter location = new ReportParameter("locationLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
            ReportParameter tagNo = new ReportParameter("tagNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter productCD = new ReportParameter("productCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("productNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter lot1 = new ReportParameter("lot1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter lot2 = new ReportParameter("lot2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("lot3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter quantity = new ReportParameter("quantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0174));
            ReportParameter deliveryNumber = new ReportParameter("deliveryNumberLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0301));

            return new ReportParameterCollection { titleReport, companyName, shipNo, shipDate, instructDate, customerCD, customerName, page, orderNo, location, tagNo, productCD, productName, lot1, lot2, lot3, quantity, deliveryNumber };
        }

        #endregion

        #region Move

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_MoveIndication_Header</param>
        private void InitDataForRowMainMove(ref System.Data.DataRow Row, Print_MoveIndication_Header header)
        {
            Row[FieldsMainMove.ShipNo.ToString()] = header.ShipNo;
            string locationTo = string.Empty;
            string barCode = header.ShipNo;
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row[FieldsMainMove.Barcode.ToString()] = Stream.ToArray();
            Row[FieldsMainMove.ShipDate.ToString()] = string.IsNullOrEmpty(header.ShipDate) ? string.Empty : CommonUtil.ParseDate(header.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMainMove.InstructDate.ToString()] = string.IsNullOrEmpty(header.InstructDate) ? string.Empty : CommonUtil.ParseDate(header.InstructDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMainMove.ShippingCompleteFlag.ToString()] = header.ShippingCompleteFlag;
            Row[FieldsMainMove.DeliveryNumber.ToString()] = header.DeliveryNumber;
            if (!string.IsNullOrEmpty(header.DestinationWarehouseCD))
            {
                Row[FieldsMainMove.DestinationWarehouseCD.ToString()] = header.DestinationWarehouseCD;
                Row[FieldsMainMove.DestinationWarehouseName.ToString()] = header.DestinationWarehouseCDNm;
                Row[FieldsMainMove.DestinationLocationCD.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationName.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseCDLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193);
                Row[FieldsMainMove.DestinationWarehouseNameLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0194);
                Row[FieldsMainMove.DestinationLocationCDLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationNameLabel.ToString()] = "";
            }
            else if (!string.IsNullOrEmpty(header.DestinationLocationCD))
            {
                Row[FieldsMainMove.DestinationWarehouseCD.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseName.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationCD.ToString()] = header.DestinationLocationCD;
                Row[FieldsMainMove.DestinationLocationName.ToString()] = header.DestinationLocationCDNm;
                Row[FieldsMainMove.DestinationWarehouseCDLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseNameLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationCDLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0191);
                Row[FieldsMainMove.DestinationLocationNameLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0192);
                locationTo = header.DestinationLocationCD;
            }
            else
            {
                Row[FieldsMainMove.DestinationWarehouseCD.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseName.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationCD.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationName.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseCDLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationWarehouseNameLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationCDLabel.ToString()] = "";
                Row[FieldsMainMove.DestinationLocationNameLabel.ToString()] = "";
            }

            IQueryable<Print_MoveIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetailForMoveIndication(header.ShipNo, header.ShippingCompleteFlag, locationTo);
            Row[FieldsMain.TotalPage.ToString()] = this.GetTotalPage(listDetail.Count()).ToString();
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_MoveIndication_Detail</param>
        /// <param name="RowIndex">RowIndex</param>
        private void InitDataForRowDetailMove(ref System.Data.DataRow Row, Print_MoveIndication_Detail Data, int RowIndex, int RowCount)
        {
            Row[FieldsDetail.ShipNo.ToString()] = Data.ShipNo;
            Row[FieldsDetail.OrderNo.ToString()] = RowIndex;
            Row[FieldsDetail.LocationCD.ToString()] = Data.LocationCD;
            Row[FieldsDetail.TagNo.ToString()] = Data.TagNo;
            Row[FieldsDetail.ProductCD.ToString()] = Data.ProductCD;
            Row[FieldsDetail.ProductName.ToString()] = Data.ProductName;
            Row[FieldsDetail.Lot1.ToString()] = Data.Lot1;
            Row[FieldsDetail.Lot2.ToString()] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Lot3.ToString()] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Quantity.ToString()] = Data.Quantity;
            Row[FieldsDetail.TotalLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0175);
            Row[FieldsDetail.RowCount.ToString()] = RowCount;
            Row[FieldsDetail.IsDelied.ToString()] = Data.IsDelied;
        }

        /// <summary>
        /// Create Detail Data
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <param name="ShippingCompleteFlg">ShippingCompleteFlg</param>
        /// <returns>DataTable</returns>
        private DataTable CreateDetailDataMove(string moveNo, bool ShippingCompleteFlg, string locationTo)
        {
            //Set data for detail table
            dtDetail = new DataTable();
            Report.DataObject.SubMoveIndicationDataSet SubDataSet = new Report.DataObject.SubMoveIndicationDataSet();
            dtDetail = SubDataSet._SubMoveIndicationDataSet.Clone();
            List<Print_MoveIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetailForMoveIndication(moveNo, ShippingCompleteFlg, locationTo).ToList();
            int count = listDetail.Count();
            for (int j = 0; j < count; j++)
            {
                var dtRow = dtDetail.NewRow();
                InitDataForRowDetailMove(ref dtRow, listDetail[j], j + 1, count);
                dtDetail.Rows.Add(dtRow);

            }
            return dtDetail;
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRAM
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForMainReportMove()
        {
            //Set Parameters	
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;
            string space = "";
            ReportParameter titleWare = new ReportParameter("titleWarehouse", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0293));
            ReportParameter titleLo = new ReportParameter("titleLocation", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0294));
            ReportParameter titleSr = new ReportParameter("titleScrap", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0295));
            ReportParameter companyName = new ReportParameter("companyName", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            ReportParameter shipNo = new ReportParameter("shipNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
            ReportParameter shipDate = new ReportParameter("shipDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
            ReportParameter instructDate = new ReportParameter("instructDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0173));
            ReportParameter page = new ReportParameter("pageLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172));
            ReportParameter orderNo = new ReportParameter("orderNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0151));
            ReportParameter locationLabel = new ReportParameter("locationLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
            ReportParameter tagNo = new ReportParameter("tagNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter productCD = new ReportParameter("productCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("productNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter lot1 = new ReportParameter("lot1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter lot2 = new ReportParameter("lot2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("lot3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter quantity = new ReportParameter("quantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0174));
            ReportParameter deliveryNumber = new ReportParameter("deliveryNumberLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0301));
            return new ReportParameterCollection { titleWare, titleLo, titleSr, companyName, shipNo, shipDate, instructDate, page, locationLabel, orderNo, tagNo, productCD, productName, lot1, lot2, lot3, quantity, deliveryNumber };
        }

        #endregion Move

        /// <summary>
        /// Get Total Page
        /// </summary>
        /// <param name="rowNum">Detail row number</param>
        /// <returns>int</returns>
        private int GetTotalPage(int rowNum)
        {
            int pageTotal = 0;

            if (rowNum > 0)
            {
                //if detail table's number row <=15
                if (rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE <= 1)
                {
                    //if detail table's number row =15
                    if (rowNum % PDF_NUMBER_ROW_PER_FIRST_PAGE == 0)
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE;
                    }
                    else//if detail table's number row <15
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE + 1;
                    }
                }
                else//if detail table's number row >15
                {
                    //Init pageTotal for first page
                    pageTotal = 1;

                    //Set pageTotal for after pages
                    if ((rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) % PDF_NUMBER_ROW_PER_NEXT_PAGE == 0)
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE;
                    }
                    else
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE + 1;
                    }
                }
            }
            return pageTotal;
        }

        /// <summary>
        ///  Show Message For Print
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void ShowMessageForPrint(int SeqNum)
        {
            //Show confirm message
            this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
            value3: SeqNum.ToString());
        }

        #region Handle

        /// <summary>
        /// Subreport Processing Event Handler
        /// Author: ISV-TRAM
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SubreportProcessingEventHandler(object sender, SubreportProcessingEventArgs e)
        {
            LocalReport localReport = (LocalReport)sender;
            ReportDataSourceCollection data = localReport.DataSources;
            DataTable dt = (DataTable)data[0].Value;

            dtDetail = this.CreateDetailData(dt.Rows[count++][FieldsMain.ShipNo.ToString()].ToString(), (bool)dt.Rows[0][FieldsMain.ShippingCompleteFlag.ToString()]);
            ReportDataSource SubShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_DETAIL_NOR, dtDetail);
            e.DataSources.Add(SubShippingInstructionTable);
        }

        /// <summary>
        /// Subreport Processing Event Handler
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SubreportProcessingEventHandlerMove(object sender, SubreportProcessingEventArgs e)
        {
            LocalReport localReport = (LocalReport)sender;
            ReportDataSourceCollection data = localReport.DataSources;
            DataTable dt = (DataTable)data[0].Value;
            int i = count;
            count++;
            dtDetail = this.CreateDetailDataMove(dt.Rows[i][FieldsMainMove.ShipNo.ToString()].ToString(), (bool)dt.Rows[0][FieldsMainMove.ShippingCompleteFlag.ToString()], dt.Rows[i][FieldsMainMove.DestinationLocationCD.ToString()].ToString());
            ReportDataSource SubMoveTable = new ReportDataSource(PDF_REPORTDATASOURCE_DETAIL_MOVE, dtDetail);
            e.DataSources.Add(SubMoveTable);
        }

        #endregion

        #endregion Print

        #endregion Event

        #region Method

        ///<summary>
        ///Set DropDownlist
        ///</summary>
        ///<param name="moveKind">Move Kind</param>
        private void SetDropDownlist(string moveKind)
        {
            //Get List MKind_D: Move Kind
            List<MKind_D> dropKind = this.mKind_DService.GetListByKindForOutboundInquiry(Constant.MKIND_KINDCD_OUTBOUND_KIND).ToList();
            
            MKind_D emptyItem = new MKind_D();
            emptyItem.KindCD = Constant.MKIND_KINDCD_OUTBOUND_KIND;
            emptyItem.DataCD = string.Empty;
            emptyItem.Value = Constant.BLANK;

            dropKind.Insert(0, emptyItem);

            this.CreateViewBagKind(dropKind, "ddl_Kind", moveKind);
        }

        ///<summary>
        ///Create Move Kind: MoveKind SelectList
        ///</summary>
        ///<param name="dropSrc">Dropdownlist</param>
        ///<param name="control">Control name</param>
        ///<param name="value">Selected value</param>
        private void CreateViewBagKind(List<MKind_D> dropSrc, string control, string value)
        {
            SelectOption option = new SelectOption("Value", "DataCD", control, value);
            this.SetViewDataDropdownList<MKind_D>(option, dropSrc);
        }

        #endregion

        #region Exclusion

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="message">message error</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum, string message)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/OutboundDeliveredInquiry/Index", message: message);

            OutboundDeliveredInquiryHeader model = new OutboundDeliveredInquiryHeader();
            model.SeqNum = SeqNum;

            return View(SCREEN_DETAIL, model);
        }

        #endregion Exclution

        #region "Registration"

        /// <summary>
        /// Update ShippingPrintFlag After Printed
        /// Author : ISV-LOC
        /// </summary>
        /// <param name="gmListShipNo">List Of ShipNo</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdateShippingPrintFlag(string shipNo)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();

                //update ShippingPrintFlag for Detail
                TShippingInstruction entity = this.tShippingInstructionService.GetByPk(shipNo);

                entity.ShippingPrintFlag = true;
                entity.UpdateDate = updateDate;
                entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                this.tShippingInstructionService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = string.Empty;

                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }
            return ret;
        }

        #endregion

        #region Ajax

        /// <summary>
        /// Show CustomerName
        /// </summary>
        /// <param name="CustomerCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowCustomerNm(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerCD = CustomerCD.ToUpper();
            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);

            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.CustomerName,
                        model.Address1,
                        model.Address2,
                        model.Address3
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show WarehouseName
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowWarehouseName(string WarehouseCD)
        {
            if (string.IsNullOrEmpty(WarehouseCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            WarehouseModels model = this.mWarehouseService.GetByCd(WarehouseCD);

            if (model != default(WarehouseModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.WarehouseName
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion Ajax

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(OutboundDeliveredInquiryHeader gmModel)
        {
            this.ClearModelState();
            if (this.GetMode(gmModel.SeqNum) != Mode.Show)
            {
                return this.Show(gmModel.SeqNum, gmModel.txt_ShipNo);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion Back

    }
}

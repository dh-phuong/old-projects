﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using InventoryManagement.Common;
using InventoryManagement.Models;
using System.Web.Helpers;
using System.Transactions;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Collections;
using Microsoft.Reporting.WebForms;
using InventoryManagement.Report;

namespace InventoryManagement.Controllers
{
    [InventoryManagement.Validation.iAuthorize]
    public class StockTakeProclamationController : BaseController
    {
        #region Common

        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TInventory_DService tInventory_DService;

        private DataAccess.MLocationService mLocationService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TTakeInventory_DService tTakeInventory_DService;
        private DataAccess.TTakeInventory_HService tTakeInventory_HService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        
        private DataAccess.TTakeHistory_HService tTakeHistory_HService;
        private DataAccess.TTakeHistory_DService tTakeHistory_DService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.TSequencesService tSequencesService;

        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.MWarehouseService mWarehouseService;

        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;
        
        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="tInventoryService">商品マスター</param>
        /// <param name="mProductService">倉庫マスター</param>
        /// <param name="mWarehouseService">在庫データ</param>
        /// <param name="mKind_DService">MKind_D</param>
        /// <param name="mCompanyService">MCompanyService</param>
        /// <param name="mWarehouseService">MWarehouseService</param>
        public StockTakeProclamationController(DataAccess.TInventory_HService tInventory_HService,
                                            DataAccess.TInventory_DService tInventory_DService,
                                            DataAccess.MLocationService mLocationService,
                                            DataAccess.TReserveService tReserveService,
                                            DataAccess.TTakeInventory_DService tTakeInventory_DService,
                                            DataAccess.TTakeInventory_HService tTakeInventory_HService,
                                            DataAccess.TPessimisticLockService tPessimisticLockService,
                                            DataAccess.TTakeHistory_HService tTakeHistory_HService,
                                            DataAccess.TTakeHistory_DService tTakeHistory_DService,
                                            DataAccess.TBalanceInStoresService tBalanceInStoresService,
                                            DataAccess.TSequencesService tSequencesService,
                                            DataAccess.MCompanyService mCompanyService,
                                            DataAccess.MWarehouseService mWarehouseService,
                                            DataAccess.MKind_DService mKind_DService
            )
        {
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();

            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.mLocationService = mLocationService;
            this.tReserveService = tReserveService;
            this.tTakeInventory_DService = tTakeInventory_DService;
            this.tTakeInventory_HService = tTakeInventory_HService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.tTakeHistory_HService = tTakeHistory_HService;
            this.tTakeHistory_DService = tTakeHistory_DService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.tSequencesService = tSequencesService;
            this.mCompanyService = mCompanyService;
            this.mWarehouseService = mWarehouseService;
            this.mKind_DService = mKind_DService;
            
            this.tInventory_HService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.mLocationService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tTakeInventory_DService.Context = ctx;
            this.tTakeInventory_HService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;

            this.tTakeHistory_HService.Context = ctx;
            this.tTakeHistory_DService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.mCompanyService.Context = ctx;
            this.mWarehouseService.Context = ctx;

            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string PARTIAL_LIST = "_List";
        private const string PARTIAL_DETAIL_LIST = "_ListDetail";
        
        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_DETAIL = "Detail";

        private const string KEY_LOCATIONCD = "txt_LocationCD";
        private const string KEY_LIST_CHK_PROCLAMATION = "chk_select_all";

        private const string SORT_DEFAULT = "LocationCD";
        private const string SORT_URL = "/StockTakeProclamation/Sorting";
        private const string SORT_DETAIL_URL = "/StockTakeProclamation/DetailSorting";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        private const string SESSION_LOCATION_CD = "Ses_Location_Cd";

        #endregion

        #region Event

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">StockTakeProclamationList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(StockTakeProclamationList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(StockTakeProclamationList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                StockTakeProclamationList oldModel = (StockTakeProclamationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(StockTakeProclamationList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    this.ShowGridView(gmModel, false);
                    //Focus
                    this.SetFocusId(KEY_LOCATIONCD);
                }
            }
            
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                this.ShowGridView(gmModel, true);

                //Store Proclamation Hastable
                this.Session[Constant.SESSION_SELECTED_ITEM + gmModel.SeqNum.ToString()] = new Hashtable();

                this.ModelState.Clear();
                this.SetFocusId(KEY_LOCATIONCD);
            }
          
            return View(SCREEN_INDEX, gmModel);
        }

        #region Proclamation

        /// <summary>
        /// Proclamation
        /// </summary>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Proclamation(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }
            StockTakeProclamationList gmModel = (StockTakeProclamationList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum];
            
            Hashtable hashtable = (Hashtable)this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum.ToString()];

            //Filter selected row
            List<string> listLocationCD = hashtable.Keys.OfType<string>().ToList();

            //Show Grid View
            this.ShowGridView(gmModel, false);

            //Print Key
            ViewBag.SeqNum = SeqNum;
            this.ModelState.Clear();

            //Check Data
            if (!this.LocationCheck(gmModel, listLocationCD))
            {
                return View(SCREEN_INDEX, gmModel);
            }

            //Set mode state
            this.SetMode(Common.Mode.Insert, gmModel.SeqNum);
            this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

            //Show message confirm
            string message = this.FormatMessage(Constant.MES_M0085);
            this.ShowMessageConfirm(gmModel.SeqNum, "/StockTakeProclamation/ProclamationAction", value1: gmModel.SeqNum.ToString(), message: message);
            
            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Proclamation Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult ProclamationAction(string value1)
        {
            //Clear ModeState
            this.ClearModelState();

            StockTakeProclamationList gmModel = (StockTakeProclamationList)this.Session[Constant.SESSION_LIST_CONDITION + value1];
            
            //Show Gridview
            this.ShowGridView(gmModel, false);
            
            CommitFlag result = CommitFlag.Success;
            Hashtable hashtable = (Hashtable)this.Session[Constant.SESSION_SELECTED_ITEM + value1];

            //Filter selected row
            List<string> listLocationCD = hashtable.Keys.OfType<string>().ToList();

            //Check Data
            if (!this.LocationCheck(gmModel,listLocationCD))
            {
                return View(SCREEN_INDEX, gmModel);
            }
            
            //Update data
            result = this.UpdateData(listLocationCD);
            
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (result)
            {
                case CommitFlag.DataIsEmpty:
                    message = this.FormatMessage(Constant.MES_E0009);
                    this.ShowMessageExclusion("/StockTakeProclamation/Index",string.Empty, gmModel.SeqNum.ToString(), message: message);
                    ret = View(SCREEN_INDEX, gmModel);  
                    break;
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/StockTakeProclamation/Index", string.Empty, gmModel.SeqNum.ToString());
                    ret = View(SCREEN_INDEX, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_LIST_CONDITION + value1] = null;
                    this.Session[Constant.SESSION_LIST_RESULT + value1] = null;
                    this.Session[Constant.SESSION_SELECTED_ITEM + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = View(SCREEN_INDEX, gmModel);
                    break;
            }
            return ret;
        }

        #endregion
               
        #endregion

        #region Detail Show

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/StockTakeProclamation/Index");
            StockTakeProclamationDetailModel model = new StockTakeProclamationDetailModel();            
            model.SeqNum = SeqNum;
            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="value1">LocationCD</param>
        /// <param name="value2">Sequense Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            StockTakeProclamationDetailModel model = new StockTakeProclamationDetailModel();

            //Get Location
            LocationModels loc = mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, value1);
            model.LocationCD = loc.LocationCD;
            model.LocationName = loc.LocationName;

            //Get TakeInventory 
            TTakeInventory_H takeInventoryH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeInventoryH != null)
            {
                model.TakeStartDate = CommonUtil.ParseDate(takeInventoryH.TakeStartDate, Constant.FMT_YMD, Constant.FMT_DATE);
                model.TakeEndDate = string.Empty;
            }
            else
            {
                TTakeHistory_H takeHistoryH = this.tTakeHistory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                if (takeHistoryH != null)
                {
                    model.TakeStartDate = CommonUtil.ParseDate(takeHistoryH.TakeStartDate, Constant.FMT_YMD, Constant.FMT_DATE);
                    model.TakeEndDate = CommonUtil.ParseDate(takeHistoryH.TakeEndDate, Constant.FMT_YMD, Constant.FMT_DATE);
                }
                else
                {
                    this.TempData[TEMP_SEQNUM] = model.SeqNum;
                    return this.ExclusionProcess(model.SeqNum);                    
                }
            }

            Session[SESSION_LOCATION_CD] = value1;

            model.SeqNum = (int)value2;

            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        #endregion

        #region Detail Defference List Print

        /// <summary>
        /// DefferenceList Print Confirm
        /// </summary>
        /// <param name="model">StockTakeProclamationDetailModel</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DefferenceListPrintConfirm(StockTakeProclamationDetailModel model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Store model into Session
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            var existInTakeInventory = this.tTakeInventory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            var existInHistory = this.tTakeHistory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (!existInTakeInventory && !existInHistory)
            {
                this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));

            }
            else
            {
                //Show message confirm
                string message = message = this.FormatMessage(Constant.MES_M0020);
                this.ShowMessageConfirm(model.SeqNum, "/StockTakeProclamation/DefferenceListPrintAction", message: message, value1: model.SeqNum.ToString());
            }
           
            //Load Data
            this.LoadData(model);
            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// DefferenceList Print Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DefferenceListPrintAction(string value1)
        {
            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            #region DifferenceCheckList
            var existInTakeInventory = this.tTakeInventory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            var existInHistory = this.tTakeHistory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            List<DifferenceCheckList> ReportDataSource = null;
            if (existInTakeInventory)
            {
                ReportDataSource = this.tTakeInventory_HService.GetDifferenceCheckList(model.LocationCD);
            }
            else if (existInHistory)
            {
                ReportDataSource = this.tTakeHistory_HService.GetDifferenceCheckList(model.LocationCD);
            }

            const int PDF_NUMBER_ROW_PER_FIRST_PAGE = 15;
            const int PDF_NUMBER_ROW_PER_NEXT_PAGE = 20;

            //download file name
            var filename = string.Format("InventoryDefferenceList_{0}.pdf",DateTime.Now.ToString(Constant.FMT_DMY));

            LocalReport localReport = new LocalReport();

            localReport.ReportPath = Server.MapPath("~/Report/DifferenceCheckList.rdlc");

            string crrtLocationCD = string.Empty;
            int RowIndex = 1;
            var totalPage = 1;
            var group = ReportDataSource.GroupBy(m => m.LocationCD).ToList();
            foreach (var item in group)
            {
                if (crrtLocationCD != item.Key)
                {
                    //Reset group info
                    RowIndex = 1;
                    totalPage = 1;
                    crrtLocationCD = item.Key;
                    var SubList = ReportDataSource.Where(m => m.LocationCD.Equals(crrtLocationCD));

                    //Get Total Page
                    var totalRowofGroup = SubList.Count(m => m.LocationCD.Equals(crrtLocationCD));
                    if (totalRowofGroup > PDF_NUMBER_ROW_PER_FIRST_PAGE)
                    {
                        if ((totalRowofGroup - PDF_NUMBER_ROW_PER_FIRST_PAGE) % PDF_NUMBER_ROW_PER_NEXT_PAGE != 0)
                            totalPage += 1;
                        totalPage = totalPage + (totalRowofGroup - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE;
                    }

                    //Set Group Info
                    foreach (var item1 in SubList)
                    {
                        item1.RowIndex = RowIndex;
                        item1.TakeStartDate = string.IsNullOrEmpty(item1.TakeStartDate) ? string.Empty : CommonUtil.ParseDate(item1.TakeStartDate, Constant.FMT_YMD, Constant.FMT_DATE);
                        item1.TakeEndDate = string.IsNullOrEmpty(item1.TakeEndDate) ? string.Empty : CommonUtil.ParseDate(item1.TakeEndDate, Constant.FMT_YMD, Constant.FMT_DATE);
                        item1.Lot2 = string.IsNullOrEmpty(item1.Lot2) ? string.Empty : CommonUtil.ParseDate(item1.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
                        item1.Lot3 = string.IsNullOrEmpty(item1.Lot3) ? string.Empty : CommonUtil.ParseDate(item1.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
                        item1.TotalPage = totalPage;
                        RowIndex += 1;
                    }
                }
            }

            //Report source
            ReportDataSource dataSource = new ReportDataSource("DifferenceCheckList", ReportDataSource);

            localReport.DataSources.Add(dataSource);

            //Set Parameters
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;

            //Set label
            localReport.SetLabelFromCache(
                                           new KeyValuePair<string, string>("PageLabel", Constant.LBL_L0172),
                                           new KeyValuePair<string, string>("NoLabel", Constant.LBL_L0151),
                                           new KeyValuePair<string, string>("Taglabel", Constant.LBL_L0106),
                                           new KeyValuePair<string, string>("ProductCDLabel", Constant.LBL_L0018),
                                           new KeyValuePair<string, string>("ProductNameLabel", Constant.LBL_L0019),
                                           new KeyValuePair<string, string>("LOT1Label", Constant.LBL_L0084),
                                           new KeyValuePair<string, string>("LOT2Label", Constant.LBL_L0085),
                                           new KeyValuePair<string, string>("LOT3Label", Constant.LBL_L0086),
                                           new KeyValuePair<string, string>("CheckLabel", Constant.LBL_L0286),
                                           new KeyValuePair<string, string>("LocationNameLabel", Constant.LBL_L0052),
                                           new KeyValuePair<string, string>("LocationCDLabel", Constant.LBL_L0051),
                                           new KeyValuePair<string, string>("TitleReport", Constant.LBL_L0285),
                                           new KeyValuePair<string, string>("DateLabel", Constant.LBL_L0251),
                                           new KeyValuePair<string, string>("InChargePersonLabel", Constant.LBL_L0270),
                                           new KeyValuePair<string, string>("ApprovalPersonLabel", Constant.LBL_L0271),
                                           new KeyValuePair<string, string>("TakeStartDateLabel", Constant.LBL_L0272),
                                           new KeyValuePair<string, string>("MaruLabel", Constant.LBL_L0217),
                                           new KeyValuePair<string, string>("PositiveLabel", Constant.LBL_L0238),
                                           new KeyValuePair<string, string>("NegativeLabel", Constant.LBL_L0239)
                                        );

            localReport.SetLabelValue("CompanyName", companyNm + (" ").PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            var file = this.PDFOutPut(localReport, filename, ReportType.Business, false);
            this.StoreFileDownload(file, model.SeqNum);
            ViewBag.IsDownload = true;
            return Show(model.LocationCD, model.SeqNum);         
            #endregion
        }

        #endregion

        #region Detail Stock Taking List Print

        /// <summary>
        /// StockTakingList Print Confirm
        /// </summary>
        /// <param name="model">StockTakeProclamationDetailModel</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult StockTakingListPrintConfirm(StockTakeProclamationDetailModel model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Store model into Session
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;
            
            var existInTakeInventory = this.tTakeInventory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (!existInTakeInventory)
            {
                this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
            }
            else
            {
                //Show message confirm
                string message = message = this.FormatMessage(Constant.MES_M0020);
                this.ShowMessageConfirm(model.SeqNum, "/StockTakeProclamation/StockTakingListPrintAction", message: message, value1: model.SeqNum.ToString());
            }
            
            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// StockTakingList Print Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]        
        public ActionResult StockTakingListPrintAction(string value1)
        {
            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            var lstInventoryCheckList = this.tTakeInventory_HService.GetInventoryCheckList(model.LocationCD);

            if (lstInventoryCheckList.Count > 0)
            {
                const int PDF_NUMBER_ROW_PER_FIRST_PAGE = 15;
                const int PDF_NUMBER_ROW_PER_NEXT_PAGE = 20;
                const int ROW_BLANK_COUNT = 5;

                //download file name
                var filename = string.Format("InventoryCheckList_{0}.pdf", DateTime.Now.ToString(Constant.FMT_DMY));
                LocalReport localReport = new LocalReport(); 
                localReport.ReportPath = Server.MapPath("~/Report/InventoryCheckList.rdlc");

                string crrtLocationCD = string.Empty;
                int RowIndex = 1;
                var totalPage = 1;

                var group = lstInventoryCheckList.GroupBy(m => m.LocationCD).ToList();

                foreach (var item in group)
                {
                    if (crrtLocationCD != item.Key)
                    {
                        //Reset group info
                        RowIndex = 1;
                        totalPage = 1;
                        crrtLocationCD = item.Key;
                        var SubList = lstInventoryCheckList.Where(m => m.LocationCD.Equals(crrtLocationCD));

                        //Get Total Page
                        var totalRowofGroup = SubList.Count(m => m.LocationCD.Equals(crrtLocationCD)) + ROW_BLANK_COUNT;
                        if (totalRowofGroup > PDF_NUMBER_ROW_PER_FIRST_PAGE)
                        {
                            if ((totalRowofGroup - PDF_NUMBER_ROW_PER_FIRST_PAGE) % PDF_NUMBER_ROW_PER_NEXT_PAGE != 0)
                                totalPage += 1;
                            totalPage = totalPage + (totalRowofGroup - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE;
                        }

                        //Set Group Info
                        foreach (var item1 in SubList)
                        {
                            item1.RowIndex = RowIndex;
                            item1.TakeStartDate = string.IsNullOrEmpty(item1.TakeStartDate) ? string.Empty : CommonUtil.ParseDate(item1.TakeStartDate, Constant.FMT_YMD, Constant.FMT_DATE);
                            item1.Lot2 = string.IsNullOrEmpty(item1.Lot2) ? string.Empty : CommonUtil.ParseDate(item1.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
                            item1.Lot3 = string.IsNullOrEmpty(item1.Lot3) ? string.Empty : CommonUtil.ParseDate(item1.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
                            item1.TotalPage = totalPage;
                            RowIndex += 1;
                        }

                        //add 6 Row blank
                        for (int j = 0; j < ROW_BLANK_COUNT; j++)
                        {
                            lstInventoryCheckList.Add(new InventoryCheckList
                            {
                                RowIndex = RowIndex,
                                TotalPage = totalPage,
                                LocationCD = crrtLocationCD
                            });
                            RowIndex += 1;
                        }

                    }
                }

                //Report source
                ReportDataSource dataSource = new ReportDataSource("InventoryCheckList", lstInventoryCheckList);

                localReport.DataSources.Add(dataSource);

                //Set Parameters
                MCompany mCompany = mCompanyService.GetMCompany();
                MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
                string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;

                //Set label
                localReport.SetLabelFromCache(
                                               new KeyValuePair<string, string>("PageLabel", Constant.LBL_L0172),
                                               new KeyValuePair<string, string>("NoLabel", Constant.LBL_L0151),
                                               new KeyValuePair<string, string>("Taglabel", Constant.LBL_L0106),
                                               new KeyValuePair<string, string>("ProductCDLabel", Constant.LBL_L0018),
                                               new KeyValuePair<string, string>("ProductNameLabel", Constant.LBL_L0019),
                                               new KeyValuePair<string, string>("LOT1Label", Constant.LBL_L0084),
                                               new KeyValuePair<string, string>("LOT2Label", Constant.LBL_L0085),
                                               new KeyValuePair<string, string>("LOT3Label", Constant.LBL_L0086),
                                               new KeyValuePair<string, string>("CheckLabel", Constant.LBL_L0276),
                                               new KeyValuePair<string, string>("LocationNameLabel", Constant.LBL_L0052),
                                               new KeyValuePair<string, string>("LocationCDLabel", Constant.LBL_L0051),
                                               new KeyValuePair<string, string>("TitleReport", Constant.LBL_L0273),
                                               new KeyValuePair<string, string>("DateLabel", Constant.LBL_L0251),
                                               new KeyValuePair<string, string>("InChargePersonLabel", Constant.LBL_L0270),
                                               new KeyValuePair<string, string>("ApprovalPersonLabel", Constant.LBL_L0271),
                                               new KeyValuePair<string, string>("TakeStartDateLabel", Constant.LBL_L0272)

                                            );

                localReport.SetLabelValue("CompanyName", companyNm + (" ").PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);

                var file = this.PDFOutPut(localReport, filename, ReportType.Business, false);

                this.StoreFileDownload(file, model.SeqNum);

                ViewBag.IsDownload = true;
            }
            else
            {
                this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
            }
            return Show(model.LocationCD, model.SeqNum);
        }

        #endregion

        #region Detail Decision

        /// <summary>
        /// Decision Confirm
        /// </summary>
        /// <param name="model">StockTakeProclamationDetailModel</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DecisionConfirm(StockTakeProclamationDetailModel model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            int count = this.tInventory_DService.GetCountSurplusChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (count > 0)
            {
                string message = this.FormatMessage(Constant.MES_M0086);
                this.ModelState.AddModelError(string.Empty, message);
            } 

            //Update Take History Header
            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
            }            

            if (this.ModelState.IsValid)
            {
                //Store model into Session
                this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

                //Show message confirm
                IQueryable<TTakeInventory_D> listTakeInventoryD = this.tTakeInventory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                string message = string.Empty;
                message = this.FormatMessage(Constant.MES_M0067);
                this.ShowMessageConfirm(model.SeqNum, "/StockTakeProclamation/DecisionConfirm2", message: message, value1: model.SeqNum.ToString());
            }

            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Decision Confirm 2
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DecisionConfirm2(string value1)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            int count = this.tInventory_DService.GetCountSurplusChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);            
            if (count > 0)
            {
                string message = this.FormatMessage(Constant.MES_M0086);
                this.ModelState.AddModelError(string.Empty, message);
            }            

            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
            }

            if (this.ModelState.IsValid)
            {
                string message = string.Empty;
                message = this.FormatMessage(Constant.MES_M0068);
                this.ShowMessageConfirm(Convert.ToInt32(value1), "/StockTakeProclamation/DecisionConfirm3", message: message, value1: value1);
            }            

            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Decision Confirm 3
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DecisionConfirm3(string value1)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            int count = this.tInventory_DService.GetCountSurplusChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (count > 0)
            {
                string message = this.FormatMessage(Constant.MES_M0086);
                this.ModelState.AddModelError(string.Empty, message);
            } 

            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
            }

            if (this.ModelState.IsValid)
            {
                string message = string.Empty;
                message = this.FormatMessage(Constant.MES_M0069);
                this.ShowMessageConfirm(Convert.ToInt32(value1), "/StockTakeProclamation/DecisionAction", message: message, value1: value1);
            }                        

            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Decision Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DecisionAction(string value1)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            int count = this.tInventory_DService.GetCountSurplusChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (count > 0)
            {
                string message = this.FormatMessage(Constant.MES_M0086);
                this.ModelState.AddModelError(string.Empty, message);

                //Load Data
                this.LoadData(model);

                return View(SCREEN_DETAIL, model);
            }            

            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);

                //Load Data
                this.LoadData(model);

                return View(SCREEN_DETAIL, model);
            }
            
            //Decision Data
            CommitFlag flag = this.DecisionData(model);
            if (flag == CommitFlag.DataChanged)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);

                //Load Data
                this.LoadData(model);

                return View(SCREEN_DETAIL, model);
            }
            if (flag == CommitFlag.Failed)
            {
                string message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);

                //Load Data
                this.LoadData(model);

                return View(SCREEN_INDEX, model);
            }

            //
            this.TempData[TEMP_SEQNUM] = model.SeqNum;
            return RedirectToAction("Index");
            
        }

        #endregion

        #region Detail Cancel

        /// <summary>
        /// Cancel Confirm
        /// </summary>
        /// <param name="model">StockTakeProclamationDetailModel</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CancelConfirm(StockTakeProclamationDetailModel model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Update Take History Header
            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
            }
            else
            {
                //Show message confirm
                string message = this.FormatMessage(Constant.MES_M0066);
                this.ShowMessageConfirm(model.SeqNum, "/StockTakeProclamation/CancelAction", message: message, value1: model.SeqNum.ToString());

                //Store model into Session
                this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;   
            }

            //Load Data
            this.LoadData(model);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Cancel Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CancelAction(string value1)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_STOCK_TAKING_PROCLAIM))
            {
                return this.RedirectNotAuthority();
            }

            //Get data from session
            StockTakeProclamationDetailModel model = (StockTakeProclamationDetailModel)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update Take History Header
            TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takeinvenH == default(TTakeInventory_H))
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);

                //Load Data
                this.LoadData(model);

                return View(SCREEN_DETAIL, model);
            }
            else
            {
                //Cancel Data
                CommitFlag flag = this.CancelData(model);
                if (flag == CommitFlag.DataChanged)
                {
                    string message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);

                    //Load Data
                    this.LoadData(model);

                    return View(SCREEN_DETAIL, model);
                }
                if (flag == CommitFlag.Failed)
                {
                    string message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);

                    //Load Data
                    this.LoadData(model);

                    return View(SCREEN_DETAIL, model);
                }

                this.TempData[TEMP_SEQNUM] = model.SeqNum;
                return RedirectToAction("Index");
            }            
        }

        #endregion

        #region Detail Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">StockTakeProclamationDetailModel</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(StockTakeProclamationDetailModel model)
        {
            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = model.SeqNum;
            return RedirectToAction("Index");
        }

        #endregion

        #region Ajax

        /// <summary>
        /// Show Location Name
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>
        [HttpPost]
        public string ShowLocationNm(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return string.Empty;
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);

            if (model != default(LocationModels) && model != null && !model.DeleteFlag)
            {
                return model.LocationName;
            }
            return string.Empty;
        }

        /// <summary>
        /// Check Proclamation ALL
        /// </summary>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public void CheckProclamationALL(bool Checked, int SeqNum)
        {
            Hashtable ListItems = (Hashtable)this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum.ToString()];

            //Clear list location
            ListItems.Clear();

            //Add Location
            if (Checked)
            {
                IQueryable<StockTakeProclamationResults> results = (IQueryable<StockTakeProclamationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

                foreach (var row in results.Where(m => !m.IsTakingFlag))
                {
                    ListItems.Add(row.LocationCD, true);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum.ToString()] = ListItems;
        }

        /// <summary>
        /// Check Proclamation Item At
        /// </summary>
        /// <param name="Key">LocationCD</param>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public bool CheckProclamationItemAt(string Key, bool Checked, int SeqNum)
        {
            Hashtable ListItems = (Hashtable)this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum.ToString()];
            IQueryable<StockTakeProclamationResults> results = (IQueryable<StockTakeProclamationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Add Location
            if (Checked)
            {
                if (!ListItems.ContainsKey(Key) && results.Where(m => m.LocationCD.Equals(Key) && !m.IsTakingFlag).SingleOrDefault() != null)
                {
                    ListItems.Add(Key, true);
                }
            }
            else
            {
                //Remove Location
                if (ListItems.ContainsKey(Key))
                {
                    ListItems.Remove(Key);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum.ToString()] = ListItems;
            bool checkAll = (ListItems.Count == results.Count(m => !m.IsTakingFlag));
            return checkAll;
        }

        #endregion

        #region Setting

        /// <summary>
        /// Set Possible All
        /// </summary>
        /// <param name="list">List StockTakeProclamationResults</param>
        /// <param name="SeqNum">Sequense Number</param>
        private void SetPossibleAll(List<StockTakeProclamationResults> list, int SeqNum)
        {
            foreach (StockTakeProclamationResults row in list)
            {
                if (this.tTakeInventory_HService.IsExistByLocationUnCompleted(UserSession.Session.LoginInfo.WarehouseCD, row.LocationCD))
                {
                    row.StatusTaking = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0226);
                    row.IsTakingFlag = true;

                    //Reset field 
                    Hashtable hashtable = (Hashtable)this.Session[Constant.SESSION_SELECTED_ITEM + SeqNum];

                    if (hashtable != null && hashtable.ContainsKey(row.LocationCD))
                    {
                        hashtable.Remove(row.LocationCD);
                        row.chk_Proclamation = false;
                    }
                }
                else
                {
                    row.StatusTaking = string.Empty;
                }
            }
        }

        #endregion

        #region Check

        /// <summary>
        /// Location Check
        /// </summary>
        /// <param name="gmModel">StockTakeProclamationList</param>
        /// <param name="listLocationCD">list LocationCD</param>
        /// <returns>boolean</returns>
        private bool LocationCheck(StockTakeProclamationList gmModel, List<string> listLocationCD)
        {
            bool result = true;
            string message = string.Empty;
            
            if (listLocationCD.Count == 0)
            {
                message = this.FormatMessage(Constant.MES_M0014);
                this.ModelState.AddModelError(KEY_LIST_CHK_PROCLAMATION, message);
                return false;
            }
            //Sort Key
            listLocationCD.Sort();
            foreach (string LocationCD in listLocationCD)
            {
                LocationModels mLocation = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);

                //locationCD is Not Exist
                if (mLocation == default(LocationModels) || mLocation.DeleteFlag)
                {
                    // エラーメッセージを返す
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0245));
                    this.ModelState.AddModelError(string.Empty, message);
                    continue;
                }
                //The input LocationCD is exist shipping instruction. (Check in TReserve)
                if (this.tReserveService.ExistLocationShipping(UserSession.Session.LoginInfo.WarehouseCD, LocationCD))
                {
                    // エラーメッセージを返す
                    message = this.FormatMessage(Constant.MES_M0055, LocationCD);
                    this.ModelState.AddModelError(string.Empty, message);
                    result = false;
                    continue;
                }

                //The input LocationCD is exist with StockStatus = "10" 入荷（良品）
                if (this.tInventory_DService.IsExistLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD, Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE))
                {
                    // エラーメッセージを返す
                    message = this.FormatMessage(Constant.MES_M0063, LocationCD);
                    this.ModelState.AddModelError(string.Empty, message);
                    result = false;
                    continue;
                }

                //Location exist tagno selected for moving
                if (this.tInventory_DService.IsExistLocationForMoving(UserSession.Session.LoginInfo.WarehouseCD, LocationCD))
                {
                    message = this.FormatMessage(Constant.MES_M0055, LocationCD);
                    this.ModelState.AddModelError(string.Empty, message);
                    result = false;
                    continue;
                }

                //The input LocationCD is exist in TTakeInventory_H TakingCompleteFlg = false
                if (this.tTakeInventory_HService.IsExistByLocationUnCompleted(UserSession.Session.LoginInfo.WarehouseCD, LocationCD))
                {
                    //エラーメッセージを返す
                    message = this.FormatMessage(Constant.MES_M0056);
                    this.ModelState.AddModelError(string.Empty, message);
                    result = false;
                    continue;
                }
            }

            return result;
        }

        #endregion

        #region Paging and Sorting

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockTakeProclamationResults> result = (IQueryable<StockTakeProclamationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            IQueryable<StockTakeProclamationResults> outList = this.AddValueFromIQueryAble(result, SeqNum);
            //Paging
            this.PagingBase<StockTakeProclamationResults>(ref outList, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockTakeProclamationResults> result = (IQueryable<StockTakeProclamationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //
            IQueryable<StockTakeProclamationResults> outList = this.AddValueFromIQueryAble(result, SeqNum);

            //Sorting
            this.SortingBase<StockTakeProclamationResults>(outList, sortInfo, SeqNum, pageSize: this.pageSize);

            StockTakeProclamationList oldModel = (StockTakeProclamationList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Add Value From IQueryAble
        /// </summary>
        /// <param name="result">IQueryable StockTakeProclamationResults</param>
        /// <returns>IQueryable StockTakeProclamationResults</returns>
        private IQueryable<StockTakeProclamationResults> AddValueFromIQueryAble(IQueryable<StockTakeProclamationResults> result, int SeqNum)
        {
            List<StockTakeProclamationResults> list = result.ToList();
            this.SetPossibleAll(list, SeqNum);
            IQueryable<StockTakeProclamationResults> outList = list.AsQueryable();
            return outList;
        }

        /// <summary>
        /// Show GridView
        /// </summary>
        /// <param name="gmModel">StockTakeProclamationList</param>
        /// <param name="saveSession">Is Save Session</param>
        private void ShowGridView(StockTakeProclamationList gmModel, bool saveSession)
        {
            IQueryable<StockTakeProclamationResults> results;
            SortingInfo sortInfo;
            PagingRequest pageRequest;
            
            if (saveSession)
            {
                results = this.tTakeInventory_HService.GetListStockTakeProclamationbyConditions(gmModel);
                sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };
                pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;
                
                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Store SortingInfo into session
                this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()] = sortInfo;

                //Store PagingRequest into session
                this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()] = pageRequest;
            }
            else
            {
                //Sorting
                sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];
                pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];
                results = (IQueryable<StockTakeProclamationResults>)this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()];
            }

            IQueryable<StockTakeProclamationResults> outList = this.AddValueFromIQueryAble(results, gmModel.SeqNum);
            this.PagingBase<StockTakeProclamationResults>(ref outList, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize, notStore: true);
        }
        
        #endregion

        #region Detail Paging and Sorting

        /// <summary>
        ///  Paging
        /// </summary>                
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>      
        /// <returns></returns>
        [HttpPost]
        public ActionResult DetailPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            TTakeInventory_H takeInventoryH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString());
            ViewBag.LockDecision = false;
            if (takeInventoryH != null)
            {
                ViewBag.CountDeficit = this.tTakeInventory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
                ViewBag.CountSurplus = this.tTakeInventory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
            }
            else
            {
                ViewBag.LockDecision = true;
                ViewBag.CountDeficit = this.tTakeHistory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
                ViewBag.CountSurplus = this.tTakeHistory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
            }

            //Get search result from session
            IQueryable<StockTakeProclamationDetailResults> list = (IQueryable<StockTakeProclamationDetailResults>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<StockTakeProclamationDetailResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);
            return PartialView(PARTIAL_DETAIL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DetailSorting(SortingInfo sortInfo, int SeqNum)
        {
            TTakeInventory_H takeInventoryH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString());
            ViewBag.LockDecision = false;
            if (takeInventoryH != null)
            {

                ViewBag.CountDeficit = this.tTakeInventory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
                ViewBag.CountSurplus = this.tTakeInventory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
            }
            else
            {
                ViewBag.LockDecision = true;
                ViewBag.CountDeficit = this.tTakeHistory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
                ViewBag.CountSurplus = this.tTakeHistory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, Session[SESSION_LOCATION_CD].ToString()).Count().ToString();
            }

            //Get search result from session
            IQueryable<StockTakeProclamationDetailResults> list = (IQueryable<StockTakeProclamationDetailResults>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<StockTakeProclamationDetailResults>(list, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);

            return PartialView(PARTIAL_DETAIL_LIST);
        }

        #endregion

        #region Registration

        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="listLocationCD">list LocationCD</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdateData(List<string> listLocationCD)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                    foreach (string LocationCD in listLocationCD)
                    {
                        List<string> listTagNo = this.tTakeInventory_HService.GetListTagNoByLocationCDForStockTakeProclamation(LocationCD);
                        
                        foreach (string tagNo in listTagNo)
                        {
                            TPessimisticLock lockRecord = new TPessimisticLock();
                            lockRecord.TagNo = tagNo;
                            if (!listInsert.Any(m => m.TagNo.Equals(tagNo)))
                            {
                                listInsert.Add(lockRecord);
                            }
                        }
                    }
                    
                    if (listInsert.Count > 0)
                    {
                        this.tPessimisticLockService.Insert(listInsert);
                        this.tTakeInventory_HService.Context.SubmitChanges();
                    }
                    string curDate = this.GetCurrentDate();

                    //Insert/ Update Taking
                    this.SetUpdateByListLocationCD(listLocationCD, curDate);
                    
                    if (listInsert.Count > 0)
                    {
                        //Remove lock
                        this.tPessimisticLockService.Delete(listInsert);
                    }
                    //Submit 
                    this.tTakeInventory_HService.Context.SubmitChanges();
                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TTAKEINVENTORY_D_PK)
                        || sqlEx.Message.Contains(Constant.DB_TTAKEINVENTORY_H_PK)
                        || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK)
                        || sqlEx.Message.Contains(Constant.DB_MLocation_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;

        }

        /// <summary>
        /// Set Update By List LocationCD
        /// </summary>
        /// <param name="listLocationCD">list LocationCD</param>
        /// <param name="curDate">curDate</param>
        private void SetUpdateByListLocationCD(List<string> listLocationCD, string curDate)
        {
            foreach (string LocationCD in listLocationCD)
            {
                MLocation dbModel_Location = new MLocation();
                dbModel_Location = this.mLocationService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
                if (dbModel_Location == null)
                {
                    continue;
                }
            
                //Get TTakeInventory_H by Location, Warehouse
                TTakeInventory_H dbModel_TH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
                if (dbModel_TH == default(TTakeInventory_H))
                {
                    //=>Insert
                    dbModel_TH = this.GetInsertTakeInventoryHeader(dbModel_Location, curDate);
                    this.tTakeInventory_HService.Insert(dbModel_TH);
                }
                else
                {
                    //=>Update
                    //==>Update Header
                    this.SetUpdateTakeInventoryHeader(dbModel_TH, dbModel_Location, curDate);
                    //==>Delete Detail
                    List<TTakeInventory_D> listDbModel_TD_Upd = this.tTakeInventory_DService.GetListByLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
                    this.tTakeInventory_DService.Delete(listDbModel_TD_Upd);

                }
                //=>Insert Detail
                List<TTakeInventory_D> listDbModel_TD_Ins = this.GetInsertListDetail(LocationCD, curDate);
                if (listDbModel_TD_Ins.Count > 0)
                {
                    this.tTakeInventory_DService.Insert(listDbModel_TD_Ins);
                }
                //Update MLocation
                this.SetUpdateLocation(dbModel_Location, curDate);
            }
        }

        /// <summary>
        /// Get Insert Take Inventory Header
        /// </summary>
        /// <param name="dbModel_Location">MLocation</param>
        /// <param name="curDate">curDate</param>
        /// <returns>TTakeInventory_H</returns>
        private TTakeInventory_H GetInsertTakeInventoryHeader(MLocation dbModel_Location, string curDate)
        {
            TTakeInventory_H dbModel_TH = new TTakeInventory_H();
            dbModel_TH.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            dbModel_TH.LocationCD = dbModel_Location.LocationCD;
            dbModel_TH.TakeStartDate = curDate.Substring(0, 8);
            dbModel_TH.TakeEndDate = null;
            dbModel_TH.TakeCompleteFlag = false;
            dbModel_TH.BeforeIssueProhibitionFlag = dbModel_Location.IssueProhibitionFlag;
            dbModel_TH.BeforeReceiptProhibitionFlag = dbModel_Location.ReceiptProhibitionFlag;
            dbModel_TH.DeleteFlag = false;
            dbModel_TH.CreateDate = curDate;
            dbModel_TH.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            dbModel_TH.UpdateDate = curDate;
            dbModel_TH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            return dbModel_TH;
        }

        /// <summary>
        /// Set Update Take Inventory Header
        /// </summary>
        /// <param name="dbModel_TH">TTakeInventory_H</param>
        /// <param name="dbModel_Location">MLocation</param>
        /// <param name="curDate">curDate</param>
        private void SetUpdateTakeInventoryHeader(TTakeInventory_H dbModel_TH, MLocation dbModel_Location, string curDate)
        {
            dbModel_TH.TakeStartDate = curDate.Substring(0, 8);
            dbModel_TH.TakeEndDate = null;
            dbModel_TH.TakeCompleteFlag = false;
            dbModel_TH.BeforeIssueProhibitionFlag = dbModel_Location.IssueProhibitionFlag;
            dbModel_TH.BeforeReceiptProhibitionFlag = dbModel_Location.ReceiptProhibitionFlag;
            dbModel_TH.DeleteFlag = false;
            dbModel_TH.UpdateDate = curDate;
            dbModel_TH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Set Update Location
        /// </summary>
        /// <param name="dbModel">MLocation</param>
        /// <param name="curDate">curDate</param>
        /// <param name="dc">DataClasses1DataContext</param>
        private void SetUpdateLocation(MLocation dbModel, string curDate)
        {
                dbModel.IssueProhibitionFlag = true;
                dbModel.ReceiptProhibitionFlag = true;
                dbModel.UpdateDate = curDate;
                dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            
        }

        /// <summary>
        /// Get Insert List Detail
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <param name="curDate">curDate</param>
        /// <param name="dc">DataClasses1DataContext</param>
        /// <returns>List TTakeInventory_D</returns>
        private List<TTakeInventory_D> GetInsertListDetail(string LocationCD, string curDate)
        {
            List<TTakeInventory_D> listDbModel_TD = new List<TTakeInventory_D>();
            IQueryable<StockTakeProclamationDetail> listDetail = this.tInventory_DService.GetListByLocationForStockTakeProclamation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            foreach (StockTakeProclamationDetail detail in listDetail)
            {
                TTakeInventory_D dbModel_TD = new TTakeInventory_D();
                dbModel_TD.TagNo = detail.TagNo;
                dbModel_TD.BranchTagNo = detail.BranchTagNo;
                dbModel_TD.TakeStatus = null;
                dbModel_TD.ProductCD = detail.ProductCD;
                dbModel_TD.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
                dbModel_TD.LocationCD = LocationCD;
                dbModel_TD.StoredCost = detail.StoredCost;
                dbModel_TD.QuantityPerUnit = detail.QuantityPerUnit;
                dbModel_TD.UnitQuantity = detail.UnitQuantity;
                dbModel_TD.TotalCost = detail.TotalCost;
                dbModel_TD.LOT1 = detail.LOT1;
                dbModel_TD.LOT2 = detail.LOT2;
                dbModel_TD.LOT3 = detail.LOT3;
                dbModel_TD.TakeFlag = false;
                dbModel_TD.TakeStartDate = curDate.Substring(0, 8);
                dbModel_TD.TakeDate = null;
                dbModel_TD.DeleteFlag = false;
                dbModel_TD.CreateDate = curDate;
                dbModel_TD.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                dbModel_TD.UpdateDate = curDate;
                dbModel_TD.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                listDbModel_TD.Add(dbModel_TD);
            }
            return listDbModel_TD;
        }

        #endregion

        #region Private

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="model">StockTakeInspectionList Model</param>
        private void LoadData(StockTakeProclamationDetailModel model)
        {
            //Search data
            IQueryable<StockTakeProclamationDetailResults> results;

            TTakeInventory_H takeInventoryH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);

            ViewBag.LockDecision = false;
            if (takeInventoryH != null)
            {
                results = this.tTakeInventory_DService.GetListStockTakeProclamationDetailResults(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);

                ViewBag.CountDeficit = this.tTakeInventory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD).Count().ToString();
                ViewBag.CountSurplus = this.tTakeInventory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD).Count().ToString();
            }
            else
            {
                ViewBag.LockDecision = true;
                results = this.tTakeHistory_DService.GetListStockTakeProclamationDetailResults(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);

                ViewBag.CountDeficit = this.tTakeHistory_DService.GetListDeficit(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD).Count().ToString();
                ViewBag.CountSurplus = this.tTakeHistory_DService.GetListSurplus(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD).Count().ToString();
            }

            //Store result into session
            this.Session[Constant.SESSION_LIST_DETAIL_RESULT + model.SeqNum.ToString()] = results;

            //Create sorting info
            var sortInfo = new SortingInfo
            {
                Url = SORT_DETAIL_URL,
                SortField = "UpdateDate",
                Direction = SortDirection.Descending,
            };

            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<StockTakeProclamationDetailResults>(ref results, pageRequest, sortInfo, model.SeqNum, pageSize: this.pageSize, notStore: true);
        }

        /// <summary>
        /// Insert Balance In Stores
        /// </summary>
        /// <param name="sequencesModel">Sequences Model</param>
        /// <param name="inventoryDetail">Inventory Detail</param>
        /// <param name="curDate">Current Date</param>
        private void InsertBalanceInStores(TInventory_D inventoryDetail, string stockStatus, string warehouseCD, string locationCD, string curDate)
        {
            TBalanceInStores balanceinstoresModel = new TBalanceInStores();

            //string maxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

            //balanceinstoresModel.BalanceNo = maxTagNo;
            balanceinstoresModel.BalanceStatus = stockStatus;
            balanceinstoresModel.BalanceDate = DateTime.Now.ToString(Constant.FMT_YMD);
            balanceinstoresModel.TagNo = inventoryDetail.TagNo;
            balanceinstoresModel.BranchTagNo = inventoryDetail.BranchTagNo;
            balanceinstoresModel.WarehouseCD = warehouseCD;
            balanceinstoresModel.LocationCD = locationCD;
            balanceinstoresModel.CreateDate = curDate;
            balanceinstoresModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            balanceinstoresModel.UpdateDate = curDate;
            balanceinstoresModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

            this.tBalanceInStoresService.Insert(balanceinstoresModel);
        }        

        /// <summary>
        /// Update Take History Header
        /// </summary>
        /// <param name="model">StockTakeProclamationDetailModel</param>
        /// <param name="takeinvenH">Take History Header</param>
        /// <param name="curDate">Current Date</param>
        private void UpdateTakeHistoryHeader(StockTakeProclamationDetailModel model, TTakeInventory_H takeinvenH, string curDate)
        {
            TTakeHistory_H takehistoryH = this.tTakeHistory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
            if (takehistoryH != null)
            {
                this.tTakeHistory_HService.Delete(takehistoryH);
            }            

            takehistoryH = new TTakeHistory_H();
            this.tTakeHistory_HService.Insert(takehistoryH);

            takehistoryH.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            takehistoryH.LocationCD = model.LocationCD;
            takehistoryH.TakeStartDate = takeinvenH.TakeStartDate;
            takehistoryH.TakeEndDate = DateTime.Now.ToString(Constant.FMT_YMD);
            takehistoryH.TakeCompleteFlag = true;
            takehistoryH.DeleteFlag = false;
            takehistoryH.CreateDate = takeinvenH.CreateDate;
            takehistoryH.CreateUCD = takeinvenH.CreateUCD;
            takehistoryH.UpdateDate = curDate;
            takehistoryH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Update Location Master
        /// </summary>
        /// <param name="locaionCD">Locaion Code</param>
        /// <param name="beforeIssueProhibitionFlag">Before Issue Prohibition Flag</param>
        /// <param name="beforeReceiptProhibitionFlag">Before Receipt Prohibition Flag</param>
        /// <param name="curDate">Current Date</param>
        private void UpdateLocation(string locaionCD, bool beforeIssueProhibitionFlag, bool beforeReceiptProhibitionFlag, string curDate)
        {
            MLocation loc = mLocationService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, locaionCD);
            loc.IssueProhibitionFlag = beforeIssueProhibitionFlag;
            loc.ReceiptProhibitionFlag = beforeReceiptProhibitionFlag;
            loc.UpdateDate = curDate;
            loc.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }        

        /// <summary>
        /// Decision Data
        /// </summary>
        /// <param name="model">Stock Take Inspection List Model</param>
        /// <returns></returns>
        private CommitFlag DecisionData(StockTakeProclamationDetailModel model)
        {
            try
            {
                //Get Current Date
                string curDate = this.GetCurrentDate();

                //Update Take History Header
                TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                if (takeinvenH == default(TTakeInventory_H))
                {
                    return CommitFlag.DataChanged;
                }                
                this.UpdateTakeHistoryHeader(model, takeinvenH, curDate);                

                //Delete Take Inventory Header
                this.tTakeInventory_HService.Delete(takeinvenH);

                //Delete Take History Detail
                IQueryable<TTakeHistory_D> listHistoryD = this.tTakeHistory_DService.GetAllByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                foreach (TTakeHistory_D item in listHistoryD)
                {
                    this.tTakeHistory_DService.Delete(item);
                }

                //Insert TakeHistory Detail
                IQueryable<TTakeInventory_D> listTakeInventoryD = this.tTakeInventory_DService.GetAllByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                foreach (TTakeInventory_D item in listTakeInventoryD)
                {
                    TTakeHistory_D temp = new TTakeHistory_D();
                    temp.TagNo = item.TagNo;
                    temp.BranchTagNo = item.BranchTagNo;
                    temp.TakeStatus = item.TakeStatus;
                    if (string.IsNullOrEmpty(temp.TakeStatus))
                    {
                        item.TakeStatus = Constant.TAKE_STATUS_ISSUE;
                    }
                    temp.ProductCD = item.ProductCD;
                    temp.WarehouseCD = item.WarehouseCD;
                    temp.LocationCD = item.LocationCD;
                    temp.StoredCost = item.StoredCost;
                    temp.QuantityPerUnit = item.QuantityPerUnit;
                    temp.UnitQuantity = item.UnitQuantity;
                    temp.TotalCost = item.TotalCost;
                    temp.LOT1 = item.LOT1;
                    temp.LOT2 = item.LOT2;
                    temp.LOT3 = item.LOT3;
                    temp.TakeFlag = item.TakeFlag;
                    temp.TakeStartDate = item.TakeStartDate;
                    temp.TakeDate = item.TakeDate;
                    temp.DeleteFlag = item.DeleteFlag;
                    temp.CreateDate = item.CreateDate;
                    temp.CreateUCD = item.CreateUCD;
                    temp.UpdateDate = item.UpdateDate;
                    temp.UpdateUCD = item.UpdateUCD;

                    this.tTakeInventory_DService.Delete(item);
                    this.tTakeHistory_DService.Insert(temp);
                }

                //Update Inventory
                TBalanceInStores balanceinstoresModel = new TBalanceInStores();
                //TSequences sequencesModel = this.tSequencesService.GetByPK(Constant.TAGNO_DIVISION_BALANCENO);
                //Update Inventory Detail
                IQueryable<TInventory_D> listInventoryDSurplus = this.tInventory_DService.GetListSurplusChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);

                IDictionary<string, TReserve> reserveListOld = new Dictionary<string, TReserve>();
                IDictionary<string, TReserve> reserveListNew = new Dictionary<string, TReserve>();
                foreach (TInventory_D item in listInventoryDSurplus)
                {
                    TInventory_H header = tInventory_HService.GetByPK(item.TagNo);

                    if (item.StockStatus == Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE || item.StockStatus == Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) 
                    {
                        this.InsertBalanceInStores(item, Constant.TAKE_STATUS_ISSUE, header.WarehouseCD, item.LocationCD, curDate);                    
                    }
                    
                    this.InsertBalanceInStores(item, Constant.TAKE_STATUS_RECEIPTS, UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD, curDate);                    

                    if (item.LocationCD != model.LocationCD && !string.IsNullOrEmpty(item.ShippingNo))
                    {
                        TReserve tReOld;
                        if (reserveListOld.ContainsKey(item.ShippingNo + item.TagNo + item.LocationCD))
                        {
                            tReOld = reserveListOld[item.ShippingNo + item.TagNo + item.LocationCD];
                        }
                        else
                        {
                            tReOld = tReserveService.GetByPK(item.ShippingNo, item.TagNo, item.LocationCD);                            
                        }

                        if (tReOld != null)
                        {
                            if (!reserveListOld.ContainsKey(item.ShippingNo + item.TagNo + item.LocationCD))
                            {
                                reserveListOld.Add(item.ShippingNo + item.TagNo + item.LocationCD, tReOld);
                            }

                            if (!item.PickingFlag.Value)
                            {
                                tReOld.RemainQuantity -= 1;
                            }
                            tReOld.Quantity -= 1;

                            TReserve tReNew;
                            if (reserveListNew.ContainsKey(item.ShippingNo + item.TagNo + model.LocationCD))
                            {
                                tReNew = reserveListNew[item.ShippingNo + item.TagNo + model.LocationCD];
                            }
                            else
                            {
                                tReNew = new TReserve();
                                tReNew.ShipNo = item.ShippingNo;
                                tReNew.TagNo = item.TagNo;
                                tReNew.LocationCD = model.LocationCD;
                                tReNew.ShipDetailNo = tReOld.ShipDetailNo;
                                reserveListNew.Add(item.ShippingNo + item.TagNo + model.LocationCD, tReNew);
                            }

                            if (!item.PickingFlag.Value)
                            {
                                tReNew.RemainQuantity += 1;
                            }
                            tReNew.Quantity += 1;
                        }                        
                    }

                    item.LocationCD = model.LocationCD;
                    item.StoredDate = DateTime.Now.ToString(Constant.FMT_YMD);
                    item.UpdateDate = curDate;
                    item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                    //Insert BalanceInStores
                    if (
                        string.IsNullOrEmpty(item.ShippingNo) ||
                        ( 
                            !string.IsNullOrEmpty(item.ShippingNo) && (item.StockStatus == Constant.STOCK_STATUS_DELIVERY || item.StockStatus == Constant.STOCK_STATUS_DELIVERY_DEFECTIVE || item.StockStatus == Constant.STOCK_STATUS_DELIVERY_SCRAP)
                        )
                       )
                    {
                        //this.InsertBalanceInStores(sequencesModel, item, Constant.TAKE_STATUS_ISSUE, header.WarehouseCD, item.LocationCD, curDate);
                        //this.InsertBalanceInStores(sequencesModel, item, Constant.TAKE_STATUS_RECEIPTS, UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD, curDate);                       

                        //item.LocationCD = model.LocationCD;

                        //Update Inventory Detail 
                        if (item.StockStatus == Constant.STOCK_STATUS_DELIVERY || item.StockStatus == Constant.STOCK_STATUS_DELIVERY_DEFECTIVE || item.StockStatus == Constant.STOCK_STATUS_DELIVERY_SCRAP)
                        {
                            item.StockStatus = Constant.STOCK_STATUS_RECEIPT_DEFECTIVE;
                        }
                        else
                        {
                            item.StockStatus = Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE;
                        }                        
                        
                        item.ShippingNo = null;
                        item.ShippingDetailNo = null;
                        item.TagPrintFlag = false;
                        item.PickingFlag = false;
                        item.DeliveryPrintFlag = false;
                        item.DeliveryFlag = false;                        
                    }
                    else
                    {
                        //this.InsertBalanceInStores(sequencesModel, item, Constant.TAKE_STATUS_RECEIPTS, UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD, curDate);
                    }                    

                    //Update Inventory Header
                    //header.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
                }

                //Update TReserve
                foreach (TReserve item in reserveListOld.Values)
                {
                    if (item.Quantity <= 0)
                    {
                        tReserveService.Delete(item);
                    }
                }

                //Insert TReserve
                foreach (TReserve item in reserveListNew.Values)
                {
                    tReserveService.Insert(item);                    
                }  

                //Update Inventory Detail
                IQueryable<TInventory_D> listInventoryDNormal = this.tInventory_DService.GetListNormalChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                foreach (TInventory_D item in listInventoryDNormal)
                {
                    //Insert BalanceInStores
                    //this.InsertBalanceInStores(sequencesModel, item, Constant.TAKE_STATUS_RECEIPTS, UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD, curDate);

                    //Update Inventory Detail                
                    //item.StockStatus = Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE;

                    item.LocationCD = model.LocationCD;
                    item.StoredDate = DateTime.Now.ToString(Constant.FMT_YMD);
                    item.ShippingNo = null;
                    item.ShippingDetailNo = null;
                    item.TagPrintFlag = false;
                    item.PickingFlag = false;
                    item.DeliveryPrintFlag = false;
                    item.DeliveryFlag = false;
                    item.UpdateDate = curDate;
                    item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }

                //Update Inventory Detail
                IQueryable<TInventory_D> listInventoryDNotChecked = this.tInventory_DService.GetListPickingNotChecked(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                foreach (TInventory_D item in listInventoryDNotChecked)
                {
                    //Insert BalanceInStores
                    this.InsertBalanceInStores(item, Constant.TAKE_STATUS_ISSUE, UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD, curDate);

                    //Update Inventory Detail
                    item.StockStatus = Constant.STOCK_STATUS_ISSUE_INVENTORY;
                    item.UpdateDate = curDate;
                    item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }

                //Update Location
                this.UpdateLocation(model.LocationCD, takeinvenH.BeforeIssueProhibitionFlag, takeinvenH.BeforeReceiptProhibitionFlag, curDate);

                this.tTakeInventory_DService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Process Cancel Data
        /// </summary>
        /// <param name="model">Stock Take Proclamation Detail Model</param>
        /// <returns></returns>
        private CommitFlag CancelData(StockTakeProclamationDetailModel model)
        {
            try
            {
                //Delete TakeInventory Header
                TTakeInventory_H takeinvenH = this.tTakeInventory_HService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                if (takeinvenH == default(TTakeInventory_H))
                {
                    return CommitFlag.DataChanged;
                }
                else
                {
                    this.tTakeInventory_HService.Delete(takeinvenH);
                }                

                //Delete TakeInventory Detail
                IQueryable<TTakeInventory_D> listTakeInventoryD = this.tTakeInventory_DService.GetAllByLocation(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                foreach (TTakeInventory_D item in listTakeInventoryD)
                {
                    this.tTakeInventory_DService.Delete(item);
                }

                //Update Location
                if (takeinvenH != null)
                {
                    this.UpdateLocation(model.LocationCD, takeinvenH.BeforeIssueProhibitionFlag, takeinvenH.BeforeReceiptProhibitionFlag, this.GetCurrentDate());
                }

                this.tTakeInventory_DService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        #endregion
    }
}

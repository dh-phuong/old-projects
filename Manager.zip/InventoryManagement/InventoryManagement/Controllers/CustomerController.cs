﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Web.Helpers;
using System.Data.SqlClient;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Customer Master
    /// Author: ISV-LOC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class CustomerController : BaseController
    {
        #region Common

        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.TStockAllowanceService tStockAllowanceService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;
        
        
        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="mCustomerService"></param>
        /// <param name="tStockAllowanceService"></param>
        /// <param name="mKind_DService"></param>
        public CustomerController(DataAccess.MCustomerService mCustomerService, 
                                  DataAccess.TStockAllowanceService tStockAllowanceService, 
                                  DataAccess.MKind_DService mKind_DService)
        {
            this.mCustomerService = mCustomerService;
            this.tStockAllowanceService = tStockAllowanceService;
            this.mKind_DService = mKind_DService;

            //User single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.mCustomerService.Context = ctx;
            this.tStockAllowanceService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string BUTTON_INSERT = "btnInsert";
        private const string BUTTON_EDIT = "btnUpdate";
        private const string BUTTON_BACK = "btnBack";

        private const string KEY_CUSTOMER_NAME = "CustomerName";
        private const string KEY_CUSTOMER_CD = "CustomerCD";

        private const string DROPDOWN_ITEM = "item";
        private const string DROPDOWN_SORT_ORDER = "sortorder";

        private const string PARTIAL_LIST = "_List";
        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_DETAIL = "Details";
        
        private const string SEARCH_CUSTOMER_CD = "txt_CustomerCD";
        private const string SEARCH_CUSTOMER_NAME = "txt_CustomerName";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_DEFAULT_CSV = "CustomerCD";
        private const string SORT_URL = "/Customer/Sorting";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Event

        #region Index
        
        /// <summary>
        /// List
        /// </summary>
        /// <param name="gmModel">CustomerList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(CustomerList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                CustomerList oldModel = (CustomerList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(CustomerList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<CustomerResults> results = this.mCustomerService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<CustomerResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_CUSTOMER_CD);
                }
            }
            
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<CustomerResults> results = mCustomerService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo  = new SortingInfo
                                            {
                                                Url = SORT_URL,
                                                SortField = SORT_DEFAULT,
                                                Direction = SortDirection.Descending,
                                            };
                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<CustomerResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_CUSTOMER_CD);
            }
            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<CustomerResults> list = (IQueryable<CustomerResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<CustomerResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<CustomerResults> list = (IQueryable<CustomerResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<CustomerResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="PreCustomerCD"></param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string PreCustomerCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0025);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(KEY_CUSTOMER_CD);

            CustomerModels gmModel = new CustomerModels();
            gmModel.PreCustomerCD = PreCustomerCD;
            gmModel.SeqNum = SeqNum;
            
            this.SetDropDownlistAll(gmModel, null);
            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(CustomerModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Customer/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }
            this.SetDropDownlistAll(gmModel, null);
            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            CustomerModels gmModel = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            this.SetDropDownlistAll(gmModel, null);
            
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }
            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = this.InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = this.RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = this.InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion Insert

        #region Show

        /// <summary>
        /// View
        /// </summary>
        /// <param name="value1">CustomerCD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0024);

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            //Get data
            CustomerModels model = mCustomerService.GetByCd(value1);
            if (model == default(CustomerModels))
            {
                return this.ExclusionProcess(value2);
            }

            this.SetDropDownlistAll(model, value1);
            //Store data into session
            model.SeqNum = value2;
            
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View(SCREEN_DETAIL, model);
        }

        #endregion Show

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0027);

            //Get data
            CustomerModels gmModel = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            CustomerModels customerModel = mCustomerService.GetByCd(gmModel.CustomerCD);

            this.SetDropDownlistAll(customerModel, gmModel.CustomerCD);  
            //Check Exclusion
            if (customerModel == default(CustomerModels) || gmModel.UpdateDate != customerModel.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set Sequence Number
            customerModel.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_CUSTOMER_NAME);
            return View(SCREEN_DETAIL, customerModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(CustomerModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Customer/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }

            this.SetDropDownlistAll(gmModel, null);
            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            CustomerModels gmModel = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            this.SetDropDownlistAll(gmModel, null);
           
            //Update check
            if (!this.UpdateCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }

            //Update data
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/Customer/Show", gmModel.CustomerCD, gmModel.SeqNum.ToString());
                    ret = View(SCREEN_DETAIL, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion Update

        #region Delete

        /// <summary>
        /// Delete Confirm
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(CustomerModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Get data
            CustomerModels dbModel = this.mCustomerService.GetByCd(gmModel.CustomerCD);

            //Check Exclution
            if (dbModel == default(CustomerModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }
            
            this.SetDropDownlistAll(gmModel, gmModel.CustomerCD);

            //Check Customer used in other
            if (this.CheckUsedInOThers(gmModel.CustomerCD))
            {
                string message = this.FormatMessage(Constant.MES_M0023, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(string.Empty, message);
            }
            else
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, "/Customer/DeleteAction", value1: gmModel.SeqNum.ToString());
            }
            
            return View("Details",gmModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            CustomerModels model = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];
            this.SetDropDownlistAll(model, model.CustomerCD);

            string message = String.Empty;
            //Check Customer used in other
            if (this.CheckUsedInOThers(model.CustomerCD))
            {
                message = this.FormatMessage(Constant.MES_M0023, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(string.Empty, message);
                return View("Details", model);
            }

            //Delete data
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = this.Show(model.CustomerCD, value1);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = this.Show(model.CustomerCD, value1);
                    break;
            }

            return ret;
        }

        #endregion Delete

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0025);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            CustomerModels model = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            this.SetDropDownlistAll(model, model.CustomerCD);
            //Set focus
            this.SetFocusId(KEY_CUSTOMER_CD);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Copy Action Confirm
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(CustomerModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Customer/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }
            this.SetDropDownlistAll(gmModel, null);
            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            CustomerModels gmModel = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            
            this.SetDropDownlistAll(gmModel, null);
            
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }
            //insert data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion Copy

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(CustomerModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreCustomerCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreCustomerCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion Back

        #region CSV

        /// <summary>
        /// CSV
        /// </summary>
        /// <param name="gmModel">CustomerList</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(CustomerList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_CUSTOMER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();
            //Get model
            IQueryable<CustomerListCSV> customerListCSV = null;
            customerListCSV = this.mCustomerService.GetListCustomerCSV();
            if (customerListCSV.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View(SCREEN_INDEX, gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MCustomer"];
            var filename = string.Format("{0}-{1}.csv", "MCustomer", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };
            var file = this.CSVOutPut<CustomerListCSV>(customerListCSV, hideColumn, fileFullName, "MCustomer.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            CustomerList oldModel = (CustomerList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<CustomerResults> results = this.mCustomerService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<CustomerResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion CSV
        
        #endregion

        #region Check

        /// <summary>
        /// Dropdownlist Check
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns></returns>
        private bool DropdownlistCheck(CustomerModels gmModel)
        {
            bool ret = true;
            List<CustomerModels.ErrorDropDownlist> lstErr = gmModel.ValidateDropdownlist();
            
            //Not selected A Dropdownlist
            for(int i = 0; i< lstErr.Count; i++)
            {
                CustomerModels.ErrorDropDownlist err = lstErr[i];
                
                //Select a pair
                if (err.enumError.Equals(CustomerModels.EnumDropdownlistError.SelectPair))
                {
                    //Show error message
                    string message = string.Empty;
                    if (string.IsNullOrEmpty(gmModel.item[int.Parse(err.position)]))
                    {
                        message = this.FormatMessage(Constant.MES_E0015, int.Parse(err.position)+1);
                        this.ModelState.AddModelError(DROPDOWN_ITEM + "[" + err.position + "]", message);
                    }
                    else
                    {
                        message = this.FormatMessage(Constant.MES_E0016, int.Parse(err.position) + 1);
                        this.ModelState.AddModelError(DROPDOWN_SORT_ORDER + "[" + err.position + "]", message);
                    }
                    ret = false;
                }
                //Duplicate Dropdownlist
                if (err.enumError.Equals(CustomerModels.EnumDropdownlistError.Duplicate))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0015);
                    this.ModelState.AddModelError(DROPDOWN_ITEM +"[" +err.position + "]", message);
                    ret = false;
                }
            }
            
            return ret;
        }

        /// <summary>
        /// Check data changed
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(CustomerModels gmModel)
        {
            //Get data
            CustomerModels customerModel = mCustomerService.GetByCd(gmModel.CustomerCD);

            //Check Exclusion
            if (customerModel == default(CustomerModels) || gmModel.UpdateDate != customerModel.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion("/Customer/Show", gmModel.CustomerCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check Exist Data
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns></returns>
        private bool CheckExistData(CustomerModels gmModel)
        {
            bool ret = true;

            //Check MKind_D
            for (int i = 0; i < gmModel.item.Count; i++)
            {
                if (!string.IsNullOrEmpty(gmModel.item[i]))
                {
                    MKind_D mKind_D = this.mKind_DService.GetByPK(Constant.MKIND_KINDCD_STOCK_ALLOWANCE, gmModel.item[i]);
                    if (mKind_D == default(MKind_D))
                    {
                        //Stock Allowance Not Exist
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0075));
                        this.ModelState.AddModelError(DROPDOWN_ITEM + "[" + i + "]", message);
                        ret = false;
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(CustomerModels gmModel)
        {
            bool ret = true;
            if (!this.DropdownlistCheck(gmModel))
            {
                ret =  false;
            }
            if (!this.CheckExistData(gmModel))
            {
                ret = false;
            }
            if (this.mCustomerService.ExistCustomerCD(gmModel.CustomerCD, false))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(KEY_CUSTOMER_CD, message);
                ret = false;
            }
            else if (this.mCustomerService.ExistCustomerCD(gmModel.CustomerCD, true))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(KEY_CUSTOMER_CD, message);
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">screen CustomerModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(CustomerModels gmModel)
        {
            bool ret = true;

            //Check Customer used in others
            if (gmModel.DeleteFlag && this.CheckUsedInOThers(gmModel.CustomerCD))
            {
                string message = this.FormatMessage(Constant.MES_M0023, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(string.Empty, message);
                ret = false;
            }

            if (!this.DropdownlistCheck(gmModel))
            {
                ret = false;
            }
            if (!this.CheckExistData(gmModel))
            {
                ret = false;
            }
            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check Customer Used In Others
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="customerCD">customer CD</param>
        /// <returns>TRUE: Exist, FALSE: Not Exist</returns>
        private bool CheckUsedInOThers(string customerCD)
        {
            return this.mCustomerService.IsExistInTShippingInstruction(customerCD) || this.mCustomerService.IsExistInUser(customerCD);
        }

        #endregion Check
        
        #region Setting

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="dbModel">MCustomer</param>
        /// <param name="gmModel">CustomerModels</param>
        private void SetUpdateCustomer(MCustomer dbModel, CustomerModels gmModel)
        {
            dbModel.CustomerName = gmModel.CustomerName;
            dbModel.Address1 = gmModel.Address1;
            dbModel.Address2 = gmModel.Address2;
            dbModel.Address3 = gmModel.Address3;
            dbModel.Email = gmModel.Email;
            dbModel.Tel = gmModel.Tel;
            dbModel.Fax = gmModel.Fax;
            dbModel.DeleteFlag = gmModel.DeleteFlag;
            dbModel.UpdateDate = this.GetCurrentDate();
            dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="dbModel">MCustomer</param>
        private void SetDeleteCustomer(MCustomer dbModel)
        {
            dbModel.DeleteFlag = true;
            dbModel.UpdateDate = this.GetCurrentDate();
            dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion Setting
        
        #region Getting

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>MCustomer</returns>
        private MCustomer GetInsertCustomer(CustomerModels gmModel)
        {
            MCustomer ret = new MCustomer();

            ret.CustomerCD = MCustomer.FixCodeDB(gmModel.CustomerCD);
            ret.CustomerName = gmModel.CustomerName;
            ret.Address1 = gmModel.Address1;
            ret.Address2 = gmModel.Address2;
            ret.Address3 = gmModel.Address3;
            ret.Email = gmModel.Email;
            ret.Tel = gmModel.Tel;
            ret.Fax = gmModel.Fax;
            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        #endregion Getting

        #region Exclusion
        
        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum"></param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/Customer/Index");
            CustomerModels model = (CustomerModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(CustomerModels))
            {
                model = new CustomerModels();
                model.SeqNum = SeqNum;
            }
            return View(SCREEN_DETAIL, model);
        }

        #endregion Exclusion

        #region Dropdownlist
        
        ///<summary>
        ///Create Item SelectList
        ///</summary>
        ///<param name="dropSrc">dropSrc</param>
        ///<param name="control">Control Name</param>
        ///<param name="item">selected value</param>
        private void CreateViewBagItem(List<MKind_D> dropSrc, string control, string item)
        {
            SelectOption option = new SelectOption("Value", "DataCD", control, item);
            this.SetViewDataDropdownList<MKind_D>(option, dropSrc);
        }

        ///<summary>
        ///Create sortOrder SelectList
        ///</summary>
        ///<param name="dropSrc">dropSrc</param>
        ///<param name="control">Control Name</param>
        ///<param name="sortOrder">selected value</param>
        private void CreateViewBagSortOrder(List<SelectListItem> dropSrc, string control, string sortOrder)
        {
            SelectOption option = new SelectOption("Text", "Value", control, sortOrder);
            this.SetViewDataDropdownList<SelectListItem>(option, dropSrc);
        }

        /// <summary>
        /// Get Name From Dropdownlist Item
        /// </summary>
        /// <param name="value">Item</param>
        /// <returns></returns>
        private string GetNameFromDropdownlistItem(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                MKind_D model = mKind_DService.GetByPK(Constant.MKIND_KINDCD_STOCK_ALLOWANCE, value);
                if (model != null)
                {
                    return model.Value;
                }
            }
            return UserSession.Session.SysCache.GetLabel(Constant.LBL_L0034);
        }

        /// <summary>
        /// Get Name From Dropdownlist SortOrder
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string GetNameFromDropdownlistSortOrder(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (value.Equals(((int)Common.SortOrder.Ascending).ToString()))
                {
                    return UserSession.Session.SysCache.GetLabel(Constant.LBL_L0035);
                }
                else if (value.Equals(((int)Common.SortOrder.Descending).ToString()))
                {
                    return UserSession.Session.SysCache.GetLabel(Constant.LBL_L0036);
                }
            }

            return UserSession.Session.SysCache.GetLabel(Constant.LBL_L0034);
        }

        /// <summary>
        /// Set DropDownlist All
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <param name="customerCd">customerCd</param>
        private void SetDropDownlistAll(CustomerModels gmModel, string customerCd)

        {
            //Get List MKind
            List<MKind_D> dropItem = this.mKind_DService.GetListByDataKind(Common.Constant.MKIND_KINDCD_STOCK_ALLOWANCE).ToList();

            //Create List DataKind for SortOrder
            List<SelectListItem> dropSortOrder = Utility.CommonUtil.GetListSortOrder();
            if (gmModel.item == null || gmModel.item.Count == 0)
            {
                gmModel.item = new List<string>();
                gmModel.sortorder = new List<string>();
                foreach (MKind_D mkind in dropItem)
                {
                    gmModel.item.Add(null);
                    gmModel.sortorder.Add(null);
                }
                
            }
            gmModel.itemDisp = new List<string>();
            gmModel.sortorderDisp = new List<string>();
            foreach (MKind_D mkind in dropItem)
            {
                gmModel.itemDisp.Add(null);
                gmModel.sortorderDisp.Add(null);
            }
            if (!string.IsNullOrEmpty(customerCd))
            {
                List<TStockAllowance> lstEntity = this.tStockAllowanceService.GetListByCustomerCd(customerCd).ToList();
                for (int i = 0; i < lstEntity.Count(); i++)
                {
                    TStockAllowance entity = lstEntity[i];
                    gmModel.item[i] = entity.DataCD.ToString();
                    gmModel.sortorder[i] = entity.SortOrder.ToString();
                }
            }
            for (int i = 0; i < dropItem.Count; i++)
            {
                CreateViewBagItem(dropItem, DROPDOWN_ITEM + i, gmModel.item[i]);
                CreateViewBagSortOrder(dropSortOrder, DROPDOWN_SORT_ORDER + i, gmModel.sortorder[i]);

                //Get value name
                gmModel.itemDisp[i] = GetNameFromDropdownlistItem(gmModel.item[i]);
                gmModel.sortorderDisp[i] = GetNameFromDropdownlistSortOrder(gmModel.sortorder[i]);
            }
            ViewBag.Count = dropItem.Count;

        }

        #endregion Dropdownlist

        #region Registration

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="model">CustomerModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(CustomerModels gmModel)
        {
            //Get insert model
            MCustomer model = this.GetInsertCustomer(gmModel);
            try
            {
                this.mCustomerService.Insert(model);
                this.UpdateStockAllowance(gmModel);
                this.mCustomerService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCustomer_PK))
                {
                    return CommitFlag.DataChanged;
                }
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(CustomerModels gmModel)
        {
            try
            {
                MCustomer dbModel = this.mCustomerService.GetMCustomerByCd(gmModel.CustomerCD);
                if (dbModel == default(MCustomer) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                this.SetUpdateCustomer(dbModel, gmModel);
                this.UpdateStockAllowance(gmModel);
                mCustomerService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCustomer_PK))
                {
                    return CommitFlag.DataChanged;
                }
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="model">CustomerModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(CustomerModels gmModel)
        {
            try
            {
                // Check data changed
                MCustomer dbModel = this.mCustomerService.GetMCustomerByCd(gmModel.CustomerCD);
                if (dbModel == default(MCustomer) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Set delete data
                this.SetDeleteCustomer(dbModel);
                this.mCustomerService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCustomer_PK))
                {
                    return CommitFlag.DataChanged;
                }
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update StockAllowance
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <param name="dc">DataClasses1DataContext</param>
        private void UpdateStockAllowance(CustomerModels gmModel)
        {
            DeleteStockAllowance(gmModel.CustomerCD);
            InsertStockAllowance(gmModel);
        }

        /// <summary>
        /// Set value update StockAllowance
        /// </summary>
        /// <param name="gmModel">CustomerModels</param>
        /// <returns></returns>
        private void InsertStockAllowance(CustomerModels gmModel)
        {
            List<TStockAllowance> lstAllow = new List<TStockAllowance>();
            for (int i = 0; i < gmModel.item.Count; i++)
            {
                if (!string.IsNullOrEmpty(gmModel.item[i]))
                {
                    TStockAllowance ret1 = new TStockAllowance();
                    ret1.CustomerCD = MCustomer.FixCodeDB(gmModel.CustomerCD);
                    ret1.ProvisionOrder = 1;
                    ret1.DataCD = gmModel.item[i];
                    ret1.SortOrder = byte.Parse(gmModel.sortorder[i]);
                    ret1.StatusFlag = true;
                    lstAllow.Add(ret1);
                }
            }
                
            //Reset Number
            int cnt = 1;
            foreach (TStockAllowance entity in lstAllow)
            {
                entity.ProvisionOrder = cnt;
                cnt++;
            }
            tStockAllowanceService.Insert(lstAllow);
        }

        /// <summary>
        /// Set Delete StockAllowance
        /// </summary>
        /// <param name="customerCd">customerCd</param>
        /// <param name="dc">DataClasses1DataContext</param>
        private void DeleteStockAllowance(string customerCd)
        {
            //Get List StockAllowance in database
            List<TStockAllowance> lst = tStockAllowanceService.GetListByCustomerCd(customerCd);
            tStockAllowanceService.Delete(lst);
        }
        
        #endregion Registration
    }
}

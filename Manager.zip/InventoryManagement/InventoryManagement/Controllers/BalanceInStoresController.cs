﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using InventoryManagement.Common;
using Microsoft.Reporting.WebForms;
using System.Data;
using InventoryManagement.iQueryable;
using InventoryManagement.Report;

//=================
using System.IO;
using NPOI.HPSF;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.Util;
using NPOI.HSSF.UserModel;

//====================

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Balance In Stores Controller
    /// Author : ISV-TRUC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class BalanceInStoresController : BaseController
    {
        #region Finish
        #region Common

        private DataAccess.TBalanceInStoresService tBalanceInStoresService;

        private DataAccess.TTakeInventory_HService tTakeInventory_HService;
        private DataAccess.TTakeHistory_HService tTakeHistory_HService;

        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.MWarehouseService mWarehouseService;

        private DataAccess.MProductService mProductService;
        private DataAccess.MLocationService mLocationService;

        //Detail table
        private DataTable tblDetail = null;

        //Number key of main report 
        private int count = 0;
        //  private bool isFlagBranch = true;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mWarehouseService">mWarehouseService</param>
        /// <param name="mMessageService">mMessageService</param>
        /// <param name="mLocationService">mLocationService</param>
        public BalanceInStoresController(DataAccess.TBalanceInStoresService tBalanceInStoresService
                                               , DataAccess.MCompanyService mCompanyService
                                               , DataAccess.MProductService mProductService
                                               , DataAccess.MLocationService mLocationService
                                               , DataAccess.MWarehouseService mWarehouseService
                                               , DataAccess.TTakeInventory_HService tTakeInventory_HService
                                               , DataAccess.TTakeHistory_HService tTakeHistory_HService
                                               )
        {
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.mCompanyService = mCompanyService;
            this.tTakeInventory_HService = tTakeInventory_HService;
            this.mProductService = mProductService;
            this.mLocationService = mLocationService;
            this.mWarehouseService = mWarehouseService;
            this.tTakeHistory_HService = tTakeHistory_HService;
        }
        #endregion

        #region Constant

        private const int PDF_NUMBER_ROW_PER_PAGE = 30;
        private const string PRINT_ACTION_URL = "/BalanceInStores/PrintAction";
        private const string BALANCE_DATE_FROM_DAY = "BalanceDateFrom_Day";

        private const string SAVE_LIST_PRINT = "Save_List_Print";

        private const string REPORT_PRODUCT_URL = "~/Report/BalanceInStoresProduct.rdlc";

        private const string REPORT_PRODUCT_URL_New = "~/Report/BalanceInStoresProduct_1.rdlc";

        private const string REPORT_LOCATION_URL = "~/Report/BalanceInStoresLocation.rdlc";
        private const string PDF_FILE_PATH_PRODUCT = "BalanceInStores_ByProduct_{0}.pdf";
        private const string PDF_FILE_PATH_LOCATION = "BalanceInStores_ByLocation_{0}.pdf";
        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Index(BalanceInStoresModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_BALANCE_IN_STORE_PRINT))
            {
                return this.RedirectNotAuthority();
            }

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack() && gmModel.SeqNum != default(int))
            {
                //Get model
                BalanceInStoresModels oldModel = (BalanceInStoresModels)this.Session[Constant.SESSION_BALANCE_STORES_PRINT + gmModel.SeqNum.ToString()];
                if (oldModel != default(BalanceInStoresModels))
                {
                    gmModel = oldModel;
                    isFormBack = true;
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int) && !isFormBack)
            {
                gmModel = new BalanceInStoresModels();
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
                this.ClearModelState();
            }

            //Check search data
            if (this.ModelState.IsValid)//&& !isFormBack)
            {
                //
                //Store condition
                this.Session[Constant.SESSION_BALANCE_STORES_PRINT + gmModel.SeqNum.ToString()] = gmModel;
                this.Session[Constant.SESSION_SEQUENCE_NUMBER] = gmModel.SeqNum;
                //Focus
                SetFocusId(BALANCE_DATE_FROM_DAY);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
                //Clear ModeState
                this.ClearModelState();
            }

            return View("Index", gmModel);
        }

        #endregion

        #region Print

        private bool CheckDateRange(BalanceInStoresModels gmModel)
        {
            var balanceDateFromStr = gmModel.BalanceDateFrom.DateValue();
            var balanceDateToStr = gmModel.BalanceDateTo.DateValue();
            if (!string.IsNullOrEmpty(balanceDateFromStr) || !string.IsNullOrEmpty(balanceDateToStr))
            {
                var balanceDateFrom = DateTime.MinValue;
                var balanceDateTo = DateTime.MinValue;
                if (!string.IsNullOrEmpty(balanceDateFromStr))
                {
                    balanceDateFrom = Utility.CommonUtil.ParseDate(balanceDateFromStr, Constant.FMT_YMD);
                }
                if (!string.IsNullOrEmpty(balanceDateToStr))
                {
                    balanceDateTo = Utility.CommonUtil.ParseDate(balanceDateToStr, Constant.FMT_YMD);
                }
                if (balanceDateTo.CompareTo((balanceDateFrom.AddMonths(3).AddDays(-1))) > 0)
                {
                    this.ModelState.AddModelError("BalanceDateFrom", this.FormatMessage(Constant.MES_M0076, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0246), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0247)));
                    this.SortModelState(typeof(BalanceInStoresModels));
                    return false;
                }
                if (!this.CheckExistInput(gmModel))
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Print
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Print(BalanceInStoresModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_BALANCE_IN_STORE_PRINT))
            {
                return this.RedirectNotAuthority();
            }

            //Check search data
            if (this.ModelState.IsValid)
            {
                #region Check Date Range
                //Check date range
                if (!this.CheckDateRange(gmModel))
                {
                    return View("Index", gmModel);
                }
                #endregion

                #region Get data product
                if (gmModel.CheckProduct)
                {
                    //List<BalanceInStoresProductHeader> lstProductHeader = null;
                    ////if (gmModel.CheckTagNo)
                    ////{                       
                    ////    lstProductHeader = this.tBalanceInStoresService.GetListBalanceByProductHeader(gmModel, false).ToList();                        
                    ////}
                    ////else
                    ////{                      
                    ////    lstProductHeader = this.tBalanceInStoresService.GetListBalanceByProductHeader(gmModel, true).ToList();                       
                    ////}
                    //lstProductHeader = this.tBalanceInStoresService.GetListBalanceByProductHeader(gmModel, true).ToList();    

                    //if (lstProductHeader.Count == 0)
                    //{
                    //    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                    //    return View("Index", gmModel);
                    //}

                    //TempData[SAVE_LIST_PRINT] = lstProductHeader;

                    //========new ===========================
                    //IQueryable<BalanceInStoresProduct> lstProduct = null;

                    var lstProduct = this.tBalanceInStoresService.GetListByProductBranchTagNo(gmModel).AsQueryable()
                        .iOrderBy("TagInfo", System.Web.Helpers.SortDirection.Ascending)
                        .iThenBy("BalanceNo", System.Web.Helpers.SortDirection.Ascending);

                    if (lstProduct.ToList().Count == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }

                    List<BalanceInStoresProduct> lstData = this.SetSum_Product(lstProduct);

                    TempData[SAVE_LIST_PRINT] = lstData;

                    //========new ===========================
                }
                #endregion

                #region Get data Location
                else
                {
                    // IQueryable<BalanceInStoresLocation> lstLocation = null;
                    //if (gmModel.CheckTagNo)
                    //{
                    //    lstLocation = this.tBalanceInStoresService.GetListBalanceByLocationTagNo(gmModel)
                    //        .iOrderBy("BalanceDate", System.Web.Helpers.SortDirection.Descending)
                    //        .iThenBy("BalanceStatus", System.Web.Helpers.SortDirection.Ascending)
                    //        .iThenBy("TagInfo", System.Web.Helpers.SortDirection.Ascending);
                    //}
                    //else
                    //{
                    //    lstLocation = this.tBalanceInStoresService.GetListBalanceByLocationBranchTagNo(gmModel)
                    //        .iOrderBy("BalanceDate", System.Web.Helpers.SortDirection.Descending)
                    //        .iThenBy("BalanceStatus", System.Web.Helpers.SortDirection.Ascending)
                    //        .iThenBy("TagInfo", System.Web.Helpers.SortDirection.Ascending);
                    //}
                    //sort
                    var lstLocation = this.tBalanceInStoresService.GetListBalanceByLocationBranchTagNo(gmModel).AsQueryable()
                         .iOrderBy("TagInfo", System.Web.Helpers.SortDirection.Ascending)
                         .iThenBy("BalanceNo", System.Web.Helpers.SortDirection.Ascending);

                    if (lstLocation.ToList().Count == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }

                    List<BalanceInStoresLocation> lstData = this.SetSum(lstLocation);

                    #region //set quantity//
                    //foreach (var grp in lstGroupped)
                    //{
                    //    // var dic = HtmlHelper.AnonymousObjectToHtmlAttributes(grp.Key);
                    //    //foreach (var key in dic)
                    //    //{
                    //    //    key.Key
                    //    //}
                    //    var sum10 = grp.Where(n => n.BalanceStatus.Equals("10")).Count();// (m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum12 = grp.Where(n => n.BalanceStatus.Equals("12")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum14 = grp.Where(n => n.BalanceStatus.Equals("14")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum16 = grp.Where(n => n.BalanceStatus.Equals("16")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum18 = grp.Where(n => n.BalanceStatus.Equals("18")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                    //    var sum20 = grp.Where(n => n.BalanceStatus.Equals("20")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum22 = grp.Where(n => n.BalanceStatus.Equals("22")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum24 = grp.Where(n => n.BalanceStatus.Equals("24")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum26 = grp.Where(n => n.BalanceStatus.Equals("26")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum28 = grp.Where(n => n.BalanceStatus.Equals("28")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                    //    var sum40 = grp.Where(n => n.BalanceStatus.Equals("40")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum42 = grp.Where(n => n.BalanceStatus.Equals("42")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum44 = grp.Where(n => n.BalanceStatus.Equals("44")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum46 = grp.Where(n => n.BalanceStatus.Equals("46")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum48 = grp.Where(n => n.BalanceStatus.Equals("48")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                    //    var sum50 = grp.Where(n => n.BalanceStatus.Equals("50")).Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum52 = grp.Where(n => n.BalanceStatus.Equals("52")).Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum54 = grp.Where(n => n.BalanceStatus.Equals("54")).Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum56 = grp.Where(n => n.BalanceStatus.Equals("56")).Sum(m => CommonUtil.ParseInteger(m.Quantity));
                    //    var sum58 = grp.Where(n => n.BalanceStatus.Equals("58")).Sum(m => CommonUtil.ParseInteger(m.Quantity));

                    //    foreach (var item in grp)
                    //    {
                    //        item.InbNormal = sum10;
                    //        item.InbReturn = sum12;
                    //        item.InbTranfer = sum14;
                    //        item.InbStock = sum16;
                    //        item.InbScrap = sum18;

                    //        item.RecNormal = sum20;
                    //        item.RecReturn = sum22;
                    //        item.RecTranfer = sum24;
                    //        item.RecStock = sum26;
                    //        item.RecScrap = sum28;

                    //        item.IssNormal = sum40;
                    //        item.IssReturn = sum42;
                    //        item.IssTranfer = sum44;
                    //        item.IssStock = sum46;
                    //        item.IssScrap = sum48;

                    //        item.OutNormal = sum50;
                    //        item.OutReturn = sum52;
                    //        item.OutTranfer = sum54;
                    //        item.OutStock = sum56;
                    //        item.OutScrap = sum58;

                    //        lstData.Add(item);
                    //    }
                    //}
                    #endregion

                    // TempData[SAVE_LIST_PRINT] = lstLocation;
                    TempData[SAVE_LIST_PRINT] = lstData;
                }
                #endregion
                //Store condition
                this.Session[Constant.SESSION_BALANCE_STORES_PRINT + gmModel.SeqNum.ToString()] = gmModel;
                this.ShowMessageConfirm(gmModel.SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020), value1: gmModel.SeqNum.ToString());
            }

            this.SortModelState(typeof(BalanceInStoresModels));
            return View("Index", gmModel);
        }

        /// <summary>
        /// Set Sum
        /// ISV-TRUC
        /// </summary>
        /// <param name="lstLocation">IQueryable of BalanceInStoresLocation</param>
        /// <returns></returns>
        private List<BalanceInStoresLocation> SetSum(IQueryable<BalanceInStoresLocation> lstLocation)
        {
            var lstGroupped = lstLocation.GroupBy(m => m.LocationCD);
            List<BalanceInStoresLocation> lstData = new List<BalanceInStoresLocation>();
            foreach (var grp in lstGroupped)
            {

                var sum10 = grp.Where(n => n.BalanceStatus.Equals("10")).Count();// (m => CommonUtil.ParseInteger(m.Quantity));
                var sum12 = grp.Where(n => n.BalanceStatus.Equals("12")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum14 = grp.Where(n => n.BalanceStatus.Equals("14")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum16 = grp.Where(n => n.BalanceStatus.Equals("16")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum18 = grp.Where(n => n.BalanceStatus.Equals("18")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum20 = grp.Where(n => n.BalanceStatus.Equals("20")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum22 = grp.Where(n => n.BalanceStatus.Equals("22")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum24 = grp.Where(n => n.BalanceStatus.Equals("24")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum26 = grp.Where(n => n.BalanceStatus.Equals("26")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum28 = grp.Where(n => n.BalanceStatus.Equals("28")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum40 = grp.Where(n => n.BalanceStatus.Equals("40")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum42 = grp.Where(n => n.BalanceStatus.Equals("42")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum44 = grp.Where(n => n.BalanceStatus.Equals("44")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum46 = grp.Where(n => n.BalanceStatus.Equals("46")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum48 = grp.Where(n => n.BalanceStatus.Equals("48")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum50 = grp.Where(n => n.BalanceStatus.Equals("50")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum52 = grp.Where(n => n.BalanceStatus.Equals("52")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum54 = grp.Where(n => n.BalanceStatus.Equals("54")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum56 = grp.Where(n => n.BalanceStatus.Equals("56")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum58 = grp.Where(n => n.BalanceStatus.Equals("58")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                foreach (var item in grp)
                {
                    item.InbNormal = sum10;
                    item.InbReturn = sum12;
                    item.InbTranfer = sum14;
                    item.InbStock = sum16;
                    item.InbScrap = sum18;

                    item.RecNormal = sum20;
                    item.RecReturn = sum22;
                    item.RecTranfer = sum24;
                    item.RecStock = sum26;
                    item.RecScrap = sum28;

                    item.IssNormal = sum40;
                    item.IssReturn = sum42;
                    item.IssTranfer = sum44;
                    item.IssStock = sum46;
                    item.IssScrap = sum48;

                    item.OutNormal = sum50;
                    item.OutReturn = sum52;
                    item.OutTranfer = sum54;
                    item.OutStock = sum56;
                    item.OutScrap = sum58;

                    lstData.Add(item);
                }
            }

            return lstData;
        }

        /// <summary>
        /// Set Sum
        /// ISV-TRUC
        /// </summary>
        /// <param name="lstProduct">IQueryable of BalanceInStoresProduct</param>
        /// <returns></returns>
        private List<BalanceInStoresProduct> SetSum_Product(IQueryable<BalanceInStoresProduct> lstProduct)
        {
            var lstGroupped = lstProduct.GroupBy(m => m.ProductCD);
            List<BalanceInStoresProduct> lstData = new List<BalanceInStoresProduct>();
            foreach (var grp in lstGroupped)
            {

                var sum10 = grp.Where(n => n.BalanceStatus.Equals("10")).Count();// (m => CommonUtil.ParseInteger(m.Quantity));
                var sum12 = grp.Where(n => n.BalanceStatus.Equals("12")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum14 = grp.Where(n => n.BalanceStatus.Equals("14")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum16 = grp.Where(n => n.BalanceStatus.Equals("16")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum18 = grp.Where(n => n.BalanceStatus.Equals("18")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum20 = grp.Where(n => n.BalanceStatus.Equals("20")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum22 = grp.Where(n => n.BalanceStatus.Equals("22")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum24 = grp.Where(n => n.BalanceStatus.Equals("24")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum26 = grp.Where(n => n.BalanceStatus.Equals("26")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum28 = grp.Where(n => n.BalanceStatus.Equals("28")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum40 = grp.Where(n => n.BalanceStatus.Equals("40")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum42 = grp.Where(n => n.BalanceStatus.Equals("42")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum44 = grp.Where(n => n.BalanceStatus.Equals("44")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum46 = grp.Where(n => n.BalanceStatus.Equals("46")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum48 = grp.Where(n => n.BalanceStatus.Equals("48")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                var sum50 = grp.Where(n => n.BalanceStatus.Equals("50")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum52 = grp.Where(n => n.BalanceStatus.Equals("52")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum54 = grp.Where(n => n.BalanceStatus.Equals("54")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum56 = grp.Where(n => n.BalanceStatus.Equals("56")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));
                var sum58 = grp.Where(n => n.BalanceStatus.Equals("58")).Count();//.Sum(m => CommonUtil.ParseInteger(m.Quantity));

                foreach (var item in grp)
                {
                    item.InbNormal = sum10;
                    item.InbReturn = sum12;
                    item.InbTranfer = sum14;
                    item.InbStock = sum16;
                    item.InbScrap = sum18;

                    item.RecNormal = sum20;
                    item.RecReturn = sum22;
                    item.RecTranfer = sum24;
                    item.RecStock = sum26;
                    item.RecScrap = sum28;

                    item.IssNormal = sum40;
                    item.IssReturn = sum42;
                    item.IssTranfer = sum44;
                    item.IssStock = sum46;
                    item.IssScrap = sum48;

                    item.OutNormal = sum50;
                    item.OutReturn = sum52;
                    item.OutTranfer = sum54;
                    item.OutStock = sum56;
                    item.OutScrap = sum58;

                    lstData.Add(item);
                }
            }

            return lstData;
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-TRUC
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value1)
        {
            //Clear ModeState
            this.ClearModelState();

            BalanceInStoresModels gmModel = (BalanceInStoresModels)this.Session[Constant.SESSION_BALANCE_STORES_PRINT + value1];
            if (!this.CheckExistInput(gmModel))
            {
                return View("Index", gmModel);
            }
            //Report
            LocalReport localReport = new LocalReport();

            #region product
            if (gmModel.CheckProduct)
            {

                //if (gmModel.CheckBranchTagNo)
                //{
                //    isFlagBranch = true;
                //}
                //else
                //    isFlagBranch = false;

                #region dataset
                //List<BalanceInStoresProductHeader> ReportSource = (List<BalanceInStoresProductHeader>)TempData[SAVE_LIST_PRINT];

                //var Count = ReportSource.Count;

                //if (Count > 0)
                //{
                //    //Report dataset                
                //    Report.DataObject.BalanceInStoresProductDataSet DataSet = new Report.DataObject.BalanceInStoresProductDataSet();

                //    //Report Source
                //    var tblBalance = DataSet.BanlanceStoreProduct.Clone();
                //    tblDetail = DataSet.BanlanceStoreProduct.Clone();

                //    var item = ReportSource[0];
                //    var newRow = tblBalance.NewRow();
                //    //this.InitDataForRowHeader(ref newRow, item, gmModel, isFlagBranch);
                //    this.InitDataForRowHeader(ref newRow, item, gmModel);
                //    tblBalance.Rows.Add(newRow);

                //    //Get data for report source
                //    for (int i = 0; i < Count; i++)
                //    {
                //        if (item.ProductCD != ReportSource[i].ProductCD)
                //        {
                //            item = ReportSource[i];
                //            newRow = tblBalance.NewRow();
                //            //this.InitDataForRowHeader(ref newRow, item, gmModel, isFlagBranch);
                //            this.InitDataForRowHeader(ref newRow, item, gmModel);

                //            tblBalance.Rows.Add(newRow);
                //        }
                //    }

                //    //Download file name
                //    var filename = string.Format(PDF_FILE_PATH_PRODUCT, DateTime.Now.ToString(Constant.FMT_DMY));

                //    localReport.ReportPath = Server.MapPath(REPORT_PRODUCT_URL);

                //    //Report source
                //    ReportDataSource dataSource = new ReportDataSource("BalanceInStoreProduct", tblBalance);

                //    // Add a handler for SubreportProcessing.
                //    localReport.SubreportProcessing +=
                //                new SubreportProcessingEventHandler(SubReportProcessingEventHandler);

                //    localReport.DataSources.Add(dataSource);

                //    //Set parameter
                //    localReport.SetParameters(this.InitParamsForReport(gmModel));

                //    var file = this.PDFOutPut(localReport, filename, Common.ReportType.System, false);
                //    TempData[TMP_DOWNLOAD_FILE] = file;
                //}
                //else
                //{
                //    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                //    return View("Index", gmModel);
                //} 
                #endregion

                #region Model---new
                List<BalanceInStoresProduct> lstData = (List<BalanceInStoresProduct>)TempData[SAVE_LIST_PRINT];
                if (lstData.ToList().Count > 0)
                {
                    //Download file name
                    var filename = string.Format(PDF_FILE_PATH_PRODUCT, DateTime.Now.ToString(Constant.FMT_DMY));

                    localReport.ReportPath = Server.MapPath(REPORT_PRODUCT_URL_New);

                    //Set label
                    this.SetParameterForReportProduct(localReport, gmModel);

                    var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
                    var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
                    //if (string.IsNullOrEmpty(dateFrom) && string.IsNullOrEmpty(dateTo))
                    //{
                    //    localReport.SetLabelValue("lblBalanceDateHeader"," ");
                    //}
                    //else
                    //{
                    //    localReport.SetLabelValue("lblBalanceDateHeader", string.Format("{0} ～ {1}", dateFrom, dateTo));
                    //}

                    localReport.SetLabelValue("lblBalanceDateHeader", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068));
                    localReport.SetLabelValue("DateFromLabel", dateFrom);
                    localReport.SetLabelValue("DateToLabel", dateTo);

                    MCompany mCompany = mCompanyService.GetMCompany();
                    MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
                    string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
                    string space = "";
                    localReport.SetLabelValue("CompanyLabel", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);

                    //Report source                     
                    // ReportDataSource dataSource = new ReportDataSource("BalanceInStoreLocation", lstLocation);
                    ReportDataSource dataSource = new ReportDataSource("BalanceInStoreProduct", lstData);

                    localReport.DataSources.Add(dataSource);

                    var file = this.PDFOutPut(localReport, filename, Common.ReportType.System, false);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
                else
                {
                    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                    return View("Index", gmModel);
                }
                #endregion
            }
            #endregion

            #region location
            else if (gmModel.CheckLocation)
            {
                //if (gmModel.CheckBranchTagNo)
                //{
                //    isFlagBranch = true;
                //}
                //else
                //    isFlagBranch = false;

                // IQueryable<BalanceInStoresLocation> lstLocation = (IQueryable<BalanceInStoresLocation>)TempData[SAVE_LIST_PRINT];
                List<BalanceInStoresLocation> lstData = (List<BalanceInStoresLocation>)TempData[SAVE_LIST_PRINT];
                if (lstData.ToList().Count > 0)
                {
                    //Download file name
                    var filename = string.Format(PDF_FILE_PATH_LOCATION, DateTime.Now.ToString(Constant.FMT_DMY));

                    localReport.ReportPath = Server.MapPath(REPORT_LOCATION_URL);

                    //Set label
                    this.SetParameterForReportLocation(localReport, gmModel);

                    var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
                    var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
                    //if (string.IsNullOrEmpty(dateFrom) && string.IsNullOrEmpty(dateTo))
                    //{
                    //    localReport.SetLabelValue("lblBalanceDateHeader"," ");
                    //}
                    //else
                    //{
                    //    localReport.SetLabelValue("lblBalanceDateHeader", string.Format("{0} ～ {1}", dateFrom, dateTo));
                    //}

                    localReport.SetLabelValue("lblBalanceDateHeader", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068));
                    localReport.SetLabelValue("DateFromLabel", dateFrom);
                    localReport.SetLabelValue("DateToLabel", dateTo);

                    MCompany mCompany = mCompanyService.GetMCompany();
                    MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
                    string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
                    string space = "";
                    localReport.SetLabelValue("CompanyLabel", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);

                    //Report source                     
                    // ReportDataSource dataSource = new ReportDataSource("BalanceInStoreLocation", lstLocation);
                    ReportDataSource dataSource = new ReportDataSource("BalanceInStoreLocation", lstData);

                    localReport.DataSources.Add(dataSource);

                    var file = this.PDFOutPut(localReport, filename, Common.ReportType.System, false);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
                else
                {
                    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                    return View("Index", gmModel);
                }
            }
            #endregion

            //Set is form back
            this.SetFormBack();
            return RedirectToAction("Index", new { SeqNum = gmModel.SeqNum });
        }

        #region Private Methods For Print

        /// <summary>
        /// Set Parameter For Report Location
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        private void SetParameterForReportLocation(LocalReport localReport, BalanceInStoresModels gmModel)
        {
            localReport.SetLabelFromCache(
                                                   new KeyValuePair<string, string>("BalanceDateTitleLabel", Constant.LBL_L0261),
                                                   new KeyValuePair<string, string>("LocationCodeLabel", Constant.LBL_L0110),
                                                   new KeyValuePair<string, string>("LocationNameLabel", Constant.LBL_L0052),
                                                   new KeyValuePair<string, string>("TagInfoLabel", Constant.LBL_L0106),
                                                   new KeyValuePair<string, string>("LOT1Label", Constant.LBL_L0084),
                                                   new KeyValuePair<string, string>("LOT2Label", Constant.LBL_L0085),
                                                   new KeyValuePair<string, string>("LOT3Label", Constant.LBL_L0086),
                                                   new KeyValuePair<string, string>("BalanceStatusLabel", Constant.LBL_L0262),
                                                   new KeyValuePair<string, string>("BalanceDateLabel", Constant.LBL_L0243),
                                                   new KeyValuePair<string, string>("QuantityLabel", Constant.LBL_L0127),
                                                   new KeyValuePair<string, string>("TitleLabel", Constant.LBL_L0266),
                                                   new KeyValuePair<string, string>("PageLabel", Constant.LBL_L0172),
                                                   new KeyValuePair<string, string>("ArrivalLabel", Constant.LBL_L0213),
                                                   new KeyValuePair<string, string>("ReceiptLabel", Constant.LBL_L0214),
                                                   new KeyValuePair<string, string>("ShipmentLabel", Constant.LBL_L0215),
                                                   new KeyValuePair<string, string>("ShippingLabel", Constant.LBL_L0216),
                                                   new KeyValuePair<string, string>("ArrivalFlagLabel", Constant.LBL_L0217),
                                                   new KeyValuePair<string, string>("ReturnLabel", Constant.LBL_L0218),
                                                   new KeyValuePair<string, string>("MoveLabel", Constant.LBL_L0219),
                                                   new KeyValuePair<string, string>("TakeLabel", Constant.LBL_L0220),
                                                   new KeyValuePair<string, string>("ScrapLabel", Constant.LBL_L0297),
                                                   new KeyValuePair<string, string>("TotalLabel", Constant.LBL_L0083)
                                                );
        }


        private void SetParameterForReportProduct(LocalReport localReport, BalanceInStoresModels gmModel)
        {
            localReport.SetLabelFromCache(
                                                   new KeyValuePair<string, string>("BalanceDateTitleLabel", Constant.LBL_L0261),
                                                   new KeyValuePair<string, string>("ProductCodeLabel", Constant.LBL_L0018),
                                                   new KeyValuePair<string, string>("ProductNameLabel", Constant.LBL_L0019),
                                                   new KeyValuePair<string, string>("LocationCDLabel", Constant.LBL_L0110),
                                                   new KeyValuePair<string, string>("TagInfoLabel", Constant.LBL_L0106),
                                                   new KeyValuePair<string, string>("LOT1Label", Constant.LBL_L0084),
                                                   new KeyValuePair<string, string>("LOT2Label", Constant.LBL_L0085),
                                                   new KeyValuePair<string, string>("LOT3Label", Constant.LBL_L0086),
                                                   new KeyValuePair<string, string>("BalanceStatusLabel", Constant.LBL_L0262),
                                                   new KeyValuePair<string, string>("BalanceDateLabel", Constant.LBL_L0243),
                                                   new KeyValuePair<string, string>("QuantityLabel", Constant.LBL_L0127),
                                                   new KeyValuePair<string, string>("TitleLabel", Constant.LBL_L0265),
                                                   new KeyValuePair<string, string>("PageLabel", Constant.LBL_L0172),
                                                   new KeyValuePair<string, string>("ArrivalLabel", Constant.LBL_L0213),
                                                   new KeyValuePair<string, string>("ReceiptLabel", Constant.LBL_L0214),
                                                   new KeyValuePair<string, string>("ShipmentLabel", Constant.LBL_L0215),
                                                   new KeyValuePair<string, string>("ShippingLabel", Constant.LBL_L0216),
                                                   new KeyValuePair<string, string>("ArrivalFlagLabel", Constant.LBL_L0217),
                                                   new KeyValuePair<string, string>("ReturnLabel", Constant.LBL_L0218),
                                                   new KeyValuePair<string, string>("MoveLabel", Constant.LBL_L0219),
                                                   new KeyValuePair<string, string>("TakeLabel", Constant.LBL_L0220),
                                                   new KeyValuePair<string, string>("ScrapLabel", Constant.LBL_L0297),
                                                   new KeyValuePair<string, string>("TotalLabel", Constant.LBL_L0083)
                                                );
        }

        /// <summary>
        /// Sub Report Processing Event Handler
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">SubreportProcessingEventArgs</param>
        void SubReportProcessingEventHandler(object sender, SubreportProcessingEventArgs e)
        {
            string seqNum = this.Session[Constant.SESSION_SEQUENCE_NUMBER].ToString();
            BalanceInStoresModels gmModel = (BalanceInStoresModels)this.Session[Constant.SESSION_BALANCE_STORES_PRINT + seqNum];

            LocalReport localReport = (LocalReport)sender;

            ReportDataSourceCollection data = localReport.DataSources;
            DataTable dt = (DataTable)data[0].Value;
            count++;
            tblDetail = this.CreateDetailData(dt.Rows[count - 1]["ProductCD"].ToString(), gmModel);
            ReportDataSource Sub = new ReportDataSource("SubBalanceInStoresProduct", tblDetail);

            e.DataSources.Add(Sub);
        }

        /// <summary>
        /// Create Detail Data
        /// </summary>
        /// <param name="productCD">ProductCD</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        private DataTable CreateDetailData(string productCD, BalanceInStoresModels gmModel)
        {
            //Set data for detail table
            tblDetail = new DataTable();
            Report.DataObject.BalanceInStoresProductDataSet SubDataSet = new Report.DataObject.BalanceInStoresProductDataSet();
            tblDetail = SubDataSet.BanlanceStoreProduct.Clone();

            List<BalanceInStoresProductDetail> listDetail = null;

            //if (gmModel.CheckBranchTagNo)
            //{
            //    listDetail = this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(productCD, gmModel)
            //        .iOrderBy("BalanceDate", System.Web.Helpers.SortDirection.Descending).iThenBy("BalanceStatus", System.Web.Helpers.SortDirection.Ascending).iThenBy("TagNo", System.Web.Helpers.SortDirection.Ascending).ToList();

            //    //this.SetTotalValue(listDetail, gmModel, isFlagBranch);
            //    this.SetTotalValue(listDetail, gmModel);
            //}
            //else if (gmModel.CheckTagNo)
            //{
            //    listDetail = this.tBalanceInStoresService.GetListBalanceByProductTagNo(productCD, gmModel)
            //        .iOrderBy("BalanceDate", System.Web.Helpers.SortDirection.Descending).iThenBy("BalanceStatus", System.Web.Helpers.SortDirection.Ascending).iThenBy("TagNo", System.Web.Helpers.SortDirection.Ascending).ToList();

            //    //this.SetTotalValue(listDetail, gmModel, isFlagBranch);
            //    this.SetTotalValue(listDetail, gmModel);
            //}

            listDetail = this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(productCD, gmModel)
                .iOrderBy("TagInfo", System.Web.Helpers.SortDirection.Ascending).iThenBy("BalanceNo", System.Web.Helpers.SortDirection.Ascending).ToList();

            this.SetTotalValue(listDetail, gmModel);

            return tblDetail;
        }

        /// <summary>
        /// SetTotalValue
        /// </summary>
        /// <param name="listDetail">List Of BalanceInStoresProductDetail</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <param name="isBranchTagNo">isBranchTagNo Flag</param>
        //private void SetTotalValue(List<BalanceInStoresProductDetail> listDetail, BalanceInStoresModels gmModel, bool isBranchTagNo)
        private void SetTotalValue(List<BalanceInStoresProductDetail> listDetail, BalanceInStoresModels gmModel)
        {
            int totalArrival = 0;
            int totalReturnArrival = 0;
            int totalMoveArrival = 0;
            int totalTakeArrival = 0;
            int totalScrapArrival = 0;

            int totalStore = 0;
            int totalReturnStore = 0;
            int totalMoveStore = 0;
            int totalTakeStore = 0;
            int totalScrapStore = 0;

            int totalShipment = 0;
            int totalReturnShipment = 0;
            int totalMoveShipment = 0;
            int totalTakeShipment = 0;
            int totalScrapShipment = 0;

            int totalShipping = 0;
            int totalReturnShipping = 0;
            int totalMoveShipping = 0;
            int totalTakeShipping = 0;
            int totalScrapShipping = 0;

            int count = listDetail.Count();
            for (int j = 0; j < count; j++)
            {
                var dtRow = tblDetail.NewRow();
                switch (listDetail[j].BalanceStatus)
                {
                    case Constant.BALANCE_STATUS_ARRIVAL://10
                        totalArrival += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_RETURN_ARRIVAL://12
                        totalReturnArrival += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_MOVES_ARRIVAL://14
                        totalMoveArrival += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_TAKE_ARRIVAL://16
                        totalTakeArrival += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_SCRAP_ARRIVAL://18
                        totalScrapArrival += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_RECEIPT://20
                        totalStore += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_RETURN_RECEIPT://22
                        totalReturnStore += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_MOVE_RECEIPT://24
                        totalMoveStore += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_INVENTORY_RECEIPT://26
                        totalTakeStore += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_SCRAP_RECEIPT://28
                        totalScrapStore += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_GOODS_ISSUE://40
                        totalShipment += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_RETURN_ISSUE://42
                        totalReturnShipment += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_MOVE_ISSUE://44
                        totalMoveShipment += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_INVENTORY_ISSUE://46
                        totalTakeShipment += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_DISCARD_ISSUE://48
                        totalScrapShipment += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_SHIPPING://50
                        totalShipping += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_RETURN_SHIPPING://52
                        totalReturnShipping += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_MOVE_SHIPPING://54
                        totalMoveShipping += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_TAKE_SHIPPING://56
                        totalTakeShipping += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    case Constant.BALANCE_STATUS_DISCARD_SHIPPING://58
                        totalScrapShipping += 1;//(isBranchTagNo ? 1 : int.Parse(listDetail[j].Quantity));
                        break;

                    default:
                        break;
                }
                //Set data for latest row
                if (j == listDetail.Count - 1)
                {
                    dtRow["Arrival"] = totalArrival;
                    dtRow["ReturnArrival"] = totalReturnArrival;
                    dtRow["MoveArrival"] = totalMoveArrival;
                    dtRow["TakeArrival"] = totalTakeArrival;
                    dtRow["ScrapArrival"] = totalScrapArrival;

                    dtRow["Store"] = totalStore;
                    dtRow["ReturnStore"] = totalReturnStore;
                    dtRow["MoveStore"] = totalMoveStore;
                    dtRow["TakeStore"] = totalTakeStore;
                    dtRow["ScrapStore"] = totalScrapStore;

                    dtRow["Shipment"] = totalShipment;
                    dtRow["ReturnShipment"] = totalReturnShipment;
                    dtRow["MoveShipment"] = totalMoveShipment;
                    dtRow["TakeShipment"] = totalTakeShipment;
                    dtRow["ScrapShipment"] = totalScrapShipment;

                    dtRow["Shipping"] = totalShipping;
                    dtRow["ReturnShipping"] = totalReturnShipping;
                    dtRow["MoveShipping"] = totalMoveShipping;
                    dtRow["TakeShipping"] = totalTakeShipping;
                    dtRow["ScrapShipping"] = totalScrapShipping;
                }

                InitDataForRowDetail(ref dtRow, listDetail[j], gmModel, listDetail.Count);
                tblDetail.Rows.Add(dtRow);
            }
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/InboundDelivery/Index");

            InboundDeliveryModels model = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(InboundDeliveryModels))
            {
                model = new InboundDeliveryModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">InboundDeliveryModels</param>
        /// <param name="BoxNo">BoxNo</param>
        //private void InitDataForRowHeader(ref System.Data.DataRow Row, BalanceInStoresProductHeader Data, BalanceInStoresModels gmModel, bool isBranchTagNo)
        private void InitDataForRowHeader(ref System.Data.DataRow Row, BalanceInStoresProductHeader Data, BalanceInStoresModels gmModel)
        {
            Row["BalanceDateFrom"] = string.IsNullOrEmpty(gmModel.BalanceDateFrom.DateValue()) ? string.Empty : CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            Row["BalanceDateTo"] = string.IsNullOrEmpty(gmModel.BalanceDateTo.DateValue()) ? string.Empty : CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            Row["ProductCD"] = Data.ProductCD;
            Row["ProductName"] = Data.ProductName;
            Row["TypeReport"] = Data.TypeReport;

            List<BalanceInStoresProductDetail> listDetail = null;

            //if (isBranchTagNo)
            //    listDetail = this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(Data.ProductCD, gmModel).ToList();//this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(Data.ProductCD, gmModel.BalanceDateFrom.DateValue(), gmModel.BalanceDateTo.DateValue()).ToList();
            //else
            //    listDetail = this.tBalanceInStoresService.GetListBalanceByProductTagNo(Data.ProductCD, gmModel).ToList();

            listDetail = this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(Data.ProductCD, gmModel).ToList();
        }

        /// <summary>
        /// Init Data For Row Detail
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">BalanceInStoresProductDetail</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <param name="detailRowsCount">Detail total row count</param>
        private void InitDataForRowDetail(ref System.Data.DataRow Row, BalanceInStoresProductDetail Data, BalanceInStoresModels gmModel, int detailRowsCount)
        {
            //if (gmModel.CheckBranchTagNo)
            //{
            //    Row["TagInfo"] = Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), 4);
            //}
            //else
            //{
            //    Row["TagInfo"] = Data.TagNo;
            //}
            Row["TagInfo"] = Data.TagInfo;// Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), 4);

            Row["BalanceDate"] = string.IsNullOrEmpty(Data.BalanceDate) ? string.Empty : CommonUtil.ParseDate(Data.BalanceDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LOT1"] = Data.Lot1;
            Row["LOT2"] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LOT3"] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["Quantity"] = Data.Quantity;
            Row["BalanceStatusName"] = Data.BalanceStatusName;
            Row["LocationName"] = Data.LocationName;
            Row["TotalRowCount"] = detailRowsCount;
            InitLabelForFooterDetail(ref Row);
        }

        /// <summary>
        /// Init Label For Footer Detail
        /// </summary>
        /// <param name="Row">DataRow</param>
        private void InitLabelForFooterDetail(ref System.Data.DataRow Row)
        {
            Row["ArrivalLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0213);
            Row["ArrivalFlagLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0217);
            Row["ReceiptLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0214);
            Row["ShipmentLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0215);
            Row["ShippingLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0216);
            Row["ReturnLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0218);
            Row["MoveLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0219);
            Row["TakeLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0220);
            Row["ScrapLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0297);
            Row["TotalLabel"] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0083);
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForReport(BalanceInStoresModels gmModel)
        {
            //Set Parameters           
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            ReportParameter title = new ReportParameter("TitleLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0265));
            ReportParameter companyName = new ReportParameter("CompanyLabel", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            ReportParameter balanceDateTitle = new ReportParameter("BalanceDateTitleLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0261));
            ReportParameter productCode = new ReportParameter("ProductCodeLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("ProductNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter tagInfo = new ReportParameter("TagInfoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter lot1 = new ReportParameter("LOT1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter lot2 = new ReportParameter("LOT2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("LOT3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter balanceStatus = new ReportParameter("BalanceStatusLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0262));
            ReportParameter balanceDate = new ReportParameter("BalanceDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0243));
            ReportParameter quantity = new ReportParameter("QuantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0127));
            ReportParameter page = new ReportParameter("PageLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172));
            ReportParameter location = new ReportParameter("LocationLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));

            var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            ReportParameter balanceDateInput = null;
            balanceDateInput = new ReportParameter("lblBalanceDateHeader", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068));

            return new ReportParameterCollection { title, companyName, balanceDateTitle, productCode, productName, tagInfo, lot1, lot2, lot3, balanceStatus, balanceDate, quantity, page, location, balanceDateInput };
        }

        #endregion

        /// <summary>
        /// Check Exist Input value
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <returns></returns>
        private bool CheckExistInput(BalanceInStoresModels gmModel)
        {
            bool ret = true;
            if (!string.IsNullOrEmpty(gmModel.ProductCD))
            {
                //Check exist in Product Master
                ProductModels modelProduct = this.mProductService.GetByCd(gmModel.ProductCD);
                if (modelProduct == default(ProductModels) || modelProduct.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError("ProductCD", message);
                    ret = false;
                }
            }
            return ret;
        }

        #endregion

        #region Ajax
        /// <summary>
        /// Show Product Name
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <returns>Product Name</returns>      
        ///  [HttpPost]
        public string ShowProductNm(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return string.Empty;
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD);

            if (model != default(ProductModels) && model != null && !model.DeleteFlag)
            {
                return model.ProductName;

            }
            return string.Empty;
        }

        /// <summary>
        /// Show Location Name
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>
        [HttpPost]
        public string ShowLocationNm(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return string.Empty;
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);

            if (model != default(LocationModels) && model != null && !model.DeleteFlag)
            {
                return model.LocationName;
            }
            return string.Empty;
        }

        #endregion

        #endregion

        #region Excel

        #region contanst Excel
        private const string EXCEL_PRODUCT_DOWNLOAD = "Balance_P_{0}.xls";
        private const string EXCEL_LOCATION_DOWNLOAD = "Balance_L_{0}.xls";
        private const string PRINT_EXCEL_ACTION_URL = "/BalanceInStores/ExcelAction";

        #endregion

        #region Variant
        IWorkbook workbook;
        IFont font;
        ICellStyle styleDate;
        
        IFont fontBold;
        ICellStyle styleHeader;
        ICellStyle styleGeneral;
        ICellStyle styleTitle;
        IDataFormat formatText;
        #endregion

        /// <summary>
        /// Excel
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Excel(BalanceInStoresModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_BALANCE_IN_STORE_PRINT))
            {
                return this.RedirectNotAuthority();
            }

            //Check search data
            if (this.ModelState.IsValid)
            {
                #region Check Date Range
                //Check date range
                if (!this.CheckDateRange(gmModel))
                {
                    return View("Index", gmModel);
                }
                #endregion

                string messConfirn = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020);

                #region Get data product
                if (gmModel.CheckProduct)
                {                    
                    DAC.Report dac = new DAC.Report();
                    
                    //double numOutSheet = dac.GetBalanceStoresNumOfSheet(gmModel,true);
                    List<double> lstRowCount = dac.GetBalanceStoresRowCountProduct(gmModel);
                    if (lstRowCount.Count == 0)//ko co du lieu
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }
                    else if (lstRowCount.Exists(n => n > Constant.EXCEL_MAX_ROW))//so dong > 65536 dong
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0016));
                        return View("Index", gmModel);
                    }
                    else
                    {
                        //List<BalanceInStoresCheckExcel> lstOutRow = dac.GetBalanceStoresOutOfRangeProduct(gmModel);
                        if (lstRowCount.Count > Constant.EXCEL_MAX_SHEET)//so sheet > 255 sheet
                        {
                            messConfirn =  InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0040);
                        }
                        
                        IQueryable<BalanceInStoresProduct> lstProduct = dac.GetBalanceInStoresProduct(gmModel);

                        //var lstProduct = this.tBalanceInStoresService.GetListByProductBranchTagNo(gmModel).AsQueryable()
                        //    .iOrderBy("TagInfo", System.Web.Helpers.SortDirection.Ascending)
                        //    .iThenBy("BalanceNo", System.Web.Helpers.SortDirection.Ascending);
                        //da kiem tra ben ngoai
                        //if (lstProduct.ToList().Count == 0)
                        //{
                        //    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        //    return View("Index", gmModel);
                        //}
                        TempData[SAVE_LIST_PRINT] = lstProduct;
                    }
                }
                #endregion
                
                #region Get data Location
                else
                {
                    DAC.Report dac = new DAC.Report();
                    //double numOutSheet = dac.GetBalanceStoresNumOfSheet(gmModel, false);
                    List<double> lstRowCount = dac.GetBalanceStoresRowCountLocation(gmModel);
                    if (lstRowCount.Count == 0)//ko co dl
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }
                    else if (lstRowCount.Count > Constant.EXCEL_MAX_ROW)
                    {
                        this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0016));
                        return View("Index", gmModel);
                    }
                    else
                    {
                       // List<BalanceInStoresCheckExcel> lstOutRow = dac.GetBalanceStoresOutOfRangeLocation(gmModel);
                        if (lstRowCount.Exists(n=>n > Constant.EXCEL_MAX_SHEET))
                        {
                            messConfirn = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0040);
                        }
                        IQueryable<BalanceInStoresLocation> lstLocation = dac.GetBalanceInStoresLocation(gmModel);

                        //var lstLocation = this.tBalanceInStoresService.GetListByLocationBranchTagNo(gmModel).AsQueryable()                    
                        //    .iOrderBy("TagInfo", System.Web.Helpers.SortDirection.Ascending)
                        //    .iThenBy("BalanceNo", System.Web.Helpers.SortDirection.Ascending);

                        //if (lstLocation.ToList().Count == 0)
                        //{
                        //    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                        //    return View("Index", gmModel);
                        //}
                        TempData[SAVE_LIST_PRINT] = lstLocation;
                    }
                    
                }
                #endregion

                //Store condition
                this.Session[Constant.SESSION_BALANCE_STORES_PRINT + gmModel.SeqNum.ToString()] = gmModel;
                this.ShowMessageConfirm(gmModel.SeqNum, PRINT_EXCEL_ACTION_URL, message: messConfirn, value1: gmModel.SeqNum.ToString());
            }
            this.SortModelState(typeof(BalanceInStoresModels));
            return View("Index", gmModel);
        }

        /// <summary>
        /// Excel Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ExcelAction(string value1)
        {
            //Clear ModeState
            this.ClearModelState();

            BalanceInStoresModels gmModel = (BalanceInStoresModels)this.Session[Constant.SESSION_BALANCE_STORES_PRINT + value1];
            if (!this.CheckExistInput(gmModel))
            {
                return View("Index", gmModel);
            }
            //Report
            LocalReport localReport = new LocalReport();

            #region product
            if (gmModel.CheckProduct)
            {
                IQueryable<BalanceInStoresProduct> lstData = (IQueryable<BalanceInStoresProduct>)TempData[SAVE_LIST_PRINT];
                if (lstData.ToList().Count > 0)
                {
                    //Download file name
                    var filename = string.Format(EXCEL_PRODUCT_DOWNLOAD, DateTime.Now.ToString(Constant.FMT_YMDHMM));
                    //create file                    
                    InitializeWorkbook();
                    int k = 0;
                    var lstGroupped = lstData.GroupBy(m => m.ProductCD).iOrderBy("Key", System.Web.Helpers.SortDirection.Ascending);
                    foreach (var grp in lstGroupped)
                    {
                        var ProductCD = grp.Key.ToString();
                        var lst = grp.Where(n => n.ProductCD.Equals(ProductCD)).Select(m => new BalanceInStoresProduct()
                        {
                            ProductCD = m.ProductCD,
                            ProductName = m.ProductName,
                            TagInfo = m.TagInfo,
                            Lot1 = m.Lot1,
                            Lot2 = m.Lot2,
                            Lot3 = m.Lot3,
                            BalanceDate = m.BalanceDate,
                            BalanceStatus = m.BalanceStatus,
                            BalanceStatusName = m.BalanceStatusName,
                            LocationCD = m.LocationCD,
                            Quantity = m.Quantity
                        });
                        this.GenerateData_Product(gmModel, lst.ToList(), ProductCD, k);
                        k++;
                    }
                                        
                    var file = File(WriteToStream().GetBuffer(), "application/vnd.ms-excel", filename);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
                else
                {
                    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                    return View("Index", gmModel);
                }
            }
            #endregion

            #region location
            else if (gmModel.CheckLocation)
            {
                IQueryable<BalanceInStoresLocation> lstData = (IQueryable<BalanceInStoresLocation>)TempData[SAVE_LIST_PRINT];
                if (lstData.ToList().Count > 0)
                {
                    //Download file name
                    var filename = string.Format(EXCEL_LOCATION_DOWNLOAD, DateTime.Now.ToString(Constant.FMT_YMDHMM));
                   
                    InitializeWorkbook();

                    var lstGroupped = lstData.GroupBy(m => new { m.LocationCD, m.LocationName }).OrderBy(m => m.Key.LocationCD);
                    //.iOrderBy("Key", System.Web.Helpers.SortDirection.Ascending); 
                    int k = 0;
                    foreach (var grp in lstGroupped)
                    {
                        var LocationCD = string.IsNullOrEmpty(grp.Key.LocationCD) ? string.Empty : grp.Key.LocationCD.ToString();
                        var LocationName = string.IsNullOrEmpty(grp.Key.LocationName) ? string.Empty : grp.Key.LocationName.ToString();
                        var lst = grp.Where(n => n.LocationCD.Equals(LocationCD)).Select(m => new BalanceInStoresLocation()
                        {
                            ProductCD = m.ProductCD,
                            ProductName = m.ProductName,
                            TagInfo = m.TagInfo,
                            Lot1 = m.Lot1,
                            Lot2 = m.Lot2,
                            Lot3 = m.Lot3,
                            BalanceDate = m.BalanceDate,
                            BalanceStatus = m.BalanceStatus,
                            BalanceStatusName = m.BalanceStatusName,
                            LocationCD = m.LocationCD,
                            LocationName = m.LocationName,
                            Quantity = m.Quantity
                        });

                        this.GenerateData_Location(gmModel, lst.AsQueryable(), LocationCD, LocationName, k);
                        k++;
                    }

                    var file = File(WriteToStream().GetBuffer(), "application/vnd.ms-excel", filename);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
                else
                {
                    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
                    return View("Index", gmModel);
                }
            }
            #endregion

            //Set is form back
            this.SetFormBack();
            return RedirectToAction("Index", new { SeqNum = gmModel.SeqNum });
        }

        /// <summary>
        /// Init Workbook
        /// </summary>
        void InitializeWorkbook()
        {
            workbook = new HSSFWorkbook();
            font = workbook.CreateFont();
            font.FontName = "Arial";

            //set format for bold text
            fontBold = workbook.CreateFont();
            fontBold.FontName = "Arial";
            fontBold.Boldweight = (short)FontBoldWeight.BOLD;
            fontBold.FontHeightInPoints = 10;

            // set border for header data
            styleHeader = workbook.CreateCellStyle();
            styleHeader.BorderBottom = BorderStyle.THIN;
            styleHeader.BottomBorderColor = HSSFColor.BLACK.index;
            styleHeader.BorderTop = BorderStyle.THIN;
            styleHeader.TopBorderColor = HSSFColor.BLACK.index;
            styleHeader.Alignment = HorizontalAlignment.LEFT;


            //create the format for Date
            IDataFormat format = workbook.CreateDataFormat();
            styleDate = workbook.CreateCellStyle();
            styleDate.DataFormat = format.GetFormat("dd/MM/yyyy");
            styleDate.Alignment = HorizontalAlignment.LEFT;
            
            //format title
            styleTitle = workbook.CreateCellStyle();
            styleTitle.Alignment = HorizontalAlignment.CENTER;
            IFont fontTitle = workbook.CreateFont();
            fontTitle.FontHeightInPoints = 14;
            fontTitle.Boldweight = (short)FontBoldWeight.BOLD;
            styleTitle.SetFont(fontTitle);


            //set format general for sheet
            styleGeneral = workbook.CreateCellStyle();
            styleGeneral.Alignment = HorizontalAlignment.LEFT;
            styleGeneral.SetFont(font);
            formatText = workbook.CreateDataFormat();
            styleGeneral.DataFormat = formatText.GetFormat("@");

            ////create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "ISV Viet Nam CO., LTD.";
            //workbook.DocumentSummaryInformation = dsi;
            
            ////create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "Inventory Managerment";
            //workbook.SummaryInformation = si;
        }

        /// <summary>
        /// Set Up Info When Print Report
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetUpInfoForPrintReport(ISheet sheet)
        {
            //sheet disables gridline
            sheet.DisplayGridlines = false;
            sheet.FitToPage = true;
            sheet.PrintSetup.NoColor = true;
            sheet.PrintSetup.Landscape = true;
            sheet.PrintSetup.PaperSize = (short)PaperSize.A4_Small;
            sheet.HorizontallyCenter = true;
            sheet.PrintSetup.Copies = 1;
            //% zoom
            sheet.PrintSetup.Scale = 100;
            //luc view de in se hien ra grid
            sheet.IsPrintGridlines = false;

            sheet.SetMargin(MarginType.RightMargin, (double)0.25);
            sheet.SetMargin(MarginType.TopMargin, (double)0.6);
            sheet.SetMargin(MarginType.LeftMargin, (double)0.25);
            sheet.SetMargin(MarginType.BottomMargin, (double)0.1);
            
            sheet.PrintSetup.FooterMargin = 0.25;
            sheet.PrintSetup.HeaderMargin = 0.25;
            sheet.FitToPage = true;
            sheet.PrintSetup.FitHeight = 0;
            sheet.PrintSetup.FitWidth = 1;
            
        }

        /// <summary>
        /// Setting General
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="isProductView"> is view by product</param>
        private void SettingGeneral(ISheet sheet, bool isProductView)
        {
            font.Boldweight = (short)FontBoldWeight.None;
            font.FontHeightInPoints = 10;
            this.SetUpInfoForPrintReport(sheet);

            

            if (isProductView)
            {
                //Set width for column Of Sheet
                this.SetWidthColumn_Product(sheet, styleGeneral);
            }
            else//location
            {                
                //Set width for column Of Sheet
                this.SetWidthColumn_Location(sheet, styleGeneral);
            }

            //Set header for Sheet
            this.SetHeaderOfSheet(sheet);
        }

        /// <summary>
        /// Set Width Column With View by Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="style">ICellStyle</param>
        private void SetWidthColumn_Product(ISheet sheet, ICellStyle style)
        {
            //col TagInfo
            sheet.SetColumnWidth(0, 20 * 256);
            sheet.SetDefaultColumnStyle((short)0, style);

            //col LOT1
            sheet.SetColumnWidth(1, 40 * 256);
            sheet.SetDefaultColumnStyle((short)1, style);

            //col LOT2
            sheet.SetColumnWidth(2, 14 * 256);
            sheet.SetDefaultColumnStyle((short)2, style);

            //col LOT3
            sheet.SetColumnWidth(3, 14 * 256);
            sheet.SetDefaultColumnStyle((short)3, style);

            //col Balance Date
            sheet.SetColumnWidth(4, 14 * 256);
            sheet.SetDefaultColumnStyle((short)4, style);

            //col Balance Status Name
            sheet.SetColumnWidth(5, 21 * 256);
            sheet.SetDefaultColumnStyle((short)5, style);

            //col Location
            sheet.SetColumnWidth(6, 22 * 256);
            sheet.SetDefaultColumnStyle((short)6, style);

            ////col Balance Status
            //sheet.SetColumnWidth(7, 10 * 256);
            //sheet.SetDefaultColumnStyle((short)7, style);

            ////set column balanceStatus is hidden
            //sheet.SetColumnHidden(7, true);

        }

        /// <summary>
        /// Set Width Column View by Location
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="style">ICellStyle</param>
        private void SetWidthColumn_Location(ISheet sheet, ICellStyle style)
        {
            //col TagInfo
            sheet.SetColumnWidth(0, 24 * 256);
            sheet.SetDefaultColumnStyle((short)0, style);

            //col LOT1
            sheet.SetColumnWidth(1, 29 * 256);
            sheet.SetDefaultColumnStyle((short)1, style);
            sheet.SetColumnWidth(2, 14 * 256);
            sheet.SetDefaultColumnStyle((short)2, style);

            //col LOT2
            sheet.SetColumnWidth(3, 17 * 256);
            sheet.SetDefaultColumnStyle((short)3, style);

            //col LOT3
            sheet.SetColumnWidth(4, 17 * 256);
            sheet.SetDefaultColumnStyle((short)4, style);

            //col Balance Date
            sheet.SetColumnWidth(5, 17 * 256);
            sheet.SetDefaultColumnStyle((short)5, style);

            //col Balance Status Name
            sheet.SetColumnWidth(6, 25 * 256);
            sheet.SetDefaultColumnStyle((short)6, style);
                        
            ////col Balance Status
            //sheet.SetColumnWidth(7, 10 * 256);
            //sheet.SetDefaultColumnStyle((short)7, style);

            ////set column balanceStatus is hidden
            //sheet.SetColumnHidden(7, true);

        }

        /// <summary>
        /// Generate Data View By Product
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <param name="lstData">List of BalanceInStoresProduct</param>
        /// <param name="ProductCD">ProductCD</param>
        /// <param name="indexSheet">index of Sheet</param>
        private void GenerateData_Product(BalanceInStoresModels gmModel, List<BalanceInStoresProduct> lstData, string ProductCD, int indexSheet)
        {
            //string Name = ProductCD;
           // string sheetName = Name.Length > 30 ? Name.Substring(0, 30) : Name;
            ISheet sheet = workbook.CreateSheet(ProductCD);

            // Set the rows to repeat from row 0 to 4 on sheet.
            workbook.SetRepeatingRowsAndColumns(indexSheet, -1, -1, 0, 4);

            #region set the width of columns and font for data
            this.SettingGeneral(sheet, true);
            #endregion

            #region set value for cell Title

            this.SetTitleForExcel(sheet, true);
            #endregion======================================================================

            #region set value for cell Balance Date

            this.SetBalanceDateHeader(sheet, gmModel);

            #endregion======================================================================

            #region set value for cell Product
            this.SetHeaderCodeAndName(sheet, ProductCD, lstData[0].ProductName, true);
            #endregion

            //row empty
            IRow rowEmpty = sheet.CreateRow(3);
            rowEmpty.HeightInPoints = 9f;

            #region set value for cell Header Of Data

            this.SetHeaderOfData(sheet, true);
            #endregion

            #region fill data
            this.FillData_Product(sheet, lstData, styleDate);
            #endregion
        }

        /// <summary>
        /// Generate Data View By Location
        /// </summary>
        /// <param name="gmModel">BalanceInStoresModels</param>
        /// <param name="lstData">IQueryable of BalanceInStoresLocation</param>
        /// <param name="LocationCD">LocationCD</param>
        /// <param name="LocationNm">LocationNm</param>
        /// <param name="indexSheet">indexSheet</param>
        private void GenerateData_Location(BalanceInStoresModels gmModel, IQueryable<BalanceInStoresLocation> lstData, string LocationCD, string LocationNm, int indexSheet)
        {
            string Name = string.IsNullOrEmpty(LocationCD) ? UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287) : LocationCD;
            //string sheetName = Name.Length > 30 ? Name.Substring(0, 30) : Name;
            ISheet sheet = workbook.CreateSheet(Name);

            // Set the rows to repeat from row 0 to 4 on sheet.
            workbook.SetRepeatingRowsAndColumns(indexSheet, -1, -1, 0, 4);

            #region set the width of columns and font for data
            this.SettingGeneral(sheet, false);
            #endregion
            
            #region set value for cell Title

            this.SetTitleForExcel(sheet, false);
            #endregion======================================================================

            #region set value for cell Balance Date

            this.SetBalanceDateHeader(sheet, gmModel);

            #endregion======================================================================

            #region set value for cell Location
            this.SetHeaderCodeAndName(sheet, LocationCD, LocationNm, false);
            #endregion

            //row empty
            IRow rowEmpty = sheet.CreateRow(3);
            rowEmpty.HeightInPoints = 9f;

            #region set value for cell Header Of Data
            this.SetHeaderOfData(sheet, false);
            #endregion

            #region fill data
            this.FillData_Location(sheet, lstData, styleDate);
            #endregion
        }

        /// <summary>
        /// Set Balance Date In Header
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="gmModel">BalanceInStoresModels</param>
        private void SetBalanceDateHeader(ISheet sheet, BalanceInStoresModels gmModel)
        {
            IRow row = sheet.CreateRow(1);
            row.HeightInPoints = 16f;
            ICell cell = row.CreateCell(0);
            var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            string balanceDate = dateFrom + " " + UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068) + " " + dateTo;

            string strBalanceDate = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0261) + ": " + balanceDate;
            cell.SetCellValue(strBalanceDate);
            //sheet.AddMergedRegion(new CellRangeAddress(1, 1, 0, 3));
        }

        /// <summary>
        /// Set Title For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="isProductView">is view by Product</param>
        private void SetTitleForExcel(ISheet sheet, bool isProductView)
        {
            IRow row3 = sheet.CreateRow(0);
            row3.HeightInPoints = 18f;
            
            ICell cell3 = row3.CreateCell(0);
            if (isProductView)
            {
                cell3.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0265));
                //merged cells on Cell Title
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 6));
            }
            else//location
            {
                cell3.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0266));
                //merged cells on Cell Title
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 6));
            }

            
            cell3.CellStyle = styleTitle;
        }

        /// <summary>
        /// Set Header Code And Name
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="Code">Code</param>
        /// <param name="Name">Name</param>
        /// <param name="isProductView">is view by Product</param>
        private void SetHeaderCodeAndName(ISheet sheet, string Code, string Name, bool isProductView)
        {
            IRow row6 = sheet.CreateRow(2);
            row6.HeightInPoints = 16f;
            ICell cell60 = row6.CreateCell(0);
            string CDLabel = isProductView ? UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018) : UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110);
            int labelLenghtCD = CDLabel.Length;
            string strCode = CDLabel + ": " + (string.IsNullOrEmpty(Code) ? UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287) : Code);
            cell60.SetCellValue(strCode);
            cell60.RichStringCellValue.ApplyFont(labelLenghtCD + 2, strCode.Length, fontBold);

            ICell cell63 = row6.CreateCell(2);
            string NameLabel = isProductView ? UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019) : UserSession.Session.SysCache.GetLabel(Constant.LBL_L0052);
            int labelLenghtNm = NameLabel.Length;
            string strName = NameLabel + ": " + (string.IsNullOrEmpty(Name) ? string.Empty : Name);
            cell63.SetCellValue(strName);
            cell63.RichStringCellValue.ApplyFont(labelLenghtNm + 2, strName.Length, fontBold);
        }
        
        /// <summary>
        /// Set Header Of Data
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="isProductView">is view by Product</param>
        private void SetHeaderOfData(ISheet sheet, bool isProductView)
        {
            
            IRow row5 = sheet.CreateRow(4);
            row5.HeightInPoints = 16f;
            //row5.RowStyle = styleHeader;

            if (isProductView)
            {

                ICell cell70 = row5.CreateCell(0);
                cell70.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                cell70.CellStyle = styleHeader;

                ICell cell71 = row5.CreateCell(1);
                cell71.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
                cell71.CellStyle = styleHeader;

                ICell cell72 = row5.CreateCell(2);
                cell72.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
                cell72.CellStyle = styleHeader;

                ICell cell73 = row5.CreateCell(3);
                cell73.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
                cell73.CellStyle = styleHeader;

                ICell cell74 = row5.CreateCell(4);
                cell74.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0243));
                cell74.CellStyle = styleHeader;

                ICell cell75 = row5.CreateCell(5);
                cell75.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0262));
                cell75.CellStyle = styleHeader;

                ICell cell76 = row5.CreateCell(6);
                cell76.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
                cell76.CellStyle = styleHeader;
            }
            else
            {
                ICell cell70 = row5.CreateCell(0);
                cell70.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                cell70.CellStyle = styleHeader;

                ICell cell71 = row5.CreateCell(1);
                cell71.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
                cell71.CellStyle = styleHeader;

                ICell cell712 = row5.CreateCell(2);
                cell712.SetCellValue(string.Empty);
                cell712.CellStyle = styleHeader;

                ICell cell72 = row5.CreateCell(3);
                cell72.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
                cell72.CellStyle = styleHeader;

                ICell cell73 = row5.CreateCell(4);
                cell73.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
                cell73.CellStyle = styleHeader;

                ICell cell74 = row5.CreateCell(5);
                cell74.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0243));
                cell74.CellStyle = styleHeader;

                ICell cell75 = row5.CreateCell(6);
                cell75.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0262));
                cell75.CellStyle = styleHeader;
            }
        }

        /// <summary>
        /// Set Header Of Sheet
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderOfSheet(ISheet sheet)
        {
            IHeader header = sheet.Header;

            string pageNumberInfo = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172) + ": " + HeaderFooter.Page + "/" + HeaderFooter.NumPages;
            //string nowDateInfo = String.Format(Constant.FMT_DATE_DPL, DateTime.Now) + " " + HeaderFooter.Time;
            string nowDateInfo = DateTime.Now.ToString(Constant.FMT_DATETIME_REPORT_SHOW);

            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            string companyInfo = companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName;
            header.Left = companyInfo + "\n" + space.PadLeft(5);
            header.Right = nowDateInfo + "\n" + HSSFHeader.FontSize((short)11) + pageNumberInfo;

        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of BalanceInStoresProduct</param>
        /// <param name="style">ICellStyle</param>
        private void FillData_Product(ISheet sheet, List<BalanceInStoresProduct> lstData,ICellStyle style)
        {
            int indexCurRow = 5;
            int n = indexCurRow + lstData.Count;
            
            int k = 0;
           
             Dictionary<string, int> lstSum = new Dictionary<string, int>();
             this.InitDictionaryList(lstSum);

            for (int i = indexCurRow; i < n; i++)
            {
                IRow rowTemp = sheet.CreateRow(i);
                rowTemp.HeightInPoints = 16f;

                ICell cell0 = rowTemp.CreateCell(0);
                cell0.SetCellValue(lstData[k].TagInfo);

                ICell cell1 = rowTemp.CreateCell(1);
                cell1.SetCellValue(lstData[k].Lot1);

                ICell cell2 = rowTemp.CreateCell(2);
                // cell2.SetCellValue(CommonUtil.ParseDate(lstData[k].Lot2, Constant.FMT_YMD, Constant.FMT_DATE));
                if (!string.IsNullOrEmpty(lstData[k].Lot2))
                {
                    cell2.SetCellValue(new DateTime(int.Parse(lstData[k].Lot2.Substring(0, 4)), int.Parse(lstData[k].Lot2.Substring(4, 2)), int.Parse(lstData[k].Lot2.Substring(6, 2))));
                }
                else
                {
                    cell2.SetCellValue(string.Empty);
                }                
                cell2.CellStyle = styleDate;

                ICell cell3 = rowTemp.CreateCell(3);
                if (!string.IsNullOrEmpty(lstData[k].Lot3))
                {
                    cell3.SetCellValue(new DateTime(int.Parse(lstData[k].Lot3.Substring(0, 4)), int.Parse(lstData[k].Lot3.Substring(4, 2)), int.Parse(lstData[k].Lot3.Substring(6, 2))));
                }
                else
                {
                    cell3.SetCellValue(string.Empty);
                }                   
                cell3.CellStyle = styleDate;
                
                ICell cell4 = rowTemp.CreateCell(4);
                if (!string.IsNullOrEmpty(lstData[k].BalanceDate))
                {
                    cell4.SetCellValue(new DateTime(int.Parse(lstData[k].BalanceDate.Substring(0, 4)), int.Parse(lstData[k].BalanceDate.Substring(4, 2)), int.Parse(lstData[k].BalanceDate.Substring(6, 2))));
                }
                else
                {
                    cell4.SetCellValue(string.Empty);
                }                    
                cell4.CellStyle = styleDate;

                ICell cell5 = rowTemp.CreateCell(5);
                cell5.SetCellValue(lstData[k].BalanceStatusName);

                ICell cell6 = rowTemp.CreateCell(6);
                cell6.SetCellValue(lstData[k].LocationCD);

                ////balance status
                //ICell cell7 = rowTemp.CreateCell(7);
                //cell7.SetCellValue(int.Parse(lstData[k].BalanceStatus));

                //increase total                          
                if (lstSum.ContainsKey(lstData[k].BalanceStatus))
                {
                    lstSum[lstData[k].BalanceStatus] += 1;
                }

                k++;
            }
            this.AddFooterDataForReport(sheet, n + 1, lstSum);//add 1 row empty
        }

        private void InitDictionaryList(Dictionary<string, int> lstSum)
        {
            lstSum.Add(Constant.BALANCE_STATUS_ARRIVAL, 0);
            lstSum.Add(Constant.BALANCE_STATUS_RETURN_ARRIVAL, 0);
            lstSum.Add(Constant.BALANCE_STATUS_MOVES_ARRIVAL, 0);
            lstSum.Add(Constant.BALANCE_STATUS_TAKE_ARRIVAL, 0);
            lstSum.Add(Constant.BALANCE_STATUS_SCRAP_ARRIVAL, 0);

            lstSum.Add(Constant.BALANCE_STATUS_RECEIPT, 0);
            lstSum.Add(Constant.BALANCE_STATUS_RETURN_RECEIPT, 0);
            lstSum.Add(Constant.BALANCE_STATUS_MOVE_RECEIPT, 0);
            lstSum.Add(Constant.BALANCE_STATUS_INVENTORY_RECEIPT, 0);
            lstSum.Add(Constant.BALANCE_STATUS_SCRAP_RECEIPT, 0);

            lstSum.Add(Constant.BALANCE_STATUS_GOODS_ISSUE, 0);
            lstSum.Add(Constant.BALANCE_STATUS_RETURN_ISSUE, 0);
            lstSum.Add(Constant.BALANCE_STATUS_MOVE_ISSUE, 0);
            lstSum.Add(Constant.BALANCE_STATUS_INVENTORY_ISSUE, 0);
            lstSum.Add(Constant.BALANCE_STATUS_DISCARD_ISSUE, 0);

            lstSum.Add(Constant.BALANCE_STATUS_SHIPPING, 0);
            lstSum.Add(Constant.BALANCE_STATUS_RETURN_SHIPPING, 0);
            lstSum.Add(Constant.BALANCE_STATUS_MOVE_SHIPPING, 0);
            lstSum.Add(Constant.BALANCE_STATUS_TAKE_SHIPPING, 0);
            lstSum.Add(Constant.BALANCE_STATUS_DISCARD_SHIPPING, 0);
        }
                
        /// <summary>
        /// Fill Data For Location
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">IQueryable Of BalanceInStoresLocation</param>
        /// <param name="style">ICellStyle</param>
        private void FillData_Location(ISheet sheet, IQueryable<BalanceInStoresLocation> lstData, ICellStyle style)
        {
            int rowStartFillData = 5;
            int curRowOneSheet = rowStartFillData;
            var lstGroupped = lstData.GroupBy(m => m.ProductCD).iOrderBy("Key", System.Web.Helpers.SortDirection.Ascending);

            Dictionary<string, int> lstSum = new Dictionary<string, int>();
            this.InitDictionaryList(lstSum);

            foreach (var grp in lstGroupped)
            {
                var ProductCD = grp.Key.ToString();
                var lst = grp.Where(n => n.ProductCD.Equals(ProductCD)).Select(m => new BalanceInStoresLocation()
                {
                    ProductCD = m.ProductCD,
                    ProductName = m.ProductName,
                    TagInfo = m.TagInfo,
                    Lot1 = m.Lot1,
                    Lot2 = m.Lot2,
                    Lot3 = m.Lot3,
                    BalanceDate = m.BalanceDate,
                    BalanceStatus = m.BalanceStatus,
                    BalanceStatusName = m.BalanceStatusName,
                    LocationCD = m.LocationCD,
                    LocationName=m.LocationName,
                    Quantity = m.Quantity
                });

                List<BalanceInStoresLocation> lstOf1Pro = lst.ToList();

                //set dong productCd-productNm
                IRow rowPro = sheet.CreateRow(curRowOneSheet);
                rowPro.HeightInPoints = 16f;

                ICell cellProCD = rowPro.CreateCell(0);
                cellProCD.SetCellValue(ProductCD.ToString());
                cellProCD.RichStringCellValue.ApplyFont(0, ProductCD.Length, fontBold);
                
                

                ICell cellProNm = rowPro.CreateCell(1);
                cellProNm.SetCellValue(lstOf1Pro[0].ProductName);
                cellProNm.RichStringCellValue.ApplyFont(0, lstOf1Pro[0].ProductName.Length, fontBold);
                

                //increase current row
                curRowOneSheet++;

                //set data
                foreach (BalanceInStoresLocation LP in lstOf1Pro)
                {
                    int n = curRowOneSheet + lstOf1Pro.Count;

                    IRow rowTemp = sheet.CreateRow(curRowOneSheet);
                    rowTemp.HeightInPoints = 16f;

                    ICell cell0 = rowTemp.CreateCell(0);
                    cell0.SetCellValue(LP.TagInfo);

                    ICell cell1 = rowTemp.CreateCell(1);
                    cell1.SetCellValue(LP.Lot1);

                    ICell cell2 = rowTemp.CreateCell(3);
                    if (!string.IsNullOrEmpty(LP.Lot2))
                    {
                        cell2.SetCellValue(new DateTime(int.Parse(LP.Lot2.Substring(0, 4)), int.Parse(LP.Lot2.Substring(4, 2)), int.Parse(LP.Lot2.Substring(6, 2))));
                    }
                    else
                    {
                        cell2.SetCellValue(string.Empty);
                    }
                    cell2.CellStyle = styleDate;

                    ICell cell3 = rowTemp.CreateCell(4);
                    if (!string.IsNullOrEmpty(LP.Lot3))
                    {
                        cell3.SetCellValue(new DateTime(int.Parse(LP.Lot3.Substring(0, 4)), int.Parse(LP.Lot3.Substring(4, 2)), int.Parse(LP.Lot3.Substring(6, 2))));
                    }
                    else
                    {
                        cell3.SetCellValue(string.Empty);
                    }
                    cell3.CellStyle = styleDate;

                    ICell cell4 = rowTemp.CreateCell(5);
                    if (!string.IsNullOrEmpty(LP.BalanceDate))
                    {
                        cell4.SetCellValue(new DateTime(int.Parse(LP.BalanceDate.Substring(0, 4)), int.Parse(LP.BalanceDate.Substring(4, 2)), int.Parse(LP.BalanceDate.Substring(6, 2))));
                    }
                    else
                    {
                        cell4.SetCellValue(string.Empty);
                    }
                    cell4.CellStyle = styleDate;

                    ICell cell5 = rowTemp.CreateCell(6);
                    cell5.SetCellValue(LP.BalanceStatusName);
                        
                    ////balance status
                    //ICell cell6 = rowTemp.CreateCell(7);
                    //cell6.SetCellValue(int.Parse(LP.BalanceStatus));

                    //increase total                          
                    if (lstSum.ContainsKey(LP.BalanceStatus))
                    {
                        lstSum[LP.BalanceStatus] += 1;
                    }

                    curRowOneSheet++;                    
                }
                curRowOneSheet++;
            }

            this.AddFooterDataForReport(sheet, curRowOneSheet, lstSum);
        }

        /// <summary>
        /// Add Footer Data For Report
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lenghtData">lenght of Data</param>
        private void AddFooterDataForReport(ISheet sheet, int lenghtData, Dictionary<string, int> lstSum)
        {
           // int lenght = lenghtData - 1;
            //create the format instance
            IDataFormat format = workbook.CreateDataFormat();

            ICellStyle styleHor = workbook.CreateCellStyle();
            styleHor.Alignment = HorizontalAlignment.CENTER;
            styleHor.DataFormat = format.GetFormat("#,##0");

            //row type of balance status
            IRow rowFooter0 = sheet.CreateRow(lenghtData);
            rowFooter0.HeightInPoints = 16f;

            ICell cell03 = rowFooter0.CreateCell(3);
            cell03.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0213));
            cell03.CellStyle = styleHor;

            ICell cell04 = rowFooter0.CreateCell(4);
            cell04.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0214));
            cell04.CellStyle = styleHor;

            ICell cell05 = rowFooter0.CreateCell(5);
            cell05.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0215));
            cell05.CellStyle = styleHor;

            ICell cell06 = rowFooter0.CreateCell(6);
            cell06.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0216));
            cell06.CellStyle = styleHor;

            //set hang doc 
            ICellStyle styleVer = workbook.CreateCellStyle();
            styleVer.Alignment = HorizontalAlignment.RIGHT;
            //dong 1
            IRow rowFooter1 = sheet.CreateRow(lenghtData + 1);
            rowFooter1.HeightInPoints = 16f;
            ICell cell12 = rowFooter1.CreateCell(2);
            cell12.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0217));
            cell12.CellStyle = styleVer;

            ICell cell13 = rowFooter1.CreateCell(3);
            //string val13 = lstSum[Constant.BALANCE_STATUS_ARRIVAL].ToString();
            //cell13.SetCellFormula(val13);
            cell13.SetCellValue(lstSum[Constant.BALANCE_STATUS_ARRIVAL]);
            cell13.CellStyle = styleHor;

            ICell cell14 = rowFooter1.CreateCell(4);
            //string val14 = lstSum[Constant.BALANCE_STATUS_RECEIPT].ToString();
            //cell14.SetCellFormula(val14);
            cell14.SetCellValue(lstSum[Constant.BALANCE_STATUS_RECEIPT]);
            cell14.CellStyle = styleHor;

            ICell cell15 = rowFooter1.CreateCell(5);
            //string val15 = lstSum[Constant.BALANCE_STATUS_GOODS_ISSUE].ToString();
            //cell15.SetCellFormula(val15);
            cell15.SetCellValue(lstSum[Constant.BALANCE_STATUS_GOODS_ISSUE]);
            cell15.CellStyle = styleHor;

            ICell cell16 = rowFooter1.CreateCell(6);
            //string val16 = lstSum[Constant.BALANCE_STATUS_SHIPPING].ToString();
            //cell16.SetCellFormula(val16);
            cell16.SetCellValue(lstSum[Constant.BALANCE_STATUS_SHIPPING]);
            cell16.CellStyle = styleHor;

            //dong 2
            IRow rowFooter2 = sheet.CreateRow(lenghtData + 2);
            rowFooter2.HeightInPoints = 16f;
            ICell cell22 = rowFooter2.CreateCell(2);
            cell22.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0218));
            cell22.CellStyle = styleVer;

            ICell cell23 = rowFooter2.CreateCell(3);
            //string val23 = lstSum[Constant.BALANCE_STATUS_RETURN_ARRIVAL].ToString();
            //cell23.SetCellFormula(val23);
            cell23.SetCellValue(lstSum[Constant.BALANCE_STATUS_RETURN_ARRIVAL]);
            cell23.CellStyle = styleHor;

            ICell cell24 = rowFooter2.CreateCell(4);
            //string val24 = lstSum[Constant.BALANCE_STATUS_RETURN_RECEIPT].ToString();
            //cell24.SetCellFormula(val24);
            cell24.SetCellValue(lstSum[Constant.BALANCE_STATUS_RETURN_RECEIPT]);
            cell24.CellStyle = styleHor;

            ICell cell25 = rowFooter2.CreateCell(5);
            //string val25 = lstSum[Constant.BALANCE_STATUS_RETURN_ISSUE].ToString();
            //cell25.SetCellFormula(val25);
            cell25.SetCellValue(lstSum[Constant.BALANCE_STATUS_RETURN_ISSUE]);
            cell25.CellStyle = styleHor;

            ICell cell26 = rowFooter2.CreateCell(6);
            //string val26 = lstSum[Constant.BALANCE_STATUS_RETURN_SHIPPING].ToString();
            //cell26.SetCellFormula(val26);
            cell26.SetCellValue(lstSum[Constant.BALANCE_STATUS_RETURN_SHIPPING]);
            cell26.CellStyle = styleHor;

            //dong 3
            IRow rowFooter3 = sheet.CreateRow(lenghtData + 3);
            rowFooter3.HeightInPoints = 16f;
            ICell cell32 = rowFooter3.CreateCell(2);
            cell32.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0219));
            cell32.CellStyle = styleVer;

            ICell cell33 = rowFooter3.CreateCell(3);
            //string val33 = lstSum[Constant.BALANCE_STATUS_MOVES_ARRIVAL].ToString();
            //cell33.SetCellFormula(val33);
            cell33.SetCellValue(lstSum[Constant.BALANCE_STATUS_MOVES_ARRIVAL]);
            cell33.CellStyle = styleHor;

            ICell cell34 = rowFooter3.CreateCell(4);
            //string val34 = lstSum[Constant.BALANCE_STATUS_MOVE_RECEIPT].ToString();
            //cell34.SetCellFormula(val34);
            cell34.SetCellValue(lstSum[Constant.BALANCE_STATUS_MOVE_RECEIPT]);
            cell34.CellStyle = styleHor;

            ICell cell35 = rowFooter3.CreateCell(5);
            //string val35 = lstSum[Constant.BALANCE_STATUS_MOVE_ISSUE].ToString();
            //cell35.SetCellFormula(val35);
            cell35.SetCellValue(lstSum[Constant.BALANCE_STATUS_MOVE_ISSUE]);
            cell35.CellStyle = styleHor;

            ICell cell36 = rowFooter3.CreateCell(6);
            //string val36 = lstSum[Constant.BALANCE_STATUS_MOVE_SHIPPING].ToString();
            //cell36.SetCellFormula(val36);
            cell36.SetCellValue(lstSum[Constant.BALANCE_STATUS_MOVE_SHIPPING]);
            cell36.CellStyle = styleHor;

            //dong 4
            IRow rowFooter4 = sheet.CreateRow(lenghtData + 4);
            rowFooter4.HeightInPoints = 16f;
            ICell cell42 = rowFooter4.CreateCell(2);
            cell42.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0220));
            cell42.CellStyle = styleVer;

            ICell cell43 = rowFooter4.CreateCell(3);
            //string val43 = lstSum[Constant.BALANCE_STATUS_TAKE_ARRIVAL].ToString();
            //cell43.SetCellFormula(val43);
            cell43.SetCellValue(lstSum[Constant.BALANCE_STATUS_TAKE_ARRIVAL]);
            cell43.CellStyle = styleHor;

            ICell cell44 = rowFooter4.CreateCell(4);
            //string val44 = lstSum[Constant.BALANCE_STATUS_INVENTORY_RECEIPT].ToString();
            //cell44.SetCellFormula(val44);
            cell44.SetCellValue(lstSum[Constant.BALANCE_STATUS_INVENTORY_RECEIPT]);
            cell44.CellStyle = styleHor;

            ICell cell45 = rowFooter4.CreateCell(5);
            //string val45 = lstSum[Constant.BALANCE_STATUS_INVENTORY_ISSUE].ToString();
            //cell45.SetCellFormula(val45);
            cell45.SetCellValue(lstSum[Constant.BALANCE_STATUS_INVENTORY_ISSUE]);
            cell45.CellStyle = styleHor;

            ICell cell46 = rowFooter4.CreateCell(6);
            //string val46 = lstSum[Constant.BALANCE_STATUS_TAKE_SHIPPING].ToString();
            //cell46.SetCellFormula(val46);
            cell46.SetCellValue(lstSum[Constant.BALANCE_STATUS_TAKE_SHIPPING]);
            cell46.CellStyle = styleHor;

            //dong 5
            IRow rowFooter5 = sheet.CreateRow(lenghtData + 5);
            rowFooter5.HeightInPoints = 16f;
            ICell cell52 = rowFooter5.CreateCell(2);
            cell52.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0297));
            cell52.CellStyle = styleVer;
            
            ICell cell53 = rowFooter5.CreateCell(3);
            //string val53 = lstSum[Constant.BALANCE_STATUS_SCRAP_ARRIVAL].ToString();
            //cell53.SetCellFormula(val53);
            cell53.SetCellValue(lstSum[Constant.BALANCE_STATUS_SCRAP_ARRIVAL]);
            cell53.CellStyle = styleHor;

            ICell cell54 = rowFooter5.CreateCell(4);
            //string val54 = lstSum[Constant.BALANCE_STATUS_SCRAP_RECEIPT].ToString();
            //cell54.SetCellFormula(val54);
            cell54.SetCellValue(lstSum[Constant.BALANCE_STATUS_SCRAP_RECEIPT]);
            cell54.CellStyle = styleHor;

            ICell cell55 = rowFooter5.CreateCell(5);
            //string val55 = lstSum[Constant.BALANCE_STATUS_DISCARD_ISSUE].ToString();
            //cell55.SetCellFormula(val55);
            cell55.SetCellValue(lstSum[Constant.BALANCE_STATUS_DISCARD_ISSUE]);
            cell55.CellStyle = styleHor;

            ICell cell56 = rowFooter5.CreateCell(6);
            //string val56 = lstSum[Constant.BALANCE_STATUS_DISCARD_SHIPPING].ToString();
            //cell56.SetCellFormula(val56);
            cell56.SetCellValue(lstSum[Constant.BALANCE_STATUS_DISCARD_SHIPPING]);
            cell56.CellStyle = styleHor;

            //total
            ICellStyle styleTotal = workbook.CreateCellStyle();
            styleTotal.BorderTop = BorderStyle.THIN;
            styleTotal.TopBorderColor = HSSFColor.BLACK.index;
            styleTotal.Alignment = HorizontalAlignment.RIGHT;
            

            IRow rowFooter6 = sheet.CreateRow(lenghtData + 6);
            rowFooter6.HeightInPoints = 16f;
            rowFooter6.Height = 15 * 20;
            ICell cell62 = rowFooter6.CreateCell(2);
            cell62.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0083));
            cell62.CellStyle = styleTotal;
            
            //set total value
            this.SetFooterTotal(rowFooter6, lenghtData, format, lstSum);
            
        }

        /// <summary>
        /// Set Footer Total
        /// </summary>
        /// <param name="Row">IRow</param>
        /// <param name="LenghtData">Lenght of Data</param>
        /// <param name="DataFormat">IDataFormat</param>
        private void SetFooterTotal(IRow Row, int LenghtData, IDataFormat DataFormat, Dictionary<string, int> lstSum)
        {
            ICellStyle styleTotalVal = workbook.CreateCellStyle();
            styleTotalVal.BorderTop = BorderStyle.THIN;
            styleTotalVal.TopBorderColor = HSSFColor.BLACK.index;
            styleTotalVal.Alignment = HorizontalAlignment.CENTER;
            styleTotalVal.DataFormat = DataFormat.GetFormat("#,##0");

            int totalInbound = lstSum[Constant.BALANCE_STATUS_ARRIVAL] + lstSum[Constant.BALANCE_STATUS_RETURN_ARRIVAL] + lstSum[Constant.BALANCE_STATUS_MOVES_ARRIVAL] + lstSum[Constant.BALANCE_STATUS_TAKE_ARRIVAL]+ lstSum[Constant.BALANCE_STATUS_SCRAP_ARRIVAL];
            int totalReceipt = lstSum[Constant.BALANCE_STATUS_RECEIPT] + lstSum[Constant.BALANCE_STATUS_RETURN_RECEIPT] + lstSum[Constant.BALANCE_STATUS_MOVE_RECEIPT] + lstSum[Constant.BALANCE_STATUS_INVENTORY_RECEIPT]+ lstSum[Constant.BALANCE_STATUS_SCRAP_RECEIPT];
            int totalIssue = lstSum[Constant.BALANCE_STATUS_GOODS_ISSUE] + lstSum[Constant.BALANCE_STATUS_RETURN_ISSUE] + lstSum[Constant.BALANCE_STATUS_MOVE_ISSUE] + lstSum[Constant.BALANCE_STATUS_INVENTORY_ISSUE]+ lstSum[Constant.BALANCE_STATUS_DISCARD_ISSUE];
            int totalOutbound = lstSum[Constant.BALANCE_STATUS_SHIPPING] + lstSum[Constant.BALANCE_STATUS_RETURN_SHIPPING] + lstSum[Constant.BALANCE_STATUS_MOVE_SHIPPING] + lstSum[Constant.BALANCE_STATUS_TAKE_SHIPPING] + lstSum[Constant.BALANCE_STATUS_DISCARD_SHIPPING];
            
            ICell cell63 = Row.CreateCell(3);
            //string val63 = totalInbound.ToString();
            //cell63.SetCellFormula(val63);
            cell63.SetCellValue(totalInbound);
            cell63.CellStyle = styleTotalVal;

            ICell cell64 = Row.CreateCell(4);
            //string val64 = totalReceipt.ToString();
            //cell64.SetCellFormula(val64);
            cell64.SetCellValue(totalReceipt);
            cell64.CellStyle = styleTotalVal;

            ICell cell65 = Row.CreateCell(5);
            //string val65 = totalIssue.ToString();
            //cell65.SetCellFormula(val65);
            cell65.SetCellValue(totalIssue);
            cell65.CellStyle = styleTotalVal;

            ICell cell66 = Row.CreateCell(6);
            //string val66 = totalOutbound.ToString();
            //cell66.SetCellFormula(val66);
            cell66.SetCellValue(totalOutbound);
            cell66.CellStyle = styleTotalVal;
        }
        
        /// <summary>
        /// Write To Stream
        /// </summary>
        /// <returns>MemoryStream</returns>
        MemoryStream WriteToStream()
        {
            //Write the stream data of workbook to the root directory
            MemoryStream file = new MemoryStream();
            workbook.Write(file);
            return file;
        }

        #endregion
    }
}

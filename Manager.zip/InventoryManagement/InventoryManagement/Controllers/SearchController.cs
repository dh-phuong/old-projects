﻿using InventoryManagement.Common;
using InventoryManagement.iQueryable;
using InventoryManagement.Models;
using InventoryManagement.Validation;
using System.Linq;
using System.Web.Helpers;
using System.Web.Mvc;
using System.Collections;

namespace InventoryManagement.Controllers
{
    [InventoryManagement.Validation.iAuthorize]
    public class SearchController : BaseController
    {
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MKind_HService mKind_HService;
        private DataAccess.MUserService mUserService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TStockAllowanceService tStockAllowanceService;
        private DataAccess.MGroup_HService mGroup_HService;
        private DataAccess.MCategoryService mCategoryService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mKind_DService">DataAccess.MKind_DService</param>
        /// <param name="mKind_HService">DataAccess.MKind_HService</param>
        /// <param name="mUserService">DataAccess.MUserService</param>
        /// <param name="mProductService">DataAccess.MProductService</param>
        /// <param name="mWarehouseService">DataAccess.MWarehouseService</param>
        /// <param name="mLocationService">DataAccess.MLocationService</param>
        /// <param name="mCustomerService">DataAccess.MCustomerService</param>
        /// <param name="mCompanyService">DataAccess.MCompanyService</param>
        /// <param name="tInventoryService">DataAccess.TInventoryService</param>
        /// <param name="mGroup_HService">DataAccess.MGroup_HService</param>
        /// <param name="mCategoryService">DataAccess.MCategoryService</param>
        public SearchController(DataAccess.MKind_DService mKind_DService,
                                DataAccess.MKind_HService mKind_HService,
                                DataAccess.MUserService mUserService,
                                DataAccess.MProductService mProductService,
                                DataAccess.MWarehouseService mWarehouseService,
                                DataAccess.MLocationService mLocationService,
                                DataAccess.MCustomerService mCustomerService,
                                DataAccess.MCompanyService mCompanyService,
                                DataAccess.TInventory_HService tInventory_HService,
                                DataAccess.TInventory_DService tInventory_DService,
                                DataAccess.TStockAllowanceService tStockAllowanceService,
                                DataAccess.MGroup_HService mGroup_HService,
                                DataAccess.MCategoryService mCategoryService
            )
        {
            this.mKind_DService = mKind_DService;
            this.mKind_HService = mKind_HService;
            this.mUserService = mUserService;
            this.mProductService = mProductService;
            this.mWarehouseService = mWarehouseService;
            this.mLocationService = mLocationService;
            this.mCustomerService = mCustomerService;
            this.mCompanyService = mCompanyService;
            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.tStockAllowanceService = tStockAllowanceService;
            this.mGroup_HService = mGroup_HService;
            this.mCategoryService = mCategoryService;
        }

        #region UserSearch

        #region Constant
        private const string USER_KEY_USER_CD = "sUserCD";
        private const string USER_SORT_DEFAULT = "sUserCD";
        private const string ROLES_CD_CONTROL = "sRolesCD";
        private const string USER_SORT_URL = "/Search/UserSorting";
        #endregion

        /// <summary>
        /// User Search
        /// Author: ISV-Tram
        /// </summary>
        /// <param name="gmModel">UserSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult UserSearch(UserSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get data list 
                IQueryable<UserSearch> list = this.mUserService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(USER_KEY_USER_CD);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = USER_SORT_URL,
                    SortField = USER_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<UserSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore:true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// User Paging
        /// Author: ISV-Tram
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UserPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            UserSearch gmModel = new UserSearch();
            IQueryable<UserSearch> list = (IQueryable<UserSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<UserSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_UserList", gmModel);
        }

        /// <summary>
        /// User Sorting
        /// Author: ISV-Tram
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UserSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            UserSearch gmModel = new UserSearch();
            IQueryable<UserSearch> list = (IQueryable<UserSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];
            this.SortingBase<UserSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_UserList", gmModel);
        }

        #endregion

        #region Customer Search

        #region Constant
        private const string CUSTOMER_KEY_CUSTOMER_CD = "sCustomerCD";
        private const string CUSTOMER_KEY_CUSTOMER_NAME = "sCustomerName";
        private const string CUSTOMER_SORT_URL = "/Search/CustomerSorting";
        #endregion

        /// <summary>
        /// Customer Search
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="gmModel">CustomerSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult CustomerSearch(CustomerSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<CustomerSearch> list = this.mCustomerService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(CUSTOMER_KEY_CUSTOMER_CD);

                //Check result is empty
                if (list.Count() == 0)
                {
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = CUSTOMER_SORT_URL,
                    SortField = CUSTOMER_KEY_CUSTOMER_CD,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<CustomerSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// Customer Paging 
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CustomerPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            CustomerSearch gmModel = new CustomerSearch();
            IQueryable<CustomerSearch> list = (IQueryable<CustomerSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<CustomerSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_CustomerList", gmModel);
        }

        /// <summary>
        /// Customer Sorting
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CustomerSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            CustomerSearch gmModel = new CustomerSearch();
            IQueryable<CustomerSearch> list = (IQueryable<CustomerSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<CustomerSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_CustomerList", gmModel);
        }

        #endregion

        #region Kind Search

        #region Constant
        private const string KIND_KEY_DATACD = "sDataCD";
        private const string KIND_KEY_VALUE = "sValue";
        private const string KIND_SORT_DEFAULT = "sDataCD";
        private const string KIND_SORT_URL = "/Search/KindSorting";
        #endregion

        /// <summary>
        /// Kind Search
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">KindSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult KindSearch(KindSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<KindSearch> list = this.mKind_HService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(KIND_KEY_DATACD);

                //Check result is empty
                int count = list.Count();
                if (count == 0)
                {
                    this.SetFocusId(KIND_KEY_DATACD);
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = KIND_SORT_URL,
                    SortField = KIND_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<KindSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// Kind Paging 
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult KindPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            KindSearch gmModel = new KindSearch();
            IQueryable<KindSearch> list = (IQueryable<KindSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<KindSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_KindList", gmModel);
        }

        /// <summary>
        /// Kind Sorting
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult KindSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            KindSearch gmModel = new KindSearch();
            IQueryable<KindSearch> list = (IQueryable<KindSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<KindSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_KindList", gmModel);
        }

        #endregion

        #region WareHouse

        #region Constant
        private const string WAREHOUSE_KEY_WAREHOUSECD = "sWarehouseCD";
        private const string WAREHOUSE_KEY_WAREHOUSENAME = "sWarehouseName";
        private const string WAREHOUSE_SORT_DEFAULT = "sWarehouseCD";
        private const string WAREHOUSE_SORT_URL = "/Search/WarehouseSorting";
        #endregion

        /// <summary>
        /// Warehouse Search
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="gmModel">WarehouseSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult WarehouseSearch(WarehouseSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<WarehouseSearch> list = this.mWarehouseService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(WAREHOUSE_KEY_WAREHOUSECD);

                //Check result is empty
                int count = list.Count();
                if (count == 0)
                {
                    this.SetFocusId(WAREHOUSE_KEY_WAREHOUSECD);
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = WAREHOUSE_SORT_URL,
                    SortField = WAREHOUSE_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };
                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<WarehouseSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }
            return PartialView(gmModel);
        }

        /// <summary>
        /// Warehouse Paging
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult WarehousePaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            WarehouseSearch gmModel = new WarehouseSearch();
            IQueryable<WarehouseSearch> list = (IQueryable<WarehouseSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<WarehouseSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_WarehouseList", gmModel);
        }

        /// <summary>
        /// Warehouse Sorting
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult WarehouseSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            WarehouseSearch gmModel = new WarehouseSearch();
            IQueryable<WarehouseSearch> list = (IQueryable<WarehouseSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<WarehouseSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_WarehouseList", gmModel);
        }

        #endregion

        #region Location

        #region Constant
        private const string LOCATION_KEY_LOCATIONCD = "sLocationCD";
        private const string LOCATION_KEY_LOCATIONAME = "sLocationName";
        private const string LOCATION_SORT_DEFAULT = "sLocationCD";
        private const string LOCATION_SORT_URL = "/Search/LocationSorting";
        #endregion

        /// <summary>
        /// Location Search Action
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="gmModel">LocationSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult LocationSearch(LocationSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<LocationSearch> list = this.mLocationService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(LOCATION_KEY_LOCATIONCD);

                //Check result is empty
                int count = list.Count();
                if (count == 0)
                {
                    this.SetFocusId(LOCATION_KEY_LOCATIONCD);
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = LOCATION_SORT_URL,
                    SortField = LOCATION_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<LocationSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// Location Paging
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult LocationPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            LocationSearch gmModel = new LocationSearch();
            IQueryable<LocationSearch> list = (IQueryable<LocationSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<LocationSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_LocationList", gmModel);
        }

        /// <summary>
        /// Location Sorting
        /// Author:ISV-HUNG
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult LocationSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            LocationSearch gmModel = new LocationSearch();
            IQueryable<LocationSearch> list = (IQueryable<LocationSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<LocationSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_LocationList", gmModel);
        }

        #endregion

        #region Product search

        #region Constant
        private const string PRODUCT_KEY_DATA_KIND = "sProductCD";
        private const string PRODUCT_SORT_DEFAULT = "sProductCD";
        private const string PRODUCT_SORT_URL = "/Search/ProductSorting";
        #endregion

        /// <summary>
        /// Search Action
        /// Author: ISV-PHUONG
        /// </summary>
        /// <param name="gmModel">ProductSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult ProductSearch(ProductSearch gmModel)
        {
            ViewBag.Title = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0062);
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            //Check search data
            if (this.ModelState.IsValid)
            {
                IQueryable<ProductSearch> list = null;

                //Get list
                if (!gmModel.IsStockOnly)
                {
                    list = this.mProductService.GetListByConditionsForSearch(gmModel);
                }
                else
                {
                    list = this.mProductService.GetListByConditionsForSearchStockOnly(gmModel);
                }                                

                //Focus
                this.SetFocusId(PRODUCT_KEY_DATA_KIND);

                //Check result is empty
                int count = list.Count();
                if (count == 0)
                {
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = PRODUCT_SORT_URL,
                    SortField = PRODUCT_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<ProductSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// ProductSorting
        /// Author:ISV-PHUONG
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult ProductSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session            
            IQueryable<ProductSearch> list = (IQueryable<ProductSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];
            ProductSearch gmModel = new ProductSearch();

            this.SortingBase<ProductSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_ProductList", gmModel);
        }

        /// <summary>
        /// Product Paging
        /// Author:ISV-PHUONG
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ProductPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<ProductSearch> list = (IQueryable<ProductSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];
            ProductSearch gmModel = new ProductSearch();

            this.PagingBase<ProductSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_ProductList", gmModel);
        }

        #endregion

        #region Group Search

        #region Constant
        private const string GROUP_KEY_GROUP_CD = "sGroupCD";
        private const string GROUP_KEY_GROUP_NAME = "sGroupName";
        private const string GROUP_SORT_URL = "/Search/GroupSorting";
        #endregion

        /// <summary>
        /// Group Search
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="gmModel">GroupSearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult GroupSearch(GroupSearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<GroupSearch> list = this.mGroup_HService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(GROUP_KEY_GROUP_CD);

                //Check result is empty
                if (list.Count() == 0)
                {
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = GROUP_SORT_URL,
                    SortField = GROUP_KEY_GROUP_CD,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<GroupSearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// Group Paging 
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult GroupPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            GroupSearch gmModel = new GroupSearch();
            IQueryable<GroupSearch> list = (IQueryable<GroupSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<GroupSearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_GroupList", gmModel);
        }

        /// <summary>
        /// Group Sorting
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult GroupSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            GroupSearch gmModel = new GroupSearch();
            IQueryable<GroupSearch> list = (IQueryable<GroupSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<GroupSearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_GroupList", gmModel);
        }

        #endregion

        #region Category Search

        #region Constant
        private const string CATEGORY_KEY_CATEGORY_CD = "sCategoryCD";
        private const string CATEGORY_KEY_CATEGORY_NAME = "sCategoryName";
        private const string CATEGORY_SORT_URL = "/Search/CategorySorting";
        #endregion

        /// <summary>
        /// Category Search
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="gmModel">CategorySearch</param>
        /// <returns>ActionResult</returns>
        public ActionResult CategorySearch(CategorySearch gmModel)
        {
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Get list
                IQueryable<CategorySearch> list = this.mCategoryService.GetListByConditionsForSearch(gmModel);

                //Focus
                this.SetFocusId(CATEGORY_KEY_CATEGORY_CD);

                //Check result is empty
                if (list.Count() == 0)
                {
                    return PartialView(gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = list;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = CATEGORY_SORT_URL,
                    SortField = CATEGORY_KEY_CATEGORY_CD,
                    Direction = SortDirection.Ascending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<CategorySearch>(ref list, pageRequest, sortInfo, gmModel.SeqNum, notStore: true);
            }

            return PartialView(gmModel);
        }

        /// <summary>
        /// Category Paging 
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CategoryPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            CategorySearch gmModel = new CategorySearch();
            IQueryable<CategorySearch> list = (IQueryable<CategorySearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<CategorySearch>(ref list, pageRequest, sortInfo, SeqNum, notStore: true);
            return PartialView("_CategoryList", gmModel);
        }

        /// <summary>
        /// Group Sorting
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CategorySorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            CategorySearch gmModel = new CategorySearch();
            IQueryable<CategorySearch> list = (IQueryable<CategorySearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase<CategorySearch>(list, sortInfo, SeqNum, notStore: true);

            return PartialView("_CategoryList", gmModel);
        }

        #endregion

        #region TagInfo Search

        #region Constant
        private const string TAG_INFO_KEY_TAGNO = "sPTagNo";
        private const string TAG_INFO_SORT_DEFAULT = "sPTagInfo";
        private const string TAG_INFO_SORT_URL = "/Search/TagInfoSorting";
        #endregion

        /// <summary>
        /// TagInfo Search
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public ActionResult TagInfoSearch(TagInfoSearch gmModel)
        {
            //Create new Sequence Number
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            string labelCD = gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP) ? Constant.LBL_L0304 : Constant.LBL_L0296;

            //Set title
            this.Session[Constant.SESSION_TITLE + gmModel.SeqNum] = UserSession.Session.SysCache.GetLabel(labelCD);

            gmModel.IsShowSuplier = this.mKind_HService.IsShowCustomer();

            //Check Search Conditions
            if (this.ModelState.IsValid)
            {
                //Get List Result
                IQueryable<TagInfoSearch> result = this.tInventory_HService.GetListForTagInfoSearch(gmModel);

                //Set focus
                this.SetFocusId(TAG_INFO_KEY_TAGNO);

                //Check result is empty
                if (result.Count() == 0)
                {
                    return this.PartialView("TagInfoSearch",gmModel);
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = result;

                //Create sort Information
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = TAG_INFO_SORT_URL,
                    SortField = TAG_INFO_SORT_DEFAULT,
                    Direction = SortDirection.Ascending,
                };

                //Create Pagging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<TagInfoSearch>(ref result, pageRequest, sortInfo, gmModel.SeqNum, notStore : true);

            }
            return PartialView("TagInfoSearch", gmModel);
        }

        /// <summary>
        /// TagInfo Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">Sorting Information</param>
        /// <param name="seqNum">Sequence number</param>
        /// <returns>List After paging</returns>
        [HttpPost]
        public ActionResult TagInfoPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get result from session
            TagInfoSearch gmModel = new TagInfoSearch();
            IQueryable<TagInfoSearch> result = (IQueryable<TagInfoSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.PagingBase<TagInfoSearch>(ref result, pageRequest, sortInfo, SeqNum, notStore: true);
            return this.PartialView("_TagInfoList", gmModel);
        }

        /// <summary>
        /// TagInfo Sorting
        /// </summary>
        /// <param name="sortInfo">Sorting Information</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>List After Sorting</returns>
        [HttpPost]
        public ActionResult TagInfoSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get result from session
            TagInfoSearch gmModel = new TagInfoSearch();
            IQueryable<TagInfoSearch> result = (IQueryable<TagInfoSearch>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            this.SortingBase(result, sortInfo, SeqNum, notStore: true);
            return this.PartialView("_TagInfoList", gmModel);
        }

        #endregion

        #region Public Function

        /// <summary>
        /// Show Customer Name
        /// </summary>
        /// <param name="CustomerCD">Customer Code</param>
        /// <returns>Customer Name</returns>
        public JsonResult ShowCustomerName(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(string.Empty, JsonRequestBehavior.AllowGet);
            }

            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);
            if (model != default(CustomerModels) && !model.DeleteFlag)
            {
                return Json(model.CustomerName, JsonRequestBehavior.AllowGet);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Product Name
        /// </summary>
        /// <param name="ProductCD">Product Code</param>
        /// <returns>Product Name</returns>
        public JsonResult ShowProductName(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return Json(string.Empty, JsonRequestBehavior.AllowGet);
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD);
            if (model != default(ProductModels) && !model.DeleteFlag)
            {
                return Json(model.ProductName, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Location Name
        /// </summary>
        /// <param name="LocationCD">Location Code</param>
        /// <returns>Location Name</returns>
        public JsonResult ShowLocationName(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return Json(string.Empty, JsonRequestBehavior.AllowGet);
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.WarehouseCD, LocationCD);
            if (model != default(LocationModels) && !model.DeleteFlag)
            {
                return Json(model.LocationName, JsonRequestBehavior.AllowGet);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion
    }
}

﻿using Microsoft.Reporting.WebForms;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Helpers;
using System.Data.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Drawing;
using NPOI.POIFS.FileSystem;
using NPOI.HSSF.Util;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Report;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using NPOI.HPSF;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.UserModel;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 在庫照会
    /// Author : ISV-LOC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class StockInquiryController : BaseController
    {
        #region Common

        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.MCategoryService mCategoryService;
        private bool isShowSup;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        public StockInquiryController(DataAccess.TInventory_HService tInventory_HService,
                                      DataAccess.TInventory_DService tInventory_DService,
                                      DataAccess.MProductService mProductService,
                                      DataAccess.MWarehouseService mWarehouseService,
                                      DataAccess.MKind_DService mKind_DService,
                                      DataAccess.MCompanyService mCompanyService,
                                      DataAccess.MLocationService mLocationService,
                                      DataAccess.MCustomerService mCustomerService,
                                      DataAccess.MCategoryService mCategoryService)
        {
            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.mProductService = mProductService;
            this.mWarehouseService = mWarehouseService;
            this.mKind_DService = mKind_DService;
            this.mCompanyService = mCompanyService;
            this.mLocationService = mLocationService;
            this.mCustomerService = mCustomerService;
            this.mCategoryService = mCategoryService;

            //Use single data context
            DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tInventory_HService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.mProductService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.mCompanyService.Context = ctx;
            this.mLocationService.Context = ctx;
            this.mCustomerService.Context = ctx;
            this.mCategoryService.Context = ctx;

            this.isShowSup = this.mKind_DService.IsShowCustomer();
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string SAVE_LIST_PRINT = "Save_List_Print";

        private const string PRINT_WITH_BRANCH_TAGNO = "Print_With_BranchTagNo";
        private const string PRINT_WITH_TAGNO = "Print_With_TagNo";

        public const int BRANCH_TAG_NO_SHOW_PRINT = 4;

        private const string BUTTON_UPDATE = "btnUpdate";

        private const string CHK_FIRST_ROW = "checkFirst";

        private const string BUTTON_PRINT_GROUP = "btnPrintGroup";
        private const string BUTTON_PRINT_BRANCH = "btnPrintBranch";

        private const string DROPDOWN_STATUS_SEARCH = "ddl_Status";
        private const string DROPDOWN_STATUS = "StockStatus";
        private const string DROPDOWN_STATUS_LIST = "arrStockStatus";
        private const string GROUP_MEMO = "sMemo";
        private const string BRANCH_MEMO = "Memo";
        private const string KEY_LOT1 = "LOT1";
        private const string KEY_S_LOT1 = "sLOT1";
        private const string KEY_SUPPLIER = "SuplierCD";
        private const string KEY_S_SUPPLIER = "sSuplierCD";

        private const string PARTIAL_LIST = "_List";

        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_DETAIL_BRANCH = "DetailBranch";
        private const string SCREEN_DETAIL_GROUP = "DetailGroup";

        private const string SEARCH_TAG_NO = "txt_TagNo";

        private const string SORT_DEFAULT = "TagNo";
        private const string SORT_URL = "/StockInquiry/Sorting";
        private const string PRINT_ACTION_URL = "/StockInquiry/PrintAction";
        private const string EXCEL_ACTION_URL = "/StockInquiry/ExcelAction";

        private const string PRINT_DETAIL_ACTION_URL = "/StockInquiry/PrintDetailAction";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        private const string PATH_PRODUCT = "~/Report/StockListPro.rdlc";
        private const string PATH_PRODUCT_BRANCH = "~/Report/StockListProBra.rdlc";
        private const string PATH_LOCATION = "~/Report/StockListLoca.rdlc";
        private const string PATH_LOCATION_BRANCH = "~/Report/StockListLocaBra.rdlc";
        private const string NAME_DATASET = "StockList";
        private const int PDF_NUMBER_ROW_PER_PAGE = 30;

        private const string PATH_LARGE_REPORT = "~/Report/LargeTagLabel.rdlc";
        private const string PATH_SMALL_REPORT = "~/Report/SmallTagLabel.rdlc";

        //SET STYLE EXCEL
        private const float HEIGHT_ROW = 16f;
        private const float HEIGHT_ROW_TITLE = 18f;

        private const string CSS_TITLE = "css_title";
        private const string CSS_HEADER_GROUP_2 = "css_header_group_2";
        private const string CSS_HEADER_GRID_LEFT = "css_header_grid_left";
        private const string CSS_HEADER_GRID_RIGHT = "css_header_grid_right";
        private const string CSS_ROW_DETAIL_STRING = "css_row_detail_string";
        private const string CSS_ROW_DETAIL_INT = "css_row_detail_int";
        private const string CSS_ROW_DETAIL_DECIMAL = "css_row_detail_decimal";
        private const string CSS_LBL_TOTAL_BODER_TOP = "css_lbl_total_boder_top";
        private const string CSS_LBL_TOTAL_BODER_TOP_BOTTOM = "css_lbl_total_boder_top_bottom";
        private const string CSS_CELL_EMPTY_BORDER_TOP = "css_cell_empty_border_top";
        private const string CSS_CELL_EMPTY_BORDER_TOP_BOTTOM = "css_cell_empty_border_top_bottom";
        private const string CSS_VALUE_TOTAL_INT_BORDER_TOP = "css_value_total_int_border_top";
        private const string CSS_VALUE_TOTAL_INT_BORDER_TOP_BOTTOM = "css_value_total_int_border_top_bottom";
        private const string CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP = "css_value_total_decimal_border_top";
        private const string CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM = "css_value_total_decimal_border_top_bottom";


        #endregion

        #region Event

        #region Index

        /// <summary>
        /// List
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(StockInquiryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(StockInquiryList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                StockInquiryList oldModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(StockInquiryList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<StockInquiryResults> results = this.tInventory_HService.GetListStockInquiryByConditions(gmModel, gmModel.chk_GroupBranchTagNo);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<StockInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_TAG_NO);
                }
            }
            this.SetDropDownlistAllForSearch(gmModel);

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            gmModel.IsShowSuplier = this.isShowSup;

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Common.Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<StockInquiryResults> results = tInventory_HService.GetListStockInquiryByConditions(gmModel, gmModel.chk_GroupBranchTagNo);

                //Store result into session
                this.Session[Common.Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<StockInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_TAG_NO);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockInquiryResults> list = (IQueryable<StockInquiryResults>)this.Session[Common.Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<StockInquiryResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockInquiryResults> list = (IQueryable<StockInquiryResults>)this.Session[Common.Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<StockInquiryResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        #endregion

        #region Show

        /// <summary>
        /// View
        /// </summary>
        ///<param name="value1">TagNo</param>
        /// <param name="value2">Sequence Number</param>
        ///<param name="value3">BranchTagNo</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2, string value3)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Set Print Detail
            this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + value2] = new StockInquiryPrintInput();

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);
            StockInquiryList modelCondition = (StockInquiryList)this.Session[Common.Constant.SESSION_LIST_CONDITION + value2.ToString()];

            //Get data
            if (modelCondition.chk_GroupBranchTagNo)
            {
                //Get data for Group ListDetail
                List<GroupListDetail> listGroup = tInventory_HService.GetDetailForStockInquiryGroup(value1);

                if (listGroup.Count == 0)
                {
                    return this.ExclusionProcess(modelCondition.chk_GroupBranchTagNo, value2);
                }
                StockInquiryGroupModels model = new StockInquiryGroupModels();

                //Set Data Header
                this.SetDetailHeaderGroup(model, listGroup);

                //Set data for List Group
                this.SetDetailListGroup(model);

                //Get UpdateDate
                model.UpdateDate = tInventory_HService.GetMaxUpdateDateForStockInquiryGroup(value1);

                //Store data into session
                model.SeqNum = value2;
                this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

                if (TempData[TMP_DOWNLOAD_FILE] != null)
                {
                    this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], model.SeqNum);
                    ViewBag.IsDownload = true;
                }

                //Set focus
                //this.SetFocusId(BUTTON_UPDATE);
                return View(SCREEN_DETAIL_GROUP, model);
            }
            else
            {
                //Get data for StockInquiry Branch
                StockInquiryBranchModels model = tInventory_HService.GetDetailForStockInquiryBranch(value1, value3);
                if (model == default(StockInquiryBranchModels))
                {
                    return this.ExclusionProcess(modelCondition.chk_GroupBranchTagNo, value2);
                }
                model.IsShowSuplier = this.isShowSup;

                //Store data into session
                model.SeqNum = value2;
                this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

                this.SetDropDownlistForBranch(model.StockStatus);
                ////Set focus
                //this.SetFocusId(BUTTON_UPDATE);

                if (TempData[TMP_DOWNLOAD_FILE] != null)
                {
                    this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], model.SeqNum);
                    ViewBag.IsDownload = true;
                }
                return View(SCREEN_DETAIL_BRANCH, model);
            }
        }

        #endregion Show

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="TagNo"></param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="BranchTagNo"></param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(string TagNo, int SeqNum, string BranchTagNo)
        {
            this.ClearModelState();
            if (this.GetMode(SeqNum) != Mode.Show)
            {
                return this.Show(TagNo, SeqNum, BranchTagNo);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion Back

        #region UpdateBranch

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum"></param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateBranch(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            StockInquiryBranchModels gmModel = (StockInquiryBranchModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            TInventory_D idModel = tInventory_DService.GetByPK(gmModel.TagNo, CommonUtil.ParseInteger(gmModel.BranchTagNo));
            this.SetDropDownlistForBranch(gmModel.StockStatus);

            //Check Exclusion
            if (idModel == default(TInventory_D) || gmModel.UpdateDate != idModel.UpdateDate)
            {
                return this.ExclusionProcess(false, SeqNum);
            }

            gmModel.IsEditCus = this.tInventory_HService.IsEditCus(gmModel.TagNo);
            gmModel.LOT2Date = new DateControl(CommonUtil.ParseDate(gmModel.LOT2, Constant.FMT_DATE, Constant.FMT_YMD));
            gmModel.LOT3Date = new DateControl(CommonUtil.ParseDate(gmModel.LOT3, Constant.FMT_DATE, Constant.FMT_YMD));

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set focusId
            this.SetFocusId(BRANCH_MEMO);
            if (gmModel.canEditStatus)
            {
                this.SetFocusId(DROPDOWN_STATUS);
            }
            if (gmModel.IsEditCus)
            {
                if (isShowSup)
                {
                    this.SetFocusId(KEY_SUPPLIER);
                }
                else
                {
                    this.SetFocusId(KEY_LOT1);

                }
            }
            return View(SCREEN_DETAIL_BRANCH, gmModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateBranchConfirm(StockInquiryBranchModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateBranchCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/StockInquiry/UpdateBranchAction", value1: gmModel.SeqNum.ToString());
                }
            }

            this.SetDropDownlistForBranch(gmModel.StockStatus);
            return View(SCREEN_DETAIL_BRANCH, gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1"></param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateBranchAction(string value1)
        {
            //Get screen model from session
            StockInquiryBranchModels gmModel = (StockInquiryBranchModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            this.SetDropDownlistForBranch(gmModel.StockStatus);
            //Update check
            if (!this.UpdateBranchCheck(gmModel))
            {
                return View(SCREEN_DETAIL_BRANCH, gmModel);
            }
            //Update data
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.UpdateBranchData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/StockInquiry/Show", gmModel.TagNo, gmModel.SeqNum.ToString(), gmModel.BranchTagNo);
                    ret = View(SCREEN_DETAIL_BRANCH, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction(SCREEN_INDEX);
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateBranchConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion UpdateBranch

        #region UpdateGroup

        /// <summary>
        /// Update Group
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateGroup(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            StockInquiryGroupModels model = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Check Exclusion
            string updateDate = tInventory_HService.GetMaxUpdateDateForStockInquiryGroup(model.TagNo);
            if (model.listGroup.Count == 0 || !model.UpdateDate.Equals(updateDate))
            {
                return this.ExclusionProcess(true, SeqNum);
            }

            model.IsEditCus = this.tInventory_HService.IsEditCus(model.TagNo);
            model.LOT2Date = new DateControl(CommonUtil.ParseDate(model.sLOT2, Constant.FMT_DATE, Constant.FMT_YMD));
            model.LOT3Date = new DateControl(CommonUtil.ParseDate(model.sLOT3, Constant.FMT_DATE, Constant.FMT_YMD));

            //Get data for Group ListDetail
            List<GroupListDetail> listGroup = tInventory_HService.GetDetailForStockInquiryGroup(model.TagNo);

            if (listGroup.Count == 0)
            {
                return this.ExclusionProcess(true, SeqNum);

            }

            //if (listGroup.All(m=> !m.IsCanEdit))
            //{
            //    string message = this.FormatMessage(Constant.MES_M0081);
            //    this.ShowMessageInfo(message);
            //    return Show(model.TagNo, model.SeqNum, string.Empty);
            //}

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set data for List Group
            this.SetDropDownlistForGroup(model.arrStockStatus);

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(GROUP_MEMO);

            if (model.IsEditCus)
            {
                if (isShowSup)
                {
                    this.SetFocusId(KEY_S_SUPPLIER);
                }
                else
                {
                    this.SetFocusId(KEY_S_LOT1);

                }
            }
            return View(SCREEN_DETAIL_GROUP, model);
        }

        /// <summary>
        /// Update Group Confirm
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateGroupConfirm(StockInquiryGroupModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateGroupCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/StockInquiry/UpdateGroupAction", value1: gmModel.SeqNum.ToString());
                }
            }
            //Get Display Stock Status
            gmModel.arrStockStatusDisp = this.GetDisplayStockStatus(gmModel.arrStockStatus);

            //Set Drop Down list For Group
            this.SetDropDownlistForGroup(gmModel.arrStockStatus);
            return View(SCREEN_DETAIL_GROUP, gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateGroupAction(string value1)
        {
            //Get screen model from session
            StockInquiryGroupModels gmModel = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            this.SetDropDownlistForGroup(gmModel.arrStockStatus);

            //Update check
            if (!this.UpdateGroupCheck(gmModel))
            {
                return View(SCREEN_DETAIL_GROUP, gmModel);
            }
            //Update data
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.UpdateGroupData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/StockInquiry/Show", gmModel.TagNo, gmModel.SeqNum.ToString(), null);
                    ret = View(SCREEN_DETAIL_GROUP, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction(SCREEN_INDEX);
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateGroupConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion UpdateGroup

        #region CSV

        /// <summary>
        /// CSV
        /// </summary>
        /// <param name="gmModel">CustomerList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(StockInquiryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            StockInquiryList oldModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum];
            this.RestoreGrid(gmModel, oldModel);
            this.ClearModelState();

            string filename = string.Empty;
            string fileFullName = string.Empty;
            string directory = string.Empty;
            string[] hideColumn = { };

            if (gmModel.chk_GroupBranchTagNo)
            {
                //Export CSV Group
                IQueryable<StockInquiryGroupCSV> customerListCSV = this.tInventory_HService.GetListStockInquiryGroupCSV();
                if (customerListCSV.Count() == 0)
                {
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                    return View(SCREEN_INDEX, gmModel);
                }
                directory = System.Configuration.ConfigurationManager.AppSettings["StockInquiry"];
                filename = string.Format("{0}-{1}.csv", "StockInquiry", this.GetCurrentDate());
                fileFullName = System.IO.Path.Combine(directory, filename);
                var file = this.CSVOutPut<StockInquiryGroupCSV>(customerListCSV, hideColumn, fileFullName, "STOCKINQUIRY.csv");

                //Set download
                this.StoreFileDownload(file, gmModel.SeqNum);
                ViewBag.IsDownload = true;
                return View(SCREEN_INDEX, gmModel);
            }
            else
            {
                //Export CSV Branch
                IQueryable<StockInquiryBranchCSV> customerListCSV = this.tInventory_HService.GetListStockInquiryBranchCSV();
                if (customerListCSV.Count() == 0)
                {
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                    return View(SCREEN_INDEX, gmModel);
                }
                directory = System.Configuration.ConfigurationManager.AppSettings["StockInquiry"];
                filename = string.Format("{0}-{1}.csv", "StockInquiry", this.GetCurrentDate());
                fileFullName = System.IO.Path.Combine(directory, filename);
                var file = this.CSVOutPut<StockInquiryBranchCSV>(customerListCSV, hideColumn, fileFullName, "STOCKINQUIRY.csv");

                //Set download
                this.StoreFileDownload(file, gmModel.SeqNum);
                ViewBag.IsDownload = true;
                return View(SCREEN_INDEX, gmModel);
            }
        }

        #endregion CSV

        #region Ajax

        /// <summary>
        /// Show Product Name
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <returns>Product Name</returns>
        [HttpPost]
        public string ShowProductName(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return string.Empty;
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD);
            if (model != default(ProductModels) && !model.DeleteFlag)
            {
                return model.ProductName;
            }
            return string.Empty;
        }

        /// <summary>
        /// Show Location Name        
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>
        [HttpPost]
        public string ShowLocationNm(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return string.Empty;
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            if (model != default(LocationModels) && !model.DeleteFlag)
            {
                return model.LocationName;
            }
            return string.Empty;
        }

        /// <summary>
        /// Show CustomerName
        /// </summary>
        /// <param name="CustomerCD">CustomerCD</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowCustomerNm(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerCD = CustomerCD.ToUpper();
            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);
            if (model != default(CustomerModels) && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.CustomerName,
                        model.Address1,
                        model.Address2,
                        model.Address3
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Category Name
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>Category Name</returns>
        [HttpPost]
        public string ShowCategoryNm(string CategoryCD)
        {
            if (string.IsNullOrEmpty(CategoryCD))
            {
                return string.Empty;
            }
            var model = this.mCategoryService.GetByCd(CategoryCD);
            if (model != default(CategoryModels) && !model.DeleteFlag)
            {
                return model.CategoryName;
            }
            return string.Empty;
        }

        #endregion

        #endregion Event

        #region Check

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateBranchCheck(StockInquiryBranchModels gmModel)
        {
            bool ret = true;

            //Check data changed
            if (!this.CheckDataChangedBranch(gmModel))
            {
                ret = false;
            }
            else if (!this.CheckExistSupplierBranch(gmModel))
            {
                return false;
            }
            //Check Exist Data Branch
            else if (!CheckExistDataBranch(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check data changed Branch
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChangedBranch(StockInquiryBranchModels gmModel)
        {
            //Check Exclusion
            TInventory_D model = this.tInventory_DService.GetByPK(gmModel.TagNo, CommonUtil.ParseInteger(gmModel.BranchTagNo));
            if (model == default(TInventory_D) || gmModel.UpdateDate != model.UpdateDate || (gmModel.IsEditCus && !this.tInventory_HService.IsEditCus(gmModel.TagNo)))
            {
                //Show error Message
                this.ShowMessageExclusion("/StockInquiry/Show", gmModel.TagNo, gmModel.SeqNum.ToString(), gmModel.BranchTagNo);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check Exist Branch Data
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns></returns>
        private bool CheckExistDataBranch(StockInquiryBranchModels gmModel)
        {
            bool ret = true;
            //Check MKind_D
            if (!string.IsNullOrEmpty(gmModel.StockStatus))
            {
                MKind_D mKind_D = this.mKind_DService.GetByPK(Constant.MKIND_KINDCD_STOCK_STATUS, gmModel.StockStatus);
                if (mKind_D == default(MKind_D))
                {
                    //Stock Status Not Exist
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0129));
                    this.ModelState.AddModelError(DROPDOWN_STATUS, message);
                    ret = false;
                }
            }
            return ret;
        }

        /// <summary>
        /// Update Group Check
        /// </summary>
        /// <param name="gmModel">screen StockInquiryGroupModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateGroupCheck(StockInquiryGroupModels gmModel)
        {
            bool ret = true;

            //Check data changed
            if (!this.CheckDataChangedGroup(gmModel))
            {
                ret = false;
            }
            else if (!this.CheckExistSupplierGroup(gmModel))
            {
                ret = false;
            }
            //Check Exist Data Group
            else if (!CheckExistDataGroup(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check Exist Supplier
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        private bool CheckExistSupplierGroup(StockInquiryGroupModels gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.sSuplierCD))
            {
                return true;
            }

            CustomerModels model = this.mCustomerService.GetByCd(gmModel.sSuplierCD);
            if (model == default(CustomerModels))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0288));
                this.ModelState.AddModelError(KEY_S_SUPPLIER, message);
                gmModel.sSuplierName = string.Empty;
                return false;
            }
            gmModel.sSuplierName = model.CustomerName;

            return true;
        }

        /// <summary>
        /// Check Exist Supplier
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        private bool CheckExistSupplierBranch(StockInquiryBranchModels gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.SuplierCD))
            {
                return true;
            }

            CustomerModels model = this.mCustomerService.GetByCd(gmModel.SuplierCD);
            if (model == default(CustomerModels))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0288));
                this.ModelState.AddModelError(KEY_SUPPLIER, message);
                gmModel.SuplierName = string.Empty;
                return false;
            }
            gmModel.SuplierName = model.CustomerName;

            return true;
        }

        /// <summary>
        /// Check data changed Group
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChangedGroup(StockInquiryGroupModels gmModel)
        {
            bool ret = true;
            //Check Exclusion
            string updateDate = tInventory_HService.GetMaxUpdateDateForStockInquiryGroup(gmModel.TagNo);
            gmModel.listGroup = tInventory_HService.GetDetailForStockInquiryGroup(gmModel.TagNo);
            if (gmModel.listGroup.Count == 0 || !gmModel.UpdateDate.Equals(updateDate) || (gmModel.IsEditCus && !this.tInventory_HService.IsEditCus(gmModel.TagNo)))
            {
                ret = false;
            }
            else if (gmModel.listGroup.Count != gmModel.arrBranchTagNo.Count)
            {
                ret = false;
            }

            if (!ret)
            {
                //Show error Message
                this.ShowMessageExclusion("/StockInquiry/Show", gmModel.TagNo, gmModel.SeqNum.ToString(), null);
            }
            return ret;
        }

        /// <summary>
        /// Check Exist Data Group
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <returns></returns>
        private bool CheckExistDataGroup(StockInquiryGroupModels gmModel)
        {
            bool ret = true;
            //Check MKind_D
            for (int i = 0; i < gmModel.arrStockStatus.Count; i++)
            {
                if (!string.IsNullOrEmpty(gmModel.arrStockStatus[i]))
                {
                    MKind_D mKind_D = this.mKind_DService.GetByPK(Constant.MKIND_KINDCD_STOCK_STATUS, gmModel.arrStockStatus[i]);
                    if (mKind_D == default(MKind_D))
                    {
                        //Stock Status Not Exist
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0129));
                        this.ModelState.AddModelError(DROPDOWN_STATUS_LIST + "[" + i + "]", message);
                        ret = false;
                    }
                }
            }
            return ret;
        }

        #endregion Check

        #region Setting

        /// <summary>
        /// Set Detail Header
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <param name="listGroup"> List GroupListDetail </param>
        private void SetDetailHeaderGroup(StockInquiryGroupModels gmModel, List<GroupListDetail> listGroup)
        {
            gmModel.TagNo = listGroup[0].TagNo;
            gmModel.TagNoDisp = listGroup[0].TagNo;
            gmModel.sSuplierCD = listGroup[0].SuplierCD;
            gmModel.sSuplierName = listGroup[0].SuplierName;
            gmModel.sProductCD = listGroup[0].ProductCD;
            gmModel.sProductName = listGroup[0].ProductName;
            gmModel.ArrivalDate = listGroup[0].ArrivalDate;
            gmModel.sUnitQuantity = listGroup[0].UnitQuantity;
            gmModel.sTotalCost = listGroup[0].TotalCost;
            gmModel.sLOT1 = listGroup[0].LOT1;
            gmModel.sLOT2 = CommonUtil.ParseDate(listGroup[0].LOT2, Constant.FMT_YMD, Constant.FMT_DATE);
            gmModel.sLOT3 = CommonUtil.ParseDate(listGroup[0].LOT3, Constant.FMT_YMD, Constant.FMT_DATE);
            gmModel.sMemo = listGroup[0].Memo;
            gmModel.listGroup = listGroup;
            gmModel.IsShowSuplier = this.isShowSup;
        }

        /// <summary>
        /// Set Detail for List Group
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        private void SetDetailListGroup(StockInquiryGroupModels gmModel)
        {
            gmModel.arrBranchTagNo = new List<string>();
            gmModel.arrLocationCD = new List<string>();
            gmModel.arrStoredDate = new List<string>();
            gmModel.arrStockStatus = new List<string>();
            gmModel.arrStockStatusDisp = new List<string>();
            gmModel.arrCanEditStatus = new List<bool>();

            foreach (GroupListDetail ret in gmModel.listGroup)
            {
                gmModel.arrStoredDate.Add(CommonUtil.ParseDate(ret.StoredDate, Constant.FMT_YMD, Constant.FMT_DATE));
                gmModel.arrBranchTagNo.Add(ret.BranchTagNoDisp);
                gmModel.arrLocationCD.Add(ret.LocationCD);
                gmModel.arrStockStatus.Add(ret.StockStatus);
                gmModel.arrStockStatusDisp.Add(ret.StockStatusDisp);
                gmModel.arrCanEditStatus.Add(ret.IsCanEdit);
            }
        }

        #endregion Setting

        #region Exclusion

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="groupBranchTagNo">is Group</param>
        /// <param name="SeqNum"></param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(bool groupBranchTagNo, int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/StockInquiry/Index");
            if (groupBranchTagNo)
            {
                StockInquiryGroupModels model = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum];
                if (model == default(StockInquiryGroupModels))
                {
                    model = new StockInquiryGroupModels();
                    model.SeqNum = SeqNum;
                }
                return View(SCREEN_DETAIL_GROUP, model);
            }
            else
            {
                StockInquiryBranchModels model = (StockInquiryBranchModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum];
                if (model == default(StockInquiryBranchModels))
                {
                    model = new StockInquiryBranchModels();
                    model.SeqNum = SeqNum;
                }
                return View(SCREEN_DETAIL_BRANCH, model);
            }

        }

        #endregion Exclusion

        #region Dropdownlist

        /// <summary>
        /// Get Display Stock Status
        /// </summary>
        /// <param name="list">Stock Status</param>
        private List<string> GetDisplayStockStatus(List<string> list)
        {
            List<string> displayStockstatus = new List<string>();
            for (int i = 0; i < list.Count; i++)
            {
                MKind_D mKind = mKind_DService.GetByPK(Constant.MKIND_KINDCD_STOCK_STATUS, list[i]);
                displayStockstatus.Add(mKind.Value);
            }
            return displayStockstatus;
        }

        ///<summary>
        ///Create Kind: StockStatus SelectList
        ///</summary>
        ///<param name="dropSrc">Dropdownlist</param>
        ///<param name="control">Control name</param>
        ///<param name="value">Selected value</param>
        private void CreateViewBagStockStatus(List<MKind_D> dropSrc, string control, string value)
        {
            SelectOption option = new SelectOption("Value", "DataCD", control, value);
            this.SetViewDataDropdownList<MKind_D>(option, dropSrc);
        }

        ///<summary>
        ///Set DropDownlist All For Search
        ///</summary>
        ///<param name="gmModel">StockInquiryList</param>
        private void SetDropDownlistAllForSearch(StockInquiryList gmModel)
        {
            //Get List Month
            List<SelectListItem> items = CommonUtil.GetListMonths();

            //Get List MKind_D: Stock Status
            List<MKind_D> dropStockStatus = this.mKind_DService.GetListForStockInquiry(Common.Constant.MKIND_KINDCD_STOCK_STATUS).ToList();
            dropStockStatus.Insert(0, new MKind_D() { Value = Constant.BLANK, DataCD = String.Empty });
            this.CreateViewBagStockStatus(dropStockStatus, DROPDOWN_STATUS_SEARCH, gmModel.ddl_Status);
        }

        /// <summary>
        /// Set DropDownlist For Branch
        /// </summary>
        /// <param name="value">Selected Value</param>
        private void SetDropDownlistForBranch(string value)
        {
            //Get List MKind_D: Stock Status
            List<MKind_D> dropStockStatus = this.mKind_DService.GetListByDataKindForDetailStockInquiry(Common.Constant.MKIND_KINDCD_STOCK_STATUS).ToList();
            this.CreateViewBagStockStatus(dropStockStatus, DROPDOWN_STATUS, value);
        }

        /// <summary>
        /// Set DropDownlist For Group
        /// </summary>
        /// <param name="list"> List Group</param>
        private void SetDropDownlistForGroup(List<string> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                //Get List MKind_D: Stock Status
                List<MKind_D> dropStockStatus = this.mKind_DService.GetListByDataKindForDetailStockInquiry(Common.Constant.MKIND_KINDCD_STOCK_STATUS).ToList();
                this.CreateViewBagStockStatus(dropStockStatus, DROPDOWN_STATUS + i, list[i]);
            }
        }

        #endregion Dropdownlist

        #region Registration

        /// <summary>
        /// Update Data Branch
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateBranchData(StockInquiryBranchModels gmModel)
        {
            try
            {
                TInventory_H modelH = this.tInventory_HService.GetByPK(gmModel.TagNo);
                TInventory_D modelD = this.tInventory_DService.GetByPK(gmModel.TagNo, CommonUtil.ParseInteger(gmModel.BranchTagNo));
                if (modelH == default(TInventory_H) || modelD.UpdateDate != gmModel.UpdateDate || (gmModel.IsEditCus && !this.tInventory_HService.IsEditCus(gmModel.TagNo)))
                {
                    return CommitFlag.DataChanged;
                }

                //Update Data
                modelH.Memo = gmModel.Memo;
                if (gmModel.IsEditCus)
                {
                    if (isShowSup)
                    {
                        modelH.CustomerCD = gmModel.SuplierCD;
                    }
                    modelH.Lot1 = gmModel.LOT1;
                    modelH.Lot2 = gmModel.LOT2Date.DateValue();
                    modelH.Lot3 = gmModel.LOT3Date.DateValue();
                }

                if (gmModel.canEditStatus)
                {
                    modelD.StockStatus = gmModel.StockStatus;
                }
                modelD.UpdateDate = this.GetCurrentDate();
                modelD.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                tInventory_HService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Update Data Group
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateGroupData(StockInquiryGroupModels gmModel)
        {
            try
            {
                TInventory_H modelH = this.tInventory_HService.GetByPK(gmModel.TagNo);
                IQueryable<TInventory_D> dbListD = this.tInventory_DService.GetListStockInquiryByTagNo(gmModel.TagNo);
                string updateDate = tInventory_HService.GetMaxUpdateDateForStockInquiryGroup(gmModel.TagNo);
                if (modelH == default(TInventory_H))
                {
                    return CommitFlag.DataChanged;
                }
                if (!updateDate.Equals(gmModel.UpdateDate))
                {
                    return CommitFlag.DataChanged;
                }
                if (gmModel.arrStockStatus.Count != dbListD.Count())
                {
                    return CommitFlag.DataChanged;
                }
                if (gmModel.IsEditCus && !this.tInventory_HService.IsEditCus(gmModel.TagNo))
                {
                    return CommitFlag.DataChanged;
                }

                //Update Data
                modelH.Memo = gmModel.sMemo;
                if (gmModel.IsEditCus)
                {
                    if (isShowSup)
                    {
                        modelH.CustomerCD = gmModel.sSuplierCD;
                    }
                    modelH.Lot1 = gmModel.sLOT1;
                    modelH.Lot2 = gmModel.LOT2Date.DateValue();
                    modelH.Lot3 = gmModel.LOT3Date.DateValue();
                }
                string curDate = this.GetCurrentDate();
                int i = 0;
                foreach (TInventory_D model in dbListD)
                {
                    if ((gmModel.arrStockStatus[i].Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) ||
                        gmModel.arrStockStatus[i].Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                        && gmModel.arrCanEditStatus[i])
                    {

                        model.StockStatus = gmModel.arrStockStatus[i];
                        model.UpdateDate = curDate;
                        model.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    }
                    i++;
                }
                tInventory_HService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        #endregion Registration

        #region Report

        #region Print From Detail ---- TRUC

        #region Check all
        /// <summary>
        /// Change Print All
        /// </summary>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public void CheckPrintItemALL(bool Checked, int SeqNum)
        {


            StockInquiryPrintInput p = (StockInquiryPrintInput)this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + SeqNum];

            List<string> ListItems = p.ListBranch;

            //Clear list location
            ListItems.Clear();

            //Add Location
            if (Checked)
            {
                //Get data for StockInquiry Branch
                StockInquiryGroupModels model = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum];

                List<GroupListDetail> results = model.listGroup;

                foreach (var row in results)
                {
                    ListItems.Add(row.BranchTagNo);
                }
            }

            //Store in sesstion
            p.ListBranch = ListItems;
        }

        /// <summary>
        /// Change Print Item
        /// </summary>
        /// <param name="Key">LocationCD</param>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public bool CheckPrintItemAt(string Key, bool Checked, int SeqNum)
        {
            StockInquiryPrintInput p = (StockInquiryPrintInput)this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + SeqNum];

            List<string> ListItems = p.ListBranch;

            //Get data for StockInquiry Branch
            StockInquiryGroupModels model = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum];

            List<GroupListDetail> results = model.listGroup;

            //Add Location
            if (Checked)
            {
                if (!ListItems.Contains(Key) && results.Where(m => m.BranchTagNo.Equals(Key)).SingleOrDefault() != null)
                {
                    ListItems.Add(Key);
                }
            }
            else
            {
                //Remove Location
                if (ListItems.Contains(Key))
                {
                    ListItems.Remove(Key);
                }
            }


            //Store in sesstion
            p.ListBranch = ListItems;
            var checkAll = (ListItems.Count == results.Count);
            return checkAll;
        }

        #endregion

        /// <summary>
        /// Print Branch
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="gmModel">StockInquiryBranchModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult PrintBranch(StockInquiryBranchModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }
            //Clear ModeState
            this.ClearModelState();

            //Get data for StockInquiry Branch
            StockInquiryBranchModels model = (StockInquiryBranchModels)this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum];

            StockInquiryPrintInput p = new StockInquiryPrintInput();
            p.TagNo = gmModel.TagNo;
            p.ListBranch.Add(gmModel.BranchTagNo);
            bool tagPrintFlg = this.tInventory_DService.GetTagPrintedByTagInfo(gmModel.TagNo, gmModel.BranchTagNo);
            p.TagPrintFlag = tagPrintFlg;

            this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + gmModel.SeqNum] = p;

            //Set size for form print
            PrintTypeFlag PrintFlag = this.SetPrintSize();

            this.ShowMessageForPrintDetail(gmModel.SeqNum, tagPrintFlg, PrintFlag, PRINT_WITH_BRANCH_TAGNO, PRINT_DETAIL_ACTION_URL);

            return View(SCREEN_DETAIL_BRANCH, model);
        }

        /// <summary>
        /// Print Group
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="gmModel">StockInquiryGroupModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult PrintGroup(StockInquiryGroupModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }
            //Clear ModeState
            this.ClearModelState();

            //Get data for StockInquiry Branch
            StockInquiryGroupModels model = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum];

            StockInquiryPrintInput p = (StockInquiryPrintInput)this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + gmModel.SeqNum];
            p.TagNo = gmModel.TagNo;
            bool tagPrintFlg;
            if (p.ListBranch.Count < 1)
            {
                //Not choose any row yet
                this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                return View(SCREEN_DETAIL_GROUP, model);
            }
            else if (p.ListBranch.Count == 1)
            {
                tagPrintFlg = this.tInventory_DService.GetTagPrintedByTagInfo(gmModel.TagNo, p.ListBranch[0]);
            }
            else
            {
                tagPrintFlg = false;
            }
            p.TagPrintFlag = tagPrintFlg;
            this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + gmModel.SeqNum] = p;

            //Set size for form print
            PrintTypeFlag PrintFlag = this.SetPrintSize();

            this.ShowMessageForPrintDetail(gmModel.SeqNum, tagPrintFlg, PrintFlag, PRINT_WITH_TAGNO, PRINT_DETAIL_ACTION_URL);

            return View(SCREEN_DETAIL_GROUP, model);
        }


        /// <summary>
        /// Print Detail Action
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="value1">Print From</param>
        /// <param name="value2">Print Size Flag</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult PrintDetailAction(string value1, string value2, string value3)
        {
            StockInquiryBranchModels modelBranch = null;
            StockInquiryGroupModels modelGroup = null;

            if (value1.Equals(PRINT_WITH_BRANCH_TAGNO))
            {
                //Get data for StockInquiry Branch
                modelBranch = (StockInquiryBranchModels)this.Session[Constant.SESSION_DETAIL_MODEL + value3];
            }
            else // (value1.Equals(PRINT_WITH_TAGNO))
            {
                //Get data for StockInquiry Group
                modelGroup = (StockInquiryGroupModels)this.Session[Constant.SESSION_DETAIL_MODEL + value3];
            }

            //Get data for StockInquiry input        
            StockInquiryPrintInput p = (StockInquiryPrintInput)this.Session[Constant.SESSION_STOCK_INQUIRY_PRINT + value3];

            List<StockInquiryPrintModels> Resource = this.tInventory_HService.GetListStockInquiryByListTagInfo(p.ListBranch, p.TagNo).ToList<StockInquiryPrintModels>();
            int Count = Resource.Count;
            if (Count > 0)
            {
                //Report dataset
                Report.DataObject.TagLabelDataSet DataSet = new Report.DataObject.TagLabelDataSet();

                //Report Source
                var tblEvent = DataSet._TagLabelDataSet.Clone();
                var tblOdd = DataSet._TagLabelDataSet.Clone();
                //Get data for report source
                for (int i = 0; i < Count; i++)
                {
                    var item = Resource[i];
                    if (i % 2 == 0)//Even
                    {
                        var newRow = tblEvent.NewRow();
                        this.InitDataForRow(ref newRow, item, (i + 1));
                        tblEvent.Rows.Add(newRow);
                    }
                    else//Odd
                    {
                        var newRow = tblOdd.NewRow();
                        this.InitDataForRow(ref newRow, item, (i + 1));
                        tblOdd.Rows.Add(newRow);
                    }
                }

                //Report
                LocalReport localReport = new LocalReport();

                //Print Size
                PrintTypeFlag PrintType = (PrintTypeFlag)Convert.ToInt16(value2);

                //Download file name
                var filename = string.Empty;

                //Choose report
                if (PrintType == PrintTypeFlag.Big)
                {
                    localReport.ReportPath = Server.MapPath(PATH_LARGE_REPORT);
                    filename = string.Format("StockInquiry_Large_{0}.pdf", DateTime.Now.ToString(Constant.FMT_DMY));
                }
                else if (PrintType == PrintTypeFlag.Small)
                {
                    localReport.ReportPath = Server.MapPath(PATH_SMALL_REPORT);
                    filename = string.Format("StockInquiry_Small{0}.pdf", DateTime.Now.ToString(Constant.FMT_DMY));
                }

                //Report source
                ReportDataSource Even = new ReportDataSource("Even", tblEvent);
                ReportDataSource Odd = new ReportDataSource("Odd", tblOdd);

                localReport.DataSources.Add(Even);
                localReport.DataSources.Add(Odd);

                //Set parameter
                this.InitParamsForReport(localReport);

                //Set Printed Flag      
                var UpdateResult = CommitFlag.Success;

                //if (value1.Equals(PRINT_WITH_BRANCH_TAGNO))
                //{
                //    UpdateResult = this.UpdatePrintData(modelBranch.TagNo, p.ListBranch);
                //}
                //else //if (value1.Equals(PRINT_WITH_TAGNO))
                //{

                //}

                UpdateResult = this.UpdatePrintData(p.TagNo, p.ListBranch);

                //Output file for download
                if (UpdateResult == CommitFlag.Success)
                {
                    var file = this.PDFOutPut(localReport, filename, Common.ReportType.Barcode, true);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
            }
            else
            {
                this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
            }

            if (value1.Equals(PRINT_WITH_BRANCH_TAGNO))
            {

                return this.Show(modelBranch.TagNo, modelBranch.SeqNum, modelBranch.BranchTagNo);

            }
            else //if (value1.Equals(PRINT_WITH_TAGNO))
            {
                return this.Show(modelGroup.TagNo, modelGroup.SeqNum, string.Empty);
            }
        }

        #region Private Methods
        /// <summary>
        ///  Show Message For Print base in PrintFlag
        ///  Author : ISV-TRUC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="FlagIsPrinted">TagPrintFlag</param>
        /// <param name="PrintSizeFlag">PrintFlag</param>
        /// <param name="ReportSize">PrintTypeFlag</param>
        /// <param name="TypePrintFrom">TypePrintFrom</param>
        private void ShowMessageForPrintDetail(int SeqNum, bool FlagIsPrinted, PrintTypeFlag PrintSizeFlag, string TypePrintFrom, string RedirectUrl)
        {
            switch (PrintSizeFlag)
            {
                case PrintTypeFlag.None:

                    string printAppend = "<div id='PrintOption'>";
                    printAppend += "<div>" +
                                            "<input type='radio' name='PrintType' id='rdoLarge' checked='checked'>" +
                                            "<lable for ='rdoLarge'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.BTN_B0018) + "</lable>" +
                                      "</div>";
                    printAppend += "<div>" +
                                            "<input type='radio' name='PrintType' id='rdoSmall'>" +
                                            "<lable for ='rdoSmall'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.BTN_B0019) + "</lable>" +
                                      "</div>";
                    printAppend += "</div>";

                    //check TagPrintFlag
                    if (FlagIsPrinted == true)
                    {
                        //Show confirm message
                        this.ShowMessageConfirmPrint(SeqNum, RedirectUrl, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0019),
                        value1: TypePrintFrom, value2: Convert.ToUInt16(PrintSizeFlag).ToString(), value3: SeqNum.ToString(), printAppend: printAppend);

                    }
                    else
                    {
                        //Show confirm message
                        this.ShowMessageConfirmPrint(SeqNum, RedirectUrl, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0018),
                                                     value1: TypePrintFrom, value2: Convert.ToUInt16(PrintSizeFlag).ToString(), value3: SeqNum.ToString(), printAppend: printAppend);

                    }
                    break;
                case PrintTypeFlag.Big:
                case PrintTypeFlag.Small:
                    //Check TagPrintFlag
                    if (FlagIsPrinted == true)
                    {
                        //Show confirm message
                        this.ShowMessageConfirm(SeqNum, RedirectUrl, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0021),
                                                value1: TypePrintFrom, value2: Convert.ToUInt16(PrintSizeFlag).ToString(), value3: SeqNum.ToString());
                    }
                    else
                    {
                        //Show confirm message
                        this.ShowMessageConfirm(SeqNum, RedirectUrl, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
                                                value1: TypePrintFrom, value2: Convert.ToUInt16(PrintSizeFlag).ToString(), value3: SeqNum.ToString());
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Set size for form print
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns>PrintTypeFlag</returns>
        private PrintTypeFlag SetPrintSize()
        {
            PrintTypeFlag PrintFlag = PrintTypeFlag.None;
            //Get Kind for set size report            
            KindForPrint ktype = this.tInventory_HService.GetKindForSetSizePrint(Constant.TAG_PRINT_SET_SIZE_CD, Constant.TAG_PRINT_LANGUAGE_ENG)
                                     .Where(m => m.Value.Equals("True")).SingleOrDefault();
            //Set size for print form
            if (ktype.DataCD.Equals(Constant.TAG_PRINT_LARGE))
            {
                PrintFlag = PrintTypeFlag.Big;
            }
            else if (ktype.DataCD.Equals(Constant.TAG_PRINT_SMALL))
            {
                PrintFlag = PrintTypeFlag.Small;
            }
            return PrintFlag;
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">InboundDeliveryModels</param>
        /// <param name="BoxNo">BoxNo</param>
        private void InitDataForRow(ref System.Data.DataRow Row, StockInquiryPrintModels Data, int BoxNo)
        {
            Row["ArrivalDate"] = Data.StoredDate;

            string barCode = Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), BRANCH_TAG_NO_SHOW_PRINT);
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row["Barcode"] = Stream.ToArray();
            Row["TagNo"] = Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), BRANCH_TAG_NO_SHOW_PRINT);
            Row["ProductCD"] = Data.ProductCD;
            Row["ProductName"] = Data.ProductName;
            Row["QuantityPerUnit"] = Data.QuantityPerUnit;
            Row["BoxNo"] = BoxNo;
            Row["BoxNumber"] = FixCode(Data.BranchTagNo.ToString(), 4) + "/" + FixCode(Data.UnitQuantity.ToString(), 4);
            Row["LOT1"] = Data.LOT1;
            Row["LOT2"] = string.IsNullOrEmpty(Data.LOT2) ? string.Empty : CommonUtil.ParseDate(Data.LOT2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LOT3"] = string.IsNullOrEmpty(Data.LOT3) ? string.Empty : CommonUtil.ParseDate(Data.LOT3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LocationCD"] = Data.LocationCD;
        }

        /// <summary>
        /// Init Params For Report
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        private void InitParamsForReport(LocalReport localReport)
        {
            // set para header report
            localReport.SetLabelFromCache(
                                         new KeyValuePair<string, string>("arrivalDateLabel", Constant.LBL_L0105),
                                         new KeyValuePair<string, string>("tagNoLabel", Constant.LBL_L0106),
                                         new KeyValuePair<string, string>("productCDLabel", Constant.LBL_L0018),
                                         new KeyValuePair<string, string>("productNameLabel", Constant.LBL_L0019),
                                         new KeyValuePair<string, string>("quantityLabel", Constant.LBL_L0022),
                                         new KeyValuePair<string, string>("lot1Label", Constant.LBL_L0084),
                                         new KeyValuePair<string, string>("lot2Label", Constant.LBL_L0085),
                                         new KeyValuePair<string, string>("lot3Label", Constant.LBL_L0086),
                                         new KeyValuePair<string, string>("boxNumberLabel", Constant.LBL_L0127),
                                         new KeyValuePair<string, string>("locationLabel", Constant.LBL_L0110)
                                        );
        }

        /// <summary>
        /// Update Print Data
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagNo">TagNo</param>
        /// <param name="BranchTagNo">BranchTagNo</param>
        /// <returns></returns>
        private CommitFlag UpdatePrintData(string TagNo, List<string> BranchTagNo)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();
                List<TInventory_D> lst = this.tInventory_DService.GetListByTagInfoForPrintStock(TagNo, BranchTagNo).ToList();

                //update TagPrintFlag for Detail
                foreach (var item in lst)
                {
                    item.UpdateDate = updateDate;
                    item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    item.TagPrintFlag = true;
                }
                tInventory_DService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = "";

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }

            return ret;
        }

        #endregion

        #endregion Print Detail

        #region method

        /// <summary>
        /// Show Message Print
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        private void ShowMessagePrint(int SeqNum, string Url)
        {
            string printAppend = "<div id='PrintOption'>";
            printAppend += "<div>" +
                                    "<input type='radio' name='PrintType' id='rdoLocation' checked='checked'>" +
                                    "<lable for ='rdoLocation'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110) + "</lable>" +
                              "</div>";
            printAppend += "<div>" +
                                    "<input type='radio' name='PrintType' id='rdoProduct'>" +
                                    "<lable for ='rdoProduct'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0269) + "</lable>" +
                              "</div>";
            printAppend += "</div>";

            this.ShowMessageConfirmPrint(SeqNum, Url, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0070),
            value3: SeqNum.ToString(), printAppend: printAppend);
        }

        #endregion

        #region Print

        /// <summary>
        /// Print
        /// Author : ISV-THUY
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Print(StockInquiryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Clear ModeState
            this.ClearModelState();

            StockInquiryList oldModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum];
            this.RestoreGrid(gmModel, oldModel);

            List<StockListModels> ReportSource = new List<StockListModels>();
            //Search data

            DAC.Report dac = new DAC.Report();

            //Search data
            if (gmModel.chk_GroupBranchTagNo)
            {
                ReportSource = dac.StockInqReportGroup(gmModel);
            }
            else
            {
                ReportSource = dac.StockInqReportNotGroup(gmModel);
            }

            if (ReportSource.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }

            TempData[SAVE_LIST_PRINT] = ReportSource;

            this.ShowMessagePrint(gmModel.SeqNum, PRINT_ACTION_URL);
            return View("Index", gmModel);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-THUY
        /// </summary>
        /// <param name="value1">Type Print From</param>
        /// <param name="value2">Print Size</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value2, string value3)
        {
            //Clear ModeState
            this.ClearModelState();

            //Print Size
            PrintConditionTypeFlag PrintType = (PrintConditionTypeFlag)Convert.ToInt16(value2);

            StockInquiryList gmModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + value3];
            this.SetDropDownlistAllForSearch(gmModel);

            //Search data
            IQueryable<StockInquiryResults> results = this.tInventory_HService.GetListStockInquiryByConditions(gmModel, gmModel.chk_GroupBranchTagNo);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

            this.PagingBase<StockInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

            List<StockListModels> ReportSource = new List<StockListModels>();
            ReportSource = (List<StockListModels>)TempData[SAVE_LIST_PRINT];

            string path = string.Empty;
            string tilte = string.Empty;
            string fileName = string.Empty;

            switch (PrintType)
            {
                case PrintConditionTypeFlag.Location:

                    ReportSource = ReportSource.OrderBy(m => m.locationCd).ToList();
                    if (ReportSource.Count() == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }
                    tilte = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0250);
                    fileName = string.Format("StockList_ByLocation_{0}.pdf", DateTime.Now.ToString(Constant.FMT_YMDHMM));

                    if (gmModel.chk_GroupBranchTagNo)
                    {
                        path = PATH_LOCATION;
                    }
                    else
                    {
                        path = PATH_LOCATION_BRANCH;
                    }
                    break;

                case PrintConditionTypeFlag.Product:

                    if (ReportSource.Count() == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                        return View("Index", gmModel);
                    }
                    tilte = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0253);
                    fileName = string.Format("StockList_P_{0}.pdf", DateTime.Now.ToString(Constant.FMT_YMDHMM));

                    if (gmModel.chk_GroupBranchTagNo)
                    {
                        path = PATH_PRODUCT;
                    }
                    else
                    {
                        path = PATH_PRODUCT_BRANCH;
                    }
                    break;

            }

            LocalReport localReport = new LocalReport();
            this.setDataSource(localReport, ReportSource, path);
            //seting the partameters for the report            
            this.SetParas(localReport, gmModel, tilte);

            //out put pdf
            FileContentResult file = this.PDFOutPut(localReport, fileName, Common.ReportType.System, false);
            TempData[TMP_DOWNLOAD_FILE] = file;

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value3);
            return RedirectToAction("Index");
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="oldModel">StockInquiryList</param>
        private void RestoreGrid(StockInquiryList gmModel, StockInquiryList oldModel)
        {
            this.SetDropDownlistAllForSearch(gmModel);
            IQueryable<StockInquiryResults> results = this.tInventory_HService.GetListStockInquiryByConditions(oldModel, oldModel.chk_GroupBranchTagNo);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];
            this.PagingBase<StockInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);
        }

        /// <summary>
        /// Set Parameters
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="tilte">tilte</param>
        private void SetParas(LocalReport localReport, StockInquiryList gmModel, string tilte)
        {
            // set para header report
            localReport.SetLabelValue("ReportTitle", tilte);
            localReport.SetLabelValue("ReportDate", DateTime.Now.ToString(Constant.FMT_DATE));
            string LocationNameFrom = gmModel.txtLocationCDFrom ?? string.Empty.PadLeft(20, ' ');
            string LocationNameTo = gmModel.txtLocationCDTo ?? string.Empty.PadRight(20, ' ');
            localReport.SetLabelValue("lblLocationCDFromTo", string.Format("{0} ～ {1}", LocationNameFrom, LocationNameTo));
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            localReport.SetLabelValue("lblCompany", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            localReport.SetLabelFromCache(
                                          new KeyValuePair<string, string>("lblPage", Constant.LBL_L0172),
                                          new KeyValuePair<string, string>("lblDate", Constant.LBL_L0251),
                                          new KeyValuePair<string, string>("lblProductCD", Constant.LBL_L0018),
                                          new KeyValuePair<string, string>("lblProductName", Constant.LBL_L0019),
                                          new KeyValuePair<string, string>("lblLocationCD", Constant.LBL_L0051),
                                          new KeyValuePair<string, string>("lblLocationName", Constant.LBL_L0052),
                                          new KeyValuePair<string, string>("lblLocationRange", Constant.LBL_L0252),
                                          new KeyValuePair<string, string>("lblTagNo", Constant.LBL_L0106),
                                          new KeyValuePair<string, string>("lblLot1", Constant.LBL_L0084),
                                          new KeyValuePair<string, string>("lblLot2", Constant.LBL_L0085),
                                          new KeyValuePair<string, string>("lblLot3", Constant.LBL_L0086),
                                          new KeyValuePair<string, string>("lblUnitQuantity", Constant.LBL_L0259),
                                          new KeyValuePair<string, string>("lblQuantityPerUnit", Constant.LBL_L0260),
                                          new KeyValuePair<string, string>("lblStoredCost", Constant.LBL_L0021),
                                          new KeyValuePair<string, string>("lblTotalCost", Constant.LBL_L0083),
                                          new KeyValuePair<string, string>("lblTotal", Constant.LBL_L0083),
                                          new KeyValuePair<string, string>("lblProductTotal", Constant.LBL_L0248),
                                          new KeyValuePair<string, string>("lblLocationTotal", Constant.LBL_L0274),
                                          new KeyValuePair<string, string>("lblGrandTotal", Constant.LBL_L0249),
                                          new KeyValuePair<string, string>("lblNotReceipt", Constant.LBL_L0287)
                                         );
        }

        /// <summary>
        /// Set Data Source
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        /// <param name="source"> List Of StockListModels</param>
        /// <param name="path">path</param>
        private void setDataSource(LocalReport localReport, List<StockListModels> source, string path)
        {
            //creating a new report and setting its path
            localReport.ReportPath = System.Web.HttpContext.Current.Server.MapPath(path);

            //adding the reort datasets with there names
            ReportDataSource reportDataSource = new ReportDataSource(NAME_DATASET, source);
            localReport.DataSources.Add(reportDataSource);
        }

        #endregion

        #region Excel ***** Create date: 05/08/2013 ***** Author: ISV-Thuy

        /// <summary>
        /// Print
        /// Author : ISV-THUY
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Excel(StockInquiryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_STOCK_INQUIRY))
            {
                return this.RedirectNotAuthority();
            }

            //Clear ModeState
            this.ClearModelState();

            StockInquiryList oldModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum];
            this.RestoreGrid(gmModel, oldModel);

            List<StockListModels> ReportSource = new List<StockListModels>();
            //Search data

            DAC.Report dac = new DAC.Report();

            if (gmModel.chk_GroupBranchTagNo)
            {
                ReportSource = dac.StockInqReportGroup(oldModel);
            }
            else
            {
                ReportSource = dac.StockInqReportNotGroup(oldModel);
            }

            if (ReportSource.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }


            TempData[SAVE_LIST_PRINT] = ReportSource;

            this.ShowMessagePrint(gmModel.SeqNum, EXCEL_ACTION_URL);
            return View("Index", gmModel);
        }

        HSSFWorkbook workbook;
        Dictionary<String, ICellStyle> styles;

        [HttpPost]
        public ActionResult ExcelAction(string value2, string value3)
        {
            //Clear ModeState
            this.ClearModelState();
            PrintConditionTypeFlag PrintType = (PrintConditionTypeFlag)Convert.ToInt16(value2);
            StockInquiryList gmModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + value3];
            this.SetDropDownlistAllForSearch(gmModel);
            this.RestoreGrid(gmModel, gmModel);

            DAC.Report dac = new DAC.Report();
            List<double> list = dac.StockInqCountRow(gmModel, PrintType);
            if (list.Exists(n => n > Constant.EXCEL_MAX_ROW))
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0016));
                return View("Index", gmModel);
            }
            if (list.Count > Constant.EXCEL_MAX_SHEET)
            {
                //Store condition
                this.ShowMessageConfirm(gmModel.SeqNum, "ExcelAction2", message: this.FormatMessage(Constant.MES_M0040), value2: value2, value3: value3);
            }
            else
            {
                return ExcelAction2(value2, value3);
            }

            var dataSource = TempData[SAVE_LIST_PRINT];
            TempData[SAVE_LIST_PRINT] = dataSource;

            return View("Index", gmModel);

        }

        [HttpPost]
        public ActionResult ExcelAction2(string value2, string value3)
        {
            //Clear ModeState
            this.ClearModelState();

            //Print Size
            PrintConditionTypeFlag PrintType = (PrintConditionTypeFlag)Convert.ToInt16(value2);
            StockInquiryList gmModel = (StockInquiryList)this.Session[Constant.SESSION_LIST_CONDITION + value3];

            this.SetDropDownlistAllForSearch(gmModel);

            //Search data
            IQueryable<StockInquiryResults> results = this.tInventory_HService.GetListStockInquiryByConditions(gmModel, gmModel.chk_GroupBranchTagNo);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

            this.PagingBase<StockInquiryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);            

            TempData[TMP_DOWNLOAD_FILE] = this.ExportFileExcel(gmModel, PrintType);
            if (TempData[TMP_DOWNLOAD_FILE] == null)
            {
                return View("Index", gmModel);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = int.Parse(value3);
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Export excel 
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        /// <returns></returns>
        private FileContentResult ExportFileExcel(StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            string type = string.Empty;
            switch (PrintType)
            {
                case PrintConditionTypeFlag.Location:
                    type = "StockList_L_{0}.xls";
                    break;
                case PrintConditionTypeFlag.Product:
                    type = "StockList_P_{0}.xls";
                    break;
            }

            string filename = string.Format(type, DateTime.Now.ToString(Constant.FMT_YMDHMM));

            InitializeWorkbook();
            bool ret = GenerateData(gmModel, PrintType);
            if (!ret)
            {
                return null;
            }

            return File(WriteToStream().GetBuffer(), "application/vnd.ms-excel", filename);
        }

        /// <summary>
        /// Initialize Workbook
        /// </summary>
        void InitializeWorkbook()
        {
            workbook = new HSSFWorkbook();
            styles = createStyles(workbook);

            ////create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "ISV Viet Nam CO., LTD.";
            workbook.DocumentSummaryInformation = dsi;

            ////create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "Inventory Managerment";
            workbook.SummaryInformation = si;
        }

        /// <summary>
        /// Generate Data
        /// </summary>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        /// <returns></returns>
        private bool GenerateData(StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            List<StockListModels> ReportSource = new List<StockListModels>();
            ReportSource = (List<StockListModels>)TempData[SAVE_LIST_PRINT];

            switch (PrintType)
            {
                case PrintConditionTypeFlag.Location:

                    ReportSource = ReportSource.OrderBy(m => m.locationCd)
                                               .ThenBy(m => m.ProductCd)
                                               .ThenBy(m => m.TagNo).ToList();
                    if (ReportSource.Count() == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                        return false;
                    }
                    if (gmModel.chk_GroupBranchTagNo)
                    {
                        this.ExcelLocation(ReportSource, gmModel, PrintType);
                    }
                    else
                    {
                        this.ExcelLocationBranchTagNo(ReportSource, gmModel, PrintType);

                    }

                    break;

                case PrintConditionTypeFlag.Product:

                    ReportSource = ReportSource.OrderBy(m => m.ProductCd)
                                               .ThenBy(m => m.locationCd)
                                               .ThenBy(m => m.TagNo).ToList();
                    if (ReportSource.Count() == 0)
                    {
                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                        return false;
                    }

                    if (gmModel.chk_GroupBranchTagNo)
                    {
                        this.ExcelProduct(ReportSource, gmModel, PrintType);
                    }
                    else
                    {
                        this.ExcelProductBranchTagNo(ReportSource, gmModel, PrintType);
                    }

                    break;
            }
            return true;
        }

        /// <summary>
        /// Excel for Product
        /// </summary>
        /// <param name="ReportSource">list of StockListModels</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        private void ExcelProduct(List<StockListModels> ReportSource, StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            var srcGroupPro = ReportSource.Select(n => new { n.ProductCd, n.ProductName }).Distinct().ToList();

            decimal totalStoreCostLocation = new decimal();
            decimal totalStoredCostProduct = new decimal();

            decimal totalTotalCostLocation = new decimal();
            decimal totalTotalCostProduct = new decimal();

            decimal totalQuantityPerUnitLocation = new decimal();

            int totalQuantityUnitLocation = 0;
            int totalTotalQuantityUnitProduct = 0;

            for (int i = 0; i < srcGroupPro.Count; i++)
            {
                string sheetName = srcGroupPro[i].ProductCd;
                if (sheetName.Length > 30)
                {
                    sheetName = sheetName.Substring(0, 30);
                }
                ISheet sheet = workbook.CreateSheet(sheetName);
                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0253), gmModel.chk_GroupBranchTagNo);

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel, PrintType);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupPro[i].ProductCd, srcGroupPro[i].ProductName, PrintType);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4_Group(sheet, row_4, gmModel);

                var srcGroupLoc = ReportSource.Select(n => new { n.locationCd, n.locationName, n.ProductCd }).Distinct().ToList().Where(n => n.ProductCd.Equals(srcGroupPro[i].ProductCd)).ToList();

                int startRow = 5;
                totalStoredCostProduct = 0;
                totalTotalCostProduct = 0;
                totalTotalQuantityUnitProduct = 0;
                for (int t = 0; t < srcGroupLoc.Count; t++)
                {
                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);
                    string CD = srcGroupLoc[t].locationCd.Trim();
                    if (string.IsNullOrEmpty(CD))
                    {
                        CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287);
                    }
                    CreateRow_5(sheet, row, CD, srcGroupLoc[t].locationName);

                    var srcDetail = ReportSource.Where(n => n.locationCd.Equals(srcGroupLoc[t].locationCd) && n.ProductCd.Equals(srcGroupPro[i].ProductCd)).ToList();

                    totalStoreCostLocation = 0;
                    totalQuantityPerUnitLocation = 0;
                    totalQuantityUnitLocation = 0;
                    totalTotalCostLocation = 0;
                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        totalTotalCostLocation = totalTotalCostLocation + srcDetail[j].TotalCost;
                        totalStoreCostLocation = totalStoreCostLocation + srcDetail[j].StoredCost;
                        totalQuantityPerUnitLocation = totalQuantityPerUnitLocation + srcDetail[j].QuantityPerUnit;
                        totalQuantityUnitLocation = totalQuantityUnitLocation + srcDetail[j].UnitQuantity;

                        for (int iCol = 0; iCol <= 7; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagNo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 6:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_INT];
                                    cell.SetCellValue((double)srcDetail[j].UnitQuantity);
                                    break;

                                case 4:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].QuantityPerUnit);
                                    break;

                                case 5:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].StoredCost);
                                    break;

                                case 7:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].TotalCost);
                                    break;
                            }
                        }
                    }
                    totalStoredCostProduct = totalStoredCostProduct + totalStoreCostLocation;
                    totalTotalCostProduct = totalTotalCostProduct + totalTotalCostLocation;
                    totalTotalQuantityUnitProduct = totalTotalQuantityUnitProduct + totalQuantityUnitLocation;

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    for (int index = 0; index <= 7; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 4:
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0274));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                                break;

                            case 6:
                                cell.SetCellValue((double)totalQuantityUnitLocation);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                                break;

                            case 7:
                                cell.SetCellValue((double)totalTotalCostLocation);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                }

                startRow++;
                IRow rowTotalLoc = sheet.CreateRow(startRow);
                rowTotalLoc.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 7; index++)
                {
                    ICell cell = rowTotalLoc.CreateCell(index);
                    switch (index)
                    {
                        case 4:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0248));
                            break;

                        case 6:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                            cell.SetCellValue((double)totalTotalQuantityUnitProduct);
                            break;

                        case 7:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                            cell.SetCellValue((double)totalTotalCostProduct);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Excel for Product
        /// </summary>
        /// <param name="ReportSource">list of StockListModels</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        private void ExcelProductBranchTagNo(List<StockListModels> ReportSource, StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            var srcGroupPro = ReportSource.Select(n => new { n.ProductCd, n.ProductName }).Distinct().ToList();

            decimal totalStoreCostLocation = new decimal();
            decimal totalStoredCostProduct = new decimal();

            decimal totalTotalCostLocation = new decimal();
            decimal totalTotalCostProduct = new decimal();

            decimal totalQuantityPerUnitLocation = new decimal();

            int totalQuantityUnitLocation = 0;
            for (int i = 0; i < srcGroupPro.Count; i++)
            {
                string sheetName = srcGroupPro[i].ProductCd;
                if (sheetName.Length > 30)
                {
                    sheetName = sheetName.Substring(0, 30);
                }
                ISheet sheet = workbook.CreateSheet(sheetName);
                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0253), gmModel.chk_GroupBranchTagNo);

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel, PrintType);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupPro[i].ProductCd, srcGroupPro[i].ProductName, PrintType);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4_NotGroup(sheet, row_4, gmModel);

                var srcGroupLoc = ReportSource.Select(n => new { n.locationCd, n.locationName, n.ProductCd }).Distinct().ToList().Where(n => n.ProductCd.Equals(srcGroupPro[i].ProductCd)).ToList();

                int startRow = 5;
                totalStoredCostProduct = 0;
                totalTotalCostProduct = 0;
                for (int t = 0; t < srcGroupLoc.Count; t++)
                {
                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);
                    string CD = srcGroupLoc[t].locationCd.Trim();
                    if (string.IsNullOrEmpty(CD))
                    {
                        CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287);
                    }
                    CreateRow_5(sheet, row, CD, srcGroupLoc[t].locationName);

                    var srcDetail = ReportSource.Where(n => n.locationCd.Equals(srcGroupLoc[t].locationCd) && n.ProductCd.Equals(srcGroupPro[i].ProductCd)).ToList();

                    totalStoreCostLocation = 0;
                    totalQuantityPerUnitLocation = 0;
                    totalQuantityUnitLocation = 0;
                    totalTotalCostLocation = 0;
                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        totalTotalCostLocation = totalTotalCostLocation + srcDetail[j].TotalCost;
                        totalStoreCostLocation = totalStoreCostLocation + srcDetail[j].StoredCost;
                        totalQuantityPerUnitLocation = totalQuantityPerUnitLocation + srcDetail[j].QuantityPerUnit;
                        totalQuantityUnitLocation = totalQuantityUnitLocation + srcDetail[j].UnitQuantity;

                        for (int iCol = 0; iCol <= 5; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagNo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 4:

                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].QuantityPerUnit);
                                    break;

                                case 5:

                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].StoredCost);
                                    break;
                            }
                        }
                    }
                    totalStoredCostProduct = totalStoredCostProduct + totalStoreCostLocation;
                    totalTotalCostProduct = totalTotalCostProduct + totalTotalCostLocation;

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    for (int index = 0; index <= 5; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 3:
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0274));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];

                                break;

                            case 4:

                                cell.SetCellValue((double)totalQuantityPerUnitLocation);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            case 5:
                                cell.SetCellValue((double)totalStoreCostLocation);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                }

                startRow++;
                IRow rowTotalLoc = sheet.CreateRow(startRow);
                rowTotalLoc.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 5; index++)
                {
                    ICell cell = rowTotalLoc.CreateCell(index);
                    switch (index)
                    {
                        case 3:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0248));
                            break;

                        case 5:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                            cell.SetCellValue((double)totalStoredCostProduct);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Excel for Location
        /// </summary>
        /// <param name="ReportSource">list of StockListModels</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        private void ExcelLocationBranchTagNo(List<StockListModels> ReportSource, StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            //group Location
            var srcGroupLocation = ReportSource.Select(n => new { n.locationCd, n.locationName }).Distinct().ToList();
            decimal totalStoreCostPro = new decimal();
            decimal totalStoredCostLoc = new decimal();
            decimal totalQuantityPerUnit = new decimal();
            int totalQuantityUnit = 0;
            int totalTotalQuantityUnitLoc = 0;
            decimal totalTotalCostPro = new decimal();
            decimal totalTotalCostLoc = new decimal();

            for (int i = 0; i < srcGroupLocation.Count; i++)
            {
                string sheetName = srcGroupLocation[i].locationCd;
                if (string.IsNullOrEmpty(sheetName.Trim()))
                {
                    //create name for sheet 
                    sheetName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287);
                }
                else
                {
                    if (sheetName.Length > 30)
                    {
                        sheetName = sheetName.Substring(0, 30);
                    }
                }

                ISheet sheet = workbook.CreateSheet(sheetName);

                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0250), gmModel.chk_GroupBranchTagNo);

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel, PrintType);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupLocation[i].locationCd, srcGroupLocation[i].locationName, PrintType);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4_NotGroup(sheet, row_4, gmModel);

                //group Product
                var srcGroupProduct = ReportSource.Select(n => new { n.ProductCd, n.ProductName, n.locationCd }).Distinct().ToList().Where(n => n.locationCd.Equals(srcGroupLocation[i].locationCd)).ToList();

                int startRow = 5;
                totalStoredCostLoc = 0;
                totalTotalCostPro = 0;
                totalTotalQuantityUnitLoc = 0;
                for (int t = 0; t < srcGroupProduct.Count; t++)
                {

                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);
                    CreateRow_5(sheet, row, srcGroupProduct[t].ProductCd, srcGroupProduct[t].ProductName);

                    //data detail
                    var srcDetail = ReportSource.Where(n => n.locationCd.Equals(srcGroupLocation[i].locationCd) && n.ProductCd.Equals(srcGroupProduct[t].ProductCd)).ToList();

                    totalStoreCostPro = 0;
                    totalQuantityPerUnit = 0;
                    totalQuantityUnit = 0;
                    totalTotalCostPro = 0;
                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        totalTotalCostPro = totalTotalCostPro + srcDetail[j].TotalCost;
                        totalStoreCostPro = totalStoreCostPro + srcDetail[j].StoredCost;
                        totalQuantityPerUnit = totalQuantityPerUnit + srcDetail[j].QuantityPerUnit;
                        totalQuantityUnit = totalQuantityUnit + srcDetail[j].UnitQuantity;

                        //fill data into cell of row
                        for (int iCol = 0; iCol <= 5; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagNo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 4:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].QuantityPerUnit);
                                    break;

                                case 5:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].StoredCost);
                                    break;

                            }
                        }
                    }
                    totalStoredCostLoc = totalStoredCostLoc + totalStoreCostPro;
                    totalTotalCostLoc = totalTotalCostLoc + totalTotalCostPro;
                    totalTotalQuantityUnitLoc = totalTotalQuantityUnitLoc + totalQuantityUnit;

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    //fill data into cell of row
                    for (int index = 0; index <= 5; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 3:
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0248));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];

                                break;

                            case 4:
                                cell.SetCellValue((double)totalQuantityPerUnit);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            case 5:
                                cell.SetCellValue((double)totalStoreCostPro);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                }

                startRow++;
                IRow rowTotalLoc = sheet.CreateRow(startRow);
                rowTotalLoc.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 5; index++)
                {
                    ICell cell = rowTotalLoc.CreateCell(index);
                    switch (index)
                    {
                        case 3:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0274));
                            break;

                        case 5:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                            cell.SetCellValue((double)totalStoredCostLoc);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Excel for Location
        /// </summary>
        /// <param name="ReportSource">list of StockListModels</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="PrintType"></param>
        private void ExcelLocation(List<StockListModels> ReportSource, StockInquiryList gmModel, PrintConditionTypeFlag PrintType)
        {
            //group Location
            var srcGroupLocation = ReportSource.Select(n => new { n.locationCd, n.locationName }).Distinct().ToList();
            decimal totalStoreCostPro = new decimal();
            decimal totalStoredCostLoc = new decimal();
            decimal totalQuantityPerUnit = new decimal();
            int totalQuantityUnit = 0;
            int totalTotalQuantityUnitLoc = 0;
            decimal totalTotalCostPro = new decimal();
            decimal totalTotalCostLoc = new decimal();

            for (int i = 0; i < srcGroupLocation.Count; i++)
            {
                string sheetName = srcGroupLocation[i].locationCd;
                if (string.IsNullOrEmpty(sheetName.Trim()))
                {
                    //create name for sheet 
                    sheetName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287);
                }
                else
                {
                    if (sheetName.Length > 30)
                    {
                        sheetName = sheetName.Substring(0, 30);
                    }
                }

                ISheet sheet = workbook.CreateSheet(sheetName);

                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0250), gmModel.chk_GroupBranchTagNo);

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel, PrintType);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupLocation[i].locationCd, srcGroupLocation[i].locationName, PrintType);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4_Group(sheet, row_4, gmModel);

                //group Product
                var srcGroupProduct = ReportSource.Select(n => new { n.ProductCd, n.ProductName, n.locationCd }).Distinct().ToList().Where(n => n.locationCd.Equals(srcGroupLocation[i].locationCd)).ToList();

                int startRow = 5;
                totalStoredCostLoc = 0;
                totalTotalCostPro = 0;
                totalTotalQuantityUnitLoc = 0;
                for (int t = 0; t < srcGroupProduct.Count; t++)
                {

                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);
                    CreateRow_5(sheet, row, srcGroupProduct[t].ProductCd, srcGroupProduct[t].ProductName);

                    //data detail
                    var srcDetail = ReportSource.Where(n => n.locationCd.Equals(srcGroupLocation[i].locationCd) && n.ProductCd.Equals(srcGroupProduct[t].ProductCd)).ToList();

                    totalStoreCostPro = 0;
                    totalQuantityPerUnit = 0;
                    totalQuantityUnit = 0;
                    totalTotalCostPro = 0;
                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        totalTotalCostPro = totalTotalCostPro + srcDetail[j].TotalCost;
                        totalStoreCostPro = totalStoreCostPro + srcDetail[j].StoredCost;
                        totalQuantityPerUnit = totalQuantityPerUnit + srcDetail[j].QuantityPerUnit;
                        totalQuantityUnit = totalQuantityUnit + srcDetail[j].UnitQuantity;

                        //fill data into cell of row
                        for (int iCol = 0; iCol <= 7; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagNo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 6:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_INT];
                                    cell.SetCellValue((double)srcDetail[j].UnitQuantity);
                                    break;

                                case 4:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].QuantityPerUnit);
                                    break;

                                case 5:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].StoredCost);
                                    break;

                                case 7:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_DECIMAL];
                                    cell.SetCellValue((double)srcDetail[j].TotalCost);
                                    break;
                            }
                        }
                    }
                    totalStoredCostLoc = totalStoredCostLoc + totalStoreCostPro;
                    totalTotalCostLoc = totalTotalCostLoc + totalTotalCostPro;
                    totalTotalQuantityUnitLoc = totalTotalQuantityUnitLoc + totalQuantityUnit;

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    //fill data into cell of row
                    for (int index = 0; index <= 7; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 4:
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0248));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                                break;

                            case 6:
                                cell.SetCellValue((double)totalQuantityUnit);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                                break;

                            case 7:
                                cell.SetCellValue((double)totalTotalCostPro);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                }

                startRow++;
                IRow rowTotalLoc = sheet.CreateRow(startRow);
                rowTotalLoc.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 7; index++)
                {
                    ICell cell = rowTotalLoc.CreateCell(index);
                    switch (index)
                    {
                        case 4:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0274));
                            break;

                        case 6:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                            cell.SetCellValue((double)totalTotalQuantityUnitLoc);
                            break;

                        case 7:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP];
                            cell.SetCellValue((double)totalTotalCostLoc);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// setup sheet
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void SheetSetup(ISheet sheet)
        {
            sheet.DisplayGridlines = false;

            sheet.FitToPage = (true);
            sheet.HorizontallyCenter = (true);
            sheet.IsPrintGridlines = false;

            sheet.SetMargin(MarginType.RightMargin, (double)0.25);
            sheet.SetMargin(MarginType.TopMargin, (double)0.6);
            sheet.SetMargin(MarginType.LeftMargin, (double)0.25);
            sheet.SetMargin(MarginType.BottomMargin, (double)0.1);

            sheet.Autobreaks = (true);
            //sheet.CreateFreezePane(0, 5, 0, 5);

            sheet.DefaultRowHeightInPoints = HEIGHT_ROW;
            sheet.DefaultColumnWidth = 5;
        }

        /// <summary>
        /// setup printer
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void PrinterSetup(ISheet sheet)
        {
            IPrintSetup printSetup = sheet.PrintSetup;

            printSetup.HeaderMargin = 0.25;
            printSetup.FooterMargin = 0.25;

            printSetup.Copies = 1;
            printSetup.NoColor = true;
            printSetup.Landscape = true;
            printSetup.PaperSize = (short)PaperSize.A4_Small;
            printSetup.FitHeight = ((short)600);
            printSetup.FitWidth = ((short)1);
        }

        /// <summary>
        /// Create header page
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void CreateHeader(ISheet sheet)
        {
            IHeader header = sheet.Header;

            string pageNumberInfo = "Trang: " + HeaderFooter.Page + "/" + HeaderFooter.NumPages;
            string nowDateInfo = String.Format(Constant.FMT_DATE_DPL, DateTime.Now) + " " + HeaderFooter.Time;

            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            string companyInfo = companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName + "\n" + "       ";

            //HSSFHeader.font("Stencil-Normal", "Italic") +
            //        HSSFHeader.fontSize((short) 16) + "Right w/ Stencil-Normal Italic font and size 16"

            header.Left = companyInfo;
            header.Right = nowDateInfo + "\n" + HSSFHeader.FontSize((short)11) + pageNumberInfo;
        }

        /// <summary>
        /// Create Title
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="value"></param>
        private void CreateTitle(ISheet sheet, IRow row, string value, bool isTagNo)
        {
            row.HeightInPoints = (HEIGHT_ROW_TITLE);

            ICell cellTitle = row.CreateCell(0);
            cellTitle.SetCellValue(value);
            cellTitle.CellStyle = styles[CSS_TITLE];

            if (isTagNo)
            {
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 7));

            }
            else
            {
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 5));
            }
        }

        /// <summary>
        /// Create row 1
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="printType"></param>
        private void CreateRow_1(ISheet sheet, IRow row, StockInquiryList gmModel, PrintConditionTypeFlag printType)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0251) + ": " + DateTime.Now.ToString(Constant.FMT_DATE));

            if (printType == PrintConditionTypeFlag.Location)
            {
                string LocationNameFrom = gmModel.txtLocationCDFrom ?? string.Empty.PadLeft(20, ' ');
                string LocationNameTo = gmModel.txtLocationCDTo ?? string.Empty.PadRight(20, ' ');

                ICell cell_2 = row.CreateCell(2);
                cell_2.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0252) + ": " + LocationNameFrom + UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068) + LocationNameTo);
            }
        }

        /// <summary>
        /// Create row 2
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="CD"></param>
        /// <param name="Name"></param>
        /// <param name="printType"></param>
        private void CreateRow_2(ISheet sheet, IRow row, string CD, string Name, PrintConditionTypeFlag printType)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            if (string.IsNullOrEmpty(CD.Trim()))
            {
                CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0287);
            }

            string lblCD = string.Empty;
            string lblNm = string.Empty;
            string value = string.Empty;

            switch (printType)
            {
                case PrintConditionTypeFlag.Location:
                    lblCD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051) + ": ";
                    lblNm = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0052) + ": ";
                    break;
                case PrintConditionTypeFlag.Product:
                    lblCD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018) + ": ";
                    lblNm = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019) + ": ";
                    break;
            }

            value = lblCD + CD;

            IFont font = workbook.CreateFont();
            font.Boldweight = (short)(FontBoldWeight.BOLD);

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(value);
            cell_0.RichStringCellValue.ApplyFont(lblCD.Length, value.Length, font);

            ICell cell_2 = row.CreateCell(2);
            value = lblNm + Name;
            cell_2.SetCellValue(value);
            if (!string.IsNullOrEmpty(value))
            {
                cell_2.RichStringCellValue.ApplyFont(lblNm.Length, value.Length, font);
            }
        }

        /// <summary>
        /// Create row 4
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="gmModel">StockInquiryList</param>
        private void CreateRow_4_Group(ISheet sheet, IRow row, StockInquiryList gmModel)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            for (int iCol = 0; iCol <= 7; iCol++)
            {
                ICell cell = row.CreateCell(iCol);

                switch (iCol)
                {
                    case 0:
                        sheet.SetColumnWidth(iCol, 17 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 1:
                        sheet.SetColumnWidth(iCol, 38 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 2:
                        sheet.SetColumnWidth(iCol, 14 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 3:
                        sheet.SetColumnWidth(iCol, 14 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 6:
                        sheet.SetColumnWidth(iCol, 11 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0259));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;

                    case 4:
                        sheet.SetColumnWidth(iCol, 13 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0260));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;

                    case 5:
                        sheet.SetColumnWidth(iCol, 18 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0021));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;

                    case 7:
                        sheet.SetColumnWidth(iCol, 20 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0083));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;
                }
            }
        }

        /// <summary>
        /// CreateRow_4_NotGroup
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="gmModel"></param>
        private void CreateRow_4_NotGroup(ISheet sheet, IRow row, StockInquiryList gmModel)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            for (int iCol = 0; iCol <= 5; iCol++)
            {
                ICell cell = row.CreateCell(iCol);

                switch (iCol)
                {
                    case 0:
                        sheet.SetColumnWidth(iCol, 17 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 1:
                        sheet.SetColumnWidth(iCol, 38 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 2:
                        sheet.SetColumnWidth(iCol, 14 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 3:
                        sheet.SetColumnWidth(iCol, 14 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        break;

                    case 4:
                        sheet.SetColumnWidth(iCol, 27 * 256);
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0260));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;

                    case 5:
                        sheet.SetColumnWidth(iCol, 35 * 256);

                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0021));
                        cell.CellStyle = styles[CSS_HEADER_GRID_RIGHT];
                        break;
                }
            }
        }

        /// <summary>
        /// Create row 5
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="CD"></param>
        /// <param name="Name"></param>
        private void CreateRow_5(ISheet sheet, IRow row, string CD, string Name)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            ICellStyle style = styles[CSS_HEADER_GROUP_2];

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(CD);
            cell_0.CellStyle = style;

            ICell cell_1 = row.CreateCell(1);
            cell_1.SetCellValue(Name);
            cell_1.CellStyle = style;
        }

        /// <summary>
        /// Write the stream data of workbook to the root directory
        /// </summary>
        /// <returns>MemoryStream</returns>
        MemoryStream WriteToStream()
        {
            //Write the stream data of workbook to the root directory
            MemoryStream file = new MemoryStream();
            workbook.Write(file);
            return file;
        }

        /// <summary>
        /// Create border of cell
        /// </summary>
        /// <param name="wb"></param>
        /// <returns>ICellStyle</returns>
        private static ICellStyle CreateBorderedStyle(HSSFWorkbook wb)
        {
            ICellStyle style = wb.CreateCellStyle();
            style.BorderBottom = BorderStyle.THIN;
            style.BottomBorderColor = (IndexedColors.BLACK.Index);
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);

            return style;
        }

        /// <summary>
        /// Create format number of cell
        /// </summary>
        /// <param name="wb"></param>
        /// <returns>ICellStyle</returns>
        private static ICellStyle CreateFormatNumber(HSSFWorkbook wb, string format)
        {
            ICellStyle style = wb.CreateCellStyle();
            style.Alignment = HorizontalAlignment.RIGHT;
            style.DataFormat = HSSFDataFormat.GetBuiltinFormat(format);

            return style;
        }

        /// <summary>
        /// Create format string of cell
        /// </summary>
        /// <param name="wb"></param>
        /// <returns>ICellStyle</returns>
        private static ICellStyle CreateFormatstring(HSSFWorkbook wb)
        {
            ICellStyle style = wb.CreateCellStyle();
            style.Alignment = HorizontalAlignment.LEFT;

            return style;
        }

        /// <summary>
        /// Create row Empty 
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="index"></param>
        private static void CreateRowEmpty(ISheet sheet, int index)
        {
            IRow row = sheet.CreateRow(index);
            row.HeightInPoints = 9f;
        }

        /// <summary>
        /// create Styles
        /// </summary>
        /// <param name="wb"></param>
        /// <returns></returns>
        private static Dictionary<String, ICellStyle> createStyles(HSSFWorkbook wb)
        {
            Dictionary<String, ICellStyle> styles = new Dictionary<String, ICellStyle>();
            IDataFormat dataFormat = wb.CreateDataFormat();
            ICellStyle style;

            #region CSS_TITLE

            style = wb.CreateCellStyle();
            style.Alignment = HorizontalAlignment.CENTER;
            //font
            IFont titleFont = wb.CreateFont();
            titleFont.Boldweight = (short)(FontBoldWeight.BOLD);
            titleFont.FontHeightInPoints = 14;
            style.SetFont(titleFont);
            styles.Add(CSS_TITLE, style);

            #endregion

            #region CSS_HEADER_GROUP_2

            style = wb.CreateCellStyle();
            IFont headerGroupFont = wb.CreateFont();
            headerGroupFont.Boldweight = (short)(FontBoldWeight.BOLD);
            //format data
            style.DataFormat = dataFormat.GetFormat("@");
            style.SetFont(headerGroupFont);
            styles.Add(CSS_HEADER_GROUP_2, style);

            #endregion

            #region CSS_HEADER_GRID_LEFT

            style = CreateBorderedStyle(wb);
            style.Alignment = HorizontalAlignment.LEFT;
            styles.Add(CSS_HEADER_GRID_LEFT, style);

            #endregion

            #region CSS_HEADER_GRID_RIGHT

            style = CreateBorderedStyle(wb);
            style.Alignment = HorizontalAlignment.RIGHT;
            styles.Add(CSS_HEADER_GRID_RIGHT, style);

            #endregion

            #region CSS_ROW_DETAIL_STRING

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat("@");
            styles.Add(CSS_ROW_DETAIL_STRING, style);

            #endregion

            #region CSS_ROW_DETAIL_INT

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            styles.Add(CSS_ROW_DETAIL_INT, style);

            #endregion

            #region CSS_ROW_DETAIL_DECIMAL

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            styles.Add(CSS_ROW_DETAIL_DECIMAL, style);

            #endregion

            #region CSS_LBL_TOTAL_BODER_TOP

            style = wb.CreateCellStyle();
            //format data
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.Alignment = HorizontalAlignment.RIGHT;
            styles.Add(CSS_LBL_TOTAL_BODER_TOP, style);

            #endregion

            //#region CSS_LBL_TOTAL_BODER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.Alignment = HorizontalAlignment.RIGHT;
            //styles.Add(CSS_LBL_TOTAL_BODER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_CELL_EMPTY_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            styles.Add(CSS_CELL_EMPTY_BORDER_TOP, style);

            #endregion

            //#region CSS_CELL_EMPTY_BORDER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //styles.Add(CSS_CELL_EMPTY_BORDER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            styles.Add(CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP, style);

            #endregion

            //#region CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            //styles.Add(CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_VALUE_TOTAL_INT_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            styles.Add(CSS_VALUE_TOTAL_INT_BORDER_TOP, style);

            #endregion

            //#region CSS_VALUE_TOTAL_INT_TOP_BORDER_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            //styles.Add(CSS_VALUE_TOTAL_INT_BORDER_TOP_BOTTOM, style);

            //#endregion

            return styles;
        }

        #endregion

        #endregion
    }
}

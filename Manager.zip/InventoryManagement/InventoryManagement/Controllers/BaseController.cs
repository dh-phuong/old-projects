﻿using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Common;
using System;
using InventoryManagement.iQueryable;
using System.Collections.Generic;
using InventoryManagement.Validation;
using Microsoft.Reporting.WebForms;
using InventoryManagement.Utility;
using System.Web.Helpers;
using System.Reflection;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Base Controller
    /// Author: ISV-Vinh
    /// </summary>
    [iNoCache]
    public class BaseController : Controller
    {
        #region Constant

        public const int PAGE_SIZE = 10;
        private const string SES_FORM_BACK = "Session_IsFormBack";
        private const string SES_ACTION_DATA = "Session_Action_Data";
        protected const string SES_DOWNLOAD_FILE = "Session_FileDownLoad";
        protected const string TMP_DOWNLOAD_FILE = "Tmp_FileDownLoad";
       
        #endregion

        #region Method

        /// <summary>
        /// Set form back call
        /// </summary>
        protected void SetFormBack()
        {
            this.TempData[SES_FORM_BACK] = true;
        }

        /// <summary>
        /// Check form back call
        /// </summary>
        /// <returns></returns>
        protected bool IsFormBack()
        {
            return this.TempData[SES_FORM_BACK] != null;
        }

        /// <summary>
        /// Set Action tranfer data
        /// </summary>
        /// <param name="value">data</param>
        protected void SetActionDataPass(object value)
        {
            this.TempData[SES_ACTION_DATA] = value;
        }

        /// <summary>
        /// Get action tranfer data
        /// </summary>
        /// <returns>data</returns>
        protected object GetActionDataPass()
        {
            return this.TempData[SES_ACTION_DATA];
        }

        /// <summary>
        /// Set focus
        /// </summary>
        /// <param name="controlId">focusId</param>
        protected void SetFocusId(string controlId)
        {
            ViewData[Common.Constant.VIEWDATA_FOCUSID] = controlId;
        }

        /// <summary>
        /// Clear focus
        /// </summary>
        protected void ClearFocusId()
        {
            ViewData[Common.Constant.VIEWDATA_FOCUSID] = null;
        }

        /// <summary>
        /// Set ModeState
        /// </summary>
        /// <param name="modeState">modeState</param>
        /// <param name="seqNum">sequence Number</param>
        protected void SetMode(Common.Mode modeState, int seqNum)
        {
            Session[Constant.SESSION_STATE_MODE + seqNum.ToString()] = modeState;
        }

        /// <summary>
        /// Get mode
        /// </summary>
        /// <param name="seqNum">sequence Number</param>
        /// <returns>modeState</returns>
        protected Mode GetMode(int seqNum)
        {
            if (Session[Constant.SESSION_STATE_MODE + seqNum.ToString()] == null)
            {
                throw new ArgumentNullException("Session ModeState not exists.");
            }

            return (Mode)Session[Constant.SESSION_STATE_MODE + seqNum.ToString()];
        }

        /// <summary>
        /// Show Message Confirm
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="urlConfirm">urlConfirm</param>
        /// <param name="value1">Value pass</param>
        protected void ShowMessageConfirm(int SeqNum, string urlConfirm, string message = "", string value1 = "", string value2 = "", string value3 = "", string value4 = "", string value5 = "")
        {
            if (String.IsNullOrEmpty(message))
            {
                switch ((Mode)Session[Constant.SESSION_STATE_MODE + SeqNum.ToString()])
                {
                    case Mode.Insert:
                    case Mode.Copy:
                        message = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0008);
                        break;

                    case Mode.Update:
                        message = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0010);
                        break;
                    case Mode.Delete:
                        message = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0006);
                        break;                   
                    default:
                        break;
                }
            }

            //Set data pass
            if (!String.IsNullOrEmpty(value1))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_1] = value1;
            }

            if (!String.IsNullOrEmpty(value2))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_2] = value2;
            }

            if (!String.IsNullOrEmpty(value3))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_3] = value3;
            }

            if (!String.IsNullOrEmpty(value4))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_4] = value4;
            }

            if (!String.IsNullOrEmpty(value5))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_5] = value5;
            }

            ViewData[Constant.VIEWDATA_TRANFER_URL] = urlConfirm;
            ViewData[Constant.VIEWDATA_MES_CONFIRM] = message;
        }

        /// <summary>
        /// ShowMessageConfirmPrint
        /// Author: ISV-Truc
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="urlConfirm">url Confirm</param>
        /// <param name="message">message content</param>
        /// <param name="value1">param 1</param>
        /// <param name="value2">param 2</param>
        /// <param name="value3">param 3</param>
        /// <param name="value4">param 4</param>
        /// <param name="value5">param 5</param>
        /// <param name="printAppend">Print Append</param>
        protected void ShowMessageConfirmPrint(int SeqNum, string urlConfirm, string message = "", string value1 = "", string value2 = "", string value3 = "", string value4 = "", string value5 = "", string printAppend = "")
        {
            if (String.IsNullOrEmpty(message))
            {
                switch ((Mode)Session[Constant.SESSION_STATE_MODE + SeqNum.ToString()])
                {
                   
                    case Mode.Print:
                        if (string.IsNullOrEmpty(message))
                        {
                            message = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020);
                        }
                        break;
                    default:
                        break;
                }
            }

            //Set data pass
            if (!String.IsNullOrEmpty(value1))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_1] = value1;
            }

            if (!String.IsNullOrEmpty(value2))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_2] = value2;
            }

            if (!String.IsNullOrEmpty(value3))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_3] = value3;
            }

            if (!String.IsNullOrEmpty(value4))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_4] = value4;
            }

            if (!String.IsNullOrEmpty(value5))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_5] = value5;
            }

            if (!String.IsNullOrEmpty(printAppend))
            {
                ViewData[Constant.VIEWDATA_MES_APPEND] = printAppend;
            }

            ViewData[Constant.VIEWDATA_TRANFER_URL] = urlConfirm;
            ViewData[Constant.VIEWDATA_MES_PRINT] = message;
        }

        /// <summary>
        /// Show message Information
        /// </summary>
        /// <param name="message">message string</param>
        protected void ShowMessageInfo(string message)
        {
            ViewData[Common.Constant.VIEWDATA_MES_INFO] = message;
        }

        /// <summary>
        /// Show Message Exclusion
        /// </summary>
        /// <param name="urlRedirect">urlRedirect</param>
        /// <param name="value1">Param 1</param>
        /// <param name="value2">Param 2</param>
        /// <param name="value3">Param 3</param>
        protected void ShowMessageExclusion(string urlRedirect, string value1 = "", string value2 = "", string value3 = "", string message = "")
        {
            if (String.IsNullOrEmpty(message))
            {
                message = this.FormatMessage(Constant.MES_M0003);
            }

            ViewData[Common.Constant.VIEWDATA_MES_TRANFER] = message;
            ViewData[Common.Constant.VIEWDATA_TRANFER_URL] = urlRedirect;

            //Set data pass
            if (!String.IsNullOrEmpty(value1))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_1] = value1;
            }
            if (!String.IsNullOrEmpty(value2))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_2] = value2;
            }
            if (!String.IsNullOrEmpty(value3))
            {
                ViewData[Constant.VIEWDATA_TRANFER_VALUE_3] = value3;
            }
        }

        /// <summary>
        /// Paging Search
        /// </summary>
        /// <typeparam name="T">Generic</typeparam>
        /// <param name="list">IQueryable</param>
        /// <param name="pageRequest">page Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="seqNum">Sequense Number</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="orderField2">Other sort files</param>
        /// <param name="notStore">Not store in session flag</param>
        /// <param name="SesionPagingKey">Sesion Paging Key</param>
        /// <param name="SesionSortingKey">Sesion Sorting Key</param>
        protected void PagingBase<T>(ref IQueryable<T> list, PagingRequest pageRequest, SortingInfo sortInfo, int seqNum, int pageSize = PAGE_SIZE,
                                     string orderField2 = null, bool notStore = false, string SesionPagingKey = Constant.SESSION_LIST_PAGING, string SesionSortingKey = Constant.SESSION_LIST_SORTING)
        {
            if (!notStore)
            {
                //Store Paging Request
                this.Session[SesionPagingKey + seqNum.ToString()] = pageRequest;

                //Store Storing Request
                this.Session[SesionSortingKey + seqNum.ToString()] = sortInfo;
            }
           
            //Set Sequence Number
            ViewBag.SeqNum = seqNum;

            if (sortInfo != null)
            {
                //Set sorting
                if (!string.IsNullOrEmpty(sortInfo.SortField))
                {
                    list = list.iOrderBy(sortInfo.SortField, sortInfo.Direction);
                }
                if (!string.IsNullOrEmpty(orderField2)) 
                {
                    list = list.iThenBy(sortInfo.SortField, SortDirection.Ascending);                
                }
                ViewBag.SortingInfo = sortInfo;
            }           

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = pageRequest.page,                
                ItemsPerPage = pageSize,
                TotalItems = list.Count()
            };

            if (pageRequest.isFirst)
            {
                pageInfo.CurrentPage = 1;
            }
            else if (pageRequest.isLast)
            {
                pageInfo.CurrentPage = pageInfo.TotalPages;
            }
            ViewBag.PagingInfo = pageInfo;

            //Set list display
            ViewBag.Result = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage);
        }

        /// <summary>
        /// Sorting Search
        /// </summary>
        /// <typeparam name="T">Generic</typeparam>
        /// <param name="list">IQueryable</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="seqNum">Sequense Number</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="notStore">Not store in session flag</param>
        /// <param name="SesionPagingKey">Sesion Paging Key</param>
        /// <param name="SesionSortingKey">Sesion Sorting Key</param>
        protected void SortingBase<T>(IQueryable<T> list, SortingInfo sortInfo, int seqNum, int pageSize = PAGE_SIZE, bool notStore = false,
                                      string SesionPagingKey = Constant.SESSION_LIST_PAGING, string SesionSortingKey = Constant.SESSION_LIST_SORTING)
        {
            if (!notStore)
            {
                //Store Storing Request
                this.Session[SesionSortingKey + seqNum.ToString()] = sortInfo;
            }

            //Store Paging Request
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.Session[SesionPagingKey + seqNum.ToString()] = pageRequest;

            //Set Sequence Number
            ViewBag.SeqNum = seqNum;

            //Set sorting
            list = list.iOrderBy(sortInfo.SortField, sortInfo.Direction);
            ViewBag.SortingInfo = sortInfo;

            //Create paging info
            ViewBag.PagingInfo = new PagingInfo
            {
                CurrentPage = 1,
                ItemsPerPage = pageSize,
                TotalItems = list.Count()
            };

            //Set list display
            ViewBag.Result = list.Take(pageSize);
        }

        /// <summary>
        /// Format Message
        /// </summary>
        /// <param name="messageCD"><messageCD/param>
        /// <param name="paramArray">paramArray</param>
        /// <returns>Message string</returns>
        protected string FormatMessage(string messageCD, params object[] paramArray)
        {
            return String.Format(InventoryManagement.UserSession.Session.SysCache.GetMessage(messageCD), paramArray);
        }

        /// <summary>
        /// Get current date
        /// </summary>
        /// <returns>Current date string</returns>
        protected string GetCurrentDate()
        {
            DateTime now = DateTime.Now;
            return now.ToString(Constant.FMT_DATETIME) + now.Millisecond.ToString("0000");
        }

        /// <summary>
        /// Clear Model State
        /// </summary>
        protected void ClearModelState()
        {
            List<String> lstKey = this.ModelState.Keys.ToList();

            foreach (var item in lstKey)
            {
                if (!String.IsNullOrEmpty(item))
                {
                    this.ModelState.Remove(item);
                }
            }
        }

        /// <summary>
        /// Clear model state by key
        /// </summary>
        /// <param name="key">key</param>
        protected void ClearModelStateByKey(string key)
        {
            if (this.ModelState.ContainsKey(key))
            {
                this.ModelState.Remove(key);
            }
        }

        /// <summary>
        /// Set Viewbag
        /// Author: ISV-PHUONG
        /// </summary>
        /// <typeparam name="TEntity">Model</typeparam>
        /// <param name="ViewDataValue">selected item</param>
        /// <param name="option">select option</param>
        /// <param name="Entities">Source</param>
        protected void SetViewDataDropdownList<TEntity>(SelectOption option, IEnumerable<TEntity> Entities)
        {
            ViewData[option.ViewDataKey] = new SelectList(Entities, option.ValueMember, option.DisplayMember, option.SelectedValue);
        }

        /// <summary>
        /// Fix code to show
        /// Author: ISV-PHUONG
        /// </summary>
        /// <param name="iCode">input code</param>
        /// <returns>code</returns>       
        public string FixCode(string iCode, int iLength)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }
            System.Text.RegularExpressions.Match match = System.Text.RegularExpressions.Regex.Match(iCode, Constant.PATTERN_NUMERIC, System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            // Here we check the Match instance.
            if (match.Success)
            {
                return iCode.PadLeft(iLength, Constant.CHAR_ZERO);
            }
          
            return iCode;
        }

        /// <summary>
        /// Fix code to show
        /// Author: ISV-PHUONG
        /// </summary>
        /// <param name="iCode">input code</param>
        /// <returns>code</returns>       
        public string FormatNumber(string iCode, TypeFormat iTypeFormat)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }
            switch (iTypeFormat)
            {
                case TypeFormat.Int:
                    int resultI = 0;
                    if (CommonUtil.TryParseInt(iCode, ref resultI))
                    {
                        return String.Format(Constant.NUMBER_FORMAT_INT, resultI);
                    }

                    break;
                case TypeFormat.Dec:
                    decimal resultD = 0;
                    if (CommonUtil.TryParseDecimal(iCode, ref resultD))
                    {
                        return String.Format(Constant.FMT_DECIMAL_FULL, resultD);
                    }
                    break;
                default:
                    return iCode;
            }
            
            return iCode;
        }

        /// <summary>
        /// output csv file
        /// Author: ISV-PHUONG
        /// </summary>
        /// <typeparam name="TEntity">Model</typeparam>
        /// <param name="Data">Data source</param>
        /// <param name="FileName">File output</param>
        /// <param name="hideColumn">hide column</param>
        /// <param name="IsShowCaption">Show Caption</param>
        /// <returns></returns>        
        public FileContentResult CSVOutPut<TEntity>(IQueryable<TEntity> Data, string[] hideColumn, string FileName, string FileDownloadName, bool IsShowCaption = false)
        {
            //dislay colum as string (data)
            //hien thi du lieu nhu la du lieu ky tu
            List<string> columns = new List<string>();

            //Get Column Name
            var defaultObj = Data.FirstOrDefault();
            var Fields = defaultObj.GetType().GetProperties();
            foreach (var propInfo in Fields)
            {
                var attribute = propInfo.GetCustomAttributes(typeof(iDisplayNameAttribute), true).Cast<iDisplayNameAttribute>().SingleOrDefault();
                if (attribute != null)
                {
                    columns.Add(attribute.DisplayName);
                }
                else
                {
                    columns.Add(string.Empty);
                }

            }

            //CSV Writer
            var writer = new Utility.CSVUtil(FileName, columns.ToArray(), IsShowCaption);

            //Write data
            byte[] data = writer.Write(Data.ToArray<TEntity>(), null, hideColumn);
            
            //For download file
            return File(data, "application/csv", FileDownloadName);             
        }

        /// <summary>
        /// output csv file
        /// Author: ISV-TIEN
        /// </summary>
        /// <param name="Report">Local Report</param>
        /// <param name="FileDownloadName">File Download Name</param>
        /// <param name="reportType">Report Type</param>
        /// <param name="isPortrait">Is Portrait Page</param>
        /// <returns>FileContentResult</returns>
        public FileContentResult PDFOutPut(LocalReport Report, string FileDownloadName, Common.ReportType reportType, bool isPortrait)
        {
            string REPORT_TYPE = "PDF";
            string MimeType;
            string Encoding;
            string FilenameExtension;

            //Page size
            double pageWidth = isPortrait? 21 : 29.7;
            double pageHeight = isPortrait? 29.7 : 21;

            //Margin
            double maginTop = 0;
            double maginRight = 0;
            double maginBottom = 0;
            double maginLeft = 0;
            switch (reportType)
            {
                case ReportType.Barcode:
                    maginTop = 0;
                    maginRight = 0;
                    maginBottom = 0;
                    maginLeft = 0;
                    break;

                case ReportType.Business:
                    maginTop = 0.5;
                    maginRight = 0.5;
                    maginBottom = 0.5;
                    maginLeft = 0.5;
                    break;

                case ReportType.System:
                    maginTop = 0.1;
                    maginRight = 0.3;
                    maginBottom = 0.1;
                    maginLeft = 0.3;
                    break;

                default:
                    break;
            }

            string DEVICE_INFO = "<DeviceInfo>";
            DEVICE_INFO += "  <OutputFormat>PDF</OutputFormat>";
            DEVICE_INFO += "  <PageWidth>" + pageWidth + "cm</PageWidth>";
            DEVICE_INFO += "  <PageHeight>" + pageHeight + "cm</PageHeight>";
            DEVICE_INFO += "  <MarginTop>" + maginTop + "cm</MarginTop>";
            DEVICE_INFO += "  <MarginRight>" + maginRight + "cm</MarginRight>";
            DEVICE_INFO += "  <MarginBottom>" + maginBottom + "cm</MarginBottom>";
            DEVICE_INFO += "  <MarginLeft>" + maginLeft + "cm</MarginLeft>";
            DEVICE_INFO += "  </DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            //Render the report
            renderedBytes = Report.Render(
                                            REPORT_TYPE,
                                            DEVICE_INFO,
                                            out MimeType,
                                            out Encoding,
                                            out FilenameExtension,
                                            out streams,
                                            out warnings);
         
            return File(renderedBytes, "application/pdf", FileDownloadName);
        }

        /// <summary>
        /// Down Load File
        /// Author: ISV-VINH
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>File</returns>     
        [iHttpParamAction]
        public ActionResult DownLoadFile(int SeqNum)
        {
            var file = (FileContentResult)this.Session[SES_DOWNLOAD_FILE + SeqNum.ToString()];

            //for download
            Response.Clear();
            Response.AddHeader("Content-Disposition", string.Format("attachment; filename={0}", file.FileDownloadName));
            Response.ContentType = string.Format("application/{0}", file.ContentType);
            Response.BinaryWrite(file.FileContents);
            Response.End();

            return View();
        }

        /// <summary>
        /// Store File Download
        /// </summary>
        /// <param name="file">FileContentResult</param>
        /// <param name="seqNum">Sequence Number</param>
        public void StoreFileDownload(FileContentResult file, int seqNum)
        {
            this.Session[SES_DOWNLOAD_FILE + seqNum.ToString()] = file;
        }

        /// <summary>
        /// Sort Model State
        /// </summary>
        /// <param name="obj">model class</param>
        protected void SortModelState(Type type)
        {
            PropertyInfo[] properties = type.GetProperties();

            //Store ModelState
            List<string> KeyDic = this.ModelState.Keys.ToList();
            List<ModelState> ValueDic = this.ModelState.Values.ToList();
            this.ModelState.Clear();

            foreach (PropertyInfo property in properties)
            {
                if (property.PropertyType == typeof(DateControl))
                {
                    this.InsertModelStateForSort(KeyDic, ValueDic, property.Name, property.Name + ".Day");

                    this.InsertModelStateForSort(KeyDic, ValueDic, property.Name + ".Day");
                    this.InsertModelStateForSort(KeyDic, ValueDic, property.Name + ".Month");
                    this.InsertModelStateForSort(KeyDic, ValueDic, property.Name + ".Year");
                    continue;
                }

                this.InsertModelStateForSort(KeyDic, ValueDic, property.Name);
            }

            while (KeyDic.Count() != 0)
            {
                this.ModelState.Add(KeyDic[0], ValueDic[0]);

                KeyDic.RemoveAt(0);
                ValueDic.RemoveAt(0);
            }
        }

        /// <summary>
        /// Insert ModelState For Sort
        /// </summary>
        /// <param name="KeyDic">Keys Dictionary</param>
        /// <param name="ValueDic">Values Dictionary</param>
        /// <param name="proName">Propertise Name</param>
        private void InsertModelStateForSort(List<string> KeyDic, List<ModelState> ValueDic, string proName, string convertProName = "")
        {
            var temp = KeyDic.Select((item, i) => new { Item = item, Index = i })
                 .FirstOrDefault(x => x.Item == proName);
            if (temp != null)
            {
                int index = temp.Index;
                if (String.IsNullOrEmpty(convertProName) || ValueDic[index].Errors.Count == 0)
                {
                    convertProName = KeyDic[index];
                }
                
                if (!this.ModelState.ContainsKey(convertProName))
                {
                    this.ModelState.Add(convertProName, ValueDic[index]);
                }

                KeyDic.RemoveAt(index);
                ValueDic.RemoveAt(index);
            }
        }

        /// <summary>
        /// Option dropdownlist
        /// </summary>
        public class SelectOption
        {
            /// <summary>
            /// Field to display
            /// </summary>
            public string DisplayMember { get; set; }

            /// <summary>
            /// Field to get value
            /// </summary>
            public string ValueMember { get; set; }

            /// <summary>
            /// Key ViewData
            /// </summary>
            public string ViewDataKey { get; set; }

            /// <summary>
            /// Key ViewData
            /// </summary>
            public object SelectedValue { get; set; }

            /// <summary>
            /// Init data
            /// </summary>
            /// <param name="displayField">DisplayMember</param>
            /// <param name="valueField">ValueMember</param>
            /// <param name="key">ViewDataKey</param>
            public SelectOption(string displayField, string valueField, string key, object selectedItem)
            {
                this.DisplayMember = displayField;
                this.ValueMember = valueField;
                this.ViewDataKey = key;
                this.SelectedValue = selectedItem;
            }

            public SelectOption(string displayField, string valueField)
            {
                this.DisplayMember = displayField;

                this.ValueMember = valueField;
            }
        }

        #endregion

        #region Redirect Not Authority

        /// <summary>
        /// Redirect If Not Authority
        /// </summary>
        /// <returns></returns>
        public ActionResult RedirectNotAuthority()
        {
            return RedirectToAction("Menu", "Menu");
        }

        /// <summary>
        /// Redirect If Not Authority
        /// </summary>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Action()
        {
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Search TimeOut action
        /// </summary>
        /// <returns></returns>
        public ActionResult Timeout()
        {
            return Content(string.Empty);
        }

        #endregion
    }
}

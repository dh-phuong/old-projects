﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    [InventoryManagement.Validation.iAuthorize]
    public class MenuController : BaseController
    {
        
        #region Common

        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TTakeInventory_HService tTakeInventory_HService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tInventoryService">TInventoryService</param>
        /// <param name="mCustomerService">MCustomerService</param>
        /// <param name="tShippingInstructionService">TShippingInstructionService</param>
        /// <param name="tShippingInstructionDetailService">TShippingInstructionDetailsService</param>
        /// <param name="mProductService">MProductService</param>
        /// <param name="tSequencesService">TSequencesService</param>
        /// <param name="tStockAllowanceService">TStockAllowanceService</param>
        public MenuController(DataAccess.TInventory_DService tInventory_DService
                            , DataAccess.TTakeInventory_HService tTakeInventory_HService
                            , DataAccess.TShippingInstructionService tShippingInstructionService
            )
        {
            this.tInventory_DService = tInventory_DService;
            this.tTakeInventory_HService = tTakeInventory_HService;
            this.tShippingInstructionService = tShippingInstructionService;
        }

        #endregion

        //
        // GET: /Menu/
        [iAuthorize]
        public ActionResult Menu()
        {
            if (string.IsNullOrEmpty(UserSession.Session.LoginInfo.User.CustomerCD))
            {
                ViewBag.IsExistsArrivalNonDefective = this.tInventory_DService.IsExistsArrivalNonDefective();
                ViewBag.IsExistRegist = this.tShippingInstructionService.IsExistRegist();
                ViewBag.IsExistsIssueOrIssueInsideMove = this.tShippingInstructionService.IsExistRun();
                ViewBag.IsExistsInTakeInventory = this.tTakeInventory_HService.IsExistsInTakeInventory();
            }
            else
            {
                ViewBag.IsExistsArrivalNonDefective = false;
                ViewBag.IsExistRegist = false;
                ViewBag.IsExistsIssueOrIssueInsideMove = false;
                ViewBag.IsExistsInTakeInventory = false;
            }

            return View();
        }

        //
        // GET: /Master/
        [iAuthorize]
        public ActionResult Master()
        {
            return View();
        }

        [iAuthorize]
        public ActionResult Report()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// エラーのController
    /// Author: ISV-PHUONG
    /// </summary>
    public class ErrorsController : BaseController
    {
        /// <summary>
        /// Error
        /// </summary>
        /// <param name="exception">Exception</param>
        /// <returns>View</returns>
        public ActionResult Error(Exception exception)
        {
            HandleErrorInfo ex = new HandleErrorInfo(exception, "Errors", "Error");
            return View("Error", ex);
        }      
    }
}

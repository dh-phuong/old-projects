﻿using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Common;
using System;
using System.Data.Linq;
using System.Web.Helpers;
using System.Data.SqlClient;
using InventoryManagement.Utility;
using InventoryManagement.Validation;
using System.Collections.Generic;
using System.Collections;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Author : ISV - Thuy
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class UserController : BaseController
    {
        #region Common

        private DataAccess.MUserService mUserService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MGroup_HService mGroup_HService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MWarehouseByUserService mWarehouseByUserService;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="mUserService">MUserService</param>
        /// <param name="mKindService">MKindService</param>
        public UserController(DataAccess.MUserService mUserService,
                              DataAccess.MKind_DService mKind_DService,
                              DataAccess.MGroup_HService mGroup_HService,
                              DataAccess.MCustomerService mCustomerService,
                              DataAccess.MWarehouseService mWarehouseService,
                              DataAccess.MWarehouseByUserService mWarehouseByUserService
                              )
        {
            this.mUserService = mUserService;
            this.mKind_DService = mKind_DService;
            this.mGroup_HService = mGroup_HService;
            this.mCustomerService = mCustomerService;
            this.mWarehouseService = mWarehouseService;
            this.mWarehouseByUserService = mWarehouseByUserService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.mUserService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.mGroup_HService.Context = ctx;
            this.mCustomerService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.mWarehouseByUserService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string KEY_USER_CD = "txt_UserCD";
        private const string KEY_ROLES_CD = "txt_RolesCD";

        private const string USER_CD_CONTROL = "UserCD";
        private const string LOGIN_ID_CONTROL = "LoginID";
        private const string GROUP_CD_CONTROL = "GroupCD";
        private const string CUSTOMER_CD_CONTROL = "CustomerCD";
        private const string PASSWORD_ID_CONTROL = "Password";

        private const string DETAIL_CHECKBOX_ID = "chk_Delete_{0}";
        private const string DETAIL_WAREHOUSE_CD_CONTROL = "txt_WarehouseCD_{0}";
        private const string DETAIL_WAREHOUSE_CD_ID = "txt_WarehouseCD_";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/User/Sorting";

        private const string BUTTON_EDIT = "btnEdit";
        private const string BUTTON_BACK = "btnBack";

        private const string PARTIAL_LIST = "_List";
        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_DETAIL = "Details";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        private const int ROWNUMBER_DEFAULT = 10;

        #endregion

        #region Event
        
        #region Index

        /// <summary>
        /// List action
        /// </summary>
        /// <param name="gmModel">UserList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(UserList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                UserList oldModel = (UserList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(UserList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<UserResults> results = this.mUserService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<UserResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(KEY_USER_CD);
                }
            }

            this.Session[Constant.SESSION_SHOW_CUSTOMER] = this.mKind_DService.IsShowCustomer();
            
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<UserResults> results = this.mUserService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };
                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<UserResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                SetFocusId(KEY_USER_CD);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<UserResults> list = (IQueryable<UserResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<UserResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">sortInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<UserResults> list = (IQueryable<UserResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<UserResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView(PARTIAL_LIST);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="PreUserCD">PreUserCD</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string PreUserCD, int SeqNum)
        {
            //Check Authority
            if(!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0003);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(USER_CD_CONTROL);

            //Set data display
            UserModels gmModel = new UserModels();
            gmModel.PreUserCD = PreUserCD;
            gmModel.SeqNum = SeqNum;
            //Default Check All Warehouse
            gmModel.chk_AllWarehouse = true;

            //IsFirstPostBack
            this.ViewBag.IsFirstPostBack = true;

            //Add empty rows 
            this.AddEmtyRows(gmModel, ROWNUMBER_DEFAULT);
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = gmModel;

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(UserModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/User/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }
            else
            {
                if (string.IsNullOrEmpty(gmModel.UserShortName))
                {
                    this.ViewBag.IsFirstPostBack = true;
                }
            }

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            UserModels gmModel = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }

            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }
            return ret;
        }

        #endregion

        #region View

        /// <summary>
        /// View
        /// </summary>
        /// <param name="value1">UserCd</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Clear model state
            this.ClearModelState();

            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0002);

            //Set ModeState
            SetMode(Common.Mode.Show, value2);

            //Get data
            UserModels model = this.mUserService.GetByUserCd(value1);

            //Add empty rows 
            this.AddEmtyRows(model, ROWNUMBER_DEFAULT);

            //Check exclusion
            if (model == default(UserModels))
            {
                return this.ExclusionProcess(value2);
            }

            //Show List
            IQueryable<WarehouseByUserGrid> result = this.mWarehouseByUserService.GetListDetailByUserCD(model.UserCD);
            if (result.Count() > 0)
            {
                List<WarehouseByUserGrid> listDetail = result.ToList();
                model.Detail = listDetail;
                this.GetNumRow(model);
            }
            else
            {
                model.chk_AllWarehouse = true;
            }

            //Store model into session
            model.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            string temp = string.Empty;
            model.Password = temp.PadLeft(model.Password.Length, Constant.MUSER_USER_CHAR_PASSWORD);

            //Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_USER_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View(SCREEN_DETAIL, model);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0005);

            //Get data
            UserModels gmModel = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            UserModels userModels = mUserService.GetByUserCd(gmModel.UserCD);

            //Check Exclusion
            if (userModels == default(UserModels) || gmModel.UpdateDate != userModels.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set Sequence Number
            userModels.SeqNum = SeqNum;
            userModels.chk_AllWarehouse = gmModel.chk_AllWarehouse;
            userModels.Password = String.Empty;

            //Reset List Detail Warehouse by User
            int rowNumber = 1;
            foreach (WarehouseByUserGrid row in gmModel.Detail)
            {
                WarehouseByUserGrid rowNew = new WarehouseByUserGrid()
                {
                    txt_WarehouseCD = row.txt_WarehouseCD,
                    txt_WarehouseName = row.txt_WarehouseName,
                    NumRow = rowNumber++
                };
                userModels.Detail.Add(rowNew);
            }

            //Get Number of Row Detail
            this.GetNumRow(userModels);

            //Set focusId
            this.SetFocusId(LOGIN_ID_CONTROL);
            return View(SCREEN_DETAIL, userModels);
        }

        /// <summary>
        /// Update Confirm
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(UserModels gmModel)
        {
            // clear cokiee of browser settings
            if (string.IsNullOrEmpty(gmModel.UserShortName))
            {
                this.ViewBag.IsFirstPostBack = true;
            }

            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/User/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            UserModels gmModel = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update check
            if (!this.UpdateCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }

            ActionResult ret = default(ActionResult);
            //Update data
            string message = string.Empty;
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/User/Show", gmModel.UserCD, gmModel.SeqNum.ToString());
                    ret = View(SCREEN_DETAIL, gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(UserModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();
            //Get data
            MUser dbModel = this.mUserService.GetByCdAndUpDate(gmModel.UserCD, gmModel.UpdateDate);
            //Check Exclusion
            if (dbModel == default(MUser))
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

            //Show confirm message
            this.ShowMessageConfirm(gmModel.SeqNum, "/User/DeleteAction", value1: gmModel.SeqNum.ToString());

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            UserModels model = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            //Delete data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.UserCD, value1);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.UserCD, value1);
                    break;
            }

            return ret;
        }

        #endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0003);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            UserModels model = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            model.Password = string.Empty;
            model.ConfirmPassword = string.Empty;

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(USER_CD_CONTROL);
            //this.SetViewBagRolesCD(ROLES_CD_CONTROL, model.RolesCD);

            return View(SCREEN_DETAIL, model);
        }

        /// <summary>
        /// Copy Action Confirm
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(UserModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/User/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }

            //this.SetViewBagRolesCD(ROLES_CD_CONTROL, gmModel.RolesCD);
            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            UserModels gmModel = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View(SCREEN_DETAIL, gmModel);
            }

            ActionResult ret = default(ActionResult);
            string message = String.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;
            }


            return ret;
        }

        #endregion

        #endregion

        # region CSV

        /// <summary>
        /// CSV
        /// </summary>
        /// <param name="gmModel">UserList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(UserList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_USER_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Get model
            IQueryable<UserListCSV> userListCSV = null;
            userListCSV = this.mUserService.GetListUserCSV();
            if (userListCSV.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View(SCREEN_INDEX, gmModel);
            }

            //Export CSV file
            var directory = System.Configuration.ConfigurationManager.AppSettings["MUser"];
            var filename = string.Format("{0}-{1}.csv", "MUser", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };
            
            var file = this.CSVOutPut<UserListCSV>(userListCSV, hideColumn, fileFullName, "MUSER.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            UserList oldModel = (UserList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<UserResults> results = this.mUserService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<UserResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="gmModel">gmModel</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(UserModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreUserCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreUserCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region ReadOnlyGrid

        [HttpPost]
        [iHttpParamAction]
        public ActionResult ReadOnlyGrid(UserModels gmModel)
        {
            this.ClearModelState();
            if (gmModel.chk_AllWarehouse)
            {
                gmModel.Detail = new List<WarehouseByUserGrid>();
                this.AddEmtyRows(gmModel, ROWNUMBER_DEFAULT);
            }
            Mode modeState = (Mode)Session[Constant.SESSION_STATE_MODE + gmModel.SeqNum];
            if (modeState.Equals(Mode.Insert) || modeState.Equals(Mode.Copy))
            {
                //Set focus
                this.SetFocusId(USER_CD_CONTROL);
                if (!gmModel.chk_AllWarehouse)
                {
                    if (!string.IsNullOrEmpty(gmModel.UserCD))
                    {
                        this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + 1);
                    }
                }
            }
            else
            {
                this.SetFocusId(LOGIN_ID_CONTROL);
                
                UserModels userModels = mUserService.GetByUserCd(gmModel.UserCD);
                //Set focusId
                if (userModels != null
                    && userModels != default(UserModels)
                    && userModels.UserCD.Equals(Constant.MUSER_USER_CD_ADMIN))
                {
                    this.SetFocusId(PASSWORD_ID_CONTROL);
                }

                if (!gmModel.chk_AllWarehouse)
                {
                    this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + 1);
                }
                
            }
            return View(SCREEN_DETAIL, gmModel);
        }

        #endregion

        #region Remove/Add rows

        /// <summary>
        /// Remove row comfirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult RemoveRowConfirm(UserModels gmModel)
        {
            //Clear model state
            this.ClearModelState();

            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            var listDelete = this.GetIndexCheckDelete(gmModel.delFlg);

            if (listDelete.Count == 0)
            {
                this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));

                this.SetFocusId(string.Format(DETAIL_CHECKBOX_ID,1));

                return View(SCREEN_DETAIL, gmModel);
            }
            if (listDelete.Count == gmModel.Detail.Count)
            {
                gmModel.chk_DeleteAll = true;
            }
            else
            {
                gmModel.chk_DeleteAll = false;
            }
            //Show message confirm
            this.ShowMessageConfirm(gmModel.SeqNum, "/User/RemoveRowAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0036), value1: gmModel.SeqNum.ToString());

            return View(SCREEN_DETAIL, gmModel);
        }

        /// <summary>
        /// Delete a row
        /// </summary>
        /// <param name="value1">Sequen Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult RemoveRowAction(string value1)
        {
            ////Clear ModelState
            //this.ClearModelState();

            UserModels gmModel = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            UserModels newModel = new UserModels();
            newModel.UserCD = gmModel.UserCD;
            newModel.LoginID = gmModel.LoginID;
            newModel.UserFullName = gmModel.UserFullName;
            newModel.UserShortName = gmModel.UserShortName;
            newModel.Password = gmModel.Password;
            newModel.ConfirmPassword = gmModel.ConfirmPassword;
            newModel.GroupCD = gmModel.GroupCD;
            newModel.GroupNm = gmModel.GroupNm;
            newModel.CustomerCD = MCustomer.FixCodeDB(gmModel.CustomerCD);
            newModel.CustomerName = gmModel.CustomerName;
            newModel.DeleteFlag = gmModel.DeleteFlag;
            newModel.UpdateDate = gmModel.UpdateDate;
            newModel.UpdateUCD = gmModel.UpdateUCD;
            newModel.PreUserCD = gmModel.PreUserCD;
            newModel.chk_DeleteAll = false;
            newModel.SeqNum = gmModel.SeqNum;


            //Get list delete
            Hashtable listDelete = this.GetIndexCheckDelete(gmModel.delFlg);

            if (listDelete.Count == gmModel.Detail.Count)
            {
                //Add empty rows 
                this.AddEmtyRows(newModel, ROWNUMBER_DEFAULT);
                this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

                //Set focus
                this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + 1);
                return View(SCREEN_DETAIL, newModel);
            }

            Hashtable listKeySession = new Hashtable();
            int index = 0;
            for (int i = 0; i < gmModel.Detail.Count; i++)
            {
                if (!listDelete.ContainsKey((i + 1)))
                {

                    newModel.Detail.Add(gmModel.Detail[i]);
                    newModel.Detail[index].NumRow = index + 1;
                    index++;
                }
            }
            if (newModel.Detail.Count == 0)
            {

                //Add empty rows 
                this.AddEmtyRows(newModel, ROWNUMBER_DEFAULT);
                this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

                //Set focus
                this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + 1);

                return View(SCREEN_DETAIL, newModel);
            }

            //Add empty rows
            int rowsAddNum = ROWNUMBER_DEFAULT - newModel.Detail.Count();
            this.AddEmtyRows(newModel, rowsAddNum);

            //Set focus
            this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + 1);

            //Add store
            listDelete.Clear();
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

            return View(SCREEN_DETAIL, newModel);
        }

        /// <summary>
        /// Add rows
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Add(UserModels gmModel)
        {
            this.ClearModelState();
            //Add an empty row 
            this.AddEmtyRows(gmModel, 1);


            gmModel.chk_DeleteAll = false;
            //Store session
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            //set focus
            this.SetFocusId(DETAIL_WAREHOUSE_CD_ID + gmModel.Detail.Count);

            return View(SCREEN_DETAIL, gmModel);
        }

        #endregion

        #region Ajax

        /// <summary>
        /// Show Group Name
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>Category Name</returns>
        [HttpPost]
        public string ShowGroupNm(string GroupCD)
        {
            if (string.IsNullOrEmpty(GroupCD))
            {
                return string.Empty;
            }

            string ret = string.Empty;
            MGroup_H model = this.mGroup_HService.GetActiveByPK(GroupCD);
            if (model != default(MGroup_H))
            {
                ret = model.GroupName;

                if (model.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
                {
                    ret = string.Empty;
                }
            }
            return ret;
        }

        /// <summary>
        /// Show CustomerName
        /// </summary>
        /// <param name="CustomerCD">CustomerCD</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowCustomerNm(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);
            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.CustomerName,
                        model.Address1,
                        model.Address2,
                        model.Address3
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show WarehouseName
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowWarehouseName(string WarehouseCD)
        {
            if (string.IsNullOrEmpty(WarehouseCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            WarehouseModels model = this.mWarehouseService.GetByCd(WarehouseCD);

            if (model != default(WarehouseModels) && !model.DeleteFlag)
            {
                return Json(new List<string>(){ model.WarehouseName}, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Getting

        /// <summary>
        /// Add empty rows 
        /// </summary>
        /// <param name="gmodel">MoveIndicationMain</param>
        /// <param name="rowsNum">Number of rows</param>
        /// <param name="SeqNum">Sequense Num</param>
        private void AddEmtyRows(UserModels gmodel, int rowsNum)
        {
            for (int i = 0; i < rowsNum; i++)
            {
                WarehouseByUserGrid item = new WarehouseByUserGrid();

                item.NumRow = gmodel.Detail == null ? i + 1 : gmodel.Detail.Count + 1;
                item.txt_WarehouseCD = string.Empty;
                item.txt_WarehouseName = string.Empty;

                gmodel.Detail.Add(item);
            }
        }

        /// <summary>
        /// Get index delete check
        /// </summary>
        /// <param name="delFlgs"></param>
        /// <returns></returns>
        private Hashtable GetIndexCheckDelete(string delFlgs)
        {
            Hashtable listDelete = new Hashtable();
            for (int i = 0; i < delFlgs.Length; i++)
            {
                if (delFlgs.ElementAt(i).ToString().Equals("1"))
                {
                    listDelete.Add(i + 1, true);
                }
            }
            return listDelete;
        }

        /// <summary>
        /// Get NumRow for Grid Detail 
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        private void GetNumRow(UserModels gmModel)
        {
            int num = 1;
            foreach (WarehouseByUserGrid row in gmModel.Detail)
            {
                row.NumRow = num++;
            }
            if (gmModel.Detail.Count < ROWNUMBER_DEFAULT)
            {
                //Add empty rows 
                this.AddEmtyRows(gmModel, ROWNUMBER_DEFAULT - gmModel.Detail.Count);
            }
        }

        #endregion
        
        #region Check

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">User Master</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool InsertCheck(UserModels gmModel)
        {
            bool ret = true;

            //Check exist UserCD
            UserModels proModel = this.mUserService.GetByUserCd(gmModel.UserCD);
            if (proModel != default(UserModels))
            {
                if (proModel.DeleteFlag)
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0006));
                    this.ModelState.AddModelError(USER_CD_CONTROL, message);
                }
                else
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0006));
                    this.ModelState.AddModelError(USER_CD_CONTROL, message);
                }
                ret = false;
            }

            //Check Exist LoginID    
            UserModels proModel_ID = this.mUserService.GetUserByLoginID(gmModel.LoginID);
            if (proModel_ID != default(UserModels))
            {
                if (proModel_ID.DeleteFlag)
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0009));
                    this.ModelState.AddModelError(LOGIN_ID_CONTROL, message);
                }
                else
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0009));
                    this.ModelState.AddModelError(LOGIN_ID_CONTROL, message);
                }
                ret = false;
            }

            //check GroupCD
            MGroup_H mGroup_H = this.mGroup_HService.GetActiveByPK(gmModel.GroupCD);
            if (mGroup_H == default(MGroup_H))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0181));
                this.ModelState.AddModelError(GROUP_CD_CONTROL, message);
                ret = false;
            }
            // Only User Supper Admin
            else if (mGroup_H.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                // エラーメッセージを返す: {0}はデータベースに存在しています。
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0181));
                this.ModelState.AddModelError(GROUP_CD_CONTROL, message);
                ret = false;
            }
            
            //Set group name
            gmModel.GroupNm = string.Empty;
            if (mGroup_H != default(MGroup_H) && !mGroup_H.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                gmModel.GroupNm = mGroup_H.GroupName;
            }

            //Check Exist Customer
            if (!string.IsNullOrEmpty(gmModel.CustomerCD))
            {
                CustomerModels modelC = this.mCustomerService.GetByCd(gmModel.CustomerCD);
                gmModel.CustomerName = string.Empty;
                if (modelC == default(CustomerModels) || modelC.DeleteFlag)
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                    this.ModelState.AddModelError(CUSTOMER_CD_CONTROL, message);
                    ret = false;
                }
                else
                {
                    gmModel.CustomerName = modelC.CustomerName;
                }
            }

            //Check List Warehouse of User
            if (!gmModel.chk_AllWarehouse && UserSession.Session.WareHouseMode == WareHouseMode.Multiple)
            {
                if (!WarehouseCheck(gmModel.Detail))
                {
                    ret = false;
                }
            }

            return ret;
        }

        /// <summary>
        /// Warehouse Of User Check
        /// </summary>
        /// <param name="listDetail">List WarehouseByUserGrid</param>
        /// <returns></returns>
        private bool WarehouseCheck(List<WarehouseByUserGrid> listDetail)
        {
            bool ret = true;
            List<string> listWarehouseCD = new List<string>();
            for (int i = 0; i < listDetail.Count; i++)
            {
                if (string.IsNullOrEmpty(listDetail[i].txt_WarehouseCD))
                {
                    continue;
                }
                WarehouseModels model = this.mWarehouseService.GetByCd(listDetail[i].txt_WarehouseCD);
                if (model == default(WarehouseModels) || model.DeleteFlag)
                {
                    listDetail[i].txt_WarehouseName = string.Empty;
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0058));
                    this.ModelState.AddModelError(string.Format(DETAIL_WAREHOUSE_CD_CONTROL, i + 1), message);
                    ret = false;
                }
                else
                {
                    listDetail[i].txt_WarehouseName = model.WarehouseName;
                }

                //Check Duplicate
                if (!listWarehouseCD.Contains(listDetail[i].txt_WarehouseCD))
                {
                    listWarehouseCD.Add(listDetail[i].txt_WarehouseCD);
                }
                else
                {
                    //Error Duplicate
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_E0019, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0058));
                    this.ModelState.AddModelError(string.Format(DETAIL_WAREHOUSE_CD_CONTROL, i + 1), message);
                    ret = false;
                }
            }
            if (listWarehouseCD.Count == 0)
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0058));
                this.ModelState.AddModelError(string.Format(DETAIL_WAREHOUSE_CD_CONTROL, 1), message);
                ret = false;

            }
            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">screen model</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool UpdateCheck(UserModels gmModel)
        {
            bool ret = true;

            //Check exist UserCD
            UserModels proModel = this.mUserService.GetByUserCd(gmModel.UserCD);
            string loginId = string.Empty;
            if (proModel != default(UserModels))
            {
                loginId = proModel.LoginID;
            }

            //Check Exist LoginID    
            UserModels proModel_ID = this.mUserService.GetUserByLoginID(gmModel.LoginID);
            if (proModel_ID != default(UserModels) && loginId != proModel_ID.LoginID)
            {
                if (proModel_ID.DeleteFlag)
                {
                    // エラーメッセージを返す:{0}は削除されたコードです。
                    string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0009));
                    this.ModelState.AddModelError(LOGIN_ID_CONTROL, message);
                }
                else
                {
                    // エラーメッセージを返す:{0}はデータベースに存在しています。
                    string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0009));
                    this.ModelState.AddModelError(LOGIN_ID_CONTROL, message);
                }
                ret = false;
            }

            //check GroupCD
            MGroup_H mGroup_H = this.mGroup_HService.GetActiveByPK(gmModel.GroupCD);
            if (mGroup_H == default(MGroup_H))
            {
                // エラーメッセージを返す: {0}はデータベースに存在しています。
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0181));
                this.ModelState.AddModelError(GROUP_CD_CONTROL, message);
                ret = false;
            }
            else if (gmModel.UserCD != Constant.MUSER_USER_CD_ADMIN && mGroup_H.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                // エラーメッセージを返す: {0}はデータベースに存在しています。
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0181));
                this.ModelState.AddModelError(GROUP_CD_CONTROL, message);
                ret = false;
            }

            //Set group name
            gmModel.GroupNm = string.Empty;
            if (mGroup_H != default(MGroup_H) && !mGroup_H.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                gmModel.GroupNm = mGroup_H.GroupName;
            }

            //Check Exist Customer
            if (!string.IsNullOrEmpty(gmModel.CustomerCD))
            {
                CustomerModels modelC = this.mCustomerService.GetByCd(gmModel.CustomerCD);
                gmModel.CustomerName = string.Empty;
                if (modelC == default(CustomerModels) || modelC.DeleteFlag)
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                    this.ModelState.AddModelError(CUSTOMER_CD_CONTROL, message);
                    ret = false;
                }
                else
                {
                    gmModel.CustomerName = modelC.CustomerName;
                }
            }
            if (!gmModel.chk_AllWarehouse && UserSession.Session.WareHouseMode == WareHouseMode.Multiple && gmModel.UserCD != Constant.MUSER_USER_CD_ADMIN)
            {
                if (!WarehouseCheck(gmModel.Detail))
                {
                    ret = false;
                }
            }

            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">UserModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(UserModels gmModel)
        {
            gmModel.UserCD = gmModel.UserCD;
            bool exist = this.mUserService.CheckDataChanged(gmModel);
            if (exist)
            {
                //Show error Message
                this.ShowMessageExclusion("/User/Show", gmModel.UserCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion

        #region Registration

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">User Master</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag InsertData(UserModels gmModel)
        {
            //Get insert model
            string curDate = this.GetCurrentDate();
            MUser model = this.GetInsertData(gmModel, curDate);

            try
            {
                this.mUserService.Insert(model);

                //Insert List Warehouse Of User
                if (!gmModel.chk_AllWarehouse)
                {
                    List<MWarehouseByUser> listWarehouseByUser = new List<MWarehouseByUser>();
                    foreach (WarehouseByUserGrid row in gmModel.Detail)
                    {
                        if (string.IsNullOrEmpty(row.txt_WarehouseCD))
                        {
                            continue;
                        }
                        MWarehouseByUser model_WarehouseByUser = new MWarehouseByUser();
                        model_WarehouseByUser.UserCD = model.UserCD;
                        model_WarehouseByUser.WarehouseCD = row.txt_WarehouseCD;
                        model_WarehouseByUser.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                        model_WarehouseByUser.CreateDate = curDate;
                        model_WarehouseByUser.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                        model_WarehouseByUser.UpdateDate = curDate;
                        listWarehouseByUser.Add(model_WarehouseByUser);
                    }
                    this.mWarehouseByUserService.Insert(listWarehouseByUser);
                }
                this.mUserService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MUser_PK)
                    || sqlEx.Message.Contains(Constant.DB_MUser_UN)
                    || sqlEx.Message.Contains(Constant.DB_MWAREHOUSEBYUSER_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get insert Data
        /// </summary>
        /// <param name="gmModel">User Master</param>
        /// <returns>TUser</returns>
        private MUser GetInsertData(UserModels gmModel, string curDate)
        {
            MUser result = new MUser();

            result.UserCD = gmModel.UserCD;
            result.LoginID = gmModel.LoginID;
            result.GroupCD = gmModel.GroupCD;
            result.CustomerCD = MCustomer.FixCodeDB(gmModel.CustomerCD);
            result.UserFullName = gmModel.UserFullName;
            result.UserShortName = gmModel.UserShortName;
            result.Password = Security.Encrypt(gmModel.Password);
            result.DeleteFlag = false;
            result.CreateDate = curDate;
            result.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            result.UpdateUCD = result.CreateUCD;
            result.UpdateDate = result.CreateDate;

            return result;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">Screen model</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag UpdateData(UserModels gmModel)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                MUser data = this.mUserService.GetByCdAndUpDate(gmModel.PreUserCD, gmModel.UpdateDate);
                if (data == default(MUser))
                {
                    return CommitFlag.DataChanged;
                }

                this.SetUpdateData(data, gmModel, curDate);

                //Delete List Warehouse(Old) By User
                
                List<MWarehouseByUser> listDetail = this.mWarehouseByUserService.GetListByUserCD(data.UserCD);
                if (listDetail.Count > 0)
                {
                    this.mWarehouseByUserService.Delete(listDetail);
                }

                //Insert List Warehouse By User
                if (!gmModel.chk_AllWarehouse)
                {
                    List<MWarehouseByUser> listWarehouseByUser = new List<MWarehouseByUser>();
                    foreach (WarehouseByUserGrid row in gmModel.Detail)
                    {
                        if (string.IsNullOrEmpty(row.txt_WarehouseCD))
                        {
                            continue;
                        }
                        MWarehouseByUser model_WarehouseByUser = new MWarehouseByUser();
                        model_WarehouseByUser.UserCD = data.UserCD;
                        model_WarehouseByUser.WarehouseCD = row.txt_WarehouseCD;
                        model_WarehouseByUser.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                        model_WarehouseByUser.CreateDate = curDate;
                        model_WarehouseByUser.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                        model_WarehouseByUser.UpdateDate = curDate;
                        listWarehouseByUser.Add(model_WarehouseByUser);
                    }
                    this.mWarehouseByUserService.Insert(listWarehouseByUser);
                }
                mUserService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MUser_PK)
                    || sqlEx.Message.Contains(Constant.DB_MUser_UN)
                    || sqlEx.Message.Contains(Constant.DB_MWAREHOUSEBYUSER_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set update data
        /// </summary>
        /// <param name="user">MUser model</param>
        /// <param name="gmModel">screen model</param>
        /// <param name="curDate"></param>
        private void SetUpdateData(MUser user, UserModels gmModel, string curDate)
        {
            user.LoginID = gmModel.LoginID;
            user.UserFullName = gmModel.UserFullName;
            user.UserShortName = gmModel.UserShortName;
            user.Password = Security.Encrypt(gmModel.Password);
            user.GroupCD = gmModel.GroupCD;
            user.CustomerCD = MCustomer.FixCodeDB(gmModel.CustomerCD);
            user.UpdateDate = curDate;
            user.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            user.DeleteFlag = gmModel.DeleteFlag;
        }


        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="model">User model</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag DeleteData(UserModels model)
        {
            try
            {
                //Get data from database
                MUser user = this.mUserService.GetByCdAndUpDate(model.PreUserCD, model.UpdateDate);

                //Empty data
                if (user == null)
                {
                    return CommitFlag.DataChanged;
                }

                //Set delete data
                this.SetDeleteData(user);

                this.mUserService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MUser_PK) || sqlEx.Message.Contains(Constant.DB_MUser_UN))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="user">TUser model</param>
        private void SetDeleteData(MUser user)
        {
            user.DeleteFlag = true;
            user.UpdateDate = this.GetCurrentDate();
            user.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }


        #endregion

        #region Private Methods

        /// <summary>
        /// Exclusion Processing
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set message exclusion
            ShowMessageExclusion("/User/Index");

            UserModels model = (UserModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(UserModels))
            {
                model = new UserModels();
                model.SeqNum = SeqNum;
            }

            return View(SCREEN_DETAIL, model);
        }

      
        #endregion

    }
}

﻿using System;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Common;
using InventoryManagement.DataAccess;
using InventoryManagement.Models;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using System.Transactions;
using System.Collections.Generic;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Goods Receipt Inspection Controller
    /// Author: ISV-HUNG (+ GIAM)
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class GoodsReceiptInspectionController : BaseController
    {
        #region Common

        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private DataAccess.TReserveService tReserveService; 

        /// <summary>
        /// Constructor
        /// </summary>
        public GoodsReceiptInspectionController( TInventory_HService tInventory_HService,
                                                 TInventory_DService tInventory_DService,
                                                 TSequencesService tSequencesService,
                                                 TBalanceInStoresService tBalanceInStoresService,
                                                 MLocationService mLocationService,
                                                 TShippingInstructionService tShippingInstructionService,
                                                 TPessimisticLockService tPessimisticLockService,
                                                 TReserveService tReserveService)
        {
            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.tSequencesService = tSequencesService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.mLocationService = mLocationService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.tReserveService = tReserveService;
            
            //User single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tInventory_HService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.mLocationService.Context = ctx;
            this.tShippingInstructionService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.tReserveService.Context = ctx;
        }

        #endregion

        #region Constant

        private const string KEY_LOCATIONCD = "txt_LocationCD";
        private const string KEY_TAGNO = "txt_TagNo";
        private const string BTN_INSERT = "btnInsert";

        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(string SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_GOODS_RECEIPT_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //Init display
            GoodsReceiptInspectionModels gmModel = new GoodsReceiptInspectionModels();
            if (string.IsNullOrEmpty(SeqNum))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }
            else
            {
                gmModel.SeqNum = int.Parse(SeqNum);
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + gmModel.SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0107);

            //Set mode state
            this.SetMode(Common.Mode.Insert, gmModel.SeqNum);
            gmModel.txt_StoredDate = DateTime.Now.ToString(Constant.FMT_DATE);

            ViewBag.ShowLocate = true;
            this.SetFocusId(KEY_LOCATIONCD);

            //Set focus
            return View("Index", gmModel);
        }

        #endregion

        #region Insert

        /// <summary>
        /// TagNo Picking
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult LocatePicking(GoodsReceiptInspectionModels gmModel)
        {
            //GoodsReceiptInspectionModels newModel = new GoodsReceiptInspectionModels();
            //newModel.SeqNum = gmModel.SeqNum;
            //newModel.txt_StoredDate = gmModel.txt_StoredDate;
            //newModel.txt_LocationCD = gmModel.txt_LocationCD;
            //gmModel = newModel;

            ViewBag.ShowLocate = true;
            if (this.ModelState.IsValid)
            {
                if (!this.LocationCheck(ref gmModel))
                {
                    this.SetFocusId(KEY_LOCATIONCD);
                }
                else
                {
                    ViewBag.ShowLocate = false;
                    this.SetFocusId(KEY_TAGNO);                     
                }
            }

            return View("Index", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(GoodsReceiptInspectionModels gmModel)
        {

            ViewBag.ShowLocate = false;
            if (this.ModelState.IsValid)
            {
                if (!this.LocationCheck(ref gmModel))
                {
                    GoodsReceiptInspectionModels newModel = new GoodsReceiptInspectionModels();
                    newModel.SeqNum = gmModel.SeqNum;
                    newModel.txt_StoredDate = gmModel.txt_StoredDate;
                    //newModel.txt_LocationCD = gmModel.txt_LocationCD;
                    gmModel = newModel;
                    ViewBag.ShowLocate = true;

                    return View("Index", gmModel);
                }

                if (this.TagInfoCheck(ref gmModel))
                {
                    //Store model to Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Set Message Confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/GoodsReceiptInspection/InsertAction", value1: gmModel.SeqNum.ToString());
                }
                else 
                {
                    gmModel.txt_TagNo = string.Empty;
                }
            }
            return View("Index", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// public ActionResult InsertAction(int value1)
        /// </summary>
        /// <param name="value1">sequence number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertAction(GoodsReceiptInspectionModels gmModel)
        {
            ViewBag.ShowLocate = false;
            if (!this.ModelState.IsValid)
            {
                return View("Index", gmModel);
            }
            //Get data from session
            //GoodsReceiptInspectionModels gmModel = (GoodsReceiptInspectionModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];
            if (!this.LocationCheck(ref gmModel))
            {
                GoodsReceiptInspectionModels newModel = new GoodsReceiptInspectionModels();
                newModel.SeqNum = gmModel.SeqNum;
                newModel.txt_StoredDate = gmModel.txt_StoredDate;
                //newModel.txt_LocationCD = gmModel.txt_LocationCD;
                gmModel = newModel;
                ViewBag.ShowLocate = true;

                return View("Index", gmModel);
            }


            if (!TagInfoCheck(ref gmModel))
            {
                gmModel.txt_TagNo = string.Empty;
                return View("Index", gmModel);
            }

            //insert data
            ActionResult ret = default(ActionResult);
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0003));
                    ret = View("Index", gmModel);
                    break;

                case CommitFlag.Success:
                    //this.Session[Constant.SESSION_TITLE + value1] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0108);
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = null;
                    this.ShowMessageInfo(this.FormatMessage(Constant.MES_M0024));

                    //Set Exclusion message
                    ret = View("Index", gmModel);
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0009));
                    ret = InsertConfirm(gmModel);
                    break;
            }
            return ret;
        }


        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(GoodsReceiptInspectionModels gmModel)
        {
            return RedirectToAction("Menu", "Menu");
        }

        #endregion

        #region Check

        /// <summary>
        /// TagInfo Check
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspection Models</param>
        /// <returns></returns>
        private bool TagInfoCheck(ref GoodsReceiptInspectionModels gmModel)
        {
            gmModel.txt_LocationCD = gmModel.txt_LocationCD.ToUpper(); 
            if (string.IsNullOrEmpty(gmModel.txt_TagNo))
            {
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            string tagNo = string.Empty;
            int branchTagNo = 0;

            //Get info TagNo
            if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
            {
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            //Check exist tagno
            TInventory_D idModel = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
            TInventory_H iHModel = this.tInventory_HService.GetByPK(tagNo);
            if (idModel == default(TInventory_D) || iHModel == default(TInventory_H) || iHModel.DeleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            GoodsReceiptInspectionModels model = this.tInventory_HService.GetForReceipt(tagNo, branchTagNo);
            model.txt_StoredDate = DateTime.Now.ToString(Constant.FMT_DATE);
            model.txt_LocationCD = gmModel.txt_LocationCD;
            model.SeqNum = gmModel.SeqNum;
            gmModel = model;

            //Delivery status
            if (idModel.StockStatus == Constant.STOCK_STATUS_DELIVERY || idModel.StockStatus == Constant.STOCK_STATUS_DELIVERY_DEFECTIVE || idModel.StockStatus == Constant.STOCK_STATUS_DELIVERY_SCRAP)
            {
                string message = this.FormatMessage(Constant.MES_M0046);
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            //Check only receipt or issue cancel
            if (idModel.StockStatus != Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE && idModel.StockStatus != Constant.STOCK_STATUS_ISSUE
                && idModel.StockStatus != Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE && idModel.StockStatus != Constant.STOCK_STATUS_ISSUE_DEFECTIVE && idModel.StockStatus != Constant.STOCK_STATUS_ISSUE_SCRAP)
            {
                string message = this.FormatMessage(Constant.MES_M0049);
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            //Check issue cancel
            if (idModel.StockStatus != Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE && idModel.LocationCD.Equals(gmModel.txt_LocationCD))
            {
                if (this.tInventory_DService.IsExistShipDelivery(idModel.ShippingNo))
                {
                    string message = this.FormatMessage(Constant.MES_M0049);
                    this.ModelState.AddModelError(KEY_TAGNO, message);
                    return false;
                }
            }

            // Check receipt correct location
            if (idModel.StockStatus == Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
            {
                if (!String.IsNullOrEmpty(idModel.LocationCD) && !idModel.LocationCD.Equals(gmModel.txt_LocationCD))
                {
                    string message = this.FormatMessage(Constant.MES_E0022);
                    this.ModelState.AddModelError(KEY_TAGNO, message);
                    return false;
                }

                MLocation locationModel = this.mLocationService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCD);
                if (locationModel.ReceiptProhibitionFlag)
                {
                    string message = this.FormatMessage(Constant.MES_M0017);
                    this.ModelState.AddModelError(KEY_TAGNO, message);
                    return false;
                }
            }

            //Check issue cancel
            if (idModel.StockStatus == Constant.STOCK_STATUS_ISSUE && !idModel.LocationCD.Equals(gmModel.txt_LocationCD))
            {
                string message = this.FormatMessage(Constant.MES_E0022);
                this.ModelState.AddModelError(KEY_TAGNO, message);
                return false;
            }

            //Check Move
            if (idModel.StockStatus == Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE || idModel.StockStatus == Constant.STOCK_STATUS_ISSUE_DEFECTIVE || idModel.StockStatus == Constant.STOCK_STATUS_ISSUE_SCRAP)
            {
                TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(idModel.ShippingNo);
                //Check move cancel
                if (gmModel.txt_LocationCD.Equals(idModel.LocationCD))
                {
                    //Check move location cancel
                    if (!String.IsNullOrEmpty(shipH.DestinationLocationCD) && shipH != default(TShippingInstruction) && shipH.ShippingCompleteFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0017);
                        this.ModelState.AddModelError(KEY_TAGNO, message);
                        return false;
                    }
                }
                //Move to destination location
                else if (gmModel.txt_LocationCD.Equals(shipH.DestinationLocationCD) && !shipH.PickingCompleteFlag)
                {
                    string message = this.FormatMessage(Constant.MES_M0084);
                    this.ModelState.AddModelError(KEY_TAGNO, message);
                    return false;
                }
                //isn't cancel or move to destination
                else if (!gmModel.txt_LocationCD.Equals(shipH.DestinationLocationCD))
                {
                    string message = this.FormatMessage(Constant.MES_E0022);
                    this.ModelState.AddModelError(KEY_TAGNO, message);
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Location Check
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool LocationCheck(ref GoodsReceiptInspectionModels gmModel)
        {
            //Check required LocationCD
            if (string.IsNullOrEmpty(gmModel.txt_LocationCD))
            {
                gmModel.txt_LocationCD = string.Empty;
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                this.ModelState.AddModelError(KEY_LOCATIONCD, message);
                return false;
            }

            gmModel.txt_LocationCD = gmModel.txt_LocationCD.ToUpper();

            //Check exists in database
            if (!this.mLocationService.Exist(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCD))
            {
                gmModel.txt_LocationCD = string.Empty;
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                this.ModelState.AddModelError(KEY_LOCATIONCD, message);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {
            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                return false;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                return false;
            }

            tagNo = array[0];
            return true;
        }

        #endregion

        #region Registration

        /// <summary>
        /// Issue cancel
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <param name="modelD">TInventory_D</param>
        /// <param name="curDate">CurrentDate</param>
        private void IssueCancelData(GoodsReceiptInspectionModels gmModel, TInventory_D modelD, string curDate)
        {
            //Upadate RemainQuantity in TReserve
            TReserve reserveModel = this.tReserveService.GetForUpdate(modelD.ShippingNo, gmModel.txt_TagNo.Substring(0, 10), gmModel.txt_LocationCD);
            reserveModel.RemainQuantity = reserveModel.RemainQuantity + 1;
            this.tReserveService.Context.SubmitChanges();

            this.SubIssueCancel(gmModel, modelD, curDate);

            //Clear ShipNo
            modelD.ShippingNo = null;
            modelD.ShippingDetailNo = null;
        }

        /// <summary>
        /// Cancel Shipping
        /// Cancel Balance in store
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <param name="modelD">TInventory_D</param>
        /// <param name="curDate">current date</param>
        private void SubIssueCancel(GoodsReceiptInspectionModels gmModel, TInventory_D modelD, string curDate)
        {
            //Update TShippingInstruction            
            TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(modelD.ShippingNo);
            if (shipH.PickingCompleteFlag)
            {
                shipH.PickingCompleteFlag = false;
                shipH.UpdateDate = curDate;
                shipH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            }

            List<string> statusList = new List<string>() { Constant.BALANCE_STATUS_GOODS_ISSUE, Constant.BALANCE_STATUS_MOVE_ISSUE, Constant.BALANCE_STATUS_DISCARD_ISSUE };
            string balanceStatus = string.Empty;

            TBalanceInStores bisModel = this.tBalanceInStoresService.GetNewestData(modelD.TagNo, modelD.BranchTagNo, statusList);
            if (bisModel != default(TBalanceInStores))
            {
                switch (bisModel.BalanceStatus)
                {
                    case Constant.BALANCE_STATUS_DISCARD_ISSUE: //48
                        balanceStatus = Constant.BALANCE_STATUS_SCRAP_RECEIPT; //28
                        break;

                    case Constant.BALANCE_STATUS_MOVE_ISSUE: //44
                        balanceStatus = Constant.BALANCE_STATUS_MOVE_RECEIPT; //24
                        break;
                    default:
                        balanceStatus = Constant.BALANCE_STATUS_RECEIPT; //20
                        break;
                }
            }

            this.InsertBalance(gmModel, curDate, balanceStatus);
           
            this.tBalanceInStoresService.Context.SubmitChanges();
        }

        /// <summary>
        /// Insert Balance In Store
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <param name="curDate">CurrentDate</param>
        /// <param name="balanceStatus">balance Status</param>
        private void InsertBalance(GoodsReceiptInspectionModels gmModel, string curDate, string balanceStatus)
        {
            //Update TSequences
            //string MaxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

            TBalanceInStores bisModel = new TBalanceInStores();
            //bisModel.BalanceNo = MaxTagNo;
            bisModel.BalanceStatus = balanceStatus;
            bisModel.BalanceDate = DateTime.Now.ToString(Constant.FMT_YMD);
            bisModel.TagNo = gmModel.txt_TagNo.Substring(0, 10);
            bisModel.BranchTagNo = gmModel.hid_BranchTagNo;
            bisModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            bisModel.LocationCD = gmModel.txt_LocationCD;
            bisModel.CreateDate = curDate;
            bisModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            bisModel.UpdateDate = curDate;
            bisModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

            this.tBalanceInStoresService.Insert(bisModel);
            this.tBalanceInStoresService.Context.SubmitChanges();
        }

        /// <summary>
        /// Move Location
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <param name="modelD">TInventory_D</param>
        /// <param name="curDate">current date</param>
        private void MoveLocation(GoodsReceiptInspectionModels gmModel,TInventory_D modelD, string curDate)
        {
            string shipNo = modelD.ShippingNo;

            //Clear ShipNo
            modelD.ShippingNo = null;
            modelD.ShippingDetailNo = null;
            this.tInventory_DService.Context.SubmitChanges();

            //Insert balance
            this.InsertBalance(gmModel, curDate, Constant.BALANCE_STATUS_MOVE_RECEIPT);

            //Check move completed
            if (this.tInventory_DService.IsMoveLocationComplete(shipNo))
            {
                TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(shipNo);
                shipH.ShippingCompleteFlag = true;
                shipH.UpdateDate = curDate;
                shipH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            }
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">GoodsReceiptInspectionModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(GoodsReceiptInspectionModels gmModel)
        {
            string curDate = this.GetCurrentDate();
            //Begin trans
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    string tagNo = gmModel.txt_TagNo.Substring(0, 10);
                    //Insert TagNo into TPessimisticLock
                    TPessimisticLock pessLockModel = new TPessimisticLock();
                    pessLockModel.TagNo = tagNo;
                    this.tPessimisticLockService.Insert(pessLockModel);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Check data change
                    TInventory_D idModel = this.tInventory_DService.GetByPK(tagNo, gmModel.hid_BranchTagNo);
                    if (idModel == default(TInventory_D) || idModel.UpdateDate != gmModel.hid_UpdateDate)
                    {
                        return CommitFlag.DataChanged;
                    }

                    string StockStatus = Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE;
                    //Goods receipt
                    if (idModel.StockStatus == Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)
                    {
                        this.InsertBalance(gmModel, curDate, Constant.BALANCE_STATUS_RECEIPT);
                    }
                    // Normal Issue cancel
                    else if (idModel.StockStatus == Constant.STOCK_STATUS_ISSUE)
                    {
                        this.IssueCancelData(gmModel, idModel, curDate);
                    }
                    //Move
                    else
                    {
                        if (idModel.StockStatus == Constant.STOCK_STATUS_ISSUE_DEFECTIVE || idModel.StockStatus == Constant.STOCK_STATUS_ISSUE_SCRAP)
                        {
                            StockStatus = Constant.STOCK_STATUS_RECEIPT_DEFECTIVE;
                        }

                        //Cancel move
                        if (gmModel.txt_LocationCD.Equals(idModel.LocationCD))
                        {
                            this.SubIssueCancel(gmModel, idModel, curDate);
                        }
                        //Receipt destination location
                        else
                        {
                            this.MoveLocation(gmModel, idModel, curDate);
                        }
                    }

                    //Update Inventory detail
                    idModel.StockStatus = StockStatus;
                    idModel.LocationCD = gmModel.txt_LocationCD;
                    idModel.StoredDate = DateTime.Now.ToString(Constant.FMT_YMD);
                    idModel.PickingFlag = false;
                    idModel.UpdateDate = curDate;
                    idModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                    //Delete TagNo
                    this.tPessimisticLockService.Delete(pessLockModel);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //System.Threading.Thread.Sleep(5000);

                    //End trans in TPessimisticLock
                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;
        }

        #endregion
    }
}

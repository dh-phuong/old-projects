﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.iQueryable;
using System.Collections;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Web.Helpers;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Transactions;
using Microsoft.Reporting.WebForms;
using System.Drawing;
using System.IO;
using System.Data;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 出荷指示入力
    /// Author: ISV-HUNG
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class OutboundDeliveryIndicationController : BaseController
    {
        #region PDF

        //Detail table
        private DataTable dtMain = null;
        private DataTable dtDetail = null;
        private int count = 0;

        /// <summary>
        /// Enum Fields Datatable Main
        /// </summary>
        private enum FieldsMain
        {
            ShipNo = 0,
            Barcode,
            ShipDate,
            InstructDate,
            CustomerCD,
            CustomerName,
            ShippingCompleteFlag,
            DeliveryNumber,
            Address1,
            Address2,
            Address3,
            TotalPage
        }

        /// <summary>
        /// Enum Fields Datatable Detail(Sub)
        /// </summary>
        private enum FieldsDetail
        {
            ShipNo = 0,
            OrderNo,
            LocationCD,
            TagNo,
            ProductCD,
            ProductName,
            Lot1,
            Lot2,
            Lot3,
            Quantity,
            TotalLabel,
            RowCount,
        }

        #endregion

        #region Common

        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.TShippingInstructionDetailsService tShippingInstructionDetailService;
        private DataAccess.MProductService mProductService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TStockAllowanceService tStockAllowanceService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private DataAccess.MCompanyService mCompanyService;      
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;
        private int MaxRowDetail = 1;
        private int MaxQty = 1;
        private int rowNumDetail = 10;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tInventory_DService">TInventory_DService</param>
        /// <param name="tInventory_HService">TInventory_HService</param>
        /// <param name="mCustomerService">MCustomerService</param>
        /// <param name="tShippingInstructionService">TShippingInstructionService</param>
        /// <param name="tShippingInstructionDetailService">TShippingInstructionDetailsService</param>
        /// <param name="mProductService">MProductService</param>
        /// <param name="tSequencesService">TSequencesService</param>
        /// <param name="tStockAllowanceService">TStockAllowanceService</param>
        /// <param name="tReserveService">TReserveService</param>
        /// <param name="tPessimisticLockService">TPessimisticLockService</param>
        /// <param name="mCompanyService">MCompanyService</param>
        /// <param name="mWarehouseService">MWarehouseService</param>
        public OutboundDeliveryIndicationController(DataAccess.TInventory_DService tInventory_DService
                                            , DataAccess.TInventory_HService tInventory_HService
                                            , DataAccess.MCustomerService mCustomerService
                                            , DataAccess.TShippingInstructionService tShippingInstructionService
                                            , DataAccess.TShippingInstructionDetailsService tShippingInstructionDetailService
                                            , DataAccess.MProductService mProductService
                                            , DataAccess.TSequencesService tSequencesService
                                            , DataAccess.TStockAllowanceService tStockAllowanceService
                                            , DataAccess.TReserveService tReserveService
                                            , DataAccess.TPessimisticLockService tPessimisticLockService
                                            , DataAccess.MCompanyService mCompanyService
                                            , DataAccess.MWarehouseService mWarehouseService
                                            , DataAccess.MKind_DService mKind_DService)
        {
            this.tInventory_DService = tInventory_DService;
            this.tInventory_HService = tInventory_HService;
            this.mCustomerService = mCustomerService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.tShippingInstructionDetailService = tShippingInstructionDetailService;
            this.mProductService = mProductService;
            this.tSequencesService = tSequencesService;
            this.tStockAllowanceService = tStockAllowanceService;
            this.tReserveService = tReserveService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.mCompanyService = mCompanyService;
            this.mWarehouseService = mWarehouseService;
            this.mKind_DService = mKind_DService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tInventory_DService.Context = ctx;
            this.tInventory_HService.Context = ctx;
            this.mCustomerService.Context = ctx;
            this.tShippingInstructionService.Context = ctx;
            this.tShippingInstructionDetailService.Context = ctx;
            this.mProductService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tStockAllowanceService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.mCompanyService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
            this.MaxRowDetail = this.mKind_DService.GetMaxRowAndQuantity(Constant.MKIND_DATACD_MAX_ROW_OB, 100);
            this.MaxQty = this.mKind_DService.GetMaxRowAndQuantity(Constant.MKIND_DATACD_MAX_QTY_OB, 1000);
            if (this.rowNumDetail > this.MaxRowDetail)
            {
                this.rowNumDetail = this.MaxRowDetail;
            }
        }

        #endregion

        #region Constant

        private const string KEY_SHIPDATE_DAYFROM = "ShipDate.Day";
        private const string KEY_SHIPDATE_DAYFROMID = "ShipDate_Day";
        private const string KEY_SHIPDATE = "ShipDate";
        private const string KEY_CUSTOMERCD = "txt_CustomerCD";
        private const string KEY_DELIVERYCD = "DeliveryNumber";
        private const string KEY_SHIPNO = "txt_ShipNo";
        private const string KEY_TAG_NO = "txt_TagNo";
        private const string KEY_RESERVE = "Results[{0}].Reserve";

        private const string CHK_FIRST_ROW = "checkFirst";
        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/OutboundDeliveryIndication/Sorting";

        private const string BUTTON_EDIT = "btnUpdate";
        private const string BUTTON_BACK = "btnBack";
        private const string SCREEN_INDEX = "Index";

        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_ARRIVALDATE = "ArrivalDate";
        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_LOT1 = "Lot1";
        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_LOT2 = "Lot2";
        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_LOT3 = "Lot3";
        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_STOREDDATE = "StoredDate";
        private const string SHIPPING_INSTRUCTION_DETAIL_SORT_TAGNO = "TagNo";

        private const int PAGE_SIZE_DETAIL = 5;

        //Print
        private const string PRINT_ACTION_URL = "/OutboundDeliveryIndication/PrintAction";
        private const string PDF_REPORTDATASOURCE_MAIN = "ShippingInstruction";
        private const string PDF_REPORTDATASOURCE_DETAIL = "SubShippingInstruction";
        private const int PDF_NUMBER_ROW_PER_FIRST_PAGE = 15;
        private const int PDF_NUMBER_ROW_PER_NEXT_PAGE = 20;
        private const string PDF_FILENAME = "OutboundDeliveryIndication_{0}.pdf";
        private const string PDF_PATH_MAIN_LOCALREPORT = "~/Report/ShippingInstruction.rdlc";
        private const string PDF_PATH_SUB_LOCALREPORT = "~/Report/SubShippingInstruction.rdlc";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(OutboundDeliveryIndicationList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(OutboundDeliveryIndicationList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                OutboundDeliveryIndicationList oldModel = (OutboundDeliveryIndicationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(OutboundDeliveryIndicationList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<OutboundDeliveryIndicationResults> results = this.tShippingInstructionService.GetListByCondition(gmModel);

                    //Restore Paging Sorting
                    this.RestorePagingSorting(gmModel.SeqNum, results);

                    //Focus
                    SetFocusId(KEY_SHIPNO);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Store Print Hastable
            this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()] = new Hashtable();

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<OutboundDeliveryIndicationResults> results = this.tShippingInstructionService.GetListByCondition(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<OutboundDeliveryIndicationResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(KEY_SHIPNO);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View("Index", gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            OutboundDeliveryIndicationList gmModel = new OutboundDeliveryIndicationList();

            //Get search result from session
            IQueryable<OutboundDeliveryIndicationResults> list = (IQueryable<OutboundDeliveryIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<OutboundDeliveryIndicationResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List", gmModel);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            OutboundDeliveryIndicationList gmModel = new OutboundDeliveryIndicationList();

            //Get search result from session
            IQueryable<OutboundDeliveryIndicationResults> list = (IQueryable<OutboundDeliveryIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<OutboundDeliveryIndicationResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List", gmModel);
        }

        #endregion

        #region Show

        /// <summary>
        /// View Detail
        /// </summary>
        /// <param name="value1">ShipNo</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0157);

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            OutboundDeliveryIndicationMain gmModel = new OutboundDeliveryIndicationMain();

            //Get data header
            OutboundDeliveryIndicationMain ret = tShippingInstructionService.GetHeaderResultsByShipNo(value1);

            //Check exclution
            if (ret == default(OutboundDeliveryIndicationMain))
            {
                return this.ExclusionProcess(value2);
            }

            //Show header
            gmModel.PreShipNo = value1;
            gmModel.PreShipNo = value1;
            gmModel.txt_ShipDate = @CommonUtil.ParseDate(ret.txt_ShipDate, Constant.FMT_YMD, Constant.FMT_DATE);
            gmModel.txt_CustomerCD = ret.txt_CustomerCD;
            gmModel.txt_CustomerName = ret.txt_CustomerName;
            gmModel.Address1 = ret.Address1;
            gmModel.Address2 = ret.Address2;
            gmModel.Address3 = ret.Address3;
            gmModel.DeliveryNumber = ret.DeliveryNumber;
            gmModel.Memo = ret.Memo;
            gmModel.WarehouseCD = ret.WarehouseCD;
            gmModel.UpdateDate = ret.UpdateDate;
            gmModel.DeleteFlag = ret.DeleteFlag;
            gmModel.MaxRowDetail = this.MaxRowDetail;
            ViewBag.DeleteFlag = ret.DeleteFlag;
            int total = 0;
            //Show details
            gmModel.Detail = this.tShippingInstructionDetailService.GetListByShipNo(value1).ToList();
            if (gmModel.Detail.Count() > 0)
            {
                for (int i = 0; i < gmModel.Detail.Count(); i++)
                {
                    gmModel.Detail[i].NumRow = i + 1;
                    gmModel.Detail[i].SeqNum = value2;
                    gmModel.Detail[i].preProductCD = gmModel.Detail[i].txt_ProductCD;
                    
                    int instructQuantity = 0;
                    if (CommonUtil.TryParseInt(gmModel.Detail[i].txt_InstructQuantity, ref instructQuantity))
                    {
                        gmModel.Detail[i].txt_InstructQuantity = instructQuantity.ToString();
                        if (CommonUtil.CheckScale(instructQuantity, 0))
                        {
                            gmModel.Detail[i].txt_InstructQuantity = string.Format(Constant.NUMBER_FORMAT_INT, instructQuantity);
                        }
                        total += instructQuantity;
                    }
                }
            }
            gmModel.TotalInstructQty = string.Format(Constant.NUMBER_FORMAT_INT, total);


            //Store data into session
            gmModel.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Details", gmModel);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0158);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(KEY_SHIPDATE_DAYFROMID);

            //Set display data
            OutboundDeliveryIndicationMain gmModel = new OutboundDeliveryIndicationMain();
            gmModel.ShipDate = new DateControl(DateTime.Now.ToString(Constant.FMT_YMD));
            gmModel.SeqNum = SeqNum;
            gmModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            gmModel.MaxRowDetail = this.MaxRowDetail;

            //Add empty rows 
            this.AddEmtyRows(gmModel, this.rowNumDetail, SeqNum);
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = gmModel;

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(OutboundDeliveryIndicationMain gmModel)
        {
            //Add number sequen for detail
            //gmModel.AddSeqForDetail();
            
            //Sort Error
            this.SortModelState(typeof(OutboundDeliveryIndicationMain));

            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        if (string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD))
                        {
                            continue;
                        }
                    }

                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveryIndication/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            OutboundDeliveryIndicationMain gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //Insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                case CommitFlag.InsertExclusion:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.ClearSession(gmModel);
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;

                    ret = RedirectToAction("Index");
                    break;
                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }
            return ret;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(OutboundDeliveryIndicationMain gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Clear ModelState
            this.ClearModelState();

            //Set ViewBag
            ViewBag.DeleteFlag = gmModel.DeleteFlag;

            if (DeleteCheck(gmModel))
            {
            
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveryIndication/DeleteAction", value1: gmModel.SeqNum.ToString());

                this.SetMode(Common.Mode.Show, gmModel.SeqNum);
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            OutboundDeliveryIndicationMain gModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            //Delete check
            string message = String.Empty;
            if (this.DeleteCheck(gModel))
            {
                //Delete data
                ActionResult ret = default(ActionResult);
                switch (this.DeleteData(gModel))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(gModel.PreShipNo, value1);
                        break;

                    case CommitFlag.IsExistsInAnotherTB:

                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0013));
                        ret = Show(gModel.PreShipNo, value1);
                        break;

                    case CommitFlag.Success:
                        this.ClearSession(gModel);
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0007);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(gModel.PreShipNo, value1);
                        break;
                }
                return ret;
            }
            else
            {
                return View("Details", gModel);
            }
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            OutboundDeliveryIndicationMain gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Get UpdateDate
            OutboundDeliveryIndicationMain ret = tShippingInstructionService.GetHeaderResultsByShipNo(gmModel.PreShipNo);

            //Check Exclusion
            if (ret == default(OutboundDeliveryIndicationMain) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Check picking data
            gmModel.CompleteFlag = ret.CompleteFlag;
            bool isPickingData = false;
            foreach (OutboundDeliveryIndicationDetailGrid item in gmModel.Detail)
            {
                if (this.tShippingInstructionDetailService.CheckPickingData(item.txt_ShipNo, item.txt_ShipNoDetail))
                {
                    item.IsPicked = true;
                    isPickingData = true;
                }
            }
            gmModel.IsPicked = isPickingData;

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0160);

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Add empty rows
            if (!gmModel.CompleteFlag)
            {
                int rowsAddNum = this.rowNumDetail - gmModel.Detail.Count();
                this.AddEmtyRows(gmModel, rowsAddNum, gmModel.SeqNum);
            }

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;
            string value = @CommonUtil.ParseDate(gmModel.txt_ShipDate, Constant.FMT_DATE, Constant.FMT_YMD);
            gmModel.ShipDate = new DateControl(value);
            gmModel.MaxRowDetail = this.MaxRowDetail;

            //Set focus
            this.SetFocusId(KEY_SHIPDATE_DAYFROMID);
            if (gmModel.CompleteFlag)
            {
                this.SetFocusId(KEY_DELIVERYCD);
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Update confirm
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(OutboundDeliveryIndicationMain gmModel)
        {
            //Addd number sequen for detail
            //gmModel.AddSeqForDetail();

            if (gmModel.CompleteFlag)
            {
                base.ClearModelStateByKey(KEY_SHIPDATE);
            }

            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveryIndication/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1"></param>
        /// <returns>ActionResult</returns>
        public ActionResult UpdateAction(string value1)
        {
            //Get data from session
            OutboundDeliveryIndicationMain gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update check
            if (this.UpdateCheck(gmModel))
            {
                //Update data
                string message = string.Empty;
                ActionResult ret = default(ActionResult);
                CommitFlag resultFlag = default(CommitFlag);
                if (gmModel.CompleteFlag)
                {
                    resultFlag = this.UpdateDataForComplete(gmModel);
                }
                else
                {
                    resultFlag = this.UpdateData(gmModel);
                }
                switch (resultFlag)
                {
                    case CommitFlag.DataChanged:
                        this.ShowMessageExclusion("/OutboundDeliveryIndication/Show", gmModel.PreShipNo, gmModel.SeqNum.ToString());
                        ret = View("Details", gmModel);
                        break;

                    case CommitFlag.Success:
                        this.ClearSession(gmModel);
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0011);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = UpdateConfirm(gmModel);
                        break;
                }
                return ret;
            }
            else
            {
                return View("Details", gmModel);
            }
        }

        #endregion

        #region Clear

        /// <summary>
        /// Clear confirm
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult ClearConfirm(OutboundDeliveryIndicationMain gmModel)
        {
            //Clear model state
            this.ClearModelState();

            //Show confirm message
            this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveryIndication/ClearAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0043), value1: gmModel.SeqNum.ToString());

            return View("Details", gmModel);
        }

        /// <summary>
        /// Clear Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult ClearAction(int value1)
        {
            //Set title
            this.Session[Constant.SESSION_TITLE + value1.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0158);

            //Set mode state
            this.SetMode(Common.Mode.Insert, value1);

            //Set focus
            this.SetFocusId(KEY_SHIPDATE_DAYFROMID);

            //Set data display
            OutboundDeliveryIndicationMain gmModel = new OutboundDeliveryIndicationMain();
            gmModel.ShipDate = new DateControl(DateTime.Now.ToString(Constant.FMT_YMD));
            gmModel.SeqNum = value1;
            gmModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            gmModel.MaxRowDetail = this.MaxRowDetail;

            //Add empty rows 
            this.AddEmtyRows(gmModel, this.rowNumDetail, value1);
            this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = gmModel;

            for (int i = 0; i < gmModel.Detail.Count(); i++)
            {
                string keySession = this.CreateKeySession(gmModel.Detail[i].NumRow.ToString(), gmModel.Detail[i].SeqNum.ToString());
                List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                if ((listViewDetail != default(List<OutboundDeliveryIndicationDetailResult>) && listViewDetail.Count != 0))
                {
                    this.Session[keySession] = null;
                }
            }
            return View("Details", gmModel);
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(OutboundDeliveryIndicationMain gmModel)
        {
            this.ClearModelState();
            //Clear sessiong detail
            this.ClearSession(gmModel);

            if (!String.IsNullOrEmpty(gmModel.PreShipNo) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreShipNo, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Restore Paging Sorting
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequense number</param>
        /// <param name="results">results</param>
        private void RestorePagingSorting(int SeqNum, IQueryable<OutboundDeliveryIndicationResults> results)
        {
            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];

            this.PagingBase<OutboundDeliveryIndicationResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        /// <summary>
        /// Add empty rows 
        /// </summary>
        /// <param name="gmodel">OutboundDeliveryIndicationDetail</param>
        /// <param name="rowsNum">Number of rows</param>
        /// <param name="SeqNum">Sequense Number</param>
        private void AddEmtyRows(OutboundDeliveryIndicationMain gmodel, int rowsNum, int SeqNum)
        {
            for (int i = 0; i < rowsNum; i++)
            {
                OutboundDeliveryIndicationDetailGrid item = new OutboundDeliveryIndicationDetailGrid();

                item.NumRow = gmodel.Detail.Count + 1;
                item.SeqNum = SeqNum;
                item.txt_ProductCD = string.Empty;
                item.txt_ProductName = string.Empty;
                item.txt_InstructQuantity = string.Empty;

                gmodel.Detail.Add(item);
            }
        }

        /// <summary>
        /// Clear Session
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        private void ClearSession(OutboundDeliveryIndicationMain gmModel)
        {
            for (int i = 0; i < gmModel.Detail.Count; i++)
            {
                string keySession = this.CreateKeySession(gmModel.Detail[i].NumRow.ToString(), gmModel.SeqNum.ToString());
                this.Session[keySession] = null;
            }
        }

        /// <summary>
        /// Get key session for detail
        /// </summary>
        /// <param name="numRow">Number of rows</param>
        /// <param name="seqNum">Sequense Number</param>
        /// <returns></returns>
        private string CreateKeySession(string numRow, string seqNum)
        {
            return string.Format("{0}_{1}_{2}", Constant.SESSION_SELECTED_ITEM, numRow, seqNum);
        }

        /// <summary>
        /// Get index delete check
        /// </summary>
        /// <param name="delFlgs"></param>
        /// <returns></returns>
        private Hashtable GetIndexCheckDelete(string delFlgs)
        {
            Hashtable listDelete = new Hashtable();
            for (int i = 0; i < delFlgs.Length; i++)
            {
                if (delFlgs.ElementAt(i).ToString().Equals("1"))
                {
                    listDelete.Add(i + 1, true);
                }
            }
            return listDelete;
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //set exclusion message
            this.ShowMessageExclusion("/OutboundDeliveryIndication/Index");

            OutboundDeliveryIndicationMain model = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            if (model == default(OutboundDeliveryIndicationMain))
            {
                model = new OutboundDeliveryIndicationMain();
                model.SeqNum = SeqNum;
            }
            return View("Details", model);
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(OutboundDeliveryIndicationMain gmModel)
        {
            //Check header
            if (!this.InsertCheckHeader(gmModel))
            {
                return false;
            }

            //Check detail
            if (!this.InsertCheckDetail(gmModel))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check header
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckHeader(OutboundDeliveryIndicationMain gmModel)
        {
            bool ret = true;

            string shipDate = gmModel.ShipDate.Year + gmModel.ShipDate.Month + gmModel.ShipDate.Day;
            int shipDateOut = 0;
            string nowDate = DateTime.Now.ToString(Constant.FMT_YMD);
            int nowDateOut = 0;
            int.TryParse(shipDate, out shipDateOut);
            int.TryParse(nowDate, out nowDateOut);

            //Check shipping data > now data
            if (shipDateOut < nowDateOut)
            {
                string message = this.FormatMessage(Constant.MES_E0005, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0164), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0147));
                this.ModelState.AddModelError(KEY_SHIPDATE_DAYFROM, message);
                ret = false;
            }

            //Check CustomerCD exist in Customer Master
            CustomerModels modelCustomer = this.mCustomerService.GetByCd(gmModel.txt_CustomerCD);
            gmModel.txt_CustomerName = string.Empty;
            if (modelCustomer == null)
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                this.ModelState.AddModelError(KEY_CUSTOMERCD, message);
                ret = false;
            }
            else
            {
                gmModel.txt_CustomerName = modelCustomer.CustomerName;
            }

            if (ret)
            {
                //check detail is empty
                bool notemptyProductCD = gmModel.Detail.Any(item => !string.IsNullOrEmpty(item.txt_ProductCD));

                if (!notemptyProductCD)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", 0), message);
                    ret = false;
                }
            }
            return ret;
        }

        /// <summary>
        /// Check detail
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckDetail(OutboundDeliveryIndicationMain gmModel)
        {
            bool ret = true;
            string shipNo = string.Empty;
            if ((Mode)this.Session[Constant.SESSION_STATE_MODE + gmModel.SeqNum.ToString()] == Mode.Update)
            {
                shipNo = gmModel.PreShipNo;
            }

            List<string> listDuplicate = new List<string>();

            //Get Sort Info
            var sortList = this.GetOrderList(gmModel.txt_CustomerCD);

            string focusErr = string.Empty;

            for (int i = 0; i < gmModel.Detail.Count(); i++)
            {
                if (gmModel.Detail[i].isEmptyRow())
                {
                    continue;
                }
                if (string.IsNullOrEmpty(focusErr))
                {
                    focusErr = string.Format("Detail[{0}].txt_InstructQuantity", i);
                }

                string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), i + 1);
                gmModel.Detail[i].txt_ProductCD = gmModel.Detail[i].txt_ProductCD.ToUpper();
                gmModel.Detail[i].txt_ProductName = string.Empty;

                //Check exist in Product Master
                ProductModels modelProduct = this.mProductService.GetByCd(gmModel.Detail[i].txt_ProductCD);
                if (modelProduct == null)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", i), message + row);
                    ret = false;
                }
                else
                {
                    gmModel.Detail[i].txt_ProductName = modelProduct.ProductName;
                    //Duplicate ProdcutCD
                    if (!listDuplicate.Contains(gmModel.Detail[i].txt_ProductCD.Trim()))
                    {
                        listDuplicate.Add(gmModel.Detail[i].txt_ProductCD.Trim());
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0019, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                        this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", i), message + row);
                        ret = false;
                        continue;
                    }

                    //Check product exist in stock
                    if (!this.tInventory_HService.ExistByProductCD(gmModel.Detail[i].txt_ProductCD, gmModel.PreShipNo))
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0051);
                        this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", i), message + row);
                        ret = false;
                    }
                    else
                    {

                        //Get data from session
                        string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                        int instrucionQty = 0;
                        CommonUtil.TryParseInt(gmModel.Detail[i].txt_InstructQuantity, ref instrucionQty);

                        List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                        //Create data detail
                        OutboundDeliveryIndicationDetail model = new OutboundDeliveryIndicationDetail();
                        model.txt_ProductCD = gmModel.Detail[i].txt_ProductCD;
                        model.SeqNum = gmModel.SeqNum;
                        model.ShipNo = gmModel.PreShipNo;
                        model.txt_CustomerCD = gmModel.txt_CustomerCD;

                        if (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>) || listViewDetail.Count == 0)
                        {
                            listViewDetail = this.CreateDataDetail(model, sortList).ToList();
                            gmModel.Detail[i].ViewDetail = listViewDetail;
                            gmModel.Detail[i].preProductCD = gmModel.Detail[i].txt_ProductCD;
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD) && !gmModel.Detail[i].txt_ProductCD.Equals(gmModel.Detail[i].preProductCD))
                            {
                                listViewDetail = this.CreateDataDetail(model, sortList).ToList();
                                gmModel.Detail[i].ViewDetail = listViewDetail;
                                gmModel.Detail[i].preProductCD = gmModel.Detail[i].txt_ProductCD;
                                this.Session[keySession] = null;
                            }
                            else
                            { 
                                List<OutboundDeliveryIndicationDetailResult> listViewDetailDB = this.CreateDataDetail(model, sortList).ToList();
                                for (int lv = 0; lv < listViewDetail.Count; lv++)
                                {
                                    var newItemDB = listViewDetailDB.Where(m => m.TagNo.Equals(listViewDetail[lv].TagNo) && m.LocationCD.Equals(listViewDetail[lv].LocationCD)).SingleOrDefault();
                                    if (newItemDB != null)
                                    {
                                        listViewDetail[lv].NumBoxes = newItemDB.NumBoxes;
                                        listViewDetail[lv].PickingQuantity = newItemDB.PickingQuantity;
                                    }
                                    else
                                    {
                                        listViewDetail[lv].NumBoxes = 0;
                                        listViewDetail[lv].PickingQuantity = 0;
                                    }
                                }
                            }

                        }

                        int totalPro = 0;
                        int valueReserve = 0;
                        foreach (OutboundDeliveryIndicationDetailResult item in listViewDetail.Where(m => !string.IsNullOrEmpty(m.Reserve)))
                        {
                            CommonUtil.TryParseInt(item.Reserve, ref valueReserve);
                            if (valueReserve > item.NumBoxes)
                            {
                                item.Reserve = item.NumBoxes == 0? string.Empty : item.NumBoxes.ToString();
                                valueReserve = item.NumBoxes;
                            }
                            totalPro += valueReserve;

                        }
                       if (totalPro != instrucionQty)
                       {
                            //Call form change quantity
                            listViewDetail = this.CreateDetail(gmModel.SeqNum, shipNo, gmModel.txt_CustomerCD, gmModel.Detail[i].txt_ProductCD, instrucionQty, listViewDetail.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList());
                            //this.Session[keySession] = listViewDetail;
                            gmModel.Detail[i].ViewDetail = listViewDetail;
                        }

                        //Check InstrucionQuantity < pickingQuantity
                        bool isError = false;
                        foreach (OutboundDeliveryIndicationDetailResult item in listViewDetail)
                        {
                            int reserveValue = 0;
                            CommonUtil.TryParseInt(item.Reserve, ref reserveValue);
                            if (reserveValue < item.PickingQuantity)
                            {
                                //Show error message
                                string message = this.FormatMessage(Constant.MES_M0051);
                                this.ModelState.AddModelError(string.Format("Detail[{0}].txt_InstructQuantity", i), message + row);
                                isError = true;
                                break;
                            }
                        }

                        //check InstructionQuantity > total in storck
                        int totalInStock = listViewDetail.Sum(m => m.NumBoxes);

                        if (instrucionQty > (totalInStock))
                        {
                            //Show error message
                            string message = this.FormatMessage(Constant.MES_M0051);
                            this.ModelState.AddModelError(string.Format("Detail[{0}].txt_InstructQuantity", i), message + row);
                            isError = true;
                        }

                        if (isError)
                        {
                            ret = false;
                        }
                        else
                        {
                            this.Session[keySession] = listViewDetail.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
                        }
                    }
                }
            }
            if (ret)
            {
                int temp = 0;
                if(CommonUtil.TryParseInt(gmModel.TotalInstructQty, ref temp))
                {
                    if (temp > this.MaxQty)
                    {
                        this.ModelState.AddModelError(focusErr, this.FormatMessage(Constant.MES_M0022, this.MaxQty.ToString(Constant.FMT_INTEGER)));
                        ret = false;
                    }

                }
            }
            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag InsertData(OutboundDeliveryIndicationMain gmModel)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    string curDate = this.GetCurrentDate();

                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        if (string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD))
                        {
                            continue;
                        }
                        string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                        List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                        if (listViewDetail == null || (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>)))
                        {
                            listViewDetail = gmModel.Detail[i].ViewDetail;
                        }
                        foreach (OutboundDeliveryIndicationDetailResult item in listViewDetail)
                        {
                            TPessimisticLock lockRecord = new TPessimisticLock();
                            lockRecord.TagNo = item.TagNo;
                            if (!listInsert.Any(m => m.TagNo.Equals(item.TagNo)))
                            {
                                listInsert.Add(lockRecord);
                            }
                        }
                    }
                    this.tPessimisticLockService.Insert(listInsert);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //TSequences
                    string newMaxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_SHIPNO, curDate.Substring(2, 4));

                    //Get insert model header
                    TShippingInstruction headerModel = new TShippingInstruction();
                    headerModel.ShipNo = newMaxTagNo;
                    headerModel.InstructDate = curDate.Substring(0, 8);
                    headerModel.ShipDate = gmModel.ShipDate.DateValue();
                    headerModel.CustomerCD = MCustomer.FixCodeDB(gmModel.txt_CustomerCD.ToUpper());
                    headerModel.Address1 = gmModel.Address1;
                    headerModel.Address2 = gmModel.Address2;
                    headerModel.Address3 = gmModel.Address3;
                    headerModel.DeliveryNumber = gmModel.DeliveryNumber;
                    headerModel.Memo = gmModel.Memo;
                    headerModel.WarehouseCD = gmModel.WarehouseCD;
                    headerModel.ShippingPrintFlag = false;
                    headerModel.PickingCompleteFlag = false;
                    headerModel.ShippingCompleteFlag = false;
                    headerModel.DeleteFlag = false;
                    headerModel.CreateDate = curDate;
                    headerModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    headerModel.UpdateDate = headerModel.CreateDate;
                    headerModel.UpdateUCD = headerModel.CreateUCD;

                    //Get insert model detail
                    List<TShippingInstructionDetails> listDetail = new List<TShippingInstructionDetails>();
                    List<TReserve> listUpdate = new List<TReserve>();

                    int detailNo = 0;
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        if (gmModel.Detail[i].isEmptyRow())
                        {
                            continue;
                        }

                        int valueInt = 0;
                        CommonUtil.TryParseInt(gmModel.Detail[i].txt_InstructQuantity, ref valueInt);
                        decimal valueDec = new decimal(valueInt);

                        TShippingInstructionDetails ret = new TShippingInstructionDetails();
                        ret.ShipNo = newMaxTagNo;
                        ret.ShipDetailNo = detailNo + 1;
                        ret.ProductCD = gmModel.Detail[i].txt_ProductCD;
                        ret.InstructQuantity = valueDec;

                        listDetail.Add(ret);

                        string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                        List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                        if (listViewDetail == null || (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>)))
                        {
                            listViewDetail = gmModel.Detail[i].ViewDetail;
                        }
                        for (int l = 0; l < listViewDetail.Count(); l++)
                        {
                            TReserve itemUpdate = new TReserve();
                            itemUpdate.ShipNo = newMaxTagNo;
                            itemUpdate.ShipDetailNo = detailNo + 1;
                            itemUpdate.TagNo = listViewDetail[l].TagNo;
                            itemUpdate.LocationCD = listViewDetail[l].LocationCD;
                            itemUpdate.Quantity = System.Convert.ToInt32(listViewDetail[l].Reserve);
                            itemUpdate.RemainQuantity = System.Convert.ToInt32(listViewDetail[l].Reserve);

                            listUpdate.Add(itemUpdate);
                        }
                        detailNo++;
                    }

                    //Insert header
                    this.tShippingInstructionService.Insert(headerModel);
                    //Insert detail
                    this.tShippingInstructionDetailService.Insert(listDetail);
                    //Insert reserve
                    this.tReserveService.Insert(listUpdate);
                    //Remove lock
                    this.tPessimisticLockService.Delete(listInsert);

                    //Submit only header context
                    this.tShippingInstructionService.Context.SubmitChanges();

                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_MKind_H_PK) || sqlEx.Message.Contains(Constant.DB_MKind_D_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Delete check
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool DeleteCheck(OutboundDeliveryIndicationMain gmModel)
        {
            //Get data hearder
            OutboundDeliveryIndicationMain ret = this.tShippingInstructionService.GetHeaderResultsByShipNo(gmModel.PreShipNo);

            //Check Exclusion
            if (ret == default(OutboundDeliveryIndicationMain) || gmModel.UpdateDate != ret.UpdateDate)
            {
                this.ShowMessageExclusion("/OutboundDeliveryIndication/Show", value1: gmModel.PreShipNo, value2: gmModel.SeqNum.ToString());
                return false;
            }

            // Not delete when complete picking
            if (ret.CompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0038, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0146));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }

            //Check picking data
            bool isPickingData = false;
            foreach (var item in gmModel.Detail)
            {
                if (this.tShippingInstructionDetailService.CheckPickingData(item.txt_ShipNo, item.txt_ShipNoDetail))
                {
                    item.IsPicked = true;
                    isPickingData = true;
                    break;
                }
            }

            gmModel.IsPicked = isPickingData;

            if (isPickingData)
            {
                //Can't delete data
                string message = this.FormatMessage(Constant.MES_M0039, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0146));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(OutboundDeliveryIndicationMain gmModel)
        {
            try
            {
                //Check data changed
                TShippingInstruction dbModel = this.tShippingInstructionService.GetByPk(gmModel.PreShipNo);
                if (dbModel == default(TShippingInstruction) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                List<TReserve> listDel = this.tReserveService.GetListByShipNo(gmModel.PreShipNo).ToList();
                //Check picking data
                bool isPickingData = false;
                foreach (var item in listDel)
                {
                    if (this.tShippingInstructionDetailService.CheckPickingData(item.ShipNo, item.ShipDetailNo.ToString()))
                    {
                        isPickingData = true;
                    }
                }

                if (isPickingData)
                {
                    return CommitFlag.DataChanged;
                }

                //Add lock
                List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                for (int i = 0; i < gmModel.Detail.Count(); i++)
                {
                    if (string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD))
                    {
                        continue;
                    }
                    string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                    List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                    if (listViewDetail == null || (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>)))
                    {
                        listViewDetail = gmModel.Detail[i].ViewDetail;
                    }
                    foreach (OutboundDeliveryIndicationDetailResult item in listViewDetail)
                    {
                        TPessimisticLock lockRecord = new TPessimisticLock();
                        lockRecord.TagNo = item.TagNo;
                        if (!listInsert.Any(m => m.TagNo.Equals(item.TagNo)))
                        {
                            listInsert.Add(lockRecord);
                        }
                    }
                }
                this.tPessimisticLockService.Insert(listInsert);
                this.tPessimisticLockService.Context.SubmitChanges();

                //Set delete data
                dbModel.DeleteFlag = true;
                dbModel.UpdateDate = this.GetCurrentDate();
                dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                this.tReserveService.Delete(listDel);
                //Remove lock
                this.tPessimisticLockService.Delete(listInsert);
                this.tShippingInstructionService.Context.SubmitChanges();

            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK) || sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTIONDETAIL_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }
            return CommitFlag.Success;
        }

        /// <summary>
        /// Update check
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool UpdateCheck(OutboundDeliveryIndicationMain gmModel)
        {
            if (this.tShippingInstructionService.CheckDataChangedNew(gmModel))
            {
                //Show error Message
                this.ShowMessageExclusion("/OutboundDeliveryIndication/Show", value1: gmModel.PreShipNo, value2: gmModel.SeqNum.ToString());
                return false;
            }

            IQueryable<TShippingInstructionDetails> detailModel = this.tShippingInstructionDetailService.GetListDetailByShipNo(gmModel.PreShipNo);

            //Edit Details data
            foreach (var item in detailModel)
            {
                if (this.tShippingInstructionDetailService.CheckPickingData(item.ShipNo, item.ShipDetailNo.ToString()) && !gmModel.Detail.Any(m => item.ProductCD.Equals(m.txt_ProductCD)))
                {
                    //Show error Message
                    this.ShowMessageExclusion("/OutboundDeliveryIndication/Show", value1: gmModel.PreShipNo, value2: gmModel.SeqNum.ToString());
                    return false;
                }
            }

            if (!gmModel.CompleteFlag && !this.InsertCheckHeader(gmModel))
            {
                return false;
            }

            if (!gmModel.CompleteFlag && !this.InsertCheckDetail(gmModel))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateDataForComplete(OutboundDeliveryIndicationMain gmModel)
        {
            try
            {
                //Get model update
                TShippingInstruction headerModel = this.tShippingInstructionService.GetByPk(gmModel.PreShipNo);
                if (headerModel == default(TShippingInstruction) || headerModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Edit header
                headerModel.Address1 = gmModel.Address1;
                headerModel.Address2 = gmModel.Address2;
                headerModel.Address3 = gmModel.Address3;
                headerModel.DeliveryNumber = gmModel.DeliveryNumber;
                headerModel.Memo = gmModel.Memo;
                headerModel.UpdateDate = this.GetCurrentDate();
                headerModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                //Submit 
                this.tShippingInstructionService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }
            return CommitFlag.Success;
        }

        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(OutboundDeliveryIndicationMain gmModel)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        if (string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD))
                        {
                            continue;
                        }
                        string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                        List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                        if (listViewDetail == null || (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>)))
                        {
                            listViewDetail = gmModel.Detail[i].ViewDetail;
                        }
                        foreach (OutboundDeliveryIndicationDetailResult item in listViewDetail)
                        {
                            TPessimisticLock lockRecord = new TPessimisticLock();
                            lockRecord.TagNo = item.TagNo;
                            if (!listInsert.Any(m => m.TagNo.Equals(item.TagNo)))
                            {
                                listInsert.Add(lockRecord);
                            }

                        }
                    }
                    this.tPessimisticLockService.Insert(listInsert);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Get model update
                    TShippingInstruction headerModel = this.tShippingInstructionService.GetByPk(gmModel.PreShipNo);

                    if (headerModel == default(TShippingInstruction) || headerModel.UpdateDate != gmModel.UpdateDate)
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Edit header
                    headerModel.ShipDate = gmModel.ShipDate.DateValue();
                    headerModel.CustomerCD = MCustomer.FixCodeDB(gmModel.txt_CustomerCD);
                    headerModel.Address1 = gmModel.Address1;
                    headerModel.Address2 = gmModel.Address2;
                    headerModel.Address3 = gmModel.Address3;
                    headerModel.DeliveryNumber = gmModel.DeliveryNumber;
                    headerModel.Memo = gmModel.Memo;
                    headerModel.UpdateDate = this.GetCurrentDate();
                    headerModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    headerModel.DeleteFlag = gmModel.DeleteFlag;

                    //Get model detail
                    IQueryable<TShippingInstructionDetails> detailModel = this.tShippingInstructionDetailService.GetListDetailByShipNo(gmModel.PreShipNo);

                    //Edit Details data
                    foreach (var item in detailModel)
                    {
                        if (this.tShippingInstructionDetailService.CheckPickingData(item.ShipNo, item.ShipDetailNo.ToString()) && !gmModel.Detail.Any(m => item.ProductCD.Equals(m.txt_ProductCD)))
                        {
                            return CommitFlag.DataChanged;
                        }
                        this.tShippingInstructionDetailService.Delete(item);
                    }

                    //PickingComplete flag
                    bool pickingCompleteFlag = true;

                    List<TShippingInstructionDetails> listDetail = new List<TShippingInstructionDetails>();
                    List<TReserve> listInsertReserve = new List<TReserve>();

                    int detailNo = 0;
                    //Insert and Update details
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        if (string.IsNullOrEmpty(gmModel.Detail[i].txt_ProductCD))
                        {
                            continue;
                        }

                        int valueInt = 0;
                        CommonUtil.TryParseInt(gmModel.Detail[i].txt_InstructQuantity, ref valueInt);
                        decimal valueDec = new decimal(valueInt);

                        TShippingInstructionDetails ret = new TShippingInstructionDetails();
                        ret.ShipNo = gmModel.PreShipNo;
                        ret.ShipDetailNo = detailNo + 1;
                        ret.ProductCD = gmModel.Detail[i].txt_ProductCD;
                        ret.InstructQuantity = valueDec;

                        listDetail.Add(ret);

                        IQueryable<TReserve> listReserve = this.tReserveService.GetListByShipNo(gmModel.PreShipNo);
                        foreach (var item in listReserve)
                        {
                            tReserveService.Delete(item);
                        }

                        List<TReserve> listUpdate = new List<TReserve>();

                        string keySession = this.CreateKeySession((i + 1).ToString(), gmModel.Detail[i].SeqNum.ToString());

                        List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                        if (listViewDetail == null || (listViewDetail == default(List<OutboundDeliveryIndicationDetailResult>)))
                        {
                            listViewDetail = gmModel.Detail[i].ViewDetail;
                        }
                        for (int l = 0; l < listViewDetail.Count(); l++)
                        {
                            if (!string.IsNullOrEmpty(listViewDetail[l].Reserve))
                            {
                                int countPicking = tInventory_DService.GetCountListPicking(gmModel.PreShipNo, listViewDetail[l].TagNo, listViewDetail[l].LocationCD);
                                if (CommonUtil.ParseInteger(listViewDetail[l].Reserve) != countPicking)
                                {
                                    pickingCompleteFlag = false;
                                }

                                TReserve newItem = new TReserve();
                                newItem.ShipNo = gmModel.PreShipNo;
                                newItem.ShipDetailNo = detailNo + 1;
                                newItem.Quantity = CommonUtil.ParseInteger(listViewDetail[l].Reserve);
                                newItem.RemainQuantity = CommonUtil.ParseInteger(listViewDetail[l].Reserve) - listViewDetail[l].PickingQuantity;
                                newItem.TagNo = listViewDetail[l].TagNo;
                                newItem.LocationCD = listViewDetail[l].LocationCD;

                                listInsertReserve.Add(newItem);
                            }
                        }
                        detailNo++;
                    }

                    //Update PickingComplete flag
                    if (!gmModel.DeleteFlag && pickingCompleteFlag)
                    {
                        headerModel.PickingCompleteFlag = true;
                    }

                    //Remove lock
                    this.tPessimisticLockService.Delete(listInsert);
                    //Update detail
                    this.tShippingInstructionDetailService.Insert(listDetail);
                    if (!gmModel.DeleteFlag)
                    {
                        //Insert Reserve
                        this.tReserveService.Insert(listInsertReserve);
                    }

                    //Submit 
                    this.tShippingInstructionService.Context.SubmitChanges();
                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK) || sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTIONDETAIL_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;

        }

        /// <summary>
        /// Get Order
        /// </summary>
        /// <param name="CustomerCD"></param>
        /// <returns></returns>
        private List<SortingInfo> GetOrderList(string CustomerCD)
        {
            var SortOrders = this.tStockAllowanceService.GetListByCustomerCd(CustomerCD);
            List<SortingInfo> Sorts = new System.Collections.Generic.List<SortingInfo>();
            foreach (var item in SortOrders)
            {
                //Create sorting info
                SortingInfo sortInfo = new SortingInfo();
                sortInfo.Direction = (SortDirection)item.SortOrder;
                switch (item.DataCD)
                {
                    case Constant.STOCKALLOWANCE_ARRIVALDATE:
                        sortInfo.SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_ARRIVALDATE;
                        break;
                    case Constant.STOCKALLOWANCE_LOT1:
                        sortInfo.SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_LOT1;
                        break;
                    case Constant.STOCKALLOWANCE_LOT2:
                        sortInfo.SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_LOT2;
                        break;
                    case Constant.STOCKALLOWANCE_LOT3:
                        sortInfo.SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_LOT3;
                        break;
                    case Constant.STOCKALLOWANCE_STOREDDATE:
                        sortInfo.SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_STOREDDATE;
                        break;
                    default:
                        break;
                }
                Sorts.Add(sortInfo);
            }

            //Add sort Tagno
            Sorts.Add(new SortingInfo() { Direction = SortDirection.Ascending, SortField = SHIPPING_INSTRUCTION_DETAIL_SORT_TAGNO });
            return Sorts;
        }

        /// <summary>
        /// Check shipNo used by other table
        /// </summary>
        /// <param name="shipNo">Ship No</param>
        /// <param name="shipNoDetail">Ship No Detail</param>
        /// <returns></returns>
        private bool IsUsedByOther(string shipNo, string shipNoDetail)
        {
            return this.tInventory_DService.IsExists(shipNo, shipNoDetail);
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Show Instrucquantity
        /// </summary>
        /// <param name="InstructQuantity">InstructQuantity</param>
        /// <returns></returns>
        public JsonResult ShowInstructQuantity(string InstructQuantity, string[] Qtys)
        {
            int instructQuantity = 0;
            int total = 0;

            if (CommonUtil.TryParseInt(InstructQuantity, ref instructQuantity))
            {
                InstructQuantity = instructQuantity.ToString();
                if (CommonUtil.CheckScale(instructQuantity, 0))
                {
                    InstructQuantity = string.Format(Constant.NUMBER_FORMAT_INT, instructQuantity);
                }
            }
            
            foreach (var item in Qtys)
            {
                int temp = 0;
                if (CommonUtil.TryParseInt(item, ref temp))
                {
                    total += temp;
                }
                
            }
            string sTotal = total == 0 ? string.Empty : string.Format(Constant.NUMBER_FORMAT_INT, total);
            return Json(new List<string>()
                {
                   InstructQuantity, sTotal
                }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show CustomerName
        /// </summary>
        /// <param name="CustomerCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowCustomerName(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD.ToUpper());

            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.CustomerName,
                        model.Address1,
                        model.Address2,
                        model.Address3
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Product Name
        /// </summary>
        /// <param name="ProductCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowProductName(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD.ToUpper());

            if (model != default(ProductModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.ProductName
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Check before call form View Detail
        /// </summary>
        /// <param name="Row"></param>
        /// <param name="txt_CustomerCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult CheckRow(OutboundDeliveryIndicationDetailGrid Row, string txt_CustomerCD)
        {
            this.ClearModelState();

            string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), Row.NumRow);
            var mode = this.GetMode(Row.SeqNum);
            if (mode != Mode.Show)
            {
                //Check required CustomerCD
                if (string.IsNullOrEmpty(txt_CustomerCD))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
                    this.ModelState.AddModelError("txt_CustomerCD", message);
                }

                //Check required ProductCD
                if (string.IsNullOrEmpty(Row.txt_ProductCD))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002,UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", Row.NumRow - 1), message + row);
                }
                else
                {
                    //Check ProductCd exist in Product Master
                    ProductModels modelProduct = this.mProductService.GetByCd(Row.txt_ProductCD);
                    if (modelProduct == null)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                        this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", Row.NumRow - 1), message + row);
                    }
                    else
                    {
                        //Check ProductCd exist in inventory
                        if (!this.tInventory_HService.ExistByProductCD(Row.txt_ProductCD, Row.txt_ShipNo))
                        {
                            //Show error message
                            string message = this.FormatMessage(Constant.MES_M0042);
                            this.ModelState.AddModelError(string.Format("Detail[{0}].txt_ProductCD", Row.NumRow - 1), message + row);
                        }
                    }
                }

                //Check required quantity
                if (string.IsNullOrEmpty(Row.txt_InstructQuantity))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002,UserSession.Session.SysCache.GetLabel(Constant.LBL_L0150));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].txt_InstructQuantity", Row.NumRow - 1), message + row);
                }
                else
                {
                    //Check quantitt valid number format
                    if (!string.IsNullOrEmpty(Row.txt_InstructQuantity))
                    {
                        int instrucQty = default(int);
                        if (!CommonUtil.TryParseInt(Row.txt_InstructQuantity, ref instrucQty))
                        {
                            //Show error message
                            string message = this.FormatMessage(Constant.MES_E0012, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0150), Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MIN.ToString(Constant.FMT_INTEGER), Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MAX.ToString(Constant.FMT_INTEGER));
                            this.ModelState.AddModelError(string.Format("Detail[{0}].txt_InstructQuantity", Row.NumRow - 1), message + row);
                        }
                        if (instrucQty < Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MIN || instrucQty > Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MAX)
                        {
                            //must in range
                            string message = this.FormatMessage(Constant.MES_E0012, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0150), Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MIN.ToString(Constant.FMT_INTEGER), Constant.TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MAX.ToString(Constant.FMT_INTEGER));
                            this.ModelState.AddModelError(string.Format("Detail[{0}].txt_InstructQuantity", Row.NumRow - 1), message + row);
                        }
                    }
                }

                if (this.ModelState.Where(m => m.Value.Errors.Count > 0).Count() != 0)
                {
                    return Json(this.ModelState.Where(m => m.Value.Errors.Count > 0).ToList(), JsonRequestBehavior.AllowGet);
                }

                //Get quantity from screen
                var InstructQuantity = 0;
                Utility.CommonUtil.TryParseInt(Row.txt_InstructQuantity, ref InstructQuantity);

                //Get value from session
                string keySession = this.CreateKeySession(Row.NumRow.ToString(), Row.SeqNum.ToString());
                List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[keySession];
                if ((listViewDetail != default(List<OutboundDeliveryIndicationDetailResult>) && listViewDetail.Count != 0))
                {
                    //Check ProductCd change value
                    if (!string.IsNullOrEmpty(Row.txt_ProductCD) && !Row.txt_ProductCD.Equals(Row.preProductCD))
                    {
                        //Get Sort Info
                        var sortList = this.GetOrderList(txt_CustomerCD);

                        //Create data detail
                        OutboundDeliveryIndicationDetail model = new OutboundDeliveryIndicationDetail();
                        model.txt_ProductCD = Row.txt_ProductCD;
                        model.SeqNum = Row.SeqNum;
                        model.ShipNo = Row.txt_ShipNo;
                        model.txt_CustomerCD = txt_CustomerCD;
                        listViewDetail = this.CreateDataDetail(model, sortList).ToList();
                        this.Session[keySession] = listViewDetail;
                    }
                }
            }
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + Row.SeqNum.ToString()] = null;
            return Json(this.ModelState.Where(m => m.Value.Errors.Count > 0).ToList(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Reserve data
        /// </summary>
        /// <param name="CurrentRow"></param>
        /// <param name="ProductCD"></param>
        /// <param name="SeqNum"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ReserveData(int CurrentRow, string ProductCD, int SeqNum, string CurQty, string[] Qtys)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            List<OutboundDeliveryIndicationDetailResult> listViewDetail = (List<OutboundDeliveryIndicationDetailResult>)this.Session[this.CreateKeySession(CurrentRow.ToString(), SeqNum.ToString())];

            if (listViewDetail != default(List<OutboundDeliveryIndicationDetailResult>) && listViewDetail != null)
            {

                //Get data
                OutboundDeliveryIndicationMain gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

                gmModel.Detail[CurrentRow - 1].ViewDetail = listViewDetail;

                this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = gmModel;

                int instructQuantity = 0;
                int total = 0;

                foreach (var item in Qtys)
                {
                    int itemVal = 0;
                    if (CommonUtil.TryParseInt(item, ref itemVal))
                    {
                        total += itemVal;
                    }

                }
                if (CommonUtil.TryParseInt(CurQty, ref instructQuantity))
                {
                    total -= instructQuantity;
                }
                
                var temp = 0;
                int newVal = listViewDetail.Where(m=> Utility.CommonUtil.TryParseInt(m.Reserve, ref temp)).Sum(m=> Utility.CommonUtil.ParseInteger(m.Reserve));
                total += newVal;
                
                string sTotal = total <= 0 ? string.Empty : string.Format(Constant.NUMBER_FORMAT_INT, total);

                return Json(new List<string>()
                    {
                        
                        string.Format(Constant.NUMBER_FORMAT_INT,newVal)
                        , sTotal
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Print - LOC

        /// <summary>
        /// Change Print All
        /// </summary>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="SeqNum">Sequence Number</param>
        [HttpPost]
        public void CheckPrintItemALL(bool CheckedFlag, int seqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];

            //Clear list location
            ListItems.Clear();

            //Add Location
            if (CheckedFlag)
            {
                IQueryable<OutboundDeliveryIndicationResults> results = (IQueryable<OutboundDeliveryIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];

                foreach (var row in results.Where(m => !m.DeleteData))
                {
                    ListItems.Add(row.ShipNo, true);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = ListItems;
        }

        /// <summary>
        /// Change Print Item
        /// </summary>
        /// <param name="shipNo">ShipNo</param>
        /// <param name="CheckedFlag">CheckedFlag</param>
        /// <param name="SeqNum">Sequence Number</param>
        [HttpPost]
        public bool CheckPrintItemAt(string shipNo, bool CheckedFlag, int seqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];
            IQueryable<OutboundDeliveryIndicationResults> results = (IQueryable<OutboundDeliveryIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];

            //Add Location
            if (CheckedFlag)
            {
                if (!ListItems.ContainsKey(shipNo) && results.Where(m => m.ShipNo.Equals(shipNo) && !m.DeleteData).SingleOrDefault() != null)
                {
                    ListItems.Add(shipNo, true);
                }
            }
            else
            {
                //Remove Location
                if (ListItems.ContainsKey(shipNo))
                {
                    ListItems.Remove(shipNo);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = ListItems;
            var checkAll = (ListItems.Count == results.Count(m => !m.DeleteData));
            return checkAll;
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Print(OutboundDeliveryIndicationList gmModel)
        {
            this.ClearModelState();

            //Get model
            var oldModel = (OutboundDeliveryIndicationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
            if (oldModel != null)
            {
                #region PageInfo

                var results = (IQueryable<OutboundDeliveryIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()];

                //Restore Paging Sorting
                this.RestorePagingSorting(oldModel.SeqNum, results);

                #endregion

                #region out report

                var hashtable = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()];

                //Filter selected row
                List<string> SelectedRows = hashtable.Keys.OfType<string>().ToList();

                //Filter data
                List<OutboundDeliveryIndicationResults> ReportData = results
                                        .Where(m => SelectedRows.Contains(m.ShipNo))
                                        .OrderBy(m => m.ShipNo).ToList();

                var RowLength = ReportData.Count();
                if (RowLength > 0)
                {
                    this.ShowMessageForPrint(gmModel.SeqNum, "Index");
                }
                else
                {
                    this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                }

                #endregion
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult PrintDetail(int SeqNum)
        {
            //Get model
            var gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            if (gmModel != null)
            {
                TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(gmModel.PreShipNo);
                if (shipH == default(TShippingInstruction) || shipH.DeleteFlag)
                {
                    return this.ExclusionProcess(SeqNum);
                }

                Hashtable htb = new Hashtable();
                htb.Add(gmModel.PreShipNo, true);
                this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()] = htb;

                this.ShowMessageForPrint(SeqNum, "Detail");
            }
            else
            {
                return this.ExclusionProcess(SeqNum);
            }
            return View("Details", gmModel);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="value1">Form From</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        public ActionResult PrintAction(string value1, string value3)
        {
            
            #region download
            var SelectedRows = ((Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + value3]).Keys.OfType<string>().OrderBy(m => m).ToList();

            //Report dataset
            Report.DataObject.ShippingInstructionDataSet DataSet = new Report.DataObject.ShippingInstructionDataSet();
            
            //Report
            LocalReport mainLocalReport = new LocalReport();
            LocalReport subLocalReport = new LocalReport();

            //Report Source
            dtMain = DataSet._ShippingInstructionDataSet.Clone();

            //Get data for Header
            IQueryable<Print_OutboundDeliveryIndication_Header> listHeader = this.tShippingInstructionService.GetDataItemPrintHeader(SelectedRows);

            foreach (Print_OutboundDeliveryIndication_Header header in listHeader)
            {
                DataRow dtMainRow = dtMain.NewRow();
                InitDataForRowMain(ref dtMainRow, header);
                dtMain.Rows.Add(dtMainRow);
            }

            //Report path
            mainLocalReport.ReportPath = Server.MapPath(PDF_PATH_MAIN_LOCALREPORT);
            subLocalReport.ReportPath = Server.MapPath(PDF_PATH_SUB_LOCALREPORT);
            
            //Report source
            ReportDataSource ShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_MAIN, dtMain);

            // Add a handler for SubreportProcessing.
            mainLocalReport.SubreportProcessing +=
                        new SubreportProcessingEventHandler(SubreportProcessingEventHandler);

            mainLocalReport.DataSources.Add(ShippingInstructionTable);

            //Set parameter
            mainLocalReport.SetParameters(this.InitParamsForMainReport());

            //Set Printed Flag      
            CommitFlag UpdateResult = CommitFlag.Success;

            UpdateResult = UpdateShippingPrintFlag(SelectedRows);

            //Output file for download
            if (UpdateResult == CommitFlag.Success)
            {
                //out put pdf
                FileContentResult file = this.PDFOutPut(mainLocalReport,string.Format(PDF_FILENAME,DateTime.Now.ToString( Constant.FMT_DMY)), Common.ReportType.Business, false);
                TempData[TMP_DOWNLOAD_FILE] = file;
            }

            if (value1.Equals("Index"))
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = int.Parse(value3);
                return RedirectToAction("Index");
            }
            else
            {
                var gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value3.ToString()];
                return Show(gmModel.PreShipNo, int.Parse(value3));                
            }

            #endregion
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_OutboundDeliveryIndication_Header</param>
        private void InitDataForRowMain(ref System.Data.DataRow Row, Print_OutboundDeliveryIndication_Header header)
        {
            Row[FieldsMain.ShipNo.ToString()] = header.ShipNo;

            string barCode = header.ShipNo;
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row[FieldsMain.Barcode.ToString()] = Stream.ToArray();
            Row[FieldsMain.ShipDate.ToString()] = string.IsNullOrEmpty(header.ShipDate) ? string.Empty : CommonUtil.ParseDate(header.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.InstructDate.ToString()] = string.IsNullOrEmpty(header.InstructDate) ? string.Empty : CommonUtil.ParseDate(header.InstructDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.CustomerCD.ToString()] = header.CustomerCD;
            Row[FieldsMain.CustomerName.ToString()] = header.CustomerName;
            Row[FieldsMain.ShippingCompleteFlag.ToString()] = header.ShippingCompleteFlag;

            Row[FieldsMain.DeliveryNumber.ToString()] = header.DeliveryNumber;
            Row[FieldsMain.Address1.ToString()] = header.Address1;
            Row[FieldsMain.Address2.ToString()] = header.Address2;
            Row[FieldsMain.Address3.ToString()] = header.Address3;

            IQueryable<Print_OutboundDeliveryIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetail(header.ShipNo, header.ShippingCompleteFlag);
            Row[FieldsMain.TotalPage.ToString()] = this.GetTotalPage(listDetail.Count()).ToString();
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_OutboundDeliveryIndication_Detail</param>
        /// <param name="RowIndex">RowIndex</param>
        private void InitDataForRowDetail(ref System.Data.DataRow Row, Print_OutboundDeliveryIndication_Detail Data, int RowIndex, int RowCount)
        {
            Row[FieldsDetail.ShipNo.ToString()] = Data.ShipNo;
            Row[FieldsDetail.OrderNo.ToString()] = RowIndex;
            Row[FieldsDetail.LocationCD.ToString()] = Data.LocationCD;
            Row[FieldsDetail.TagNo.ToString()] = Data.TagNo;
            Row[FieldsDetail.ProductCD.ToString()] = Data.ProductCD;
            Row[FieldsDetail.ProductName.ToString()] = Data.ProductName;
            Row[FieldsDetail.Lot1.ToString()] = Data.Lot1;
            Row[FieldsDetail.Lot2.ToString()] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Lot3.ToString()] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Quantity.ToString()] = Data.Quantity;
            Row[FieldsDetail.TotalLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0175);
            Row[FieldsDetail.RowCount.ToString()] = RowCount;
        }

        /// <summary>
        /// Create Detail Data
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <param name="ShippingCompleteFlg">ShippingCompleteFlg</param>
        /// <returns>DataTable</returns>
        private DataTable CreateDetailData(string shipNo, bool ShippingCompleteFlg)
        {
            //Set data for detail table
            dtDetail = new DataTable();
            Report.DataObject.SubShippingInstructionDataSet SubDataSet = new Report.DataObject.SubShippingInstructionDataSet();
            dtDetail = SubDataSet._SubShippingInstructionDataSet.Clone();
            List<Print_OutboundDeliveryIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetail(shipNo, ShippingCompleteFlg).ToList();
            int count = listDetail.Count();
            for (int j = 0; j < count; j++)
            {
                var dtRow = dtDetail.NewRow();
                InitDataForRowDetail(ref dtRow, listDetail[j], j + 1, count);
                dtDetail.Rows.Add(dtRow);

            }
            return dtDetail;
        }

        /// <summary>
        /// Get Total Page
        /// </summary>
        /// <param name="rowNum">Detail row number</param>
        /// <returns>int</returns>
        private int GetTotalPage(int rowNum)
        {
            int pageTotal = 0;

            if (rowNum > 0)
            {
                //if detail table's number row <=15
                if (rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE <= 1)
                {
                    //if detail table's number row =15
                    if (rowNum % PDF_NUMBER_ROW_PER_FIRST_PAGE == 0)
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE;
                    }
                    else//if detail table's number row <15
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE + 1;
                    }
                }
                else//if detail table's number row >15
                {
                    //Init pageTotal for first page
                    pageTotal = 1;

                    //Set pageTotal for after pages
                    if ((rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) % PDF_NUMBER_ROW_PER_NEXT_PAGE == 0)
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE;
                    }
                    else
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE + 1;
                    }
                }
            }
            return pageTotal;
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRAM
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForMainReport()
        {
            //Set Parameters
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;
            string space = "";
            ReportParameter titleReport = new ReportParameter("titleReport", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0170));
            ReportParameter companyName = new ReportParameter("companyName", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            ReportParameter shipNo = new ReportParameter("shipNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0171));
            ReportParameter shipDate = new ReportParameter("shipDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0147));
            ReportParameter instructDate = new ReportParameter("instructDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0173));
            ReportParameter customerCD = new ReportParameter("customerCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0028));
            ReportParameter customerName = new ReportParameter("customerNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0029));
            ReportParameter page = new ReportParameter("pageLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172));
            ReportParameter orderNo = new ReportParameter("orderNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0151));
            ReportParameter location = new ReportParameter("locationLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
            ReportParameter tagNo = new ReportParameter("tagNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter productCD = new ReportParameter("productCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("productNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter lot1 = new ReportParameter("lot1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter lot2 = new ReportParameter("lot2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("lot3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter quantity = new ReportParameter("quantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0174));
            ReportParameter deliveryNumber = new ReportParameter("deliveryNumberLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0301));

            return new ReportParameterCollection { titleReport, companyName, shipNo, shipDate, instructDate, customerCD, customerName, page, orderNo, location, tagNo, productCD, productName, lot1, lot2, lot3, quantity, deliveryNumber };
        }

        /// <summary>
        ///  Show Message For Print
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void ShowMessageForPrint(int SeqNum, string form)
        {
            //Show confirm message
            this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
            value1: form, value3: SeqNum.ToString());
        }

        #region Handle

        /// <summary>
        /// Subreport Processing Event Handler
        /// Author: ISV-TRAM
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SubreportProcessingEventHandler(object sender, SubreportProcessingEventArgs e)
        {
            LocalReport localReport = (LocalReport)sender;
            ReportDataSourceCollection data = localReport.DataSources;
            DataTable dt = (DataTable)data[0].Value;

            dtDetail = this.CreateDetailData(dt.Rows[count++][FieldsMain.ShipNo.ToString()].ToString(), (bool)dt.Rows[0][FieldsMain.ShippingCompleteFlag.ToString()]);
            ReportDataSource SubShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_DETAIL, dtDetail);
            e.DataSources.Add(SubShippingInstructionTable);
        }

        #endregion

        #endregion

        #region "Registration"

        /// <summary>
        /// Update ShippingPrintFlag After Printed
        /// Author : ISV-LOC
        /// </summary>
        /// <param name="gmListShipNo">List Of ShipNo</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdateShippingPrintFlag(List<string> gmListShipNo)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();
                Hashtable updated = new Hashtable();

                //update ShippingPrintFlag for Detail
                IQueryable<TShippingInstruction> listShipping = this.tShippingInstructionService.GetListByShipNos(gmListShipNo);

                foreach (TShippingInstruction entity in listShipping.ToList())
                {
                    entity.ShippingPrintFlag = true;
                    entity.UpdateDate = updateDate;
                    entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }


                this.tShippingInstructionService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = string.Empty;

                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }
            return ret;
        }

        #endregion

        #region Remove/Add rows

        /// <summary>
        /// Remove row comfirm
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult RemoveRowConfirm(OutboundDeliveryIndicationMain gmModel)
        {
            //Clear ModelState
            this.ClearModelState();

            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            var listDelete = this.GetIndexCheckDelete(gmModel.delFlg);

            if (listDelete.Count == 0)
            {
                for (int i = 0; i < gmModel.Detail.Count(); i++)
                {
                    if (!gmModel.Detail[i].IsPicked)
                    {
                        this.ModelState.AddModelError("Detail_" + i + "__Delete", InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                        break;
                    }
                }
                return View("Details", gmModel);
            }
            if (listDelete.Count == gmModel.Detail.Where(m=>!m.IsPicked).Count())
            {
                gmModel.CheckDeleteAll = true;
            }
            else
            {
                gmModel.CheckDeleteAll = false;
            }
            //Show message confirm
            this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDeliveryIndication/RemoveRowAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0036), value1: gmModel.SeqNum.ToString());

            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete a row
        /// </summary>
        /// <param name="value1">Sequen Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult RemoveRowAction(string value1)
        {
            this.ClearModelState();
            OutboundDeliveryIndicationMain gmModel = (OutboundDeliveryIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Add number sequen for detail
            //gmModel.AddSeqForDetail();

            OutboundDeliveryIndicationMain newModel = new OutboundDeliveryIndicationMain();
            newModel.PreShipNo = gmModel.PreShipNo;
            newModel.txt_ShipDate = gmModel.txt_ShipDate;
            newModel.ShipDate = gmModel.ShipDate;
            newModel.txt_CustomerCD = gmModel.txt_CustomerCD;
            newModel.txt_CustomerName = gmModel.txt_CustomerName;
            newModel.Address1 = gmModel.Address1;
            newModel.Address2 = gmModel.Address2;
            newModel.Address3 = gmModel.Address3;
            newModel.DeliveryNumber = gmModel.DeliveryNumber;
            newModel.Memo = gmModel.Memo;
            newModel.WarehouseCD = gmModel.WarehouseCD;
            newModel.DeleteFlag = gmModel.DeleteFlag;
            newModel.UpdateDate = gmModel.UpdateDate;
            newModel.SeqNum = gmModel.SeqNum;
            newModel.PreShipNo = gmModel.PreShipNo;
            newModel.IsPicked = gmModel.IsPicked;
            newModel.CompleteFlag = gmModel.CompleteFlag;
            newModel.TotalInstructQty = gmModel.TotalInstructQty;
            newModel.MaxRowDetail = gmModel.MaxRowDetail;
            newModel.CheckDeleteAll = false;

            //Get list delete
            var listDelete = this.GetIndexCheckDelete(gmModel.delFlg);

            if (listDelete.Count == gmModel.Detail.Count)
            {
                //Clear session
                ClearSession(gmModel);

                newModel.TotalInstructQty = string.Empty;

                //Add empty rows 
                this.AddEmtyRows(newModel, this.rowNumDetail, newModel.SeqNum);
                this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

                //Set focus
                this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_ProductCD", 0)));
                return View("Details", newModel);
            }

            Hashtable listKeySession = new Hashtable();
            int index = 0;
            for (int i = 0; i < gmModel.Detail.Count; i++)
            {
                string keySession = this.CreateKeySession(gmModel.Detail[i].NumRow.ToString(), gmModel.Detail[i].SeqNum.ToString());
                if (!listDelete.ContainsKey((i + 1)))
                {
                    listKeySession.Add(index + 1, keySession);

                    newModel.Detail.Add(gmModel.Detail[i]);
                    newModel.Detail[index].NumRow = index + 1;
                    //newModel.Detail[index].txt_ShipNoDetail = (index + 1).ToString();
                    index++;
                }
                else
                {
                    this.Session[keySession] = null;
                }
            }
            if (newModel.Detail.Count == 0)
            {
                
                //Add empty rows 
                this.AddEmtyRows(newModel, this.rowNumDetail, newModel.SeqNum);
                this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

                //Set focus
                this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_ProductCD", 0)));

                return View("Details", newModel);
            }

            //Reset numer of rows and reset value in sesion
            int total = 0;
            for (int i = 0; i < newModel.Detail.Count(); i++)
            {
                string newKeySession = this.CreateKeySession(newModel.Detail[i].NumRow.ToString(), newModel.Detail[i].SeqNum.ToString());
                if (listKeySession.ContainsKey(newModel.Detail[i].NumRow))
                {
                    var temp = this.Session[listKeySession[newModel.Detail[i].NumRow].ToString()];
                    this.Session[listKeySession[newModel.Detail[i].NumRow].ToString()] = new List<OutboundDeliveryIndicationDetailResult>();
                    this.Session[newKeySession] = temp;
                }

                int qty = 0;
                if (CommonUtil.TryParseInt(newModel.Detail[i].txt_InstructQuantity, ref qty))
                {
                    total += qty;
                }
            }
            newModel.TotalInstructQty = total == 0 ? string.Empty : total.ToString(Constant.FMT_INTEGER);


            //Add empty rows
            int rowsAddNum = this.rowNumDetail - newModel.Detail.Count();
            this.AddEmtyRows(newModel, rowsAddNum, newModel.SeqNum);

            for (int j = 0; j < newModel.Detail.Count(); j++)
            {
                if (!newModel.Detail[j].IsPicked)
                {
                    //Set focus
                    this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_ProductCD", (j))));
                    break;
                }
            }

            //Add store
            listDelete.Clear();
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = newModel;

            return View("Details", newModel);
        }

        /// <summary>
        /// Add rows
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Add(OutboundDeliveryIndicationMain gmModel)
        {
            //Clear ModelState
            this.ClearModelState();

            if (gmModel.Detail.Count() >= this.MaxRowDetail)
            {
                return View("Details", gmModel);
            }

            //Add an empty row 
            this.AddEmtyRows(gmModel, 1, gmModel.SeqNum);

            //Add number sequen for detail
            //gmModel.AddSeqForDetail();

            gmModel.CheckDeleteAll = false;

            //Store session
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            //set focus
            this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_ProductCD", gmModel.Detail.Count()-1)));

            return View("Details", gmModel);
        }

        #endregion

        #region Outbound Delivery Indicaton Detail ISV-Nho

        /// <summary>
        /// Build List Detail
        /// </summary>
        /// <param name="listDB"></param>
        /// <param name="oldList"></param>
        /// <param name="Quantity"></param>
        /// <param name="sortList"></param>
        /// <returns></returns>
        private List<OutboundDeliveryIndicationDetailResult> BuildListDetail(List<OutboundDeliveryIndicationDetailResult> listDB, List<OutboundDeliveryIndicationDetailResult> oldList, int Quantity, List<SortingInfo> sortList)
        {
            List<OutboundDeliveryIndicationDetailResult> ret = new List<OutboundDeliveryIndicationDetailResult>();

            //No old List And No Quantity
            if (oldList.Count == 0 && Quantity == 0)
            {
                return listDB;
            }

            //has oldList
            if (oldList.Count != 0)
            {
                List<string> listKey = new List<string>();
                foreach (var item in listDB)
                {
                    //set Reserve for retsult list
                    var itemO = oldList.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD)).SingleOrDefault();
                    if (itemO != default(OutboundDeliveryIndicationDetailResult))
                    {
                        item.Reserve = itemO.Reserve;
                    }
                    else
                    {
                        item.Reserve = string.Empty;
                    }

                    listKey.Add(item.TagNo + item.LocationCD);

                    ret.Add(item);
                }

                var listNew = oldList.Where(m => !listKey.Contains(m.TagNo + m.LocationCD));
                foreach (var item in listNew)
                {
                    item.NumBoxes = 0;
                    ret.Add(item);
                }

                //Set sorting
                if (sortList.Count > 0)
                {
                    var retI = ret.AsQueryable();
                    retI = retI.iOrderBy(sortList[0].SortField, sortList[0].Direction);
                    for (int i = 1; i < sortList.Count; i++)
                    {
                        retI = retI.iThenBy(sortList[i].SortField, sortList[i].Direction);
                    }
                    ret = retI.ToList();
                }
            }
            else
            {
                ret = listDB;
            }

            int totalReserve = ret.Where(m => !string.IsNullOrEmpty(m.Reserve)).Sum(m => CommonUtil.ParseInteger(m.Reserve));

            //set Quantity
            if (Quantity != 0 && totalReserve != Quantity)
            {
                ret = ResetReserve(ret, Quantity);
            }

            //Set sorting
            if (sortList.Count > 0)
            {
                var retI = ret.AsQueryable();
                retI = retI.iOrderBy(sortList[0].SortField, sortList[0].Direction);
                for (int i = 1; i < sortList.Count; i++)
                {
                    retI = retI.iThenBy(sortList[i].SortField, sortList[i].Direction);
                }
                ret = retI.Where(m => !(string.IsNullOrEmpty(m.Reserve) && m.NumBoxes <= 0)).ToList();
            }
            return ret;
        }

        /// <summary>
        /// Reset Reserve
        /// </summary>
        /// <param name="list"></param>
        /// <param name="quantity"></param>
        /// <returns></returns>
        private List<OutboundDeliveryIndicationDetailResult> ResetReserve(List<OutboundDeliveryIndicationDetailResult> list, int quantity)
        {
            int totalReserve = list.Where(m => !string.IsNullOrEmpty(m.Reserve)).Sum(m => CommonUtil.ParseInteger(m.Reserve));

            if (quantity > totalReserve)
            {
                int needAdd = quantity - totalReserve;
                var hasReserveList = list.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
                foreach (var item in hasReserveList)
                {
                    int canAdd = item.NumBoxes - CommonUtil.ParseInteger(item.Reserve);
                    int newReserve = needAdd > canAdd ? item.NumBoxes : CommonUtil.ParseInteger(item.Reserve) + needAdd;
                    needAdd = needAdd - canAdd;

                    item.Reserve = newReserve == 0 ? string.Empty : newReserve.ToString();
                    if (needAdd <= 0)
                    {
                        break;
                    }
                }
                var noReserveList = list.Where(m => string.IsNullOrEmpty(m.Reserve)).ToList();

                if (needAdd > 0)
                {
                    foreach (var item in noReserveList)
                    {
                        int newReserve = needAdd > item.NumBoxes ? item.NumBoxes : CommonUtil.ParseInteger(string.IsNullOrEmpty(item.Reserve) ? "0" : item.Reserve) + needAdd;
                        needAdd = needAdd - item.NumBoxes;

                        item.Reserve = newReserve.ToString();
                        if (needAdd <= 0)
                        {
                            break;
                        }
                    }
                }
            }
            else
            {
                int needSub = totalReserve - quantity;
                for (int i = list.Count - 1; i >= 0; i--)
                {
                    if (!string.IsNullOrEmpty(list[i].Reserve))
                    {
                        int newReserve = needSub >= CommonUtil.ParseInteger(list[i].Reserve) ? 0 : CommonUtil.ParseInteger(list[i].Reserve) - needSub;
                        needSub = needSub - CommonUtil.ParseInteger(list[i].Reserve);
                        list[i].Reserve = newReserve == 0 ? string.Empty : newReserve.ToString();
                    }
                    if (needSub <= 0)
                    {
                        break;
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// Outbound Delivery Indication Detail
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public ActionResult OutboundDeliveryIndicationDetail(OutboundDeliveryIndicationDetail gmModel)
        {
            //Set title
            ViewBag.Title = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0157);

            //clear error detail
            this.ClearModelStateDetail(gmModel);
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = null;

            //Check search data
            if (this.ModelState.IsValid)
            {
                Mode modeState = this.GetMode(gmModel.SeqNum);

                //Clear Modestate
                this.ClearModelState();

                //Get Sort Info
                var sortList = this.GetOrderList(gmModel.txt_CustomerCD);

                //Check Shiping completed
                var ShippingObj = this.tShippingInstructionService.GetByPk(gmModel.ShipNo);
                gmModel.ShippingCompleteFlag = ShippingObj != default(TShippingInstruction) ? ShippingObj.ShippingCompleteFlag : false;
                gmModel.PickCompleteFlag = ShippingObj != default(TShippingInstruction) ? ShippingObj.PickingCompleteFlag : false;

                //Get list
                IQueryable<OutboundDeliveryIndicationDetailResult> list = CreateDataDetail(gmModel, sortList);


                //Get old List 
                List<OutboundDeliveryIndicationDetailResult> oldList = (List<OutboundDeliveryIndicationDetailResult>)this.Session[this.CreateKeySession(gmModel.RowNo.ToString(), gmModel.SeqNum.ToString())];
                if (oldList == null)
                {
                    oldList = new List<OutboundDeliveryIndicationDetailResult>();
                }
                else
                {
                    oldList = oldList.Where(m => m.NumBoxes>0).ToList();
                }

                if (modeState.Equals(Mode.Show) || gmModel.PickCompleteFlag)
                {
                    list = list.Where(m => !string.IsNullOrEmpty(m.Reserve));
                }

                //Focus
                this.SetFocusId(KEY_TAG_NO);

                //Check result is empty
                int count = list.Count();
                if (count == 0)
                {
                    gmModel.Results = null;
                    this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = null;
                    return PartialView(gmModel);
                }

                if (!gmModel.OnSearch && !modeState.Equals(Mode.Show) && !gmModel.PickCompleteFlag)
                {
                    list = this.BuildListDetail(list.ToList(), oldList, CommonUtil.ParseInteger(String.IsNullOrEmpty(gmModel.InstructQuantity) ? "0" : gmModel.InstructQuantity), sortList).AsQueryable();
                }

                //Set sorting
                if (sortList.Count > 0)
                {
                    list = list.iOrderBy("PickedFlag", SortDirection.Descending);
                    for (int i = 0; i < sortList.Count; i++)
                    {
                        list = list.iThenBy(sortList[i].SortField, sortList[i].Direction);
                    }
                }

                //Store result into session
                this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = list;

                //Set default sort
                ViewBag.SortingInfo = new SortingInfo();

                //Create paging info
                PagingInfo pageInfo = new PagingInfo
                {
                    CurrentPage = 1,
                    ItemsPerPage = PAGE_SIZE_DETAIL,
                    TotalItems = list.Count(),

                };
                gmModel.PageInfo = pageInfo;

                gmModel.Results = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
            }
            else
            {
                gmModel.Results = null;

                //Store result into session
                this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = null;
            }
            return PartialView(gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="selectedPage"></param>
        /// <param name="pageRequest"></param>
        /// <param name="SeqNum"></param>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public ActionResult OutboundDeliveryIndicationDetailPaging(PagingRequest pageRequest, int SeqNum, OutboundDeliveryIndicationDetail gmModel)
        {
            //Clear Model State
            this.ClearModelState();

            //Get search result from session
            List<OutboundDeliveryIndicationDetailResult> list = ((IQueryable<OutboundDeliveryIndicationDetailResult>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()]).ToList();

            foreach (var item in gmModel.Results)
            {
                list.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD)).SingleOrDefault().Reserve = item.Reserve;
            }

            var listI = list.AsQueryable();

            //Get Sort Info
            var sortList = this.GetOrderList(gmModel.txt_CustomerCD);

            //Set sorting
            if (sortList.Count > 0)
            {
                listI = listI.iOrderBy(sortList[0].SortField, sortList[0].Direction);
                for (int i = 1; i < sortList.Count; i++)
                {
                    listI = listI.iThenBy(sortList[i].SortField, sortList[i].Direction);
                }
            }

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()] = listI;

            //Paging
            this.PagingBase<OutboundDeliveryIndicationDetailResult>(ref listI, pageRequest, new SortingInfo(), SeqNum, gmModel.PageInfo.ItemsPerPage, notStore: true);

            IQueryable<OutboundDeliveryIndicationDetailResult> Grid = (IQueryable<OutboundDeliveryIndicationDetailResult>)ViewBag.Result;

            gmModel.PageInfo = (PagingInfo)ViewBag.PagingInfo;

            //Grid Data
            gmModel.Results = Grid.ToList();

            return PartialView("_OutboundDeliveryIndicationDetailList", gmModel);
        }

        /// <summary>
        /// Cofirm
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        public ActionResult OutboundDeliveryIndicationDetailConfirm(OutboundDeliveryIndicationDetail header)
        {
            //Clear Modestate
            this.ClearModelState();

            //Clear session
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + header.SeqNum.ToString()] = null;

            if (this.ModelState.IsValid)
            {
                if (header.Results == null || header.Results.Count == 0)
                {
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                }
                else
                {
                    List<string> listKey = new List<string>();
                    List<string> listErrors = new List<string>();
                    List<OutboundDeliveryIndicationDetailResult> list = ((IQueryable<OutboundDeliveryIndicationDetailResult>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + header.SeqNum.ToString()]).ToList();
                    int page = 1;
                    int firstPageErr = 0;
                    int firstRowErr = -1;
                    foreach (var item in header.Results)
                    {
                        list.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD)).SingleOrDefault().Reserve = item.Reserve;
                    }

                    var listData = list.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();

                    if (listData.Count == 0)
                    {
                        //this.ModelState.AddModelError(string.Format(KEY_RESERVE, 0), UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                        firstPageErr = 1;
                        firstRowErr = 0;
                        listErrors.Add(UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                    }
                    else
                    {
                        int row = 1;
                        foreach (var item in list)
                        {
                            string errorMes = this.CheckDataOfRow(item);
                            if (!string.IsNullOrEmpty(errorMes))
                            {
                                string rowErr = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), row);
                                string pageRee = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0221), page);
                                firstPageErr = firstPageErr == 0 ? page : firstPageErr;
                                firstRowErr = firstRowErr == -1 ? row : firstRowErr;
                                listErrors.Add(errorMes + pageRee + rowErr);
                                listKey.Add(item.TagNo + item.LocationCD);
                            }

                            row++;
                            if (row == PAGE_SIZE_DETAIL + 1)
                            {
                                row = 1;
                                page++;
                            }
                        }
                    }

                    if (listErrors.Count == 0)
                    {
                        this.Session[this.CreateKeySession(header.RowNo.ToString(), header.SeqNum.ToString())] = listData;
                    }
                    else
                    {
                        //Create paging info
                        PagingInfo pageInfo = new PagingInfo
                        {
                            CurrentPage = firstPageErr,
                            ItemsPerPage = PAGE_SIZE_DETAIL,
                            TotalItems = list.Count(),
                        };
                        header.PageInfo = pageInfo;

                        header.Results = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
                        this.Session[Constant.SESSION_GRID_ERROR_KEYS + header.SeqNum.ToString()] = listKey;
                        for (int i = listErrors.Count - 1; i >= 0; i--)
                        {
                            if (i == 0)
                            {
                                this.ModelState.AddModelError(string.Format("Results[{0}].Reserve", firstRowErr), listErrors[i]);
                            }
                            else
                            {
                                this.ModelState.AddModelError(string.Empty, listErrors[i]);
                            }
                        }
                    }
                }
            }

            ViewBag.SortingInfo = new SortingInfo();
            //Validate info to close form
            header.IsErrors = this.ModelState.Values.Any(m => m.Errors.Count > 0);

            //If no error then clear session all pages
            if (!header.IsErrors)
            {
                this.Session[Constant.SESSION_LIST_SEARCH_RESULT + header.SeqNum.ToString()] = null;
            }
            return PartialView("OutboundDeliveryIndicationDetail", header);
        }

        /// <summary>
        /// check Data of row
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        private string CheckDataOfRow(OutboundDeliveryIndicationDetailResult item)
        {
            string errorMes = string.Empty;
            //if not input
            if (string.IsNullOrEmpty(item.Reserve))
            {
                return errorMes;
            }

            string errorName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0152);

            int reserveValue = 0;
            if (CommonUtil.TryParseInt(item.Reserve, ref reserveValue))
            {
                if (reserveValue == 0)
                {
                    errorMes = UserSession.Session.SysCache.GetMessage(Constant.MES_E0005);
                    return String.Format(errorMes, "0", errorName);
                }

                if (reserveValue > item.NumBoxes || reserveValue < item.PickingQuantity)
                {
                    string numBoxesName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0127);
                    string pickingName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0166);

                    //Format Message
                    errorMes = UserSession.Session.SysCache.GetMessage(Constant.MES_E0021);
                    return String.Format(errorMes, errorName, pickingName, numBoxesName);
                }
            }
            else
            {
                errorMes = UserSession.Session.SysCache.GetMessage(Constant.MES_M0004);
                return String.Format(errorMes, errorName);
            }
            return errorMes;
        }

        /// <summary>
        /// Create data
        /// </summary>
        /// <param name="gmModel"></param>
        /// <param name="sortList"></param>
        /// <returns></returns>
        private IQueryable<OutboundDeliveryIndicationDetailResult> CreateDataDetail(OutboundDeliveryIndicationDetail gmModel, List<SortingInfo> sortList)
        {
            var modeState = this.GetMode(gmModel.SeqNum);

            //list result
            List<OutboundDeliveryIndicationDetailResult> ret = new List<OutboundDeliveryIndicationDetailResult>();

            var dac = new DAC.TShippingInstruction();
            if (modeState == Mode.Show || gmModel.PickCompleteFlag)
            {
                ret = dac.GetListDetailResultForShow(gmModel);
            }
            else
            {
                ret = dac.GetListDetailResultForNewAndEdit(gmModel);
            }

            ret = ret.Where(m => !(string.IsNullOrEmpty(m.Reserve) && m.NumBoxes <= 0)).ToList();

            var retI = ret.AsQueryable();
            //Set sorting
            if (sortList.Count > 0)
            {
                retI = retI.iOrderBy(sortList[0].SortField, sortList[0].Direction);
                for (int i = 1; i < sortList.Count; i++)
                {
                    retI = retI.iThenBy(sortList[i].SortField, sortList[i].Direction);
                }
            }
            return retI;
        }

        /// <summary>
        /// Create data
        /// </summary>
        /// <param name="gmModel"></param>
        /// <param name="sortList"></param>
        /// <returns></returns>
        private IQueryable<OutboundDeliveryIndicationDetailResult> CreateDataDetail_old(OutboundDeliveryIndicationDetail gmModel, List<SortingInfo> sortList)
        {
            var modeState = this.GetMode(gmModel.SeqNum);

            //list result
            List<OutboundDeliveryIndicationDetailResult> ret = this.tInventory_HService.GetListShippingInstructionDetailNew(gmModel).ToList();

            //list Reserve
            var lstTReserve = this.tReserveService.GetList();

            if (modeState.Equals(Mode.Insert))
            {
                foreach (var item in ret)
                {
                    var temp = lstTReserve.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD));
                    if (temp != null && temp.Count() > 0)
                    {
                        item.ReserveQuantity = temp.Sum(m => m.RemainQuantity);
                    }

                    item.NumBoxes = item.NumBoxes - item.ReserveQuantity;
                    item.PickedFlag = item.PickingQuantity != 0;
                }
            }
            else
            {
                List<string> listKey = new List<string>();

                foreach (var item in ret)
                {
                    var temp = lstTReserve.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD));
                    if (temp != null && temp.Count() > 0)
                    {
                        item.ReserveQuantity = temp.Sum(m => m.RemainQuantity);

                    }

                    //set Reserve
                    int reserveValue = 0;
                    var tempR = temp.Where(m => m.ShipNo.Equals(gmModel.ShipNo)).SingleOrDefault();
                    if (tempR != default(TReserve))
                    {
                        item.Reserve = tempR.Quantity.ToString();
                        reserveValue = tempR.Quantity;
                        item.PickingQuantity = tempR.Quantity - tempR.RemainQuantity;
                    }
                    else
                    {
                        item.PickingQuantity = 0;
                    }

                    //set Numboxes
                    item.NumBoxes = item.NumBoxes - item.ReserveQuantity + reserveValue;
                    item.PickedFlag = item.PickingQuantity != 0;
                    listKey.Add(item.TagNo + item.LocationCD);
                }

                var lisReserveAdd = this.tReserveService.GetListByConditionForOutDeliIndiDetail(gmModel);
                var listAdd = lisReserveAdd.Where(m => !listKey.Contains(m.TagNo + m.LocationCD));
                if (listAdd != null && listAdd.Count() != 0)
                {
                    foreach (var item in listAdd)
                    {
                        var itemNew = this.tInventory_HService.GetListShippingInstructionDetailNewAdd(item, gmModel.txt_ProductCD, gmModel.SeqNum);
                        if (itemNew != default(OutboundDeliveryIndicationDetailResult))
                        {
                            ret = ret.Union(itemNew).ToList();
                        }
                    }
                }
            }

            ret = ret.Where(m => !(string.IsNullOrEmpty(m.Reserve) && m.NumBoxes <= 0)).ToList();

            var retI = ret.AsQueryable();
            //Set sorting
            if (sortList.Count > 0)
            {
                retI = retI.iOrderBy(sortList[0].SortField, sortList[0].Direction);
                for (int i = 1; i < sortList.Count; i++)
                {
                    retI = retI.iThenBy(sortList[i].SortField, sortList[i].Direction);
                }
            }
            return retI;
        }

        /// <summary>
        /// Clear error detail on search
        /// </summary>
        /// <param name="gmModel"></param>
        private void ClearModelStateDetail(OutboundDeliveryIndicationDetail gmModel)
        {
            if (gmModel.Results != null)
            {
                for (int i = 0; i < gmModel.Results.Count; i++)
                {
                    this.ClearModelStateByKey(string.Format(KEY_RESERVE, i));
                }
            }
        }

        /// <summary>
        /// CreateDetail
        /// </summary>
        /// <param name="seqNum">seqNum</param>
        /// <param name="shipNo">shipNo</param>
        /// <param name="CustomerCD">CustomerCD</param>
        /// <param name="productCD">productCD</param>
        /// <param name="Quantity">Quantity</param>
        /// <param name="oldResult">oldResult</param>
        /// <returns>List</returns>
        private List<OutboundDeliveryIndicationDetailResult> CreateDetail(int seqNum, string shipNo, string CustomerCD, string productCD, int Quantity, List<OutboundDeliveryIndicationDetailResult> oldResult)
        {
            List<OutboundDeliveryIndicationDetailResult> ret = new List<OutboundDeliveryIndicationDetailResult>();

            OutboundDeliveryIndicationDetail gmModel = new OutboundDeliveryIndicationDetail();
            gmModel.txt_ProductCD = productCD;
            gmModel.ShipNo = shipNo;
            gmModel.SeqNum = seqNum;

            var dac = new DAC.TShippingInstruction();

            IQueryable<OutboundDeliveryIndicationDetailResult> list = dac.GetListDetailResultForNewAndEdit(gmModel).AsQueryable();

            //Check result is empty
            int count = list.Count();
            if (count == 0)
            {
                return new List<OutboundDeliveryIndicationDetailResult>();
            }

            //Get Sort Info
            var Sorts = this.GetOrderList(CustomerCD);

            //Set sorting
            if (Sorts.Count > 0)
            {
                list = list.iOrderBy(Sorts[0].SortField, Sorts[0].Direction);
                for (int i = 1; i < Sorts.Count; i++)
                {
                    list = list.iThenBy(Sorts[i].SortField, Sorts[i].Direction);
                }
            }
            
            //Create new List
            if (oldResult == default(List<OutboundDeliveryIndicationDetailResult>) || oldResult.Count() == 0)
            {
                int curQuantity = Quantity;
                foreach (var item in list)
                {
                    int itemReserve = curQuantity - item.NumBoxes > 0 ? item.NumBoxes : curQuantity;
                    curQuantity = curQuantity - item.NumBoxes;

                    item.Reserve = itemReserve <= 0 ? string.Empty : itemReserve.ToString();

                    ret.Add(item);
                    if (curQuantity <= 0)
                    {
                        return ret.Where(m => !(string.IsNullOrEmpty(m.Reserve) && m.NumBoxes <= 0)).ToList();
                    }
                }
            }
            else //Edit old List
            {
                int Reserve = 0;
                int oldQuantity = oldResult.Where(m => Utility.CommonUtil.TryParseInt(m.Reserve, ref Reserve)).Sum(m => CommonUtil.ParseInteger(m.Reserve));
                if (Quantity > oldQuantity) //Add Quantity
                {
                    List<string> listKey = new List<string>();
                    int needAdd = Quantity - oldQuantity;
                    foreach (var item in oldResult)
                    {
                        if (needAdd > 0)
                        {

                            int canAdd = item.NumBoxes - CommonUtil.ParseInteger(item.Reserve);
                            int newReserve = CommonUtil.ParseInteger(item.Reserve) + (needAdd > canAdd ? canAdd : needAdd);
                            item.Reserve = newReserve <= 0 ? string.Empty : newReserve.ToString();
                            needAdd = needAdd - canAdd;

                        }
                        listKey.Add(item.TagNo + item.LocationCD + item.ArrivalDate);
                        ret.Add(item);
                    }
                    if (needAdd > 0)
                    {
                        var listNew = list.Where(m => !listKey.Contains(m.TagNo + m.LocationCD + m.ArrivalDate));

                        foreach (var item in listNew)
                        {
                            int itemReserve = needAdd - item.NumBoxes > 0 ? item.NumBoxes : needAdd;
                            needAdd = needAdd - item.NumBoxes;

                            item.Reserve = itemReserve <= 0 ? string.Empty : itemReserve.ToString();
                            ret.Add(item);
                            if (needAdd <= 0)
                            {
                                break;
                            }
                        }
                    }
                }
                else // sub quantity
                {

                    int needSub = oldQuantity - Quantity;
                    for (int i = oldResult.Count - 1; i >= 0; i--)
                    {
                        int oldReserve = CommonUtil.ParseInteger(oldResult[i].Reserve);
                        oldResult[i].Reserve = oldReserve > needSub ? (oldReserve - needSub).ToString() : string.Empty;
                        needSub = needSub - oldReserve;
                        if (needSub <= 0)
                        {
                            break;
                        }
                    }
                    ret = oldResult.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
                }

            }
            ret = ret.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
            IQueryable<OutboundDeliveryIndicationDetailResult> retS = ret.AsQueryable();
            if (Sorts.Count > 0)
            {
                retS = retS.iOrderBy(Sorts[0].SortField, Sorts[0].Direction);
                for (int i = 1; i < Sorts.Count; i++)
                {
                    retS = retS.iThenBy(Sorts[i].SortField, Sorts[i].Direction);
                }
            }
            return retS.ToList();
        }

        /// <summary>
        /// CreateDetail
        /// </summary>
        /// <param name="seqNum">seqNum</param>
        /// <param name="shipNo">shipNo</param>
        /// <param name="CustomerCD">CustomerCD</param>
        /// <param name="productCD">productCD</param>
        /// <param name="Quantity">Quantity</param>
        /// <param name="oldResult">oldResult</param>
        /// <returns>List</returns>
        private List<OutboundDeliveryIndicationDetailResult> CreateDetail_old(int seqNum, string shipNo, string CustomerCD, string productCD, int Quantity, List<OutboundDeliveryIndicationDetailResult> oldResult)
        {
            List<OutboundDeliveryIndicationDetailResult> ret = new List<OutboundDeliveryIndicationDetailResult>();

            OutboundDeliveryIndicationDetail gmModel = new OutboundDeliveryIndicationDetail();
            gmModel.txt_ProductCD = productCD;
            gmModel.ShipNo = shipNo;
            gmModel.SeqNum = seqNum;
            
            IQueryable<OutboundDeliveryIndicationDetailResult> list = this.tInventory_HService.GetListShippingInstructionDetailNew(gmModel);

            //Check result is empty
            int count = list.Count();
            if (count == 0)
            {
                return new List<OutboundDeliveryIndicationDetailResult>();
            }

            //Get Sort Info
            var Sorts = this.GetOrderList(CustomerCD);

            //Set sorting
            if (Sorts.Count > 0)
            {
                list = list.iOrderBy(Sorts[0].SortField, Sorts[0].Direction);
                for (int i = 1; i < Sorts.Count; i++)
                {
                    list = list.iThenBy(Sorts[i].SortField, Sorts[i].Direction);
                }
            }
            var lstTReserve = this.tReserveService.GetList();

            //Create new List
            if (oldResult == default(List<OutboundDeliveryIndicationDetailResult>) || oldResult.Count() == 0)
            {
                int curQuantity = Quantity;
                if (lstTReserve != null)
                {
                    foreach (var item in list)
                    {
                        var temp = lstTReserve.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD));
                        if (temp != null && temp.Count() > 0)
                        {
                            item.ReserveQuantity = temp.Sum(m => m.RemainQuantity);

                        }

                        item.NumBoxes = item.NumBoxes - item.ReserveQuantity;

                        int itemReserve = curQuantity - item.NumBoxes > 0 ? item.NumBoxes : curQuantity;
                        curQuantity = curQuantity - item.NumBoxes;

                        item.Reserve = itemReserve <= 0 ? string.Empty : itemReserve.ToString();

                        ret.Add(item);
                        if (curQuantity <= 0)
                        {
                            return ret.Where(m => !(string.IsNullOrEmpty(m.Reserve) && m.NumBoxes <= 0)).ToList();
                        }
                    }
                }
            }
            else //Edit old List
            {
                int Reserve = 0;
                int oldQuantity = oldResult.Where(m => Utility.CommonUtil.TryParseInt(m.Reserve, ref Reserve)).Sum(m => CommonUtil.ParseInteger(m.Reserve));
                if (Quantity > oldQuantity) //Add Quantity
                {
                    List<string> listKey = new List<string>();
                    int needAdd = Quantity - oldQuantity;
                    foreach (var item in oldResult)
                    {
                        if (needAdd > 0)
                        {

                            int canAdd = item.NumBoxes - CommonUtil.ParseInteger(item.Reserve);
                            int newReserve = CommonUtil.ParseInteger(item.Reserve) + (needAdd > canAdd ? canAdd : needAdd);
                            item.Reserve = newReserve <= 0 ? string.Empty : newReserve.ToString();
                            needAdd = needAdd - canAdd;

                        }
                        listKey.Add(item.TagNo + item.LocationCD + item.ArrivalDate);
                        ret.Add(item);
                    }
                    if (needAdd > 0)
                    {
                        var listNew = list.Where(m => !listKey.Contains(m.TagNo + m.LocationCD + m.ArrivalDate));

                        foreach (var item in listNew)
                        {
                            var temp = lstTReserve.Where(m => m.TagNo.Equals(item.TagNo) && m.LocationCD.Equals(item.LocationCD));
                            if (temp != null && temp.Count() > 0)
                            {
                                item.ReserveQuantity = temp.Sum(m => m.RemainQuantity);
                            }

                            item.NumBoxes = item.NumBoxes - item.ReserveQuantity;

                            int itemReserve = needAdd - item.NumBoxes > 0 ? item.NumBoxes : needAdd;
                            needAdd = needAdd - item.NumBoxes;

                            item.Reserve = itemReserve <= 0 ? string.Empty : itemReserve.ToString();
                            ret.Add(item);
                            if (needAdd <= 0)
                            {
                                break;
                            }
                        }
                    }
                }
                else // sub quantity
                {

                    int needSub = oldQuantity - Quantity;
                    for (int i = oldResult.Count - 1; i >= 0; i--)
                    {
                        int oldReserve = CommonUtil.ParseInteger(oldResult[i].Reserve);
                        oldResult[i].Reserve = oldReserve > needSub ? (oldReserve - needSub).ToString() : string.Empty;
                        needSub = needSub - oldReserve;
                        if (needSub <= 0)
                        {
                            break;
                        }
                    }
                    ret = oldResult.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
                }

            }
            ret = ret.Where(m => !string.IsNullOrEmpty(m.Reserve)).ToList();
            IQueryable<OutboundDeliveryIndicationDetailResult> retS = ret.AsQueryable();
            if (Sorts.Count > 0)
            {
                retS = retS.iOrderBy(Sorts[0].SortField, Sorts[0].Direction);
                for (int i = 1; i < Sorts.Count; i++)
                {
                    retS = retS.iThenBy(Sorts[i].SortField, Sorts[i].Direction);
                }
            }
            return retS.ToList();
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.iQueryable;
using InventoryManagement.Common;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Utility;
using InventoryManagement.Validation;
using System.Collections;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Author: ISV-GIAM
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class KindController : BaseController
    {
        #region Common

        private DataAccess.MKind_HService mKindHService;
        private DataAccess.MKind_DService mKindDService;
        private DataAccess.MUserService mUserService;
        private DataAccess.MProductService mProductService;
        private DataAccess.TStockAllowanceService tStockAllowanceService;
        private DataAccess.TInventory_DService tInventoryDService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.MGroup_DService mGroup_DService;
        private int pageSize = 1;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mKindHService">MKindHService</param>
        /// <param name="mKindDService">MKindDService</param>
        /// <param name="mUserService">MUserService</param>
        /// <param name="mProductService">MProductService</param>
        /// <param name="tStockAllowanceService">TStockAllowanceService</param>
        /// <param name="tInventoryDService">TInventoryDService</param>
        /// <param name="mGroup_DService">MGroup_DService</param>
        public KindController(DataAccess.MKind_HService mKindHService,
                              DataAccess.MKind_DService mKindDService,
                              DataAccess.MUserService mUserService,
                              DataAccess.MProductService mProductService,
                              DataAccess.TStockAllowanceService tStockAllowanceService,
                              DataAccess.TInventory_DService tInventoryDService,
                              DataAccess.TBalanceInStoresService tBalanceInStoresService,
                              DataAccess.MGroup_DService mGroup_DService) 
        {
            this.mKindHService = mKindHService;
            this.mKindDService = mKindDService;
            this.mUserService = mUserService;
            this.mProductService = mProductService;
            this.tStockAllowanceService = tStockAllowanceService;
            this.tInventoryDService = tInventoryDService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.mGroup_DService = mGroup_DService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.mKindHService.Context = ctx;
            this.mKindDService.Context = ctx;
            this.mUserService.Context = ctx;
            this.mProductService.Context = ctx;
            this.tStockAllowanceService.Context = ctx;
            this.tInventoryDService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.mGroup_DService.Context = ctx;
            this.pageSize = this.mKindDService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string KEY_KIND_CD = "KindCD";
        private const string KEY_KIND_NAME = "KindName";
        private const string KEY_DATA_CD = "DataCD";
        private const string KEY_VALUE = "Value";

        private const string SCREEN_INDEX = "Index";

        private const string SEARCH_KIND_CD = "txt_KindCD";
        private const string SEARCH_KIND_NAME = "txt_KindName";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/Kind/Sorting";

        private const int ROWNUMBER_DEFAULT = 10;

        private const string BUTTON_EDIT = "btnUpdate";
        private const string BUTTON_BACK = "btnBack";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// List
        /// </summary>
        /// <param name="gmModel">KindHeaderList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(KindHeaderList gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                KindHeaderList oldModel = (KindHeaderList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(KindHeaderList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<KindHeaderResults> results = this.mKindHService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<KindHeaderResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_KIND_CD);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<KindHeaderResults> results = this.mKindHService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<KindHeaderResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_KIND_CD);
            }
            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View("Index", gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<KindHeaderResults> list = (IQueryable<KindHeaderResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<KindHeaderResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<KindHeaderResults> list = (IQueryable<KindHeaderResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<KindHeaderResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        #endregion

        #region Show

        /// <summary>
        /// View Detail
        /// </summary>
        /// <param name="value1">KindCD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0038);

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            //Get data
            KindDetail gmodel = new KindDetail();

            //Get header data
            KindHeaderResults ret = mKindHService.GetHeaderResultsByKindCD(value1);

            //Check exclusion
            if (ret == default(KindHeaderResults))
            {
                return this.ExclusionProcess(value2);
            }

            //Show header
            gmodel.KindCD = value1;
            gmodel.PreKindCD = value1;
            gmodel.KindName = ret.KindName;
            gmodel.UpdateDate = ret.UpdateDate;
            gmodel.DeleteFlag = ret.DeleteFlag;

            //Details
            gmodel.Detail = this.mKindDService.GetListValueByKindCD(value1).ToList();

            //Show gridview [plus]
            if (gmodel.Detail.Count() > 0)
            {
                for (int i = 0; i < gmodel.Detail.Count(); i++)
                {
                    gmodel.Detail[i].NumRow = i + 1;
                    gmodel.Detail[i].SeqNum = value2;
                }
            }

            //Get IsExistInTable Property
            this.GetIsExistInTableProperty(gmodel);

            //Store data into session
            gmodel.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + gmodel.SeqNum.ToString()] = gmodel;

            //Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View("Details", gmodel);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="preKindCD">preKindCD</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string preKindCD, int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0039);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(KEY_KIND_CD);

            //Set data display
            KindDetail gmodel = new KindDetail();
            gmodel.PreKindCD = preKindCD;
            gmodel.SeqNum = SeqNum;

            //Add empty rows 
            this.AddEmtyRows(gmodel, ROWNUMBER_DEFAULT, SeqNum);

            return View("Details", gmodel);
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(KindDetail gmModel)
        {
            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Kind/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            KindDetail gmModel = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //Insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(KindDetail gmModel)
        {
            bool ret = true;

            //Check header (KindCD, KindName)
            if (!this.InsertCheckHeader(gmModel))
            {
                ret = false;
            }

            //Check gridview (DataCD, Values)
            if (!this.InsertCheckGrid(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(KindDetail gmModel)
        {
            //Get insert model
            MKind_H modelHeader = this.GetInsertDataHeader(gmModel);
            List<MKind_D> listModelDetails = this.GetInsertDataDetails(gmModel);

            try
            {
                this.mKindHService.Insert(modelHeader);
                this.mKindDService.Insert(listModelDetails);

                //Submit only header context
                this.mKindHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MKind_H_PK) || sqlEx.Message.Contains(Constant.DB_MKind_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data for header
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>MKind_H</returns>
        private MKind_H GetInsertDataHeader(KindDetail gmModel)
        {
            MKind_H ret = new MKind_H();

            ret.KindCD = gmModel.KindCD;
            ret.KindName = gmModel.KindName;
            ret.DeleteFlag = false;
            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        /// <summary>
        /// Get Insert data for details
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>List of MKind_D</returns>
        private List<MKind_D> GetInsertDataDetails(KindDetail gmModel)
        {
            List<MKind_D> listResult = new List<MKind_D>();

            for (int i = 0; i < gmModel.Detail.Count(); i++)
            {
                if (string.IsNullOrEmpty(gmModel.Detail[i].DataCD))
                {
                    continue;
                }

                //Set data to insert for each Language type
                for (int j = 0; j < 3; j++)
                {
                    MKind_D ret = this.SetDataInsertForeachLanguage(gmModel, i, j);
                    listResult.Add(ret);
                }
            }
            return listResult;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0041);

            //Get data
            KindDetail gmModel = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set IsUsedByOther
            foreach (var item in gmModel.Detail)
            {
                item.IsUsedDataCD = this.IsUsedByOther(gmModel.KindCD, item.DataCD);
            }

            //Get UpdateDate
            KindHeaderResults ret = mKindHService.GetHeaderResultsByKindCD(gmModel.KindCD);

            //Check Exclusion
            if (ret == default(KindHeaderResults) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Add empty rows
            int rowsAddNum = ROWNUMBER_DEFAULT - gmModel.Detail.Count();
            this.AddEmtyRows(gmModel, rowsAddNum, gmModel.SeqNum);

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_KIND_NAME);
            return View("Details", gmModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(KindDetail gmModel)
        {
            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Kind/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            KindDetail gmModel = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update data
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/Kind/Show", gmModel.KindCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">screen KindDetail</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(KindDetail gmModel)
        {
            bool ret = true;

            //Get language type
            int language = InventoryManagement.UserSession.Session.Language.GetHashCode();

            //Check data changed header
            if (this.mKindHService.CheckDataChanged(gmModel))
            {
                //Show error Message
                this.ShowMessageExclusion("/Kind/Show", gmModel.KindCD, gmModel.SeqNum.ToString());
                ret = false;
            }

            //Check data changed details
            IQueryable<MKind_D> dbDetailModel = this.mKindDService.GetListDetailByKindCD(gmModel.KindCD);
            IQueryable<MKind_D> listDel = this.GetlistDelWithinLanguage(dbDetailModel, gmModel, language);

            foreach (var item in listDel)
            {
                if (IsUsedByOther(gmModel.KindCD, item.DataCD))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0023, item.DataCD);
                    this.ModelState.AddModelError(String.Empty, message);
                    ret = false;
                }
            }

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(KindDetail gmModel)
        {
            try
            {
                //Get update model
                MKind_H dbHeaderModel = this.mKindHService.GetHeaderByKindCD(gmModel.KindCD);
                IQueryable<MKind_D> dbDetailModel = this.mKindDService.GetListDetailByKindCD(gmModel.KindCD);

                if (dbHeaderModel == default(MKind_H) || dbHeaderModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Edit Header Data
                dbHeaderModel.KindName = gmModel.KindName;
                dbHeaderModel.UpdateDate = this.GetCurrentDate();
                dbHeaderModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                dbHeaderModel.DeleteFlag = gmModel.DeleteFlag;

                //Edit Details Data
                //Get list DataCD replaced
                IQueryable<MKind_D> listDel = this.GetlistDelWithoutLanguage(dbDetailModel, gmModel);

                //Delete details
                foreach (var item in listDel)
                {
                    //Check Data change
                    if (IsUsedByOther(item.KindCD, item.DataCD))
                    {
                        return CommitFlag.DataChanged;
                    }
                    else
                    {
                        this.mKindDService.Delete(item);
                    }
                }

                //Insert and Update details
                for (int i = 0; i < gmModel.Detail.Count(); i++)
                {
                    if (string.IsNullOrEmpty(gmModel.Detail[i].DataCD))
                    {
                        continue;
                    }

                    //Insert
                    if (!this.mKindDService.IsExistInMKind_D(dbDetailModel, gmModel.Detail[i].DataCD))
                    {
                        for (int j = 0; j < 3; j++)
                        {
                            //Set data to insert for each Language type
                            MKind_D ret = this.SetDataInsertForeachLanguage(gmModel, i, j);
                            this.mKindDService.Insert(ret);
                        }
                    }
                    //Update
                    else
                    {
                        //Get detail data foreach a group (KindCD, DataCD)
                        List<MKind_D> upDetailModel = this.mKindDService.GetDetailByKindCDAndDataCD(gmModel.KindCD, gmModel.Detail[i].DataCD);

                        for (int j = 0; j < 3; j++)
                        {
                            //Update detail data for each Language type
                            this.UpdateDetaiForeachLanguage(upDetailModel, gmModel, i, j);
                        }
                    }
                }

                //Submit only header context
                this.mKindHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MKind_H_PK) || sqlEx.Message.Contains(Constant.DB_MKind_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(KindDetail gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }

            //Set mode state
            this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

            //Get data
            KindDetail dbModel = new KindDetail();

            //Get header data
            KindHeaderResults ret = mKindHService.GetHeaderResultsByKindCD(gmModel.KindCD);

            //Check exclusion
            if (ret == default(KindHeaderResults) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            //Show header
            dbModel.KindCD = gmModel.KindCD;
            dbModel.PreKindCD = gmModel.KindCD;
            dbModel.KindName = ret.KindName;
            dbModel.UpdateDate = ret.UpdateDate;
            dbModel.DeleteFlag = ret.DeleteFlag;

            dbModel.SeqNum = gmModel.SeqNum;

            //Details
            dbModel.Detail = this.mKindDService.GetListValueByKindCD(gmModel.KindCD).ToList();

            //Show gridview [plus]
            if (dbModel.Detail.Count() > 0)
            {
                for (int i = 0; i < dbModel.Detail.Count(); i++)
                {
                    dbModel.Detail[i].NumRow = i + 1;
                }
            }

            //Add number sequen for detail
            dbModel.AddSeqForDetail();

            //Check data exists in another table
            bool isExistsOrtherTB = false;           
            foreach (var item in gmModel.Detail)
            {
                if (this.IsUsedByOther(gmModel.KindCD, item.DataCD))
                {
                    isExistsOrtherTB = true;
                    break;
                }
            }

            //set IsExistsOrtherTB property
            dbModel.IsExistsOrtherTB = isExistsOrtherTB;

            if (!isExistsOrtherTB)
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(dbModel.SeqNum, "/Kind/DeleteAction", value1: dbModel.SeqNum.ToString());
            }
            else
            {
                //Can't delete data
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((KindDetailGrid m) => m.DataCD));
                this.ModelState.AddModelError(string.Empty, message);
            }

            return View("Details", dbModel);
        }

        /// <summary>
        /// Delete action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            KindDetail model = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            //Delete data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.KindCD, value1);
                    break;

                case CommitFlag.IsExistsInAnotherTB:

                    message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((KindDetail m) => m.KindCD));
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.KindCD, value1);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.KindCD, value1);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(KindDetail gmModel)
        {
            try
            {
                //Check data changed
                MKind_H dbModel = this.mKindHService.GetHeaderByKindCD(gmModel.KindCD);
                if (dbModel == default(MKind_H) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Check data exists in another table
                foreach (var item in gmModel.Detail)
	            {
                    if (this.IsUsedByOther(gmModel.KindCD, item.DataCD))
                    {
                        return CommitFlag.IsExistsInAnotherTB;
                    }
	            }

                //Set delete data
                this.SetDeleteData(dbModel);
                this.mKindHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MKind_H_PK) || sqlEx.Message.Contains(Constant.DB_MKind_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="dbModel">MKind_H</param>
        private void SetDeleteData(MKind_H dbModel)
        {
            dbModel.DeleteFlag = true;
            dbModel.UpdateDate = this.GetCurrentDate();
            dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0039);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            KindDetail gmModel = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Add empty rows
            int rowsAddNum = ROWNUMBER_DEFAULT - gmModel.Detail.Count();
            this.AddEmtyRows(gmModel, rowsAddNum, SeqNum);

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_KIND_CD);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action Confirm
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(KindDetail gmModel)
        {
            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {             
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Kind/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            KindDetail gmModel = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //insert data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(KindDetail gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreKindCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreKindCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Remove/Add rows

        /// <summary>
        /// Delete a row
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult RemoveRow(KindDetail gmModel)
        {
            this.ClearModelState();

            //Get current index
            int index = gmModel.currentIndex;

            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (gmModel.Detail.Count > 1)
            {
                //Select check
                if (this.RemoveRowCheck(gmModel))
                {
                    //Remove row
                    gmModel.Detail.RemoveAt(index - 1);

                    //Reset numer of rows
                    for (int i = 0; i < gmModel.Detail.Count(); i++)
                    {
                        gmModel.Detail[i].NumRow = i + 1;
                    }
                }
                else
                {
                    string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((KindDetailGrid m) => m.DataCD));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].DataCD", index - 1), message);
                }
            }
            else
            {
                string message = this.FormatMessage(Constant.MES_M0028, CommonUtil.GetDisplayName((KindDetailGrid m) => m.DataCD));
                this.ModelState.AddModelError(string.Format("Detail[{0}].DataCD", index - 1), message);
            }

            //Get IsExistInTable Property
            this.GetIsExistInTableProperty(gmModel);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Check delete DataCD
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        public bool RemoveRowCheck(KindDetail gmModel)
        {
            bool ret = true;

            //Get modeState
            Mode modeState = this.GetMode(gmModel.SeqNum);

            //Get current index
            int index = gmModel.currentIndex;

            if (modeState == Mode.Update)
            {
                string dataCD = gmModel.Detail[index - 1].DataCD;
                if (!String.IsNullOrEmpty(dataCD))
                {
                    ret = !this.IsUsedByOther(gmModel.KindCD, dataCD);
                }
            }

            return ret;
        }

        /// <summary>
        /// Add rows
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Add(KindDetail gmModel)
        {
            this.ClearModelState();
            //Add an empty row 
            this.AddEmtyRows(gmModel, 1, gmModel.SeqNum);

            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            //Get IsExistInTable Property
            this.GetIsExistInTableProperty(gmModel);

            //Set Focus
            this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].DataCD", gmModel.Detail.Count()-1)));
            return View("Details", gmModel);
        }
        #endregion

        #region CSV

        /// <summary>
        /// CSV
        /// </summary>
        /// <param name="gmModel">KindHeaderList</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(KindHeaderList gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();

            //Get model
            IQueryable<KindListCSV> kindListCSV = null;
            kindListCSV = this.mKindHService.GetListKindCSV();
            if (kindListCSV.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View(SCREEN_INDEX, gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MKind"];
            var filename = string.Format("{0}-{1}.csv", "MKind", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };
            var file = this.CSVOutPut<KindListCSV>(kindListCSV, hideColumn, fileFullName, "MKind.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            KindHeaderList oldModel = (KindHeaderList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<KindHeaderResults> results = this.mKindHService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<KindHeaderResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion CSV

        #region Private Methods

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/Kind/Index");

            KindDetail model = (KindDetail)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(KindDetail))
            {
                model = new KindDetail();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Check header(KindCD, KindName)
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckHeader(KindDetail gmModel)
        {
            bool ret = true;

            //Get modeState
            Mode modeState = this.GetMode(gmModel.SeqNum);

            if (modeState == Mode.Insert || modeState == Mode.Copy)
            {
                KindHeaderResults resultlist = this.mKindHService.GetHeaderResultsByKindCD(gmModel.KindCD);

                //Check exist KindCD
                if (resultlist != null)
                {
                    if (resultlist.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((KindDetail m) => m.KindCD));
                        this.ModelState.AddModelError(KEY_KIND_CD, message);
                        ret = false;
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0002, CommonUtil.GetDisplayName((KindDetail m) => m.KindCD));
                        this.ModelState.AddModelError(KEY_KIND_CD, message);
                        ret = false;
                    }
                }
            }

            //Gridview is empty
            bool NotEmptyDataCD = gmModel.Detail.Any(item => !string.IsNullOrEmpty(item.DataCD));

            if (!NotEmptyDataCD )
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, CommonUtil.GetDisplayName((KindDetailGrid m) => m.DataCD));
                this.ModelState.AddModelError(string.Format("Detail[{0}].DataCD", 0), message);
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check GridView (DataCD, Value)
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckGrid(KindDetail gmModel)
        {
            bool ret = true;
            List<string> listDup = new List<string>();

            for (int i = 0; i < gmModel.Detail.Count(); i++)
            {
                if (gmModel.Detail[i].isEmptyRow())
                {
                    continue;
                }

                //Duplicate DataCD
                if (!string.IsNullOrEmpty(gmModel.Detail[i].DataCD.Trim()))
                {
                    if (!listDup.Contains(gmModel.Detail[i].DataCD.Trim()))
                    {
                        listDup.Add(gmModel.Detail[i].DataCD.Trim());
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0019, CommonUtil.GetDisplayName((KindDetailGrid m) => m.DataCD));
                        this.ModelState.AddModelError(string.Format("Detail[{0}].DataCD", i), message);
                        ret = false;
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Check DataCd used by other table
        /// </summary>
        /// <param name="kindCD">KindCD</param>
        /// <param name="dataCD">DataCD</param>
        /// <returns>TRUE: invalid, FLASE: valid</returns>
        private bool IsUsedByOther(string kindCD, string dataCD)
        {
            bool ret = false;

            switch (kindCD)
            {
                case Constant.MKIND_KINDCD_STOCK_ALLOWANCE://03
                    ret = this.tStockAllowanceService.IsExistInTStockAllowance(dataCD);
                    break;
                case Constant.MKIND_KINDCD_STOCK_STATUS://04
                    ret = this.tInventoryDService.IsExistInTInventory(dataCD);
                    break;
                case Constant.MKIND_KINDCD_BALANCE_STATUS://05
                    ret = this.tBalanceInStoresService.IsExistInTBalanceInStores(dataCD);
                    break;
                case Constant.MKIND_KINDCD_GROUP_ROLES://08
                    ret = this.mGroup_DService.IsExistInMGroupDByRoles(dataCD);
                    break;
                case Constant.MKIND_KINDCD_VIEW1ST://09
                    ret = this.mGroup_DService.IsExistInMGroupDByView1st(dataCD);
                    break;
                case Constant.MKIND_KINDCD_VIEW2ND://10
                    ret = this.mGroup_DService.IsExistInMGroupDByView2nd(dataCD);
                    break;
                    
                default:
                    ret = false;
                    break;
            }
            return ret;
        }

        /// <summary>
        /// Add empty rows 
        /// </summary>
        /// <param name="gmodel">KindDetail</param>
        /// <param name="rowsNum">Number of rows</param>
        /// <param name="SeqNum">Sequense Key</param>
        private void AddEmtyRows(KindDetail gmodel, int rowsNum, int SeqNum)
        {
            for (int i = 0; i < rowsNum; i++)
            {
                KindDetailGrid item = new KindDetailGrid();
                
                item.NumRow = gmodel.Detail.Count + 1;
                item.SeqNum = SeqNum;
                item.DataCD = string.Empty;
                item.EngValue = string.Empty;
                item.VieValue = string.Empty;
                item.JapValue = string.Empty;
                item.IsUsedDataCD = false;

                gmodel.Detail.Add(item);
            }
        }

        /// <summary>
        /// Set Data to insert Foreach Language Type
        /// </summary>
        /// <param name="gmModel">KindDetail</param>
        /// <param name="idxDataCD">Index of DataCD</param>
        /// <param name="idxLang">Index of Language</param>
        /// <returns>MKind_D</returns>
        private MKind_D SetDataInsertForeachLanguage(KindDetail gmModel, int idxDataCD, int idxLang)
        {

            MKind_D ret = new MKind_D();
            ret.KindCD = gmModel.KindCD;
            ret.DataCD = gmModel.Detail[idxDataCD].DataCD;

            switch (idxLang)
            {
                case 0:
                    ret.Value = gmModel.Detail[idxDataCD].EngValue;
                    ret.Language = (byte)LanguageFlag.English;
                    break;
                case 1:
                    ret.Value = gmModel.Detail[idxDataCD].VieValue;
                    ret.Language = (byte)LanguageFlag.Vietnamese;
                    break;
                default:
                    ret.Value = gmModel.Detail[idxDataCD].JapValue;
                    ret.Language = (byte)LanguageFlag.Japanese;
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update detail data Foreach Language Type
        /// </summary>
        /// <param name="upDetailModel">List of MKind_D</param>
        /// <param name="gmModel">KindDetail</param>
        /// <param name="idxDataCD">Index of DataCD</param>
        /// <param name="idxLang">Index of Lang</param>
        private void UpdateDetaiForeachLanguage(List<MKind_D> upDetailModel, KindDetail gmModel, int idxDataCD, int idxLang)
        {
            upDetailModel[idxLang].DataCD = gmModel.Detail[idxDataCD].DataCD;

            switch (idxLang)
            {
                case 0:
                    upDetailModel[idxLang].Value = gmModel.Detail[idxDataCD].EngValue;
                    upDetailModel[idxLang].Language = (byte)LanguageFlag.English;
                    break;
                case 1:
                    upDetailModel[idxLang].Value = gmModel.Detail[idxDataCD].VieValue;
                    upDetailModel[idxLang].Language = (byte)LanguageFlag.Vietnamese;
                    break;
                default:
                    upDetailModel[idxLang].Value = gmModel.Detail[idxDataCD].JapValue;
                    upDetailModel[idxLang].Language = (byte)LanguageFlag.Japanese;
                    break;
            }
        }

        /// <summary>
        /// Get list DataCD deleted without Language
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dbDetailModel">IQueryable of MKind_D</param>
        /// <param name="gmModel">KindDetail</param>
        /// <returns>IQueryable of MKind_D</returns>
        public IQueryable<MKind_D> GetlistDelWithoutLanguage(IQueryable<MKind_D> dbDetailModel, KindDetail gmModel)
        {
            List<string> listDataCD = gmModel.Detail.Select(m=>m.DataCD).ToList();
            IQueryable<MKind_D> listDel = from i in dbDetailModel
                                          where !listDataCD.Contains(i.DataCD)
                                          select i;
            return listDel;
        }

        /// <summary>
        /// Get list DataCD deleted within Language
        /// Author:ISV-GIAM
        /// </summary>
        /// <param name="dbDetailModel">IQueryable of MKind_D</param>
        /// <param name="gmModel">KindDetail</param>
        /// <param name="language">Language type</param>
        /// <returns>IQueryable of MKind_D</returns>
        public IQueryable<MKind_D> GetlistDelWithinLanguage(IQueryable<MKind_D> dbDetailModel, KindDetail gmModel, int language)
        {
            List<string> listDataCD = gmModel.Detail.Select(m => m.DataCD).ToList();
            IQueryable<MKind_D> listDel = from i in dbDetailModel
                                          where !listDataCD.Contains(i.DataCD) && i.Language.Equals(language)
                                          select i;
            return listDel;
        }

        /// <summary>
        /// Get IsExistsOrtherTB property for KindDetail
        /// </summary>
        /// <param name="gmModel"></param>
        public void GetIsExistInTableProperty(KindDetail gmModel) 
        {
            //Check data exists in another table
            bool isExistsOrtherTB = false;
            foreach (var item in gmModel.Detail)
            {
                if (this.IsUsedByOther(gmModel.KindCD, item.DataCD))
                {
                    isExistsOrtherTB = true;
                    break;
                }
            }

            //set IsExistsOrtherTB property
            gmModel.IsExistsOrtherTB = isExistsOrtherTB;
        }

        #endregion
    }
}

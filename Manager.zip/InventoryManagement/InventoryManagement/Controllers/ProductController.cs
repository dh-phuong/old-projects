﻿using System;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Web.Helpers;
using System.Data.SqlClient;
using InventoryManagement.DataAccess;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Product
    /// Author: ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class ProductController : BaseController
    {

        #region Common

        private MProductService mProductService;
        private MKind_HService mKindHService;
        private MKind_DService mKindDService;
        private MCategoryService mCategoryService;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="mProductService">mProductService</param>
        /// <param name="mKindHService">mKindHService</param>
        /// <param name="mKindDService">mKindDService</param>
        /// <param name="mCategoryService">mCategoryService</param>
        public ProductController(MProductService mProductService, MKind_HService mKindHService, MKind_DService mKindDService, MCategoryService mCategoryService)
        {
            this.mProductService = mProductService;
            this.mKindHService = mKindHService;
            this.mKindDService = mKindDService;
            this.mCategoryService = mCategoryService;
            this.pageSize = this.mKindDService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string SRH_PRODUCT_CD = "txtProductCD";
        private const string SRH_PRODUCT_NAME = "txtProductName";
        private const string SRH_CATEGORY_CD = "txtCategoryCD";
        private const string SRH_COST_FROM = "txtCostFrom";

        private const string KEY_PRODUCT_CD = "ProductCD";
        private const string KEY_PRODUCT_NM = "ProductName";
        private const string KEY_CATEGORY_CD = "CategoryCD";
        private const string KEY_TOTAL_COST = "TotalCost";

        private const string SES_MODEL = "Session_Product_Model";
        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/Product/Sorting";
        private const string BUTTON_INSERT = "btnInsert";
        private const string BUTTON_EDIT = "btnEdit";
        private const string BUTTON_BACK = "btnBack";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// List
        /// </summary>
        /// <param name="gmModel">ProductList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(ProductList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                ProductList oldModel = (ProductList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(ProductList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<ProductResult> results = this.mProductService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<ProductResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SRH_PRODUCT_CD);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            if (this.ModelState.IsValid && !isFormBack)
            {

                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<ProductResult> results = mProductService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Create paging info
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<ProductResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SRH_PRODUCT_CD);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Index", gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Num</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<ProductResult> list = (IQueryable<ProductResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<ProductResult>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView("_List");
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Num</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<ProductResult> list = (IQueryable<ProductResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<ProductResult>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }       

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="preProductCD">preProductCD</param>
        /// <param name="SeqNum">Sequnece Num</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string preProductCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0015);

            //Set mode
            SetMode(Common.Mode.Insert, SeqNum);

            //Focus
            SetFocusId(KEY_PRODUCT_CD);

            ProductModels gmModel = new ProductModels();
            gmModel.PreProductCD = preProductCD;
            gmModel.SeqNum = SeqNum;
            gmModel.QuantityPerUnit = "1";

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="gmModel">Product Models</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(ProductModels gmModel)
        {
            //calculate total cost
            gmModel.TotalCost = this.CalculateTotalCost(gmModel.QuantityPerUnit, gmModel.Cost);
            if (this.ModelState.IsValid)
            {
                //Insert Check
                if (InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Set Message Confirm
                    ShowMessageConfirm(gmModel.SeqNum, "/Product/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            ProductModels gmModel = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert Check
            if (!InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //insert data
            ActionResult ret = default(ActionResult);
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0003));
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0009));
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Show

        /// <summary>
        /// View
        /// </summary>
        /// <param name="value1">Product Code</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0014);

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            //Get data
            ProductModels model = this.mProductService.GetByCd(value1);
            if (model == default(ProductModels))
            {
                return this.ExclusionProcess(value2);
            }

            model.IsExistsOrtherTB = this.mProductService.IsExistsInOrtherTable(model.PreProductCD);

            model.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            ////Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View("Details", model);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="DataKey">DataKey</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0017);

            //Get data
            ProductModels gmModel = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            ProductModels productModel = this.mProductService.GetByCd(gmModel.ProductCD);

            //Check Exclusion
            if (productModel == default(ProductModels) || gmModel.UpdateDate != productModel.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            productModel.IsExistsOrtherTB = mProductService.IsExistsInOrtherTable(productModel.ProductCD);

            //Set Sequence Number
            productModel.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_PRODUCT_NM);
            
            return View("Details", productModel);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(ProductModels gmModel)
        {
            //calculate Total cost
            gmModel.TotalCost = this.CalculateTotalCost(gmModel.QuantityPerUnit, gmModel.Cost);
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Product/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequen Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            ProductModels gmModel = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update check
            if (!this.UpdateCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            //Update data
            ActionResult ret = default(ActionResult);
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/Product/Show", gmModel.ProductCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;
                case CommitFlag.IsExistsInAnotherTB:

                    string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((ProductModels m) => m.ProductCD));
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0011));
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(ProductModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Get data
            ProductModels dbModel = this.mProductService.GetByCd(gmModel.ProductCD);

            //Check Exclusion
            if (dbModel == default(ProductModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            dbModel.IsExistsOrtherTB = this.mProductService.IsExistsInOrtherTable(dbModel.PreProductCD);
            dbModel.PreProductCD = gmModel.PreProductCD;
            dbModel.SeqNum = gmModel.SeqNum;

            if (!dbModel.IsExistsOrtherTB)
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(dbModel.SeqNum, "/Product/DeleteAction", value1: dbModel.SeqNum.ToString());
            }
            else
            {
                //Cant delete data
                ViewBag.AllowDelete = false;
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((ProductModels m) => m.ProductCD));
                this.ModelState.AddModelError(string.Empty, message);
            }

            return View("Details", dbModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            ProductModels model = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            //Delete data
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0003));
                    ret = Show(model.ProductCD, value1);
                    break;

                case CommitFlag.IsExistsInAnotherTB:
                    
                    string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((ProductModels m) => m.ProductCD));
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.ProductCD, value1);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0007));
                    ret = Show(model.ProductCD, value1);
                    break;
            }

            return ret;
        }

        #endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="DataKey">DataKey</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0015);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            ProductModels model = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_PRODUCT_CD);

            return View("Details", model);
        }

        /// <summary>
        /// Copy Action Confirm
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(ProductModels gmModel)
        {
            //calculate Total cost
            gmModel.TotalCost = this.CalculateTotalCost(gmModel.QuantityPerUnit, gmModel.Cost);
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Product/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">ProductModels Sesion Key</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            ProductModels gmModel = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            //insert data
            ActionResult ret = default(ActionResult);
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0003));
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0009));
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(ProductModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreProductCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreProductCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        # region CSV

        /// <summary>
        /// CSV action
        /// </summary>
        /// <param name="gmModel">ProductList</param>
        /// <returns>CSV File</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(ProductList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_PRODUCT_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Get model
            IQueryable<ProductListCsv> ListCSV = null;
            ListCSV = this.mProductService.GetListCSV();
            if (ListCSV.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MProduct"];
            var filename = string.Format("{0}-{1}.csv", "MProduct", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };
            
            var file = this.CSVOutPut<ProductListCsv>(ListCSV, hideColumn, fileFullName, "MProduct.csv");

            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            ProductList oldModel = (ProductList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<ProductResult> results = this.mProductService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<ProductResult>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion

        #region Check

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="model">Product Models</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool InsertCheck(ProductModels model)
        {
            bool ret = true;

            //Check exist ProductCD
            ProductModels proModel = this.mProductService.GetByCd(model.ProductCD);
            if (proModel != default(ProductModels) && proModel != null)
            {
                if (proModel.DeleteFlag)
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                    ret = false;
                }
                else {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                    ret = false;
                }
            }

            //Check Exist CategoryCD
            var cModel = this.mCategoryService.GetByPK(model.CategoryCD);
            if (cModel != default(Models.MCategory))
            {
                model.CategoryNm = cModel.CategoryName;
            }
            else 
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0020));
                this.ModelState.AddModelError(KEY_CATEGORY_CD, message);
                model.CategoryNm = string.Empty;
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">Product model</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(ProductModels model)
        {
            //Check data changed
            if (this.mProductService.CheckDataChanged(model))
            {
                //Show error Message
                this.ShowMessageExclusion("/Product/Show", model.ProductCD, model.SeqNum.ToString());
                return false;
            }
            //check Data exists in another table
            if(model.DeleteFlag && this.mProductService.IsExistsInOrtherTable(model.ProductCD)){
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((ProductModels m) => m.ProductCD));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }

            bool ret = true;

            //Check exist ProductCD
            if (!model.ProductCD.Equals(model.PreProductCD))
            {
                ProductModels proModel = this.mProductService.GetByCd(model.ProductCD);
                if (proModel != default(ProductModels) && proModel != null)
                {
                    if (proModel.DeleteFlag)
                    {
                        // エラーメッセージを返す
                        string message = this.FormatMessage(Constant.MES_E0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                        this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                        ret = false;
                    }
                    else
                    {
                        // エラーメッセージを返す
                        string message = this.FormatMessage(Constant.MES_M0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                        this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                        ret = false;
                    }
                }
            }

            //Check Exist CategoryCD
            var cModel = this.mCategoryService.GetByPK(model.CategoryCD);
            if (cModel != default(Models.MCategory) && cModel != null)
            {
                model.CategoryNm = cModel.CategoryName;
            }
            else
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0020));
                this.ModelState.AddModelError(KEY_CATEGORY_CD, message);
                model.CategoryNm = string.Empty;
                ret = false;
            }

            return ret;
        }

        #endregion

        #region public method

        /// <summary>
        /// Show TotalCost
        /// Author: ISV-Nho
        /// </summary>
        /// <param name="QuantityPerUnit">QuantityPerUnit</param>
        /// <param name="StoredCost">Cost</param>
        /// <returns>Total Cost</returns>
        public JsonResult ShowTotalCost(string QuantityPerUnit, string Cost)
        {
            string totalCost = this.CalculateTotalCost(QuantityPerUnit, Cost);

            return Json(totalCost, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Category Name
        /// </summary>
        /// <param name="CategoryCD">CategoryCD</param>
        /// <returns>Category Name</returns>
        [HttpPost]
        public string ShowCategoryNm(string CategoryCD)
        {
            if (string.IsNullOrEmpty(CategoryCD))
            {
                return string.Empty;
            }
            var model = this.mCategoryService.GetByCd(CategoryCD);
            if (model != default(CategoryModels) && !model.DeleteFlag)
            {
                return model.CategoryName;
            }           
            return string.Empty;
        }

        #endregion

        #region method

        /// <summary>
        /// Calculate Total Cost
        /// </summary>
        /// <param name="quantityPerUnit">quantityPerUnit</param>
        /// <param name="cost">Cost</param>
        /// <returns>Total Cost</returns>
        private string CalculateTotalCost(string quantityPerUnit, string cost)
        { 
            if(string.IsNullOrEmpty(quantityPerUnit) || string.IsNullOrEmpty(cost))
            {
                return string.Empty;
            }

            decimal dcCost = 0;
            decimal dcQuantityPerUnit = 0;
            decimal dcTotalCost = 0;

            try
            {

                if (CommonUtil.TryParseDecimal(quantityPerUnit, ref dcQuantityPerUnit) && CommonUtil.TryParseDecimal(cost, ref dcCost))
                {
                    dcTotalCost = dcCost * dcQuantityPerUnit;
                    string Totalcost = String.Format(Constant.FMT_DECIMAL_FULL, dcTotalCost);
                    return Totalcost;
                }
                else
                {
                    return string.Empty;
                }
            }
            catch (Exception)
            {

                return string.Empty;
            }
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/Product/Index");

            ProductModels model = (ProductModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(ProductModels))
            {
                model = new ProductModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(ProductModels gmModel)
        {
            //Get insert model
            MProduct model = this.GetInsertData(gmModel);
            try
            {
                this.mProductService.Insert(model);
                this.mProductService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MProduct_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>MProduct</returns>
        private MProduct GetInsertData(ProductModels gmModel)
        {
            MProduct ret = new MProduct();

            ret.ProductCD = gmModel.ProductCD;
            ret.ProductName = gmModel.ProductName;
            ret.CategoryCD = gmModel.CategoryCD;
            ret.QuantityPerUnit = CommonUtil.ParseDecimal(gmModel.QuantityPerUnit);
            ret.Cost = CommonUtil.ParseDecimal(gmModel.Cost);
            ret.DeleteFlag = false;
            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">ProductModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(ProductModels gmModel)
        {
            try
            {
                IQueryable<MProduct> proModel = this.mProductService.GetByCdAndUpDate(gmModel.PreProductCD, gmModel.UpdateDate);
                MProduct data = proModel.SingleOrDefault<MProduct>();
                if (data == default(MProduct))
                {
                    return CommitFlag.DataChanged;
                }
                if ((!gmModel.ProductCD.Equals(gmModel.PreProductCD) || gmModel.DeleteFlag) && this.mProductService.IsExistsInOrtherTable(gmModel.PreProductCD))
                {
                    
                    return CommitFlag.IsExistsInAnotherTB;
                }
                this.SetUpdateData(proModel.FirstOrDefault(), gmModel);
                this.mProductService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MProduct_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="dbModel">MProduct</param>
        /// <param name="gmModel">ProductModels</param>
        private void SetUpdateData(MProduct dbModel, ProductModels gmModel)
        {
            dbModel.ProductName = gmModel.ProductName;
            dbModel.CategoryCD = gmModel.CategoryCD;
            dbModel.QuantityPerUnit = CommonUtil.ParseDecimal(gmModel.QuantityPerUnit);
            dbModel.Cost = CommonUtil.ParseDecimal(gmModel.Cost);
            dbModel.DeleteFlag = gmModel.DeleteFlag;
            dbModel.UpdateDate = this.GetCurrentDate();
            dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="model">ProductModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(ProductModels gmModel)
        {
            try
            {
                // Check customer data changed
                IQueryable<MProduct> proModel = this.mProductService.GetByCdAndUpDate(gmModel.ProductCD, gmModel.UpdateDate);
                MProduct dbModel = proModel.SingleOrDefault<MProduct>();
                if (dbModel == default(MProduct))
                {
                    return CommitFlag.DataChanged;
                }

                //check data exists in another table
                if (this.mProductService.IsExistsInOrtherTable(dbModel.ProductCD)) {
                    return CommitFlag.IsExistsInAnotherTB;
                }

                //Set delete data
                this.SetDeleteData(dbModel);
                this.mProductService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MProduct_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="model">MProduct</param>
        private void SetDeleteData(MProduct model)
        {
            model.DeleteFlag = true;
            model.UpdateDate = this.GetCurrentDate();
            model.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion
    }
}

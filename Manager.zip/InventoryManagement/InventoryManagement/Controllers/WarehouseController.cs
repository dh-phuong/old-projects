﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.iQueryable;
using InventoryManagement.Common;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 倉庫のController
    /// Author : ISV-TRUC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class WarehouseController : BaseController
    {
        #region Common

        private DataAccess.MWarehouseService mWarehouseService;

        private DataAccess.MMessageService mMessageService;

        private DataAccess.MLocationService mLocationService;
        
        private DataAccess.MKind_DService mKind_DService;
        
        private int pageSize = 1;
       
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mWarehouseService">mWarehouseService</param>
        /// <param name="mMessageService">mMessageService</param>
        /// <param name="mLocationService">mLocationService</param>
        public WarehouseController(DataAccess.MWarehouseService mWarehouseService
                                , DataAccess.MMessageService mMessageService
                                , DataAccess.MLocationService mLocationService
                                , DataAccess.MKind_DService mKind_DService)
        {
            this.mWarehouseService = mWarehouseService;
            this.mMessageService = mMessageService;
            this.mLocationService = mLocationService;
            this.mKind_DService = mKind_DService;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }
        #endregion

        #region Constant

        /// <summary>
        /// KEY_WAREHOUSE_CD = "WarehouseCD"
        /// </summary>
        private const string KEY_WAREHOUSE_CD = "WarehouseCD";

        /// <summary>
        /// KEY_WAREHOUSE_NM = "WarehouseName"
        /// </summary>
        private const string KEY_WAREHOUSE_NM = "WarehouseName";

        /// <summary>
        /// SEARCH_WAREHOUSE_CD : "txt_WarehouseCD"
        /// </summary>
        private const string SEARCH_WAREHOUSE_CD = "txt_WarehouseCD";

        /// <summary>
        /// SEARCH_WAREHOUSE_NM : "txt_WarehouseName"
        /// </summary>
        private const string SEARCH_WAREHOUSE_NM = "txt_WarehouseName";

        /// <summary>
        /// SORT_DEFAULT : "UpdateDate"
        /// </summary>
        private const string SORT_DEFAULT = "UpdateDate";

        /// <summary>
        /// SORT_URL : "/Warehouse/Sorting"
        /// </summary>
        private const string SORT_URL = "/Warehouse/Sorting";

        /// <summary>
        /// DELETE_ACTION_URL : "/Warehouse/DeleteAction"
        /// </summary>
        private const string DELETE_ACTION_URL = "/Warehouse/DeleteAction";

        /// <summary>
        /// INDEX_URL : "/Warehouse/Index"
        /// </summary>
        private const string INDEX_URL = "/Warehouse/Index";

        /// <summary>
        /// SHOW_URL : "/Warehouse/Show"
        /// </summary>
        private const string SHOW_URL = "/Warehouse/Show";

        /// <summary>
        /// INSERT_ACTION_URL : "/Warehouse/InsertAction"
        /// </summary>
        private const string INSERT_ACTION_URL = "/Warehouse/InsertAction";

        /// <summary>
        /// UPDATE_ACTION_URL : "/Warehouse/UpdateAction"
        /// </summary>
        private const string UPDATE_ACTION_URL = "/Warehouse/UpdateAction";

        /// <summary>
        /// COPY_ACTION_URL : "/Warehouse/CopyAction";
        /// </summary>
        private const string COPY_ACTION_URL = "/Warehouse/CopyAction";

        /// <summary>
        /// BUTTON_EDIT : "btnUpdate"
        /// </summary>
        private const string BUTTON_EDIT = "btnUpdate";

        /// <summary>
        /// BUTTON_BACK : "btnBack"
        /// </summary>
        private const string BUTTON_BACK = "btnBack";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index
        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">WarehouseList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(WarehouseList gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];
                //Get model
                WarehouseList oldModel = (WarehouseList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(WarehouseList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<WarehouseResults> results = this.mWarehouseService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<WarehouseResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_WAREHOUSE_CD);
                }
            }
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Save conditions
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<WarehouseResults> results = this.mWarehouseService.GetListByConditions(gmModel);

                //Store result into session                
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Focus
                this.SetFocusId(SEARCH_WAREHOUSE_CD);

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<WarehouseResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                SetFocusId(SEARCH_WAREHOUSE_CD);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Index", gmModel);
        }


        #endregion

        #region Show
        /// <summary>
        /// Show
        /// </summary>
        /// <param name="value1">preWarehouse CD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0054);

            //Set mode state
            this.SetMode(Common.Mode.Show,value2);

            //Get data
            WarehouseModels model = this.mWarehouseService.GetByCd(value1);

            //Check exclusion
            if (model == default(WarehouseModels))
            {
                return this.ExclusionProcess(value2);
            }

            //Store model into session
            this.Session[Constant.SESSION_DETAIL_MODEL + value2.ToString()] = model;
            model.SeqNum = value2;

            model.PreWarehouseCD = value1;
            model.IsExistsInShelf = this.mLocationService.IsWarehouseExist(model.PreWarehouseCD);

            ////Set focus
            //this.SetFocusId(BUTTON_BACK);
            return View("Details", model);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="PreWarehouseCD">PreWarehouse CD</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string PreWarehouseCD, int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0055);

            //Set mode state
            this.SetMode(Common.Mode.Insert,SeqNum);

            //Set focus
            this.SetFocusId(KEY_WAREHOUSE_CD);

            WarehouseModels gmModel = new WarehouseModels();
            gmModel.PreWarehouseCD = PreWarehouseCD;
            gmModel.SeqNum = SeqNum;

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(WarehouseModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, INSERT_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }
           
            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            WarehouseModels gmModel = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0009));
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(WarehouseModels gmModel)
        {
            //Check exist WarehouseCD Exist      
            if (this.mWarehouseService.IsExistsWarehouseCD(gmModel.WarehouseCD,false))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_M0002, CommonUtil.GetDisplayName((WarehouseModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(KEY_WAREHOUSE_CD, message);
                return false;
            }
            //WarehouseCD has been deleted        
            else if (this.mWarehouseService.IsExistsWarehouseCD(gmModel.WarehouseCD,true))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((WarehouseModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(KEY_WAREHOUSE_CD, message);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(WarehouseModels gmModel)
        {
            //Get insert model
            MWarehouse model = this.GetInsertData(gmModel);
            try
            {
                this.mWarehouseService.Insert(model);
                this.mWarehouseService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MWarehouse_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>MWarehouse</returns>
        private MWarehouse GetInsertData(WarehouseModels gmModel)
        {
            MWarehouse ret = new MWarehouse();

            ret.WarehouseCD = gmModel.WarehouseCD;
            ret.WarehouseName = gmModel.WarehouseName;

            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0057);

            //Get old form from session
            WarehouseModels oldForm = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Get data
            WarehouseModels model = mWarehouseService.GetByCd(oldForm.WarehouseCD);
           
            //Check Exclusion
            if (model == default(WarehouseModels) || oldForm.UpdateDate != model.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            model.PreWarehouseCD = oldForm.PreWarehouseCD;
            model.SeqNum = SeqNum;
            model.IsExistsInShelf = this.mLocationService.IsWarehouseExist(model.PreWarehouseCD);

            //Set focusId
            this.SetFocusId(KEY_WAREHOUSE_NM);

            return View("Details", model);
        }

        /// <summary>
        /// Update Confirm
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(WarehouseModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum,UPDATE_ACTION_URL,value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            WarehouseModels gmModel = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.UpdateCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //Update data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion(SHOW_URL, gmModel.WarehouseCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0011));
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(WarehouseModels gmModel)
        {
            if (gmModel.DeleteFlag && this.mLocationService.IsWarehouseExist(gmModel.WarehouseCD))
            {
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((WarehouseModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }
            
            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">Warehouse Model</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(WarehouseModels gmModel)
        {
            try
            {
                MWarehouse dbModel = this.mWarehouseService.GetMWarehouseByCd(gmModel.WarehouseCD);
                if (dbModel == default(MWarehouse) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }
                this.SetUpdateData(dbModel, gmModel);
                mWarehouseService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MWarehouse_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="entityMWarehouse">MWarehouse</param>
        /// <param name="gmModel">WarehouseModels</param>
        private void SetUpdateData(MWarehouse entityMWarehouse, WarehouseModels gmModel)
        {
            entityMWarehouse.WarehouseName = gmModel.WarehouseName;           
            entityMWarehouse.DeleteFlag = gmModel.DeleteFlag;
            entityMWarehouse.UpdateDate = this.GetCurrentDate();
            entityMWarehouse.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete Confirm
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(WarehouseModels gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Get data
            WarehouseModels dbModel = this.mWarehouseService.GetByCd(gmModel.WarehouseCD);
            //Check Exclusion
            if (dbModel == default(WarehouseModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            string message = String.Empty;

            if (this.mLocationService.IsWarehouseExist(gmModel.PreWarehouseCD))
            {
                message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((WarehouseModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(string.Empty, message);
               
            }
            else
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, DELETE_ACTION_URL, value1: gmModel.SeqNum.ToString());
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(string value1)
        {           
            //Get model from session
            WarehouseModels model = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            string message = String.Empty;
            //Delete data
            ActionResult ret = default(ActionResult);
            if (!this.mLocationService.IsWarehouseExist(model.PreWarehouseCD))
            {
                
                switch (this.DeleteData(model))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(model.WarehouseCD, model.SeqNum);
                        break;

                    case CommitFlag.Success:
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0007);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(model.WarehouseCD, model.SeqNum);
                        break;
                }
            }
            else
            {
                message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((WarehouseModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(string.Empty, message);               
                ret = Show(model.WarehouseCD, model.SeqNum);
            }
            return ret;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">Warehouse Model</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(WarehouseModels gmModel)
        {
            try
            {
                // Check data changed
                MWarehouse dbModel = this.mWarehouseService.GetMWarehouseByCd(gmModel.WarehouseCD);
                if (dbModel == default(MWarehouse) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Set delete data
                this.SetDeleteData(dbModel);

                this.mWarehouseService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MWarehouse_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete Data
        /// </summary>
        /// <param name="entity">MWarehouse</param>
        private void SetDeleteData(MWarehouse entity)
        {
            entity.DeleteFlag = true;
            entity.UpdateDate = this.GetCurrentDate();
            entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion

        #region Copy
        
        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0055);

            //Set mode state
            this.SetMode(Common.Mode.Copy,SeqNum);

            //Get data            
            WarehouseModels model = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_WAREHOUSE_CD);

            return View("Details", model);
        }

        /// <summary>
        /// Copy Confirm
        /// </summary>
        /// <param name="gmModel">Warehouse Model</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(WarehouseModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum ,COPY_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            WarehouseModels gmModel = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //insert data
            ActionResult ret = default(ActionResult);
            string message = String.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                     message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0009));
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }
        #endregion

        #region CSV

        /// <summary>
        /// Export CSV
        /// </summary>
        /// <param name="gmModel">WarehouseCSV Model</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(WarehouseList gmModel)
        {
            //Check Authority
            if (!UserSession.Session.LoginInfo.User.GroupCD.Equals(Constant.GROUP_SUPPER_ADMIN_CD))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Get model
            IQueryable<WarehouseCSV> data = this.mWarehouseService.GetListCSV();
            if (data.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("NIndex", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MWarehouse"];
            var filename = string.Format("{0}-{1}.csv", "MWarehouse", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };

            var file= this.CSVOutPut<WarehouseCSV>(data, hideColumn, fileFullName, "MWarehouse.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            WarehouseList oldModel = (WarehouseList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<WarehouseResults> results = this.mWarehouseService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<WarehouseResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">Warehouse Model</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(WarehouseModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreWarehouseCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreWarehouseCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Paging and Sorting
        
        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<WarehouseResults> list = (IQueryable<WarehouseResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<WarehouseResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="other1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<WarehouseResults> list = (IQueryable<WarehouseResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<WarehouseResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        #endregion
        
        #region Private Methods

        /// <summary>
        /// ExclusionProcess
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion(INDEX_URL);

            WarehouseModels model = (WarehouseModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(WarehouseModels))
            {
                model = new WarehouseModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">WarehouseModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(WarehouseModels gmModel)
        {
            //Get data
            WarehouseModels model = this.mWarehouseService.GetByCd(gmModel.WarehouseCD);

            //Check Exclusion
            if (model == default(WarehouseModels) || gmModel.UpdateDate != model.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion(SHOW_URL, gmModel.WarehouseCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion

    }
}

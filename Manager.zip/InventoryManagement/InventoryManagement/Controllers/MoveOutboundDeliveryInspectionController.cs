﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Helpers;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Transactions;

using InventoryManagement.Validation;
using InventoryManagement.Common;
using InventoryManagement.Utility;
using InventoryManagement.Models;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// MoveOutboundDeliveryInspectionController
    /// ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class MoveOutboundDeliveryInspectionController : BaseController
    {
        #region Common

        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private bool isCheckShipNo;
        private int pageSize = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tShippingInstructionService">tShippingInstructionService</param>
        /// <param name="tInventory_DService">tInventory_DService</param>        
        /// <param name="tInventory_HService">tInventory_HService</param>        
        /// <param name="mWarehouseService">MWarehouse Service</param>
        /// <param name="tOutBoundDeliveredService">TOutBoundDelivered Service</param>
        /// <param name="tReserveService">tReserveService</param>      
        /// <param name="tSequencesService">tSequencesService</param>        
        /// <param name="tBalanceInStoresService">tBalanceInStoresService</param>        
        /// <param name="mKind_DService">Mkind Detail Service</param>
        /// <param name="tPessimisticLockService">TPessimisticLock Service</param>
        public MoveOutboundDeliveryInspectionController(DataAccess.TShippingInstructionService tShippingInstructionService,
                                                        DataAccess.TInventory_DService tInventory_DService,
                                                        DataAccess.TInventory_HService tInventory_HService,
                                                        DataAccess.MWarehouseService mWarehouseService,
                                                        DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService,
                                                        DataAccess.TReserveService tReserveService,
                                                        DataAccess.TSequencesService tSequencesService,
                                                        DataAccess.TBalanceInStoresService tBalanceInStoresService,
                                                        DataAccess.MKind_DService mKind_DService,
                                                        DataAccess.TPessimisticLockService tPessimisticLockService
                                                        )
        {
            this.tShippingInstructionService = tShippingInstructionService;
            this.mWarehouseService = mWarehouseService;
            this.tInventory_DService = tInventory_DService;
            this.tInventory_HService = tInventory_HService;
            this.tOutBoundDeliveredService = tOutBoundDeliveredService;
            this.tReserveService = tReserveService;
            this.tSequencesService = tSequencesService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.mKind_DService = mKind_DService;
            this.tPessimisticLockService = tPessimisticLockService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tShippingInstructionService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.tInventory_HService.Context = ctx;
            this.tOutBoundDeliveredService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.isCheckShipNo = this.mKind_DService.IsChecKShipNo();
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string PARTIAL_LIST = "_List";
        private const string PARTIAL_PICKING_DETAIL = "_PickingList";
        private const string KEY_PICKING_TAG_NO = "txt_TagNo";

        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_PICKING = "Picking";
        private const string KEY_MOVE_NO = "txt_MoveNo";

        private const string SEARCH_MOVE_NO = "txt_MoveNo";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_DEFAULT_PICKING = "TagInfo";
        private const string SORT_DEFAULT_CANCEL = "DeliveryFlag";
        private const string SORT_URL_LIST = "/MoveOutboundDeliveryInspection/Sorting";
        private const string SORT_URL_PICKING_DETAIL = "/MoveOutboundDeliveryInspection/SortingDetail";

        private const string MODE_PICKING = "Picking";
        private const string MODE_CANCEL= "Cancel";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// List
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="gmModel">MoveMoveOutboundDeliveryInspectionInspectionList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(MoveOutboundDeliveryInspectionList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION)
                && !CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //Check single Warehouse
            if (UserSession.Session.WareHouseMode == WareHouseMode.Single)
            {
                gmModel.IsSingleWareHouse = true;
                gmModel.ddl_MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_SCRAP;
            }

            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //Sort model state
            this.SortModelState(typeof(MoveOutboundDeliveryInspectionList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                MoveOutboundDeliveryInspectionList oldModel = (MoveOutboundDeliveryInspectionList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(MoveOutboundDeliveryInspectionList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<MoveOutboundDeliveryInspectionResults> results = this.tShippingInstructionService.GetListMoveOutboundDeliveryByCondition(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<MoveOutboundDeliveryInspectionResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_MOVE_NO);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<MoveOutboundDeliveryInspectionResults> results = this.tShippingInstructionService.GetListMoveOutboundDeliveryByCondition(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL_LIST,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<MoveOutboundDeliveryInspectionResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_MOVE_NO);
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveOutboundDeliveryInspectionResults> list = (IQueryable<MoveOutboundDeliveryInspectionResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<MoveOutboundDeliveryInspectionResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveOutboundDeliveryInspectionResults> list = (IQueryable<MoveOutboundDeliveryInspectionResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<MoveOutboundDeliveryInspectionResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView(PARTIAL_LIST);
        }

        #endregion

        #region Ajax
        /// <summary>
        /// Show Warehouse Name
        /// Author: ISV-TRUC
        /// </summary>
        /// <param name="warehouseCD">Warehouse Code</param>
        /// <returns></returns>        
        public JsonResult ShowWarehouseName(string warehouseCD)
        {
            if (string.IsNullOrEmpty(warehouseCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            WarehouseModels model = this.mWarehouseService.GetByCd(warehouseCD.ToUpper());

            if (model != default(WarehouseModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                {
                    model.WarehouseName
                    
                }, JsonRequestBehavior.AllowGet);

            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Picking

        /// <summary>
        /// Sorting Picking List
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult SortingDetail(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveOutboundDeliveryInspectionDetail> list = (IQueryable<MoveOutboundDeliveryInspectionDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()];

            //Sorting
            this.SortingBase<MoveOutboundDeliveryInspectionDetail>(list, sortInfo, SeqNum, list.Count(), SesionSortingKey: Constant.SESSION_DETAIL_SORTING, SesionPagingKey: Constant.SESSION_DETAIL_PAGING);

            return PartialView(PARTIAL_PICKING_DETAIL);
        }

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Picking(int SeqNum, string MoveNo, string MoveKind)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0237);

            //this.ClearModelState();

            //get Data Header
            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(MoveNo, MoveKind, this.isCheckShipNo);

            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                return this.ExclusionProcess(SeqNum, null, MoveKind);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(SeqNum, message, MoveKind);
            }
            model.SeqNum = SeqNum;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Get Data Detail
            IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(MoveNo, MoveKind);

            this.SetSortAndPageging(ref results, SeqNum, SORT_DEFAULT_PICKING, SortDirection.Ascending);

            //Store Data Results 
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = results;

            //Set focus
            if (model.IsCheckShipNo)
            {
                this.SetFocusId(KEY_MOVE_NO);
            }
            else
            {
                this.SetFocusId(KEY_PICKING_TAG_NO);
            }

            //set Mode
            model.Mode = MODE_PICKING;
            model.IsCorrectMoveNo = !model.IsCheckShipNo;

            return View(SCREEN_PICKING, model);

        }

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">MoveOutboundDeliveryInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult TagNoPicking(MoveOutboundDeliveryInspectionHeader gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            //get Data Header
            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(gmModel.MoveNoDB, gmModel.MoveKind, this.isCheckShipNo);

            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null, gmModel.MoveKind);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message, gmModel.MoveKind);
            }

            //Get Data Results
            IQueryable<MoveOutboundDeliveryInspectionDetail> list = (IQueryable<MoveOutboundDeliveryInspectionDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(gmModel.MoveNoDB, gmModel.MoveKind);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_PICKING, SortDirection.Ascending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }
           
            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
                {
                     //エラーメッセージを返す: {0}はデータベースに存在しません。
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (TagNoCheck(gmModel, dbModelInventory_H, dbModelInventory_D, list, true))
                 {
                    //Update data
                     if (this.UpdateData(gmModel, dbModelInventory_D, list))
                    {
                        //Clear Focus ID
                        this.ClearFocusId();
                        message = this.FormatMessage(Constant.MES_M0041);
                        return ExclusionProcess(gmModel.SeqNum, message, gmModel.MoveKind);
                    }
                    else if(ModelState.Where(x => x.Value.Errors.Count > 0).Count() == 0)
                    {
                        message = this.FormatMessage(Constant.MES_M0024);
                        this.ShowMessageInfo(message);
                    }
                }
            }
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region MoveNoPicking

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">MoveOutboundDeliveryInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult MoveNoPicking(MoveOutboundDeliveryInspectionHeader gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //get Data Header
            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(gmModel.MoveNoDB, gmModel.MoveKind, this.isCheckShipNo);

            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null, gmModel.MoveKind);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message, gmModel.MoveKind);
            }

            //Get Data Results
            IQueryable<MoveOutboundDeliveryInspectionDetail> list = (IQueryable<MoveOutboundDeliveryInspectionDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(gmModel.MoveNoDB, gmModel.MoveKind);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                string sortField = gmModel.Mode.Equals(MODE_PICKING) ? SORT_DEFAULT_PICKING : SORT_DEFAULT_CANCEL;
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortField, gmModel.Mode.Equals(MODE_PICKING) ? SortDirection.Ascending : SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_MoveNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                    this.ModelState.AddModelError(KEY_MOVE_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Check Exist ShipNo
                TShippingInstruction modelS = this.tShippingInstructionService.GetByPk(gmModel.txt_MoveNo);
                if (modelS == default(TShippingInstruction) || modelS.DeleteFlag)
                {
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                    this.ModelState.AddModelError(KEY_MOVE_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                if (!gmModel.txt_MoveNo.Equals(gmModel.MoveNoDB))
                {
                    message = this.FormatMessage(Constant.MES_M0061);
                    this.ModelState.AddModelError(KEY_MOVE_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }
                else
                {
                    gmModel.IsCorrectMoveNo = true;
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;
                    this.SetFocusId(KEY_PICKING_TAG_NO);
                }
            }

            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region Cancel

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Cancel(int SeqNum, string MoveNo, string MoveKind)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0240);

            //this.ClearModelState();

            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(MoveNo, MoveKind, this.isCheckShipNo);
            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                return this.ExclusionProcess(SeqNum, null, MoveKind);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(SeqNum, message, MoveKind);
            }
            model.SeqNum = SeqNum;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Search data
            IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(MoveNo, MoveKind);
            if (results.All(m => !m.DeliveryFlag))
            {
                string message = this.FormatMessage(Constant.MES_M0044);
                return this.ExclusionProcess(SeqNum, message, MoveKind);
            }

            this.SetSortAndPageging(ref results, model.SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);

            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = results;

            //Set focus
            if (model.IsCheckShipNo)
            {
                this.SetFocusId(KEY_MOVE_NO);
            }
            else
            {
                this.SetFocusId(KEY_PICKING_TAG_NO);
            }

            model.Mode = MODE_CANCEL;
            model.IsCorrectMoveNo = !model.IsCheckShipNo;

            return View(SCREEN_PICKING, model);

        }

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">MoveOutboundDeliveryInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult TagNoCancel(MoveOutboundDeliveryInspectionHeader gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(gmModel.MoveNoDB, gmModel.MoveKind, this.isCheckShipNo);
            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null, gmModel.MoveKind);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message, gmModel.MoveKind);
            }
            IQueryable<MoveOutboundDeliveryInspectionDetail> list = (IQueryable<MoveOutboundDeliveryInspectionDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(gmModel.MoveNoDB, gmModel.MoveKind);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }
            
            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
                {
                    // エラーメッセージを返す: {0}はデータベースに存在しません。
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (TagNoCheck(gmModel, dbModelInventory_H, dbModelInventory_D, list, false))
                {
                    //Update data
                    this.CancelData(gmModel, dbModelInventory_D, list);
                    if (list.All(m => !m.DeliveryFlag))
                    {
                        //Clear Focus ID
                        this.ClearFocusId();
                        message = this.FormatMessage(Constant.MES_M0044);
                        return ExclusionProcess(gmModel.SeqNum, message, gmModel.MoveKind);
                    } 
                    else if (ModelState.Where(x => x.Value.Errors.Count > 0).Count() == 0)
                    {
                        message = this.FormatMessage(Constant.MES_M0024);
                        this.ShowMessageInfo(message);
                    }
                }
            }
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region private

        ///<summary>
        ///Set DropDownlist
        ///</summary>
        ///<param name="moveKind">Move Kind</param>
        private void SetDropDownlist(string moveKind)
        {
            //Get List MKind_D: Move Kind
            Boolean isMultiWareHouse = UserSession.Session.WareHouseMode == WareHouseMode.Multiple;
            List<MKind_D> dropMoveKind = this.mKind_DService.GetListByDataKindForMoveOutbound(Common.Constant.MKIND_KINDCD_MOVE_KIND, isMultiWareHouse).ToList();

            //Add empty Item
            if (isMultiWareHouse)
            {
                MKind_D emptyItem = new MKind_D();
                emptyItem.KindCD = Common.Constant.MKIND_KINDCD_MOVE_KIND;
                emptyItem.DataCD = string.Empty;
                emptyItem.Value = Constant.BLANK;
                dropMoveKind.Insert(0, emptyItem);
            }

            this.CreateViewBagMoveKind(dropMoveKind, "ddl_MoveKind", moveKind);
        }

        ///<summary>
        ///Create Move Kind: MoveKind SelectList
        ///</summary>
        ///<param name="dropSrc">Dropdownlist</param>
        ///<param name="control">Control name</param>
        ///<param name="value">Selected value</param>
        private void CreateViewBagMoveKind(List<MKind_D> dropSrc, string control, string value)
        {
            SelectOption option = new SelectOption("Value", "DataCD", control, value);
            this.SetViewDataDropdownList<MKind_D>(option, dropSrc);
        }

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {
            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                return false;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                return false;
            }

            tagNo = array[0];
            return true;
        }

        /// <summary>
        /// Set Sort and Pageging
        /// </summary>
        /// <param name="list">list GoodsIssueInspectionDetail</param>
        /// <param name="SeqNum">SeqNum</param>
        private void SetSortAndPageging(ref IQueryable<MoveOutboundDeliveryInspectionDetail> list, int SeqNum, string sortField, SortDirection direction)
        {
            //Create sorting info
            SortingInfo sortInfo = new SortingInfo
            {
                Url = SORT_URL_PICKING_DETAIL,
                SortField = sortField,
                Direction = direction,
            };
            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<MoveOutboundDeliveryInspectionDetail>(ref list, pageRequest, sortInfo, SeqNum, list.Count(), SesionSortingKey: Constant.SESSION_DETAIL_SORTING, SesionPagingKey: Constant.SESSION_DETAIL_PAGING);
        }

        /// <summary>
        /// Get New Stock Status from old Stock Status
        /// </summary>
        /// <param name="inStatus">old Stock Status</param>
        /// <returns>New Stock Status</returns>
        private string GetStockStatus(string inStatus)
        {
            string ret = string.Empty;
            switch (inStatus)
            {
                case Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE:   //45 -> 50
                    ret = Constant.STOCK_STATUS_DELIVERY;
                    break;
                    
                case Constant.STOCK_STATUS_ISSUE_DEFECTIVE:     //47 -> 57
                    ret = Constant.STOCK_STATUS_DELIVERY_DEFECTIVE;
                    break;

                case Constant.STOCK_STATUS_ISSUE_SCRAP:         //48 -> 58
                    ret = Constant.STOCK_STATUS_DELIVERY_SCRAP;
                    break;

                case Constant.STOCK_STATUS_DELIVERY:            //50 -> 45
                    ret = Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE;
                    break;

                case Constant.STOCK_STATUS_DELIVERY_DEFECTIVE:  //57 -> 47
                    ret = Constant.STOCK_STATUS_ISSUE_DEFECTIVE;
                    break;

                case Constant.STOCK_STATUS_DELIVERY_SCRAP:      //58 -> 48
                    ret = Constant.STOCK_STATUS_ISSUE_SCRAP;
                    break;

                default:
                    ret = string.Empty;
                    break;
            }
            return ret;
        }

        #endregion

        #region Check

        /// <summary>
        /// TagNo Check
        /// </summary>
        /// <param name="gmModel">MoveOutboundDeliveryInspectionHeader</param>
        /// <param name="dbModel_H">TInventory_H</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">List MoveOutboundDeliveryInspectionDetail</param>
        /// <param name="isPicking">is Pick Flag</param>
        /// <returns>Bool</returns>
        private bool TagNoCheck(MoveOutboundDeliveryInspectionHeader gmModel, TInventory_H dbModel_H, TInventory_D dbModel_D, IQueryable<MoveOutboundDeliveryInspectionDetail> list, bool isPicking)
        {
            //Check Exist Data
            if (dbModel_D == default(TInventory_D))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            //Check Data is Deleted
            else if (dbModel_H.DeleteFlag)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            //The input tag number is not exist shipping instruction.
            else if (string.IsNullOrEmpty(dbModel_D.ShippingNo) || !dbModel_D.ShippingNo.Equals(gmModel.txt_MoveNo))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0030, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0203));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            // This {0} is already loaded. Please read of next the {0}.
            else if (dbModel_D.DeliveryFlag == true && isPicking)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0035, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            else if (!dbModel_D.DeliveryFlag == true && !isPicking)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0045);
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            else
            {
                //Check UpdatedDate
                foreach (MoveOutboundDeliveryInspectionDetail detail in list)
                {
                    if (gmModel.txt_TagNo.Equals(detail.TagInfo))
                    {
                        if (!dbModel_D.UpdateDate.Equals(detail.UpdateDate))
                        {
                            // エラーメッセージを返す: TagInfo is Updated
                            string message = this.FormatMessage(Constant.MES_M0003, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                            this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        #endregion Check

        #region Registration

        /// <summary>
        /// Update DeliveryFlg
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateDeliveryFlg(TInventory_D dbModel_D, string MoveKind)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                //Update DeliveryFlg
                dbModel_D.DeliveryFlag = true;
                dbModel_D.StockStatus = this.GetStockStatus(dbModel_D.StockStatus); //Set new Stock Status
                dbModel_D.UpdateDate = curDate;
                dbModel_D.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                //Insert TBalanceInStores
                //TSequences
                //string balanceNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

                //Insert TBalanceInStores
                string arrivalDate = DateTime.Now.ToString(Constant.FMT_YMD);
                TBalanceInStores balanceinstoresModel = this.GetInsertTBalanceInStores(dbModel_D, arrivalDate, curDate, MoveKind);
                this.tBalanceInStoresService.Insert(balanceinstoresModel);

            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Update CompleteFlg
        /// </summary>
        /// <param name="dbModel">TShippingInstruction</param>
        /// <param name="gmModel">MoveOutboundDeliveryInspectionHeader</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateCompleteFlg(MoveOutboundDeliveryInspectionHeader gmModel)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                //Update Shipping Complete Flag
                TShippingInstruction dbShipH = this.tShippingInstructionService.GetByPk(gmModel.txt_MoveNo);
                if (dbShipH == default(TShippingInstruction) || dbShipH.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }
                dbShipH.ShippingCompleteFlag = true;
                dbShipH.UpdateDate = curDate;
                dbShipH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                //Delete TReserve
                IQueryable<TReserve> listReserve = this.tReserveService.GetListByShipNo(gmModel.txt_MoveNo);

                foreach (var item in listReserve)
                {
                    this.tReserveService.Delete(item);
                }

                //Insert TOutBoundDelivered
                this.InsertTOutBoundDelivered(gmModel.txt_MoveNo, curDate);

                //Inbound Delivery
                if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                {
                    this.InboundDelivery(gmModel.txt_MoveNo, gmModel.txt_WarehouseCDTo, curDate);
                }                
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Insert TOutBoundDelivered
        /// </summary>
        /// <param name="moveNo">moveNo</param>
        /// <param name="curDate">current Date</param>
        private void InsertTOutBoundDelivered( string moveNo, string curDate)
        {
            IQueryable<TInventory_D> listData = this.tInventory_DService.GetListByShipNo(moveNo);
            foreach (var item in listData)
            {
                TOutBoundDelivered newData = new TOutBoundDelivered();
                newData.TagNo = item.TagNo;
                newData.BranchTagNo = item.BranchTagNo;
                newData.ShippingNo = item.ShippingNo;
                newData.ShippingDetailNo = item.ShippingDetailNo;
                newData.DeleteFlag = false;
                newData.CreateDate = curDate;
                newData.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                newData.UpdateDate = curDate;
                newData.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                this.tOutBoundDeliveredService.Insert(newData);
            }
        }

        /// <summary>
        /// Inbound Delivery
        /// </summary>
        /// <param name="moveNo">moveNo</param>
        /// <param name="wareHouseTo">wareHouseTo</param>
        /// <param name="curDate">curDate</param>
        private void InboundDelivery(string moveNo, string wareHouseTo, string curDate)
        {
            IQueryable<TInventory_D> listD = this.tInventory_DService.GetListByShipNo(moveNo);
            List<string> listTagNo = listD.Select(m => m.TagNo).Distinct().ToList();

            //get newTagNo and  newBalanceNo
            //TSequences tSequencesT = this.tSequencesService.GetByPK(Constant.TAGNO_DIVISION_TAGNO);
            //TSequences tSequencesB = this.tSequencesService.GetByPK(Constant.TAGNO_DIVISION_BALANCENO);
            //string newTagNo = tSequencesT.MaxTagNo;
            //string newBalanceNo = tSequencesB.MaxTagNo;

            foreach (var item in listTagNo)
            {

                string newTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_TAGNO, curDate.Substring(2, 4));

                int newQuantity = listD.Count(m => m.TagNo.Equals(item));
                
                //insert Inven Header
                this.InsertInventoryHeader(item, newTagNo, wareHouseTo, curDate, newQuantity);

                //insert Detail and balance in store
                for (int i = 0; i < newQuantity; i++)
			    {
                    //string newBalanceNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

                    this.InsertInvenDetailAndBalance(newTagNo, i + 1 , curDate, wareHouseTo);
			    }
            }

            ////Update TSequences
            //tSequencesT.MaxTagNo = newTagNo;
            //tSequencesB.MaxTagNo = newBalanceNo;
        }

        /// <summary>
        /// Insert Inventory Detail
        /// </summary>
        /// <param name="newTagNo">new TagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <param name="curDate">current Date</param>
        /// <param name="newBalanceNo">newBalanceNo</param>
        /// <param name="wareHouseTo">wareHouseTo</param>
        private void InsertInvenDetailAndBalance(string newTagNo, int branchTagNo, string curDate, string wareHouseTo)
        {
            //insert inventory Detail
            TInventory_D newInvenD = new TInventory_D();

            newInvenD.TagNo = newTagNo;
            newInvenD.BranchTagNo = branchTagNo;
            newInvenD.StockStatus = Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE;
            newInvenD.LocationCD = null;
            newInvenD.TagPrintFlag = false;
            newInvenD.PickingFlag = false;
            newInvenD.DeliveryPrintFlag = false;
            newInvenD.DeliveryFlag = false;
            newInvenD.CreateDate = curDate;
            newInvenD.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            newInvenD.UpdateUCD = newInvenD.CreateUCD;
            newInvenD.UpdateDate = newInvenD.CreateDate;

            this.tInventory_DService.Insert(newInvenD);

            //insert banlance in store
            TBalanceInStores newBalance = new TBalanceInStores();

            //newBalance.BalanceNo = newBalanceNo;
            newBalance.BalanceStatus = Constant.BALANCE_STATUS_MOVES_ARRIVAL;
            newBalance.BalanceDate = curDate.Substring(0, 8);
            newBalance.TagNo = newTagNo;
            newBalance.BranchTagNo = branchTagNo;
            newBalance.WarehouseCD = wareHouseTo;
            newBalance.LocationCD = null;
            newBalance.DeleteFlag = false;
            newBalance.CreateDate = curDate;
            newBalance.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            newBalance.UpdateDate = curDate;
            newBalance.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

            this.tBalanceInStoresService.Insert(newBalance);
        }

        /// <summary>
        /// Insert Inventory Header
        /// </summary>
        /// <param name="tagNo">old tagNo</param>
        /// <param name="newTagNo">new TagNo</param>
        /// <param name="wareHouseTo">wareHouseTo</param>
        /// <param name="curDate">current Date</param>
        /// <param name="quantity">unit quantity</param>
        private void InsertInventoryHeader(string tagNo, string newTagNo, string wareHouseTo, string curDate, int quantity)
        {
            TInventory_H oldH = this.tInventory_HService.GetByPK(tagNo);
            TInventory_H newInvenH = new TInventory_H();

            newInvenH.TagNo = newTagNo;
            newInvenH.WarehouseCD = wareHouseTo;
            newInvenH.ArrivalDate = curDate.Substring(0, 8);
            newInvenH.ProductCD = oldH.ProductCD;
            newInvenH.QuantityPerUnit = oldH.QuantityPerUnit;
            newInvenH.StoredCost = oldH.StoredCost;
            newInvenH.UnitQuantity = quantity;
            newInvenH.TotalCost = newInvenH.UnitQuantity * newInvenH.StoredCost;
            newInvenH.Lot1 = oldH.Lot1;
            newInvenH.Lot2 = oldH.Lot2;
            newInvenH.Lot3 = oldH.Lot3;
            newInvenH.Memo = oldH.Memo;
            newInvenH.DeleteFlag = false;

            this.tInventory_HService.Insert(newInvenH);
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">ShipmentPickingHeader</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">list ShipmentPickingDetail</param>
        /// <returns></returns>
        private bool UpdateData(MoveOutboundDeliveryInspectionHeader gmModel, TInventory_D dbModel_D, IQueryable<MoveOutboundDeliveryInspectionDetail> list)
        {
            bool ret = true;
            string message = string.Empty;

            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //Add lock
                    TPessimisticLock modelPLock = new TPessimisticLock();
                    modelPLock.TagNo = dbModel_D.TagNo;
                    this.tPessimisticLockService.Insert(modelPLock);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Update DeliveryFlg
                    switch (this.UpdateDeliveryFlg(dbModel_D, gmModel.MoveKind))
                    {
                        case CommitFlag.DataChanged:
                            message = this.FormatMessage(Constant.MES_M0003);
                            this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                            ret = false;
                            break;

                        case CommitFlag.Success:
                            this.tShippingInstructionService.Context.SubmitChanges();
                            this.SetFocusId(KEY_PICKING_TAG_NO);

                            gmModel.txt_TagNo = null;
                            break;

                        default:
                            message = this.FormatMessage(Constant.MES_M0011);
                            this.ModelState.AddModelError(string.Empty, message);
                            ret = false;
                            break;
                    }
                    if (!ret)
                    {
                        return ret;
                    }

                    if (this.tShippingInstructionService.IsShipCompleteByDetail(gmModel.MoveNoDB))
                    {
                        //Update CompleteFlg
                        switch (this.UpdateCompleteFlg(gmModel))
                        {
                            case CommitFlag.DataChanged:
                                message = this.FormatMessage(Constant.MES_M0003);
                                this.ModelState.AddModelError(string.Empty, message);
                                ret = false;
                                break;

                            case CommitFlag.Success:
                                
                                ret = true;
                                //Remove lock
                                this.tPessimisticLockService.Delete(modelPLock);
                                this.tShippingInstructionService.Context.SubmitChanges();

                                trans.Complete();
                                break;

                            default:
                                message = this.FormatMessage(Constant.MES_M0011);
                                this.ModelState.AddModelError(string.Empty, message);
                                ret = false;
                                break;
                        }
                    }
                    else
                    {
                        //Remove lock
                        this.tPessimisticLockService.Delete(modelPLock);
                        this.tShippingInstructionService.Context.SubmitChanges();
                    
                        trans.Complete();
                        ret = false;
                    }
                }
                catch (ChangeConflictException)
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    ret = false;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    ret = false;                    
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = false;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return ret;
        }

        /// <summary>
        /// Get data TBalanceInStores for Insert      
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="balanceNo">BalanceNo</param>
        /// <param name="balanceDate">curren date</param>
        /// <param name="curDate">curren date</param>
        /// <returns>TBalanceInStores</returns>
        private TBalanceInStores GetInsertTBalanceInStores(TInventory_D dbModel_D, string balanceDate, string curDate, string MoveKind)
        {
            TBalanceInStores result = new TBalanceInStores();

            //result.BalanceNo = balanceNo;
            if (MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                result.BalanceStatus = Constant.BALANCE_STATUS_MOVE_SHIPPING;
            }
            else
            {
                result.BalanceStatus = Constant.BALANCE_STATUS_DISCARD_SHIPPING; 
            }
            result.BalanceDate = balanceDate;
            result.TagNo = dbModel_D.TagNo;
            result.BranchTagNo = dbModel_D.BranchTagNo;
            result.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            result.LocationCD = dbModel_D.LocationCD;
            result.CreateDate = curDate;
            result.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            result.UpdateDate = curDate;
            result.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

            return result;
        }

        #region Cancel

        /// <summary>
        /// Cancel Data
        /// </summary>
        /// <param name="gmModel">ShipmentPickingHeader</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">list ShipmentPickingDetail</param>
        /// <returns></returns>
        private bool CancelData(MoveOutboundDeliveryInspectionHeader gmModel, TInventory_D dbModel_D, IQueryable<MoveOutboundDeliveryInspectionDetail> list)
        {
            bool ret = true;
            string message = string.Empty;

            //Cancel DeliveryFlg
            switch (this.CancelDeliveryFlg(dbModel_D, gmModel.MoveKind))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    ret = false;
                    break;

                case CommitFlag.Success:
                    this.SetFocusId(KEY_PICKING_TAG_NO);
                    gmModel.txt_TagNo = null;
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = false;
                    break;
            }
            return ret;
        }

        /// <summary>
        /// Update DeliveryFlg
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="dc">DataContext</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag CancelDeliveryFlg(TInventory_D dbModel_D, string MoveKind)
        {
            string curDate = this.GetCurrentDate();
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //insert TPessimisticLock
                    TPessimisticLock modelPLock = new TPessimisticLock();
                    modelPLock.TagNo = dbModel_D.TagNo;
                    this.tPessimisticLockService.Insert(modelPLock);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Cancel DeliveryFlg
                    dbModel_D.DeliveryFlag = false;
                    dbModel_D.StockStatus = this.GetStockStatus(dbModel_D.StockStatus);
                    dbModel_D.UpdateDate = curDate;
                    dbModel_D.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                    //delete TBalanceInStores
                    List<string> statusList = new List<string>() { Constant.BALANCE_STATUS_MOVE_SHIPPING, Constant.BALANCE_STATUS_DISCARD_SHIPPING };
                    TBalanceInStores modelB = this.tBalanceInStoresService.GetNewestData(dbModel_D.TagNo, dbModel_D.BranchTagNo, statusList);
                    if (modelB != default(TBalanceInStores))
                    {
                        modelB.DeleteFlag = true;
                    }

                    this.tPessimisticLockService.Delete(modelPLock);
                    this.tShippingInstructionService.Context.SubmitChanges();

                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;
        }

        #endregion

        #endregion Registration

        #region Exclusion

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="message">message error</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum, string message, string MoveKind)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/MoveOutboundDeliveryInspection/Index", message: message);

            MoveOutboundDeliveryInspectionHeader model = (MoveOutboundDeliveryInspectionHeader)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(MoveOutboundDeliveryInspectionHeader))
            {
                model = new MoveOutboundDeliveryInspectionHeader();
                model.SeqNum = SeqNum;
                model.MoveKind = MoveKind;
            }
            //Clear Session
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = null;
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = null;

            return View(SCREEN_PICKING, model);
        }

        #endregion Exclution

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(MoveOutboundDeliveryInspectionHeader gmModel)
        {
            this.ClearModelState();
            MoveOutboundDeliveryInspectionHeader model = this.tShippingInstructionService.GetMoveDeliveryHeaderByShipNo(gmModel.MoveNoDB, gmModel.MoveKind, this.isCheckShipNo);
            //Check exclusion
            if (model == default(MoveOutboundDeliveryInspectionHeader) || model.ShippingCompleteFlag)
            {
                return BackAction(gmModel.SeqNum.ToString());
            }
            IQueryable<MoveOutboundDeliveryInspectionDetail> list = (IQueryable<MoveOutboundDeliveryInspectionDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<MoveOutboundDeliveryInspectionDetail> results = this.tInventory_DService.GetListMoveOutboundDeliveryDetail(gmModel.MoveNoDB, gmModel.MoveKind);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (gmModel.Mode.Equals(MODE_CANCEL))
            {
                //if (list.All(m => !m.DeliveryFlag))
                //{
                return BackAction(gmModel.SeqNum.ToString());
                //}
            }

            string message = this.FormatMessage(Constant.MES_M0025);

            //Show message confirm
            this.ShowMessageConfirm(gmModel.SeqNum, "/MoveOutboundDeliveryInspection/BackAction", message: message, value1: gmModel.SeqNum.ToString());
            return View(SCREEN_PICKING, gmModel);
            
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult BackAction(string value1)
        {
            this.ClearModelState();
            this.Session[Constant.SESSION_DETAIL_SORTING + value1] = null;

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value1);
            return RedirectToAction("Index");
        }

        #endregion Back
    }
}

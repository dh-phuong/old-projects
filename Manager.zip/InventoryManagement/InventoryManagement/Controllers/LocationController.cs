﻿using System;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;
using InventoryManagement.Validation;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Web.Helpers;
using System.Drawing;
using System.IO;
using Microsoft.Reporting.WebForms;
using System.Collections;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 棚情報のController
    /// Author: ISV-PHUONG
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class LocationController : BaseController
    {
        #region Common

        private DataAccess.MLocationService mLocationService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.TInventory_HService tInventoryService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TTakeInventory_HService tTakeInventory_HService;
        private DataAccess.TTakeHistory_HService tTakeHistory_HService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        public LocationController(DataAccess.MLocationService mLocationService,
                                  DataAccess.MWarehouseService mWarehouseService,
                                  DataAccess.TInventory_HService tInventoryService,
                                  DataAccess.TReserveService tReserveService,
                                  DataAccess.TTakeInventory_HService tTakeInventory_HService,
                                  DataAccess.TTakeHistory_HService tTakeHistory_HService,
                                  DataAccess.TShippingInstructionService tShippingInstructionService,
                                  DataAccess.MKind_DService mKind_DService
                                  )
        {
            this.mLocationService = mLocationService;
            this.mWarehouseService = mWarehouseService;
            this.tInventoryService = tInventoryService;
            this.tReserveService = tReserveService;
            this.tTakeInventory_HService = tTakeInventory_HService;
            this.tTakeHistory_HService = tTakeHistory_HService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.mKind_DService = mKind_DService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.mLocationService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.tInventoryService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tTakeInventory_HService.Context = ctx;
            this.tTakeHistory_HService.Context = ctx;
            this.tShippingInstructionService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string CHK_FIRST_ROW = "PrintFlag0";

        private const string KEY_LOCATION_CD = "LocationCD";
        private const string KEY_LOCATION_NM = "LocationName";

        private const string SEARCH_LOCATION_CD = "txt_LocationCD";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/Location/LocationSorting";

        private const string BUTTON_EDIT = "btnEdit";
        private const string BUTTON_BACK = "btnBack";

        private const string PRINT_ACTION_URL = "/Location/PrintAction";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// Page default
        /// </summary>
        /// <param name="gmModel">LocationList</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Index(LocationList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                LocationList oldModel = (LocationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(LocationList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<LocationResults> results = this.mLocationService.GetListByConditions(gmModel);

                    //Restore Paging Sorting
                    this.RestorePagingSorting(gmModel.SeqNum, results);

                    //Focus
                    SetFocusId(SEARCH_LOCATION_CD);
                }
            }
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Display CSV button
            ViewBag.CSVCount = this.mLocationService.CountByWarehouseCD();

            //Store Print Hastable
            this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()] = new Hashtable();

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data                
                var results = this.mLocationService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                var sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<LocationResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_LOCATION_CD);
            }
            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View("Index", gmModel);
        }

        #endregion

        #region Show

        /// <summary>
        /// View
        /// </summary>
        /// <param name="value1">LocationCD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0047);

            //Set ModeState
            this.SetMode(Common.Mode.Show, value2);
                        
            //Get data
            LocationModels gmModel = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, value1);
            if (gmModel == default(LocationModels))
            {
                return this.ExclusionProcess(value2);
            }

            gmModel.iLocationCD = value1;

            //Store model into session
            gmModel.SeqNum = value2;

            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            //Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View("Details", gmModel);

        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="iLocationCD">LocationCD</param>
        /// <param name="ConditionKey">ConditionKey</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string iLocationCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0048);

            //Set mode state           
            this.SetMode(Common.Mode.Insert, SeqNum);
      
            //Get data
            LocationModels gmModel = new LocationModels();

            gmModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            gmModel.iLocationCD = iLocationCD;
            gmModel.SeqNum = SeqNum;
            //Set focus
            this.SetFocusId(KEY_LOCATION_CD);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(LocationModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Location/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">DataKey</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            LocationModels gmModel = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(LocationModels gmModel)
        {
            bool ret = true;
            if (!this.mWarehouseService.Exist(UserSession.Session.LoginInfo.WarehouseCD))
            {
                var message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((LocationModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(string.Empty, message);
                ret = false;
            }            
            var MLocation = this.mLocationService.GetByCd(gmModel.WarehouseCD, gmModel.LocationCD);
            if (MLocation != null && MLocation != default(LocationModels))
            {
                //Show error message
                string message = string.Empty;
                if (MLocation.DeleteFlag)
                {
                    message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                }
                else
                {
                    message = this.FormatMessage(Constant.MES_M0002, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                }

                this.ModelState.AddModelError(KEY_LOCATION_CD, message);
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(LocationModels gmModel)
        {
            //Get insert model
            MLocation model = this.GetInsertData(gmModel);
            try
            {
                this.mLocationService.Insert(model);
                this.mLocationService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MLocation_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>MCustomer</returns>
        private MLocation GetInsertData(LocationModels gmModel)
        {
            MLocation ret = new MLocation();

            ret.WarehouseCD = gmModel.WarehouseCD;
            ret.LocationCD = gmModel.LocationCD;
            ret.LocationName = gmModel.LocationName;
            ret.ReceiptProhibitionFlag = gmModel.ReceiptProhibitionFlag;
            ret.IssueProhibitionFlag = gmModel.IssueProhibitionFlag;
            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        #endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="DataKey">DataKey</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0048);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            LocationModels oldModel = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set Sequence Number
            oldModel.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_LOCATION_CD);

            return View("Details", oldModel);
        }

        /// <summary>
        /// Copy Action Confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(LocationModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session

                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Location/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">DataKey</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            LocationModels gmModel = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //insert data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0050);

            //Get data
            LocationModels oldModel = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            LocationModels gmModel = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, oldModel.LocationCD);
            
            //Check Exclusion
            if (gmModel == default(LocationModels) || oldModel.UpdateDate != gmModel.UpdateDate)
            {
                ViewBag.TakeComplete = false;
                return this.ExclusionProcess(SeqNum);
            }

            //Check Take Complete
            if (this.CheckTakeComplete(gmModel.LocationCD))
            {
                var message = this.FormatMessage(Constant.MES_M0054, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                this.ModelState.AddModelError(string.Empty, message);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            gmModel.iLocationCD = oldModel.LocationCD;

            //Set condition key
            gmModel.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_LOCATION_NM);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(LocationModels gmModel)
        {
            //Check Take Complete
            this.CheckTakeComplete(gmModel.LocationCD);

            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/Location/UpdateAction", value1: gmModel.SeqNum.ToString());
                }                
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">DataKey</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            LocationModels gmModel = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Update data
            string message = string.Empty;

           
            //Update data
            ActionResult ret = default(ActionResult);

            //Check Take Complete
            if (!gmModel.TakeComplete && this.CheckTakeComplete(gmModel.LocationCD))
            {
                //reset ReceiptProhibitionFlag && IssueProhibitionFlag
                LocationModels dbModel = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.LocationCD);
                gmModel.ReceiptProhibitionFlag = dbModel.ReceiptProhibitionFlag;
                gmModel.IssueProhibitionFlag = dbModel.IssueProhibitionFlag;

                message = this.FormatMessage(Constant.MES_M0054, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                this.ModelState.AddModelError(string.Empty, message);
                ret = View("Details", gmModel);
                return ret;
            }

            if (!this.UpdateCheck(gmModel))
            {                
                ret = View("Details", gmModel);
                return ret;
            }
            
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion("/Location/Show", gmModel.LocationCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.Success:
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(LocationModels gmModel)
        {
            bool ret = true;
            if (!this.mWarehouseService.Exist(UserSession.Session.LoginInfo.WarehouseCD))
            {
                var message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((LocationModels m) => m.WarehouseCD));
                this.ModelState.AddModelError(string.Empty, message);
                ret = false;
            }   

            if (gmModel.DeleteFlag)
            {
                if (this.CheckUsed(gmModel.LocationCD))
                {
                    string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = false;
                }
            }           
            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                ret = false;
            }

            //Check Inventory.Shipping user
            if (gmModel.IssueProhibitionFlag && 
                (this.tReserveService.ExistLocationShipping(UserSession.Session.LoginInfo.WarehouseCD, gmModel.LocationCD)
                || this.tInventoryService.CheckExistLocationMoving(UserSession.Session.LoginInfo.WarehouseCD, gmModel.LocationCD)))
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0034));
                ret = false;
            }else if (gmModel.ReceiptProhibitionFlag && (this.tShippingInstructionService.IsExistDesLocation(gmModel.LocationCD)))
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0034));
                ret = false;
            }


            return ret;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(LocationModels gmModel)
        {
            try
            {
                //Check data changed
                var entity = this.mLocationService.GetDataChanged(gmModel.WarehouseCD, gmModel.LocationCD, gmModel.UpdateDate);
                if (entity == default(MLocation))
                {
                    return CommitFlag.DataChanged;
                }

                this.SetUpdateData(entity, gmModel);
                this.mLocationService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MLocation_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="entity">MLocation</param>
        /// <param name="gmModel">LocationModels</param>
        private void SetUpdateData(MLocation entity, LocationModels gmModel)
        {
            entity.LocationName = gmModel.LocationName;
            if (!this.CheckTakeComplete(gmModel.LocationCD))
            {
                entity.IssueProhibitionFlag = gmModel.IssueProhibitionFlag;
                entity.ReceiptProhibitionFlag = gmModel.ReceiptProhibitionFlag;
                entity.DeleteFlag = gmModel.DeleteFlag;
            }            
            entity.UpdateDate = this.GetCurrentDate();
            entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(LocationModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Get data
            LocationModels dbModel = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.LocationCD);
                      
            //Check Exclusion
            if (dbModel == default(LocationModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }
           
            gmModel.iLocationCD = dbModel.iLocationCD;
            gmModel.LocationCD = dbModel.LocationCD;
            gmModel.LocationName = dbModel.LocationName;
            gmModel.ReceiptProhibitionFlag = dbModel.ReceiptProhibitionFlag;
            gmModel.IssueProhibitionFlag = dbModel.IssueProhibitionFlag;

            if (!this.CheckUsed(gmModel.LocationCD))
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, "/Location/DeleteAction", value1: gmModel.SeqNum.ToString());
            }
            else
            {
                //Cant delete data
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                this.ModelState.AddModelError(string.Empty, message);
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">DataKey</param>
        /// <returns>ActionResult</returns>        
        [HttpPost]
        public ActionResult DeleteAction(string value1)
        {
            //Get model from session
            LocationModels model = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Delete data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);

            if (this.CheckUsed(model.LocationCD))
            {
                message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((LocationModels m) => m.LocationCD));
                this.ModelState.AddModelError(string.Empty, message);
                ret = Show(model.LocationCD, model.SeqNum);
                return ret;
            }
            
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.LocationCD, model.SeqNum);
                    break;

                case CommitFlag.Success:
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.LocationCD, model.SeqNum);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(LocationModels gmModel)
        {
            try
            {
                // Check location data changed           
                var entity = this.mLocationService.GetDataChanged(gmModel.WarehouseCD, gmModel.LocationCD, gmModel.UpdateDate);

                if (entity == default(MLocation))
                {
                    return CommitFlag.DataChanged;
                }

                //Set delete data
                this.SetDeleteData(entity);
                this.mLocationService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MLocation_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="entity">MLocation</param>
        private void SetDeleteData(MLocation entity)
        {
            if (!this.CheckTakeComplete(entity.LocationCD))
            {
                entity.DeleteFlag = true;
                entity.UpdateDate = this.GetCurrentDate();
                entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            }            
        }

        #endregion

        #region Paging

        /// <summary>
        ///  Paging
        /// </summary>                
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>      
        /// <returns></returns>
        [HttpPost]
        public ActionResult LocationPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<LocationResults> list = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<LocationResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView("_List");
        }

        #endregion

        #region Sorting

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>        
        /// <returns></returns>
        [HttpPost]
        public ActionResult LocationSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<LocationResults> list = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<LocationResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }


        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(LocationModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.iLocationCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.iLocationCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Restore Paging Sorting
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequense number</param>
        /// <param name="results">results</param>
        private void RestorePagingSorting(int SeqNum, IQueryable<LocationResults> results)
        {
            //Display CSV button
            ViewBag.CSVCount = this.mLocationService.CountByWarehouseCD();

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<LocationResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/Location/Index");

            LocationModels model = (LocationModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(LocationModels))
            {
                model = new LocationModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Check data changed
        /// </summary>
        /// <param name="gmModel">MLocationModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(LocationModels gmModel)
        {
            LocationModels model = this.mLocationService.GetByCd(gmModel.WarehouseCD, gmModel.LocationCD);
            if (model == default(LocationModels) || gmModel.UpdateDate != model.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion("/Location/Show", gmModel.LocationCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        private bool CheckTakeComplete(string LocationCD)
        {
            var TakeComplete =  this.tTakeInventory_HService.IsExistByLocationUnCompleted(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            ViewBag.TakeComplete = TakeComplete;
            return TakeComplete;
        }

        /// <summary>
        /// Check used in other
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>TRUE: Exist; FALSE: not exist</returns>
        private bool CheckUsed(string LocationCD)
        {
            bool ret = this.tInventoryService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            ret = ret || this.tTakeInventory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            ret = ret || this.tTakeHistory_HService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            ret = ret || this.tShippingInstructionService.ExistByLocation(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            return ret;
        }

        #endregion

        #region CSV
       
        /// <summary>
        /// CSV Download file
        /// </summary>
        /// <param name="gmModel">LocationList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(LocationList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();

            //Get model
            IQueryable<LocationCSV> data = this.mLocationService.GetListCSV();
            if (data.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MLocation"];
            var filename = string.Format("{0}-{1}.csv", "MLocation", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };

            var file= this.CSVOutPut<LocationCSV>(data, hideColumn, fileFullName, string.Format("MLocation-{0}.csv", UserSession.Session.LoginInfo.WarehouseCD));

            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            var results = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Restore Paging Sorting
            this.RestorePagingSorting(SeqNum, results);
        }

        #endregion

        #region Print

        /// <summary>
        /// Change Print All
        /// </summary>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public void CheckPrintItemALL(bool Checked, int SeqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()];

            //Clear list location
            ListItems.Clear();

            //Add Location
            if (Checked)
            {
                IQueryable<LocationResults> results = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

                foreach (var row in results.Where(m => !m.DeleteFlag))
                {
                    ListItems.Add(row.LocationCD, true);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()] = ListItems;
        }

        /// <summary>
        /// Change Print Item
        /// </summary>
        /// <param name="Key">LocationCD</param>
        /// <param name="Checked">CheckedFlag</param>
        /// <param name="PrintKey">PrintKey</param>
        /// <param name="DataKey">DataKey</param>
        [HttpPost]
        public bool CheckPrintItemAt(string Key, bool Checked, int SeqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()];
            IQueryable<LocationResults> results = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Add Location
            if (Checked)
            {
                if (!ListItems.ContainsKey(Key) && results.Where(m => m.LocationCD.Equals(Key) && !m.DeleteFlag).SingleOrDefault() != null)
                {
                    ListItems.Add(Key, true);
                }
            }
            else
            {
                //Remove Location
                if (ListItems.ContainsKey(Key))
                {
                    ListItems.Remove(Key);
                }
            }


            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()] = ListItems;
            var checkAll = (ListItems.Count == results.Count(m => !m.DeleteFlag));
            return checkAll;
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Print(LocationList model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Get model
            var oldModel = (LocationList)this.Session[Constant.SESSION_LIST_CONDITION + model.SeqNum.ToString()];

           

            #region PageInfo

            var results = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + model.SeqNum.ToString()];
            //Restore Paging Sorting
            this.RestorePagingSorting(oldModel.SeqNum, results);

            #endregion

            #region out report

            var hashtable = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + model.SeqNum.ToString()];

            //Filter selected row
            var SelectedRow = hashtable.Keys.OfType<string>().ToList();

            //Filter data
            var ReportData = results
                                    .Where(m => SelectedRow.Contains(m.LocationCD))
                                    .OrderBy(m => m.LocationCD).ToList();

            var RowLength = ReportData.Count();
            if (RowLength > 0)
            {
                this.ShowMessageForPrint(model.SeqNum);
            }
            else
            {
                this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                return View("Index", model);
            }

            #endregion

            return View("Index", model);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value3)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_LOCATION_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            var hashtable = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + value3];

            //Filter selected row
            var SelectedRow = hashtable.Keys.OfType<string>().ToList();

            #region out report

            var results = (IQueryable<LocationResults>)this.Session[Constant.SESSION_LIST_RESULT + value3];

            //Filter data
            var ReportData = results
                                    .Where(m => SelectedRow.Contains(m.LocationCD))
                                    .OrderBy(m => m.LocationCD).ToList();

            var RowLength = ReportData.Count();
                

            #endregion
            #region download

            Report.DataObject.LocationLabelDataSet DataSet = new Report.DataObject.LocationLabelDataSet();
            string WarehouseCode = UserSession.Session.LoginInfo.WarehouseCD;
            string WarehouseName = string.Empty;
            var Warehouse = mWarehouseService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD);
            if (Warehouse != null)
            {
                WarehouseName = Warehouse.WarehouseName;
            }

            //Data Source for report
            var tblEven = DataSet.LocationLabel.Clone();
            var tblOdd = DataSet.LocationLabel.Clone();

            for (int i = 0; i < RowLength; i++)
            {
                var Model = ReportData[i];
                if (i % 2 == 0)//Even
                {
                    this.CreateDataRow(tblEven, Model, WarehouseCode, WarehouseName, (i + 1));
                }
                else//Odd
                {
                    this.CreateDataRow(tblOdd, Model, WarehouseCode, WarehouseName, (i + 1));
                }
            }

            //Report
            LocalReport localReport = new LocalReport();

            //Report path
            localReport.ReportPath = Server.MapPath("~/Report/LocationLabel.rdlc");

            //Report source
            ReportDataSource Even = new ReportDataSource("Even", tblEven);
            ReportDataSource Odd = new ReportDataSource("Odd", tblOdd);

            //Add Report source
            localReport.DataSources.Add(Even);
            localReport.DataSources.Add(Odd);

            //file name download
            var filename = string.Format("LocationLabel_{0}.pdf",DateTime.Now.ToString(Constant.FMT_DMY));

            //out put pdf
            var file = this.PDFOutPut(localReport, filename, Common.ReportType.Barcode, true);

            TempData[TMP_DOWNLOAD_FILE] = file;

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value3);
            return RedirectToAction("Index");

            #endregion
        }


        /// <summary>
        /// Create data row for report
        /// </summary>
        /// <param name="Table">Table Source</param>
        /// <param name="Model">Data Source</param>
        /// <param name="WarehouseCode">WarehouseCode</param>
        /// <param name="WarehouseName">WarehouseName</param>
        /// <param name="RowIndex">Row Index</param>
        private void CreateDataRow(System.Data.DataTable Table, LocationResults Model, string WarehouseCode, string WarehouseName, int RowIndex)
        {
            var newRow = Table.NewRow();
            newRow["BarcodeString"] = Model.LocationCD;
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(Model.LocationCD, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            newRow["Barcode"] = Stream.ToArray();
            newRow["LocationName"] = Model.LocationName;
            newRow["WarehouseCode"] = WarehouseCode;
            newRow["WarehouseName"] = WarehouseName;
            newRow["RowIndex"] = RowIndex;
            Table.Rows.Add(newRow);
        }

        /// <summary>
        ///  Show Message For Print
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void ShowMessageForPrint(int SeqNum)
        {

            //Show confirm message
            this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
            value3: SeqNum.ToString());

        }

        #endregion

    }
}

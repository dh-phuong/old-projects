﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Data.SqlClient;

namespace InventoryManagement.Controllers
{
     /// <summary>
    /// カテゴリーのController
    /// Author : ISV-TRUC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class CategoryController : BaseController
    {
        
        #region Common

        private DataAccess.MCategoryService mCategoryService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mCategoryService">mCategoryService</param>
        /// <param name="mMessageService">mMessageService</param>        
        public CategoryController(DataAccess.MCategoryService mCategoryService
                                , DataAccess.MProductService mProductService
                                , DataAccess.MKind_DService mKind_DService)
        {
            this.mCategoryService = mCategoryService;
            this.mProductService = mProductService;
            this.mKind_DService = mKind_DService;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }
        #endregion

        #region Constant

        /// <summary>
        /// KEY_CATAGORY_CD = "CategoryCD"
        /// </summary>
        private const string KEY_CATEGORY_CD = "CategoryCD";

        /// <summary>
        /// KEY_CATAGORY_NM = "CategoryName"
        /// </summary>
        private const string KEY_CATAGORY_NM = "CategoryName";

        /// <summary>
        /// SEARCH_CATAGORY_CD : "txt_CategoryCD"
        /// </summary>
        private const string SEARCH_CATAGORY_CD = "txt_CategoryCD";

        /// <summary>
        /// SEARCH_CATAGORY_NM : "txt_CategoryName"
        /// </summary>
        private const string SEARCH_CATAGORY_NM = "txt_CategoryName";

        /// <summary>
        /// SORT_DEFAULT : "UpdateDate"
        /// </summary>
        private const string SORT_DEFAULT = "UpdateDate";

        /// <summary>
        /// SORT_URL : "/Category/Sorting"
        /// </summary>
        private const string SORT_URL = "/Category/Sorting";

        /// <summary>
        /// DELETE_ACTION_URL : "/Category/DeleteAction"
        /// </summary>
        private const string DELETE_ACTION_URL = "/Category/DeleteAction";

        /// <summary>
        /// INDEX_URL : "/Category/Index"
        /// </summary>
        private const string INDEX_URL = "/Category/Index";

        /// <summary>
        /// SHOW_URL : "/Category/Show"
        /// </summary>
        private const string SHOW_URL = "/Category/Show";

        /// <summary>
        /// INSERT_ACTION_URL : "/Category/InsertAction"
        /// </summary>
        private const string INSERT_ACTION_URL = "/Category/InsertAction";

        /// <summary>
        /// UPDATE_ACTION_URL : "/Category/UpdateAction"
        /// </summary>
        private const string UPDATE_ACTION_URL = "/Category/UpdateAction";

        /// <summary>
        /// COPY_ACTION_URL : "/Category/CopyAction";
        /// </summary>
        private const string COPY_ACTION_URL = "/Category/CopyAction";

        /// <summary>
        /// BUTTON_EDIT : "btnUpdate"
        /// </summary>
        private const string BUTTON_EDIT = "btnUpdate";

        /// <summary>
        /// BUTTON_BACK : "btnBack"
        /// </summary>
        private const string BUTTON_BACK = "btnBack";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index
        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">CategoryList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(CategoryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int) this.TempData[TEMP_SEQNUM];

                //Get model
                CategoryList oldModel = (CategoryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(CategoryList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<CategoryResults> results = this.mCategoryService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<CategoryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_CATAGORY_CD);
                }
            }
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Save conditions
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<CategoryResults> results = this.mCategoryService.GetListByConditions(gmModel);

                //Store result into session                
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Focus
                this.SetFocusId(SEARCH_CATAGORY_CD);

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<CategoryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_CATAGORY_CD);
                
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Index", gmModel);
        }

        #endregion

        #region Show
        
        /// <summary>
        /// Show
        /// </summary>
        /// <param name="value1">preCategory CD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0207);

            //Set mode state
            this.SetMode(Common.Mode.Show,value2);

            //Get data
            CategoryModels model = this.mCategoryService.GetByCd(value1);

            //Check exclusion
            if (model == default(CategoryModels))
            {
                return this.ExclusionProcess(value2);
            }

            //Store model into session
            this.Session[Constant.SESSION_DETAIL_MODEL + value2.ToString()] = model;
            model.SeqNum = value2;

            model.PreCategoryCD = value1.Trim();
            model.IsExistsInOther = this.mProductService.IsCategoryExist(model.CategoryCD);

            //Set focus
            //if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            //{
            //    this.SetFocusId(BUTTON_EDIT);
            //}
            //else
            //{
            //    this.SetFocusId(BUTTON_BACK);
            //}

            return View("Details", model);
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="PreCategoryCD">PreCategory CD</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string PreCategoryCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0208);

            //Set mode state
            this.SetMode(Common.Mode.Insert,SeqNum);

            //Set focus
            this.SetFocusId(KEY_CATEGORY_CD);

            CategoryModels gmModel = new CategoryModels();
            gmModel.PreCategoryCD = PreCategoryCD;
            gmModel.SeqNum = SeqNum;

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(CategoryModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, INSERT_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }
           
            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            CategoryModels gmModel = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0009));
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(CategoryModels gmModel)
        {
            bool ret = true;
            CategoryModels resultlist = this.mCategoryService.GetByCd(gmModel.CategoryCD);

            //Check exist CategoryCD
            if (resultlist != null)
            {
                if (resultlist.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((CategoryModels m) => m.CategoryCD));
                    this.ModelState.AddModelError(KEY_CATEGORY_CD, message);
                    ret = false;
                }
                else
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0002, CommonUtil.GetDisplayName((CategoryModels m) => m.CategoryCD));
                    this.ModelState.AddModelError(KEY_CATEGORY_CD, message);
                    ret = false;
                }
            }

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(CategoryModels gmModel)
        {
            //Get insert model
            MCategory model = this.GetInsertData(gmModel);
            try
            {
                this.mCategoryService.Insert(model);
                this.mCategoryService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCategory_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>MCategory</returns>
        private MCategory GetInsertData(CategoryModels gmModel)
        {
            MCategory ret = new MCategory();

            ret.CategoryCD = gmModel.CategoryCD;
            ret.CategoryName = gmModel.CategoryName;

            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0209);

            //Get old form from session
            CategoryModels oldForm = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Get data
            CategoryModels model = this.mCategoryService.GetByCd(oldForm.CategoryCD);
           
            //Check Exclusion
            if (model == default(CategoryModels) || oldForm.UpdateDate != model.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            model.PreCategoryCD = oldForm.PreCategoryCD;
            model.SeqNum = SeqNum;
            model.IsExistsInOther = this.mProductService.IsCategoryExist(model.PreCategoryCD);

            //Set focusId
            this.SetFocusId(KEY_CATAGORY_NM);

            return View("Details", model);
        }

        /// <summary>
        /// Update Confirm
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(CategoryModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum,UPDATE_ACTION_URL,value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            CategoryModels gmModel = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.UpdateCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //Update data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion(SHOW_URL, gmModel.CategoryCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0011));
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(CategoryModels gmModel)
        {
            if (gmModel.DeleteFlag && this.mProductService.IsCategoryExist(gmModel.CategoryCD))
            {
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((CategoryModels m) => m.CategoryCD));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }

            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(CategoryModels gmModel)
        {
            try
            {
                MCategory dbModel = this.mCategoryService.GetMCategoryByCd(gmModel.CategoryCD);
                if (dbModel == default(MCategory) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }
                this.SetUpdateData(dbModel, gmModel);
                this.mCategoryService.Context.SubmitChanges();
                
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCategory_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="entityMCategory">MCategory</param>
        /// <param name="gmModel">CategoryModels</param>
        private void SetUpdateData(MCategory entityMCategory, CategoryModels gmModel)
        {
            entityMCategory.CategoryName = gmModel.CategoryName;           
            entityMCategory.DeleteFlag = gmModel.DeleteFlag;
            entityMCategory.UpdateDate = this.GetCurrentDate();
            entityMCategory.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }
        #endregion
        
        #region Delete

        /// <summary>
        /// Delete Confirm
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(CategoryModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            CategoryModels dbModel = this.mCategoryService.GetByCd(gmModel.CategoryCD);
            //Check Exclusion
            if (dbModel == default(CategoryModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            if (this.mProductService.IsCategoryExist(gmModel.PreCategoryCD))
            {
                 string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((CategoryModels m) => m.CategoryCD));
                this.ModelState.AddModelError(string.Empty, message);               
            }
            else
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, DELETE_ACTION_URL, value1: gmModel.SeqNum.ToString());
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete Action
        /// </summary>
        /// <param name="value1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(string value1)
        {           
            //Get model from session
            CategoryModels model = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            string message = String.Empty;
            //Delete data
            ActionResult ret = default(ActionResult);
            if (!this.mProductService.IsCategoryExist(model.PreCategoryCD))
            {                
                switch (this.DeleteData(model))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(model.CategoryCD, model.SeqNum);
                        break;

                    case CommitFlag.Success:
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0007);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(model.CategoryCD, model.SeqNum);
                        break;
                }
            }
            else
            {
                message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((CategoryModels m) => m.CategoryCD));
                this.ModelState.AddModelError(string.Empty, message);
                
                ret = Show(model.CategoryCD, model.SeqNum);
            }
            return ret;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(CategoryModels gmModel)
        {
            try
            {
                // Check data changed
                MCategory dbModel = this.mCategoryService.GetMCategoryByCd(gmModel.CategoryCD);
                if (dbModel == default(MCategory) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Set delete data
                this.SetDeleteData(dbModel);

                this.mCategoryService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCategory_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete Data
        /// </summary>
        /// <param name="entity">MCategory</param>
        private void SetDeleteData(MCategory entity)
        {
            entity.DeleteFlag = true;
            entity.UpdateDate = this.GetCurrentDate();
            entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion
        
        #region Copy
        
        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0208);

            //Set mode state
            this.SetMode(Common.Mode.Copy,SeqNum);

            //Get data            
            CategoryModels model = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_CATEGORY_CD);

            return View("Details", model);
        }

        /// <summary>
        /// Copy Confirm
        /// </summary>
        /// <param name="gmModel">Category Model</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(CategoryModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum ,COPY_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            CategoryModels gmModel = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }
            
            //insert data
            ActionResult ret = default(ActionResult);
            string message = String.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                     message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0009));
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }
        #endregion
        
        #region CSV

        /// <summary>
        /// Export CSV
        /// </summary>
        /// <param name="gmModel">CategoryList Model</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(CategoryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_CATEGORY_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();

            //Get model
            IQueryable<CategoryCSV> data = this.mCategoryService.GetListCSV();
            if (data.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MCategory"];
            var filename = string.Format("{0}-{1}.csv", "MCategory", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };

            var file= this.CSVOutPut<CategoryCSV>(data, hideColumn, fileFullName, "MCategory.csv");

            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            CategoryList oldModel = (CategoryList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<CategoryResults> results = this.mCategoryService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<CategoryResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">CategoryModelsl</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(CategoryModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreCategoryCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show( gmModel.PreCategoryCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Paging and Sorting
        
        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<CategoryResults> list = (IQueryable<CategoryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<CategoryResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="other1">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<CategoryResults> list = (IQueryable<CategoryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<CategoryResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        #endregion
        
        #region Private Methods

        /// <summary>
        /// ExclusionProcess
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion(INDEX_URL);

            CategoryModels model = (CategoryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(CategoryModels))
            {
                model = new CategoryModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">CategoryModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(CategoryModels gmModel)
        {
            //Get data
            CategoryModels model = this.mCategoryService.GetByCd(gmModel.CategoryCD);

            //Check Exclusion
            if (model == default(CategoryModels) || gmModel.UpdateDate != model.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion(SHOW_URL, gmModel.CategoryCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion
    }
}

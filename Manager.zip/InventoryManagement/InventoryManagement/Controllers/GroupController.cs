﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Common;
using System.Web.Helpers;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Data.SqlClient;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 権限のController
    /// Author : ISV-TRUC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class GroupController : BaseController
    {

        #region Common

        private DataAccess.MKind_HService mKindHService;
        private DataAccess.MKind_DService mKindDService;
        private DataAccess.MUserService mUserService;
        private DataAccess.MGroup_HService mGroupHService;
        private DataAccess.MGroup_DService mGroupDService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;

        public GroupController(DataAccess.MKind_HService mKindHService,
                                DataAccess.MKind_DService mKindDService,
                                DataAccess.MUserService mUserService,
                                DataAccess.MGroup_HService mGroupHService,
                                DataAccess.MGroup_DService mGroupDService,
                                DataAccess.MKind_DService mKind_DService)
        {
            this.mKindHService = mKindHService;
            this.mKindDService = mKindDService;
            this.mUserService = mUserService;
            this.mGroupDService = mGroupDService;
            this.mGroupHService = mGroupHService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.mKindHService.Context = ctx;
            this.mKindDService.Context = ctx;
            this.mUserService.Context = ctx;
            this.mGroupDService.Context = ctx;
            this.mGroupHService.Context = ctx;
            this.mKind_DService = mKind_DService;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string KEY_GROUP_CD = "GroupCD";
        private const string KEY_GROUP_NAME = "GroupName";
        
        private const string SEARCH_GROUP_CD = "txt_GroupCD";
        
        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL = "/Group/Sorting";

        private const string BUTTON_EDIT = "btnUpdate";
        private const string BUTTON_BACK = "btnBack";

        private const string UPDATE_ACTION_PATH = "/Group/UpdateAction";
        private const string INSERT_ACTION_PATH = "/Group/InsertAction";
        private const string COPY_ACTION_PATH = "/Group/CopyAction";
        private const string DELETE_ACTION_PATH = "/Group/DeleteAction";
        private const string SHOW_PATH = "/Group/Show";
        private const string INDEX_PATH = "/Group/Index";

        public const int ROLE_USER_COUNT = 8;

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">GroupHeaderList</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Index(GroupHeaderList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                GroupHeaderList oldModel = (GroupHeaderList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(GroupHeaderList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<GroupHeaderResult> results = this.mGroupHService.GetListByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<GroupHeaderResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_GROUP_CD);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<GroupHeaderResult> results = this.mGroupHService.GetListByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<GroupHeaderResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_GROUP_CD);
                List<MKind_D> TitleGrid = this.mGroupHService.GetTitleForGrid().ToList();
                this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmModel.SeqNum.ToString()] = TitleGrid;
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View("Index", gmModel);
        }
        #endregion

        #region Show

        /// <summary>
        /// Show
        /// </summary>
        /// <param name="value1">Group CD</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0177);

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            //Get header data
            GroupHeaderResult ret = this.mGroupHService.GetHeaderResultByKey(value1);

            //Check exclusion
            if (ret == default(GroupHeaderResult))
            {
                return this.ExclusionProcess(value2);
            }
            
            //Get data
            GroupDetailModels gmModel = new GroupDetailModels();

            //Set IsExistsOtherTB
            gmModel.IsExistsOtherTB = this.mUserService.IsGroupExist(value1);

            //Show header
            gmModel.GroupCD = value1.Trim();
            gmModel.PreGroupCD = value1.Trim();
            gmModel.GroupName = ret.GroupName;
            gmModel.UpdateDate = ret.UpdateDate;
            gmModel.DeleteFlag = ret.DeleteFlag;

            //set title for Grid
            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + value2];
            gmModel.TitleGrid = Title;
            
            //Details
            gmModel.DetailMaster = this.mGroupDService.GetListMasterByGroupCD(value1).ToList();
            gmModel.DetailProcess = this.mGroupDService.GetListProcessByGroupCD(value1).ToList();

            //Show gridview 
            this.SetNumRow_SequenceForDetail(gmModel, value2);

            //Store data into session
            gmModel.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            return View("Details", gmModel);
        }

        /// <summary>
        /// Set Number Row and Sequence Number For Screen Detail
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <param name="SeqNum">SeqNum</param>
        private void SetNumRow_SequenceForDetail(GroupDetailModels gmModel, int SeqNum)
        {
            if (gmModel.DetailMaster.Count() > 0)
            {
                for (int i = 0; i < gmModel.DetailMaster.Count(); i++)
                {
                    gmModel.DetailMaster[i].NumRow = i + 1;
                    gmModel.DetailMaster[i].SeqNum = SeqNum;
                }
            }

            if (gmModel.DetailProcess.Count() > 0)
            {
                for (int i = 0; i < gmModel.DetailProcess.Count(); i++)
                {
                    gmModel.DetailProcess[i].NumRow = i + 1;
                    gmModel.DetailProcess[i].SeqNum = SeqNum;
                }
            }
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="preGroupCD">preGroupCD</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string preGroupCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0178);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(KEY_GROUP_CD);

            //Set data display
            GroupDetailModels gmodel = new GroupDetailModels();
            gmodel.PreGroupCD = preGroupCD;
            gmodel.SeqNum = SeqNum;

            //set title for Grid
            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmodel.SeqNum];
            gmodel.TitleGrid = Title;
           
            gmodel.DetailMaster = this.mGroupHService.GetListGroupGridForInsert(Common.Constant.MGROUP_MASTER, gmodel.SeqNum).ToList();
            gmodel.DetailProcess = this.mGroupHService.GetListGroupGridForInsert(Common.Constant.MGROUP_PROCESS, gmodel.SeqNum).ToList();
            this.Session[Constant.SESSION_DETAIL_MODEL + gmodel.SeqNum.ToString()] = gmodel;
            return View("Details", gmodel);
        }

        /// <summary>
        /// InsertConfirm
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(GroupDetailModels gmModel)
        {
            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmModel.SeqNum];
            gmModel.TitleGrid = Title;

            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, INSERT_ACTION_PATH, value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// InsertAction
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            GroupDetailModels gmModel = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //Insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>True: data input is valid, False: data input is invalid</returns>
        private bool InsertCheck(GroupDetailModels gmModel)
        {
            bool ret = true;

            //Check header 
            if (!this.InsertCheckHeader(gmModel))
            {
                ret = false;
            }

            //Check gridview
            if (!this.CheckGrid(gmModel))
            {
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check Header
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        private bool InsertCheckHeader(GroupDetailModels gmModel)
        {
            bool ret = true;

            //Get modeState
            Mode modeState = this.GetMode(gmModel.SeqNum);

            if (modeState == Mode.Insert || modeState == Mode.Copy)
            {
                GroupHeaderResult resultlist = this.mGroupHService.GetHeaderResultByKey(gmModel.GroupCD);

                //Check exist GroupCD
                if (resultlist != null)
                {
                    if (resultlist.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0006, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                        this.ModelState.AddModelError(KEY_GROUP_CD, message);
                        ret = false;
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0002, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                        this.ModelState.AddModelError(KEY_GROUP_CD, message);
                        ret = false;
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// InsertData
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        private CommitFlag InsertData(GroupDetailModels gmModel)
        {
            //Get insert model
            MGroup_H modelHeader = this.GetInsertDataHeader(gmModel);
            List<MGroup_D> listModelDetails = this.GetInsertDataDetails(gmModel);
            try
            {
                this.mGroupHService.Insert(modelHeader);
                this.mGroupDService.Insert(listModelDetails);

                //Submit only header context
                this.mGroupHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MGroup_H_PK) || sqlEx.Message.Contains(Constant.DB_MGroup_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// GetInsertDataHeader
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        private MGroup_H GetInsertDataHeader(GroupDetailModels gmModel)
        {
            MGroup_H ret = new MGroup_H();

            ret.GroupCD = gmModel.GroupCD;
            ret.GroupName = gmModel.GroupName;
            ret.DeleteFlag = false;
            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        /// <summary>
        /// Get Insert data for details
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>List of MGroup_D</returns>
        private List<MGroup_D> GetInsertDataDetails(GroupDetailModels gmModel)
        {
            List<MGroup_D> listResult = new List<MGroup_D>();

            this.SetRoleForGridDetail(listResult, gmModel.DetailMaster,gmModel.GroupCD);
            this.SetRoleForGridDetail(listResult, gmModel.DetailProcess, gmModel.GroupCD);

            return listResult;
        }

        /// <summary>
        /// Set Role For Grid Detail
        /// </summary>
        /// <param name="list">List of MGroup_D </param>
        /// <param name="model">List of GroupDetailGrid</param>
        private void SetRoleForGridDetail(List<MGroup_D> list, List<GroupDetailGrid> model,string GroupCD)
        {
            for (int i = 0; i < model.Count(); i++)
            {
                //Set data to insert for each Role
                for (int j = 0; j < ROLE_USER_COUNT; j++)
                {
                    MGroup_D ret = this.SetDataInsertForeachRole(GroupCD, model, i, j);
                    if (ret != null)
                    {
                        list.Add(ret);
                    }
                }
            }
        }

        /// <summary>
        /// Set value of EnableFlag for each Role
        /// </summary>
        /// <param name="GroupCD">GroupCD</param>
        /// <param name="gmModel">List of GroupDetailGrid</param>
        /// <param name="index">Index of list GroupDetailGrid</param>
        /// <param name="Role">Role will set</param>
        /// <returns></returns>
        private MGroup_D SetDataInsertForeachRole(string GroupCD, List<GroupDetailGrid> gmModel, int index, int Role)
        {

            MGroup_D ret = new MGroup_D();
            ret.GroupCD = GroupCD;

            switch (Role)
            {
                case 0://insert        
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_INSERT_CD;
                    ret.EnableFlag = gmModel[index].Insert;
                    break;

                case 1://update
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_UPDATE_CD;
                    ret.EnableFlag = gmModel[index].Update;
                    break;
                case 2://delete
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_DELETE_CD;
                    ret.EnableFlag = gmModel[index].Delete;
                    break;
                case 3://export
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_EXPORT_CD;
                    ret.EnableFlag = gmModel[index].Export;
                    break;
                case 4://view
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_VIEW_CD;
                    ret.EnableFlag = gmModel[index].View;
                    break;
                case 5://Include Deleted            
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_INCLUDE_DELETE_CD;
                    ret.EnableFlag = gmModel[index].IncludeDeleted;
                    break;
                case 6://Picking            
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_PICKING;
                    ret.EnableFlag = gmModel[index].Picking;
                    break;
                case 7://Cancel            
                    ret.ViewCD = gmModel[index].ViewCD;
                    ret.RolesCD = Common.Constant.GROUP_ROLE_CANCEL;
                    ret.EnableFlag = gmModel[index].Cancel;
                    break;
                default:      
                    break;
            }

            if (!ret.EnableFlag)
            {
                ret = null;
            }
            return ret;
        }

        #endregion
        
        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0180);

            //Get data
            GroupDetailModels gmModel = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Get UpdateDate
            GroupHeaderResult ret = mGroupHService.GetHeaderResultByKey(gmModel.GroupCD);

            //Check Exclusion
            if (ret == default(GroupHeaderResult) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_GROUP_NAME);
            return View("Details", gmModel);
        }

        /// <summary>
        /// UpdateConfirm
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(GroupDetailModels gmModel)
        {
           //Get Title for Grid
            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmModel.SeqNum];
            gmModel.TitleGrid = Title;

            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, UPDATE_ACTION_PATH, value1: gmModel.SeqNum.ToString());
                }
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            GroupDetailModels gmModel = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Update data
            string message = string.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion(SHOW_PATH, gmModel.GroupCD, gmModel.SeqNum.ToString());
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.IsExistsInAnotherTB:
                    message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                    this.ModelState.AddModelError(string.Empty, message);                   
                    ret = View("Details", gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        private bool UpdateCheck(GroupDetailModels gmModel)
        {
            bool ret = true;

            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                return false;
            }

            if (!this.CheckGrid(gmModel))
                ret = false;

            if (gmModel.DeleteFlag && this.mUserService.IsGroupExist(gmModel.GroupCD))
            {
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                this.ModelState.AddModelError(string.Empty, message);
                ret = false;
            }
            return ret;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(GroupDetailModels gmModel)
        {
            try
            {
                //Get update model
                MGroup_H dbHeaderModel = this.mGroupHService.GetHeaderEntityByKey(gmModel.GroupCD);
                if (dbHeaderModel == default(MGroup_H) || dbHeaderModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                if (gmModel.DeleteFlag && this.mUserService.IsGroupExist(gmModel.GroupCD))
                {
                    return CommitFlag.IsExistsInAnotherTB;
                }

                //Edit Header Data
                dbHeaderModel.GroupName = gmModel.GroupName;
                dbHeaderModel.UpdateDate = this.GetCurrentDate();
                dbHeaderModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                dbHeaderModel.DeleteFlag = gmModel.DeleteFlag;

                //Delete details in database
                List<MGroup_D> dbListDetails = this.mGroupDService.GetListByKey(gmModel.GroupCD).ToList();
                if (dbListDetails.Count != 0)
                {
                    this.mGroupDService.Delete(dbListDetails);
                }

                //Insert current detail data
                List<MGroup_D> listModelDetails = this.GetInsertDataDetails(gmModel);
                this.mGroupDService.Insert(listModelDetails);
              
                //Submit only header context
                this.mGroupHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MGroup_H_PK) || sqlEx.Message.Contains(Constant.DB_MGroup_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }
#endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0178);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            GroupDetailModels gmModel = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;

            //Set focus
            this.SetFocusId(KEY_GROUP_CD);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Confirm
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(GroupDetailModels gmModel)
        {
            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmModel.SeqNum];
            gmModel.TitleGrid = Title;

            //Add number sequen for detail
            gmModel.AddSeqForDetail();

            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, COPY_ACTION_PATH, value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            GroupDetailModels gmModel = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel))
            {
                return View("Details", gmModel);
            }

            //insert data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);

            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = CopyConfirm(gmModel);
                    break;
            }

            return ret;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(GroupDetailModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set mode state
            this.SetMode(Common.Mode.Delete, gmModel.SeqNum);
                        
            //Get header data
            GroupHeaderResult ret = this.mGroupHService.GetHeaderResultByKey(gmModel.GroupCD);

            //Check exclusion
            if (ret == default(GroupHeaderResult) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }

            //Get data
            GroupDetailModels dbModel = new GroupDetailModels();

            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + gmModel.SeqNum];
            dbModel.TitleGrid = Title;

            //Show header
            dbModel.GroupCD = gmModel.GroupCD;
            dbModel.PreGroupCD = gmModel.GroupCD;
            dbModel.GroupName = ret.GroupName;
            dbModel.UpdateDate = ret.UpdateDate;
            dbModel.DeleteFlag = ret.DeleteFlag;
            dbModel.SeqNum = gmModel.SeqNum;

            //Details
            dbModel.DetailMaster = this.mGroupDService.GetListMasterByGroupCD(gmModel.GroupCD).ToList();
            dbModel.DetailProcess = this.mGroupDService.GetListProcessByGroupCD(gmModel.GroupCD).ToList();

            //Show gridview [plus]
            if (dbModel.DetailMaster.Count() > 0)
            {
                for (int i = 0; i < dbModel.DetailMaster.Count(); i++)
                {
                    dbModel.DetailMaster[i].NumRow = i + 1;
                }
            }

            if (dbModel.DetailProcess.Count() > 0)
            {
                for (int i = 0; i < dbModel.DetailProcess.Count(); i++)
                {
                    dbModel.DetailProcess[i].NumRow = i + 1;
                }
            }

            //Add number sequen for detail
            dbModel.AddSeqForDetail();

            //Check data exists in another table
            if (this.mUserService.IsGroupExist(gmModel.GroupCD))
            {
                //Can't delete data
                string message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                this.ModelState.AddModelError(string.Empty, message);                
            }
            else 
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(dbModel.SeqNum,DELETE_ACTION_PATH, value1: dbModel.SeqNum.ToString());
            }

            return View("Details", dbModel);
        }

        /// <summary>
        /// Delete action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            GroupDetailModels model = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            List<MKind_D> Title = (List<MKind_D>)this.Session[Constant.SESSION_TITLE_GROUP_ROLE + value1];
            model.TitleGrid = Title;

            //Delete data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.GroupCD, value1);
                    break;

                case CommitFlag.IsExistsInAnotherTB:

                    message = this.FormatMessage(Constant.MES_M0023, CommonUtil.GetDisplayName((GroupDetailModels m) => m.GroupCD));
                    this.ModelState.AddModelError(string.Empty, message);

                    ret = Show(model.GroupCD, value1);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.GroupCD, value1);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(GroupDetailModels gmModel)
        {
            try
            {
                //Check data changed
                MGroup_H dbModel = this.mGroupHService.GetHeaderEntityByKey(gmModel.GroupCD);
                if (dbModel == default(MGroup_H) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                //Check data exists in another table
                if (this.mUserService.IsGroupExist(gmModel.GroupCD))
                {
                    //Can't delete data
                    return CommitFlag.IsExistsInAnotherTB;
                }
                
                //Set delete data
                this.SetDeleteData(dbModel);
                this.mGroupHService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MGroup_H_PK) || sqlEx.Message.Contains(Constant.DB_MGroup_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="dbModel">MGroup_H</param>
        private void SetDeleteData(MGroup_H dbModel)
        {
            dbModel.DeleteFlag = true;
            dbModel.UpdateDate = this.GetCurrentDate();
            dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        #endregion

        #region Back
        
        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(GroupDetailModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.PreGroupCD) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreGroupCD, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region CSV

        /// <summary>
        /// Export CSV
        /// </summary>
        /// <param name="gmModel">GroupHeaderList</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(GroupHeaderList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_GROUP_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            this.ClearModelState();
            //Get model
            IQueryable<GroupCSV> data = this.mGroupHService.GetListCSV();
            if (data.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MGroup"];
            var filename = string.Format("{0}-{1}.csv", "MGroup", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };

            var file = this.CSVOutPut<GroupCSV>(data, hideColumn, fileFullName, "MGroup.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            this.RestoreGrid(gmModel.SeqNum);
            return View("Index", gmModel);
        }

        /// <summary>
        /// RestoreGrid
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void RestoreGrid(int SeqNum)
        {
            //Get model
            GroupHeaderList oldModel = (GroupHeaderList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

            //Search data
            IQueryable<GroupHeaderResult> results = this.mGroupHService.GetListByConditions(oldModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];
            this.PagingBase<GroupHeaderResult>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        #endregion

        #region Paging and sorting
        
        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<GroupHeaderResult> list = (IQueryable<GroupHeaderResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<GroupHeaderResult>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<GroupHeaderResult> list = (IQueryable<GroupHeaderResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<GroupHeaderResult>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion(INDEX_PATH);

            GroupDetailModels model = (GroupDetailModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(GroupDetailModels))
            {
                model = new GroupDetailModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }


        /// <summary>
        /// CheckGrid
        /// </summary>
        /// <param name="gmModel">GroupDetailModels</param>
        /// <returns></returns>
        private bool CheckGrid(GroupDetailModels gmModel)
        {
            bool ret = true;

            bool g1 = this.IsChooseRoleOnGrid(gmModel.DetailMaster);
            bool g2 = this.IsChooseRoleOnGrid(gmModel.DetailProcess);
            if (!g1 && !g2)
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_M0014, gmModel.GroupCD);
                this.ModelState.AddModelError(String.Empty, message);
                this.SetFocusId(KEY_GROUP_CD);
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Check have Choose Role On Grid
        /// </summary>
        /// <param name="gmModel">List Of GroupDetailGrid</param>
        /// <returns></returns>
        private bool IsChooseRoleOnGrid(List<GroupDetailGrid> gmModel)
        {
            return gmModel.Any(d => d.Insert || d.Update || d.Delete || d.Export || d.View || d.IncludeDeleted || d.Picking || d.Cancel);
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">Group Detail Models</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(GroupDetailModels gmModel)
        {
            //Get data
            MGroup_H model = this.mGroupHService.GetByPK(gmModel.GroupCD);

            //Check Exclusion
            if (model == default(MGroup_H) || gmModel.UpdateDate != model.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion("/Group/Show", gmModel.GroupCD, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion

    }
}

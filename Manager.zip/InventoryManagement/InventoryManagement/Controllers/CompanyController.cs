﻿using System;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.Common;
using InventoryManagement.Utility;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Company Controller 
    /// Author: ISV-TRUC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class CompanyController : BaseController
    {

        #region Common

        private DataAccess.MCompanyService mCompanyService;
               
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mCompanyService">mCompanyService</param>
        public CompanyController(DataAccess.MCompanyService mCompanyService)
        {
            this.mCompanyService = mCompanyService;
        }

        #endregion

        #region Constant
        
        /// <summary>
        /// KEY_COMPANY_NM : "CompanyName"
        /// </summary>
        private const string KEY_COMPANY_NM = "CompanyName1";

        /// <summary>
        /// SORT_DEFAULT : "UpdateDate"
        /// </summary>
        private const string SORT_DEFAULT = "UpdateDate";
        
        /// <summary>
        ///  INDEX_URL : "/Company/Index"
        /// </summary>
        private const string INDEX_URL = "/Company/Index";

        /// <summary>
        /// INSERT_ACTION_URL : "/Company/InsertAction"
        /// </summary>
        private const string INSERT_ACTION_URL = "/Company/InsertAction";

        /// <summary>
        /// UPDATE_ACTION_URL : "/Company/UpdateAction"
        /// </summary>
        private const string UPDATE_ACTION_URL = "/Company/UpdateAction";

        /// <summary>
        /// BUTTON_EDIT : "btnUpdate"
        /// </summary>
        private const string BUTTON_EDIT = "btnUpdate";

        /// <summary>
        /// BUTTON_EDIT : "btnUpdate"
        /// </summary>
        private const string BUTTON_CSV = "btnCSV";

        /// <summary>
        /// BUTTON_BACK : "btnBack"
        /// </summary>
        private const string BUTTON_BACK = "btnBack";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index
        
        /// <summary>
        /// Index
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(string SeqNum)
        {
            int seqNum;
            //Create new sequence key
            if (string.IsNullOrEmpty(SeqNum))
            {
                seqNum = UserSession.Session.CreateSequenceNumber();
            }
            else 
            {
                seqNum = int.Parse(SeqNum);
            }

            //Get data           
            CompanyModels model = this.mCompanyService.GetCompany();

            //Check exclusion
            if (model == default(CompanyModels))
            {
                //Check Authority
                if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
                {
                    return this.RedirectNotAuthority();
                }

                //Set title
                this.Session[Constant.SESSION_TITLE + seqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0102);

                //Set mode state
                this.SetMode(Common.Mode.Insert, seqNum);

                //Set focus
                this.SetFocusId(KEY_COMPANY_NM);

                CompanyModels gmModel = new CompanyModels();
                gmModel.SeqNum = seqNum;
                return View("Index", gmModel);
            }
            else
            {
                model.SeqNum = seqNum;

                //Check Authority
                if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
                {
                    return this.RedirectNotAuthority();
                }
                //Set title
                this.Session[Constant.SESSION_TITLE + seqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0101);

                //Set mode state
                this.SetMode(Common.Mode.Show, seqNum);

                //Store model into session
                this.Session[Constant.SESSION_DETAIL_MODEL + seqNum.ToString()] = model;

                //Set focus
                if (CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
                {
                    this.SetFocusId(BUTTON_EDIT);
                }
                else if (CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
                {
                    this.SetFocusId(BUTTON_CSV);
                }
                else
                {
                    this.SetFocusId(BUTTON_BACK);
                }
                if (TempData[TMP_DOWNLOAD_FILE] != null)
                {
                    this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], model.SeqNum);
                    ViewBag.IsDownload = true;
                }
                return View("Index", model);
            }
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(CompanyModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel.SeqNum))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum,INSERT_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }
            
            return View("Index", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            CompanyModels gmModel = (CompanyModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Insert check
            if (!this.InsertCheck(gmModel.SeqNum))
            {
                return View("Index", gmModel);
            }
            //insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.InsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                    //Show error Message
                    this.ShowMessageExclusion(INDEX_URL, value1.ToString());
                    return View("Index", gmModel);

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0009));
                    ret = InsertConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(int seqNum)
        {
            CompanyModels model = this.mCompanyService.GetCompany();

            if (model != default(CompanyModels))
            {
                //Show error Message
                this.ShowMessageExclusion(INDEX_URL, seqNum.ToString());
                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag InsertData(CompanyModels gmModel)
        {
            //Get insert model
            MCompany model = this.GetInsertData(gmModel);
            try
            {
                this.mCompanyService.Insert(model);
                this.mCompanyService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCompany_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get Insert data
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>MCompany</returns>
        private MCompany GetInsertData(CompanyModels gmModel)
        {
            MCompany ret = new MCompany();

            ret.CompanyCD = Constant.DEFAULT_COMPANY_CD;
            ret.CompanyName1 = gmModel.CompanyName1;
            ret.CompanyName2 = gmModel.CompanyName2;
            ret.Address1 = gmModel.Address1;
            ret.Address2 = gmModel.Address2;
            ret.Address3 = gmModel.Address3;
            ret.Tel = gmModel.Tel;
            ret.Fax = gmModel.Fax;
            ret.Email = gmModel.Email;

            ret.CreateDate = this.GetCurrentDate();
            ret.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            ret.UpdateDate = ret.CreateDate;
            ret.UpdateUCD = ret.CreateUCD;

            return ret;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0104);

            //Get old form from session
            CompanyModels oldForm = (CompanyModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Get data
            CompanyModels model = mCompanyService.GetCompany();
          
            //Check Exclusion
            if (model == default(CompanyModels) || oldForm.UpdateDate != model.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            model.SeqNum = SeqNum;

            //Set focusId
            this.SetFocusId(KEY_COMPANY_NM);

            return View("Index", model);
        }

        /// <summary>
        /// Update Confirm
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(CompanyModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum,UPDATE_ACTION_URL, value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Index", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Data key</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1)
        {
            //Get screen model from session
            CompanyModels gmModel = (CompanyModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            //Insert check
            if (!this.UpdateCheck(gmModel))
            {
                return View("Index", gmModel);
            }
            //Update data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;
            switch (this.UpdateData(gmModel))
            {
                case CommitFlag.DataChanged:
                    this.ShowMessageExclusion(INDEX_URL, gmModel.SeqNum.ToString());

                    ret = View("Index", gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                    ret = RedirectToAction("Index");
                    break;

                default:
                    this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0011));
                    ret = UpdateConfirm(gmModel);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool UpdateCheck(CompanyModels gmModel)
        {
            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(CompanyModels gmModel)
        {
            try
            {
                MCompany dbModel = this.mCompanyService.GetMCompany();
                if (dbModel == default(MCompany) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }
                this.SetUpdateData(dbModel, gmModel);
                mCompanyService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_MCompany_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set Update Data
        /// </summary>
        /// <param name="entity">MCompany</param>
        /// <param name="gmModel">CompanyModels</param>
        private void SetUpdateData(MCompany entity, CompanyModels gmModel)
        {
            entity.CompanyName1 = gmModel.CompanyName1;
            entity.CompanyName2 = gmModel.CompanyName2;
            entity.Address1 = gmModel.Address1;
            entity.Address2 = gmModel.Address2;
            entity.Address3 = gmModel.Address3;
            entity.Tel = gmModel.Tel;
            entity.Fax = gmModel.Fax;
            entity.Email = gmModel.Email;

            entity.DeleteFlag = gmModel.DeleteFlag;
            entity.UpdateDate = this.GetCurrentDate();
            entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }
        #endregion

        #region CSV

        /// <summary>
        /// Export CSV
        /// </summary>
        /// <param name="gmModel">CompanyList</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CSV(CompanyModels gmModel)
        {
            this.ClearModelState();

            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_COMPANY_MASTER))
            {
                return this.RedirectNotAuthority();
            }
            //Get model
            IQueryable<CompanyListCSV> data = this.mCompanyService.GetListCSV();
            if (data.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View("Index", gmModel);
            }
            var directory = System.Configuration.ConfigurationManager.AppSettings["MCompany"];
            var filename = string.Format("{0}-{1}.csv", "MCompany", this.GetCurrentDate());
            var fileFullName = System.IO.Path.Combine(directory, filename);
            string[] hideColumn = { };
            var file = this.CSVOutPut<CompanyListCSV>(data, hideColumn, fileFullName, "MCompany.csv");
            
            //Set download
            this.StoreFileDownload(file, gmModel.SeqNum);
            ViewBag.IsDownload = true;
            return View("Index", gmModel);
        }
        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(CompanyModels gmModel)
        {
            this.ClearModelState();
            if (this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Insert)
            {
                return this.Index(gmModel.SeqNum.ToString());
            }
            else
            {
                return RedirectToAction("Master", "Menu");
            }
        }
        #endregion
        
        #region Private Methods

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns></returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion(INDEX_URL);

            CompanyModels model = (CompanyModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(CompanyModels))
            {
                model = new CompanyModels();
                model.SeqNum = SeqNum;
            }
          
            return View("Index", model);
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(CompanyModels gmModel)
        {
            //Get data
            CompanyModels model = this.mCompanyService.GetCompany();

            //Check Exclusion
            if (model == default(CompanyModels) || gmModel.UpdateDate != model.UpdateDate)
            {                
                //Show error Message
                this.ShowMessageExclusion(INDEX_URL, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.iQueryable;
using System.Collections;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Web.Helpers;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Transactions;
using System.Text.RegularExpressions;
using Microsoft.Reporting.WebForms;
using System.Drawing;
using System.IO;
using System.Data;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// 移動指示入力
    /// Author: ISV-HUNG
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class MoveIndicationController : BaseController
    {
        #region PDF

        //Detail table
        private DataTable dtMain = null;
        private DataTable dtDetail = null;
        private int count = 0;

        /// <summary>
        /// Enum Fields Datatable Main
        /// </summary>
        private enum FieldsMain
        {
            ShipNo = 0,
            ShipDate,
            InstructDate,
            DestinationWarehouseCD,
            DestinationWarehouseName,
            TotalPage,
            Barcode,
            ShippingCompleteFlag,
            DestinationLocationCD,
            DestinationLocationName,
            DestinationLocationCDLabel,
            DestinationLocationNameLabel,
            DestinationWarehouseCDLabel,
            DestinationWarehouseNameLabel,
            WarehouseLabel,
            LocationLabel,
            DeliveryNumber         
        }

        /// <summary>
        /// Enum Fields Datatable Detail(Sub)
        /// </summary>
        private enum FieldsDetail
        {
            ShipNo = 0,
            OrderNo,
            LocationCD,
            TagNo,
            ProductCD,
            ProductName,
            Lot1,
            Lot2,
            Lot3,
            Quantity,
            TotalLabel,
            RowCount,
            IsDelied,
        }

        #endregion

        #region Common

        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.TShippingInstructionDetailsService tShippingInstructionDetailService;
        private DataAccess.MProductService mProductService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TStockAllowanceService tStockAllowanceService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;
        private int rowNumDetail = 10;
        private int MaxQty = 1;
        private int MaxPageSizeDetail = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tInventory_DService">TInventory_DService</param>
        /// <param name="tInventory_HService">TInventory_HService</param>
        /// <param name="tShippingInstructionService">TShippingInstructionService</param>
        /// <param name="tShippingInstructionDetailService">TShippingInstructionDetailsService</param>
        /// <param name="mProductService">MProductService</param>
        /// <param name="tSequencesService">TSequencesService</param>
        /// <param name="tStockAllowanceService">TStockAllowanceService</param>
        /// <param name="tReserveService">TReserveService</param>
        /// <param name="tPessimisticLockService">TPessimisticLockService</param>
        /// <param name="mCompanyService">MCompanyService</param>
        /// <param name="mWarehouseService">MWarehouseService</param>
        /// <param name="mLocationService">MLocationService</param>
        /// <param name="mKind_DService">MKind_DService</param>
        public MoveIndicationController(DataAccess.TInventory_DService tInventory_DService
                                            , DataAccess.TInventory_HService tInventory_HService
                                            , DataAccess.TShippingInstructionService tShippingInstructionService
                                            , DataAccess.TShippingInstructionDetailsService tShippingInstructionDetailService
                                            , DataAccess.MProductService mProductService
                                            , DataAccess.TSequencesService tSequencesService
                                            , DataAccess.TStockAllowanceService tStockAllowanceService
                                            , DataAccess.TReserveService tReserveService
                                            , DataAccess.TPessimisticLockService tPessimisticLockService
                                            , DataAccess.MCompanyService mCompanyService
                                            , DataAccess.MWarehouseService mWarehouseService
                                            , DataAccess.MLocationService mLocationService
                                            , DataAccess.MKind_DService mKind_DService)
        {
            this.tInventory_DService = tInventory_DService;
            this.tInventory_HService = tInventory_HService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.tShippingInstructionDetailService = tShippingInstructionDetailService;
            this.mProductService = mProductService;
            this.tSequencesService = tSequencesService;
            this.tStockAllowanceService = tStockAllowanceService;
            this.tReserveService = tReserveService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.mCompanyService = mCompanyService;
            this.mWarehouseService = mWarehouseService;
            this.mLocationService = mLocationService;
            this.mKind_DService = mKind_DService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tInventory_DService.Context = ctx;
            this.tInventory_HService.Context = ctx;
            this.tShippingInstructionService.Context = ctx;
            this.tShippingInstructionDetailService.Context = ctx;
            this.mProductService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tStockAllowanceService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.mCompanyService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.mLocationService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
            this.MaxPageSizeDetail = this.mKind_DService.GetMaxRowAndQuantity(Constant.MKIND_DATACD_MAX_ROW_MOB, 0);
            this.MaxQty = this.mKind_DService.GetMaxRowAndQuantity(Constant.MKIND_DATACD_MAX_QTY_MOB, 0);
            if (MaxPageSizeDetail > MaxQty)
            {
                MaxPageSizeDetail = MaxQty;
            }
            if (this.rowNumDetail > this.MaxPageSizeDetail)
            {
                this.rowNumDetail = this.MaxPageSizeDetail;
            }
        }

        #endregion

        #region Constant

        private const string KEY_MOVEDATE_DAYFROM = "MoveDate.Day";
        private const string KEY_MOVEDATE_DAYFROMID = "MoveDate_Day";
        private const string KEY_DELIVERY_NUMBER = "txt_DeliveryNumber";
        private const string KEY_WAREHOUSECDTO = "txt_WarehouseCDTo";
        private const string KEY_LOCATIONCDFROM = "txt_LocationCDFrom";
        private const string KEY_LOCATIONCDTO = "txt_LocationCDTo";
        private const string KEY_MOVENO = "txt_MoveNo";
        private const string KEY_DDL_MOVEKIND = "ddl_MoveKind";
        private const string KEY_TAG_NO = "txt_TagNo";

        private const string CHK_FIRST_ROW = "checkFirst";
        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_MOVEALL_DEFAULT = "TagInfo";
        private const string SORT_URL = "/MoveIndication/Sorting";
        private const string SORT_MOVEALL_URL = "/MoveIndication/AllMoveSorting";

        private const string BUTTON_EDIT = "btnUpdate";
        private const string BUTTON_BACK = "btnBack";
        private const string SCREEN_INDEX = "Index";

        //private const int ROWNUMBER_DEFAULT = 10;

        //Print
        private const string PRINT_ACTION_URL = "/MoveIndication/PrintAction";
        private const string PDF_REPORTDATASOURCE_MAIN = "MoveIndicationDataSet";
        private const string PDF_REPORTDATASOURCE_DETAIL = "SubMoveIndicationDataSet";
        private const string SES_DETAIL_PAGING_MOVEALL = "Ses_Detail_Paging_MoveAll";
        private const string SES_DETAIL_SORT_MOVEALL = "Ses_Detail_Sort_MoveAll";
        private const string SES_DETAIL_MOVEALL_LIST = "Ses_Detail_MoveAll_List";
        private const int PDF_NUMBER_ROW_PER_FIRST_PAGE = 15;
        private const int PDF_NUMBER_ROW_PER_NEXT_PAGE = 20;
        private const string PDF_FILENAME = "MoveIndication_{0}.pdf";
        private const string PDF_PATH_MAIN_LOCALREPORT = "~/Report/MoveIndication.rdlc";
        private const string PDF_PATH_SUB_LOCALREPORT = "~/Report/SubMoveIndication.rdlc";
        
        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">MoveIndicationList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(MoveIndicationList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(MoveIndicationList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                MoveIndicationList oldModel = (MoveIndicationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(MoveIndicationList))
                {
                    gmModel = oldModel;
                    isFormBack = true;
                    gmModel.isPreLoad = true;

                    //Search data
                    IQueryable<MoveIndicationResults> results = null;
                    results = this.tShippingInstructionService.GetListByConditionForMoveIndication(gmModel);

                    //Restore Paging Sorting
                    this.RestorePagingSorting(gmModel.SeqNum, results);

                    //Focus
                    SetFocusId(KEY_MOVENO);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Set value default
            gmModel.isPreLoad = false;
            this.SetDropDownlist(gmModel.ddl_MoveKind, true);

            //Store Print Hastable
            this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()] = new Hashtable();

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<MoveIndicationResults> results = null;
                results = this.tShippingInstructionService.GetListByConditionForMoveIndication(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<MoveIndicationResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(KEY_MOVENO);
            }

            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = new List<string>();

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }
            return View("Index", gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            MoveIndicationList gmModel = new MoveIndicationList();

            //Get search result from session
            IQueryable<MoveIndicationResults> list = (IQueryable<MoveIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<MoveIndicationResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List", gmModel);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            MoveIndicationList gmModel = new MoveIndicationList();

            //Get search result from session
            IQueryable<MoveIndicationResults> list = (IQueryable<MoveIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<MoveIndicationResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List", gmModel);
        }

        #endregion

        #region Show

        /// <summary>
        /// Update Data from gamen to list
        /// </summary>
        /// <param name="list">list</param>
        /// <param name="gmList">gamen list</param>
        /// <param name="space">space</param>
        private void UpdateList(ref List<MoveIndicationDetailGrid> list, List<MoveIndicationDetailGrid> gmList, int space)
        {
            for (int i = 0; i < gmList.Count(); i++)
            {
                list[i + space].MoveKind = gmList[i].MoveKind;
                list[i + space].txt_TagInfo = gmList[i].txt_TagInfo;
                list[i + space].txt_LocationCD = gmList[i].txt_LocationCD;
                list[i + space].txt_ProductCD = gmList[i].txt_ProductCD;
                list[i + space].txt_ProductName = gmList[i].txt_ProductName;
                list[i + space].txt_ArrivalDate = gmList[i].txt_ArrivalDate;
                list[i + space].txt_Lot1 = gmList[i].txt_Lot1;
                list[i + space].txt_LOT2 = gmList[i].txt_LOT2;
                list[i + space].txt_LOT3 = gmList[i].txt_LOT3;
                list[i + space].txt_StockStatusDisp = gmList[i].txt_StockStatusDisp;
                list[i + space].StockStatus = gmList[i].StockStatus;
                list[i + space].IsPicked = gmList[i].IsPicked;
                list[i + space].Delete = gmList[i].Delete;
                list[i + space].CompleteFlag = gmList[i].CompleteFlag;
                list[i + space].IsUsedMoveNo = gmList[i].IsUsedMoveNo;
            }
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <returns></returns>
        public ActionResult DetailPaging(PagingRequest pageRequest, int SeqNum, MoveIndicationMain gmModel)
        {
            //Clear Model State
            this.ClearModelState();

            //Get search result from session
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()]).ToList();
            int space = (gmModel.PageInfo.CurrentPage - 1) * gmModel.PageInfo.ItemsPerPage;

            UpdateList(ref list, gmModel.Detail, space);

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()] = list;
            var listI = list.AsQueryable();

            //Paging
            this.PagingBase<MoveIndicationDetailGrid>(ref listI, pageRequest, new SortingInfo(), SeqNum, gmModel.PageInfo.ItemsPerPage, notStore: true);

            IQueryable<MoveIndicationDetailGrid> Grid = (IQueryable<MoveIndicationDetailGrid>)ViewBag.Result;

            gmModel.PageInfo = (PagingInfo)ViewBag.PagingInfo;

            //Grid Data
            gmModel.Detail = Grid.ToList();

            return PartialView("_ListDetail", gmModel);
        }

        /// <summary>
        /// View Detail
        /// </summary>
        /// <param name="value1">MoveNo</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0255);
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + value2.ToString()] = new List<string>();

            //Set mode state
            this.SetMode(Common.Mode.Show, value2);

            MoveIndicationMain gmModel = new MoveIndicationMain();

            //Get data header
            gmModel = tShippingInstructionService.GetHeaderResultsByMoveNo(value1);

            //Check exclution
            if (gmModel == default(MoveIndicationMain))
            {
                return this.ExclusionProcess(value2);
            }

            //Show header
            gmModel.PreMoveNo = value1;
            gmModel.txt_MoveDate = @CommonUtil.ParseDate(gmModel.txt_MoveDate, Constant.FMT_YMD, Constant.FMT_DATE);
            if (!string.IsNullOrEmpty(gmModel.txt_WarehouseCDTo))
            {
                gmModel.MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE;
            }
            else if (!string.IsNullOrEmpty(gmModel.txt_LocationCDTo))
            {
                gmModel.MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_LOCATION;
            }
            else
            {
                gmModel.MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_SCRAP;
            }

            gmModel.ddl_MoveKind = gmModel.MoveKind;

            gmModel.moveKindDisp = this.GetDisplayMoveKind(Constant.MKIND_KINDCD_MOVE_KIND, gmModel.MoveKind);
            ViewBag.DeleteFlag = gmModel.DeleteFlag;

            //Show details
            var listDetail = this.tShippingInstructionDetailService.GetListByMoveNo(value1, value2, gmModel.CompleteFlag, gmModel.txt_LocationCDTo).ToList();
            this.SetNumRow(listDetail);

            //Store result into session
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + value2.ToString()] = listDetail;

            //Set default sort
            ViewBag.SortingInfo = new SortingInfo();

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = 1,
                ItemsPerPage = this.MaxPageSizeDetail,
                TotalItems = listDetail.Count(),

            };
            gmModel.PageInfo = pageInfo;
            gmModel.IsPicked = listDetail.Any(m => m.IsPicked);
            gmModel.Detail = listDetail.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();

            //Store data into session
            gmModel.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            //Set focus
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INCLUDE_DELETE_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                this.SetFocusId(BUTTON_EDIT);
            }
            else
            {
                this.SetFocusId(BUTTON_BACK);
            }

            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Details", gmModel);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="SeqNum">Sequense Number</param>
        /// <param name="MoveKind">Move Kind</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(int SeqNum, string MoveKind)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            if (string.IsNullOrEmpty(MoveKind))
            {
                MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_LOCATION;
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0256);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            this.SetFocusId(KEY_MOVEDATE_DAYFROMID);

            //Set display data
            MoveIndicationMain gmModel = new MoveIndicationMain();
            gmModel.MoveDate = new DateControl(DateTime.Now.ToString(Constant.FMT_YMD));
            gmModel.MoveKind = MoveKind;
            gmModel.ddl_MoveKind = MoveKind;
            gmModel.SeqNum = SeqNum;

            //Set data for DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //Add empty rows
            List<MoveIndicationDetailGrid> list = new List<MoveIndicationDetailGrid>();
            this.AddEmtyRows(ref list, this.rowNumDetail, SeqNum);
            gmModel.Detail = list;
            gmModel.MaxQty = this.MaxQty;
            gmModel.CurQty = list.Count();

            ViewBag.SortingInfo = new SortingInfo();

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = 1,
                ItemsPerPage = this.MaxPageSizeDetail,
                TotalItems = list.Count(),

            };
            gmModel.PageInfo = pageInfo;

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()] = list;

            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = gmModel;

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(MoveIndicationMain gmModel)
        {

            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            int space = (gmModel.PageInfo.CurrentPage - 1) * gmModel.PageInfo.ItemsPerPage;

            UpdateList(ref list, gmModel.Detail, space);

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = list;

            //Sort Error
            this.SortModelState(typeof(MoveIndicationMain));

            //Set data for DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            if (this.ModelState.IsValid)
            {
                this.ClearModelState();
                //Insert check
                if (this.InsertCheck(ref gmModel, list))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/InsertAction", value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        public ActionResult InsertAction(string value1)
        {
            //Get data from session
            MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            
            //Set data for DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //Insert check
            if (!this.InsertCheck(ref gmModel, list))
            {
                return View("Details", gmModel);
            }

            //Insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;

            switch (this.InsertData(gmModel, list))
            {
                case CommitFlag.DataChanged:
                case CommitFlag.InsertExclusion:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    //this.ClearSession(gmModel);
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;

                    ret = RedirectToAction("Index");
                    break;
                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = InsertConfirm(gmModel);
                    break;
            }
            return ret;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(MoveIndicationMain gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Clear ModelState
            this.ClearModelState();

            //Set ViewBag
            ViewBag.DeleteFlag = gmModel.DeleteFlag;

            if (DeleteCheck(gmModel))
            {
             
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/DeleteAction", value1: gmModel.SeqNum.ToString());

                this.SetMode(Common.Mode.Show, gmModel.SeqNum);
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult DeleteAction(int value1)
        {
            //Get model from session
            MoveIndicationMain gModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            //Set data for DropDownList
            this.SetDropDownlist(gModel.ddl_MoveKind);

            //Delete check
            string message = String.Empty;
            if (this.DeleteCheck(gModel))
            {
                //Delete data
                ActionResult ret = default(ActionResult);
                switch (this.DeleteData(gModel))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(gModel.PreMoveNo, value1);
                        break;

                    case CommitFlag.IsExistsInAnotherTB:

                        this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0013));
                        ret = Show(gModel.PreMoveNo, value1);
                        break;

                    case CommitFlag.Success:
                        //this.ClearSession(gModel);
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0007);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = Show(gModel.PreMoveNo, value1);
                        break;
                }
                return ret;
            }
            else
            {
                return View("Details", gModel);
            }
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            //Get data
            MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            //List<MoveIndicationDetailGrid> list = (List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()];

            //Get UpdateDate
            MoveIndicationMain ret = tShippingInstructionService.GetHeaderResultsByMoveNo(gmModel.PreMoveNo);

            //Check Exclusion
            if (ret == default(MoveIndicationMain) || gmModel.UpdateDate != ret.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            List<MoveIndicationDetailGrid> list = this.tShippingInstructionDetailService.GetListByMoveNo(gmModel.PreMoveNo, SeqNum, gmModel.CompleteFlag, gmModel.txt_LocationCDTo).ToList();
            this.SetNumRow(list);
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + SeqNum.ToString()] = list;

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0257);

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            if (!gmModel.CompleteFlag) {

                //Add empty rows
                int rowsAddNum = this.rowNumDetail - gmModel.Detail.Count();
                this.AddEmtyRows(ref list, rowsAddNum, gmModel.SeqNum);
            }

             ViewBag.SortingInfo = new SortingInfo();

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = 1,
                ItemsPerPage = this.MaxPageSizeDetail,
                TotalItems = list.Count(),

            };
            gmModel.PageInfo = pageInfo;
            gmModel.IsPicked = list.Any(m => m.IsPicked);
            gmModel.Detail = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
            gmModel.MaxQty = this.MaxQty;
            gmModel.CurQty = list.Count();

            //Set Sequence Number
            gmModel.SeqNum = SeqNum;
            string value = CommonUtil.ParseDate(gmModel.txt_MoveDate, Constant.FMT_DATE, Constant.FMT_YMD);
            gmModel.MoveDate = new DateControl(value);
            gmModel.moveKindDisp = this.GetDisplayMoveKind(Constant.MKIND_KINDCD_MOVE_KIND, gmModel.MoveKind);
            if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                gmModel.txt_WarehouseCDTo = ret.txt_WarehouseCDTo;

            }
            else if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
            {
                gmModel.txt_LocationCDTo = ret.txt_LocationCDTo;
            }

            if (!gmModel.CompleteFlag)
            {
                //Set focus
                this.SetFocusId(KEY_MOVEDATE_DAYFROMID);
            }
            else
            { 
                //Set focus
                this.SetFocusId(KEY_DELIVERY_NUMBER);
            }

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update confirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(MoveIndicationMain gmModel)
        {
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            int space = (gmModel.PageInfo.CurrentPage - 1) * gmModel.PageInfo.ItemsPerPage;

            UpdateList(ref list, gmModel.Detail, space);

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                this.ClearModelState();

                //Update check
                if (this.UpdateCheck(ref gmModel, list))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/UpdateAction", value1: gmModel.SeqNum.ToString());
                }
            }
            return View("Details", gmModel);
        }

        /// <summary>
        /// Update action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        public ActionResult UpdateAction(string value1)
        {
            //Get data from session
            MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();

            //Set data for DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //Update check
            if (this.UpdateCheck(ref gmModel, list))
            {
                //Update data
                string message = string.Empty;
                ActionResult ret = default(ActionResult);
                switch (this.UpdateData(gmModel, list))
                {
                    case CommitFlag.DataChanged:
                        this.ShowMessageExclusion("/MoveIndication/Show", gmModel.PreMoveNo, gmModel.SeqNum.ToString(), gmModel.MoveKind);
                        ret = View("Details", gmModel);
                        break;

                    case CommitFlag.Success:
                        //this.ClearSession(gmModel);
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("Index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0011);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = UpdateConfirm(gmModel);
                        break;
                }

                return ret;
            }
            else
            {
                return View("Details", gmModel);
            }
        }

        #endregion

        #region Clear

        ///// <summary>
        ///// Clear for change kind
        ///// </summary>
        ///// <param name="gmModel">MoveIndicationMain</param>
        ///// <returns>ActionResult</returns>
        //[HttpPost]
        //[iHttpParamAction]
        //public ActionResult ClearForChangeKind(MoveIndicationMain gmModel)
        //{
        //    //This clear model state
        //    this.ClearModelState();

        //    return ClearAction(gmModel.SeqNum, gmModel.MoveKind);
        //}

        /// <summary>
        /// Clear confirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult ClearConfirm(MoveIndicationMain gmModel)
        {
            //Clear model state
            this.ClearModelState();

            this.SetDropDownlist(gmModel.ddl_MoveKind);
            //Show confirm message
            this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/ClearAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0043), value1: gmModel.SeqNum.ToString());

            return View("Details", gmModel);
        }

        /// <summary>
        /// Clear Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// /// <param name="value2">Move Kind</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult ClearAction(int value1)
        {
            //Set title
            this.Session[Constant.SESSION_TITLE + value1.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0256);

            //Set mode state
            this.SetMode(Common.Mode.Insert, value1);

            //Set focus
            this.SetFocusId(KEY_MOVEDATE_DAYFROMID);

            //Set data display
            MoveIndicationMain gmModel = new MoveIndicationMain();
            gmModel.MoveDate = new DateControl(DateTime.Now.ToString(Constant.FMT_YMD));
            gmModel.SeqNum = value1;
            gmModel.MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_LOCATION;
            gmModel.ddl_MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_LOCATION;
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //Add empty rows 
            List<MoveIndicationDetailGrid> list = new List<MoveIndicationDetailGrid>();
            this.AddEmtyRows(ref list, this.rowNumDetail, value1);
            gmModel.Detail = list;
            gmModel.MaxQty = this.MaxQty;
            gmModel.CurQty = list.Count();
            
            ViewBag.SortingInfo = new SortingInfo();

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = 1,
                ItemsPerPage = this.MaxPageSizeDetail,
                TotalItems = list.Count(),

            };
            gmModel.PageInfo = pageInfo;

            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = new List<string>();
            this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = gmModel;

            return View("Details", gmModel);
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(MoveIndicationMain gmModel)
        {
            this.ClearModelState();

            //Clear sessiong detail
            //this.ClearSession(gmModel);

            if (!String.IsNullOrEmpty(gmModel.PreMoveNo) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.PreMoveNo, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Private Method

        /// <summary>
        /// Restore Paging Sorting
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequense number</param>
        /// <param name="results">results</param>
        private void RestorePagingSorting(int SeqNum, IQueryable<MoveIndicationResults> results)
        {
            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + SeqNum.ToString()];

            this.PagingBase<MoveIndicationResults>(ref results, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
        }

        /// <summary>
        /// Add empty rows 
        /// </summary>
        /// <param name="gmodel">MoveIndicationMain</param>
        /// <param name="rowsNum">Number of rows</param>
        /// <param name="SeqNum">Sequense Num</param>
        private void AddEmtyRows(ref List<MoveIndicationDetailGrid> list, int rowsNum, int SeqNum)
        {
            for (int i = 0; i < rowsNum; i++)
            {
                int newRowNum = list == null ? i + 1 : list.Count + 1;
                MoveIndicationDetailGrid item = new MoveIndicationDetailGrid(newRowNum, SeqNum);
                list.Add(item);
            }
        }

        ///<summary>
        ///Set DropDownlist All
        ///</summary>
        ///<param name="moveKind">Move Kind</param>
        private void SetDropDownlist(string moveKind, bool isWithBlank = false)
        {
            //Get List MKind_D: Move Kind
            List<MKind_D> dropMoveKind = this.mKind_DService.GetListByDataKindForMoveIndication(Constant.MKIND_KINDCD_MOVE_KIND).ToList();
            if (isWithBlank)
            {
                MKind_D emptyItem = new MKind_D();
                emptyItem.KindCD = Constant.MKIND_KINDCD_MOVE_KIND;
                emptyItem.DataCD = string.Empty;
                emptyItem.Value = Constant.BLANK;

                dropMoveKind.Insert(0, emptyItem);
            }

            this.CreateViewBagMoveKind(dropMoveKind, KEY_DDL_MOVEKIND, moveKind);
        }

        /// <summary>
        /// Get Display Move Kind
        /// </summary>
        /// <param name="KindCD"></param>
        /// <param name="dataCD"></param>
        /// <returns></returns>
        private string GetDisplayMoveKind(string KindCD, string dataCD)
        {
            MKind_D mKind = mKind_DService.GetByPK(KindCD, dataCD);
            return mKind.Value;
        }

        ///<summary>
        ///Create Move Kind: MoveKind SelectList
        ///</summary>
        ///<param name="dropSrc">Dropdownlist</param>
        ///<param name="control">Control name</param>
        ///<param name="value">Selected value</param>
        private void CreateViewBagMoveKind(List<MKind_D> dropSrc, string control, string value)
        {
            SelectOption option = new SelectOption("Value", "DataCD", control, value);
            this.SetViewDataDropdownList<MKind_D>(option, dropSrc);
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //set exclusion message
            this.ShowMessageExclusion("/MoveIndication/Index");

            MoveIndicationMain model = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            if (model == default(MoveIndicationMain))
            {
                model = new MoveIndicationMain();
                model.SeqNum = SeqNum;
            }
            return View("Details", model);
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheck(ref MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            //Check header
            if (!this.InsertCheckHeader(gmModel, list))
            {
                return false;
            }

            //Check detail
            if (!this.InsertCheckDetail(ref gmModel, list))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check header
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckHeader(MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            bool ret = true;

            string moveDate = gmModel.MoveDate.Year + gmModel.MoveDate.Month + gmModel.MoveDate.Day;
            //Check required
            if (string.IsNullOrEmpty(moveDate))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
                this.ModelState.AddModelError(KEY_MOVEDATE_DAYFROM, message);
                ret = false;
            }
            else
            {
                //Check shipping data > now data
                int shipDateOut = 0;
                string nowDate = DateTime.Now.ToString(Constant.FMT_YMD);
                int nowDateOut = 0;
                int.TryParse(moveDate, out shipDateOut);
                int.TryParse(nowDate, out nowDateOut);
                
                if (shipDateOut < nowDateOut)
                {
                    string message = this.FormatMessage(Constant.MES_E0005, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0164), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
                    this.ModelState.AddModelError(KEY_MOVEDATE_DAYFROM, message);
                    ret = false;
                }
            }

            if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                //Check required
                if (string.IsNullOrEmpty(gmModel.txt_WarehouseCDTo))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193));
                    this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                    ret = false;
                }
                else
                {
                    //Check WarehouseCD exist in Warehouse Master
                    WarehouseModels modelWarehouse = this.mWarehouseService.GetByCd(gmModel.txt_WarehouseCDTo);
                    if (modelWarehouse == null || modelWarehouse.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193));
                        this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                        gmModel.txt_WarehouseName = string.Empty;
                        ret = false;
                    }
                    else 
                    {
                        gmModel.txt_WarehouseName = modelWarehouse.WarehouseName;
                    }

                    //Check WarehouseCDTo
                    if (gmModel.txt_WarehouseCDTo.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0065);
                        this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                        ret = false;
                    }
                }
            }
            else if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
            {
                //Check required
                if (string.IsNullOrEmpty(gmModel.txt_LocationCDTo))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0191));
                    this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                    ret = false;
                }
                else
                {
                    //Check LocationCD exist in Location Master
                    LocationModels modelLocation = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCDTo);
                    if (modelLocation == null || modelLocation.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0191));
                        this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                        gmModel.txt_LocationName = string.Empty;
                        ret = false;
                    }
                    else
                    {
                        gmModel.txt_LocationName = modelLocation.LocationName;
                        if (modelLocation.ReceiptProhibitionFlag)
                        {
                            string message = this.FormatMessage(Constant.MES_M0017, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0191));
                            this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                            ret = false;
                        }
                    }
                }
            }
            return ret;
        }

        /// <summary>
        /// Check detail
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool InsertCheckDetail(ref MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            bool ret = true;
            bool hasData = false;
            string moveNo = string.Empty;

            List<string> listDuplicate = new List<string>();
            List<string> listKey = new List<string>();
            List<string> listErrKeys = new List<string>();
            int firstErrPage = 0;

            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].isEmptyRow())
                {
                    continue;
                }
                hasData = true;
                string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), i + 1);
                
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                var lstErrTag = this.CheckScreenTagNoInput(list[i].txt_TagInfo, ref tagNo, ref branchTagNo);
                if (lstErrTag.Count() > 0)
                {
                    foreach (var item in lstErrTag)
                    {
                        this.ModelState.AddModelError(string.Empty, item + row);                        
                    }
                    listErrKeys.Add((i + 1).ToString());
                    if (firstErrPage == 0)
                    {
                        firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                    }
                    ret = false;
                    continue;
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (dbModelInventory_D == null || dbModelInventory_H == null || dbModelInventory_H.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(string.Empty, message + row);
                    listErrKeys.Add((i + 1).ToString());
                    ret = false;
                }
                else
                {
                    //Duplicate ProdcutCD
                    if (!listDuplicate.Contains(list[i].txt_TagInfo.Trim()))
                    {
                        listDuplicate.Add(list[i].txt_TagInfo.Trim());
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0019, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        this.ModelState.AddModelError(string.Empty, message + row);
                        listErrKeys.Add((i + 1).ToString());
                        ret = false;
                        if (firstErrPage == 0)
                        {
                            firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                        }
                        continue;
                    }

                    LocationModels modelLo = this.mLocationService.GetByCd(UserSession.Session.WarehouseCD, dbModelInventory_D.LocationCD);
                    if (modelLo != default(LocationModels) && modelLo.IssueProhibitionFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0075, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                        this.ModelState.AddModelError(string.Empty, message + row);
                        listErrKeys.Add((i + 1).ToString());
                        ret = false;
                    }

                    //Check StockStatus
                    if (!gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
                    {
                        if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION) && !string.IsNullOrEmpty(list[i].txt_LocationCD) && list[i].txt_LocationCD.Equals(gmModel.txt_LocationCDTo))
                        {
                            string message = this.FormatMessage(Constant.MES_M0065);
                            this.ModelState.AddModelError(string.Empty, message + row);
                            listErrKeys.Add((i + 1).ToString());
                            ret = false;
                        }
                        else
                        {
                            if (!dbModelInventory_D.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
                            && !dbModelInventory_D.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                            {

                                //Show error message
                                string message = this.FormatMessage(Constant.MES_M0079);
                                this.ModelState.AddModelError(string.Empty, message + row);
                                listErrKeys.Add((i + 1).ToString());
                                ret = false;
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(dbModelInventory_D.ShippingNo))
                                {
                                    //Show error message
                                    string message = this.FormatMessage(Constant.MES_M0079, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                                    this.ModelState.AddModelError(string.Empty, message + row);
                                    listErrKeys.Add((i + 1).ToString());
                                    ret = false;
                                }
                            }
                        }
                    }
                    else
                    {
                        list[i].StockStatus = dbModelInventory_D.StockStatus;

                        if (!dbModelInventory_D.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                        {
                            //Show error message
                            string message = this.FormatMessage(Constant.MES_M0079, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                            this.ModelState.AddModelError(string.Empty, message + row);
                            listErrKeys.Add((i + 1).ToString());
                            ret = false;
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(dbModelInventory_D.ShippingNo))
                            {
                                //Show error message
                                string message = this.FormatMessage(Constant.MES_M0079, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                                this.ModelState.AddModelError(string.Empty, message + row);
                                listErrKeys.Add((i + 1).ToString());
                                ret = false;
                            }
                        }
                    }
                }
                if(ret && dbModelInventory_D.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                {
                    listKey.Add(dbModelInventory_D.TagNo + dbModelInventory_D.LocationCD);
                }

                if (firstErrPage == 0 && !ret)
                {
                    firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                }
            }

            if(ret && hasData)
            {
                listKey = listKey.Distinct().ToList();
                foreach (var item in listKey)
	            {
                    int countNeed = this.tReserveService.GetCountByConditionsForMoveIndication(moveNo, item.Substring(0, 10), item.Substring(10));
                    int countReg = list.Where(m => !string.IsNullOrEmpty(m.txt_TagInfo) 
                                                            && (m.txt_TagInfo.Substring(0, 10) + m.txt_LocationCD).Equals(item) 
                                                            && m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)).Count();
                    int countCan = this.tInventory_DService.GetCountByConditionsForMoveIndication(moveNo, item.Substring(0, 10), item.Substring(10));
                    if (countCan - countNeed < countReg)
                    {
                        string message = this.FormatMessage(Constant.MES_M0080, item.Substring(0, 10), item.Substring(10));

                        int index = 0;
                        for (int i = 0; i < list.Count - 1; i++)
                        {
                            if (list[i].isEmptyRow())
                            {
                                continue;
                            }
                            if (item.Substring(0, 10).Equals(list[i].txt_TagInfo.Substring(0, 10)) && item.Substring(10).Equals(list[i].txt_LocationCD))
                            {
                                index = i;
                                break;
                            }
                            
                        }
                        this.ModelState.AddModelError(string.Empty, message);
                        listErrKeys.Add((index + 1).ToString());
                        if (firstErrPage == 0)
                        {
                            firstErrPage = index / gmModel.PageInfo.ItemsPerPage + 1;
                        }

                        ret = false;
                    }
	            }
            }

            if (!hasData)
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(string.Empty, message);
                listErrKeys.Add("1");
                firstErrPage = 1;
                ret = false;
            }

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = firstErrPage == 0 ? 1 : firstErrPage,
                ItemsPerPage = this.rowNumDetail,
                TotalItems = list.Count(),
            };
            gmModel.PageInfo = pageInfo;

            gmModel.Detail = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = listErrKeys;

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag InsertData(MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    string curDate = this.GetCurrentDate();

                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();

                    List<string> listKeyP = list.Where(m => !string.IsNullOrEmpty(m.txt_TagInfo)).Select(m => m.txt_TagInfo.Substring(0, 10)).Distinct().ToList();
                    listInsert = listKeyP.Select(m => new TPessimisticLock { TagNo = m }).ToList();

                    this.tPessimisticLockService.Insert(listInsert);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //TSequences
                    string newMaxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_SHIPNO, curDate.Substring(2, 4));
                    TSequences sequencesModel = this.tSequencesService.GetByPK(Constant.TAGNO_DIVISION_SHIPNO);

                    //Get insert model header
                    TShippingInstruction headerModel = new TShippingInstruction();
                    headerModel.ShipNo = newMaxTagNo;
                    headerModel.InstructDate = curDate.Substring(0, 8);
                    headerModel.ShipDate = gmModel.MoveDate.DateValue();
                    headerModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
                    if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                    {
                        headerModel.DestinationWarehouseCD = gmModel.txt_WarehouseCDTo;
                    }
                    else if  (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
                    {
                        headerModel.DestinationLocationCD = gmModel.txt_LocationCDTo;
                    }
                    headerModel.DeliveryNumber = gmModel.txt_DeliveryNumber;
                    headerModel.Memo = gmModel.Memo;
                    headerModel.ShippingPrintFlag = false;
                    headerModel.PickingCompleteFlag = false;
                    headerModel.ShippingCompleteFlag = false;
                    headerModel.DeleteFlag = false;
                    headerModel.CreateDate = curDate;
                    headerModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    headerModel.UpdateDate = headerModel.CreateDate;
                    headerModel.UpdateUCD = headerModel.CreateUCD;

                    //Get insert model detail
                    List<TShippingInstructionDetails> listDetail = new List<TShippingInstructionDetails>();
                    int detailNo = 0;
                    var listData = list.Where(m=>!m.isEmptyRow());

                    foreach (var item in listData)
                    {
                        var listTag = item.txt_TagInfo.Split(Constant.HYPHEN_CHAR);

                        TShippingInstructionDetails ret = new TShippingInstructionDetails();
                        ret.ShipNo = newMaxTagNo;
                        ret.ShipDetailNo = detailNo + 1;
                        ret.TagNo = listTag[0];
                        ret.BranchTagNo = CommonUtil.ParseInteger(listTag[1]);
                        ret.ProductCD = item.txt_ProductCD;
                        ret.InstructQuantity = 1;
                        listDetail.Add(ret);

                        TInventory_D modelID = this.tInventory_DService.GetByPK(listTag[0], ret.BranchTagNo.Value);
                        modelID.ShippingNo = newMaxTagNo;
                        modelID.ShippingDetailNo = detailNo + 1;
                        modelID.UpdateDate = curDate;
                        modelID.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                        
                        detailNo++;
                    }

                    //Insert header
                    this.tShippingInstructionService.Insert(headerModel);
                    
                    //Insert detail
                    this.tShippingInstructionDetailService.Insert(listDetail);
                    
                    //Remove lock
                    this.tPessimisticLockService.Delete(listInsert);

                    //Submit only header context
                    this.tShippingInstructionService.Context.SubmitChanges();

                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK) || sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTIONDETAIL_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;
        }

        /// <summary>
        /// Delete check
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool DeleteCheck(MoveIndicationMain gmModel)
        {
            //Get data hearder
            MoveIndicationMain ret = this.tShippingInstructionService.GetHeaderResultsByMoveNo(gmModel.PreMoveNo);

            //Check Exclusion
            if (ret == default(MoveIndicationMain) || gmModel.UpdateDate != ret.UpdateDate)
            {
                this.ShowMessageExclusion("/MoveIndication/Show", value1: gmModel.PreMoveNo, value2: gmModel.SeqNum.ToString());
                return false;
            }

            // Not delete when complete picking
            if (ret.CompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0038, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }

            //Check picking data
            IQueryable<TInventory_D> listInDe = this.tInventory_DService.GetListByShipNo(gmModel.PreMoveNo);            
            bool isPickingData = !listInDe.All(m=>m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) || m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE));
            if (isPickingData)
            {
                //Can't delete data
                string message = this.FormatMessage(Constant.MES_M0039, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                this.ModelState.AddModelError(string.Empty, message);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag DeleteData(MoveIndicationMain gmModel)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                //Check data changed
                TShippingInstruction dbModel = this.tShippingInstructionService.GetByPk(gmModel.PreMoveNo);
                if (dbModel == default(TShippingInstruction) || dbModel.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }

                IQueryable<TInventory_D> listInDe = this.tInventory_DService.GetListByShipNo(gmModel.PreMoveNo);            
                bool isPickingData = !listInDe.All(m=>m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) || m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE));
                if (isPickingData)
                {
                    return CommitFlag.DataChanged;
                }

                //Add lock
                List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                List<string> listKeyP = gmModel.Detail.Where(m => !string.IsNullOrEmpty(m.txt_TagInfo)).Select(m => m.txt_TagInfo.Substring(0, 10)).Distinct().ToList();
                listInsert = listKeyP.Select(m => new TPessimisticLock { TagNo = m }).ToList();

                this.tPessimisticLockService.Insert(listInsert);
                this.tPessimisticLockService.Context.SubmitChanges();

                //Update TInventory Details
                IQueryable<TInventory_D> listReMove = this.tInventory_DService.GetListByShipNo(gmModel.PreMoveNo);

                foreach (var item in listReMove)
                {
                    item.ShippingNo = null;
                    item.ShippingDetailNo = null;
                    item.UpdateDate = curDate;
                    item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }

                //Update header
                dbModel.DeleteFlag = true;
                dbModel.UpdateDate = curDate;
                dbModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                

                //Remove lock
                this.tPessimisticLockService.Delete(listInsert);
                this.tShippingInstructionService.Context.SubmitChanges();

            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK) || sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTIONDETAIL_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }
            return CommitFlag.Success;
        }

        /// <summary>
        /// Update check
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool UpdateCheck(ref MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            TShippingInstruction header = this.tShippingInstructionService.GetByPk(gmModel.PreMoveNo);
            if (header == default(TShippingInstruction) || header.UpdateDate != gmModel.UpdateDate)
            {
                //Show error Message
                this.ShowMessageExclusion("/MoveIndication/Show", value1: gmModel.PreMoveNo, value2: gmModel.SeqNum.ToString());
                return false;
            }

            if (!gmModel.CompleteFlag)
            {
                var oldList = this.tInventory_DService.GetListByShipNo(gmModel.PreMoveNo);
                bool isPicking = !oldList.All(m => m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE));

                if (isPicking)
                {
                    if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE) && !gmModel.txt_WarehouseCDTo.Equals(header.DestinationWarehouseCD))
                    {
                        //Show error Message
                        this.ShowMessageExclusion("/MoveIndication/Show", value1: gmModel.PreMoveNo, value2: gmModel.SeqNum.ToString());
                        return false;
                    }
                    if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION) && !gmModel.txt_LocationCDTo.Equals(header.DestinationLocationCD))
                    {
                        //Show error Message
                        this.ShowMessageExclusion("/MoveIndication/Show", value1: gmModel.PreMoveNo, value2: gmModel.SeqNum.ToString());
                        return false;
                    }
                }

                if (!this.InsertCheckHeader(gmModel, list))
                {
                    return false;
                }

                if (gmModel.DeleteFlag)
                {
                    if (isPicking)
                    {
                        //Can't delete data
                        string message = this.FormatMessage(Constant.MES_M0039, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                        this.ModelState.AddModelError(string.Empty, message);
                        return false;
                    }

                }

                if (!this.UpdateCheckDetail(ref gmModel, list, oldList))
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Check detail
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool UpdateCheckDetail(ref MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list, IQueryable<TInventory_D> oldList)
        {
            bool ret = true;
            bool hasData = false;

            List<string> listDuplicate = new List<string>();
            List<string> listKey = new List<string>();
            List<string> listErrKeys = new List<string>();
            int firstErrPage = 0;

            for (int i = 0; i < list.Count(); i++)
            {
                if (list[i].isEmptyRow())
                {
                    continue;
                }
                hasData = true;

                string row = String.Format(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0145), i + 1);
                int curIndex = i % gmModel.PageInfo.ItemsPerPage;

                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                var lstErrTag = this.CheckScreenTagNoInput(list[i].txt_TagInfo, ref tagNo, ref branchTagNo);
                if (lstErrTag.Count() > 0)
                {
                    foreach (var item in lstErrTag)
                    {
                        this.ModelState.AddModelError(string.Empty, item + row);
                    }
                    listErrKeys.Add((i + 1).ToString());
                    if (firstErrPage == 0)
                    {
                        firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                    }
                    ret = false;
                    continue;
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (dbModelInventory_D == null || dbModelInventory_H == null || dbModelInventory_H.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(string.Format("Detail[{0}].txt_TagInfo", curIndex), message + row);
                    ret = false;
                }
                else
                {
                    //Duplicate ProdcutCD
                    if (!listDuplicate.Contains(list[i].txt_TagInfo.Trim()))
                    {
                        listDuplicate.Add(list[i].txt_TagInfo.Trim());
                    }
                    else
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_E0019, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        this.ModelState.AddModelError(string.Empty, message + row);
                        listErrKeys.Add((i + 1).ToString());
                        ret = false;
                        if (firstErrPage == 0)
                        {
                            firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                        }
                        continue;
                    }

                    if (!string.IsNullOrEmpty(dbModelInventory_D.ShippingNo) && !gmModel.PreMoveNo.Equals(dbModelInventory_D.ShippingNo))
                    {
                            //Show error message
                            string message = this.FormatMessage(Constant.MES_M0079, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                            this.ModelState.AddModelError(string.Empty, message + row);
                            listErrKeys.Add((i + 1).ToString());
                            ret = false;
                            continue;
                    }

                    LocationModels modelLo = this.mLocationService.GetByCd(UserSession.Session.WarehouseCD, dbModelInventory_D.LocationCD);
                    if (modelLo != default(LocationModels) && modelLo.IssueProhibitionFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0075, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                        this.ModelState.AddModelError(string.Empty, message + row);
                        listErrKeys.Add((i + 1).ToString());
                        ret = false;
                    }

                    list[i].StockStatus = dbModelInventory_D.StockStatus;
                    string status = list[i].StockStatus;
                    bool isExist = oldList.Any(m => m.TagNo.Equals(tagNo) && m.BranchTagNo.Equals(branchTagNo));

                    switch (gmModel.MoveKind)
                    {
                        case Constant.MKIND_KINDCD_MOVE_KIND_SCRAP:

                            if (isExist)
                            {
                                if (status.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                {
                                    //Show error message
                                    //thay doi
                                    string message = this.FormatMessage(Constant.MES_M0081);
                                    this.ModelState.AddModelError(string.Empty, message + row);
                                    listErrKeys.Add((i + 1).ToString());
                                    ret = false;
                                }
                            }
                            else
                            {
                                if (!status.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE))
                                {
                                    //Show error message
                                    //hok hop le
                                    string message = this.FormatMessage(Constant.MES_M0082);
                                    this.ModelState.AddModelError(string.Empty, message + row);
                                    listErrKeys.Add((i + 1).ToString());
                                    ret = false;
                                }
                            }
                            
                            break;
                        default:

                            if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION) && !string.IsNullOrEmpty(list[i].txt_LocationCD) && list[i].txt_LocationCD.Equals(gmModel.txt_LocationCDTo))
                            {
                                string message = this.FormatMessage(Constant.MES_M0065, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                                this.ModelState.AddModelError(string.Empty, message + row);
                                listErrKeys.Add((i + 1).ToString());
                                ret = false;
                                break;
                            }

                            if (!isExist)
                            {
                                if (!status.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) && !status.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                {
                                    //Show error message
                                    string message = this.FormatMessage(Constant.MES_M0079);
                                    this.ModelState.AddModelError(string.Empty, message + row);
                                    listErrKeys.Add((i + 1).ToString());
                                    ret = false;
                                }
                            }
                            break;
                    }
                }
                if(ret && dbModelInventory_D.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                {
                    listKey.Add(dbModelInventory_D.TagNo + dbModelInventory_D.LocationCD);
                }

                if (firstErrPage == 0 && !ret)
                {
                    firstErrPage = i / gmModel.PageInfo.ItemsPerPage + 1;
                }
            }

            if (ret)
            {
                var deleteList = oldList.Where(m => !listDuplicate.Contains(m.TagNo + Constant.HYPHEN + m.BranchTagNo.ToString().PadLeft(4, '0')));
                bool isChangePicked = deleteList.Any(m => !m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE) && !m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE));
                if (isChangePicked)
                {
                    //Show error Message
                    this.ShowMessageExclusion("/MoveIndication/Show", value1: gmModel.PreMoveNo, value2: gmModel.SeqNum.ToString());
                    return false;
                }
            }

            if (ret && hasData)
            {
                listKey = listKey.Distinct().ToList();
                foreach (var item in listKey)
                {
                    int countNeed = this.tReserveService.GetCountByConditionsForMoveIndication(gmModel.PreMoveNo, item.Substring(0, 10), item.Substring(10));
                    int countReg = list.Where(m => !string.IsNullOrEmpty(m.txt_TagInfo) && (m.txt_TagInfo.Substring(0, 10) + m.txt_LocationCD).Equals(item) && m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)).Count();
                    int countCan = this.tInventory_DService.GetCountByConditionsForMoveIndication(gmModel.PreMoveNo, item.Substring(0, 10), item.Substring(10));
                    if (countCan - countNeed < countReg)
                    {
                        string message = this.FormatMessage(Constant.MES_M0080, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
                        int index = 0;
                        for (int i = 0; i < list.Count - 1; i++)
                        {
                            if (list[i].isEmptyRow())
                            {
                                continue;
                            }
                            if (item.Substring(0, 10).Equals(list[i].txt_TagInfo.Substring(0, 10)) && item.Substring(10).Equals(list[i].txt_LocationCD) && !list[i].IsPicked)
                            {
                                index = i;
                                break;
                            }

                        }
                        this.ModelState.AddModelError(string.Empty, message);
                        listErrKeys.Add((index + 1).ToString());
                        if (firstErrPage == 0)
                        {
                            firstErrPage = index / gmModel.PageInfo.ItemsPerPage + 1;
                        }
                        ret = false;
                    }
                }              
            }

            if (!hasData)
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(string.Empty, message);
                listErrKeys.Add("1");
                firstErrPage = 1;
                ret = false;
            }

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = firstErrPage == 0 ? 1 : firstErrPage,
                ItemsPerPage = this.rowNumDetail,
                TotalItems = list.Count(),
            };
            gmModel.PageInfo = pageInfo;

            gmModel.Detail = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = listErrKeys;

            return ret;
        }

        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateData(MoveIndicationMain gmModel, List<MoveIndicationDetailGrid> list)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                var curDate = this.GetCurrentDate();
                try
                {
                    //Get model update
                    TShippingInstruction headerModel = this.tShippingInstructionService.GetByPk(gmModel.PreMoveNo);

                    if (headerModel == default(TShippingInstruction) || headerModel.UpdateDate != gmModel.UpdateDate)
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                    List<string> listKeyP = list.Where(m => !string.IsNullOrEmpty(m.txt_TagInfo)).Select(m => m.txt_TagInfo.Substring(0, 10)).Distinct().ToList();
                    listInsert = listKeyP.Select(m => new TPessimisticLock { TagNo = m }).ToList();

                    this.tPessimisticLockService.Insert(listInsert);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    bool pickingCompleteFlag = false;
                    if (!gmModel.CompleteFlag)
                    {
                        //Get model detail
                        IQueryable<TShippingInstructionDetails> detailModel = this.tShippingInstructionDetailService.GetListDetailByShipNo(gmModel.PreMoveNo);

                        //Edit Details data
                        foreach (var item in detailModel)
                        {
                            this.tShippingInstructionDetailService.Delete(item);
                        }

                        //Get insert model detail
                        List<TShippingInstructionDetails> listDetail = new List<TShippingInstructionDetails>();
                        int detailNo = 0;

                        List<string> listTagInfo = list.Where(m => !m.isEmptyRow()).Select(m => m.txt_TagInfo).ToList();
                        var oldList = this.tInventory_DService.GetListByShipNo(gmModel.PreMoveNo);
                        if (gmModel.DeleteFlag)
                        {
                            foreach (var item in oldList)
                            {
                                if (!item.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
                                    && !item.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                {
                                    return CommitFlag.DataChanged;
                                }
                                item.ShippingNo = null;
                                item.ShippingDetailNo = null;
                                item.UpdateDate = curDate;
                                item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                            }
                        }
                        else
                        {
                            IQueryable<TInventory_D> listReMove = oldList.Where(m => !listTagInfo.Contains(m.TagNo + Constant.HYPHEN + m.BranchTagNo.ToString().PadLeft(4, '0')));

                            foreach (var item in listReMove)
                            {
                                if (!item.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
                                    && !item.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE))
                                {
                                    return CommitFlag.DataChanged;
                                }
                                item.ShippingNo = null;
                                item.ShippingDetailNo = null;
                                item.UpdateDate = curDate;
                                item.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                            }
                        }

                        var listData = list.Where(m => !m.isEmptyRow());
                        foreach (var item in listData)
                        {

                            var listTag = item.txt_TagInfo.Split(Constant.HYPHEN_CHAR);
                            TShippingInstructionDetails ret = new TShippingInstructionDetails();
                            ret.ShipNo = gmModel.PreMoveNo;
                            ret.ShipDetailNo = detailNo + 1;
                            ret.TagNo = listTag[0];
                            ret.BranchTagNo = CommonUtil.ParseInteger(listTag[1]);
                            ret.ProductCD = item.txt_ProductCD;
                            ret.InstructQuantity = 1;
                            listDetail.Add(ret);

                            if (!gmModel.DeleteFlag)
                            {
                                TInventory_D modelID = this.tInventory_DService.GetByPK(ret.TagNo, ret.BranchTagNo.Value);
                                modelID.ShippingNo = gmModel.PreMoveNo;
                                modelID.ShippingDetailNo = detailNo + 1;
                                modelID.UpdateDate = curDate;
                                modelID.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                            }
                            detailNo++;
                        }

                        //PickingComplete flag
                        pickingCompleteFlag = !listData.Any(m => m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE) || m.StockStatus.Equals(Constant.STOCK_STATUS_RECEIPT_DEFECTIVE));
                       
                        //Update detail
                        this.tShippingInstructionDetailService.Insert(listDetail);
                    }
                    else
                    {
                        pickingCompleteFlag = true;
                    }
                    //Edit header
                    if (gmModel.CompleteFlag)
                    {
                        headerModel.ShipDate = @CommonUtil.ParseDate(gmModel.txt_MoveDate, Constant.FMT_DATE, Constant.FMT_YMD);
                    }
                    else
                    {
                        headerModel.ShipDate = gmModel.MoveDate.DateValue(); 
                    }
                    if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                    {
                        headerModel.DestinationWarehouseCD = gmModel.txt_WarehouseCDTo;
                    }
                    else if (gmModel.MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
                    {
                        headerModel.DestinationLocationCD = gmModel.txt_LocationCDTo;
                    }
                    headerModel.DeliveryNumber = gmModel.txt_DeliveryNumber;
                    headerModel.Memo = gmModel.Memo;
                    headerModel.PickingCompleteFlag = pickingCompleteFlag; 
                    headerModel.UpdateDate = this.GetCurrentDate();
                    headerModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    headerModel.DeleteFlag = gmModel.DeleteFlag;

                    //Remove lock
                    this.tPessimisticLockService.Delete(listInsert);

                    //Submit 
                    this.tShippingInstructionService.Context.SubmitChanges();
                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK) || sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTIONDETAIL_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;

        }

        /// <summary>
        /// All Move Check
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns>TRUE: valid, FLASE: invalid</returns>
        private bool AllMoveCheck(MoveIndicationAll gmModel)
        {
            bool ret = true;

            string moveDate = gmModel.MoveDate.Year + gmModel.MoveDate.Month + gmModel.MoveDate.Day;
            var listData = this.CreateListMoveAllDetail(gmModel);

            //Check required MoveDate
            if (string.IsNullOrEmpty(moveDate))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
                this.ModelState.AddModelError(KEY_MOVEDATE_DAYFROM, message);
                ret = false;
            }
            else
            {
                int shipDateOut = 0;
                string nowDate = DateTime.Now.ToString(Constant.FMT_YMD);
                int nowDateOut = 0;
                int.TryParse(moveDate, out shipDateOut);
                int.TryParse(nowDate, out nowDateOut);

                //Check shipping data > now data
                if (shipDateOut < nowDateOut)
                {
                    string message = this.FormatMessage(Constant.MES_E0005, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0164), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
                    this.ModelState.AddModelError(KEY_MOVEDATE_DAYFROM, message);
                    ret = false;
                }
            }
            //Check required LocationCD From
            if (string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                //Show error message
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                ret = false;
            }
            else
            {
                //Check LocationCD exist in Location Master
                LocationModels modelLocation = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCDFrom);
                if (modelLocation == null || modelLocation.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                    this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                    gmModel.txt_LocationNameFrom = string.Empty;
                    ret = false;
                }
                else
                {
                    gmModel.txt_LocationNameFrom = modelLocation.LocationName;
                    if (modelLocation.IssueProhibitionFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0075, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                        this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                        ret = false;
                    }
                    else
                    {
                        if (this.tReserveService.ExistLocaShipInRegis(UserSession.Session.WarehouseCD, gmModel.txt_LocationCDFrom)
                            || this.tInventory_DService.IsExistInRegisMove(gmModel.txt_LocationCDFrom))
                        {
                            string message = this.FormatMessage(Constant.MES_M0012, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0244));
                            this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                            ret = false;
                        }

                    }
                }
            }
            if (gmModel.ddl_MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
            {
                //Check required Warehouse To
                if (string.IsNullOrEmpty(gmModel.txt_WarehouseCDTo))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193));
                    this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                    ret = false;
                }
                else
                {
                    //Check WarehouseCD exist in Warehouse Master
                    WarehouseModels modelWarehouse = this.mWarehouseService.GetByCd(gmModel.txt_WarehouseCDTo);
                    if (modelWarehouse == null || modelWarehouse.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193));
                        this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                        gmModel.txt_WarehouseNameTo = string.Empty;
                        ret = false;
                    }
                    else
                    {
                        gmModel.txt_WarehouseNameTo = modelWarehouse.WarehouseName;
                    }

                    //Check WarehouseCDTo is same Warehouse From
                    if (gmModel.txt_WarehouseCDTo.Equals(UserSession.Session.LoginInfo.WarehouseCD))
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0065);
                        this.ModelState.AddModelError(KEY_WAREHOUSECDTO, message);
                        ret = false;
                    }
                }

            }
            else if (gmModel.ddl_MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
            {
                

                //Check required LocationCD To
                if (string.IsNullOrEmpty(gmModel.txt_LocationCDTo))
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0245));
                    this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                    ret = false;
                }
                else
                {
                    //Check LocationCD exist in Location Master
                    LocationModels modelLocation = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCDTo);
                    if (modelLocation == null || modelLocation.DeleteFlag)
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0245));
                        this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                        gmModel.txt_LocationNameTo = string.Empty;
                        ret = false;
                    }
                    else
                    {
                        gmModel.txt_LocationNameTo = modelLocation.LocationName;
                        if (modelLocation.ReceiptProhibitionFlag)
                        {
                            string message = this.FormatMessage(Constant.MES_M0017, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0245));
                            this.ModelState.AddModelError(KEY_LOCATIONCDTO, message);
                            ret = false;
                        }
                    }
                }

                //Check Location From and Location To is same
                if (!string.IsNullOrEmpty(gmModel.txt_LocationCDFrom) && !string.IsNullOrEmpty(gmModel.txt_LocationCDTo))
                {
                    if (gmModel.txt_LocationCDFrom.Equals(gmModel.txt_LocationCDTo))
                    {
                        //Show error message
                        string message = this.FormatMessage(Constant.MES_M0065);
                        this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                        ret = false;
                    }
                }
            }
            if (ret)
            {
                if (listData == default(IQueryable<MoveIndicationAllResults>) || listData.Count() == 0)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_E0009);
                    this.ModelState.AddModelError(KEY_LOCATIONCDFROM, message);
                    ret = false;
                }
                else
                { 
                    if (listData.Count() > this.MaxQty)
                    {
                        //Show error message
                        this.ModelState.AddModelError(KEY_LOCATIONCDFROM, this.FormatMessage(Constant.MES_M0022, this.MaxQty.ToString(Constant.FMT_INTEGER)));
                        ret = false;
                    }
                }


            }
            return ret;
        }

        /// <summary>
        /// Insert Data All Move
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        private CommitFlag AllMoveInsertData(MoveIndicationAll gmModel)
        {
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    string curDate = this.GetCurrentDate();
                    var listData = this.CreateListMoveAllDetail(gmModel);
                    
                    if (listData == default(IQueryable<MoveIndicationAllResults>) || listData.Count() == 0)
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Add lock
                    List<TPessimisticLock> listInsert = new List<TPessimisticLock>();
                    List<string> listKeyP = listData.Select(m => m.TagInfo.Substring(0, 10)).Distinct().ToList();
                    listInsert = listKeyP.Select(m => new TPessimisticLock { TagNo = m }).ToList();

                    this.tPessimisticLockService.Insert(listInsert);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //TSequences
                    string newMaxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_SHIPNO, curDate.Substring(2, 4));

                    //Get insert model header
                    TShippingInstruction headerModel = new TShippingInstruction();
                    headerModel.ShipNo = newMaxTagNo;
                    headerModel.InstructDate = curDate.Substring(0, 8);
                    headerModel.ShipDate = gmModel.MoveDate.DateValue();
                    headerModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
                    if (gmModel.ddl_MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE))
                    {
                        headerModel.DestinationWarehouseCD = gmModel.txt_WarehouseCDTo;
                    }
                    else if (gmModel.ddl_MoveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_LOCATION))
                    {
                        headerModel.DestinationLocationCD = gmModel.txt_LocationCDTo;
                    }
                    headerModel.DeliveryNumber = gmModel.txt_DeliveryNumber;
                    headerModel.Memo = gmModel.Memo;
                    headerModel.ShippingPrintFlag = false;
                    headerModel.PickingCompleteFlag = false;
                    headerModel.ShippingCompleteFlag = false;
                    headerModel.DeleteFlag = false;
                    headerModel.CreateDate = curDate;
                    headerModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    headerModel.UpdateDate = headerModel.CreateDate;
                    headerModel.UpdateUCD = headerModel.CreateUCD;

                    //Get insert model detail
                    List<TShippingInstructionDetails> listDetail = new List<TShippingInstructionDetails>();
                    int i = 0;
                    foreach (var item in listData)
                    {
                        var listTag = item.TagInfo.Split(Constant.HYPHEN_CHAR);

                        TShippingInstructionDetails ret = new TShippingInstructionDetails();
                        ret.ShipNo = newMaxTagNo;
                        ret.ShipDetailNo = i + 1;
                        ret.TagNo = listTag[0];
                        ret.BranchTagNo = CommonUtil.ParseInteger(listTag[1]);
                        ret.ProductCD = null;
                        ret.InstructQuantity = null;

                        listDetail.Add(ret);

                        TInventory_D modelID = this.tInventory_DService.GetByPK(ret.TagNo, ret.BranchTagNo.Value);
                        modelID.ShippingNo = newMaxTagNo;
                        modelID.ShippingDetailNo = i + 1;
                        modelID.UpdateDate = curDate;
                        modelID.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                        i += 1;
                    }

                    //Insert header
                    this.tShippingInstructionService.Insert(headerModel);
                    //Insert detail
                    this.tShippingInstructionDetailService.Insert(listDetail);
                    
                    //Remove lock
                    this.tPessimisticLockService.Delete(listInsert);

                    //Submit only header context
                    this.tShippingInstructionService.Context.SubmitChanges();

                    trans.Complete();

                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_MKind_H_PK) || sqlEx.Message.Contains(Constant.DB_MKind_D_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return CommitFlag.Success;
        }

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private List<string> CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {

            List<string> ret = new List<string>();
            if (screenTagNo.Length != Constant.TINVENTORY_TAGNO_INFO_MAX)
            {
                ret.Add(this.FormatMessage(Constant.MES_E0024, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106), Constant.TINVENTORY_TAGNO_INFO_MAX));
            }
            Match match = Regex.Match(screenTagNo, Constant.PATTERN_NUMERIC_SUBTRACT, RegexOptions.Compiled);
            if (!match.Success)
            {
                ret.Add(this.FormatMessage(Constant.MES_E0023, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106)));
            }
            if (ret.Count() > 0)
            {
                return ret;
            }

            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                 ret.Add(this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106)));
                 return ret;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                ret.Add(this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106)));
                return ret;
            }

            tagNo = array[0];
            return ret;
        }

        #endregion

        #region Public Method

        /// <summary>
        /// Show Tag Information
        /// </summary>
        /// <param name="TagInfo">TagInfo</param>
        /// <returns>Tag Information</returns>
        [HttpPost]
        public JsonResult ShowTagInfo(string TagInfo)
        {
            if (string.IsNullOrEmpty(TagInfo) || TagInfo.Length != 15)
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }
            string[] list = TagInfo.Split(Constant.HYPHEN_CHAR);
            if (list.Count() != 2)
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            MoveIndicationDetailGrid model = this.tInventory_HService.GetMoveIndiDetailGridByTagInfo(TagInfo);
            if (model != default(MoveIndicationDetailGrid))
            {
                List<string> ret = new List<string>();
                ret.Add(model.txt_LocationCD);
                ret.Add(model.txt_ProductCD);
                ret.Add(model.txt_ProductName);
                ret.Add(model.txt_ArrivalDate);
                ret.Add(model.txt_Lot1);
                ret.Add(model.txt_LOT2);
                ret.Add(model.txt_LOT2);
                ret.Add(model.StockStatus);
                ret.Add(model.txt_StockStatusDisp);
                return Json(ret, JsonRequestBehavior.AllowGet);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show WarehouseName
        /// </summary>
        /// <param name="WarehouseCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowWarehouseName(string WarehouseCD)
        {
            if (string.IsNullOrEmpty(WarehouseCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            WarehouseModels model = this.mWarehouseService.GetByCd(WarehouseCD);

            if (model != default(WarehouseModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.WarehouseName
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
        
        /// <summary>
        /// Show LocationName
        /// </summary>
        /// <param name="LocationCD"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowLocationName(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD.ToUpper());

            if (model != default(LocationModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.LocationName
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Print

        /// <summary>
        /// Change Print All
        /// </summary>
        /// <param name="CheckedFlag"></param>
        /// <param name="seqNum"></param>
        [HttpPost]
        public void CheckPrintItemALL(bool CheckedFlag, int seqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];

            //Clear list location
            ListItems.Clear();

            //Add Location
            if (CheckedFlag)
            {
                IQueryable<MoveIndicationResults> results = (IQueryable<MoveIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];

                foreach (var row in results.Where(m => !m.DeleteData))
                {
                    ListItems.Add(row.MoveNo, true);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = ListItems;
        }

        /// <summary>
        /// Change Print Item
        /// </summary>
        /// <param name="moveNo">Move No</param>
        /// <param name="CheckedFlag"></param>
        /// <param name="seqNum"></param>
        /// <returns></returns>
        [HttpPost]
        public bool CheckPrintItemAt(string moveNo, bool CheckedFlag, int seqNum)
        {
            var ListItems = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];
            IQueryable<MoveIndicationResults> results = (IQueryable<MoveIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];

            //Add Location
            if (CheckedFlag)
            {
                if (!ListItems.ContainsKey(moveNo) && results.Where(m => m.MoveNo.Equals(moveNo) && !m.DeleteData).SingleOrDefault() != null)
                {
                    ListItems.Add(moveNo, true);
                }
            }
            else
            {
                //Remove Location
                if (ListItems.ContainsKey(moveNo))
                {
                    ListItems.Remove(moveNo);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = ListItems;
            var checkAll = (ListItems.Count == results.Count(m => !m.DeleteData));
            return checkAll;
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Print(MoveIndicationList gmModel)
        {
            this.ClearModelState();

            //Get model
            var oldModel = (MoveIndicationList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
            this.SetDropDownlist(gmModel.ddl_MoveKind, true);
            if (oldModel != null)
            {
                #region PageInfo

                var results = (IQueryable<MoveIndicationResults>)this.Session[Constant.SESSION_LIST_RESULT + oldModel. SeqNum.ToString()];

                //Restore Pagin Sorting
                this.RestorePagingSorting(oldModel.SeqNum, results);

                #endregion

                #region out report

                var hashtable = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + oldModel.SeqNum.ToString()];

                //Filter selected row
                List<string> SelectedRows = hashtable.Keys.OfType<string>().ToList();

                //Filter data
                List<MoveIndicationResults> ReportData = results
                                        .Where(m => SelectedRows.Contains(m.MoveNo))
                                        .OrderBy(m => m.MoveNo).ToList();

                var RowLength = ReportData.Count();
                if (RowLength > 0)
                {
                    this.ShowMessageForPrint(oldModel.SeqNum, "Index");
                }
                else
                {
                    this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                }

                #endregion
            }
            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Print
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult PrintDetail(int SeqNum)
        {
            //Get data
            MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            TShippingInstruction shipH = this.tShippingInstructionService.GetByPk(gmModel.PreMoveNo);
            if (shipH == default(TShippingInstruction) || shipH.DeleteFlag)
            {
                return this.ExclusionProcess(SeqNum);
            }

            Hashtable htb = new Hashtable();
            htb.Add(shipH.ShipNo, true);
            this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()] = htb;
            this.ShowMessageForPrint(SeqNum, "Detail");

            this.ClearModelState();
            return this.Show(shipH.ShipNo, SeqNum);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value1, string value3)
        {
            //Clear ModeState
            this.ClearModelState();

            #region download

            var SelectedRows = ((Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + value3]).Keys.OfType<string>().OrderBy(m => m).ToList();

            //Report dataset
            Report.DataObject.MoveIndicationDataSet DataSet = new Report.DataObject.MoveIndicationDataSet();

            //Report
            LocalReport mainLocalReport = new LocalReport();
            LocalReport subLocalReport = new LocalReport();

            //Report Source
            dtMain = DataSet._MoveIndicationDataSet.Clone();

            //Get data for Header
            IQueryable<Print_MoveIndication_Header> listHeader = this.tShippingInstructionService.GetDataItemPrintHeaderForMoveIndication(SelectedRows);

            foreach (Print_MoveIndication_Header header in listHeader)
            {
                DataRow dtMainRow = dtMain.NewRow();
                InitDataForRowMain(ref dtMainRow, header);
                dtMain.Rows.Add(dtMainRow);

            }

            //Report path
            mainLocalReport.ReportPath = Server.MapPath(PDF_PATH_MAIN_LOCALREPORT);
            subLocalReport.ReportPath = Server.MapPath(PDF_PATH_SUB_LOCALREPORT);

            //Report source
            ReportDataSource ShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_MAIN, dtMain);

            // Add a handler for SubreportProcessing.
            mainLocalReport.SubreportProcessing +=
                        new SubreportProcessingEventHandler(SubreportProcessingEventHandler);

            mainLocalReport.DataSources.Add(ShippingInstructionTable);

            //Set parameter
            mainLocalReport.SetParameters(this.InitParamsForMainReport());


            //Set Printed Flag      
            CommitFlag UpdateResult = CommitFlag.Success;

            UpdateResult = UpdateShippingPrintFlag(SelectedRows);

            //Output file for download
            if (UpdateResult == CommitFlag.Success)
            {
                //out put pdf
                FileContentResult file = this.PDFOutPut(mainLocalReport,string.Format(PDF_FILENAME,DateTime.Now.ToString(Constant.FMT_DMY)), Common.ReportType.Business, false);
                TempData[TMP_DOWNLOAD_FILE] = file;
            }

            if (value1.Equals("Index"))
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = int.Parse(value3);
                return RedirectToAction("Index");
            }
            else
            {
                //Get data
                MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value3];
                return Show(gmModel.PreMoveNo, gmModel.SeqNum);
            }
            

            #endregion
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_MoveIndication_Header</param>
        private void InitDataForRowMain(ref System.Data.DataRow Row, Print_MoveIndication_Header header)
        {
            string locationTo = string.Empty;
            Row[FieldsMain.ShipNo.ToString()] = header.ShipNo;

            string barCode = header.ShipNo;
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row[FieldsMain.Barcode.ToString()] = Stream.ToArray();
            Row[FieldsMain.ShipDate.ToString()] = string.IsNullOrEmpty(header.ShipDate) ? string.Empty : CommonUtil.ParseDate(header.ShipDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.InstructDate.ToString()] = string.IsNullOrEmpty(header.InstructDate) ? string.Empty : CommonUtil.ParseDate(header.InstructDate, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsMain.ShippingCompleteFlag.ToString()] = header.ShippingCompleteFlag;
            Row[FieldsMain.DeliveryNumber.ToString()] = header.DeliveryNumber;
            if (!string.IsNullOrEmpty(header.DestinationWarehouseCD))
            {
                Row[FieldsMain.DestinationWarehouseCD.ToString()] = header.DestinationWarehouseCD;
                Row[FieldsMain.DestinationWarehouseName.ToString()] = header.DestinationWarehouseCDNm;
                Row[FieldsMain.DestinationLocationCD.ToString()] = "";
                Row[FieldsMain.DestinationLocationName.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseCDLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0193);
                Row[FieldsMain.DestinationWarehouseNameLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0194);
                Row[FieldsMain.DestinationLocationCDLabel.ToString()] = "";
                Row[FieldsMain.DestinationLocationNameLabel.ToString()] = "";
            }
            else if (!string.IsNullOrEmpty(header.DestinationLocationCD))
            {
                Row[FieldsMain.DestinationWarehouseCD.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseName.ToString()] = "";
                Row[FieldsMain.DestinationLocationCD.ToString()] = header.DestinationLocationCD;
                Row[FieldsMain.DestinationLocationName.ToString()] = header.DestinationLocationCDNm;
                Row[FieldsMain.DestinationWarehouseCDLabel.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseNameLabel.ToString()] = "";
                Row[FieldsMain.DestinationLocationCDLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0191);
                Row[FieldsMain.DestinationLocationNameLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0192);
                locationTo = header.DestinationLocationCD;
            }
            else
            {
                Row[FieldsMain.DestinationWarehouseCD.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseName.ToString()] = "";
                Row[FieldsMain.DestinationLocationCD.ToString()] = "";
                Row[FieldsMain.DestinationLocationName.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseCDLabel.ToString()] = "";
                Row[FieldsMain.DestinationWarehouseNameLabel.ToString()] = "";
                Row[FieldsMain.DestinationLocationCDLabel.ToString()] = "";
                Row[FieldsMain.DestinationLocationNameLabel.ToString()] = "";
            }
            
            IQueryable<Print_MoveIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetailForMoveIndication(header.ShipNo, header.ShippingCompleteFlag, locationTo);
            Row[FieldsMain.TotalPage.ToString()] = this.GetTotalPage(listDetail.Count()).ToString();
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRAM
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">Print_MoveIndication_Detail</param>
        /// <param name="RowIndex">RowIndex</param>
        private void InitDataForRowDetail(ref System.Data.DataRow Row, Print_MoveIndication_Detail Data, int RowIndex, int RowCount)
        {
            Row[FieldsDetail.ShipNo.ToString()] = Data.ShipNo;
            Row[FieldsDetail.OrderNo.ToString()] = RowIndex;
            Row[FieldsDetail.LocationCD.ToString()] = Data.LocationCD;
            Row[FieldsDetail.TagNo.ToString()] = Data.TagNo;
            Row[FieldsDetail.ProductCD.ToString()] = Data.ProductCD;
            Row[FieldsDetail.ProductName.ToString()] = Data.ProductName;
            Row[FieldsDetail.Lot1.ToString()] = Data.Lot1;
            Row[FieldsDetail.Lot2.ToString()] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Lot3.ToString()] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row[FieldsDetail.Quantity.ToString()] = Data.Quantity;
            Row[FieldsDetail.TotalLabel.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0175);
            Row[FieldsDetail.RowCount.ToString()] = RowCount;
            Row[FieldsDetail.IsDelied.ToString()] = Data.IsDelied;
        }

        /// <summary>
        /// Create Detail Data
        /// </summary>
        /// <param name="shipNo">shipNo</param>
        /// <param name="ShippingCompleteFlg">ShippingCompleteFlg</param>
        /// <returns>DataTable</returns>
        private DataTable CreateDetailData(string moveNo, bool ShippingCompleteFlg, string locationTo)
        {
            //Set data for detail table
            dtDetail = new DataTable();
            Report.DataObject.SubMoveIndicationDataSet SubDataSet = new Report.DataObject.SubMoveIndicationDataSet();
            dtDetail = SubDataSet._SubMoveIndicationDataSet.Clone();
            List<Print_MoveIndication_Detail> listDetail = this.tShippingInstructionService.GetDataListPrintDetailForMoveIndication(moveNo, ShippingCompleteFlg, locationTo).ToList();
            int count = listDetail.Count();
            for (int j = 0; j < count; j++)
            {
                var dtRow = dtDetail.NewRow();
                InitDataForRowDetail(ref dtRow, listDetail[j], j + 1, count);
                dtDetail.Rows.Add(dtRow);

            }
            return dtDetail;
        }

        /// <summary>
        /// Get Total Page
        /// </summary>
        /// <param name="rowNum">Detail row number</param>
        /// <returns>int</returns>
        private int GetTotalPage(int rowNum)
        {
            int pageTotal = 0;

            if (rowNum > 0)
            {
                //if detail table's number row <=15
                if (rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE <= 1)
                {
                    //if detail table's number row =15
                    if (rowNum % PDF_NUMBER_ROW_PER_FIRST_PAGE == 0)
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE;
                    }
                    else//if detail table's number row <15
                    {
                        pageTotal = rowNum / PDF_NUMBER_ROW_PER_FIRST_PAGE + 1;
                    }
                }
                else//if detail table's number row >15
                {
                    //Init pageTotal for first page
                    pageTotal = 1;

                    //Set pageTotal for after pages
                    if ((rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) % PDF_NUMBER_ROW_PER_NEXT_PAGE == 0)
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE;
                    }
                    else
                    {
                        pageTotal = pageTotal + (rowNum - PDF_NUMBER_ROW_PER_FIRST_PAGE) / PDF_NUMBER_ROW_PER_NEXT_PAGE + 1;
                    }
                }
            }
            return pageTotal;
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRAM
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForMainReport()
        {
            //Set Parameters	
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany)? mCompany.CompanyName1 : string.Empty;
            string space = "";
            ReportParameter titleWare = new ReportParameter("titleWarehouse", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0293));
            ReportParameter titleLo = new ReportParameter("titleLocation", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0294));
            ReportParameter titleSr = new ReportParameter("titleScrap", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0295));
            ReportParameter companyName = new ReportParameter("companyName", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            ReportParameter shipNo = new ReportParameter("shipNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
            ReportParameter shipDate = new ReportParameter("shipDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0196));
            ReportParameter instructDate = new ReportParameter("instructDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0173));
            ReportParameter page = new ReportParameter("pageLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0172));
            ReportParameter orderNo = new ReportParameter("orderNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0151));
            ReportParameter locationLabel = new ReportParameter("locationLabel",  UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
            ReportParameter tagNo = new ReportParameter("tagNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter productCD = new ReportParameter("productCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("productNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter lot1 = new ReportParameter("lot1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter lot2 = new ReportParameter("lot2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("lot3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter quantity = new ReportParameter("quantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0174));
            ReportParameter deliveryNumber = new ReportParameter("deliveryNumberLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0301));
            return new ReportParameterCollection { titleWare, titleLo, titleSr, companyName, shipNo, shipDate, instructDate, page, locationLabel, orderNo, tagNo, productCD, productName, lot1, lot2, lot3, quantity, deliveryNumber };
        }

        /// <summary>
        ///  Show Message For Print
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        private void ShowMessageForPrint(int SeqNum, string from)
        {
            //Show confirm message
            this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
            value1:from, value3: SeqNum.ToString());
        }

        #region Handle

        /// <summary>
        /// Subreport Processing Event Handler
        /// Author: ISV-HUNG
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SubreportProcessingEventHandler(object sender, SubreportProcessingEventArgs e)
        {
            LocalReport localReport = (LocalReport)sender;
            ReportDataSourceCollection data = localReport.DataSources;
            DataTable dt = (DataTable)data[0].Value;
            int i = count;
            count++;
            dtDetail = this.CreateDetailData(dt.Rows[i][FieldsMain.ShipNo.ToString()].ToString(), (bool)dt.Rows[0][FieldsMain.ShippingCompleteFlag.ToString()], dt.Rows[i][FieldsMain.DestinationLocationCD.ToString()].ToString());
            ReportDataSource SubShippingInstructionTable = new ReportDataSource(PDF_REPORTDATASOURCE_DETAIL, dtDetail);
            e.DataSources.Add(SubShippingInstructionTable);
        }

        #endregion

        #endregion

        #region "Registration"

        /// <summary>
        /// Update ShippingPrintFlag After Printed
        /// Author : ISV-HUNG
        /// </summary>
        /// <param name="gmListShipNo">List Of ShipNo</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdateShippingPrintFlag(List<string> gmListShipNo)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();
                Hashtable updated = new Hashtable();

                //update ShippingPrintFlag for Detail
                IQueryable<TShippingInstruction> listShipping = this.tShippingInstructionService.GetListByShipNos(gmListShipNo);

                foreach (TShippingInstruction entity in listShipping.ToList())
                {
                    entity.ShippingPrintFlag = true;
                    entity.UpdateDate = updateDate;
                    entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }

                this.tShippingInstructionService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = string.Empty;

                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0011);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }
            return ret;
        }

        #endregion

        #region Remove/Add rows

        /// <summary>
        /// Change Delete All
        /// </summary>
        /// <param name="CheckedFlag">CheckedFlag</param>
        /// <param name="seqNum">Sequence Number</param>
        [HttpPost]
        public void ChangeDeleteAll(bool CheckedFlag, int seqNum)
        {
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + seqNum.ToString()]).ToList();
            foreach (var item in list)
            {
                if (CheckedFlag && !item.IsPicked)
                {
                    item.Delete = true;
                }
                else
                {
                    item.Delete = false;
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + seqNum.ToString()] = list;
        }

        /// <summary>
        /// Change Delete Item
        /// </summary>
        /// <param name="TagInfo">Num Row</param>
        /// <param name="CheckedFlag">CheckedFlag</param>
        /// <param name="seqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public bool ChangeDeleteItem(int NumRow, bool CheckedFlag, int seqNum)
        {
            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + seqNum.ToString()]).ToList();

            list[NumRow - 1].Delete = CheckedFlag;

            //Store in sesstion
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + seqNum.ToString()] = list;
            var checkAll = list.Where(m=>!m.IsPicked).All(m=>m.Delete);
            return checkAll;
        }

        /// <summary>
        /// Set Num Row
        /// </summary>
        private void SetNumRow(List<MoveIndicationDetailGrid> list)
        {
            for (int i = 0; i < list.Count(); i++)
            {
                list[i].NumRow = i + 1;
            }
        }

        /// <summary>
        /// Remove row comfirm
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult RemoveRowConfirm(MoveIndicationMain gmModel)
        {
            //Clear model state
            this.ClearModelState();

            this.SetDropDownlist(gmModel.ddl_MoveKind);
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            int space = (gmModel.PageInfo.CurrentPage - 1) * gmModel.PageInfo.ItemsPerPage;

            UpdateList(ref list, gmModel.Detail, space);

            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = list;
            int rowDel = list.Count(m => m.Delete);
            if (rowDel == 0)
            {

                for (int i = 0; i < gmModel.Detail.Count(); i++)
                {
                    if (!gmModel.Detail[i].IsPicked)
                    {
                        this.ModelState.AddModelError("Detail_" + i + "__Delete", InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                        break;
                    }
                }
                return View("Details", gmModel);
            }

            if (rowDel == list.Count(m => !m.IsPicked))
            {
                gmModel.CheckDeleteAll = true;
            }
            else
            {
                gmModel.CheckDeleteAll = false;
            }
            //Show message confirm
            this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/RemoveRowAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0036), value1: gmModel.SeqNum.ToString());

            return View("Details", gmModel);
        }

        /// <summary>
        /// Delete a row
        /// </summary>
        /// <param name="value1">Sequen Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult RemoveRowAction(string value1)
        {
            MoveIndicationMain gmModel = (MoveIndicationMain)this.Session[Constant.SESSION_DETAIL_MODEL + value1];
            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = new List<string>();
            
            this.SetDropDownlist(gmModel.ddl_MoveKind);
            gmModel.CheckDeleteAll = false;

            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            var listNotDel = list.Where(m => !m.Delete).ToList();
            if (listNotDel.Count() == 0)
            {
                List<MoveIndicationDetailGrid> listNew = new List<MoveIndicationDetailGrid>();
                this.AddEmtyRows(ref listNew, this.rowNumDetail, gmModel.SeqNum);

                gmModel.Detail = listNew;

                this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;
                this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = listNew;
                //Set focus
                this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_TagInfo", (0))));
                gmModel.MaxQty = this.MaxQty;
                gmModel.CurQty = list.Count();

                return View("Details", gmModel);
            }
            else
            {
                this.SetNumRow(listNotDel);
                if (listNotDel.Count() < this.rowNumDetail)
                {
                    int rowsAddNum = rowNumDetail - listNotDel.Count();
                    this.AddEmtyRows(ref listNotDel, rowsAddNum, gmModel.SeqNum);
                    gmModel.Detail = listNotDel;
                }
                else
                {
                    //Set default sort
                    ViewBag.SortingInfo = new SortingInfo();

                    //Create paging info
                    PagingInfo pageInfo = new PagingInfo
                    {
                        CurrentPage = 1,
                        ItemsPerPage = this.MaxPageSizeDetail,
                        TotalItems = listNotDel.Count(),

                    };
                    gmModel.PageInfo = pageInfo;
                    gmModel.Detail = listNotDel.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();
                }
 
            }

            for (int j = 0; j < gmModel.Detail.Count(); j++)
            {
                if (!gmModel.Detail[j].IsPicked)
                {
                    //Set focus
                    this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_TagInfo", (j))));
                    break;
                }
            }

            //Add store
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = listNotDel;
            gmModel.MaxQty = this.MaxQty;
            gmModel.CurQty = listNotDel.Count();

            return View("Details", gmModel);
        }

        /// <summary>
        /// Add rows
        /// </summary>
        /// <param name="gmModel">MoveIndicationMain</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Add(MoveIndicationMain gmModel)
        {
            //Clear ModelState
            this.ClearModelState();

            this.Session[Constant.SESSION_GRID_ERROR_KEYS + gmModel.SeqNum.ToString()] = new List<string>();

            List<MoveIndicationDetailGrid> list = ((List<MoveIndicationDetailGrid>)this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()]).ToList();
            int space = (gmModel.PageInfo.CurrentPage - 1) * gmModel.PageInfo.ItemsPerPage;
            UpdateList(ref list, gmModel.Detail, space);

            if (list.Count() >= 1000)
            {
                return View("Details", gmModel);
            }

            //Add an empty row 
            this.AddEmtyRows(ref list, 1, gmModel.SeqNum);

            //Store result into session
            this.Session[Constant.SESSION_LIST_SEARCH_RESULT + gmModel.SeqNum.ToString()] = list;

            //Set default sort
            ViewBag.SortingInfo = new SortingInfo();

            //Create paging info
            PagingInfo pageInfo = new PagingInfo
            {
                CurrentPage = (int)Math.Ceiling((double)list.Count() / this.MaxPageSizeDetail),
                ItemsPerPage = this.MaxPageSizeDetail,
                TotalItems = list.Count(),

            };

            gmModel.PageInfo = pageInfo;

            gmModel.Detail = list.Skip((pageInfo.CurrentPage - 1) * pageInfo.ItemsPerPage).Take(pageInfo.ItemsPerPage).ToList();

            this.SetDropDownlist(gmModel.ddl_MoveKind);

            gmModel.CheckDeleteAll = false;
            gmModel.MaxQty = this.MaxQty;
            gmModel.CurQty = list.Count();

            //Store session
            this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

            //set focus
            this.SetFocusId(ViewData.TemplateInfo.GetFullHtmlFieldId(String.Format("Detail[{0}].txt_TagInfo", gmModel.Detail.Count - 1)));

            return View("Details", gmModel);
        }

        #endregion

        #region All Move

        #region Method

        /// <summary>
        /// Create List Result for Move all
        /// </summary>
        /// <param name="gmModel">MoveIndicationAll</param>
        /// <returns>List of MoveIndicationAllResults</returns>
        private IQueryable<MoveIndicationAllResults> CreateListMoveAllDetail(MoveIndicationAll gmModel)
        {
            if (string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                return null;
            }

            //Search data
            List<MoveIndicationAllResults> ret = this.tInventory_HService.GetListForMoveAll(gmModel).ToList();

            this.Session[SES_DETAIL_MOVEALL_LIST + gmModel.SeqNum.ToString() + gmModel.SeqNum.ToString()] = ret.AsQueryable();

            //Sort Defaul
            this.MoveAllDefaultSort(ret.AsQueryable(), gmModel.SeqNum);

            return ret.AsQueryable();

        }

        /// <summary>
        /// Set Sort Default MoveAll Result List
        /// </summary>
        /// <param name="list">IQueryable of MoveIndicationAllResults</param>
        /// <param name="seqNum">Sequence Number</param>
        private void MoveAllDefaultSort(IQueryable<MoveIndicationAllResults> list, int seqNum)
        {

            //Create sorting info
            SortingInfo sortInfo = new SortingInfo
            {
                Url = SORT_MOVEALL_URL,
                SortField = SORT_MOVEALL_DEFAULT,
                Direction = SortDirection.Ascending,
            };

            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<MoveIndicationAllResults>(ref list, pageRequest, sortInfo, seqNum, pageSize: this.pageSize, SesionPagingKey: SES_DETAIL_PAGING_MOVEALL, SesionSortingKey: SES_DETAIL_SORT_MOVEALL);
 
        }

        #endregion

        /// <summary>
        /// All Move
        /// </summary>
        /// <param name="gModel">MoveIndicationAll</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult AllMove(MoveIndicationAll gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_MOVE_INDICATION))
            {
                return this.RedirectNotAuthority();
            }

            if (string.IsNullOrEmpty(gmModel.ddl_MoveKind))
            {
                this.ClearModelStateByKey(KEY_DDL_MOVEKIND);
                gmModel.ddl_MoveKind = Constant.MKIND_KINDCD_MOVE_KIND_LOCATION;
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + gmModel.SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0256);

            gmModel.MoveDate = new DateControl(DateTime.Now.ToString(Constant.FMT_YMD));

            //Set data DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            if (!string.IsNullOrEmpty(gmModel.txt_LocationCDFrom))
            {
                this.CreateListMoveAllDetail(gmModel);
            }

            //Store result into session
            this.Session[Constant.SESSION_LIST_DETAIL_RESULT + gmModel.SeqNum.ToString()] = gmModel;

            //Set focus
            this.SetFocusId(KEY_MOVEDATE_DAYFROMID);

            return View("MoveAllDetail", gmModel);
        }

        /// <summary>
        /// All Move Paging
        /// </summary>
        /// <param name="selectedPage"></param>
        /// <param name="pageRequest"></param>
        /// <param name="sortInfo"></param>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        public ActionResult AllMovePaging(PagingRequest pageRequest, SortingInfo sortInfo, MoveIndicationAll gmModel)
        {
            //Get search result from session
            IQueryable<MoveIndicationAllResults> list = ((IQueryable<MoveIndicationAllResults>)this.Session[SES_DETAIL_MOVEALL_LIST + gmModel.SeqNum.ToString() + gmModel.SeqNum.ToString()]);

            //Paging
            this.PagingBase<MoveIndicationAllResults>(ref list, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize, SesionPagingKey: SES_DETAIL_PAGING_MOVEALL, SesionSortingKey: SES_DETAIL_SORT_MOVEALL);

            return PartialView("_ListMoveAllDetail", gmModel);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult AllMoveSorting(SortingInfo sortInfo, int SeqNum)
        {
            var gmModel = new MoveIndicationAll();

            //Get search result from session
            IQueryable<MoveIndicationAllResults> list = (IQueryable<MoveIndicationAllResults>)this.Session[SES_DETAIL_MOVEALL_LIST + SeqNum.ToString() + SeqNum.ToString()];

            //Sorting
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.SortingBase<MoveIndicationAllResults>(list, sortInfo, SeqNum, pageSize: this.pageSize, SesionPagingKey: SES_DETAIL_PAGING_MOVEALL, SesionSortingKey: SES_DETAIL_SORT_MOVEALL);

            return PartialView("_ListMoveAllDetail", gmModel);
        }

        /// <summary>
        /// All Move Confirm
        /// </summary>
        /// <param name="gmModel"></param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult AllMoveConfirm(MoveIndicationAll gmModel)
        {
            //Sort error
            this.SortModelState(typeof(MoveIndicationAll));

            //Set data DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            if (this.ModelState.IsValid)
            {
                //All move check
                if (this.AllMoveCheck(gmModel))
                {

                    this.Session[Constant.SESSION_LIST_DETAIL_RESULT + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/MoveIndication/AllMoveAction", message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0008), value1: gmModel.SeqNum.ToString());
                }
            }
            else
            {
                this.CreateListMoveAllDetail(gmModel);
            }
            return View("MoveAllDetail", gmModel);
        }

        /// <summary>
        /// All Move Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        public ActionResult AllMoveAction(string value1)
        {
            //Get data from session
            MoveIndicationAll gmModel = ((MoveIndicationAll)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + value1.ToString()]);

            //Set data for DropDownList
            this.SetDropDownlist(gmModel.ddl_MoveKind);

            //All Move check
            if (!this.AllMoveCheck(gmModel))
            {
                return View("MoveAllDetail", gmModel);
            }

            //Insert data
            ActionResult ret = default(ActionResult);
            string message = string.Empty;

            switch (this.AllMoveInsertData(gmModel))
            {
                case CommitFlag.DataChanged:
                case CommitFlag.InsertExclusion:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = AllMoveConfirm(gmModel);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;

                    ret = RedirectToAction("Index");
                    break;
                default:
                    message = this.FormatMessage(Constant.MES_M0009);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = AllMoveConfirm(gmModel);
                    break;
            }
            return ret;
        }

        #endregion
    }
}

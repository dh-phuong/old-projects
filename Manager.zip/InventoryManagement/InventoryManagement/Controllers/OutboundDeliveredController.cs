﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using InventoryManagement.Models;
using InventoryManagement.Validation;
using InventoryManagement.Utility;
using InventoryManagement.Common;
using Microsoft.Reporting.WebForms;
using System.Data;
using InventoryManagement.iQueryable;
using InventoryManagement.Report;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using System.IO;
using NPOI.SS.Util;
using NPOI.HPSF;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Balance In Stores Controller
    /// Author : ISV-LOC
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class OutboundDeliveredController : BaseController
    {
        #region Common


        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MCompanyService mCompanyService;
        private DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="mWarehouseService">mWarehouseService</param>
        /// <param name="mMessageService">mMessageService</param>
        /// <param name="mLocationService">mLocationService</param>
        public OutboundDeliveredController(DataAccess.MKind_DService mKind_DService
                                            , DataAccess.MCustomerService mCustomerService
                                            , DataAccess.MWarehouseService mWarehouseService
                                            , DataAccess.MProductService mProductService
                                            , DataAccess.MCompanyService mCompanyService
                                            , DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService
                                               )
        {
            this.mKind_DService = mKind_DService;
            this.mCustomerService = mCustomerService;
            this.mWarehouseService = mWarehouseService;
            this.mProductService = mProductService;
            this.mCompanyService = mCompanyService;
            this.tOutBoundDeliveredService = tOutBoundDeliveredService;
        }

        #endregion

        #region Constant
        private const string SCREEN_INDEX = "Index";
        private const string PRINT_ACTION_URL = "/OutboundDelivered/PrintAction";
        private const string EXCEL_ACTION_URL = "/OutboundDelivered/ExcelAction";

        private const string DROPDOWN_OUTBOUND_KIND = "ddl_Kind";
        private const string SHIP_DATE_FROM = "shr_ShipDateFrom";

        private const string SAVE_LIST_PRINT = "Save_List_Print";

        private const string PATH_PRODUCT = "~/Report/OutboundDeliveredProduct.rdlc";
        private const string PATH_DESTINATION = "~/Report/OutboundDeliveredDestination.rdlc";

        private const string NAME_DATASET = "OutboundDeliveredDataSet";

        private const string PDF_FILE_PATH_PRODUCT = "OutboundDelivered_P_{0}.pdf";
        private const string PDF_FILE_PATH_DESTINATION = "OutboundDelivered_D_{0}.pdf";
        private const int PDF_NUMBER_ROW_PER_PAGE = 30;

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        //SET STYLE EXCEL
        private const float HEIGHT_ROW = 16f;
        private const float HEIGHT_ROW_TITLE = 18f;

        private const string CSS_TITLE = "css_title";
        private const string CSS_HEADER_GROUP_2 = "css_header_group_2";
        private const string CSS_HEADER_GRID_LEFT = "css_header_grid_left";
        private const string CSS_HEADER_GRID_RIGHT = "css_header_grid_right";
        private const string CSS_ROW_DETAIL_STRING = "css_row_detail_string";
        private const string CSS_ROW_DETAIL_INT = "css_row_detail_int";
        private const string CSS_ROW_DETAIL_DECIMAL = "css_row_detail_decimal";
        private const string CSS_LBL_TOTAL_BODER_TOP = "css_lbl_total_boder_top";
        private const string CSS_LBL_TOTAL_BODER_TOP_BOTTOM = "css_lbl_total_boder_top_bottom";
        private const string CSS_CELL_EMPTY_BORDER_TOP = "css_cell_empty_border_top";
        private const string CSS_CELL_EMPTY_BORDER_TOP_BOTTOM = "css_cell_empty_border_top_bottom";
        private const string CSS_VALUE_TOTAL_INT_BORDER_TOP = "css_value_total_int_border_top";
        private const string CSS_VALUE_TOTAL_INT_BORDER_TOP_BOTTOM = "css_value_total_int_border_top_bottom";
        private const string CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP = "css_value_total_decimal_border_top";
        private const string CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM = "css_value_total_decimal_border_top_bottom";

        #endregion

        #region Index

        /// <summary>
        /// Index
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <returns></returns>
        [iHttpParamAction]
        public ActionResult Index(OutboundDeliveredModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERED_REPORT))
            {
                return this.RedirectNotAuthority();
            }

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];
                //Get model
                OutboundDeliveredModels oldModel = (OutboundDeliveredModels)this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + gmModel.SeqNum.ToString()];
                if (oldModel != default(OutboundDeliveredModels))
                {
                    gmModel = oldModel;
                    isFormBack = true;
                }
            }

            this.ClearModelState();

            this.SetDropDownlistForSearch(gmModel);

            //Create new sequence key
            if (gmModel.SeqNum == default(int) && !isFormBack)
            {
                gmModel = new OutboundDeliveredModels();
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
                this.ClearModelState();
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
                //Clear ModeState
                this.ClearModelState();
            }

            return View(SCREEN_INDEX, gmModel);
        }

        #endregion

        #region Back

        /// <summary>
        /// Back
        /// </summary>
        /// <param name="gmModel">CompanyModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(OutboundDeliveredModels gmModel)
        {
            this.ClearModelState();
            if (!gmModel.IsFromMenu)
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index", "OutboundDeliveredInquiry");
            }
            else
            {
                return RedirectToAction("Report", "Menu");
            }
        }
        #endregion

        #region Print

        /// <summary>
        /// Print
        /// Author : ISV-LOC
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Print(OutboundDeliveredModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERED_REPORT))
            {
                return this.RedirectNotAuthority();
            }
            this.SetDropDownlistForSearch(gmModel);
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Check date range
                var shipDateFromStr = gmModel.shr_ShipDateFrom.DateValue();
                var shipDateToStr = gmModel.shr_ShipDateTo.DateValue();
                if (!string.IsNullOrEmpty(shipDateFromStr) || !string.IsNullOrEmpty(shipDateToStr))
                {
                    var shipDateFrom = DateTime.MinValue;
                    var shipDateTo = DateTime.MinValue;
                    //Check three month
                    if (!string.IsNullOrEmpty(shipDateFromStr))
                    {
                        shipDateFrom = Utility.CommonUtil.ParseDate(shipDateFromStr, Constant.FMT_YMD);
                    }
                    if (!string.IsNullOrEmpty(shipDateToStr))
                    {
                        shipDateTo = Utility.CommonUtil.ParseDate(shipDateToStr, Constant.FMT_YMD);
                    }
                    if (shipDateTo.CompareTo((shipDateFrom.AddMonths(3).AddDays(-1))) > 0)
                    {
                        this.ModelState.AddModelError(SHIP_DATE_FROM, this.FormatMessage(Constant.MES_M0076, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0153), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0154)));
                        this.SortModelState(typeof(OutboundDeliveredModels));
                        return View(SCREEN_INDEX, gmModel);
                    }
                }
                if (!this.CheckExistInput(gmModel))
                {
                    return View(SCREEN_INDEX, gmModel);
                }

                IQueryable<OutboundDeliveredReport> dataSource = this.tOutBoundDeliveredService.GetListOutboundDeliveredForReport(gmModel);
                if (dataSource.Count() == 0)
                {
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                    return View(SCREEN_INDEX, gmModel);
                }

                //Store condition
                this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + gmModel.SeqNum.ToString()] = gmModel;
                this.ShowMessageConfirm(gmModel.SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020), value1: gmModel.SeqNum.ToString());
            }

            this.SortModelState(typeof(OutboundDeliveredModels));
            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-LOC
        /// </summary>
        /// <param name="value1">Type Print From</param>
        /// <param name="value2">Print Size</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value1)
        {
            //Clear ModeState
            this.ClearModelState();

            OutboundDeliveredModels gmModel = (OutboundDeliveredModels)this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + value1];
            this.SetDropDownlistForSearch(gmModel);
            if (!this.CheckExistInput(gmModel))
            {
                return View(SCREEN_INDEX, gmModel);
            }
            //List<StockListModels> ReportSource = new List<StockListModels>();
            string path = string.Empty;
            string tilte = string.Empty;
            string fileName = string.Empty;
            LocalReport localReport = new LocalReport();
            IQueryable<OutboundDeliveredReport> dataSource = this.tOutBoundDeliveredService.GetListOutboundDeliveredForReport(gmModel);
            if (dataSource.Count() == 0)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                return View(SCREEN_INDEX, gmModel);
            }

            List<OutboundDeliveredReport> listReport = new List<OutboundDeliveredReport>();
            if (gmModel.CheckProduct)
            {
                tilte = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0309);
                fileName = string.Format(PDF_FILE_PATH_PRODUCT, DateTime.Now.ToString(Constant.FMT_DMY));

                listReport = dataSource.iOrderBy("ProductCD", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("ShipDate", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("ShipNo", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("DeliveryNumber", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("TagInfo", System.Web.Helpers.SortDirection.Ascending).ToList();
                path = PATH_PRODUCT;

            }
            else
            {
                tilte = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0310);
                fileName = string.Format(PDF_FILE_PATH_DESTINATION, DateTime.Now.ToString(Constant.FMT_DMY));

                listReport = dataSource.iOrderBy("DestinationCD", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("ShipDate", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("ShipNo", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("DeliveryNumber", System.Web.Helpers.SortDirection.Ascending)
                                        .iThenBy("TagInfo", System.Web.Helpers.SortDirection.Ascending).ToList();

                path = PATH_DESTINATION;
            }

            //Set dataSource for Product
            this.setDataSource(localReport, listReport, path, NAME_DATASET);

            //seting the partameters for the report            
            this.SetParas(localReport, gmModel, tilte);

            //out put pdf
            FileContentResult file = this.PDFOutPut(localReport, fileName, Common.ReportType.System, false);
            TempData[TMP_DOWNLOAD_FILE] = file;

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value1);
            return RedirectToAction("Index");
        }

        ///// <summary>
        /////  Print Action
        /////  Author : ISV-LOC
        ///// </summary>
        ///// <param name="value1">Sequence Number</param>
        ///// <returns>ActionResult</returns>
        //[HttpPost]
        //public ActionResult PrintAction(string value1)
        //{
        //    //Clear ModeState
        //    this.ClearModelState();

        //    OutboundDeliveredModels gmModel = (OutboundDeliveredModels)this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + value1];

        //    //Report
        //    LocalReport localReport = new LocalReport();

        //    #region product
        //    if (gmModel.CheckProduct)
        //    {

        //        #region dataset
        //        List<OutboundDeliveredProductHeader> ReportSource = (List<OutboundDeliveredProductHeader>)TempData[SAVE_LIST_PRINT];

        //        var Count = ReportSource.Count;

        //        if (Count > 0)
        //        {
        //            //Report dataset                
        //            Report.DataObject.BalanceInStoresProductDataSet DataSet = new Report.DataObject.BalanceInStoresProductDataSet();

        //            //Report Source
        //            var tblBalance = DataSet.BanlanceStoreProduct.Clone();
        //            tblDetail = DataSet.BanlanceStoreProduct.Clone();

        //            var item = ReportSource[0];
        //            var newRow = tblBalance.NewRow();
        //            //this.InitDataForRowHeader(ref newRow, item, gmModel, isFlagBranch);
        //            this.InitDataForRowHeader(ref newRow, item, gmModel);
        //            tblBalance.Rows.Add(newRow);

        //            //Get data for report source
        //            for (int i = 0; i < Count; i++)
        //            {
        //                if (item.ProductCD != ReportSource[i].ProductCD)
        //                {
        //                    item = ReportSource[i];
        //                    newRow = tblBalance.NewRow();
        //                    //this.InitDataForRowHeader(ref newRow, item, gmModel, isFlagBranch);
        //                    this.InitDataForRowHeader(ref newRow, item, gmModel);

        //                    tblBalance.Rows.Add(newRow);
        //                }
        //            }

        //            //Download file name
        //            var filename = string.Format(PDF_FILE_PATH_PRODUCT, DateTime.Now.ToString(Constant.FMT_DMY));

        //            localReport.ReportPath = Server.MapPath(REPORT_PRODUCT_URL);

        //            //Report source
        //            ReportDataSource dataSource = new ReportDataSource("BalanceInStoreProduct", tblBalance);

        //            // Add a handler for SubreportProcessing.
        //            localReport.SubreportProcessing +=
        //                        new SubreportProcessingEventHandler(SubReportProcessingEventHandler);

        //            localReport.DataSources.Add(dataSource);

        //            //Set parameter
        //            localReport.SetParameters(this.InitParamsForReport(gmModel));

        //            var file = this.PDFOutPut(localReport, filename, Common.ReportType.System, false);
        //            TempData[TMP_DOWNLOAD_FILE] = file;
        //        }
        //        else
        //        {
        //            this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
        //            return View(SCREEN_INDEX, gmModel);
        //        } 
        //        #endregion

        //        #region Model---stop
        //        //List<BalanceInStoresLocation> lstProduct = null;
        //        //if (gmModel.CheckTagNo)
        //        //{
        //        //    lstProduct = this.tBalanceInStoresService.GetListBalanceByProductTagNo(gmModel)
        //        //        .iOrderBy("BalanceDate",System.Web.Helpers.SortDirection.Ascending).iThenBy("BalanceStatus",System.Web.Helpers.SortDirection.Ascending)
        //        //        .iThenBy("TagInfo",System.Web.Helpers.SortDirection.Ascending).ToList<BalanceInStoresLocation>();
        //        //}
        //        //else
        //        //{
        //        //    lstProduct = this.tBalanceInStoresService.GetListBalanceByProductBranchTagNo(gmModel)
        //        //        .iOrderBy("BalanceDate", System.Web.Helpers.SortDirection.Ascending).iThenBy("BalanceStatus", System.Web.Helpers.SortDirection.Ascending)
        //        //        .iThenBy("TagInfo", System.Web.Helpers.SortDirection.Ascending).ToList<BalanceInStoresLocation>();
        //        //}
        //        //var group = lstProduct.GroupBy(m => m.ProductCD).ToList();

        //        //if (lstProduct.Count > 0)
        //        //{
        //        //    var fileNameProduct = string.Format("BalanceInStores_ByProduct_{0}.pdf",DateTime.Now.ToString(Constant.FMT_DMY));
        //        //    localReport.ReportPath = Server.MapPath("~/Report/BalanceInStoresProduct_Test.rdlc");

        //        //    this.SetParameterForReportProduct(localReport);
        //        //    var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
        //        //    var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
        //        //    localReport.SetLabelValue("lblBalanceDateHeader", string.Format("{0} ～ {1}", dateFrom, dateTo));

        //        //    MCompany mCompany = mCompanyService.GetMCompany();
        //        //    MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
        //        //    string companyNm = mCompany.CompanyName1;
        //        //    string space = "";
        //        //    localReport.SetLabelValue("CompanyLabel", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);

        //        //    //Report source
        //        //    ReportDataSource dataSource = new ReportDataSource("BalanceInStoresProduct", lstProduct);

        //        //    localReport.DataSources.Add(dataSource);

        //        //    var file = this.PDFOutPut(localReport, fileNameProduct, Common.ReportType.System, false);
        //        //    TempData[TMP_DOWNLOAD_FILE] = file;
        //        //}
        //        //else
        //        //{
        //        //    this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
        //        //    return View("Index", gmModel);
        //        //}
        //        #endregion
        //    }
        //    #endregion

        //    #region location
        //    else if (gmModel.CheckLocation)
        //    {
        //        //if (gmModel.CheckBranchTagNo)
        //        //{
        //        //    isFlagBranch = true;
        //        //}
        //        //else
        //        //    isFlagBranch = false;

        //        IQueryable<BalanceInStoresLocation> lstLocation = (IQueryable<BalanceInStoresLocation>)TempData[SAVE_LIST_PRINT];

        //         if (lstLocation.ToList().Count > 0)
        //        {
        //            //Download file name
        //            var filename = string.Format(PDF_FILE_PATH_LOCATION, DateTime.Now.ToString(Constant.FMT_DMY));

        //            localReport.ReportPath = Server.MapPath(REPORT_LOCATION_URL);

        //            //Set label
        //            this.SetParameterForReportLocation(localReport);

        //            var dateFrom = CommonUtil.ParseDate(gmModel.BalanceDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
        //            var dateTo = CommonUtil.ParseDate(gmModel.BalanceDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
        //            if (string.IsNullOrEmpty(dateFrom) && string.IsNullOrEmpty(dateTo))
        //            {
        //                localReport.SetLabelValue("lblBalanceDateHeader"," ");
        //            }
        //            else
        //            {
        //                localReport.SetLabelValue("lblBalanceDateHeader", string.Format("{0} ～ {1}", dateFrom, dateTo));
        //            }
        //            MCompany mCompany = mCompanyService.GetMCompany();
        //            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
        //            string companyNm = mCompany.CompanyName1;
        //            string space = "";
        //            localReport.SetLabelValue("CompanyLabel", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);

        //            //Report source
        //            ReportDataSource dataSource = new ReportDataSource("BalanceInStoreLocation", lstLocation);

        //            localReport.DataSources.Add(dataSource);

        //            var file = this.PDFOutPut(localReport, filename, Common.ReportType.System, false);
        //            TempData[TMP_DOWNLOAD_FILE] = file;
        //        }
        //        else
        //        {
        //            this.ModelState.AddModelError(string.Empty, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_E0009));
        //            return View("Index", gmModel);
        //        }
        //    }
        //    #endregion

        //    //Set is form back
        //    this.SetFormBack();
        //    return RedirectToAction("Index", new { SeqNum = gmModel.SeqNum });
        //}

        #region Private Methods For Print

        /// <summary>
        /// Set Parameters
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="tilte">tilte</param>
        private void SetParas(LocalReport localReport, OutboundDeliveredModels gmModel, string tilte)
        {
            // set para header report
            localReport.SetLabelValue("ReportTitle", tilte);
            //localReport.SetLabelValue("ReportDate", DateTime.Now.ToString(Constant.FMT_DATE));
            string shipDateFrom = string.IsNullOrEmpty(gmModel.shr_ShipDateFrom.DateValue()) ? string.Empty : CommonUtil.ParseDate(gmModel.shr_ShipDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            string shipDateTo = string.IsNullOrEmpty(gmModel.shr_ShipDateTo.DateValue()) ? string.Empty : CommonUtil.ParseDate(gmModel.shr_ShipDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            localReport.SetLabelValue("lblShipDateFrom", string.Format("{0}", shipDateFrom));
            localReport.SetLabelValue("lblShipDateTo", string.Format("{0}", shipDateTo));
            localReport.SetLabelValue("lblFromTo", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068));
            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            localReport.SetLabelValue("lblCompany", companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName);
            localReport.SetLabelFromCache(
                                          new KeyValuePair<string, string>("lblPage", Constant.LBL_L0172),

                                          new KeyValuePair<string, string>("lblShipDate", Constant.LBL_L0261),
                                          new KeyValuePair<string, string>("lblProductCD", Constant.LBL_L0018),
                                          new KeyValuePair<string, string>("lblProductName", Constant.LBL_L0019),
                                          new KeyValuePair<string, string>("lblDestinationCD", Constant.LBL_L0302),
                                          new KeyValuePair<string, string>("lblDestinationName", Constant.LBL_L0303),
                                          new KeyValuePair<string, string>("lblTagNo", Constant.LBL_L0106),
                                          new KeyValuePair<string, string>("lblLot1", Constant.LBL_L0084),
                                          new KeyValuePair<string, string>("lblLot2", Constant.LBL_L0085),
                                          new KeyValuePair<string, string>("lblLot3", Constant.LBL_L0086),
                                          new KeyValuePair<string, string>("lblOutboundKind", Constant.LBL_L0300),

                                          new KeyValuePair<string, string>("lblProductTotal", Constant.LBL_L0248),
                                          new KeyValuePair<string, string>("lblDestinationTotal", Constant.LBL_L0314),
                                          new KeyValuePair<string, string>("lblGrandTotal", Constant.LBL_L0249),
                                          new KeyValuePair<string, string>("lblShippingTotal", Constant.LBL_L0313)
                                         );
        }

        /// <summary>
        /// Set Data Source
        /// </summary>
        /// <param name="localReport">LocalReport</param>
        /// <param name="source"> List Of StockListModels</param>
        /// <param name="path">path</param>
        private void setDataSource<TEntity>(LocalReport localReport, List<TEntity> source, string path, string nameDataSet)
        {
            //creating a new report and setting its path
            localReport.ReportPath = System.Web.HttpContext.Current.Server.MapPath(path);

            //adding the reort datasets with there names
            ReportDataSource reportDataSource = new ReportDataSource(nameDataSet, source);
            localReport.DataSources.Add(reportDataSource);
        }

        #endregion

        #endregion

        #region Excel ***** Create Date: 08/08/2013 ***** Author: ISV-Thuy

        /// <summary>
        /// Print
        /// Author : ISV-THUY
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Excel(OutboundDeliveredModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_OUTBOUND_DELIVERED_REPORT))
            {
                return this.RedirectNotAuthority();
            }
            this.SetDropDownlistForSearch(gmModel);
            //Check search data
            if (this.ModelState.IsValid)
            {
                //Check date range
                var shipDateFromStr = gmModel.shr_ShipDateFrom.DateValue();
                var shipDateToStr = gmModel.shr_ShipDateTo.DateValue();
                if (!string.IsNullOrEmpty(shipDateFromStr) || !string.IsNullOrEmpty(shipDateToStr))
                {
                    var shipDateFrom = DateTime.MinValue;
                    var shipDateTo = DateTime.MinValue;
                    //Check three month
                    if (!string.IsNullOrEmpty(shipDateFromStr))
                    {
                        shipDateFrom = Utility.CommonUtil.ParseDate(shipDateFromStr, Constant.FMT_YMD);
                    }
                    if (!string.IsNullOrEmpty(shipDateToStr))
                    {
                        shipDateTo = Utility.CommonUtil.ParseDate(shipDateToStr, Constant.FMT_YMD);
                    }
                    if (shipDateTo.CompareTo((shipDateFrom.AddMonths(3).AddDays(-1))) > 0)
                    {
                        this.ModelState.AddModelError(SHIP_DATE_FROM, this.FormatMessage(Constant.MES_M0076, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0153), UserSession.Session.SysCache.GetLabel(Constant.LBL_L0154)));
                        this.SortModelState(typeof(OutboundDeliveredModels));
                        return View(SCREEN_INDEX, gmModel);
                    }
                }
                if (!this.CheckExistInput(gmModel))
                {
                    return View(SCREEN_INDEX, gmModel);
                }

                DAC.Report dac = new DAC.Report();
                List<OutboundDeliveredReport> dataSource = dac.OutboundDeliveredReport(gmModel);
                if (dataSource.Count() == 0)
                {
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_E0009));
                    return View(SCREEN_INDEX, gmModel);
                }

                List<double> list = dac.OutboundDeliveredCountRow(gmModel);
                if (list.Exists(n => n > Constant.EXCEL_MAX_ROW) )
                {
                    this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0016));
                    return View("Index", gmModel);
                }
                string messConfirm = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020);
                if(list.Count > Constant.EXCEL_MAX_SHEET)
                {
                    messConfirm = InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0040);
                }

                TempData[SAVE_LIST_PRINT] = dataSource;

                //Store condition
                this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + gmModel.SeqNum.ToString()] = gmModel;
                this.ShowMessageConfirm(gmModel.SeqNum, EXCEL_ACTION_URL, message: messConfirm, value1: gmModel.SeqNum.ToString());
            }

            this.SortModelState(typeof(OutboundDeliveredModels));
            return View(SCREEN_INDEX, gmModel);
        }

        HSSFWorkbook workbook;
        Dictionary<String, ICellStyle> styles;

        /// <summary>
        /// Excel Action
        /// </summary>
        /// <param name="value1">Seq Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ExcelAction(string value1)
        {
            //Clear ModeState
            this.ClearModelState();

            OutboundDeliveredModels gmModel = (OutboundDeliveredModels)this.Session[Constant.SESSION_OUTBOUND_DELIVERED_PRINT + value1];
            this.SetDropDownlistForSearch(gmModel);
            if (!this.CheckExistInput(gmModel))
            {
                return View(SCREEN_INDEX, gmModel);
            }

            string type = string.Empty;
            switch (gmModel.CheckDestination)
            {
                case true:
                    type = "OutboundDelivered_L_{0}.xls";
                    break;

                case false:
                    type = "OutboundDelivered_P_{0}.xls";
                    break;
            }

            string fileName = string.Format(type, DateTime.Now.ToString(Constant.FMT_YMDHMM));

            InitializeWorkbook();
            GenerateData(gmModel);

            TempData[TMP_DOWNLOAD_FILE] = File(WriteToStream().GetBuffer(), "application/vnd.ms-excel", fileName);

            if (TempData[TMP_DOWNLOAD_FILE] == null)
            {
                return View("Index", gmModel);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = int.Parse(value1);
                return RedirectToAction("Index");
            }
        }

        /// <summary>
        /// Initialize Workbook
        /// </summary>
        void InitializeWorkbook()
        {
            workbook = new HSSFWorkbook();
            styles = createStyles(workbook);

            ////create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "ISV Viet Nam CO., LTD.";
            workbook.DocumentSummaryInformation = dsi;

            ////create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "Inventory Managerment";
            workbook.SummaryInformation = si;
        }

        /// <summary>
        /// Generate Data
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <param name="PrintType"></param>
        /// <returns></returns>
        private void GenerateData(OutboundDeliveredModels gmModel)
        {
            List<OutboundDeliveredReport> ReportSource = new List<OutboundDeliveredReport>();
            ReportSource = (List<OutboundDeliveredReport>)TempData[SAVE_LIST_PRINT];

            if (gmModel.CheckProduct)
            {
                ReportSource = ReportSource.OrderBy(n => n.ProductCD)
                                           .ThenBy(n => n.ShipDateSort)
                                           .ThenBy(n => n.ShipNo)
                                           .ThenBy(n => n.DeliveryNumber)
                                           .ThenBy(n => n.TagInfo).ToList();

                ExcelProduct(ReportSource, gmModel);
            }
            else
            {
                //tilte = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0310);
                ReportSource = ReportSource.OrderBy(n => n.DestinationCD)
                                           .ThenBy(n => n.ShipDateSort)
                                           .ThenBy(n => n.ShipNo)
                                           .ThenBy(n => n.DeliveryNumber)
                                           .ThenBy(n => n.TagInfo).ToList();

                ExcelCustomer(ReportSource, gmModel);
            }
        }

        /// <summary>
        /// Excel for Product
        /// </summary>
        /// <param name="ReportSource">list of OutboundDeliveredReport</param>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <param name="PrintType"></param>
        private void ExcelProduct(List<OutboundDeliveredReport> ReportSource, OutboundDeliveredModels gmModel)
        {
            var srcGroupPro = ReportSource.Select(n => new { n.ProductCD, n.ProductName }).Distinct().ToList();
           
            for (int i = 0; i < srcGroupPro.Count; i++)
            {
                string sheetName = srcGroupPro[i].ProductCD;
                if (sheetName.Length > 30)
                {
                    sheetName = sheetName.Substring(0, 30);
                }
                ISheet sheet = workbook.CreateSheet(sheetName.Replace("/",string.Empty));
                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0309));

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupPro[i].ProductCD, srcGroupPro[i].ProductName, gmModel);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4(sheet, row_4, gmModel);

                var srcGroupShip = ReportSource.Select(n => new { n.ShipDate, n.ShipNo, n.ProductCD }).Distinct().ToList().Where(n => n.ProductCD.Equals(srcGroupPro[i].ProductCD)).ToList();

                double total = 0;
                int startRow = 5;
                for (int t = 0; t < srcGroupShip.Count; t++)
                {
                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);

                    CreateRow_5(sheet, row, srcGroupShip[t].ShipDate, srcGroupShip[t].ShipNo);

                    var srcDetail = ReportSource.Where(n => n.ShipNo.Equals(srcGroupShip[t].ShipNo) && n.ProductCD.Equals(srcGroupPro[i].ProductCD)).ToList();

                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        for (int iCol = 0; iCol <= 6; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagInfo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    string DestinationCD = srcDetail[j].DestinationCD.Trim();
                                    if (string.IsNullOrEmpty(DestinationCD))
                                    {
                                        DestinationCD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0316);
                                    }
                                    cell.SetCellValue(DestinationCD);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].DestinationName);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 4:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 5:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 6:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].OutboundKind);
                                    break;
                            }
                        }
                    }

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    for (int index = 0; index <= 6; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 3:
                                //Tổng theo mã xuất hàng
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0313));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                                break;

                            case 5:
                                cell.SetCellValue((double)srcDetail.Count);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                    total = total + srcDetail.Count;
                }

                startRow++;
                IRow rowTotal = sheet.CreateRow(startRow);
                rowTotal.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 6; index++)
                {
                    ICell cell = rowTotal.CreateCell(index);
                    switch (index)
                    {
                        case 3:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0248));
                            break;

                        case 5:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                            cell.SetCellValue((double)total);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// Excel for Location
        /// </summary>
        /// <param name="ReportSource">list of OutboundDeliveredReport</param>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <param name="PrintType"></param>
        private void ExcelCustomer(List<OutboundDeliveredReport> ReportSource, OutboundDeliveredModels gmModel)
        {
            var srcGroupDes = ReportSource.Select(n => new { n.DestinationCD, n.DestinationName }).Distinct().ToList();
            int total = 0;
            for (int i = 0; i < srcGroupDes.Count; i++)
            {
                string sheetName = srcGroupDes[i].DestinationCD;
                if (string.IsNullOrEmpty(sheetName.Trim()))
                {
                    sheetName = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0316);
                }

                if (sheetName.Length > 30)
                {
                    sheetName = sheetName.Substring(0, 30);
                }
                ISheet sheet = workbook.CreateSheet(sheetName);
                // Set the the repeating rows and columns on the third sheet.
                workbook.SetRepeatingRowsAndColumns(i, -1, -1, 0, 4);

                PrinterSetup(sheet);

                SheetSetup(sheet);

                CreateHeader(sheet);

                //Danh sách xuất hàng (theo khách hàng)
                IRow row_0 = sheet.CreateRow(0);
                CreateTitle(sheet, row_0, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0310));

                IRow row_1 = sheet.CreateRow(1);
                CreateRow_1(sheet, row_1, gmModel);

                IRow row_2 = sheet.CreateRow(2);
                CreateRow_2(sheet, row_2, srcGroupDes[i].DestinationCD, srcGroupDes[i].DestinationName, gmModel);

                CreateRowEmpty(sheet, 3);

                IRow row_4 = sheet.CreateRow(4);
                CreateRow_4(sheet, row_4, gmModel);

                var srcGroupShip = ReportSource.Select(n => new { n.ShipDate, n.ShipNo, n.DestinationCD }).Distinct().ToList().Where(n => n.DestinationCD.Equals(srcGroupDes[i].DestinationCD)).ToList();

                int startRow = 5;
                total = 0;
                for (int t = 0; t < srcGroupShip.Count; t++)
                {
                    if (t != 0)
                    {
                        startRow++;
                    }
                    IRow row = sheet.CreateRow(startRow);
                    row.HeightInPoints = (HEIGHT_ROW);

                    CreateRow_5(sheet, row, srcGroupShip[t].ShipDate, srcGroupShip[t].ShipNo);

                    var srcDetail = ReportSource.Where(n => n.ShipNo.Equals(srcGroupShip[t].ShipNo) && n.DestinationCD.Equals(srcGroupDes[i].DestinationCD)).ToList();

                    for (int j = 0; j < srcDetail.Count; j++)
                    {
                        startRow++;
                        IRow rowDetail = sheet.CreateRow(startRow);
                        rowDetail.HeightInPoints = (HEIGHT_ROW);

                        for (int iCol = 0; iCol <= 6; iCol++)
                        {
                            ICell cell = rowDetail.CreateCell(iCol);
                            switch (iCol)
                            {
                                case 0:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].TagInfo);
                                    break;

                                case 1:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].ProductCD);
                                    break;

                                case 2:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].ProductName);
                                    break;

                                case 3:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot1);
                                    break;

                                case 4:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot2);
                                    break;

                                case 5:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].Lot3);
                                    break;

                                case 6:
                                    cell.CellStyle = styles[CSS_ROW_DETAIL_STRING];
                                    cell.SetCellValue(srcDetail[j].OutboundKind);
                                    break;
                            }
                        }
                    }

                    startRow++;
                    IRow rowTotalPro = sheet.CreateRow(startRow);
                    rowTotalPro.HeightInPoints = (HEIGHT_ROW);

                    for (int index = 0; index <= 6; index++)
                    {
                        ICell cell = rowTotalPro.CreateCell(index);
                        switch (index)
                        {
                            case 3:
                                //Tổng theo mã xuất hàng
                                cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0313));
                                cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                                break;

                            case 5:
                                cell.SetCellValue((double)srcDetail.Count);
                                cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                                break;

                            default:
                                cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                                break;
                        }
                    }
                    total = total + srcDetail.Count;
                }

                startRow++;
                IRow rowTotal = sheet.CreateRow(startRow);
                rowTotal.HeightInPoints = (HEIGHT_ROW);

                for (int index = 0; index <= 6; index++)
                {
                    ICell cell = rowTotal.CreateCell(index);
                    switch (index)
                    {
                        case 3:
                            cell.CellStyle = styles[CSS_LBL_TOTAL_BODER_TOP];
                            cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0314));
                            break;

                        case 5:
                            cell.CellStyle = styles[CSS_VALUE_TOTAL_INT_BORDER_TOP];
                            cell.SetCellValue((double)total);
                            break;

                        default:
                            cell.CellStyle = styles[CSS_CELL_EMPTY_BORDER_TOP];
                            break;
                    }
                }
            }
        }

        /// <summary>
        /// setup sheet
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void SheetSetup(ISheet sheet)
        {
            sheet.DisplayGridlines = false;

            sheet.FitToPage = (true);
            sheet.HorizontallyCenter = (true);
            sheet.IsPrintGridlines = false;
            // Freeze just one row
            //sheet.CreateFreezePane(0, 5, 0, 5);

            sheet.SetMargin(MarginType.RightMargin, (double)0.25);
            sheet.SetMargin(MarginType.TopMargin, (double)0.6);
            sheet.SetMargin(MarginType.LeftMargin, (double)0.25);
            sheet.SetMargin(MarginType.BottomMargin, (double)0.1);

            sheet.DefaultRowHeightInPoints = HEIGHT_ROW;
            sheet.DefaultColumnWidth = 5;
        }

        /// <summary>
        /// setup printer
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void PrinterSetup(ISheet sheet)
        {
            IPrintSetup printSetup = sheet.PrintSetup;

            printSetup.HeaderMargin = 0.25;
            printSetup.FooterMargin = 0.25;

            printSetup.Copies = 1;
            printSetup.NoColor = true;
            printSetup.Landscape = true;
            printSetup.PaperSize = (short)PaperSize.A4_Small;
            printSetup.FitHeight = ((short)600);
            printSetup.FitWidth = ((short)1);
        }

        /// <summary>
        /// Create header page
        /// </summary>
        /// <param name="sheet">sheet</param>
        private void CreateHeader(ISheet sheet)
        {
            IHeader header = sheet.Header;

            string pageNumberInfo = "Trang: " + HeaderFooter.Page + "/" + HeaderFooter.NumPages;
            string nowDateInfo = String.Format(Constant.FMT_DATE_DPL, DateTime.Now) + " " + HeaderFooter.Time;

            MCompany mCompany = mCompanyService.GetMCompany();
            MWarehouse mWarehouse = mWarehouseService.GetMWarehouseByCd(UserSession.Session.LoginInfo.WarehouseCD);
            string companyNm = mCompany != default(MCompany) ? mCompany.CompanyName1 : string.Empty;
            string space = "";
            string companyInfo = companyNm + space.PadLeft(10) + UserSession.Session.LoginInfo.WarehouseCD + " " + mWarehouse.WarehouseName + "\n" + "       ";

            //HSSFHeader.font("Stencil-Normal", "Italic") +
            //        HSSFHeader.fontSize((short) 16) + "Right w/ Stencil-Normal Italic font and size 16"

            header.Left = companyInfo;
            header.Right = nowDateInfo + "\n" + HSSFHeader.FontSize((short)11) + pageNumberInfo;
        }

        /// <summary>
        /// Create Title
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="value"></param>
        private void CreateTitle(ISheet sheet, IRow row, string value)
        {
            row.HeightInPoints = (HEIGHT_ROW_TITLE);

            ICell cellTitle = row.CreateCell(0);
            cellTitle.SetCellValue(value);
            cellTitle.CellStyle = styles[CSS_TITLE];

            sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 6));
        }

        /// <summary>
        /// Create row 1
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="gmModel">StockInquiryList</param>
        /// <param name="printType"></param>
        private void CreateRow_1(ISheet sheet, IRow row, OutboundDeliveredModels gmModel)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            string shipDateFrom = string.IsNullOrEmpty(gmModel.shr_ShipDateFrom.DateValue()) ? string.Empty.PadLeft(20, ' ') : CommonUtil.ParseDate(gmModel.shr_ShipDateFrom.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);
            string shipDateTo = string.IsNullOrEmpty(gmModel.shr_ShipDateTo.DateValue()) ? string.Empty.PadLeft(20, ' ') : CommonUtil.ParseDate(gmModel.shr_ShipDateTo.DateValue(), Constant.FMT_YMD, Constant.FMT_DATE);

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0261) + ": " + shipDateFrom + " " + UserSession.Session.SysCache.GetLabel(Constant.LBL_L0068) + " " + shipDateTo);
        }

        /// <summary>
        /// Create row 2
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="CD"></param>
        /// <param name="Name"></param>
        /// <param name="printType"></param>
        private void CreateRow_2(ISheet sheet, IRow row, string CD, string Name, OutboundDeliveredModels model)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            if (string.IsNullOrEmpty(CD.Trim()))
            {
                CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0316);
            }

            string lblCD = string.Empty;
            string lblNm = string.Empty;
            string value = string.Empty;

            switch (model.CheckDestination)
            {
                case true:
                    lblCD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0302) + ": ";
                    lblNm = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0303) + ": ";
                    break;

                case false:
                    lblCD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018) + ": ";
                    lblNm = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019) + ": ";
                    break;
            }

            value = lblCD + CD;

            IFont font = workbook.CreateFont();
            font.Boldweight = (short)(FontBoldWeight.BOLD);

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(value);
            cell_0.RichStringCellValue.ApplyFont(lblCD.Length, value.Length, font);

            ICell cell_2 = row.CreateCell(2);
            value = lblNm + Name;
            cell_2.SetCellValue(value);
            if (!string.IsNullOrEmpty(value))
            {
                cell_2.RichStringCellValue.ApplyFont(lblNm.Length, value.Length, font);
            }
        }

        /// <summary>
        /// Create row 4
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        private void CreateRow_4(ISheet sheet, IRow row, OutboundDeliveredModels gmModel)
        {
            row.HeightInPoints = (HEIGHT_ROW);

            for (int iCol = 0; iCol <= 7; iCol++)
            {
                ICell cell = row.CreateCell(iCol);
                switch (iCol)
                {
                    case 0:
                        sheet.SetColumnWidth(iCol, 17 * 256);
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        break;

                    case 1:
                        sheet.SetColumnWidth(iCol, 37 * 256);

                        string CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0302);
                        if (gmModel.CheckDestination)
                        {
                            CD = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018);
                        }
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(CD);
                        break;

                    case 2:
                        sheet.SetColumnWidth(iCol, 55 * 256);

                        string Name = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0303);
                        if (gmModel.CheckDestination)
                        {
                            Name = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019);
                        }
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(Name);
                        break;

                    case 3:
                        sheet.SetColumnWidth(iCol, 37 * 256);
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
                        break;

                    case 4:
                        sheet.SetColumnWidth(iCol, 13 * 256);
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
                        break;

                    case 5:
                        sheet.SetColumnWidth(iCol, 13 * 256);
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
                        break;

                    case 6:
                        sheet.SetColumnWidth(iCol, 20 * 256);
                        cell.CellStyle = styles[CSS_HEADER_GRID_LEFT];
                        cell.SetCellValue(UserSession.Session.SysCache.GetLabel(Constant.LBL_L0300));
                        break;
                }
            }
        }

        /// <summary>
        /// Create row 5
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="row"></param>
        /// <param name="CD"></param>
        /// <param name="Name"></param>
        private void CreateRow_5(ISheet sheet, IRow row, string shipDate, string shipNo)
        {
            shipDate = string.Format(Constant.FMT_DATE_DPL, shipDate);

            row.HeightInPoints = (HEIGHT_ROW);

            ICellStyle style = styles[CSS_HEADER_GROUP_2];

            ICell cell_0 = row.CreateCell(0);
            cell_0.SetCellValue(shipDate);
            cell_0.CellStyle = style;

            ICell cell_1 = row.CreateCell(1);
            cell_1.SetCellValue(shipNo);
            cell_1.CellStyle = style;
        }

        /// <summary>
        /// Write the stream data of workbook to the root directory
        /// </summary>
        /// <returns>MemoryStream</returns>
        MemoryStream WriteToStream()
        {
            //Write the stream data of workbook to the root directory
            MemoryStream file = new MemoryStream();
            workbook.Write(file);
            return file;
        }

        /// <summary>
        /// Create border of cell
        /// </summary>
        /// <param name="wb"></param>
        /// <returns>ICellStyle</returns>
        private static ICellStyle CreateBorderedStyle(HSSFWorkbook wb)
        {
            ICellStyle style = wb.CreateCellStyle();
            style.BorderBottom = BorderStyle.THIN;
            style.BottomBorderColor = (IndexedColors.BLACK.Index);
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);

            return style;
        }

        /// <summary>
        /// Create row Empty 
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="index"></param>
        private static void CreateRowEmpty(ISheet sheet, int index)
        {
            IRow row = sheet.CreateRow(index);
            row.HeightInPoints = 9f;
        }

        /// <summary>
        /// create Styles
        /// </summary>
        /// <param name="wb"></param>
        /// <returns></returns>
        private static Dictionary<String, ICellStyle> createStyles(HSSFWorkbook wb)
        {
            Dictionary<String, ICellStyle> styles = new Dictionary<String, ICellStyle>();
            IDataFormat dataFormat = wb.CreateDataFormat();
            ICellStyle style;

            #region CSS_TITLE

            style = wb.CreateCellStyle();
            style.Alignment = HorizontalAlignment.CENTER;
            //font
            IFont titleFont = wb.CreateFont();
            titleFont.Boldweight = (short)(FontBoldWeight.BOLD);
            titleFont.FontHeightInPoints = 14;
            style.SetFont(titleFont);
            styles.Add(CSS_TITLE, style);

            #endregion

            #region CSS_HEADER_GROUP_2

            style = wb.CreateCellStyle();
            IFont headerGroupFont = wb.CreateFont();
            headerGroupFont.Boldweight = (short)(FontBoldWeight.BOLD);
            //format data
            style.DataFormat = dataFormat.GetFormat("@");
            style.SetFont(headerGroupFont);
            styles.Add(CSS_HEADER_GROUP_2, style);

            #endregion

            #region CSS_HEADER_GRID_LEFT

            style = CreateBorderedStyle(wb);
            style.Alignment = HorizontalAlignment.LEFT;
            styles.Add(CSS_HEADER_GRID_LEFT, style);

            #endregion

            #region CSS_HEADER_GRID_RIGHT

            style = CreateBorderedStyle(wb);
            style.Alignment = HorizontalAlignment.RIGHT;
            styles.Add(CSS_HEADER_GRID_RIGHT, style);

            #endregion

            #region CSS_ROW_DETAIL_STRING

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat("@");
            styles.Add(CSS_ROW_DETAIL_STRING, style);

            #endregion

            #region CSS_ROW_DETAIL_INT

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            styles.Add(CSS_ROW_DETAIL_INT, style);

            #endregion

            #region CSS_ROW_DETAIL_DECIMAL

            style = wb.CreateCellStyle();
            //format data
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            styles.Add(CSS_ROW_DETAIL_DECIMAL, style);

            #endregion

            #region CSS_LBL_TOTAL_BODER_TOP

            style = wb.CreateCellStyle();
            //format data
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.Alignment = HorizontalAlignment.RIGHT;
            styles.Add(CSS_LBL_TOTAL_BODER_TOP, style);

            #endregion

            //#region CSS_LBL_TOTAL_BODER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.Alignment = HorizontalAlignment.RIGHT;
            //styles.Add(CSS_LBL_TOTAL_BODER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_CELL_EMPTY_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            styles.Add(CSS_CELL_EMPTY_BORDER_TOP, style);

            #endregion

            //#region CSS_CELL_EMPTY_BORDER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //styles.Add(CSS_CELL_EMPTY_BORDER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            styles.Add(CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP, style);

            #endregion

            //#region CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.DataFormat = dataFormat.GetFormat(Constant.FMT_DECIMAL);
            //styles.Add(CSS_VALUE_TOTAL_DECIMAL_BORDER_TOP_BOTTOM, style);

            //#endregion

            #region CSS_VALUE_TOTAL_INT_BORDER_TOP

            style = wb.CreateCellStyle();
            style.BorderTop = BorderStyle.THIN;
            style.TopBorderColor = (IndexedColors.BLACK.Index);
            style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            styles.Add(CSS_VALUE_TOTAL_INT_BORDER_TOP, style);

            #endregion

            //#region CSS_VALUE_TOTAL_INT_TOP_BORDER_BOTTOM

            //style = CreateBorderedStyle(wb);
            //style.DataFormat = dataFormat.GetFormat(Constant.FMT_INTEGER);
            //styles.Add(CSS_VALUE_TOTAL_INT_BORDER_TOP_BOTTOM, style);

            //#endregion

            return styles;
        }

        #endregion

        #region Ajax

        /// <summary>
        /// Show Product Name
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <returns>Product Name</returns>      
        ///  [HttpPost]
        public string ShowProductNm(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return string.Empty;
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD);

            if (model != default(ProductModels) && model != null && !model.DeleteFlag)
            {
                return model.ProductName;

            }
            return string.Empty;
        }

        /// <summary>
        /// Show Customer Name
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="CustomerCD">Customer Code</param>
        /// <returns>Customer Name</returns>
        [HttpPost]
        public string ShowCustomerNm(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return string.Empty;
            }

            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);

            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return model.CustomerName;
            }
            return string.Empty;
        }

        /// <summary>
        /// Show Warehouse Name
        /// Author: ISV-LOC
        /// </summary>
        /// <param name="WarehouseCD">Warehouse Code</param>
        /// <returns>Warehouse Name</returns>
        [HttpPost]
        public string ShowWarehouseNm(string WarehouseCD)
        {
            if (string.IsNullOrEmpty(WarehouseCD))
            {
                return string.Empty;
            }

            WarehouseModels model = this.mWarehouseService.GetByCd(WarehouseCD);

            if (model != default(WarehouseModels) && model != null && !model.DeleteFlag)
            {
                return model.WarehouseName;
            }
            return string.Empty;
        }

        #endregion

        #region Private

        /// <summary>
        /// Check Exist Input value
        /// </summary>
        /// <param name="gmModel">OutboundDeliveredModels</param>
        /// <returns></returns>
        private bool CheckExistInput(OutboundDeliveredModels gmModel)
        {
            bool ret = true;
            if (!string.IsNullOrEmpty(gmModel.txt_ProductCD))
            {
                //Check exist in Product Master
                ProductModels modelProduct = this.mProductService.GetByCd(gmModel.txt_ProductCD);
                if (modelProduct == default(ProductModels) || modelProduct.DeleteFlag)
                {
                    //Show error message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                    this.ModelState.AddModelError("txt_ProductCD", message);
                    ret = false;
                }
            }
            return ret;
        }

        ///<summary>
        ///Set DropDownlist For Search
        ///</summary>
        ///<param name="gmModel">StockInquiryList</param>
        private void SetDropDownlistForSearch(OutboundDeliveredModels gmModel)
        {
            //Get List MKind_D: Move Kind
            List<MKind_D> dropKind = this.mKind_DService.GetListByKindForOutboundInquiry(Constant.MKIND_KINDCD_OUTBOUND_KIND).ToList();

            MKind_D emptyItem = new MKind_D();
            emptyItem.KindCD = Constant.MKIND_KINDCD_OUTBOUND_KIND;
            emptyItem.DataCD = string.Empty;
            emptyItem.Value = Constant.BLANK;

            SelectOption option = new SelectOption("Value", "DataCD", DROPDOWN_OUTBOUND_KIND, gmModel.ddl_Kind);
            this.SetViewDataDropdownList<MKind_D>(option, dropKind);
        }

        #endregion
    }
}

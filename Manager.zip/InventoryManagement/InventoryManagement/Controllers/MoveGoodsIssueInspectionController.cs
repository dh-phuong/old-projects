﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.Common;
using InventoryManagement.Validation;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Utility;
using System.Transactions;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// MoveGoodsIssueInspection Controller
    /// Author: ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class MoveGoodsIssueInspectionController : BaseController
    {
        #region Common

        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MWarehouseService mWarehouseService;
        private bool isCheckShipNo;
        private int pageSize = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        public MoveGoodsIssueInspectionController(DataAccess.TShippingInstructionService tShippingInstructionService,
                                                  DataAccess.TInventory_HService tInventory_HService,
                                                  DataAccess.TInventory_DService tInventory_DService,
                                                  DataAccess.MLocationService mLocationService,
                                                  DataAccess.MCustomerService mCustomerService,
                                                  DataAccess.TSequencesService tSequencesService,
                                                  DataAccess.TBalanceInStoresService tBalanceInStoresService,
                                                  DataAccess.TReserveService tReserveService,
                                                  DataAccess.TPessimisticLockService tPessimisticLockService,
                                                  DataAccess.MKind_DService mKind_DService,
                                                  DataAccess.MWarehouseService mWarehouseService)
        {
            this.tShippingInstructionService = tShippingInstructionService;
            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.mLocationService = mLocationService;
            this.tSequencesService = tSequencesService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.tReserveService = tReserveService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.mKind_DService = mKind_DService;
            this.mWarehouseService = mWarehouseService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tShippingInstructionService.Context = ctx;
            this.tInventory_HService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.mLocationService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.mWarehouseService.Context = ctx;
            this.isCheckShipNo = this.mKind_DService.IsChecKShipNo();
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string KEY_PICKING_LOCATION_CD = "txt_LocationCD";
        private const string KEY_PICKING_TAG_NO = "txt_TagNo";
        private const string KEY_SHIP_NO = "txt_ShipNo";

        private const string PARTIAL_LIST = "_List";
        private const string PARTIAL_PICKING_DETAIL = "_PickingList";

        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_PICKING = "Picking";

        private const string SEARCH_DDL_MOVEKIND = "ddl_MoveKind";
        private const string SEARCH_TXT_SHIPNO = "txt_ShipNo";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_LOCATION_CD = "LocationCD";
        private const string SORT_TAG_NO = "TagNo";
        private const string SORT_URL_LIST = "/MoveGoodsIssueInspection/Sorting";
        private const string SORT_URL_PICKING_DETAIL = "/MoveGoodsIssueInspection/SortingDetail";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";
        #endregion

        #region Enum

        /// <summary>
        /// Checking flag
        /// </summary>
        private enum CheckFlag
        {
            Success = 0,
            Error,
            Redirect,
        }

        /// <summary>
        /// Update flag
        /// </summary>
        private enum UpdateFlag
        {
            Success = 0,
            Failed,
            Exclusion
        }

        #endregion Enum

        #region Event

        #region Index

        /// <summary>
        /// List
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(MoveGoodsIssueInspectionList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_GOODS_ISSUE_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(MoveGoodsIssueInspectionList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];
                //Get model
                MoveGoodsIssueInspectionList oldModel = (MoveGoodsIssueInspectionList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(MoveGoodsIssueInspectionList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<MoveGoodsIssueInspectionResults> results = this.tShippingInstructionService.GetListByConditionForMoveGoodsIssueInspection(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<MoveGoodsIssueInspectionResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    this.SetFocusId(SEARCH_DDL_MOVEKIND);
                }
            }
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<MoveGoodsIssueInspectionResults> results = this.tShippingInstructionService.GetListByConditionForMoveGoodsIssueInspection(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL_LIST,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<MoveGoodsIssueInspectionResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_DDL_MOVEKIND);
            }

            //Init RolesCD combobox
            SetViewBagMoveKind(SEARCH_DDL_MOVEKIND, gmModel.ddl_MoveKind);

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveGoodsIssueInspectionResults> list = (IQueryable<MoveGoodsIssueInspectionResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<MoveGoodsIssueInspectionResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveGoodsIssueInspectionResults> list = (IQueryable<MoveGoodsIssueInspectionResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<MoveGoodsIssueInspectionResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        #endregion
        
        #region Picking

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Picking(int SeqNum, string ShipNo, string MoveKind,string ShipNoChecked, string Message)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_MOVE_GOODS_ISSUE_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0199);

            //Get info Header
            MoveGoodsIssueInspectionHeader model = this.tShippingInstructionService.GetByShipNoForMoveHeader(ShipNo, MoveKind, this.isCheckShipNo);
            //Check exclusion
            if (model == default(MoveGoodsIssueInspectionHeader))
            {
                return this.ExclusionProcess(SeqNum, Message);
            }
            model.SeqNum = SeqNum;
            model.MoveKind = MoveKind;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Search data
            IQueryable<MoveGoodsIssueInspectionDetail> results = this.tInventory_DService.GetListMoveDetail(ShipNo);
            this.SetSortAndPaging(ref results, SeqNum, SORT_LOCATION_CD, SortDirection.Ascending, SORT_TAG_NO, null);
            this.Session[Constant.SESSION_SHIPMENT_PICKING_DETAIL + SeqNum.ToString()] = results;

            if (!string.IsNullOrEmpty(Message))
            {
                this.ShowMessageInfo(Message);
                ViewBag.MsgComplete = true;
            }
            //Set focus
            if (model.isCheckShipNo && string.IsNullOrEmpty(ShipNoChecked))
            {
                this.SetFocusId(KEY_SHIP_NO);
            }
            else
            {
                this.SetFocusId(KEY_PICKING_LOCATION_CD);
            }
            model.isShowShipNo = model.isCheckShipNo;

            //ShipNo checking is completed
            if (!string.IsNullOrEmpty(ShipNoChecked))
            {
                model.txt_ShipNo = model.ShipNoDB;
                model.isShowShipNo = false;
            }
            return View(SCREEN_PICKING, model);
        }

        #region ShipNoPicking

        /// <summary>
        /// ShipNo Picking
        /// </summary>
        /// <param name="gmModel">GoodsIssueInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult ShipNoPicking(MoveGoodsIssueInspectionHeader gmModel)
        {
            IQueryable<MoveGoodsIssueInspectionDetail> list = null;
            if (this.RestoreDetail(gmModel, ref list) == CheckFlag.Redirect)
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_ShipNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Check Exist ShipNo
                TShippingInstruction modelS = this.tShippingInstructionService.GetByPk(gmModel.txt_ShipNo);
                if (modelS == default(TShippingInstruction) || modelS.DeleteFlag)
                {
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0195));
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                if (!gmModel.txt_ShipNo.Equals(gmModel.ShipNoDB))
                {
                    message = this.FormatMessage(Constant.MES_M0061);
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }
                else
                {
                    gmModel.isShowShipNo = false;
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;
                }
                this.SetFocusId(KEY_PICKING_LOCATION_CD);
            }

            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        /// <summary>
        /// Location for Picking
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult LocationPicking(MoveGoodsIssueInspectionHeader gmModel)
        {
            IQueryable<MoveGoodsIssueInspectionDetail> list = null;
            if (this.RestoreDetail(gmModel, ref list) == CheckFlag.Redirect)
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }

            if (this.ModelState.IsValid)
            {
                gmModel.txt_LocationCD = Models.MLocation.FixCodeDB(gmModel.txt_LocationCD);
                CheckFlag ret = LocationCheck(gmModel, list);
                if (ret.Equals(CheckFlag.Redirect))
                {
                    //Show message: Shipped all the stock. Finish the picking.
                    string message = this.FormatMessage(Constant.MES_M0033);
                    return ExclusionProcess(gmModel.SeqNum, message);
                }
                else if (ret.Equals(CheckFlag.Success))
                {
                    ViewBag.CheckedQty = list.Count(m => m.Checked);

                    //Set focus
                    this.SetFocusId(KEY_PICKING_TAG_NO);
                }
            }

            return View(SCREEN_PICKING, gmModel);
        }

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult TagNoPicking(MoveGoodsIssueInspectionHeader gmModel)
        {
            IQueryable<MoveGoodsIssueInspectionDetail> list = null;
            if(this.RestoreDetail(gmModel, ref list) == CheckFlag.Redirect)
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }

            if (this.ModelState.IsValid)
            {
                //Check location
                string message = string.Empty;
                CheckFlag flg = LocationCheck(gmModel, list);
                if (flg.Equals(CheckFlag.Redirect))
                {
                    //Show message: Shipped all the stock. Finish the picking.
                    message = this.FormatMessage(Constant.MES_M0033);
                    return ExclusionProcess(gmModel.SeqNum, message);
                }
                else if (flg.Equals(CheckFlag.Error))
                {
                    return View(SCREEN_PICKING, gmModel);
                }
                else if (string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }
                
                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
                {
                    //{0}はデータベースに存在しません。
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //TagNo Check
                if (TagNoCheck(gmModel,tagNo, branchTagNo, list))
                {
                    //Update data
                    switch(this.UpdateData(gmModel,tagNo, branchTagNo, list))
                    {
                        case UpdateFlag.Exclusion:
                            this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0003));
                            break;

                        case UpdateFlag.Failed:
                            this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0011));
                            break;
                        
                        default:

                            message = this.FormatMessage(Constant.MES_M0024);
                            this.ShowMessageInfo(message);

                            ViewBag.CheckedQty = list.Count(m => m.Checked);
                            if(!list.Any(m => !m.Checked))
                            {
                                ViewBag.MsgAfter = this.FormatMessage(Constant.MES_M0033);
                            }
                            //Check current loction checked all
                            else if (!list.Any(m => m.LocationCD.Equals(gmModel.txt_LocationCD) && !m.Checked))
                            {
                                ViewBag.MsgAfter = this.FormatMessage(Constant.MES_M0032);
                            }
                            break;
                    }
                }
            }

            return View(SCREEN_PICKING, gmModel);
        }

        /// <summary>
        /// Sorting Picking List
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult SortingDetail(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveGoodsIssueInspectionDetail> list = (IQueryable<MoveGoodsIssueInspectionDetail>)this.Session[Constant.SESSION_SHIPMENT_PICKING_DETAIL + SeqNum.ToString()];

            this.SetSortAndPaging(ref list, SeqNum, sortInfo.SortField, sortInfo.Direction, SORT_TAG_NO, null);
            return PartialView(PARTIAL_PICKING_DETAIL);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult PagingDetail(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<MoveGoodsIssueInspectionDetail> list = (IQueryable<MoveGoodsIssueInspectionDetail>)this.Session[Constant.SESSION_SHIPMENT_PICKING_DETAIL + SeqNum.ToString()];

            this.SetSortAndPaging(ref list, SeqNum, sortInfo.SortField, sortInfo.Direction, SORT_TAG_NO, pageRequest);
            return PartialView(PARTIAL_PICKING_DETAIL);
        }

        #endregion Picking

        #endregion Event

        #region private

        /// <summary>
        /// Restore Detail
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionHeader</param>
        /// <param name="list">IQueryable of MoveGoodsIssueInspectionDetail</param>
        /// <returns></returns>
        private CheckFlag RestoreDetail(MoveGoodsIssueInspectionHeader gmModel, ref IQueryable<MoveGoodsIssueInspectionDetail> list)
        {
            //Check exclusion
            MoveGoodsIssueInspectionHeader model = this.tShippingInstructionService.GetByShipNoForMoveHeader(gmModel.ShipNoDB, gmModel.MoveKind, this.isCheckShipNo);
            if (model == default(MoveGoodsIssueInspectionHeader))
            {
                return CheckFlag.Redirect;
            }

            //Get detail list
            list = list = this.tInventory_DService.GetListMoveDetail(gmModel.ShipNoDB);
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];
            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPaging(ref list, gmModel.SeqNum, SORT_LOCATION_CD, SortDirection.Ascending, SORT_TAG_NO, null);
            }
            else
            {
                this.SetSortAndPaging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction, SORT_TAG_NO, null);
            }

            //Store result into session
            this.Session[Constant.SESSION_SHIPMENT_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;
            return CheckFlag.Success;
        }

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {
            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                return false;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                return false;
            }

            tagNo = array[0];
            return true;
        }

        /// <summary>
        /// Set Sort and Paging
        /// </summary>
        /// <param name="list">list GoodsIssueInspectionDetail</param>
        /// <param name="SeqNum">SeqNum</param>
        private void SetSortAndPaging(ref IQueryable<MoveGoodsIssueInspectionDetail> list, int SeqNum, string sortField, SortDirection Direction, string otherSortField, PagingRequest pageRequest)
        {
            //Create sorting info
            SortingInfo sortInfo = new SortingInfo
            {
                Url = SORT_URL_PICKING_DETAIL,
                SortField = sortField,
                Direction = Direction,
            };

            //Checked Quantity
            ViewBag.CheckedQty = list.Where(m => m.Checked).Count();

            //Paging
            if(pageRequest == null)
            {
                pageRequest = (PagingRequest)this.Session[Constant.SESSION_DETAIL_PAGING + SeqNum.ToString()];
                if (pageRequest == null)
                {
                    pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                }
            }
            this.PagingBase<MoveGoodsIssueInspectionDetail>(ref list, pageRequest, sortInfo, SeqNum, list.Count(), SesionSortingKey: Constant.SESSION_DETAIL_SORTING, SesionPagingKey: Constant.SESSION_DETAIL_PAGING, orderField2: otherSortField);
        }

        /// <summary>
        /// Set RolesCD SelectList
        /// </summary>
        /// <param name="control">control</param>
        /// <param name="RoleCD">RoleCD</param>
        private void SetViewBagMoveKind(string control, string KindCD)
        {
            IOrderedQueryable<MKind_D> dropSrc = this.mKind_DService.GetListByDataKind(Common.Constant.MKIND_KINDCD_MOVE_KIND);
            if (UserSession.Session.WareHouseMode == WareHouseMode.Single)
            {
                dropSrc = (IOrderedQueryable<MKind_D>)dropSrc.Where(m => !m.DataCD.Equals(Constant.MKIND_KINDCD_MOVE_KIND_WAREHOUSE));
            }

            //Insert Blank Item
            var ItemList = dropSrc.ToList();
            ItemList.Insert(0, new MKind_D() { DataCD = String.Empty, Value = Constant.BLANK });

            SelectOption option = new SelectOption("value", "dataCD", control, KindCD);
            this.SetViewDataDropdownList<Models.MKind_D>(option, ItemList);
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="message">message error</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum, string message)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/MoveGoodsIssueInspection/Index", message: message);
            MoveGoodsIssueInspectionHeader model = (MoveGoodsIssueInspectionHeader)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(MoveGoodsIssueInspectionHeader))
            {
                model = new MoveGoodsIssueInspectionHeader();
                model.SeqNum = SeqNum;
            }
            //Clear Session
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = null;
            this.Session[Constant.SESSION_SHIPMENT_PICKING_DETAIL + SeqNum.ToString()] = null;

            return View(SCREEN_PICKING, model);
        }

        #endregion

        #region Check

        /// <summary>
        /// Location Check
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionHeader</param>
        /// <param name="list">List MoveGoodsIssueInspectionDetail</param>
        /// <returns>CheckFlag</returns>
        private CheckFlag LocationCheck(MoveGoodsIssueInspectionHeader gmModel, IQueryable<MoveGoodsIssueInspectionDetail> list)
        {

            if (string.IsNullOrEmpty(gmModel.txt_LocationCD))
            {
                string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                this.ModelState.AddModelError(KEY_SHIP_NO, message);
                return CheckFlag.Error;
            }

            LocationModels mLocation = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCD);
            //TagInfo is Not Exist
            if (mLocation == default(LocationModels) || mLocation.DeleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                this.ModelState.AddModelError(KEY_PICKING_LOCATION_CD, message);
                return CheckFlag.Error;
            }

            //The input tag number is not exist shipping instruction.
            if (!list.Any(m => m.LocationCD.Equals(gmModel.txt_LocationCD)))
            {
                string message = this.FormatMessage(Constant.MES_M0029, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0203));
                this.ModelState.AddModelError(KEY_PICKING_LOCATION_CD, message);
                return CheckFlag.Error;
            }

            //Shipment of this location is now complete.
            if (!list.Any(m => m.LocationCD.Equals(gmModel.txt_LocationCD) && !m.Checked))
            {
                string message = this.FormatMessage(Constant.MES_M0032);
                gmModel.txt_LocationCD = string.Empty;
                gmModel.txt_TagNo = string.Empty;
                this.ShowMessageInfo(message);
                ViewBag.ErrorCus = true;
                return CheckFlag.Error;
            }

            // this location Issue Prohibition
            if (mLocation.IssueProhibitionFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0075);
                this.ModelState.AddModelError(KEY_PICKING_LOCATION_CD, message);
                return CheckFlag.Error;
            }

            //Shipped all the stock. Finish the picking.
            if (!list.Any(m => m.Checked.Equals(false)))
            {
                return CheckFlag.Redirect;
            }

            return CheckFlag.Success;
        }

        /// <summary>
        /// TagNo Check
        /// </summary>
        /// <param name="gmModel">header moedl</param>
        /// <param name="tagNo">Tag No</param>.
        /// <param name="branchTagNo">Branch Tag No</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool TagNoCheck(MoveGoodsIssueInspectionHeader gmModel, string tagNo, int branchTagNo, IQueryable<MoveGoodsIssueInspectionDetail> list)
        {
            TInventory_D invDetail = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
            TInventory_H invHeader = this.tInventory_HService.GetByTagNo(tagNo);

            string message = string.Empty;
            //Check Exist Data
            if (invDetail == default(TInventory_D) || invHeader.DeleteFlag)
            {
                message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            }
            //Identification tag number you entered does not exist in the specified location.
            else if (!invDetail.LocationCD.Equals(gmModel.txt_LocationCD))
            {
                message = this.FormatMessage(Constant.MES_M0031);
            }
            //Check Shipping include this tag no
            else if (!list.Any(m => m.TagNo.Equals(gmModel.txt_TagNo)))
            {
                message = this.FormatMessage(Constant.MES_M0030, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0203));
            }
            //check select normal product for scrap
            else if (gmModel.MoveKind == Constant.MKIND_KINDCD_MOVE_KIND_SCRAP && invDetail.StockStatus == Constant.STOCK_STATUS_RECEIPT_NON_DEFECTIVE)
            {
                message = this.FormatMessage(Constant.MES_M0083);
            }
            // This {0} is already loaded. Please read of next the {1}.
            else if (invDetail.PickingFlag.Value)
            {
                message = this.FormatMessage(Constant.MES_M0035, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            }
            
            if (!string.IsNullOrEmpty(message))
            {
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
           
            return true;
        }
        
        #endregion Check

        #region Registration

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">MoveGoodsIssueInspectionHeader</param>
        /// <param name="string">Tag No</param>
        /// <param name="branchTagNo">Branch Tag No</param>
        /// <param name="listDetail">list detail</param>
        private UpdateFlag UpdateData(MoveGoodsIssueInspectionHeader gmModel, string tagNo, int branchTagNo, IQueryable<MoveGoodsIssueInspectionDetail> listDetail)
        {
            string curDate = this.GetCurrentDate();
            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //Insert TPessimisticLock
                    TPessimisticLock tPessi = new TPessimisticLock();
                    tPessi.TagNo = tagNo;
                    this.tPessimisticLockService.Insert(tPessi);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Update PickingFlg
                    TInventory_D invDetail = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                    this.SetUpdatePicking(invDetail, curDate, gmModel.MoveKind);

                    //Insert BalanceInStores
                    this.SetInsertBalanceInStores(invDetail, curDate, gmModel.MoveKind);
                    this.tInventory_DService.Context.SubmitChanges();

                    //All checked
                    if (!listDetail.Any(m => m.Checked.Equals(false)))
                    {
                        TShippingInstruction dbShipH = this.tShippingInstructionService.GetByPk(invDetail.ShippingNo);
                        this.SetUpdateCompleteFlg(dbShipH, curDate);
                    }

                    //Delete tagno in TPessimisticLock
                    this.tPessimisticLockService.Delete(tPessi);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Commit transaction
                    trans.Complete();
                }
                catch (ChangeConflictException)
                {
                    return UpdateFlag.Exclusion;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return UpdateFlag.Exclusion;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return UpdateFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return UpdateFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }

            return UpdateFlag.Success;
        }

        /// <summary>
        /// Get Issue Stock Status
        /// </summary>
        /// <param name="moveKind">move kind</param>
        /// <param name="preStockStatus">previous stock status</param>
        /// <returns>Issue Stock Status</returns>
        private string GetIssueStockStatus(string moveKind, string preStockStatus)
        {
            string ret = Constant.STOCK_STATUS_ISSUE_INSIDE_MOVE;
            if (moveKind == Constant.MKIND_KINDCD_MOVE_KIND_SCRAP)
            {
                ret = Constant.STOCK_STATUS_ISSUE_SCRAP;
            }
            else if (preStockStatus == Constant.STOCK_STATUS_RECEIPT_DEFECTIVE)
            {
                ret = Constant.STOCK_STATUS_ISSUE_DEFECTIVE;
            }

            return ret;
        }

        /// <summary>
        /// Set Update Picking
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="curDate">CurDate</param>
        /// <param name="moveKind">Move Kind</param>
        private void SetUpdatePicking(TInventory_D dbModel_D, string curDate, string moveKind)
        {
            dbModel_D.PickingFlag = true;
            dbModel_D.StockStatus = this.GetIssueStockStatus(moveKind, dbModel_D.StockStatus);
            dbModel_D.UpdateDate = curDate;
            dbModel_D.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Set Insert BalanceInStores
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="curDate">curDate</param>
        /// <param name="moveKind">Move Kind</param>
        private void SetInsertBalanceInStores(TInventory_D dbModel_D, string curDate, string moveKind)
        {
            //TSequences
            //string MaxTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

            //Insert TBalanceInStores
            TBalanceInStores balanceinstoresModel = new TBalanceInStores();
            //balanceinstoresModel.BalanceNo = MaxTagNo;
            balanceinstoresModel.BalanceStatus = Constant.BALANCE_STATUS_MOVE_ISSUE;
            if (moveKind.Equals(Constant.MKIND_KINDCD_MOVE_KIND_SCRAP))
            {
                balanceinstoresModel.BalanceStatus = Constant.BALANCE_STATUS_DISCARD_ISSUE;
            }
            balanceinstoresModel.BalanceDate = DateTime.Now.ToString(Constant.FMT_YMD);
            balanceinstoresModel.TagNo = dbModel_D.TagNo;
            balanceinstoresModel.BranchTagNo = dbModel_D.BranchTagNo;
            balanceinstoresModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            balanceinstoresModel.LocationCD = dbModel_D.LocationCD;
            balanceinstoresModel.CreateDate = curDate;
            balanceinstoresModel.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            balanceinstoresModel.UpdateDate = curDate;
            balanceinstoresModel.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            this.tBalanceInStoresService.Insert(balanceinstoresModel);
        }

        /// <summary>
        /// Set Update CompleteFlg
        /// </summary>
        /// <param name="dbShipH">TShippingInstruction</param>
        /// <param name="curDate">curDate</param>
        private void SetUpdateCompleteFlg(TShippingInstruction dbShipH, string curDate)
        {
            dbShipH.PickingCompleteFlag = true;
            dbShipH.UpdateDate = curDate;
            dbShipH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }
        
        #endregion Registration

        #region Ajax

        /// <summary>
        /// Show Location Name
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>        
        public JsonResult ShowLocationName(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            MLocation model = this.mLocationService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);
            if (model != default(MLocation) && !model.DeleteFlag)
            {
                return Json(new List<string>(){model.LocationName}, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Warehouse Name
        /// </summary>
        /// <param name="WarehouseCD">WarehouseCD</param>
        /// <returns>Warehouse Name</returns>        
        public JsonResult ShowWarehouseName(string WarehouseCD)
        {
            if (string.IsNullOrEmpty(WarehouseCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            MWarehouse model = this.mWarehouseService.GetMWarehouseByCd(WarehouseCD);
            if (model != default(MWarehouse) && !model.DeleteFlag)
            {
                return Json(new List<string>(){model.WarehouseName}, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion Ajax

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(int SeqNum)
        {
            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = SeqNum;
            return RedirectToAction("Index");
        }

        #endregion Back

    }
}

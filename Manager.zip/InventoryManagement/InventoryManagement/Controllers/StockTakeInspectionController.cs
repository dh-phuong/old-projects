﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Validation;
using InventoryManagement.iQueryable;
using System.Collections;
using InventoryManagement.Common;
using InventoryManagement.Models;
using InventoryManagement.Utility;
using System.Web.Helpers;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Transactions;
using Microsoft.Reporting.WebForms;
using System.Drawing;
using System.IO;
using System.Data;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Author: ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class StockTakeInspectionController : BaseController
    {
        #region Common

        /// <summary>
        /// 棚情報のサービス
        /// </summary>
        private DataAccess.MLocationService mLocationService;

        /// <summary>
        /// TTakeInventory_Dのサービス
        /// </summary>
        private DataAccess.TTakeInventory_DService tTakeInventoryDService;

        /// <summary>
        /// TTakeInventory_Hのサービス
        /// </summary>
        private DataAccess.TTakeInventory_HService tTakeInventoryHService;

        /// <summary>
        /// TInventory_Hのサービス
        /// </summary>
        private DataAccess.TInventory_HService tInventoryHService;

        /// <summary>
        /// TInventory_Dのサービス
        /// </summary>
        private DataAccess.TInventory_DService tInventoryDService;

        /// <summary>
        /// TShippingInstructionのサービス
        /// </summary>
        private DataAccess.TShippingInstructionService tShippingInstructionService;

        private DataAccess.MKind_DService mKind_DService;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="mLocationService">MLocationService</param>
        /// <param name="tTakeInventoryHService">tTakeInventoryHService</param>
        /// <param name="tTakeInventoryDService">tTakeInventoryDService</param>
        /// <param name="tInventoryHService">tInventoryHService</param>
        /// <param name="tInventoryDService">tInventoryDService</param>
        /// <param name="tShippingInstructionService">tShippingInstructionService</param>
        public StockTakeInspectionController(DataAccess.MLocationService mLocationService,
                                             DataAccess.TTakeInventory_HService tTakeInventoryHService,
                                             DataAccess.TTakeInventory_DService tTakeInventoryDService,
                                             DataAccess.TInventory_HService tInventoryHService,
                                             DataAccess.TInventory_DService tInventoryDService,
                                             DataAccess.TShippingInstructionService tShippingInstructionService,
                                             DataAccess.MKind_DService mKind_DService
                                            )
        {

            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();

            this.mLocationService = mLocationService;
            this.tTakeInventoryHService = tTakeInventoryHService;
            this.tTakeInventoryDService = tTakeInventoryDService;
            this.tInventoryHService = tInventoryHService;
            this.tInventoryDService = tInventoryDService;
            this.tShippingInstructionService = tShippingInstructionService;
            this.mKind_DService = mKind_DService;

            this.mLocationService.Context = ctx;
            this.tTakeInventoryHService.Context = ctx;
            this.tTakeInventoryDService.Context = ctx;
            this.tInventoryHService.Context = ctx;
            this.tInventoryDService.Context = ctx;
            this.tShippingInstructionService.Context = ctx;
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string SEARCH_LOCATION_CD = "txt_LocationCD";
        private const string SEARCH_TAG_NO = "txt_TagNo";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_URL_PICKING = "/StockTakeInspection/PickingSorting";
        private const string SORT_URL_LIST = "/StockTakeInspection/ListSorting";

        private const string SCREEN_PICKING = "Picking";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region List

        /// <summary>
        /// Index
        /// </summary>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(StockTakeList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_STOCK_TAKING_DEF))
            {
                return this.RedirectNotAuthority();
            }

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                StockTakeList oldModel = (StockTakeList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(StockTakeList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<StockTakeResults> results = this.tTakeInventoryHService.GetListStockTakeResultsByConditions(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<StockTakeResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_LOCATION_CD);
                }
            }
            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data                
                var results = this.tTakeInventoryHService.GetListStockTakeResultsByConditions(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                var sortInfo = new SortingInfo
                {
                    Url = SORT_URL_LIST,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<StockTakeResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_LOCATION_CD);
            }

            return View("Index", gmModel);
        }

        #region Paging

        /// <summary>
        ///  Paging
        /// </summary>                
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>      
        /// <returns></returns>
        [HttpPost]
        public ActionResult ListPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockTakeResults> list = (IQueryable<StockTakeResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<StockTakeResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView("_List");
        }

        #endregion

        #region Sorting

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>        
        /// <returns></returns>
        [HttpPost]
        public ActionResult ListSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<StockTakeResults> list = (IQueryable<StockTakeResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<StockTakeResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List");
        }

        #endregion

        #endregion

        #region Picking

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Picking(string LocationCD, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_STOCK_TAKING_DEF))
            {
                return this.RedirectNotAuthority();
            }

            //Lock TagNo
            ViewBag.LockTagNo = true;

            StockTakeInspectionModels model = new StockTakeInspectionModels();
            model.LocationDB = LocationCD;
            model.SeqNum = SeqNum;

            TTakeInventory_H takeinvenH = this.tTakeInventoryHService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationDB);
            if (takeinvenH == null)
            {
                return this.ExclusionProcess(model, null);
            }

            //Focus
            this.SetFocusId(SEARCH_LOCATION_CD);

            return View(SCREEN_PICKING, model);
        }

        #endregion

        #region InputLocationCD

        /// <summary>
        /// Input LocationCD
        /// </summary>
        /// <param name="gmModel">StockTakeInspectionModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InputLocationCD(StockTakeInspectionModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_STOCK_TAKING_DEF))
            {
                return this.RedirectNotAuthority();
            }

            //Lock TagNo
            ViewBag.LockTagNo = true;

            if (this.ModelState.IsValid)
            {
                gmModel.txt_LocationCD = gmModel.txt_LocationCD.ToUpper();
                LocationModels location = mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCD);
                if (location == null)
                {
                    // Show Error Message
                    string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                    this.ModelState.AddModelError(SEARCH_LOCATION_CD, message);
                }
                else
                {
                    if (gmModel.txt_LocationCD.Equals(gmModel.LocationDB))
                    {
                        TTakeInventory_H takeinvenH = this.tTakeInventoryHService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, gmModel.txt_LocationCD);
                        if (takeinvenH == null)
                        {
                            // Show Error Message
                            return this.ExclusionProcess(gmModel, null);
                        }
                        else
                        {
                            gmModel.txt_LocationName = location.LocationName;

                            //Load Data
                            this.LoadData(gmModel);
                        }
                    }
                    else 
                    {
                        // Show Error Message
                        string message = this.FormatMessage(Constant.MES_M0064);
                        this.ModelState.AddModelError(SEARCH_LOCATION_CD, message);
                    }
                }
            }

            //Check Error
            if (this.ModelState.IsValid)
            {
                ViewBag.LockTagNo = false;

                //Focus
                this.SetFocusId(SEARCH_TAG_NO);
            }

            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region InputTagNo

        /// <summary>
        /// InputTagNo
        /// </summary>
        /// <param name="model">StockTakeInspectionModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InputTagNo(StockTakeInspectionModels model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_STOCK_TAKING_DEF))
            {
                return this.RedirectNotAuthority();
            }

            //Lock TagNo
            ViewBag.LockTagNo = false;

            TTakeInventory_H takeinvenH = this.tTakeInventoryHService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, model.LocationDB);
            if (takeinvenH == null)
            {
                return this.ExclusionProcess(model, null);
            }

            if (this.ModelState.IsValid)
            {
                //Check require
                if (string.IsNullOrEmpty(model.txt_TagNo) || string.IsNullOrEmpty(model.txt_TagNo.Trim()))
                {
                    // Show Error Message
                    string message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                }
                else
                {
                    //Get info TagNo
                    string tagNo = string.Empty;
                    int branchTagNo = default(int);
                    if (!this.CheckScreenTagNoInput(model.txt_TagNo, ref tagNo, ref branchTagNo))
                    {
                        // Show Error Message
                        string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                        this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                    }
                    else
                    {
                        //Check Inventory Detail
                        TInventory_H inventoryH = this.tInventoryHService.GetByPK(tagNo);
                        TInventory_D inventoryD = tInventoryDService.GetByPK(tagNo, branchTagNo);
                        if (inventoryD == null || inventoryH == null)
                        {
                            // Show Error Message
                            string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                            this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                        }
                        else
                        {
                            if ((inventoryD.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY)              //50: 出荷
                                    || inventoryD.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_DEFECTIVE) //57:「出荷(不良品)」
                                    || inventoryD.StockStatus.Equals(Constant.STOCK_STATUS_DELIVERY_SCRAP))    //58:「破棄出荷」
                                && !this.tShippingInstructionService.IsShipComplete(inventoryD.ShippingNo))
                            {
                                string message = this.FormatMessage(Constant.MES_M0086);
                                this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                            }
                            else
                            {
                                model.txt_TagNo = string.Empty;
                                //Focus
                                this.SetFocusId(SEARCH_TAG_NO);

                                CommitFlag flag = this.ProcessInsertData(tagNo, branchTagNo.ToString(), model.txt_LocationCD, takeinvenH.TakeStartDate);

                                //Insert Fail
                                if (flag == CommitFlag.Failed)
                                {
                                    string message = this.FormatMessage(Constant.MES_M0011);
                                    this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                                }

                                //Checked
                                if (flag == CommitFlag.DataChanged)
                                {
                                    string message = this.FormatMessage(Constant.MES_M0035, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                                    this.ModelState.AddModelError(SEARCH_TAG_NO, message);
                                }
                            }
                        }
                    }
                }
            }

            //Load Data
            this.LoadData(model);

            return View(SCREEN_PICKING, model);
        }

        #endregion

        #region PickingPaging

        /// <summary>
        ///  Picking Paging
        /// </summary>                
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>      
        /// <returns></returns>
        [HttpPost]
        public ActionResult PickingPaging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Lock TagNo
            ViewBag.LockTagNo = false;

            //Focus
            this.SetFocusId(SEARCH_TAG_NO);

            //Get search result from session
            IQueryable<StockTakeInspectionResults> list = (IQueryable<StockTakeInspectionResults>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<StockTakeInspectionResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);
            return PartialView("_PickingList");
        }

        #endregion

        #region PickingSorting

        /// <summary>
        /// Picking Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">SeqNum</param>        
        /// <returns></returns>
        [HttpPost]
        public ActionResult PickingSorting(SortingInfo sortInfo, int SeqNum)
        {
            //Lock TagNo
            ViewBag.LockTagNo = false;

            //Focus
            this.SetFocusId(SEARCH_TAG_NO);

            //Get search result from session
            IQueryable<StockTakeInspectionResults> list = (IQueryable<StockTakeInspectionResults>)this.Session[Constant.SESSION_LIST_DETAIL_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<StockTakeInspectionResults>(list, sortInfo, SeqNum, pageSize: this.pageSize, notStore: true);

            return PartialView("_PickingList");
        }

        #endregion

        #region Back

        /// <summary>
        /// Restore from Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult BackPicking(int SeqNum)
        {
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = SeqNum;
            return RedirectToAction("Index");
        }

        /// <summary>
        /// Back from Index
        /// </summary>        
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Back()
        {
            return RedirectToAction("Menu", "Menu");
        }

        #endregion

        #region Private

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {
            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                return false;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                return false;
            }

            tagNo = array[0];
            return true;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="model">StockTakeInspectionList Model</param>
        private void LoadData(StockTakeInspectionModels model)
        {
            //Search data                
            var results = this.tTakeInventoryDService.GetListPickingResults(UserSession.Session.LoginInfo.WarehouseCD, model.txt_LocationCD);

            //Store result into session
            this.Session[Constant.SESSION_LIST_DETAIL_RESULT + model.SeqNum.ToString()] = results;

            //Create sorting info
            var sortInfo = new SortingInfo
            {
                Url = SORT_URL_PICKING,
                SortField = SORT_DEFAULT,
                Direction = SortDirection.Descending,
            };

            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<StockTakeInspectionResults>(ref results, pageRequest, sortInfo, model.SeqNum, pageSize: this.pageSize, notStore: true);
        }

        /// <summary>
        /// Process Insert Data
        /// </summary>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagNo">branchTagNo</param>
        /// <param name="locationCD">locationCD</param>
        /// <returns></returns>
        private CommitFlag ProcessInsertData(string tagNo, string branchTagNo, string locationCD, string TakeStartDate)
        {
            try
            {
                TTakeInventory_D takeinvenD = this.tTakeInventoryDService.GetByPK(UserSession.Session.LoginInfo.WarehouseCD, locationCD, tagNo, branchTagNo);
                if (takeinvenD != null) //normal
                {
                    if (takeinvenD.TakeFlag != true)
                    {
                        takeinvenD.TakeStatus = Constant.TAKE_STATUS_NONE;
                        takeinvenD.TakeFlag = true;
                        takeinvenD.TakeDate = DateTime.Now.ToString(Constant.FMT_YMD);
                        takeinvenD.UpdateDate = this.GetCurrentDate();
                        takeinvenD.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    }
                    else
                    {
                        return CommitFlag.DataChanged;
                    }
                }
                else //redundancy
                {
                    TInventory_H inven = this.tInventoryHService.GetByPK(tagNo);
                    takeinvenD = new TTakeInventory_D();
                    takeinvenD.TagNo = tagNo;
                    takeinvenD.BranchTagNo = Convert.ToInt32(branchTagNo);
                    takeinvenD.TakeStatus = Constant.TAKE_STATUS_RECEIPTS;
                    takeinvenD.ProductCD = inven.ProductCD;
                    takeinvenD.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
                    takeinvenD.LocationCD = locationCD;
                    takeinvenD.StoredCost = inven.StoredCost;
                    takeinvenD.QuantityPerUnit = inven.QuantityPerUnit;
                    takeinvenD.UnitQuantity = inven.UnitQuantity;
                    takeinvenD.TotalCost = inven.TotalCost;
                    takeinvenD.LOT1 = inven.Lot1;
                    takeinvenD.LOT2 = inven.Lot2;
                    takeinvenD.LOT3 = inven.Lot3;
                    takeinvenD.TakeFlag = true;
                    takeinvenD.TakeStartDate = TakeStartDate;
                    takeinvenD.TakeDate = DateTime.Now.ToString(Constant.FMT_YMD);
                    takeinvenD.DeleteFlag = false;
                    takeinvenD.CreateDate = this.GetCurrentDate();
                    takeinvenD.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    takeinvenD.UpdateDate = takeinvenD.CreateDate;
                    takeinvenD.UpdateUCD = takeinvenD.CreateUCD;

                    this.tTakeInventoryDService.Insert(takeinvenD);
                }

                this.tTakeInventoryDService.Context.SubmitChanges();
            }            
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TTAKEINVENTORY_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }
        
        #endregion

        #region Public

        /// <summary>
        /// Show Location Name
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>
        [HttpPost]
        public string ShowLocationNm(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return string.Empty;
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);

            if (model != default(LocationModels) && model != null && !model.DeleteFlag)
            {
                return model.LocationName;
            }
            return string.Empty;
        }

        #endregion

        #region Exclusion

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="message">message error</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(StockTakeInspectionModels gmModel, string message)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/StockTakeInspection/Index", message: message);

            //Clear Session
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion Exclution
    }
}

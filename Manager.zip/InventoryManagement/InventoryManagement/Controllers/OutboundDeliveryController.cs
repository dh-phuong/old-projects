﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using System.Web.Helpers;
using InventoryManagement.Common;
using InventoryManagement.Validation;
using System.Data.Linq;
using System.Data.SqlClient;
using InventoryManagement.Utility;
using System.Transactions;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Outbound Delivery Controller
    /// Author: ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class OutboundDeliveryController : BaseController
    {
        #region Common

        private DataAccess.TShippingInstructionService tShippingInstructionService;
        private DataAccess.MCustomerService mCustomerService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.TReserveService tReserveService;
        private DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService;
        private DataAccess.TPessimisticLockService tPessimisticLockService;
        private DataAccess.MKind_DService mKind_DService;
        private bool isCheckShipNo;
        private int pageSize = 1;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tShippingInstructionService">tShippingInstructionService</param>
        /// <param name="mCustomerService">mCustomerService</param>        
        /// <param name="tInventory_DService">tInventory_DService</param>        
        /// <param name="tInventory_HService">tInventory_HService</param>        
        /// <param name="tSequencesService">tSequencesService</param>        
        /// <param name="tBalanceInStoresService">tBalanceInStoresService</param>        
        /// <param name="tReserveService">tReserveService</param>  
        /// <param name="tOutBoundDeliveredService">tOutBoundDeliveredService</param>
        /// <param name="tPessimisticLockService">tPessimisticLockService</param>
        public OutboundDeliveryController(DataAccess.TShippingInstructionService tShippingInstructionService,
                                          DataAccess.MCustomerService mCustomerService,
                                          DataAccess.TInventory_DService tInventory_DService,
                                          DataAccess.TInventory_HService tInventory_HService,
                                          DataAccess.TSequencesService tSequencesService,
                                          DataAccess.TBalanceInStoresService tBalanceInStoresService,
                                          DataAccess.TReserveService tReserveService,
                                          DataAccess.TOutBoundDeliveredService tOutBoundDeliveredService,
                                          DataAccess.TPessimisticLockService tPessimisticLockService,
                                          DataAccess.MKind_DService mKind_DService)
        {
            this.tShippingInstructionService = tShippingInstructionService;
            this.mCustomerService = mCustomerService;
            this.tInventory_DService = tInventory_DService;
            this.tInventory_HService = tInventory_HService;
            this.tSequencesService = tSequencesService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.tReserveService = tReserveService;
            this.tOutBoundDeliveredService = tOutBoundDeliveredService;
            this.tPessimisticLockService = tPessimisticLockService;
            this.mKind_DService = mKind_DService;

            //Use single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tShippingInstructionService.Context = ctx;
            this.mCustomerService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.tInventory_HService.Context = ctx;
            this.tSequencesService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.tReserveService.Context = ctx;
            this.tOutBoundDeliveredService.Context = ctx;
            this.tPessimisticLockService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.isCheckShipNo = this.mKind_DService.IsChecKShipNo();
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string PARTIAL_LIST = "_List";
        private const string PARTIAL_PICKING_DETAIL = "_PickingList";
        private const string KEY_PICKING_TAG_NO = "txt_TagNo";
        private const string KEY_SHIP_NO = "txt_ShipNo";

        private const string SCREEN_INDEX = "Index";
        private const string SCREEN_PICKING = "Picking";

        private const string SEARCH_SHIP_NO = "txt_ShipNo";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_DEFAULT_PICKING = "TagInfo";
        private const string SORT_DEFAULT_CANCEL = "DeliveryFlag";
        private const string SORT_URL_LIST = "/OutboundDelivery/Sorting";
        private const string SORT_URL_PICKING_DETAIL = "/OutboundDelivery/SortingDetail";

        private const string MODE_PICKING = "Picking";
        private const string MODE_CANCEL= "Cancel";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";

        #endregion

        #region Index

        /// <summary>
        /// List
        /// Author: ISV-GiAM
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(OutboundDeliveryList gmModel)
        {
            //Check Authority
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION)
                && !CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(OutboundDeliveryList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                OutboundDeliveryList oldModel = (OutboundDeliveryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(OutboundDeliveryList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Search data
                    IQueryable<OutboundDeliveryResults> results = this.tShippingInstructionService.GetListByConditionForOutboundDelivery(gmModel);

                    //Sorting
                    SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

                    //Paging
                    PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

                    this.PagingBase<OutboundDeliveryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                    //Focus
                    SetFocusId(SEARCH_SHIP_NO);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {
                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<OutboundDeliveryResults> results = this.tShippingInstructionService.GetListByConditionForOutboundDelivery(gmModel);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL_LIST,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<OutboundDeliveryResults>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize);

                //Focus
                this.SetFocusId(SEARCH_SHIP_NO);
            }

            return View(SCREEN_INDEX, gmModel);
        }

        /// <summary>
        /// Paging
        /// Author: ISV-GiAM
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>PartialView</returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveryResults> list = (IQueryable<OutboundDeliveryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<OutboundDeliveryResults>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView(PARTIAL_LIST);
        }

        /// <summary>
        /// Sorting
        /// Author: ISV-GiAM
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveryResults> list = (IQueryable<OutboundDeliveryResults>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<OutboundDeliveryResults>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView(PARTIAL_LIST);
        }

        #endregion

        #region Picking

        /// <summary>
        /// Sorting Picking List
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequense Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult SortingDetail(SortingInfo sortInfo, int SeqNum)
        {
            //Get search result from session
            IQueryable<OutboundDeliveryDetail> list = (IQueryable<OutboundDeliveryDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()];

            //Sorting
            this.SortingBase<OutboundDeliveryDetail>(list, sortInfo, SeqNum, list.Count(), SesionSortingKey: Constant.SESSION_DETAIL_SORTING, SesionPagingKey: Constant.SESSION_DETAIL_PAGING);

            return PartialView(PARTIAL_PICKING_DETAIL);
        }

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Picking(int SeqNum, string ShipNo)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_PICKING, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0168);

            //this.ClearModelState();

            //get Data Header
            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(ShipNo, this.isCheckShipNo);

            //Check exclusion
            if (model == default(OutboundDeliveryHeader))
            {
                return this.ExclusionProcess(SeqNum, null);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(SeqNum, message);
            }
            model.SeqNum = SeqNum;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Get Data Detail
            IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(ShipNo);

            this.SetSortAndPageging(ref results, SeqNum, SORT_DEFAULT_PICKING, SortDirection.Ascending);

            //Store Data Results 
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = results;


            //Set focus
            if (model.IsCheckShipNo)
            {
                this.SetFocusId(KEY_SHIP_NO);
            }
            else
            {
                this.SetFocusId(KEY_PICKING_TAG_NO); 
            }

            //set Mode
            model.Mode = MODE_PICKING;
            model.IsCorrectShipNo = !model.IsCheckShipNo;

            return View(SCREEN_PICKING, model);

        }

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult TagNoPicking(OutboundDeliveryHeader gmModel)
        {
            //get Data Header
            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(gmModel.ShipNoDB, gmModel.IsCheckShipNo);

            //Check exclusion
            if (model == default(OutboundDeliveryHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message);
            }

            //Get Data Results
            IQueryable<OutboundDeliveryDetail> list = (IQueryable<OutboundDeliveryDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(gmModel.ShipNoDB);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_PICKING, SortDirection.Ascending);
            }
            else
            {
                this.SetSortAndPageging(ref list, model.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
                {
                    // エラーメッセージを返す: {0}はデータベースに存在しません。
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (TagNoCheck(gmModel, dbModelInventory_H, dbModelInventory_D, list, true))
                {
                    //Update data
                    if (this.UpdateData(gmModel, dbModelInventory_D, list))
                    {
                        //Clear Focus ID
                        this.ClearFocusId();
                        message = this.FormatMessage(Constant.MES_M0041);
                        return ExclusionProcess(gmModel.SeqNum, message);
                    }
                    else if(ModelState.Where(x => x.Value.Errors.Count > 0).Count() == 0)
                    {
                        message = this.FormatMessage(Constant.MES_M0024);
                        this.ShowMessageInfo(message);
                    }
                }
            }
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region ShipNoPicking

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult ShipNoPicking(OutboundDeliveryHeader gmModel)
        {
            //get Data Header
            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(gmModel.ShipNoDB, gmModel.IsCheckShipNo);

            //Check exclusion
            if (model == default(OutboundDeliveryHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message);
            }

            //Get Data Results
            IQueryable<OutboundDeliveryDetail> list = (IQueryable<OutboundDeliveryDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(gmModel.ShipNoDB);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                string sortField = gmModel.Mode.Equals(MODE_PICKING) ? SORT_DEFAULT_PICKING : SORT_DEFAULT_CANCEL;
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortField, gmModel.Mode.Equals(MODE_PICKING) ? SortDirection.Ascending : SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                ////Clear
                //this.ClearModelState();

                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_ShipNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0146));
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Check Exist ShipNo
                TShippingInstruction modelS = this.tShippingInstructionService.GetByPk(gmModel.txt_ShipNo);
                if (modelS == default(TShippingInstruction) || modelS.DeleteFlag)
                {
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0146));
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                if (!gmModel.txt_ShipNo.Equals(gmModel.ShipNoDB))
                {
                    message = this.FormatMessage(Constant.MES_M0061);
                    this.ModelState.AddModelError(KEY_SHIP_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }
                else
                {
                    gmModel.IsCorrectShipNo = true;
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;
                }
                this.SetFocusId(KEY_PICKING_TAG_NO);
            }
            
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region Cancel

        /// <summary>
        /// Picking
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <param name="ShipNo">ShipNo</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Cancel(int SeqNum, string ShipNo)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_CANCEL, Constant.GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0169);

            //this.ClearModelState();

            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(ShipNo, this.isCheckShipNo);
            //Check exclusion
            if (model == default(OutboundDeliveryHeader))
            {
                return this.ExclusionProcess(SeqNum, null);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(SeqNum, message);
            }
            model.SeqNum = SeqNum;
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = model;

            //Search data
            IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(ShipNo);
            if(results.All(m=>!m.DeliveryFlag))
            {
                string message = this.FormatMessage(Constant.MES_M0044);
                return this.ExclusionProcess(SeqNum, message);
            }

            this.SetSortAndPageging(ref results, SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);

            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = results;

            //Set focus
            if (model.IsCheckShipNo)
            {
                this.SetFocusId(KEY_SHIP_NO);
            }
            else
            {
                this.SetFocusId(KEY_PICKING_TAG_NO);
            }

            model.Mode = MODE_CANCEL;
            model.IsCorrectShipNo = !model.IsCheckShipNo;

            return View(SCREEN_PICKING, model);

        }

        /// <summary>
        /// TagNo for Picking
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryHeader</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult TagNoCancel(OutboundDeliveryHeader gmModel)
        {
            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(gmModel.ShipNoDB, this.isCheckShipNo);
            //Check exclusion
            if (model == default(OutboundDeliveryHeader))
            {
                return this.ExclusionProcess(gmModel.SeqNum, null);
            }
            if (model.ShippingCompleteFlag)
            {
                string message = this.FormatMessage(Constant.MES_M0041);
                return this.ExclusionProcess(gmModel.SeqNum, message);
            }
            IQueryable<OutboundDeliveryDetail> list = (IQueryable<OutboundDeliveryDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(gmModel.ShipNoDB);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;

            if (this.ModelState.IsValid)
            {
                string message = string.Empty;
                if (string.IsNullOrEmpty(gmModel.txt_TagNo))
                {
                    message = this.FormatMessage(Constant.MES_E0002, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get info TagNo
                string tagNo = string.Empty;
                int branchTagNo = default(int);
                if (!this.CheckScreenTagNoInput(gmModel.txt_TagNo, ref tagNo, ref branchTagNo))
                {
                    // エラーメッセージを返す: {0}はデータベースに存在しません。
                    message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    return View(SCREEN_PICKING, gmModel);
                }

                //Get TInventory by TagInfo for Update
                TInventory_D dbModelInventory_D = this.tInventory_DService.GetByPK(tagNo, branchTagNo);
                TInventory_H dbModelInventory_H = this.tInventory_HService.GetByTagNo(tagNo);

                if (TagNoCheck(gmModel, dbModelInventory_H, dbModelInventory_D, list, false))
                {
                    //Update data
                    this.CancelData(gmModel, dbModelInventory_D, list, this.tInventory_HService.Context);
                    if (list.All(m => !m.DeliveryFlag))
                    {
                        //Clear Focus ID
                        this.ClearFocusId();
                        message = this.FormatMessage(Constant.MES_M0044);
                        return ExclusionProcess(gmModel.SeqNum, message);
                    }
                    else if(ModelState.Where(x => x.Value.Errors.Count > 0).Count() == 0)
                    {
                        message = this.FormatMessage(Constant.MES_M0024);
                        this.ShowMessageInfo(message);
                    }
                }
            }
            return View(SCREEN_PICKING, gmModel);
        }

        #endregion

        #region private

        /// <summary>
        /// Check Screen tag no input
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="screenTagNo">screenTagNo</param>
        /// <param name="tagNo">tagNo</param>
        /// <param name="branchTagno">branchTagno</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool CheckScreenTagNoInput(string screenTagNo, ref string tagNo, ref int branchTagno)
        {
            //Get info TagNo
            string[] array = screenTagNo.Split(Constant.HYPHEN_CHAR);
            if (array.Length != 2)
            {
                return false;
            }
            if (!CommonUtil.TryParseInt(array[1], ref branchTagno))
            {
                return false;
            }

            tagNo = array[0];
            return true;
        }

        /// <summary>
        /// Set Sort and Pageging
        /// </summary>
        /// <param name="list">list GoodsIssueInspectionDetail</param>
        /// <param name="SeqNum">SeqNum</param>
        private void SetSortAndPageging(ref IQueryable<OutboundDeliveryDetail> list, int SeqNum, string sortField, SortDirection direction)
        {
            //Create sorting info
            SortingInfo sortInfo = new SortingInfo
            {
                Url = SORT_URL_PICKING_DETAIL,
                SortField = sortField,
                Direction = direction,
            };
            //Paging
            PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
            this.PagingBase<OutboundDeliveryDetail>(ref list, pageRequest, sortInfo, SeqNum, list.Count(), SesionSortingKey: Constant.SESSION_DETAIL_SORTING, SesionPagingKey: Constant.SESSION_DETAIL_PAGING);
        }

        #endregion

        #region public

        /// <summary>
        /// Show Customer Name
        /// Author: ISV-GIAM
        /// </summary>
        /// <param name="customerCD">CustomerCD</param>
        /// <returns>Customer Name</returns>        
        public JsonResult ShowCustomerName(string customerCD)
        {
            if (string.IsNullOrEmpty(customerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerModels model = this.mCustomerService.GetByCd(customerCD.ToUpper());

            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                {
                    model.CustomerName
                    
                }, JsonRequestBehavior.AllowGet);

            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion Ajax

        #region Check

        /// <summary>
        /// TagNo Check
        /// </summary>
        /// <param name="gmModel">OutboundDeliveryHeader</param>
        /// <param name="dbModel_H">TInventory_H</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">List OutboundDeliveryDetail</param>
        /// <param name="isPicking">is Pick Flag</param>
        /// <returns>Bool</returns>
        private bool TagNoCheck(OutboundDeliveryHeader gmModel, TInventory_H dbModel_H, TInventory_D dbModel_D, IQueryable<OutboundDeliveryDetail> list, bool isPicking)
        {
            //Check Exist Data
            if (dbModel_D == default(TInventory_D))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            //Check Data is Deleted
            else if (dbModel_H.DeleteFlag)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0006, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            //The input tag number is not exist shipping instruction.
            else if (string.IsNullOrEmpty(dbModel_D.ShippingNo) || !dbModel_D.ShippingNo.Equals(gmModel.ShipNoDB))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0030, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0202));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            // This {0} is already loaded. Please read of next the {0}.
            else if (dbModel_D.DeliveryFlag == true && isPicking)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0035, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            else if (!dbModel_D.DeliveryFlag == true && !isPicking)
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0045);
                this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                return false;
            }
            else
            {
                //Check UpdatedDate
                foreach (OutboundDeliveryDetail detail in list)
                {
                    if (gmModel.txt_TagNo.Equals(detail.TagInfo))
                    {
                        if (!dbModel_D.UpdateDate.Equals(detail.UpdateDate))
                        {
                            // エラーメッセージを返す: TagInfo is Updated
                            string message = this.FormatMessage(Constant.MES_M0003, UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
                            this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                            return false;
                        }
                    }
                }
            }
            return true;
        }

        #endregion Check

        #region Registration

        /// <summary>
        /// Update DeliveryFlg
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateDeliveryFlg(TInventory_D dbModel_D)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                //Update DeliveryFlg
                dbModel_D.DeliveryFlag = true;
                dbModel_D.StockStatus = Constant.STOCK_STATUS_DELIVERY; // 40:出庫 -> 50:出荷
                dbModel_D.UpdateDate = curDate;
                dbModel_D.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                //Insert TBalanceInStores
                //TSequences
                //string balanceNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));

                //Insert TBalanceInStores
                string arrivalDate = DateTime.Now.ToString(Constant.FMT_YMD);
                TBalanceInStores balanceinstoresModel = this.GetInsertTBalanceInStores(dbModel_D, arrivalDate, curDate, true);
                this.tBalanceInStoresService.Insert(balanceinstoresModel);
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Update CompleteFlg
        /// </summary>
        /// <param name="dbModel">TShippingInstruction</param>
        /// <param name="gmModel">OutboundDeliveryHeader</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag UpdateCompleteFlg(OutboundDeliveryHeader gmModel)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                //Update Shipping Complete Flag
                TShippingInstruction dbShipH = this.tShippingInstructionService.GetByPk(gmModel.ShipNoDB);
                if (dbShipH == default(TShippingInstruction) || dbShipH.UpdateDate != gmModel.UpdateDate)
                {
                    return CommitFlag.DataChanged;
                }
                dbShipH.ShippingCompleteFlag = true;
                dbShipH.UpdateDate = curDate;
                dbShipH.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                //Delete TReserve
                IQueryable<TReserve> listReserve = this.tReserveService.GetListByShipNo(gmModel.ShipNoDB);

                foreach (var item in listReserve)
                {
                    this.tReserveService.Delete(item);
                }

                //Insert TOutBoundDelivered
                IQueryable<TInventory_D> listData = this.tInventory_DService.GetListByShipNo(gmModel.ShipNoDB);
                foreach (var item in listData)
                {
                    TOutBoundDelivered newData = new TOutBoundDelivered();
                    newData.TagNo = item.TagNo;
                    newData.BranchTagNo = item.BranchTagNo;
                    newData.ShippingNo = item.ShippingNo;
                    newData.ShippingDetailNo = item.ShippingDetailNo;
                    newData.DeleteFlag = false;
                    newData.CreateDate = curDate;
                    newData.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    newData.UpdateDate = curDate;
                    newData.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                    this.tOutBoundDeliveredService.Insert(newData);
                }
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                if (sqlEx.Message.Contains(Constant.DB_TSHIPPINGINSTRUCTION_PK))
                {
                    return CommitFlag.DataChanged;
                }

                //Write Log
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                //Write Log
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">ShipmentPickingHeader</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">list ShipmentPickingDetail</param>
        /// <returns></returns>
        private bool UpdateData(OutboundDeliveryHeader gmModel, TInventory_D dbModel_D, IQueryable<OutboundDeliveryDetail> list)
        {
            bool ret = true;
            string message = string.Empty;

            using (TransactionScope trans = new TransactionScope())
            {
                try
                {
                    //Add lock
                    TPessimisticLock modelPLock = new TPessimisticLock();
                    modelPLock.TagNo = dbModel_D.TagNo;
                    this.tPessimisticLockService.Insert(modelPLock);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Update DeliveryFlg
                    switch (this.UpdateDeliveryFlg(dbModel_D))
                    {
                        case CommitFlag.DataChanged:
                            message = this.FormatMessage(Constant.MES_M0003);
                            this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                            ret = false;
                            break;

                        case CommitFlag.Success:
                            this.tShippingInstructionService.Context.SubmitChanges();
                            this.SetFocusId(KEY_PICKING_TAG_NO);

                            gmModel.txt_TagNo = null;
                            break;

                        default:
                            message = this.FormatMessage(Constant.MES_M0011);
                            this.ModelState.AddModelError(string.Empty, message);
                            ret = false;
                            break;
                    }
                    if (!ret)
                    {
                        return ret;
                    }

                    if (this.tShippingInstructionService.IsShipCompleteByDetail(gmModel.ShipNoDB))
                    {
                        //Update CompleteFlg
                        switch (this.UpdateCompleteFlg(gmModel))
                        {
                            case CommitFlag.DataChanged:
                                message = this.FormatMessage(Constant.MES_M0003);
                                this.ModelState.AddModelError(string.Empty, message);
                                ret = false;
                                break;

                            case CommitFlag.Success:

                                ret = true;
                        
                                //Remove lock
                                this.tPessimisticLockService.Delete(modelPLock);
                                this.tShippingInstructionService.Context.SubmitChanges();

                                trans.Complete();
                                break;

                            default:
                                message = this.FormatMessage(Constant.MES_M0011);
                                this.ModelState.AddModelError(string.Empty, message);
                                ret = false;
                                break;
                        }
                    }
                    else
                    {
                        //Remove lock
                        this.tPessimisticLockService.Delete(modelPLock);
                        this.tShippingInstructionService.Context.SubmitChanges();

                        trans.Complete();

                        ret = false;
                    }
                }
                 catch (ChangeConflictException)
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    ret = false;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    ret = false;                    
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = false;
                }
                finally
                {
                    trans.Dispose();
                }
            }
            return ret;
        }

        /// <summary>
        /// Get data TBalanceInStores for Insert      
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="balanceNo">BalanceNo</param>
        /// <param name="balanceDate">curren date</param>
        /// <param name="curDate">curren date</param>
        /// <returns>TBalanceInStores</returns>
        private TBalanceInStores GetInsertTBalanceInStores(TInventory_D dbModel_D, string balanceDate, string curDate, bool isPicking)
        {
            TBalanceInStores result = new TBalanceInStores();

            //result.BalanceNo = balanceNo;
            if (isPicking)
            {
                result.BalanceStatus = Constant.BALANCE_STATUS_SHIPPING;
            }
            else 
            {
                result.BalanceStatus = Constant.BALANCE_STATUS_GOODS_ISSUE;
            }
            result.BalanceDate = balanceDate;
            result.TagNo = dbModel_D.TagNo;
            result.BranchTagNo = dbModel_D.BranchTagNo;
            result.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            result.LocationCD = dbModel_D.LocationCD;
            result.CreateDate = curDate;
            result.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            result.UpdateDate = curDate;
            result.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

            return result;
        }

        #region Cancel

        /// <summary>
        /// Cancel Data
        /// </summary>
        /// <param name="gmModel">ShipmentPickingHeader</param>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="list">list ShipmentPickingDetail</param>
        /// <param name="dc">DataContext</param>
        /// <returns></returns>
        private bool CancelData(OutboundDeliveryHeader gmModel, TInventory_D dbModel_D, IQueryable<OutboundDeliveryDetail> list, DataClasses1DataContext dc)
        {
            bool ret = true;
            string message = string.Empty;

            //Cancel DeliveryFlg
            switch (this.CancelDeliveryFlg(dbModel_D, dc))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(KEY_PICKING_TAG_NO, message);
                    ret = false;
                    break;

                case CommitFlag.Success:
                    dc.SubmitChanges();
                    this.SetFocusId(KEY_PICKING_TAG_NO);

                    gmModel.txt_TagNo = null;
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0011);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = false;
                    break;
            }
            return ret;
        }

        /// <summary>
        /// Update DeliveryFlg
        /// </summary>
        /// <param name="dbModel_D">TInventory_D</param>
        /// <param name="dc">DataContext</param>
        /// <returns>Success, DataChanged, Failed</returns>
        private CommitFlag CancelDeliveryFlg(TInventory_D dbModel_D, DataClasses1DataContext dc)
        {
            string curDate = this.GetCurrentDate();
            using (TransactionScope trans = new TransactionScope())
            {

                try
                {
                    //insert TPessimisticLock
                    TPessimisticLock modelPLock = new TPessimisticLock();
                    modelPLock.TagNo = dbModel_D.TagNo;
                    this.tPessimisticLockService.Insert(modelPLock);
                    this.tPessimisticLockService.Context.SubmitChanges();

                    //Cancel DeliveryFlg
                    dbModel_D.DeliveryFlag = false;
                    dbModel_D.StockStatus = Constant.STOCK_STATUS_ISSUE; //50:出荷 -> 40:出庫 
                    dbModel_D.UpdateDate = curDate;
                    dbModel_D.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;

                    //delete TBalanceInStores
                    List<string> statusList = new List<string>() { Constant.BALANCE_STATUS_SHIPPING};
                    TBalanceInStores modelB = this.tBalanceInStoresService.GetNewestData(dbModel_D.TagNo, dbModel_D.BranchTagNo, statusList);
                    if (modelB != default(TBalanceInStores))
                    {
                        modelB.DeleteFlag = true;
                    }

                    this.tPessimisticLockService.Delete(modelPLock);
                    this.tShippingInstructionService.Context.SubmitChanges();

                    trans.Complete();

                }
                catch (ChangeConflictException)
                {
                    return CommitFlag.DataChanged;
                }
                catch (SqlException sqlEx)
                {
                    if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK) || sqlEx.Message.Contains(Constant.DB_TPESSIMISTICLOCK_PK))
                    {
                        return CommitFlag.DataChanged;
                    }

                    //Write Log
                    Log.WriteLog(sqlEx);
                    return CommitFlag.Failed;
                }
                catch (Exception ex)
                {
                    //Write Log
                    Log.WriteLog(ex);
                    return CommitFlag.Failed;
                }
                finally
                {
                    trans.Dispose();
                }
            }

            return CommitFlag.Success;
        }

        #endregion

        #endregion Registration

        #region Exclusion

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="message">message error</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum, string message)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/OutboundDelivery/Index", message: message);

            OutboundDeliveryHeader model = (OutboundDeliveryHeader)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(OutboundDeliveryHeader))
            {
                model = new OutboundDeliveryHeader();
                model.SeqNum = SeqNum;
            }
            else
            {
                model.txt_ShipNo = model.ShipNoDB;
            }

            //Clear Session
            this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()] = null;
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + SeqNum.ToString()] = null;

            return View(SCREEN_PICKING, model);
        }

        #endregion Exclution

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="SeqNum">SeqNum</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(OutboundDeliveryHeader gmModel)
        {
            this.ClearModelState();
            OutboundDeliveryHeader model = this.tShippingInstructionService.GetDeliveryHeaderByShipNo(gmModel.ShipNoDB, this.isCheckShipNo);
            //Check exclusion
            if (model == default(OutboundDeliveryHeader) || model.ShippingCompleteFlag)
            {
                return BackAction(gmModel.SeqNum.ToString());
            }
            
            IQueryable<OutboundDeliveryDetail> list = (IQueryable<OutboundDeliveryDetail>)this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()];
            if (list == default(IQueryable))
            {
                //Search data
                IQueryable<OutboundDeliveryDetail> results = this.tInventory_DService.GetListOutboundDeliveryDetail(gmModel.ShipNoDB);
                list = results;
            }

            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_DETAIL_SORTING + gmModel.SeqNum.ToString()];

            if (sortInfo == default(SortingInfo))
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, SORT_DEFAULT_CANCEL, SortDirection.Descending);
            }
            else
            {
                this.SetSortAndPageging(ref list, gmModel.SeqNum, sortInfo.SortField, sortInfo.Direction);
            }

            //Store result into session
            this.Session[Constant.SESSION_DELIVERY_PICKING_DETAIL + gmModel.SeqNum.ToString()] = list;


            if (gmModel.Mode.Equals(MODE_CANCEL))
            {
                return BackAction(gmModel.SeqNum.ToString()); 

                //if (list.All(m => !m.DeliveryFlag))
                //{
                //    return BackAction(gmModel.SeqNum.ToString()); 
                //}
            }

            string message = this.FormatMessage(Constant.MES_M0025);

            //Show message confirm
            this.ShowMessageConfirm(gmModel.SeqNum, "/OutboundDelivery/BackAction", message: message, value1: gmModel.SeqNum.ToString());
            return View(SCREEN_PICKING, gmModel);

        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult BackAction(string value1)
        {
            this.ClearModelState();
            this.Session[Constant.SESSION_DETAIL_SORTING + value1] = null;

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value1);
            return RedirectToAction("Index");
        }

        #endregion Back

    }
}

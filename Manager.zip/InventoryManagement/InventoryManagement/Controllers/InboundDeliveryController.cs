﻿using System.Linq;
using System.Web.Mvc;
using InventoryManagement.Models;
using System;
using System.Collections;
using System.Data.Linq;
using System.Data.SqlClient;
using System.IO;
using System.Web.Helpers;

using InventoryManagement.Common;
//using InventoryManagement.DAC;
using InventoryManagement.Utility;
using InventoryManagement.Validation;
using System.Collections.Generic;
using System.Drawing;
using Microsoft.Reporting.WebForms;

namespace InventoryManagement.Controllers
{

    /// <summary>
    /// InboundDelivery Controller
    /// Author : ISV-Nho
    /// </summary>
    [InventoryManagement.Validation.iAuthorize]
    public class InboundDeliveryController : BaseController
    {

        #region Common

        private DataAccess.TInventory_HService tInventory_HService;
        private DataAccess.TInventory_DService tInventory_DService;
        private DataAccess.MProductService mProductService;
        private DataAccess.MLocationService mLocationService;
        private DataAccess.TSequencesService tSequencesService;
        private DataAccess.TBalanceInStoresService tBalanceInStoresService;
        private DataAccess.MKind_DService mKind_DService;
        private DataAccess.MCustomerService mCustomerService;
        private bool isShowSup;
        private int pageSize = 1;

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="TInventoryService">TInventoryService</param>
        /// <param name="MProductService">MProductService</param>
        /// <param name="MLocationService">MLocationService</param>
        /// <param name="TSequencesService">TSequencesService</param>
        /// <param name="TBalanceInStoresService">TBalanceInStoresService</param>
        public InboundDeliveryController(DataAccess.TInventory_HService tInventory_HService,
                                         DataAccess.TInventory_DService tInventory_DService,
                                         DataAccess.MProductService mProductService,
                                         DataAccess.MLocationService mLocationService,
                                         DataAccess.TSequencesService tSequencesService,
                                         DataAccess.TBalanceInStoresService tBalanceInStoresService,
                                         DataAccess.MKind_DService mKind_DService,
                                         DataAccess.MCustomerService mCustomerService)
        {
            this.tInventory_HService = tInventory_HService;
            this.tInventory_DService = tInventory_DService;
            this.mProductService = mProductService;
            this.mLocationService = mLocationService;
            this.tSequencesService = tSequencesService;
            this.tBalanceInStoresService = tBalanceInStoresService;
            this.mKind_DService = mKind_DService;
            this.mCustomerService = mCustomerService;

            //User single data context
            Models.DataClasses1DataContext ctx = InventoryManagement.DataAccess.DbServices.CreateContext();
            this.tInventory_HService.Context = ctx;
            this.tInventory_DService.Context = ctx;
            this.mProductService.Context = ctx;
            this.mLocationService.Context = ctx;
            //this.tSequencesService.Context = ctx;
            this.tBalanceInStoresService.Context = ctx;
            this.mKind_DService.Context = ctx;
            this.mCustomerService.Context = ctx;
            this.isShowSup = this.mKind_DService.IsShowCustomer();
            this.pageSize = this.mKind_DService.GetPageSizeOfGrid();
        }

        #endregion

        #region Constant

        private const string SRH_DAY_FROM = "SrhArrivalDateFrom_Day";

        private const string KEY_PRODUCT_CD = "ProductCD";
        private const string KEY_SUPLIER_CD = "SuplierCD";
        private const string KEY_LOCATION_CD = "LocationCD";
        private const string KEY_BALANCE_STATUS = "BalanceStatus";

        private const string SORT_DEFAULT = "UpdateDate";
        private const string SORT_DEFAULT_2 = "TagInfo";
        private const string SORT_URL = "/InboundDelivery/Sorting";

        private const string CHK_FIRST_ROW = "checkFirst";   

        private const string PRINT_ACTION_URL = "/InboundDelivery/PrintAction";
        private const string PATH_LARGE_REPORT = "~/Report/LargeTagLabel.rdlc";
        private const string PATH_SMALL_REPORT = "~/Report/SmallTagLabel.rdlc";

        private const string BUTTON_EDIT = "btnEdit";

        //Temp data keys
        private const string TEMP_SEQNUM = "Temp_SeqNum";
        #endregion

        #region Index

        /// <summary>
        /// List action
        /// </summary>
        /// <param name="gmModel">InboundDeliveryList</param>
        /// <returns>ActionResult</returns>
        [iHttpParamAction]
        public ActionResult Index(InboundDeliveryList gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }

            //Sort model state
            this.SortModelState(typeof(InboundDeliveryList));

            //Check form back call
            bool isFormBack = false;
            if (this.IsFormBack())
            {
                gmModel.SeqNum = (int)this.TempData[TEMP_SEQNUM];

                //Get model
                InboundDeliveryList oldModel = (InboundDeliveryList)this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()];
                if (oldModel != default(InboundDeliveryList))
                {
                    gmModel = oldModel;
                    isFormBack = true;

                    //Restore Paging Sorting
                    this.RestorePagingSorting(gmModel);

                    //Focus
                    SetFocusId(SRH_DAY_FROM);
                }
            }

            //Create new sequence key
            if (gmModel.SeqNum == default(int))
            {
                gmModel.SeqNum = UserSession.Session.CreateSequenceNumber();
            }

            //Store Print Hastable
            this.Session[Constant.SESSION_PRINT_ITEM + gmModel.SeqNum.ToString()] = new Hashtable();
            gmModel.IsShowSuplier = this.isShowSup;

            //Check search data
            if (this.ModelState.IsValid && !isFormBack)
            {

                //Store condition
                this.Session[Constant.SESSION_LIST_CONDITION + gmModel.SeqNum.ToString()] = gmModel;

                //Search data
                IQueryable<InboundDeliveryResult> results = this.tInventory_HService.GetListInboundDeliveryByConditions(gmModel);

                //Create sorting info
                SortingInfo sortInfo = new SortingInfo
                {
                    Url = SORT_URL,
                    SortField = SORT_DEFAULT,
                    Direction = SortDirection.Descending,
                };

                //Paging
                PagingRequest pageRequest = new PagingRequest { page = 1, isFirst = true, isLast = false };
                this.PagingBase<InboundDeliveryResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize, orderField2: SORT_DEFAULT_2);

                //Store result into session
                this.Session[Constant.SESSION_LIST_RESULT + gmModel.SeqNum.ToString()] = results;

                //Focus
                SetFocusId(SRH_DAY_FROM);
            }

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], gmModel.SeqNum);
                ViewBag.IsDownload = true;
            }

            return View("Index", gmModel);
        }

        /// <summary>
        /// Paging
        /// </summary>
        /// <param name="pageRequest">Paging Request</param>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Paging(PagingRequest pageRequest, SortingInfo sortInfo, int SeqNum)
        {
            var gmModel = new InboundDeliveryList();

            //Get search result from session
            IQueryable<InboundDeliveryResult> list = (IQueryable<InboundDeliveryResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Paging
            this.PagingBase<InboundDeliveryResult>(ref list, pageRequest, sortInfo, SeqNum, pageSize: this.pageSize);
            return PartialView("_List", gmModel);
        }

        /// <summary>
        /// Sorting
        /// </summary>
        /// <param name="sortInfo">SortingInfo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Sorting(SortingInfo sortInfo, int SeqNum)
        {
            var gmModel = new InboundDeliveryList();

            //Get search result from session
            IQueryable<InboundDeliveryResult> list = (IQueryable<InboundDeliveryResult>)this.Session[Constant.SESSION_LIST_RESULT + SeqNum.ToString()];

            //Sorting
            this.SortingBase<InboundDeliveryResult>(list, sortInfo, SeqNum, pageSize: this.pageSize);

            return PartialView("_List", gmModel);
        }

        #endregion

        #region Create

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="TagNo">TagNo</param>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [iHttpParamAction]
        [HttpPost]
        public ActionResult Insert(string TagNo, int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0093);

            //Set mode state
            this.SetMode(Common.Mode.Insert, SeqNum);

            //Set focus
            if (this.isShowSup)
            {
                this.SetFocusId(KEY_SUPLIER_CD);
            }
            else
            {
                this.SetFocusId(KEY_PRODUCT_CD); 
            }

            //Set data display
            InboundDeliveryModels gmModel = new InboundDeliveryModels();
            gmModel.TagNo = TagNo;
            gmModel.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            gmModel.ArrivalDate = DateTime.Now.ToString(Constant.FMT_DATE);
            gmModel.UnitQuantity = "1";
            gmModel.SeqNum = SeqNum;
            gmModel.IsShowSuplier = this.isShowSup;


            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Confirm
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="TypePrintFrom">Type Print From : List or Detail</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult InsertConfirm(InboundDeliveryModels gmModel, string TypePrintFrom)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/InboundDelivery/InsertAction", value1: gmModel.SeqNum.ToString(), value2: TypePrintFrom);
                }
            }

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Insert Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <param name="value2">TypePrintFrom</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult InsertAction(string value1, string value2)
        {
            //Get data from session
            InboundDeliveryModels gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            //Insert check
            if (this.InsertCheck(gmModel))
            {
                //insert data
                ActionResult ret = default(ActionResult);
                string message = string.Empty;
                switch (this.InsertData(gmModel))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = InsertConfirm(gmModel, value2);
                        break;

                    case CommitFlag.Success:
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0009);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = InsertConfirm(gmModel, value2);
                        break;
                }

                return ret;
            }
            else
            {
                return View("Details", gmModel);
            }
        }

        /// <summary>
        /// Insert Check
        /// </summary>
        /// <param name="model">InboundDeliveryModels</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool InsertCheck(InboundDeliveryModels model)
        {
            bool ret = true;

            //Check Exist SuplierCD
            if (!string.IsNullOrEmpty(model.SuplierCD) && model.IsShowSuplier)
            {
                if (!this.mCustomerService.ExistCustomerCD(model.SuplierCD, false))
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0288));
                    this.ModelState.AddModelError(KEY_SUPLIER_CD, message);
                    model.SuplierName = string.Empty;
                    ret = false;
                }
            }

            //Check Exist ProductCD
            if (!this.mProductService.IsExistsProduct(model.ProductCD))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                model.ProductName = string.Empty;
                ret = false;
            }

            //Check Exist LocationCD
            if (!String.IsNullOrEmpty(model.LocationCD))
            {
                model.LocationName = string.Empty;
                LocationModels modelL = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, model.LocationCD);
                if (modelL == default(LocationModels) || modelL.DeleteFlag)
                {
                    string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                    this.ModelState.AddModelError(KEY_LOCATION_CD, message);
                    ret = false;
                }
                else
                {
                    model.LocationName = modelL.LocationName;
                    if (modelL.ReceiptProhibitionFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0017, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                        this.ModelState.AddModelError(KEY_LOCATION_CD, message);
                        ret = false;
                    }
                }

            }

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag InsertData(InboundDeliveryModels gmModel)
        {
            //Get insert model
            string curDate = this.GetCurrentDate();
            string newTagNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_TAGNO, curDate.Substring(2, 4));
            try
            {
                TInventory_H modelH = this.GetInsertDataH(gmModel, newTagNo, curDate);
                this.tInventory_HService.Insert(modelH);

                for (int i = 0; i < CommonUtil.ParseInteger(gmModel.UnitQuantity); i++)
                {
                    //insert inventory
                    TInventory_D modelD = this.GetInsertDataD(gmModel, newTagNo, i + 1, curDate);
                    this.tInventory_DService.Insert(modelD);

                    //insert BalanceInStore
                    //string newBalanNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));
                    TBalanceInStores modelB = this.GetInsertDataB(modelH, modelD, gmModel.BalanceStatus);
                    this.tBalanceInStoresService.Insert(modelB);
                }

                this.tInventory_HService.Context.SubmitChanges();

                //var dac = new DAC.TInventory_H();

                //ResultType ret = dac.InboundDeliveryInsert(gmModel);

                //if (ret == ResultType.Fail)
                //{

                //    return CommitFlag.Failed;
                //}

                //if (ret == ResultType.DuplicateCode || ret == ResultType.DataChangedByOrther)
                //{
                //    return CommitFlag.DataChanged;
                //}

            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK) || sqlEx.Message.Contains(Constant.DB_TSEQUENCES_PK))
                {
                    return CommitFlag.DataChanged;
                }

                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Get insert Data
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="newTagNo">New TagNo</param>
        /// <param name="BranchTagNo">Branch TagNo</param>
        /// <param name="curDate">Current Date</param>
        /// <returns>TInventory</returns>
        private Models.TInventory_H GetInsertDataH(InboundDeliveryModels gmModel, string newTagNo, string curDate)
        {
            Models.TInventory_H result = new Models.TInventory_H();

            result.TagNo = newTagNo;
            result.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            result.ArrivalDate = DateTime.Now.ToString(Constant.FMT_YMD);
            result.ProductCD = gmModel.ProductCD;
            if (gmModel.IsShowSuplier)
            {
                result.CustomerCD = MCustomer.FixCodeDB(gmModel.SuplierCD);
            }
            result.QuantityPerUnit = CommonUtil.ParseDecimal(gmModel.QuantityPerUnit);
            result.StoredCost = CommonUtil.ParseDecimal(gmModel.StoredCost);
            result.UnitQuantity = CommonUtil.ParseInteger(gmModel.UnitQuantity);
            result.TotalCost = CommonUtil.ParseDecimal(gmModel.TotalCost);
            result.Lot1 = gmModel.Lot1;
            result.Lot2 = gmModel.LOT2Date.DateValue();
            result.Lot3 = gmModel.LOT3Date.DateValue();
            result.Memo = gmModel.Memo;
            result.DeleteFlag = false;

            return result;
        }

        /// <summary>
        /// Get insert Data
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="newTagNo">New TagNo</param>
        /// <param name="BranchTagNo">Branch TagNo</param>
        /// <param name="curDate">Current Date</param>
        /// <returns>TInventory</returns>
        private TInventory_D GetInsertDataD(InboundDeliveryModels gmModel, string newTagNo, int BranchTagNo, string curDate)
        {
            TInventory_D result = new TInventory_D();

            result.TagNo = newTagNo;
            result.BranchTagNo = BranchTagNo;
            result.StockStatus = Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE;
            //result.ReserveStatus = Constant.RESERVE_STATUS_NOT_RESERVE;
            result.LocationCD = gmModel.LocationCD;
            result.TagPrintFlag = false;
            result.PickingFlag = false;
            result.DeliveryPrintFlag = false;
            result.DeliveryFlag = false;
            result.CreateDate = curDate;
            result.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            result.UpdateUCD = result.CreateUCD;
            result.UpdateDate = result.CreateDate;

            return result;
        }

        /// <summary>
        /// Get insert Data For TBalanceInStores
        /// </summary>
        /// <param name="modelD">TInventory</param>
        /// <param name="newBalanNo">new BalanNo</param>
        /// <returns>TBalanceInStores</returns>
        private TBalanceInStores GetInsertDataB(Models.TInventory_H modelH, TInventory_D modelD, string balanceStatus)
        {
            TBalanceInStores result = new TBalanceInStores();

            //result.BalanceNo = newBalanNo;
            result.BalanceStatus = balanceStatus;
            result.BalanceDate = modelH.ArrivalDate;
            result.TagNo = modelD.TagNo;
            result.BranchTagNo = modelD.BranchTagNo;
            result.WarehouseCD = modelH.WarehouseCD;
            result.LocationCD = modelD.LocationCD;
            result.DeleteFlag = modelH.DeleteFlag;
            result.CreateDate = modelD.UpdateDate;
            result.CreateUCD = UserSession.Session.LoginInfo.User.UserCD;
            result.UpdateUCD = result.CreateUCD;
            result.UpdateDate = result.CreateDate;

            return result;
        }

        #endregion

        #region View

        /// <summary>
        /// Show
        /// </summary>
        /// <param name="value1">Tag No</param>
        /// <param name="value2">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Show(string value1, int value2)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_VIEW_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + value2] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0092);

            //Set ModeState
            SetMode(Common.Mode.Show, value2);

            //Get data
            InboundDeliveryModels model = this.tInventory_HService.GetInboundDeliveryByTagNo(value1);

            //Check exclusion
            if (model == default(InboundDeliveryModels))
            {
                return this.ExclusionProcess(value2);
            }

            //Store model into session
            model.SeqNum = value2;
            this.Session[Constant.SESSION_DETAIL_MODEL + model.SeqNum.ToString()] = model;

            //Set focus
            //this.SetFocusId(BUTTON_EDIT);

            if (TempData[TMP_DOWNLOAD_FILE] != null)
            {
                this.StoreFileDownload((FileContentResult)TempData[TMP_DOWNLOAD_FILE], model.SeqNum);
                ViewBag.IsDownload = true;
            }
            model.IsShowSuplier = this.isShowSup;

            return View("Details", model);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Update(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_UPDATE_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0095);

            //Get data
            InboundDeliveryModels gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            InboundDeliveryModels ArrModels = this.tInventory_HService.GetInboundDeliveryByTagNo(gmModel.TagNo);

            if (ArrModels != default(InboundDeliveryModels) && ArrModels.isNotArr)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0026));
                return Show(gmModel.TagNo, gmModel.SeqNum);
            }

            //Check Exclusion
            if (ArrModels == default(InboundDeliveryModels) || gmModel.UpdateDate != ArrModels.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, ArrModels.BalanceStatus);

            //Set mode state
            this.SetMode(Common.Mode.Update, SeqNum);

            //Set focus
            if (this.isShowSup)
            {
                this.SetFocusId(KEY_SUPLIER_CD);
            }
            else
            {
                this.SetFocusId(KEY_PRODUCT_CD);
            }

            ArrModels.SeqNum = SeqNum;
            ArrModels.IsShowSuplier = this.isShowSup;

            return View("Details", ArrModels);
        }

        /// <summary>
        /// Update Confirm
        /// </summary>
        /// <param name="gmModel">InboundDeliveryList</param>
        /// <param name="TypePrintFrom">Type Print Form : List or Detail</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult UpdateConfirm(InboundDeliveryModels gmModel, string TypePrintFrom)
        {
            if (this.ModelState.IsValid)
            {
                //Update check
                if (this.UpdateCheck(gmModel))
                {
                    //Store data into session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show confirm message
                    this.ShowMessageConfirm(gmModel.SeqNum, "/InboundDelivery/UpdateAction", value1: gmModel.SeqNum.ToString(), value2: TypePrintFrom);
                }
            }

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Update Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <param name="value2">Type Print From : List or Detail</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateAction(string value1, string value2)
        {
            //Get screen model from session
            InboundDeliveryModels gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            //Update check
            if (this.UpdateCheck(gmModel))
            {
                //Update data
                string message = string.Empty;
                ActionResult ret = default(ActionResult);
                switch (this.UpdateData(gmModel))
                {
                    case CommitFlag.DataChanged:
                        this.ShowMessageExclusion("/InboundDelivery/Show", gmModel.TagNo, gmModel.SeqNum.ToString());
                        ret = View("Details", gmModel);
                        break;

                    case CommitFlag.Success:
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0011);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = UpdateConfirm(gmModel, value2);
                        break;
                }

                return ret;
            }
            else
            {
                return View("Details", gmModel);
            }
        }

        /// <summary>
        /// Update Check
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <returns>TRUE: Valid, FALSE: Invalid</returns>
        private bool UpdateCheck(InboundDeliveryModels gmModel)
        {
            //Check data changed
            if (!this.CheckDataChanged(gmModel))
            {
                return false;
            }

            bool ret = true;

            //Check Exist SuplierCD
            if (!string.IsNullOrEmpty(gmModel.SuplierCD) && gmModel.IsShowSuplier)
            {
                if (!this.mCustomerService.ExistCustomerCD(gmModel.SuplierCD, false))
                {
                    // エラーメッセージを返す
                    string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0288));
                    this.ModelState.AddModelError(KEY_SUPLIER_CD, message);
                    gmModel.SuplierName = string.Empty;
                    ret = false;
                }
            }

            //Check Exist ProductCD
            if (!this.mProductService.IsExistsProduct(gmModel.ProductCD))
            {
                // エラーメッセージを返す
                string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
                this.ModelState.AddModelError(KEY_PRODUCT_CD, message);
                gmModel.ProductName = string.Empty;
                ret = false;
            }

            //Check Exist LocationCD
            if (!String.IsNullOrEmpty(gmModel.LocationCD))
            {
                LocationModels modelL = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, gmModel.LocationCD);
                gmModel.LocationName = string.Empty;
                if (modelL == default(LocationModels) || modelL.DeleteFlag)
                {
                    string message = this.FormatMessage(Constant.MES_M0001, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                    this.ModelState.AddModelError(KEY_LOCATION_CD, message);
                    ret = false;
                }
                else
                {
                    gmModel.LocationName = modelL.LocationName;
                    if (modelL.ReceiptProhibitionFlag)
                    {
                        string message = this.FormatMessage(Constant.MES_M0017, InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.LBL_L0051));
                        this.ModelState.AddModelError(KEY_LOCATION_CD, message);
                        ret = false;
                    }
                }

            }

            return ret;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag UpdateData(InboundDeliveryModels gmModel)
        {
            string curDate = this.GetCurrentDate();
            try
            {
                Models.TInventory_H modelH = this.tInventory_HService.GetByTagNo(gmModel.TagNo);
                IQueryable<TInventory_D> listDetail = this.tInventory_DService.GetListByTagNo(gmModel.TagNo);

                if (modelH == default(Models.TInventory_H) || listDetail.Any(m => m.UpdateDate.CompareTo(gmModel.UpdateDate) > 0 || !m.StockStatus.Equals(Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)))
                {
                    return CommitFlag.DataChanged;
                }

                int newSize = CommonUtil.ParseInteger(gmModel.UnitQuantity);
                int curSize = listDetail.Count();

                var listU = listDetail.Where(m => m.BranchTagNo <= newSize);
                var listD = listDetail.Where(m => m.BranchTagNo > newSize);

                this.SetUpdateDataH(modelH, gmModel, curDate);

                foreach (var item in listU)
                {
                    TBalanceInStores modelBD = this.tBalanceInStoresService.GetByConditionsForInboundDelivery(item.TagNo, item.BranchTagNo);

                    this.SetUpdateDataD(item, gmModel, curDate);

                    //update data
                    this.SetUpdateBalanceStore(modelBD, modelH, gmModel.LocationCD, curDate, gmModel.BalanceStatus);
                }
                foreach (var item in listD)
                {
                    TBalanceInStores modelBD = this.tBalanceInStoresService.GetByConditionsForInboundDelivery(item.TagNo, item.BranchTagNo);

                    //delete Inve and banlanceInstore
                    this.tInventory_DService.Delete(item);
                    this.tBalanceInStoresService.Delete(modelBD);
                }

                //insert new item for inven and BalanceInStore
                for (int i = listDetail.Count() + 1; i <= newSize; i++)
                {
                    var modelI = SetUpdateDataInsert(listDetail.FirstOrDefault(), gmModel, i);
                    this.tInventory_DService.Insert(modelI);

                    //string newBalanNo = this.tSequencesService.GetNewMaxTagNoByTagNoDivision(Constant.TAGNO_DIVISION_BALANCENO, curDate.Substring(2, 4));
                    TBalanceInStores modelB = this.GetInsertDataB(modelH, modelI, gmModel.BalanceStatus);
                    this.tBalanceInStoresService.Insert(modelB);
                }

                this.tInventory_HService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            gmModel.UpdateDate = curDate;
            return CommitFlag.Success;
        }

        /// <summary>
        /// Set update data
        /// </summary>
        /// <param name="model">TInventory</param>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="curDate">Current Date</param>
        private void SetUpdateDataH(Models.TInventory_H model, InboundDeliveryModels gmModel, string curDate)
        {
            model.ProductCD = gmModel.ProductCD;
            if (gmModel.IsShowSuplier)
            {
                model.CustomerCD = MCustomer.FixCodeDB(gmModel.SuplierCD);
            }
            model.QuantityPerUnit = CommonUtil.ParseDecimal(gmModel.QuantityPerUnit);
            model.StoredCost = CommonUtil.ParseDecimal(gmModel.StoredCost);
            model.UnitQuantity = CommonUtil.ParseInteger(gmModel.UnitQuantity);
            model.TotalCost = CommonUtil.ParseDecimal(gmModel.TotalCost);
            model.Lot1 = gmModel.Lot1;
            model.Lot2 = gmModel.LOT2Date.DateValue();
            model.Lot3 = gmModel.LOT3Date.DateValue();
            model.Memo = gmModel.Memo;
            model.DeleteFlag = gmModel.DeleteFlag;
        }

        /// <summary>
        /// Set update data
        /// </summary>
        /// <param name="model">TInventory</param>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="curDate">Current Date</param>
        private void SetUpdateDataD(TInventory_D model, InboundDeliveryModels gmModel, string curDate)
        {
            model.LocationCD = gmModel.LocationCD;
            model.UpdateDate = curDate;
            model.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Set Update BalanceStore
        /// </summary>
        /// <param name="modelB">TBalanceInStores</param>
        /// <param name="modelI">TInventory</param>
        private void SetUpdateBalanceStore(TBalanceInStores modelB, Models.TInventory_H modelI, string locationCD, string curDate, string balanceStatus)
        {
            modelB.BalanceStatus = balanceStatus;
            modelB.LocationCD = locationCD;
            modelB.DeleteFlag = modelI.DeleteFlag;
            modelB.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
            modelB.UpdateDate = curDate;
        }

        /// <summary>
        /// Set update data
        /// </summary>
        /// <param name="oldModel">Old Data</param>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <param name="branchTagNo">BranchTagNo</param>
        /// <param name="curDate">Current Date</param>
        private TInventory_D SetUpdateDataInsert(TInventory_D oldModel, InboundDeliveryModels gmModel, int branchTagNo)
        {
            TInventory_D model = new TInventory_D();

            model.TagNo = oldModel.TagNo;
            model.BranchTagNo = branchTagNo;
            model.StockStatus = oldModel.StockStatus;
            model.LocationCD = gmModel.LocationCD;
            model.StoredDate = oldModel.StoredDate;
            model.ShippingNo = oldModel.ShippingNo;
            model.ShippingDetailNo = oldModel.ShippingDetailNo;
            //model.ReserveStatus = oldModel.ReserveStatus;
            model.TagPrintFlag = false;
            model.PickingFlag = oldModel.PickingFlag;
            model.DeliveryPrintFlag = oldModel.DeliveryPrintFlag;
            model.DeliveryFlag = oldModel.DeliveryFlag;
            model.CreateDate = oldModel.CreateDate;
            model.CreateUCD = oldModel.CreateUCD;
            model.UpdateDate = oldModel.UpdateDate;
            model.UpdateUCD = oldModel.UpdateUCD;

            return model;
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete confirm
        /// </summary>
        /// <param name="gmModel">LocationModels</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult DeleteConfirm(InboundDeliveryModels gmModel)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_DELETE_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }
            //Get data
            InboundDeliveryModels dbModel = this.tInventory_HService.GetInboundDeliveryByTagNo(gmModel.TagNo);
            //Check Exclusion
            if (dbModel == default(InboundDeliveryModels) || gmModel.UpdateDate != dbModel.UpdateDate)
            {
                return this.ExclusionProcess(gmModel.SeqNum);
            }
            dbModel.BranchTagNo = gmModel.BranchTagNo;
            dbModel.UpdateDate = gmModel.UpdateDate;
            dbModel.SeqNum = gmModel.SeqNum;
            dbModel.PrintSize = gmModel.PrintSize;
            dbModel.TagPrintFlag = gmModel.TagPrintFlag;

            if (!dbModel.isNotArr)
            {
                //Set mode state
                this.SetMode(Common.Mode.Delete, gmModel.SeqNum);

                //Show confirm message
                this.ShowMessageConfirm(gmModel.SeqNum, "/InboundDelivery/DeleteAction", value1: gmModel.SeqNum.ToString());
            }
            else
            {
                //Cant delete data
                this.ModelState.AddModelError(string.Empty, UserSession.Session.SysCache.GetMessage(Constant.MES_M0027));
            }

            return View("Details", dbModel);
        }

        /// <summary>
        /// Delete Confirm
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult DeleteAction(string value1)
        {
            //Get model from session
            InboundDeliveryModels model = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()];

            if (model != default(InboundDeliveryModels) && model.isNotArr)
            {
                this.ModelState.AddModelError(string.Empty, this.FormatMessage(Constant.MES_M0027));
                return Show(model.TagNo, model.SeqNum);
            }

            //Delete data
            string message = String.Empty;
            ActionResult ret = default(ActionResult);
            switch (this.DeleteData(model))
            {
                case CommitFlag.DataChanged:
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.TagNo, model.SeqNum);
                    break;

                case CommitFlag.Success:
                    this.Session[Constant.SESSION_DETAIL_MODEL + value1.ToString()] = null;
                    ret = RedirectToAction("index");
                    break;

                default:
                    message = this.FormatMessage(Constant.MES_M0007);
                    this.ModelState.AddModelError(string.Empty, message);
                    ret = Show(model.TagNo, model.SeqNum);
                    break;
            }

            return ret;
        }

        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="model">InboundDeliveryModels</param>
        /// <returns>TRUE: success, FALSE: failed</returns>
        private CommitFlag DeleteData(InboundDeliveryModels gmModel)
        {
            try
            {
                Models.TInventory_H modelH = this.tInventory_HService.GetByTagNo(gmModel.TagNo);
                IQueryable<TInventory_D> listDetail = this.tInventory_DService.GetListByTagNo(gmModel.TagNo);

                if (modelH == default(Models.TInventory_H) || listDetail.Any(m => m.UpdateDate.CompareTo(gmModel.UpdateDate) > 0 || !m.StockStatus.Equals(Constant.STOCK_STATUS_ARRIVAL_NON_DEFECTIVE)))
                {
                    return CommitFlag.DataChanged;
                }
                string curDate = this.GetCurrentDate();

                this.SetDeleteData(modelH, curDate);


                foreach (var item in listDetail)
                {
                    TBalanceInStores modelDB = this.tBalanceInStoresService.GetByConditionsForInboundDelivery(modelH.TagNo, item.BranchTagNo);

                    //Set delete data
                    this.SetDeleteDataD(item, curDate);
                    this.SetDeleteBalanceStore(modelDB, item);
                }
                this.tInventory_HService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                return CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    return CommitFlag.DataChanged;
                }
                Log.WriteLog(sqlEx);
                return CommitFlag.Failed;
            }
            catch (Exception ex)
            {
                Log.WriteLog(ex);
                return CommitFlag.Failed;
            }

            return CommitFlag.Success;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="model">TInventory</param>
        /// <param name="curDate">Current Date</param>
        private void SetDeleteData(Models.TInventory_H model, string curDate)
        {
            model.DeleteFlag = true;
        }

        /// <summary>
        /// Set delete data
        /// </summary>
        /// <param name="model">TInventory</param>
        /// <param name="curDate">Current Date</param>
        private void SetDeleteDataD(TInventory_D model, string curDate)
        {
            model.UpdateDate = curDate;
            model.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
        }

        /// <summary>
        /// Set delete BalanceStore
        /// </summary>
        /// <param name="modelB">TBalanceInStores</param>
        /// <param name="modelI">TInventory</param>
        private void SetDeleteBalanceStore(TBalanceInStores modelB, TInventory_D modelI)
        {
            modelB.DeleteFlag = true;
            modelB.UpdateDate = modelI.UpdateDate;
            modelB.UpdateUCD = modelI.UpdateUCD;
        }

        #endregion

        #region Back

        /// <summary>
        /// Restore
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Back(InboundDeliveryModels gmModel)
        {
            this.ClearModelState();
            if (!String.IsNullOrEmpty(gmModel.TagNo) && this.GetMode(gmModel.SeqNum) != Mode.Show && this.GetMode(gmModel.SeqNum) != Mode.Delete)
            {
                return this.Show(gmModel.TagNo, gmModel.SeqNum);
            }
            else
            {
                //Set is form back
                this.SetFormBack();
                this.TempData[TEMP_SEQNUM] = gmModel.SeqNum;
                return RedirectToAction("Index");
            }
        }

        #endregion

        #region Copy

        /// <summary>
        /// Copy
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Copy(int SeqNum)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_INSERT_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }
            //Set title
            this.Session[Constant.SESSION_TITLE + SeqNum.ToString()] = UserSession.Session.SysCache.GetLabel(Constant.LBL_L0093);

            //Set mode state
            this.SetMode(Common.Mode.Copy, SeqNum);

            //Get data
            InboundDeliveryModels model = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            model.WarehouseCD = UserSession.Session.LoginInfo.WarehouseCD;
            model.ArrivalDate = DateTime.Now.ToString(Constant.FMT_DATE);

            //Set Sequence Number
            model.SeqNum = SeqNum;

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, model.BalanceStatus);

            //Set focus
            this.SetFocusId(KEY_BALANCE_STATUS);

            return View("Details", model);
        }

        /// <summary>
        /// Copy Confirm
        /// </summary>
        /// <param name="gmModel">InboundDelivery Model</param>/param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult CopyConfirm(InboundDeliveryModels gmModel)
        {
            if (this.ModelState.IsValid)
            {
                //Insert check
                if (this.InsertCheck(gmModel))
                {
                    //Store model into Session
                    this.Session[Constant.SESSION_DETAIL_MODEL + gmModel.SeqNum.ToString()] = gmModel;

                    //Show message confirm
                    this.ShowMessageConfirm(gmModel.SeqNum, "/InboundDelivery/CopyAction", value1: gmModel.SeqNum.ToString());
                }
            }

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            return View("Details", gmModel);
        }

        /// <summary>
        /// Copy Action
        /// </summary>
        /// <param name="value1">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CopyAction(string value1)
        {
            //Get data from session
            InboundDeliveryModels gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value1];

            //Set DropDown
            this.SetViewBagBalanceStatus(KEY_BALANCE_STATUS, gmModel.BalanceStatus);

            //Insert check
            if (this.InsertCheck(gmModel))
            {
                //insert data
                string message = String.Empty;
                ActionResult ret = default(ActionResult);
                switch (this.InsertData(gmModel))
                {
                    case CommitFlag.DataChanged:
                        message = this.FormatMessage(Constant.MES_M0003);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = CopyConfirm(gmModel);
                        break;

                    case CommitFlag.Success:
                        this.Session[Constant.SESSION_DETAIL_MODEL + value1] = null;
                        ret = RedirectToAction("index");
                        break;

                    default:
                        message = this.FormatMessage(Constant.MES_M0009);
                        this.ModelState.AddModelError(string.Empty, message);
                        ret = CopyConfirm(gmModel);
                        break;
                }

                return ret;
            }
            else
            {
                return View("Details", gmModel);
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Restore Paging Sorting
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="SeqNum">Sequense number</param>
        /// <param name="results">results</param>
        private void RestorePagingSorting(InboundDeliveryList gmModel)
        {
            //Search data
            IQueryable<InboundDeliveryResult> results = this.tInventory_HService.GetListInboundDeliveryByConditions(gmModel);

            //Sorting
            SortingInfo sortInfo = (SortingInfo)this.Session[Constant.SESSION_LIST_SORTING + gmModel.SeqNum.ToString()];

            //Paging
            PagingRequest pageRequest = (PagingRequest)this.Session[Constant.SESSION_LIST_PAGING + gmModel.SeqNum.ToString()];

            this.PagingBase<InboundDeliveryResult>(ref results, pageRequest, sortInfo, gmModel.SeqNum, pageSize: this.pageSize, orderField2: SORT_DEFAULT_2);
        }

        /// <summary>
        /// Set BalanceStatus SelectList
        /// </summary>
        /// <param name="control">control</param>
        /// <param name="RoleCD">BalanceStatus</param>
        private void SetViewBagBalanceStatus(string control, string BalanceStatus)
        {
            IOrderedQueryable<MKind_D> dropSrc = this.mKind_DService.GetListByDataKind(Common.Constant.MKIND_KINDCD_BALANCE_STATUS);
            dropSrc = (IOrderedQueryable<MKind_D>)dropSrc.Where(m => m.DataCD.Equals(Constant.BALANCE_STATUS_ARRIVAL) || m.DataCD.Equals(Constant.BALANCE_STATUS_RETURN_ARRIVAL) || m.DataCD.Equals(Constant.BALANCE_STATUS_MOVES_ARRIVAL));
            SelectOption option = new SelectOption("value", "dataCD", control, BalanceStatus);
            this.SetViewDataDropdownList<Models.MKind_D>(option, dropSrc);
        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="gmModel">InboundDeliveryModels</param>
        /// <returns>TRUE: changed, FALSE: Not change</returns>
        private bool CheckDataChanged(InboundDeliveryModels gmModel)
        {
            bool exist = this.tInventory_HService.CheckDataChanged(gmModel);
            if (exist)
            {
                //Show error Message
                this.ShowMessageExclusion("/InboundDelivery/Show", gmModel.TagNo, gmModel.SeqNum.ToString());
                return false;
            }

            return true;
        }

        #endregion

        #region public method

        /// <summary>
        /// Show TotalCost
        /// Author: ISV-Thuy
        /// </summary>
        /// <param name="UnitQuantity">UnitQuantity</param>
        /// <param name="QuantityPerUnit">QuantityPerUnit</param>
        /// <param name="ProductCD">ProductCD</param>
        /// <param name="StoredCost">StoredCost</param>
        /// <param name="isShowCost">isShowCost</param>
        /// <returns></returns>
        public JsonResult ShowTotalCost(string UnitQuantity, string QuantityPerUnit, string ProductCD, string StoredCost, bool isShowCost)
        {
            bool isErr = false;
            decimal dcCost = 0;
            decimal dcStoredCost = 0;
            int intUnitQuantity = 0;
            decimal dcQuantityPerUnit = 0;
            decimal dcTotalCost = 0;
            int maxlength = 0;
            try
            {

                #region QuantityPerUnit
                
                #endregion

                if (CommonUtil.TryParseDecimal(QuantityPerUnit, ref dcQuantityPerUnit))
                {
                    QuantityPerUnit = String.Format(Constant.FMT_DECIMAL_FULL, dcQuantityPerUnit);
                }
                else
                {
                    if (CommonUtil.IsNumber(QuantityPerUnit))
                    {
                        maxlength = Constant.MPRODUCT_QUANTITY_PER_UNIT_PRECISION;
                        maxlength += (int)Math.Ceiling((double)(Constant.MPRODUCT_QUANTITY_PER_UNIT_PRECISION - Constant.MPRODUCT_QUANTITY_PER_UNIT_SCALE) / 3);
                        QuantityPerUnit = string.Empty.PadLeft(maxlength, '#');
                    }                            
                    isErr = true;
                }



                if (CommonUtil.TryParseInt(UnitQuantity, ref intUnitQuantity))
                {
                    UnitQuantity = intUnitQuantity.ToString();
                    if (CommonUtil.CheckScale(intUnitQuantity, 0))
                    {
                        UnitQuantity = string.Format(Constant.NUMBER_FORMAT_INT, intUnitQuantity);
                    }
                }
                else
                {
                    if (CommonUtil.IsNumber(UnitQuantity))
                    {
                        UnitQuantity = string.Empty.PadLeft(14, '#');
                    }  
                }

                JsonResult retError = Json(new List<string>()
                                            {                        
                                                QuantityPerUnit,
                                                string.Empty,
                                                UnitQuantity,                            
                                                string.Empty

                                            }, JsonRequestBehavior.AllowGet);

                if (isShowCost)
                {
                    ProductModels model = this.mProductService.GetByCd(ProductCD);

                    if (model != default(object) && !model.DeleteFlag)
                    {

                        if (CommonUtil.TryParseDecimal(model.Cost, ref dcCost))
                        {
                            dcStoredCost = dcCost * dcQuantityPerUnit;
                            StoredCost = String.Format(Constant.FMT_DECIMAL_FULL, dcStoredCost);
                        }
                        else
                        {
                            return retError;
                        }
                    }
                    else
                    {
                        return retError;
                    }
                }
                else
                {
                    if (!CommonUtil.TryParseDecimal(StoredCost, ref dcStoredCost))
                    {
                        return retError;
                    }
                    else
                    {
                        StoredCost = String.Format(Constant.FMT_DECIMAL_FULL, dcStoredCost);
                    }
                }

                string TotalCost = string.Empty;

                if (CommonUtil.TryParseInt(UnitQuantity, ref intUnitQuantity) && !isErr)
                {
                    try
                    {
                        dcTotalCost = dcStoredCost * intUnitQuantity;
                        TotalCost = String.Format(Constant.FMT_DECIMAL_FULL, dcTotalCost);
                    }
                    catch (OverflowException)
                    {
                        TotalCost = string.Empty.PadLeft(decimal.MaxValue.ToString().Length, '#');                        
                    }                                     
                }
                return Json(new List<string>()
                {
                        
                    QuantityPerUnit,
                    StoredCost,
                    UnitQuantity,
                    TotalCost

                }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {

                return Json(string.Empty, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// Show Product Name
        /// Author: ISV-Thuy
        /// </summary>
        /// <param name="ProductCD">ProductCD</param>
        /// <returns>Product Name</returns>        
        public JsonResult ShowProductNm(string ProductCD)
        {
            if (string.IsNullOrEmpty(ProductCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            ProductModels model = this.mProductService.GetByCd(ProductCD);

            if (model != default(ProductModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                {
                    model.ProductName,
                    model.QuantityPerUnit
                    
                }, JsonRequestBehavior.AllowGet);

            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Show Location Name
        /// Author: ISV-Thuy
        /// </summary>
        /// <param name="LocationCD">LocationCD</param>
        /// <returns>Location Name</returns>
        [HttpPost]
        public string ShowLocationNm(string LocationCD)
        {
            if (string.IsNullOrEmpty(LocationCD))
            {
                return string.Empty;
            }

            LocationModels model = this.mLocationService.GetByCd(UserSession.Session.LoginInfo.WarehouseCD, LocationCD);

            if (model != default(LocationModels) && model != null && !model.DeleteFlag)
            {
                return model.LocationName;
            }
            return string.Empty;
        }

        /// <summary>
        /// Show CustomerName
        /// </summary>
        /// <param name="CustomerCD">CustomerCD</param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult ShowCustomerNm(string CustomerCD)
        {
            if (string.IsNullOrEmpty(CustomerCD))
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }

            CustomerCD = CustomerCD.ToUpper();
            CustomerModels model = this.mCustomerService.GetByCd(CustomerCD);

            if (model != default(CustomerModels) && model != null && !model.DeleteFlag)
            {
                return Json(new List<string>()
                    {
                        model.CustomerName,
                        model.Address1,
                        model.Address2,
                        model.Address3
                    }, JsonRequestBehavior.AllowGet);
            }
            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Print -- ISV-TRUC

        #region constant
        public const string IS_BIG_PRINT = "BIG";
        public const string IS_SMALL_PRINT = "SMALL";
        public const int BRANCH_TAG_NO_SHOW_PRINT = 4;
        #endregion

        /// <summary>
        /// Change Print All
        /// </summary>
        /// <param name="CheckedFlag">CheckedFlag</param>
        /// <param name="seqNum">Sequence Number</param>
        [HttpPost]
        public void ChangePrintAll(bool CheckedFlag, int seqNum)
        {
            var listTagNo = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];

            //Clear list location
            listTagNo.Clear();

            //Add Location
            if (CheckedFlag)
            {
                IQueryable<InboundDeliveryResult> results = (IQueryable<InboundDeliveryResult>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];

                foreach (var row in results.Where(m => !m.DeleteData))
                {
                    listTagNo.Add(row.TagInfo, true);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = listTagNo;
        }

        /// <summary>
        /// Change Print Item
        /// </summary>
        /// <param name="TagInfo">TagInfo</param>
        /// <param name="CheckedFlag">CheckedFlag</param>
        /// <param name="seqNum">Sequence Number</param>
        /// <returns></returns>
        [HttpPost]
        public bool ChangePrintItem(string TagInfo, bool CheckedFlag, int seqNum)
        {
            var listTagNo = (Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()];

            //Add Location
            if (CheckedFlag)
            {
                if (!listTagNo.ContainsKey(TagInfo))
                {
                    listTagNo.Add(TagInfo, true);
                }
            }
            else
            {
                //Remmove Location
                if (listTagNo.ContainsKey(TagInfo))
                {
                    listTagNo.Remove(TagInfo);
                }
            }

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + seqNum.ToString()] = listTagNo;
            IQueryable<InboundDeliveryResult> results = (IQueryable<InboundDeliveryResult>)this.Session[Constant.SESSION_LIST_RESULT + seqNum.ToString()];
            var checkAll = (listTagNo.Count == results.Count(m => !m.DeleteData));
            return checkAll;
        }

        /// <summary>
        /// Print
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="TypePrintFrom">TypePrintFrom</param>
        /// <returns></returns>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult Print(int SeqNum, string TypePrintFrom)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }

            //Set size for form print
            PrintTypeFlag PrintFlag = this.SetPrintSize();
            var StrPrintFlg = Convert.ToUInt16(PrintFlag).ToString();

            //Print from List
            InboundDeliveryList gmSearchModel = null;
            InboundDeliveryModels gmModel = null;
            if (TypePrintFrom.Equals(Constant.PRINT_TYPE_LIST))
            {
                //Get data for Search Model
                gmSearchModel = (InboundDeliveryList)this.Session[Constant.SESSION_LIST_CONDITION + SeqNum.ToString()];

                bool TagPrintListFlag = false;
                //Get list selected from screen                
                var SelectedRows = ((Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + SeqNum.ToString()]).Keys.OfType<string>().ToList();

                int SelectedRowsCount = SelectedRows.Count;

                //TagInfo=TagNo-BranchTagNo
                string TagInfo = string.Empty;

                //Set data for Model as form detail
                if (SelectedRowsCount == 1)
                {
                    TagInfo = (string)SelectedRows[0];
                    //Get data
                    gmModel = tInventory_HService.GetByTagInfo(TagInfo);
                    TagPrintListFlag = gmModel.TagPrintFlag;
                }
                else if (SelectedRowsCount < 1)
                {
                    //Not choose any row yet
                    this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));
                   

                    //Restore Paging Sorting
                    this.RestorePagingSorting(gmSearchModel);
                    return View("Index", gmSearchModel);
                }
                this.ShowMessageForPrint(SeqNum, TagPrintListFlag, PrintFlag, StrPrintFlg, TypePrintFrom);

                //Store data for screen
                gmSearchModel.PrintSize = PrintFlag;
                this.RestorePagingSorting(gmSearchModel);

                return View("Index", gmSearchModel);
            }
            //Print from detail            
            gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];

            //Check model exists in database
            InboundDeliveryModels ExistsModels = this.tInventory_HService.GetInboundDeliveryByTagNo(gmModel.TagNo);

            if (ExistsModels == default(InboundDeliveryModels) || gmModel.UpdateDate != ExistsModels.UpdateDate)
            {
                return this.ExclusionProcess(SeqNum);
            }

            var ListItems = new Hashtable();
            string TagInfoPrint = gmModel.TagNo + Constant.HYPHEN + FixCode(gmModel.BranchTagNo.ToString(), 4);

            ListItems.Add(TagInfoPrint, true);

            gmModel.PrintSize = PrintFlag;

            //Store in sesstion
            this.Session[Constant.SESSION_PRINT_ITEM + SeqNum] = ListItems;
            this.ShowMessageForPrint(SeqNum, gmModel.TagPrintFlag, PrintFlag, StrPrintFlg, TypePrintFrom);
            return View("Details", gmModel);
        }

        /// <summary>
        /// Print
        /// Author : ISV-Vinh
        /// </summary>
        [HttpPost]
        [iHttpParamAction]
        public ActionResult PrintList(InboundDeliveryList model)
        {
            //Check Authority
            if (!CommonUtil.CheckAuthority(Constant.GROUP_ROLE_EXPORT_CD, Constant.GROUP_VIEW_INBOUND_DELIVERY))
            {
                return this.RedirectNotAuthority();
            }

            this.ClearModelState();

            //Set size for form print
            PrintTypeFlag PrintFlag = this.SetPrintSize();
            var StrPrintFlg = Convert.ToUInt16(PrintFlag).ToString();

            InboundDeliveryModels gmModel = null;
            //Get data for Search Model
             InboundDeliveryList gmSearchModel = (InboundDeliveryList)this.Session[Constant.SESSION_LIST_CONDITION + model.SeqNum.ToString()];

            bool TagPrintListFlag = false;
            //Get list selected from screen                
            var SelectedRows = ((Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + model.SeqNum.ToString()]).Keys.OfType<string>().ToList();

            int SelectedRowsCount = SelectedRows.Count;

            //TagInfo=TagNo-BranchTagNo
            string TagInfo = string.Empty;

            //Set data for Model as form detail
            if (SelectedRowsCount == 1)
            {
                TagInfo = (string)SelectedRows[0];
                //Get data
                gmModel = tInventory_HService.GetByTagInfo(TagInfo);
                TagPrintListFlag = gmModel.TagPrintFlag;
            }
            else if (SelectedRowsCount < 1)
            {
                //Not choose any row yet
                this.ModelState.AddModelError(CHK_FIRST_ROW, InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0014));


                //Restore Paging Sorting
                this.RestorePagingSorting(gmSearchModel);
                return View("Index", model);
            }
            this.ShowMessageForPrint(model.SeqNum, TagPrintListFlag, PrintFlag, StrPrintFlg, Common.Constant.PRINT_TYPE_LIST);

            //Store data for screen
            gmSearchModel.PrintSize = PrintFlag;
            this.RestorePagingSorting(gmSearchModel);

            return View("Index", model);
        }

        /// <summary>
        ///  Print Action
        ///  Author : ISV-TRUC
        /// </summary>
        /// <param name="value1">Type Print From</param>
        /// <param name="value2">Print Size</param>
        /// <param name="value3">Sequence Number</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        public ActionResult PrintAction(string value1, string value2, string value3)
        {
            string tagNoDetail = string.Empty;

            var SelectedRows = ((Hashtable)this.Session[Constant.SESSION_PRINT_ITEM + value3]).Keys.OfType<string>().OrderBy(m => m).ToList();

            List<InboundDeliveryModels> ReportSource = null;
            InboundDeliveryList gmSearchModel = new InboundDeliveryList();

            if (value1.Equals(Constant.PRINT_TYPE_LIST))
            {
                gmSearchModel = (InboundDeliveryList)this.Session[Constant.SESSION_LIST_CONDITION + value3];
                ReportSource = this.tInventory_HService.GetListByTagNosFromList(SelectedRows).ToList();
            }
            else
            {
                tagNoDetail = this.SplitTagNo(SelectedRows[0]);
                ReportSource = this.tInventory_HService.GetListByTagNoForPrint(tagNoDetail).ToList();
            }

            var Count = ReportSource.Count;

            if (Count > 0)
            {
                //Report dataset
                Report.DataObject.TagLabelDataSet DataSet = new Report.DataObject.TagLabelDataSet();

                //Report Source
                var tblEvent = DataSet._TagLabelDataSet.Clone();
                var tblOdd = DataSet._TagLabelDataSet.Clone();
                //Get data for report source
                for (int i = 0; i < Count; i++)
                {
                    var item = ReportSource[i];
                    if (i % 2 == 0)//Even
                    {
                        var newRow = tblEvent.NewRow();
                        this.InitDataForRow(ref newRow, item, (i + 1));
                        tblEvent.Rows.Add(newRow);
                    }
                    else//Odd
                    {
                        var newRow = tblOdd.NewRow();
                        this.InitDataForRow(ref newRow, item, (i + 1));
                        tblOdd.Rows.Add(newRow);
                    }
                }

                //Report
                LocalReport localReport = new LocalReport();

                //Print Size
                PrintTypeFlag PrintType = (PrintTypeFlag)Convert.ToInt16(value2);

                //Download file name
                var filename = string.Empty;

                //Choose report
                if (PrintType == PrintTypeFlag.Big)
                {
                    localReport.ReportPath = Server.MapPath(PATH_LARGE_REPORT);
                    filename = string.Format("TagLabel_Large_{0}.pdf", DateTime.Now.ToString(Constant.FMT_DMY));
                }
                else if (PrintType == PrintTypeFlag.Small)
                {
                    localReport.ReportPath = Server.MapPath(PATH_SMALL_REPORT);
                    filename = string.Format("TagLabel_Small_{0}.pdf", DateTime.Now.ToString(Constant.FMT_DMY));
                }

                //Report source
                ReportDataSource Even = new ReportDataSource("Even", tblEvent);
                ReportDataSource Odd = new ReportDataSource("Odd", tblOdd);

                localReport.DataSources.Add(Even);
                localReport.DataSources.Add(Odd);

                //Set parameter
                localReport.SetParameters(this.InitParamsForReport());

                //Set Printed Flag      
                var UpdateResult = CommitFlag.Success;

                if (value1.Equals(Constant.PRINT_TYPE_LIST))
                    UpdateResult = UpdatePrintFlag(SelectedRows);
                else
                    UpdateResult = UpdatePrintFlagSingle(tagNoDetail);

                //Output file for download
                if (UpdateResult == CommitFlag.Success)
                {
                    var file = this.PDFOutPut(localReport, filename, Common.ReportType.Barcode, true);
                    TempData[TMP_DOWNLOAD_FILE] = file;
                }
            }

            if (value1.Equals(Constant.PRINT_TYPE_DETAIL))
            {
                //Get data
                InboundDeliveryModels gmModel = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + value3];

                //Check exclusion
                if (gmModel == default(InboundDeliveryModels))
                {
                    return this.ExclusionProcess(int.Parse(value3));
                }

                return this.Show(gmModel.TagNo, int.Parse(value3));
            }

            //Set is form back
            this.SetFormBack();
            this.TempData[TEMP_SEQNUM] = int.Parse(value3);
            return RedirectToAction("Index");
        }

        #region Private Methods For Print

        /// <summary>
        ///  Show Message For Print base in PrintFlag
        ///  Author : ISV-TRUC
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <param name="TagPrintFlag">TagPrintFlag</param>
        /// <param name="PrintFlag">PrintFlag</param>
        /// <param name="StrPrintFlg">PrintTypeFlag</param>
        /// <param name="TypePrintFrom">TypePrintFrom</param>
        private void ShowMessageForPrint(int SeqNum, bool TagPrintFlag, PrintTypeFlag PrintFlag, string StrPrintFlg, string TypePrintFrom)
        {
            switch (PrintFlag)
            {
                case PrintTypeFlag.None:

                    string printAppend = "<div id='PrintOption'>";
                    printAppend += "<div>" +
                                            "<input type='radio' name='PrintType' id='rdoLarge' checked='checked'>" +
                                            "<lable for ='rdoLarge'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.BTN_B0018) + "</lable>" +
                                      "</div>";
                    printAppend += "<div>" +
                                            "<input type='radio' name='PrintType' id='rdoSmall'>" +
                                            "<lable for ='rdoSmall'>" + InventoryManagement.UserSession.Session.SysCache.GetLabel(Constant.BTN_B0019) + "</lable>" +
                                      "</div>";
                    printAppend += "</div>";

                    //check TagPrintFlag
                    if (TagPrintFlag == true)
                    {
                        //Show confirm message
                        this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0019),
                        value1: TypePrintFrom, value2: StrPrintFlg, value3: SeqNum.ToString(), printAppend: printAppend);

                    }
                    else
                    {
                        //Show confirm message
                        this.ShowMessageConfirmPrint(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0018),
                                                     value1: TypePrintFrom, value2: StrPrintFlg, value3: SeqNum.ToString(), printAppend: printAppend);

                    }
                    break;
                case PrintTypeFlag.Big:
                case PrintTypeFlag.Small:
                    //Check TagPrintFlag
                    if (TagPrintFlag == true)
                    {
                        //Show confirm message
                        this.ShowMessageConfirm(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0021),
                                                value1: TypePrintFrom, value2: StrPrintFlg, value3: SeqNum.ToString());
                    }
                    else
                    {
                        //Show confirm message
                        this.ShowMessageConfirm(SeqNum, PRINT_ACTION_URL, message: InventoryManagement.UserSession.Session.SysCache.GetMessage(Constant.MES_M0020),
                                                value1: TypePrintFrom, value2: StrPrintFlg, value3: SeqNum.ToString());
                    }
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Exclusion Process
        /// </summary>
        /// <param name="SeqNum">Sequence Number</param>
        /// <returns>ActionResult</returns>
        private ActionResult ExclusionProcess(int SeqNum)
        {
            //Set Exclusion message
            this.ShowMessageExclusion("/InboundDelivery/Index");

            InboundDeliveryModels model = (InboundDeliveryModels)this.Session[Constant.SESSION_DETAIL_MODEL + SeqNum.ToString()];
            if (model == default(InboundDeliveryModels))
            {
                model = new InboundDeliveryModels();
                model.SeqNum = SeqNum;
            }

            return View("Details", model);
        }

        /// <summary>
        /// Set size for form print
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns>PrintTypeFlag</returns>
        private PrintTypeFlag SetPrintSize()
        {
            PrintTypeFlag PrintFlag = PrintTypeFlag.None;
            //Get Kind for set size report            
            KindForPrint ktype = this.tInventory_HService.GetKindForSetSizePrint(Constant.TAG_PRINT_SET_SIZE_CD, Constant.TAG_PRINT_LANGUAGE_ENG)
                                     .Where(m => m.Value.ToLower().Equals("true")).SingleOrDefault();
            //Set size for print form
            if (ktype.DataCD.Equals(Constant.TAG_PRINT_LARGE))
            {
                PrintFlag = PrintTypeFlag.Big;
            }
            else if (ktype.DataCD.Equals(Constant.TAG_PRINT_SMALL))
            {
                PrintFlag = PrintTypeFlag.Small;
            }
            return PrintFlag;
        }

        /// <summary>
        /// Create Data For Row
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="Row">DataRow</param>
        /// <param name="Data">InboundDeliveryModels</param>
        /// <param name="BoxNo">BoxNo</param>
        private void InitDataForRow(ref System.Data.DataRow Row, InboundDeliveryModels Data, int BoxNo)
        {
            Row["ArrivalDate"] = Data.ArrivalDate;

            string barCode = Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), BRANCH_TAG_NO_SHOW_PRINT);
            Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(barCode, 3, false);
            MemoryStream Stream = new MemoryStream();
            BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
            Row["Barcode"] = Stream.ToArray();
            Row["TagNo"] = Data.TagNo + "-" + this.FixCode(Data.BranchTagNo.ToString(), BRANCH_TAG_NO_SHOW_PRINT);
            Row["ProductCD"] = Data.ProductCD;
            Row["ProductName"] = Data.ProductName;
            Row["QuantityPerUnit"] = Data.QuantityPerUnit;
            Row["BoxNo"] = BoxNo;
            Row["BoxNumber"] = FixCode(Data.BranchTagNo.ToString(), 4) + "/" + FixCode(Data.UnitQuantity.ToString(), 4);
            Row["LOT1"] = Data.Lot1;
            Row["LOT2"] = string.IsNullOrEmpty(Data.Lot2) ? string.Empty : CommonUtil.ParseDate(Data.Lot2, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LOT3"] = string.IsNullOrEmpty(Data.Lot3) ? string.Empty : CommonUtil.ParseDate(Data.Lot3, Constant.FMT_YMD, Constant.FMT_DATE);
            Row["LocationCD"] = Data.LocationCD;
        }

        /// <summary>
        /// Init Params
        /// Author : ISV-TRUC
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParamsForReport()
        {
            //Set Parameters
            ReportParameter arrivalDate = new ReportParameter("arrivalDateLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0080));
            ReportParameter tagNo = new ReportParameter("tagNoLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0106));
            ReportParameter productCD = new ReportParameter("productCDLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0018));
            ReportParameter productName = new ReportParameter("productNameLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0019));
            ReportParameter quantity = new ReportParameter("quantityLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0022));
            ReportParameter lot1 = new ReportParameter("lot1Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0084));
            ReportParameter boxNumber = new ReportParameter("boxNumberLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0315));
            ReportParameter lot2 = new ReportParameter("lot2Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0085));
            ReportParameter lot3 = new ReportParameter("lot3Label", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0086));
            ReportParameter location = new ReportParameter("locationLabel", UserSession.Session.SysCache.GetLabel(Constant.LBL_L0110));
            return new ReportParameterCollection { arrivalDate, tagNo, productCD, productName, quantity, lot1, boxNumber, lot2, lot3, location };
        }

        #endregion

        #endregion

        #region Update Print -- ISV-TRUC

        /// <summary>
        /// Update Print Flag After Printed
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagNos">List Of TagNo</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdatePrintFlag(List<string> TagNos)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();
                Hashtable updated = new Hashtable();

                //update TagPrintFlag for Detail
                var inventoryDList = this.tInventory_DService.GetListByTagNoBranchTagNo(TagNos);

                foreach (var entity in inventoryDList.ToList())
                {
                    entity.TagPrintFlag = true;
                }

                //update UpdateDate for Detail
                foreach (var item in TagNos)
                {
                    string TagNoLst = SplitTagNo(item);
                    if (updated.Contains(TagNoLst))
                    {
                        continue;
                    }
                    updated.Add(TagNoLst, TagNoLst);

                    var detailList = this.tInventory_DService.GetListEntityByTagNo(TagNoLst);
                    foreach (var entityDetail in detailList.ToList())
                    {
                        entityDetail.UpdateDate = updateDate;
                        entityDetail.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                    }
                }

                tInventory_DService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = "";

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }

            return ret;
        }

        /// <summary>
        /// Update Print Flag Single
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagNo">TagNo</param>
        /// <returns>CommitFlag</returns>
        private CommitFlag UpdatePrintFlagSingle(string TagNo)
        {
            var ret = CommitFlag.Success;
            try
            {
                string updateDate = this.GetCurrentDate();

                //update TagPrintFlag of Detail
                var inventoryDList = this.tInventory_DService.GetListByTagNoForPrint(TagNo);
                foreach (var entity in inventoryDList)
                {
                    entity.TagPrintFlag = true;
                    entity.UpdateDate = updateDate;
                    entity.UpdateUCD = UserSession.Session.LoginInfo.User.UserCD;
                }

                tInventory_DService.Context.SubmitChanges();
            }
            catch (ChangeConflictException)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.DataChanged;
            }
            catch (SqlException sqlEx)
            {
                string message = "";

                if (sqlEx.Message.Contains(Constant.DB_TINVENTORY_H_PK) || sqlEx.Message.Contains(Constant.DB_TINVENTORY_D_PK))
                {
                    message = this.FormatMessage(Constant.MES_M0003);
                    this.ModelState.AddModelError(string.Empty, message);
                }
                message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                ret = CommitFlag.IsExistsInAnotherTB;
            }
            catch (Exception ex)
            {
                string message = this.FormatMessage(Constant.MES_M0003);
                this.ModelState.AddModelError(string.Empty, message);
                Log.WriteLog(ex);
                ret = CommitFlag.Failed;
            }

            return ret;
        }

        /// <summary>
        /// Split Tag No
        /// Author : ISV-TRUC
        /// </summary>
        /// <param name="TagInfo">TagNo-BranchTagNo</param>
        /// <returns>Splited TagNo</returns>
        private string SplitTagNo(string TagInfo)
        {
            return TagInfo.Split(Constant.HYPHEN_CHAR)[0].ToString();
        }

        #endregion


    }
}

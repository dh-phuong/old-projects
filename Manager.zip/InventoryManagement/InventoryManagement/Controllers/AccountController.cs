﻿using System;
using System.Linq;
using System.Web.Mvc;
using System.Web.Security;
using InventoryManagement.Models;
using InventoryManagement.Common;
using InventoryManagement.Utility;
using System.Collections.Generic;
using InventoryManagement.Validation;

namespace InventoryManagement.Controllers
{
    /// <summary>
    /// Acount Controller 
    /// Author: ISV-Vinh
    /// </summary>
    [iNoCache]
    public class AccountController : Controller
    {
        #region Common

        private DataAccess.MUserService mUserService;
        private DataAccess.MWarehouseService mWarehouseService;
        private DataAccess.MWarehouseByUserService mWarehouseByUserService;
        private DataAccess.MGroup_DService mGroup_DService;

        /// <summary>
        /// Constructor
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="mUserService">MUserService</param>
        /// <param name="mWarehouseService">MWarehouseService</param>
        public AccountController(DataAccess.MUserService mUserService, 
                                 DataAccess.MWarehouseService mWarehouseService,
                                 DataAccess.MGroup_DService mGroup_DService,
                                 DataAccess.MWarehouseByUserService mWarehouseByUserService)
        {
            this.mUserService = mUserService;
            this.mWarehouseService = mWarehouseService;
            this.mGroup_DService = mGroup_DService;
            this.mWarehouseByUserService = mWarehouseByUserService;
        }

        #endregion

        #region Constant

        private const string KEY_LOGIN_ID = "LoginID";
        private const string KEY_WAREHOUSE_CD = "WarehouseCD";
        private const string TMP_LANG = "LangCD";

        #endregion

        #region Action

        /// <summary>
        /// Login
        /// Author: ISV-Vinh
        /// </summary>
        /// <returns>ActionResult</returns>
        public ActionResult Index()
        {
            //Init message
            Utility.CommonUtil.InitCache();

            //Redirect if login
            if (UserSession.Session.IsAuthenticated)
            {
                return RedirectToAction("Menu", "Menu");
            }
           
            AccountModels model = new AccountModels();
            model.LanguageCD = Common.LanguageFlag.Vietnamese;
            UserSession.Session.SetLanguageSession(model.LanguageCD);
            
            //Init Dropdown
            this.InitDropDown(model, model.LanguageCD);

            //Set focus
            ViewData[Common.Constant.VIEWDATA_FOCUSID] = UserSession.Session.WareHouseMode == WareHouseMode.Single? KEY_LOGIN_ID: KEY_WAREHOUSE_CD;
            return View("Login", model);
        }

        /// <summary>
        /// Login
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="model">LoginModels</param>
        /// <returns>ActionResult</returns>
        [HttpPost]
        [iExistCache]
        public ActionResult Login(AccountModels model)
        {
            if (ModelState.IsValid && this.LoginCheck(model))
            {
                bool isValid = true;
                
                //Check exist user and correct password
                UserModels user = this.mUserService.GetByLoginID(model.LoginID);
                if (user == default(UserModels) || !user.Password.Equals(model.Password))
                {
                    ModelState.AddModelError(KEY_LOGIN_ID, UserSession.Session.SysCache.GetMessage(Constant.MES_E0008));
                    isValid = false;
                }

                //Check warehouse user take care
                if (isValid && UserSession.Session.WareHouseMode == WareHouseMode.Multiple)
                {
                    List<MWarehouseByUser> listWarehouse = mWarehouseByUserService.GetListByUserCD(user.UserCD);
                    if (listWarehouse.Count != 0 && !listWarehouse.Any(m => m.WarehouseCD.Equals(model.WarehouseCD)))
                    {
                        string message =  String.Format(UserSession.Session.SysCache.GetMessage(Constant.MES_M0074),model.WarehouseCD) ;
                        ModelState.AddModelError(KEY_WAREHOUSE_CD, message);
                        isValid = false;
                    }
                }
                if (isValid)
                {
                    //Set login Info
                    List<MGroup_D> listGroupDetail = this.mGroup_DService.GetListByKey(user.GroupCD).ToList();
                    Models.LoginInfo loginInfo = new Models.LoginInfo();
                    loginInfo.User = user;
                    loginInfo.WarehouseCD = model.WarehouseCD;
                    loginInfo.ListGroupDetail = listGroupDetail;
                    
                    //Store login info                    
                    UserSession.Session.SetLoginInfoSession(loginInfo);
                    
                    UserSession.Session.SetLanguageSession(model.LanguageCD);
                    UserSession.Session.SetWareHouseSession(model.WarehouseCD);

                    return RedirectToAction("Menu", "Menu");
                }
            }

            //Init Dropdown
            this.InitDropDown(model, model.LanguageCD);

            return View(model);
        }

        /// <summary>
        /// LogOff
        /// Author: ISV-Vinh
        /// </summary>
        /// <returns>ActionResult</returns>
        public ActionResult LogOff()
        {
            //Clear Login Info
            UserSession.Session.LogOff();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Change language
        /// Author: ISV-Phuong
        /// </summary>
        /// <param name="Model">AccountModels</param>
        [HttpPost]
        [iExistCache]
        public ActionResult ChangeLanguage(AccountModels Model)
        {
            this.ClearModelState();
            UserSession.Session.SetLanguageSession(Model.LanguageCD);
            UserSession.Session.SetWareHouseSession(Model.WarehouseCD);                       
            this.InitDropDown(Model, Model.LanguageCD);

            //Store model into session
            this.Session[Constant.SESSION_LOGIN_MODEL] = Model;
                      
            return View("Login", Model);
        }

         /// <summary>
         /// Change language
         /// Author: ISV-Phuong
         /// </summary>
         /// <param name="Model">AccountModels</param>   
         [iExistCache]
         public ActionResult ChangeLanguage()
         {
             //Get model into session             
             var Model = (AccountModels)this.Session[Constant.SESSION_LOGIN_MODEL];
             
             //Default language
             LanguageFlag language = UserSession.Session.Language;
             if (Model == null)
             {
                 Model = new AccountModels();
             }
             else
             {                 
                 language = Model.LanguageCD;
             }
             //Init warehouse and language dropdown list
             this.InitDropDown(Model, language);

             //Redirect if login
             if (UserSession.Session.IsAuthenticated)
             {
                 return RedirectToAction("Menu", "Menu");
             }

             return View("Login", Model);
         }

        #endregion

        #region Private Methods

        /// <summary>
        /// Init Dropdown
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="gmModel">AccountModels</param>
        /// <param name="LanguageCD">LanguageFlag</param>
        private void InitDropDown(AccountModels gmModel, LanguageFlag LanguageCD)
        {
            //WarehouseCD Dropdown
            IQueryable<WarehouseDropDown> list = this.mWarehouseService.GetList();

            UserSession.Session.WareHouseMode = WareHouseMode.Multiple;
            if (list.Count() == 1)
            {
                UserSession.Session.WareHouseMode = WareHouseMode.Single;
            }
            if (string.IsNullOrEmpty(gmModel.WarehouseCD) && list.Count() != 0)
            {
                gmModel.WarehouseCD = list.First().WarehouseCD;
            }

            //WarehouseCD Dropdown
            ViewBag.WarehouseCD = new SelectList(list, "WarehouseCD", "WarehouseName", gmModel.WarehouseCD);

            //LanguageCD Dropdown
            ViewBag.LanguageCD = new SelectList(new[]{
                                                        new {ID=(int)LanguageFlag.English,Name="English"},
                                                        new{ID=(int)LanguageFlag.Vietnamese,Name="Tiếng Việt"},
                                                        new{ID=(int)LanguageFlag.Japanese,Name="日本語"},
                                                    }, "ID", "Name", (int)LanguageCD);
        }

        /// <summary>
        /// Login Check
        /// Author: ISV-Vinh
        /// </summary>
        /// <param name="gmModel">AccountModels</param>
        /// <returns>TRUE: valid, FALSE: invalid</returns>
        private bool LoginCheck(AccountModels gmModel)
        {
            bool ret = true;

            //Check WarehouseCD Exist
            if (!this.mWarehouseService.Exist(gmModel.WarehouseCD))
            {
                string message = UserSession.Session.SysCache.GetMessage(Constant.MES_M0001);
                message = String.Format(message, CommonUtil.GetDisplayName((MWarehouse m) => m.WarehouseCD));
                ModelState.AddModelError(KEY_WAREHOUSE_CD, message);
                ret = false;
            }

            return ret;
        }

        /// <summary>
        /// Clear Model State
        /// </summary>
        private void ClearModelState()
        {
            System.Collections.Generic.List<String> lstKey = this.ModelState.Keys.ToList();

            foreach (var item in lstKey)
            {
                if (!String.IsNullOrEmpty(item))
                {
                    this.ModelState.Remove(item);
                }
            }
        }

        #endregion
    }
}

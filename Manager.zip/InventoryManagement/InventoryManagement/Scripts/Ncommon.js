﻿// Default load script
// Author : ISV-PHUONG
function DefaultLoadScript() {
    LockEnterKey();
    EnterMoveNextControl();
    InputNum();
    InputAlpNum();
    InputAlpNumUpper();
    InputAlpNumCode();
    InputAlpNumSubCode();
    InputInt();
    InpuDec();
    InputTel();
    InputHaflwidth();
    InputNumSub();
    InputDeliveryNumber();
    DisableIme();
    IsInputDisplay();
    BackToMenu();
    TriggerAcceptButton();
}

// Parse text to boolean
// Author : ISV-PHUONG
Boolean.parse = function (str) {
    if ($.trim(str) == "") {
        return false;
    }
    return JSON.parse(str.toLowerCase());
};

/**
* htmlのエスケープを戻す
* Author: ISV-Phuong
* param str
* returns
*/
function ConvertHtml(str) {

    return str.replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
}

/**
* htmlのエスケープを戻す
* Author: ISV-Phuong
* param str
* returns
*/
function DeconvertHtml(str) {

    str = str.replace(/&amp;/, "&");
    str = str.replace(/&gt;/, ">");
    str = str.replace(/&lt;/, "<");
    str = str.replace(/&quot;/, '"');

    return str;
}

/**
*  Auto update case
*  Author : ISV-Vinh
*
**/
function UpperCaseCode(element) {

    element.value = element.value.toUpperCase();
}

/**
* Show Message Confirm
* Author: ISV-Vinh
*/
function ScriptShowMessageConfirm() {

    //Focus
    $("#mesConfirmModal").on("shown", function () {
        $("#cBtnYes").focus();
    })

    $("#mesConfirmModal").modal("show");
    $("#cBtnYes").click(function () {
        $("#hbtnSubmit").click();
    });

    $("#mesConfirmModal").on("hidden", function () {
        if (typeof (ConfirmMessageCallBack) == "function") {
            ConfirmMessageCallBack();
        }
    })
}

/**
* Show Message Tranfer
* Author: ISV-Vinh
*/
function ScriptShowMessageTranfer() {

    //Focus
    $("#mesTranferModal").on("shown", function () {
        $("#mesTranferModal .modal-footer .btn").focus();
    })

    $("#mesTranferModal").modal("show");
    $("#mesTranferModal").on("hidden", function () {
        $("#hbtnSubmit").click();
    })
}

/**
* Show Message Information
* Author: ISV-Vinh
*/
function ScriptShowMessageInfo() {

    //Focus
    $("#mesInfoModal").on("shown", function () {
        $("#mesInfoModal .modal-footer .btn").focus();
    })

    $("#mesInfoModal").modal("show");
    $("#mesInfoModal").on("hidden", function () {
        if (typeof (InfoMessageCallBack) == "function") {
            InfoMessageCallBack();
        }
    })
}

/**
* Show Message Confirm Print
* Author: ISV-Phuong
*/
function ScriptShowMessageConfirmPrint() {

    //Focus
    $("#mesPrintModal").on("shown", function () {
        $("#mesPrintModal .modal-footer .btn:First").focus();
    })

    $("#mesPrintModal").modal("show");

    if (typeof (PrintingCallBack) == "function") {
        PrintingCallBack();
    }
}

function showPleaseWait() {

    $('#pleaseWaitDialog').modal("show");
}

function hidePleaseWait() {
    $('#pleaseWaitDialog').modal('hide');
}


/**
* 二重サブミットを防止する
* Author: ISV-Loc
*/
function PreventDoubleSubmit() {

    var args = arguments;
    var val = '';
    $('a').mousedown(function (e) {
        val = e.button;
    });

    $('a.menu').click(function (e) {

        if (this == "") {
            return;
        }

        if (this.id == "#help") {
            hidePleaseWait();
            return;
        }

        if (e.ctrlKey) {
            return true;
        }

        if (e.button == 1 || val == 4 || e.shiftKey) {
            return true;
        }
        
        current_perc = 0;
        showPleaseWait();
    });

    $("form :submit, form :button, button[name=Back]").click(function (e) {
        if (this.id == "PbtnClear" || this.id == "btnClear" || this.id == "btnCollapse" || this.id == "btnDownload") {
            return true;
        }
        for (var i = 0; i < args.length; i++) {

            for (var j = 0; j < $(args[i]).length; j++) {

                if (this == $(args[i])[j]) {

                    return true;
                }
            }
        }
        current_perc = 0;
        showPleaseWait();

        $("form").submit(function () {

            $(this).submit(function () {

                return false;
            });
        });
    })
}

/**
* Show Message Error Ajax
* data: modelstate as json
* Author: ISV-Hung
*/
function ShowMessageErrorAjax(data) {

    hidePleaseWait();

    if (data[0].Key == undefined) {
        window.location = "/";
        return;
    }

    var message = "";
    for (var i = (data.length - 1); i >= 0; i--) {
        $("input[name='" + data[i].Key + "']").parents("div.control-group").addClass('error');
        message += "<p>" + data[i].Value.Errors[0].ErrorMessage + "</p>";
    }
    $("#mesErrorModal .modal-body").html(message);

    $("#mesErrorModal").modal("show");
    $("#mesErrorModal").on("hidden", function () {
        $("input[name='" + data[data.length - 1].Key + "']").focus().select();
    })
}

//Paging 
//Author: ISV-Vinh
//url       : Url to get data for paging
//page      : current page index
//isFirst   : is first page flag
//isLast    : is last page flag
//sortUrl,sortField,direction: sorting info
//SeqNum   : sequence Number
function Paging(url, updateId, page, isFirst, isLast,
                    sortUrl, sortField, direction,
                    SeqNum, FormSerialize, pageType) {
    //    /* show loading */
    //    if (pageType && pageType == PageType.PopUp) {
    //        ShowLoadingSearch();
    //    } else {
    //        ShowLoading();
    //    }
    showPleaseWait();
    var formParams = [];
    if (FormSerialize) {
        formParams = $('#' + FormSerialize).serializeArray();
    }

    var pagingParams = { selectedPage: $("#paging a.active").html(),
        page: page,
        isFirst: isFirst, isLast: isLast,
        Url: sortUrl, SortField: sortField, Direction: direction,
        SeqNum: SeqNum
    };

    var param = $.param(pagingParams, true) + "&" + $.param(formParams, true);

    var posting = $.post(url, param);

    /* Put the results in a div */
    posting.done(function (data) {

        //        /* hide loading */
        //        if (pageType && pageType == PageType.PopUp) {
        //            HideLoadingSearch();
        //        } else {
        //            HideLoading();
        //        }
        $("#" + updateId).html(data);
        PreventDoubleSubmit();
        hidePleaseWait();
        //        IsInputDisplay();
        if (typeof (PagingCallBack) == "function") {
            PagingCallBack();
            
        }
    });
}

//Sorting
//Author: ISV-Vinh
//updateId  : Update data when sorting completed
//sortField : field data to sort
//direction : direction
//SeqNum   : sequence Number
//FormSerialize   : Form data
//SeqNum   : PageType
function Sorting(url, updateId
                    , sortField
                    , direction
                    , SeqNum
                    , FormSerialize
                    , pageType) {

    //    if (pageType && pageType == PageType.PopUp) {
    //        ShowLoadingSearch();
    //    } else {
    //        ShowLoading();
    //    }
    showPleaseWait();
    var formParams = [];
    if (FormSerialize) {
        formParams = $('#' + FormSerialize).serializeArray();
    }

    var sortingParams = { Url: url,
        SortField: sortField,
        Direction: direction,
        SeqNum: SeqNum
    };

    var param = $.param(sortingParams, true) + "&" + $.param(formParams, true);

    /* Send the data using post */
    var posting = $.post(url, param);


    /* Put the results in a div */
    posting.done(function (data) {
        $("#" + updateId).html(data);
        PreventDoubleSubmit();
        hidePleaseWait();
        /* hide loading */
        //        if (pageType && pageType == PageType.PopUp) {
        //            HideLoadingSearch();
        //        } else {
        //            HideLoading();
        //        }

        if (typeof (SortingCallBack) == "function") {            
            SortingCallBack();
        }
    });
}

/**
* Padleft
* Author: ISV-Loc
*/
function padLeft(nr, n, str) {
    var zero = "0";
    return Array(n - String(nr).length + 1).join(str || zero) + nr;
}

// or as a Number prototype method:
// Author: ISV-Loc
Number.prototype.padLeft = function (n, str) {
    var zero = "0";
    return Array(n - String(this).length + 1).join(str || zero) + this;
}

/**
* Fix code by maxlenght
* Author: ISV-Phuong
*/
function FixCode(input) {

    var val = $(input).val();
    var maxlength = $(input).attr("maxlength");
    if ($.isNumeric(val)) {
        val = padLeft(val, maxlength);
    }
    if (val) {
        val = val.toUpperCase();
    }
    $(input).val(val);
}

/**
* Disable IME mode
* Author: ISV-Vinh
*/
function DisableIme() {

    var elmNum = $('.disableIme');
    if (elmNum) {
        elmNum.keydown(function (event) {
            // Remove ime-mode
            if (event.keyCode == 229) {
                event.preventDefault();
            }
        });
    }
}

/**
* Input Numeric And Substract
* Author: ISV-Vinh
*/
function InputNumSub() {

    var elmNum = $('.iNumSub');
    if (elmNum) {
        elmNum.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)
                    && (event.keyCode != 109 && event.keyCode != 189 && event.keyCode != 173)) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input Num
* Author: ISV-Vinh
*/
function InputNum() {

    var elmNum = $('.iNum');
    if (elmNum) {
        elmNum.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input Alpha numberic
* Author: ISV-Hung
*/
function InputAlpNum() {

    var elmAlpNum = $('.iAlpNumNone');
    if (elmAlpNum) {

        elmAlpNum.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                //remove shift + number
                if (event.shiftKey && ((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105))) {
                    event.preventDefault();
                }

                // Ensure alpha numberic input
                if ((event.keyCode < 48 || event.keyCode > 57)
                    && (event.keyCode < 65 || event.keyCode > 90)
                    && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input Alpha numberic upper case
* Author: ISV-Hung
*/
function InputAlpNumUpper() {

    var elmAlpNum = $('.iAlpNum');
    var keyPressed;
    if (elmAlpNum) {

        elmAlpNum.keydown(function (event) {
            if (window.event) { // IE					
                keyPressed = event.keyCode;
            } else {
                if (event.which) { // Netscape/Firefox/Opera					
                    keyPressed = event.which;
                }
            }
            // Allow: backspace, delete, tab, escape, and enter
            if (keyPressed == 46 || keyPressed == 8 || keyPressed == 9 || keyPressed == 27 || keyPressed == 13 ||
            // Allow: Ctrl+A
                (keyPressed == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (keyPressed >= 35 && keyPressed <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                //remove shift + number
                if (event.shiftKey && ((keyPressed >= 48 && keyPressed <= 57) || (keyPressed >= 96 && keyPressed <= 105))) {
                    event.preventDefault();
                }

                // Ensure alpha numberic input
                if ((keyPressed < 48 || keyPressed > 57)
                    && (keyPressed < 65 || keyPressed > 90)
                    && (keyPressed < 96 || keyPressed > 105)) {
                    event.preventDefault();
                }
            }

        });
    }
}

/**
* Input Alpha numberic upper case
* Author: ISV-Hung
*/
function InputAlpNumCode() {

    var elmAlpNum = $('.iAlpNumC');
    var keyPressed;
    if (elmAlpNum) {
        elmAlpNum.keydown(function (event) {
            if (window.event) { // IE					
                keyPressed = event.keyCode;
            } else {
                if (event.which) { // Netscape/Firefox/Opera					
                    keyPressed = event.which;
                }
            }
            // Allow: backspace, delete, tab, escape, and enter
            if (keyPressed == 46 || keyPressed == 8 || keyPressed == 9 || keyPressed == 27 || keyPressed == 13 ||
            // Allow: Ctrl+A
                (keyPressed == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (keyPressed >= 35 && keyPressed <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {

                //remove shift + number
                if (event.shiftKey && ((keyPressed >= 48 && keyPressed <= 57) || (keyPressed >= 96 && keyPressed <= 105) || keyPressed == 191 || keyPressed == 173 || keyPressed == 189)) {
                    event.preventDefault();
                }

                // Ensure alpha numberic input
                if ((keyPressed < 47 || keyPressed > 57)
                    && (keyPressed < 65 || keyPressed > 96)
                    && (keyPressed < 97 || keyPressed > 105)
                    && (keyPressed < 109 || keyPressed > 109)
                    && (keyPressed < 111 || keyPressed > 111)
                    && (keyPressed < 173 || keyPressed > 173)
                    && (keyPressed < 189 || keyPressed > 189)
                    && (keyPressed < 191 || keyPressed > 191)
                    ) {
                    event.preventDefault();
                }
            }

        });

    }
}

/**
* Input Alpha numberic upper case
* Author: ISV-Hung
*/
function InputAlpNumSubCode() {

    var elmAlpNum = $('.iAlpNumS');
    var keyPressed;
    if (elmAlpNum) {
        elmAlpNum.keydown(function (event) {
            if (window.event) { // IE					
                keyPressed = event.keyCode;
            } else {
                if (event.which) { // Netscape/Firefox/Opera					
                    keyPressed = event.which;
                }
            }
            // Allow: backspace, delete, tab, escape, and enter
            if (keyPressed == 46 || keyPressed == 8 || keyPressed == 9 || keyPressed == 27 || keyPressed == 13 ||
            // Allow: Ctrl+A
                (keyPressed == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (keyPressed >= 35 && keyPressed <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {

                //remove shift + number
                if (event.shiftKey && ((keyPressed >= 48 && keyPressed <= 57) || (keyPressed >= 96 && keyPressed <= 105) || keyPressed == 191 || keyPressed == 173 || keyPressed == 189)) {
                    event.preventDefault();
                }

                // Ensure alpha numberic input
                if ((keyPressed < 47 || keyPressed > 57)
                    && (keyPressed < 65 || keyPressed > 96)
                    && (keyPressed < 97 || keyPressed > 105)
                    && (keyPressed < 109 || keyPressed > 109)
                    //&& (keyPressed < 111 || keyPressed > 111)
                    && (keyPressed < 173 || keyPressed > 173)
                    && (keyPressed < 189 || keyPressed > 189)
                    //&& (keyPressed < 191 || keyPressed > 191)
                    ) {
                    event.preventDefault();
                }
            }

        });

    }
}

/**
* Input Alpha numberic upper case
* Author: ISV-Hung
*/
function InputDeliveryNumber() {

    var elmAlpNum = $('.iDlvNo');
    var keyPressed;
    if (elmAlpNum) {
        elmAlpNum.keydown(function (event) {
            if (window.event) { // IE					
                keyPressed = event.keyCode;
            } else {
                if (event.which) { // Netscape/Firefox/Opera					
                    keyPressed = event.which;
                }
            }
            // Allow: backspace, delete, tab, escape, and enter
            if (keyPressed == 46 || keyPressed == 8 || keyPressed == 9 || keyPressed == 27 || keyPressed == 13 ||
            // Allow: Ctrl+A
                (keyPressed == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (keyPressed >= 35 && keyPressed <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {

                //remove shift + number
                if (event.shiftKey && ((keyPressed >= 48 && keyPressed <= 57) || (keyPressed >= 96 && keyPressed <= 105) || keyPressed == 191 || keyPressed == 173 || keyPressed == 189)) {
                    event.preventDefault();
                }

                // Ensure alpha numberic input
                if ((keyPressed < 47 || keyPressed > 57)
                    && (keyPressed < 65 || keyPressed > 96)
                    && (keyPressed < 97 || keyPressed > 105)
                    && (keyPressed < 109 || keyPressed > 109)
                    && (keyPressed < 111 || keyPressed > 111)
                    && (keyPressed < 173 || keyPressed > 173)
                    && (keyPressed < 189 || keyPressed > 189)
                    && (keyPressed < 191 || keyPressed > 191)
                    && (keyPressed != 32)
                    ) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input tel
* Author: ISV-Vinh
*/
function InputTel() {

    var element = $('.iTel');
    if (element) {

        element.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {

                if (!event.ctrlKey && !event.shiftKey && !event.altKey && (
                        (event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105)
                        || event.keyCode == 107 || event.keyCode == 173 || event.keyCode == 189 || event.keyCode == 109 || event.keyCode == 32)) {
                    return;
                }
                if (!event.ctrlKey && event.shiftKey && !event.altKey && (event.keyCode == 57 || event.keyCode == 48
                            || event.keyCode == 61 || event.keyCode == 187)) {
                    return;
                }

                event.preventDefault();
            }
        });
    }
}

/**
* Input Integer
* Author: ISV-Vinh
*/
function InputInt() {

    var elmDate = $('.integer');
    if (elmDate) {

        elmDate.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: comma, subtract
                (event.keyCode == 188 || event.keyCode == 109) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input Decimal
* Author: ISV-Vinh
*/
function InpuDec() {

    var elmDate = $('.decimal');
    if (elmDate) {

        elmDate.keydown(function (event) {
            // Allow: backspace, delete, tab, escape, and enter
            if (event.keyCode == 46 || event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 27 || event.keyCode == 13 ||
            // Allow: Ctrl+A
                (event.keyCode == 65 && event.ctrlKey === true) ||
            // Allow: comma, subtract, dot
                (event.keyCode == 188 || event.keyCode == 109 || event.keyCode == 173 || event.keyCode == 190 || event.keyCode == 110) ||
            // Allow: home, end, left, right
                (event.keyCode >= 35 && event.keyCode <= 39)) {
                // let it happen, don't do anything
                return;
            }
            else {
                // Ensure that it is a number and stop the keypress
                if (event.shiftKey || (event.keyCode < 48 || event.keyCode > 57) && (event.keyCode < 96 || event.keyCode > 105)) {
                    event.preventDefault();
                }
            }
        });
    }
}

/**
* Input Haflwidth
* ISV-Vinh
*/
function InputHaflwidth() {

    var elmNum = $('.iHafl');
    if (elmNum) {

        elmNum.keydown(function (event) {
            //Remove space
            if (event.keyCode == 32) {
                event.preventDefault();
            }
        });
    }
}

/**
*  Enter move next
*  Author : ISV-phuong
* 
**/
function EnterMoveNextControl() {
    $(":input:enabled,visible").not('[type=button]').not('[type=submit]').not('textarea').keydown(function (e) {
        var key = e.charCode ? e.charCode : e.keyCode ? e.keyCode : 0;
        if (key == 13) {
            e.preventDefault();
            var inputs = $(':input[tabIndex !=-1]:enabled,visible').not('[type=hidden]');
            if ((inputs.index(this) + 1) > inputs.length - 1) {
                if ($(inputs.eq(0)).prop("type") == "text") {
                    $(inputs.eq(0)).focus().select();
                } else {
                    $(inputs.eq(0)).focus();
                }
            } else {
                if ($(inputs.eq(inputs.index(this) + 1)).prop("type") == "text") {
                    $(inputs.eq(inputs.index(this) + 1)).focus().select();
                } else {
                    $(inputs.eq(inputs.index(this) + 1)).focus();
                }


            }
        }
    });
}

/**
* Lock Enter Key
* Author: ISV-Phuong
*/
function LockEnterKey() {
    $('input[type!="button"][type!="submit"]').keypress(function (event) {
        var keycode = event.which;
        if (keycode == '13') {
            return false;
        }
    });
}
/**
*  Set Input Display
*  Author : ISV-Loc
*
**/
function IsInputDisplay() {
    $("textarea[readonly='readonly'],input[type='text'][readonly='readonly'],textarea[readonly='true'],input[type='text'][readonly='true']").each(function () {
        //$(this).addClass('disp');
        $(this).attr("tabindex", -1);
    });

}

/**
*  Fix code by maxlenght
*  Author : ISV-phuong
*
**/
function FormatNumber(input, typeFormat) {

    var val = $(input).val();

    var url = "/Base/FormatNumber";

    var inParams = { iCode: val, iTypeFormat: typeFormat };

    $.ajax({
        type: "POST",
        url: url,
        data: inParams,
        success: function (data) {
            if (data) {
                $(input).val(data);
            }
        }
    });     
}

/**
*  Enter to click first button on modal-footer 
*  Author : ISV-phuong
*
**/
function TriggerAcceptButton() {
    $('.info-modal').keydown(function (e) {
        var key = e.charCode ? e.charCode : e.keyCode ? e.keyCode : 0;
        if (key == 13) {
            $(".info-modal.in .modal-footer .btn").trigger('click');
        }
    });
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Common;
using System.Web.Helpers;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Sorting Info
    /// Author: ISV-Vinh
    /// </summary>
    public class SortingInfo
    {
        public string Url { get; set; }
        public string SortField { get; set; }
        public SortDirection Direction { get; set; }
    }
}
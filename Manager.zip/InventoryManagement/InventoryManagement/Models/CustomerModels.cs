﻿using InventoryManagement.Validation;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using InventoryManagement.Common;
using System.Collections.Generic;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Customer Models
    /// Author: ISV-LOC
    /// </summary>
    public class CustomerModels : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MCUSTOMER_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0030)]
        public string Address1 { get; set; }

        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0072)]
        public string Address2 { get; set; }

        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0073)]
        public string Address3 { get; set; }

        [iPattern(PatternType.Email)]
        [iStringLength(Constant.MCUSTOMER_EMAIL_MAX)]
        [iDisplayName(Name = Constant.LBL_L0074)]
        public string Email { get; set; }
        
        [iPattern(PatternType.Tel)]
        [iStringLength(Constant.MCUSTOMER_TEL_MAX)]
        [iDisplayName(Name = Constant.LBL_L0031)]
        public string Tel { get; set; }

        [iPattern(PatternType.Tel)]
        [iStringLength(Constant.MCUSTOMER_FAX_MAX)]
        [iDisplayName(Name = Constant.LBL_L0032)]
        public string Fax { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }

        public string PreCustomerCD { get; set; }

        public List<string> item { get; set; }
        public List<string> sortorder { get; set; }
        public List<string> itemDisp { get; set; }
        public List<string> sortorderDisp { get; set; }

        /// <summary>
        /// Validate Dropdownlist
        /// </summary>
        /// <returns></returns>
        public List<ErrorDropDownlist> ValidateDropdownlist()
        {
            List<ErrorDropDownlist> lstErr = new List<ErrorDropDownlist>();

            //Select a pair
            for (int i = 0; i < item.Count; i++)
            {
                if (!CheckSelectedPair(item[i], sortorder[i]))
                {
                    //Select a pair
                    lstErr.Add(new ErrorDropDownlist(EnumDropdownlistError.SelectPair,i.ToString()));
                }
            }

            //Duplicate Dropdownlist
            for (int i = 0; i < item.Count - 1; i++)
            {
                for (int j = i + 1; j < item.Count; j++)
                {
                    if (   !string.IsNullOrEmpty(item[i]) 
                        && !string.IsNullOrEmpty(item[i])
                        && item[i].Equals(item[j]))
                    {
                        //Select a pair 1
                        lstErr.Add(new ErrorDropDownlist(EnumDropdownlistError.Duplicate, j.ToString()));
                        break;
                    }
                }
            }
            
            return lstErr;
        }
        
        /// <summary>
        /// Check Selected Pair
        /// </summary>
        /// <param name="value1"></param>
        /// <param name="value2"></param>
        /// <returns></returns>
        private bool CheckSelectedPair(string value1, string value2)
        {
            return !((string.IsNullOrEmpty(value1) && !string.IsNullOrEmpty(value2))
                 || (!string.IsNullOrEmpty(value1) && string.IsNullOrEmpty(value2))
                   );
        }
        
        /// <summary>
        /// Error Dropdownlist
        /// </summary>
        public enum EnumDropdownlistError
        {
            SelectPair = 0,
            Duplicate,
            Ok
        }
        public class ErrorDropDownlist
        {
            public EnumDropdownlistError enumError { get; set; }
            public string position { get; set; }

            public ErrorDropDownlist(EnumDropdownlistError enumError, string position)
            {
                this.enumError = enumError;
                this.position = position;
            }
        }
    }

    /// <summary>
    /// Customer List
    /// Author: ISV-Loc
    /// </summary>
    public class CustomerList : BaseList
    {
        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iStringLength(Constant.MCUSTOMER_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool chk_DeleteData { get; set; }
    }

    /// <summary>
    /// Customer Results
    /// Author: ISV-Loc
    /// </summary>
    public class CustomerResults
    {
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0031)]
        public string Tel { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Customer List For CSV
    /// Author: ISV-Loc
    /// </summary>
    public class CustomerListCSV
    {
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Email { get; set; }
        public string Tel { get; set; }
        public string Fax { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
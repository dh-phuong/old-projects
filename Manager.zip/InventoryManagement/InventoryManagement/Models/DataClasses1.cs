using System.Data.Linq.Mapping;
using System.Reflection;
namespace InventoryManagement.Models
{
    /// <summary>
    /// DataContext
    /// Author: ISV-Vinh
    /// </summary>
    partial class DataClasses1DataContext
    {
        /// <summary>
        /// ISNULL SQL Command for Int
        /// </summary>
        /// <param name="field">value</param>
        /// <param name="output">null value</param>
        /// <returns>int value</returns>
        [Function(Name = "ISNULL", IsComposable = true)]
        [return: Parameter(DbType = "INT")]
        public int IsNullInt(
            [Parameter(Name = "field", DbType = "INT")] int field,
            [Parameter(Name = "output", DbType = "INT")] int output)
        {
            return ((int)(this.ExecuteMethodCall(this,
                    ((MethodInfo)(MethodInfo.GetCurrentMethod())),
                    field, output).ReturnValue));
        }

        /// <summary>
        /// ISNULL SQL Command for Boolean
        /// </summary>
        /// <param name="field">value</param>
        /// <param name="output">null value</param>
        /// <returns>Boolean value</returns>
        [Function(Name = "ISNULL", IsComposable = true)]
        [return: Parameter(DbType = "BIT")]
        public bool IsNullBool(
            [Parameter(Name = "field", DbType = "BIT")] bool field,
            [Parameter(Name = "output", DbType = "BIT")] bool output)
        {
            return ((bool)(this.ExecuteMethodCall(this,
                    ((MethodInfo)(MethodInfo.GetCurrentMethod())),
                    field, output).ReturnValue));
        }
    }
}

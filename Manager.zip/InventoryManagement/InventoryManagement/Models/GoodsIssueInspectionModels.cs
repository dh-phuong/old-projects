﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    // <summary>
    /// Goods Issue Inspection List (For search)
    /// Author: ISV-Giam
    /// </summary>
    public class GoodsIssueInspectionList : BaseList
    {
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iCompareDateTAttribute("dCtr_ShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0153, Constant.LBL_L0154)]
        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateTo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        public GoodsIssueInspectionList()
        {
            dCtr_ShipDateFrom = new DateControl();
            dCtr_ShipDateTo = new DateControl();
        }
    }

    /// <summary>
    /// Goods Issue Inspection Results
    /// Author: ISV-Giam
    /// </summary>
    public class GoodsIssueInspectionResults 
    {
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        //public string CreateDate { get; set; }
        //public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        //public string UpdateUCD { get; set; }
    }


    /// <summary>
    /// Goods Issue Inspection Header
    /// Author: ISV-LOC
    /// </summary>
    public class GoodsIssueInspectionHeader : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string txt_ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string txt_LocationCD { get; set; }

        [iStringLength(Constant.TINVENTORY_TAGNO_INFO, Constant.TINVENTORY_TAGNO_INFO)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        public string UpdateDate { get; set; }
        public bool isShowShipNo { get; set; }
        public bool isShowTagNo { get; set; }
        public bool isCheckShipNo { get; set; }
        public string ShipNoDB { get; set; }
    }

    /// <summary>
    /// Goods Issue Inspection Detail
    /// Author: ISV-LOC
    /// </summary>
    public class GoodsIssueInspectionDetail
    {

        [iDisplayName(Name = Constant.LBL_L0166)]
        public int CheckedQuantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0150)]
        public int DeliveryQuantity { get; set; }
        
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        //public string TagInfo { get; set; }
        public string TagNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public int ShipDetailNo { get; set; }
        //public string UpdateDate { get; set; }
        
    }

}

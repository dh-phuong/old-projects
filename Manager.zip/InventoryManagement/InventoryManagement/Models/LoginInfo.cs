﻿using System.Linq;
using System.ComponentModel.DataAnnotations;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.Collections.Generic;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Login Info
    /// Author: ISV-Phuong
    /// </summary>
    public class LoginInfo: System.IDisposable
    {
        public UserModels User { get; set; }
        public string WarehouseCD { get; set; }
        public List<MGroup_D> ListGroupDetail { get; set; }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.User = null;
            this.WarehouseCD = null;
        }
    }


}
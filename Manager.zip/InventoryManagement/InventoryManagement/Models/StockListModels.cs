﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    public class StockListConditionModels : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txtProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txtProductName { get; set; }
       
        public string txtLocationCDFrom { get; set; }

        public string txtLocationNameFrom { get; set; }

        public string txtLocationCDTo { get; set; }

        public string txtLocationNameTo { get; set; }

        public bool CheckTagNo { get; set; }
        public bool CheckBranchTagNo { get; set; }
        public bool CheckProduct { get; set; }
        public bool CheckLocation { get; set; }        

        public StockListConditionModels()
        {
            CheckTagNo = true;
            CheckProduct = true;
            txtProductCD = string.Empty;
            txtProductName = string.Empty;
            txtLocationCDFrom = string.Empty;
            txtLocationNameFrom = string.Empty;
            txtLocationCDTo = string.Empty;
            txtLocationNameTo = string.Empty;
        }
    }

    public class StockListModels : BaseReport<StockListModels>
    {
        public StockListModels(System.Data.SqlClient.SqlDataReader dr)
        {
            // TODO: Complete member initialization
            this.locationCd = Convert.ToString(dr["locationCd"]);
            this.locationName = Convert.ToString(dr["locationName"]);
            this.ProductCd = Convert.ToString(dr["ProductCd"]);
            this.ProductName = Convert.ToString(dr["ProductName"]);
            this.TagNo = Convert.ToString(dr["TagNo"]);
            this.Lot1 = Convert.ToString(dr["Lot1"]);
            this.Lot2 = Convert.ToString(dr["Lot2"]);
            this.Lot3 = Convert.ToString(dr["Lot3"]);
            this.UnitQuantity = Convert.ToInt32(dr["UnitQuantity"]);
            this.QuantityPerUnit = Convert.ToDecimal(dr["QuantityPerUnit"]);
            this.StoredCost = Convert.ToDecimal(dr["StoredCost"]);
            this.TotalCost = Convert.ToDecimal(dr["TotalCost"]);
        }

        public StockListModels()
        {
            // TODO: Complete member initialization
        }

        public string locationCd { get; set; }
        public string locationName { get; set; }
        public string ProductCd { get; set; }        
        public string ProductName { get; set; }
        public string TagNo { get; set; }
        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }
        public int UnitQuantity { get; set; }
        public decimal QuantityPerUnit { get; set; }
        public decimal StoredCost { get; set; }
        public decimal TotalCost { get; set; }
    }    
}
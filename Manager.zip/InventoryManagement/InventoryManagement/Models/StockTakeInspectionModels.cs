﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    public class StockTakeInspectionModels : BaseList
    {
        public string LocationDB { get; set; }

        [iRequired]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        public string txt_LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string txt_LocationName { get; set; }

        [iStringLength(Constant.TINVENTORY_TAGNO_INFO_MAX, MinimumLength = Constant.TINVENTORY_TAGNO_INFO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        [iPatternAttribute(PatternType.NumbericSubstract)]
        public string txt_TagNo { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0229)]
        //public bool chk_NoCheckOnly { get; set; }
    }

    public class StockTakeInspectionResults
    {
        [iDisplayName(Name = Constant.LBL_L0155)]
        public bool TakeFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNoAndBranchTagNo { get; set; }

        //public string TagNo { get; set; }

        //public string BranchTagNo { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0018)]
        //public string ProductCD { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0019)]
        //public string ProductName { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0084)]
        //public string LOT1 { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0085)]
        //public string LOT2 { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0086)]
        //public string LOT3 { get; set; }

        public string UpdateDate { get; set; }

        public string TakeStatus { get; set; }
    }

    /// <summary>
    /// 棚卸のリスト
    /// Author: ISV-Nho
    /// </summary>
    public class StockTakeList : BaseList
    {
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        public string txt_LocationCD { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0052)]
        public string txt_LocationName { get; set; }

        [iCompareDateTAttribute("SrhTakeStartDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0231, Constant.LBL_L0232)]
        public DateControl SrhTakeStartDateFrom { get; set; }
        public DateControl SrhTakeStartDateTo { get; set; }

        [iCompareDateTAttribute("SrhTakeEndDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0234, Constant.LBL_L0235)]
        public DateControl SrhTakeEndDateFrom { get; set; }
        public DateControl SrhTakeEndDateTo { get; set; }

        public StockTakeList()
        {
            SrhTakeStartDateFrom = new DateControl();
            SrhTakeStartDateTo = new DateControl();
            SrhTakeEndDateFrom = new DateControl();
            SrhTakeEndDateTo = new DateControl();
        }
    }

    /// <summary>
    /// 棚卸の結果
    /// Author: ISV-Nho
    /// </summary>
    public class StockTakeResults
    {
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0230)]
        public string TakeStartDate { get; set; }

        public string UpdateDate { get; set; }
    }

    
}
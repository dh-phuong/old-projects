﻿using System;
using System.Collections.Generic;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.Web.Mvc;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Date Control
    /// Author: ISV-Nho
    /// </summary>
    public class DateControl
    {
        [iDisplayName(Name = Constant.LBL_L0130)]
        [iStringLength(Constant.DAY_MAX)]
        [iDDate("Month", "Year")]
        public string Day { get; set; }

        private string _month;

        [iDisplayName(Name = Constant.LBL_L0131)]
        [iStringLength(Constant.MONTH_MAX)]
        [iMDate("Day", "Year")]
        public string Month
        {
            get
            {
                return _month;
            }
            set
            {
                _month = value;
                SetDropDownForMonth();
            }
        }

        [iDisplayName(Name = Constant.LBL_L0132)]
        [iStringLength(Constant.YEAR_MAX)]
        [iYDate("Day", "Month")]
        public string Year { get; set; }

        public List<SelectListItem> itemsMonth;

        /// <summary>
        /// Constructor
        /// </summary>
        public DateControl()
        {
            Month = string.Empty;
            SetDropDownForMonth();
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dateValue">date value</param>
        public DateControl(string dateValue)
        {
            Month = string.Empty;
            if (!string.IsNullOrEmpty(dateValue))
            {

                Day = dateValue.Substring(6, 2);
                Month = dateValue.Substring(4, 2);
                Year = dateValue.Substring(0, 4);
            }
            SetDropDownForMonth();
        }

        /// <summary>
        /// get value of Date
        /// </summary>
        /// <returns></returns>
        public string DateValue()
        {
            return String.Format("{0}{1}{2}", Year, Month, Day);
        }

        /// <summary>
        /// Set DropDown For Month
        /// </summary>
        private void SetDropDownForMonth()
        {
            itemsMonth = new List<SelectListItem>();

            itemsMonth.Add(new SelectListItem { Text = "--", Value = "", Selected = (string.IsNullOrEmpty(Month) || Month.Equals("")) });
            itemsMonth.Add(new SelectListItem { Text = "01", Value = "01", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("01")) });
            itemsMonth.Add(new SelectListItem { Text = "02", Value = "02", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("02")) });
            itemsMonth.Add(new SelectListItem { Text = "03", Value = "03", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("03")) });
            itemsMonth.Add(new SelectListItem { Text = "04", Value = "04", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("04")) });
            itemsMonth.Add(new SelectListItem { Text = "05", Value = "05", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("05")) });
            itemsMonth.Add(new SelectListItem { Text = "06", Value = "06", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("06")) });
            itemsMonth.Add(new SelectListItem { Text = "07", Value = "07", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("07")) });
            itemsMonth.Add(new SelectListItem { Text = "08", Value = "08", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("08")) });
            itemsMonth.Add(new SelectListItem { Text = "09", Value = "09", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("09")) });
            itemsMonth.Add(new SelectListItem { Text = "10", Value = "10", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("10")) });
            itemsMonth.Add(new SelectListItem { Text = "11", Value = "11", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("11")) });
            itemsMonth.Add(new SelectListItem { Text = "12", Value = "12", Selected = (!string.IsNullOrEmpty(Month) && Month.Equals("12")) });
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Move Indication List
    /// Author:ISV-HUNG
    /// </summary>
    public class MoveIndicationList : BaseList
    {
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string txt_MoveNo { get; set; }

        [iCompareDateTAttribute("SrhMoveDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0200, Constant.LBL_L0201)]
        public DateControl SrhMoveDateFrom { get; set; }

        public DateControl SrhMoveDateTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string ddl_MoveKind { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0298)]
        public string txt_WarehouseCDTo { get; set; }

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0299)]
        public string txt_WarehouseName { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0298)]
        public string txt_LocationCDTo { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0299)]
        public string txt_LocationName { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0087)]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_MEMO_MAX)]
        public string Memo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0148)]
        public string lbl_NotGoodsIssueDataOnly { get; set; }
        public bool cbk_NotGoodsIssueDataOnly { get; set; }

        [iDisplayName(Name = Constant.LBL_L0090)]
        public string lbl_NotPrintDataOnly { get; set; }
        public bool cbk_NotPrintDataOnly { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public string lbl_DeleteData { get; set; }
        public bool chk_DeleteData { get; set; }

        public bool isPreLoad { get; set; }

        public bool chk_CheckAll { get; set; }

        public MoveIndicationList()
        {
            SrhMoveDateFrom = new DateControl();
            SrhMoveDateTo = new DateControl();
            ddl_MoveKind = string.Empty;
        }
    }

    /// <summary>
    /// Move Indication Results
    /// Author: ISV-HUNG
    /// </summary>
    public class MoveIndicationResults
    {
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string MoveNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0298)]
        public string DestinationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0299)]
        public string DestinationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0301)]
        public string DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0189)]
        public bool PickingCompleteFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0089)]
        public bool ShippingPrintFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteData { get; set; }

        [iDisplayName(Name = Constant.LBL_L0149)]
        public bool Print { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string MoveKindDisp { get; set; }

        public string MoveKind { get; set; }
        public string ddMoveKind { get; set; }
        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Move Indication Main
    /// Author:ISV-HUNG
    /// </summary>
    public class MoveIndicationMain : BaseModel
    {
        public string MoveKind { get; set; }

        [iDisplayName(Name = Constant.LBL_L0195)]
        public string PreMoveNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string txt_MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string ddl_MoveKind { get; set; }

        public string moveKindDisp { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WarehouseCDTo { get; set; }

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WarehouseName { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0191)]
        public string txt_LocationCDTo { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0192)]
        public string txt_LocationName { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0087)]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_MEMO_MAX)]
        public string Memo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public bool CompleteFlag { get; set; }
        public bool IsPicked { get; set; }
        public bool CheckDeleteAll { get; set; }
        public List<MoveIndicationDetailGrid> Detail { get; set; }

        public MoveIndicationMain()
        {
            Detail = new List<MoveIndicationDetailGrid>();
            MoveDate = new DateControl();
        }

        public PagingInfo PageInfo { get; set; }
        public int MaxQty { get; set; }
        public int CurQty { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }

    /// <summary>
    /// Move Indication Detail Grid
    /// Author:ISV-HUNG
    /// </summary>
    public class MoveIndicationDetailGrid : BaseModel
    {
        public int NumRow { get; set; }

        public string MoveKind { get; set; }

        //[iStringLengthGridAttribute(Constant.TINVENTORY_TAGNO_INFO, Constant.TINVENTORY_TAGNO_INFO, RowIndexName = "NumRow")]
        //[iPatternGridAttribute(Common.PatternType.NumbericSubstract, RowIndexName = "NumRow")]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string txt_LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txt_ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txt_ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string txt_ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string txt_Lot1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string txt_LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string txt_LOT3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string txt_StockStatusDisp { get; set; }

        public string StockStatus { get; set; }

        public bool IsPicked { get; set; }
        public bool IsDelied { get; set; }
        public bool Delete { get; set; }
        public bool CompleteFlag { get; set; }
        public bool IsUsedMoveNo { get; set; }
        public MoveIndicationDetailGrid()
        {
        }

        public MoveIndicationDetailGrid(int numRow, int seqNum)
        {
            NumRow = numRow;
            SeqNum = SeqNum;
            txt_TagInfo = string.Empty;
            txt_LocationCD = string.Empty;
            txt_ProductCD = string.Empty;
            txt_ArrivalDate = string.Empty;
            txt_Lot1 = string.Empty;
            txt_LOT2 = string.Empty;
            txt_LOT3 = string.Empty;
            StockStatus = string.Empty;
            IsPicked = false;
            IsDelied = false;
            CompleteFlag = false;
        }

        /// <summary>
        /// is empty row
        /// </summary>
        /// <returns>true:empty, false: not empty</returns>
        public bool isEmptyRow()
        {
            return string.IsNullOrEmpty(txt_TagInfo);
        }
    }

    ///// <summary>
    ///// Move Indication Detail (Search)
    ///// Author: ISV-HUNG
    ///// </summary>
    //public class MoveIndicationDetail1 : BaseSearch
    //{
    //    public bool OnSearch { get; set; }
    //    public bool IsErrors { get; set; }
    //    public int RowNo { get; set; }
    //    public bool ShippingCompleteFlag { get; set; }
    //    public string MoveNo { get; set; }
    //    public string MoveKind { get; set; }
    //    public string InstructQuantity { get; set; }

    //    public PagingInfo PageInfo { get; set; }

    //    public string txt_WarehouseCDTo { get; set; }
    //    public string txt_LocationCDTo { get; set; }

    //    [iPatternAttribute(PatternType.UpperAlpaNumericFlash)]
    //    [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
    //    [iDisplayName(Name = Constant.LBL_L0018)]
    //    public string txt_ProductCD { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0019)]
    //    public string txt_ProductName { get; set; }

    //    [iPatternAttribute(PatternType.Numeric)]
    //    [iStringLength(Constant.TINVENTORY_TAGNO_INFO_MAX)]
    //    [iDisplayName(Name = Constant.LBL_L0106)]
    //    public string txt_TagNo { get; set; }

    //    [iCompareDateTAttribute("ctr_ArrivalDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0125, Constant.LBL_L0126)]
    //    public DateControl ctr_ArrivalDateFrom { get; set; }
    //    public DateControl ctr_ArrivalDateTo { get; set; }

    //    [iCompareDateTAttribute("ctr_LOT2DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0136, Constant.LBL_L0137)]
    //    public DateControl ctr_LOT2DateFrom { get; set; }
    //    public DateControl ctr_LOT2DateTo { get; set; }

    //    [iCompareDateTAttribute("ctr_LOT3DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0138, Constant.LBL_L0139)]
    //    public DateControl ctr_LOT3DateFrom { get; set; }
    //    public DateControl ctr_LOT3DateTo { get; set; }

    //    [iPatternAttribute(PatternType.UpperAlpaNumericFlash)]
    //    [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
    //    [iDisplayName(Name = Constant.LBL_L0084)]
    //    public string txt_LOT1 { get; set; }

    //    public MoveIndicationDetail1()
    //    {
    //        ctr_ArrivalDateFrom = new DateControl();
    //        ctr_ArrivalDateTo = new DateControl();
    //        ctr_LOT2DateFrom = new DateControl();
    //        ctr_LOT2DateTo = new DateControl();
    //        ctr_LOT3DateFrom = new DateControl();
    //        ctr_LOT3DateTo = new DateControl();

    //    }
    //}

    /// <summary>
    /// Move Indication All
    /// </summary>
    public class MoveIndicationAll : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0196)]
        public string txt_MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string ddl_MoveKind { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }
        
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0244)]
        public string txt_LocationCDFrom { get; set; }//LocationCD From

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0192)]
        public string txt_LocationNameFrom { get; set; }//LocationCD Name From

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0245)]
        public string txt_LocationCDTo { get; set; }//LocationCD To

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0192)]
        public string txt_LocationNameTo { get; set; }//LocationCD Name To

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WarehouseCDTo { get; set; }//WareohouseCD To

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WarehouseNameTo { get; set; }//WareohouseCD Name To

        [iDisplayName(Name = Constant.LBL_L0087)]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_MEMO_MAX)]
        public string Memo { get; set; }

        public System.Collections.Generic.List<MoveIndicationAllResults> ResultsDetail { get; set; }
        public bool isChange { get; set; }
    }

    /// <summary>
    /// Move Indication All Results (Search result)
    /// Author: ISV-HUNG
    /// </summary>
    public class MoveIndicationAllResults : BaseModel
    {
        public int NumRow { get; set; }

        public string MoveKind { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string Lot1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string StockStatusDisp { get; set; }

        public string StockStatus { get; set; }
    }

    #region Print

    /// <summary>
    /// Print Header
    /// Author: ISV-HUNG
    /// </summary>
    public class Print_MoveIndication_Header
    {
        public string ShipNo { get; set; }
        public string ShipDate { get; set; }
        public string InstructDate { get; set; }
        public string DestinationWarehouseCD { get; set; }
        public string DestinationWarehouseCDNm { get; set; }
        public string DestinationLocationCD { get; set; }
        public string DestinationLocationCDNm { get; set; }
        public bool ShippingCompleteFlag { get; set; }
        public string DeliveryNumber { get; set; }        
    }

    /// <summary>
    /// Print Detail
    /// Author: ISV-HUNG
    /// </summary>
    public class Print_MoveIndication_Detail
    {
        public string ShipNo { get; set; }
        public string Warehouse { get; set; }
        public string Location { get; set; }
        public string LocationCD { get; set; }
        public string TagNo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }
        public int Quantity { get; set; }
        public bool IsDelied { get; set; }
    }

    #endregion

    /// <summary>
    /// Move Indication Model class
    /// Author: HUNG
    /// </summary>
    public class MoveIndicationModel : BaseModel
    {
        /// <summary>
        /// ShipNo
        /// </summary>
        public string ShipNo { get; set; }

        /// <summary>
        /// ShipDetailNo
        /// </summary>
        public int ShipDetailNo { get; set; }

        /// <summary>
        /// ShipDate
        /// </summary>
        public string ShipDate { get; set; }

        /// <summary>
        /// InstructDate
        /// </summary>
        public string InstructDate { get; set; }

        /// <summary>
        /// DestinationWarehouseCD
        /// </summary>
        public string DestinationWarehouseCD { get; set; }

        /// <summary>
        /// DestinationWarehouseCDNm
        /// </summary>
        public string DestinationWarehouseCDNm { get; set; }

        /// <summary>
        /// DestinationLocationCD
        /// </summary>
        public string DestinationLocationCD { get; set; }

        /// <summary>
        /// DestinationLocationCDNm
        /// </summary>
        public string DestinationLocationCDNm { get; set; }

        /// <summary>
        /// LocationCD
        /// </summary>
        public string LocationCD { get; set; }

        /// <summary>
        /// TagNo
        /// </summary>
        public string TagNo { get; set; }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Lot1
        /// </summary>
        public string Lot1 { get; set; }

        /// <summary>
        /// Lot2
        /// </summary>
        public string Lot2 { get; set; }

        /// <summary>
        /// Lot3
        /// </summary>
        public string Lot3 { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Total
        /// </summary>
        public decimal? TotalQuantity { get; set; }
    }
}
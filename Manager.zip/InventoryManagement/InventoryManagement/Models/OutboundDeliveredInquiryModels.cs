﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{

    /// <summary>
    /// ISV-Nho
    /// </summary>
    public class OutboundDeliveredInquiryModels
    {
    }

    /// <summary>
    /// Outbound Delivered Inquiry List (For search)
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveredInquiryList : BaseList
    {
        [iStringLength(Constant.TINVENTORY_TAGNO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        [iPatternAttribute(PatternType.Numeric)]
        public string txt_ShipNo { get; set; }

        [iCompareDateTAttribute("dCtr_ShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0200, Constant.LBL_L0201)]
        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0300)]
        public string ddl_Kind { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WareCDTo { get; set; }

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WareNmTo { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string txt_Lot1 { get; set; }

        [iCompareDateTAttribute("dCtr_Lot2To", CompareType.LessThanOrEqual, Constant.LBL_L0136, Constant.LBL_L0137)]
        public DateControl dCtr_Lot2From { get; set; }
        public DateControl dCtr_Lot2To { get; set; }

        [iCompareDateTAttribute("dCtr_Lot3To", CompareType.LessThanOrEqual, Constant.LBL_L0138, Constant.LBL_L0139)]
        public DateControl dCtr_Lot3From { get; set; }
        public DateControl dCtr_Lot3To { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }

        public bool IsUserCustomer { get; set; }
        public OutboundDeliveredInquiryList()
        {
            dCtr_ShipDateFrom = new DateControl();
            dCtr_ShipDateTo = new DateControl();
            dCtr_Lot2From = new DateControl();
            dCtr_Lot2To = new DateControl();
            dCtr_Lot3From = new DateControl();
            dCtr_Lot3To = new DateControl();
            IsUserCustomer = false;
        }
    }

    /// <summary>
    /// Outbound Delivered Inquiry Results
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveredInquiryResults
    {
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0302)]
        public string DataCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0303)]
        public string DataName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0301)]
        public string DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0300)]
        public string KindName { get; set; }
    }

    /// <summary>
    /// Outbound Delivered Inquiry Header
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveredInquiryHeader : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0300)]
        public string txt_KindName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string txt_ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0030)]
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WareCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WareNmTo { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_MEMO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0087)]
        public string txt_Memo { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Outbound Delivered Inquiry Detail
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveredInquiryDetail
    {
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }
    }
}
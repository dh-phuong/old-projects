﻿using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.Collections.Generic;
using System.Linq;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Inventory Reference Group Models
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryGroupModels : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNoDisp { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string sSuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string sSuplierName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string sProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string sProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0127)]
        [iInteger(MinValue = 1)]
        public string sUnitQuantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        [iDecimal(Constant.TINVENTORY_TOTAL_COST_PRECISION, Constant.TINVENTORY_TOTAL_COST_SCALE)]
        public string sTotalCost { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string sLOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string sLOT2 { get; set; }

        public DateControl LOT2Date { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string sLOT3 { get; set; }

        public DateControl LOT3Date { get; set; }

        [iStringLength(Constant.TINVENTORY_MEMO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0087)]
        public string sMemo { get; set; }

        public string TagNo { get; set; }
        public string UpdateDate { get; set; }

        public List<GroupListDetail> listGroup { get; set; }

        public List<string> arrBranchTagNo { get; set; }
        public List<string> arrLocationCD { get; set; }
        public List<string> arrStoredDate { get; set; }
        public List<string> arrStockStatus { get; set; }
        public List<string> arrStockStatusDisp { get; set; }
        public List<bool> arrCanEditStatus { get; set; }

        //Label
        [iDisplayName(Name = Constant.LBL_L0079)]
        public string sBranchTagNo { get; set; }
        
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string sLocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0105)]
        public string sStoredDate { get; set; }
        
        [iDisplayName(Name = Constant.LBL_L0129)]
        public string sStockStatus { get; set; }

        public bool IsEditCus { get; set; }
        public bool IsShowSuplier { get; set; }
        public bool chk_CheckAll { get; set; }
    }

    /// <summary>
    /// Class All List Detail
    /// Author: ISV-Loc
    /// </summary>
    public class GroupListDetail
    {
        [iDisplayName(Name = Constant.LBL_L0079)]
        public string BranchTagNo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SuplierName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0127)]
        public string UnitQuantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        public string TotalCost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0087)]
        public string Memo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0105)]
        public string StoredDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string StockStatus { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string StockStatusDisp { get; set; }

        public bool IsCanEdit { get; set; }
        public string TagNo { get; set; }
        public string BranchTagNoDisp { get; set; }
        
    }

    /// <summary>
    /// Detail Branch
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryBranchModels : BaseModel
    {
        public bool IsShowSuplier { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNoDisp { get; set; }

        public string TagNo { get; set; }
        public string BranchTagNo { get; set; }
        public string UpdateDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SuplierName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0105)]
        public string StoredDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0127)]
        [iInteger(MinValue = 1)]
        public string UnitQuantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        [iDecimal(Constant.TINVENTORY_TOTAL_COST_PRECISION, Constant.TINVENTORY_TOTAL_COST_SCALE)]
        public string TotalCost { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        public DateControl LOT2Date { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public DateControl LOT3Date { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string StockStatus { get; set; }

        public string StockStatusDisp { get; set; }

        public bool canEditStatus { get; set; }

        [iStringLength(Constant.TINVENTORY_MEMO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0087)]
        public string Memo { get; set; }

        public bool IsEditCus { get; set; }
    }

    /// <summary>
    /// Search Conditions
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryList : BaseList
    {
        [iStringLength(Constant.TINVENTORY_TAGNO_INFO_MAX)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string txt_SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string txt_SuplierName { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txt_ProductCD { get; set; }

        [iStringLength(Constant.MPRODUCT_PRODUCT_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txt_ProductName { get; set; }

        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string txt_CategoryCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0205)]
        public string txt_CategoryNm { get; set; }

        [iCompareStringTAttribute("txtLocationCDTo", CompareType.LessThanOrEqual, Constant.LBL_L0244, Constant.LBL_L0245)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0244)]
        public string txtLocationCDFrom { get; set; }

        public string txtLocationNameFrom { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0245)]
        public string txtLocationCDTo { get; set; }

        public string txtLocationNameTo { get; set; }

        [iCompareDateTAttribute("txt_StoredDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0134, Constant.LBL_L0135)]
        public DateControl txt_StoredDateFrom { get; set; }
        public DateControl txt_StoredDateTo { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string txt_LOT1 { get; set; }

        [iCompareDateTAttribute("txt_LOT2To", CompareType.LessThanOrEqual, Constant.LBL_L0136, Constant.LBL_L0137)]
        public DateControl txt_LOT2From { get; set; }
        public DateControl txt_LOT2To { get; set; }

        [iCompareDateTAttribute("txt_LOT3To", CompareType.LessThanOrEqual, Constant.LBL_L0138, Constant.LBL_L0139)]
        public DateControl txt_LOT3From { get; set; }
        public DateControl txt_LOT3To { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string ddl_Status { get; set; }

        public bool IsShowSuplier { get; set; }

        [iDisplayName(Name = Constant.LBL_L0133)]
        public bool chk_GroupBranchTagNo { get; set; }

        public StockInquiryList()
        {
            txt_StoredDateFrom = new DateControl();
            txt_StoredDateTo = new DateControl();
            
            txt_LOT2From = new DateControl();
            txt_LOT2To = new DateControl();

            txt_LOT3From = new DateControl();
            txt_LOT3To = new DateControl();
        }
    }

    /// <summary>
    /// Result List 
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryResults
    {
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SuplierName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0127)]
        public int? Quantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0105)]
        public string StoredDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string StockStatus { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNoDisp { get; set; }

        public bool IsShowSuplier { get; set; }
        public string BranchTagNo { get; set; }
        public string TagNo { get; set; }
        public string StockStatusName { get; set; }
    }
    
    /// <summary>
    /// Stock Inquiry Group CSV
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryGroupCSV
    {
        public string TagNo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string UnitQuantity { get; set; }
        public string ArrivalDate { get; set; }
        public string TotalCost { get; set; }
        public string LOT1 { get; set; }
        public string LOT2 { get; set; }
        public string LOT3 { get; set; }
    }

    /// <summary>
    /// Stock Inquiry Branch CSV
    /// Author: ISV-Loc
    /// </summary>
    public class StockInquiryBranchCSV
    {
        public string TagNo { get; set; }
        public string BranchTagNo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string LocationCD { get; set; }
        public string ArrivalDate { get; set; }
        public string StoredDate { get; set; }
        public string TotalCost { get; set; }
        public string LOT1 { get; set; }
        public string LOT2 { get; set; }
        public string LOT3 { get; set; }
        public string StockStatusName { get; set; }
    }

    /// <summary>
    /// Stock Inquiry Print
    /// Author: ISV-LOC
    /// </summary>
    public class StockInquiryPrintInput
    {
        public string TagNo { get; set; }
        public List<string> ListBranch { get; set; }
        public bool TagPrintFlag { get; set; }

        public StockInquiryPrintInput()
        {
            ListBranch = new List<string>();
        }
    }

    /// <summary>
    /// Stock Inquiry Print Models
    /// </summary>
    public class StockInquiryPrintModels : BaseModel
    {
        public string TagNo { get; set; }
        public string BranchTagNo { get; set; }
        public string UpdateDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0105)]
        public string StoredDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0127)]
        [iInteger(MinValue = 1)]
        public string UnitQuantity { get; set; }

        public string QuantityPerUnit { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public bool TagPrintFlag { get; set; }
    }
}
﻿using InventoryManagement.Common;
using InventoryManagement.Validation;
namespace InventoryManagement.Models
{
    /// <summary>
    /// Search user
    /// Author: ISV-TRAM
    /// </summary>
    public class UserSearch : BaseSearch
    {
        [iPatternAttribute(PatternType.Numeric)]
        [iStringLength(Constant.MUSER_USER_CD_MAX, MinimumLength = Constant.MUSER_USER_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0006)]
        public string sUserCD { get; set; }

        [iPatternAttribute(PatternType.AlphaNumeric)]
        [iStringLength(Constant.MUSER_LOGIN_ID_MAX)]
        [iDisplayName(Name = Constant.LBL_L0009)]
        public string sLoginID { get; set; }

        [iStringLength(Constant.MUSER_USER_FULL_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0007)]
        public string sUserFullName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0008)]
        public string sUserShortName { get; set; }

        [iStringLength(Constant.MUSER_USER_FULL_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0007)]
        public string sUserName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0181)]
        public string sGroupCD { get; set; }
        public string sGroupName { get; set; }

    }

    /// <summary>
    /// Search product
    /// Author: ISV-PHUONG
    /// </summary>
    public class ProductSearch : BaseSearch
    {
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string sProductCD { get; set; }

        [iStringLength(Constant.MPRODUCT_PRODUCT_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0019)]
        public string sProductName { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string sCategoryCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0205)]
        public string CategoryNm { get; set; }

        [iDecimal(Constant.MPRODUCT_COST_PRECISION, Constant.MPRODUCT_COST_SCALE, Constant.MPRODUCT_COST_MIN, Constant.MPRODUCT_COST_MAX)]
        [iDisplayName(Name = Constant.LBL_L0081)]
        public decimal sTotal { get; set; }

        public bool IsStockOnly { get; set; }
        public string sShipNo { get; set; }
        //public string sLocationCDTo { get; set; }
    }

    /// <summary>
    /// Search customer
    /// Author: ISV-LOC
    /// </summary>
    public class CustomerSearch : BaseSearch
    {
        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string sCustomerCD { get; set; }

        [iStringLength(Constant.MCUSTOMER_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0029)]
        public string sCustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0031)]
        public string sTel { get; set; }

        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
    }

    /// <summary>
    /// Search kind
    /// Author:ISV-HUNG
    /// </summary>
    public class KindSearch : BaseSearch
    {
        [iDisplayName(Name = Constant.LBL_L0042)]
        public string sDataKind { get; set; }
        public string sDataKindNm { get; set; }

        [iStringLength(Constant.MKIND_DATA_CD_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0044)]
        public string sDataCD { get; set; }

        [iStringLength(Constant.MKIND_VALUE_MAX)]
        [iDisplayName(Name = Constant.LBL_L0045)]
        public string sValue { get; set; }

        public string sUpdateDate { get; set; }
    }

    /// <summary>
    /// Search warehouse
    /// Author:ISV-HUNG
    /// </summary>
    public class WarehouseSearch : BaseSearch
    {
        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string sWarehouseCD { get; set; }

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0059)]
        public string sWarehouseName { get; set; }

        public string sUpdateDate { get; set; }

        /// <summary>
        /// ISV-TRUC 
        /// 27.08.13
        /// </summary>
        /// <param name="dr"></param>
        public WarehouseSearch(System.Data.SqlClient.SqlDataReader dr)
        {
            this.sWarehouseCD = string.Format("{0}", dr["WarehouseCD"]);
            this.sWarehouseName = string.Format("{0}", dr["WarehouseName"]);
            this.sUpdateDate = string.Format("{0}", dr["UpdateDate"]);
        }

        public WarehouseSearch()
        {
            this.sWarehouseCD = string.Empty;
            this.sWarehouseName = string.Empty;
            this.sUpdateDate = string.Empty;
        }
    }

    /// <summary>
    /// Search location
    /// Author:ISV-HUNG
    /// </summary>
    public class LocationSearch : BaseSearch
    {
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string sLocationCD { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0052)]
        public string sLocationName { get; set; }

        public string sUpdateDate { get; set; }
        public string sReceiptOnlyFlag { get; set; }
        public string sIssueOnlyFlag { get; set; }
    }

    /// <summary>
    /// Search company
    /// Author: ISV-TRUC
    /// </summary>
    public class CompanySearch : BaseSearch
    {
        [iStringLength(Constant.MCOMPANY_COMPANYCD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0096)]
        [iPatternAttribute(PatternType.Numeric)]
        public string sCompanyCD { get; set; }

        [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0099)]
        public string sCompanyName { get; set; }

        [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0097)]
        public string sCompanyName1 { get; set; }

        [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0098)]
        public string sCompanyName2 { get; set; }
    }

    /// <summary>
    /// Search Group
    /// Author: ISV-Nho
    /// </summary>
    public class GroupSearch : BaseSearch
    {
        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iStringLength(Constant.MGROUP_GROUP_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string sGroupCD { get; set; }

        [iStringLength(Constant.MGROUP_GROUP_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string sGroupName { get; set; }
    }

    /// <summary>
    /// Search Category
    /// Author:ISV-TRUC
    /// </summary>
    public class CategorySearch : BaseSearch
    {
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string sCategoryCD { get; set; }

        [iStringLength(Constant.MCATEGORY_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0205)]
        public string sCategoryName { get; set; }

        public string sUpdateDate { get; set; }
    }

    public class TagInfoSearch : BaseSearch
    {
        public string MoveKind { get; set; }
        public string MoveNo { get; set; }
        public bool IsShowSuplier { get; set; }

        [iStringLengthAttribute(Constant.TINVENTORY_TAGNO_MAX)]
        [iPatternAttribute(Common.PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string sPTagNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string sPTagInfo { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string sPSupplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string sPSupplierName { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string sPProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string sPProductName { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string sPLocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string sPLocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string sPArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string sPLot1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string sPLot2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string sPLot3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0129)]
        public string sPStockStatus { get; set; }
    }
}

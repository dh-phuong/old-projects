﻿using InventoryManagement.Models;
using System.Collections;
using System.Linq;
using InventoryManagement.Common;
using System.Collections.Generic;

namespace InventoryManagement
{
    /// <summary>
    /// Cache data
    /// Author: ISV-Phuong
    /// </summary>
    public class Cache : System.IDisposable
    {
   
        #region Messages
        /// <summary>
        /// Message cache
        /// </summary>
        private Hashtable Messages;

        /// <summary>
        /// Init Messages Cache
        /// </summary>
        /// <param name="list"></param>
        public void AddMessages(IQueryable<Models.MMessage> Data)
        {
            InitMessageData(Data);
        }

        /// <summary>
        /// Init Message Data
        /// </summary>
        /// <param name="htb">Hashtable</param>
        /// <param name="list">list of MMessage</param>
        private void InitMessageData(IQueryable<Models.MMessage> list)
        {
            //Set data
            Messages = new Hashtable();
            foreach (MMessage item in list)
            {
                string msgVal;
                List<string> menuMsg = new List<string>() { Constant.MES_M0057, Constant.MES_M0058, Constant.MES_M0059, Constant.MES_M0060 };
                if (menuMsg.Contains(item.MessageID))
                {
                    msgVal = item.MessageStrings;
                }
                else
                {
                    msgVal = string.Format("{0} [{1}]", item.MessageStrings, item.MessageID);
                }
                Messages.Add(new KeyValuePair<string, int>(item.MessageID, item.Language), msgVal);
            }
        }

        /// <summary>
        /// Get message
        /// </summary>
        /// <param name="messageCD"></param>
        /// <returns></returns>
        public string GetMessage(string messageCD)
        {
            var Language = (LanguageFlag)UserSession.Session.Language;
            return (string)Messages[new KeyValuePair<string, int>(messageCD, (int)Language)];
        }


        #endregion

        #region Labels

        /// <summary>
        /// Label cache
        /// </summary>
        private Hashtable Labels;

        /// <summary>
        /// Init Messages Cache
        /// </summary>
        /// <param name="list"></param>
        public void AddLabels(IQueryable<Models.MLabel> Data)
        {
            InitLabelData(Data);
        }

        /// <summary>
        /// Init Message Data
        /// </summary>
        /// <param name="htb">Hashtable</param>
        /// <param name="list">list of MMessage</param>
        private void InitLabelData(IQueryable<Models.MLabel> list)
        {
            //Set data
            Labels = new Hashtable();
            foreach (MLabel item in list)
            {
                Labels.Add(new KeyValuePair<string, int>(item.LabelCD, item.Language), item.LabelStrings);
            }
        }

        /// <summary>
        /// Get Label
        /// </summary>
        /// <param name="labelCD">labelCD</param>
        /// <returns>Label string</returns>
        public string GetLabel(string labelCD)
        {
            var Language = (LanguageFlag)UserSession.Session.Language;
            return (string)Labels[new KeyValuePair<string, int>(labelCD, (int)Language)];
        }

        #endregion

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            this.Messages = null;
            this.Labels = null;
        }
    }
}
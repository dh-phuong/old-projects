﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class CategoryModels : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string CategoryCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MCATEGORY_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0205)]
        public string CategoryName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }
        public string PreCategoryCD { get; set; }
        public string CreateDate { get; set; }
        public string CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUID { get; set; }

        public bool IsExistsInOther { get; set; }
    }

    /// <summary>
    /// Category List Model
    /// Author: ISV-TRUC
    /// </summary>
    public class CategoryList : BaseList
    {
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string txt_CategoryCD { get; set; }

        [iStringLength(Constant.MCATEGORY_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0205)]
        public string txt_CategoryName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool chk_IncludeDeleteData { get; set; }
    }

    /// <summary>
    /// Category Results
    /// Author: ISV-TRUC
    /// </summary>
    public class CategoryResults
    {
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string CategoryCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0205)]
        public string CategoryName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Category CSV Models
    /// Author: ISV-TRUC
    /// </summary>
    public class CategoryCSV
    {
        public string CategoryCD { get; set; }
        public string CategoryName { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Balance In Stores Model
    /// Author : ISV-TRUC
    /// </summary>
    public class BalanceInStoresModels : BaseModel
    {
        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0246)]
        [iCompareDateTAttribute("BalanceDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0246, Constant.LBL_L0247)]
        public DateControl BalanceDateFrom { get; set; }

        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0247)]
        public DateControl BalanceDateTo { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0244)]
        public string LocationCDFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationNameFrom { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0245)]
        public string LocationCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationNameTo { get; set; }

        public bool CheckTagNo { get; set; }
        public bool CheckBranchTagNo { get; set; }
        public bool CheckProduct { get; set; }
        public bool CheckLocation { get; set; }

        //Default date
        public string Hid_DefaultDateFrom{get;set;}
        public string Hid_DefaultDateTo { get; set; }
        
        public BalanceInStoresModels()
        {
            CheckTagNo = true;
            CheckProduct = true;

            Hid_DefaultDateFrom = DateTime.Now.AddMonths(-3).AddDays(1).ToString(Constant.FMT_YMD);
            Hid_DefaultDateTo = DateTime.Now.ToString(Constant.FMT_YMD);

            BalanceDateFrom = new DateControl(Hid_DefaultDateFrom);
            BalanceDateTo = new DateControl(Hid_DefaultDateTo);
        }
    }

    public class BalanceInStoresProductHeader : BaseModel
    {
        public string BalanceDateFrom { get; set; }
        public string BalanceDateTo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public bool TypeReport { get; set; }
    }

    /// <summary>
    /// 
    /// Author : ISV-TRUC
    /// </summary>
    public class BalanceInStoresProductDetail : BaseModel
    {
        //public string TagNo { get; set; }
        //public string BranchTagNo { get; set; }
        public string TagInfo { get; set; }

        public int BalanceNo { get; set; }

        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }

        public string BalanceStatus { get; set; }
        public string BalanceStatusName { get; set; }
        public string BalanceDate { get; set; }
        public string LocationName { get; set; }
        public string Quantity { get; set; }
        public bool TypeReport { get; set; }

    }

    /// <summary>
    /// Balance In Stores Location Model
    /// Author : ISV-TRUC
    /// </summary>
    public class BalanceInStoresLocation : BaseReport<BalanceInStoresLocation>
    {
        public BalanceInStoresLocation(System.Data.SqlClient.SqlDataReader dr)
        {
            // TODO: Complete member initialization
            this.BalanceNo = Convert.ToInt32(dr["BalanceNo"]);
            this.BalanceStatus = Convert.ToString(dr["BalanceStatus"]);
            this.BalanceDate = Convert.ToString(dr["BalanceDate"]);
            this.BalanceStatusName = Convert.ToString(dr["BalanceStatusName"]);

            this.LocationCD = Convert.ToString(dr["LocationCD"]);
            this.LocationName = Convert.ToString(dr["LocationName"]);
            this.ProductCD = Convert.ToString(dr["ProductCD"]);
            this.ProductName = Convert.ToString(dr["ProductName"]);
            this.TagInfo = Convert.ToString(dr["TagInfo"]);
            this.Lot1 = Convert.ToString(dr["Lot1"]);
            this.Lot2 = Convert.ToString(dr["Lot2"]);
            this.Lot3 = Convert.ToString(dr["Lot3"]);
           
        }

        public BalanceInStoresLocation()
        {
            // TODO: Complete member initialization
        }




        //old
        public int BalanceNo { get; set; }

        public string LocationCD { get; set; }
        public string LocationName { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }

        public string TagInfo { get; set; }

        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }

        public string BalanceStatus { get; set; }
        public string BalanceStatusName { get; set; }
        public string BalanceDate { get; set; }

        public string Quantity { get; set; }
        public bool TypeReport { get; set; }

        public int RowIndex { get; set; }


        public int InbNormal { get; set; }
        public int InbReturn { get; set; }
        public int InbTranfer { get; set; }
        public int InbStock { get; set; }
        public int InbScrap { get; set; }

        public int RecNormal { get; set; }
        public int RecReturn { get; set; }
        public int RecTranfer { get; set; }
        public int RecStock { get; set; }
        public int RecScrap { get; set; }

        public int IssNormal { get; set; }
        public int IssReturn { get; set; }
        public int IssTranfer { get; set; }
        public int IssStock { get; set; }
        public int IssScrap { get; set; }

        public int OutNormal { get; set; }
        public int OutReturn { get; set; }
        public int OutTranfer { get; set; }
        public int OutStock { get; set; }
        public int OutScrap { get; set; }

    }

    /// <summary>
    /// Balance In Stores Product Model
    /// Author : ISV-TRUC
    /// </summary>
    public class BalanceInStoresProduct : BaseReport<BalanceInStoresProduct>
    {
        public BalanceInStoresProduct(System.Data.SqlClient.SqlDataReader dr)
        {
            // TODO: Complete member initialization
            this.BalanceNo = Convert.ToInt32(dr["BalanceNo"]);
            this.BalanceStatus = Convert.ToString(dr["BalanceStatus"]);
            this.BalanceDate = Convert.ToString(dr["BalanceDate"]);
            this.BalanceStatusName = Convert.ToString(dr["BalanceStatusName"]);

            this.LocationCD = Convert.ToString(dr["LocationCD"]);
            this.ProductCD = Convert.ToString(dr["ProductCD"]);
            this.ProductName = Convert.ToString(dr["ProductName"]);
            this.TagInfo = Convert.ToString(dr["TagInfo"]);
            this.Lot1 = Convert.ToString(dr["Lot1"]);
            this.Lot2 = Convert.ToString(dr["Lot2"]);
            this.Lot3 = Convert.ToString(dr["Lot3"]);
           
        }

        public BalanceInStoresProduct()
        {
            // TODO: Complete member initialization
        }

        public int BalanceNo { get; set; }
                
        public string ProductCD { get; set; }
        public string ProductName { get; set; }

        public string TagInfo { get; set; }

        public string LocationCD { get; set; }

        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }

        public string BalanceStatus { get; set; }
        public string BalanceStatusName { get; set; }
        public string BalanceDate { get; set; }

        public string Quantity { get; set; }
        public bool TypeReport { get; set; }

        public int RowIndex { get; set; }


        public int InbNormal { get; set; }
        public int InbReturn { get; set; }
        public int InbTranfer { get; set; }
        public int InbStock { get; set; }
        public int InbScrap { get; set; }

        public int RecNormal { get; set; }
        public int RecReturn { get; set; }
        public int RecTranfer { get; set; }
        public int RecStock { get; set; }
        public int RecScrap { get; set; }

        public int IssNormal { get; set; }
        public int IssReturn { get; set; }
        public int IssTranfer { get; set; }
        public int IssStock { get; set; }
        public int IssScrap { get; set; }

        public int OutNormal { get; set; }
        public int OutReturn { get; set; }
        public int OutTranfer { get; set; }
        public int OutStock { get; set; }
        public int OutScrap { get; set; }

    }

    public class BalanceInStoresCheckExcel : BaseReport<BalanceInStoresCheckExcel>
    {
        public BalanceInStoresCheckExcel(System.Data.SqlClient.SqlDataReader dr)
        {
            // TODO: Complete member initialization
            this.IsOutOfRange = Convert.ToInt32(dr["IsOutOfRange"]);
        }

        public BalanceInStoresCheckExcel()
        {
            // TODO: Complete member initialization
        }

        public int IsOutOfRange { get; set; }


    }
}
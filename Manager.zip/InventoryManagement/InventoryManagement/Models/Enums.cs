﻿using System.ComponentModel;

namespace InventoryManagement.Common
{
    /// <summary>
    /// セッションのライフサイクル(保持期間)
    /// Author: ISV-Phuong
    /// </summary>
    /// <remarks></remarks>
    public enum SessionLifecycle
    {
        Permanent,
        Temporary
    }

    /// <summary>
    /// Mode
    /// Author: ISV-Vinh
    /// </summary>
    public enum Mode
    {
        Insert = 0,
        Update,
        Delete,
        Show,
        Copy,
        Confirm,
        Select,
        Add,
        UserList,
        ProductList,
        SalesList,
        ConfirmSalesList,
        OrderSheet,
        Print,
        RemoveRow,
        Picking,
        Cancel
    };

    /// <summary>
    /// Common Flag
    /// Author: ISV-Vinh
    /// </summary>
    public enum CommonFlag
    {
        No = 0,
        Yes
    }

    /// <summary>
    /// Commit Flag
    /// Author: ISV-Vinh
    /// </summary>
    public enum CommitFlag
    {
        Success = 0,
        Failed,
        DataChanged,
        IsExistsInAnotherTB,
        InsertExclusion,
        DataIsEmpty
    }

    /// <summary>
    /// PatternType
    /// Author: ISV-Nho
    /// </summary>
    public enum PatternType
    {
        AlphaNumeric = 0,
        Email,
        HaflWidth,
        Numeric,
        Tel,
        UpperAlphaNumeric,
        AlphaNumericFlashSpace,
        UpperAlphaNumericFlash,
        NumbericSubstract,
        UpperAlphaNumericSubtract
    }

    /// <summary>
    /// 引当順
    /// Author: ISV-Loc
    /// </summary>
    public enum SortOrder
    {
        //昇順
        Ascending = 0,

        //降順
        Descending
    }

    /// <summary>
    /// Language
    /// Author: ISV-Vinh
    /// </summary>
    public enum LanguageFlag
    {
        English = 1,
        Vietnamese,
        Japanese
    }

    /// <summary>
    /// Language
    /// Author: ISV-Truc
    /// </summary>
    public enum PrintTypeFlag
    {
        None = 0,
        Big,
        Small
    }

    /// <summary>
    /// Print Condition Type Flag
    /// Author: ISV-Thuy
    /// </summary>
    public enum PrintConditionTypeFlag
    {
        None = 0,
        Location,
        Product
    }

    /// <summary>
    /// Format Type
    /// </summary>
    public enum TypeFormat
    {
        Int,
        Dec
    }
    
    /// <summary>
    /// Page Type
    /// </summary>
    public enum PageType
    {
        Windows = 0,
        PopUp       
    }

    /// <summary>
    /// Ware house Mode
    /// Author: ISV-Vinh
    /// </summary>
    public enum WareHouseMode
    {
        Single = 0,
        Multiple 
    }

    /// <summary>
    /// Report Type
    /// Author: ISV-Vinh
    /// </summary>
    public enum ReportType
    {
        Barcode = 0,
        Business,
        System,
    }

    /// <summary>
    /// Location Type
    /// Author: ISV-HUNG
    /// </summary>
    public enum LocationType
    {
        NotReceiptIssue=0,
        Receipt,
        Issue
    }

    /// <summary>
    /// Result Type
    /// ISV-Nho
    /// </summary>
    public enum ResultType
    {
        Success = 0,
        Fail,
        DataChangedByOrther,
        DuplicateCode,
        DataUsedByOrther
    }
}
﻿using InventoryManagement.Common;
using System.Text.RegularExpressions;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Fix Code 
    /// Author: ISV-Phuong
    /// </summary>
    public class FixCode
    {
        /// <summary>
        /// Fix iCode to Database
        /// </summary>
        /// <param name="iCode">input code</param>
        /// <returns>code</returns>       
        public static string FixCodeDB(string iCode, int iLength)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }
            Match match = Regex.Match(iCode, Constant.PATTERN_NUMERIC, RegexOptions.IgnoreCase);
            // Here we check the Match instance.
            if (match.Success)
            {
                return iCode.PadLeft(iLength, Constant.CHAR_ZERO);
            }
            return iCode;
        }

        /// <summary>
        /// Fix iCode to show
        /// </summary>
        /// <param name="userCD">iCode</param>
        /// <returns>iCode</returns>
        public static string FixCodeShow(string iCode, int iLength)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }

            return iCode.Substring(iCode.Length - iLength, iLength);
        }
    }

    /// <summary>
    /// Author: ISV-LOC
    /// </summary>
    public partial class MCustomer
    {
        /// <summary>
        /// Fix customer code to database
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <returns>customerCD</returns>
        public static string FixCodeDB(string customerCD)
        {
            string ret = customerCD;
            if (!string.IsNullOrEmpty(ret))
            {
                ret = ret.ToUpper();
            }
            return ret;
        }
    }

    /// <summary>
    /// Author: ISV-Vinh
    /// </summary>
    public partial class MLocation
    {
        /// <summary>
        /// Fix location code to database
        /// </summary>
        /// <param name="locationCD">Location CD</param>
        /// <returns>location CD</returns>
        public static string FixCodeDB(string locationCD)
        {
            if (!string.IsNullOrEmpty(locationCD))
            {
                locationCD = locationCD.ToUpper();
            }
            return locationCD;
        }
    }
}

﻿using InventoryManagement.Common;
using InventoryManagement.Validation;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Receipt Model
    /// Author: ISV-HUNG
    /// </summary>
    public class GoodsReceiptInspectionModels : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0105)]
        public string txt_StoredDate { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string txt_LocationCD { get; set; }

        [iStringLengthAttribute(Constant.TINVENTORY_TAGNO_INFO_MAX, Constant.TINVENTORY_TAGNO_INFO_MAX)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0079)]
        //public string txt_BranchTagNo { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0018)]
        //public string txt_ProductCD { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0019)]
        //public string txt_ProductName { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0084)]
        //public string txt_LOT1 { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0085)]
        //public string txt_LOT2 { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0086)]
        //public string txt_LOT3 { get; set; }

        //[iDisplayName(Name = Constant.LBL_L0087)]
        //public string txt_Memo { get; set; }

        public int hid_BranchTagNo { get; set; }
        //public string hid_UnitQuantity { get; set; }
        //public string hid_StockStatus { get; set; }
        //public string hid_WarehouseCD { get; set; }
        public string hid_UpdateDate { get; set; }
        //public string hid_BalanceStatus { get; set; }

        //public bool IsEmptyData { get; set; }
        //public bool IsEmptyLocationData { get; set; }

        //public string ShippingNo { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models 
{
    public class StockTakeProclamationDetailModel : BaseList
    {
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0230)]
        public string TakeStartDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0233)]
        public string TakeEndDate { get; set; }
    }

    public class StockTakeProclamationDetailResults
    {
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNoAndBranchTagNo { get; set; }        

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }
                
        public string TagNo { get; set; }
        public string BranchTagNo { get; set; }
        public string TakeStatus { get; set; }        
        public bool TakeFlag { get; set; }
        public string UpdateDate { get; set; }        
    }
}
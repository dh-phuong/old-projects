﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Move Outbound Delivery Inspection List
    /// Author : ISV-TRUC
    /// </summary>
    public class MoveOutboundDeliveryInspectionList : BaseList
    {
        [iDisplayName(Name = Constant.LBL_L0197)]
        public string ddl_MoveKind { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string txt_MoveNo { get; set; }

        [iCompareDateTAttribute("dCtr_MoveDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0200, Constant.LBL_L0201)]
        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl dCtr_MoveDateFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl dCtr_MoveDateTo { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPattern(PatternType.Numeric)]
        [DisplayFormat(ConvertEmptyStringToNull = true)]
        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WarehouseCDTo { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = true)]
        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WarehouseNameTo { get; set; }

        public bool IsSingleWareHouse { get; set; }

        public MoveOutboundDeliveryInspectionList()
        {
            dCtr_MoveDateFrom = new DateControl();
            dCtr_MoveDateTo = new DateControl();
            ddl_MoveKind = string.Empty;
        }
    }

    /// <summary>
    /// Move Outbound Delivery Inspection Results 
    /// Author : ISV-TRUC
    /// </summary>
    public class MoveOutboundDeliveryInspectionResults 
    {
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string MoveNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0193)]
        public string WarehouseCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0194)]
        public string WarehouseName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string MoveKindDisp { get; set; }

        public string MoveKind { get; set; }
        public string UpdateDate { get; set; }
        public bool ExistDelivery { get; set; } 
    }

    /// <summary>
    /// Move Outbound Delivery Inspection Header
    /// Author: ISV-Nho
    /// </summary>
    public class MoveOutboundDeliveryInspectionHeader : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string MoveNoDB { get; set; }

        [iRequired]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string txt_MoveNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string txt_MoveDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WarehouseCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WarehouseNameTo { get; set; }

        [iStringLength(Constant.TINVENTORY_TAGNO_INFO, Constant.TINVENTORY_TAGNO_INFO)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        public string MoveKind { get; set; }
        public bool ShippingCompleteFlag { get; set; }
        public bool IsCorrectMoveNo { get; set; }
        public bool IsCheckShipNo { get; set; }
        public string Mode { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Move Outbound Delivery Inspection Detail
    /// Author: ISV-Nho
    /// </summary>
    public class MoveOutboundDeliveryInspectionDetail
    {

        [iDisplayName(Name = Constant.LBL_L0155)]
        public bool DeliveryFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public string UpdateDate { get; set; }
    }
}
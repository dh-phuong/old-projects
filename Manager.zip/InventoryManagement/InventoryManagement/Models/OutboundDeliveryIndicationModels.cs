﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Outbound Delivery Indication List
    /// Author:ISV-HUNG
    /// </summary>
    public class OutboundDeliveryIndicationList : BaseList
    {
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iCompareDateTAttribute("SrhShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0153, Constant.LBL_L0154)]
        public DateControl SrhShipDateFrom { get; set; }

        public DateControl SrhShipDateTo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        [DisplayFormat(ConvertEmptyStringToNull = false)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string txt_DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0148)]
        public string lbl_NotGoodsIssueDataOnly { get; set; }
        public bool cbk_NotGoodsIssueDataOnly { get; set; }

        [iDisplayName(Name = Constant.LBL_L0090)]
        public string lbl_NotPrintDataOnly { get; set; }
        public bool cbk_NotPrintDataOnly { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public string lbl_DeleteData { get; set; }
        public bool chk_DeleteData { get; set; }

        public bool chk_CheckAll { get; set; }

        public OutboundDeliveryIndicationList()
        {
            SrhShipDateFrom = new DateControl();
            SrhShipDateTo = new DateControl();
        }
    }

    /// <summary>
    /// Outbound Delivery Indication Results
    /// Author: ISV-HUNG
    /// </summary>
    public class OutboundDeliveryIndicationResults
    {
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0301)]
        public string DeliveryNumber { get; set; }

        [iDisplayName(Name = Constant.LBL_L0189)]
        public bool PickingCompleteFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0089)]
        public bool ShippingPrintFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteData { get; set; }

        [iDisplayName(Name = Constant.LBL_L0149)]
        public bool Print { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// OutboundDeliveryIndication Main Detail
    /// Author: ISV-HUNG
    /// </summary>
    public class OutboundDeliveryIndicationMain : BaseModel
    {

        [iDisplayName(Name = Constant.LBL_L0171)]
        public string PreShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string txt_ShipDate { get; set; }

        [iRequiredDateAttribute]
        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl ShipDate { get; set; }

        [iRequired]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER)]
        [iPatternAttribute(PatternType.AlphaNumericFlashSpace)]
        [iDisplayName(Name = Constant.LBL_L0301)]
        public string DeliveryNumber { get; set; }

        [iRequired]
        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0030)]
        public string Address1 { get; set; }

        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0072)]
        public string Address2 { get; set; }

        [iStringLength(Constant.MCUSTOMER_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0073)]
        public string Address3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0087)]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_MEMO_MAX)]
        public string Memo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public bool CompleteFlag { get; set; }

        public bool IsPicked { get; set; }
        public bool CheckDeleteAll { get; set; }
        public string delFlg { get; set; }
        public List<OutboundDeliveryIndicationDetailGrid> Detail { get; set; }
        public OutboundDeliveryIndicationMain()
        {
            Detail = new List<OutboundDeliveryIndicationDetailGrid>();
            ShipDate = new DateControl();
        }

        [iDisplayName(Name = Constant.LBL_L0083)]
        public string TotalInstructQty { get; set; }

        //public void AddSeqForDetail()
        //{
        //    foreach (var item in Detail)
        //    {
        //        item.SeqNum = SeqNum;
        //    }
        //}

        public int MaxRowDetail { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }

    /// <summary>
    /// OutboundDeliveryIndication Detail Grid
    /// Author: ISV-HUNG
    /// </summary>
    public class OutboundDeliveryIndicationDetailGrid : BaseModel
    {
        public int NumRow { get; set; }

        public string txt_ShipNo { get; set; }
        public string txt_ShipNoDetail { get; set; }

        [iRequiredGrid(EmptyWhen = new string[] { "txt_InstructQuantity" }, RowIndexName = "NumRow")]
        [iPatternGridAttribute(PatternType.UpperAlphaNumericSubtract, RowIndexName = "NumRow")]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txt_ProductCD { get; set; }

        public string preProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txt_ProductName { get; set; }

        [iRequiredGrid(EmptyWhen = new string[] { "txt_ProductCD" }, RowIndexName = "NumRow")]
        [iIntegerGrid(MinValue = 1, MaxValue = 1000, RowIndexName = "NumRow")]
        [iDisplayName(Name = Constant.LBL_L0150)]
        public string txt_InstructQuantity { get; set; }

        public bool IsPicked { get; set; }
        public bool Delete { get; set; }
        public bool IsUsedShipNo { get; set; }

        public List<OutboundDeliveryIndicationDetailResult> ViewDetail { get; set; }
        public OutboundDeliveryIndicationDetailGrid()
        {
            ViewDetail = new List<OutboundDeliveryIndicationDetailResult>();
        }

        /// <summary>
        /// is empty row
        /// </summary>
        /// <returns>true:empty, false: not empty</returns>
        public bool isEmptyRow()
        {
            return string.IsNullOrEmpty(String.Format("{0}{1}", txt_ProductCD, txt_InstructQuantity));
        }
    }

    /// <summary>
    /// OutboundDeliveryIndication Detail (Search)
    /// Author: ISV-PHUONG
    /// </summary>
    public class OutboundDeliveryIndicationDetail : BaseSearch
    {
        public bool OnSearch { get; set; }
        public bool IsErrors { get; set; }
        public int RowNo { get; set; }
        public bool ShippingCompleteFlag { get; set; }
        public bool PickCompleteFlag { get; set; }
        public string ShipNo { get; set; }
        public string InstructQuantity { get; set; }

        public PagingInfo PageInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txt_ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txt_ProductName { get; set; }

        [iPatternAttribute(PatternType.Numeric)]
        [iStringLength(Constant.TINVENTORY_TAGNO_INFO_MAX)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        [iCompareDateTAttribute("ctr_ArrivalDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0125, Constant.LBL_L0126)]
        public DateControl ctr_ArrivalDateFrom { get; set; }
        public DateControl ctr_ArrivalDateTo { get; set; }

        [iCompareDateTAttribute("ctr_LOT2DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0136, Constant.LBL_L0137)]
        public DateControl ctr_LOT2DateFrom { get; set; }
        public DateControl ctr_LOT2DateTo { get; set; }

        [iCompareDateTAttribute("ctr_LOT3DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0138, Constant.LBL_L0139)]
        public DateControl ctr_LOT3DateFrom { get; set; }
        public DateControl ctr_LOT3DateTo { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string txt_LOT1 { get; set; }

        public System.Collections.Generic.List<OutboundDeliveryIndicationDetailResult> Results { get; set; }

        public OutboundDeliveryIndicationDetail()
        {
            ctr_ArrivalDateFrom = new DateControl();
            ctr_ArrivalDateTo = new DateControl();
            ctr_LOT2DateFrom = new DateControl();
            ctr_LOT2DateTo = new DateControl();
            ctr_LOT3DateFrom = new DateControl();
            ctr_LOT3DateTo = new DateControl();

        }
    }

    /// <summary>
    /// OutboundDeliveryIndication Detail (Search result)
    /// Author: ISV-PHUONG
    /// </summary>
    public class OutboundDeliveryIndicationDetailResult : BaseModel
    {

        public OutboundDeliveryIndicationDetailResult(System.Data.SqlClient.SqlDataReader dr)
        {
            this.Reserve = string.Format("{0}",dr["Reserve"]);
            this.NumBoxes = int.Parse((dr["NumBoxes"]).ToString());
            this.TagNo = string.Format("{0}", dr["TagNo"]);
            this.LocationCD = string.Format("{0}", dr["LocationCD"]);
            this.ArrivalDate = string.Format("{0}", dr["ArrivalDate"]);
            this.Lot1 = string.Format("{0}", dr["Lot1"]);
            this.Lot2 = string.Format("{0}", dr["Lot2"]);
            this.Lot3 = string.Format("{0}", dr["Lot3"]);
            this.StoredDate = string.Format("{0}", dr["StoredDate"]);
            this.PickingQuantity = int.Parse(dr["PickingQuantity"].ToString());
            this.SeqNum = int.Parse(dr["SeqNum"].ToString());
        }

        public OutboundDeliveryIndicationDetailResult()
        {
            // TODO: Complete member initialization
        }

        public int NumRow { get; set; }

        //[iIntegerGrid(MinValue = 0, MaxValue = 9999, RowIndexName = "NumRow")]
        //[iBetweenNumberGrid("PickingQuantity", "NumBoxes", RowIndexName = "NumRow")]
        [iDisplayName(Name = Constant.LBL_L0152)]
        public string Reserve { get; set; }

        /// <summary>
        /// Number of boxes
        /// </summary>
        //[iIntegerGrid(MinValue = 0, RowIndexName = "NumRow")]
        [iDisplayName(Name = Constant.LBL_L0127)]
        public int NumBoxes { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNo { get; set; }
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }
        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string Lot1 { get; set; }
        [iDisplayName(Name = Constant.LBL_L0085)]
        public string Lot2 { get; set; }
        [iDisplayName(Name = Constant.LBL_L0086)]
        public string Lot3 { get; set; }

        public string StoredDate { get; set; }
        [iDisplayName(Name = Constant.LBL_L0166)]
        public int PickingQuantity { get; set; }
        public bool PickedFlag { get; set; }
        public int ReserveQuantity { get; set; }
    }

    #region Print

    /// <summary>
    /// Print Header
    /// Author: ISV-LOC
    /// </summary>
    public class Print_OutboundDeliveryIndication_Header
    {
        public string ShipNo { get; set; }
        public string ShipDate { get; set; }
        public string InstructDate { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public bool ShippingCompleteFlag { get; set; }
        public string DeliveryNumber { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
    }

    /// <summary>
    /// Print Detail
    /// Author: ISV-LOC
    /// </summary>
    public class Print_OutboundDeliveryIndication_Detail
    {
        public string ShipNo { get; set; }
        //public string OrderNo { get; set; }
        public string LocationCD { get; set; }
        public string TagNo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string Lot1 { get; set; }
        public string Lot2 { get; set; }
        public string Lot3 { get; set; }
        public int Quantity { get; set; }
    }
    #endregion

    /// <summary>
    /// OutboundDeliveryIndicationModel class
    /// Author: TRAM
    /// </summary>
    public class OutboundDeliveryIndicationModel : BaseModel
    {
        /// <summary>
        /// ShipNo
        /// </summary>
        public string ShipNo { get; set; }

        /// <summary>
        /// ShipDetailNo
        /// </summary>
        public int ShipDetailNo { get; set; }

        /// <summary>
        /// ShipDate
        /// </summary>
        public string ShipDate { get; set; }

        /// <summary>
        /// InstructDate
        /// </summary>
        public string InstructDate { get; set; }

        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// LocationCD
        /// </summary>
        public string LocationCD { get; set; }

        /// <summary>
        /// TagNo
        /// </summary>
        public string TagNo { get; set; }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Lot1
        /// </summary>
        public string Lot1 { get; set; }

        /// <summary>
        /// Lot2
        /// </summary>
        public string Lot2 { get; set; }

        /// <summary>
        /// Lot3
        /// </summary>
        public string Lot3 { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Total
        /// </summary>
        public decimal? TotalQuantity { get; set; }
    }
}
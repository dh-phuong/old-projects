﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Search Conditions
    /// Author: ISV-Loc
    /// </summary>
    public class StockTakeProclamationList : BaseList
    {

        [iDisplayName(Name = Constant.LBL_L0263)]
        public bool chk_CheckAll { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string txt_LocationCD { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0052)]
        public string txt_LocationName { get; set; }

        [iCompareDateTAttribute("txt_TakeStartDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0231, Constant.LBL_L0232)]
        public DateControl txt_TakeStartDateFrom { get; set; }
        public DateControl txt_TakeStartDateTo { get; set; }

        [iCompareDateTAttribute("txt_TakeEndDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0234, Constant.LBL_L0235)]
        public DateControl txt_TakeEndDateFrom { get; set; }
        public DateControl txt_TakeEndDateTo { get; set; }

        public StockTakeProclamationList()
        {
            txt_TakeStartDateFrom = new DateControl();
            txt_TakeStartDateTo = new DateControl();

            txt_TakeEndDateFrom = new DateControl();
            txt_TakeEndDateTo = new DateControl();
        }


    }
    
    /// <summary>
    /// Results Conditions
    /// Author: ISV-Loc
    /// </summary>
    public class StockTakeProclamationResults
    {


        [iDisplayName(Name = Constant.LBL_L0263)]
        public bool chk_Proclamation { get; set; }

        [iDisplayName(Name = Constant.LBL_L0264)]
        public string StatusTaking { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0230)]
        public string TakeStartDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0233)]
        public string TakeEndDate { get; set; }

        public bool IsTakingFlag { get; set; }
        public bool haveDetail { get; set; }


    }

    /// <summary>
    /// Class StockTakeProclamationDetail for Insert/Update TTakeInventory_D
    /// Author: ISV-Loc
    /// </summary>
    public class StockTakeProclamationDetail
    {
        //現品票番号	
        public string TagNo { get; set; }
        //現品票枝番号	
        public int BranchTagNo { get; set; }
        //棚卸状態区分	
        public string TakeStatus { get; set; }
        //商品コード	
        public string ProductCD { get; set; }
        //保管場所コード	
        public string WarehouseCD { get; set; }
        //保管棚コード	
        public string LocationCD { get; set; }
        //商品入庫単価	
        public decimal? StoredCost { get; set; }
        //入数	
        public decimal? QuantityPerUnit { get; set; }
        //箱数	
        public int? UnitQuantity { get; set; }
        //在庫金額	
        public decimal? TotalCost { get; set; }
        //LOT1	
        public string LOT1 { get; set; }
        //LOT2	
        public string LOT2 { get; set; }
        //LOT3	
        public string LOT3 { get; set; }
        //棚卸検品フラグ	
        public bool TakeFlag { get; set; }
        //棚卸開始年月日	
        public string TakeStartDate { get; set; }
        //棚卸実施年月日	
        public string TakeDate { get; set; }


    }

    /// <summary>
    /// Model report
    /// ISV-PHUONG
    /// </summary>
    public class InventoryCheckList : BaseReport<InventoryCheckList>
    {
        private string _LocationCD;

        /// <summary>
        /// LocationCD
        /// </summary>
        public string LocationCD
        {
            get { return this._LocationCD; }
            set { this._LocationCD = value; }
        }

        /// <summary>
        /// Location Name
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// Take Start Date
        /// </summary>
        public string TakeStartDate { get; set; }

        /// <summary>
        /// Row index
        /// </summary>
        public int RowIndex { get; set; }

        /// <summary>
        /// TagNo + Bran TagNo
        /// </summary>
        public string TagInfo { get; set; }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Lot1
        /// </summary>
        public string Lot1 { get; set; }

        /// <summary>
        /// Lot2
        /// </summary>
        public string Lot2 { get; set; }

        /// <summary>
        /// Lot3
        /// </summary>
        public string Lot3 { get; set; }

        /// <summary>
        /// Barcode
        /// </summary>
        public byte[] LocationCDBarCode
        {
            get
            {
                System.Drawing.Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(this._LocationCD, 3, false);
                System.IO.MemoryStream Stream = new System.IO.MemoryStream();
                BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
                return Stream.ToArray();
            }
        }

        public int TotalPage { get; set; }
    }


    /// <summary>
    /// Model Difference List report
    /// ISV-PHUONG
    /// </summary>
    public class DifferenceCheckList : BaseReport<DifferenceCheckList>
    {
        private string _LocationCD;

        /// <summary>
        /// LocationCD
        /// </summary>
        public string LocationCD
        {
            get { return this._LocationCD; }
            set { this._LocationCD = value; }
        }

        /// <summary>
        /// Location Name
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        /// Take Start Date
        /// </summary>
        public string TakeStartDate { get; set; }

        /// <summary>
        /// Take End Date
        /// </summary>
        public string TakeEndDate { get; set; }

        /// <summary>
        /// Row index
        /// </summary>
        public int RowIndex { get; set; }

        /// <summary>
        /// TagNo + Bran TagNo
        /// </summary>
        public string TagInfo { get; set; }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Lot1
        /// </summary>
        public string Lot1 { get; set; }

        /// <summary>
        /// Lot2
        /// </summary>
        public string Lot2 { get; set; }

        /// <summary>
        /// Lot3
        /// </summary>
        public string Lot3 { get; set; }

        /// <summary>
        /// Barcode
        /// </summary>
        public byte[] LocationCDBarCode
        {
            get
            {
                System.Drawing.Image BarCodeImg = InventoryManagement.Barcode.Code128Rendering.MakeBarcodeImage(this._LocationCD, 3, false);
                System.IO.MemoryStream Stream = new System.IO.MemoryStream();
                BarCodeImg.Save(Stream, System.Drawing.Imaging.ImageFormat.Gif);
                return Stream.ToArray();
            }
        }

        public int TotalPage { get; set; }

        public string TakeStatus { get; set; }

        public int TakeStatusIndex { get; set; }

    }

}
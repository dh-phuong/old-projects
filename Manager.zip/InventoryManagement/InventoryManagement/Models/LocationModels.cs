﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// 棚情報のモデル
    /// Author: ISV-PHUONG
    /// </summary>
    public class LocationModels : BaseModel
    {
        [iStringLength(Constant.MWAREHOUSE_CD_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public bool ReceiptProhibitionFlag { get; set; }
        public bool IssueProhibitionFlag { get; set; }
        public bool TakeComplete { get; set; }

        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }

        public string iLocationCD { get; set; }
    }

    /// <summary>
    /// 棚情報のリスト
    /// Author: ISV-PHUONG
    /// </summary>
    public class LocationList : BaseList
    {
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        public string txt_LocationCD { get; set; }

        [iStringLength(Constant.MLOCATION_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0052)]
        public string txt_LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool chk_DeleteData { get; set; }

        public bool chk_CheckAll { get; set; }
    }

    /// <summary>
    /// 棚情報の結果
    /// Author: ISV-PHUONG
    /// </summary>
    public class LocationResults
    {
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0089)]
        public bool PrintFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0143)]
        public bool ReceiptProhibitionFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0144)]
        public bool IssueProhibitionFlag { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Location For CSV model
    /// Author: ISV-Phuong
    /// </summary>
    public class LocationCSV
    {
        public string WarehouseCD { get; set; }
        public string LocationCD { get; set; }
        public string LocationName { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
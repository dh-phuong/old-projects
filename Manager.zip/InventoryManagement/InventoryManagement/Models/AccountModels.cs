﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Web.Mvc;
using System.Web.Security;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Acccount Model
    /// Author: ISV-Vinh
    /// </summary>
    public class AccountModels
    {
        [iRequired]
        [iStringLength(Constant.MUSER_LOGIN_ID_MAX)]
        [iPattern(InventoryManagement.Common.PatternType.AlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0009)]
        public string LoginID { get; set; }

        [iRequired(IgnoreOnEmpty= false)]
        [iStringLength(Constant.MUSER_PASSWORD_MAX)]
        [iPattern(Common.PatternType.HaflWidth)]
        [iDisplayName(Name = Constant.LBL_L0010)]
        public string Password { get; set; }

        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iRequired]
        public LanguageFlag LanguageCD { get; set; }
    }
}

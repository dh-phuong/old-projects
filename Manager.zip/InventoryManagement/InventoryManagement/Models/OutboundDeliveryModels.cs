﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    public class OutboundDeliveryModels 
    {
    }

    // <summary>
    /// Delivery Picking List (For search)
    /// Author: ISV-Giam
    /// </summary>
    public class OutboundDeliveryList : BaseList
    {
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iCompareDateTAttribute("dCtr_ShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0153, Constant.LBL_L0154)]
        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public DateControl dCtr_ShipDateTo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [DisplayFormat(ConvertEmptyStringToNull = true)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = true)]
        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        public OutboundDeliveryList()
        {
            dCtr_ShipDateFrom = new DateControl();
            dCtr_ShipDateTo = new DateControl();
        }
    }

    /// <summary>
    /// Delivery Picking Results
    /// Author: ISV-Giam
    /// </summary>
    public class OutboundDeliveryResults 
    {
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        //public string CreateDate { get; set; }
        //public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        //public string UpdateUCD { get; set; }

        public bool ExistDelivery { get; set; } 
    }

    /// <summary>
    /// Shipment Picking Header
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveryHeader : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string ShipNoDB { get; set; }

        [iRequired]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0146)]
        public string txt_ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0147)]
        public string txt_ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iStringLength(Constant.TINVENTORY_TAGNO_INFO, Constant.TINVENTORY_TAGNO_INFO)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        public bool ShippingCompleteFlag { get; set; }
        public bool IsCorrectShipNo { get; set; }
        public bool IsCheckShipNo { get; set; }
        public string Mode { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Shipment Picking Detail
    /// Author: ISV-Nho
    /// </summary>
    public class OutboundDeliveryDetail
    {

        [iDisplayName(Name = Constant.LBL_L0155)]
        public bool DeliveryFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public string UpdateDate { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Kind Header List (For search)
    /// Author: ISV-Giam
    /// </summary>
    public class KindHeaderList : BaseList 
    {
        [iStringLength(Constant.MKIND_DATA_KIND_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0042)]
        public string txt_KindCD { get; set; }

        [iStringLength(Constant.MKIND_KIND_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0043)]
        public string txt_KindName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool chb_IncludeDeleteData { get; set; } 
    }

    /// <summary>
    /// Kind Header Results
    /// Author: ISV-Giam
    /// </summary>
    public class KindHeaderResults
    {
        [iDisplayName(Name = Constant.LBL_L0042)]
        public string KindCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0043)]
        public string KindName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }

    /// <summary>
    /// Kind Detail
    /// Author: ISV-Giam
    /// </summary>
    public class KindDetail : BaseModel 
    {
        [iRequired]
        [iStringLength(Constant.MKIND_DATA_KIND_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0042)]
        public string KindCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MKIND_KIND_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0043)]
        public string KindName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string UpdateDate { get; set; }
        public int currentIndex { get; set; }
        public string PreKindCD { get; set; }
        public bool IsExistsOrtherTB { get; set; }
        
        public List<KindDetailGrid> Detail { get; set; }

        public KindDetail()
        {
            Detail = new List<KindDetailGrid>();
        }

        /// <summary>
        /// Add Sequence Number for Detail row
        /// </summary>
        public void AddSeqForDetail() 
        {
            foreach (var item in Detail)
            {
                item.SeqNum = SeqNum;
            }
        }

    }

    /// <summary>
    /// Kind detail grid
    /// Author: ISV-Giam
    /// </summary>
    public class KindDetailGrid : BaseModel 
    {
        public int NumRow { get; set; }

        [iDisplayName(Name = Constant.LBL_L0044)]
        [iRequiredGrid(EmptyWhen = new string[] { "EngValue", "VieValue", "JapValue" }, RowIndexName = "NumRow")]
        [iPatternGrid(PatternType.UpperAlphaNumeric, RowIndexName = "NumRow")]
        public string DataCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0116)]
        [iRequiredGrid(EmptyWhen = new string[] { "DataCD", "VieValue", "JapValue" }, RowIndexName = "NumRow")]
        public string EngValue { get; set; }

        [iDisplayName(Name = Constant.LBL_L0117)]
        [iRequiredGrid(EmptyWhen = new string[] { "DataCD", "EngValue", "JapValue" }, RowIndexName = "NumRow")]
        public string VieValue { get; set; }

        [iDisplayName(Name = Constant.LBL_L0118)]
        [iRequiredGrid(EmptyWhen = new string[] { "DataCD", "EngValue", "VieValue" }, RowIndexName = "NumRow")]
        public string JapValue { get; set; }

        public bool IsUsedDataCD { get; set; }

        /// <summary>
        /// is empty row
        /// </summary>
        /// <returns>true:empty, false: not empty</returns>
        public bool isEmptyRow()
        {
            return string.IsNullOrEmpty(String.Format("{0}{1}{2}{3}", DataCD, EngValue, VieValue, JapValue));
        }
    }

    /// <summary>
    /// Kind List For CSV
    /// Author: ISV-Giam
    /// </summary>
    public class KindListCSV
    {
        public string KindCD { get; set; }
        public string KindName { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
        public string DataCD { get; set; }
        public string Value { get; set; }
        public byte Language { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Paging Info
    /// Author: ISV-Vinh
    /// </summary>
    public class PagingInfo
    {
        /// <summary>
        /// Total Items
        /// </summary>
        public int TotalItems { get; set; }
        
        /// <summary>
        /// Number of Items per Page
        /// </summary>
        public int ItemsPerPage { get; set; }

        /// <summary>
        /// Current Page
        /// </summary>
        public int CurrentPage { get; set; }
        
        /// <summary>
        /// Total pages
        /// </summary>
        public int TotalPages
        {
            get { return (int)Math.Ceiling((double)TotalItems / ItemsPerPage); }
        }

        /// <summary>
        /// Start Index
        /// </summary>
        public int StartIndex
        {
            get { return (CurrentPage - 1) * ItemsPerPage + 1; }
        }

        /// <summary>
        /// End Index
        /// </summary>
        public int EndIndex
        {
            get {
                int endIndex = CurrentPage * ItemsPerPage;
                return endIndex > TotalItems ? TotalItems : endIndex;
            }
        }
    }

    /// <summary>
    /// Paging Request
    /// Author: ISV-Vinh
    /// </summary>
    public class PagingRequest
    {
        /// <summary>
        /// Current Page
        /// </summary>
        public int page { get; set; }

        /// <summary>
        /// Is First
        /// </summary>
        public bool isFirst { get; set; }

        /// <summary>
        /// Is Last
        /// </summary>
        public bool isLast { get; set; }
    }
}
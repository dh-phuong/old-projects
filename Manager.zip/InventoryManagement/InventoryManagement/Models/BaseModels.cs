﻿using System.Linq;
using System.ComponentModel.DataAnnotations;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Base Model
    /// Author: ISV-Vinh
    /// </summary>
    public class BaseModel
    {
        //public string DataKey { get; set; }
        //public string ConditionKey { get; set; }
        public int SeqNum { get; set; }
    }

    /// <summary>
    /// Base List Model
    /// Author: ISV-Vinh
    /// </summary>
    public class BaseList
    {
        //public string ConditionKey { get; set; }
        public int SeqNum { get; set; }
    }

    /// <summary>
    /// Base Search
    /// Author: ISV-Hung
    /// </summary>
    public class BaseSearch
    {
        //public string DataKey { get; set; }
        public int SeqNum { get; set; }
    }

    /// <summary>
    /// Base Report
    /// Author: ISV-PHUONG
    /// </summary>
    public abstract class BaseReport<T>
    {
        public T Clone()
        {
            return (T)this.MemberwiseClone();
        }
       

        public System.Collections.Generic.List<T> DataItems()
        {
            return null;
        }
    }
}
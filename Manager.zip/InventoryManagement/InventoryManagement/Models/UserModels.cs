﻿using InventoryManagement.Validation;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using InventoryManagement.Common;
using System;
using System.Collections.Generic;

namespace InventoryManagement.Models
{
    /// <summary>
    /// User Models
    /// Author: ISV-Thuy
    /// </summary>
    public class UserModels : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.MUSER_USER_CD_MAX, MinimumLength = Constant.MUSER_USER_CD_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0006)]
        public string UserCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MUSER_LOGIN_ID_MAX)]
        [iPatternAttribute(PatternType.AlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0009)]
        public string LoginID { get; set; }

        [iRequired]
        [iStringLength(Constant.MUSER_USER_FULL_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0007)]
        public string UserFullName { get; set; }

        [iRequired]
        [iStringLength(Constant.MUSER_USER_SHORT_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0008)]
        public string UserShortName { get; set; }

        [iRequired(IgnoreOnEmpty = false)]
        [iCompare("ConfirmPassword")]
        [iStringLength(Constant.MUSER_PASSWORD_MAX, MinimumLength = Constant.MUSER_PASSWORD_MIN)]
        [iPattern(Common.PatternType.HaflWidth)]
        [iDisplayName(Name = Constant.LBL_L0010)]
        public string Password { get; set; }

        [iRequired(IgnoreOnEmpty = false)]
        [iStringLength(Constant.MUSER_PASSWORD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0011)]
        public string ConfirmPassword { get; set; }

        [iRequired]
        [iStringLength(Constant.MGROUP_GROUP_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string GroupCD { get; set; }

        [iStringLength(Constant.MGROUP_GROUP_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string GroupNm { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }

        public string PreUserCD { get; set; }
        public UserModels()
        {
            Detail = new List<WarehouseByUserGrid>();
        }
        //List Warehouse by UserCD
        public List<WarehouseByUserGrid> Detail { get; set; }

        [iDisplayName(Name = Constant.LBL_L0290)]
        public bool chk_AllWarehouse { get; set; }

        public bool chk_DeleteAll { get; set; }
        public string delFlg { get; set; }
    }

    /// <summary>
    /// User List Model
    /// Author: ISV-Thuy
    /// </summary>
    public class UserList : BaseList
    {
        [iStringLength(Constant.MUSER_USER_CD_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0006)]
        public string txt_UserCD { get; set; }

        [iStringLength(Constant.MUSER_LOGIN_ID_MAX)]
        [iPatternAttribute(PatternType.AlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0009)]
        public string txt_LoginID { get; set; }

        [iStringLength(Constant.MUSER_USER_FULL_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0007)]
        public string txt_UserName { get; set; }

        [iStringLength(Constant.MGROUP_GROUP_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string txt_GroupCD { get; set; }

        [iStringLength(Constant.MGROUP_GROUP_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string txt_GroupName { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0028)]
        public string txt_CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string txt_CustomerName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool chk_DeleteData { get; set; }
    }

    /// <summary>
    /// User Results
    /// Author: ISV-Thuy
    /// </summary>
    public class UserResults
    {
        [iDisplayName(Name = Constant.LBL_L0006)]
        public string UserCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0009)]
        public string LoginID { get; set; }

        [iDisplayName(Name = Constant.LBL_L0007)]
        public string UserFullName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0008)]
        public string UserShortName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0012)]
        public string GroupNm { get; set; }

        [iDisplayName(Name = Constant.LBL_L0028)]
        public string CustomerCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0029)]
        public string CustomerName { get; set; }

        public bool DeleteFlagRoles { get; set; }

        public string UpdateDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }
    }

    /// <summary>
    /// WarehouseByUser Grid
    /// Author:ISV-LOC
    /// </summary>
    public class WarehouseByUserGrid
    {
        public int NumRow { get; set; }

        //[iRequiredGrid(EmptyWhen = new string[] { "txt_InstructQuantity" }, RowIndexName = "NumRow")]
        [iPatternGridAttribute(PatternType.Numeric, RowIndexName = "NumRow")]
        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string txt_WarehouseCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0059)]
        public string txt_WarehouseName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool chk_Delete { get; set; }


        /// <summary>
        /// is empty row
        /// </summary>
        /// <returns>true:empty, false: not empty</returns>
        public bool isEmptyRow()
        {
            return string.IsNullOrEmpty(String.Format("{0}", txt_WarehouseCD));
        }
    }


    /// <summary>
    /// User List CSV
    /// Author: ISV-Thuy
    /// </summary>
    public class UserListCSV
    {
        public string UserCD { get; set; }
        public string LoginID { get; set; }
        public string PassWord { get; set; }
        public string UserFullName { get; set; }
        public string UserShortName { get; set; }
        public string GroupCD { get; set; }
        public string CustomerCD { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Company Models
    /// Author: ISV-TRUC
    /// </summary>
    public class CompanyModels : BaseModel
    {
        //[iRequired]
        //[iStringLength(Constant.MCOMPANY_COMPANYCD_MAX)]
        //[iPatternAttribute(PatternType.Numeric)]
        //[iDisplayName(Name = Constant.LBL_L0096)]
        public string CompanyCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0097)]
        public string CompanyName1 { get; set; }

        [iRequired]        
        [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0098)]
        public string CompanyName2 { get; set; }

        [iStringLength(Constant.MCOMPANY_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0071)]
        public string Address1 { get; set; }

        [iStringLength(Constant.MCOMPANY_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0072)]
        public string Address2 { get; set; }

        [iStringLength(Constant.MCOMPANY_ADDRESS_MAX)]
        [iDisplayName(Name = Constant.LBL_L0073)]
        public string Address3 { get; set; }

        [iPattern(PatternType.Email)]
        [iStringLength(Constant.MCOMPANY_EMAIL_MAX)]
        [iDisplayName(Name = Constant.LBL_L0074)]
        public string Email { get; set; }

        [iPattern(PatternType.Tel)]
        [iStringLength(Constant.MCOMPANY_TEL_MAX)]
        [iDisplayName(Name = Constant.LBL_L0031)]
        public string Tel { get; set; }

        [iPattern(PatternType.Tel)]
        [iStringLength(Constant.MCOMPANY_FAX_MAX)]
        [iDisplayName(Name = Constant.LBL_L0032)]
        public string Fax { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        //public string PreCompanyCD { get; set; }
        public string CreateDate { get; set; }
        public string CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUID { get; set; }
    }

    ///// <summary>
    ///// Company List
    ///// Author: ISV-TRUC
    ///// </summary>
    //public class CompanyList : BaseList
    //{
    //    [iStringLength(Constant.MCOMPANY_COMPANYCD_MAX)]
    //    [iPatternAttribute(PatternType.Numeric)]
    //    [iDisplayName(Name = Constant.LBL_L0096)]
    //    public string txt_CompanyCD { get; set; }

    //    [iStringLength(Constant.MCOMPANY_COMPANYNAME_MAX)]
    //    [iDisplayName(Name = Constant.LBL_L0099)]
    //    public string txt_CompanyName { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0067)]
    //    public bool chk_DeleteData { get; set; }
    //}

    ///// <summary>
    ///// Company Results
    ///// Author: ISV-TRUC
    ///// </summary>
    //public class CompanyResults
    //{
    //    [iDisplayName(Name = Constant.LBL_L0096)]
    //    public string CompanyCD { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0097)]
    //    public string CompanyName1 { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0098)]
    //    public string CompanyName2 { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0031)]
    //    public string Tel { get; set; }

    //    [iDisplayName(Name = Constant.LBL_L0066)]
    //    public bool DeleteFlag { get; set; }

    //    public string UpdateDate { get; set; }
    //}

    /// <summary>
    /// Company List for CSV
    /// Author: ISV-TRUC
    /// </summary>
    public class CompanyListCSV
    {
        public string CompanyCD { get; set; }
        public string CompanyName1 { get; set; }
        public string CompanyName2 { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Email { get; set; }
        public string Tel { get; set; }
        public string Fax { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
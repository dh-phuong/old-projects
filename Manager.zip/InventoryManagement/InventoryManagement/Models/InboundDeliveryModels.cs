﻿using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// InboundDelivery Models
    /// Author: ISV-Nho
    /// </summary>
    public class InboundDeliveryModels : BaseModel
    {
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }
        
        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0165)]
        public string BalanceStatus { get; set; }

        [iDisplayName(Name = Constant.LBL_L0165)]
        public string BalanceStatusName { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SuplierName { get; set; }

        [iRequired]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iRequired]
        [iInteger(MinValue = 1)]
        [iDisplayName(Name = Constant.LBL_L0082)]
        public string UnitQuantity { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string Lot1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string Lot2 { get; set; }

        public DateControl LOT2Date { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string Lot3 { get; set; }

        public DateControl LOT3Date { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0052)]
        public string LocationName { get; set; }

        [iRequired]
        [iDecimal(Constant.MPRODUCT_QUANTITY_PER_UNIT_PRECISION, Constant.MPRODUCT_QUANTITY_PER_UNIT_SCALE, Constant.MPRODUCT_QUANTITY_PER_UNIT_MIN, Constant.MPRODUCT_QUANTITY_PER_UNIT_MAX)]
        [iDisplayName(Name = Constant.LBL_L0022)]
        public string QuantityPerUnit { get; set; }

        [iRequired]
        [iDecimal(Constant.TINVENTORY_STORED_COST_PRECISION, Constant.TINVENTORY_STORED_COST_SCALE, Constant.TINVENTORY_STORED_COST_MIN, Constant.TINVENTORY_STORED_COST_MAX)]
        [iDisplayName(Name = Constant.LBL_L0021)]
        public string StoredCost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        [iRequired]
        [iDecimal(Constant.TINVENTORY_TOTAL_COST_PRECISION, Constant.TINVENTORY_TOTAL_COST_SCALE, Constant.TINVENTORY_TOTAL_COST_MIN, Constant.TINVENTORY_TOTAL_COST_MAX)]
        public string TotalCost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0087)]
        [iStringLength(Constant.TINVENTORY_MEMO_MAX)]
        public string Memo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0088)]
        public bool TagPrintFlag { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string CreateDate { get; set; }
        public int CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public int UpdateUID { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string DisTagNo { get; set; }
        
        public string TagNo { get; set; }
        public int BranchTagNo { get; set; }
        public string StockStatus { get; set; }
        public bool isNotArr { get; set; }

        public bool IsShowSuplier { get; set; }

        public PrintTypeFlag PrintSize { get; set; }

        public InboundDeliveryModels()
        {
            LOT2Date = new DateControl();
            LOT3Date = new DateControl();
        }
    }

    /// <summary>
    /// InboundDelivery List
    /// Author: ISV-Nho
    /// </summary>
    public class InboundDeliveryList : BaseList
    {
        [iCompareDateTAttribute("SrhArrivalDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0125, Constant.LBL_L0126)]
        public DateControl SrhArrivalDateFrom { get; set; }
        public DateControl SrhArrivalDateTo { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SrhSuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SrhSuplierName { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string SrhProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string SrhProductName { get; set; }

        [iPatternAttribute(PatternType.HaflWidth)]
        [iStringLength(Constant.TINVENTORY_LOT_NO_MAX_LEN)]
        [iDisplayName(Name = Constant.LBL_L0084)]
        public string SrhLot1 { get; set; }

        [iCompareDateTAttribute("LOT2DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0136, Constant.LBL_L0137)]
        public DateControl LOT2DateFrom { get; set; }
        public DateControl LOT2DateTo { get; set; }

        [iCompareDateTAttribute("LOT3DateTo", CompareType.LessThanOrEqual, Constant.LBL_L0138, Constant.LBL_L0139)]
        public DateControl LOT3DateFrom { get; set; }
        public DateControl LOT3DateTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool IncludeDeleteData { get; set; }

        [iDisplayName(Name = Constant.LBL_L0090)]
        public bool NotPrintingDataOnly { get; set; }

        public bool IsShowSuplier { get; set; }

        public bool chk_CheckAll { get; set; }
        public PrintTypeFlag PrintSize { get; set; }

        public InboundDeliveryList()
        {
            SrhArrivalDateFrom = new DateControl();
            SrhArrivalDateTo = new DateControl();
            LOT2DateFrom = new DateControl();
            LOT2DateTo = new DateControl();
            LOT3DateFrom = new DateControl();
            LOT3DateTo = new DateControl();
        }
    }

    /// <summary>
    /// InboundDelivery Result
    /// Author: ISV-Nho
    /// </summary>
    public class InboundDeliveryResult
    {
        public string TagNo { get; set; }
        public int BranchTagNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagInfo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0288)]
        public string SuplierCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0289)]
        public string SuplierName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0082)]
        public int UnitQuantity { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string Lot1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0088)]
        public bool Printed { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteData { get; set; }

        [iDisplayName(Name = Constant.LBL_L0089)]
        public bool Print { get; set; }

        public bool IsShowSuplier { get; set; }
        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Kind For Print
    /// Author: ISV-Nho
    /// </summary>
    public class KindForPrint
    {
        public string KindCD { get; set; }
        public string DataCD { get; set; }
        public string Value { get; set; }
    }
}
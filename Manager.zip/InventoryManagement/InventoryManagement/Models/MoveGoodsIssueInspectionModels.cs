﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;
using System.ComponentModel.DataAnnotations;

namespace InventoryManagement.Models
{
    /// <summary>
    /// MoveGoods Issue Inspection List (For search)
    /// Author: ISV-Nho
    /// </summary>
    public class MoveGoodsIssueInspectionList : BaseList
    {
        [iDisplayName(Name = Constant.LBL_L0197)]
        public string ddl_MoveKind { get; set; }

        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string txt_ShipNo { get; set; }

        [iCompareDateTAttribute("dCtr_ShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0200, Constant.LBL_L0201)]
        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl dCtr_ShipDateFrom { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public DateControl dCtr_ShipDateTo { get; set; }

        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iDisplayName(Name = Constant.LBL_L0298)]
        public string txt_LocationCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0299)]
        public string txt_LocationNameTo { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0298)]
        public string txt_WarehouseCDTo { get; set; }

        [DisplayFormat(ConvertEmptyStringToNull = true)]
        [iDisplayName(Name = Constant.LBL_L0299)]
        public string txt_WarehouseNameTo { get; set; }
        
        /// <summary>
        /// Constructor
        /// </summary>
        public MoveGoodsIssueInspectionList()
        {
            dCtr_ShipDateFrom = new DateControl();
            dCtr_ShipDateTo = new DateControl();
        }
    }

    /// <summary>
    /// Move Goods Issue Inspection Results
    /// Author: ISV-Nho
    /// </summary>
    public class MoveGoodsIssueInspectionResults
    {
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0298)]
        public string DestinationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0299)]
        public string DestinationNm { get; set; }

        [iDisplayName(Name = Constant.LBL_L0197)]
        public string MoveKindDisplay { get; set; }
        public string MoveKind { get; set; }
        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Move Goods Issue Inspection Header
    /// Author: ISV-Nho
    /// </summary>
    public class MoveGoodsIssueInspectionHeader : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.TSHIPPINGINSTRUCTION_SHIPNO_MAX)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0195)]
        public string txt_ShipNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0196)]
        public string txt_ShipDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0193)]
        public string txt_WarehouseCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0194)]
        public string txt_WarehouseNameTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0191)]
        public string txt_LocationCDTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0192)]
        public string txt_LocationNameTo { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MLOCATION_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0051)]
        public string txt_LocationCD { get; set; }

        [iStringLength(Constant.TINVENTORY_TAGNO_INFO, Constant.TINVENTORY_TAGNO_INFO)]
        [iPattern(Common.PatternType.NumbericSubstract)]
        [iDisplayName(Name = Constant.LBL_L0106)]
        public string txt_TagNo { get; set; }

        public bool isShowShipNo { get; set; }
        public bool isCheckShipNo { get; set; }
        public string ShipNoDB { get; set; }

        public string MoveKind { get; set; }
    }

    /// <summary>
    /// Move Goods Issue Inspection Detail
    /// Author: ISV-Nho
    /// </summary>
    public class MoveGoodsIssueInspectionDetail
    {
        [iDisplayName(Name = Constant.LBL_L0155)]
        public bool Checked { get; set; }

        [iDisplayName(Name = Constant.LBL_L0051)]
        public string LocationCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0106)]
        public string TagNo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0080)]
        public string ArrivalDate { get; set; }

        [iDisplayName(Name = Constant.LBL_L0084)]
        public string LOT1 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0085)]
        public string LOT2 { get; set; }

        [iDisplayName(Name = Constant.LBL_L0086)]
        public string LOT3 { get; set; }

        public int ShipDetailNo { get; set; }
        public string UpdateDate { get; set; }
    }
}
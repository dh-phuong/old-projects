﻿using System;
using InventoryManagement.Models;

namespace InventoryManagement.Common
{
    /// <summary>
    /// Constant
    /// </summary>
    public class Constant
    {
        #region Tables

        #region MCompany

        public const int MCOMPANY_COMPANYCD_MAX = 6;
        public const int MCOMPANY_ADDRESS_MAX = 100;
        public const int MCOMPANY_EMAIL_MAX = 320;
        public const int MCOMPANY_FAX_MAX = 15;
        public const int MCOMPANY_COMPANYNAME_MAX = 30;
        public const int MCOMPANY_TEL_MAX = 15;

        #endregion

        #region MProduct
        
        public const int MPRODUCT_COST_PRECISION = 12;
        public const string MPRODUCT_COST_MAX = "9999999999.99";
        public const string MPRODUCT_COST_MIN = "0";
        public const int MPRODUCT_COST_SCALE = 2;
        public const int MPRODUCT_QUANTITY_PER_UNIT_PRECISION = 8;
        public const string MPRODUCT_QUANTITY_PER_UNIT_MAX = "999999.99";
        public const string MPRODUCT_QUANTITY_PER_UNIT_MIN = "1";
        public const int MPRODUCT_QUANTITY_PER_UNIT_SCALE = 2;
        public const int PRODUCT_DETAIL_MAX = 1000;
        public const int MPRODUCT_PRODUCT_CD_MAX = 20;
        public const int MPRODUCT_PRODUCT_NAME_MAX = 30;

        #endregion 

        #region MGroup
        
        public const int MGROUP_GROUP_CD_MAX = 2;
        public const int MGROUP_GROUP_NAME_MAX = 20;
        public const string MGROUP_ROLE_CD = "08";
        public const string MGROUP_MASTER = "09";
        public const string MGROUP_PROCESS = "10";

        #endregion

        #region MCustomer

        public const int MCUSTOMER_ADDRESS_MAX = 50;
        public const int MCUSTOMER_EMAIL_MAX = 50;
        public const int MCUSTOMER_FAX_MAX = 15;
        public const int MCUSTOMER_CD_MAX = 6;
        public const int MCUSTOMER_NAME_MAX = 30;
        public const int MCUSTOMER_TEL_MAX = 15;

        #endregion  
        
        #region MKind

        //Max lenght
        public const int MKIND_DATA_CD_MAX = 2;
        public const int MKIND_DATA_KIND_MAX = 2;
        public const int MKIND_VALUE_MAX = 30;
        public const int MKIND_KIND_NAME_MAX = 15;

        //Outbound Kind
        public const string MKIND_KINDCD_OUTBOUND_KIND = "01";

        //Move
        public const string MKIND_KINDCD_MOVE_KIND = "11";

        //Category
        public const string MKIND_KINDCD_CATEGORY = "02";

        public const string MKIND_KINDCD_STOCK_ALLOWANCE = "03";
        public const string MKIND_KINDCD_STOCK_STATUS = "04";
        public const string MKIND_KINDCD_BALANCE_STATUS = "05";
        public const string MKIND_KINDCD_GROUP_ROLES = "08";
        public const string MKIND_KINDCD_VIEW1ST = "09"; //(01 -> 09)
        public const string MKIND_KINDCD_VIEW2ND = "10"; //(20 -> 39)

        public const string MKIND_KINDCD_PAGE_SIZE = "02";
        public const string MKIND_DATACD_PAGE_SIZE = "01";

        public const string MKIND_KINDCD_VIEW_CUS = "13";
        public const string MKIND_DATACD_VIEW_CUS = "01";

        /// <summary>
        /// Check ShipNo
        /// </summary>
        public const string MKIND_KINDCD_CHECK_SHIPNO = "14";
        public const string MKIND_DATACD_CHECK_SHIPNO = "10";

        /// <summary>
        /// Max Row Data
        /// </summary>
        public const string MKIND_KINDCD_MAX_ROW_QTY = "15";
        public const string MKIND_DATACD_MAX_ROW_OB = "01";
        public const string MKIND_DATACD_MAX_QTY_OB = "02";
        public const string MKIND_DATACD_MAX_ROW_MOB = "03";
        public const string MKIND_DATACD_MAX_QTY_MOB = "04";

        #endregion

        #region MRoles
        
        public const int MROLES_ID_MAX = 4;
        public const int MROLES_NAME_MAX = 20;

        #endregion

        #region MUser
        
        public const int MUSER_USER_CD_MAX = 4;
        public const int MUSER_LOGIN_ID_MAX = 20;
        public const int MUSER_USER_SHORT_NAME_MAX = 15;
        public const int MUSER_USER_FULL_NAME_MAX = 30;
        public const int MUSER_PASSWORD_MAX = 16;
        public const int MUSER_PASSWORD_MIN = 6;
        public const int MUSER_USER_CD_SHOW = 4;
        public const int MUSER_USER_CD_DATA = 10;
        public const string MUSER_USER_CD_ADMIN = "0000";
        public const char MUSER_USER_CHAR_PASSWORD = '●';

        #endregion

        #region MWarehouse
        
        public const int MWAREHOUSE_CD_MAX = 4;
        public const int MWAREHOUSE_NAME_MAX = 30;
        public const int MWAREHOUSE_WAREHOUSECD_DATA = 4;
        public const int MWAREHOUSE_WAREHOUSECD_SHOW = 4;

        #endregion

        #region MCategory
        
        public const int MCATEGORY_CD_MAX = 4;
        public const int MCATEGORY_NAME_MAX = 30;

        #endregion

        #region MLocation

        public const int MLOCATION_CD_MAX = 15;
        public const int MLOCATION_NAME_MAX = 30;
        public const string MLOCATION_RECEIPT_ONLY_FLAG = "true";
        public const string MLOCATION_ISSUE_ONLY_FLAG = "true";

        #endregion

        #region TShippingInstruction

        public const int TSHIPPINGINSTRUCTION_MEMO_MAX = 150;
        public const int TSHIPPINGINSTRUCTION_SHIPNO_MAX = 10;
        public const int TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_PRECISION = 6;
        public const int TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MAX = 999999;
        public const int TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_MIN = 1;
        public const int TSHIPPINGINSTRUCTION_INSTRUCT_QUANTITY_SCALE = 0;
        public const int TSHIPPINGINSTRUCTION_INSTRUCT_DELIVERY_NUMBER = 50;


        #endregion

        #region TInventory
        
        public const int TINVENTORY_MEMO_MAX = 300;
        public const int TINVENTORY_TAGNO_INFO_MAX = 15;
        public const int TINVENTORY_TAGNO_MAX = 10;
        public const int TINVENTORY_TAGNO_INFO = 15;
        public const int TINVENTORY_LOT_NO_MAX_LEN = 20;
        public const int TINVENTORY_UNIT_PRICE_PRECISION = 17;
        public const string TINVENTORY_UNIT_PRICE_MAX = "922337203685477.58";
        public const string TINVENTORY_UNIT_PRICE_MIN = "0";
        public const int TINVENTORY_UNIT_PRICE_SCALE = 2;
        public const int TINVENTORY_STORED_COST_PRECISION = 16;
        public const int TINVENTORY_STORED_COST_SCALE = 2;
        public const string TINVENTORY_STORED_COST_MAX = "99999999999999.99";
        public const string TINVENTORY_STORED_COST_MIN = "0";
        public const int TINVENTORY_TOTAL_COST_PRECISION = 16;
        public const int TINVENTORY_TOTAL_COST_SCALE = 2;
        public const string TINVENTORY_TOTAL_COST_MAX = "99999999999999.99";
        public const string TINVENTORY_TOTAL_COST_MIN = "0";
        public const int DAY_MAX = 2;
        public const int MONTH_MAX = 2;
        public const int YEAR_MAX = 4;
        public const int TINVENTORY_BRANCH_TAG_NO_LEN = 4;

        #endregion

        #region Database Contrain
        
        public const string DB_MGroup_H_PK = "PK_MGroup_H";
        public const string DB_MGroup_D_PK = "PK_MGroup_D";
        public const string DB_MCustomer_PK = "PK_MCustomer";
        public const string DB_MKind_H_PK = "PK_MKind_H";
        public const string DB_MKind_D_PK = "PK_MKind_D";
        public const string DB_MLocation_PK = "PK_MLocation";
        public const string DB_MProduct_PK = "PK_MProduct";
        public const string DB_MUser_PK = "PK_MUser";
        public const string DB_MUser_UN = "MUser_UN";
        public const string DB_MWarehouse_PK = "PK_MWarehouse";
        public const string DB_MCategory_PK = "PK_MCategory";
        public const string DB_MCompany_PK = "PK_MCompany";
        public const string DB_TINVENTORY_D_PK = "PK_TInventory_D";
        public const string DB_TINVENTORY_H_PK = "PK_TInventory_H";
        public const string DB_TSHIPPINGINSTRUCTION_PK = "PK_TShippingInstruction";
        public const string DB_TSHIPPINGINSTRUCTIONDETAIL_PK = "PK_TShippingInstructionDetail";
        public const string DB_TPESSIMISTICLOCK_PK = "PK_TPessimisticLock";
        public const string DB_TSEQUENCES_PK = "PK_TSequences";
        public const string DB_TTAKEINVENTORY_D_PK = "PK_TTakeInventory_D";
        public const string DB_TTAKEINVENTORY_H_PK = "PK_TTakeInventory_H";
        public const string DB_MWAREHOUSEBYUSER_PK = "PK_MWarehouseByUser";

        #endregion

        #endregion

        #region Common

        //ViewData Keys
        public const string VIEWDATA_FOCUSID = "View_FocusId";
        public const string VIEWDATA_MES_TRANFER = "View_Mes_Tranfer";
        public const string VIEWDATA_MES_CONFIRM = "View_Message";
        public const string VIEWDATA_MES_APPEND = "View_Message_Append";
        public const string VIEWDATA_MES_PRINT = "View_Message_Print";
        public const string VIEWDATA_MES_INFO = "View_Message_Info";
        public const string VIEWDATA_TRANFER_URL = "View_Tranfer_Url";
        public const string VIEWDATA_TRANFER_VALUE_1 = "View_Tranfer_Val1";
        public const string VIEWDATA_TRANFER_VALUE_2 = "View_Tranfer_Val2";
        public const string VIEWDATA_TRANFER_VALUE_3 = "View_Tranfer_Val3";
        public const string VIEWDATA_TRANFER_VALUE_4 = "View_Tranfer_Val4";
        public const string VIEWDATA_TRANFER_VALUE_5 = "View_Tranfer_Val5";

        //Session state
        public const string SESSION_STATE_ADMIN = "Admin";
        public const string SESSION_STATE_NORMAL = "Normal";
        public const string SESSION_STATE_MODE = "Mode";
        public const string SESSION_STATE_SEARCH_ID = "SearchID";
        public const string SESSION_STATE_RESULT_INSERT_ID = "ResultInsertID";
        public const string SESSION_STATE_RESULT_LIST = "ResultList";

        //Session
        public const string SESSION_LIST_CONDITION = "Ses_List_Cond";
        public const string SESSION_LIST_SEARCH_CONDITION = "Ses_List_Search_Cond";
        public const string SESSION_LIST_RESULT = "Ses_List_Result";
        public const string SESSION_LIST_DETAIL_RESULT = "Ses_List_Detail_Result";
        public const string SESSION_LIST_DETAIL_RESULT_VIEW = "Ses_List_Detail_Result_View";
        public const string SESSION_LIST_SEARCH_RESULT = "Ses_List_Search_Result";
        public const string SESSION_LIST_PAGING = "Ses_List_Paging";
        public const string SESSION_LIST_SORTING = "Ses_List_Sorting";
        public const string SESSION_DETAIL_PAGING = "Ses_Detail_Paging";
        public const string SESSION_DETAIL_SORTING = "Ses_Detail_Sorting";


        public const string SESSION_LOGIN_MODEL = "Ses_Login_Model";
        public const string SESSION_DETAIL_MODEL = "Ses_Detail_Model";
        public const string SESSION_TITLE_GROUP_ROLE = "Ses_Title_Group_Role";
        public const string SESSION_SHIPMENT_PICKING_CONDITION = "Ses_Shipment_Picking_Condition";
        public const string SESSION_SHIPMENT_PICKING_DETAIL = "Ses_Shipment_Picking_Detail";
        public const string SESSION_DELIVERY_PICKING_DETAIL = "Ses_Delivery_Picking_Detail";
        public const string SESSION_PRINT_ITEM = "Ses_Print_Item";
        public const string SESSION_SELECTED_ITEM = "Ses_Selected_Item";
        public const string SESSION_TITLE = "Ses_Title";
        public const string SESSION_AUTHORITY = "Ses_Authority_User";
        public const string SESSION_GRID_ERROR_KEYS = "Ses_Grid_Error_Keys";
        public const string SESSION_SHOW_CUSTOMER = "Ses_Show_Customer";

        public const string SESSION_BALANCE_STORES_PRINT = "Ses_Balance_Stores_Print";
        public const string SESSION_OUTBOUND_DELIVERED_PRINT = "Ses_Outbound_Delivered_Print";
        public const string SESSION_SEQUENCE_NUMBER = "Ses_Sequence_Number";

        public static string SESSION_STOCK_LIST_PRINT = "Ses_Stock_List_Print";
        public static string SESSION_STOCK_INQUIRY_PRINT = "Ses_Stock_Inquiry_Print"; 

        //View ID
        public const string ID_CONFIRM = "Confirm";
        public const string ID_ERROR = "Errors";
        public const string ID_ERROR_SEARCH = "sErrors";
        public const string ID_HID_FORM = "HidForm";
        public const string ID_SEARCH = "Search";
        public const string ID_TRANFER = "Tranfer";

        //Search partial id
        public const string SEARCH_PRODUCT = "SearchProduct";
        public const string SEARCH_USER_ID = "SearchUserID";

        //Search result id
        public const string SEARCH_RESULT_OUT = "SearchResultOut";

        //Search result insert id
        public const string RESULT_PRODUCT_ID = "ProductID";
        public const string RESULT_PRODUCT_NAME = "ProductName";
        public const string RESULT_USER_ID = "UserID";
        public const string RESULT_USER_NAME = "UserName";
        public const string RESULT_USER_FULL_NAME = "UserFullName";
        public const string RESULT_PRODUCT_PRICE = "ProductPrice";

        //Date Time
        public static DateTime MAX_DATE = new DateTime(2099, 12, 31);
        public const int MAX_YEAR = 2099;
        public static DateTime MIN_DATE = new DateTime(2000, 01, 01);
        public const int MIN_YEAR = 2000;

        //Default
        public const string DFT_DECIMAL_POINT = ".";
        /** - */
        public const string HYPHEN = "-";
        public const char HYPHEN_CHAR = '-';
        public const string DFT_CULTURE_NAME = "ja-JP";

        //CSS
        public const string CSS_CLASS_DELETE_ROW = "rowDel";
        public const string CSS_CLASS_BUTTON_GRID = "button_grid";
        public const string CSS_CLASS_DATE = "dat";
        public const string CSS_CLASS_FINDBUTTON = "findButton";
        public const string CSS_CLASS_PICKING_ROW = "info";

        public const char CHAR_ZERO = '0';
        public const char CHAR_SEPARATOR = '|';

        public const string BLANK = "---";
        public const string SLASH = "/";

        public const string PRINT_TYPE_LIST = "LIST";
        public const string PRINT_TYPE_DETAIL = "DETAIL";

        public const string MASTER_GRID = "master";
        public const string PROCESS_GRID = "process";

        //TSequences TagNo
        public const string TAGNO_DIVISION_TAGNO = "10";
        //public const string TAGNO_DIVISION_BALANCENO = "20";
        public const string TAGNO_DIVISION_SHIPNO = "30";

        public const string SHIPPINGPRINTFLAG_TRUE= "True";
        public const string SHIPPINGCOMPLETEFLAG_TRUE = "True";
        public const string PICKINGCOMPLETEFLAG_TRUE = "True";

        /// <summary>
        /// TAG_PRINT_LARGE : "10"
        /// </summary>
        public const string TAG_PRINT_LARGE = "10";

        /// <summary>
        /// TAG_PRINT_SMALL : "20"
        /// </summary>
        public const string TAG_PRINT_SMALL = "20";

        /// <summary>
        /// TAG_PRINT_SET_SIZE_CD : "07"
        /// </summary>
        public const string TAG_PRINT_SET_SIZE_CD = "07";

        /// <summary>
        /// TAG_PRINT_NONE : "00"
        /// </summary>
        public const string TAG_PRINT_NONE = "00";

        /// <summary>
        /// TAG_PRINT_LANGUAGE_ENG : 1
        /// </summary>
        public const int TAG_PRINT_LANGUAGE_ENG = 1;

        /// <summary>
        /// BALANCE_PRINT_VIEW_TAGNO : "TagNo"
        /// </summary>
        public const string BALANCE_PRINT_VIEW_TAGNO = "TagNo";

        /// <summary>
        /// BALANCE_PRINT_VIEW_BRANCH_TAGNO : "BranchTagNo"
        /// </summary>
        public const string BALANCE_PRINT_VIEW_BRANCH_TAGNO = "BranchTagNo";

        /// <summary>
        /// BALANCE_PRINT_VIEW_PRODUCT : "Product"
        /// </summary>
        public const string BALANCE_PRINT_VIEW_PRODUCT = "Product";

        /// <summary>
        /// BALANCE_PRINT_VIEW_LOCATION : "Location"
        /// </summary>
        public const string BALANCE_PRINT_VIEW_LOCATION = "Location";

        public const int EXCEL_MAX_SHEET = 500;

        public const int EXCEL_MAX_ROW = 65536;

        #endregion

        #region Group Action

        /// <summary>
        /// GROUP_ROLE_INSERT : "01"
        /// </summary>
        public const string GROUP_ROLE_INSERT_CD = "01";

        /// <summary>
        /// GROUP_ROLE_UPDATE : "02"
        /// </summary>
        public const string GROUP_ROLE_UPDATE_CD = "02";

        /// <summary>
        /// GROUP_ROLE_DELETE : "03"
        /// </summary>
        public const string GROUP_ROLE_DELETE_CD = "03";

        /// <summary>
        /// GROUP_ROLE_EXPORT : "04"
        /// </summary>
        public const string GROUP_ROLE_EXPORT_CD = "04";

        /// <summary>
        /// GROUP_ROLE_VIEW : "05"
        /// </summary>
        public const string GROUP_ROLE_VIEW_CD = "05";

        /// <summary>
        /// Role Include Deleted Data
        /// </summary>
        public const string GROUP_ROLE_INCLUDE_DELETE_CD = "06";

        /// <summary>
        /// 07 Picking
        /// 07 検品
        /// </summary>
        public const string GROUP_ROLE_PICKING = "07";

        /// <summary>
        /// 08 Cancel
        /// 08 キャンセル
        /// </summary>
        public const string GROUP_ROLE_CANCEL = "08";

        /// <summary>
        /// GROUP_SUPPER_ADMIN_CD
        /// </summary>
        public const string GROUP_SUPPER_ADMIN_CD = "00";

        #endregion

        #region Group View
        
        /// <summary>
        /// 01	UserMaster
        /// 01	ユーザーマスタ
        /// </summary>
        public const string GROUP_VIEW_USER_MASTER = "01";

        /// <summary>
        /// 02	ProductMaster
        /// 02	商品マスタ
        /// </summary>
        public const string GROUP_VIEW_PRODUCT_MASTER = "02";
        
        /// <summary>
        /// 03	CustomerMaster
        /// 03	出荷先マスタ
        /// </summary>
        public const string GROUP_VIEW_CUSTOMER_MASTER = "03";
        
        /// <summary>
        /// 04	CompanyMaster
        /// 04	自社マスタ
        /// </summary>
        public const string GROUP_VIEW_COMPANY_MASTER = "04";

        /// <summary>
        ///05	LocationMaster
        ///05	ロケーションマスタ
        /// </summary>
        public const string GROUP_VIEW_LOCATION_MASTER = "05";

        /// 06	GroupMaster
        /// 06	グループマスタ
        /// <summary>
        /// </summary>
        public const string GROUP_VIEW_GROUP_MASTER = "06";

        /// <summary>
        /// 07	CategoryMaster
        /// 07	カテゴリーマスタ
        /// </summary>
        public const string GROUP_VIEW_CATEGORY_MASTER = "07";

        /// <summary>
        /// 21	InboundDelivery
        /// 21	入荷
        /// </summary>
        public const string GROUP_VIEW_INBOUND_DELIVERY = "21";

        /// <summary>
        /// 22	GoodsReceiptInspection
        /// 22	入庫検品
        /// </summary>
        public const string GROUP_VIEW_GOODS_RECEIPT_INSPECTION = "22";

        /// <summary>
        /// 23	StockInquiry
        /// 23	在庫照会
        /// </summary>
        public const string GROUP_VIEW_STOCK_INQUIRY = "23";

        /// <summary>
        /// 24	OutboundDeliveryIndication
        /// 24	出荷指示
        /// </summary>
        public const string GROUP_VIEW_OUTBOUND_DELIVERY_INDICATION = "24";

        /// <summary>
        /// 25	GoodsIssueInspection
        /// 25	出庫検品
        /// </summary>
        public const string GROUP_VIEW_GOODS_ISSUE_INSPECTION = "25";

        /// <summary>
        /// 26	OutboundDeliveryInspection
        /// 26	出荷検品
        /// </summary>
        public const string GROUP_VIEW_OUTBOUND_DELIVERY_INSPECTION = "26";

        /// <summary>
        /// 27	MoveIndication
        /// 27	移動指示
        /// </summary>
        public const string GROUP_VIEW_MOVE_INDICATION = "27";

        /// <summary>
        /// 28	MoveGoodsIssueInspection
        /// 28	移動出庫検品
        /// </summary>
        public const string GROUP_VIEW_MOVE_GOODS_ISSUE_INSPECTION = "28";

        /// <summary>
        /// 29	MoveOutboundDeliveryInspection
        /// 29	移動出荷検品
        /// </summary>
        public const string GROUP_VIEW_MOVE_OUTBOUND_DELIVERY_INSPECTION = "29";

        /// <summary>
        /// 30	StockTakeProclamation
        /// 30	棚卸宣言
        /// </summary>
        public const string GROUP_VIEW_STOCK_TAKING_PROCLAIM = "30";

        /// <summary>
        /// 31	StockTaking
        /// 31	棚卸差異
        /// </summary>
        public const string GROUP_VIEW_STOCK_TAKING_DEF = "31";

        /// <summary>
        /// 32	Balance In Store Print
        /// 32	受払表印刷
        /// </summary>
        public const string GROUP_VIEW_BALANCE_IN_STORE_PRINT = "32";

        /// <summary>
        /// 33	Outbound Delivered Inquiry
        /// 33	出荷済照会
        /// </summary>
        public const string GROUP_VIEW_OUTBOUND_DELIVERED_INQUIRY = "33";

        /// <summary>
        /// Outbound Delivered Report
        /// 出荷済一覧表出力
        /// </summary>
        public const string GROUP_VIEW_OUTBOUND_DELIVERED_REPORT = "34";

        #endregion

        #region Label - Title

        /// <summary>
        /// Appy
        /// </summary>
        public const string BTN_B0001 = "B0001";

        /// <summary>
        /// Back
        /// </summary>
        public const string BTN_B0002 = "B0002";

        /// <summary>
        /// Cancel
        /// </summary>
        public const string BTN_B0003 = "B0003";

        /// <summary>
        /// Clear
        /// </summary>
        public const string BTN_B0004 = "B0004";

        /// <summary>
        /// Copy
        /// </summary>
        public const string BTN_B0005 = "B0005";

        /// <summary>
        /// Decision
        /// </summary>
        public const string BTN_B0006 = "B0006";

        /// <summary>
        /// Delete
        /// </summary>
        public const string BTN_B0007 = "B0007";

        /// <summary>
        /// Login
        /// </summary>
        public const string BTN_B0008 = "B0008";

        /// <summary>
        /// Create
        /// </summary>
        public const string BTN_B0009 = "B0009";
        
        /// <summary>
        /// Search
        /// </summary>
        public const string BTN_B0010 = "B0010";

        /// <summary>
        /// Edit
        /// </summary>
        public const string BTN_B0011 = "B0011";

        /// <summary>
        /// Detail
        /// </summary>
        public const string BTN_B0012 = "B0012";

        /// <summary>
        /// Tag Print
        /// </summary>
        public const string BTN_B0013 = "B0013";

        /// <summary>
        /// CSV output
        /// </summary>
        public const string BTN_B0014 = "B0014";

        /// <summary>
        /// Add Row
        /// </summary>
        public const string BTN_B0015 = "B0015";

        /// <summary>
        /// Large
        /// </summary>
        public const string BTN_B0018 = "B0018";

        /// <summary>
        /// Small
        /// </summary>
        public const string BTN_B0019 = "B0019";

        /// <summary>
        /// はい
        /// </summary>
        public const string BTN_B0020 = "B0020";

        /// <summary>
        /// いいえ
        /// </summary>
        public const string BTN_B0021 = "B0021";

        /// <summary>
        /// OK
        /// </summary>
        public const string BTN_B0022 = "B0022";

        /// <summary>
        /// (出荷指示書発行) Shipping instruction issue
        /// </summary>
        public const string BTN_B0023 = "B0023";

        /// <summary>
        /// 検品 (Picking)
        /// </summary>
        public const string BTN_B0024 = "B0024";

        /// <summary>
        /// 明細
        /// </summary>
        public const string BTN_B0025 = "B0025";

        /// <summary>
        /// 移動指示書発行
        /// Move indication print
        /// </summary>
        public const string BTN_B0026 = "B0026";

        /// <summary>
        /// 宣言
        /// Proclaim
        /// </summary>
        public const string BTN_B0027 = "B0027";

        /// <summary>
        /// 棚卸表発行
        /// Stock list print
        /// </summary>
        public const string BTN_B0028 = "B0028";

        /// <summary>
        /// 棚卸確定
        /// </summary>
        public const string BTN_B0029 = "B0029";

        /// <summary>
        /// 差異表発行
        /// </summary>
        public const string BTN_B0030 = "B0030";

        /// <summary>
        /// 受払表発行
        /// Issue balance store
        /// </summary>
        public const string BTN_B0031 = "B0031";
        
        /// <summary>
        /// 在庫一覧発行
        /// Issue stock list
        /// </summary>
        public const string BTN_B0032 = "B0032";

        /// <summary>
        /// 全移動
        /// </summary>
        public const string BTN_B0033 = "B0033";

        /// <summary>
        /// 行削除
        /// </summary>
        public const string BTN_B0034 = "B0034";

        /// <summary>
        /// 出荷済一覧発行
        /// </summary>
        public const string BTN_B0035 = "B0035";

        /// <summary>
        /// 出荷済一覧発行
        /// </summary>
        public const string BTN_B0036 = "B0036";

        /// <summary>
        /// export excel balance store
        /// </summary>
        public const string BTN_B0037 = "B0037";

        /// <summary>
        /// 入荷入力
        /// </summary>
        public const string LBL_T0001 = "T0001";

        /// <summary>
        /// 入庫検品
        /// </summary>
        public const string LBL_T0002 = "T0002";

        /// <summary>
        /// 出荷登録
        /// </summary>
        public const string LBL_T0003 = "T0003";

        /// <summary>
        /// 出庫検品
        /// </summary>
        public const string LBL_T0004 = "T0004";

        /// <summary>
        /// 出荷検品
        /// </summary>
        public const string LBL_T0005 = "T0005";

        /// <summary>
        /// 移動指示登録
        /// </summary>
        public const string LBL_T0006 = "T0006";

        /// <summary>
        /// 移動出庫検品
        /// </summary>
        public const string LBL_T0007 = "T0007";

        /// <summary>
        /// 移動出荷検品
        /// </summary>
        public const string LBL_T0008 = "T0008";

        /// <summary>
        /// 在庫照会
        /// </summary>
        public const string LBL_T0009 = "T0009";

        /// <summary>
        /// 出荷済照会
        /// </summary>
        public const string LBL_T0010 = "T0010";

        /// <summary>
        /// 棚卸
        /// </summary>
        public const string LBL_T0011 = "T0011";

        /// <summary>
        /// 棚卸検品
        /// </summary>
        public const string LBL_T0012 = "T0012";

        /// <summary>
        /// 帳票出力
        /// </summary>
        public const string LBL_T0013 = "T0013";

        /// <summary>
        /// 各種マスタ設定
        /// </summary>
        public const string LBL_T0014 = "T0014";

        /// <summary>
        /// 商品マスタ
        /// </summary>
        public const string LBL_T0015 = "T0015";

        /// <summary>
        /// カテゴリーマスタ
        /// </summary>
        public const string LBL_T0016 = "T0016";

        /// <summary>
        /// 顧客マスタ
        /// </summary>
        public const string LBL_T0017 = "T0017";

        /// <summary>
        /// ロケーションマスタ
        /// </summary>
        public const string LBL_T0018 = "T0018";

        /// <summary>
        /// ユーザーマスタ
        /// </summary>
        public const string LBL_T0019 = "T0019";

        /// <summary>
        /// グループマスタ
        /// </summary>
        public const string LBL_T0020 = "T0020";

        /// <summary>
        /// 自社マスタ
        /// </summary>
        public const string LBL_T0021 = "T0021";

        /// <summary>
        /// 倉庫マスタ
        /// </summary>
        public const string LBL_T0022 = "T0022";

        /// <summary>
        /// 区分マスタ
        /// </summary>
        public const string LBL_T0023 = "T0023";

        /// <summary>
        /// メインメニュー
        /// </summary>
        public const string LBL_T0024 = "T0024";

        /// <summary>
        /// 各種帳票出力
        /// </summary>
        public const string LBL_T0025 = "T0025";

        /// <summary>
        /// 受払表出力
        /// </summary>
        public const string LBL_T0026 = "T0026";

        /// <summary>
        /// 出荷済一覧表出力
        /// </summary>
        public const string LBL_T0027 = "T0027";

        /// <summary>
        /// 入荷登録を行います。現品票発行も行います。
        /// </summary>
        public const string LBL_S0001 = "S0001";

        /// <summary>
        /// 入庫検品を行います。
        /// </summary>
        public const string LBL_S0002 = "S0002";

        /// <summary>
        /// 出荷指示を登録します。
        /// </summary>
        public const string LBL_S0003 = "S0003";

        /// <summary>
        /// 出荷指示にもとづく出庫を行います。
        /// </summary>
        public const string LBL_S0004 = "S0004";

        /// <summary>
        /// 出荷指示書にもとづく出荷を行います。
        /// </summary>
        public const string LBL_S0005 = "S0005";

        /// <summary>
        /// ロケーション移動、倉庫間移動の指示登録を行います。
        /// </summary>
        public const string LBL_S0006 = "S0006";

        /// <summary>
        /// 移動現品の出庫検品を行います。
        /// </summary>
        public const string LBL_S0007 = "S0007";

        /// <summary>
        /// 倉庫間移動の現品を出荷します。
        /// </summary>
        public const string LBL_S0008 = "S0008";

        /// <summary>
        /// 在庫一覧を照会します。在庫状態の変更が可能です。
        /// </summary>
        public const string LBL_S0009 = "S0009";

        /// <summary>
        /// 出荷済の現品を検索、照会します。
        /// </summary>
        public const string LBL_S0010 = "S0010";

        /// <summary>
        /// ロケーションを指定して棚卸を開始します。
        /// </summary>
        public const string LBL_S0011 = "S0011";

        /// <summary>
        /// 棚卸検品を行います。
        /// </summary>
        public const string LBL_S0012 = "S0012";

        /// <summary>
        /// 各種帳票を出力します。
        /// </summary>
        public const string LBL_S0013 = "S0013";

        /// <summary>
        /// 各種マスタの設定を行います。
        /// </summary>
        public const string LBL_S0014 = "S0014";

        /// <summary>
        /// 商品情報を管理します。
        /// </summary>
        public const string LBL_S0015 = "S0015";

        /// <summary>
        /// カテゴリ情報を管理します。
        /// </summary>
        public const string LBL_S0016 = "S0016";

        /// <summary>
        /// 顧客情報を管理します。
        /// </summary>
        public const string LBL_S0017 = "S0017";

        /// <summary>
        /// ロケーション情報を管理します。
        /// </summary>
        public const string LBL_S0018 = "S0018";

        /// <summary>
        /// ユーザー情報を管理します。
        /// </summary>
        public const string LBL_S0019 = "S0019";

        /// <summary>
        /// 権限グループ情報を管理します。
        /// </summary>
        public const string LBL_S0020 = "S0020";

        /// <summary>
        /// 自社情報を管理します。
        /// </summary>
        public const string LBL_S0021 = "S0021";

        /// <summary>
        /// 倉庫情報を管理します。
        /// </summary>
        public const string LBL_S0022 = "S0022";

        /// <summary>
        /// 区分情報を管理します。
        /// </summary>
        public const string LBL_S0023 = "S0023";

        /// <summary>
        /// 受払表を出力します。
        /// </summary>
        public const string LBL_S0024 = "S0024";

        /// <summary>
        /// 出荷済一覧表を出力します。
        /// </summary>
        public const string LBL_S0025 = "S0025";

        /// <summary>
        /// User list
        /// </summary>
        public const string LBL_L0001 = "L0001";

        /// <summary>
        /// User detail
        /// </summary>
        public const string LBL_L0002 = "L0002";

        /// <summary>
        /// User create
        /// </summary>
        public const string LBL_L0003 = "L0003";

        /// <summary>
        /// User edit
        /// </summary>
        public const string LBL_L0005 = "L0005";

        /// <summary>
        /// User CD
        /// </summary>
        public const string LBL_L0006 = "L0006";

        /// <summary>
        /// User name
        /// </summary>
        public const string LBL_L0007 = "L0007";

        /// <summary>
        /// User short name 
        /// </summary>
        public const string LBL_L0008 = "L0008";

        /// <summary>
        /// Login ID
        /// </summary>
        public const string LBL_L0009 = "L0009";

        /// <summary>
        /// Password
        /// </summary>
        public const string LBL_L0010 = "L0010";

        /// <summary>
        /// Confirm password 
        /// </summary>
        public const string LBL_L0011 = "L0011";

        /// <summary>
        /// Authority
        /// </summary>
        public const string LBL_L0012 = "L0012";

        /// <summary>
        /// Product list
        /// </summary>
        public const string LBL_L0013 = "L0013";

        /// <summary>
        /// Product Detail
        /// </summary>
        public const string LBL_L0014 = "L0014";

        /// <summary>
        /// Product create
        /// </summary>
        public const string LBL_L0015 = "L0015";

        /// <summary>
        /// Product edit
        /// </summary>
        public const string LBL_L0017 = "L0017";

        /// <summary>
        /// Product CD
        /// </summary>
        public const string LBL_L0018 = "L0018";

        /// <summary>
        /// 商品名
        /// </summary>
        public const string LBL_L0019 = "L0019";

        /// <summary>
        /// カテゴリー
        /// </summary>
        public const string LBL_L0020 = "L0020";

        /// <summary>
        /// 単価
        /// </summary>
        public const string LBL_L0021 = "L0021";

        /// <summary>
        /// 入数
        /// </summary>
        public const string LBL_L0022 = "L0022";

        /// <summary>
        /// 得意先一覧
        /// </summary>
        public const string LBL_L0023 = "L0023";

        /// <summary>
        /// 得意先詳細
        /// </summary>
        public const string LBL_L0024 = "L0024";

        /// <summary>
        /// 得意先新規
        /// </summary>
        public const string LBL_L0025 = "L0025";

        /// <summary>
        /// 得意先編集
        /// </summary>
        public const string LBL_L0027 = "L0027";

        /// <summary>
        /// 得意先CD
        /// </summary>
        public const string LBL_L0028 = "L0028";

        /// <summary>
        /// 得意先名
        /// </summary>
        public const string LBL_L0029 = "L0029";

        /// <summary>
        /// 住所
        /// </summary>
        public const string LBL_L0030 = "L0030";

        /// <summary>
        /// 電話番号
        /// </summary>
        public const string LBL_L0031 = "L0031";

        /// <summary>
        /// FAX
        /// </summary>
        public const string LBL_L0032 = "L0032";

        /// <summary>
        /// 未選択
        /// </summary>
        public const string LBL_L0034 = "L0034";

        /// <summary>
        /// 昇順
        /// </summary>
        public const string LBL_L0035 = "L0035";

        /// <summary>
        /// 降順
        /// </summary>
        public const string LBL_L0036 = "L0036";

        /// <summary>
        /// 区分一覧
        /// </summary>
        public const string LBL_L0037 = "L0037";

        /// <summary>
        /// 区分詳細
        /// </summary>
        public const string LBL_L0038 = "L0038";

        /// <summary>
        /// 区分新規
        /// </summary>
        public const string LBL_L0039 = "L0039";
        
        /// <summary>
        /// 区分編集
        /// </summary>
        public const string LBL_L0041 = "L0041";

        /// <summary>
        /// 区分CD
        /// </summary>
        public const string LBL_L0042 = "L0042";

        /// <summary>
        /// 区分名
        /// </summary>
        public const string LBL_L0043 = "L0043";

        /// <summary>
        /// データCD
        /// </summary>
        public const string LBL_L0044 = "L0044";

        /// <summary>
        /// 値
        /// </summary>
        public const string LBL_L0045 = "L0045";

        /// <summary>
        /// Location list
        /// </summary>
        public const string LBL_L0046 = "L0046";

        /// <summary>
        /// Location detail
        /// </summary>
        public const string LBL_L0047 = "L0047";

        /// <summary>
        /// Location create
        /// </summary>
        public const string LBL_L0048 = "L0048";

        /// <summary>
        /// Location edit
        /// </summary>
        public const string LBL_L0050 = "L0050";

        /// <summary>
        /// Location CD
        /// </summary>
        public const string LBL_L0051 = "L0051";

        /// <summary>
        /// Location name
        /// </summary>
        public const string LBL_L0052 = "L0052";

        /// <summary>
        /// Warehouse list
        /// </summary>
        public const string LBL_L0053 = "L0053";

        /// <summary>
        /// Warehouse detail
        /// </summary>
        public const string LBL_L0054 = "L0054";

        /// <summary>
        /// Warehouse create
        /// </summary>
        public const string LBL_L0055 = "L0055";

        /// <summary>
        /// Warehouse edit
        /// </summary>
        public const string LBL_L0057 = "L0057";

        /// <summary>
        /// Warehouse CD
        /// </summary>
        public const string LBL_L0058 = "L0058";

        /// <summary>
        /// Warehouse name
        /// </summary>
        public const string LBL_L0059 = "L0059";

        /// <summary>
        /// Customer search
        /// </summary>
        public const string LBL_L0060 = "L0060";

        /// <summary>
        /// Division search
        /// </summary>
        public const string LBL_L0061 = "L0061";

        /// <summary>
        /// Product search
        /// </summary>
        public const string LBL_L0062 = "L0062";

        /// <summary>
        /// Location search
        /// </summary>
        public const string LBL_L0063 = "L0063";

        /// <summary>
        /// Warehouse search
        /// </summary>
        public const string LBL_L0064 = "L0064";

        /// <summary>
        /// Login
        /// </summary>
        public const string LBL_L0065 = "L0065";

        /// <summary>
        /// Delete flag
        /// </summary>
        public const string LBL_L0066 = "L0066";

        /// <summary>
        /// Include delete data
        /// </summary>
        public const string LBL_L0067 = "L0067";

        /// <summary>
        /// ～
        /// </summary>
        public const string LBL_L0068 = "L0068";

        /// <summary>
        /// Cost (From)
        /// </summary>
        public const string LBL_L0069 = "L0069";

        /// <summary>
        /// Cost (To)
        /// </summary>
        public const string LBL_L0070 = "L0070";

        /// <summary>
        /// 住所１
        /// </summary>
        public const string LBL_L0071 = "L0071";
        
        /// <summary>
        /// 住所２
        /// </summary>
        public const string LBL_L0072 = "L0072";
        
        /// <summary>
        /// 住所３
        /// </summary>
        public const string LBL_L0073 = "L0073";

        /// <summary>
        /// メール
        /// </summary>
        public const string LBL_L0074 = "L0074";

        /// <summary>
        /// 在庫引当順序
        /// Stock allocation order
        /// </summary>
        public const string LBL_L0075 = "L0075";

        /// <summary>
        /// ユーザー検索のタイトル
        /// </summary>
        public const string LBL_L0076 = "L0076";

        /// <summary>
        /// Welcome {0}
        /// </summary>
        public const string LBL_L0077 = "L0077";

        /// <summary>
        /// Logout
        /// </summary>
        public const string LBL_L0078 = "L0078";  

        /// <summary>
        /// 現品票枝番号
        /// </summary>
        public const string LBL_L0079 = "L0079";  
        
        /// <summary>
        /// 入荷日
        /// </summary>
        public const string LBL_L0080 = "L0080";  

        /// <summary>
        /// 商品入庫単価	
        /// </summary>
        public const string LBL_L0081 = "L0081";  

        /// <summary>
        /// 入荷数
        /// </summary>
        public const string LBL_L0082 = "L0082";  

        /// <summary>
        /// 入荷合計金額
        /// </summary>
        public const string LBL_L0083 = "L0083";  

        /// <summary>
        /// LOT番号
        /// </summary>
        public const string LBL_L0084 = "L0084";  

        /// <summary>
        /// 製造年月日
        /// </summary>
        public const string LBL_L0085 = "L0085";  

        /// <summary>
        /// 賞味期限
        /// </summary>
        public const string LBL_L0086 = "L0086";  

        /// <summary>
        /// メモ	
        /// </summary>
        public const string LBL_L0087 = "L0087";  

        /// <summary>
        /// 印刷済
        /// </summary>
        public const string LBL_L0088 = "L0088";  

        /// <summary>
        /// 印刷	
        /// </summary>
        public const string LBL_L0089 = "L0089";

        /// <summary>
        /// Printed data only	
        /// </summary>
        public const string LBL_L0090 = "L0090";

        /// <summary>
        /// 入荷入力一覧
        /// </summary>
        public const string LBL_L0091 = "L0091";

        /// <summary>
        /// 入荷入力詳細
        /// </summary>
        public const string LBL_L0092 = "L0092";

        /// <summary>
        /// 入荷入力新規
        /// </summary>
        public const string LBL_L0093 = "L0093";

        /// <summary>
        /// 入荷入力編集
        /// </summary>
        public const string LBL_L0095 = "L0095";

        /// <summary>
        /// 自社CD
        /// </summary>
        public const string LBL_L0096 = "L0096";

        /// <summary>
        /// 自社名1
        /// </summary>
        public const string LBL_L0097 = "L0097";

        /// <summary>
        /// 自社名2
        /// </summary>
        public const string LBL_L0098 = "L0098";

        /// <summary>
        /// 自社名
        /// </summary>
        public const string LBL_L0099 = "L0099";

        /// <summary>
        /// 自社一覧
        /// </summary>
        public const string LBL_L0100 = "L0100";

        /// <summary>
        /// 自社詳細
        /// </summary>
        public const string LBL_L0101 = "L0101";

        /// <summary>
        /// 自社新規
        /// </summary>
        public const string LBL_L0102 = "L0102";

        /// <summary>
        /// 自社編集
        /// </summary>
        public const string LBL_L0104 = "L0104";

        /// <summary>
        /// 入庫日
        /// </summary>
        public const string LBL_L0105 = "L0105";

        /// <summary>
        /// 現品票番号
        /// </summary>
        public const string LBL_L0106 = "L0106";

        /// <summary>
        /// 入庫登録
        /// </summary>
        public const string LBL_L0107 = "L0107";

        /// <summary>
        /// 入庫詳細
        /// </summary>
        public const string LBL_L0108 = "L0108";

        /// <summary>
        /// 自社検索	
        /// </summary>
        public const string LBL_L0109 = "L0109";

        /// <summary>
        /// 棚	
        /// </summary>
        public const string LBL_L0110 = "L0110";

        /// <summary>
        /// 倉庫		
        /// </summary>
        public const string LBL_L0111 = "L0111";

        /// <summary>
        /// 入庫禁止			
        /// </summary>
        public const string LBL_L0112 = "L0112";
        
        /// <summary>
        /// 入庫許可		
        /// </summary>
        public const string LBL_L0113 = "L0113";

        /// <summary>
        /// 出庫禁止	
        /// </summary>
        public const string LBL_L0114 = "L0114";
        
        /// <summary>
        /// 出庫許可
        /// </summary>
        public const string LBL_L0115 = "L0115";

        /// <summary>
        /// 値（英語）
        /// </summary>
        public const string LBL_L0116 = "L0116";

        /// <summary>
        /// 値（ベトナム語）
        /// </summary>
        public const string LBL_L0117 = "L0117";

        /// <summary>
        /// 値（日本語)
        /// </summary>
        public const string LBL_L0118 = "L0118";

        /// <summary>
        /// 日の入荷日（From）
        /// </summary>
        public const string LBL_L0119 = "L0119";

        /// <summary>
        /// 月の入荷日（From）
        /// </summary>
        public const string LBL_L0120 = "L0120";

        /// <summary>
        /// 年の入荷日（From）
        /// </summary>
        public const string LBL_L0121 = "L0121";

        /// <summary>
        /// 日の入荷日（To）
        /// </summary>
        public const string LBL_L0122 = "L0122";

        /// <summary>
        /// 月の入荷日（To）
        /// </summary>
        public const string LBL_L0123 = "L0123";

        /// <summary>
        /// 年の入荷日（To）
        /// </summary>
        public const string LBL_L0124 = "L0124";

        /// <summary>
        /// 入荷日（From）
        /// </summary>
        public const string LBL_L0125 = "L0125";

        /// <summary>
        /// 入荷日（To）
        /// </summary>
        public const string LBL_L0126 = "L0126";
        
		/// <summary>
        /// 箱数
        /// </summary>
        public const string LBL_L0127 = "L0127";

        /// <summary>
        /// 現品票番号印刷
        /// </summary>
        public const string LBL_L0128 = "L0128";

        /// <summary>
        /// 在庫状態区分
        /// </summary>
        public const string LBL_L0129 = "L0129";

        /// <summary>
        /// 日付
        /// </summary>
        public const string LBL_L0130 = "L0130";

        /// <summary>
        /// 月
        /// </summary>
        public const string LBL_L0131 = "L0131";

        /// <summary>
        /// 年
        /// </summary>
        public const string LBL_L0132 = "L0132";

        /// <summary>
        /// 表示現品票枝番号
        /// </summary>
        public const string LBL_L0133 = "L0133";

        /// <summary>
        /// 入庫日（From）
        /// </summary>
        public const string LBL_L0134 = "L0134";

        /// <summary>
        /// 入庫日（To）
        /// </summary>
        public const string LBL_L0135 = "L0135";

        /// <summary>
        /// LOT2（From）
        /// </summary>
        public const string LBL_L0136 = "L0136";

        /// <summary>
        /// LOT2（To）
        /// </summary>
        public const string LBL_L0137 = "L0137";

        /// <summary>
        /// LOT3（From）
        /// </summary>
        public const string LBL_L0138 = "L0138";

        /// <summary>
        /// LOT3（To）
        /// </summary>
        public const string LBL_L0139 = "L0139";

        /// <summary>
        /// Category Name
        /// </summary>
        public const string LBL_L0140 = "L0140";

        /// <summary>
        /// Category CD
        /// </summary>
        public const string LBL_L0141 = "L0141";

        /// <summary>
        /// 在庫照会
        /// </summary>
        public const string LBL_L0142 = "L0142";

        /// <summary>
        /// 入庫
        /// </summary>
        public const string LBL_L0143 = "L0143";

        /// <summary>
        /// 出庫
        /// </summary>
        public const string LBL_L0144 = "L0144";

        /// <summary>
        /// （{0}番目）
        /// </summary>
        public const string LBL_L0145 = "L0145";

        /// <summary>
        /// 出荷指示番号
        /// </summary>
        public const string LBL_L0146 = "L0146";

        /// <summary>
        /// 出荷予定日
        /// </summary>
        public const string LBL_L0147 = "L0147";

        /// <summary>
        /// 出庫検品フラグ
        /// </summary>
        public const string LBL_L0148 = "L0148";

        /// <summary>
        /// 出庫検品フラグ
        /// </summary>
        public const string LBL_L0149 = "L0149";

        /// <summary>
        /// 出荷数
        /// </summary>
        public const string LBL_L0150 = "L0150";

        /// <summary>
        /// 番号
        /// </summary>
        public const string LBL_L0151 = "L0151";

        /// <summary>
        /// Allocation
        /// </summary>
        public const string LBL_L0152 = "L0152";

        /// <summary>
        /// 出荷予定日(From)
        /// </summary>
        public const string LBL_L0153 = "L0153";

        /// <summary>
        /// 出荷予定日(To)
        /// </summary>
        public const string LBL_L0154 = "L0154";

        /// <summary>
        /// Checked
        /// Đã chọn
        /// 検品済
        /// </summary>
        public const string LBL_L0155 = "L0155";

        /// <summary>
        /// 出荷指示入力一覧
        /// </summary>
        public const string LBL_L0156 = "L0156";

        /// <summary>
        /// 出荷指示入力詳細
        /// </summary>
        public const string LBL_L0157 = "L0157";

        /// <summary>
        /// 出荷指示入力新規
        /// </summary>
        public const string LBL_L0158 = "L0158";

        /// <summary>
        /// 出荷指示入力編集
        /// </summary>
        public const string LBL_L0160 = "L0160";

        /// <summary>
        /// 出荷指示商品別明細
        /// </summary>
        public const string LBL_L0161 = "L0161";

        /// <summary>
        /// 出庫検品一覧
        /// </summary>
        public const string LBL_L0162 = "L0162";

        /// <summary>
        /// Shipment Picking
        /// </summary>
        public const string LBL_L0163 = "L0163";

        /// <summary>
        /// 当日
        /// </summary>
        public const string LBL_L0164 = "L0164";

        /// <summary>
        /// 受払区分
        /// </summary>
        public const string LBL_L0165 = "L0165";

        /// <summary>
        /// Checked Quantity
        /// 検品済数
        /// </summary>
        public const string LBL_L0166 = "L0166";

        /// <summary>
        /// 出荷検品一覧
        /// </summary>
        public const string LBL_L0167 = "L0167";

        /// <summary>
        /// 出荷検品
        /// </summary>
        public const string LBL_L0168 = "L0168";

        /// <summary>
        /// 出荷検品キャンセル
        /// </summary>
        public const string LBL_L0169 = "L0169";

        /// <summary>
        /// 出荷指示書
        /// </summary>
        public const string LBL_L0170 = "L0170";

        /// 指示番号
        /// </summary>
        public const string LBL_L0171 = "L0171";

        /// <summary>
        /// ページ
        /// </summary>
        public const string LBL_L0172 = "L0172";

        /// <summary>
        /// 作成日
        /// </summary>
        public const string LBL_L0173 = "L0173";

        /// <summary>
        /// 数量
        /// </summary>
        public const string LBL_L0174 = "L0174";

        /// <summary>
        /// 出荷合計
        /// </summary>
        public const string LBL_L0175 = "L0175";
        
        /// <summary>
        /// グループユーザ一覧
        /// </summary>
        public const string LBL_L0176 = "L0176";

        /// <summary>
        /// グループユーザ詳細
        /// </summary>
        public const string LBL_L0177 = "L0177";

        /// <summary>
        /// グループユーザ新規
        /// </summary>
        public const string LBL_L0178 = "L0178";

        /// <summary>
        /// グループユーザ編集
        /// </summary>
        public const string LBL_L0180 = "L0180";
                
        /// <summary>
        /// グループCD
        /// </summary>
        public const string LBL_L0181 = "L0181";

        /// <summary>
        /// グループ名
        /// </summary>
        public const string LBL_L0182 = "L0182";

        /// <summary>
        /// マスタ画面
        /// </summary>
        public const string LBL_L0183 = "L0183";

        /// <summary>
        /// 処理画面
        /// </summary>
        public const string LBL_L0184 = "L0184";

        /// <summary>
        /// 画面CD
        /// </summary>
        public const string LBL_L0185 = "L0185";

        /// <summary>
        /// 画面名
        /// </summary>
        public const string LBL_L0186 = "L0186";

        /// <summary>
        /// グループユーザ検索
        /// </summary>
        public const string LBL_L0187 = "L0187";

        /// <summary>
        /// 未出荷検品のみ
        /// </summary>
        public const string LBL_L0188 = "L0188";

        /// <summary>
        /// 出庫検品済
        /// </summary>
        public const string LBL_L0189 = "L0189";

        /// <summary>
        /// 出荷検品済
        /// </summary>
        public const string LBL_L0190 = "L0190";

        /// <summary>
        /// 移動先ロケーションCD
        /// </summary>
        public const string LBL_L0191 = "L0191";
        
        /// <summary>
        /// 移動先ロケーション名
        /// </summary>
        public const string LBL_L0192 = "L0192";

        /// <summary>
        /// 移動先倉庫CD
        /// </summary>
        public const string LBL_L0193 = "L0193";

        /// <summary>
        /// 移動先倉庫名
        /// </summary>
        public const string LBL_L0194 = "L0194";

        /// <summary>
        /// 移動指示番号
        /// </summary>
        public const string LBL_L0195 = "L0195";

        /// <summary>
        /// 移動予定日
        /// </summary>
        public const string LBL_L0196 = "L0196";

        /// <summary>
        /// 移動区分
        /// </summary>
        public const string LBL_L0197 = "L0197";

        /// <summary>
        /// 移動出庫検品一覧
        /// </summary>
        public const string LBL_L0198 = "L0198";

        /// <summary>
        /// 移動出庫検品
        /// </summary>
        public const string LBL_L0199 = "L0199";

        /// <summary>
        /// 移動予定日（From）
        /// </summary>
        public const string LBL_L0200 = "L0200";

        /// <summary>
        /// 移動予定日（To）
        /// </summary>
        public const string LBL_L0201 = "L0201";

        /// <summary>
        /// 出荷指示
        /// </summary>
        public const string LBL_L0202 = "L0202";

        /// <summary>
        /// 移動指示
        /// </summary>
        public const string LBL_L0203 = "L0203";

        /// <summary>
        /// カテゴリーコード
        /// </summary>
        public const string LBL_L0204 = "L0204";

        /// <summary>
        /// カテゴリー名
        /// </summary>
        public const string LBL_L0205 = "L0205";

        /// <summary>
        /// カテゴリー一覧
        /// </summary>
        public const string LBL_L0206 = "L0206";

        /// <summary>
        /// カテゴリー詳細
        /// </summary>
        public const string LBL_L0207 = "L0207";

        /// <summary>
        /// カテゴリー新規
        /// </summary>
        public const string LBL_L0208 = "L0208";

        /// <summary>
        /// カテゴリー編集
        /// </summary>
        public const string LBL_L0209 = "L0209";

        /// <summary>
        /// カテゴリー検索
        /// </summary>
        public const string LBL_L0210 = "L0210";

        /// <summary>
        /// 期限
        /// </summary>
        public const string LBL_L0211 = "L0211";

        /// <summary>
        /// 受払表
        /// </summary>
        public const string LBL_L0212 = "L0212";

        /// <summary>
        /// 入荷
        /// </summary>
        public const string LBL_L0213 = "L0213";

        /// <summary>
        /// 入庫
        /// </summary>
        public const string LBL_L0214 = "L0214";

        /// <summary>
        /// 出庫
        /// </summary>
        public const string LBL_L0215 = "L0215";

        /// <summary>
        /// 出荷
        /// </summary>
        public const string LBL_L0216 = "L0216";

        /// <summary>
        /// 通常
        /// </summary>
        public const string LBL_L0217 = "L0217";

        /// <summary>
        /// 返品
        /// </summary>
        public const string LBL_L0218 = "L0218";

        /// <summary>
        /// 移動
        /// </summary>
        public const string LBL_L0219 = "L0219";

        /// <summary>
        /// 棚卸
        /// </summary>
        public const string LBL_L0220 = "L0220";

        /// <summary>
        ///（{0}ページ）
        /// </summary>
        public const string LBL_L0221 = "L0221";
        
        /// <summary>
        /// 移動出荷検品一覧
        /// </summary>
        public const string LBL_L0222 = "L0222";

        /// <summary>
        /// 全ロケーション
        /// All Location
        /// </summary>
        public const string LBL_L0223 = "L0223";				

        /// <summary>
        /// 棚卸宣言
        /// Proclamation
        /// </summary>
        public const string LBL_L0224 = "L0224";

        /// <summary>
        /// 棚卸可能
        /// Possible
        /// </summary>
        public const string LBL_L0225 = "L0225";

        /// <summary>
        /// 棚卸中
        /// Taking
        /// </summary>
        public const string LBL_L0226 = "L0226";

        /// <summary>
        /// はい
        /// Yes
        /// </summary>
        public const string LBL_L0227 = "L0227";

        /// <summary>
        /// いいえ
        /// NoL0237
        /// </summary>
        public const string LBL_L0228 = "L0228";

        /// <summary>
        /// 未検品のみ
        /// </summary>
        public const string LBL_L0229 = "L0229";
        
        /// <summary>
        /// 棚卸開始日
        /// </summary>
        public const string LBL_L0230 = "L0230";
        
        /// <summary>
        /// 棚卸開始日(From)
        /// </summary>
        public const string LBL_L0231 = "L0231";
        
        /// <summary>
        /// 棚卸開始日(To)
        /// </summary>
        public const string LBL_L0232 = "L0232";
        
        /// <summary>
        /// 棚卸終了日
        /// </summary>
        public const string LBL_L0233 = "L0233";
        
        /// <summary>
        /// 棚卸終了日(From)
        /// </summary>
        public const string LBL_L0234 = "L0234";
        
        /// <summary>
        /// 棚卸終了日(To)
        /// </summary>
        public const string LBL_L0235 = "L0235";
        
        /// <summary>
        /// 過不足
        /// </summary>
        public const string LBL_L0236 = "L0236";

        /// <summary>
        /// 移動出荷検品
        /// </summary>
        public const string LBL_L0237 = "L0237";

        /// <summary>
        /// 過剰
        /// </summary>
        public const string LBL_L0238 = "L0238";

        /// <summary>
        /// 不足
        /// </summary>
        public const string LBL_L0239 = "L0239";

        /// <summary>
        /// 移動出荷検品キャンセル
        /// </summary>
        public const string LBL_L0240 = "L0240";

        /// <summary>
        /// 棚卸差異一覧
        /// </summary>
        public const string LBL_L0241 = "L0241";

        /// <summary>
        /// 棚卸差異詳細
        /// </summary>
        public const string LBL_L0242 = "L0242";

        /// <summary>
        /// 受払日
        /// Balance Store Date
        /// </summary>
        public const string LBL_L0243 = "L0243";

        /// <summary>
        /// ロケーションCD(From)
        /// Location CD(From)
        /// </summary>
        public const string LBL_L0244 = "L0244";

        /// <summary>
        /// ロケーションCD(To)
        /// Location CD(To)
        /// </summary>
        public const string LBL_L0245 = "L0245";

        /// <summary>
        /// 受払日(From)
        /// </summary>
        public const string LBL_L0246 = "L0246";

        /// <summary>
        /// 受払日(To)
        /// </summary>
        public const string LBL_L0247 = "L0247";

        /// <summary>
        /// Product Total
        /// 商品合計
        /// </summary>
        public const string LBL_L0248 = "L0248";

        /// <summary>
        /// Grand Total
        /// 総計
        /// </summary>
        public const string LBL_L0249 = "L0249";

        /// <summary>
        /// Stock List by Location
        /// 在庫一覧表（ロケーション別）
        /// </summary>
        public const string LBL_L0250 = "L0250";

        /// <summary>
        /// Date
        /// 日付
        /// </summary>
        public const string LBL_L0251 = "L0251";

        /// <summary>
        /// Location Range
        /// ロケーション範囲
        /// </summary>
        public const string LBL_L0252 = "L0252";

        // <summary>
        /// Stock List by Product
        /// 在庫一覧表（商品別）
        /// </summary>
        public const string LBL_L0253 = "L0253";

        /// <summary>
        /// 移動指示一覧
        /// </summary>
        public const string LBL_L0254 = "L0254";

        /// <summary>
        /// 移動指示詳細
        /// </summary>
        public const string LBL_L0255 = "L0255";

        /// <summary>
        /// 移動指示新規
        /// </summary>
        public const string LBL_L0256 = "L0256";

        /// <summary>
        /// 移動指示編集
        /// </summary>
        public const string LBL_L0257 = "L0257";

        /// <summary>
        /// 移動指示商品別明細
        /// </summary>
        public const string LBL_L0258 = "L0258";

        /// <summary>
        /// 箱数
        /// Box Qty
        /// </summary>
        public const string LBL_L0259 = "L0259";

        /// <summary>
        /// 箱数
        /// Box Qty
        /// </summary>
        public const string LBL_L0260 = "L0260";

        /// <summary>
        /// 期間
        /// Period
        /// </summary>
        public const string LBL_L0261 = "L0261";

        /// <summary>
        /// 区分
        /// Type
        /// </summary>
        public const string LBL_L0262 = "L0262";

        /// <summary>
        /// 宣言
        /// Proclaim
        /// </summary>
        public const string LBL_L0263 = "L0263";

        /// <summary>
        /// 状態	
        /// Status
        /// </summary>
        public const string LBL_L0264 = "L0264";

        /// <summary>
        /// 受払表（商品別）
        /// Balance in Stores by Product
        /// </summary>
        public const string LBL_L0265 = "L0265";

        /// <summary>
        /// 受払表（ロケーション別）
        /// Balance in Stores by Location
        /// </summary>
        public const string LBL_L0266 = "L0266";

        /// <summary>
        /// 棚卸詳細
        /// Stock Taking Detail
        /// </summary>
        public const string LBL_L0267 = "L0267";

        /// <summary>
        /// 在庫一覧表
        /// Stock list
        /// </summary>
        public const string LBL_L0268 = "L0268";

        /// <summary>
        /// 商品
        /// </summary>
        public const string LBL_L0269 = "L0269";

        /// <summary>
        /// In charge person
        /// </summary>
        public const string LBL_L0270 = "L0270";

        /// <summary>
        /// Approval person
        /// </summary>
        public const string LBL_L0271 = "L0271";

        /// <summary>
        /// Start date
        /// </summary>
        public const string LBL_L0272 = "L0272";

        /// <summary>
        /// 棚卸一覧表
        /// </summary>
        public const string LBL_L0273 = "L0273";

        /// <summary>
        /// Location Total
        /// </summary>
        public const string LBL_L0274 = "L0274";

        /// <summary>
        /// Stock List Print
        /// </summary>
        public const string LBL_L0275 = "L0275";

        /// <summary>
        /// Check
        /// </summary>
        public const string LBL_L0276 = "L0276";

        /// <summary>
        /// Outbound Delivered Inquiry List
        /// </summary>
        public const string LBL_L0277 = "L0277";

        /// <summary>
        /// Outbound Delivered Inquiry Detail
        /// </summary>
        public const string LBL_L0278 = "L0278";

        /// <summary>
        /// View tag no
        /// </summary>
        public const string LBL_L0279 = "L0279";

        /// <summary>
        /// Delivered Quantity
        /// </summary>
        public const string LBL_L0280 = "L0280";

        /// <summary>
        /// 移動指示数
        /// </summary>
        public const string LBL_L0281 = "L0281";

        /// <summary>
        /// 移動指示書
        /// </summary>
        public const string LBL_L0282 = "L0282";

        /// <summary>
        /// 重要
        /// </summary>
        public const string LBL_L0283 = "L0283";

        /// <summary>
        /// ヘルプ
        /// </summary>
        public const string LBL_L0284 = "L0284";

        /// <summary>
        /// Variance list
        /// </summary>
        public const string LBL_L0285 = "L0285";

        /// <summary>
        /// Variance
        /// </summary>
        public const string LBL_L0286 = "L0286";

        /// <summary>
        /// Not receipt
        /// </summary>
        public const string LBL_L0287 = "L0287";

        /// <summary>
        /// Supplier CD
        /// </summary>
        public const string LBL_L0288 = "L0288";

        /// <summary>
        /// Supplier name
        /// </summary>
        public const string LBL_L0289 = "L0289";

        /// <summary>
        /// All warehouse
        /// </summary>
        public const string LBL_L0290 = "L0290";

        /// <summary>
        /// Warehouse In Charge
        /// </summary>
        public const string LBL_L0291 = "L0291";

        /// <summary>
        /// View Type
        /// </summary>
        public const string LBL_L0292 = "L0292";

        /// <summary>
        /// 移動指示書（倉庫間）
        /// </summary>
        public const string LBL_L0293 = "L0293";

        /// <summary>
        /// 移動指示書（庫内）
        /// </summary>
        public const string LBL_L0294 = "L0294";

        /// <summary>
        /// 廃棄指示書
        /// </summary>
        public const string LBL_L0295 = "L0295";

        /// <summary>
        /// (良品 or 不良品)一覧
        /// </summary>
        public const string LBL_L0296 = "L0296";

        /// <summary>
        /// 破棄
        /// </summary>
        public const string LBL_L0297 = "L0297";

        /// <summary>
        /// 移動先CD
        /// </summary>
        public const string LBL_L0298 = "L0298";

        /// <summary>
        /// 移動先名
        /// </summary>
        public const string LBL_L0299 = "L0299";

        /// <summary>
        /// 出荷区分
        /// Outbound Kind
        /// </summary>
        public const string LBL_L0300 = "L0300";

        /// <summary>
        /// 便名
        /// DeliveryNumber
        /// </summary>
        public const string LBL_L0301 = "L0301";

        /// <summary>
        /// 出荷先CD
        /// </summary>
        public const string LBL_L0302 = "L0302";

        /// <summary>
        /// 出荷先名
        /// </summary>
        public const string LBL_L0303 = "L0303";

        /// <summary>
        /// 不良品在庫一覧
        /// </summary>
        public const string LBL_L0304 = "L0304";

        /// <summary>
        /// 出荷済編集
        /// </summary>
        public const string LBL_L0305 = "L0305";

        /// <summary>
        /// 出荷済一覧表出力
        /// </summary>
        public const string LBL_L0306 = "L0306";

        /// <summary>
        /// 商品別
        /// </summary>
        public const string LBL_L0307 = "L0307";

        /// <summary>
        /// 出荷先別
        /// </summary>
        public const string LBL_L0308 = "L0308";

        /// <summary>
        /// 出荷済一覧表（商品別）
        /// </summary>
        public const string LBL_L0309 = "L0309";

        /// <summary>
        /// 出荷済一覧表（出荷先別）
        /// </summary>
        public const string LBL_L0310 = "L0310";

        /// <summary>
        /// 出荷先CD(From)
        /// </summary>
        public const string LBL_L0311 = "L0311";

        /// <summary>
        /// 出荷先CD(To)
        /// </summary>
        public const string LBL_L0312 = "L0312";

        /// <summary>
        /// 出荷指示番号合計
        /// </summary>
        public const string LBL_L0313 = "L0313";

        /// <summary>
        /// 出荷先合計
        /// </summary>
        public const string LBL_L0314 = "L0314";

        /// <summary>
        /// 数量
        /// </summary>
        public const string LBL_L0315 = "L0315";

        /// <summary>
        /// 数量
        /// </summary>
        public const string LBL_L0316 = "L0316";

        #endregion

        #region Messages

        /// <summary>
        /// {0}と{1}が一致しません。
        /// </summary>
        public const string MES_E0001 = "E0001";

        /// <summary>
        /// {{0}は必須です。
        /// </summary>
        public const string MES_E0002 = "E0002";

        /// <summary>
        /// {0}は半角英数字のみです。
        /// </summary>
        public const string MES_E0003 = "E0003";

        /// <summary>
        /// {0}は半角数字と"-"のみです。
        /// </summary>
        public const string MES_E0004 = "E0004";

        /// <summary>
        /// {1}は{0}より大きくなければいけません。
        /// </summary>
        public const string MES_E0005 = "E0005";

        /// <summary>
        /// {0}は削除されたコードです。
        /// </summary>
        public const string MES_E0006 = "E0006";

        /// <summary>
        /// {0}は、最小の長さが {2} で、最大の長さが {1} の文字列でなければなりません。
        /// </summary>
        public const string MES_E0007 = "E0007";

        /// <summary>
        /// 指定されたユーザー名またはパスワードが正しくありません。
        /// </summary>
        public const string MES_E0008 = "E0008";

        /// <summary>
        /// データは存在しません。
        /// </summary>
        public const string MES_E0009 = "E0009";

        /// <summary>
        /// {0}は数字と"."のみです。
        /// </summary>
        public const string MES_E0010 = "E0010";

        /// <summary>
        /// {0}は小数点以下の桁数が{1}以下でなければなりません。
        /// </summary>
        public const string MES_E0011 = "E0011";

        /// <summary>
        /// {0}は{1}以上、{2}以下の数字でなければなりません。
        /// </summary>
        public const string MES_E0012 = "E0012";

        /// <summary>
        /// {0}は半角数字でなければなりません。
        /// </summary>
        public const string MES_E0013 = "E0013";

        /// <summary>
        /// {0}は半角文字でなければなりません。
        /// </summary>
        public const string MES_E0014 = "E0014";

        /// <summary>
        /// {0}番目の在庫引当順序の項目が選ばれていません。
        /// </summary>
        public const string MES_E0015 = "E0015";

        /// <summary>
        /// {0}番目のソート順が選ばれていません。
        /// </summary>
        public const string MES_E0016 = "E0016";

        /// <summary>
        /// {0}はE-mailの形式でなければいけません。
        /// </summary>
        public const string MES_E0017 = "E0017";

        /// <summary>
        /// {0}はA～Zと"/"、"-"でなければなりません。
        /// </summary>
        public const string MES_E0018 = "E0018";

        /// <summary>
        /// {0}は同じ値を入力できません。
        /// </summary>
        public const string MES_E0019 = "E0019";

        /// <summary>
        /// 正しい値を入力してください。
        /// </summary>
        public const string MES_E0020 = "E0020";

        /// <summary>
        /// {0} は {1}～{2}の範囲で入力してください。
        /// </summary>
        public const string MES_E0021 = "E0021";

        /// <summary>
        /// 入力したロケーションCDはこの商品を入庫するロケーションではありません。
        /// </summary>
       public const string MES_E0022 = "E0022";

        /// <summary>
        /// {0}は半角数字と"-"でなければいけません。
        /// </summary>
         public const string MES_E0023 = "E0023";

        /// <summary>
        /// {0}は長さが {1} の文字列でなければなりません。
        /// {0} must be the string whose the length is {1}.
        /// </summary>
        public const string MES_E0024 = "E0024";

        /// <summary>
        /// 
        /// 
        /// </summary>
        public const string MES_E0025 = "E0025";

        /// <summary>
        /// {0}は半角英数字と"-"でなければなりません。
        /// {0} must be alphanumeric, symbol "-".
        /// </summary>
        public const string MES_E0026 = "E0026";

        /// <summary>
        /// {0}はデータベースに存在しません。
        /// </summary>
        public const string MES_M0001 = "M0001";

        /// <summary>
        /// {0}はデータベースに存在しています。
        /// </summary>
        public const string MES_M0002 = "M0002";

        /// <summary>
        /// このデータは他のユーザーが更新しました。再読み込み後に更新してください。
        /// </summary>
        public const string MES_M0003 = "M0003";

        /// <summary>
        /// {0}は整数でなければいけません。
        /// </summary>
        public const string MES_M0004 = "M0004";

        /// <summary>
        /// データを削除してよろしいですか？
        /// </summary>
        public const string MES_M0006 = "M0006";

        /// <summary>
        /// 削除に失敗しました。
        /// </summary>
        public const string MES_M0007 = "M0007";

        /// <summary>
        /// データを作成してよろしいですか？
        /// </summary>
        public const string MES_M0008 = "M0008";

        /// <summary>
        /// 作成に失敗しました。
        /// </summary>
        public const string MES_M0009 = "M0009";

        /// <summary>
        /// データを更新してよろしいですか？
        /// </summary>
        public const string MES_M0010 = "M0010";

        /// <summary>
        /// 更新に失敗しました。
        /// </summary>
        public const string MES_M0011 = "M0011";

        /// <summary>
        /// 
        /// </summary>
        public const string MES_M0012 = "M0012";

        /// <summary>
        /// このデータは使用されています。削除できません。
        /// </summary>
        public const string MES_M0013 = "M0013";

        /// <summary>
        /// データを選択してください。
        /// </summary>
        public const string MES_M0014 = "M0014";

        /// <summary>
        /// 重複する項目は設定できません。
        /// </summary>
        public const string MES_M0015 = "M0015";

        /// <summary>
        /// 現品票番号{0}は入庫できる状態ではありません。
        /// </summary>
        public const string MES_M0016 = "M0016";

        /// <summary>
        /// 選択した棚コードは入庫できる棚ではありません。
        /// </summary>
        public const string MES_M0017 = "M0017";

        /// <summary>
        /// 現品票を印刷します。サイズを選択してください。
        /// </summary>
        public const string MES_M0018 = "M0018";

        /// <summary>
        ///現品票は既に発行済みです。再度、現品票を発行する場合、サイズを選択してください。
        /// </summary>
        public const string MES_M0019 = "M0019";

        /// <summary>
        /// 印刷してもよろしいですか？
        /// </summary>
        public const string MES_M0020 = "M0020";

        /// <summary>
        /// 現品票は発行済みです。再度、印刷してよろしいですか？
        /// </summary>
        public const string MES_M0021 = "M0021";

        /// <summary>
        /// 入力された現品番号は入庫できる状態ではありません。
        /// </summary>
        public const string MES_M0022 = "M0022";

        /// <summary>
        /// {0}は使用されています。削除できません。
        /// </summary>
        public const string MES_M0023 = "M0023";

        /// <summary>
        /// 登録が完了しました。
        /// </summary>
        public const string MES_M0024 = "M0024";

        /// <summary>
        /// 
        /// </summary>
        public const string MES_M0025 = "M0025";

        /// <summary>
        /// 入庫しています。編集できません。
        /// </summary>
        public const string MES_M0026 = "M0026";

        /// <summary>
        /// 入庫しています。削除できません。
        /// </summary>
        public const string MES_M0027 = "M0027";

        /// <summary>
        /// Grid data must contain at least 1 row. M0028
        /// </summary>
        public const string MES_M0028 = "M0028";

        /// <summary>
        /// 入力されたロケーションは{0}に存在しません。
        /// The input location is not exist {0}.
        /// </summary>
        public const string MES_M0029 = "M0029";

        /// <summary>
        /// 入力された現品票番号は{0}に存在しません。
        /// The input tag number is not exist {0}.
        /// </summary>
        public const string MES_M0030 = "M0030";

        /// <summary>
        /// 入力された現品票番号は指定したロケーションに存在しません。
        /// Identification tag number you entered does not exist in the specified location.
        /// </summary>
        public const string MES_M0031 = "M0031";

        /// <summary>
        /// このロケーションの出庫が完了しました。
        /// Shipment of this location is now complete.
        /// </summary>
        public const string MES_M0032 = "M0032";

        /// <summary>
        /// 全ての在庫を出庫しました。出庫検品を終了します。
        /// Shipped all the stock. Finish the picking.
        /// </summary>
        public const string MES_M0033 = "M0033";

        /// <summary>
        /// このロケーションの商品が引き当てられているため変更できません。
        /// Can not edit because of picking.
        /// </summary>
        public const string MES_M0034 = "M0034";

        /// <summary>
        /// This {0} is already loaded. Please read of next the {0}.
        /// この{0}は既に読み込まれています。次の{0}を読み込んでください。
        /// </summary>
        public const string MES_M0035 = "M0035";

        /// <summary>
        /// 選択した行を削除してよろしいですか？
        /// </summary>
        public const string MES_M0036 = "M0036";

        /// <summary>
        /// この出荷指示は出庫検品が終了しています。編集できません。
        /// </summary>
       public const string MES_M0037 = "M0037";

        /// <summary>
        /// この出荷指示は出庫検品が終了しています。削除できません。
        /// </summary>
         public const string MES_M0038 = "M0038";

        /// <summary>
        /// この商品は1つ以上出庫検品されています。削除できません。
        /// </summary>
        public const string MES_M0039 = "M0039";

        /// <summary>
        /// 
        /// </summary>
        public const string MES_M0040 = "M0040";

        /// <summary>
        /// 全ての在庫を出荷しました。出荷検品を終了します。
        /// </summary>
        public const string MES_M0041 = "M0041";

        /// <summary>
        /// この商品は在庫として存在しません。
        /// </summary>
        public const string MES_M0042 = "M0042";

        /// <summary>
        /// 全ての明細行を削除しますがよろしいですか？
        /// </summary>
        public const string MES_M0043 = "M0043";

        /// <summary>
        /// 全ての出荷キャンセルが完了しました。
        /// </summary>
        public const string MES_M0044 = "M0044";

        /// <summary>
        /// この現品票番号は出荷していません。
        /// </summary>
        public const string MES_M0045 = "M0045";

        /// <summary>
        /// この在庫は出荷されています。入庫できません。
        /// </summary>
        public const string MES_M0046 = "M0046";

        /// <summary>
        /// 
        /// </summary>
        public const string MES_M0047 = "M0047";

        /// <summary>
        /// 
        /// </summary>
        public const string MES_M0048 = "M0048";

        /// <summary>
        /// この商品は入庫できません。
        /// </summary>
        public const string MES_M0049 = "M0049";

        /// <summary>
        /// この在庫は既に出庫されています。
        /// This tag no was issued.
        /// </summary>
        public const string MES_M0050 = "M0050";

        /// <summary>
        /// 在庫数が足りません。在庫数以下の数字を入力してください。
        /// </summary>
        public const string MES_M0051 = "M0051";

        /// <summary>
        /// この在庫は不良品です。出庫できません。
        /// </summary>
        public const string MES_M0052 = "M0052";
        				
        /// <summary>
        /// この在庫は入庫されていないため出庫できません。
        /// </summary>
        public const string MES_M0053 = "M0053";

        /// <summary>
        /// このロケーションは現在棚卸中です。入出庫禁止フラグは編集できません。
        /// Can not edit receipt and issue prohibition flag. Because this location taking.
        /// </summary>
        public const string MES_M0054 = "M0054";

        /// <summary>
        /// 
        /// These shipping indication which include product in this location not complete shipping. You can not taking.
        /// </summary>
        public const string MES_M0055 = "M0055";

        /// <summary>
        /// このロケーションは現在棚卸中です。再度棚卸を開始するにはキャンセルしてください。
        /// This location taking. If you want retaking please do cancel taking.
        /// </summary>
        public const string MES_M0056 = "M0056";

        /// <summary>
        /// 
        /// 
        /// </summary>
        public const string MES_M0057 = "M0057";

        /// <summary>
        /// 
        /// 
        /// </summary>
        public const string MES_M0058 = "M0058";

        /// <summary>
        /// 
        /// 
        /// </summary>
        public const string MES_M0059 = "M0059";

        /// <summary>
        /// 
        /// 
        /// </summary>
        public const string MES_M0060 = "M0060";

        /// <summary>
        /// 入力した出荷指示番号はこの出荷指示と異なります。
        /// </summary>
        public const string MES_M0061 = "M0061";

        /// <summary>
        /// {0}は在庫がありません。
        /// </summary>
        //public const string MES_M0062 = "M0062";

        /// <summary>
        /// 
        /// This location not complete goods receipt. You can not taking.
        /// </summary>
        public const string MES_M0063 = "M0063";

        /// <summary>
        /// {0}は棚卸できません。
        /// </summary>
        public const string MES_M0064 = "M0064";

        /// <summary>
        /// 移動元と移動先で同じロケーションを選択することはできません。
        /// </summary>
        public const string MES_M0065 = "M0065";

        /// <summary>
        /// 棚卸をキャンセルします。よろしいですか？
        /// </summary>
        public const string MES_M0066 = "M0066";

        /// <summary>
        /// 棚卸確定処理を始めます。よろしいですか？
        /// </summary>
        public const string MES_M0067 = "M0067";

        /// <summary>
        /// この処理は実行すると元に戻せません。よろしいですか？
        /// </summary>
        public const string MES_M0068 = "M0068";

        /// <summary>
        /// 棚卸を確定しますが、よろしいですか？
        /// </summary>
        public const string MES_M0069 = "M0069";

        /// <summary>
        /// 在庫一覧表を発行します。表示方法を選択してください。
        /// Please select view by for export stock list report.
        /// </summary>
        public const string MES_M0070 = "M0070";

        /// <summary>
        /// 入荷済、未入庫の現品があります。
        /// </summary>
        public const string MES_M0071 = "M0071";

        /// <summary>
        /// 出庫済、未出荷・未入庫の現品があります。
        /// </summary>
        public const string MES_M0072 = "M0072";

        /// <summary>
        /// 棚卸確定していないロケーションがあります。
        /// </summary>
        public const string MES_M0073 = "M0073";

        /// <summary>
        /// このユーザーは倉庫{0}にログインできません。
        /// </summary>
        public const string MES_M0074 = "M0074";

        /// <summary>
        /// 選択したロケーションコードは出庫できるロケーションではありません。
        /// </summary>
        public const string MES_M0075 = "M0075";

        /// <summary>
        /// {0}～{1}の範囲は3ヶ月以内にしてください。
        /// </summary>
        public const string MES_M0076 = "M0076";

        /// <summary>
        /// 良品在庫は破棄できません。不良在庫のみ破棄できます。
        /// You can not destroy the normal stock. Please select the defective tag no to destroy.
        /// </summary>
      //  public const string MES_M0077 = "M0077";

        /// <summary>
        /// この在庫は移動予定です。出庫できません。
        /// This tag no can not issue because of selected for moving.
        /// </summary>
        public const string MES_M0078 = "M0078";

        public const string MES_M0079 = "M0079";
        public const string MES_M0080 = "M0080";

        /// <summary>
        /// 移動指示引当中です。在庫状態は変更できません。
        /// </summary>
        public const string MES_M0081 = "M0081";
        public const string MES_M0082 = "M0082";

        /// <summary>
        /// This tag no is not defective, can not issue for scrap.
        /// </summary>
        public const string MES_M0083 = "M0083";

        /// <summary>
        /// Can not receipt because of not completed issue.
        /// </summary>
        public const string MES_M0084 = "M0084";

        /// <summary>
        /// 棚卸を登録してよろしいですか？
        /// Do you want to register taking?
        /// </summary>
        public const string MES_M0085 = "M0085";

        /// <summary>
        /// 出荷検品済の在庫です。棚卸検品はできません。
        /// This tag no was outbound deliverd. Can not taking.
        /// </summary>
        public const string MES_M0086 = "M0086";

        #endregion        

        #region pattern

        public const string PATTERN_NUMERIC = "^[0-9]*$";
        public const string PATTERN_ANPHA_NUMERIC = "^[a-zA-Z0-9]*$";
        public const string PATTERN_NUMERIC_SUBTRACT = "^[0-9\\-]*$";
        public const string PATTERN_UPPER_ANPHA_NUMERIC = "^[A-Z0-9]*$";
        public const string PATTERN_ANPHA_NUMERIC_FLASH = "^[a-zA-Z0-9\\-\\/]*$";
        public const string PATTERN_UPPER_ANPHA_NUMERIC_FLASH = "^[A-Z0-9\\-\\/]*$";
        public const string PATTERN_UPPER_ANPHA_NUMERIC_SUBTRACT = "^[A-Z0-9\\-]*$";
        public const string PATTERN_TEL = "^[0-9() \\+\\-]*$";
        public const string PATTERN_HAFL_WIDTH = "^[a-zA-Z0-9｡-ﾟ\\p{P}\\p{S}]*$";
        public const string PATTERN_EMAIL = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";

        #endregion

        #region Format
        public const string NUMBER_FORMAT_INT = "{0:#,##0}";
        public const string NUMBER_FORMAT_DEC_2 = "{0:#,##0.00}";

        public const string FMT_DATETIME = "yyyyMMddHHmmss";
        public const string FMT_DATETIME_SHOW = "yyyy/MM/dd HH:mm:ss";

        public const string FMT_DATETIME_REPORT_SHOW = "dd/MM/yyyy HH:mm";

        public const string FMT_DMY = "ddMMyyyy";
        public const string FMT_YMDHMM = "yyMMddHHmm";
        public const string FMT_YMD = "yyyyMMdd";
        public const string FMT_DATE = "dd/MM/yyyy";
        public const string FMR_DATE_YMD = "{0:yyyy/MM/dd}";
        public const string FMT_DATE_DPL = "{0:dd/MM/yyyy}";
        public const string FMT_INTEGER = "#,##0";
        public const string FMT_DECIMAL = "#,##0.00";
        public const string FMT_INTEGER_DPL = "{0:#,##0}";
        public const string FMT_DECIMAL_FULL = "{0:#,##0.#############################}";

        public const string MIN_DATE_TEST = "01/01/2013";
        public const string MAX_DATE_TEST = "31/12/2015";

        #endregion

        #region system

        public const string CURRENT_LANGUAGE = "Ses_CurrentLanguage";
        public const string CURRENT_WAREHOUSE_CD = "Ses_CurrentWarehouseCD";
        public const int MAXROW = 9999;
        public const int DEFAULT_ROW_COUNT = 10;

        #endregion

        #region Class Name

        /// <summary>
        /// Class Required Name
        /// </summary>
        public const string CLASS_REQUIRED = "required";

        /// <summary>
        /// Class Hidden
        /// </summary>
        public const string CLASS_HIDDEN = "hidden";

        /// <summary>
        /// Class Color grid row Normal
        /// </summary>
        public const string CLASS_GRID_ROW_NORMAL = "normal";

        /// <summary>
        /// Class Color grid row surplus
        /// </summary>
        public const string CLASS_GRID_ROW_SURPLUS = "surplus";

        #endregion

        #region Symbol

        public const string SYB_COLON = ":";

        #endregion

        #region Field Values 

        #region Reserve Status

        /// <summary>
        /// 00: 未引当
        /// </summary>
        public const string RESERVE_STATUS_NOT_RESERVE = "00";

        /// <summary>
        /// 10: 引当済
        /// </summary>
        public const string RESERVE_STATUS_PROVISION_ALREADY = "10";

        /// <summary>
        /// 20: 引落済
        /// </summary>
        public const string RESERVE_STATUS_WITHDRAWAL_ALREADY = "20";

        /// <summary>
        /// 99: 取扱不可
        /// </summary>
        public const string RESERVE_STATUS_NOT_HANDLING = "99";  

        #endregion

        #region Stock Status

        /// <summary>
        /// 10: 入荷（良品）
        /// </summary>
        public const string STOCK_STATUS_ARRIVAL_NON_DEFECTIVE = "10";

        /// <summary>
        /// 20: 入庫（良品在庫）
        /// </summary>
        public const string STOCK_STATUS_RECEIPT_NON_DEFECTIVE = "20";

        /// <summary>
        /// 25: 入庫（不良品在庫）
        /// </summary>
        public const string STOCK_STATUS_RECEIPT_DEFECTIVE = "25";

        /// <summary>
        /// 40: 出庫
        /// </summary>
        public const string STOCK_STATUS_ISSUE = "40";

        /// <summary>
        /// 45: 出庫（庫内移動）
        /// </summary>
        public const string STOCK_STATUS_ISSUE_INSIDE_MOVE = "45";

        /// <summary>
        /// 46: 出庫（棚卸）
        /// </summary>
        public const string STOCK_STATUS_ISSUE_INVENTORY = "46";

        /// <summary>
        /// 47:「移動出庫(不良品)」
        /// </summary>
        public const string STOCK_STATUS_ISSUE_DEFECTIVE = "47";

        /// <summary>
        /// 48:「破棄出庫」
        /// </summary>
        public const string STOCK_STATUS_ISSUE_SCRAP = "48";

        /// <summary>
        /// 50: 出荷
        /// </summary>
        public const string STOCK_STATUS_DELIVERY = "50";

        /// <summary>
        /// 57:「出荷(不良品)」
        /// </summary>
        public const string STOCK_STATUS_DELIVERY_DEFECTIVE = "57";

        /// <summary>
        /// 58:「破棄出荷」
        /// </summary>
        public const string STOCK_STATUS_DELIVERY_SCRAP = "58";

        #endregion

        #region Taking Status

        /// <summary>
        /// 00: 差異なし
        /// </summary>
        public const string TAKE_STATUS_NONE = "00";

        /// <summary>
        /// 26: 棚卸入庫
        /// </summary>
        public const string TAKE_STATUS_RECEIPTS = "26";

        /// <summary>
        /// 46: 棚卸出庫
        /// </summary>
        public const string TAKE_STATUS_ISSUE = "46";  

        #endregion

        #region Balance Status

        /// <summary>
        /// 10: 入荷
        /// </summary>
        public const string BALANCE_STATUS_ARRIVAL = "10";

        /// <summary>
        /// 12: 返品入荷
        /// </summary>
        public const string BALANCE_STATUS_RETURN_ARRIVAL = "12";

        /// <summary>
        /// 14: 移動入荷
        /// </summary>
        public const string BALANCE_STATUS_MOVES_ARRIVAL = "14";

        /// <summary>
        /// 16: (for report only)
        /// </summary>
        public const string BALANCE_STATUS_TAKE_ARRIVAL = "16";

        /// <summary>
        /// 18: (for report only)
        /// </summary>
        public const string BALANCE_STATUS_SCRAP_ARRIVAL = "18";

        /// <summary>
        /// 20: 入庫
        /// </summary>
        public const string BALANCE_STATUS_RECEIPT = "20";

        /// <summary>
        /// 22: 返品入庫 
        /// </summary>
        public const string BALANCE_STATUS_RETURN_RECEIPT = "22";

        /// <summary>
        /// 24: 移動入庫
        /// </summary>
        public const string BALANCE_STATUS_MOVE_RECEIPT = "24";

        /// <summary>
        /// 26: 棚卸入庫 
        /// </summary>
        public const string BALANCE_STATUS_INVENTORY_RECEIPT = "26";

        /// <summary>
        /// 28: (for report only)
        /// </summary>
        public const string BALANCE_STATUS_SCRAP_RECEIPT = "28";

        /// <summary>
        /// 40: 出庫
        /// </summary>
        public const string BALANCE_STATUS_GOODS_ISSUE = "40";

        /// <summary>
        /// 42: 返品出庫
        /// </summary>
        public const string BALANCE_STATUS_RETURN_ISSUE = "42";

        /// <summary>
        /// 44: 移動出庫
        /// </summary>
        public const string BALANCE_STATUS_MOVE_ISSUE = "44";

        /// <summary>
        /// 46: 棚卸出庫
        /// </summary>
        public const string BALANCE_STATUS_INVENTORY_ISSUE = "46";

        /// <summary>
        /// 48: 破棄出庫
        /// </summary>
        public const string BALANCE_STATUS_DISCARD_ISSUE = "48";

        /// <summary>
        /// 50: 出荷
        /// </summary>
        public const string BALANCE_STATUS_SHIPPING = "50";

        /// <summary>
        /// 52: 返品出荷
        /// </summary>
        public const string BALANCE_STATUS_RETURN_SHIPPING = "52";

        /// <summary>
        /// 54: 移動出荷
        /// </summary>
        public const string BALANCE_STATUS_MOVE_SHIPPING = "54";

        /// <summary>
        /// 56: (for report only)
        /// </summary>
        public const string BALANCE_STATUS_TAKE_SHIPPING = "56";

        /// <summary>
        /// 58: 破棄出荷
        /// </summary>
        public const string BALANCE_STATUS_DISCARD_SHIPPING = "58";

        #endregion

        #region Stock Allowance

        /// <summary>
        /// 01: 入荷日
        /// </summary>
        public const string STOCKALLOWANCE_ARRIVALDATE = "01";

        /// <summary>
        /// 02: LOT1
        /// </summary>
        public const string STOCKALLOWANCE_LOT1 = "02";

        /// <summary>
        /// 03: LOT2
        /// </summary>
        public const string STOCKALLOWANCE_LOT2 = "03";

        /// <summary>
        /// 04: LOT3
        /// </summary>
        public const string STOCKALLOWANCE_LOT3 = "04";

        /// <summary>
        /// 05: 入庫日
        /// </summary>
        public const string STOCKALLOWANCE_STOREDDATE = "05";   

        #endregion

        #region Company

        /// <summary>
        /// Default company code
        /// </summary>
        public const string DEFAULT_COMPANY_CD = "000001";

        #endregion

        #region Move Kind

        public const string MKIND_KINDCD_MOVE_KIND_WAREHOUSE = "01";
        public const string MKIND_KINDCD_MOVE_KIND_LOCATION = "02";
        public const string MKIND_KINDCD_MOVE_KIND_SCRAP = "03";

        #endregion

        #region Outbound Kind

        public const string MKIND_KINDCD_OUT_KIND_OUTBOUND = "00";
        public const string MKIND_KINDCD_OUT_KIND_WAREHOUSE = "01";
        public const string MKIND_KINDCD_OUT_KIND_SCRAP = "02";

        #endregion

        #endregion

        #region MENU URL

        public const string MENU_MASTER = "Master";
        public const string MENU_MASTER_URL = "/Menu/Master/";

        public const string MENU_PROCESS = "Process";
        public const string MENU_PROCESS_URL = "/Menu/Menu/";

        public const string MENU_REPORT = "Report";
        public const string MENU_REPORT_URL = "/Menu/Report/";

        #endregion

        #region Help URL

        #region Main

        /// <summary>
        /// Help Url of Goods Issue Inspection
        /// </summary>
        public const string HELP_URL_MAIN_GOODS_ISSUE_INSPEC = "";

        /// <summary>
        /// Help Url of Goods Receipt Inspection
        /// </summary>
        public const string HELP_URL_MAIN_GOODS_RECEIPT = "";

        /// <summary>
        /// Help Url of Inbound Delivery
        /// </summary>
        public const string HELP_URL_MAIN_INBOUND_DELIVERY = "";

        /// <summary>
        /// Help Url of Move Goods Issue Inspection
        /// </summary>
        public const string HELP_URL_MAIN_MOVE_GOODS_ISSUE = "";

        /// <summary>
        /// Help Url of Move Indication
        /// </summary>
        public const string HELP_URL_MAIN_MOVE_INDICATION = "";

        /// <summary>
        /// Help Url of Move Outbound Delivery Inspection
        /// </summary>
        public const string HELP_URL_MAIN_MOVE_OUT_DELI = "";

        /// <summary>
        /// Help Url of Outbound Delivery
        /// </summary>
        public const string HELP_URL_MAIN_OUT_DELI = "";
        
        /// <summary>
        /// Help Url of Outbound Delivery Indication
        /// </summary>
        public const string HELP_URL_MAIN_OUT_DELI_INDI = "";

        /// <summary>
        /// Help Url of Outbound Delivery Inquiry
        /// </summary>
        public const string HELP_URL_MAIN_OUT_DELI_INQUIRY = "";

        /// <summary>
        /// Help Url of Stock Inquiry
        /// </summary>
        public const string HELP_URL_MAIN_STOCK_INQUIRY = "";

        /// <summary>
        /// Help Url Stock Take Inspection
        /// </summary>
        public const string HELP_URL_MAIN_STOCK_TAKE_INSPEC = "";

        /// <summary>
        /// Help Url of Stock Take Proclamation
        /// </summary>
        public const string HELP_URL_MAIN_STOCK_TAKE_PROC = "";

        #endregion

        #region Master

        /// <summary>
        /// Help Url of Category Master
        /// </summary>
        public const string HELP_URL_MASTER_CATEGORY_LIST = "/manual/{0}/master.html#category-list";
        public const string HELP_URL_MASTER_CATEGORY_NEW = "/manual/{0}/master.html#category-new";
        public const string HELP_URL_MASTER_CATEGORY_VIEW = "/manual/{0}/master.html#category-view";

        /// <summary>
        /// Help Url of Company Master
        /// </summary>
        public const string HELP_URL_MASTER_COMPANY_LIST = "";
        public const string HELP_URL_MASTER_COMPANY_NEW = "";
        public const string HELP_URL_MASTER_COMPANY_VIEW = "";

        /// <summary>
        /// Help Url of Customer Master
        /// </summary>
        public const string HELP_URL_MASTER_CUSTOMER_LIST = "/manual/{0}/master.html#customer-list";
        public const string HELP_URL_MASTER_CUSTOMER_NEW = "/manual/{0}/master.html#customer-new";
        public const string HELP_URL_MASTER_CUSTOMER_VIEW = "/manual/{0}/master.html#customer-view";

        /// <summary>
        /// Help Url of Group Master
        /// </summary>
        public const string HEPL_URL_MASTER_GROUP_LIST = "";
        public const string HEPL_URL_MASTER_GROUP_NEW = "";
        public const string HEPL_URL_MASTER_GROUP_VIEW = "";

        /// <summary>
        /// Help Url of Kind Master
        /// </summary>
        public const string HELP_URL_MASTER_KIND_LIST = "";
        public const string HELP_URL_MASTER_KIND_NEW = "";
        public const string HELP_URL_MASTER_KIND_VIEW = "";

        /// <summary>
        /// Help Url of Location Master
        /// </summary>
        public const string HELP_URL_MASTER_LOCATION_LIST = "";
        public const string HELP_URL_MASTER_LOCATION_NEW = "";
        public const string HELP_URL_MASTER_LOCATION_VIEW = "";

        /// <summary>
        /// Help url of Product master
        /// </summary>
        public const string HELP_URL_MASTER_PRODUCT_LIST = "/manual/{0}/master.html#product-list";
        public const string HELP_URL_MASTER_PRODUCT_NEW = "/manual/{0}/master.html#product-new";
        public const string HELP_URL_MASTER_PRODUCT_VIEW = "/manual/{0}/master.html#product-view";

        /// <summary>
        /// Help Url of User Master
        /// </summary>
        public const string HELP_URL_MASTER_USER_LIST = "";
        public const string HELP_URL_MASTER_USER_NEW = "";
        public const string HELP_URL_MASTER_USER_VIEW = "";

        /// <summary>
        /// Help Url of Warehouse Master
        /// </summary>
        public const string HELP_URL_MASTER_WAREHOUSE_LIST = "";
        public const string HELP_URL_MASTER_WAREHOUSE_NEW = "";
        public const string HELP_URL_MASTER_WAREHOUSE_VIEW = "";

        #endregion

        #region Report

        /// <summary>
        /// Help Url of Balace in store report
        /// </summary>
        public const string HELP_URL_REPORT_BALANCE_IN_STORE = "";

        /// <summary>
        /// Help Url of Outbound Delivered report
        /// </summary>
        public const string HELP_URL_REPORT_OUTBOUND_DELIVERED = "";

        #endregion

        #endregion
    }
}
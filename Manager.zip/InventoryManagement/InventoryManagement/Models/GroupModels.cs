﻿using System.Collections.Generic;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class GroupDetailModels : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.MGROUP_GROUP_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string GroupCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MGROUP_GROUP_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string GroupName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0185)]
        public string ViewCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0186)]
        public string ViewName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string PreGroupCD { get; set; }

        public int ColCount
        {
            get
            {
                return this.TitleGrid.Count;
            }
        }

        public bool IsExistsOtherTB { get; set; }

        //Title of Grid
        public List<MKind_D> TitleGrid { get; set; }

        //Detail Master
         public List<GroupDetailGrid> DetailMaster { get; set; }

        //Detail Process
        public List<GroupDetailGrid> DetailProcess { get; set; }

        public GroupDetailModels()
        {
            DetailMaster = new List<GroupDetailGrid>();
            
            DetailProcess = new List<GroupDetailGrid>();
            TitleGrid = new List<MKind_D>();
        }

        /// <summary>
        /// Add Sequence Number for Detail row
        /// </summary>
        public void AddSeqForDetail()
        {
            foreach (var item in DetailMaster)
            {
                item.SeqNum = SeqNum;
            }
            foreach (var item2 in DetailProcess)
            {
                item2.SeqNum = SeqNum;
            }
        }

        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }

    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class GroupDetailGrid : BaseModel
    {
        public int NumRow { get; set; }

        //Master Grid or Process Grid
        public string GridID { get; set; }
                
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string GroupCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0185)]       
        public string ViewCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0186)]
        public string ViewName { get; set; }

        public bool Insert { get; set; }
        public bool Update { get; set; }
        public bool Delete { get; set; }
        public bool View { get; set; }
        public bool Export { get; set; }
        public bool IncludeDeleted { get; set; }
        public bool Picking { get; set; }
        public bool Cancel { get; set; }
    }

    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class GroupHeaderList : BaseList
    {
        [iStringLength(Constant.MGROUP_GROUP_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string txt_GroupCD { get; set; }

        [iStringLength(Constant.MGROUP_GROUP_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string txt_GroupName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool chb_IncludeDeleteData { get; set; }        
    }

    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class GroupHeaderResult
    {        
        [iDisplayName(Name = Constant.LBL_L0181)]
        public string GroupCD { get; set; }
                
        [iDisplayName(Name = Constant.LBL_L0182)]
        public string GroupName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }
        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Author : ISV-TRUC
    /// </summary>
    public class GroupCSV {
        
        public string GroupCD { get; set; }
        public string GroupName { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
        public string ViewCD { get; set; }
        public string RoleCD { get; set; }        
        public bool EnableFlag { get; set; }
    }
}
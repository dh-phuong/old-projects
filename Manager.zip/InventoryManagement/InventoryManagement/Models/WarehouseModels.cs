﻿using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Warehouse Models
    /// Author: ISV-TRUC
    /// </summary>
    public class WarehouseModels : BaseModel
    {
        [iRequired]
        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW, Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0059)]
        public string WarehouseName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }
        public string PreWarehouseCD { get; set; }
        public string CreateDate { get; set; }
        public string CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUID { get; set; }

        public bool IsExistsInShelf { get; set; }
    }

    /// <summary>
    /// Warehouse List Model
    /// Author: ISV-TRUC
    /// </summary>
    public class WarehouseList : BaseList
    {
        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string txt_WarehouseCD { get; set; }

        [iStringLength(Constant.MWAREHOUSE_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0059)]
        public string txt_WarehouseName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool chk_IncludeDeleteData { get; set; }
    }

    /// <summary>
    /// Warehouse Results
    /// Author: ISV-TRUC
    /// </summary>
    public class WarehouseResults
    {
        [iDisplayName(Name = Constant.LBL_L0058)]
        public string WarehouseCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0059)]
        public string WarehouseName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Warehouse CSV Models
    /// Author: ISV-TRUC
    /// </summary>
    public class WarehouseCSV
    {
        public string WarehouseCD { get; set; }
        public string WarehouseName { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }

    /// <summary>
    /// Warehouse Dropdown list model
    /// Author: ISV-Vinh
    /// </summary>
    public class WarehouseDropDown
    {
        public string WarehouseCD { get; set; }
        public string WarehouseName { get; set; }
    }
}
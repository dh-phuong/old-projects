﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Outbound Delivered Model
    /// Author : ISV-LOC
    /// </summary>
    public class OutboundDeliveredModels : BaseModel
    {

        [iDisplayName(Name = Constant.LBL_L0300)]
        public string ddl_Kind { get; set; }

        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0153)]
        [iCompareDateTAttribute("shr_ShipDateTo", CompareType.LessThanOrEqual, Constant.LBL_L0246, Constant.LBL_L0247)]
        public DateControl shr_ShipDateFrom { get; set; }

        [iRequired]
        [iDisplayName(Name = Constant.LBL_L0154)]
        public DateControl shr_ShipDateTo { get; set; }

        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txt_ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txt_ProductName { get; set; }

        #region Destination is Customer

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0311)]
        public string txt_CustomerCDFrom { get; set; }

        public string txt_CustomerNameFrom { get; set; }

        [iStringLength(Constant.MCUSTOMER_CD_MAX)]
        [iPatternAttribute(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0312)]
        public string txt_CustomerCDTo { get; set; }

        public string txt_CustomerNameTo { get; set; }

        #endregion

        #region Destionation is Warehouse

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW, Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0311)]
        public string txt_WarehouseCDFrom { get; set; }

        public string txt_WarehouseNameFrom { get; set; }

        [iStringLength(Constant.MWAREHOUSE_WAREHOUSECD_SHOW, Constant.MWAREHOUSE_WAREHOUSECD_SHOW)]
        [iPatternAttribute(PatternType.Numeric)]
        [iDisplayName(Name = Constant.LBL_L0312)]
        public string txt_WarehouseCDTo { get; set; }

        public string txt_WarehouseNameTo { get; set; }

        #endregion

        public bool IsFromMenu { get; set; }
        public bool CheckProduct { get; set; }
        public bool CheckDestination { get; set; }
       
        //Default date
        public string Hid_DefaultDateFrom { get; set; }
        public string Hid_DefaultDateTo { get; set; }
        
        public OutboundDeliveredModels()
        {
            IsFromMenu = true;
            CheckProduct = true;
            CheckDestination = false;

            Hid_DefaultDateFrom = DateTime.Now.AddMonths(-3).AddDays(1).ToString(Constant.FMT_YMD);
            Hid_DefaultDateTo = DateTime.Now.ToString(Constant.FMT_YMD);

            shr_ShipDateFrom = new DateControl(Hid_DefaultDateFrom);
            shr_ShipDateTo = new DateControl(Hid_DefaultDateTo);
        }
    }

    #region "Report"

    /// <summary>
    /// Outbound Delivered Report
    /// Author : ISV-LOC
    /// </summary>
    public class OutboundDeliveredReport : BaseReport<OutboundDeliveredReport>
    {
        public string DestinationCD { get; set; }//出荷先CD
        public string DestinationName { get; set; }//出荷先名
        
        public string ProductCD { get; set; }//商品CD
        public string ProductName { get; set; }//商品名
        
        public string TagInfo { get; set; }//現品票番号
        public string Lot1 { get; set; }//LOT1
        public string Lot2 { get; set; }//LOT2
        public string Lot3 { get; set; }//LOT3
        public string OutboundKind { get; set; }//出荷区分

        public string ShipDate { get; set; }//出荷日
        public string ShipDateSort { get; set; }//出荷日
        public string ShipNo { get; set; }//出荷指示番号
        public string DeliveryNumber { get; set; }//便名
        
        public OutboundDeliveredReport(System.Data.SqlClient.SqlDataReader dr)
        {
            // TODO: Complete member initialization
            this.DestinationCD = Convert.ToString(dr["DestinationCD"]);
            this.DestinationName = Convert.ToString(dr["DestinationName"]);
            this.ProductCD = Convert.ToString(dr["ProductCD"]);
            this.ProductName = Convert.ToString(dr["ProductName"]);
            this.TagInfo = Convert.ToString(dr["TagInfo"]);
            this.Lot1 = Convert.ToString(dr["Lot1"]);
            this.Lot2 = Convert.ToString(dr["Lot2"]);
            this.Lot3 = Convert.ToString(dr["Lot3"]);
            this.ShipNo = Convert.ToString(dr["ShipNo"]);
            this.ShipDate = Convert.ToString(dr["ShipDate"]);
            this.ShipDateSort = Convert.ToString(dr["ShipDateSort"]);
            this.DeliveryNumber = Convert.ToString(dr["DeliveryNumber"]);
            this.OutboundKind = Convert.ToString(dr["OutboundKind"]);
        }

        public OutboundDeliveredReport()
        {
            // TODO: Complete member initialization
        }
    }
   
    #endregion
}
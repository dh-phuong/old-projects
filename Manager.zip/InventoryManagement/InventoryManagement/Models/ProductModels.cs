﻿using InventoryManagement.Validation;
using InventoryManagement.Common;

namespace InventoryManagement.Models
{
    /// <summary>
    /// Product Models
    /// Author: ISV-Nho
    /// </summary>
    public class ProductModels : BaseModel
    {
        [iRequired]
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iRequired]
        [iStringLength(Constant.MPRODUCT_PRODUCT_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iRequired]
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string CategoryCD { get; set; }
        
        [iDisplayName(Name = Constant.LBL_L0205)]
        public string CategoryNm { get; set; }

        [iRequired]
        [iDecimal(Constant.MPRODUCT_QUANTITY_PER_UNIT_PRECISION, Constant.MPRODUCT_QUANTITY_PER_UNIT_SCALE, Constant.MPRODUCT_QUANTITY_PER_UNIT_MIN, Constant.MPRODUCT_QUANTITY_PER_UNIT_MAX)]
        [iDisplayName(Name = Constant.LBL_L0022)]
        public string QuantityPerUnit { get; set; }

        [iRequired]
        [iDecimal(Constant.MPRODUCT_COST_PRECISION, Constant.MPRODUCT_COST_SCALE, Constant.MPRODUCT_COST_MIN, Constant.MPRODUCT_COST_MAX)]
        [iDisplayName(Name = Constant.LBL_L0021)]
        public string Cost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        public string TotalCost { get; set; }

        public int ID { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteFlag { get; set; }

        public string CreateDate { get; set; }
        public int CreateUID { get; set; }
        public string UpdateDate { get; set; }
        public int UpdateUID { get; set; }

        public string PreProductCD { get; set; }
        public bool IsExistsOrtherTB { get; set; }
    }

    /// <summary>
    /// Product List
    /// Author: ISV-Nho
    /// </summary>
    public class ProductList : BaseList
    {
        [iPatternAttribute(PatternType.UpperAlphaNumericSubtract)]
        [iStringLength(Constant.MPRODUCT_PRODUCT_CD_MAX)]
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string txtProductCD { get; set; }

        [iStringLength(Constant.MPRODUCT_PRODUCT_NAME_MAX)]
        [iDisplayName(Name = Constant.LBL_L0019)]
        public string txtProductName { get; set; }
        
        [iStringLength(Constant.MCATEGORY_CD_MAX)]
        [iPattern(PatternType.UpperAlphaNumeric)]
        [iDisplayName(Name = Constant.LBL_L0204)]
        public string txtCategoryCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0205)]
        public string txtCategoryNm { get; set; }

        [iDecimal(Constant.MPRODUCT_COST_PRECISION, Constant.MPRODUCT_COST_SCALE, Constant.MPRODUCT_COST_MIN, Constant.MPRODUCT_COST_MAX)]
        [iDisplayName(Name = Constant.LBL_L0069)]
        [iCompareNumber("txtCostTo",CompareType.LessThanOrEqual)]
        public string txtCostFrom { get; set; }

        [iDecimal(Constant.MPRODUCT_COST_PRECISION, Constant.MPRODUCT_COST_SCALE, Constant.MPRODUCT_COST_MIN, Constant.MPRODUCT_COST_MAX)]
        [iDisplayName(Name = Constant.LBL_L0070)]
        public string txtCostTo { get; set; }

        [iDisplayName(Name = Constant.LBL_L0067)]
        public bool IncludeDeleteData { get; set; }
    }

    /// <summary>
    /// Product Result
    /// Author: ISV-Nho
    /// </summary>
    public class ProductResult
    {
        [iDisplayName(Name = Constant.LBL_L0018)]
        public string ProductCD { get; set; }

        [iDisplayName(Name = Constant.LBL_L0019)]
        public string ProductName { get; set; }

        [iDisplayName(Name = Constant.LBL_L0205)]
        public string CategoryNm { get; set; }

        [iDisplayName(Name = Constant.LBL_L0022)]
        public decimal QuantityPerUnit { get; set; }

        [iDisplayName(Name = Constant.LBL_L0021)]
        public decimal Cost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0083)]
        public decimal TotalCost { get; set; }

        [iDisplayName(Name = Constant.LBL_L0066)]
        public bool DeleteData { get; set; }

        public string UpdateDate { get; set; }
    }

    /// <summary>
    /// Product List For Csv
    /// Author: ISV-Nho
    /// </summary>
    public class ProductListCsv
    { 
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string CategoryCD { get; set; }
        public decimal Cost { get; set; }
        public decimal QuantityPerUnit { get; set; }
        public bool DeleteFlag { get; set; }
        public string CreateDate { get; set; }
        public string CreateUCD { get; set; }
        public string UpdateDate { get; set; }
        public string UpdateUCD { get; set; }
    }
}
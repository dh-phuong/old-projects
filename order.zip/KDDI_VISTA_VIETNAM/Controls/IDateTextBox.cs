﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Utilities;

namespace OMS.Controls
{
    /// <summary>
    /// Input date TextBox
    /// -------------------------
    /// Author : ISV-PHUONG
    /// Date   : 2014/07/24
    /// Ver    : 0.0.0.1
    /// -------------------------
    /// </summary>
    public class IDateTextBox : ITextBox
    {
        #region Constructor
        public IDateTextBox()
            : base()
        {
            this.InitProperties();
            this.InitDefaultStyle();
        }

        #endregion

        #region Enum
        public bool TimeEnable
        {
            get
            {
                return this.GetValueViewState<bool>("TimeEnable");
            }
            set
            {
                base.ViewState[ViewStateKey("TimeEnable")] = value;
            }
        }

        #endregion

        new public DateTime? Value
        {
            get
            {
                if (base.IsEmpty)
                {
                    return null;
                }
                try
                {
                    var fmt = this.TimeEnable ? Constants.FMT_DATE_TIME : Constants.FMT_DATE;
                    return OMS.Utilities.CommonUtil.ParseDate(base.Value, fmt);
                }
                catch
                {
                    return null;
                }
            }
            set
            {
                if (value != null)
                {
                    var fmt = this.TimeEnable ? Constants.FMT_DATE_TIME : Constants.FMT_DATE;
                    this.Text = value.Value.ToString(fmt);
                }
                else
                {
                    this.Text = string.Empty;
                }

            }
        }

        /// <summary>
        /// Css Class
        /// </summary>
        public override string CssClass
        {
            get
            {
                return base.CssClass;
            }
            set
            {
                base.CssClass = value;
                base.CssClass += " input-date disable-ime";
            }
        }

        #region Override

        protected override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            var max = 10;
            if (this.TimeEnable)
            {
                max += 9;
            }
            this.MaxLength = max;

            //var dateType = string.Format("{0}", (int)this.DateType);
            //this.Attributes.Add("date-type", dateType);
            this.Attributes.Add("time-enable", this.TimeEnable.ToString());

            base.Render(writer);
        }

        #endregion

        #region Method
        /// <summary>
        /// Khởi tạo giá trị mặc định cho các property
        /// </summary>
        private void InitProperties()
        {
            var max = 10;
            if (this.TimeEnable)
            {
                max += 9;
            }
            this.MaxLength = max;
        }

        /// <summary>
        /// constructor default value
        /// </summary>
        private void InitDefaultStyle()
        {
            this.Attributes.Add("Class", "input-date disable-ime");

        }
        #endregion


    }
}

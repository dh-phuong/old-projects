﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace OMS.Reports.PDF
{
    public class BaseReport : System.Web.UI.Page
    {
        #region Constant
        protected DateTime DATE_TIME_DEFAULT = new DateTime(1900, 1, 1);
        #endregion

        #region Get datsource

        /// <summary>
        /// get info company
        /// </summary>
        /// <returns></returns>
        protected M_Company GetCompany()
        {
            using (DB db = new DB())
            {
                CompanyService companySer = new CompanyService(db);

                //Get Company
                return companySer.GetData();
            }
        }

        /// <summary>
        /// GetGroupUserByID
        /// </summary>
        /// <param name="groupID">groupID</param>
        /// <returns>M_GroupUser_H</returns>
        protected M_GroupUser_H GetGroupUserByID(int groupID)
        {
            using (DB db = new DB())
            {
                GroupUserService groupUserSer = new GroupUserService(db);
                return groupUserSer.GetByGroupID(groupID);
            }
        }

        /// <summary>
        /// GetUserByUserCD
        /// </summary>
        /// <param name="userCd">userCd</param>
        /// <returns>M_User</returns>
        protected M_User GetUserByUserCD(string userCd)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCd);
            }
        }


        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <returns></returns>
        protected M_Customer GetCustomerByCD(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService cusSer = new CustomerService(db);
                //Get Customer
                return cusSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// GetCurrencyByIDAndDate
        /// </summary>
        /// <param name="id">id</param>
        /// <param name="baseDate">baseDate</param>
        /// <returns>M_Currency_H</returns>
        protected M_Currency_H GetCurrencyByIDAndDate(int id, DateTime baseDate)
        {
            using (DB db = new DB())
            {
                Currency_HService currencyHService = new Currency_HService(db);
                return currencyHService.GetByIDAndDate(id, baseDate);
            }
        }

        /// <summary>
        /// Get Conditions
        /// </summary>
        /// <param name="id">Header ID</param>
        /// <returns></returns>
        protected string GetQuotationC(int id)
        {
            using (DB db = new DB())
            {
                Quotation_CService quotationCSer = new Quotation_CService(db);

                //Get Conditions
                return quotationCSer.GetByPK(id).Conditions;
            }
        }

        /// <summary>
        /// Get PaymentMethod
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        protected string GetConfigName(string configCd, int value1, short methodVat)
        {
            using (DB db = new DB())
            {
                Config_DService DConfig = new Config_DService(db);
                List<M_Config_D> items = DConfig.GetListByConfigCd(configCd).ToList();
                //----------- ISV-Giam 2015/01/20 ------------
                if (methodVat.Equals(short.Parse(M_Config_D.METHOD_VAT_EACH)))
                {
                    return items.Where(x => x.Value1 == value1).Single().Value2.Replace("/", "/\n");
                }
                return items.Where(x => x.Value1 == value1).Single().Value2;
                //--------------------------------------------
            }
        }

        #endregion

        #region Get display report

        #region Header page

        /// <summary>
        /// get path logo 1
        /// </summary>
        /// <returns></returns>
        protected string GetPathLogo1()
        {
            using (DB db = new DB())
            {
                SettingService settingSer = new SettingService(db);
                //var extension = Path.GetExtension(settingSer.GetData().Logo1);
                var logo = settingSer.GetData().Logo1;

                //Get Setting
                return new Uri(Server.MapPath("~/Logo/" + logo)).AbsoluteUri;
            }
        }

        /// <summary>
        /// get path logo
        /// </summary>
        /// <returns></returns>
        protected string GetPathLogo()
        {
            using (DB db = new DB())
            {
                SettingService settingSer = new SettingService(db);
                //var extension = Path.GetExtension(settingSer.GetData().Logo1);
                var logo = settingSer.GetData().Logo2;

                //Get Setting
                return new Uri(Server.MapPath("~/Logo/" + logo)).AbsoluteUri;
            }
        }

        /// <summary>
        /// get display company name
        /// </summary>
        /// <param name="companyName"></param>
        /// <returns></returns>
        protected string GetDispCompanyName(string companyName)
        {
            return companyName.Trim();
        }

        /// <summary>
        /// get display company Address
        /// </summary>
        /// <param name="companyAddress1"></param>
        /// <param name="companyAddress2"></param>
        /// <param name="companyAddress3"></param>
        /// <returns></returns>
        protected string GetDispCompanyAddress(string companyAddress1, string companyAddress2, string companyAddress3)
        {
            return companyAddress1.Trim() + " " + companyAddress2.Trim() + " " + companyAddress3.Trim();
        }

        /// <summary>
        /// get display company tel
        /// </summary>
        /// <param name="companyTel1"></param>
        /// <param name="companyTel2"></param>
        /// <returns></returns>
        protected string GetDispCompanyTel(string companyTel1, string companyTel2 = "")
        {
            return "Tel : " + companyTel1.Trim() + (string.IsNullOrEmpty(companyTel2.Trim()) ? string.Empty : (" ~ " + companyTel2.Trim()));
        }

        /// <summary>
        /// get display company fax
        /// </summary>
        /// <param name="companyFax"></param>
        /// <returns></returns>
        protected string GetDispCompanyFax(string companyFax)
        {
            return "Fax : " + companyFax;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="companyEmail"></param>
        /// <returns></returns>
        protected string GetDispCompanyEmail(string companyEmail)
        {
            return "Email : " + companyEmail;
        }

        #endregion

        #region Header report

        /// <summary>
        /// Get Format Date
        /// </summary>
        /// <param name="month"></param>
        /// <param name="day"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        protected string GetDispDate(int month, int day, int year)
        {
            string sDate = null;
            string sMonth = string.Empty;
            switch (month)
            {
                case 1:
                    sMonth = "Jan";
                    break;
                case 2:
                    sMonth = "Feb";
                    break;
                case 3:
                    sMonth = "Mar";
                    break;
                case 4:
                    sMonth = "Apr";
                    break;
                case 5:
                    sMonth = "May";
                    break;
                case 6:
                    sMonth = "Jun";
                    break;
                case 7:
                    sMonth = "Jul";
                    break;
                case 8:
                    sMonth = "Aug";
                    break;
                case 9:
                    sMonth = "Sep";
                    break;
                case 10:
                    sMonth = "Oct";
                    break;
                case 11:
                    sMonth = "Nov";
                    break;
                case 12:
                    sMonth = "Dec";
                    break;
            }

            sDate = day.ToString("00") + "/" + sMonth + "/" + year.ToString();
            return sDate;
        }

        /// <summary>
        /// Get Display Address
        /// </summary>
        /// <param name="add1"></param>
        /// <param name="add2"></param>
        /// <param name="add3"></param>
        /// <returns></returns>
        protected string GetDispAddressMultiLine(string add1, string add2, string add3)
        {
            //string temp = string.Empty;
            //if (string.IsNullOrEmpty(add1))
            //{
            //    return temp;
            //}

            //if (!string.IsNullOrEmpty(add2))
            //{
            //    temp = add1 + "\n" + add2;
            //}

            //if (!string.IsNullOrEmpty(add3))
            //{
            //    temp = add1 + "\n" + add2 + '\n' + add3;
            //}

            //return temp;

            //-------2014/12/08 ISV-HUNG Edit Start -----------//
            var fAdds = new string[] { add1, add2, add3 };
            return string.Join("\n", fAdds.Where(s => !string.IsNullOrEmpty(s)));
            //-------2014/12/08 ISV-HUNG Edit End -----------//
        }

        #endregion

        #region detail report

        /// <summary>
        /// get display money
        /// </summary>
        /// <param name="value"></param>
        /// <param name="decimalType"></param>
        /// <returns></returns>
        protected string GetDispMoney(decimal? value, int decimalType)
        {
            if (decimalType == 1)
            {
                return string.Format(Constants.NUMBER_FORMAT_DEC_2, value);
            }
            else
            {
                return string.Format(Constants.NUMBER_FORMAT_INT, value);
            }
        }

        /// <summary>
        /// get display unit name
        /// </summary>
        /// <param name="unit"></param>
        /// <returns></returns>
        protected string GetDispUnitName(int ID)
        {
            M_Unit item = new M_Unit();
            using (DB db = new DB())
            {
                UnitService unitService = new UnitService(db);
                item = unitService.GetByID(ID);

                if (item == null)
                {
                    return string.Empty;
                }
            }
            return string.IsNullOrEmpty(item.UnitName) ? string.Empty : string.Format("{0}", item.UnitName);
        }

        /// <summary>
        /// get display Quantity
        /// </summary>
        /// <param name="quantity"></param>
        /// <param name="decimalType"></param>
        /// <returns></returns>
        protected string GetDispQuantity(decimal? quantity, int unitID,
                                         string methodVat = M_Config_D.METHOD_VAT_EACH,
                                         string vatType = M_Config_D.VAT_TYPE_FREE,
                                         string quantityDecimal = M_Config_D.QUANTITY_DECIMAL)
        {
            string tmp = string.Empty;
            string unitNm = GetDispUnitName(unitID);

            if (quantity == 0)
            {
                return unitNm;
            }
            else
            {
                var qtyDecDigit = quantityDecimal == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                if (methodVat.Equals(M_Config_D.METHOD_VAT_EACH) && vatType.Equals(M_Config_D.VAT_TYPE_EXCLUDE))
                {
                    // Description: Edit
                    // Author: ISV-PHUONG
                    // Date  : 2014/12/05
                    // ---------------------- Start ------------------------------
                    //tmp = "\n" + string.Format(Constants.FMT_DECIMAL_FULL, ) + "\n" + unitNm;
                    tmp = "\n" + quantity.GetValueOrDefault().ToString(string.Format("N{0}", qtyDecDigit)) + "\n" + unitNm;
                    // ---------------------- End  ------------------------------
                }
                else
                {
                    if (unitID != 1)
                    {
                        // Description: Edit
                        // Author: ISV-PHUONG
                        // Date  : 2014/12/05
                        // ---------------------- Start ------------------------------
                        //tmp = "\n" + string.Format(Constants.FMT_DECIMAL_FULL, quantity) + "\n" + unitNm;
                        tmp = "\n" + quantity.GetValueOrDefault().ToString(string.Format("N{0}", qtyDecDigit)) + "\n" + unitNm;

                        // ---------------------- End  ------------------------------

                    }
                    else
                    {
                        // Description: Edit
                        // Author: ISV-PHUONG
                        // Date  : 2014/12/05
                        // ---------------------- Start ------------------------------
                        //tmp = string.Format(Constants.FMT_DECIMAL_FULL, quantity);
                        tmp = quantity.GetValueOrDefault().ToString(string.Format("N{0}", qtyDecDigit));
                        // ---------------------- End  ------------------------------

                    }
                }
            }

            return tmp;
        }

        /// <summary>
        /// GetDispUnitPtice
        /// </summary>
        /// <param name="quantity"></param>
        /// <param name="unitPrice"></param>
        /// <param name="decimalType"></param>
        /// <returns></returns>
        protected string GetDispUnitPtice(string quantity, decimal? unitPrice, int decimalType)
        {
            if (quantity.Contains("\n"))
            {
                return "\n" + GetDispMoney(unitPrice, decimalType) + "\n";
            }
            return GetDispMoney(unitPrice, decimalType);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="total"></param>
        /// <param name="decimalType"></param>
        /// <param name="vat"></param>
        /// <param name="methodVat"></param>
        /// <param name="vatType"></param>
        /// <returns></returns>
        protected string GetDispSubTotal(decimal? total, decimal? quantity, int unitID, M_Currency_H currency)
        {
            string tmp = string.Empty;
            if (quantity == 0)
            {
                return tmp;
            }

            if (unitID != 1)
            {
                tmp = "\n" + GetDispMoney(total, currency.DecimalType) + "\n";
            }
            else
            {
                tmp = GetDispMoney(total, currency.DecimalType);
            }

            return tmp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vatUnit"></param>
        /// <param name="currency"></param>
        /// <param name="vat"></param>
        /// <param name="methodVat"></param>
        /// <param name="vatType"></param>
        /// <returns></returns>
        protected string GetDispSubVat(decimal? vatUnit, M_Currency_H currency, decimal? vat, string vatType = M_Config_D.VAT_TYPE_FREE)
        {
            string tmp = string.Empty;
            if (vatType.Equals(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                tmp = "\n" + GetDispMoney(vatUnit, currency.DecimalType) + ("\n (" + string.Format(Constants.NUMBER_FORMAT_INT, vat) + "%) ");
            }
            else
            {
                switch (vatType)
                {
                    case M_Config_D.VAT_TYPE_FREE:
                        tmp = this.GetConfigName(M_Config_H.CONFIG_CD_VAT_TYPE, int.Parse(M_Config_D.VAT_TYPE_FREE), short.Parse(M_Config_D.METHOD_VAT_EACH));
                        break;
                    case M_Config_D.VAT_TYPE_INCLUDE:
                        tmp = this.GetConfigName(M_Config_H.CONFIG_CD_VAT_TYPE, int.Parse(M_Config_D.VAT_TYPE_INCLUDE), short.Parse(M_Config_D.METHOD_VAT_EACH));
                        break;
                }
            }

            return tmp;
        }

        #region display Total report

        /// <summary>
        /// Get Display Label Total Sell
        /// </summary>
        /// <returns></returns>
        protected string GetDispLblTotalSell()
        {
            return "Tổng cộng / Grand total";
        }

        /// <summary>
        /// Get Display Total Sell
        /// </summary>
        /// <param name="value"></param>
        /// <param name="currency"></param>
        /// <returns></returns>
        protected string GetDispTotalSell(decimal value, M_Currency_H currency)
        {
            return GetDispMoney(value, currency.DecimalType) + " " + currency.MoneyCode;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vat"></param>
        /// <param name="tax"></param>
        /// <param name="methodVat"></param>
        /// <param name="vatType"></param>
        /// <returns></returns>
        protected string GetDispLblTotalVAT(decimal vat, string tax, string methodVat = M_Config_D.METHOD_VAT_EACH, string vatType = M_Config_D.VAT_TYPE_FREE)
        {
            string tmp = tax.ToString();
            if (methodVat.Equals(M_Config_D.METHOD_VAT_SUM))
            {
                if (vatType.Equals(M_Config_D.VAT_TYPE_EXCLUDE))
                {
                    tmp = tax + " (" + string.Format(Constants.NUMBER_FORMAT_INT, vat) + "%)";
                }
            }

            return "Tổng thuế / Total " + tmp;
        }

        /// <summary>
        /// Get Display Money VATTotal
        /// </summary>
        /// <param name="value"></param>
        /// <param name="decimalType"></param>
        /// <param name="vatType"></param>
        /// <param name="methodVat"></param>
        /// <returns></returns>
        protected string GetDispTotalVAT(decimal value, M_Currency_H currency, string methodVat = M_Config_D.METHOD_VAT_EACH, string vatType = M_Config_D.VAT_TYPE_FREE)
        {
            if (methodVat.Equals(M_Config_D.METHOD_VAT_SUM))
            {
                switch (vatType)
                {
                    case M_Config_D.VAT_TYPE_FREE:
                        return this.GetConfigName(M_Config_H.CONFIG_CD_VAT_TYPE, int.Parse(M_Config_D.VAT_TYPE_FREE), short.Parse(methodVat));

                    case M_Config_D.VAT_TYPE_INCLUDE:
                        return this.GetConfigName(M_Config_H.CONFIG_CD_VAT_TYPE, int.Parse(M_Config_D.VAT_TYPE_INCLUDE), short.Parse(methodVat)) + " " + currency.TaxName;
                }
            }
            return GetDispMoney(value, currency.DecimalType) + " " + currency.MoneyCode;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tax"></param>
        /// <returns></returns>
        protected string GetDispLblGrandTotal(string tax)
        {
            return "Tổng thành tiền / Grand total (with " + tax + ")";
        }

        /// <summary>
        /// Get Display Grand Total
        /// </summary>
        /// <param name="value"></param>
        /// <param name="currency"></param>
        /// <returns></returns>
        protected string GetDispGrandTotal(decimal value, M_Currency_H currency)
        {
            return GetDispMoney(value, currency.DecimalType) + " " + currency.MoneyCode;
        }

        #endregion

        #endregion

        #region footer report

        /// <summary>
        /// Get Approve Name
        /// </summary>
        /// <param name="approvedCD">approvedCD</param>
        /// <returns></returns>
        protected string GetApproveName(string approvedCD)
        {
            string name = string.Empty;
            if (!string.IsNullOrEmpty(approvedCD))
            {
                //Get user by ApprovedCD
                M_User user = this.GetUserByUserCD(approvedCD);
                if (user != null)
                {
                    if (!string.IsNullOrEmpty(user.Position2))//PositionVN
                    {
                        name += user.Position2;
                        if (!string.IsNullOrEmpty(user.Position1))//PositionEN
                        {
                            name += " (" + user.Position1 + ")";
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(user.Position1))//PositionEN
                        {
                            name += " / " + user.Position1;
                        }
                    }
                    name += "\n" + user.UserName1;
                }
                else
                {
                    name = "Authorized Signature / Seal";
                }
            }
            return name;
        }

        /// <summary>
        /// Get Approve Name
        /// </summary>
        /// <param name="approvedCD">approvedCD</param>
        /// <returns></returns>
        protected string GetApproveName2(string approvedCD)
        {
            string name = string.Empty;
            if (!string.IsNullOrEmpty(approvedCD))
            {
                //Get user by ApprovedCD
                M_User user = this.GetUserByUserCD(approvedCD);
                if (user != null)
                {
                    M_GroupUser_H group = this.GetGroupUserByID(user.GroupID);
                    if (group != null)
                    {
                        name = String.Format("{0} / {1}", user.UserName1, group.GroupName);
                    }
                }
                else
                {
                    name = "Authorized Signature / Seal";
                }
            }
            return name;
        }

        protected string GetApproveNameMyanmar(string approvedCD)
        {
            string name = string.Empty;
            if (!string.IsNullOrEmpty(approvedCD))
            {
                //Get user by ApprovedCD
                M_User user = this.GetUserByUserCD(approvedCD);
                if (user != null)
                {
                    M_GroupUser_H group = this.GetGroupUserByID(user.GroupID);
                    if (group != null)
                    {
                        name = String.Format("{0} / {1}", user.UserName1, user.Position1);
                    }
                }
                else
                {
                    name = "Authorized Signature / Seal";
                }
            }
            return name;
        }

        /// <summary>
        /// Get Representer
        /// </summary>
        /// <param name="name"></param>
        /// <param name="position"></param>
        /// <returns></returns>
        protected string GetRepresenter(string name, string position)
        {
            string representer = string.Empty;
            //if (!string.IsNullOrEmpty(customerCD))
            //{
            //    //Get user by customerCD
            //    //M_Customer cus = this.GetCustomerByCD(customerCD);
            //    //if (cus != null)
            //    {
            //        if (!string.IsNullOrEmpty(represent))
            //        {
            //            if (!string.IsNullOrEmpty(position2))//PositionVN
            //            {
            //                cusRepresent += position2;
            //                if (!string.IsNullOrEmpty(position1))//PositionEN
            //                {
            //                    cusRepresent += " (" + position1 + ")";
            //                }
            //            }
            //            else
            //            {
            //                if (!string.IsNullOrEmpty(position1))//PositionEN
            //                {
            //                    cusRepresent += " / " + position1;
            //                }
            //            }

            //            cusRepresent += "\n" + represent;
            //        }
            //        else
            //        {
            //            cusRepresent = "Authorized Signature / Seal";
            //        }
            //    }
            //}
            representer = position + "\n" + name;

            if (string.IsNullOrEmpty(representer.Replace("\n", "").Trim()))
            {
                //representer = "Authorized Signature / Seal";
                representer = string.Empty;
            }

            return representer;
        }

        ///// <summary>
        ///// Get Customer Represent
        ///// </summary>
        ///// <param name="customerCD"></param>
        ///// <returns></returns>
        //protected string GetCustomerRepresent(string customerCD)
        //{
        //    string cusRepresent = string.Empty;
        //    if (!string.IsNullOrEmpty(customerCD))
        //    {
        //        //Get user by customerCD
        //        M_Customer cus = this.GetCustomerByCD(customerCD);
        //        if (cus != null)
        //        {
        //            if (!string.IsNullOrEmpty(cus.Represent))
        //            {
        //                if (!string.IsNullOrEmpty(cus.Position2))//PositionVN
        //                {
        //                    cusRepresent += cus.Position2;
        //                    if (!string.IsNullOrEmpty(cus.Position1))//PositionEN
        //                    {
        //                        cusRepresent += " (" + cus.Position1 + ")";
        //                    }
        //                }
        //                else
        //                {
        //                    if (!string.IsNullOrEmpty(cus.Position1))//PositionEN
        //                    {
        //                        cusRepresent += " / " + cus.Position1;
        //                    }
        //                }

        //                cusRepresent += "\n" + cus.Represent;
        //            }
        //            else
        //            {
        //                cusRepresent = "Authorized Signature / Seal";
        //            }
        //        }
        //    }
        //    return cusRepresent;
        //}

        /// <summary>
        /// get issue name
        /// </summary>
        /// <param name="issueCD"></param>
        /// <returns></returns>
        protected string GetIssueName(string issueCD)
        {
            if (!string.IsNullOrEmpty(issueCD))
            {
                //Get user by ApprovedCD
                M_User user = this.GetUserByUserCD(issueCD);
                if (user != null)
                {
                    return String.Format("{0}", user.UserName1);
                }
            }
            return string.Empty;
        }

        #endregion

        #endregion

        #region report

        /// <summary>
        /// Spell Number
        /// </summary>
        /// <param name="myNumber"></param>
        /// <param name="currentCulture"></param>
        /// <param name="currencyUnit"></param>
        /// <param name="currencyUnitSmall"></param>
        /// <returns></returns>
        protected string GetDispNumberStr(decimal value, Language currentCulture, string currencyUnit, string currencyUnitSmall = "")
        {
            decimal tmp = Convert.ToDecimal(string.Format("{0}", value).Replace(",", ""));
            string strVal = Math.Abs(tmp).ToString();
            if (currentCulture == Language.English)
            {
                return ReadNumber(strVal, currencyUnit, currencyUnitSmall);
            }
            else
            {
                return ChuyenSo(strVal, currencyUnit, currencyUnitSmall);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DateValue"></param>
        /// <param name="language"></param>
        /// <returns></returns>
        protected string GetDateString(DateTime DateValue, Language language)
        {
            if (language == Language.Vietnam)
            {
                dynamic StrDate = string.Format("ngày {0} tháng {1} năm {2}", DateValue.Day.ToString("00"), DateValue.Month.ToString("00"), DateValue.Year.ToString("0000"));
                return StrDate;
            }
            else if (language == Language.Japan)
            {
                dynamic StrDate = string.Format("{0}年月{1}日{2}", DateValue.Year.ToString("0000"), DateValue.Month.ToString("00"), DateValue.Day.ToString("00"));//DateValue.ToString("yyyy年MM月dd日");
                return StrDate;
            }
            else
            {
                dynamic SuffixDay = string.Empty;
                dynamic SuffixMoth = string.Empty;

                switch (DateValue.Day)
                {
                    case 1:
                    case 21:
                    case 31:
                        SuffixDay = "st";
                        break;
                    case 2:
                    case 22:
                        SuffixDay = "nd";
                        break;
                    case 3:
                    case 23:
                        SuffixDay = "rd";
                        break;
                    default:
                        SuffixDay = "th";
                        break;
                }
                switch (DateValue.Month)
                {
                    case 1:
                        SuffixMoth = "January";
                        break;
                    case 2:
                        SuffixMoth = "Feburary";
                        break;
                    case 3:
                        SuffixMoth = "March";
                        break;
                    case 4:
                        SuffixMoth = "April ";
                        break;
                    case 5:
                        SuffixMoth = "May";
                        break;
                    case 6:
                        SuffixMoth = "June ";
                        break;
                    case 7:
                        SuffixMoth = "July";
                        break;
                    case 8:
                        SuffixMoth = "August";
                        break;
                    case 9:
                        SuffixMoth = "September";
                        break;
                    case 10:
                        SuffixMoth = "October";
                        break;
                    case 11:
                        SuffixMoth = "November";
                        break;
                    case 12:
                        SuffixMoth = "December";
                        break;
                }
                return string.Format("{0} {1}{2}, {3}", SuffixMoth, DateValue.Day.ToString("00"), SuffixDay, DateValue.Year.ToString("0000"));
            }
        }

        /// <summary>
        /// get Number Line
        /// </summary>
        /// <param name="textString"></param>
        /// <param name="font"></param>
        /// <param name="width"></param>
        /// <returns></returns>
        public int getNumberLine(string textString, Font font, int width)
        {
            System.Drawing.Rectangle rectangle = new System.Drawing.Rectangle(0, 0, width, 1);
            SizeF sOne = TextRenderer.MeasureText("test", font, rectangle.Size, TextFormatFlags.WordBreak);
            SizeF s = TextRenderer.MeasureText(textString, font, rectangle.Size, TextFormatFlags.WordBreak);

            return int.Parse(Math.Ceiling(s.Height / sOne.Height).ToString());
        }

        /// <summary>
        /// Get Month String
        /// </summary>
        /// <param name="value">Date</param>
        /// <returns></returns>
        protected string GetMonthString(DateTime value)
        {
            switch (value.Month)
            {
                case 1:
                    return "January";
                case 2:
                    return "Feburary";
                case 3:
                    return "March";
                case 4:
                    return "April ";
                case 5:
                    return "May";
                case 6:
                    return "June ";
                case 7:
                    return "July";
                case 8:
                    return "August";
                case 9:
                    return "September";
                case 10:
                    return "October";
                case 11:
                    return "November";
                default:
                    return "December";
            }
        }

        /// <summary>
        /// Get Day String
        /// </summary>
        /// <param name="value">Date</param>
        /// <returns></returns>
        protected string GetDayString(DateTime value)
        {
            switch (value.Day)
            {
                case 1:
                case 21:
                case 31:
                    return value.Day.ToString("00") + "st";
                case 2:
                case 22:
                    return value.Day.ToString("00") + "nd";
                case 3:
                case 23:
                    return value.Day.ToString("00") + "rd";
                default:
                    return value.Day.ToString("00") + "th";
            }
        }

        #region Doc so tieng viet

        /// <summary>
        /// cap do cua gia tri tien te
        /// </summary>
        /// <remarks></remarks>
        private enum CurrencyLevel : int
        {

            /// <summary>
            /// hang tram
            /// </summary>
            /// <remarks></remarks>
            Tram = 0,

            /// <summary>
            /// hang nghin
            /// </summary>
            /// <remarks></remarks>
            Nghin = 1,

            /// <summary>
            /// hang trieu
            /// </summary>
            /// <remarks></remarks>
            Trieu = 2,

            /// <summary>
            /// hang ty
            /// </summary>
            /// <remarks></remarks>
            Ty = 3

        }

        /// <summary>
        /// doc so thanh mot chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ChuyenSo(string NumberStr, string CurrencyUnit, string CurrencyUnitSmall)
        {

            if (string.IsNullOrEmpty(NumberStr.Trim()))
                return string.Empty;
            decimal decNum = Convert.ToDecimal(NumberStr);

            //Number interger (lay phan nguyen)
            string intNumStr = Math.Truncate(decNum).ToString();

            //Number decimal (lay phan thap phan (sau dau phay))
            string decimalNumStr = decNum.ToString().Substring(intNumStr.Length);

            //chuoi so tra ve
            string readNumberString = string.Empty;

            //kiem tra so am

            if (NumberStr.IndexOf("-") >= 0 && NumberStr.IndexOf("-") == 0)
            {
                // doc theo so am
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();


                readNumberString = "âm " + ReadNumberToString(intNumStr.Replace("-", "")).Trim() + " " + CurrencyUnit + decimalNumStr;

            }
            else
            {
                //doc so binh thuong

                //doc 2 so sau dau phay
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();

                readNumberString = ReadNumberToString(intNumStr).Trim() + " " + CurrencyUnit + decimalNumStr;

            }

            if (string.IsNullOrEmpty(readNumberString))
            {
                return string.Empty;

            }
            else
            {
                //dinh dang chuoi tra ve
                readNumberString = readNumberString.ToLower().Trim();

                //lay ki tu dau tien de viet hoa
                string FirstCharacter = readNumberString[0].ToString();

                //viet hoa donvi tien te
                if (readNumberString.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    readNumberString = readNumberString.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }

                //viet hoa chu dau
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), readNumberString.Substring(1));
            }


        }

        /// <summary>
        /// chuyen so thanh chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumberToString(string NumberStr)
        {


            if (NumberStr.Length > 3)
            {

                if (NumberStr.Length % 3 == 0)
                {
                    //Kiem tra neu chuoi so chua so khong het, thi khoi doc cac so dang sau
                    bool isZero = true;
                    for (int index = 0; index <= NumberStr.Length - 1; index++)
                    {
                        if (!NumberStr[index].Equals("0"))
                        {
                            isZero = false;
                        }
                    }
                    if (isZero)
                    {
                        return string.Empty;
                    }

                    //---------------- doc so lon hon hang ty

                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse((Math.Truncate(temp) - 1).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;
                        }
                    }

                    //-------------------------------------------
                    //lay 3 so dau
                    string NumTemp = NumberStr.Substring(0, 3);

                    // neu la 3 so 0 thi doc tiep day con lai
                    if (Convert.ToInt32(NumTemp) == 0)
                    {

                        return ReadNumberToString(NumberStr.Substring(NumTemp.Length));

                    }


                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));


                }
                else
                {
                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse(Math.Truncate(temp).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;

                        }
                    }

                    //lay ra so co hang don vi tien lon nhat
                    string NumTemp = NumberStr.Substring(0, NumberStr.Length % 3);

                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));
                }


            }
            else
            {
                //doc 3 so cuoi
                return ReadNumber3Digit(NumberStr);

            }


        }

        /// <summary>
        /// doc chuoi so voi 3 chu so
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber3Digit(string readNumber)
        {

            string hangTram = string.Empty;
            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = string.Empty;


            if (readNumber.Length == 3)
            {
                //lay so o hang tram
                hangTram = readNumber[0].ToString();

                //lay so o hang chuc
                hangChuc = readNumber[1].ToString();

                //lay do o hang don vi
                hangDonVi = readNumber[2].ToString();

            }
            else if (readNumber.Length == 2)
            {
                hangChuc = readNumber[0].ToString();
                hangDonVi = readNumber[1].ToString();
            }
            else
            {
                hangDonVi = readNumber[0].ToString();
            }
            if (hangTram == "0" && hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }


            if (!string.IsNullOrEmpty(hangTram) && !string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                //Doc so hang Tram
                readString += NumberString(Convert.ToInt32(hangTram)) + " trăm";

                // doc so hang chuc
                if (hangChuc == "0" && hangDonVi == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "0")
                {
                    readString += " lẻ";
                }
                else if (hangChuc == "1")
                {
                    readString += " mười";
                }
                else
                {
                    readString += " " + NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi));
            }

            return readString;

        }

        /// <summary>
        /// doc so le (2 chu so)
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber2Decimal(string readNumber)
        {


            if (string.IsNullOrEmpty(readNumber))
                return string.Empty;
            if (readNumber.Length > 3)
            {
                readNumber = readNumber.Substring(0, 3);
            }

            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = "và ";
            if (readNumber.Length == 3)
            {
                hangChuc = readNumber[1].ToString();
                hangDonVi = readNumber[2].ToString();
            }
            else if (readNumber.Length == 2)
            {
                hangDonVi = readNumber[1].ToString();
            }
            if (hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }

            if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString = readString.Trim();
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi)) + " mươi";
            }


            return readString;
        }

        /// <summary>
        /// so kieu chuoi
        /// </summary>
        /// <param name="intNum"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string NumberString(int intNum)
        {

            string ret = string.Empty;
            switch (intNum)
            {
                case 0:
                    ret = "không";
                    break;
                case 1:
                    ret = "một";
                    break;
                case 2:
                    ret = "hai";
                    break;
                case 3:
                    ret = "ba";
                    break;
                case 4:
                    ret = "bốn";
                    break;
                case 5:
                    ret = "năm";
                    break;
                case 6:
                    ret = "sáu";
                    break;
                case 7:
                    ret = "bảy";
                    break;
                case 8:
                    ret = "tám";
                    break;
                case 9:
                    ret = "chín";
                    break;
                case 10:
                    ret = "mười";
                    break;
            }

            return ret;
        }

        #endregion

        #region Doc so tieng anh

        /// <summary>
        /// Read number by English
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <param name="CurrencyUnit"></param>
        /// <param name="CurrencyUnitSmall"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber(string MyNumber, string CurrencyUnit, string CurrencyUnitSmall)
        {
            string Dollars = "";
            string Cents = "";
            string Temp = "";
            int DecimalPlace = 0;
            int Count = 0;
            string[] Place = new string[10];
            Place[2] = "Thousand ";
            Place[3] = "Million ";
            Place[4] = "Billion ";
            Place[5] = "Trillion ";
            // String representation of amount.
            if (string.IsNullOrEmpty(MyNumber))
            {
                return string.Empty;
            }
            MyNumber = MyNumber.Trim();
            // Position of decimal place 0 if none.
            DecimalPlace = MyNumber.IndexOf(".");
            // Convert cents and set MyNumber to dollar amount.
            if (DecimalPlace > 0)
            {
                Cents = GetTens(CommonUtil.Left(CommonUtil.Mid(MyNumber, DecimalPlace + 2) + "00", 2));
                MyNumber = (CommonUtil.Left(MyNumber, DecimalPlace)).Trim();
            }
            Count = 1;
            while (!string.IsNullOrEmpty(MyNumber))
            {
                Temp = GetHundreds(CommonUtil.Right(MyNumber, 3));
                if (!string.IsNullOrEmpty(Temp))
                    Dollars = Temp + Place[Count] + Dollars;
                if (MyNumber.Length > 3)
                {
                    MyNumber = CommonUtil.Left(MyNumber, MyNumber.Length - 3);
                }
                else
                {
                    MyNumber = "";
                }
                Count = Count + 1;
            }
            switch (Dollars)
            {
                case "":
                    Dollars = "Zero " + CurrencyUnit;
                    break;
                case "One":
                    Dollars = "One " + CurrencyUnit;
                    break;
                default:
                    Dollars = Dollars + CurrencyUnit;
                    break;
            }
            switch (Cents)
            {
                case "":
                    break;
                //Cents = " Only"
                case "One":
                    Cents = " and One " + CurrencyUnitSmall;
                    break;
                default:
                    Cents = " and " + Cents + CurrencyUnitSmall;
                    break;
            }

            Dollars = Dollars + Cents;
            if (string.IsNullOrEmpty(Dollars))
            {
                return string.Empty;
            }
            else
            {
                Dollars = Dollars.ToLower().Trim();
                if (Dollars.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    Dollars = Dollars.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }
                dynamic FirstCharacter = Dollars[0];
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), Dollars.Substring(1));
            }

        }

        /// <summary>
        /// Get number Hundreds
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetHundreds(string MyNumber)
        {
            string functionReturnValue = null;
            string Result = string.Empty;
            if (int.Parse(MyNumber) == 0)
            {
                return "";
                //return functionReturnValue;
            }
            MyNumber = CommonUtil.Right("000" + MyNumber, 3);
            // Convert the hundreds place.
            if (CommonUtil.Mid(MyNumber, 1, 1) != "0")
            {
                Result = GetDigit(CommonUtil.Mid(MyNumber, 1, 1)) + "Hundred ";
            }
            // Convert the tens and ones place.
            if (CommonUtil.Mid(MyNumber, 2, 1) != "0")
            {
                Result = Result + GetTens(CommonUtil.Mid(MyNumber, 2));
            }
            else
            {
                Result = Result + GetDigit(CommonUtil.Mid(MyNumber, 3));
            }
            functionReturnValue = Result;
            return functionReturnValue;
        }

        /// <summary>
        /// Get Number Tens
        /// </summary>
        /// <param name="TensText"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetTens(string TensText)
        {
            string Result = "";
            // Null out the temporary function value.
            // If value between 10-19...
            if (int.Parse(CommonUtil.Left(TensText, 1)) == 1)
            {
                switch (int.Parse(TensText))
                {
                    case 10:
                        Result = "Ten ";
                        break;
                    case 11:
                        Result = "Eleven ";
                        break;
                    case 12:
                        Result = "Twelve ";
                        break;
                    case 13:
                        Result = "Thirteen ";
                        break;
                    case 14:
                        Result = "Fourteen ";
                        break;
                    case 15:
                        Result = "Fifteen ";
                        break;
                    case 16:
                        Result = "Sixteen ";
                        break;
                    case 17:
                        Result = "Seventeen ";
                        break;
                    case 18:
                        Result = "Eighteen ";
                        break;
                    case 19:
                        Result = "Nineteen ";
                        break;
                    default:
                        break;
                }
                // If value between 20-99...
            }
            else
            {
                switch (int.Parse(CommonUtil.Left(TensText, 1)))
                {
                    case 2:
                        Result = "Twenty ";
                        break;
                    case 3:
                        Result = "Thirty ";
                        break;
                    case 4:
                        Result = "Forty ";
                        break;
                    case 5:
                        Result = "Fifty ";
                        break;
                    case 6:
                        Result = "Sixty ";
                        break;
                    case 7:
                        Result = "Seventy ";
                        break;
                    case 8:
                        Result = "Eighty ";
                        break;
                    case 9:
                        Result = "Ninety ";
                        break;
                    default:
                        break;
                }
                Result = Result + GetDigit(CommonUtil.Right(TensText, 1));
                // Retrieve ones place.
            }
            return Result;
        }

        /// <summary>
        /// Get Number Digits
        /// </summary>
        /// <param name="Digit"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetDigit(string Digit)
        {
            string functionReturnValue = null;
            switch (int.Parse(Digit))
            {
                case 1:
                    functionReturnValue = "One ";
                    break;
                case 2:
                    functionReturnValue = "Two ";
                    break;
                case 3:
                    functionReturnValue = "Three ";
                    break;
                case 4:
                    functionReturnValue = "Four ";
                    break;
                case 5:
                    functionReturnValue = "Five ";
                    break;
                case 6:
                    functionReturnValue = "Six ";
                    break;
                case 7:
                    functionReturnValue = "Seven ";
                    break;
                case 8:
                    functionReturnValue = "Eight ";
                    break;
                case 9:
                    functionReturnValue = "Nine ";
                    break;
                default:
                    functionReturnValue = "";
                    break;
            }
            return functionReturnValue;
        }

        #endregion
        #endregion
    }
}

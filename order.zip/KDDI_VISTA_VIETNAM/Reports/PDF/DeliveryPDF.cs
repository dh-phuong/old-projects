﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Reporting.WebForms;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.PDF
{
    /// <summary>
    /// DeliveryInfo
    /// </summary>
    public class DeliveryReport : BaseReport<DeliveryReport>
    {
        public int NumberRow { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string SeriNo { get; set; }
        public string Warranty { get; set; }
        public string Remarks { get; set; }
        public int RowCount { get; set; }
    }


    public class DeliveryPDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        /// <summary>
        /// GetLocalReport
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public LocalReport GetLocalReport(LocalReport localReport, int ID, DateTime updateDate)
        {
            localReport.EnableExternalImages = true;
            localReport.ReportPath = Server.MapPath("~/Reports/rptDelivery.rdlc");
            this.LoadData(localReport, ID, updateDate);
            localReport.Refresh();
            return localReport;
        }

        /// <summary>
        /// InitParams
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParams(T_Delivery_H deliveryH)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------
            paras.Add(new ReportParameter("imagePath", base.GetPathLogo()));

            M_Company company = this.GetCompany();
            paras.Add(new ReportParameter("title", "BIÊN BẢN BÀN GIAO KIÊM BẢO HÀNH \n(DELIVERY & WARRANTY NOTE)"));
            paras.Add(new ReportParameter("companyName", base.GetDispCompanyName(company.CompanyName1)));
            paras.Add(new ReportParameter("companyAddress", base.GetDispAddressMultiLine(company.companyAddress1, company.companyAddress2, company.CompanyAddress3)));
            paras.Add(new ReportParameter("companyTel", base.GetDispCompanyTel(company.Tel, company.Tel2)));
            paras.Add(new ReportParameter("companyFax", base.GetDispCompanyFax(company.FAX)));
            paras.Add(new ReportParameter("companyEmail", base.GetDispCompanyEmail(company.emailAddress)));

            //-------------------------------
            //  Header Report
            //-------------------------------
            paras.Add(new ReportParameter("customerName", deliveryH.CustomerName));
            paras.Add(new ReportParameter("attnName", deliveryH.ContactPerson));
            paras.Add(new ReportParameter("customerAddress", base.GetDispAddressMultiLine(deliveryH.CustomerAddress1, deliveryH.CustomerAddress2, deliveryH.CustomerAddress3)));
            paras.Add(new ReportParameter("customerTel", deliveryH.Tel));
            paras.Add(new ReportParameter("customerFax", deliveryH.Fax));

            //Represent of Customer
            paras.Add(new ReportParameter("cusRepresent", base.GetRepresenter(deliveryH.Confirmed, deliveryH.Position)));

            paras.Add(new ReportParameter("salesNo", deliveryH.SalesNo));
            paras.Add(new ReportParameter("deliveryNo", deliveryH.DeliveryNo));
            paras.Add(new ReportParameter("deliveryDate", base.GetDispDate(deliveryH.DeliveryDate.Month, deliveryH.DeliveryDate.Day, deliveryH.DeliveryDate.Year)));
            paras.Add(new ReportParameter("quoteNo", deliveryH.QuoteNo));
            paras.Add(new ReportParameter("preparedBy", deliveryH.PreparedName));

            //-----------2014/12/08 ISV-HUNG Edit with CustomerCD:999999 Start-----------------------//
            //M_Customer customer;
            //using (DB db = new DB())
            //{
            //    CustomerService cus = new CustomerService(db);
            //    customer = cus.GetByCustomerCD(shippingH.CustomerCD);
            //}

            string info = string.Format("This note is made to confirm that {0} (Customer) has received fully and accepted all the items and service in the list belows from {1} on the date of {2} and all the equipments, material, service and system as required are in good condition after installation.",
                                            deliveryH.CustomerName, company.CompanyName1, base.GetDateString(deliveryH.DeliveryDate, Utilities.Language.English));
            //-----------2014/12/08 ISV-HUNG Edit with CustomerCD:999999 End-----------------------//

            paras.Add(new ReportParameter("information", info));

            //-------------------------------
            //  Footer Report
            //-------------------------------
            using (DB db = new DB())
            {
                Delivery_CService CService = new Delivery_CService(db);
                paras.Add(new ReportParameter("condition", CService.GetByID(deliveryH.ID).Conditions));
            }

            paras.Add(new ReportParameter("approveName", base.GetApproveNameMyanmar(deliveryH.ApprovedCD)));
            paras.Add(new ReportParameter("delivererName", deliveryH.DelivererName));

            return paras;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="localReport"></param>
        private void LoadData(LocalReport localReport, int ID, DateTime updateDate)
        {
            T_Delivery_H delivery_H = new T_Delivery_H();
            IList<T_Delivery_D> delivery_D;
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            string quantityDecimal = M_Config_D.QUANTITY_DECIMAL;
            // ---------------------- End  -------------------------------
            using (DB db = new DB())
            {
                Delivery_HService HService = new Delivery_HService(db);
                delivery_H = HService.GetByID(ID);

                Delivery_DService DService = new Delivery_DService(db);
                delivery_D = DService.GetListByHID(delivery_H.ID);

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                Config_HService configSer = new Config_HService(db);
                quantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL);
                // ---------------------- End  -------------------------------
            }

            List<DeliveryReport> reportItems = new List<DeliveryReport>();
            System.Drawing.Bitmap bmp = new System.Drawing.Bitmap(1, 1);
            System.Drawing.Graphics graphic = System.Drawing.Graphics.FromImage(bmp);
            System.Drawing.Font font = new System.Drawing.Font("Arial", 8, System.Drawing.GraphicsUnit.Point);
            for (int i = 0; i < delivery_D.Count; i++)
            {
                DeliveryReport reportItem = new DeliveryReport();
                T_Delivery_D item = delivery_D[i];

                reportItem.NumberRow = (i + 1);
                reportItem.ProductName = item.ProductName;
                reportItem.Description = string.IsNullOrEmpty(item.Description) ? string.Empty : ("\n" + item.Description);
                reportItem.Remarks = item.Remark;
                // Description: Edit
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                //reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, shipping_H.MethodVat.ToString(), shipping_H.VatType.ToString());
                reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, delivery_H.MethodVat.ToString(), delivery_H.VatType.ToString(), quantityDecimal);
                // ---------------------- End  -------------------------------

                List<T_Delivery_Serial> serials = new List<T_Delivery_Serial>();
                using (DB db = new DB())
                {
                    TDeliverySerialService ser = new TDeliverySerialService(db);
                    serials = ser.GetListForDeliveryPDF(item.InternalID).ToList();
                }

                int k = 0;
                for (int j = 0; j < serials.Count(); j++)
                {
                    if (serials[0].FinishDate == serials[j].FinishDate)
                    {
                        k++;
                    }
                }
                if (k != serials.Count())
                {
                    for (int j = 0; j < serials.Count(); j++)
                    {
                        reportItem.RowCount = this.GetRowCount(serials[j].SerialNo, graphic, font);
                        string newLine = this.FormatRow(reportItem.RowCount);
                        if (j == serials.Count() - 1)
                        {
                            reportItem.Warranty = reportItem.Warranty + (serials[j].FinishDate == base.DATE_TIME_DEFAULT ? string.Empty : string.Format(Constants.FMT_DATE_DPL, serials[j].FinishDate)) + newLine;
                            reportItem.SeriNo = reportItem.SeriNo + (string.IsNullOrEmpty(serials[j].SerialNo) ? string.Empty : serials[j].SerialNo);
                        }
                        else
                        {
                            reportItem.SeriNo = reportItem.SeriNo + (string.IsNullOrEmpty(serials[j].SerialNo) ? string.Empty : serials[j].SerialNo) + "\n\n";
                            reportItem.Warranty = reportItem.Warranty + (serials[j].FinishDate == base.DATE_TIME_DEFAULT ? string.Empty : string.Format(Constants.FMT_DATE_DPL, serials[j].FinishDate)) + newLine + "\n\n";
                        }
                    }
                    reportItems.Add(reportItem);
                }
                else if (k != 0)
                {
                    for (int j = 0; j < serials.Count(); j++)
                    {
                        reportItem.SeriNo = reportItem.SeriNo + (string.IsNullOrEmpty(serials[j].SerialNo) ? string.Empty : serials[j].SerialNo) + "\n\n";
                    }
                    reportItem.SeriNo = reportItem.SeriNo.Trim();
                    reportItem.Warranty = (serials[0].FinishDate == base.DATE_TIME_DEFAULT ? string.Empty : string.Format(Constants.FMT_DATE_DPL, serials[0].FinishDate));

                    reportItems.Add(reportItem);

                }

                if (serials.Count == 0)
                {
                    reportItem.SeriNo = string.Empty;
                    reportItem.Warranty = string.Empty;

                    reportItems.Add(reportItem);
                }
            }

            localReport.SetParameters(this.InitParams(delivery_H));

            ReportDataSource reportDataSource = new ReportDataSource("Delivery", reportItems);
            localReport.DataSources.Add(reportDataSource);


            //Update
            using (DB db = new DB())
            {
                delivery_H.IssuedFlag = 1;
                delivery_H.IssuedUID = LoginInfo.User.ID;
                delivery_H.UpdateDate = updateDate;
                delivery_H.UpdateUID = LoginInfo.User.ID;

                Delivery_HService HService = new Delivery_HService(db);
                HService.UpdateIssueFlag(delivery_H);
            }
        }

        /// <summary>
        /// Get Row Count
        /// </summary>
        /// <param name="text">text</param>
        /// <param name="graphic">graphic</param>
        /// <param name="font">font</param>
        /// <returns>rowCount</returns>
        private int GetRowCount(string text, System.Drawing.Graphics graphic, System.Drawing.Font font)
        {
            System.Drawing.SizeF si = graphic.MeasureString(text, font);

            double width = si.Width;
            int rowCount = (int)OMS.Utilities.Fraction.Round(FractionType.RoundUp, width / 127);

            return rowCount;
        }

        /// <summary>
        /// Format Row
        /// </summary>
        /// <param name="rowCount">rowCount</param>
        /// <returns>newLine</returns>
        private string FormatRow(int rowCount)
        {
            string newLine = string.Empty;
            switch (rowCount)
            {
                case 0:
                case 1:
                    newLine = string.Empty;
                    break;
                case 2:
                    newLine = "\n";
                    break;
                case 3:
                    newLine = "\n\n";
                    break;
                case 4:
                    newLine = "\n\n\n";
                    break;
                case 5:
                    newLine = "\n\n\n\n";
                    break;
                case 6:
                    newLine = "\n\n\n\n\n";
                    break;
                case 7:
                    newLine = "\n\n\n\n\n\n";
                    break;
                case 8:
                    newLine = "\n\n\n\n\n\n\n";
                    break;
                case 9:
                    newLine = "\n\n\n\n\n\n\n\n";
                    break;
                case 10:
                    newLine = "\n\n\n\n\n\n\n\n\n";
                    break;
                default:
                    newLine = string.Empty;
                    break;
            }

            return newLine;
        }
    }
}
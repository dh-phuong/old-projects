﻿using System;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.PDF
{
    public class BillingReport : BaseReport<BillingReport>
    {
        public int GroupID { get; set; }
        public string NumberRow { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
        public string SubVat { get; set; }
    }

    public class DepositReport : BaseReport<DepositReport>
    {
        public string DepositDate { get; set; }
        public string Amount { get; set; }
    }

    public class BillingPDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        ///// <summary>
        ///// Get InvoiceFlag
        ///// </summary>
        //public bool InvoiceFlag;

        /// <summary>
        /// Get Local Report
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public LocalReport GetLocalReport(LocalReport localReport, int ID, DateTime updateDate)
        {
            localReport.EnableExternalImages = true;            
            this.LoadData(localReport, ID, updateDate);
            localReport.Refresh();

            return localReport;
        }

        /// <summary>
        /// Init Params
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParams(T_Billing_H billing_H, M_Currency_H currency, Decimal theRest)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------
            paras.Add(new ReportParameter("imagePath", base.GetPathLogo()));

            M_Company company = this.GetCompany();
            //if (this.InvoiceFlag)
            //{
            //    paras.Add(new ReportParameter("title", "HÓA ĐƠN (INVOICE)"));
            //}
            //else 
            //{
            //    paras.Add(new ReportParameter("title", "BIÊN NHẬN (RECEIPT)"));
            //}
            paras.Add(new ReportParameter("title", "YÊU CẦU THANH TOÁN (PAYMENT REQUEST)"));

            paras.Add(new ReportParameter("companyName", base.GetDispCompanyName(company.CompanyName1)));
            paras.Add(new ReportParameter("companyAddress", base.GetDispAddressMultiLine(company.companyAddress1, company.companyAddress2, company.CompanyAddress3)));
            paras.Add(new ReportParameter("companyTel", base.GetDispCompanyTel(company.Tel, company.Tel2)));
            paras.Add(new ReportParameter("companyFax", base.GetDispCompanyFax(company.FAX)));
            paras.Add(new ReportParameter("companyEmail", base.GetDispCompanyEmail(company.emailAddress)));

            //-------------------------------
            //  Header Report
            //-------------------------------
            paras.Add(new ReportParameter("customerName", billing_H.CustomerName));
            paras.Add(new ReportParameter("attnName", billing_H.ContactPerson));
            paras.Add(new ReportParameter("customerAddress", base.GetDispAddressMultiLine(billing_H.CustomerAddress1, billing_H.CustomerAddress2, billing_H.CustomerAddress3)));
            paras.Add(new ReportParameter("taxCode", billing_H.TAXCode));
            paras.Add(new ReportParameter("paymentMethod", base.GetConfigName(M_Config_H.CONFIG_CD_PAYMENT_METHOD, billing_H.PaymentMethod, billing_H.MethodVat)));

            paras.Add(new ReportParameter("salesNo", billing_H.SalesNo));
            paras.Add(new ReportParameter("billingNo", billing_H.BillingNo));
            paras.Add(new ReportParameter("billingDate", base.GetDispDate(billing_H.BillingDate.Month, billing_H.BillingDate.Day, billing_H.BillingDate.Year)));
            paras.Add(new ReportParameter("dueDate", base.GetDispDate(billing_H.ExpiryDate.Month, billing_H.ExpiryDate.Day, billing_H.ExpiryDate.Year)));
            paras.Add(new ReportParameter("quoteNo", billing_H.QuoteNo));
            paras.Add(new ReportParameter("preparedBy", billing_H.PreparedName));

            paras.Add(new ReportParameter("subject", billing_H.SubjectName));

            //Represent of Customer
            //paras.Add(new ReportParameter("cusRepresent", string.Empty));

            //-------------------------------
            //  Detail Report
            //-------------------------------
            paras.Add(new ReportParameter("currency", currency.MoneyCode));
            paras.Add(new ReportParameter("tax", currency.TaxName));

            //-------------------------------
            //  Footer Report
            //-------------------------------
            paras.Add(new ReportParameter("lblTotalSell", base.GetDispLblTotalSell()));
            paras.Add(new ReportParameter("totalSell", base.GetDispTotalSell(billing_H.Total, currency)));

            paras.Add(new ReportParameter("lblTotalVAT", base.GetDispLblTotalVAT(billing_H.VatRatio, currency.TaxName, billing_H.MethodVat.ToString(), billing_H.VatType.ToString())));
            paras.Add(new ReportParameter("totalVAT", base.GetDispTotalVAT(billing_H.Vat, currency, billing_H.MethodVat.ToString(), billing_H.VatType.ToString())));

            paras.Add(new ReportParameter("lblGrandTotal", base.GetDispLblGrandTotal(currency.TaxName)));
            paras.Add(new ReportParameter("grandTotal", base.GetDispGrandTotal(billing_H.GrandTotal, currency)));

            paras.Add(new ReportParameter("theRest", base.GetDispMoney(billing_H.GrandTotal - theRest, currency.DecimalType) + " " + currency.MoneyCode));

            paras.Add(new ReportParameter("grandTotalVN", base.GetDispNumberStr(billing_H.GrandTotal - theRest, Language.Vietnam, currency.MoneyNameVN, currency.DecimalNameVN)));
            paras.Add(new ReportParameter("grandTotalEN", base.GetDispNumberStr(billing_H.GrandTotal - theRest, Language.English, currency.MoneyNameUS, currency.DecimalNameUS)));

            using (DB db = new DB())
            {
                Billing_CService CService = new Billing_CService(db);
                paras.Add(new ReportParameter("condition", CService.GetByPK(billing_H.ID).Conditions));
            }

            paras.Add(new ReportParameter("approveName", base.GetApproveNameMyanmar(billing_H.ApprovedCD)));
            paras.Add(new ReportParameter("issueName", base.GetIssueName(billing_H.PreparedCD)));
            return paras;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="localReport"></param>
        private void LoadData(LocalReport localReport, int ID, DateTime updateDate)
        {
            T_Billing_H billing_H = new T_Billing_H();
            IList<T_Billing_D> billing_D;
            IList<T_Deposit> lstDeposit;
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            string quantityDecimal = M_Config_D.QUANTITY_DECIMAL;
            // ---------------------- End  -------------------------------
            using (DB db = new DB())
            {
                Billing_HService HService = new Billing_HService(db);
                billing_H = HService.GetByPK(ID);

                Billing_DService DService = new Billing_DService(db);
                billing_D = DService.GetListByID(billing_H.ID);

                Deposit_Service deposit_Service = new Deposit_Service(db);
                lstDeposit = deposit_Service.GetListByIDForReport(billing_H.ID);

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                Config_HService configSer = new Config_HService(db);
                quantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL);
                // ---------------------- End  -------------------------------
            }

            if (billing_H == null || billing_D.Count == 0) return;

            if (billing_H.MethodVat.Equals(short.Parse(M_Config_D.METHOD_VAT_EACH)))
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptBillingItem.rdlc");
            }
            else
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptBillingTotal.rdlc");
            }

            M_Currency_H currency = base.GetCurrencyByIDAndDate(billing_H.CurrencyID, DateTime.Now);
            List<BillingReport> reportItems = new List<BillingReport>();
            for (int i = 0; i < billing_D.Count; i++)
            {
                BillingReport reportItem = new BillingReport();
                T_Billing_D item = billing_D[i];

                reportItem.NumberRow = (i + 1).ToString();
                reportItem.ProductName = item.ProductName;
                reportItem.Description = item.Description;

                // Description: Edit
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                //reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID);
                reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, quantityDecimal: quantityDecimal);
                // ---------------------- End  -------------------------------

                reportItem.UnitPrice = base.GetDispUnitPtice(reportItem.Quantity, item.UnitPrice, currency.DecimalType);
                reportItem.SubTotal = base.GetDispSubTotal(item.Total, item.Quantity, item.UnitID, currency);
                reportItem.SubVat = base.GetDispSubVat(item.Vat, currency, item.VatRatio, item.VATType.ToString());

                reportItems.Add(reportItem);
            }

            List<DepositReport> reportDItems = new List<DepositReport>();
            Decimal theRest = new Decimal();
            foreach (T_Deposit item in lstDeposit)
            {
                DepositReport reportItem = new DepositReport();
                if (item.DepositDate != null)
                {
                    DateTime date = (DateTime)item.DepositDate;
                    reportItem.DepositDate = "Deposit on " + base.GetDispDate(date.Month, date.Day, date.Year);
                    theRest += item.Amount.Value;
                }

                reportItem.Amount = base.GetDispMoney(item.Amount, currency.DecimalType) + " " + currency.MoneyCode;

                reportDItems.Add(reportItem);
            }

            ReportDataSource reportDataSourceD = new ReportDataSource("Deposit", reportDItems);
            ReportDataSource reportDataSourceI = new ReportDataSource("Billing", reportItems);

            localReport.DataSources.Add(reportDataSourceI);
            localReport.DataSources.Add(reportDataSourceD);

            localReport.SetParameters(this.InitParams(billing_H, currency, theRest));

            //Update
            using (DB db = new DB())
            {
                billing_H.IssuedFlag = 1;
                billing_H.IssuedUID = LoginInfo.User.ID;
                billing_H.UpdateDate = updateDate;
                billing_H.UpdateUID = LoginInfo.User.ID;

                Billing_HService HService = new Billing_HService(db);
                HService.UpdateFlag(billing_H);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.PDF
{
    /// <summary>
    /// Purchase Report Model
    /// </summary>
    public class PurchaseReport : BaseReport<PurchaseReport>
    {
        public int GroupID { get; set; }
        public string NumberRow { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
        public string SubVat { get; set; }
        public string Remark { get; set; }
    }

    /// <summary>
    /// Purchase PDF Class
    /// </summary>
    public class PurchasePDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        /// <summary>
        /// Get Local Report
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public LocalReport GetLocalReport(LocalReport localReport, int ID, DateTime updateDate)
        {
            localReport.EnableExternalImages = true;
            this.LoadData(localReport, ID, updateDate);
            localReport.Refresh();

            return localReport;
        }

        /// <summary>
        /// Init Params
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParams(T_Purchase_H purchase_H, M_Currency_H currency)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------
            paras.Add(new ReportParameter("imagePath", base.GetPathLogo()));

            M_Company company = this.GetCompany();
            paras.Add(new ReportParameter("title", "ĐƠN ĐẶT HÀNG (ORDER SHEET)"));
            paras.Add(new ReportParameter("companyName", base.GetDispCompanyName(company.CompanyName1)));
            paras.Add(new ReportParameter("companyAddress", base.GetDispAddressMultiLine(company.companyAddress1, company.companyAddress2, company.CompanyAddress3)));
            paras.Add(new ReportParameter("companyTel", base.GetDispCompanyTel(company.Tel, company.Tel2)));
            paras.Add(new ReportParameter("companyFax", base.GetDispCompanyFax(company.FAX)));
            paras.Add(new ReportParameter("companyEmail", base.GetDispCompanyEmail(company.emailAddress)));

            //-------------------------------
            //  Header Report
            //-------------------------------
            paras.Add(new ReportParameter("vendorName", purchase_H.VendorName));
            paras.Add(new ReportParameter("attnName", purchase_H.ContactPerson));
            paras.Add(new ReportParameter("vendorAddress", base.GetDispAddressMultiLine(purchase_H.VendorAddress1, purchase_H.VendorAddress2, purchase_H.VendorAddress3)));
            paras.Add(new ReportParameter("vendorTel", purchase_H.Tel));
            paras.Add(new ReportParameter("vendorFax", purchase_H.Fax));

            paras.Add(new ReportParameter("salesNo", purchase_H.SalesNo));
            paras.Add(new ReportParameter("purchaseNo", purchase_H.PurchaseNo));
            paras.Add(new ReportParameter("orderDate", base.GetDispDate(purchase_H.PurchaseDate.Month, purchase_H.PurchaseDate.Day, purchase_H.PurchaseDate.Year)));
            paras.Add(new ReportParameter("quoteNo", purchase_H.QuoteNo));
            paras.Add(new ReportParameter("preparedBy", purchase_H.PreparedName));


            paras.Add(new ReportParameter("poRepresent", base.GetRepresenter(purchase_H.Confirmed, purchase_H.Position)));
            //------------- ISV-Giam 2015/01/09 --------------
            paras.Add(new ReportParameter("poRepresentDefault", Constant.DEFAULT_POSITION + "\n" + Constant.DEFAULT_REPRESENT));
            //------------------------------------------------
            paras.Add(new ReportParameter("subject", purchase_H.SubjectName));

            //-------------------------------
            //  Detail Report
            //-------------------------------
            paras.Add(new ReportParameter("currency", currency.MoneyCode));
            paras.Add(new ReportParameter("tax", currency.TaxName));

            //-------------------------------
            //  Footer Report
            //-------------------------------
            paras.Add(new ReportParameter("lblTotalSell", base.GetDispLblTotalSell()));
            paras.Add(new ReportParameter("totalSell", base.GetDispTotalSell(purchase_H.Total, currency)));

            paras.Add(new ReportParameter("lblTotalVAT", base.GetDispLblTotalVAT(purchase_H.VatRatio, currency.TaxName, purchase_H.MethodVat.ToString(), purchase_H.VatType.ToString())));
            paras.Add(new ReportParameter("totalVAT", base.GetDispTotalVAT(purchase_H.Vat, currency, purchase_H.MethodVat.ToString(), purchase_H.VatType.ToString())));

            paras.Add(new ReportParameter("lblGrandTotal", base.GetDispLblGrandTotal(currency.TaxName)));
            paras.Add(new ReportParameter("grandTotal", base.GetDispGrandTotal(purchase_H.GrandTotal, currency)));

            paras.Add(new ReportParameter("grandTotalVN", base.GetDispNumberStr(purchase_H.GrandTotal, Language.Vietnam, currency.MoneyNameVN, currency.DecimalNameVN)));
            paras.Add(new ReportParameter("grandTotalEN", base.GetDispNumberStr(purchase_H.GrandTotal, Language.English, currency.MoneyNameUS, currency.DecimalNameUS)));

            using (DB db = new DB())
            {
                Purchase_CService CService = new Purchase_CService(db);
                paras.Add(new ReportParameter("condition", CService.GetByPK(purchase_H.ID).Conditions));
            }

            paras.Add(new ReportParameter("approveName", base.GetApproveNameMyanmar(purchase_H.ApprovedCD)));
            paras.Add(new ReportParameter("issueName", base.GetIssueName(purchase_H.PreparedCD)));

            return paras;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="localReport"></param>
        private void LoadData(LocalReport localReport, int ID, DateTime updateDate)
        {
            T_Purchase_H purchase_H = new T_Purchase_H();
            IList<T_Purchase_D> purchase_D;
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            string quantityDecimal = M_Config_D.QUANTITY_DECIMAL;
            // ---------------------- End  -------------------------------
            using (DB db = new DB())
            {
                Purchase_HService HService = new Purchase_HService(db);
                purchase_H = HService.GetByPK(ID);

                Purchase_DService DService = new Purchase_DService(db);
                purchase_D = DService.GetByPurchaseID(purchase_H.ID);

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                Config_HService configSer = new Config_HService(db);
                quantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL);
                // ---------------------- End  -------------------------------
            }
            if (purchase_H == null || purchase_D.Count == 0) return;

            if (purchase_H.MethodVat.Equals(short.Parse(M_Config_D.METHOD_VAT_EACH)))
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptPurchaseItem.rdlc");
            }
            else
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptPurchaseTotal.rdlc");
            }

            M_Currency_H currency = base.GetCurrencyByIDAndDate(purchase_H.CurrencyID, DateTime.Now);

            List<PurchaseReport> reportItems = new List<PurchaseReport>();
            for (int i = 0; i < purchase_D.Count; i++)
            {
                PurchaseReport reportItem = new PurchaseReport();
                T_Purchase_D item = purchase_D[i];

                reportItem.NumberRow = (i + 1).ToString();
                reportItem.ProductName = item.ProductName;
                reportItem.Description = item.Description;
                // Description: Edit
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                //reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID);
                reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, quantityDecimal: quantityDecimal);
                // ---------------------- End  -------------------------------
                reportItem.UnitPrice = base.GetDispUnitPtice(reportItem.Quantity, item.UnitPrice, currency.DecimalType);
                reportItem.SubTotal = base.GetDispSubTotal(item.Total, item.Quantity, item.UnitID, currency);
                reportItem.SubVat = base.GetDispSubVat(item.Vat, currency, item.VatRatio, item.VatType.ToString());
                reportItem.Remark = item.Remark;

                reportItems.Add(reportItem);
            }

            ReportDataSource reportDataSource = new ReportDataSource("Purchase", reportItems);
            localReport.DataSources.Add(reportDataSource);

            localReport.SetParameters(InitParams(purchase_H, currency));

            //Update
            using (DB db = new DB())
            {
                purchase_H.IssuedFlag = 1;
                purchase_H.IssuedUID = LoginInfo.User.ID;
                purchase_H.UpdateDate = updateDate;
                purchase_H.UpdateUID = LoginInfo.User.ID;

                Purchase_HService HService = new Purchase_HService(db);
                HService.UpdateFlag(purchase_H);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.PDF
{
    /// <summary>
    /// Class QuotationReport
    /// Creator : ISV-Giam
    /// Date    : 2014/08/08
    /// </summary>
    public class QuotationReport : BaseReport<QuotationReport>
    {
        public int GroupID { get; set; }
        public string NumberRow { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Quantity { get; set; }
        public string UnitPrice { get; set; }
        public string SubTotal { get; set; }
        public string SubVat { get; set; }
        public string Remark { get; set; }
        public string HeadLine { get; set; }
        public short HeadeLineFlg { get; set; }
    }

    /// <summary>
    /// Report Quotation
    /// Creator : ISV-Giam
    /// Date    : 2014/08/08
    /// </summary>
    public class QuotationPDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        /// <summary>
        /// Get Local Report
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public LocalReport GetLocalReport(LocalReport localReport, int id, DateTime updateDate)
        {
            localReport.EnableExternalImages = true;
            this.LoadData(localReport, id, updateDate);
            localReport.Refresh();

            return localReport;
        }

        /// <summary>
        /// Init Params For Report 
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParams(M_Currency_H currency, T_Quote_H quoteH, int allHeader)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------           
            paras.Add(new ReportParameter("imagePath", base.GetPathLogo()));

            M_Company company = base.GetCompany();
            paras.Add(new ReportParameter("title", "BẢNG BÁO GIÁ (QUOTATION)"));
            paras.Add(new ReportParameter("companyName", base.GetDispCompanyName(company.CompanyName1)));
            paras.Add(new ReportParameter("companyAddress", base.GetDispAddressMultiLine(company.companyAddress1, company.companyAddress2, company.CompanyAddress3)));
            paras.Add(new ReportParameter("companyTel", base.GetDispCompanyTel(company.Tel, company.Tel2)));
            paras.Add(new ReportParameter("companyFax", base.GetDispCompanyFax(company.FAX)));
            paras.Add(new ReportParameter("companyEmail", base.GetDispCompanyEmail(company.emailAddress)));

            //-------------------------------
            //  Header Report
            //-------------------------------
            paras.Add(new ReportParameter("customerName", quoteH.CustomerName));
            paras.Add(new ReportParameter("attnName", quoteH.ContactPerson));
            paras.Add(new ReportParameter("customerAddress", base.GetDispAddressMultiLine(quoteH.CustomerAddress1, quoteH.CustomerAddress2, quoteH.CustomerAddress3)));
            paras.Add(new ReportParameter("customerTel", quoteH.Tel));
            paras.Add(new ReportParameter("customerFax", quoteH.FAX));

            //Represent of Customer
            paras.Add(new ReportParameter("cusRepresent", base.GetRepresenter(quoteH.Approved, quoteH.Position)));
            paras.Add(new ReportParameter("cusRepresentDefault", Constant.DEFAULT_POSITION + "\n" + Constant.DEFAULT_REPRESENT));

            paras.Add(new ReportParameter("quoteNo", quoteH.QuoteNo));
            paras.Add(new ReportParameter("quoteDate", base.GetDispDate(quoteH.QuoteDate.Month, quoteH.QuoteDate.Day, quoteH.QuoteDate.Year)));
            paras.Add(new ReportParameter("expiryDate", base.GetDispDate(quoteH.ExpiryDate.Month, quoteH.ExpiryDate.Day, quoteH.ExpiryDate.Year)));
            paras.Add(new ReportParameter("preparedBy", quoteH.PreparedName));

            paras.Add(new ReportParameter("subject", quoteH.SubjectName));

            //-------------------------------
            //  Detail Report
            //-------------------------------
            paras.Add(new ReportParameter("currency", currency.MoneyCode));
            paras.Add(new ReportParameter("tax", currency.TaxName));
            paras.Add(new ReportParameter("allHeader", allHeader.ToString()));

            //-------------------------------
            //  Footer Report
            //-------------------------------            
            paras.Add(new ReportParameter("lblTotalSell", base.GetDispLblTotalSell()));
            paras.Add(new ReportParameter("totalSell", base.GetDispTotalSell(quoteH.Total, currency)));

            paras.Add(new ReportParameter("lblTotalVAT", base.GetDispLblTotalVAT(quoteH.VatRatio, currency.TaxName, quoteH.MethodVat.ToString(), quoteH.VatType.ToString())));
            paras.Add(new ReportParameter("totalVAT", base.GetDispTotalVAT(quoteH.Vat, currency, quoteH.MethodVat.ToString(), quoteH.VatType.ToString())));

            paras.Add(new ReportParameter("lblGrandTotal", base.GetDispLblGrandTotal(currency.TaxName)));
            paras.Add(new ReportParameter("grandTotal", base.GetDispGrandTotal(quoteH.GrandTotal, currency)));

            paras.Add(new ReportParameter("grandTotalVN", base.GetDispNumberStr(quoteH.GrandTotal, Language.Vietnam, currency.MoneyNameVN, currency.DecimalNameVN)));
            paras.Add(new ReportParameter("grandTotalEN", base.GetDispNumberStr(quoteH.GrandTotal, Language.English, currency.MoneyNameUS, currency.DecimalNameUS)));

            using (DB db = new DB())
            {
                Quotation_CService quotationCSer = new Quotation_CService(db);
                paras.Add(new ReportParameter("condition", quotationCSer.GetByPK(quoteH.ID).Conditions));
            }

            paras.Add(new ReportParameter("approveName", base.GetApproveNameMyanmar(quoteH.ApprovedCD)));

            paras.Add(new ReportParameter("issueName", base.GetIssueName(quoteH.PreparedCD)));

            //-------------------------------
            //  Footer Page
            //-------------------------------

            return paras;
        }

        /// <summary>
        /// Get User by code
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <returns></returns>
        private M_User GetUser(string userCD)
        {
            using (DB db = new DB())
            {
                UserService uSer = new UserService(db);

                //Get Customer
                return uSer.GetByUserCD(userCD);
            }
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="localReport"></param>
        private void LoadData(LocalReport localReport, int id, DateTime updateDate)
        {
            T_Quote_H quoteH = new T_Quote_H();
            IList<T_Quote_D_Sell> quoteD;
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            string quantityDecimal = M_Config_D.QUANTITY_DECIMAL;
            // ---------------------- End  -------------------------------
            using (DB db = new DB())
            {
                Quotation_HService quotationHSer = new Quotation_HService(db);
                quoteH = quotationHSer.GetByPK(id);

                var quotationDSellMSer = new Quotation_D_SellService(db);
                quoteD = quotationDSellMSer.GetByIDForReport(id);

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                Config_HService configSer = new Config_HService(db);
                quantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL);
                // ---------------------- End  -------------------------------
            }

            if (quoteH == null || quoteD.Count == 0) return;

            if (quoteH.MethodVat.Equals(short.Parse(M_Config_D.METHOD_VAT_EACH)))
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptQuotationItem.rdlc");
            }
            else
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptQuotationTotal.rdlc");
            }

            M_Currency_H currency = base.GetCurrencyByIDAndDate(quoteH.CurrencyID, DateTime.Now);

            List<QuotationReport> reportItems = new List<QuotationReport>();
            int numberRow = 0;
            for (int i = 0; i < quoteD.Count; i++)
            {
                QuotationReport reportItem = new QuotationReport();
                T_Quote_D_Sell item = quoteD[i];

                reportItem.HeadeLineFlg = item.HeadlineFlag;
                if (reportItem.HeadeLineFlg == 0)
                {
                    numberRow++;
                }
                reportItem.HeadLine = item.Headline;
                reportItem.NumberRow = numberRow.ToString();
                reportItem.ProductName = item.ProductName;
                reportItem.Description = item.Description;
                // Description: Edit
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                //reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, quoteH.MethodVat.ToString(), item.VatType.ToString());
                reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, quoteH.MethodVat.ToString(), item.VatType.ToString(), quantityDecimal);
                // ---------------------- End  -------------------------------
                reportItem.UnitPrice = base.GetDispUnitPtice(reportItem.Quantity, item.UnitPrice, currency.DecimalType);
                reportItem.SubTotal = base.GetDispSubTotal(item.Total, item.Quantity, item.UnitID, currency);
                reportItem.SubVat = base.GetDispSubVat(item.Vat, currency, item.VatRatio, item.VatType.ToString());
                //---------------- ISV-Giam 2015/01/09 ----------------
                if (item.Quantity == 0)
                {
                    reportItem.Quantity = string.Empty;
                    reportItem.SubVat = string.Empty;
                }
                //-----------------------------------------------------
                reportItem.Remark = item.Remark;

                reportItems.Add(reportItem);
            }

            ReportDataSource reportDataSource = new ReportDataSource("Quotation", reportItems);
            localReport.DataSources.Add(reportDataSource);

            localReport.SetParameters(InitParams(currency, quoteH, numberRow));

            //Issued
            quoteH.IssuedFlag = 1;
            quoteH.IssuedUID = LoginInfo.User.ID;
            quoteH.UpdateDate = updateDate;
            quoteH.UpdateUID = LoginInfo.User.ID;

            using (DB db = new DB())
            {
                Quotation_HService quotationHSer = new Quotation_HService(db);
                quotationHSer.UpdateFlag(quoteH);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using Microsoft.Reporting.WebForms;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.PDF
{
    /// <summary>
    /// Class SalesReport
    /// Create  : isv.thuy  
    /// Date    : 08/08/2014
    /// </summary>
    public class SalesReport : BaseReport<SalesReport>
    {
        /// <summary>
        /// Get,set GroupID
        /// </summary>
        public int GroupID { get; set; }

        /// <summary>
        /// Get,set NumberRow
        /// </summary>
        public string NumberRow { get; set; }

        /// <summary>
        /// Get,set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get,set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get,set Quantity
        /// </summary>
        public string Quantity { get; set; }

        /// <summary>
        /// Get,set UnitPrice
        /// </summary>
        public string UnitPrice { get; set; }

        /// <summary>
        /// Get,set SubTotal
        /// </summary>
        public string SubTotal { get; set; }

        /// <summary>
        /// Get,set SubVat
        /// </summary>
        public string SubVat { get; set; }

        /// <summary>
        /// Get,set Remark
        /// </summary>
        public string Remark { get; set; }
    }

    /// <summary>
    /// RptSales
    /// Create  :isv.thuy
    /// Date    :08/08/2014
    /// </summary>
    public class SalesPDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        /// <summary>
        /// Get Local Report
        /// </summary>
        /// <param name="localReport"></param>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <param name="versionUpdateDate"></param>
        /// <returns></returns>
        public LocalReport GetLocalReport(LocalReport localReport, int ID, DateTime updateDate, DateTime versionUpdateDate)
        {
            localReport.EnableExternalImages = true;            
            this.LoadData(localReport, ID, updateDate, versionUpdateDate);
            localReport.Refresh();

            return localReport;
        }

        /// <summary>
        /// Init Params For Report 
        /// </summary>
        /// <returns></returns>
        private ReportParameterCollection InitParams(T_Sales_H sales_H, M_Currency_H currency)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------           
            paras.Add(new ReportParameter("imagePath", base.GetPathLogo()));

            M_Company company = this.GetCompany();
            paras.Add(new ReportParameter("title", "BIÊN NHẬN ĐẶT HÀNG (SALES SLIP)"));
            paras.Add(new ReportParameter("companyName", base.GetDispCompanyName(company.CompanyName1)));
            paras.Add(new ReportParameter("companyAddress", base.GetDispAddressMultiLine(company.companyAddress1, company.companyAddress2, company.CompanyAddress3)));
            paras.Add(new ReportParameter("companyTel", base.GetDispCompanyTel(company.Tel, company.Tel2)));
            paras.Add(new ReportParameter("companyFax", base.GetDispCompanyFax(company.FAX)));
            paras.Add(new ReportParameter("companyEmail", base.GetDispCompanyEmail(company.emailAddress)));

            //-------------------------------
            //  Header Report
            //-------------------------------
            paras.Add(new ReportParameter("customerName", sales_H.CustomerName));
            paras.Add(new ReportParameter("attnName", sales_H.ContactPerson));
            paras.Add(new ReportParameter("customerAddress", base.GetDispAddressMultiLine(sales_H.CustomerAddress1, sales_H.CustomerAddress2, sales_H.CustomerAddress3)));
            paras.Add(new ReportParameter("customerTel", sales_H.Tel));
            paras.Add(new ReportParameter("customerFax", sales_H.FAX));

            paras.Add(new ReportParameter("salesNo", sales_H.SalesNo));
            paras.Add(new ReportParameter("salesDate", base.GetDispDate(sales_H.SalesDate.Month, sales_H.SalesDate.Day, sales_H.SalesDate.Year)));
            paras.Add(new ReportParameter("quoteNo", sales_H.QuoteNo));
            paras.Add(new ReportParameter("preparedBy", sales_H.PreparedName));

            paras.Add(new ReportParameter("subject", sales_H.SubjectName));

            //Represent of Customer
            paras.Add(new ReportParameter("cusRepresent", base.GetRepresenter(sales_H.Approved, sales_H.Position)));
            paras.Add(new ReportParameter("cusRepresentDefault", Constant.DEFAULT_POSITION + "\n" + Constant.DEFAULT_REPRESENT));

            //-------------------------------
            //  Detail Report
            //-------------------------------
            paras.Add(new ReportParameter("currency", currency.MoneyCode));
            paras.Add(new ReportParameter("tax", currency.TaxName));

            //-------------------------------
            //  Footer Report
            //-------------------------------            
            paras.Add(new ReportParameter("lblTotalSell", base.GetDispLblTotalSell()));
            paras.Add(new ReportParameter("totalSell", base.GetDispTotalSell(sales_H.Total, currency)));

            paras.Add(new ReportParameter("lblTotalVAT", base.GetDispLblTotalVAT(sales_H.VatRatio, currency.TaxName, sales_H.MethodVat.ToString(), sales_H.VatType.ToString())));
            paras.Add(new ReportParameter("totalVAT", base.GetDispTotalVAT(sales_H.Vat, currency, sales_H.MethodVat.ToString(), sales_H.VatType.ToString())));

            paras.Add(new ReportParameter("lblGrandTotal", base.GetDispLblGrandTotal(currency.TaxName)));
            paras.Add(new ReportParameter("grandTotal", base.GetDispGrandTotal(sales_H.GrandTotal, currency)));

            paras.Add(new ReportParameter("grandTotalVN", base.GetDispNumberStr(sales_H.GrandTotal, Language.Vietnam, currency.MoneyNameVN, currency.DecimalNameVN)));
            paras.Add(new ReportParameter("grandTotalEN", base.GetDispNumberStr(sales_H.GrandTotal, Language.English, currency.MoneyNameUS, currency.DecimalNameUS)));

            using (DB db = new DB())
            {
                Sales_CService CService = new Sales_CService(db);
                paras.Add(new ReportParameter("condition", CService.GetByPK(sales_H.ID).Conditions));
            }

            paras.Add(new ReportParameter("approveName", base.GetApproveNameMyanmar(sales_H.ApprovedCD)));
            paras.Add(new ReportParameter("issueName", base.GetIssueName(sales_H.PreparedCD)));

            //-------------------------------
            //  Footer Page
            //-------------------------------

            return paras;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="localReport"></param>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <param name="versionUpdateDate"></param>
        private void LoadData(LocalReport localReport, int ID, DateTime updateDate, DateTime versionUpdateDate)
        {
            T_Sales_H sales_H = new T_Sales_H();
            IList<T_Sales_D_Sell> sales_D;
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            string quantityDecimal = M_Config_D.QUANTITY_DECIMAL;
            // ---------------------- End  -------------------------------
            using (DB db = new DB())
            {
                Sales_HService HService = new Sales_HService(db);
                sales_H = HService.GetByPK(ID);

                Sales_D_SellService DService = new Sales_D_SellService(db);
                sales_D = DService.GetListByID(ID);

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                Config_HService configSer = new Config_HService(db);
                quantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL);
                // ---------------------- End  -------------------------------
            }

            if (sales_H == null || sales_D.Count == 0)
            {
                return;
            }

            if (sales_H.MethodVat.Equals(short.Parse(M_Config_D.METHOD_VAT_EACH)))
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptSalesItem.rdlc");
            }
            else
            {
                localReport.ReportPath = Server.MapPath("~/Reports/rptSalesTotal.rdlc");
            }

            M_Currency_H currency = base.GetCurrencyByIDAndDate(sales_H.CurrencyID, DateTime.Now);

            List<SalesReport> reportItems = new List<SalesReport>();
            for (int i = 0; i < sales_D.Count; i++)
            {
                SalesReport reportItem = new SalesReport();
                T_Sales_D_Sell item = sales_D[i];

                reportItem.NumberRow = (i + 1).ToString();
                reportItem.ProductName = item.ProductName;
                reportItem.Description = item.Description;
                // Description: Edit
                // Author: ISV-PHUONG
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                //reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID);
                reportItem.Quantity = base.GetDispQuantity(item.Quantity, item.UnitID, quantityDecimal: quantityDecimal);
                // ---------------------- End  -------------------------------
                reportItem.UnitPrice = base.GetDispUnitPtice(reportItem.Quantity, item.UnitPrice, currency.DecimalType);
                reportItem.SubTotal = base.GetDispSubTotal(item.Total, item.Quantity, item.UnitID, currency);
                reportItem.SubVat = base.GetDispSubVat(item.Vat, currency, item.VatRatio, item.VatType.ToString());
                reportItem.Remark = item.Remark;
                reportItems.Add(reportItem);
            }

            ReportDataSource reportDataSource = new ReportDataSource("Sales", reportItems);
            localReport.DataSources.Add(reportDataSource);

            localReport.SetParameters(InitParams(sales_H, currency));

            //Update
            using (DB db = new DB())
            {
                sales_H.IssuedFlag = 1;
                sales_H.IssuedDate = db.NowDate;
                sales_H.IssuedUID = LoginInfo.User.ID;
                sales_H.UpdateDate = updateDate;
                sales_H.UpdateUID = LoginInfo.User.ID;
                sales_H.VersionUpdateDate = versionUpdateDate;
                sales_H.VersionUpdateUID = LoginInfo.User.ID;

                Sales_HService salesHService = new Sales_HService(db);
                salesHService.UpdateFlag(sales_H);
            }
        }
    }
}
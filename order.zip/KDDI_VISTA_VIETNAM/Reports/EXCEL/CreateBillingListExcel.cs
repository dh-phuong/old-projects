﻿using System;
using System.Collections.Generic;
using NPOI.SS.UserModel;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.EXCEL
{
    public class CreateBillingListExcel : BaseExcel
    {
        #region Variable

        /// <summary>
        /// deliveryListDateFrom;
        /// </summary>
        public DateTime? billingDateFrom;

        /// <summary>
        /// deliveryDateTo
        /// </summary>
        public DateTime? billingDateTo;

        #endregion Variable

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<CreateBillingExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("CreateBillingList");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Created Billing List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList<QuotationeExcel></returns>
        private IList<CreateBillingExcel> GetListForExcel()
        {
            IList<CreateBillingExcel> results = null;

            using (DB db = new DB())
            {
                Billing_HService billing_HService = new Billing_HService(db);
                results = billing_HService.GetListForCreateBillingListExcel(billingDateFrom, billingDateTo);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            //Purchase Date
            string strBillingDate = "Billing Date: ";
            ICell cellBillingDate = row1.GetCell(0);
            string poDateFrom = string.Empty;
            string poDateTo = string.Empty;
            if (this.billingDateFrom.HasValue)
            {
                poDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.billingDateFrom.Value);
            }
            if (this.billingDateTo.HasValue)
            {
                poDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.billingDateTo.Value);
            }
            if (!string.IsNullOrEmpty(poDateFrom) || !string.IsNullOrEmpty(poDateTo))
            {
                strBillingDate = strBillingDate + poDateFrom;
                strBillingDate = strBillingDate.Trim() + " ～ ";
                strBillingDate = strBillingDate + poDateTo;
            }
            cellBillingDate.SetCellValue(strBillingDate);

            //QuoteNo
            ICell cellCreation = row1.GetCell(13);
            string creationDate = "Creation: " + DateTime.Now.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
            cellCreation.SetCellValue(creationDate);
        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<CreateBillingExcel> lstData)
        {
            int rowStart = 4;
            string format = this.GetDefaultValueQuantity();
            for (int k = 0; k < lstData.Count; k++)
            {
                this.CopyRow(wb, sheet, 3, rowStart + k);

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell PurchaseDate
                ICell cellPurchaseDate = rowTemp.GetCell(0);
                cellPurchaseDate.SetCellValue(lstData[k].BillingDateStr);

                //create cell PurchaseNo
                ICell cellPurchaseNo = rowTemp.GetCell(1);
                cellPurchaseNo.SetCellValue(lstData[k].BillingNo);

                //create cell SalesDate
                ICell cellSalesDate = rowTemp.GetCell(2);
                if (lstData[k].SalesDate == base.DATE_TIME_DEFAULT)
                {
                    cellSalesDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellSalesDate.SetCellValue(lstData[k].SalesDateStr);
                }

                //create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(3);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //create cell CustomerCD
                ICell cellCustomerCD = rowTemp.GetCell(4);
                cellCustomerCD.SetCellValue(lstData[k].CustomerCD);

                //create cell Vendor
                ICell cellCustomerName = rowTemp.GetCell(5);
                cellCustomerName.SetCellValue(lstData[k].CustomerName);

                //create cell ProductName
                ICell cellProductName = rowTemp.GetCell(6);
                cellProductName.SetCellValue(lstData[k].ProductName);

                //create cell Quantity
                ICell cellQuantity = rowTemp.GetCell(7);
                cellQuantity.SetCellValue((double)lstData[k].Quantity);

                //create cell UnitPrice
                ICell cellUnitPrice = rowTemp.GetCell(8);
                cellUnitPrice.SetCellValue((double)lstData[k].UnitPrice);

                //create cell SubTotal
                ICell cellSubTotal = rowTemp.GetCell(9);
                cellSubTotal.SetCellValue((double)lstData[k].SubTotal);

                //create cell Currency
                ICell cellCurrency = rowTemp.GetCell(10);
                cellCurrency.SetCellValue(lstData[k].Currency);

                if (lstData[k].MethodVat == short.Parse(M_Config_D.METHOD_VAT_EACH))
                {
                    //create cell VatType
                    ICell cellVatTypeName = rowTemp.GetCell(11);
                    cellVatTypeName.SetCellValue(lstData[k].VatTypeName);
                    if (lstData[k].VatType == short.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        //create cell VatRatio
                        ICell cellVatRatio = rowTemp.GetCell(12);
                        cellVatRatio.SetCellValue((double)lstData[k].VatRatio);

                        //create cell Vat
                        ICell cellVat = rowTemp.GetCell(13);
                        cellVat.SetCellValue((double)lstData[k].Vat);
                    }
                    else
                    {
                        //create cell VatRatio
                        ICell cellVatRatio = rowTemp.GetCell(12);
                        cellVatRatio.SetCellValue(string.Empty);

                        //create cell Vat
                        ICell cellVat = rowTemp.GetCell(13);
                        cellVat.SetCellValue(string.Empty);
                    }
                }
                else
                {
                    //create cell VatType
                    ICell cellVatTypeName = rowTemp.GetCell(11);
                    cellVatTypeName.SetCellValue("On Total");

                    if (lstData[k].VatTypeTotal == short.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        if (lstData[k].DecimalType == (short)ExchangeRateDecType.Decimal)
                        {
                            lstData[k].VatTotal = Utilities.Fraction.Round(this.GetFractionType(), (lstData[k].SubTotal * lstData[k].VatRatioTotal) / 100, 2);
                            //lstData[k].VatTotaltr = lstData[k].VatTotal.ToString(Constants.FMT_DECIMAL);
                        }
                        else
                        {
                            lstData[k].VatTotal = Utilities.Fraction.Round(this.GetFractionType(), (lstData[k].SubTotal * lstData[k].VatRatioTotal) / 100, 0);
                            //lstData[k].VatTotalStr = lstData[k].VatTotal.ToString(Constants.FMT_INTEGER);
                        }

                        //create cell VatRatio
                        ICell cellVatRatio = rowTemp.GetCell(12);
                        cellVatRatio.SetCellValue((double)lstData[k].VatRatioTotal);

                        //create cell Vat
                        ICell cellVat = rowTemp.GetCell(13);
                        cellVat.SetCellValue((double)lstData[k].VatTotal);
                    }
                    else
                    {
                        //create cell VatRatio
                        ICell cellVatRatio = rowTemp.GetCell(12);
                        cellVatRatio.SetCellValue(string.Empty);

                        //create cell Vat
                        ICell cellVat = rowTemp.GetCell(13);
                        cellVat.SetCellValue(string.Empty);
                    }
                }
            }

            if (lstData.Count <= 1)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 1, -1);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -1);
            }
        }

        /// <summary>
        /// GetDefaultValueQuantity
        /// </summary>
        /// <returns>format</returns>
        private string GetDefaultValueQuantity()
        {
            string format = string.Empty;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                format = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? Constants.FMT_DECIMAL : Constants.FMT_INTEGER;
            }
            return format;
        }

        /// <summary>
        /// Get Fraction Type
        /// </summary>
        /// <returns></returns>
        private FractionType GetFractionType()
        {
            using (DB db = new DB())
            {
                Config_HService configHService = new Config_HService(db);
                return (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));
            }
        }
    }
}
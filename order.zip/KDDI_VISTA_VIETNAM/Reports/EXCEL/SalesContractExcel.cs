﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

using OMS.Models;
using OMS.DAC;
using OMS.Utilities;

using NPOI.SS.UserModel;
using NPOI.SS.Util;

namespace OMS.Reports.EXCEL
{
    public class SalesContractExcel : BaseExcel
    {
        #region Contanst Excel

        private const string _start_row_detail = "START_DETAIL";
        private const string _start_row_detail2 = "START_DETAIL2";
        private const int defaultRowHeight = 200;
        private const int defaultRowHeight2 = 400;

        private const string _contract_date_key = "ContractDate";
        private const string _contract_date2_key = "ContractDate2";

        private const string _contract_no_key = "ContractNo";
        private const string _quotation_no_key = "QuotationNo";
        private const string _sales_no_key = "SalesNo";
        private const string _the_A_name_VN_key = "TheANameVN";
        private const string _the_A_name_EN_key = "TheANameEN";
        private const string _cus_address_VN_key = "CusAddressVN";
        private const string _cus_address_EN_key = "CusAddressEN";
        private const string _cus_tax_code_key = "CusTaxCode";
        //------------------ Sales Contract BDS -------------------
        private const string _cus_account_code_key = "CusAccountCode";
        //---------------------------------------------------------
        private const string _cus_tel_key = "CusTel";
        private const string _cus_fax_key = "CusFax";
        private const string _cus_represent_VN_key = "CusRepresentVN";
        private const string _cus_represent_EN_key = "CusRepresentEN";
        //------------------ Sales Contract New CETUS -------------------
        private const string _cus_position_VN_EN_key = "CusPositionVNEN";
        //---------------------------------------------------------------
        private const string _cus_position_VN_key = "CusPositionVN";
        private const string _cus_position_EN_key = "CusPositionEN";
        private const string _the_B_name_VN_key = "TheBNameVN";
        private const string _the_B_name_EN_key = "TheBNameEN";
        private const string _com_address_VN_key = "ComAddressVN";
        private const string _com_address_EN_key = "ComAddressEN";
        private const string _com_tax_code_key = "ComTaxCode";
        private const string _com_bank_and_account_code_VN_key = "ComBankAndAccountCodeVN";
        //------------------ Sales Contract New CETUS -------------------
        private const string _com_bank_and_account_code_VN2_key = "ComBankAndAccountCodeVN2";
        //--------------------------------------------------------------
        private const string _com_bank_and_account_code_EN_key = "ComBankAndAccountCodeEN";
        private const string _com_tel_key = "ComTel";
        private const string _com_fax_key = "ComFax";
        private const string _com_represent_VN_key = "ComRepresentVN";
        private const string _com_represent_EN_key = "ComRepresentEN";
        //------------------ Sales Contract New CETUS -------------------
        private const string _com_position_VN_EN_key = "ComPositionVNEN";
        //---------------------------------------------------------------
        private const string _com_position_VN_key = "ComPositionVN";
        private const string _com_position_EN_key = "ComPositionEN";
        private const string _sales_contract_no_VN_key = "SalesContractNoVN";
        private const string _sales_contract_no_EN_key = "SalesContractNoEN";

        private const string _total_sell_key = "TotalSell";
        private const string _total_sell2_key = "TotalSell2";
        private const string _total_vat_key = "TotalVAT";
        private const string _total_vat2_key = "TotalVAT2";
        private const string _grand_total_VN_key = "GrandTotalVN";
        private const string _grand_total2_VN_key = "GrandTotalVN2";
        private const string _grand_total_EN_key = "GrandTotalEN";
        private const string _currency_1_key = "Currency1";
        private const string _currency_2_key = "Currency2";
        private const string _currency_3_key = "Currency3";

        private const string _vat_key = "VAT";
        private const string _money_text_VN_key = "MoneyTextVN";
        private const string _money_text_EN_key = "MoneyTextEN";
        private const string _conditions_key = "Conditions";
        private const string _company_name1_key = "CompanyName1";
        private const string _company_name2_key = "CompanyName2";
        private const string _customer_name1_key = "CustomerName1";
        private const string _customer_name2_key = "CustomerName2";
        private const string _com_sign_position_VN_key = "ComSignPositionVN";
        private const string _com_sign_position_EN_key = "ComSignPositionEN";
        private const string _com_sign_represent_key = "ComSignRepresent";
        private const string _cus_sign_position_VN_key = "CusSignPositionVN";
        private const string _cus_sign_position_EN_key = "CusSignPositionEN";
        private const string _cus_sign_represent_key = "CusSignRepresent";

        //-------------- Sales Contract BDS -------------       

        private const string _com_account_code_VN_key = "ComAccountCodeVN";
        private const string _com_bank_name_VN_key = "ComBankNameVN";
        private const string _com_address_VN_detail_key = "ComAddressVNDetail";
        private const string _com_account_code_VN_detail_key = "ComAccountCodeVNDetail";
        private const string _com_bank_name_VN_detail_key = "ComBankNameVNDetail";

        private const string _sales_date_VN_key = "SalesDateVN";
        private const string _sales_date_EN_key = "SalesDateEN";
        private const string _sales_date_EN2_key = "SalesDateEN2";

        //--
        private const string _tien_dot1_VN_key = "TienDot1VN";
        private const string _tien_dot1_JP_key = "TienDot1JP";
        private const string _tien_dot2_VN_key = "TienDot2VN";
        private const string _tien_dot2_JP_key = "TienDot2JP";
        //-----------------------------------------------

        #endregion

        #region Variable
        public int SalesID;
        public int QuantityDecimal;
        public FractionType _fractionType;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <param name="salesContractFile"></param>
        /// <returns></returns>
        public IWorkbook OutputExcel(string salesContractFile)
        {
            //Create Sheet
            IWorkbook wb = this.CreateWorkbook(salesContractFile);

            // Get Sheet
            ISheet sheet = wb.GetSheet(salesContractFile);

            if (sheet != null)
            {
                //show data
                this.FillData(wb, sheet);
            }

            return wb;
        }

        /// <summary>
        /// Fill Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet)
        {
            IList<T_Sales_D_Sell> lstData = new List<T_Sales_D_Sell>();
            M_Company company = new M_Company();
            var currency = new M_Currency_H();
            var sales = this.GetSales(this.SalesID);
            string cond = this.GetConditions(this.SalesID);

            if (sales != null)
            {
                using (DB db = new DB())
                {
                    Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
                    lstData = sales_D_SellService.GetListByID(this.SalesID);
                    CompanyService companySer = new CompanyService(db);
                    Currency_HService currency_HService = new Currency_HService(db);
                    UnitService unitser = new UnitService(db);
                    currency = currency_HService.GetByID(sales.CurrencyID);
                    Config_DService confD = new Config_DService(db);

                    //Get Company
                    company = companySer.GetData();

                    //Get Customer
                    var customer = GetCustomerByExcel(sales.CustomerCD);

                    DateTime currentDate = sales.ContractDate;

                    if (currentDate == DATE_TIME_DEFAULT)
                    {
                        this.SetValueIndex(wb, sheet, _contract_date_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "dd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "MM", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "yyyy", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "ddd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "MMM", "]"), false, true);

                        this.SetValueIndex(wb, sheet, _contract_date2_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "dd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "MM", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "yyyy", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "ddd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, SPACE_WITH_POINT, String.Format("{0}{1}{2}", "[", "MMM", "]"), false, true);
                    }
                    else
                    {
                        this.SetValueIndex(wb, sheet, _contract_date_key, currentDate.ToString("dd"), String.Format("{0}{1}{2}", "[", "dd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, currentDate.ToString("MM"), String.Format("{0}{1}{2}", "[", "MM", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, currentDate.ToString("yyyy"), String.Format("{0}{1}{2}", "[", "yyyy", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, base.GetDayString(currentDate), String.Format("{0}{1}{2}", "[", "ddd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date_key, base.GetMonthString(currentDate), String.Format("{0}{1}{2}", "[", "MMM", "]"), false, true);

                        this.SetValueIndex(wb, sheet, _contract_date2_key, currentDate.ToString("dd"), String.Format("{0}{1}{2}", "[", "dd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, currentDate.ToString("MM"), String.Format("{0}{1}{2}", "[", "MM", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, currentDate.ToString("yyyy"), String.Format("{0}{1}{2}", "[", "yyyy", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, base.GetDayString(currentDate), String.Format("{0}{1}{2}", "[", "ddd", "]"), false, true);
                        this.SetValueIndex(wb, sheet, _contract_date2_key, base.GetMonthString(currentDate), String.Format("{0}{1}{2}", "[", "MMM", "]"), false, true);
                    }

                    var contractNo = string.IsNullOrEmpty(sales.ContractNo) ? string.Empty : sales.ContractNo;

                    //Contract No
                    this.SetValueIndex(wb, sheet, _contract_no_key, contractNo, String.Format("{0}{1}{2}", "[", _contract_no_key, "]"));

                    //Sales no
                    this.SetValueIndex(wb, sheet, _sales_no_key, sales.SalesNo, String.Format("{0}{1}{2}", "[", _sales_no_key, "]"));

                    if (customer != null)
                    {
                        //customerName Vn
                        this.SetValueIndex(wb, sheet, _the_A_name_VN_key, customer.CustomerName2, String.Format("{0}{1}{2}", "[", _the_A_name_VN_key, "]"));

                        //customerName En
                        this.SetValueIndex(wb, sheet, _the_A_name_EN_key, customer.CustomerName1, String.Format("{0}{1}{2}", "[", _the_A_name_EN_key, "]"));

                        //customerName Vn
                        this.SetValueIndex(wb, sheet, _customer_name2_key, customer.CustomerName2, String.Format("{0}{1}{2}", "[", _customer_name2_key, "]"));

                        //customerName En
                        this.SetValueIndex(wb, sheet, _customer_name1_key, sales.CustomerName, String.Format("{0}{1}{2}", "[", _customer_name1_key, "]"));

                        //taxcode
                        this.SetValueIndex(wb, sheet, _cus_tax_code_key, customer.TAXCode, String.Format("{0}{1}{2}", "[", _cus_tax_code_key, "]"));

                        //---------------------- BDS ---------------------
                        //AccountCode
                        this.SetValueIndex(wb, sheet, _cus_account_code_key, customer.AccountCode, String.Format("{0}{1}{2}", "[", _cus_account_code_key, "]"));
                        //-------------------------------------------------

                        //Represent
                        this.SetValueIndex(wb, sheet, _cus_represent_VN_key, customer.Represent, String.Format("{0}{1}{2}", "[", _cus_represent_VN_key, "]"));

                        //Represent
                        this.SetValueIndex(wb, sheet, _cus_represent_EN_key, customer.Represent, String.Format("{0}{1}{2}", "[", _cus_represent_EN_key, "]"));

                        string position = string.Format("{0} / {1}", customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' });

                        //position VNEN
                        this.SetValueIndex(wb, sheet, _cus_position_VN_EN_key, position, String.Format("{0}{1}{2}", "[", _cus_position_VN_EN_key, "]"));

                        //position VN
                        this.SetValueIndex(wb, sheet, _cus_position_VN_key, customer.Position2, String.Format("{0}{1}{2}", "[", _cus_position_VN_key, "]"));

                        //position EN
                        this.SetValueIndex(wb, sheet, _cus_position_EN_key, customer.Position1, String.Format("{0}{1}{2}", "[", _cus_position_EN_key, "]"));

                        //position VN
                        this.SetValueIndex(wb, sheet, _cus_sign_position_VN_key, customer.Position2, String.Format("{0}{1}{2}", "[", _cus_sign_position_VN_key, "]"));

                        //position EN
                        this.SetValueIndex(wb, sheet, _cus_sign_position_EN_key, customer.Position1, String.Format("{0}{1}{2}", "[", _cus_sign_position_EN_key, "]"));

                        //Represent
                        this.SetValueIndex(wb, sheet, _cus_sign_represent_key, customer.Represent, String.Format("{0}{1}{2}", "[", _cus_sign_represent_key, "]"));

                        //tel
                        this.SetValueIndex(wb, sheet, _cus_tel_key, customer.Tel, String.Format("{0}{1}{2}", "[", _cus_tel_key, "]"));

                        //fax
                        this.SetValueIndex(wb, sheet, _cus_fax_key, customer.FAX, String.Format("{0}{1}{2}", "[", _cus_fax_key, "]"));

                        var addressEn = customer.CustomerAddress1 + SPACE_EN + customer.CustomerAddress2 + SPACE_EN + customer.CustomerAddress3;
                        var addressVn = customer.CustomerAddress4 + SPACE_EN + customer.CustomerAddress5 + SPACE_EN + customer.CustomerAddress6;

                        //address VN
                        this.SetValueIndex(wb, sheet, _cus_address_VN_key, addressVn, String.Format("{0}{1}{2}", "[", _cus_address_VN_key, "]"));

                        //address EN
                        this.SetValueIndex(wb, sheet, _cus_address_EN_key, addressEn, String.Format("{0}{1}{2}", "[", _cus_address_EN_key, "]"));
                    }
                    // Description: Add
                    // Author: ISV-PHUONG
                    // Date  : 2014/12/05
                    // ---------------------- Start ------------------------------
                    else
                    {
                        //customerName Vn
                        this.SetValueIndex(wb, sheet, _the_A_name_VN_key, string.Empty, String.Format("{0}{1}{2}", "[", _the_A_name_VN_key, "]"));

                        //customerName En
                        this.SetValueIndex(wb, sheet, _the_A_name_EN_key, sales.CustomerName, String.Format("{0}{1}{2}", "[", _the_A_name_EN_key, "]"));

                        //customerName Vn
                        this.SetValueIndex(wb, sheet, _customer_name2_key, string.Empty, String.Format("{0}{1}{2}", "[", _customer_name2_key, "]"));

                        //customerName En
                        this.SetValueIndex(wb, sheet, _customer_name1_key, sales.CustomerName, String.Format("{0}{1}{2}", "[", _customer_name1_key, "]"));

                        //taxcode
                        this.SetValueIndex(wb, sheet, _cus_tax_code_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_tax_code_key, "]"));

                        //---------------------- BDS ---------------------
                        //AccountCode
                        this.SetValueIndex(wb, sheet, _cus_account_code_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_account_code_key, "]"));
                        //-------------------------------------------------

                        //Represent VN
                        this.SetValueIndex(wb, sheet, _cus_represent_VN_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_represent_VN_key, "]"));

                        //Represent EN
                        this.SetValueIndex(wb, sheet, _cus_represent_EN_key, sales.Approved, String.Format("{0}{1}{2}", "[", _cus_represent_EN_key, "]"));

                        this.SetValueIndex(wb, sheet, _cus_position_VN_EN_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_position_VN_EN_key, "]"));

                        //position VN
                        this.SetValueIndex(wb, sheet, _cus_position_VN_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_position_VN_key, "]"));

                        //position EN
                        this.SetValueIndex(wb, sheet, _cus_position_EN_key, sales.Position, String.Format("{0}{1}{2}", "[", _cus_position_EN_key, "]"));

                        //position VN
                        this.SetValueIndex(wb, sheet, _cus_sign_position_VN_key, string.Empty, String.Format("{0}{1}{2}", "[", _cus_sign_position_VN_key, "]"));

                        //position EN
                        this.SetValueIndex(wb, sheet, _cus_sign_position_EN_key, sales.Position, String.Format("{0}{1}{2}", "[", _cus_sign_position_EN_key, "]"));

                        //Represent
                        this.SetValueIndex(wb, sheet, _cus_sign_represent_key, sales.Approved, String.Format("{0}{1}{2}", "[", _cus_sign_represent_key, "]"));

                        //tel
                        this.SetValueIndex(wb, sheet, _cus_tel_key, sales.Tel, String.Format("{0}{1}{2}", "[", _cus_tel_key, "]"));

                        //fax
                        this.SetValueIndex(wb, sheet, _cus_fax_key, sales.FAX, String.Format("{0}{1}{2}", "[", _cus_fax_key, "]"));

                        var addressEn = sales.CustomerAddress1 + SPACE_EN + sales.CustomerAddress2 + SPACE_EN + sales.CustomerAddress3;
                        var addressVn = string.Empty;

                        //address VN
                        this.SetValueIndex(wb, sheet, _cus_address_VN_key, addressVn, String.Format("{0}{1}{2}", "[", _cus_address_VN_key, "]"));

                        //address EN
                        this.SetValueIndex(wb, sheet, _cus_address_EN_key, addressEn, String.Format("{0}{1}{2}", "[", _cus_address_EN_key, "]"));
                    }
                    // ---------------------- End  -------------------------------

                    //CompanyName VN
                    this.SetValueIndex(wb, sheet, _the_B_name_VN_key, company.CompanyName2, String.Format("{0}{1}{2}", "[", _the_B_name_VN_key, "]"));

                    //CompanyName EM
                    this.SetValueIndex(wb, sheet, _the_B_name_EN_key, company.CompanyName1, String.Format("{0}{1}{2}", "[", _the_B_name_EN_key, "]"));

                    //address VN
                    var addressComVn = company.CompanyAddress4 + SPACE_EN + company.CompanyAddress5 + SPACE_EN + company.CompanyAddress6;

                    //address EN
                    var addressComEn = company.CompanyAddress1 + SPACE_EN + company.CompanyAddress2 + SPACE_EN + company.CompanyAddress3;
                    this.SetValueIndex(wb, sheet, _com_address_VN_key, addressComVn, String.Format("{0}{1}{2}", "[", _com_address_VN_key, "]"));

                    //---------- Sales Contract BDS -----------
                    this.SetValueIndex(wb, sheet, _com_address_VN_detail_key, addressComVn, String.Format("{0}{1}{2}", "[", _com_address_VN_detail_key, "]"));
                    //-----------------------------------------

                    this.SetValueIndex(wb, sheet, _com_address_EN_key, addressComEn, String.Format("{0}{1}{2}", "[", _com_address_EN_key, "]"));

                    //TAXcode
                    this.SetValueIndex(wb, sheet, _com_tax_code_key, company.TAXCode, String.Format("{0}{1}{2}", "[", _com_tax_code_key, "]"));

                    //so tai khoan
                    this.SetValueIndex(wb, sheet, _com_bank_and_account_code_VN_key, company.CompanyBank.Trim() + " " + company.AccountCode.Trim(), String.Format("{0}{1}{2}", "[", _com_bank_and_account_code_VN_key, "]"));

                    //---------- Sales Contract BDS -----------
                    //Ngan hang
                    this.SetValueIndex(wb, sheet, _com_bank_name_VN_key, company.CompanyBank.Trim(), String.Format("{0}{1}{2}", "[", _com_bank_name_VN_key, "]"));
                    this.SetValueIndex(wb, sheet, _com_bank_name_VN_detail_key, company.CompanyBank.Trim(), String.Format("{0}{1}{2}", "[", _com_bank_name_VN_detail_key, "]"));

                    //Tai khoan
                    this.SetValueIndex(wb, sheet, _com_account_code_VN_key, company.AccountCode.Trim(), String.Format("{0}{1}{2}", "[", _com_account_code_VN_key, "]"));
                    this.SetValueIndex(wb, sheet, _com_account_code_VN_detail_key, company.AccountCode.Trim(), String.Format("{0}{1}{2}", "[", _com_account_code_VN_detail_key, "]"));
                    //-----------------------------------------

                    //account
                    this.SetValueIndex(wb, sheet, _com_bank_and_account_code_VN2_key, company.AccountCode.Trim() + " - " + company.CompanyBank.Trim(), String.Format("{0}{1}{2}", "[", _com_bank_and_account_code_VN2_key, "]"));

                    //account
                    this.SetValueIndex(wb, sheet, _com_bank_and_account_code_EN_key, company.CompanyBank.Trim() + " " + company.AccountCode.Trim(), String.Format("{0}{1}{2}", "[", _com_bank_and_account_code_EN_key, "]"));

                    //tel
                    this.SetValueIndex(wb, sheet, _com_tel_key, company.Tel, String.Format("{0}{1}{2}", "[", _com_tel_key, "]"));

                    //fax
                    this.SetValueIndex(wb, sheet, _com_fax_key, company.FAX, String.Format("{0}{1}{2}", "[", _com_fax_key, "]"));

                    //Represent
                    this.SetValueIndex(wb, sheet, _com_represent_VN_key, company.Represent, String.Format("{0}{1}{2}", "[", _com_represent_VN_key, "]"));

                    //Represent
                    this.SetValueIndex(wb, sheet, _com_represent_EN_key, company.Represent, String.Format("{0}{1}{2}", "[", _com_represent_EN_key, "]"));

                    string comPosition = string.Format("{0} / {1}", company.Position2, company.Position).Trim(new char[] { ' ', '/' });

                    //position
                    this.SetValueIndex(wb, sheet, _com_position_VN_EN_key, company.Position2, String.Format("{0}{1}{2}", "[", _com_position_VN_EN_key, "]"));

                    //position
                    this.SetValueIndex(wb, sheet, _com_position_VN_key, company.Position2, String.Format("{0}{1}{2}", "[", _com_position_VN_key, "]"));

                    //position
                    this.SetValueIndex(wb, sheet, _com_position_VN_key, company.Position2, String.Format("{0}{1}{2}", "[", _com_position_VN_key, "]"));

                    //position
                    this.SetValueIndex(wb, sheet, _com_position_EN_key, company.Position, String.Format("{0}{1}{2}", "[", _com_position_EN_key, "]"));
                    if (string.IsNullOrEmpty(sales.QuoteNo))
                    {
                        //quotation No
                        this.SetValueIndex(wb, sheet, _quotation_no_key, string.Empty, String.Format("{0}{1}{2}", "[", _quotation_no_key, "]"));

                        //hopdong
                        this.SetValueIndex(wb, sheet, _sales_contract_no_VN_key, "theo số biên nhận " + sales.SalesNo, String.Format("{0}{1}{2}", "[", _sales_contract_no_VN_key, "]"));

                        //sales contract
                        this.SetValueIndex(wb, sheet, _sales_contract_no_EN_key, "SalesNo " + sales.SalesNo, String.Format("{0}{1}{2}", "[", _sales_contract_no_EN_key, "]"));
                    }
                    else
                    {
                        //quotation No
                        this.SetValueIndex(wb, sheet, _quotation_no_key, sales.QuoteNo, String.Format("{0}{1}{2}", "[", _quotation_no_key, "]"));

                        //hopdong
                        this.SetValueIndex(wb, sheet, _sales_contract_no_VN_key, "theo số báo giá " + sales.QuoteNo, String.Format("{0}{1}{2}", "[", _sales_contract_no_VN_key, "]"));

                        //sales contract
                        this.SetValueIndex(wb, sheet, _sales_contract_no_EN_key, "QuoteNo " + sales.QuoteNo, String.Format("{0}{1}{2}", "[", _sales_contract_no_EN_key, "]"));
                    }
                    //-------------------------------------------Start List detail Sales Contract----------------------------------
                    var format = string.Empty;
                    var decimalDigit = 0;
                    if ((short)currency.DecimalType == (int)ExchangeRateDecType.Decimal)
                    {
                        format = Constants.FMT_DECIMAL;
                        decimalDigit = 2;
                    }
                    else
                    {
                        format = Constants.FMT_INTEGER;
                        decimalDigit = 0;
                    }

                    IName range = wb.GetName(_start_row_detail);
                    if (range != null && !range.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                        && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName)))
                    {
                        CellReference cellRef = new CellReference(range.RefersToFormula);

                        string numberFormat = string.Format("N{0}", this.QuantityDecimal);
                        this.SetDataSalesContractDetail(wb, sheet, range, lstData, format, decimalDigit, sales, confD, unitser);
                    }
                    //-------------------------------------------Start List detail Sales Contract CETUS----------------------------------

                    IName range2 = wb.GetName(_start_row_detail2);
                    if (range2 != null && !range2.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                        && !range2.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName)))
                    {
                        CellReference cellRef = new CellReference(range2.RefersToFormula);

                        string numberFormat = string.Format("N{0}", this.QuantityDecimal);
                        this.SetDataSalesContractDetail2(wb, sheet, range2, lstData, format, decimalDigit, sales, confD, unitser);
                    }
                    //-------------------------------------------End List detail Sales Contract CETUS----------------------------------
                    //-------------------------------------------End List detail Sales Contract----------------------------------

                    //-------------------------------------------Start Total List detail Sales Contract----------------------------------
                    var vatTotal = sales.Vat;
                    var grandTotal = sales.Total;
                    var totalAmount = sales.GrandTotal;

                    //currency
                    this.SetValueIndex(wb, sheet, _currency_2_key, currency.MoneyCode, String.Format("{0}{1}{2}", "[", _currency_2_key, "]"));

                    //vat
                    //this.SetValueIndex(wb, sheet, _total_vat_key, vatTotal.ToString(format), String.Format("{0}{1}{2}", "[", _total_vat_key, "]"));
                    SetValueDouble(wb, sheet, _total_vat_key, (double)vatTotal);

                    //total
                    //this.SetValueIndex(wb, sheet, _total_sell_key, grandTotal.ToString(format), String.Format("{0}{1}{2}", "[", _total_sell_key, "]"));
                    SetValueDouble(wb, sheet, _total_sell_key, (double)grandTotal);

                    //GrandTotal
                    //this.SetValueIndex(wb, sheet, _grand_total_VN_key, totalAmount.ToString(format), String.Format("{0}{1}{2}", "[", _grand_total_VN_key, "]"));
                    SetValueDouble(wb, sheet, _grand_total_VN_key, (double)totalAmount);

                    var grandTotal2 = sales.Total;

                    var vatTotal2 = sales.Vat;

                    var totalAmount2 = sales.GrandTotal;

                    //vat
                    //this.SetValueIndex(wb, sheet, _total_vat2_key, vatTotal2.ToString(format) + " " + currency.MoneyCode, String.Format("{0}{1}{2}", "[", _total_vat2_key, "]"));
                    SetValueDouble(wb, sheet, _total_vat2_key, (double)vatTotal2);

                    //total
                    //this.SetValueIndex(wb, sheet, _total_sell2_key, grandTotal2.ToString(format) + " " + currency.MoneyCode, String.Format("{0}{1}{2}", "[", _total_sell2_key, "]"));
                    SetValueDouble(wb, sheet, _total_sell2_key, (double)grandTotal2);

                    //GrandTotal
                    //this.SetValueIndex(wb, sheet, _grand_total2_VN_key, totalAmount2.ToString(format) + " " + currency.MoneyCode, String.Format("{0}{1}{2}", "[", _grand_total2_VN_key, "]"));
                    SetValueDouble(wb, sheet, _grand_total2_VN_key, (double)totalAmount2);

                    //-------------------------------------------End Total List detail Sales Contract----------------------------------

                    //---------- Sales Contract BDS -----------
                    //this.SetValueIndex(wb, sheet, _grand_total_EN_key, totalAmount.ToString(format), String.Format("{0}{1}{2}", "[", _grand_total_EN_key, "]"));
                    SetValueDouble(wb, sheet, _grand_total_EN_key, (double)totalAmount);
                    //-----------------------------------------

                    //currency
                    this.SetValueIndex(wb, sheet, _currency_1_key, currency.MoneyCode, String.Format("{0}{1}{2}", "[", _currency_1_key, "]"));

                    //currency
                    this.SetValueIndex(wb, sheet, _currency_3_key, currency.MoneyCode, String.Format("{0}{1}{2}", "[", _currency_3_key, "]"));
                    var totalAmountEnDisp = base.GetDispNumberStr(totalAmount, Language.English, currency.MoneyNameUS, currency.DecimalNameUS);
                    var totalAmountVnDisp = base.GetDispNumberStr(totalAmount, Language.Vietnam, currency.MoneyNameVN, currency.DecimalNameVN);

                    //Money VN
                    this.SetValueIndex(wb, sheet, _money_text_VN_key, totalAmountVnDisp, String.Format("{0}{1}{2}", "[", _money_text_VN_key, "]"));

                    //Money EN
                    this.SetValueIndex(wb, sheet, _money_text_EN_key, totalAmountEnDisp, String.Format("{0}{1}{2}", "[", _money_text_EN_key, "]"));

                    //------------------start condition--------------------
                    this.SetValueIndex(wb, sheet, _conditions_key, cond, String.Format("{0}{1}{2}", "[", _conditions_key, "]"));
                    IName rangeCond = wb.GetName(_conditions_key);
                    if (rangeCond != null && !rangeCond.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                        && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName)))
                    {
                        CellReference cellRefCond = new CellReference(rangeCond.RefersToFormula);
                        IRow rowCond = sheet.GetRow(cellRefCond.Row);
                        ICell cellCond = rowCond.GetCell(cellRefCond.Col);
                        var enterList = cond.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                        cellCond.Row.Height = this.GetHeight(enterList, enterList.Length, 174, defaultRowHeight);
                    }
                    //------------------end condition--------------------

                    //CompanyName2
                    this.SetValueIndex(wb, sheet, _company_name2_key, company.CompanyName2, String.Format("{0}{1}{2}", "[", _company_name2_key, "]"));

                    //CompanyName1
                    this.SetValueIndex(wb, sheet, _company_name1_key, company.CompanyName1, String.Format("{0}{1}{2}", "[", _company_name1_key, "]"));

                    //Position2
                    this.SetValueIndex(wb, sheet, _com_sign_position_VN_key, company.Position2, String.Format("{0}{1}{2}", "[", _com_sign_position_VN_key, "]"));

                    //Position
                    this.SetValueIndex(wb, sheet, _com_sign_position_EN_key, company.Position, String.Format("{0}{1}{2}", "[", _com_sign_position_EN_key, "]"));

                    //Represent
                    this.SetValueIndex(wb, sheet, _com_sign_represent_key, company.Represent, String.Format("{0}{1}{2}", "[", _com_sign_represent_key, "]"));

                    //Sales Date
                    var salesDateVN = string.Empty;
                    salesDateVN = sales.SalesDate == DATE_TIME_DEFAULT ? SPACE_WITH_POINT : sales.SalesDate.ToString(Constants.FMT_DATE);
                    this.SetValueIndex(wb, sheet, _sales_date_VN_key, salesDateVN, String.Format("{0}{1}{2}", "[", "BeginDate", "]"));
                    this.SetValueIndex(wb, sheet, _sales_date_EN2_key, salesDateVN, String.Format("{0}{1}{2}", "[", "BeginDate", "]"));

                    var salesDateJP = string.Empty;
                    salesDateJP = sales.SalesDate == DATE_TIME_DEFAULT ? SPACE_WITH_POINT : sales.SalesDate.ToString(Constants.FMT_YMD_JP);
                    this.SetValueIndex(wb, sheet, _sales_date_EN_key, salesDateJP, String.Format("{0}{1}{2}", "[", "BeginDate", "]"));

                    //InspectionDate
                    this.SetValueIndex(wb, sheet, _sales_date_VN_key, SPACE_WITH_POINT_DATE, String.Format("{0}{1}{2}", "[", "EndDate", "]"));
                    this.SetValueIndex(wb, sheet, _sales_date_EN_key, SPACE_WITH_POINT_DATE, String.Format("{0}{1}{2}", "[", "EndDate", "]"));
                    this.SetValueIndex(wb, sheet, _sales_date_EN2_key, SPACE_WITH_POINT_DATE, String.Format("{0}{1}{2}", "[", "EndDate", "]"));
                }
            }
        }

        /// <summary>
        /// Get Sales
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Sales
                return sales_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Get condition
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private string GetConditions(int headerID)
        {
            using (DB db = new DB())
            {
                Sales_CService sales_CService = new Sales_CService(db);
                var salesC = sales_CService.GetByPK(headerID);

                return salesC.Conditions;
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerByExcel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }


        private void SetValueDouble(IWorkbook wb, ISheet sheet, string keyMap, Object value)
        {
            IName range = wb.GetName(keyMap);
            if (range != null && (!range.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName))))
            {
                CellReference cellRef = new CellReference(range.RefersToFormula);
                IRow row = sheet.GetRow(cellRef.Row);
                ICell cell = row.GetCell(cellRef.Col);

                cell.SetCellValue((double)value);
            }
        }

        /// <summary>
        /// Set Data Sales Contract Detail Grid
        /// </summary>
        /// <param name="wb">wb</param>
        /// <param name="sheet">sheet</param>
        /// <param name="range">range</param>
        /// <param name="lstData">lstData</param>
        /// <param name="format">format</param>
        /// <param name="decimalDigit">decimalDigit</param>
        /// <param name="sales">sales</param>
        /// <param name="confD">confD</param>
        /// <param name="unitser">unitser</param>
        private void SetDataSalesContractDetail(IWorkbook wb, ISheet sheet, IName range, IList<T_Sales_D_Sell> lstData, string format, int decimalDigit, T_Sales_H sales, Config_DService confD, UnitService unitser)
        {
            CellReference cellRef = new CellReference(range.RefersToFormula);
            string numberFormat = string.Format("N{0}", this.QuantityDecimal);
            int indexRow = 0;
            //-------------Start Get Style Row------------------
            IRow rowStyle = sheet.GetRow(cellRef.Row);
            ICell cell0 = rowStyle.GetCell(0);
            ICell cell1 = rowStyle.GetCell(1);
            ICell cell2 = rowStyle.GetCell(2);
            ICell cell3 = rowStyle.GetCell(3);
            ICell cell4 = rowStyle.GetCell(4);
            ICell cell5 = rowStyle.GetCell(5);
            ICell cell6 = rowStyle.GetCell(6);
            ICell cell7 = rowStyle.GetCell(7);
            ICell cell8 = rowStyle.GetCell(8);
            //-------------End Get Style Row------------------

            for (int k = 0; k < lstData.Count; k++)
            {
                M_Unit unit = unitser.GetByID(lstData[k].UnitID);
                indexRow = k + cellRef.Row;
                if (k > 0)
                {
                    this.CopyRow(wb, sheet, cellRef.Row, indexRow);
                }
                IRow row = sheet.GetRow(indexRow);

                ICell cellNo = row.GetCell(0);
                cellNo.SetCellValue(k + 1);
                cellNo.CellStyle = cell0.CellStyle;

                ICell cellModel1 = row.GetCell(1);
                ICell cellModel2 = row.GetCell(2);
                ICell cellModel3 = row.GetCell(3);
                cellModel1.CellStyle = cell1.CellStyle;
                cellModel2.CellStyle = cell2.CellStyle;
                cellModel3.CellStyle = cell3.CellStyle;
                var enterListDescript = lstData[k].Description.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                IName rangeTotal = wb.GetName(_total_sell_key);
                CellReference cellRefTotal = new CellReference(rangeTotal.RefersToFormula);
                IRow rowRefTotal = sheet.GetRow(cellRefTotal.Row);
                if (string.IsNullOrEmpty(lstData[k].Description))
                {
                    cellModel1.SetCellValue(lstData[k].ProductName);
                    row.Height = rowRefTotal.Height;
                }
                else
                {
                    cellModel1.SetCellValue(lstData[k].ProductName + "\n" + lstData[k].Description);
                    row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight);
                }

                ICell cellQual = row.GetCell(4);
                cellQual.SetCellValue((double)lstData[k].Quantity);
                cellQual.CellStyle = cell4.CellStyle;

                ICell cellUnit = row.GetCell(5);
                cellUnit.SetCellValue(unit.UnitName);
                cellUnit.CellStyle = cell5.CellStyle;

                ICell cellUnitPrice = row.GetCell(6);
                cellUnitPrice.SetCellValue((double)lstData[k].UnitPrice);
                cellUnitPrice.CellStyle = cell6.CellStyle;

                ICell cellAmount = row.GetCell(7);
                cellAmount.SetCellValue((double)lstData[k].Total);
                cellAmount.CellStyle = cell7.CellStyle;

                //var vatAmount = Utilities.Fraction.Round(this._fractionType, lstData[k].Total * lstData[k].VatRatio, 2);
                ICell cellVat = row.GetCell(8);
                cellVat.CellStyle = cell8.CellStyle;

                if (lstData[k].VatRatio != 0)
                {
                    cellVat.SetCellValue((double)lstData[k].VatRatio / 100);
                }
                else
                {
                    if (lstData[k].VatType == 255)
                    {

                        if (sales.VatType == (int)VATFlg.Exclude)
                        {
                            cellVat.SetCellValue((double)sales.VatRatio / 100);
                        }
                        else if (sales.VatType == (int)VATFlg.Free)
                        {
                            cellVat.SetCellValue(confD.GetValue2(M_Config_H.CONFIG_CD_VAT_TYPE, sales.VatType));
                            if (string.IsNullOrEmpty(lstData[k].Description))
                            {
                                row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight);
                            }
                        }
                        else
                        {
                            cellVat.SetCellValue(confD.GetValue2(M_Config_H.CONFIG_CD_VAT_TYPE, sales.VatType));
                            if (string.IsNullOrEmpty(lstData[k].Description))
                            {
                                row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight);
                            }
                        }
                    }
                    else
                    {
                        if (lstData[k].VatType == (int)VATFlg.Exclude)
                        {
                            cellVat.SetCellValue((double)lstData[k].VatRatio);
                        }
                        else if (lstData[k].VatType == (int)VATFlg.Free)
                        {
                            cellVat.SetCellValue(confD.GetValue2(M_Config_H.CONFIG_CD_VAT_TYPE, lstData[k].VatType));
                            if (string.IsNullOrEmpty(lstData[k].Description))
                            {
                                row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight);
                            }
                        }
                        else
                        {
                            cellVat.SetCellValue(confD.GetValue2(M_Config_H.CONFIG_CD_VAT_TYPE, lstData[k].VatType));
                            if (string.IsNullOrEmpty(lstData[k].Description))
                            {
                                row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Set Data Sales Contract Detail Grid
        /// </summary>
        /// <param name="wb">wb</param>
        /// <param name="sheet">sheet</param>
        /// <param name="range">range</param>
        /// <param name="lstData">lstData</param>
        /// <param name="format">format</param>
        /// <param name="decimalDigit">decimalDigit</param>
        /// <param name="sales">sales</param>
        /// <param name="confD">confD</param>
        /// <param name="unitser">unitser</param>
        private void SetDataSalesContractDetail2(IWorkbook wb, ISheet sheet, IName range, IList<T_Sales_D_Sell> lstData, string format, int decimalDigit, T_Sales_H sales, Config_DService confD, UnitService unitser)
        {
            CellReference cellRef = new CellReference(range.RefersToFormula);
            string numberFormat = string.Format("N{0}", this.QuantityDecimal);
            int indexRow = 0;
            //-------------Start Get Style Row------------------
            IRow rowStyle = sheet.GetRow(cellRef.Row);
            ICell cell0 = rowStyle.GetCell(0);
            ICell cell1 = rowStyle.GetCell(1);
            ICell cell2 = rowStyle.GetCell(2);
            ICell cell3 = rowStyle.GetCell(3);
            ICell cell4 = rowStyle.GetCell(4);
            ICell cell5 = rowStyle.GetCell(5);
            ICell cell6 = rowStyle.GetCell(6);
            ICell cell7 = rowStyle.GetCell(7);
            //-------------End Get Style Row------------------

            for (int k = 0; k < lstData.Count; k++)
            {
                M_Unit unit = unitser.GetByID(lstData[k].UnitID);
                indexRow = k + cellRef.Row;
                if (k > 0)
                {
                    this.CopyRow(wb, sheet, cellRef.Row, indexRow);
                }
                IRow row = sheet.GetRow(indexRow);

                ICell cellNo = row.GetCell(0);
                cellNo.SetCellValue(k + 1);
                cellNo.CellStyle = cell0.CellStyle;

                ICell cellModel1 = row.GetCell(1);
                ICell cellModel2 = row.GetCell(2);
                ICell cellModel3 = row.GetCell(3);
                cellModel1.CellStyle = cell1.CellStyle;
                cellModel2.CellStyle = cell2.CellStyle;
                cellModel3.CellStyle = cell3.CellStyle;
                var enterListDescript = lstData[k].Description.Split(new string[] { Environment.NewLine }, StringSplitOptions.None);
                IName rangeTotal = wb.GetName(_total_sell2_key);
                CellReference cellRefTotal = new CellReference(rangeTotal.RefersToFormula);
                IRow rowRefTotal = sheet.GetRow(cellRefTotal.Row);
                if (string.IsNullOrEmpty(lstData[k].Description))
                {
                    cellModel1.SetCellValue(lstData[k].ProductName);
                    row.Height = 800;
                }
                else
                {
                    cellModel1.SetCellValue(lstData[k].ProductName + "\n" + lstData[k].Description);
                    row.Height = this.GetHeight(enterListDescript, enterListDescript.Length + 1, 55, defaultRowHeight2);
                }

                ICell cellQual = row.GetCell(4);
                cellQual.SetCellValue(lstData[k].Quantity.ToString(numberFormat));
                cellQual.CellStyle = cell4.CellStyle;

                ICell cellUnit = row.GetCell(5);
                cellUnit.SetCellValue(unit.UnitName);
                cellUnit.CellStyle = cell5.CellStyle;

                ICell cellUnitPrice = row.GetCell(6);
                cellUnitPrice.SetCellValue(lstData[k].UnitPrice.ToString(format));
                cellUnitPrice.CellStyle = cell6.CellStyle;

                ICell cellAmount = row.GetCell(7);
                cellAmount.SetCellValue(lstData[k].Total.ToString(format));
                cellAmount.CellStyle = cell7.CellStyle;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NPOI.SS.UserModel;
using OMS.DAC;
using OMS.Utilities;
using OMS.Models;
using NPOI.SS.Util;

namespace OMS.Reports.EXCEL
{
    public class AcceptanceReportExcel : BaseExcel
    {
        #region Contanst Excel

        #region Constant Acceptance Report
        private const string _CompanyName = "CompanyName";
        private const string _CompanyInfo = "CompanyInfo";

        //ISV report
        private const string _CompanyInfo1 = "CompanyInfo1";
        private const string _CompanyInfo2 = "CompanyInfo2";

        private const string _CusName_Vn = "CusName_Vn";
        private const string _CusName_En = "CusName_En";
        private const string _CusAddress_Vn = "CusAddress_Vn";
        private const string _CusAddress_En = "CusAddress_En";
        private const string _CusTel_En = "CusTel_En";
        private const string _CusFax_En = "CusFax_En";
        private const string _CusRepresent_Vn = "CusRepresent_Vn";
        private const string _CusRepresent_En = "CusRepresent_En";
        private const string _CusTitle_Vn = "CusTitle_Vn";
        private const string _CusTitle_En = "CusTitle_En";

        private const string _ComName_Vn = "ComName_Vn";
        private const string _ComName_En = "ComName_En";
        private const string _ComAddress_Vn = "ComAddress_Vn";
        private const string _ComAddress_En = "ComAddress_En";
        private const string _ComTel_En = "ComTel_En";
        private const string _ComFax_En = "ComFax_En";
        private const string _ComRepresented_Vn = "ComRepresented_Vn";
        private const string _ComRepresented_En = "ComRepresented_En";
        private const string _ComTitle_Vn = "ComTitle_Vn";
        private const string _ComTitle_En = "ComTitle_En";

        private const string _Description_Vn = "Description_Vn";
        private const string _Description_En = "Description_En";
        private const string _ContractNo = "ContractNo";
        private const string _SalesNo = "SalesNo";
        private const string _ContractDate = "ContractDate";
        private const string _DeliPlace = "DeliPlace";
        private const string _SetUpDate = "SetUpDate";

        private const string _ComNameBottomVn = "ComNameBottom_Vn";
        private const string _ComNameBottomEn = "ComNameBottom_En";

        private const string _CusNameBottomVn = "CusNameBottom_Vn";
        private const string _CusNameBottomEn = "CusNameBottom_En";

        private const string _ComTitleBottomVn = "ComTitleBottom_Vn";
        private const string _ComTitleBottomEn = "ComTitleBottom_En";
        private const string _ComReprentedBottom = "ComReprentedBottom";

        private const string _CusTitleBottomVn = "CusTitleBottom_Vn";
        private const string _CusTitleBottomEn = "CusTitleBottom_En";
        private const string _CusReprentedBottom = "CusReprentedBottom";

        #endregion

        #endregion

        #region Variable

        public int DataID;
        
        #endregion

        #region Method
        /// <summary>
        /// Output Excel
        /// </summary>
        /// <param name="salesContractFile"></param>
        /// <returns></returns>
        public IWorkbook OutputExcel(string acceptanceReportFile)
        {
            //Create Sheet
            IWorkbook wb = this.CreateWorkbook(acceptanceReportFile);

            // Get Sheet
            ISheet sheet = wb.GetSheet(acceptanceReportFile);

            if (sheet != null)
            {
                //Fill data
                this.FillData(wb, sheet);
            }

            return wb;
        }

        /// <summary>
        /// Fill Data Acceptance Report
        /// </summary>
        /// <param name="wb">IWorkbook</param>
        /// <param name="sheet">ISheet</param>
        private void FillData(IWorkbook wb, ISheet sheet)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);
                CompanyService companySer = new CompanyService(db);

                //-------- Get data from DB ---------
                //Get Company
                var company = companySer.GetData();

                //Get delivery
                var delivery = this.GetDelivery(this.DataID);
                //-----------------------------------
                if (delivery != null)
                {
                    //Get customer
                    var customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(delivery.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = customerSer.GetByCustomerCD(customerCd);

                    if (customer != null)
                    {
                        var customerAddEn = customer.CustomerAddress1 + SPACE_EN + customer.CustomerAddress2 + SPACE_EN + customer.CustomerAddress3;
                        var customerAddVn = customer.CustomerAddress4 + SPACE_EN + customer.CustomerAddress5 + SPACE_EN + customer.CustomerAddress6;

                        this.SetValueIndex(wb, sheet, _CusName_En, customer.CustomerName1, String.Format("{0}{1}{2}", "[", _CusName_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusName_Vn, customer.CustomerName2, String.Format("{0}{1}{2}", "[", _CusName_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _CusAddress_En, customerAddEn, String.Format("{0}{1}{2}", "[", _CusAddress_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusAddress_Vn, customerAddVn, String.Format("{0}{1}{2}", "[", _CusAddress_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _CusTel_En, delivery.Tel, String.Format("{0}{1}{2}", "[", _CusTel_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusFax_En, delivery.Fax, String.Format("{0}{1}{2}", "[", _CusFax_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusRepresent_En, customer.Represent, String.Format("{0}{1}{2}", "[", _CusRepresent_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusRepresent_Vn, customer.Represent, String.Format("{0}{1}{2}", "[", _CusRepresent_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _CusTitle_En, customer.Position1, String.Format("{0}{1}{2}", "[", _CusTitle_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusTitle_Vn, customer.Position2, String.Format("{0}{1}{2}", "[", _CusTitle_Vn, "]"));

                        //Bottom
                        this.SetValueIndex(wb, sheet, _CusNameBottomEn, customer.CustomerName1, String.Format("{0}{1}{2}", "[", _CusNameBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _CusNameBottomVn, customer.CustomerName2, String.Format("{0}{1}{2}", "[", _CusNameBottomVn, "]"));

                        this.SetValueIndex(wb, sheet, _CusTitleBottomVn, customer.Position2, String.Format("{0}{1}{2}", "[", _CusTitleBottomVn, "]"));
                        this.SetValueIndex(wb, sheet, _CusTitleBottomEn, customer.Position1, String.Format("{0}{1}{2}", "[", _CusTitleBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _CusReprentedBottom, customer.Represent, String.Format("{0}{1}{2}", "[", _CusReprentedBottom, "]"));
                    }
                    else
                    {
                        //-------2014/12/09 ISV-HUNG Add Start -----------//
                        var customerAddEn = delivery.CustomerAddress1 + SPACE_EN + delivery.CustomerAddress2 + SPACE_EN + delivery.CustomerAddress3;
                        var customerAddVn = string.Empty;

                        this.SetValueIndex(wb, sheet, _CusName_En, delivery.CustomerName, String.Format("{0}{1}{2}", "[", _CusName_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusName_Vn, string.Empty, String.Format("{0}{1}{2}", "[", _CusName_Vn, "]"));

                        this.SetValueIndex(wb, sheet, _CusAddress_En, customerAddEn, String.Format("{0}{1}{2}", "[", _CusAddress_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusAddress_Vn, customerAddVn, String.Format("{0}{1}{2}", "[", _CusAddress_Vn, "]"));

                        this.SetValueIndex(wb, sheet, _CusTel_En, delivery.Tel, String.Format("{0}{1}{2}", "[", _CusTel_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusFax_En, delivery.Fax, String.Format("{0}{1}{2}", "[", _CusFax_En, "]"));

                        this.SetValueIndex(wb, sheet, _CusRepresent_En, delivery.ApprovedName, String.Format("{0}{1}{2}", "[", _CusRepresent_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusRepresent_Vn, string.Empty, String.Format("{0}{1}{2}", "[", _CusRepresent_Vn, "]"));

                        this.SetValueIndex(wb, sheet, _CusTitle_En, delivery.Position, String.Format("{0}{1}{2}", "[", _CusTitle_En, "]"));
                        this.SetValueIndex(wb, sheet, _CusTitle_Vn, string.Empty, String.Format("{0}{1}{2}", "[", _CusTitle_Vn, "]"));

                        //Bottom
                        this.SetValueIndex(wb, sheet, _CusNameBottomEn, delivery.CustomerName, String.Format("{0}{1}{2}", "[", _CusNameBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _CusNameBottomVn, string.Empty, String.Format("{0}{1}{2}", "[", _CusNameBottomVn, "]"));

                        this.SetValueIndex(wb, sheet, _CusTitleBottomEn, delivery.Position, String.Format("{0}{1}{2}", "[", _CusTitleBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _CusTitleBottomVn, string.Empty, String.Format("{0}{1}{2}", "[", _CusTitleBottomVn, "]"));

                        this.SetValueIndex(wb, sheet, _CusReprentedBottom, delivery.ApprovedName, String.Format("{0}{1}{2}", "[", _CusReprentedBottom, "]"));
                        //-------2014/12/09 ISV-HUNG Add End -----------//

                    }

                    if (company != null)
                    {
                        var tel_fax = String.Format("{0,1}{1,40}", "TEL: " + company.Tel, "FAX: " + company.FAX);
                        var companyInfo = company.CompanyAddress1 + "\n" + company.CompanyAddress2 + "\n" + company.CompanyAddress3 + "\n" + tel_fax;
                        var companyAddEn = company.CompanyAddress1 + SPACE_EN + company.CompanyAddress2 + SPACE_EN + company.CompanyAddress3;
                        var companyAddVn = company.CompanyAddress4 + SPACE_EN + company.CompanyAddress5 + SPACE_EN + company.CompanyAddress6;

                        //Header
                        this.SetValueIndex(wb, sheet, _CompanyName, company.CompanyName1, String.Format("{0}{1}{2}", "[", _CompanyName, "]"));
                        this.SetValueIndex(wb, sheet, _CompanyInfo, companyInfo, String.Format("{0}{1}{2}", "[", _CompanyInfo, "]"));

                        //Detai
                        this.SetValueIndex(wb, sheet, _ComName_En, company.CompanyName1, String.Format("{0}{1}{2}", "[", _ComName_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComName_Vn, company.CompanyName2, String.Format("{0}{1}{2}", "[", _ComName_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _ComAddress_En, companyAddEn, String.Format("{0}{1}{2}", "[", _ComAddress_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComAddress_Vn, companyAddVn, String.Format("{0}{1}{2}", "[", _ComAddress_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _ComTel_En, company.Tel, String.Format("{0}{1}{2}", "[", _ComTel_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComFax_En, company.FAX, String.Format("{0}{1}{2}", "[", _ComFax_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComRepresented_En, company.Represent, String.Format("{0}{1}{2}", "[", _ComRepresented_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComRepresented_Vn, company.Represent, String.Format("{0}{1}{2}", "[", _ComRepresented_Vn, "]"));
                        this.SetValueIndex(wb, sheet, _ComTitle_En, company.Position, String.Format("{0}{1}{2}", "[", _ComTitle_En, "]"));
                        this.SetValueIndex(wb, sheet, _ComTitle_Vn, company.Position2, String.Format("{0}{1}{2}", "[", _ComTitle_Vn, "]"));

                        //Bottom
                        this.SetValueIndex(wb, sheet, _ComNameBottomEn, company.CompanyName1, String.Format("{0}{1}{2}", "[", _ComNameBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _ComNameBottomVn, company.CompanyName2, String.Format("{0}{1}{2}", "[", _ComNameBottomVn, "]"));

                        this.SetValueIndex(wb, sheet, _ComTitleBottomVn, company.Position2, String.Format("{0}{1}{2}", "[", _ComTitleBottomVn, "]"));
                        this.SetValueIndex(wb, sheet, _ComTitleBottomEn, company.Position, String.Format("{0}{1}{2}", "[", _ComTitleBottomEn, "]"));
                        this.SetValueIndex(wb, sheet, _ComReprentedBottom, company.Represent, String.Format("{0}{1}{2}", "[", _ComReprentedBottom, "]"));
                    }

                    //Get Delivery Place
                    var places = this.GetDeliveryPlace(delivery.SalesNo);
                    var deliPlace = string.IsNullOrEmpty(places) ? SPACE_WITH_POINT : places;

                    Sales_HService sales_HSer = new Sales_HService(db);
                    var sales = sales_HSer.GetBySalesNo(delivery.SalesNo);
                    var contNo = string.Empty;
                    var contDate = DATE_TIME_DEFAULT;
                    var salesNo = string.Empty;
                    var quoteNo = string.Empty;
                    if (sales != null)
                    {
                        contDate = sales.ContractDate;
                        contNo = sales.ContractNo;

                        if (string.IsNullOrEmpty(sales.QuoteNo))
                        {

                            this.SetValueIndex(wb, sheet, _Description_Vn, "tại số đơn hàng " + sales.SalesNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                            this.SetValueIndex(wb, sheet, _Description_En, "Sales No. " + sales.SalesNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                        }
                        else
                        {
                            this.SetValueIndex(wb, sheet, _Description_Vn, "tại số báo giá " + sales.QuoteNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                            this.SetValueIndex(wb, sheet, _Description_En, "Quotation No. " + sales.QuoteNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                        }
                    }

                    var contractNo = string.IsNullOrEmpty(contNo) ? SPACE_WITH_POINT : contNo;
                    //var acceptNo = string.IsNullOrEmpty(delivery.SalesNo) ? SPACE_WITH_POINT : delivery.SalesNo;
                    var contractDtVn = contDate.Equals(DATE_TIME_DEFAULT) ? SPACE_WITH_POINT : base.GetDateString(contDate, Language.Vietnam);
                    var contractDtEn = contDate.Equals(DATE_TIME_DEFAULT) ? SPACE_WITH_POINT : base.GetDateString(contDate, Language.English);



                    //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                    var setUpDtVn = delivery.AcceptanceDate.Equals(DATE_TIME_DEFAULT) ? SPACE_WITH_POINT : base.GetDateString(delivery.AcceptanceDate, Language.Vietnam);
                    var setUpDtEn = delivery.AcceptanceDate.Equals(DATE_TIME_DEFAULT) ? SPACE_WITH_POINT : base.GetDateString(delivery.AcceptanceDate, Language.English);
                    //----------------2014/12/16 ISV-HUNG Edit End----------------------//

                    if (sales == null)
                    {
                        this.SetValueIndex(wb, sheet, _Description_Vn,"số " +contractNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                        this.SetValueIndex(wb, sheet, _Description_En, contractNo, String.Format("{0}{1}{2}", "[", _ContractNo, "]"));
                    }
                    //Vn
                    this.SetValueIndex(wb, sheet, _Description_Vn, contractDtVn, String.Format("{0}{1}{2}", "[", _ContractDate, "]"));
                    this.SetValueIndex(wb, sheet, _Description_Vn, deliPlace, String.Format("{0}{1}{2}", "[", _DeliPlace, "]"));

                    //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                    this.SetValueIndex(wb, sheet, _Description_Vn, setUpDtVn, String.Format("{0}{1}{2}", "[", _SetUpDate, "]"));
                    //----------------2014/12/16 ISV-HUNG Edit End----------------------//

                    //En
                    this.SetValueIndex(wb, sheet, _Description_En, contractDtEn, String.Format("{0}{1}{2}", "[", _ContractDate, "]"));
                    this.SetValueIndex(wb, sheet, _Description_En, deliPlace, String.Format("{0}{1}{2}", "[", _DeliPlace, "]"));

                    //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                    this.SetValueIndex(wb, sheet, _Description_En, setUpDtEn, String.Format("{0}{1}{2}", "[", _SetUpDate, "]"));
                    //----------------2014/12/16 ISV-HUNG Edit End----------------------//
                }
            }
        }

        /// <summary>
        /// Get GetDelivery
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Delivery_H GetDelivery(int id)
        {
            using (DB db = new DB())
            {
                Delivery_HService delivery_HService = new Delivery_HService(db);

                //Get Currency
                return delivery_HService.GetByID(id);
            }
        }

        /// <summary>
        /// Get DeliveryPlace
        /// </summary>
        /// <param name="acceptNo">AcceptNo</param>
        /// <returns></returns>
        private string GetDeliveryPlace(string salesNo)
        {
            using (DB db = new DB())
            {
                Delivery_HService shipHService = new Delivery_HService(db);

                return shipHService.GetDeliveryPlaceBySalesNo(salesNo);
            }
        }
        #endregion
    }
}

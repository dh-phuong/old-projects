﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NPOI.SS.UserModel;
using OMS.Models;
using OMS.DAC;

namespace OMS.Reports.EXCEL
{
    public class QuotationListExcel : BaseExcel
    {
        #region Variable
        /// <summary>
        /// Model Quotation Header Search
        /// </summary>
        public QuotationHeaderSearch modelInput;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<QuotationExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Quotation");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Quotation List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// Get List ForExcel
        /// </summary>
        /// <returns>IList<QuotationeExcel></returns>
        private IList<QuotationExcel> GetListForExcel()
        {
            IList<QuotationExcel> results = null;

            //QuotationHeaderSearch modelInput = this.GetSearchModel();

            using (DB db = new DB())
            {
                Quotation_HService quotation_HService = new Quotation_HService(db);
                results = quotation_HService.GetListForExcel(modelInput);
            }
            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //-------------------------row 1-------------------------
            IRow row1 = sheet.GetRow(1);

            //QuoteNo
            ICell cellQuoteNo = row1.GetCell(0);
            string strQuoteNo = "Quote No: " + modelInput.QuoteNo;
            cellQuoteNo.SetCellValue(strQuoteNo);

            //Quote Date
            string strQuoteDate = "Quote Date: ";
            ICell cellQuoteDate = row1.GetCell(3);
            string quoteDateFrom = string.Empty;
            string quoteDateTo = string.Empty;

            if (modelInput.QuoteDateFrom.HasValue)
            {
                quoteDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.QuoteDateFrom.Value);
            }

            if (modelInput.QuoteDateTo.HasValue)
            {
                quoteDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.QuoteDateTo.Value);
            }

            if (!string.IsNullOrEmpty(quoteDateFrom) || !string.IsNullOrEmpty(quoteDateTo))
            {
                strQuoteDate = strQuoteDate + quoteDateFrom;
                strQuoteDate = strQuoteDate.Trim() + " ～ ";
                strQuoteDate = strQuoteDate + quoteDateTo;
            }
            cellQuoteDate.SetCellValue(strQuoteDate);

            //Customer
            ICell cellCustomerName = row1.GetCell(5);
            string customerName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.CustomerCD.Trim()))
            {
                M_Customer customer = this.GetCustomerModel(modelInput.CustomerCD.Trim());
                if (customer != null)
                {
                    customerName = customer.CustomerName1;
                }
            }
            string strCustomer = "Customer : " + customerName;
            cellCustomerName.SetCellValue(strCustomer);

            //prepared
            ICell cellPreparedName = row1.GetCell(10);
            string preparedName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.PreparedCD.Trim()))
            {
                M_User user = this.GetUserModel(modelInput.PreparedCD.Trim());
                if (user != null)
                {
                    preparedName = user.UserName2;
                }
            }
            string strPrepared = "Prepared by: " + preparedName;
            cellPreparedName.SetCellValue(strPrepared);

            ICell cellSubject = row1.GetCell(14);
            string subject = "Subject: " + modelInput.Subject;
            cellSubject.SetCellValue(subject);

            //-------------------------row 2-------------------------
            IRow row2 = sheet.GetRow(2);

            ICell cellSales1 = row2.GetCell(0);
            string salesName1 = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.Sale1CD.Trim()))
            {
                M_User user = this.GetUserModel(modelInput.Sale1CD.Trim());
                if (user != null)
                {
                    salesName1 = user.UserName2;
                }
            }

            string strSales1 = "Sales 1: " + salesName1;
            cellSales1.SetCellValue(strSales1);

            ICell cellSales2 = row2.GetCell(3);
            string salesName2 = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.Sale2CD.Trim()))
            {
                M_User user = this.GetUserModel(modelInput.Sale2CD.Trim());
                if (user != null)
                {
                    salesName2 = user.UserName2;
                }
            }

            string strSales2 = "Sales 2: " + salesName2;
            cellSales2.SetCellValue(strSales2);

            //status
            ICell cellStatus = row2.GetCell(5);
            string status = string.Empty;
            if (modelInput.Status != -1)
            {
                status = modelInput.StatusName;
            }
            string strStatus = "Status: " + status;
            cellStatus.SetCellValue(strStatus);

            ICell cellLostData = row2.GetCell(10);
            string strLostData = "Lost Data: " + modelInput.InvalidName;
            cellLostData.SetCellValue(strLostData);

            ICell cellSalesData = row2.GetCell(14);
            string strSalesData = "Sales Data: " + modelInput.SalesName;
            cellSalesData.SetCellValue(strSalesData);
        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<QuotationExcel> lstData)
        {
            int rowStart = 7;
            for (int k = 0; k < lstData.Count; k++)
            {
                //----------- ISV-Giam 2015/01/20 -----------
                if (lstData[k].StatusFlag == (short)Models.StatusFlag.Lost)
                {
                    this.CopyRow(wb, sheet, 5, rowStart + k);
                }
                else if (!String.IsNullOrEmpty(lstData[k].ExpiryDateStr) && lstData[k].ExpiryDate.Date < DateTime.Today)
                {
                    this.CopyRow(wb, sheet, 4, rowStart + k);
                }                
                else
                {
                    this.CopyRow(wb, sheet, 6, rowStart + k);
                }
                //-------------------------------------------

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell QuoteNo
                ICell cellQuoteNo = rowTemp.GetCell(0);
                cellQuoteNo.SetCellValue(lstData[k].QuoteNo);

                //create cell QuoteDate
                ICell cellQuoteDate = rowTemp.GetCell(1);
                cellQuoteDate.SetCellValue(lstData[k].QuoteDateStr);

                //create cell ExpiryDate
                ICell cellExpiryDate = rowTemp.GetCell(2);
                cellExpiryDate.SetCellValue(lstData[k].ExpiryDateStr);

                //create cell ExpectedOrderDate
                ICell cellExpectedOrderDate = rowTemp.GetCell(3);
                cellExpectedOrderDate.SetCellValue(lstData[k].ExpectedOrderDateStr);

                //create cell ExpectedRevenueDate
                ICell cellExpectedRevenueDate = rowTemp.GetCell(4);
                cellExpectedRevenueDate.SetCellValue(lstData[k].ExpectedRevenueDateStr);

                //create cell Customer
                ICell cellCustomer = rowTemp.GetCell(5);
                cellCustomer.SetCellValue(lstData[k].CustomerCD + SPACE_EN + lstData[k].CustomerName);

                //create cell SubjectName
                ICell cellSubjectName = rowTemp.GetCell(6);
                cellSubjectName.SetCellValue(lstData[k].SubjectName);

                //create cell ProfitRatioStr
                ICell cellProfitRatioStr = rowTemp.GetCell(7);
                cellProfitRatioStr.SetCellValue((double)lstData[k].ProfitRatio);

                //create cell Total
                ICell cellTotal = rowTemp.GetCell(8);
                cellTotal.SetCellValue((double)lstData[k].Total);

                //create cell Currency
                ICell cellCurrency = rowTemp.GetCell(9);
                cellCurrency.SetCellValue(lstData[k].Currency);

                //create cell Vat
                ICell cellVat = rowTemp.GetCell(10);
                cellVat.SetCellValue((double)lstData[k].Vat);

                //create cell MethodVatName
                ICell cellMethodVatName = rowTemp.GetCell(11);
                cellMethodVatName.SetCellValue(lstData[k].MethodVatName);

                //create cell GrandTotal
                ICell cellGrandTotal = rowTemp.GetCell(12);
                cellGrandTotal.SetCellValue((double)lstData[k].GrandTotal);

                //create cell StatusFlagName
                ICell cellStatusFlag = rowTemp.GetCell(13);
                cellStatusFlag.SetCellValue(lstData[k].StatusFlagName);

                //create cell SalesName1
                ICell cellSalesName1 = rowTemp.GetCell(14);
                cellSalesName1.SetCellValue(lstData[k].SalesName1);

                //create cell SalesName2
                ICell cellSalesName2 = rowTemp.GetCell(15);
                cellSalesName2.SetCellValue(lstData[k].SalesName2);

                //create cell PreparedName
                ICell cellPreparedName = rowTemp.GetCell(16);
                cellPreparedName.SetCellValue(lstData[k].PreparedName);

                //create cell ApprovedName
                ICell cellApprovedName = rowTemp.GetCell(17);
                cellApprovedName.SetCellValue(lstData[k].ApprovedName);

                //create cell Memo
                ICell cellMemo = rowTemp.GetCell(18);
                cellMemo.SetCellValue(lstData[k].Memo);
            }
            if (lstData.Count <= 3)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }
    }
}

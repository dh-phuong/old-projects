﻿using System;
using System.Collections.Generic;
using NPOI.SS.UserModel;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Reports.EXCEL
{
    public class CreateDeliveryListExcel : BaseExcel
    {
        #region Variable

        /// <summary>
        /// deliveryListDateFrom;
        /// </summary>
        public DateTime? deliveryDateFrom;

        /// <summary>
        /// deliveryDateTo
        /// </summary>
        public DateTime? deliveryDateTo;

        #endregion Variable

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<CreateDeliveryExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("CreateDeliveryList");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Created Delivery List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList<QuotationeExcel></returns>
        private IList<CreateDeliveryExcel> GetListForExcel()
        {
            IList<CreateDeliveryExcel> results = null;

            using (DB db = new DB())
            {
                Delivery_HService delivery_HService = new Delivery_HService(db);
                results = delivery_HService.GetListForCreateDeliveryListExcel(deliveryDateFrom, deliveryDateTo);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            //Purchase Date
            string strDeliveryDate = "Delivery Date: ";
            ICell cellQuoteDate = row1.GetCell(0);
            string poDateFrom = string.Empty;
            string poDateTo = string.Empty;
            if (this.deliveryDateFrom.HasValue)
            {
                poDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.deliveryDateFrom.Value);
            }
            if (this.deliveryDateTo.HasValue)
            {
                poDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.deliveryDateTo.Value);
            }
            if (!string.IsNullOrEmpty(poDateFrom) || !string.IsNullOrEmpty(poDateTo))
            {
                strDeliveryDate = strDeliveryDate + poDateFrom;
                strDeliveryDate = strDeliveryDate.Trim() + " ～ ";
                strDeliveryDate = strDeliveryDate + poDateTo;
            }
            cellQuoteDate.SetCellValue(strDeliveryDate);

            //QuoteNo
            ICell cellCreation = row1.GetCell(10);
            string creationDate = "Creation: " + DateTime.Now.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
            cellCreation.SetCellValue(creationDate);
        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<CreateDeliveryExcel> lstData)
        {
            int rowStart = 4;
            string format = this.GetDefaultValueQuantity();
            for (int k = 0; k < lstData.Count; k++)
            {
                this.CopyRow(wb, sheet, 3, rowStart + k);

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell PurchaseDate
                ICell cellPurchaseDate = rowTemp.GetCell(0);
                cellPurchaseDate.SetCellValue(lstData[k].DeliveryDateStr);

                //create cell PurchaseNo
                ICell cellPurchaseNo = rowTemp.GetCell(1);
                cellPurchaseNo.SetCellValue(lstData[k].DeliveryNo);

                //create cell SalesDate
                ICell cellSalesDate = rowTemp.GetCell(2);
                if (lstData[k].SalesDate == base.DATE_TIME_DEFAULT)
                {
                    cellSalesDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellSalesDate.SetCellValue(lstData[k].SalesDateStr);
                }

                //create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(3);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //create cell CustomerCD
                ICell cellCustomerCD = rowTemp.GetCell(4);
                cellCustomerCD.SetCellValue(lstData[k].CustomerCD);

                //create cell Vendor
                ICell cellCustomerName = rowTemp.GetCell(5);
                cellCustomerName.SetCellValue(lstData[k].CustomerName);

                //create cell ProductName
                ICell cellProductName = rowTemp.GetCell(6);
                cellProductName.SetCellValue(lstData[k].ProductName);

                if (string.IsNullOrEmpty(lstData[k].SalesNo))
                {
                    //create cell SalesQuantity
                    ICell cellSalesQuantity = rowTemp.GetCell(7);
                    cellSalesQuantity.SetCellValue(string.Empty);
                }
                else
                {
                    //create cell SalesQuantity
                    ICell cellSalesQuantity = rowTemp.GetCell(7);
                    cellSalesQuantity.SetCellValue((double)lstData[k].SalesQuantity);
                }

                //create cell Quantity
                ICell cellQuantity = rowTemp.GetCell(8);
                cellQuantity.SetCellValue((double)lstData[k].Quantity);

                //create cell DeliveryDateItem
                ICell cellDeliveryDateItem = rowTemp.GetCell(9);
                if (lstData[k].DeliveryDateItem == base.DATE_TIME_DEFAULT)
                {
                    cellDeliveryDateItem.SetCellValue(string.Empty);
                }
                else
                {
                    cellDeliveryDateItem.SetCellValue(lstData[k].DeliveryDateItemStr);
                }

                //create cell Quantity
                ICell cellDelivererName = rowTemp.GetCell(10);
                cellDelivererName.SetCellValue(lstData[k].DelivererName);
            }

            if (lstData.Count <= 1)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 1, -1);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -1);
            }
        }

        /// <summary>
        /// GetDefaultValueQuantity
        /// </summary>
        /// <returns>format</returns>
        private string GetDefaultValueQuantity()
        {
            string format = string.Empty;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                format = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? Constants.FMT_DECIMAL : Constants.FMT_INTEGER;
            }
            return format;
        }
    }
}
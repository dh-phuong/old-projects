﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NPOI.SS.UserModel;
using OMS.Models;
using OMS.DAC;

namespace OMS.Reports.EXCEL
{
    public class BillingListExcel : BaseExcel
    {
        #region Variable
        /// <summary>
        /// Model Quotation Header Search
        /// </summary>
        public BillingHeaderSearch modelInput;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<BillingExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Billing");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Billing List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------------- Row 1 ---------------------
            IRow row1 = sheet.GetRow(1);

            //Billing No
            ICell cellBillingNo = row1.GetCell(0);
            string strBillingNo = "Bill No: " + modelInput.BillingNo;
            cellBillingNo.SetCellValue(strBillingNo);

            //Sales No
            ICell cellSalesNo = row1.GetCell(3);
            string strSalesNo = "Sales No: " + modelInput.SalesNo;
            cellSalesNo.SetCellValue(strSalesNo);

            //Quote No
            ICell cellQuoteNo = row1.GetCell(6);
            string strQuoteNo = "Quote No: " + modelInput.QuoteNo;
            cellQuoteNo.SetCellValue(strQuoteNo);

            //Billing Date
            string strBillingDate = "Bill Date: ";
            ICell cellBillingDate = row1.GetCell(9);
            string billingDateFrom = string.Empty;
            string billingDateTo = string.Empty;
            if (modelInput.BillingDateFrom.HasValue)
            {
                billingDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.BillingDateFrom.Value);
            }
            if (modelInput.BillingDateTo.HasValue)
            {
                billingDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.BillingDateTo.Value);
            }
            if (!string.IsNullOrEmpty(billingDateFrom) || !string.IsNullOrEmpty(billingDateTo))
            {
                strBillingDate = strBillingDate + billingDateFrom;
                strBillingDate = strBillingDate.Trim() + " ～ ";
                strBillingDate = strBillingDate + billingDateTo;
            }
            cellBillingDate.SetCellValue(strBillingDate);

            //--------------------- Row 2 ---------------------
            IRow row2 = sheet.GetRow(2);
            //Customer
            ICell cellCustomer = row2.GetCell(0);
            string customerName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.CustomerCD.Trim()))
            {
                M_Customer customer = this.GetCustomer(modelInput.CustomerCD.Trim());
                if (customer != null)
                {
                    customerName = customer.CustomerName1;
                }
            }
            string strCustomer = "Customer: " + customerName;
            cellCustomer.SetCellValue(strCustomer);

            //Prepared
            ICell cellPrepared = row2.GetCell(3);
            string preparedName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.PreparedCD.Trim()))
            {
                M_User user = this.GetUser(modelInput.PreparedCD.Trim());
                if (user != null)
                {
                    preparedName = user.UserName2;
                }
            }
            string strPrepared = "Prepared by: " + preparedName;
            cellPrepared.SetCellValue(strPrepared);

            //Subject
            ICell cellSubject = row2.GetCell(6);
            string subject = "Subject: " + modelInput.SubjectName;
            cellSubject.SetCellValue(subject);

            ICell cellLostData = row2.GetCell(9);
            string strLostData = "Finished Data: " + modelInput.FinishedName;
            cellLostData.SetCellValue(strLostData);

            ICell cellSalesData = row2.GetCell(11);
            string strSalesData = "Deleted Data: " + modelInput.DeletedName;
            cellSalesData.SetCellValue(strSalesData);
        }

        /// <summary>
        /// Fill data on excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">Data list  of billing</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<BillingExcel> lstData)
        {
            int rowStart = 7;
            for (int k = 0; k < lstData.Count; k++)
            {
                if (lstData[k].DeleteFlag == (short)Models.DeleteFlag.Deleted)
                {
                    this.CopyRow(wb, sheet, 5, rowStart + k);
                }
                else if (!String.IsNullOrEmpty(lstData[k].ExpiryDateStr) && lstData[k].ExpiryDate != base.DATE_TIME_DEFAULT &&
                    lstData[k].ExpiryDate.Date < DateTime.Today && ((int)lstData[k].FinishFlag == (int)Models.FinishedFlag.NotFinish))
                {
                    this.CopyRow(wb, sheet, 4, rowStart + k);
                }
                else
                {
                    this.CopyRow(wb, sheet, 6, rowStart + k);
                }
                IRow rowTemp = sheet.GetRow(rowStart + k);

                //Create cell BillingNo
                ICell cellBillingNo = rowTemp.GetCell(0);
                cellBillingNo.SetCellValue(lstData[k].BillingNo);

                //Create cell QuoteNo
                ICell cellQuoteNo = rowTemp.GetCell(1);
                cellQuoteNo.SetCellValue(lstData[k].QuoteNo);

                //Create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(2);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //Create cell BillingDate
                ICell cellBillingDate = rowTemp.GetCell(3);
                cellBillingDate.SetCellValue(lstData[k].BillingDateStr);

                //Create cell ExpiryDate
                ICell cellExpiryDate = rowTemp.GetCell(4);
                string strExpiryDate = string.Empty;
                if (lstData[k].ExpiryDate != DATE_TIME_DEFAULT)
                {
                    strExpiryDate = lstData[k].ExpiryDateStr;
                }
                cellExpiryDate.SetCellValue(strExpiryDate);

                //Create cell Customer
                ICell cellCustomerName = rowTemp.GetCell(5);
                cellCustomerName.SetCellValue(lstData[k].CustomerName);

                //Create cell SubjectName
                ICell cellSubjectName = rowTemp.GetCell(6);
                cellSubjectName.SetCellValue(lstData[k].SubjectName);

                //Create cell Total
                ICell cellTotal = rowTemp.GetCell(7);
                //cellTotal.SetCellValue(lstData[k].TotalStr);
                cellTotal.SetCellValue((double)lstData[k].Total);

                //Create cell Currency
                ICell cellCurrency = rowTemp.GetCell(8);
                cellCurrency.SetCellValue(lstData[k].Currency);

                //Create cell Vat
                ICell cellVat = rowTemp.GetCell(9);
                //cellVat.SetCellValue(lstData[k].VatStr);
                cellVat.SetCellValue((double)lstData[k].Vat);

                //Create cell MethodVatName
                ICell cellMethodVatName = rowTemp.GetCell(10);
                cellMethodVatName.SetCellValue(lstData[k].MethodVatName);

                //Create cell GrandTotalStr
                ICell cellGrandTotal = rowTemp.GetCell(11);
                //cellGrandTotal.SetCellValue(lstData[k].GrandTotalStr);
                cellGrandTotal.SetCellValue((double)lstData[k].GrandTotal);

                //Create cell PreparedName
                ICell cellPreparedName = rowTemp.GetCell(12);
                cellPreparedName.SetCellValue(lstData[k].PreparedName);

                //Create cell ApprovedName
                ICell cellApprovedName = rowTemp.GetCell(13);
                cellApprovedName.SetCellValue(lstData[k].ApprovedName);

                //Create cell Memo
                ICell cellMemo = rowTemp.GetCell(14);
                cellMemo.SetCellValue(lstData[k].Memo);
            }

            if (lstData.Count <= 3)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList<BillingExcel></returns>
        private IList<BillingExcel> GetListForExcel()
        {
            IList<BillingExcel> results = null;

            //BillingHeaderSearch model = this.GetSearchModel();

            using (DB db = new DB())
            {
                Billing_HService billing_HService = new Billing_HService(db);
                results = billing_HService.GetListForExcel(modelInput);
            }
            return results;
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUser(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }
    }
}
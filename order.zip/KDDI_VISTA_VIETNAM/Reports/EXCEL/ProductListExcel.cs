﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

using OMS.Models;
using OMS.DAC;
using OMS.Utilities;

using NPOI.SS.UserModel;

namespace OMS.Reports.EXCEL
{
    public class ProductListExcel : BaseExcel
    {
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<ProductExcel> lstData = this.GetListExcel();
            if (lstData.Count != 0)
            {
                wb = this.CreateWorkbook("Product");

                //Get Sheet
                ISheet sheet = wb.GetSheet("Product List");

                int rowStart = 5; //row start fill data
                for (int k = 0; k < lstData.Count; k++)
                {
                    //Check Status
                    if (lstData[k].StatusFlag == 0)
                    {
                        this.CopyRow(wb, sheet, 3, rowStart + k);
                    }
                    else
                    {
                        this.CopyRow(wb, sheet, 4, rowStart + k);
                    }

                    IRow rowTemp = sheet.GetRow(rowStart + k);
                    ProductExcel item = lstData[k];

                    //No.
                    ICell cellNo = rowTemp.GetCell(0);
                    cellNo.SetCellValue(k + 1);

                    //Type
                    ICell cellType = rowTemp.GetCell(1);
                    cellType.SetCellValue(((ProductType)item.Type).ToString());

                    //Product code
                    ICell cellProductCD = rowTemp.GetCell(2);
                    cellProductCD.SetCellValue(item.ProductCD);

                    //Product name
                    ICell cellProductName = rowTemp.GetCell(3);
                    cellProductName.SetCellValue(item.ProductName);

                    //CategoryName1
                    ICell cellCategoryName1 = rowTemp.GetCell(4);
                    cellCategoryName1.SetCellValue(item.CategoryName1);

                    //CategoryName2
                    ICell cellCategoryName2 = rowTemp.GetCell(5);
                    cellCategoryName2.SetCellValue(item.CategoryName2);

                    //CategoryName3
                    ICell cellCategoryName3 = rowTemp.GetCell(6);
                    cellCategoryName3.SetCellValue(item.CategoryName3);

                    //PurchaseFlag
                    ICell cellPurchaseFlag = rowTemp.GetCell(7);
                    cellPurchaseFlag.SetCellValue(item.PurchaseFlag);

                    //UnitPriceSell
                    ICell cellUnitPriceSell = rowTemp.GetCell(8);
                    cellUnitPriceSell.SetCellValue((double)item.UnitPriceSell);

                    //CurrencySell
                    ICell cellCurrencySell = rowTemp.GetCell(9);
                    cellCurrencySell.SetCellValue(item.CurrencySell);

                    //VatTypeSell
                    ICell cellVatTypeSell = rowTemp.GetCell(10);
                    cellVatTypeSell.SetCellValue(item.VatTypeSell);

                    //VatRatioSell
                    ICell cellVatRatioSell = rowTemp.GetCell(11);
                    cellVatRatioSell.SetCellValue((double)item.VatRatioSell/100);

                    //UnitSellName
                    ICell cellUnitSellName = rowTemp.GetCell(12);
                    cellUnitSellName.SetCellValue(item.UnitSellName);

                    //DescriptionSell
                    ICell cellDescriptionSell = rowTemp.GetCell(13);
                    cellDescriptionSell.SetCellValue(item.DescriptionSell);

                    //RemarkSell
                    ICell cellRemarkSell = rowTemp.GetCell(14);
                    cellRemarkSell.SetCellValue(item.RemarkSell);

                    //UnitPriceCost
                    ICell cellUnitPriceCost = rowTemp.GetCell(15);
                    cellUnitPriceCost.SetCellValue((double)item.UnitPriceCost);

                    //CurrencyCost
                    ICell cellCurrencyCost = rowTemp.GetCell(16);
                    cellCurrencyCost.SetCellValue(item.CurrencyCost);

                    //VatTypeCost
                    ICell cellVatTypeCost = rowTemp.GetCell(17);
                    cellVatTypeCost.SetCellValue(item.VatTypeCost);

                    //VatRatioCost
                    ICell cellVatRatioCost = rowTemp.GetCell(18);
                    cellVatRatioCost.SetCellValue((double)item.VatRatioCost/100);

                    //UnitCostName
                    ICell cellUnitCostName = rowTemp.GetCell(19);
                    cellUnitCostName.SetCellValue(item.UnitCostName);

                    //DescriptionCost
                    ICell cellDescriptionCost = rowTemp.GetCell(20);
                    cellDescriptionCost.SetCellValue(item.DescriptionCost);

                    //RemarkCost
                    ICell cellRemarkCost = rowTemp.GetCell(21);
                    cellRemarkCost.SetCellValue(item.RemarkCost);

                    //VendorCD1
                    ICell cellVendorCD1 = rowTemp.GetCell(22);
                    cellVendorCD1.SetCellValue(EditDataUtil.ToFixCodeShow(item.VendorCD1, M_Vendor.VENDOR_CODE_MAX_SHOW));

                    //VendorName1
                    ICell cellVendorName1 = rowTemp.GetCell(23);
                    cellVendorName1.SetCellValue(item.VendorName1);

                    //VendorProductCD1
                    ICell cellVendorProductCD1 = rowTemp.GetCell(24);
                    cellVendorProductCD1.SetCellValue(item.VendorProductCD1);

                    //VendorCD2
                    ICell cellVendorCD2 = rowTemp.GetCell(25);
                    cellVendorCD2.SetCellValue(EditDataUtil.ToFixCodeShow(item.VendorCD2, M_Vendor.VENDOR_CODE_MAX_SHOW));

                    //VendorName2
                    ICell cellVendorName2 = rowTemp.GetCell(26);
                    cellVendorName2.SetCellValue(item.VendorName2);

                    //VendorProductCD2
                    ICell cellVendorProductCD2 = rowTemp.GetCell(27);
                    cellVendorProductCD2.SetCellValue(item.VendorProductCD2);

                    //VendorCD3
                    ICell cellVendorCD3 = rowTemp.GetCell(28);
                    cellVendorCD3.SetCellValue(EditDataUtil.ToFixCodeShow(item.VendorCD3, M_Vendor.VENDOR_CODE_MAX_SHOW));

                    //VendorName3
                    ICell cellVendorName3 = rowTemp.GetCell(29);
                    cellVendorName3.SetCellValue(item.VendorName3);

                    //VendorProductCD3
                    ICell cellVendorProductCD3 = rowTemp.GetCell(30);
                    cellVendorProductCD3.SetCellValue(item.VendorProductCD3);
                }

                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart - 1, -2);

            }
            return wb;
        }

        /// <summary>
        /// Get list for export excel
        /// </summary>
        /// <returns></returns>
        private IList<ProductExcel> GetListExcel()
        {
            IList<ProductExcel> lstResult = null;
            using (DB db = new DB())
            {
                ProductService proSer = new ProductService(db);
                lstResult = proSer.GetListForExcel(M_Config_H.CONFIG_CD_VAT_TYPE);
            }
            return lstResult;
        }
    }
}

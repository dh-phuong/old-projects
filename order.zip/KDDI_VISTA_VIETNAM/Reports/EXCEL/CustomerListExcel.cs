﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

using OMS.Models;
using OMS.DAC;

using NPOI.SS.UserModel;

namespace OMS.Reports.EXCEL
{
    public class CustomerListExcel : BaseExcel
    {
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<CustomerExcel> lstData = this.GetListExcel();
            if (lstData.Count != 0)
            {
                wb = this.CreateWorkbook("Customer");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Customer List");

                int rowStart = 5;
                for (int k = 0; k < lstData.Count; k++)
                {
                    //Check status
                    if (lstData[k].StatusFlag == 0)
                    {
                        this.CopyRow(wb, sheet, 3, rowStart + k);
                    }
                    else
                    {
                        this.CopyRow(wb, sheet, 4, rowStart + k);
                    }

                    IRow row = sheet.GetRow(rowStart + k);

                    //create cell No.
                    ICell cellNo = row.GetCell(0);
                    cellNo.SetCellValue(k + 1);

                    //create cell Code
                    ICell cellCode = row.GetCell(1);
                    cellCode.SetCellValue(lstData[k].CustomerCD);

                    //create cell Name 1
                    ICell cellName1 = row.GetCell(2);
                    cellName1.SetCellValue(lstData[k].CustomerName1);

                    //create cell Name 2
                    ICell cellName2 = row.GetCell(3);
                    cellName2.SetCellValue(lstData[k].CustomerName2);

                    //create cell Address English
                    ICell cellAddEN = row.GetCell(4);
                    string addressEN = lstData[k].CustomerAddress1 + SPACE_EN + lstData[k].CustomerAddress2 + SPACE_EN + lstData[k].CustomerAddress3;
                    cellAddEN.SetCellValue(addressEN);

                    //create cell Address Vietnam
                    ICell cellAddVN = row.GetCell(5);
                    string addressVN = lstData[k].CustomerAddress4 + SPACE_EN + lstData[k].CustomerAddress5 + SPACE_EN + lstData[k].CustomerAddress6;
                    cellAddVN.SetCellValue(addressVN);

                    //create cell Represent
                    ICell cellRepresent = row.GetCell(6);
                    cellRepresent.SetCellValue(lstData[k].Represent);

                    //create cell Position English
                    ICell cellPositionEN = row.GetCell(7);
                    cellPositionEN.SetCellValue(lstData[k].Position1);

                    //create cell Position VietNam
                    ICell cellPositionVN = row.GetCell(8);
                    cellPositionVN.SetCellValue(lstData[k].Position2);

                    //create cell Tel
                    ICell cellTel = row.GetCell(9);
                    cellTel.SetCellValue(lstData[k].Tel);

                    //create cell Fax
                    ICell cellFAX = row.GetCell(10);
                    cellFAX.SetCellValue(lstData[k].FAX);

                    //create cell Email
                    ICell cellEmail = row.GetCell(11);
                    cellEmail.SetCellValue(lstData[k].EmailAddress);

                    //create cell Contact Person
                    ICell cellContactPerson = row.GetCell(12);
                    cellContactPerson.SetCellValue(lstData[k].ContactPerson);

                    //create cell Contact Tel
                    ICell cellContactTel = row.GetCell(13);
                    cellContactTel.SetCellValue(lstData[k].ContactTel);

                    //create cell TAX Code
                    ICell cellTAXCode = row.GetCell(14);
                    cellTAXCode.SetCellValue(lstData[k].TAXCode);

                    //create cell Customer Bank
                    ICell cellCustomerBank = row.GetCell(15);
                    cellCustomerBank.SetCellValue(lstData[k].CustomerBank);

                    //create cell Account Code
                    ICell cellAccountCode = row.GetCell(16);
                    cellAccountCode.SetCellValue(lstData[k].AccountCode);
                }

                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -2);
            }
            return wb;
        }

        /// <summary>
        /// Get list for export excel
        /// </summary>
        /// <returns></returns>
        private IList<CustomerExcel> GetListExcel()
        {
            IList<CustomerExcel> lstResult = null;
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);
                lstResult = customerSer.GetListForExcel();
            }

            return lstResult;
        }
    }
}

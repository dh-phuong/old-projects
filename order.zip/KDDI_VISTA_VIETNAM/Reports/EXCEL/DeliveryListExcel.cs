﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using NPOI.SS.UserModel;
using OMS.DAC;

namespace OMS.Reports.EXCEL
{
    /// <summary>
    /// Delivery List Excel Class
    /// </summary>
    public class DeliveryListExcel : BaseExcel
    {
        #region Variable
        /// <summary>
        /// Model Delivery Header Search
        /// </summary>
        public DeliveryHeaderSearch modelInput;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<DeliveryExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Delivery");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Delivery List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList DeliveryExcel </returns>
        private IList<DeliveryExcel> GetListForExcel()
        {
            IList<DeliveryExcel> results = null;

            //Get model input for search action
            //DeliveryHeaderSearch model = this.GetSearchModel();

            using (DB db = new DB())
            {
                Delivery_HService delivery_HService = new Delivery_HService(db);

                //Get list for Excel
                results = delivery_HService.GetListForExcel(modelInput);
            }
            return results;
        }

        /// <summary>
        /// Set header data for Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //------------------ Row 1 ---------------------
            IRow row1 = sheet.GetRow(1);

            //Delivery No
            ICell cellDeliveryNo = row1.GetCell(0);
            string strDeliveryNo = "Delivery No: " + modelInput.DeliveryNo;
            cellDeliveryNo.SetCellValue(strDeliveryNo);

            //Sales No
            ICell cellSalesNo = row1.GetCell(3);
            string strSalesNo = "Sales No: " + modelInput.SalesNo;
            cellSalesNo.SetCellValue(strSalesNo);

            //Quote No
            ICell cellQuoteNo = row1.GetCell(6);
            string strQuoteNo = "Quote No: " + modelInput.QuoteNo;
            cellQuoteNo.SetCellValue(strQuoteNo);

            //Delivery Date
            string strDeliveryDate = "Delivery Date: ";
            ICell cellDeliveryDate = row1.GetCell(10);
            string deliveryDateFrom = string.Empty;
            string deliveryDateTo = string.Empty;
            if (modelInput.DeliveryDateFrom.HasValue)
            {
                deliveryDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.DeliveryDateFrom.Value);
            }
            if (modelInput.DeliveryDateTo.HasValue)
            {
                deliveryDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.DeliveryDateTo.Value);
            }
            if (!string.IsNullOrEmpty(deliveryDateFrom) || !string.IsNullOrEmpty(deliveryDateTo))
            {
                strDeliveryDate = strDeliveryDate + deliveryDateFrom;
                strDeliveryDate = strDeliveryDate.Trim() + " ～ ";
                strDeliveryDate = strDeliveryDate + deliveryDateTo;
            }
            cellDeliveryDate.SetCellValue(strDeliveryDate);

            //Customer
            ICell cellCustomer = row1.GetCell(13);
            string customerName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.CustomerCD.Trim()))
            {
                M_Customer customer = this.GetCustomerModel(modelInput.CustomerCD.Trim());
                if (customer != null)
                {
                    customerName = customer.CustomerName1;
                }
            }
            string strCustomer = "Customer: " + customerName;
            cellCustomer.SetCellValue(strCustomer);

            //Quote No
            ICell cellSerialNo = row1.GetCell(15);
            string strSerialNo = "Quote No: " + modelInput.SerialNo;
            cellSerialNo.SetCellValue(strSerialNo);

            //------------------ Row 2 ---------------------
            IRow row2 = sheet.GetRow(2);

            //Prepared
            ICell cellPrepared = row2.GetCell(0);
            string preparedName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.PreparedCD))
            {
                M_User user = this.GetUserModel(modelInput.PreparedCD.Trim());
                if (user != null)
                {
                    preparedName = user.UserName2;
                }
            }

            string strPrepared = "Prepared by: " + preparedName;
            cellPrepared.SetCellValue(strPrepared);

            //Subject
            ICell cellSubject = row2.GetCell(3);
            string subject = "Subject: " + modelInput.Subject;
            cellSubject.SetCellValue(subject);

            ICell cellDeliveryPlace = row2.GetCell(6);
            string deliveryPlace = "Delivery Place: " + modelInput.DeliveryPlace;
            cellDeliveryPlace.SetCellValue(deliveryPlace);

            //DeliveryPlace
            ICell cellDeliveryBy = row2.GetCell(10);
            string deliveryBy = "Delivery by: " + modelInput.DelivererName;
            cellDeliveryBy.SetCellValue(deliveryBy);

            ICell cellLostData = row2.GetCell(13);
            string strLostData = "Finished Data: " + modelInput.FinishName;
            cellLostData.SetCellValue(strLostData);

            ICell cellSalesData = row2.GetCell(15);
            string strSalesData = "Deleted Data: " + modelInput.InvalidName;
            cellSalesData.SetCellValue(strSalesData);
        }

        /// <summary>
        /// Fill data on excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">Data list  of delivery</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<DeliveryExcel> lstData)
        {
            int rowStart = 7;//begin with index = 0
            for (int k = 0; k < lstData.Count; k++)
            {
                //-----------2015/1/20 ISV-Nguyen Start-----------------------//
                if (lstData[k].DeleteFlag == (short)Models.DeleteFlag.Deleted)
                {
                    this.CopyRow(wb, sheet, 5, rowStart + k);
                }
                else if (!String.IsNullOrEmpty(lstData[k].ExpiryDateStr) && lstData[k].ExpiryDate != base.DATE_TIME_DEFAULT && lstData[k].ExpiryDate.Date < DateTime.Today && ((int)lstData[k].FinishFlag == (int)Models.FinishedFlag.NotFinish))
                {
                    this.CopyRow(wb, sheet, 4, rowStart + k);
                }
                else
                {
                    this.CopyRow(wb, sheet, 6, rowStart + k);
                }
                //-----------2015/1/20 ISV-Nguyen End-----------------------//

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //Create cell Deli No.
                ICell cellDeliveryNo = rowTemp.GetCell(0);
                cellDeliveryNo.SetCellValue(lstData[k].DeliveryNo);

                //Create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(1);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //Create cell QuoteNo
                ICell cellQuoteNo = rowTemp.GetCell(2);
                cellQuoteNo.SetCellValue(lstData[k].QuoteNo);

                //Create cell DeliDate
                ICell cellDeliveryDate = rowTemp.GetCell(3);
                cellDeliveryDate.SetCellValue(lstData[k].DeliveryDateStr);

                //Create cell ExpiryDate
                ICell cellExpiryDate = rowTemp.GetCell(4);
                string strExpiryDate = string.Empty;
                if (lstData[k].ExpiryDate != DATE_TIME_DEFAULT)
                {
                    strExpiryDate = lstData[k].ExpiryDateStr;
                }
                cellExpiryDate.SetCellValue(strExpiryDate);

                //Create cell Customer
                ICell cellCustomer = rowTemp.GetCell(5);
                cellCustomer.SetCellValue(lstData[k].CustomerCD + SPACE_EN + lstData[k].CustomerName);

                //Create cell SubjectName
                ICell cellSubject = rowTemp.GetCell(6);
                cellSubject.SetCellValue(lstData[k].SubjectName);

                //Create cell DeliveryPlace
                ICell cellDeliveryPlace = rowTemp.GetCell(7);
                cellDeliveryPlace.SetCellValue(lstData[k].DeliveryPlace);

                //Create cell Total
                ICell cellTotal = rowTemp.GetCell(8);
                cellTotal.SetCellValue((double)lstData[k].Total);

                //Create cell Currency
                ICell cellCurrency = rowTemp.GetCell(9);
                cellCurrency.SetCellValue(lstData[k].Currency);

                //Create cell VAT
                ICell cellVat = rowTemp.GetCell(10);
                cellVat.SetCellValue((double)lstData[k].Vat);

                //create cell MethodVat
                ICell cellMethodVat = rowTemp.GetCell(11);
                cellMethodVat.SetCellValue(lstData[k].MethodVatName);

                //create cell GrandTotal
                ICell cellGrandTotal = rowTemp.GetCell(12);
                cellGrandTotal.SetCellValue((double)lstData[k].GrandTotal);

                //Create cell DelivererName
                ICell cellDeliveredName = rowTemp.GetCell(13);
                cellDeliveredName.SetCellValue(lstData[k].DeliveredName);

                //Create cell Prepared
                ICell cellPreparedName = rowTemp.GetCell(14);
                cellPreparedName.SetCellValue(lstData[k].PreparedName);

                //Create cell Approved
                ICell cellApprovedName = rowTemp.GetCell(15);
                cellApprovedName.SetCellValue(lstData[k].ApprovedName);

                //Create cell Memo
                ICell cellMemo = rowTemp.GetCell(16);
                cellMemo.SetCellValue(lstData[k].Memo);
            }

            if (lstData.Count <= 3)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }
    }
}

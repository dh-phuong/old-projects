﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using NPOI.SS.UserModel;
using OMS.DAC;

namespace OMS.Reports.EXCEL
{
    /// <summary>
    /// Sales List Excel Class
    /// </summary>
    public class SalesListExcel : BaseExcel
    {
        #region Constant
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        #region Variable
        /// <summary>
        /// Model Quotation Header Search
        /// </summary>
        public SalesHeaderSearch modelInput;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<SalesExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Sales");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Sales List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// Get list for excel
        /// </summary>
        /// <returns>IList SalesExcel</returns>
        private IList<SalesExcel> GetListForExcel()
        {
            IList<SalesExcel> results = null;
            //SalesHeaderSearch modelInput = this.GetSearchModel();

            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);
                results = sales_HService.GetListForExcel(modelInput);
            }
            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //-------------- Row 1 -------------
            IRow row1 = sheet.GetRow(1);

            //Sales No
            ICell cellSalesNo = row1.GetCell(0);
            string strSalesNo = "Sales No: " + modelInput.SalesNo;
            cellSalesNo.SetCellValue(strSalesNo);

            //Quote No
            ICell cellQuoteNo = row1.GetCell(3);
            string strQuoteNo = "Quote No: " + modelInput.QuoteNo;
            cellQuoteNo.SetCellValue(strQuoteNo);

            //Sales Date
            string strSalesDate = "Sales Date: ";
            ICell cellSalesDate = row1.GetCell(6);
            string salesDateFrom = string.Empty;
            string salesDateTo = string.Empty;
            if (modelInput.SalesDateFrom.HasValue)
            {
                salesDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.SalesDateFrom.Value);
            }
            if (modelInput.SalesDateTo.HasValue)
            {
                salesDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.SalesDateTo.Value);
            }
            if (!string.IsNullOrEmpty(salesDateFrom) || !string.IsNullOrEmpty(salesDateTo))
            {
                strSalesDate = strSalesDate + salesDateFrom;
                strSalesDate = strSalesDate.Trim() + " ～ ";
                strSalesDate = strSalesDate + salesDateTo;
            }
            cellSalesDate.SetCellValue(strSalesDate);

            //Customer
            ICell cellCustomer = row1.GetCell(8);
            string customerName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.CustomerCD.Trim()))
            {
                M_Customer customer = this.GetCustomer(modelInput.CustomerCD.Trim());
                if (customer != null)
                {
                    customerName = customer.CustomerName1;
                }
            }
            string strCustomer = "Customer: " + customerName;
            cellCustomer.SetCellValue(strCustomer);

            //Prepared
            ICell cellPrepared = row1.GetCell(13);
            string preparedName = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.PreparedCD.Trim()))
            {
                M_User user = this.GetUser(modelInput.PreparedCD.Trim());
                if (user != null)
                {
                    preparedName = user.UserName2;
                }
            }
            string strPrepared = "Prepared by: " + preparedName;
            cellPrepared.SetCellValue(strPrepared);

            //-------------- Row 2 -------------
            IRow row2 = sheet.GetRow(2);

            //Sales 1
            ICell cellSales1 = row2.GetCell(0);
            string sales1Name = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.Sale1CD.Trim()))
            {
                M_User user = this.GetUser(modelInput.Sale1CD.Trim());
                if (user != null)
                {
                    sales1Name = user.UserName2;
                }
            }
            string strSales1 = "Sales 1: " + sales1Name;
            cellSales1.SetCellValue(strSales1);

            //Sales 2
            ICell cellSales2 = row2.GetCell(3);
            string sales2Name = string.Empty;
            if (!string.IsNullOrEmpty(modelInput.Sale2CD.Trim()))
            {
                M_User user = this.GetUser(modelInput.Sale2CD.Trim());
                if (user != null)
                {
                    sales2Name = user.UserName2;
                }
            }
            string strSales2 = "Sales 2: " + sales2Name;
            cellSales2.SetCellValue(strSales2);

            //Subject
            ICell cellSubject = row2.GetCell(6);
            string strSubject = "Subject: " + modelInput.SubjectName;
            cellSubject.SetCellValue(strSubject);

            //Finished Data
            ICell cellFinishedData = row2.GetCell(8);
            string strFinishedData = "Finished Data: " + modelInput.FinishedName;
            cellFinishedData.SetCellValue(strFinishedData);

            //Deleted Data
            ICell cellDeletedData = row2.GetCell(13);
            string strDeletedData = "Deleted Data: " + modelInput.FailedName;
            cellDeletedData.SetCellValue(strDeletedData);
        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="wb">IWorkbook</param>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List SalesExcel</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<SalesExcel> lstData)
        {
            int rowStart = 7;
            for (int k = 0; k < lstData.Count; k++)
            {
                //------------- Edited by ISV-GIAM  --------------
                if (lstData[k].StatusFlag == (short)Models.StatusFlag.Lost)
                {
                    this.CopyRow(wb, sheet, 5, rowStart + k);
                }
                else if (!String.IsNullOrEmpty(lstData[k].CompleteDateStr) && lstData[k].CompleteDate != DEFAULT_DATE_TIME && 
                    lstData[k].CompleteDate.Date < DateTime.Today && ((int)lstData[k].FinishFlag == (int)Models.FinishedFlag.NotFinish))
                {
                    this.CopyRow(wb, sheet, 4, rowStart + k);
                }
                else
                {
                    this.CopyRow(wb, sheet, 6, rowStart + k);
                }
                //------------------------------------------------

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(0);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //create cell QuoteNo
                ICell cellQuoteNo = rowTemp.GetCell(1);
                cellQuoteNo.SetCellValue(lstData[k].QuoteNo);

                //create cell SalesDate
                ICell cellSalesDate = rowTemp.GetCell(2);
                cellSalesDate.SetCellValue(lstData[k].SalesDateStr);

                //create cell QuoteDate
                ICell cellQuoteDate = rowTemp.GetCell(3);
                cellQuoteDate.SetCellValue(lstData[k].QuoteDateStr);

                ICell cellCompleteDate = rowTemp.GetCell(4);
                string strCompleteDate = string.Empty;
                if (lstData[k].CompleteDate != DEFAULT_DATE_TIME)
                {
                    strCompleteDate = lstData[k].CompleteDateStr;
                }
                cellCompleteDate.SetCellValue(strCompleteDate);

                ICell cellPaymentDate = rowTemp.GetCell(5);
                string strPaymentDate = string.Empty;
                if (lstData[k].PaymentDate != DEFAULT_DATE_TIME)
                {
                    strPaymentDate = lstData[k].PaymentDateStr;
                }
                cellPaymentDate.SetCellValue(strPaymentDate);

                //create cell Customer
                ICell cellCustomer = rowTemp.GetCell(6);
                cellCustomer.SetCellValue(lstData[k].CustomerName);

                //create cell SubjectName
                ICell cellSubject = rowTemp.GetCell(7);
                cellSubject.SetCellValue(lstData[k].SubjectName);

                //create cell ProfitRatio
                ICell cellProfitRatio = rowTemp.GetCell(8);
                cellProfitRatio.SetCellValue((double)lstData[k].ProfitRatio);

                //create cell Total
                ICell cellTotal = rowTemp.GetCell(9);
                cellTotal.SetCellValue((double)lstData[k].Total);

                //create cell Vat
                ICell cell38 = rowTemp.GetCell(10);
                cell38.SetCellValue(lstData[k].Currency);

                //create cell Vat
                ICell cellVat = rowTemp.GetCell(11);
                cellVat.SetCellValue((double)lstData[k].Vat);

                //create cell MethodVat
                ICell cellMethodVat = rowTemp.GetCell(12);
                cellMethodVat.SetCellValue(lstData[k].MethodVatName);

                //create cell GrandTotal
                ICell cellGrandTotal = rowTemp.GetCell(13);
                cellGrandTotal.SetCellValue((double)lstData[k].GrandTotal);

                //create cell StatusFlagName
                ICell cellStatusFlag = rowTemp.GetCell(14);
                cellStatusFlag.SetCellValue(lstData[k].StatusFlagName);

                //create cell SalesName1
                ICell cellSalesName1 = rowTemp.GetCell(15);
                cellSalesName1.SetCellValue(lstData[k].SalesName1);

                //create cell SalesName2
                ICell cellSalesName2 = rowTemp.GetCell(16);
                cellSalesName2.SetCellValue(lstData[k].SalesName2);

                //create cell PreparedName
                ICell cellPreparedName = rowTemp.GetCell(17);
                cellPreparedName.SetCellValue(lstData[k].PreparedName);

                //create cell ApprovedName
                ICell cellApprovedName = rowTemp.GetCell(18);
                cellApprovedName.SetCellValue(lstData[k].ApprovedName);

                //create cell Memo
                ICell cellMemo = rowTemp.GetCell(19);
                cellMemo.SetCellValue(lstData[k].Memo);
            }

            if (lstData.Count <= 2)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUser(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }
    }
}

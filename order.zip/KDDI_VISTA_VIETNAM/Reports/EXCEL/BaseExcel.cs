﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;

using OMS.Utilities;

using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.SS.Util;

namespace OMS.Reports.EXCEL
{
    public class BaseExcel
    {
        #region Constant
        protected DateTime DATE_TIME_DEFAULT = new DateTime(1900, 1, 1);
        public const string SPACE_EN = " ";
        public const string SPACE_WITH_POINT = "......";
        public const string SPACE_WITH_POINT_DATE = "....................................";
        #endregion

        /// <summary>
        /// Create Workbook
        /// </summary>
        /// <param name="fileName">File Name</param>
        /// <returns>Workbook</returns>
        protected IWorkbook CreateWorkbook(string fileName, bool isIsvExcel = false)
        {
            if (!isIsvExcel)
            {
                using (FileStream temp = new FileStream(HttpContext.Current.Server.MapPath("~") + "/TemplateExcel/" + fileName + ".xls", FileMode.Open, FileAccess.Read))
                {
                    return new HSSFWorkbook(temp);
                }
            }
            else
            {
                using (FileStream temp = new FileStream(HttpContext.Current.Server.MapPath("~") + "/TemplateExcel_ISV/" + fileName + ".xls", FileMode.Open, FileAccess.Read))
                {
                    return new HSSFWorkbook(temp);
                }
            }
        }

        /// <summary>
        /// Copy Row
        /// </summary>
        /// <param name="workBook">IWorkbook</param>
        /// <param name="workSheet">ISheet</param>
        /// <param name="sourceRowNum">SourceRowNum</param>
        /// <param name="destinationRowNum">DestinationRowNum</param>
        protected void CopyRow(IWorkbook workBook, ISheet workSheet, int sourceRowNum, int destinationRowNum)
        {

            // Get the source / new row
            IRow newRow = workSheet.GetRow(destinationRowNum);
            IRow sourceRow = workSheet.GetRow(sourceRowNum);

            // If the row exist in destination, push down all rows by 1 else create a new row
            if (newRow != null)
            {
                workSheet.ShiftRows(destinationRowNum, workSheet.LastRowNum, 1, true, true);
            }
            else
            {
                newRow = workSheet.CreateRow(destinationRowNum);
            }

            // Loop through source columns to add to new row
            for (int i = 0; i < sourceRow.LastCellNum; i++)
            {
                // Grab a copy of the old/new cell
                ICell oldCell = sourceRow.GetCell(i);
                ICell newCell = newRow.CreateCell(i);

                // If the old cell is null jump to next cell
                if (oldCell == null)
                {
                    newCell = null;
                    continue;
                }

                // Copy style from old cell and apply to new cell
                //ICellStyle newCellStyle = workbook.CreateCellStyle();
                //newCellStyle.CloneStyleFrom(oldCell.CellStyle); ;
                newCell.CellStyle = oldCell.CellStyle;

                // If there is a cell comment, copy
                if (newCell.CellComment != null) newCell.CellComment = oldCell.CellComment;

                // If there is a cell hyperlink, copy
                if (oldCell.Hyperlink != null) newCell.Hyperlink = oldCell.Hyperlink;

                // Set the cell data type
                newCell.SetCellType(oldCell.CellType);

                // Set the cell data value
                switch (oldCell.CellType)
                {
                    case CellType.Blank:
                        newCell.SetCellValue(oldCell.StringCellValue);
                        break;
                    case CellType.Boolean:
                        newCell.SetCellValue(oldCell.BooleanCellValue);
                        break;
                    case CellType.Error:
                        newCell.SetCellErrorValue(oldCell.ErrorCellValue);
                        break;
                    case CellType.Formula:
                        newCell.SetCellFormula(oldCell.CellFormula);
                        break;
                    case CellType.Numeric:
                        newCell.SetCellValue(oldCell.NumericCellValue);
                        break;
                    case CellType.String:
                        newCell.SetCellValue(oldCell.RichStringCellValue);
                        break;
                    case CellType.Unknown:
                        newCell.SetCellValue(oldCell.StringCellValue);
                        break;
                }
            }

            // If there are are any merged regions in the source row, copy to new row
            for (int i = 0; i < workSheet.NumMergedRegions; i++)
            {
                CellRangeAddress cellRangeAddress = workSheet.GetMergedRegion(i);
                if (cellRangeAddress.FirstRow == sourceRow.RowNum)
                {
                    CellRangeAddress newCellRangeAddress = new CellRangeAddress(newRow.RowNum,
                                                                                (newRow.RowNum +
                                                                                 (cellRangeAddress.FirstRow -
                                                                                  cellRangeAddress.LastRow)),
                                                                                cellRangeAddress.FirstColumn,
                                                                                cellRangeAddress.LastColumn);
                    workSheet.AddMergedRegion(newCellRangeAddress);
                }
            }

        }

        /// <summary>
        /// Set Value Index
        /// </summary>
        /// <param name="wb">Workbook</param>
        /// <param name="sheet">sheet</param>
        /// <param name="keyMap">keyMap</param>
        /// <param name="value">value</param>
        /// <param name="replaceStr">replaceStr</param>
        /// <param name="fomular">fomular</param>
        /// <param name="replaceAll">replaceAll</param>
        protected void SetValueIndex(IWorkbook wb, ISheet sheet, string keyMap, Object value, string replaceStr = "", bool fomular = false, bool replaceAll = false)
        {
            IName range = wb.GetName(keyMap);
            if (range != null && (!range.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName))))
            {
                CellReference cellRef = new CellReference(range.RefersToFormula);
                IRow row = sheet.GetRow(cellRef.Row);
                ICell cell = row.GetCell(cellRef.Col);
                var findCellString = cell.StringCellValue;

                var cellString = string.Empty;

                if (value != null)
                {
                    cellString = value.ToString();
                }

                if (string.IsNullOrEmpty(findCellString))
                {
                    cell.SetCellValue(cellString);
                }
                else
                {
                    if (!string.IsNullOrEmpty(replaceStr) && findCellString.IndexOf(replaceStr) >= 0)
                    {
                        if (replaceAll)
                        {
                            findCellString = findCellString.Replace(replaceStr, cellString);
                        }
                        else
                        {
                            var endPoint = findCellString.IndexOf(replaceStr);
                            var tempStr1 = findCellString.Substring(0, endPoint + replaceStr.Length);
                            var tempStr2 = tempStr1.Replace(replaceStr, cellString);
                            findCellString = findCellString.Replace(tempStr1, tempStr2);
                        }
                        cell.SetCellValue(findCellString);
                    }
                }
            }
        }

        /// <summary>
        /// Get Day String
        /// </summary>
        /// <param name="value">Date</param>
        /// <returns></returns>
        protected string GetDayString(DateTime value)
        {
            switch (value.Day)
            {
                case 1:
                case 21:
                case 31:
                    return value.Day.ToString("00") + "st";
                case 2:
                case 22:
                    return value.Day.ToString("00") + "nd";
                case 3:
                case 23:
                    return value.Day.ToString("00") + "rd";
                default:
                    return value.Day.ToString("00") + "th";
            }
        }

        /// <summary>
        /// Get Month String
        /// </summary>
        /// <param name="value">Date</param>
        /// <returns></returns>
        protected string GetMonthString(DateTime value)
        {
            switch (value.Month)
            {
                case 1:
                    return "January";
                case 2:
                    return "Feburary";
                case 3:
                    return "March";
                case 4:
                    return "April ";
                case 5:
                    return "May";
                case 6:
                    return "June ";
                case 7:
                    return "July";
                case 8:
                    return "August";
                case 9:
                    return "September";
                case 10:
                    return "October";
                case 11:
                    return "November";
                default:
                    return "December";
            }
        }

        /// <summary>
        /// Spell Number
        /// </summary>
        /// <param name="myNumber"></param>
        /// <param name="currentCulture"></param>
        /// <param name="currencyUnit"></param>
        /// <param name="currencyUnitSmall"></param>
        /// <returns></returns>
        protected string GetDispNumberStr(decimal value, Language currentCulture, string currencyUnit, string currencyUnitSmall = "")
        {
            decimal tmp = Convert.ToDecimal(string.Format("{0}", value).Replace(",", ""));
            string strVal = Math.Abs(tmp).ToString();
            if (currentCulture == Language.English)
            {
                return ReadNumber(strVal, currencyUnit, currencyUnitSmall);
            }
            else
            {
                return ChuyenSo(strVal, currencyUnit, currencyUnitSmall);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="DateValue"></param>
        /// <param name="language"></param>
        /// <returns></returns>
        protected string GetDateString(DateTime DateValue, Language language)
        {
            if (language == Language.Vietnam)
            {
                dynamic StrDate = string.Format("ngày {0} tháng {1} năm {2}", DateValue.Day.ToString("00"), DateValue.Month.ToString("00"), DateValue.Year.ToString("0000"));
                return StrDate;
            }
            else if (language == Language.Japan)
            {
                dynamic StrDate = string.Format("{0}年月{1}日{2}", DateValue.Year.ToString("0000"), DateValue.Month.ToString("00"), DateValue.Day.ToString("00"));//DateValue.ToString("yyyy年MM月dd日");
                return StrDate;
            }
            else
            {
                dynamic SuffixDay = string.Empty;
                dynamic SuffixMoth = string.Empty;

                switch (DateValue.Day)
                {
                    case 1:
                    case 21:
                    case 31:
                        SuffixDay = "st";
                        break;
                    case 2:
                    case 22:
                        SuffixDay = "nd";
                        break;
                    case 3:
                    case 23:
                        SuffixDay = "rd";
                        break;
                    default:
                        SuffixDay = "th";
                        break;
                }
                switch (DateValue.Month)
                {
                    case 1:
                        SuffixMoth = "January";
                        break;
                    case 2:
                        SuffixMoth = "Feburary";
                        break;
                    case 3:
                        SuffixMoth = "March";
                        break;
                    case 4:
                        SuffixMoth = "April ";
                        break;
                    case 5:
                        SuffixMoth = "May";
                        break;
                    case 6:
                        SuffixMoth = "June ";
                        break;
                    case 7:
                        SuffixMoth = "July";
                        break;
                    case 8:
                        SuffixMoth = "August";
                        break;
                    case 9:
                        SuffixMoth = "September";
                        break;
                    case 10:
                        SuffixMoth = "October";
                        break;
                    case 11:
                        SuffixMoth = "November";
                        break;
                    case 12:
                        SuffixMoth = "December";
                        break;
                }
                return string.Format("{0} {1}{2}, {3}", SuffixMoth, DateValue.Day.ToString("00"), SuffixDay, DateValue.Year.ToString("0000"));
            }
        }

        /// <summary>
        /// Get Row Height
        /// </summary>
        /// <param name="enterList">enterList</param>
        /// <param name="rowCount">rowCount</param>
        /// <param name="length">length</param>
        /// <returns>row Height</returns>
        protected short GetHeight(string[] enterList, int rowCount, int length, int defaultRowHeight)
        {
            foreach (var item in enterList)
            {
                if (item.Length > length)
                {
                    int _temp = 0;
                    _temp = (int)Math.Truncate((double)item.Length / length);
                    rowCount += _temp;
                }
            }
            return (short)(rowCount * defaultRowHeight);
        }

        #region Read number in Vietnamese

        /// <summary>
        /// cap do cua gia tri tien te
        /// </summary>
        /// <remarks></remarks>
        private enum CurrencyLevel : int
        {

            /// <summary>
            /// hang tram
            /// </summary>
            /// <remarks></remarks>
            Tram = 0,

            /// <summary>
            /// hang nghin
            /// </summary>
            /// <remarks></remarks>
            Nghin = 1,

            /// <summary>
            /// hang trieu
            /// </summary>
            /// <remarks></remarks>
            Trieu = 2,

            /// <summary>
            /// hang ty
            /// </summary>
            /// <remarks></remarks>
            Ty = 3

        }

        /// <summary>
        /// doc so thanh mot chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ChuyenSo(string NumberStr, string CurrencyUnit, string CurrencyUnitSmall)
        {

            if (string.IsNullOrEmpty(NumberStr.Trim()))
                return string.Empty;
            decimal decNum = Convert.ToDecimal(NumberStr);

            //Number interger (lay phan nguyen)
            string intNumStr = Math.Truncate(decNum).ToString();

            //Number decimal (lay phan thap phan (sau dau phay))
            string decimalNumStr = decNum.ToString().Substring(intNumStr.Length);

            //chuoi so tra ve
            string readNumberString = string.Empty;

            //kiem tra so am

            if (NumberStr.IndexOf("-") >= 0 && NumberStr.IndexOf("-") == 0)
            {
                // doc theo so am
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();


                readNumberString = "âm " + ReadNumberToString(intNumStr.Replace("-", "")).Trim() + " " + CurrencyUnit + decimalNumStr;

            }
            else
            {
                //doc so binh thuong

                //doc 2 so sau dau phay
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();

                readNumberString = ReadNumberToString(intNumStr).Trim() + " " + CurrencyUnit + decimalNumStr;

            }

            if (string.IsNullOrEmpty(readNumberString))
            {
                return string.Empty;

            }
            else
            {
                //dinh dang chuoi tra ve
                readNumberString = readNumberString.ToLower().Trim();

                //lay ki tu dau tien de viet hoa
                string FirstCharacter = readNumberString[0].ToString();

                //viet hoa donvi tien te
                if (readNumberString.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    readNumberString = readNumberString.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }

                //viet hoa chu dau
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), readNumberString.Substring(1));
            }


        }

        /// <summary>
        /// chuyen so thanh chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumberToString(string NumberStr)
        {


            if (NumberStr.Length > 3)
            {

                if (NumberStr.Length % 3 == 0)
                {
                    //Kiem tra neu chuoi so chua so khong het, thi khoi doc cac so dang sau
                    bool isZero = true;
                    for (int index = 0; index <= NumberStr.Length - 1; index++)
                    {
                        if (!NumberStr[index].Equals("0"))
                        {
                            isZero = false;
                        }
                    }
                    if (isZero)
                    {
                        return string.Empty;
                    }

                    //---------------- doc so lon hon hang ty

                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse((Math.Truncate(temp) - 1).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;
                        }
                    }

                    //-------------------------------------------
                    //lay 3 so dau
                    string NumTemp = NumberStr.Substring(0, 3);

                    // neu la 3 so 0 thi doc tiep day con lai
                    if (Convert.ToInt32(NumTemp) == 0)
                    {

                        return ReadNumberToString(NumberStr.Substring(NumTemp.Length));

                    }


                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));


                }
                else
                {
                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse(Math.Truncate(temp).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;

                        }
                    }

                    //lay ra so co hang don vi tien lon nhat
                    string NumTemp = NumberStr.Substring(0, NumberStr.Length % 3);

                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));
                }


            }
            else
            {
                //doc 3 so cuoi
                return ReadNumber3Digit(NumberStr);

            }


        }

        /// <summary>
        /// doc chuoi so voi 3 chu so
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber3Digit(string readNumber)
        {

            string hangTram = string.Empty;
            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = string.Empty;


            if (readNumber.Length == 3)
            {
                //lay so o hang tram
                hangTram = readNumber[0].ToString();

                //lay so o hang chuc
                hangChuc = readNumber[1].ToString();

                //lay do o hang don vi
                hangDonVi = readNumber[2].ToString();

            }
            else if (readNumber.Length == 2)
            {
                hangChuc = readNumber[0].ToString();
                hangDonVi = readNumber[1].ToString();
            }
            else
            {
                hangDonVi = readNumber[0].ToString();
            }
            if (hangTram == "0" && hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }


            if (!string.IsNullOrEmpty(hangTram) && !string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                //Doc so hang Tram
                readString += NumberString(Convert.ToInt32(hangTram)) + " trăm";

                // doc so hang chuc
                if (hangChuc == "0" && hangDonVi == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "0")
                {
                    readString += " lẻ";
                }
                else if (hangChuc == "1")
                {
                    readString += " mười";
                }
                else
                {
                    readString += " " + NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi));
            }

            return readString;

        }

        /// <summary>
        /// doc so le (2 chu so)
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber2Decimal(string readNumber)
        {


            if (string.IsNullOrEmpty(readNumber))
                return string.Empty;
            if (readNumber.Length > 3)
            {
                readNumber = readNumber.Substring(0, 3);
            }

            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = "và ";
            if (readNumber.Length == 3)
            {
                hangChuc = readNumber[1].ToString();
                hangDonVi = readNumber[2].ToString();
            }
            else if (readNumber.Length == 2)
            {
                hangDonVi = readNumber[1].ToString();
            }
            if (hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }

            if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString = readString.Trim();
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi)) + " mươi";
            }


            return readString;
        }

        /// <summary>
        /// so kieu chuoi
        /// </summary>
        /// <param name="intNum"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string NumberString(int intNum)
        {

            string ret = string.Empty;
            switch (intNum)
            {
                case 0:
                    ret = "không";
                    break;
                case 1:
                    ret = "một";
                    break;
                case 2:
                    ret = "hai";
                    break;
                case 3:
                    ret = "ba";
                    break;
                case 4:
                    ret = "bốn";
                    break;
                case 5:
                    ret = "năm";
                    break;
                case 6:
                    ret = "sáu";
                    break;
                case 7:
                    ret = "bảy";
                    break;
                case 8:
                    ret = "tám";
                    break;
                case 9:
                    ret = "chín";
                    break;
                case 10:
                    ret = "mười";
                    break;
            }

            return ret;
        }

        #endregion

        #region Read number in English

        /// <summary>
        /// Read number by English
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <param name="CurrencyUnit"></param>
        /// <param name="CurrencyUnitSmall"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string ReadNumber(string MyNumber, string CurrencyUnit, string CurrencyUnitSmall)
        {
            string Dollars = "";
            string Cents = "";
            string Temp = "";
            int DecimalPlace = 0;
            int Count = 0;
            string[] Place = new string[10];
            Place[2] = "Thousand ";
            Place[3] = "Million ";
            Place[4] = "Billion ";
            Place[5] = "Trillion ";
            // String representation of amount.
            if (string.IsNullOrEmpty(MyNumber))
            {
                return string.Empty;
            }
            MyNumber = MyNumber.Trim();
            // Position of decimal place 0 if none.
            DecimalPlace = MyNumber.IndexOf(".");
            // Convert cents and set MyNumber to dollar amount.
            if (DecimalPlace > 0)
            {
                Cents = GetTens(CommonUtil.Left(CommonUtil.Mid(MyNumber, DecimalPlace + 2) + "00", 2));
                MyNumber = (CommonUtil.Left(MyNumber, DecimalPlace)).Trim();
            }
            Count = 1;
            while (!string.IsNullOrEmpty(MyNumber))
            {
                Temp = GetHundreds(CommonUtil.Right(MyNumber, 3));
                if (!string.IsNullOrEmpty(Temp))
                    Dollars = Temp + Place[Count] + Dollars;
                if (MyNumber.Length > 3)
                {
                    MyNumber = CommonUtil.Left(MyNumber, MyNumber.Length - 3);
                }
                else
                {
                    MyNumber = "";
                }
                Count = Count + 1;
            }
            switch (Dollars)
            {
                case "":
                    Dollars = "Zero " + CurrencyUnit;
                    break;
                case "One":
                    Dollars = "One " + CurrencyUnit;
                    break;
                default:
                    Dollars = Dollars + CurrencyUnit;
                    break;
            }
            switch (Cents)
            {
                case "":
                    break;
                //Cents = " Only"
                case "One":
                    Cents = " and One " + CurrencyUnitSmall;
                    break;
                default:
                    Cents = " and " + Cents + CurrencyUnitSmall;
                    break;
            }

            Dollars = Dollars + Cents;
            if (string.IsNullOrEmpty(Dollars))
            {
                return string.Empty;
            }
            else
            {
                Dollars = Dollars.ToLower().Trim();
                if (Dollars.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    Dollars = Dollars.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }
                dynamic FirstCharacter = Dollars[0];
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), Dollars.Substring(1));
            }

        }

        /// <summary>
        /// Get number Hundreds
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetHundreds(string MyNumber)
        {
            string functionReturnValue = null;
            string Result = string.Empty;
            if (int.Parse(MyNumber) == 0)
            {
                return "";
                //return functionReturnValue;
            }
            MyNumber = CommonUtil.Right("000" + MyNumber, 3);
            // Convert the hundreds place.
            if (CommonUtil.Mid(MyNumber, 1, 1) != "0")
            {
                Result = GetDigit(CommonUtil.Mid(MyNumber, 1, 1)) + "Hundred ";
            }
            // Convert the tens and ones place.
            if (CommonUtil.Mid(MyNumber, 2, 1) != "0")
            {
                Result = Result + GetTens(CommonUtil.Mid(MyNumber, 2));
            }
            else
            {
                Result = Result + GetDigit(CommonUtil.Mid(MyNumber, 3));
            }
            functionReturnValue = Result;
            return functionReturnValue;
        }

        /// <summary>
        /// Get Number Tens
        /// </summary>
        /// <param name="TensText"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetTens(string TensText)
        {
            string Result = "";
            // Null out the temporary function value.
            // If value between 10-19...
            if (int.Parse(CommonUtil.Left(TensText, 1)) == 1)
            {
                switch (int.Parse(TensText))
                {
                    case 10:
                        Result = "Ten ";
                        break;
                    case 11:
                        Result = "Eleven ";
                        break;
                    case 12:
                        Result = "Twelve ";
                        break;
                    case 13:
                        Result = "Thirteen ";
                        break;
                    case 14:
                        Result = "Fourteen ";
                        break;
                    case 15:
                        Result = "Fifteen ";
                        break;
                    case 16:
                        Result = "Sixteen ";
                        break;
                    case 17:
                        Result = "Seventeen ";
                        break;
                    case 18:
                        Result = "Eighteen ";
                        break;
                    case 19:
                        Result = "Nineteen ";
                        break;
                    default:
                        break;
                }
                // If value between 20-99...
            }
            else
            {
                switch (int.Parse(CommonUtil.Left(TensText, 1)))
                {
                    case 2:
                        Result = "Twenty ";
                        break;
                    case 3:
                        Result = "Thirty ";
                        break;
                    case 4:
                        Result = "Forty ";
                        break;
                    case 5:
                        Result = "Fifty ";
                        break;
                    case 6:
                        Result = "Sixty ";
                        break;
                    case 7:
                        Result = "Seventy ";
                        break;
                    case 8:
                        Result = "Eighty ";
                        break;
                    case 9:
                        Result = "Ninety ";
                        break;
                    default:
                        break;
                }
                Result = Result + GetDigit(CommonUtil.Right(TensText, 1));
                // Retrieve ones place.
            }
            return Result;
        }

        /// <summary>
        /// Get Number Digits
        /// </summary>
        /// <param name="Digit"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private string GetDigit(string Digit)
        {
            string functionReturnValue = null;
            switch (int.Parse(Digit))
            {
                case 1:
                    functionReturnValue = "One ";
                    break;
                case 2:
                    functionReturnValue = "Two ";
                    break;
                case 3:
                    functionReturnValue = "Three ";
                    break;
                case 4:
                    functionReturnValue = "Four ";
                    break;
                case 5:
                    functionReturnValue = "Five ";
                    break;
                case 6:
                    functionReturnValue = "Six ";
                    break;
                case 7:
                    functionReturnValue = "Seven ";
                    break;
                case 8:
                    functionReturnValue = "Eight ";
                    break;
                case 9:
                    functionReturnValue = "Nine ";
                    break;
                default:
                    functionReturnValue = "";
                    break;
            }
            return functionReturnValue;
        }

        #endregion
    }
}

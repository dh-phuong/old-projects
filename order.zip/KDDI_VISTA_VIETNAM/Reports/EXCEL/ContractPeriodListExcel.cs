﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using NPOI.SS.UserModel;
using OMS.Models;
using OMS.DAC;
using OMS.Utilities;

namespace OMS.Reports.EXCEL
{
    public class ContractPeriodListExcel : BaseExcel
    {
        #region Variable
        /// <summary>
        /// deliveryListDateFrom;
        /// </summary>
        public ContractPeriodSearch modelInput;

        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<ContractPeriodExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("ContractPeriodList");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Contract Period");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList<QuotationeExcel></returns>
        private IList<ContractPeriodExcel> GetListForExcel()
        {
            IList<ContractPeriodExcel> results = null;

            using (DB db = new DB())
            {
                Delivery_HService delivery_HService = new Delivery_HService(db);
                results = delivery_HService.GetListForContractPeriodExcel(modelInput);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            //Customer
            ICell cellCustomer = row1.GetCell(0);
            string customerName = "Customer: " ;

            if (!string.IsNullOrEmpty(modelInput.CustomerCD.Trim()))
            {
                M_Customer customer = this.GetCustomerModel(modelInput.CustomerCD.Trim());
                if (customer != null)
                {
                    customerName += customer.CustomerName1;
                }
            }
            cellCustomer.SetCellValue(customerName);


            //StartDate
            string strStartDate = "Start Date: ";
            ICell cellStartDate = row1.GetCell(2);
            string stDateFrom = string.Empty;
            string stDateTo = string.Empty;
            if (modelInput.StartDateFrom.HasValue)
            {
                stDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.StartDateFrom.Value);
            }
            if (modelInput.StartDateTo.HasValue)
            {
                stDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.StartDateTo.Value);
            }
            if (!string.IsNullOrEmpty(stDateFrom) || !string.IsNullOrEmpty(stDateTo))
            {
                strStartDate = strStartDate + stDateFrom;
                strStartDate = strStartDate.Trim() + " ～ ";
                strStartDate = strStartDate + stDateTo;
            }
            cellStartDate.SetCellValue(strStartDate);


            //EndDate
            string strEndDate = "End Date: ";
            ICell cellEndDate = row1.GetCell(4);
            string endDateFrom = string.Empty;
            string endDateTo = string.Empty;
            if (modelInput.EndDateFrom.HasValue)
            {
                endDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.EndDateFrom.Value);
            }
            if (modelInput.EndDateTo.HasValue)
            {
                endDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, modelInput.EndDateTo.Value);
            }
            if (!string.IsNullOrEmpty(endDateFrom) || !string.IsNullOrEmpty(endDateTo))
            {
                strEndDate = strEndDate + endDateFrom;
                strEndDate = strEndDate.Trim() + " ～ ";
                strEndDate = strEndDate + endDateTo;
            }
            cellEndDate.SetCellValue(strEndDate);

            //Customer
            ICell cellContractType = row1.GetCell(6);
            string contractType = "Contract Type: " + modelInput.ContractTypeName;
            cellContractType.SetCellValue(contractType);


        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<ContractPeriodExcel> lstData)
        {
            int rowStart = 6;
            string format = this.GetDefaultValueQuantity();
            for (int k = 0; k < lstData.Count; k++)
            {
                if (lstData[k].Color == (int)ColorList.Warning)
                {
                    this.CopyRow(wb, sheet, 3, rowStart + k);
                }
                else if (lstData[k].Color == (int)ColorList.Danger)
                {
                    this.CopyRow(wb, sheet, 4, rowStart + k);
                }
                else
                {
                    this.CopyRow(wb, sheet, 5, rowStart + k);
                }

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell Customer
                ICell cellCustomer = rowTemp.GetCell(0);
                cellCustomer.SetCellValue(lstData[k].CustomerName);

                //create cell SalesDate
                ICell cellSalesDate = rowTemp.GetCell(1);
                if (lstData[k].SalesDate == base.DATE_TIME_DEFAULT)
                {
                    cellSalesDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellSalesDate.SetCellValue(lstData[k].SalesDateStr);
                }

                //create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(2);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //create cell cellDeliveryDate
                ICell cellDeliveryDate = rowTemp.GetCell(3);
                if (lstData[k].DeliveryDate == base.DATE_TIME_DEFAULT)
                {
                    cellDeliveryDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellDeliveryDate.SetCellValue(lstData[k].DeliveryDateStr);
                }

                //create cell DeliveryNo
                ICell cellDeliveryNo = rowTemp.GetCell(4);
                cellDeliveryNo.SetCellValue(lstData[k].DeliveryNo);

                //create cell ProductName
                ICell cellProductName = rowTemp.GetCell(5);
                cellProductName.SetCellValue(lstData[k].ProductName);

                //create cell ContractType
                ICell cellContractType = rowTemp.GetCell(6);
                cellContractType.SetCellValue(lstData[k].ContractType);


                //create cell StartDate
                ICell cellStartDate = rowTemp.GetCell(7);
                if (lstData[k].StartDate == base.DATE_TIME_DEFAULT)
                {
                    cellStartDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellStartDate.SetCellValue(lstData[k].StartDateStr);
                }

                //create cell StartDate
                ICell cellEndDate = rowTemp.GetCell(8);
                if (lstData[k].EndDate == base.DATE_TIME_DEFAULT)
                {
                    cellEndDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellEndDate.SetCellValue(lstData[k].EndDateStr);
                }

            }

            if (lstData.Count <= 3)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// GetDefaultValueQuantity
        /// </summary>
        /// <returns>format</returns>
        private string GetDefaultValueQuantity()
        {
            string format = string.Empty;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                format = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? Constants.FMT_DECIMAL : Constants.FMT_INTEGER;
            }
            return format;
        }
    }
}

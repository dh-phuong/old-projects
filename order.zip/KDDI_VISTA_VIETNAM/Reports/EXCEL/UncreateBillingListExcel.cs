﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using NPOI.SS.UserModel;
using OMS.DAC;
using OMS.Utilities;

namespace OMS.Reports.EXCEL
{
    public class UncreateBillingListExcel : BaseExcel
    {
        #region Variable
        /// <summary>
        /// billingDateFrom;
        /// </summary>
        public DateTime? billingDateFrom;

        /// <summary>
        /// billingDateTo
        /// </summary>
        public DateTime? billingDateTo;
        #endregion

        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<UncreateBillingExcel> lstData = this.GetListForExcel();

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Uncreate Billing List");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Uncreate Billing List");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <returns>IList<UncreateDeliveryExcel></returns>
        private IList<UncreateBillingExcel> GetListForExcel()
        {
            IList<UncreateBillingExcel> results = null;

            using (DB db = new DB())
            {
                Billing_HService billing_HService = new Billing_HService(db);
                results = billing_HService.GetListForUnCreateBillingListExcel(billingDateFrom, billingDateTo);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            //Sales Date
            string strSalesDate = "Sales Date: ";
            ICell cellQuoteDate = row1.GetCell(0);
            string poDateFrom = string.Empty;
            string poDateTo = string.Empty;
            if (this.billingDateFrom.HasValue)
            {
                poDateFrom = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.billingDateFrom.Value);
            }
            if (this.billingDateTo.HasValue)
            {
                poDateTo = string.Format(OMS.Utilities.Constants.FMT_DATE_DPL, this.billingDateTo.Value);
            }
            if (!string.IsNullOrEmpty(poDateFrom) || !string.IsNullOrEmpty(poDateTo))
            {
                strSalesDate = strSalesDate + poDateFrom;
                strSalesDate = strSalesDate.Trim() + " ～ ";
                strSalesDate = strSalesDate + poDateTo;
            }
            cellQuoteDate.SetCellValue(strSalesDate);

            //QuoteNo
            ICell cellCreation = row1.GetCell(11);
            string creationDate = "Creation: " + DateTime.Now.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
            cellCreation.SetCellValue(creationDate);           
        }

        /// <summary>
        /// Fill Data For Product
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">List Of Vendor</param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<UncreateBillingExcel> lstData)
        {
            int rowStart = 4;
            string format = this.GetDefaultValueQuantity();
            for (int k = 0; k < lstData.Count; k++)
            {
                this.CopyRow(wb, sheet, 3, rowStart + k);

                IRow rowTemp = sheet.GetRow(rowStart + k);

                //create cell SalesDate
                ICell cellSalesDate = rowTemp.GetCell(0);
                if (lstData[k].SalesDate == base.DATE_TIME_DEFAULT)
                {
                    cellSalesDate.SetCellValue(string.Empty);
                }
                else
                {
                    cellSalesDate.SetCellValue(lstData[k].SalesDateStr);
                }

                //create cell SalesNo
                ICell cellSalesNo = rowTemp.GetCell(1);
                cellSalesNo.SetCellValue(lstData[k].SalesNo);

                //create cell Vendor
                ICell cellVendorCd = rowTemp.GetCell(2);
                cellVendorCd.SetCellValue(lstData[k].CustomerCD);

                //create cell Vendor
                ICell cellVendorNm = rowTemp.GetCell(3);
                cellVendorNm.SetCellValue(lstData[k].CustomerName);

                //create cell ProductName
                ICell cellProductName = rowTemp.GetCell(4);
                cellProductName.SetCellValue(lstData[k].ProductName);

                //create cell Quantity
                ICell cellQuantity = rowTemp.GetCell(5);
                cellQuantity.SetCellValue((double)lstData[k].Quantity);

                //create cell UnitPrice
                ICell cellUnitPrice = rowTemp.GetCell(6);
                cellUnitPrice.SetCellValue((double)lstData[k].UnitPrice);                

                //create cell SubTotal
                ICell cellSubTotal = rowTemp.GetCell(7);
                cellSubTotal.SetCellValue((double)lstData[k].SubTotal);

                //create cell Currency
                ICell cellCurrency = rowTemp.GetCell(8);
                cellCurrency.SetCellValue(lstData[k].Currency);

                if (lstData[k].MethodVat == short.Parse(M_Config_D.METHOD_VAT_EACH))
                {
                    //create cell Tax
                    ICell cellTax = rowTemp.GetCell(9);
                    cellTax.SetCellValue(lstData[k].VatTypeName);

                    if (lstData[k].VatType == short.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        //Vat Ratio
                        ICell cellVatRatio = rowTemp.GetCell(10);
                        cellVatRatio.SetCellValue((double)lstData[k].VatRatio);

                        //Vat
                        ICell cellVat = rowTemp.GetCell(11);
                        cellVat.SetCellValue((double)lstData[k].Vat);
                    }
                    else
                    {
                        //Vat Ratio
                        ICell cellVatRatio = rowTemp.GetCell(10);
                        cellVatRatio.SetCellValue(string.Empty);

                        //Vat
                        ICell cellVat = rowTemp.GetCell(11);
                        cellVat.SetCellValue(string.Empty);
                    }
                }
                else
                {
                    //create cell Tax
                    ICell cellTax = rowTemp.GetCell(9);
                    cellTax.SetCellValue("On Total");

                    if (lstData[k].VatTypeTotal == short.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        //Vat Ratio
                        ICell cellVatRatio = rowTemp.GetCell(10);
                        cellVatRatio.SetCellValue((double)lstData[k].VatRatioTotal);

                        //Set value VatTotal
                        if (lstData[k].DecimalType == (short)ExchangeRateDecType.Decimal)
                        {
                            lstData[k].VatTotal = Utilities.Fraction.Round(this.GetFractionType(), (lstData[k].SubTotal * lstData[k].VatRatioTotal) / 100, 2);
                            //lstData[k].VatTotalStr = lstData[k].VatTotal.ToString(Constants.FMT_DECIMAL);
                        }
                        else
                        {
                            lstData[k].VatTotal = Utilities.Fraction.Round(this.GetFractionType(), (lstData[k].SubTotal * lstData[k].VatRatioTotal) / 100, 0);
                            //lstData[k].VatTotalStr = lstData[k].VatTotal.ToString(Constants.FMT_INTEGER);
                        }                        

                        //Vat
                        ICell cellVat = rowTemp.GetCell(11);
                        cellVat.SetCellValue((double)lstData[k].VatTotal);
                    }
                    else
                    {
                        //Vat Ratio
                        ICell cellVatRatio = rowTemp.GetCell(10);
                        cellVatRatio.SetCellValue(string.Empty);

                        //Vat
                        ICell cellVat = rowTemp.GetCell(11);
                        cellVat.SetCellValue(string.Empty);
                    }                    
                }
            }

            if (lstData.Count <= 1)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 1, -1);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -1);
            }
        }

        /// <summary>
        /// GetDefaultValueQuantity
        /// </summary>
        /// <returns>format</returns>
        private string GetDefaultValueQuantity()
        {
            string format = string.Empty;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                format = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? Constants.FMT_DECIMAL : Constants.FMT_INTEGER;
            }
            return format;
        }

        /// <summary>
        /// Get Fraction Type
        /// </summary>
        /// <returns></returns>
        private FractionType GetFractionType()
        {
            using (DB db = new DB())
            {
                Config_HService configHService = new Config_HService(db);
                return (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

using OMS.Models;
using OMS.DAC;

using NPOI.SS.UserModel;

namespace OMS.Reports.EXCEL
{
    public class VendorListExcel : BaseExcel
    {
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<VendorExcel> lstData = this.GetListExcel();
            if (lstData.Count != 0)
            {
                wb = this.CreateWorkbook("Vendor");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Vendor List");

                int rowStart = 5;//row start fill data
                for (int k = 0; k < lstData.Count; k++)
                {
                    //Check status
                    if (lstData[k].StatusFlag == 0)
                    {
                        this.CopyRow(wb, sheet, 3, rowStart + k);
                    }
                    else
                    {
                        this.CopyRow(wb, sheet, 4, rowStart + k);
                    }

                    IRow rowTemp = sheet.GetRow(rowStart + k);

                    //No.
                    ICell cellNo = rowTemp.GetCell(0);
                    cellNo.SetCellValue(k + 1);

                    //Code
                    ICell cellVendorCD = rowTemp.GetCell(1);
                    cellVendorCD.SetCellValue(lstData[k].VendorCD);

                    //Name 1
                    ICell cellVendorName1 = rowTemp.GetCell(2);
                    cellVendorName1.SetCellValue(lstData[k].VendorName1);

                    //Name 2
                    ICell cellVendorName2 = rowTemp.GetCell(3);
                    cellVendorName2.SetCellValue(lstData[k].VendorName2);

                    //Address
                    ICell cellAddress = rowTemp.GetCell(4);
                    string address = lstData[k].VendorAddress1 + SPACE_EN + lstData[k].VendorAddress2 + SPACE_EN + lstData[k].VendorAddress3;
                    cellAddress.SetCellValue(address);

                    //Business GroupSupply
                    ICell cellGroupSupply = rowTemp.GetCell(5);
                    cellGroupSupply.SetCellValue(lstData[k].GroupSupply);

                    //Tel
                    ICell cellTel = rowTemp.GetCell(6);
                    cellTel.SetCellValue(lstData[k].Tel);

                    //Fax
                    ICell cellFax = rowTemp.GetCell(7);
                    cellFax.SetCellValue(lstData[k].FAX);

                    //Email
                    ICell cellEmail = rowTemp.GetCell(8);
                    cellEmail.SetCellValue(lstData[k].EmailAddress);

                    //Contact Person
                    ICell cellContactPerson = rowTemp.GetCell(9);
                    cellContactPerson.SetCellValue(lstData[k].ContactPerson);

                    //Contact Tel
                    ICell cellContactTel = rowTemp.GetCell(10);
                    cellContactTel.SetCellValue(lstData[k].ContactTel);

                    //TAX Code
                    ICell cellTAXCode = rowTemp.GetCell(11);
                    cellTAXCode.SetCellValue(lstData[k].TAXCode);

                    //Vendor Bank
                    ICell cellVendorBank = rowTemp.GetCell(12);
                    cellVendorBank.SetCellValue(lstData[k].VendorBank);

                    //Account No
                    ICell cellAccountCode = rowTemp.GetCell(13);
                    cellAccountCode.SetCellValue(lstData[k].AccountCode);
                }

                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart - 1, -2);
            }
            return wb;
        }

        /// <summary>
        /// Get list for export excel
        /// </summary>
        /// <returns></returns>
        private IList<VendorExcel> GetListExcel()
        {
            IList<VendorExcel> lstResult = null;
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);
                lstResult = vendorSer.GetListForExcel();
            }

            return lstResult;
        }
    }
}

﻿namespace BackupSetting
{
    partial class BackupSetting
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.txtDBVersionNo = new System.Windows.Forms.TextBox();
            this.txtDBBackupPath = new System.Windows.Forms.TextBox();
            this.txtDatabase = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtUserName = new System.Windows.Forms.TextBox();
            this.txtServerName = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.StatusStrip1 = new System.Windows.Forms.StatusStrip();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.txtFileBackupPath = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtFileVersion = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.btnSetting = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.GroupBox3.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.txtDBVersionNo);
            this.GroupBox3.Controls.Add(this.txtDBBackupPath);
            this.GroupBox3.Controls.Add(this.txtDatabase);
            this.GroupBox3.Controls.Add(this.txtPassword);
            this.GroupBox3.Controls.Add(this.txtUserName);
            this.GroupBox3.Controls.Add(this.txtServerName);
            this.GroupBox3.Controls.Add(this.Label6);
            this.GroupBox3.Controls.Add(this.Label7);
            this.GroupBox3.Controls.Add(this.Label4);
            this.GroupBox3.Controls.Add(this.Label3);
            this.GroupBox3.Controls.Add(this.Label2);
            this.GroupBox3.Controls.Add(this.Label1);
            this.GroupBox3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox3.Location = new System.Drawing.Point(10, 10);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(573, 211);
            this.GroupBox3.TabIndex = 0;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "Database Backup";
            // 
            // txtDBVersionNo
            // 
            this.txtDBVersionNo.Location = new System.Drawing.Point(110, 177);
            this.txtDBVersionNo.MaxLength = 2;
            this.txtDBVersionNo.Name = "txtDBVersionNo";
            this.txtDBVersionNo.Size = new System.Drawing.Size(50, 21);
            this.txtDBVersionNo.TabIndex = 5;
            this.txtDBVersionNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtDBBackupPath
            // 
            this.txtDBBackupPath.Location = new System.Drawing.Point(110, 147);
            this.txtDBBackupPath.Name = "txtDBBackupPath";
            this.txtDBBackupPath.Size = new System.Drawing.Size(457, 21);
            this.txtDBBackupPath.TabIndex = 4;
            // 
            // txtDatabase
            // 
            this.txtDatabase.Location = new System.Drawing.Point(110, 115);
            this.txtDatabase.Name = "txtDatabase";
            this.txtDatabase.Size = new System.Drawing.Size(200, 21);
            this.txtDatabase.TabIndex = 3;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(110, 83);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(200, 21);
            this.txtPassword.TabIndex = 2;
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(110, 53);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(200, 21);
            this.txtUserName.TabIndex = 1;
            // 
            // txtServerName
            // 
            this.txtServerName.Location = new System.Drawing.Point(110, 22);
            this.txtServerName.Name = "txtServerName";
            this.txtServerName.Size = new System.Drawing.Size(200, 21);
            this.txtServerName.TabIndex = 0;
            // 
            // Label6
            // 
            this.Label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label6.Location = new System.Drawing.Point(18, 180);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(92, 14);
            this.Label6.TabIndex = 33;
            this.Label6.Text = "Version No";
            // 
            // Label7
            // 
            this.Label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label7.Location = new System.Drawing.Point(17, 150);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(92, 14);
            this.Label7.TabIndex = 33;
            this.Label7.Text = "Backup Path";
            // 
            // Label4
            // 
            this.Label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label4.Location = new System.Drawing.Point(18, 118);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(92, 14);
            this.Label4.TabIndex = 33;
            this.Label4.Text = "Database";
            // 
            // Label3
            // 
            this.Label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label3.Location = new System.Drawing.Point(18, 86);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(92, 14);
            this.Label3.TabIndex = 33;
            this.Label3.Text = "Password";
            // 
            // Label2
            // 
            this.Label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label2.Location = new System.Drawing.Point(18, 56);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(92, 14);
            this.Label2.TabIndex = 33;
            this.Label2.Text = "User Name";
            // 
            // Label1
            // 
            this.Label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label1.Location = new System.Drawing.Point(18, 25);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(92, 14);
            this.Label1.TabIndex = 33;
            this.Label1.Text = "Server Name";
            // 
            // StatusStrip1
            // 
            this.StatusStrip1.Location = new System.Drawing.Point(0, 368);
            this.StatusStrip1.Name = "StatusStrip1";
            this.StatusStrip1.Size = new System.Drawing.Size(594, 22);
            this.StatusStrip1.SizingGrip = false;
            this.StatusStrip1.TabIndex = 3;
            this.StatusStrip1.Text = "StatusStrip1";
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.txtFileBackupPath);
            this.GroupBox1.Controls.Add(this.label5);
            this.GroupBox1.Controls.Add(this.txtFileVersion);
            this.GroupBox1.Controls.Add(this.Label8);
            this.GroupBox1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox1.Location = new System.Drawing.Point(10, 230);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(573, 92);
            this.GroupBox1.TabIndex = 1;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Files Backup";
            // 
            // txtFileBackupPath
            // 
            this.txtFileBackupPath.Location = new System.Drawing.Point(110, 22);
            this.txtFileBackupPath.Name = "txtFileBackupPath";
            this.txtFileBackupPath.Size = new System.Drawing.Size(455, 21);
            this.txtFileBackupPath.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(16, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 14);
            this.label5.TabIndex = 36;
            this.label5.Text = "Backup Path";
            // 
            // txtFileVersion
            // 
            this.txtFileVersion.Location = new System.Drawing.Point(110, 53);
            this.txtFileVersion.MaxLength = 2;
            this.txtFileVersion.Name = "txtFileVersion";
            this.txtFileVersion.Size = new System.Drawing.Size(50, 21);
            this.txtFileVersion.TabIndex = 1;
            this.txtFileVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label8
            // 
            this.Label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.Label8.Location = new System.Drawing.Point(18, 56);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(92, 14);
            this.Label8.TabIndex = 33;
            this.Label8.Text = "Version No";
            // 
            // btnSetting
            // 
            this.btnSetting.Location = new System.Drawing.Point(427, 330);
            this.btnSetting.Name = "btnSetting";
            this.btnSetting.Size = new System.Drawing.Size(75, 27);
            this.btnSetting.TabIndex = 2;
            this.btnSetting.Text = "&Set";
            this.btnSetting.UseVisualStyleBackColor = true;
            this.btnSetting.Click += new System.EventHandler(this.btnSetting_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(508, 330);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 27);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // BackupSetting
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(594, 390);
            this.Controls.Add(this.btnSetting);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.StatusStrip1);
            this.Controls.Add(this.GroupBox3);
            this.Font = new System.Drawing.Font("Tahoma", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "BackupSetting";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Backup Setting";
            this.Load += new System.EventHandler(this.BackupSetting_Load);
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.TextBox txtDBVersionNo;
        internal System.Windows.Forms.TextBox txtDBBackupPath;
        internal System.Windows.Forms.TextBox txtDatabase;
        internal System.Windows.Forms.TextBox txtPassword;
        internal System.Windows.Forms.TextBox txtUserName;
        internal System.Windows.Forms.TextBox txtServerName;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.StatusStrip StatusStrip1;
        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.TextBox txtFileVersion;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.TextBox txtFileBackupPath;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Button btnSetting;
        internal System.Windows.Forms.Button btnClose;
    }
}


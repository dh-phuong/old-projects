﻿using System;
using System.Windows.Forms;
using System.IO;

namespace BackupSetting
{
    /// <summary>
    /// Form BackupSetting
    /// </summary>
    public partial class BackupSetting : Form
    {
        #region Const

        private const string FILE_NAME = "Info.ini";
        private const string SERVER_NAME = "ServerName";
        private const string USER_NAME = "UserName";
        private const string PASSWORD = "Password";
        private const string DATABASE = "DataBase";
        private const string DB_BACKUP_PATH = "DBBackupPath";
        private const string DB_VERSION = "DBVersion";
        
        private const string FILE_BACKUP_PATH = "FileBackupPath";
        private const string FILE_VERSION = "FileVersion";

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public BackupSetting()
        {
            InitializeComponent();
        }

        #endregion

        #region Event

        /// <summary>
        /// Form Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackupSetting_Load(object sender, EventArgs e)
        {
            //Clear
            this.Clear();

            //Read File
            this.ReadFile();

            //Set focus
            this.txtServerName.Focus();
        }

        /// <summary>
        /// Click Setting Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSetting_Click(object sender, EventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(Path.Combine(Application.StartupPath, FILE_NAME)))
                {
                    //DB
                    sw.WriteLine(string.Format("{0}={1}", SERVER_NAME, this.txtServerName.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", USER_NAME, this.txtUserName.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", PASSWORD, this.txtPassword.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", DATABASE, this.txtDatabase.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", DB_BACKUP_PATH, this.txtDBBackupPath.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", DB_VERSION, this.txtDBVersionNo.Text.Trim()));

                    //File
                    sw.WriteLine(string.Format("{0}={1}", FILE_BACKUP_PATH, this.txtFileBackupPath.Text.Trim()));
                    sw.WriteLine(string.Format("{0}={1}", FILE_VERSION, this.txtFileVersion.Text.Trim()));

                }

                MessageBox.Show("Successful!", this.Text);
            }
            catch (Exception)
            {
                MessageBox.Show("Failure!", this.Text);
            }            
        }

        /// <summary>
        /// Click Close Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        #endregion

        #region Method

        /// <summary>
        /// Clear
        /// </summary>
        private void Clear()
        {
            this.txtServerName.Text = string.Empty;
            this.txtUserName.Text = string.Empty;
            this.txtPassword.Text = string.Empty;
            this.txtDatabase.Text = string.Empty;
            this.txtDBBackupPath.Text = string.Empty;
            this.txtDBVersionNo.Text = string.Empty;

            this.txtFileBackupPath.Text = string.Empty;
            this.txtFileVersion.Text = string.Empty;
        }

        /// <summary>
        /// Read File
        /// </summary>
        private void ReadFile()
        {
            //Check exists file
            if (File.Exists(Path.Combine(Application.StartupPath, FILE_NAME)))
            {
                //Read file
                using (StreamReader sr = new StreamReader(Path.Combine(Application.StartupPath, FILE_NAME)))
                {
                    while (sr.Peek() >= 0)
                    {
                        string[] val = sr.ReadLine().Split('=');
                        switch (val[0])
                        {
                            case SERVER_NAME:
                                this.txtServerName.Text = val[1];

                                break;

                            case USER_NAME:
                                this.txtUserName.Text = val[1];

                                break;

                            case PASSWORD:
                                this.txtPassword.Text = val[1];

                                break;

                            case DATABASE:
                                this.txtDatabase.Text = val[1];

                                break;

                            case DB_BACKUP_PATH:
                                this.txtDBBackupPath.Text = val[1];

                                break;

                            case DB_VERSION:
                                this.txtDBVersionNo.Text = val[1];

                                break;

                            case FILE_BACKUP_PATH:
                                this.txtFileBackupPath.Text = val[1];

                                break;

                            case FILE_VERSION:
                                this.txtFileVersion.Text = val[1];

                                break;


                            default: break;
                        }
                    }
                }
            }
        }

        #endregion
    }
}

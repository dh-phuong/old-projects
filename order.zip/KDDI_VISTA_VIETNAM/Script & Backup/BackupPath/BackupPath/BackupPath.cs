﻿using System;
using System.ComponentModel;
using System.Data.SqlClient;
using System.IO;
using System.Windows.Forms;

namespace BackupPath
{
    /// <summary>
    /// Form BackupPath
    /// </summary>
    public partial class BackupPath : Form
    {
        #region Const

        private const string FILE_NAME = "Info.ini";
        private const string SERVER_NAME = "ServerName";
        private const string USER_NAME = "UserName";
        private const string PASSWORD = "Password";
        private const string DATABASE = "DataBase";
        private const string DB_BACKUP_PATH = "DBBackupPath";
        private const string DB_VERSION = "DBVersion";

        private const string FILE_BACKUP_PATH = "FileBackupPath";
        private const string FILE_VERSION = "FileVersion";

        private const string FORMAT_PATH = "yyyyMMdd_HHmmss";
        private const string FILE_LOG_NAME = "BackupPath.log";

        #endregion

        #region Variable

        private string _serverName;
        private string _userName;
        private string _password;
        private string _database;
        private string _fileSourcePath;
        private string _fileBackupPath;
        private string _fileVersion;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public BackupPath()
        {
            InitializeComponent();
        }

        #endregion

        #region Event

        /// <summary>
        /// Form Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackupPath_Load(object sender, EventArgs e)
        {
            this.bgWorker.RunWorkerAsync();
        }

        /// <summary>
        /// Process
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bgWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Read File
            if (this.ReadFile())
            {
                //Create Backup path
                if (!Directory.Exists(this._fileBackupPath))
                {
                    Directory.CreateDirectory(this._fileBackupPath);
                }

                //Get File Source Path
                this.GetFileSourcePath();

                //Check
                if (!string.IsNullOrEmpty(this._fileSourcePath))
                {
                    //Copy file
                    this.CopyFile();

                    //Delete old path
                    this.DeleteOldPath();
                }
            }
        }

        /// <summary>
        /// Completed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bgWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                using (StreamWriter sw = new StreamWriter(Path.Combine(Application.StartupPath, BackupPath.FILE_LOG_NAME), true))
                {
                    //Message
                    sw.WriteLine(string.Format("------------------{0}-----{1}-------------------", "Message", DateTime.Now.ToString("yyyyMMdd hh:mm:ss")));
                    sw.WriteLine(string.Format("{0}", e.Error.Message));
                    sw.WriteLine("-----------------------------------------------------------------------");

                    //StackTrace
                    sw.WriteLine(string.Format("------------------{0}-----{1}-------------------", "StackTrace", DateTime.Now.ToString("yyyyMMdd hh:mm:ss")));
                    sw.WriteLine(string.Format("{0}", e.Error.StackTrace));
                    sw.WriteLine("--------------------------------------------------------------------------");
                }
            }

            Application.Exit();
        }

        #endregion

        #region Method

        /// <summary>
        /// Read File
        /// </summary>
        /// <returns></returns>
        private bool ReadFile()
        {
            if (File.Exists(Path.Combine(Application.StartupPath, BackupPath.FILE_NAME)))
            {
                using (StreamReader sr = new StreamReader(Path.Combine(Application.StartupPath, BackupPath.FILE_NAME)))
                {
                    while (sr.Peek() >= 0)
                    {
                        string[] val = sr.ReadLine().Split('=');
                        switch (val[0])
                        {
                            case BackupPath.SERVER_NAME:
                                this._serverName = val[1];

                                break;

                            case BackupPath.USER_NAME:
                                this._userName = val[1];

                                break;

                            case BackupPath.PASSWORD:
                                this._password = val[1];

                                break;

                            case BackupPath.DATABASE:
                                this._database = val[1];

                                break;

                            case BackupPath.FILE_BACKUP_PATH:
                                this._fileBackupPath = val[1];

                                break;

                            case BackupPath.FILE_VERSION:
                                this._fileVersion = val[1];

                                break;

                            default: break;
                        }
                    }
                }

                return true;
            }

            return false;
        }

        /// <summary>
        /// Get FileSourcePath
        /// </summary>
        private void GetFileSourcePath()
        {
            string connstr;
            if (!string.IsNullOrEmpty(this._userName))
            {
                connstr = "data source=" + this._serverName + ";initial catalog=" + this._database + ";user id=" + this._userName + ";password=" + this._password;
            }
            else
            {
                connstr = "data source=" + this._serverName + ";initial catalog=" + this._database + ";Integrated Security=true";
            }
            using (SqlConnection conn = new SqlConnection(connstr))
            {
                conn.Open();
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT AttachPath FROM dbo.M_Setting";

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            this._fileSourcePath = (string)dr["AttachPath"];
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Copy file
        /// </summary>
        private void CopyFile()
        {
            //Create New Path
            string newPath = Path.Combine(this._fileBackupPath, DateTime.Now.ToString(BackupPath.FORMAT_PATH));
            if (!Directory.Exists(newPath))
            {
                Directory.CreateDirectory(newPath);
            }

            //Copy File
            DirectoryInfo di = new DirectoryInfo(this._fileSourcePath);
            foreach (FileInfo fn in di.GetFiles())
            {
                File.Copy(fn.FullName, Path.Combine(newPath, fn.Name));
            }
        }

        /// <summary>
        /// Delete old path
        /// </summary>
        private void DeleteOldPath()
        {
            string[] pathNames = System.IO.Directory.GetDirectories(this._fileBackupPath);
            Array.Sort<string>(pathNames);
            if (pathNames.Length > int.Parse(this._fileVersion))
            {
                int temp = pathNames.Length - int.Parse(this._fileVersion);
                for (int i = 0; i < temp; i++)
                {
                    Directory.Delete(pathNames[i], true);
                }
            }
        }

        #endregion
    }
}

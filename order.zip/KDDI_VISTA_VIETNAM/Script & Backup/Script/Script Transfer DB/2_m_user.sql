--BEGIN TRAN
SET IDENTITY_INSERT [dbo].[M_User] ON 
INSERT INTO [dbo].[M_User]
(
		   ID
		 , UserCD
		 , LoginID
		 , UserName1
		 , UserName2
		 , [Password]
		 , GroupID
		 , StatusFlag
		 , CreateUID
		 , UpdateUID
)	
VALUES
(
		  11
		, '0000000001'
		, 'Admin'
		, 'Administrator'
		, 'Admin'
		, 'a5epqIqnHtNvvmD5dXOAXg=='
		, 11
		, 0
		, 1
		, 1
)		
--SET IDENTITY_INSERT [dbo].[M_User] OFF	
--ROLLBACK
	 
INSERT INTO [dbo].[M_User](
		   ID
		 , UserCD
		 , LoginID
		 , UserName1
		 , UserName2
		 , [Password]
		 , GroupID
		 , StatusFlag
		 , CreateDate 
		 , CreateUID
		 , UpdateDate
		 , UpdateUID)
SELECT 
		   ID + 10
		 , UserCD
		 , LoginID
		 , UserName1
		 , UserName2
		 , 'a5epqIqnHtNvvmD5dXOAXg=='
		 , GroupID  + 10	 
		 , StatusFlag
		 , CreateDate 		 
		 , CreateUID  + 10
		 , UpdateDate
		 , UpdateUID  + 10
FROM [KDDI_DEV].dbo.M_User
WHERE ID > 1

SET IDENTITY_INSERT [dbo].[M_User] OFF		
--ROLLBACK
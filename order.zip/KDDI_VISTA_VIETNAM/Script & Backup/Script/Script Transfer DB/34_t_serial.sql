INSERT INTO [dbo].[T_Serial]
           ([DeliveryDID]
           ,[No]
           ,[SerialNo]
           ,[Terms]
           ,[TermUnit]
           ,[FinishDate])          
SELECT	
	    [ID] + 10
       ,[GridID]
       ,SUBSTRING([SerialNo], 0, 50)
       ,[Terms]
       ,[TermUnit]
       ,[FinishDate]
FROM [KDDI_DEV].[dbo].[T_Serial]

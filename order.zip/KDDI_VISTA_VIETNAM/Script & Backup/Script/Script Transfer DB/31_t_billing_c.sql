--TRUNCATE TABLE T_Billing_C
--*****************************--
--Create by: ISV-HUNG
--Create date: 2015/01/14
--*****************************--
INSERT INTO [dbo].[T_Billing_C]
           (
           [HID]
           ,[Conditions]
           )
SELECT 
	 (H.ID + 10)
	,ISNULL(C.[Conditions], '')
FROM [KDDI_DEV].dbo.T_Invoice_H H
LEFT JOIN  [KDDI_DEV].[dbo].T_Invoice_C C ON C.ID = H.ID

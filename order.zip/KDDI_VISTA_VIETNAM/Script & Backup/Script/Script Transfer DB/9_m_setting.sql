DECLARE @OUT_QuoteNo VARCHAR(10)
DECLARE @OUT_AcceptNo VARCHAR(10)
DECLARE @OUT_PurchaseNo VARCHAR(10)
DECLARE @OUT_InvoiceNo VARCHAR(10)
DECLARE @OUT_ShippingNo VARCHAR(10)

--DECLARE @OUT_SaleContactFFile NVARCHAR(255)
--DECLARE @OUT_AcceptReportFFile NVARCHAR(255)

SELECT 
	  @OUT_QuoteNo = QuoteNo
	, @OUT_AcceptNo = AcceptNo
	, @OUT_PurchaseNo = PurchaseNo
	, @OUT_InvoiceNo = InvoiceNo
	, @OUT_ShippingNo = ShippingNo
	--, @OUT_SaleContactFFile = SaleContactFFile
	--, @OUT_AcceptReportFFile = AcceptReportFFile
		
FROM [KDDI_DEV].dbo.M_Config

UPDATE [dbo].[M_Setting]
   SET [QuoteNo] = @OUT_QuoteNo
      ,[SalesNo] = @OUT_AcceptNo
      ,[PurchaseNo] = @OUT_PurchaseNo
      ,[BillingNo] = @OUT_InvoiceNo
      ,[DeliveryNo] = @OUT_ShippingNo         
      --,[SalesContractFile1] = @OUT_SaleContactFFile     
      --,[AcceptanceReportFile1] = @OUT_AcceptReportFFile         
GO

/*

SELECT 
	*		
FROM [KDDI_DEV].dbo.M_Config

SELECT * FROM [dbo].[M_Setting]
*/



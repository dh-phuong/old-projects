﻿
/*
/*M_Currency*/

TRUNCATE TABLE [dbo].[M_Currency_D]
TRUNCATE TABLE [dbo].[M_Currency_H]

SET IDENTITY_INSERT [dbo].[M_Currency_H] ON 
INSERT [dbo].[M_Currency_H] ([ID], [MoneyCode], [MoneyNameUS], [MoneyNameVN], [TaxName], [DecimalType], [DecimalNameUS], [DecimalNameVN], [OrderIndex], [CreateDate], [CreateUID], [UpdateDate], [UpdateUID]) VALUES (1, N'VND', N'VND', N'đồng', N'VAT', 0, N'', N'', 1, GETDATE(), 1, GETDATE(), 1)
SET IDENTITY_INSERT [dbo].[M_Currency_H] OFF
INSERT [dbo].[M_Currency_D] ([HID], [EffectDate], [ExpireDate], [ExchangeRate]) VALUES (1, '1900-01-01', '9999-12-31', 1)

*/
-----------------------------------------------------------------------------------
-- INSERT HEADER
--
SET IDENTITY_INSERT [dbo].[M_Currency_H] ON
INSERT INTO [dbo].[M_Currency_H]
           (
			[ID]
           ,[MoneyCode]
           ,[MoneyNameUS]
           ,[MoneyNameVN]
           ,[TaxName]
           ,[DecimalType]
           ,[DecimalNameUS]
           ,[DecimalNameVN]
           ,[CreateDate]
           ,[CreateUID]
           ,[UpdateDate]
           ,[UpdateUID])
     
SELECT 
		    ([ID] + 10)
		   ,[MoneyCode]
           ,[MoneyNameUS]
           ,[MoneyNameVN]
           ,[TaxName]
           ,[DecimalType]
           ,[DecimalNameUS]
           ,[DecimalNameVN]
           , CreateDate	
		   , CreateUID  + 10
		   , UpdateDate
		   , UpdateUID  + 10
FROM [KDDI_DEV].dbo.M_ExchangeRate_H
WHERE [MoneyCode] COLLATE Japanese_CS_AS NOT IN (SELECT [MoneyCode] FROM [dbo].[M_Currency_H] WHERE ID = 1)
SET IDENTITY_INSERT [dbo].[M_Currency_H] OFF

-----------------------------------------------------------------------------------
-- INSERT DETAIL
--

INSERT INTO [dbo].[M_Currency_D]
           ([HID]
           ,[EffectDate]
           ,[ExpireDate]
           ,[ExchangeRate])
SELECT 
			[ID]
           ,[EffectDate]
           ,[ExpireDate]
           ,[ExchangeRate]          
FROM [KDDI_DEV].dbo.M_ExchangeRate_M  
WHERE ID <> (SELECT ID FROM [KDDI_DEV].dbo.M_ExchangeRate_H WHERE MoneyCode = 'USD')

--WHERE    ID NOT IN      (
--			SELECT ID 
--			FROM [KDDI_DEV].dbo.M_ExchangeRate_H
--			WHERE MoneyCode IN(
--			SELECT [MoneyCode] FROM [dbo].[M_Currency_H] WHERE ID = 1)
			
--	)
    
    
    -- CHANGE DETAIL OF VND TO USD
    DECLARE @IN_VND_OLD_ID INT 
    DECLARE @IN_USD_NEW_ID INT
    SET  @IN_VND_OLD_ID = (SELECT ID FROM [KDDI_DEV].dbo.M_ExchangeRate_H WHERE MoneyCode = 'VND')    
    SET  @IN_USD_NEW_ID = (SELECT ID FROM dbo.M_Currency_H WHERE MoneyCode = 'USD')
    
    PRINT(@IN_VND_OLD_ID)
    PRINT(@IN_USD_NEW_ID)
    -- UPDATE VND TO USD
    
    UPDATE dbo.M_Currency_D
		SET HID = @IN_USD_NEW_ID
    WHERE HID = @IN_VND_OLD_ID
    -- UPDATE OTHER CURRENCY
    
    
    UPDATE dbo.M_Currency_D
		SET HID = (HID + 10)
    WHERE HID <> @IN_VND_OLD_ID AND HID <> 1 AND HID <> @IN_USD_NEW_ID
	GO

    
     /*
		SELECT * FROM [KDDI_DEV].dbo.M_ExchangeRate_H
		SELECT * FROM [KDDI_DEV].dbo.M_ExchangeRate_M  

		SELECT  * FROM dbo.M_Currency_H
		SELECT * FROM dbo.M_Currency_D
     */

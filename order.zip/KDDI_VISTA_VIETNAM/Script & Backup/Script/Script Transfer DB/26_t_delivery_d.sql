-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
DECLARE @IN_CurrencyID_OLD TINYINT = 1 -- USD
DECLARE @IN_CurrencyID_NEW INT = 11

SET IDENTITY_INSERT [dbo].[T_Delivery_D] ON 
INSERT INTO [dbo].[T_Delivery_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesSellID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT	
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo]
           ,CASE WHEN [AcceptSellID] > 0 THEN
				[AcceptSellID] + 10
			ELSE
				[AcceptSellID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,(LeadTime + CHAR(13) + CHAR(10) + [Remark])           
           ,CASE WHEN
            [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceUSD]
           ,[Quantity]
           ,[VATUSD]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalUSD]
FROM [KDDI_DEV].[dbo].[T_Shipping_M]
WHERE ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Shipping_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)
                      
SET IDENTITY_INSERT [dbo].[T_Delivery_D] OFF

-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
SET @IN_CurrencyID_OLD = 2 -- VND
SET @IN_CurrencyID_NEW = 1

SET IDENTITY_INSERT [dbo].[T_Delivery_D] ON 
INSERT INTO [dbo].[T_Delivery_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesSellID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT	
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo]
           ,CASE WHEN [AcceptSellID] > 0 THEN
				[AcceptSellID] + 10
			ELSE
				[AcceptSellID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,(LeadTime + CHAR(13) + CHAR(10) + [Remark])           
           ,CASE WHEN
            [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].[dbo].[T_Shipping_M]
WHERE ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Shipping_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)
                      
SET IDENTITY_INSERT [dbo].[T_Delivery_D] OFF

/*
-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
SET @IN_CurrencyID_OLD = 3 -- JPY
SET @IN_CurrencyID_NEW = 13

SET IDENTITY_INSERT [dbo].[T_Delivery_D] ON 
INSERT INTO [dbo].[T_Delivery_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesSellID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT	
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo]
           ,CASE WHEN [AcceptSellID] > 0 THEN
				[AcceptSellID] + 10
			ELSE
				[AcceptSellID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,(LeadTime + CHAR(13) + CHAR(10) + [Remark])           
           ,CASE WHEN
            [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].[dbo].[T_Shipping_M]
WHERE ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Shipping_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)
                      
SET IDENTITY_INSERT [dbo].[T_Delivery_D] OFF

*/
/*

SELECT * FROM [KDDI_DEV].[dbo].[T_Shipping_M]

SELECT * FROM [dbo].[T_Delivery_D] 

*/
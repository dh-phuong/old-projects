
--        KDDI   ||    OMS
----------------------
-- LST    =    0 => 5
-- Accept =    1 => 0
-- A      =    2 => 1
-- B      =    3 => 2
-- C      =    4 => 3
-- D      =    5 => 4
-- RQ     =    6 => 6
UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 99
WHERE [StatusFlag] = 0

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 0
WHERE [StatusFlag] = 1

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 1
WHERE [StatusFlag] = 2

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 2
WHERE [StatusFlag] = 3

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 3
WHERE [StatusFlag] = 4

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 4
WHERE [StatusFlag] = 5

UPDATE [dbo].[T_Quote_H]
SET [StatusFlag] = 5
WHERE [StatusFlag] = 99

-- UPDATE TOTAL, VAT, GRANDTOTAL 
	
	DECLARE @ID INT
	DECLARE @SUM_Total DECIMAL
	DECLARE @SUM_Vat DECIMAL
	DECLARE @GRAND_Total DECIMAL
	
	DECLARE cTotal CURSOR FOR	
	SELECT 
		QD.HID
		, SUM(QD.Total) SUM_Total
		, SUM(QD.Vat) SUM_Vat
		, (SUM(QD.Total) +  SUM(QD.Vat)) AS GRAND_Total
	FROM dbo.T_Quote_D_Sell QD
	GROUP BY QD.HID
	
	OPEN cTotal
	FETCH NEXT FROM cTotal INTO 
	@ID, @SUM_Total, @SUM_Vat, @GRAND_Total
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE dbo.T_Quote_H
			SET   Total = @SUM_Total
				, Vat   = @SUM_Vat
				, GrandTotal   = @GRAND_Total
		WHERE ID = @ID
							
		FETCH NEXT FROM cTotal INTO 
		@ID, @SUM_Total, @SUM_Vat, @GRAND_Total
	END
	CLOSE cTotal;
	DEALLOCATE cTotal;

--


-- BLANK SELL
INSERT INTO [dbo].[T_Quote_D_Sell]
           ([HID]
           ,[No]
           ,[HeadLineFlag]           
           ,[ProductID]           
           ,[UnitID]           
           ,[VatRatio]
           )           
SELECT 
		  TH.ID
		, 1
		, 0
		, 1
		, 1
		, (SELECT CONVERT(DECIMAL(4,2), Value3) FROM 
dbo.M_Config_H CH 
INNER JOIN dbo.M_Config_D CD ON CH.ConfigCD = 'L005' AND CH.ID = CD.HID)
		
FROM dbo.T_Quote_H TH
WHERE ID NOT IN (SELECT HID FROM dbo.T_Quote_D_Sell)

-- BLANK COST
INSERT INTO [dbo].[T_Quote_D_Cost]
           ([HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[VendorID]
           ,[CurrencyID]
           ,[UnitID]
           ,[VatRatio]
           )           
SELECT 
		  TDS.HID
		, 1
		, 1
		, 1
		, 1
		, 1
		, 1
		, (SELECT CONVERT(DECIMAL(4,2), Value3) FROM 
dbo.M_Config_H CH 
INNER JOIN dbo.M_Config_D CD ON CH.ConfigCD = 'L005' AND CH.ID = CD.HID)
		
FROM dbo.T_Quote_D_Sell TDS
WHERE HID NOT IN (SELECT HID FROM dbo.T_Quote_D_Cost)
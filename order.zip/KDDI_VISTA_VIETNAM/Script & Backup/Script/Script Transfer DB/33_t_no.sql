INSERT INTO [dbo].[T_No]
           ([ItemName]
           ,[YearMonth]
           ,[NextNumber])
SELECT
			[ItemName]
           ,[YearMonth]
           ,[NextNumber]
FROM [KDDI_DEV].dbo.T_No

--//
-- UPDATE 
--//

UPDATE dbo.T_No
SET [ItemName] = 'SalesNo'
WHERE [ItemName] = 'AcceptanceHeaderNo'

UPDATE dbo.T_No
SET [ItemName] = 'QuoteNo'
WHERE [ItemName] = 'QuotationHeaderNo'

UPDATE dbo.T_No
SET [ItemName] = 'BillingNo'
WHERE [ItemName] = 'InvoiceNo'

UPDATE dbo.T_No
SET [ItemName] = 'DeliveryNo'
WHERE [ItemName] = 'ShippingNo'

UPDATE dbo.T_No
SET [ItemName] = 'PurchaseNo'
WHERE [ItemName] = 'PurchaseNo'

SET IDENTITY_INSERT [dbo].[M_Condition] ON 
INSERT INTO [dbo].[M_Condition]
           (
            [ID]
		   ,[Type]
           ,[ConditionCD]
           ,[ConditionName]
           ,[Condition]
           ,[CreateDate]
           ,[CreateUID]
           ,[UpdateDate]
           ,[UpdateUID])
   
SELECT 
		    ([ID] + 10)
		   ,([Type] - 1)
           ,[ConditionCD]
           ,[ConditionName]
           ,[Condition]
           , CreateDate	
		   , CreateUID  + 10
		   , UpdateDate
		   , UpdateUID  + 10
FROM [KDDI_DEV].dbo.[M_Condition]
SET IDENTITY_INSERT [dbo].[M_Condition] OFF

/*SELECT 
CH.ConfigName,
CD.*
FROM 
dbo.M_Config_H CH 
INNER JOIN dbo.M_Config_D CD ON CH.ID = CD.HID AND CH.ConfigCD ='L019'*/

/*

SELECT 
		    *
FROM [KDDI_DEV].dbo.[M_Condition]

*/
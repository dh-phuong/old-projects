
SET IDENTITY_INSERT [dbo].[T_Attached] ON 
INSERT INTO [dbo].[T_Attached]
           (
            [ID]
           ,[No]
           ,[Path]
           ,[CreateDate]
           ,[CreateUID])
     
SELECT 
		   ([ID] + 10)
		   ,UPPER([No])
           ,[Path]
           , CreateDate	
		   , CreateUID  + 10
FROM [KDDI_DEV].dbo.[T_Attached]

SET IDENTITY_INSERT [dbo].[T_Attached] OFF


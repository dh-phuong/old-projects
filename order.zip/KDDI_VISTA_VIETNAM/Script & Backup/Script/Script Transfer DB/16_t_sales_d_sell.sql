--*****************************--
--Create by: ISV-HUNG
--Create date: 2015/01/14
--*****************************--
-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
DECLARE @IN_CurrencyID_OLD TINYINT = 1 -- USD
DECLARE @IN_CurrencyID_NEW INT = 11

SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] ON 
INSERT INTO [dbo].[T_Sales_D_Sell]
           (
           [InternalID]
           ,[HID]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[LeadTime] --???[Remark]
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceUSD] --???[UnitPrice]
           ,[Quantity]
           ,[VATUSD] --???[Vat]
           ,[VATRatio] --???[VatRatio]
           ,[VATFlag] --???[VatType]
           ,[SubTotalUSD] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Sell TMS
	WHERE 
			TMS.[CurrencyFlag] = @IN_CurrencyID_OLD 

SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] OFF


-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
SET @IN_CurrencyID_OLD = 2 -- VND
SET @IN_CurrencyID_NEW = 1

SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] ON 
INSERT INTO [dbo].[T_Sales_D_Sell]
           (
           [InternalID]
           ,[HID]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[LeadTime] --???[Remark]
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceVND] --???[UnitPrice]
           ,[Quantity]
           ,[VATVND] --???[Vat]
           ,[VATRatio] --???[VatRatio]
           ,[VATFlag] --???[VatType]
           ,[SubTotalVND] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Sell TMS
	WHERE 
			TMS.[CurrencyFlag] = @IN_CurrencyID_OLD 
			
SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] OFF

/*
-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
SET @IN_CurrencyID_OLD = 3 -- JPY
SET @IN_CurrencyID_NEW = 13

SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] ON 
INSERT INTO [dbo].[T_Sales_D_Sell]
           (
           [InternalID]
           ,[HID]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[LeadTime] --???[Remark]
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceVND] --???[UnitPrice]
           ,[Quantity]
           ,[VATVND] --???[Vat]
           ,[VATRatio] --???[VatRatio]
           ,[VATFlag] --???[VatType]
           ,[SubTotalVND] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Sell TMS
	WHERE 
			TMS.[CurrencyFlag] = @IN_CurrencyID_OLD 

SET IDENTITY_INSERT [dbo].[T_Sales_D_Sell] OFF
*/
DECLARE @OUT_CompanyName1 NVARCHAR(100)
DECLARE @OUT_CompanyName2 NVARCHAR(100)

DECLARE @OUT_CompanyAddress1 NVARCHAR(150)
DECLARE @OUT_CompanyAddress2 NVARCHAR(150)
DECLARE @OUT_CompanyAddress3 NVARCHAR(150)
DECLARE @OUT_CompanyAddress4 NVARCHAR(150)
DECLARE @OUT_CompanyAddress5 NVARCHAR(150)
DECLARE @OUT_CompanyAddress6 NVARCHAR(150)

DECLARE @OUT_Tel CHAR(20)
DECLARE @OUT_FAX CHAR(20)
DECLARE @OUT_EmailAddress VARCHAR(50)
DECLARE @OUT_TAXCode NVARCHAR(150)
DECLARE @OUT_CompanyBank NVARCHAR(100)
DECLARE @OUT_AccountCode CHAR(20)
DECLARE @OUT_Represent NVARCHAR(50)
DECLARE @OUT_Position NVARCHAR(50)
DECLARE @OUT_Position2 NVARCHAR(50)

SELECT 
	  @OUT_CompanyName1 = CompanyName1
	, @OUT_CompanyName2 = CompanyName2
	, @OUT_CompanyAddress1 = CompanyAddress1
	, @OUT_CompanyAddress2 = CompanyAddress2
	, @OUT_CompanyAddress3 = CompanyAddress3
	, @OUT_CompanyAddress4 = CompanyAddress4
	, @OUT_CompanyAddress5 = CompanyAddress5
	, @OUT_CompanyAddress6 = CompanyAddress6
	, @OUT_Tel = Tel
	, @OUT_FAX = FAX
	, @OUT_EmailAddress = EmailAddress
	, @OUT_TAXCode = TAXCode
	, @OUT_CompanyBank = CompanyBank
	, @OUT_AccountCode = AccountCode
	, @OUT_Represent = Represent
	, @OUT_Position = Position
	, @OUT_Position2 = Position2
	
FROM [KDDI_DEV].dbo.M_Company

UPDATE [dbo].[M_Company]
   SET [CompanyName1] = @OUT_CompanyName1
      ,[CompanyName2] = @OUT_CompanyName2
      ,[CompanyAddress1] = @OUT_CompanyAddress1
      ,[CompanyAddress2] = @OUT_CompanyAddress2
      ,[CompanyAddress3] = @OUT_CompanyAddress3
      ,[CompanyAddress4] = @OUT_CompanyAddress4
      ,[CompanyAddress5] = @OUT_CompanyAddress5
      ,[CompanyAddress6] = @OUT_CompanyAddress6
      ,[Tel] = @OUT_Tel
      ,[Tel2] = ''
      ,[FAX] = @OUT_FAX
      ,[EmailAddress] = @OUT_EmailAddress
      ,[TAXCode] = @OUT_TAXCode
      ,[CompanyBank] = @OUT_CompanyBank
      ,[AccountCode] = @OUT_AccountCode
      ,[Represent] = @OUT_Represent
      ,[Position] = @OUT_Position
      ,[Position2] = @OUT_Position2     
GO


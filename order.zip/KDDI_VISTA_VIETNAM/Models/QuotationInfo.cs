﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Class QuotationHeaderInfo
    /// </summary>
    [Serializable]
    public class QuotationHeaderInfo
    {
        /// <summary>
        /// Get or set QuotationNo
        /// </summary>
        public string QuotationNo { get; set; }

        /// <summary>
        /// Get or set QuotationDate
        /// </summary>
        public DateTime QuotationDate { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Get or set ContactPerson
        /// </summary>
        public string ContactPerson { get; set; }

        /// <summary>
        /// Get or set CustomerAddress1
        /// </summary>
        public string CustomerAddress1 { get; set; }

        /// <summary>
        /// Get or set CustomerAddress2
        /// </summary>
        public string CustomerAddress2 { get; set; }

        /// <summary>
        /// Get or set CustomerAddress3
        /// </summary>
        public string CustomerAddress3 { get; set; }

        /// <summary>
        /// Get or set CustomerTel
        /// </summary>
        public string CustomerTel { get; set; }

        /// <summary>
        /// Get or set CustomerFax
        /// </summary>
        public string CustomerFax { get; set; }

        /// <summary>
        /// Get or set Subject
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// Get or set ExchangeRateID
        /// </summary>
        public string ExchangeRateID { get; set; }

        /// <summary>
        /// Get or set Status
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// Get or set MethodVat
        /// </summary>
        public string MethodVat { get; set; }

        /// <summary>
        /// Get or set TaxFlag
        /// </summary>
        public int TaxFlag { get; set; }
    }

    /// <summary>
    /// Class QuotationHeaderSearch
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class QuotationHeaderSearch
    {
        public string QuoteNo { get; set; }
        public short Status { get; set; }
        public string StatusName { get; set; }
        public short Invalid { get; set; }
        public string InvalidName { get; set; }//2015/01/15 ISV-Giam
        public short Sales { get; set; }
        public string SalesName { get; set; }//2015/01/15 ISV-Giam
        public DateTime? QuoteDateFrom { get; set; }
        public DateTime? QuoteDateTo { get; set; }

        public string CustomerCD { get; set; }
       // public string CustomerName { get; set; }
        public string Subject { get; set; }

        //public decimal? TotalFrom { get; set; }
        //public decimal? TotalTo { get; set; }

        //public decimal? VatRatioFrom { get; set; }
        //public decimal? VatRatioTo { get; set; }
        //public decimal? GrandTotalFrom { get; set; }
        //public decimal? GrandTotalTo { get; set; }

        //public int Currency { get; set; }
        public string PreparedCD { get; set; }
       // public string PreparedName { get; set; }

        public string Sale1CD { get; set; }
        // public string Sale1Name { get; set; }
        public string Sale2CD { get; set; }
        //public string Sale2Name { get; set; }

        //public string FrontSalesCD { get; set; }
        //public string EngineerCD { get; set; }
        //public string InchargeCD { get; set; }

    }

    /// <summary>
    /// Class QuotationHeaderResult
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class QuotationHeaderResult
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string QuoteNo { get; set; }

        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string SubjectName { get; set; }
        public string Currency { get; set; }

        public short StatusFlag { get; set; }
        public string StatusFlagName { get; set; }
        public DateTime QuoteDate { get; set; }
        public short IssuedFlag { get; set; }
        public DateTime ExpiryDate { get; set; }
        //public DateTime IssuedDate { get; set; }
        public string QuoteDateStr { get; set; }
        public string ExpiryDateStr { get; set; }
        //public string IssuedDateStr { get; set; }
        public short DecimalType { get; set; }
        //public decimal Total { get; set; }
        //public decimal Vat { get; set; }
        //public decimal VatRatio { get; set; }
        public decimal GrandTotal { get; set; }
        //public string TotalStr { get; set; }
        //public string VatStr { get; set; }
        //public string VatRatioStr { get; set; }
        public string GrandTotalStr { get; set; }

        public string PreparedCD { get; set; }
        public string PreparedName { get; set; }
        public string CssClass { get; set; }
        public int Color { get; set; }

        /// <summary>
        /// Contructor class QuotationHeaderResult
        /// </summary>
        public QuotationHeaderResult()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.QuoteNo = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.PreparedCD = string.Empty;
            this.PreparedName = string.Empty;
            this.SubjectName = string.Empty;
            //this.Total = 0;
            this.Currency = string.Empty;
            //this.Vat = 0;
            //this.VatRatio = 0;
            this.GrandTotal = 0;
            this.StatusFlag = 0;
            this.StatusFlagName = string.Empty;
            this.QuoteDate = DateTime.MinValue;
            this.IssuedFlag = 0;
            this.ExpiryDate = DateTime.MinValue;
            //this.IssuedDate = DateTime.MinValue;
            this.DecimalType = 0;
            //this.VatRatioStr = string.Empty;
            //this.TotalStr = string.Empty;
            //this.VatStr = string.Empty;
            this.QuoteDateStr = string.Empty;
            this.ExpiryDateStr = string.Empty;
            this.GrandTotalStr = string.Empty;
            //this.IssuedDateStr = string.Empty;
            this.CssClass = string.Empty;
            this.Color = -1;
        }

        /// <summary>
        /// Constructor class QuotationHeaderResult
        /// </summary>
        /// <param name="dr"></param>
        public QuotationHeaderResult(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.PreparedCD = EditDataUtil.ToFixCodeShow((string)dr["PreparedCD"], M_User.MAX_USER_CODE_SHOW);
            this.PreparedName = (string)dr["PreparedName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            //this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            //this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            //this.VatRatio = dr["VatRatio"] != DBNull.Value ? (decimal)dr["VatRatio"] : 0;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                }
                else
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                }
            }

            //this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
            //this.VatRatioStr = this.VatRatio.ToString(Constants.FMT_DECIMAL);

            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
                if ((int)this.StatusFlag == (int)Models.StatusFlag.Lost)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }

            this.CssClass = (string)dr["CssClass"];
            if (string.IsNullOrEmpty(this.CssClass))
            {
                this.StatusFlagName = string.Empty;
            }
            else 
            {
                this.StatusFlagName = "<span class='label label-" + this.CssClass + "' style='width:55px; display: inline-block'>" + string.Format("{0}", dr["StatusFlagName"]) + "</span>";
            }

            this.QuoteDate = (DateTime)dr["QuoteDate"];
            this.QuoteDateStr = this.QuoteDate.ToString(Constants.FMT_DATE);
            this.ExpiryDate = (DateTime)dr["ExpiryDate"];
            if (this.ExpiryDate.Date < DateTime.Now.Date && this.Color == -1)
            {
                this.Color = (int)ColorList.Warning;
            }
            this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);
            this.IssuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            //if ((int)this.IssuedFlag == (int)IssuedFlagEnum.Unissued && this.Color == -1)
            //{
            //    this.Color = (int)ColorList.Info;
            //}
            //else if ((int)this.IssuedFlag == (int)IssuedFlagEnum.Issued && this.Color == -1)
            //{
            //    this.Color = (int)ColorList.Success;
            //}
            //this.IssuedDate = (DateTime)dr["IssuedDate"];
            //this.IssuedDateStr = this.IssuedDate.ToString(Constants.FMT_DATE);           
        }
    }
    
    /// <summary>
    /// Class QuotationDetailInfo
    /// </summary>
    [Serializable]
    public class QuotationDetailInfo
    {
        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Ger or set Type
        /// </summary>
        public QuotationDetailType Type { get; set; }

        /// <summary>
        /// Ger or set HeadLine
        /// </summary>
        public string HeadLine { get; set; }

        /// <summary>
        /// Ger or set Sell
        /// </summary>
        public SellInfo Sell { get; set; }

        /// <summary>
        /// Ger or set CostList
        /// </summary>
        public IList<CostInfo> CostList { get; set; }

        /// <summary>
        /// Checked
        /// </summary>
        public bool Checked { get; set; }

        /// <summary>
        /// Clone Object
        /// </summary>
        /// <typeparam name="T">Class to clone</typeparam>
        /// <returns></returns>
        public QuotationDetailInfo Clone()
        {
            return (QuotationDetailInfo)base.MemberwiseClone();
        }
    }

    /// <summary>
    /// Class SellInfo
    /// </summary>
    [Serializable]
    public class SellInfo
    {
        /// <summary>
        /// Get or set No
        /// </summary>
        public int SellNoDisp { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set Price
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set Profit
        /// </summary>
        public decimal? Profit { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public int VatType { get; set; }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Get or set Remark
        /// </summary>
        public string Remark { get; set; }

        public string Collapsed { get; set; }

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty(decimal defaultVATRatio)
        {
            if (string.IsNullOrEmpty(this.ProductCD) &&
                string.IsNullOrEmpty(this.ProductName) &&
                string.IsNullOrEmpty(this.Description) &&
                string.IsNullOrEmpty(this.Remark) &&
                this.UnitID == Constant.DEFAULT_ID &&
                !this.Price.HasValue &&
                !this.Quantity.HasValue &&
                !this.Total.HasValue &&
                !this.Vat.HasValue &&
                (!this.VatRatio.HasValue || this.VatRatio.Value == defaultVATRatio)
                )
            {
                return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Class CostInfo
    /// </summary>
    [Serializable]
    public class CostInfo
    {
        public int SellNo { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set CurrencyID
        /// </summary>
        public int CurrencyID { get; set; }

        /// <summary>
        /// Get or set PurchaseFlag
        /// </summary>
        public bool PurchaseFlag { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set Price
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public int VatType { get; set; }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        public string Collapsed { get; set; }

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty(decimal defaultVATRatio)
        {
            if (string.IsNullOrEmpty(this.ProductCD) &&
                string.IsNullOrEmpty(this.ProductName) &&
                string.IsNullOrEmpty(this.Description) &&
                !this.Price.HasValue &&
                !this.Quantity.HasValue &&
                !this.Total.HasValue &&
                !this.Vat.HasValue &&
                !this.PurchaseFlag &&
                (!this.VatRatio.HasValue || this.VatRatio.Value == defaultVATRatio)
                )
            {
                return true;
            }

            return false;
        }

    }   

    /// <summary>
    /// Class QuotationeExcel
    /// ISV-Nguyen
    /// </summary>
    [Serializable]
    public class QuotationExcel
    {
        public int ID { get; set; }
        public string QuoteNo { get; set; }

        public DateTime QuoteDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public DateTime ExpectedOrderDate { get; set; }
        public DateTime ExpectedRevenueDate { get; set; }
        public string PreparedCD { get; set; }
        public string PreparedName { get; set; }
        public string ApprovedCD { get; set; }
        public string ApprovedName { get; set; }
        public string SalesName1 { get; set; }
        public string SalesName2 { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string SubjectName { get; set; }
        public string Currency { get; set; }
        public string MethodVatName { get; set; }
        public decimal Total { get; set; }
        public decimal Vat { get; set; }
        public decimal GrandTotal { get; set; }
        public short StatusFlag { get; set; }
        public short IssuedFlag { get; set; }
        public string StatusFlagName { get; set; }
        public decimal ProfitRatio { get; set; }
        //public string TotalStr { get; set; }
        //public string VatStr { get; set; }
        //public string VatRatioStr { get; set; }
        //public string GrandTotalStr { get; set; }
        public string QuoteDateStr { get; set; }
        public string ExpiryDateStr { get; set; }
        public string ExpectedOrderDateStr { get; set; }
        public string ExpectedRevenueDateStr { get; set; }
        public short DecimalType { get; set; }
        //public string ProfitRatioStr { get; set; }
        public string Memo { get; set; }

        /// <summary>
        /// Contructor class QuotationeExcel
        /// </summary>
        public QuotationExcel()
        {
            this.ID = 0;
            this.QuoteNo = string.Empty;
            this.QuoteDate = DateTime.MinValue;
            this.ExpiryDate = DateTime.MinValue;
            this.PreparedCD = string.Empty;
            this.PreparedName = string.Empty;
            this.ApprovedCD = string.Empty;
            this.ApprovedName = string.Empty;
            this.SalesName1 = string.Empty;
            this.SalesName2 = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.SubjectName = string.Empty;
            this.MethodVatName =string.Empty;
            this.StatusFlag = 0;
            this.IssuedFlag = 0;
            this.StatusFlagName = string.Empty;
            this.Currency = string.Empty;
            this.DecimalType = 0;
            //this.GrandTotalStr = string.Empty;
            this.Memo = string.Empty;            
        }

        /// <summary>
        /// Constructor class QuotationeExcel
        /// </summary>
        /// <param name="dr"></param>
        public QuotationExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            this.ProfitRatio = EditDataUtil.CalSumProfit((decimal)dr["TotalSell"], (decimal)dr["TotalCost"]);
            
            if (this.ProfitRatio > Constant.MAX_PROFIT)
            {
                this.ProfitRatio = Constant.MAX_PROFIT;
            }

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                //}
            }
            //this.ProfitRatioStr = this.ProfitRatio.ToString(Constants.FMT_DECIMAL);
            this.SalesName1 = (string)dr["SalesName1"];
            this.SalesName2 = (string)dr["SalesName2"];
            this.ApprovedName = (string)dr["ApprovedName"];
            this.PreparedName = (string)dr["PreparedName"];
            this.Memo = (string)dr["Memo"];
            
            if (dr["MethodVatName"] != DBNull.Value)
            {
                this.MethodVatName = (string)dr["MethodVatName"];
            }
            
            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
            }
            this.StatusFlagName = (string)dr["StatusFlagName"];
            this.QuoteDate = (DateTime)dr["QuoteDate"];
            this.QuoteDateStr = this.QuoteDate.ToString(Constants.FMT_DATE);
            this.IssuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            this.ExpiryDate = (DateTime)dr["ExpiryDate"];
            this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);


            this.ExpectedOrderDate = (DateTime)dr["ExpectedOrderDate"];

            if (this.ExpectedOrderDate != new DateTime(1900, 1, 1))
            {
                this.ExpectedOrderDateStr = this.ExpectedOrderDate.ToString(Constants.FMT_DATE);
            }

            

            this.ExpectedRevenueDate = (DateTime)dr["ExpectedRevenueDate"];
            if (this.ExpectedRevenueDate != new DateTime(1900, 1, 1))
            {
                this.ExpectedRevenueDateStr = this.ExpectedRevenueDate.ToString(Constants.FMT_DATE);
            }            
            
        }

        ///// <summary>
        ///// CalcProfit
        ///// </summary>
        ///// <param name="totalSell"></param>
        ///// <param name="totalCost"></param>
        ///// <param name="fractionType"></param>
        ///// <returns></returns>
        //private decimal CalcProfit(decimal totalSell, decimal totalCost, FractionType fractionType)
        //{
        //    decimal ret = 0;

        //    //Check  total sell

        //    if (totalSell <= 0)
        //    {
        //        return ret;
        //    }

        //    //calculate profit
        //    ret = Fraction.Round(fractionType, (decimal)((totalSell - totalCost) / totalSell) * 100, 2);

        //    if (ret < 0)
        //    {
        //        ret = 0;
        //    }
        //    return ret;

        //}
    }

    /// <summary>
    /// Quotation Product Search Model
    /// </summary>
    [Serializable]
    public class QuotationProductSearchModel : BaseSearch
    {
        /// <summary>
        /// Gets or sets the quote date FRM.
        /// </summary>
        /// <value>
        /// The quote date FRM.
        /// </value>
        public DateTime? QuoteDateFrm { get; set; }

        /// <summary>
        /// Gets or sets the quote date to.
        /// </summary>
        /// <value>
        /// The quote date to.
        /// </value>
        public DateTime? QuoteDateTo { get; set; }

        /// <summary>
        /// Gets or sets the category i d1.
        /// </summary>
        /// <value>
        /// The category i d1.
        /// </value>
        public int CategoryID1 { get; set; }
        /// <summary>
        /// Gets or sets the category i d2.
        /// </summary>
        /// <value>
        /// The category i d2.
        /// </value>
        public int CategoryID2 { get; set; }
        /// <summary>
        /// Gets or sets the category i d3.
        /// </summary>
        /// <value>
        /// The category i d3.
        /// </value>
        public int CategoryID3 { get; set; }
        /// <summary>
        /// Gets or sets the product cd.
        /// </summary>
        /// <value>
        /// The product cd.
        /// </value>
        public string ProductCD { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the unit price FRM.
        /// </summary>
        /// <value>
        /// The unit price FRM.
        /// </value>
        public decimal? UnitPriceFrm { get; set; }

        /// <summary>
        /// Gets or sets the unit price to.
        /// </summary>
        /// <value>
        /// The unit price to.
        /// </value>
        public decimal? UnitPriceTo { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the customer cd.
        /// </summary>
        /// <value>
        /// The customer cd.
        /// </value>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the currency identifier.
        /// </summary>
        /// <value>
        /// The currency identifier.
        /// </value>
        public int CurrencyID { get; set; }
    }

    /// <summary>
    /// Quotation Product Search Result
    /// </summary>
    [Serializable]
    public class QuotationProductSearchResult
    {
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string CustomerInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.CustomerCD, this.CustomerName);
            }
        }
        public int CurrencyID { get; set; }
        public DateTime QuoteDate { get; set; }
        public string QuoteDateStr
        {
            get
            {
                return this.QuoteDate.ToString(Constants.FMT_DATE);
            }
        }
        public string QuoteNo { get; set; }
        public int QuoteID { get; set; }
        public int SellNo { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string ProductInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.ProductCD, this.ProductName);
            }
        }
        public string MoneyCode { get; set; }
        public int DecimalType { get; set; }
        public decimal UnitPrice { get; set; }
        public string UnitPriceStr
        {
            get
            {
                string span = string.Empty;
                if (this.UnitPrice >= 0)
                {
                    span = "<span>{0}</span>";
                }
                else
                {
                    span = "<span class='negative-num'>{0}</span>";
                }
                return string.Format(span, this.UnitPrice.ToString(this.DecimalType > 0 ? "N2" : "N0"));
            }
        }
        
        public int RowNumber { get; set; }

        #region Contructor
        public QuotationProductSearchResult()
        {
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.CurrencyID = 0;
            this.QuoteDate = CommonUtil.GetDefaultDate();
            this.QuoteNo = string.Empty;
            this.QuoteID = 0;
            this.SellNo = 0;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.MoneyCode = string.Empty;
            this.DecimalType = 0;
            this.UnitPrice = 0;
            this.RowNumber = 0;
        }

        public QuotationProductSearchResult(DbDataReader dr)
        {
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.CurrencyID = (int)dr["CurrencyID"];
            this.QuoteDate = (DateTime)dr["QuoteDate"];
            this.QuoteNo = (string)dr["QuoteNo"];
            this.QuoteID = (int)dr["QuoteID"];
            this.SellNo = (int)dr["SellNo"];
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.MoneyCode = (string)dr["MoneyCode"];
            this.DecimalType = (byte)dr["DecimalType"];
            this.UnitPrice = (decimal)dr["UnitPrice"];
            this.RowNumber = Convert.ToInt32(dr["RowNumber"]);
        }
        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class CurrencyInfo Model
    /// Create Date: 2014/07/24
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class CurrencyInfo
    {
        public long RowNumber { get; set; }

        //M_Currency_H
        public int ID { get; set; }
        public string MoneyCode { get; set; }
        public string MoneyNameUS { get; set; }
        public string MoneyNameVN { get; set; }
        public string TaxName { get; set; }
        public int DecimalType { get; set; }
        public string DecimalNameUS { get; set; }
        public string DecimalNameVN { get; set; }
        public int OrderIndex { get; set; }

        //M_Currency_D
        public int HID { get; set; }
        public DateTime EffectDate { get; set; }
        public DateTime ExpireDate { get; set; }
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Constructor
        /// </summary>
        public CurrencyInfo()
        {
            this.RowNumber = 0;

            this.ID = 0;
            this.MoneyCode = string.Empty;
            this.MoneyNameUS = string.Empty;
            this.MoneyNameVN = string.Empty;
            this.TaxName = string.Empty;
            this.DecimalType = 0;
            this.DecimalNameUS = string.Empty;
            this.DecimalNameVN = string.Empty;
            this.OrderIndex = 0;

            this.HID = 0;
            this.EffectDate = DateTime.Now;
            this.ExpireDate = DateTime.Now;
            this.ExchangeRate = 0;
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CurrencyInfo(DbDataReader dr)
        {
            this.RowNumber = long.Parse(dr["RowNumber"].ToString());

            this.ID = (int)dr["ID"];
            this.MoneyCode = (string)dr["MoneyCode"];
            this.MoneyNameUS = (string)dr["MoneyNameUS"];
            this.MoneyNameVN = (string)dr["MoneyNameVN"];
            this.TaxName = (string)dr["TaxName"];
            this.DecimalType = int.Parse(dr["DecimalType"].ToString());
            this.DecimalNameUS = (string)dr["DecimalNameUS"];
            this.DecimalNameVN = (string)dr["DecimalNameVN"];
            this.OrderIndex = (int)dr["OrderIndex"];

            this.HID = (int)dr["HID"];
            this.EffectDate = (DateTime)dr["EffectDate"];
            this.ExpireDate = (DateTime)dr["ExpireDate"];
            this.ExchangeRate = (decimal)dr["ExchangeRate"];
        }
    }
}

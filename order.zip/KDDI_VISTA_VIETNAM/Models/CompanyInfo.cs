﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class CompanyInfo
    /// </summary>
    [Serializable]
    public class CompanyInfo
    {
        public int ID { get; set; }
        public string CompanyName1 { get; set; }
        public string CompanyName2 { get; set; }
        public string CompanyAddress1 { get; set; }
        public string CompanyAddress2 { get; set; }
        public string CompanyAddress3 { get; set; }
        public string CompanyAddress4 { get; set; }
        public string CompanyAddress5 { get; set; }
        public string CompanyAddress6 { get; set; }
        public string Tel { get; set; }
        public string Tel2 { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string TAXCode { get; set; }
        public string CompanyBank { get; set; }
        public string AccountCode { get; set; }
        public string Represent { get; set; }
        public string Position { get; set; }
        public string Position2 { get; set; }

        /// <summary>
        /// Constructor class CompanyInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CompanyInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.CompanyName1 = (string)dr["CompanyName1"]; ;
            this.CompanyName2 = (string)dr["CompanyName2"];
            this.CompanyAddress1 = (string)dr["CompanyAddress1"];
            this.CompanyAddress2 = (string)dr["CompanyAddress2"];
            this.CompanyAddress3 = (string)dr["CompanyAddress3"]; ;
            this.CompanyAddress4 = (string)dr["CompanyAddress4"];
            this.CompanyAddress5 = (string)dr["CompanyAddress5"];
            this.CompanyAddress6 = (string)dr["CompanyAddress6"];
            this.Tel = (string)dr["Tel"];
            this.Tel2 = (string)dr["Tel2"];
            this.FAX = (string)dr["FAX"];
            this.EmailAddress = (string)dr["EmailAddress"];
            this.TAXCode = (string)dr["TAXCode"];
            this.CompanyBank = (string)dr["CompanyBank"];
            this.AccountCode = (string)dr["AccountCode"];
            this.Represent = (string)dr["Represent"];
            this.Position = (string)dr["Position"];
            this.Position2 = (string)dr["Position2"];
        }

        /// <summary>
        /// Constructor class CompanyInfo
        /// </summary>
        public CompanyInfo()
        {
            
            this.CompanyName1 = string.Empty;
            this.CompanyName2 = string.Empty;
            this.CompanyAddress1 = string.Empty;
            this.CompanyAddress2 = string.Empty;
            this.CompanyAddress3 = string.Empty;
            this.CompanyAddress4 = string.Empty;
            this.CompanyAddress5 = string.Empty;
            this.CompanyAddress6 = string.Empty;
            this.Tel = string.Empty;
            this.Tel2 = string.Empty;
            this.FAX = string.Empty;
            this.EmailAddress = string.Empty;
            this.TAXCode = string.Empty;
            this.CompanyBank = string.Empty;
            this.AccountCode = string.Empty;
            this.Represent = string.Empty;
            this.Position = string.Empty;
            this.Position2 = string.Empty;
        }
    }
}

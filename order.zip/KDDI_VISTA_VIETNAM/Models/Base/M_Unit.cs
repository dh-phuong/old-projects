﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class M_Unit
    /// </summary>
    [Serializable]
    public class M_Unit : M_Base<M_Unit>
    {
        #region Constant

        /// <summary>
        /// max length of Unit Name
        /// </summary>
        public const int UNIT_NAME_MAX_LENGTH = 12;

        #endregion

        #region Variable

        /// <summary>
        /// Unit Name
        /// </summary>
        private string unitName;

        #endregion

        #region Property

        /// <summary>
        /// Get or set Unit Name
        /// </summary>
        public string UnitName
        {
            get { return this.unitName; }
            set
            {
                if (value != this.unitName)
                {
                    this.unitName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Unit
        /// </summary>
        public M_Unit()
            : base()
        {
        }

        /// <summary>
        /// Contructor
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Unit(DbDataReader dr)
            : base(dr)
        {
            this.unitName = (string)dr["UnitName"];
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Sales_D_Sell Model
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class T_Sales_D_Sell
    {
        #region Variable
        /// <summary>
        /// InternalID
        /// </summary>
        private int _internalID;
        /// <summary>
        /// HID
        /// </summary>
        private int _hID;
        /// <summary>
        /// No
        /// </summary>
        private int _no;
        /// <summary>
        /// ProductID
        /// </summary>
        private int _productID;
        /// <summary>
        /// ProductCD
        /// </summary>
        private string _productCD;
        /// <summary>
        /// ProductName
        /// </summary>
        private string _productName;
        /// <summary>
        /// Description
        /// </summary>
        private string _description;
        /// <summary>
        /// Remark
        /// </summary>
        private string _remark;
        /// <summary>
        /// UnitID
        /// </summary>
        private int _unitID;
        /// <summary>
        /// UnitPrice
        /// </summary>
        private decimal _unitPrice;
        /// <summary>
        /// Quantity
        /// </summary>
        private decimal _quantity;
        /// <summary>
        /// Vat
        /// </summary>
        private decimal _vat;
        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;
        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;
        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;
        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        #endregion

        #region Property
        /// <summary>
        /// Get,set InternalID
        /// </summary>
        public int InternalID
        {
            get { return this._internalID; }
            set
            {
                if (value != this._internalID)
                {
                    this._internalID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this._hID; }
            set
            {
                if (value != this._hID)
                {
                    this._hID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set No
        /// </summary>
        public int No
        {
            get { return this._no; }
            set
            {
                if (value != this._no)
                {
                    this._no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductID
        /// </summary>
        public int ProductID
        {
            get { return this._productID; }
            set
            {
                if (value != this._productID)
                {
                    this._productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductCD
        /// </summary>
        public string ProductCD
        {
            get { return this._productCD; }
            set
            {
                if (value != this._productCD)
                {
                    this._productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductName
        /// </summary>
        public string ProductName
        {
            get { return this._productName; }
            set
            {
                if (value != this._productName)
                {
                    this._productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Description
        /// </summary>
        public string Description
        {
            get { return this._description; }
            set
            {
                if (value != this._description)
                {
                    this._description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Remark
        /// </summary>
        public string Remark
        {
            get { return this._remark; }
            set
            {
                if (value != this._remark)
                {
                    this._remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitID
        /// </summary>
        public int UnitID
        {
            get { return this._unitID; }
            set
            {
                if (value != this._unitID)
                {
                    this._unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitPrice
        /// </summary>
        public decimal UnitPrice
        {
            get { return this._unitPrice; }
            set
            {
                if (value != this._unitPrice)
                {
                    this._unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Quantity
        /// </summary>
        public decimal Quantity
        {
            get { return this._quantity; }
            set
            {
                if (value != this._quantity)
                {
                    this._quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Vat
        /// </summary>
        public decimal Vat
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VatType
        /// </summary>
        public short VatType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }
        #endregion
        
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Sales_D_Sell()
        {
            this._productID = Constant.DEFAULT_ID;
            this._productCD = string.Empty;
            this._productName = string.Empty;
            this._description = string.Empty;
            this._unitID = Constant.DEFAULT_ID;
            this._unitPrice = 0;
            this._quantity = 0;
            this._vat = 0;
            this._vatRatio = 0;
            this._vatType = 0;
            this._total = 0;
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Sales_D_Sell(DbDataReader dr)
        {
            this._internalID = (int)dr["InternalID"];
            this._hID = (int)dr["HID"];
            this._no = (int)dr["No"];
            this._productID = (int)dr["ProductID"];
            this._productCD = string.Format("{0}", dr["ProductCD"]);
            this._productName = string.Format("{0}", dr["ProductName"]);
            this._description = string.Format("{0}", dr["Description"]);
            this._remark = string.Format("{0}", dr["Remark"]);
            this._unitID = (int)dr["UnitID"];
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._quantity = (decimal)dr["Quantity"];
            this._vat = (decimal)dr["Vat"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._total = (decimal)dr["Total"];
        }
        #endregion
    }
}
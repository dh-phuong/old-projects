﻿using System;

namespace OMS.Models
{
    [Serializable]
    public class T_No
    {
        /// <summary>
        /// QuoteNo Key
        /// </summary>
        public const string QuoteNo = "QuoteNo";
        /// <summary>
        /// SalesNo Key
        /// </summary>
        public const string SalesNo = "SalesNo";
        /// <summary>
        /// PurchaseNo Key
        /// </summary>
        public const string PurchaseNo = "PurchaseNo";
        ///// <summary>
        ///// InvoiceNo Key
        ///// </summary>
        //public const string InvoiceNo = "InvoiceNo";

        /// <summary>
        /// BillingNo Key
        /// </summary>
        public const string BillingNo = "BillingNo";

        /// <summary>
        /// DeliveryNo Key
        /// </summary>
        public const string DeliveryNo = "DeliveryNo";
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Billing_C Model
    /// Create Author: ISV-Giam
    /// Create Date: 2014/12/16
    [Serializable]
    public class T_Billing_C
    {
        #region Variable
        /// <summary>
        /// HID
        /// </summary>
        private int _hid;
        /// <summary>
        /// Conditions
        /// </summary>
        private string _conditions;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Billing_C()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Billing_C(DbDataReader dr)
        {
            this._hid = (int)dr["HID"];
            this._conditions = (string)dr["Conditions"];
        }
        #endregion

        #region Property
        /// <summary>
        /// Get,set ID
        /// </summary>
        public int HID
        {
            get { return this._hid; }
            set
            {
                if (value != this._hid)
                {
                    this._hid = value;
                }
            }
        }
        /// <summary>
        /// Get,set Conditions
        /// </summary>
        public string Conditions
        {
            get { return this._conditions; }
            set
            {
                if (value != this._conditions)
                {
                    this._conditions = value;
                }
            }
        }
        #endregion
    }
}

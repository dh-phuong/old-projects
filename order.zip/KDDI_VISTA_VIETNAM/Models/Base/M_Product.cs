﻿
using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class M_Product model
    /// Create Author: ISV-HUNG
    /// Create Data: 2014/09/22
    /// </summary>
    [Serializable]
    public class M_Product : M_Base<M_Product>
    {
        #region Constant

        /// <summary>
        /// Max length Show of Product code
        /// </summary>
        public const int PRODUCT_CODE_MAX_LENGTH = 15;

        /// <summary>
        /// Max length DB of Product code
        /// </summary>
        public const int PRODUCT_CODE_MAX_LENGTH_DB = 50;

        /// <summary>
        /// Max length of Product name
        /// </summary>
        public const int PRODUCT_NAME_MAX_LENGTH = 200;

        /// <summary>
        /// Max length of Description
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;

        /// <summary>
        /// Max length of Lead time cost
        /// </summary>
        public const int LEAD_TIME_MAX_LENGTH = 25;

        /// <summary>
        /// Max length of Remark
        /// </summary>
        public const int REMARK_MAX_LENGTH = 500;

        /// <summary>
        /// Max Unit Price USD
        /// </summary>
        public const decimal MAX_UNIT_PRICE_USD = (decimal)9999999.99;

        /// <summary>
        /// Max Unit Price VND
        /// </summary>
        public const decimal MAX_UNIT_PRICE_VND = 9999999999;

        public const string PRODUCT_CODE_SUPPORT = "999999";

        #endregion

        #region Variable
        /// <summary>
        /// Product code
        /// </summary>
        private string productCD;

        /// <summary>
        /// Product name
        /// </summary>
        private string productName;

        /// <summary>
        /// Category Struct ID
        /// </summary>
        private int categoryStructID;

        /// <summary>
        /// Type
        /// </summary>
        private short type;

        /// <summary>
        /// DescriptionSell
        /// </summary>
        private string descriptionSell;

        /// <summary>
        /// CurrencyIDSell
        /// </summary>
        private int currencyIDSell;

        /// <summary>
        /// UnitPriceSell
        /// </summary>
        private decimal unitPriceSell;

        /// <summary>
        /// UnitIDSell
        /// </summary>
        private int unitIDSell;

        /// <summary>
        /// VatTypeSell
        /// </summary>
        private short vatTypeSell;

        /// <summary>
        /// VatRatioSell
        /// </summary>
        private decimal vatRatioSell;

        /// <summary>
        /// RemarkSell
        /// </summary>
        private string remarkSell;

        /// <summary>
        /// DescriptionCost
        /// </summary>
        private string descriptionCost;

        /// <summary>
        /// CurrencyIDCost
        /// </summary>
        private int currencyIDCost;

        /// <summary>
        /// UnitPriceCost
        /// </summary>
        private decimal unitPriceCost;

        /// <summary>
        /// UnitIDCost
        /// </summary>
        private int unitIDCost;

        /// <summary>
        /// VatTypeCost
        /// </summary>
        private short vatTypeCost;

        /// <summary>
        /// VatRatioCost
        /// </summary>
        private decimal vatRatioCost;

        /// <summary>
        /// RemarkCost
        /// </summary>
        private string remarkCost;

        /// <summary>
        /// PurchaseFlag
        /// </summary>
        private short purchaseFlag;

        /// <summary>
        /// status Flag
        /// </summary>
        private short statusFlag;
        #endregion

        #region Property
        /// <summary>
        /// Product code
        /// </summary>
        public string ProductCD
        {
            get { return this.productCD; }
            set
            {
                if (value != this.productCD)
                {
                    this.productCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product name
        /// </summary>
        public string ProductName
        {
            get { return this.productName; }
            set
            {
                if (value != this.productName)
                {
                    this.productName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Category Struct ID
        /// </summary>
        public int CategoryStructID
        {
            get { return this.categoryStructID; }
            set
            {
                if (value != this.categoryStructID)
                {
                    this.categoryStructID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Type
        /// </summary>
        public short Type
        {
            get { return this.type; }
            set
            {
                if (value != this.type)
                {
                    this.type = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DescriptionSell
        /// </summary>
        public string DescriptionSell
        {
            get { return this.descriptionSell; }
            set
            {
                if (value != this.descriptionSell)
                {
                    this.descriptionSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyIDSell
        /// </summary>
        public int CurrencyIDSell
        {
            get { return this.currencyIDSell; }
            set
            {
                if (value != this.currencyIDSell)
                {
                    this.currencyIDSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitPriceSell
        /// </summary>
        public decimal UnitPriceSell
        {
            get { return this.unitPriceSell; }
            set
            {
                if (value != this.unitPriceSell)
                {
                    this.unitPriceSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitIDSell
        /// </summary>
        public int UnitIDSell
        {
            get { return this.unitIDSell; }
            set
            {
                if (value != this.unitIDSell)
                {
                    this.unitIDSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatTypeSell
        /// </summary>
        public short VatTypeSell
        {
            get { return this.vatTypeSell; }
            set
            {
                if (value != this.vatTypeSell)
                {
                    this.vatTypeSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatRatioSell
        /// </summary>
        public decimal VatRatioSell
        {
            get { return this.vatRatioSell; }
            set
            {
                if (value != this.vatRatioSell)
                {
                    this.vatRatioSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// RemarkSell
        /// </summary>
        public string RemarkSell
        {
            get { return this.remarkSell; }
            set
            {
                if (value != this.remarkSell)
                {
                    this.remarkSell = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DescriptionCost
        /// </summary>
        public string DescriptionCost
        {
            get { return this.descriptionCost; }
            set
            {
                if (value != this.descriptionCost)
                {
                    this.descriptionCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyIDCost
        /// </summary>
        public int CurrencyIDCost
        {
            get { return this.currencyIDCost; }
            set
            {
                if (value != this.currencyIDCost)
                {
                    this.currencyIDCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitPriceCost
        /// </summary>
        public decimal UnitPriceCost
        {
            get { return this.unitPriceCost; }
            set
            {
                if (value != this.unitPriceCost)
                {
                    this.unitPriceCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitIDCost
        /// </summary>
        public int UnitIDCost
        {
            get { return this.unitIDCost; }
            set
            {
                if (value != this.unitIDCost)
                {
                    this.unitIDCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatTypeCost
        /// </summary>
        public short VatTypeCost
        {
            get { return this.vatTypeCost; }
            set
            {
                if (value != this.vatTypeCost)
                {
                    this.vatTypeCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatRatioCost
        /// </summary>
        public decimal VatRatioCost
        {
            get { return this.vatRatioCost; }
            set
            {
                if (value != this.vatRatioCost)
                {
                    this.vatRatioCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// RemarkCost
        /// </summary>
        public string RemarkCost
        {
            get { return this.remarkCost; }
            set
            {
                if (value != this.remarkCost)
                {
                    this.remarkCost = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PurchaseFlag
        /// </summary>
        public short PurchaseFlag
        {
            get { return this.purchaseFlag; }
            set
            {
                if (value != this.purchaseFlag)
                {
                    this.purchaseFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// status Flag
        /// </summary>
        public short StatusFlag
        {
            get { return this.statusFlag; }
            set
            {
                if (value != this.statusFlag)
                {
                    this.statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Product
        /// </summary>
        public M_Product()
            : base()
        { 
        }

        /// <summary>
        /// Contructor of M_Product
        /// </summary>
        /// <param name="dr">Database Data Reader</param>
        public M_Product(DbDataReader dr)
            : base(dr)
        {
            this.productCD = string.Format("{0}", dr["ProductCD"]);
            this.productName = string.Format("{0}", dr["ProductName"]);
            this.categoryStructID = int.Parse(string.Format("{0}", dr["CategoryStructID"]));
            this.type = short.Parse(string.Format("{0}", dr["Type"]));
            this.descriptionSell = string.Format("{0}", dr["DescriptionSell"]);
            this.currencyIDSell = int.Parse(string.Format("{0}", dr["CurrencyIDSell"]));
            this.unitPriceSell = decimal.Parse(string.Format("{0}", dr["UnitPriceSell"]));
            this.unitIDSell = int.Parse(string.Format("{0}", dr["UnitIDSell"]));
            this.vatTypeSell = short.Parse(string.Format("{0}", dr["VatTypeSell"]));
            this.vatRatioSell = decimal.Parse(string.Format("{0}", dr["VatRatioSell"]));
            this.remarkSell = string.Format("{0}", dr["RemarkSell"]);

            this.descriptionCost = string.Format("{0}", dr["DescriptionCost"]);
            this.currencyIDCost = int.Parse(string.Format("{0}", dr["CurrencyIDCost"]));
            this.unitPriceCost = decimal.Parse(string.Format("{0}", dr["UnitPriceCost"]));
            this.unitIDCost = int.Parse(string.Format("{0}", dr["UnitIDCost"]));
            this.vatTypeCost = short.Parse(string.Format("{0}", dr["VatTypeCost"]));
            this.vatRatioCost = decimal.Parse(string.Format("{0}", dr["VatRatioCost"]));
            this.remarkCost = string.Format("{0}", dr["RemarkCost"]);
            this.purchaseFlag = short.Parse(string.Format("{0}", dr["PurchaseFlag"]));
            this.statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
        }
        #endregion
    }
}
﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Config service
    /// </summary>
    [Serializable]
    public class M_Setting : M_Base<M_Setting>
    {
        #region Constant
        public const int QUOTE_NO_MAX_LENGTH = 6;
        public const int SALES_NO_MAX_LENGTH = 6;
        public const int PURCHASE_NO_MAX_LENGTH = 6;
        public const int BILLING_NO_MAX_LENGTH = 6;
        public const int DELIVERY_NO_MAX_LENGTH = 6;
        public const int ATTACH_PATH_MAX_LENGTH = 225;
        public const int SALES_CONTRACT_FILE_MAX_LENGTH = 225;
        public const int ACCEPTANCE_REPORT_FILE_MAX_LENGTH = 225;
        public const int LOGO_1_MAX_LENGTH = 225;
        public const int LOGO_2_MAX_LENGTH = 225;

        #endregion

        #region Variable

        /// <summary>
        /// QuoteNo
        /// </summary>
        public string _quoteNo;

        /// <summary>
        /// SalesNo
        /// </summary>
        public string _salesNo;

        /// <summary>
        /// PurchaseNo
        /// </summary>
        public string _purchaseNo;

        /// <summary>
        /// BillingNo
        /// </summary>
        public string _billingNo;

        /// <summary>
        /// ShippingNo
        /// </summary>
        public string _deliveryNo;

        /// <summary>
        /// Logo1
        /// </summary>
        public string _logo1;

        /// <summary>
        /// Logo2
        /// </summary>
        public string _logo2;

        /// <summary>
        /// AttachPath
        /// </summary>
        public string _attachPath;

        /// <summary>
        /// SalesContractFile1
        /// </summary>
        public string _salesContractFile1;

        /// <summary>
        /// SalesContractFile2
        /// </summary>
        public string _salesContractFile2;

        /// <summary>
        /// SalesContractFile3
        /// </summary>
        public string _salesContractFile3;

        /// <summary>
        /// SalesContractFile4
        /// </summary>
        public string _salesContractFile4;

        /// <summary>
        /// SalesContractFile5
        /// </summary>
        public string _salesContractFile5;

        /// <summary>
        /// acceptanceReportFile1
        /// </summary>
        public string _acceptanceReportFile1;

        /// <summary>
        /// acceptanceReportFile2
        /// </summary>
        public string _acceptanceReportFile2;

        /// <summary>
        /// acceptanceReportFile3
        /// </summary>
        public string _acceptanceReportFile3;

        /// <summary>
        /// acceptanceReportFile4
        /// </summary>
        public string _acceptanceReportFile4;

        /// <summary>
        /// acceptanceReportFile5
        /// </summary>
        public string _acceptanceReportFile5;

        #endregion

        #region Property

        /// <summary>
        /// Get or set quoteNo
        /// </summary>
        public string QuoteNo
        {
            get { return this._quoteNo; }
            set
            {
                if (value != this._quoteNo)
                {
                    this._quoteNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptNo
        /// </summary>
        public string SalesNo
        {
            get { return this._salesNo; }
            set
            {
                if (value != this._salesNo)
                {
                    this._salesNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set PurchaseNo
        /// </summary>
        public string PurchaseNo
        {
            get { return this._purchaseNo; }
            set
            {
                if (value != this._purchaseNo)
                {
                    this._purchaseNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set BillingNo
        /// </summary>
        public string BillingNo
        {
            get { return this._billingNo; }
            set
            {
                if (value != this._billingNo)
                {
                    this._billingNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set DeliveryNo
        /// </summary>
        public string DeliveryNo
        {
            get { return this._deliveryNo; }
            set
            {
                if (value != this._deliveryNo)
                {
                    this._deliveryNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Logo1
        /// </summary>
        public string Logo1
        {
            get { return this._logo1; }
            set
            {
                if (value != this._logo1)
                {
                    this._logo1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Logo2
        /// </summary>
        public string Logo2
        {
            get { return this._logo2; }
            set
            {
                if (value != this._logo2)
                {
                    this._logo2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AttachPath
        /// </summary>
        public string AttachPath
        {
            get { return this._attachPath; }
            set
            {
                if (value != this._attachPath)
                {
                    this._attachPath = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set SalesContractFile1
        /// </summary>
        public string SalesContractFile1
        {
            get { return this._salesContractFile1; }
            set
            {
                if (value != this._salesContractFile1)
                {
                    this._salesContractFile1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set SalesContractFile2
        /// </summary>
        public string SalesContractFile2
        {
            get { return this._salesContractFile2; }
            set
            {
                if (value != this._salesContractFile2)
                {
                    this._salesContractFile2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set SalesContractFile3
        /// </summary>
        public string SalesContractFile3
        {
            get { return this._salesContractFile3; }
            set
            {
                if (value != this._salesContractFile3)
                {
                    this._salesContractFile3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set SalesContractFile4
        /// </summary>
        public string SalesContractFile4
        {
            get { return this._salesContractFile4; }
            set
            {
                if (value != this._salesContractFile4)
                {
                    this._salesContractFile4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set SalesContractFile5
        /// </summary>
        public string SalesContractFile5
        {
            get { return this._salesContractFile5; }
            set
            {
                if (value != this._salesContractFile5)
                {
                    this._salesContractFile5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptanceReportFile1
        /// </summary>
        public string AcceptanceReportFile1
        {
            get { return this._acceptanceReportFile1; }
            set
            {
                if (value != this._acceptanceReportFile1)
                {
                    this._acceptanceReportFile1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptanceReportFile2
        /// </summary>
        public string AcceptanceReportFile2
        {
            get { return this._acceptanceReportFile2; }
            set
            {
                if (value != this._acceptanceReportFile2)
                {
                    this._acceptanceReportFile2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptanceReportFile3
        /// </summary>
        public string AcceptanceReportFile3
        {
            get { return this._acceptanceReportFile3; }
            set
            {
                if (value != this._acceptanceReportFile3)
                {
                    this._acceptanceReportFile3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptanceReportFile4
        /// </summary>
        public string AcceptanceReportFile4
        {
            get { return this._acceptanceReportFile4; }
            set
            {
                if (value != this._acceptanceReportFile4)
                {
                    this._acceptanceReportFile4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AcceptanceReportFile5
        /// </summary>
        public string AcceptanceReportFile5
        {
            get { return this._acceptanceReportFile5; }
            set
            {
                if (value != this._acceptanceReportFile5)
                {
                    this._acceptanceReportFile5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor M_Setting
        /// </summary>
        public M_Setting()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Setting
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Setting(DbDataReader dr)
            : base(dr)
        {
            this._quoteNo = (string)dr["QuoteNo"];
            this._salesNo = (string)dr["SalesNo"];
            this._purchaseNo = (string)dr["PurchaseNo"];
            this._billingNo = (string)dr["BillingNo"];
            this._deliveryNo = (string)dr["DeliveryNo"];
            this._logo1 = (string)dr["Logo1"];
            this._logo2 = (string)dr["Logo2"];
            this._attachPath = (string)dr["AttachPath"];
            this._salesContractFile1 = (string)dr["SalesContractFile1"];
            this._salesContractFile2 = (string)dr["SalesContractFile2"];
            this._salesContractFile3 = (string)dr["SalesContractFile3"];
            this._salesContractFile4 = (string)dr["SalesContractFile4"];
            this._salesContractFile5 = (string)dr["SalesContractFile5"];
            this._acceptanceReportFile1 = (string)dr["AcceptanceReportFile1"];
            this._acceptanceReportFile2 = (string)dr["AcceptanceReportFile2"];
            this._acceptanceReportFile3 = (string)dr["AcceptanceReportFile3"];
            this._acceptanceReportFile4 = (string)dr["AcceptanceReportFile4"];
            this._acceptanceReportFile5 = (string)dr["AcceptanceReportFile5"]; 
        }
        #endregion
    }
}

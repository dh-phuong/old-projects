﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class Seting header
    /// </summary>
    [Serializable]
    public class M_Config_H : M_Base<M_Config_H>
    {
        #region Constant

        /// <summary>
        /// Max length of Config code
        /// </summary>
        public const int CONFIG_CODE_MAX_LENGTH = 4;

        /// <summary>
        /// Max length of config name
        /// </summary>
        public const int CONFIG_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Config cd paging
        /// </summary>
        public const string CONFIG_CD_PAGING = "L001";

        /// <summary>
        /// Config cd Status
        /// </summary>
        public const string CONFIG_CD_STATUS = "L002";

        /// <summary>
        /// Config cd VAT Type
        /// </summary>
        public const string CONFIG_CD_VAT_TYPE = "L003";

        /// <summary>
        /// Config cd Method VAT
        /// </summary>
        public const string CONFIG_CD_METHOD_VAT = "L004";

        /// <summary>
        /// Config cd Default VAT value
        /// </summary>
        public const string CONFIG_CD_DEFAULT_VAT_VAL = "L005";

        /// <summary>
        /// 小数点端数処理　Decimal Calc 
        /// </summary>
        public const string CONFIG_CD_FRACTION_TYPE = "L006";

        /// <summary>
        ///  数量小数点設定 Quantity Decimal 
        /// </summary>
        public const string CONFIG_CD_QUANTITY_DECIMAL  = "L007";

        /// <summary>
        /// 原価明細初期表示　Default View Cost Detail 
        /// </summary>
        public const string CONFIG_CD_DEFAULT_COST_VIEW = "L008";

        /// <summary>
        /// Day Expiry
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY = "L009";

        /// <summary>
        /// default profit value
        /// </summary>
        public const string CONFIG_CD_DEFAULT_PROFIT_VALUE = "L010";

        /// <summary>
        /// default Serial Hidden value
        /// </summary>
        public const string CONFIG_CD_DEFAULT_SERIAL_HIDDEN = "L011";

        /// <summary>
        /// Config cd payment Method
        /// </summary>
        public const string CONFIG_CD_PAYMENT_METHOD = "L012";

        /// <summary>
        /// 一覧検索 コンボボックス
        /// </summary>
        public const string CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO = "L013";

        /// <summary>
        /// Pattern of Acceptance Report 
        /// </summary>
        public const string CONFIG_CD_ACCEPT_REPORT = "L014";

        /// <summary>
        /// ユーザー登録制限数　Max Active User No.
        /// </summary>
        public const string CONFIG_CD_MAX_ACTIVE_USER = "L015";

        /// <summary>
        /// 商品情報設定 Product Code Setting 
        /// </summary>
        public const string CONFIG_CD_PRODUCT_CD_SETTING = "L016";

        /// <summary>
        /// 最大添付ファイル容量　Max upload file volume 
        /// </summary>
        public const string CONFIG_CD_UPLOAD_FILE = "L017";

        /// <summary>
        /// CONFIG_GROUP_USERCD_ADMIN
        /// </summary>
        public const string CONFIG_GROUP_USERCD_ADMIN = "L018";

        /// <summary>
        /// Config Condition Type
        /// </summary>
        public const string CONFIG_CONDITION_TYPE = "L019";

        /// <summary>
        /// File Extension
        /// </summary>
        public const string CONFIG_FILE_EXTENSION_TYPE = "L020";

        /// <summary>
        /// 使用する商品コード
        /// </summary>
        public const string CONFIG_CD_PRODUCT_CD_USED = "L021";

        /// <summary>
        /// Profit設定
        /// </summary>
        public const string CONFIG_CD_PROFIT_SETTING = "L022";
        /// <summary>
        /// Config Serial Contract Type
        /// </summary>
        public const string CONFIG_CD_SERIAL_CONTRACT_TYPE = "L023";
        #endregion

        #region Variable

        /// <summary>
        /// Config Code
        /// </summary>
        public string ConfigCD { get; set; }

        /// <summary>
        /// Setting Name
        /// </summary>
        private string configName;

        #endregion

        #region Property

        /// <summary>
        /// Get or Set Config Name
        /// </summary>
        public string ConfigName
        {
            get { return configName; }
            set
            {
                if (value != this.configName)
                {
                    this.configName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Setting_H
        /// </summary>
        public M_Config_H()
            : base()
        { 
        }

        /// <summary>
        /// Contructor M_Setting_H
        /// </summary>
        /// <param name="dr"></param>
        public M_Config_H(DbDataReader dr)
            : base(dr)
        {
            this.ConfigCD = (string)dr["ConfigCD"];
            this.configName = (string)dr["ConfigName"];
        }


        #endregion

    }
}

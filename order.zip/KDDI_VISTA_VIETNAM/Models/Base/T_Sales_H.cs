﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Sales_H Model
    /// Create Author: ISV-HUNG
    /// Create Date: 2014/12/16
    /// </summary>
    [Serializable]
    public class T_Sales_H : M_Base<T_Sales_H>
    {
        #region Constant
        /// <summary>
        /// Sales no max length
        /// </summary>
        public const int SALES_NO_MAX_LENGTH = 20;

        /// <summary>
        ///Subject name max length
        /// </summary>
        public const int SUBJECT_NAME_MAX_LENGTH = 150;
        /// <summary>
        /// Max length of ProjectName
        /// </summary>
        public const int PROJECT_NAME_MAX_LENGTH = 150;
        /// <summary>
        /// Max length of Memo
        /// </summary>
        public const int MEMO_MAX_LENGTH = 150;
        /// <summary>
        /// Max length of Contract NO
        /// </summary>
        public const int CONTRACT_NO_MAX_LENGTH = 30;
        #endregion

        #region Variable
        /// <summary>
        /// SalesNo
        /// </summary>
        private string _salesNo;
        /// <summary>
        /// SalesDate
        /// </summary>
        private DateTime _salesDate;
        /// <summary>
        /// Quote No
        /// </summary>
        private string _quoteNo;
        /// <summary>
        /// QuoteDate
        /// </summary>
        private DateTime _quoteDate;
        /// <summary>
        /// PreparedCD
        /// </summary>
        private string _preparedCD;
        /// <summary>
        /// PreparedName
        /// </summary>
        private string _preparedName;
        /// <summary>
        /// ApprovedCD
        /// </summary>
        private string _approvedCD;
        /// <summary>
        /// ApprovedName
        /// </summary>
        private string _approvedName;
        /// <summary>
        /// SalesCD1
        /// </summary>
        private string _salesCD1;
        /// <summary>
        /// SalesName1
        /// </summary>
        private string _salesName1;
        /// <summary>
        /// SalesCD2
        /// </summary>
        private string _salesCD2;
        /// <summary>
        /// SalesName2
        /// </summary>
        private string _salesName2;
        /// <summary>
        /// CustomerCD
        /// </summary>
        private string _customerCD;
        /// <summary>
        /// CustomerName
        /// </summary>
        private string _customerName;
        /// <summary>
        /// SubjectName
        /// </summary>
        private string _subjectName;
        /// <summary>
        /// Memo
        /// </summary>
        private string _memo;
        /// <summary>
        /// ContractDate
        /// </summary>
        private string _contractNo;
        /// <summary>
        /// ContractDate
        /// </summary>
        private DateTime _contractDate;
        /// <summary>
        /// CustomerAddress1
        /// </summary>
        private string _customerAddress1;
        /// <summary>
        /// CustomerAddress2
        /// </summary>
        private string _customerAddress2;
        /// <summary>
        /// CustomerAddress3
        /// </summary>
        private string _customerAddress3;
        /// <summary>
        /// Tel
        /// </summary>
        private string _tel;
        /// <summary>
        /// FAX
        /// </summary>
        private string _fax;
        /// <summary>
        /// ContactPerson
        /// </summary>
        private string _contactPerson;
        /// <summary>
        /// CurrencyID
        /// </summary>
        private int _currencyID;
        /// <summary>
        /// MethodVat
        /// </summary>
        private short _methodVat;
        /// <summary>
        /// Vat
        /// </summary>
        private decimal _vat;
        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;
        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;
        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;
        /// <summary>
        /// GrandTotal
        /// </summary>
        private decimal _grandTotal;
        //2014/12/18 ISV-HUNG - Delete Start
        ///// <summary>
        ///// ProfitRatio
        ///// </summary>
        //private decimal _profitRatio;
        //2014/12/18 ISV-HUNG - Delete End
        /// <summary>
        /// Approved
        /// </summary>
        private string _approved;
        /// <summary>
        /// Position
        /// </summary>
        private string _position;
        /// <summary>
        /// Status Flag
        /// </summary>
        private short _statusFlag;
        /// <summary>
        /// IssuedFlag
        /// </summary>
        private short _issuedFlag;
        /// <summary>
        /// DeleteFlag
        /// </summary>
        private short _deleteFlag;
        /// <summary>
        /// IssuedDate
        /// </summary>
        private DateTime _issuedDate;
        /// <summary>
        /// IssuedUID
        /// </summary>
        private int _issuedUID;
        /// <summary>
        /// VersionUpdateUID
        /// </summary>
        private int _versionUpdateUID;
        /// <summary>
        /// VersionUpdateDate
        /// </summary>
        private DateTime _versionUpdateDate;
        /// <summary>
        /// FinishFlag
        /// </summary>
        private short _finishFlag;

        //---------------Add 2015/01/06-----------------//
        /// <summary>
        /// CompleteDate
        /// </summary>
        private DateTime _completeDate;

        /// <summary>
        /// PaymentDate
        /// </summary>
        private DateTime _paymentDate;
        //---------------Add 2015/01/06-----------------//
        #endregion

        #region Property
        /// <summary>
        /// Get,set SalesNo
        /// </summary>
        public string SalesNo
        {
            get { return this._salesNo; }
            set
            {
                if (value != this._salesNo)
                {
                    this._salesNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesDate
        /// </summary>
        public DateTime SalesDate
        {
            get { return this._salesDate; }
            set
            {
                if (value != this._salesDate)
                {
                    this._salesDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set QuoteNo
        /// </summary>
        public string QuoteNo
        {
            get { return this._quoteNo; }
            set
            {
                if (value != this._quoteNo)
                {
                    this._quoteNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set QuoteDate
        /// </summary>
        public DateTime QuoteDate
        {
            get { return this._quoteDate; }
            set
            {
                if (value != this._quoteDate)
                {
                    this._quoteDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PreparedCD
        /// </summary>
        public string PreparedCD
        {
            get { return this._preparedCD; }
            set
            {
                if (value != this._preparedCD)
                {
                    this._preparedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PreparedName
        /// </summary>
        public string PreparedName
        {
            get { return this._preparedName; }
            set
            {
                if (value != this._preparedName)
                {
                    this._preparedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ApprovedCD
        /// </summary>
        public string ApprovedCD
        {
            get { return this._approvedCD; }
            set
            {
                if (value != this._approvedCD)
                {
                    this._approvedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ApprovedName
        /// </summary>
        public string ApprovedName
        {
            get { return this._approvedName; }
            set
            {
                if (value != this._approvedName)
                {
                    this._approvedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesCD1
        /// </summary>
        public string SalesCD1
        {
            get { return this._salesCD1; }
            set
            {
                if (value != this._salesCD1)
                {
                    this._salesCD1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesName1
        /// </summary>
        public string SalesName1
        {
            get { return this._salesName1; }
            set
            {
                if (value != this._salesName1)
                {
                    this._salesName1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesCD2
        /// </summary>
        public string SalesCD2
        {
            get { return this._salesCD2; }
            set
            {
                if (value != this._salesCD2)
                {
                    this._salesCD2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesName2
        /// </summary>
        public string SalesName2
        {
            get { return this._salesName2; }
            set
            {
                if (value != this._salesName2)
                {
                    this._salesName2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerCD
        /// </summary>
        public string CustomerCD
        {
            get { return this._customerCD; }
            set
            {
                if (value != this._customerCD)
                {
                    this._customerCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerName
        /// </summary>
        public string CustomerName
        {
            get { return this._customerName; }
            set
            {
                if (value != this._customerName)
                {
                    this._customerName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SubjectName
        /// </summary>
        public string SubjectName
        {
            get { return this._subjectName; }
            set
            {
                if (value != this._subjectName)
                {
                    this._subjectName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Memo
        /// </summary>
        public string Memo
        {
            get { return this._memo; }
            set
            {
                if (value != this._memo)
                {
                    this._memo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ContractDate
        /// </summary>
        public string ContractNo
        {
            get { return this._contractNo; }
            set
            {
                if (value != this._contractNo)
                {
                    this._contractNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ContractDate
        /// </summary>
        public DateTime ContractDate
        {
            get { return this._contractDate; }
            set
            {
                if (value != this._contractDate)
                {
                    this._contractDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress1
        /// </summary>
        public string CustomerAddress1
        {
            get { return this._customerAddress1; }
            set
            {
                if (value != this._customerAddress1)
                {
                    this._customerAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress2
        /// </summary>
        public string CustomerAddress2
        {
            get { return this._customerAddress2; }
            set
            {
                if (value != this._customerAddress2)
                {
                    this._customerAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress3
        /// </summary>
        public string CustomerAddress3
        {
            get { return this._customerAddress3; }
            set
            {
                if (value != this._customerAddress3)
                {
                    this._customerAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Tel
        /// </summary>
        public string Tel
        {
            get { return this._tel; }
            set
            {
                if (value != this._tel)
                {
                    this._tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set FAX
        /// </summary>
        public string FAX
        {
            get { return this._fax; }
            set
            {
                if (value != this._fax)
                {
                    this._fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return this._contactPerson; }
            set
            {
                if (value != this._contactPerson)
                {
                    this._contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set CurrencyID
        /// </summary>
        public int CurrencyID
        {
            get { return this._currencyID; }
            set
            {
                if (value != this._currencyID)
                {
                    this._currencyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set MethodVat
        /// </summary>
        public short MethodVat
        {
            get { return this._methodVat; }
            set
            {
                if (value != this._methodVat)
                {
                    this._methodVat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal Vat
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public short VatType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set GrandTotal
        /// </summary>
        public decimal GrandTotal
        {
            get { return this._grandTotal; }
            set
            {
                if (value != this._grandTotal)
                {
                    this._grandTotal = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        //2014/12/18 ISV-HUNG - Delete Start
        ///// <summary>
        ///// Get or set ProfitRatio
        ///// </summary>
        //public decimal ProfitRatio
        //{
        //    get { return this._profitRatio; }
        //    set
        //    {
        //        if (value != this._profitRatio)
        //        {
        //            this._profitRatio = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}
        //2014/12/18 ISV-HUNG - Delete End

        /// <summary>
        /// Get or set Approved
        /// </summary>
        public string Approved
        {
            get { return this._approved; }
            set
            {
                if (value != this._approved)
                {
                    this._approved = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Position
        /// </summary>
        public string Position
        {
            get { return this._position; }
            set
            {
                if (value != this._position)
                {
                    this._position = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Status Flag
        /// </summary>
        public short StatusFlag
        {
            get { return _statusFlag; }
            set
            {
                if (value != this._statusFlag)
                {
                    this._statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set IssuedFlag
        /// </summary>
        public short IssuedFlag
        {
            get { return this._issuedFlag; }
            set
            {
                if (value != this._issuedFlag)
                {
                    this._issuedFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return this._deleteFlag; }
            set
            {
                if (value != this._deleteFlag)
                {
                    this._deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set IssuedDate
        /// </summary>
        public DateTime IssuedDate
        {
            get { return this._issuedDate; }
            set
            {
                if (value != this._issuedDate)
                {
                    this._issuedDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set IssuedUID
        /// </summary>
        public int IssuedUID
        {
            get { return this._issuedUID; }
            set
            {
                if (value != this._issuedUID)
                {
                    this._issuedUID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VersionUpdateDate
        /// </summary>
        public DateTime VersionUpdateDate
        {
            get { return this._versionUpdateDate; }
            set
            {
                if (value != this._versionUpdateDate)
                {
                    this._versionUpdateDate = value;
                }
            }
        }

        /// <summary>
        /// Get,set VersionUpdateUID
        /// </summary>
        public int VersionUpdateUID
        {
            get { return this._versionUpdateUID; }
            set
            {
                if (value != this._versionUpdateUID)
                {
                    this._versionUpdateUID = value;
                }
            }
        }

        /// <summary>
        /// Get,set FinishFlag
        /// </summary>
        public short FinishFlag
        {
            get { return this._finishFlag; }
            set
            {
                if (value != this._finishFlag)
                {
                    this._finishFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        //---------------Add 2015/01/06-----------------//
        /// <summary>
        /// Get,set CompleteDate
        /// </summary>
        public DateTime CompleteDate
        {
            get { return this._completeDate; }
            set
            {
                if (value != this._completeDate)
                {
                    this._completeDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PaymentDate
        /// </summary>
        public DateTime PaymentDate
        {
            get { return this._paymentDate; }
            set
            {
                if (value != this._paymentDate)
                {
                    this._paymentDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        //---------------Add 2015/01/06-----------------//
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Sales_H()
            : base()
        {
            this._salesNo = string.Empty;
            this._salesDate = DateTime.MinValue;
            this._quoteNo = string.Empty;
            this._quoteDate = DateTime.MinValue;
            this._preparedCD = string.Empty;
            this._preparedName = string.Empty;
            this._approvedCD = string.Empty;
            this._approvedName = string.Empty;
            this._salesCD1 = string.Empty;
            this._salesName1 = string.Empty;
            this._salesCD2 = string.Empty;
            this._salesName2 = string.Empty;
            this._customerCD = string.Empty;
            this._customerName = string.Empty;
            this._subjectName = string.Empty;
            this._memo = string.Empty;
            this._contractNo = string.Empty;
            this._contractDate = DateTime.MinValue;
            this._customerAddress1 = string.Empty;
            this._customerAddress2 = string.Empty;
            this._customerAddress3 = string.Empty;
            this._tel = string.Empty;
            this._fax = string.Empty;
            this._contactPerson = string.Empty;
            this._currencyID = Constant.DEFAULT_ID;
            this._methodVat = 0;
            this._vat = 0;
            this._vatRatio = 0;
            this._vatType = 0;
            this._total = 0;
            this._grandTotal = 0;
            //2014/12/18 ISV-HUNG - Delete Start
            //this._profitRatio = 0;
            //2014/12/18 ISV-HUNG - Delete End
            this._approved = string.Empty;
            this._position = string.Empty;
            this._statusFlag = 0;
            this._issuedFlag = 0;
            this._deleteFlag = 0;
            this._issuedDate = DateTime.MinValue;
            this._issuedUID = 0;
            this._versionUpdateUID = 0;
            this._versionUpdateDate = DateTime.MinValue;
            this._finishFlag = 0;
            //---------------Add 2015/01/06-----------------//
            this._completeDate = DateTime.MinValue;
            this._paymentDate = DateTime.MinValue;
            //---------------Add 2015/01/06-----------------//
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Sales_H(DbDataReader dr)
            : base(dr)
        {
            this._salesNo = (string)dr["SalesNo"];
            this._salesDate = (DateTime)dr["SalesDate"];
            this._quoteNo = (string)dr["QuoteNo"];
            this._quoteDate = (DateTime)dr["QuoteDate"];
            this._preparedCD = (string)dr["PreparedCD"];
            this._preparedName = (string)dr["PreparedName"];
            this._approvedCD = (string)dr["ApprovedCD"];
            this._approvedName = (string)dr["ApprovedName"];
            this._salesCD1 = (string)dr["SalesCD1"];
            this._salesName1 = (string)dr["SalesName1"];
            this._salesCD2 = (string)dr["SalesCD2"];
            this._salesName2 = (string)dr["SalesName2"];
            this._customerCD = (string)dr["CustomerCD"];
            this._customerName = (string)dr["CustomerName"];
            this._subjectName = (string)dr["SubjectName"];
            this._memo = (string)dr["Memo"];
            this._contractNo = (string)dr["ContractNo"];
            this._contractDate = (DateTime)dr["ContractDate"];
            this._customerAddress1 = (string)dr["CustomerAddress1"];
            this._customerAddress2 = (string)dr["CustomerAddress2"];
            this._customerAddress3 = (string)dr["CustomerAddress3"];
            this._tel = (string)dr["Tel"];
            this._fax = (string)dr["FAX"];
            this._contactPerson = (string)dr["ContactPerson"];
            this._currencyID = (int)dr["CurrencyID"];
            this._methodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            this._vat = (decimal)dr["Vat"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._total = (decimal)dr["Total"];
            this._grandTotal = (decimal)dr["GrandTotal"];
            //2014/12/18 ISV-HUNG - Delete Start
            //this._profitRatio = (decimal)dr["ProfitRatio"];
            //2014/12/18 ISV-HUNG - Delete End
            this._approved = (string)dr["Approved"];
            this._position = (string)dr["Position"];
            this._statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
            this._issuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            this._deleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this._issuedDate = (DateTime)dr["IssuedDate"];
            this._issuedUID = (int)dr["IssuedUID"];
            this._versionUpdateDate = (DateTime)dr["VersionUpdateDate"];
            this._versionUpdateUID = (int)dr["VersionUpdateUID"];
            this._finishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            //---------------Add 2015/01/06-----------------//
            this._completeDate = (DateTime)dr["CompleteDate"];
            this._paymentDate = (DateTime)dr["PaymentDate"];
            //---------------Add 2015/01/06-----------------//
        }
        #endregion
    }
}
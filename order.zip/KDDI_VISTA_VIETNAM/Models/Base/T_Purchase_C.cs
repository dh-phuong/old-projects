﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Purchase_C Model
    /// Create Date: 2014/09/03
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class T_Purchase_C
    {
        #region Variable
        /// <summary>
        /// HID
        /// </summary>
        private int hID;
        /// <summary>
        /// Conditions
        /// </summary>
        private string conditions;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Purchase_C()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Purchase_C(DbDataReader dr)
        {
            this.hID = (int)dr["HID"];
            this.conditions = (string)dr["Conditions"];
        }
        #endregion

        #region Property
        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this.hID; }
            set
            {
                if (value != this.hID)
                {
                    this.hID = value;
                }
            }
        }
        /// <summary>
        /// Get,set Conditions
        /// </summary>
        public string Conditions
        {
            get { return this.conditions; }
            set
            {
                if (value != this.conditions)
                {
                    this.conditions = value;
                }
            }
        }
        #endregion
    }
}
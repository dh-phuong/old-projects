﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Sales_C Model
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class T_Sales_C
    {
        #region Variable
        /// <summary>
        /// HID
        /// </summary>
        private int _hID;
        /// <summary>
        /// Conditions
        /// </summary>
        private string _conditions;
        #endregion

        #region Property
        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this._hID; }
            set
            {
                if (value != this._hID)
                {
                    this._hID = value;
                }
            }
        }

        /// <summary>
        /// Get,set Conditions
        /// </summary>
        public string Conditions
        {
            get { return this._conditions; }
            set
            {
                if (value != this._conditions)
                {
                    this._conditions = value;
                }
            }
        }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Sales_C()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Sales_C(DbDataReader dr)
        {
            this._hID = (int)dr["HID"];
            this._conditions = (string)dr["Conditions"];
        }
        #endregion
    }
}
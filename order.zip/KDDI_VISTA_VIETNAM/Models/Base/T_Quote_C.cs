﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// T_Quote_C Model
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class T_Quote_C
    {
        #region Variant
        /// <summary>
        /// HID
        /// </summary>
        private int hID;

        /// <summary>
        /// Conditions
        /// </summary>
        private string conditions;
        
        #endregion

        #region Property

        /// <summary>
        /// HID
        /// </summary>
        public int HID
        {
            get { return hID; }
            set { hID = value; }
        }

        /// <summary>
        /// Conditions
        /// </summary>
        public string Conditions
        {
            get { return conditions; }
            set { conditions = value; }
        }
        
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor T_Quote_C
        /// </summary>
        public T_Quote_C()
            : base()
        {

        }

        /// <summary>
        /// Contructor T_Quote_C
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Quote_C(DbDataReader dr)
        {
            this.hID = (int)dr["HID"];
            this.conditions = (string)dr["Conditions"];           
        }

        #endregion
    }
}

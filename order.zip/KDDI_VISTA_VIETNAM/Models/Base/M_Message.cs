﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    [Serializable]
    public class M_Message
    {
        #region Const MessageID

        /// <summary>
        /// Please input {0}.
        /// </summary>
        public const string MSG_0001 = "0001";

        /// <summary>
        /// Please input {0}.
        /// </summary>
        public const string MSG_REQUIRE = "0001";

        /// <summary>
        /// {0} has already existed.
        /// </summary>
        public const string MSG_EXIST_CODE = "0002";

        /// <summary>
        /// Inputed {0} has not existed.
        /// </summary>
        public const string MSG_NOT_EXIST_CODE = "0003";

        /// <summary>
        /// An unexpected error has occurred. {0} data is failed.
        /// </summary>
        public const string MSG_UPDATE_FAILE = "0004";

        /// <summary>
        /// This data has been already updated by another user. Please press the Back button for trying again.
        /// </summary>
        public const string MSG_DATA_CHANGED = "0005";

        /// <summary>
        /// {0} is incorrect.
        /// </summary>
        public const string MSG_INCORRECT_FORMAT = "0006";

        /// <summary>
        /// {0} has already used in system. Can't delete.
        /// </summary>
        public const string MSG_EXIST_CANT_DELETE = "0008";

        /// <summary>
        /// Data will be created. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_INSERT = "0009";

        /// <summary>
        /// Data will be updated. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_UPDATE = "0010";

        /// <summary>
        /// Data will be deleted.  Are you OK?
        /// </summary>
        public const string MSG_QUESTION_DELETE = "0011";

        /// <summary>
        /// {0} is duplicated.
        /// </summary>
        public const string MSG_DUPLICATE = "0012";

        /// <summary>
        /// Old password is invalid.
        /// </summary>
        public const string MSG_PASS_INVALID = "0013";

        /// <summary>
        /// Confirm password is incorrect.
        /// </summary>
        public const string MSG_PASS_NOT_MATCH = "0014";

        /// <summary>
        /// Password must have at least 8 characters and contain both the alpha and the number.
        /// </summary>
        public const string MSG_PASSWORD_RULE = "0015";

        /// <summary>
        /// Please select {0}.
        /// </summary>
        public const string MSG_PLEASE_SELECT = "0016";

        /// <summary>
        /// {0} must be less than or equal to {1}.
        /// </summary>
        public const string MSG_LESS_THAN_EQUAL = "0017";

        /// <summary>
        /// Please input {0}. 【Row {1}】
        /// </summary>
        public const string MSG_REQUIRE_GRID = "0018";

        /// <summary>
        /// {0} is duplicated. 【Row {1}】
        /// </summary>
        public const string MSG_DUPLICATE_GRID = "0019";

        /// <summary>
        /// {0} must be less than or equal to {1}. 【Row {2}】
        /// </summary>
        public const string MSG_LESS_THAN_EQUAL_GRID = "0020";

        /// <summary>
        /// {0} is invalid. 【Row {1}】
        /// </summary>
        public const string MSG_INVALID_GRID = "0021";

        /// <summary>
        /// {0} must be greater than or equal to {1}. 【Row {2}】 
        /// </summary>
        public const string MSG_GREATER_THAN_EQUAL_GRID = "0022";

        /// <summary>
        /// {0} doesn't exist.
        /// </summary>
        public const string MSG_VALUE_NOT_EXIST = "0023";

        /// <summary>
        /// {0} was disabled. Please check the relevant master. 
        /// </summary>
        public const string MSG_CODE_DISABLE = "0024";

        /// <summary>
        /// Login information is incorrect.
        /// </summary>
        public const string MSG_LOGIN_INFO_INCORRECT = "0025";

        /// <summary>
        /// Can't create {0}. It made up to 9,999 in a month.
        /// </summary>
        public const string MSG_SIZE_MAX_NO = "0026";

        /// <summary>
        /// {0} must be greater than or equal to {1}.
        /// </summary>
        public const string MSG_GREATER_THAN_EQUAL = "0027";

        /// <summary>
        /// Inputed {0} has not existed. 【Row {1}】
        /// </summary>
        public const string MSG_NOT_EXIST_CODE_GRID = "0028";

        /// <summary>
        /// {0} must be less than {1}.
        /// </summary>
        public const string MSG_LESS_THAN = "0030";

        /// <summary>
        /// {0} must be greater than {1}. 【Row {2}】
        /// </summary>
        public const string MSG_GREATER_THAN_GRID = "0032";

        /// <summary>
        /// {0} must be less than {1}. 【Row {2}】
        /// </summary>
        public const string MSG_LESS_THAN_GRID = "0033";

        /// <summary>
        /// Can't create revision. Revision was up to 99 maximum.
        /// </summary>
        public const string MSG_OVERFLOWING_QUOTE = "0034";

        /// <summary>
        /// This Acceptance data will be remanded to Quotation. \n\nAre you sure?
        /// </summary>
        public const string MSG_QUESTION_REMAND_QUOTE = "0035";

        /// <summary>
        /// Data will be remanded to "Quotation" stage. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_DATA_ISSUED = "0036";

        /// <summary>
        /// Download {0}. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_OUTPUT_FILE = "0037";

        /// <summary>
        /// This data will be rose to "Sales" stage. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_MOVED_TO_SALES = "0038";

        /// <summary>
        /// {0} process has been completed. {1}<button class="btn btn-link" onclick="callRef('{2}');return false;">{3}</button>.
        /// </summary>
        public const string MSG_PROCESS_COMPLETED = "0039";

        /// <summary>
        /// Selected row will be deleted. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_DELETE_SELECTED_ROW = "0042";

        /// <summary>
        /// Please select row data.
        /// </summary>
        public const string MSG_SELECT_ROW_DATA = "0043";


        /// <summary>
        /// Please select file to upload
        /// </summary>
        public const string MSG_SELECT_FILE_UPLOAD = "0044";

        /// <summary>
        /// {0} disabled. 【Row {1}】
        /// </summary>
        public const string MSG_CODE_DISABLE_GRID = "0047";

        /// <summary>
        /// If you change the Currency, "Unit price"  "Subtotal"  "TAX"  will be cleared.  Are you OK?
        /// </summary>
        public const string MSG_CODE_CURRENCY_CHANGED = "0048";

        /// <summary>
        /// If you change the Method of Taxation, "TAX amount" will be changed. Are you OK?
        /// </summary>
        public const string MSG_CODE_METHOD_CHANGED = "0049";

        ///// <summary>
        ///// This data has been already processed P.O. </br>Can't continue this process.
        ///// </summary>
        //public const string MSG_ALREADY_PROCESSED_PO = "0050";

        /// <summary>
        /// Please input an excel file path.
        /// </summary>
        public const string MSG_INPUT_EXCEL = "0050";

        /// <summary>
        /// File extension must be in {0}.
        /// </summary>
        public const string MSG_CODE_FILE_EXTENSION = "0051";

        /// <summary>
        /// Please input an image file path.
        /// </summary>
        public const string MSG_INPUT_IMAGE = "0053";

        /// <summary>
        /// This data has been already updated by another user. Please try again.
        /// </summary>
        public const string MSG_CODE_DELETED_UPDATED = "0054";

        /// <summary>
        /// Can't create data. {0} is different.
        /// </summary>
        public const string MSG_SELECT_ROW_SAME_VALUE = "0055";

        /// <summary>
        ///  {0} data will be created. Are you OK ?
        /// </summary>
        public const string MSG_QUESTION_CREATE = "0059";

        /// <summary>
        /// Can't delete. Selected detail row has been created {0} data.【Row {1}】
        /// </summary>
        public const string MSG_CAN_NOT_DELETE_SELL_INVOICE_DELIVERY_GRID = "0061";

        /// <summary>
        /// Please Select {0}. 【Row {1}】
        /// </summary>
        public const string MSG_REQUIRE_SELECT_GRID = "0063";
      
        /// <summary>
        /// Size of {0} must be less than or equal to {1}.
        /// </summary>
        public const string MSG_SIZE_FILE_UPLOAD_LESS_THAN_EQUAL = "0068";

        /// <summary>
        /// Make a Copy. Are you OK?
        /// </summary>
        public const string MSG_MAKE_COPY = "0069";

        /// <summary>
        /// Make a Revision. Are you OK?
        /// </summary>
        public const string MSG_MAKE_REVISE = "0070";

        /// <summary>
        /// {0} must be different {1}.
        /// </summary>
        public const string MSG_MUST_BE_DIFFERENT = "0071";

        /// <summary>
        /// Make copy data from cost. Are you OK?
        /// </summary>
        public const string MSG_COPY_FROM_COST = "0072";

        /// <summary>
        /// Make copy data from sell. Are you OK?
        /// </summary>
        public const string MSG_COPY_FROM_SELL = "0073";

        /// <summary>
        /// {0} must be different {1}.【Row {2}】
        /// </summary>
        public const string MSG_MUST_BE_DIFFERENT_GRID = "0074";

        #endregion

        public string MessageID { get; set; }
        public string Message1 { get; set; }
        public string Message2 { get; set; }
        public string Type { get; set; }

        public M_Message(DbDataReader dr)
        {
            this.MessageID = (string)dr["MessageID"];
            this.Message1 = (string)dr["Message1"];
            this.Message2 = (string)dr["Message2"];
            this.Type = (string)dr["Type"];
        }
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class M_Category model
    /// </summary>
    [Serializable]
    public class M_Category : M_Base<M_Category>
    {
        #region Constant

        /// <summary>
        /// Max length of Category Code
        /// </summary>
        public const int CATEGORY_CODE_MAX_LENGTH = 4;

        /// <summary>
        /// Max length of Category Name
        /// </summary>
        public const int CATEGORY_NAME_MAX_LENGTH = 100;

        #endregion

        #region Variable      
        /// <summary>
        /// Category Name
        /// </summary>
        private string categoryName;

        #endregion

        #region Property
        /// <summary>
        /// Category Code
        /// </summary>
        public string CategoryCD { get; set; }

        /// <summary>
        /// Get or set Category Name
        /// </summary>
        public string CategoryName
        {
            get { return this.categoryName; }
            set
            {
                if (value != this.categoryName)
                {
                    this.categoryName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Category
        /// </summary>
        public M_Category()
            : base()
        { }

        /// <summary>
        /// Contructor M_Category with data reader
        /// </summary>
        /// <param name="dr"></param>
        public M_Category(DbDataReader dr)
            : base(dr)
        {
            this.CategoryCD = (string)dr["CategoryCD"];
            this.categoryName = (string)dr["CategoryName"];
        }

        #endregion
    }
}

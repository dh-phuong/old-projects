﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Purchase_D Model
    /// Create Date: 2014/09/03
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class T_Purchase_D
    {
        #region Constant

        /// <summary>
        /// Description Maxlength
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;

        /// <summary>
        /// Remark Maxlength
        /// </summary>
        public const int REMARK_MAX_LENGTH = 500;
        
        #endregion

        #region Variable
        /// <summary>
        /// InternalID
        /// </summary>
        private int internalID;
        /// <summary>
        /// HID
        /// </summary>
        private int hID;
        /// <summary>
        /// No
        /// </summary>
        private int no;
        /// <summary>
        /// SalesCostID
        /// </summary>
        private int salesCostID;
        /// <summary>
        /// ProductID
        /// </summary>
        private int productID;
        /// <summary>
        /// ProductCD
        /// </summary>
        private string productCD;
        /// <summary>
        /// ProductName
        /// </summary>
        private string productName;
        /// <summary>
        /// Description
        /// </summary>
        private string description;
        /// <summary>
        /// UnitPrice
        /// </summary>
        private decimal? unitPrice;
        /// <summary>
        /// VAT
        /// </summary>
        private decimal? vat;
        /// <summary>
        /// VATFlag
        /// </summary>
        private short vatType;
        /// <summary>
        /// VATRatio
        /// </summary>
        private decimal? vatRatio;
        /// <summary>
        /// Quantity
        /// </summary>
        private decimal? quantity;
        /// <summary>
        /// UnitID
        /// </summary>
        private int unitID;
        /// <summary>
        /// Total
        /// </summary>
        private decimal? total;
        /// <summary>
        /// DeliverQuantity
        /// </summary>
        private decimal? deliverQuantity;
        /// <summary>
        /// DeliverDate
        /// </summary>
        private DateTime deliverDate;
        /// <summary>
        /// Remark
        /// </summary>
        private string remark;

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Purchase_D()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Purchase_D(DbDataReader dr)
        {
            this.internalID = (int)dr["InternalID"];
            this.hID = (int)dr["HID"];
            this.no = (int)dr["No"];
            this.salesCostID = (int)dr["SalesCostID"];
            this.productID = (int)dr["ProductID"];
            this.productCD = string.Format("{0}", dr["ProductCD"]);
            this.productName = string.Format("{0}", dr["ProductName"]);
            this.description = string.Format("{0}", dr["Description"]);
            this.unitPrice = (decimal)dr["UnitPrice"];
            this.vat = (decimal)dr["Vat"];
            this.vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this.vatRatio = (decimal)dr["VatRatio"];
            this.quantity = (decimal)dr["Quantity"];
            this.unitID = (int)dr["UnitID"];
            this.total = (decimal)dr["Total"];
            this.deliverQuantity = (decimal)dr["DeliverQuantity"];
            this.deliverDate = (DateTime)dr["DeliverDate"];
            this.remark = string.Format("{0}", dr["Remark"]);
        }
        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// Get,set InternalID
        /// </summary>
        public int InternalID
        {
            get { return this.internalID; }
            set
            {
                if (value != this.internalID)
                {
                    this.internalID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this.hID; }
            set
            {
                if (value != this.hID)
                {
                    this.hID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set No
        /// </summary>
        public int No
        {
            get { return this.no; }
            set
            {
                if (value != this.no)
                {
                    this.no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesCostID
        /// </summary>
        public int SalesCostID
        {
            get { return this.salesCostID; }
            set
            {
                if (value != this.salesCostID)
                {
                    this.salesCostID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductID
        /// </summary>
        public int ProductID
        {
            get { return this.productID; }
            set
            {
                if (value != this.productID)
                {
                    this.productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductCD
        /// </summary>
        public string ProductCD
        {
            get { return this.productCD; }
            set
            {
                if (value != this.productCD)
                {
                    this.productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductName
        /// </summary>
        public string ProductName
        {
            get { return this.productName; }
            set
            {
                if (value != this.productName)
                {
                    this.productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Description
        /// </summary>
        public string Description
        {
            get { return this.description; }
            set
            {
                if (value != this.description)
                {
                    this.description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitPrice
        /// </summary>
        public decimal? UnitPrice
        {
            get { return this.unitPrice; }
            set
            {
                if (value != this.unitPrice)
                {
                    this.unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VAT
        /// </summary>
        public decimal? Vat
        {
            get { return this.vat; }
            set
            {
                if (value != this.vat)
                {
                    this.vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VATFlag
        /// </summary>
        public short VatType
        {
            get { return this.vatType; }
            set
            {
                if (value != this.vatType)
                {
                    this.vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VATRatio
        /// </summary>
        public decimal? VatRatio
        {
            get { return this.vatRatio; }
            set
            {
                if (value != this.vatRatio)
                {
                    this.vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Quantity
        /// </summary>
        public decimal? Quantity
        {
            get { return this.quantity; }
            set
            {
                if (value != this.quantity)
                {
                    this.quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitID
        /// </summary>
        public int UnitID
        {
            get { return this.unitID; }
            set
            {
                if (value != this.unitID)
                {
                    this.unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Total
        /// </summary>
        public decimal? Total
        {
            get { return this.total; }
            set
            {
                if (value != this.total)
                {
                    this.total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set DeliverQuantity
        /// </summary>
        public decimal? DeliverQuantity
        {
            get { return this.deliverQuantity; }
            set
            {
                if (value != this.deliverQuantity)
                {
                    this.deliverQuantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set DeliverDate
        /// </summary>
        public DateTime DeliverDate
        {
            get { return this.deliverDate; }
            set
            {
                if (value != this.deliverDate)
                {
                    this.deliverDate = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Remark
        /// </summary>
        public string Remark
        {
            get { return this.remark; }
            set
            {
                if (value != this.remark)
                {
                    this.remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        #endregion
    }
}
﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    ///  Class M_Condition Model
    /// </summary>
    [Serializable]
    public class M_Condition : M_Base<M_Condition>
    {
        #region Contanst
        /// <summary>
        /// Max length of ConditionCD
        /// </summary>
        public const int CONDITION_CODE_MAX_LENGTH = 2;

        /// <summary>
        /// Max length of ConditionName
        /// </summary>
        public const int CONDITION_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of Condition
        /// </summary>
        public const int CONDITION_MAX_LENGTH = 15000;

        /// <summary>
        /// Max length of ConditionCD to show
        /// </summary>
        public const int MAX_CONDITION_CODE_SHOW = 2;
        #endregion

        #region Fields
        /// <summary>
        /// Type
        /// </summary>
        private int type;

        /// <summary>
        /// Condition Name
        /// </summary>
        private string conditionName;

        /// <summary>
        /// Condition
        /// </summary>
        private string condition;
        #endregion

        #region Properties
        /// <summary>
        /// Get or set Type
        /// </summary>
        public int Type
        {
            get { return this.type; }
            set
            {
                if (value != this.type)
                {
                    this.type = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Condition CD
        /// </summary>
        public string ConditionCD { get; set; }

        /// <summary>
        /// Get or set Condition Name
        /// </summary>
        public string ConditionName
        {
            get { return this.conditionName; }
            set
            {
                if (value != this.conditionName)
                {
                    this.conditionName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Condition
        /// </summary>
        public string Condition
        {
            get { return this.condition; }
            set
            {
                if (value != this.condition)
                {
                    this.condition = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor M_Condition
        /// </summary>
        public M_Condition()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Condition
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Condition(DbDataReader dr)
            : base(dr)
        {
            this.type = (int)dr["Type"];
            this.ConditionCD = (string)dr["ConditionCD"];
            this.conditionName = (string)dr["ConditionName"];
            this.condition = (string)dr["Condition"];
        }
        #endregion
    }
}

﻿using System;
using System.Data.Common;
using System.Xml.Serialization;
using System.Web.Script.Serialization;

namespace OMS.Models
{
    /// <summary>
    /// Class M_Currency_D Model
    /// Create Date: 2014/07/24
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class M_Currency_D
    {
        #region Variable
        /// <summary>
        /// Delete flag
        /// </summary>
        private bool delFlg;
        /// <summary>
        /// HID
        /// </summary>
        private int hID;
        /// <summary>
        /// EffectDate
        /// </summary>
        private DateTime? effectDate;
        /// <summary>
        /// ExpireDate
        /// </summary>
        private DateTime? expireDate;
        /// <summary>
        /// ExchangeRate
        /// </summary>
        private decimal? exchangeRate;
        #endregion

        #region Constant
        /// <summary>
        /// Max length of Money code
        /// </summary>
        public const decimal EXCHANGE_RATE_MAX_VALUE = 999999.99M;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public M_Currency_D()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Currency_D(DbDataReader dr)
        {
            this.HID = (int)dr["HID"];
            this.EffectDate = (DateTime)dr["EffectDate"];
            this.ExpireDate = (DateTime)dr["ExpireDate"];
            this.ExchangeRate = (decimal)dr["ExchangeRate"];
        }
        #endregion

        #region Property
        /// <summary>
        /// Get,set DelFlag
        /// </summary>
        public bool DelFlag
        {
            get { return this.delFlg; }
            set { this.delFlg = value; }
        }

        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this.hID; }
            set { this.hID = value; }
        }

        [ScriptIgnore]
        public DateTime? EffectDate
        {
            get { return this.effectDate; }
            set { this.effectDate = value; }
        }

        /// <summary>
        /// Get,set ExpireDate
        /// </summary>
        [ScriptIgnore]
        public DateTime? ExpireDate
        {
            get { return this.expireDate; }
            set { this.expireDate = value; }
        }

        /// <summary>
        /// Get,set EffectDate
        /// </summary>
        [XmlElement]
        public string ProxyEffectDate
        {
            get
            {
                if (this.EffectDate.HasValue)
                {
                    return this.EffectDate.Value.ToString("D");
                }
                return null;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.EffectDate = DateTime.Parse(value);
                }
                else
                {
                    this.EffectDate = null;
                }
            }
        }

        /// <summary>
        /// Get,set ExpireDate
        /// </summary>
        [XmlElement]
        public string ProxyExpireDate
        {
            get
            {
                if (this.ExpireDate.HasValue)
                {
                    return this.ExpireDate.Value.ToString("D");
                }
                return null;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.ExpireDate = DateTime.Parse(value);
                }
                else
                {
                    this.ExpireDate = null;
                }
            }
        }

        /// <summary>
        /// Get,set ExchangeRate
        /// </summary>
        public decimal? ExchangeRate
        {
            get { return this.exchangeRate; }
            set { this.exchangeRate = value; }
        }
        #endregion

        #region Method
        /// <summary>
        /// Clone
        /// </summary>
        /// <returns></returns>
        public M_Currency_D Clone()
        {
            return (M_Currency_D)base.MemberwiseClone();
        }
        #endregion
    }
}
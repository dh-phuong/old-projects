﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace OMS.Models
{
    [Serializable]
    public class T_Payment
    {
        #region Variable

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;

        /// <summary>
        /// Delete flag
        /// </summary>
        private bool delFlg;

        /// <summary>
        /// PurchaseID
        /// </summary>
        private int purchaseID;

        /// <summary>
        /// No
        /// </summary>
        private int no;

        /// <summary>
        /// PaymentDate
        /// </summary>
        private DateTime? paymentDate;

        /// <summary>
        /// Amount
        /// </summary>
        private decimal? amount;

        /// <summary>
        /// PaymentMethod
        /// </summary>
        private short paymentMethod;

        /// <summary>
        /// Remark 1
        /// </summary>
        private string remark1;

        /// <summary>
        /// Remark 2
        /// </summary>
        private string remark2;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Payment()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Payment(DbDataReader dr)
        {
            this.purchaseID = (int)dr["PurchaseID"];
            this.no = (int)dr["No"];
            this.paymentDate = (DateTime)dr["PaymentDate"];
            this.amount = (decimal)dr["Amount"];
            this.paymentMethod = short.Parse(dr["PaymentMethod"].ToString());
            this.remark1 = dr["Remark1"].ToString();
            this.remark2 = dr["Remark2"].ToString();
        }
        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// Get,set DelFlag
        /// </summary>
        public bool DelFlag
        {
            get { return this.delFlg; }
            set { this.delFlg = value; }
        }

        /// <summary>
        /// Get,set ID
        /// </summary>
        public int PurchaseID
        {
            get { return this.purchaseID; }
            set
            {
                if (value != this.purchaseID)
                {
                    this.purchaseID = value;
                }
            }
        }

        /// <summary>
        /// Get,set No
        /// </summary>
        public int No
        {
            get { return this.no; }
            set
            {
                if (value != this.no)
                {
                    this.no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PaymentDate
        /// </summary>
        public DateTime? PaymentDate
        {
            get { return this.paymentDate; }
            set
            {
                if (value != this.paymentDate)
                {
                    this.paymentDate = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Amount
        /// </summary>
        public decimal? Amount
        {
            get { return this.amount; }
            set
            {
                if (value != this.amount)
                {
                    this.amount = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PaymentMethod
        /// </summary>
        public short PaymentMethod
        {
            get { return this.paymentMethod; }
            set
            {
                if (value != this.paymentMethod)
                {
                    this.paymentMethod = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Remark 1
        /// </summary>
        public string Remark1
        {
            get { return this.remark1; }
            set
            {
                if (value != this.remark1)
                {
                    this.remark1 = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Remark 2
        /// </summary>
        public string Remark2
        {
            get { return this.remark2; }
            set
            {
                if (value != this.remark2)
                {
                    this.remark2 = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Billing_D Model
    /// Create Author: ISV-Giam
    /// Create Date: 2014/12/16
    [Serializable]
    public class T_Billing_D
    {
        #region Variable
        /// <summary>
        /// HID
        /// </summary>
        private int _hid;
        /// <summary>
        /// No
        /// </summary>
        private int _no;
        /// <summary>
        /// SalesSellID
        /// </summary>
        private int _salesSellID;
        /// <summary>
        /// ProductID
        /// </summary>
        private int _productID;
        /// <summary>
        /// ProductCD
        /// </summary>
        private string _productCD;
        /// <summary>
        /// ProductName
        /// </summary>
        private string _productName;
        /// <summary>
        /// VATRatio
        /// </summary>
        private decimal _vatRatio;
        /// <summary>
        /// Description
        /// </summary>
        private string _description;
        /// <summary>
        /// UnitPrice
        /// </summary>
        private decimal _unitPrice;
        /// <summary>
        /// Quantity
        /// </summary>
        private decimal _quantity;
        /// <summary>
        /// UnitID
        /// </summary>
        private int _unitID;
        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;
        /// <summary>
        /// VAT
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// Get or set VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// remark
        /// </summary>
        private string _remark;

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Billing_D()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Billing_D(DbDataReader dr)
        {
            this.InternalID = (int)dr["InternalID"];
            this._hid = (int)dr["HID"];
            this._no = (int)dr["No"];
            this._salesSellID = (int)dr["SalesSellID"];
            this._productID = (int)dr["ProductID"];
            this._productCD = string.Format("{0}", dr["ProductCD"]);
            this._productName = string.Format("{0}", dr["ProductName"]);
            this._vatRatio = (decimal)dr["VatRatio"];
            this._description = string.Format("{0}", dr["Description"]);
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._quantity = (decimal)dr["Quantity"];
            this._unitID = (int)dr["UnitID"];
            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._remark = (string)dr["Remark"];
        }
        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this._hid; }
            set
            {
                if (value != this._hid)
                {
                    this._hid = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set No
        /// </summary>
        public int No
        {
            get { return this._no; }
            set
            {
                if (value != this._no)
                {
                    this._no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesSellID
        /// </summary>
        public int SalesSellID
        {
            get { return this._salesSellID; }
            set
            {
                if (value != this._salesSellID)
                {
                    this._salesSellID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductID
        /// </summary>
        public int ProductID
        {
            get { return this._productID; }
            set
            {
                if (value != this._productID)
                {
                    this._productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductCD
        /// </summary>
        public string ProductCD
        {
            get { return this._productCD; }
            set
            {
                if (value != this._productCD)
                {
                    this._productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ProductName
        /// </summary>
        public string ProductName
        {
            get { return this._productName; }
            set
            {
                if (value != this._productName)
                {
                    this._productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VATRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VatType
        /// </summary>
        public short VATType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        
        /// <summary>
        /// Get,set Description
        /// </summary>
        public string Description
        {
            get { return this._description; }
            set
            {
                if (value != this._description)
                {
                    this._description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitPrice
        /// </summary>
        public decimal UnitPrice
        {
            get { return this._unitPrice; }
            set
            {
                if (value != this._unitPrice)
                {
                    this._unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Quantity
        /// </summary>
        public decimal Quantity
        {
            get { return this._quantity; }
            set
            {
                if (value != this._quantity)
                {
                    this._quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set UnitID
        /// </summary>
        public int UnitID
        {
            get { return this._unitID; }
            set
            {
                if (value != this._unitID)
                {
                    this._unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set VAT
        /// </summary>
        public decimal Vat
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Remark
        /// </summary>
        public string Remark
        {
            get { return this._remark; }
            set
            {
                if (value != this._remark)
                {
                    this._remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    [Serializable]
    public class T_Delivery_Serial
    {
        #region Contanst

        /// <summary>
        /// Max length of SerialNo
        /// </summary>
        public const int SERIAL_NO_MAX_LENGTH = 50;

        #endregion Contanst

        #region Variable

        /// <summary>
        /// SerialNo
        /// </summary>
        private string _serialNo;

        /// <summary>
        /// The contract type
        /// </summary>
        private short _contractType;

        /// <summary>
        /// Terms
        /// </summary>
        private int _terms;

        /// <summary>
        /// TermUnit
        /// </summary>
        private int _termUnit;

        /// <summary>
        /// The start date
        /// </summary>
        private DateTime _startDate;

        /// <summary>
        /// The finish date
        /// </summary>
        private DateTime _finishDate;

        #endregion Variable

        #region Properties

        /// <summary>
        /// ShippingMID
        /// </summary>
        public int DeliveryDID { get; set; }

        /// <summary>
        /// GridID
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// SerialNo
        /// </summary>
        public string SerialNo
        {
            get { return _serialNo; }
            set
            {
                if (value != _serialNo)
                {
                    _serialNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets or sets the type of the contract.
        /// </summary>
        /// <value>
        /// The type of the contract.
        /// </value>
        public short ContractType
        {
            get { return _contractType; }
            set
            {
                if (value != _contractType)
                {
                    _contractType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets or sets the terms.
        /// </summary>
        /// <value>
        /// The terms.
        /// </value>
        public int Terms
        {
            get { return _terms; }
            set
            {
                if (value != _terms)
                {
                    _terms = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets or sets the term unit.
        /// </summary>
        /// <value>
        /// The term unit.
        /// </value>
        public int TermUnit
        {
            get { return _termUnit; }
            set
            {
                if (value != _termUnit)
                {
                    _termUnit = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets or sets the start date.
        /// </summary>
        /// <value>
        /// The start date.
        /// </value>
        public DateTime StartDate
        {
            get { return _startDate; }
            set
            {
                if (value != _startDate)
                {
                    _startDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets or sets the finish date.
        /// </summary>
        /// <value>
        /// The finish date.
        /// </value>
        public DateTime FinishDate
        {
            get { return _finishDate; }
            set
            {
                if (value != _finishDate)
                {
                    _finishDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Gets the status.
        /// </summary>
        /// <value>
        /// The status.
        /// </value>
        public DataStatus Status
        {
            get;
            private set;
        }

        #endregion Properties

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="T_Delivery_Serial"/> class.
        /// </summary>
        public T_Delivery_Serial()
        {
            this.DeliveryDID = 0;
            this.No = 0;
            this._serialNo = string.Empty;
            this._contractType = 0;
            this._terms = 0;
            this._termUnit = 0;
            this._startDate = DateTime.MinValue;
            this._finishDate = DateTime.MinValue;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="T_Delivery_Serial"/> class.
        /// </summary>
        /// <param name="dr">The dr.</param>
        public T_Delivery_Serial(DbDataReader dr)
        {
            this.DeliveryDID = (int)dr["DeliveryDID"];
            this.No = (int)dr["No"];
            this._serialNo = (string)dr["SerialNo"];
            this._contractType = (short)Convert.ChangeType(dr["ContractType"], this.ContractType.GetType());
            this._terms = (int)dr["Terms"];
            this._termUnit = (int)dr["TermUnit"];
            this._startDate = (DateTime)dr["StartDate"];
            this._finishDate = (DateTime)dr["FinishDate"];
        }

        #endregion Constructor
    }
}
﻿using System;
using System.Data.Common;
namespace OMS.Models
{
    [Serializable]
    public class T_Delivery_C
    {
         #region Constant

        /// <summary>
        /// Conditions Maxlength
        /// </summary>
        public const int SHIPING_CONDITION_MAX_LENGTH = 3000;
        
        #endregion

        #region Variant

        /// <summary>
        /// ID
        /// </summary>
        private int _hid;

        /// <summary>
        /// Conditions
        /// </summary>
        private string _conditions;

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;

        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// ID
        /// </summary>
        public int HID
        {
            get { return this._hid; }
            set
            {
                if (value != this._hid)
                {
                    this._hid = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Conditions
        /// </summary>
        public string Conditions
        {
            get { return this._conditions; }
            set
            {
                if (value != this._conditions)
                {
                    this._conditions = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor T_Shipping_C
        /// </summary>
        public T_Delivery_C()
            : base()
        {

        }

        /// <summary>
        /// Contructor T_Shipping_C
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Delivery_C(DbDataReader dr)
        {
            this._hid = (int)dr["HID"];
            this._conditions = (string)dr["Conditions"];           
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    [Serializable]
    public class T_Delivery_D
    {
        #region Constant

        /// <summary>
        /// Description Maxlength
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;

        /// <summary>
        /// Remark Maxlength
        /// </summary>
        public const int REMARK_MAX_LENGTH = 500;

        #endregion

        #region Variable

        /// <summary>
        /// InternalID
        /// </summary>
        private int _internalID;

        /// <summary>
        /// HeaderID
        /// </summary>
        private int _hID;

        /// <summary>
        /// No
        /// </summary>
        private int _no;

        /// <summary>
        /// SalesSellID
        /// </summary>
        private int _salesSellID;

        /// <summary>
        /// ProductID
        /// </summary>
        private int _productID;

        /// <summary>
        /// ProductCD
        /// </summary>
        private string _productCD;

        /// <summary>
        /// ProductName
        /// </summary>
        private string _productName;

        /// <summary>
        /// VATFlag
        /// </summary>
        private short _vatType;

        /// <summary>
        /// VATRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// Description
        /// </summary>
        private string _description;

        /// <summary>
        /// DeliveryQuantity
        /// </summary>
        private decimal _deliveryQuantity;

        /// <summary>
        /// EstDeriverDate
        /// </summary>
        private DateTime _deliveryDate;

        /// <summary>
        /// UnitPrice
        /// </summary>
        private decimal _unitPrice;

        /// <summary>
        /// Quantity
        /// </summary>
        private decimal _quantity;

        /// <summary>
        /// UnitID
        /// </summary>
        private int _unitID;

        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// VAT
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// Remark
        /// </summary>
        private string _remark;


        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;

        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// InternalID
        /// </summary>
        public int InternalID
        {
            get { return this._internalID; }
            set
            {
                if (value != this._internalID)
                {
                    this._internalID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// HeaderID
        /// </summary>
        public int HID
        {
            get { return this._hID; }
            set
            {
                if (value != this._hID)
                {
                    this._hID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// No
        /// </summary>
        public int No
        {
            get { return this._no; }
            set
            {
                if (value != this._no)
                {
                    this._no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// salesSellID
        /// </summary>
        public int SalesSellID
        {
            get { return this._salesSellID; }
            set
            {
                if (value != this._salesSellID)
                {
                    this._salesSellID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ProductID
        /// </summary>
        public int ProductID
        {
            get { return _productID; }
            set
            {
                if (value != _productID)
                {
                    this._productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD
        {
            get { return this._productCD; }
            set
            {
                if (value != this._productCD)
                {
                    this._productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ProductName
        /// </summary>
        public string ProductName
        {
            get { return this._productName; }
            set
            {
                if (value != this._productName)
                {
                    this._productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VATFlag
        /// </summary>
        public short VATType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VATRatio
        /// </summary>
        public decimal VATRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Description
        /// </summary>
        public string Description
        {
            get { return this._description; }
            set
            {
                if (value != this._description)
                {
                    this._description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// EstDeriverDate
        /// </summary>
        public DateTime DeliveryDate
        {
            get { return this._deliveryDate; }
            set
            {
                if (value != this._deliveryDate)
                {
                    this._deliveryDate = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitPrice
        /// </summary>
        public decimal UnitPrice
        {
            get { return this._unitPrice; }
            set
            {
                if (value != this._unitPrice)
                {
                    this._unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DeliveryQuantity
        /// </summary>
        public decimal DeliveryQuantity
        {
            get { return this._deliveryQuantity; }
            set
            {
                if (value != this._deliveryQuantity)
                {
                    this._deliveryQuantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity
        {
            get { return this._quantity; }
            set
            {
                if (value != this._quantity)
                {
                    this._quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// UnitID
        /// </summary>
        public int UnitID
        {
            get { return this._unitID; }
            set
            {
                if (value != this._unitID)
                {
                    this._unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VAT
        /// </summary>
        public decimal VAT
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Remark
        /// </summary>
        public string Remark
        {
            get { return this._remark; }
            set
            {
                if (value != this._remark)
                {
                    this._remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor T_Shipping_D
        /// </summary>
        public T_Delivery_D()
            : base()
        {
            this._internalID = 0;
            this._hID = 0;
            this._no = 0;
            this._salesSellID = 0;
            this._productID = 0;
            this._productCD = string.Empty;
            this._productName = string.Empty;
            this._vatType = 0;
            this._vatRatio = 0;
            this._description = string.Empty;
            this._deliveryDate = DateTime.MinValue;
            this._deliveryQuantity = 0;
            this._unitPrice = 0;
            this._quantity = 0;
            this._unitID = 0;
            this._total = 0;
            this._vat = 0;
            this._remark = string.Empty;
        }

        /// <summary>
        /// Contructor T_Shipping_D
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Delivery_D(DbDataReader dr)
        {
            this._internalID = (int)dr["InternalID"];
            this._hID = (int)dr["HID"];
            this._no = (int)dr["No"];
            this._salesSellID = (int)dr["SalesSellID"];
            this._productID = (int)dr["ProductID"];
            this._productCD = (string)dr["ProductCD"];
            this._productName = (string)dr["ProductName"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._vatRatio = (decimal)dr["VatRatio"];
            this._description = (string)dr["Description"];
            this._deliveryDate = (DateTime)dr["DeliveryDate"];
            this._deliveryQuantity = (decimal)dr["DeliveryQuantity"];
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._quantity = (decimal)dr["Quantity"];
            this._unitID = (int)dr["UnitID"];
            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._remark = (string)dr["Remark"];
        }

        #endregion
    }
}

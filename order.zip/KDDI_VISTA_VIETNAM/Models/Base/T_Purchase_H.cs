﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// T_Purchase_H model
    /// </summary>
    [Serializable]
    public class T_Purchase_H : M_Base<T_Purchase_H>
    {
        #region Contanst

        /// <summary>
        /// Max length of PurchaseNo
        /// </summary>
        public const int PURCHASE_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of ProjectName
        /// </summary>
        public const int PROJECT_NAME_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of Memo
        /// </summary>
        public const int MEMO_MAX_LENGTH = 150;

        #endregion

        #region Variable

        /// <summary>
        /// PurchaseNo
        /// </summary>
        public string PurchaseNo { get; set; }

        /// <summary>
        /// QuoteNo
        /// </summary>
        private string _quoteNo;

        /// <summary>
        /// SalesNo
        /// </summary>
        private string _salesNo;

        /// <summary>
        /// PrintFlag
        /// </summary>
        private short _issuedFlag;

        /// <summary>
        /// DeleteFlag
        /// </summary>
        private short _deleteFlag;

        /// <summary>
        /// FinishFlag
        /// </summary>
        private short _finishFlag;

        /// <summary>
        /// CurrencyID
        /// </summary>
        private int _currencyID;

        /// <summary>
        /// PurchaseDate
        /// </summary>
        private DateTime _purchaseDate;

        ///// <summary>
        ///// DeliveredDate
        ///// </summary>
        //private DateTime _deliveredDate;

        /// <summary>
        /// ExpiryDate
        /// </summary>
        private DateTime _expiryDate;

        /// <summary>
        /// PaymentDate
        /// </summary>
        private DateTime _paymentDate;

        /// <summary>
        /// SubjectName
        /// </summary>
        private string _subjectName;

        /// <summary>
        /// PreparedCD
        /// </summary>
        private string _preparedCD;

        /// <summary>
        /// PreparedName
        /// </summary>
        private string _preparedName;

        /// <summary>
        /// ApprovedCD
        /// </summary>
        private string _approvedCD;

        /// <summary>
        /// ApprovedName
        /// </summary>
        private string _approvedName;

        /// <summary>
        /// VendorCD
        /// </summary>
        private string _vendorCD;

        /// <summary>
        /// VendorName
        /// </summary>
        private string _vendorName;

        /// <summary>
        /// VendorAddress1
        /// </summary>
        private string _vendorAddress1;

        /// <summary>
        /// VendorAddress2
        /// </summary>
        private string _vendorAddress2;

        /// <summary>
        /// VendorAddress3
        /// </summary>
        private string _vendorAddress3;

        /// <summary>
        /// Tel
        /// </summary>
        private string _tel;

        /// <summary>
        /// Fax
        /// </summary>
        private string _fax;

        /// <summary>
        /// ContactPerson
        /// </summary>
        private string _contactPerson;

        ///// <summary>
        ///// EstPaymentDate
        ///// </summary>
        //private DateTime _estPaymentDate;

        ///// <summary>
        ///// PaymentDate
        ///// </summary>
        //private DateTime _paymentDate;

        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// GrandTotal
        /// </summary>
        private decimal _grandTotal;

        /// <summary>
        /// Confirmed
        /// </summary>
        private string confirmed;

        /// <summary>
        /// Position
        /// </summary>
        private string position;

        /// <summary>
        /// MethodVat
        /// </summary>
        private short _methodVat;

        /// <summary>
        /// VAT
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// Memo
        /// </summary>
        private string _memo;

        /// <summary>
        /// IssuedDate
        /// </summary>
        private DateTime _issuedDate;

        /// <summary>
        /// IssuedUID
        /// </summary>
        private int _issuedUID;

        #endregion

        #region Property

        /// <summary>
        /// QuoteNo
        /// </summary>
        public string QuoteNo
        {
            get { return _quoteNo; }
            set
            {
                if (value != _quoteNo)
                {
                    _quoteNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SalesNo
        /// </summary>
        public string SalesNo
        {
            get { return _salesNo; }
            set
            {
                if (value != _salesNo)
                {
                    _salesNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PrintFlag
        /// </summary>
        public short IssuedFlag
        {
            get { return this._issuedFlag; }
            set
            {
                if (value != this._issuedFlag)
                {
                    this._issuedFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return _deleteFlag; }
            set
            {
                if (value != _deleteFlag)
                {
                    _deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public short FinishFlag
        {
            get { return _finishFlag; }
            set
            {
                if (value != _finishFlag)
                {
                    _finishFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyID
        /// </summary>
        public int CurrencyID
        {
            get { return _currencyID; }
            set
            {
                if (value != _currencyID)
                {
                    _currencyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PurchaseDate
        /// </summary>
        public DateTime PurchaseDate
        {
            get { return _purchaseDate; }
            set
            {
                if (value != _purchaseDate)
                {
                    _purchaseDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        ///// <summary>
        ///// DeliveredDate
        ///// </summary>
        //public DateTime DeliveredDate
        //{
        //    get { return _deliveredDate; }
        //    set
        //    {
        //        if (value != _deliveredDate)
        //        {
        //            _deliveredDate = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}

        /// <summary>
        /// ExpiryDate
        /// </summary>
        public DateTime ExpiryDate
        {
            get { return _expiryDate; }
            set
            {
                if (value != _expiryDate)
                {
                    _expiryDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PaymentDate
        /// </summary>
        public DateTime PaymentDate
        {
            get { return _paymentDate; }
            set
            {
                if (value != _paymentDate)
                {
                    _paymentDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName
        {
            get { return _subjectName; }
            set
            {
                if (value != _subjectName)
                {
                    _subjectName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedCD
        /// </summary>
        public string PreparedCD
        {
            get { return _preparedCD; }
            set
            {
                if (value != _preparedCD)
                {
                    _preparedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedName
        /// </summary>
        public string PreparedName
        {
            get { return _preparedName; }
            set
            {
                if (value != _preparedName)
                {
                    _preparedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedCD
        /// </summary>
        public string ApprovedCD
        {
            get { return _approvedCD; }
            set
            {
                if (value != _approvedCD)
                {
                    _approvedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedName
        /// </summary>
        public string ApprovedName
        {
            get { return _approvedName; }
            set
            {
                if (value != _approvedName)
                {
                    _approvedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorCD
        /// </summary>
        public string VendorCD
        {
            get { return _vendorCD; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_Vendor.VENDOR_CODE_MAX_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(_vendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);

                if (val1 != val2)
                {
                    _vendorCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorName
        /// </summary>
        public string VendorName
        {
            get { return _vendorName; }
            set
            {
                if (value != _vendorName)
                {
                    _vendorName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorAddress1
        /// </summary>
        public string VendorAddress1
        {
            get { return _vendorAddress1; }
            set
            {
                if (value != _vendorAddress1)
                {
                    _vendorAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorAddress2
        /// </summary>
        public string VendorAddress2
        {
            get { return _vendorAddress2; }
            set
            {
                if (value != _vendorAddress2)
                {
                    _vendorAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorAddress3
        /// </summary>
        public string VendorAddress3
        {
            get { return _vendorAddress3; }
            set
            {
                if (value != _vendorAddress3)
                {
                    _vendorAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Tel
        /// </summary>
        public string Tel
        {
            get { return _tel; }
            set
            {
                if (value != _tel)
                {
                    _tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Fax
        /// </summary>
        public string Fax
        {
            get { return _fax; }
            set
            {
                if (value != _fax)
                {
                    _fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return _contactPerson; }
            set
            {
                if (value != _contactPerson)
                {
                    _contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        ///// <summary>
        ///// EstPaymentDate
        ///// </summary>
        //public DateTime EstPaymentDate
        //{
        //    get { return _estPaymentDate; }
        //    set
        //    {
        //        if (value != _estPaymentDate)
        //        {
        //            _estPaymentDate = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}

        ///// <summary>
        ///// PaymentDate
        ///// </summary>
        //public DateTime PaymentDate
        //{
        //    get { return _paymentDate; }
        //    set
        //    {
        //        if (value != _paymentDate)
        //        {
        //            _paymentDate = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return _total; }
            set
            {
                if (value != _total)
                {
                    _total = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// GrandTotal
        /// </summary>
        public decimal GrandTotal
        {
            get { return _grandTotal; }
            set
            {
                if (value != _grandTotal)
                {
                    _grandTotal = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Confirmed
        /// </summary>
        public string Confirmed
        {
            get { return confirmed; }
            set
            {
                if (value != confirmed)
                {
                    confirmed = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Position
        /// </summary>
        public string Position
        {
            get { return position; }
            set
            {
                if (value != position)
                {
                    position = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// MethodVat
        /// </summary>
        public short MethodVat
        {
            get { return _methodVat; }
            set
            {
                if (value != _methodVat)
                {
                    _methodVat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VAT
        /// </summary>
        public decimal Vat
        {
            get { return _vat; }
            set
            {
                if (value != _vat)
                {
                    _vat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return _vatRatio; }
            set
            {
                if (value != _vatRatio)
                {
                    _vatRatio = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType
        {
            get { return _vatType; }
            set
            {
                if (value != _vatType)
                {
                    _vatType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Memo
        /// </summary>
        public string Memo
        {
            get { return _memo; }
            set
            {
                if (value != _memo)
                {
                    _memo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedDate
        /// </summary>
        public DateTime IssuedDate
        {
            get { return _issuedDate; }
            set
            {
                if (value != _issuedDate)
                {
                    _issuedDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedUID
        /// </summary>
        public int IssuedUID
        {
            get { return _issuedUID; }
            set
            {
                if (value != _issuedUID)
                {
                    _issuedUID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor T_Purchase_H
        /// </summary>
        public T_Purchase_H()
            : base()
        {
            this.PurchaseNo = string.Empty;
            this._quoteNo = string.Empty;
            this._salesNo = string.Empty;
            this._issuedFlag = 0;
            this._deleteFlag = 0;
            this._finishFlag = 0;
            this._currencyID = 0;
            this._purchaseDate = DateTime.MinValue;
            //this._deliveredDate = DateTime.MinValue;
            this._expiryDate = DateTime.MinValue;
            this._paymentDate = DateTime.MinValue;
            this._subjectName = string.Empty;
            this._preparedCD = string.Empty;
            this._preparedName = string.Empty;
            this._approvedCD = string.Empty;
            this._approvedName = string.Empty;
            this._vendorCD = string.Empty;
            this._vendorName = string.Empty;
            this._vendorAddress1 = string.Empty;
            this._vendorAddress2 = string.Empty;
            this._vendorAddress3 = string.Empty;
            this._tel = string.Empty;
            this._fax = string.Empty;
            this._contactPerson = string.Empty;
            //this._estPaymentDate = DateTime.MinValue;
            //this._paymentDate = DateTime.MinValue;
            this._total = 0;
            this._grandTotal = 0;
            this._methodVat = 0;
            this._vat = 0;
            this._vatRatio = 0;
            this._vatType = 0;
            this._memo = string.Empty;
            this._issuedDate = DateTime.MinValue;
            this._issuedUID = 0;
            this.confirmed = string.Empty;
            this.position = string.Empty;
        }

        /// <summary>
        /// Contructor T_Purchase_H
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Purchase_H(DbDataReader dr)
            : base(dr)
        {
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this._quoteNo = (string)dr["QuoteNo"];
            this._salesNo = (string)dr["SalesNo"];
            this._issuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"])); ;
            this._deleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this._finishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            this._currencyID = int.Parse(string.Format("{0}", dr["CurrencyID"]));
            this._purchaseDate = (DateTime)dr["PurchaseDate"];
            //this._deliveredDate = (DateTime)dr["DeliveredDate"];
            this._expiryDate = (DateTime)dr["ExpiryDate"];
            this._paymentDate = (DateTime)dr["PaymentDate"];
            this._subjectName = (string)dr["SubjectName"];
            this._preparedCD = (string)dr["PreparedCD"];
            this._preparedName = (string)dr["PreparedName"];
            this._approvedCD = (string)dr["ApprovedCD"];
            this._approvedName = (string)dr["ApprovedName"];
            this._vendorCD = (string)dr["VendorCD"];
            this._vendorName = (string)dr["VendorName"];
            this._vendorAddress1 = (string)dr["VendorAddress1"];
            this._vendorAddress2 = (string)dr["VendorAddress2"];
            this._vendorAddress3 = (string)dr["VendorAddress3"];
            this._tel = (string)dr["Tel"];
            this._fax = (string)dr["Fax"];
            this._contactPerson = (string)dr["ContactPerson"];
            //this._estPaymentDate = (DateTime)dr["EstPaymentDate"];
            //this._paymentDate = (DateTime)dr["PaymentDate"];
            this._total = (decimal)dr["Total"];
            this._grandTotal = (decimal)dr["GrandTotal"];
            this._methodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            this._vat = (decimal)dr["Vat"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._memo = (string)dr["Memo"];
            this._issuedDate = (DateTime)dr["IssuedDate"];
            this._issuedUID = int.Parse(string.Format("{0}", dr["IssuedUID"]));
            this.position = (string)dr["Position"];
            this.confirmed = (string)dr["Confirmed"];
        }

        #endregion
    }
}

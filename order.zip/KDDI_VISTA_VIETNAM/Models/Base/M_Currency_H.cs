﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class M_Currency_H Model
    /// Create Date: 2014/07/24
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class M_Currency_H : M_Base<M_Currency_H>
    {
        #region Variable
        /// <summary>
        /// MoneyCode
        /// </summary>
        private string moneyCode;
        /// <summary>
        /// MoneyNameUS
        /// </summary>
        private string moneyNameUS;
        /// <summary>
        /// MoneyNameVN
        /// </summary>
        private string moneyNameVN;
        /// <summary>
        /// TaxName
        /// </summary>
        private string taxName;
        /// <summary>
        /// DecimalType
        /// </summary>
        private int decimalType;
        /// <summary>
        /// DecimalNameUS
        /// </summary>
        private string decimalNameUS;
        /// <summary>
        /// DecimalNameVN
        /// </summary>
        private string decimalNameVN;
        /// <summary>
        /// OrderIndex
        /// </summary>
        private int orderIndex;
        #endregion

        #region Constant
        /// <summary>
        /// Max length of Money code
        /// </summary>
        public const int MONEY_CODE_MAX_LENGTH = 5;
        /// <summary>
        /// Max length of Money name
        /// </summary>
        public const int MONEY_NAME_MAX_LENGTH = 30;
        /// <summary>
        /// Max length of Tax name
        /// </summary>
        public const int TAX_NAME_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of Decimal name
        /// </summary>
        public const int DECIMAL_NAME_MAX_LENGTH = 30;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public M_Currency_H()
            : base()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Currency_H(DbDataReader dr)
            : base(dr)
        {
            this.moneyCode = (string)dr["MoneyCode"];
            this.moneyNameUS = (string)dr["MoneyNameUS"];
            this.moneyNameVN = (string)dr["MoneyNameVN"];
            this.taxName = (string)dr["TaxName"];
            this.decimalType = int.Parse(dr["DecimalType"].ToString());
            this.decimalNameUS = (string)dr["DecimalNameUS"];
            this.decimalNameVN = (string)dr["DecimalNameVN"];
            this.orderIndex = (int)dr["OrderIndex"];
        }
        #endregion

        #region Property
        /// <summary>
        /// Get,set MoneyCode
        /// </summary>
        public string MoneyCode
        {
            get { return this.moneyCode; }
            set
            {
                if (value != this.moneyCode)
                {
                    this.moneyCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set MoneyNameUS
        /// </summary>
        public string MoneyNameUS
        {
            get { return this.moneyNameUS; }
            set
            {
                if (value != this.moneyNameUS)
                {
                    this.moneyNameUS = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set MoneyNameVN
        /// </summary>
        public string MoneyNameVN
        {
            get { return this.moneyNameVN; }
            set
            {
                if (value != this.moneyNameVN)
                {
                    this.moneyNameVN = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set TaxName
        /// </summary>
        public string TaxName
        {
            get { return this.taxName; }
            set
            {
                if (value != this.taxName)
                {
                    this.taxName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set DecimalType
        /// </summary>
        public int DecimalType
        {
            get { return this.decimalType; }
            set
            {
                if (value != this.decimalType)
                {
                    this.decimalType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set DecimalNameUS
        /// </summary>
        public string DecimalNameUS
        {
            get { return this.decimalNameUS; }
            set
            {
                if (value != this.decimalNameUS)
                {
                    this.decimalNameUS = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set DecimalNameVN
        /// </summary>
        public string DecimalNameVN
        {
            get { return this.decimalNameVN; }
            set
            {
                if (value != this.decimalNameVN)
                {
                    this.decimalNameVN = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set OrderIndex
        /// </summary>
        public int OrderIndex
        {
            get { return this.orderIndex; }
            set
            {
                if (value != this.orderIndex)
                {
                    this.orderIndex = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion
    }
}
﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    ///  T_Quotation_D_Cost Model
    ///  ISV-TRUC
    /// </summary>
    [Serializable]
    public class T_Quote_D_Cost
    {
        #region Contanst
        /// <summary>
        /// Max length of Description
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;
        #endregion

        #region Variable
        /// <summary>
        /// Header ID
        /// </summary>
        private int _hID;

        /// <summary>
        /// SellNo
        /// </summary>
        private int _sellNo;

        private int _originalSellNo;

        /// <summary>
        /// No
        /// </summary>
        private int _no;

        /// <summary>
        /// Product ID
        /// </summary>
        private int _productID;

        /// <summary>
        /// Product CD
        /// </summary>
        private string _productCD;

        /// <summary>
        /// Product Name
        /// </summary>
        private string _productName;

        /// <summary>
        /// Description
        /// </summary>
        private string _description;

        /// <summary>
        /// Unit ID
        /// </summary>
        private int _unitID;

        /// <summary>
        /// CurrencyID
        /// </summary>
        private int _currencyID;

        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// Remark
        /// </summary>
        private string _remark;

        /// <summary>
        /// PurchaseFlag
        /// </summary>
        private short _purchaseFlag;

        /// <summary>
        /// VendorCD
        /// </summary>
        private string _vendorCD;

        /// <summary>
        /// VendorName
        /// </summary>
        private string _vendorName;

        /// <summary>
        /// Unit Price
        /// </summary>
        private decimal _unitPrice;

        /// <summary>
        /// Quantity
        /// </summary>
        private decimal _quantity;

        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// Vat
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        #endregion

        #region Property

        /// <summary>
        /// Header ID
        /// </summary>
        public int HID
        {
            get { return _hID; }
            set { _hID = value; }
        }

        /// <summary>
        /// SellNo
        /// </summary>
        public int SellNo
        {
            get { return _sellNo; }
            set { _sellNo = value; }
        }

        /// <summary>
        /// No
        /// </summary>
        public int No
        {
            get { return _no; }
            set { _no = value; }
        }

        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID
        {
            get { return _productID; }
            set
            {
                if (value != _productID)
                {
                    _productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product CD
        /// </summary>
        public string ProductCD
        {
            get { return _productCD; }
            set
            {
                if (value != _productCD)
                {
                    _productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName
        {
            get { return _productName; }
            set
            {
                if (value != _productName)
                {
                    _productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Description
        /// </summary>
        public string Description
        {
            get { return _description; }
            set
            {
                if (value != _description)
                {
                    _description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Remark
        /// </summary>
        public string Remark
        {
            get { return _remark; }
            set
            {
                if (value != _remark)
                {
                    _remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Unit ID
        /// </summary>
        public int UnitID
        {
            get { return _unitID; }
            set
            {
                if (value != _unitID)
                {
                    _unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyID
        /// </summary>
        public int CurrencyID
        {
            get { return _currencyID; }
            set
            {
                if (value != _currencyID)
                {
                    _currencyID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType
        {
            get { return _vatType; }
            set
            {
                if (value != _vatType)
                {
                    _vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// vatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return _vatRatio; }
            set
            {
                if (value != _vatRatio)
                {
                    _vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PurchaseFlag
        /// </summary>
        public short PurchaseFlag
        {
            get { return _purchaseFlag; }
            set
            {
                if (value != _purchaseFlag)
                {
                    _purchaseFlag = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorCD
        /// </summary>
        public string VendorCD
        {
            get { return _vendorCD; }
            set
            {
                if (value != _vendorCD)
                {
                    _vendorCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VendorName
        /// </summary>
        public string VendorName
        {
            get { return _vendorName; }
            set
            {
                if (value != _vendorName)
                {
                    _vendorName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Unit Price
        /// </summary>
        public decimal UnitPrice
        {
            get { return _unitPrice; }
            set
            {
                if (value != _unitPrice)
                {
                    _unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity
        {
            get { return _quantity; }
            set
            {
                if (value != _quantity)
                {
                    _quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return _total; }
            set
            {
                if (value != _total)
                {
                    _total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Vat
        /// </summary>
        public decimal Vat
        {
            get { return _vat; }
            set
            {
                if (value != _vat)
                {
                    _vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }
        /// <summary>
        /// Original SellNo
        /// </summary>
        public int OriginalSellNo
        {
            get
            {
                return _originalSellNo;
            }
        }

        /// <summary>
        /// Deleted Flg
        /// </summary>
        public bool DeletedFlg { get; set; }
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor T_Quotation_D_Cost
        /// </summary>
        public T_Quote_D_Cost()
            : base()
        {
            this._productID = Constant.DEFAULT_ID;
            this._unitID = Constant.DEFAULT_ID;
            this._currencyID = Constant.DEFAULT_ID;
            this._hID = 0;
            this._sellNo = 0;
            this._no = 0;

            this._productCD = string.Empty;
            this._productName = string.Empty;
            this._description = string.Empty;


            this._vatType = 0;
            this._vatRatio = 0;
            this._purchaseFlag = 0;
            this._vendorCD = string.Empty;
            this._vendorName = string.Empty;
            this._unitPrice = 0;
            this._quantity = 0;
            this._total = 0;
            this._vat = 0;
            this._status = DataStatus.None;
            this.DeletedFlg = false;
        }

        /// <summary>
        /// Contructor T_Quotation_D_Cost
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Quote_D_Cost(DbDataReader dr)
        {
            this._hID = (int)dr["HID"];
            this._sellNo = (int)dr["SellNo"];
            this._originalSellNo = this._sellNo;
            this._no = (int)dr["No"];
            this._productID = (int)dr["ProductID"];
            this._productCD = (string)dr["ProductCD"];
            this._productName = (string)dr["ProductName"];
            this._description = (string)dr["Description"];
            this._unitID = (int)dr["UnitID"];
            this._currencyID = (int)dr["CurrencyID"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._vatRatio = (decimal)dr["VATRatio"];
            this._purchaseFlag = short.Parse(string.Format("{0}", dr["PurchaseFlag"]));
            this._vendorCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this._vendorName = (string)dr["VendorName"];
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._quantity = (decimal)dr["Quantity"];
            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._status = DataStatus.None;
            this.DeletedFlg = false;
        }

        #endregion


        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
            if (string.IsNullOrEmpty(this.ProductCD) &&
                string.IsNullOrEmpty(this.ProductName) &&
                string.IsNullOrEmpty(this.Description) &&
                this._unitPrice == 0 &&
                this._quantity == 0 &&
                this._unitID == Constant.DEFAULT_ID &&
                this._total == 0 &&
                this._vat == 0
                )
            {
                return true;
            }

            return false;
        }
    }
}

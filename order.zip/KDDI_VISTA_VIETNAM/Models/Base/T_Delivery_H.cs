﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    [Serializable]
    public class T_Delivery_H : M_Base<T_Delivery_H>
    {
        #region Contanst

        /// <summary>
        /// Max length of Shipping
        /// </summary>
        public const int DELIVERY_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of InchargeCD
        /// </summary>
        public const int INCHARGE_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of InchargeName
        /// </summary>
        public const int INCHARGE_NAME_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ApprovedCD
        /// </summary>
        public const int APPROVED_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of ApprovedName
        /// </summary>
        public const int APPROVED_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of DeliveryCD
        /// </summary>
        public const int DELIVERY_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of Delivery Name
        /// </summary>
        public const int DELIVERY_NAME_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ProjectName
        /// </summary>
        public const int SUBJECT_NAME_MAX_LENGTH = 150;
        /// <summary>
        /// Max length of Tel
        /// </summary>
        public const int TEL_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of Fax
        /// </summary>
        public const int FAX_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ContactPerson
        /// </summary>
        public const int CONTACT_PERSON_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of DeliveryPlace
        /// </summary>
        public const int DELIVERY_PLACE_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of Memo
        /// </summary>
        public const int MEMO_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of Contract No
        /// </summary>
        public const int CONTRACT_NO_MAX_LENGTH = 30;

        /// <summary>
        /// Max length of Acceptance No
        /// </summary>
        public const int ACCEPTANCE_NO_MAX_LENGTH = 30;

        #endregion

        #region Variant

        /// <summary>
        /// ShippingNo
        /// </summary>
        public string DeliveryNo { get; set; }
        /// <summary>
        /// QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }
        /// <summary>
        /// SalesNo
        /// </summary>
        public string SalesNo { get; set; }
        /// <summary>
        /// DeliveryPlace
        /// </summary>
        private string _deliveryPlace;

        /// <summary>
        /// PrintFlag
        /// </summary>
        private short _issuedFlag;

        /// <summary>
        /// DeleteFlag
        /// </summary>
        private short _deleteFlag;

        /// <summary>
        /// FinishFlag
        /// </summary>
        private short _finishFlag;

        /// <summary>
        /// CurrencyID
        /// </summary>
        private int _currencyID;

        /// <summary>
        /// MethodVat
        /// </summary>
        private short _methodVat;

        /// <summary>
        /// DeliveryDate
        /// </summary>
        private DateTime _deliveryDate;

        /// <summary>
        /// ExpiryDate
        /// </summary>
        private DateTime _expiryDate;

        /// <summary>
        /// SubjectName
        /// </summary>
        private string _subjectName;

        /// <summary>
        /// PreparedCD
        /// </summary>
        private string _preparedCD;

        /// <summary>
        /// PreparedName
        /// </summary>
        private string _preparedName;

        /// <summary>
        /// ApprovedCD
        /// </summary>
        private string _approvedCD;

        /// <summary>
        /// ApprovedName
        /// </summary>
        private string _approvedName;

        /// <summary>
        /// DelivererName
        /// </summary>
        private string _delivererName;

        /// <summary>
        /// CustomerCD
        /// </summary>
        private string _customerCD;

        /// <summary>
        /// CustomerName
        /// </summary>
        private string _customerName;

        /// <summary>
        /// CustomerAddress1
        /// </summary>
        private string _customerAddress1;

        /// <summary>
        /// CustomerAddress2
        /// </summary>
        private string _customerAddress2;

        /// <summary>
        /// CustomerAddress3
        /// </summary>
        private string _customerAddress3;

        /// <summary>
        /// Tel
        /// </summary>
        private string _tel;

        /// <summary>
        /// Fax
        /// </summary>
        private string _fax;

        /// <summary>
        /// ContactPerson
        /// </summary>
        private string _contactPerson;

        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// grandTotal
        /// </summary>
        private decimal _grandTotal;

        /// <summary>
        /// VAT
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// Memo
        /// </summary>
        private string _memo;

        /// <summary>
        /// ContractNo
        /// </summary>
        private string _acceptanceNo;

        /// <summary>
        /// InspectionDate
        /// </summary>
        private DateTime _acceptanceDate;

        /// <summary>
        /// confirmed
        /// </summary>
        private string _confirmed;

         /// <summary>
        /// position
        /// </summary>
        private string _position;

        /// <summary>
        /// IssuedDate
        /// </summary>
        private DateTime _issuedDate;

        /// <summary>
        /// IssuedUID
        /// </summary>
        private int _issuedUID;

        #endregion

        #region Property

        /// <summary>
        /// DeliveryPlace
        /// </summary>
        public string DeliveryPlace
        {
            get { return this._deliveryPlace; }
            set
            {
                if (value != this._deliveryPlace)
                {
                    this._deliveryPlace = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PrintFlag
        /// </summary>
        public short IssuedFlag
        {
            get { return this._issuedFlag; }
            set
            {
                if (value != this._issuedFlag)
                {
                    this._issuedFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return this._deleteFlag; }
            set
            {
                if (value != this._deleteFlag)
                {
                    this._deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public short FinishFlag
        {
            get { return this._finishFlag; }
            set
            {
                if (value != _finishFlag)
                {
                    this._finishFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// MethodVat
        /// </summary>
        public short MethodVat
        {
            get { return this._methodVat; }
            set
            {
                if (value != this._methodVat)
                {
                    this._methodVat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DeliveryDate
        /// </summary>
        public DateTime DeliveryDate
        {
            get { return this._deliveryDate; }
            set
            {
                if (value != this._deliveryDate)
                {
                    this._deliveryDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ExpiryDate
        /// </summary>
        public DateTime ExpiryDate
        {
            get { return this._expiryDate; }
            set
            {
                if (value != this._expiryDate)
                {
                    this._expiryDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName
        {
            get { return this._subjectName; }
            set
            {
                if (value != this._subjectName)
                {
                    this._subjectName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedCD
        /// </summary>
        public string PreparedCD
        {
            get { return this._preparedCD; }
            set
            {
                if (value != this._preparedCD)
                {
                    this._preparedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedName
        /// </summary>
        public string PreparedName
        {
            get { return this._preparedName; }
            set
            {
                if (value != this._preparedName)
                {
                    this._preparedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedCD
        /// </summary>
        public string ApprovedCD
        {
            get { return this._approvedCD; }
            set
            {
                if (value != this._approvedCD)
                {
                    this._approvedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedName
        /// </summary>
        public string ApprovedName
        {
            get { return this._approvedName; }
            set
            {
                if (value != this._approvedName)
                {
                    this._approvedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DelivererName
        /// </summary>
        public string DelivererName
        {
            get { return this._delivererName; }
            set
            {
                if (value != this._delivererName)
                {
                    _delivererName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD
        {
            get { return this._customerCD; }
            set
            {
                if (value != this._customerCD)
                {
                    this._customerCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerName
        /// </summary>
        public string CustomerName
        {
            get { return this._customerName; }
            set
            {
                if (value != this._customerName)
                {
                    this._customerName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress1
        /// </summary>
        public string CustomerAddress1
        {
            get { return this._customerAddress1; }
            set
            {
                if (value != this._customerAddress1)
                {
                    this._customerAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress2
        /// </summary>
        public string CustomerAddress2
        {
            get { return this._customerAddress2; }
            set
            {
                if (value != this._customerAddress2)
                {
                    this._customerAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress3
        /// </summary>
        public string CustomerAddress3
        {
            get { return this._customerAddress3; }
            set
            {
                if (value != this._customerAddress3)
                {
                    this._customerAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Tel
        /// </summary>
        public string Tel
        {
            get { return this._tel; }
            set
            {
                if (value != this._tel)
                {
                    this._tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Fax
        /// </summary>
        public string Fax
        {
            get { return this._fax; }
            set
            {
                if (value != this._fax)
                {
                    this._fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return this._contactPerson; }
            set
            {
                if (value != this._contactPerson)
                {
                    this._contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// GrandTotal
        /// </summary>
        public decimal GrandTotal
        {
            get { return this._grandTotal; }
            set
            {
                if (value != this._grandTotal)
                {
                    this._grandTotal = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VAT
        /// </summary>
        public decimal VAT
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyID
        /// </summary>
        public int CurrencyID
        {
            get { return this._currencyID; }
            set
            {
                if (value != this._currencyID)
                {
                    this._currencyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        /// <summary>
        /// Memo
        /// </summary>
        public string Memo
        {
            get { return this._memo; }
            set
            {
                if (value != this._memo)
                {
                    this._memo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// AcceptanceNo
        /// </summary>
        public string AcceptanceNo
        {
            get { return this._acceptanceNo; }
            set
            {
                if (value != this._acceptanceNo)
                {
                    this._acceptanceNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// AcceptanceDate
        /// </summary>
        public DateTime AcceptanceDate
        {
            get { return this._acceptanceDate; }
            set
            {
                if (value != this._acceptanceDate)
                {
                    this._acceptanceDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Confirmed
        /// </summary>
        public string Confirmed
        {
            get { return this._confirmed; }
            set
            {
                if (value != this._confirmed)
                {
                    this._confirmed = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Position
        /// </summary>
        public string Position
        {
            get { return this._position; }
            set
            {
                if (value != this._position)
                {
                    this._position = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        /// <summary>
        /// IssuedDate
        /// </summary>
        public DateTime IssuedDate
        {
            get { return this._issuedDate; }
            set
            {
                if (value != this._issuedDate)
                {
                    this._issuedDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedUID
        /// </summary>
        public int IssuedUID
        {
            get { return this._issuedUID; }
            set
            {
                if (value != this._issuedUID)
                {
                    this._issuedUID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor T_Delivery_H
        /// </summary>
        public T_Delivery_H()
            : base()
        {
            this.DeliveryNo = string.Empty;
            this.QuoteNo = string.Empty;
            this.SalesNo = string.Empty;
            this._deliveryPlace = string.Empty;
            this._issuedFlag = 0;
            this._deleteFlag = 0;
            this._finishFlag = 0;
            this._currencyID = 0;
            this._deliveryDate = DateTime.MinValue;
            this._expiryDate = DateTime.MinValue;
            this._subjectName = string.Empty;
            this._preparedCD = string.Empty;
            this._preparedName = string.Empty;
            this._approvedCD = string.Empty;
            this._approvedName = string.Empty;
            this._delivererName = string.Empty;
            this._customerCD = string.Empty;
            this._customerName = string.Empty;
            this._customerAddress1 = string.Empty;
            this._customerAddress2 = string.Empty;
            this._customerAddress3 = string.Empty;
            this._tel = string.Empty;
            this._fax = string.Empty;
            this._contactPerson = string.Empty;
            this._total = 0;
            this._grandTotal = 0;
            this._vat = 0;
            this._vatRatio = 0;
            this._vatType = 0;
            this._memo = string.Empty;
            this._acceptanceDate = DateTime.MinValue;
            this._acceptanceNo = string.Empty;
            this._issuedDate = DateTime.MinValue;
            this._issuedUID = 0;
            this._confirmed = string.Empty;
            this._position = string.Empty;

        }

        /// <summary>
        /// Contructor T_Shipping_H
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Delivery_H(DbDataReader dr)
            : base(dr)
        {
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.QuoteNo = (string)dr["QuoteNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this._deliveryPlace = (string)dr["DeliveryPlace"];
            this._issuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            this._deleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this._finishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            this._currencyID = (int)dr["CurrencyID"];
            this._methodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            this._deliveryDate = (DateTime)dr["DeliveryDate"];
            this._expiryDate = (DateTime)dr["ExpiryDate"];
            this._subjectName = (string)dr["SubjectName"];
            this._preparedCD = EditDataUtil.ToFixCodeShow((string)dr["PreparedCD"], M_User.MAX_USER_CODE_SHOW);
            this._preparedName = (string)dr["PreparedName"];
            this._approvedCD = EditDataUtil.ToFixCodeShow((string)dr["ApprovedCD"], M_User.MAX_USER_CODE_SHOW);
            this._approvedName = (string)dr["ApprovedName"];
            this._delivererName = (string)dr["DelivererName"];
            this._customerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this._customerName = (string)dr["CustomerName"];
            this._customerAddress1 = (string)dr["CustomerAddress1"];
            this._customerAddress2 = (string)dr["CustomerAddress2"];
            this._customerAddress3 = (string)dr["CustomerAddress3"];
            this._tel = (string)dr["Tel"];
            this._fax = (string)dr["Fax"];
            this._contactPerson = (string)dr["ContactPerson"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._total = (decimal)dr["Total"];
            this._grandTotal = (decimal)dr["GrandTotal"];
            this._vat = (decimal)dr["Vat"];
            this._memo = (string)dr["Memo"];
            this._acceptanceNo = (string)dr["AcceptanceNo"];
            this._acceptanceDate = (DateTime)dr["AcceptanceDate"];
            this._issuedDate = (DateTime)dr["IssuedDate"];
            this._issuedUID = (int)dr["IssuedUID"];
            this._position = (string)dr["Position"];
            this._confirmed = (string)dr["Confirmed"];
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace OMS.Models
{
    /// <summary>
    /// Class Vendor product
    /// Author: VN-Nho
    /// Create Date
    /// </summary>
    public class M_VendorProduct
    {

        #region Constant

        /// <summary>
        /// Max length DB of Vendor Product code
        /// </summary>
        public const int PRODUCT_VENDOR_PRODUCT_CODE_MAX_LENGTH = 50;

        #endregion

        #region Variable

        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Vendor ID
        /// </summary>
        public int VendorID { get; set; }

        /// <summary>
        /// Vendor product code
        /// </summary>
        public string VendorProductCD { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_VendorProduct()
        {
            this.ProductID = Constant.DEFAULT_ID;
            this.No = 0;
            this.VendorID = Constant.DEFAULT_ID;
            this.VendorProductCD = string.Empty;
        }

        /// <summary>
        /// Contructor with data reader
        /// </summary>
        /// <param name="dr">Data reader</param>
        public M_VendorProduct(DbDataReader dr)
        {
            this.ProductID = int.Parse(string.Format("{0}", dr["ProductID"]));
            this.No = int.Parse(string.Format("{0}", dr["No"]));
            this.VendorID = int.Parse(string.Format("{0}", dr["VendorID"]));
            this.VendorProductCD = string.Format("{0}", dr["VendorProductCD"]);
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class T_Billing_H Model
    /// Create Author: ISV-Giam
    /// Create Date: 2014/12/16
    /// </summary>
    [Serializable]
    public class T_Billing_H : M_Base<T_Billing_H>
    {
        #region Constant
        public const int SUBJECT_NAME_MAX_LENGTH = 150;
        public const int BILLING_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Memo
        /// </summary>
        public const int MEMO_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of CONTRACT_NO
        /// </summary>
        public const int CONTRACT_NO_MAX_LENGTH = 50;
        /// <summary>
        /// Description DESCRIPTION
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;

        /// <summary>
        /// Remark Maxlength
        /// </summary>
        public const int REMARK_MAX_LENGTH = 500;

        #endregion

        #region Variable

        /// <summary>
        /// BillingNo
        /// </summary>
        private string _billingNo;
        
        /// <summary>
        /// QuoteNo
        /// </summary>
        private string _quoteNo;

        /// <summary>
        /// Sales No
        /// </summary>
        private string _salesNo;

        /// <summary>
        /// PrintFlag
        /// </summary>
        private short _issuedFlag;

        /// <summary>
        /// DeleteFlag
        /// </summary>
        private short _deleteFlg;

        /// <summary>
        /// MethodVat
        /// </summary>
        private short _methodVat;

        /// <summary>
        /// FinishFlag
        /// </summary>
        private short _finishFlg;

        /// <summary>
        /// CurrencyID
        /// </summary>
        private short _currencyID;

        /// <summary>
        /// BillingDate
        /// </summary>
        private DateTime _billingDate;

        /// <summary>
        /// ExpiryDate
        /// </summary>
        private DateTime _expiryDate;

        /// <summary>
        /// PreparedCD
        /// </summary>
        private string _preparedCD;

        /// <summary>
        /// PreparedName
        /// </summary>
        private string preparedName;

        /// <summary>
        /// ApprovedCD
        /// </summary>
        private string _approvedCD;

        /// <summary>
        /// ApprovedName
        /// </summary>
        private string _approvedName;

        /// <summary>
        /// SubjectName
        /// </summary>
        private string _subjectName;

        /// <summary>
        /// CustomerCD
        /// </summary>
        private string _customerCD;

        /// <summary>
        /// CustomerName
        /// </summary>
        private string _customerName;

        /// <summary>
        /// CustomerAddress1
        /// </summary>
        private string _customerAddress1;

        /// <summary>
        /// CustomerAddress2
        /// </summary>
        private string _customerAddress2;

        /// <summary>
        /// CustomerAddress3
        /// </summary>
        private string _customerAddress3;

        /// <summary>
        /// Tel
        /// </summary>
        private string _tel;

        /// <summary>
        /// Fax
        /// </summary>
        private string _fax;

        /// <summary>
        /// TAXCode
        /// </summary>
        private string _taxCode;

        /// <summary>
        /// ContactPerson
        /// </summary>
        private string _contactPerson;

        /// <summary>
        /// RedInvoiceNo
        /// </summary>
        //---------------Add 2015/01/06 ISV-HUNG-----------------//
        //private string _redBillingNo;
        private string _redInvoiceNo;
        //---------------Add 2015/01/06 ISV-HUNG-----------------//

        /// <summary>
        /// RedInvoiceDate
        /// </summary>
        //---------------Add 2015/01/06 ISV-HUNG-----------------//
        //private DateTime _redBillingDate;
        private DateTime _redInvoiceDate;
        //---------------Add 2015/01/06 ISV-HUNG-----------------//

        /// <summary>
        /// PaymentMethod
        /// </summary>
        private short _paymentMethod;

        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// Vat
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// GrandTotal
        /// </summary>
        private decimal _grandTotal;

        /// <summary>
        /// Memo
        /// </summary>
        private string _memo;

        /// <summary>
        /// IssuedDate
        /// </summary>
        private DateTime _issuedDate;

        /// <summary>
        /// IssuedUID
        /// </summary>
        private int _issuedUID;

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Billing_H()
            : base()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Billing_H(DbDataReader dr)
            : base(dr)
        {
            this._billingNo = (string)dr["BillingNo"];
            this._salesNo = (string)dr["SalesNo"];
            this._quoteNo = (string)dr["QuoteNo"];
            this._issuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            this._deleteFlg = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this._finishFlg = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            this._currencyID = short.Parse(string.Format("{0}", dr["CurrencyID"]));
            this._billingDate = (DateTime)dr["BillingDate"];
            this._expiryDate = (DateTime)dr["ExpiryDate"];
            this._preparedCD = (string)dr["PreparedCD"];
            this.preparedName = (string)dr["PreparedName"];
            this._approvedCD = (string)dr["ApprovedCD"];
            this._approvedName = (string)dr["ApprovedName"];
            this._subjectName = (string)dr["SubjectName"];
            this._customerCD = (string)dr["CustomerCD"];
            this._customerName = (string)dr["CustomerName"];
            this._customerAddress1 = (string)dr["CustomerAddress1"];
            this._customerAddress2 = (string)dr["CustomerAddress2"];
            this._customerAddress3 = (string)dr["CustomerAddress3"];
            this._tel = (string)dr["Tel"];
            this._fax = (string)dr["FAX"];
            this._taxCode = (string)dr["TAXCode"];
            this._contactPerson = (string)dr["ContactPerson"];

            //---------------Add 2015/01/06 ISV-HUNG-----------------//
            //this._redBillingNo = (string)dr["RedBillingNo"];
            //this._redBillingDate = (DateTime)dr["RedBillingDate"];
            this._redInvoiceNo = (string)dr["RedInvoiceNo"];
            this._redInvoiceDate = (DateTime)dr["RedInvoiceDate"];
            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            this._paymentMethod = short.Parse(string.Format("{0}", dr["PaymentMethod"]));
            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._methodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            this._grandTotal = (decimal)dr["GrandTotal"];
            this._memo = (string)dr["Memo"];
            this._issuedDate = (DateTime)dr["IssuedDate"];
            this._issuedUID = (int)dr["IssuedUID"];
        }
        #endregion

        #region Property

        /// <summary>
        /// Get,set BillingNo
        /// </summary>
        public string BillingNo
        {
            get { return this._billingNo; }
            set
            {
                if (value != this._billingNo)
                {
                    this._billingNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set QuoteNo
        /// </summary>
        public string QuoteNo
        {
            get { return this._quoteNo; }
            set
            {
                if (value != this._quoteNo)
                {
                    this._quoteNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SalesNo
        /// </summary>
        public string SalesNo
        {
            get { return this._salesNo; }
            set
            {
                if (value != this._salesNo)
                {
                    this._salesNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PrintFlag
        /// </summary>
        public short IssuedFlag
        {
            get { return this._issuedFlag; }
            set
            {
                if (value != this._issuedFlag)
                {
                    this._issuedFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return this._deleteFlg; }
            set
            {
                if (value != this._deleteFlg)
                {
                    this._deleteFlg = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set FinishFlag
        /// </summary>
        public short FinishFlag
        {
            get { return this._finishFlg; }
            set
            {
                if (value != this._finishFlg)
                {
                    this._finishFlg = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        
        /// <summary>
        /// Get,set CurrencyFlag
        /// </summary>
        public short CurrencyID   
        {
            get { return this._currencyID; }
            set
            {
                if (value != this._currencyID)
                {
                    this._currencyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set BillingDate
        /// </summary>
        public DateTime BillingDate
        {
            get { return this._billingDate; }
            set
            {
                if (value != this._billingDate)
                {
                    this._billingDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ExpiryDate
        /// </summary>
        public DateTime ExpiryDate
        {
            get { return this._expiryDate; }
            set
            {
                if (value != this._expiryDate)
                {
                    this._expiryDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PreparedCD
        /// </summary>
        public string PreparedCD
        {
            get { return this._preparedCD; }
            set
            {
                if (value != this._preparedCD)
                {
                    this._preparedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set PreparedName
        /// </summary>
        public string PreparedName
        {
            get { return this.preparedName; }
            set
            {
                if (value != this.preparedName)
                {
                    this.preparedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ApprovedCD
        /// </summary>
        public string ApprovedCD
        {
            get { return this._approvedCD; }
            set
            {
                if (value != this._approvedCD)
                {
                    this._approvedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ApprovedName
        /// </summary>
        public string ApprovedName
        {
            get { return this._approvedName; }
            set
            {
                if (value != this._approvedName)
                {
                    this._approvedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SubjectName
        /// </summary>
        public string SubjectName
        {
            get { return this._subjectName; }
            set
            {
                if (value != this._subjectName)
                {
                    this._subjectName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerCD
        /// </summary>
        public string CustomerCD
        {
            get { return this._customerCD; }
            set
            {
                if (value != this._customerCD)
                {
                    this._customerCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerName
        /// </summary>
        public string CustomerName
        {
            get { return this._customerName; }
            set
            {
                if (value != this._customerName)
                {
                    this._customerName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress1
        /// </summary>
        public string CustomerAddress1
        {
            get { return this._customerAddress1; }
            set
            {
                if (value != this._customerAddress1)
                {
                    this._customerAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress2
        /// </summary>
        public string CustomerAddress2
        {
            get { return this._customerAddress2; }
            set
            {
                if (value != this._customerAddress2)
                {
                    this._customerAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set CustomerAddress3
        /// </summary>
        public string CustomerAddress3
        {
            get { return this._customerAddress3; }
            set
            {
                if (value != this._customerAddress3)
                {
                    this._customerAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set Tel
        /// </summary>
        public string Tel
        {
            get { return this._tel; }
            set
            {
                if (value != this._tel)
                {
                    this._tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set FAX
        /// </summary>
        public string FAX
        {
            get { return this._fax; }
            set
            {
                if (value != this._fax)
                {
                    this._fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set TAXCode
        /// </summary>
        public string TAXCode
        {
            get { return this._taxCode; }
            set
            {
                if (value != this._taxCode)
                {
                    this._taxCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return this._contactPerson; }
            set
            {
                if (value != this._contactPerson)
                {
                    this._contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set RedInvoiceNo
        /// </summary>
        //---------------Add 2015/01/06 ISV-HUNG-----------------//
        //public string RedBillingNo
        //{
        //    get { return this._redBillingNo; }
        //    set
        //    {
        //        if (value != this._redBillingNo)
        //        {
        //            this._redBillingNo = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}
        public string RedInvoiceNo
        {
            get { return this._redInvoiceNo; }
            set
            {
                if (value != this._redInvoiceNo)
                {
                    this._redInvoiceNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        ///// <summary>
        ///// Get,set RedBillingDate
        ///// </summary>
        //public DateTime RedBillingDate
        //{
        //    get { return this._redBillingDate; }
        //    set
        //    {
        //        if (value != this._redBillingDate)
        //        {
        //            this._redBillingDate = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}
        /// <summary>
        /// Get,set RedInvoiceDate
        /// </summary>
        public DateTime RedInvoiceDate
        {
            get { return this._redInvoiceDate; }
            set
            {
                if (value != this._redInvoiceDate)
                {
                    this._redInvoiceDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        //---------------Add 2015/01/06 ISV-HUNG-----------------//

        /// <summary>
        /// Get or set PaymentMethod
        /// </summary>
        public short PaymentMethod
        {
            get { return this._paymentMethod; }
            set
            {
                if (value != this._paymentMethod)
                {
                    this._paymentMethod = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set MethodVat
        /// </summary>
        public short MethodVat
        {
            get { return this._methodVat; }
            set
            {
                if (value != this._methodVat)
                {
                    this._methodVat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal Vat
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public short VatType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set GrandTotal
        /// </summary>
        public decimal GrandTotal
        {
            get { return this._grandTotal; }
            set
            {
                if (value != this._grandTotal)
                {
                    this._grandTotal = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Memo
        /// </summary>
        public string Memo
        {
            get { return this._memo; }
            set
            {
                if (value != this._memo)
                {
                    this._memo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set IssuedDate
        /// </summary>
        public DateTime IssuedDate
        {
            get { return this._issuedDate; }
            set
            {
                if (value != this._issuedDate)
                {
                    this._issuedDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set IssuedUID
        /// </summary>
        public int IssuedUID
        {
            get { return this._issuedUID; }
            set
            {
                if (value != this._issuedUID)
                {
                    this._issuedUID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion
    }
}


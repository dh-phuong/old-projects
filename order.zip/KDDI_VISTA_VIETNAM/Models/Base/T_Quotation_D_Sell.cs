﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// T_Quotation_D_Sell Model
    /// </summary>
    [Serializable]
    public class T_Quote_D_Sell
    {
        #region Contanst
        /// <summary>
        /// Max length of HeadLine
        /// </summary>
        public const int HEADLINE_MAX_LENGTH = 255;

        /// <summary>
        /// Max length of Description
        /// </summary>
        public const int DESCRIPTION_MAX_LENGTH = 1500;

        /// <summary>
        /// Max length of Remark
        /// </summary>
        public const int REMARK_MAX_LENGTH = 500;

        #endregion

        #region Variable
        /// <summary>
        /// Header ID
        /// </summary>
        private int _hid;

        /// <summary>
        /// No
        /// </summary>
        private int _no;

        /// <summary>
        /// Headline Flag
        /// </summary>
        private short _headlineFlag;

        /// <summary>
        /// Headline
        /// </summary>
        private string _headline;

        /// <summary>
        /// Product ID
        /// </summary>
        private int _productID;

        /// <summary>
        /// Product CD
        /// </summary>
        private string _productCD;

        /// <summary>
        /// Product Name
        /// </summary>
        private string _productName;

        /// <summary>
        /// Description
        /// </summary>
        private string _description;
        
        /// <summary>
        /// Remark
        /// </summary>
        private string _remark;

        /// <summary>
        /// Unit ID
        /// </summary>
        private int _unitID;

        /// <summary>
        /// VatType
        /// </summary>
        private short _vatType;

        /// <summary>
        /// VatRatio
        /// </summary>
        private decimal _vatRatio;

        /// <summary>
        /// Unit Price
        /// </summary>
        private decimal _unitPrice;
        
        /// <summary>
        /// Quantity
        /// </summary>
        private decimal _quantity;
        
        /// <summary>
        /// Total
        /// </summary>
        private decimal _total;

        /// <summary>
        /// Vat
        /// </summary>
        private decimal _vat;

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        #endregion

        #region Property

        /// <summary>
        /// Header ID
        /// </summary>
        public int HID
        {
            get { return _hid; }
            set { _hid = value; }
        }

        /// <summary>
        /// No
        /// </summary>
        public int No
        {
            get { return _no; }
            set { _no = value; }
        }

        /// <summary>
        /// Headline Flag
        /// </summary>
        public short HeadlineFlag
        {
            get { return _headlineFlag; }
            set { _headlineFlag = value; }
        }

        /// <summary>
        /// Headline
        /// </summary>
        public string Headline
        {
            get { return _headline; }
            set
            {
                if (value != _headline)
                {
                    _headline = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product ID
        /// </summary>
        public int ProductID
        {
            get { return _productID; }
            set
            {
                if (value != _productID)
                {
                    _productID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product CD
        /// </summary>
        public string ProductCD
        {
            get { return _productCD; }
            set
            {
                if (value != _productCD)
                {
                    _productCD = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName
        {
            get { return _productName; }
            set
            {
                if (value != _productName)
                {
                    _productName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Description
        /// </summary>
        public string Description
        {
            get { return _description; }
            set
            {
                if (value != _description)
                {
                    _description = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Remark
        /// </summary>
        public string Remark
        {
            get { return _remark; }
            set
            {
                if (value != _remark)
                {
                    _remark = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Unit ID
        /// </summary>
        public int UnitID
        {
            get { return _unitID; }
            set
            {
                if (value != _unitID)
                {
                    _unitID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType
        {
            get { return _vatType; }
            set
            {
                if (value != _vatType)
                {
                    _vatType = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// vatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return _vatRatio; }
            set
            {
                if (value != _vatRatio)
                {
                    _vatRatio = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Unit Price
        /// </summary>
        public decimal UnitPrice
        {
            get { return _unitPrice; }
            set
            {
                if (value != _unitPrice)
                {
                    _unitPrice = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity
        {
            get { return _quantity; }
            set
            {
                if (value != _quantity)
                {
                    _quantity = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return _total; }
            set
            {
                if (value != _total)
                {
                    _total = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// vat
        /// </summary>
        public decimal Vat
        {
            get { return _vat; }
            set
            {
                if (value != _vat)
                {
                    _vat = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        ///// <summary>
        ///// UnitName
        ///// (Quotation Report)ISV-GIAM
        ///// </summary>
        //public string UnitName { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// Deleted Flg
        /// </summary>
        public bool DeletedFlg { get; set; }
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor T_Quotation_D_Sell
        /// </summary>
        public T_Quote_D_Sell()
            : base()
        {
            this._productID = Constant.DEFAULT_ID;
            this._unitID = Constant.DEFAULT_ID;
            
            this._hid = 0;
            this._no = 0;
            this._headlineFlag = 0;
            this._headline = string.Empty;
            
            this._productCD = string.Empty;
            this._productName = string.Empty;
            this._description = string.Empty;
            this._remark = string.Empty;
            
            this._vatType = 0;
            this._vatRatio = 0;
            this._unitPrice = 0;
            this._quantity = 0;
            this._total = 0;
            this._vat = 0;
            //this.UnitName = string.Empty;
            this._status = DataStatus.None;
            this.DeletedFlg = false;
        }

        /// <summary>
        /// Contructor T_Quotation_D_Sell
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Quote_D_Sell(DbDataReader dr)
        {
            this._hid = (int)dr["HID"];
            this._no = (int)dr["No"];
            this._headlineFlag = short.Parse(string.Format("{0}", dr["HeadlineFlag"]));
            this._headline = (string)dr["Headline"];
            this._productID = (int)dr["ProductID"];
            this._productCD = (string)dr["ProductCD"];
            this._productName = (string)dr["ProductName"];
            this._description = (string)dr["Description"];
            this._remark = (string)dr["Remark"];
            this._unitID = (int)dr["UnitID"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._vatRatio = (decimal)dr["VATRatio"];
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._quantity = (decimal)dr["Quantity"];
            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._status = DataStatus.None;
            this.DeletedFlg = false;
        }

        #endregion

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
            if (string.IsNullOrEmpty(this._productCD) &&
                string.IsNullOrEmpty(this._productName) &&
                string.IsNullOrEmpty(this._description) &&
                this._unitPrice == 0 &&
                this._quantity == 0 &&
                this._unitID == Constant.DEFAULT_ID &&
                string.IsNullOrEmpty(this._remark) &&
                this._total == 0 &&
                this._vat == 0
                )
            {
                return true;
            }

            return false;
        }
    }
}

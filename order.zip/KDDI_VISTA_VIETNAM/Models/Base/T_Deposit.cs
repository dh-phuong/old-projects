﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    [Serializable]
    public class T_Deposit
    {

        #region Variable

        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;

        /// <summary>
        /// Delete flag
        /// </summary>
        private bool delFlg;

        /// <summary>
        /// BillingID
        /// </summary>
        private int billingID;

        /// <summary>
        /// No
        /// </summary>
        private int no;

        /// <summary>
        /// depositDate
        /// </summary>
        private DateTime? depositDate;

        /// <summary>
        /// Amount
        /// </summary>
        private decimal? amount;

        /// <summary>
        /// PaymentMethod
        /// </summary>
        private short paymentMethod;

        /// <summary>
        /// remarks
        /// </summary>
        private string remark1;

        /// <summary>
        /// remarks
        /// </summary>
        private string remark2;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Deposit()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Deposit(DbDataReader dr)
        {
            this.billingID = (int)dr["BillingID"];
            this.no = (int)dr["No"];
            this.depositDate = (DateTime)dr["DepositDate"];
            this.amount = (decimal)dr["Amount"];
            this.paymentMethod = short.Parse(dr["PaymentMethod"].ToString());
            this.remark2 = dr["Remark2"].ToString();
            this.remark1 = dr["Remark1"].ToString();
        }
        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// Get,set DelFlag
        /// </summary>
        public bool DelFlag
        {
            get { return this.delFlg; }
            set { this.delFlg = value; }
        }
        /// <summary>
        /// Get,set ID
        /// </summary>
        public int BillingID
        {
            get { return this.billingID; }
            set
            {
                if (value != this.billingID)
                {
                    this.billingID = value;
                }
            }
        }
        /// <summary>
        /// Get,set No
        /// </summary>
        public int No
        {
            get { return this.no; }
            set
            {
                if (value != this.no)
                {
                    this.no = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set DepositDate
        /// </summary>
        public DateTime? DepositDate
        {
            get { return this.depositDate; }
            set
            {
                if (value != this.depositDate)
                {
                    this.depositDate = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set Amount
        /// </summary>
        public decimal? Amount
        {
            get { return this.amount; }
            set
            {
                if (value != this.amount)
                {
                    this.amount = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set PaymentMethod
        /// </summary>
        public short PaymentMethod
        {
            get { return this.paymentMethod; }
            set
            {
                if (value != this.paymentMethod)
                {
                    this.paymentMethod = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set PaymentMethod
        /// </summary>
        public string Remark1
        {
            get { return this.remark1; }
            set
            {
                if (value != this.remark1)
                {
                    this.remark1 = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// Get,set remarks
        /// </summary>
        public string Remark2
        {
            get { return this.remark2; }
            set
            {
                if (value != this.remark2)
                {
                    this.remark2 = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        #endregion
    }
}

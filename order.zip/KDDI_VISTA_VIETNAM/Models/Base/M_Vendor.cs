﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Vendor class model
    /// </summary>
    [Serializable]
    public class M_Vendor : M_Base<M_Vendor>
    {        
        #region Constant

        /// <summary>
        /// Max length of VendorCD
        /// </summary>
        public const int VENDOR_CODE_MAX_LENGTH = 10;

        /// <summary>
        /// Max length of VendorName 1
        /// </summary>
        public const int VENDOR_NAME_1_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of VendorName 2
        /// </summary>
        public const int VENDOR_NAME_2_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of Address
        /// </summary>
        public const int VENDOR_ADDRESS_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of Group Supply
        /// </summary>
        public const int VENDOR_GROUP_SUPPLY_MAX_LENGTH = 30;

        /// <summary>
        /// Max length of Tel
        /// </summary>
        public const int VENDOR_TEL_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of FAX
        /// </summary>
        public const int VENDOR_FAX_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of EmailAddress
        /// </summary>
        public const int VENDOR_EMAIL_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of ContactPerson
        /// </summary>
        public const int VENDOR_CONTACT_PERSON_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of ContactTel
        /// </summary>
        public const int VENDOR_CONTACT_TEL_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of TAXCode
        /// </summary>
        public const int VENDOR_TAX_CODE_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of VendorBank
        /// </summary>
        public const int VENDOR_BANK_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of AccountCode
        /// </summary>
        public const int VENDOR_ACCOUNT_CODE_MAX_LENGTH = 50;
      
        /// <summary>
        /// Max length of VendorCD to show
        /// </summary>
        public const int VENDOR_CODE_MAX_SHOW = 6;

        /// <summary>
        /// Support VendorCD (999999)
        /// </summary>
        public const string VENDOR_CODE_SUPPORT = "999999";

        #endregion

        #region Variant

        /// <summary>
        /// VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// VendorName1
        /// </summary>
        private string vendorName1;
        /// <summary>
        /// VendorName2
        /// </summary>
        private string vendorName2;
        /// <summary>
        /// VendorAddress1
        /// </summary>
        private string vendorAddress1;
        /// <summary>
        /// VendorAddress2
        /// </summary>
        private string vendorAddress2;
        /// <summary>
        /// VendorAddress3
        /// </summary>
        private string vendorAddress3;
        /// <summary>
        /// GroupSupply
        /// </summary>
        private string groupSupply;
        /// <summary>
        /// Tel
        /// </summary>
        private string tel;
        /// <summary>
        /// Fax
        /// </summary>
        private string fax;
        /// <summary>
        /// EmailAddress
        /// </summary>
        private string emailAddress;
        /// <summary>
        /// ContactPerson
        /// </summary>
        private string contactPerson;
        /// <summary>
        /// ContactTel
        /// </summary>
        private string contactTel;
        /// <summary>
        /// TaxCode
        /// </summary>
        private string taxCode;
        /// <summary>
        /// VendorBank
        /// </summary>
        private string vendorBank;
        /// <summary>
        /// AccountCode
        /// </summary>
        private string accountCode;
        /// <summary>
        /// StatusFlag
        /// </summary>
        private short statusFlag;
        #endregion

        #region Property

        /// <summary>
        /// Get or set Vendor Name 1
        /// </summary>
        public string VendorName1
        {
            get { return vendorName1; }
            set
            {
                if (value != vendorName1)
                {
                    vendorName1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vendor Name 2
        /// </summary>
        public string VendorName2
        {
            get { return vendorName2; }
            set
            {
                if (value != vendorName2)
                {
                    vendorName2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vendor Address 1
        /// </summary>
        public string VendorAddress1
        {
            get { return vendorAddress1; }
            set
            {
                if (value != vendorAddress1)
                {
                    vendorAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vendor Address 2
        /// </summary>
        public string VendorAddress2
        {
            get { return vendorAddress2; }
            set
            {
                if (value != vendorAddress2)
                {
                    vendorAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vendor Address 3
        /// </summary>
        public string VendorAddress3
        {
            get { return vendorAddress3; }
            set
            {
                if (value != vendorAddress3)
                {
                    vendorAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Group Supply
        /// </summary>
        public string GroupSupply
        {
            get { return groupSupply; }
            set
            {
                if (value != groupSupply)
                {
                    groupSupply = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Tel
        /// </summary>
        public string Tel
        {
            get { return tel; }
            set
            {
                if (value != tel)
                {
                    tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set FAX
        /// </summary>
        public string FAX
        {
            get { return fax; }
            set
            {
                if (value != fax)
                {
                    fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Email Address
        /// </summary>
        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                if (value != emailAddress)
                {
                    emailAddress = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Contact Person
        /// </summary>
        public string ContactPerson
        {
            get { return contactPerson; }
            set
            {
                if (value != contactPerson)
                {
                    contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Contact Tel
        /// </summary>
        public string ContactTel
        {
            get { return contactTel; }
            set
            {
                if (value != contactTel)
                {
                    contactTel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set TAX Code
        /// </summary>
        public string TAXCode
        {
            get { return taxCode; }
            set
            {
                if (value != taxCode)
                {
                    taxCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Vendor Bank
        /// </summary>
        public string VendorBank
        {
            get { return vendorBank; }
            set
            {
                if (value != vendorBank)
                {
                    vendorBank = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Account Code
        /// </summary>
        public string AccountCode
        {
            get { return accountCode; }
            set
            {
                if (value != accountCode)
                {
                    accountCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Status Flag
        /// </summary>
        public short StatusFlag
        {
            get { return statusFlag; }
            set
            {
                if (value != statusFlag)
                {
                    statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        #endregion

        #region Contructor

        /// <summary>
        /// Constructors M_Vendor
        /// </summary>
        public M_Vendor()
            : base()
        {

        }

        /// <summary>
        /// Constructors M_Vendor
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Vendor(DbDataReader dr)
            : base(dr)
        {
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW); 
            this.vendorName1 = (string)dr["VendorName1"];
            this.vendorName2 = (string)dr["VendorName2"];
            this.vendorAddress1 = (string)dr["VendorAddress1"];
            this.vendorAddress2 = (string)dr["VendorAddress2"];
            this.vendorAddress3 = (string)dr["VendorAddress3"];
            this.groupSupply = (string)dr["GroupSupply"];
            this.tel = (string)dr["Tel"];
            this.fax = (string)(dr["FAX"]);
            this.emailAddress = (string)(dr["EmailAddress"]);
            this.contactPerson = (string)(dr["ContactPerson"]);
            this.contactTel = (string)(dr["ContactTel"]);
            this.taxCode = (string)(dr["TAXCode"]);
            this.vendorBank = (string)(dr["VendorBank"]);
            this.accountCode = (string)(dr["AccountCode"]);
            this.statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));            
        }
        #endregion
    }
}

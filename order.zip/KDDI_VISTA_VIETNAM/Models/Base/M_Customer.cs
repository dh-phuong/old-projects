﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Customer Models
    /// ISV:NGUYEN
    /// </summary>
    [Serializable]
    public class M_Customer : M_Base<M_Customer>
    {
        #region Contanst

        /// <summary>
        /// Max length of CustomerCD
        /// </summary>
        public const int CUSTOMER_CODE_MAX_LENGTH = 10;

        /// <summary>
        /// Max length of CustomerName1
        /// </summary>
        public const int CUSTOMER_NAME1_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of CustomerName2
        /// </summary>
        public const int CUSTOMER_NAME2_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of Address to show
        /// </summary>
        public const int ADDRESS_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of Represent to show
        /// </summary>
        public const int REPRESENT_MAX_LENGTH = 60;

        /// <summary>
        /// Max length of Position to show
        /// </summary>
        public const int POSITION_MAX_LENGTH = 60;

        /// <summary>
        /// Max length of Email Address to show
        /// </summary>
        public const int EMAIL_ADDRESS_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of Tel to show
        /// </summary>
        public const int TEL_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Fax to show
        /// </summary>
        public const int FAX_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of ContactPerson to show
        /// </summary>
        public const int CONTACT_PERSON_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of ContactTel to show
        /// </summary>
        public const int CONTACT_TEL_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of TaxCode to show
        /// </summary>
        public const int TAX_CODE_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of CustomerBank to show
        /// </summary>
        public const int CUSTOMER_BANK_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of AccountNo to show
        /// </summary>
        public const int ACCOUNT_NO_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of CustomerCode  to show
        /// </summary>
        public const int MAX_CUSTOMER_CODE_SHOW = 6;

        public const string CUSTOMER_CODE_SUPPORT = "999999";

        #endregion

        #region Field
        private string customerName1;
        private string customerName2;
        private string customerAddress1;
        private string customerAddress2;
        private string customerAddress3;
        private string customerAddress4;
        private string customerAddress5;
        private string customerAddress6;
        private string represent;
        private string position1;
        private string position2;
        private string tel;
        private string fax;
        private string emailAddress;
        private string contactPerson;
        private string contactTel;
        private string taxCode;
        private string customerBank;
        private string accountCode;
        private short statusFlag;
        #endregion

        #region Property
        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// CustomerName1
        /// </summary>
        public string CustomerName1
        {
            get { return customerName1; }
            set
            {
                if (value != customerName1)
                {
                    customerName1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerName2
        /// </summary>
        public string CustomerName2
        {
            get { return customerName2; }
            set
            {
                if (value != customerName2)
                {
                    customerName2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress1
        /// </summary>
        public string CustomerAddress1
        {
            get { return customerAddress1; }
            set
            {
                if (value != customerAddress1)
                {
                    customerAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress2
        /// </summary>
        public string CustomerAddress2
        {
            get { return customerAddress2; }
            set
            {
                if (value != customerAddress2)
                {
                    customerAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress3
        /// </summary>
        public string CustomerAddress3
        {
            get { return customerAddress3; }
            set
            {
                if (value != customerAddress3)
                {
                    customerAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }      

        /// <summary>
        /// CustomerAddress4
        /// </summary>
        public string CustomerAddress4
        {
            get { return customerAddress4; }
            set
            {
                if (value != customerAddress4)
                {
                    customerAddress4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress5
        /// </summary>
        public string CustomerAddress5
        {
            get { return customerAddress5; }
            set
            {
                if (value != customerAddress5)
                {
                    customerAddress5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress6
        /// </summary>
        public string CustomerAddress6
        {
            get { return customerAddress6; }
            set
            {
                if (value != customerAddress6)
                {
                    customerAddress6 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Represent
        /// </summary>
        public string Represent
        {
            get { return represent; }
            set
            {
                if (value != represent)
                {
                    represent = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Position1
        /// </summary>
        public string Position1
        {
            get { return position1; }
            set
            {
                if (value != position1)
                {
                    position1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Position2
        /// </summary>
        public string Position2
        {
            get { return position2; }
            set
            {
                if (value != position2)
                {
                    position2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Tel
        /// </summary>
        public string Tel
        {
            get { return tel; }
            set
            {
                if (value != tel)
                {
                    tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// FAX
        /// </summary>
        public string FAX
        {
            get { return fax; }
            set
            {
                if (value != fax)
                {
                    fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// EmailAddress
        /// </summary>
        public string EmailAddress
        {
            get { return emailAddress; }
            set
            {
                if (value != emailAddress)
                {
                    emailAddress = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return contactPerson; }
            set
            {
                if (value != contactPerson)
                {
                    contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ContactTel
        /// </summary>
        public string ContactTel
        {
            get { return contactTel; }
            set
            {
                if (value != contactTel)
                {
                    contactTel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// TAXCode
        /// </summary>
        public string TAXCode
        {
            get { return taxCode; }
            set
            {
                if (value != taxCode)
                {
                    taxCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerBank
        /// </summary>
        public string CustomerBank
        {
            get { return customerBank; }
            set
            {
                if (value != customerBank)
                {
                    customerBank = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// AccountCode
        /// </summary>
        public string AccountCode
        {
            get { return accountCode; }
            set
            {
                if (value != accountCode)
                {
                    accountCode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// StatusFlag
        /// </summary>
        public short StatusFlag
        {
            get { return statusFlag; }
            set
            {
                if (value != statusFlag)
                {
                    statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor M_User
        /// </summary>
        public M_Customer()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_User
        /// </summary>
        /// <param name="dr"></param>
        public M_Customer(DbDataReader dr)
            : base(dr)
        {
            this.CustomerCD = (string)dr["CustomerCD"];
            this.customerName1 = (string)dr["CustomerName1"];
            this.customerName2 = (string)dr["CustomerName2"];
            this.customerAddress1 = (string)dr["CustomerAddress1"];
            this.customerAddress2 = (string)dr["CustomerAddress2"];
            this.customerAddress3 = (string)dr["CustomerAddress3"];
            this.customerAddress4 = (string)dr["CustomerAddress4"];
            this.customerAddress5 = (string)dr["CustomerAddress5"];
            this.customerAddress6 = (string)dr["CustomerAddress6"];
            this.represent = (string)dr["Represent"];
            this.position1 = (string)dr["Position1"];
            this.position2 = (string)dr["Position2"];
            this.tel = (string)dr["Tel"];
            this.fax = (string)(dr["FAX"]);
            this.emailAddress = (string)(dr["EmailAddress"]);
            this.contactPerson = (string)(dr["ContactPerson"]);
            this.contactTel = (string)(dr["ContactTel"]);
            this.taxCode = (string)(dr["TAXCode"]);
            this.customerBank = (string)(dr["CustomerBank"]);
            this.accountCode = (string)(dr["AccountCode"]);
            this.statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
        }     
        #endregion
    }
}

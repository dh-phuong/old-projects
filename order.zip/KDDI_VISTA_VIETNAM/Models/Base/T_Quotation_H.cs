﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// T_Quotation_H model
    /// </summary>
    [Serializable]
    public class T_Quote_H : M_Base<T_Quote_H>
    {
        #region Contanst

        /// <summary>
        /// Max length of QuoteNo
        /// </summary>
        public const int QUOTE_NO_MAX_LENGTH = 20;
        /// <summary>
        /// Max length of InchargeCD
        /// </summary>
        public const int INCHARGE_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of InchargeName
        /// </summary>
        public const int INCHARGE_NAME_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ApprovedCD
        /// </summary>
        public const int APPROVED_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of ApprovedName
        /// </summary>
        public const int APPROVED_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of FrontSalesCD
        /// </summary>
        public const int FRONT_SALES_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of FrontSalesName
        /// </summary>
        public const int FRONT_SALES_NAME_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of EngineerCD
        /// </summary>
        public const int ENGINEER_CD_MAX_LENGTH = 10;
        /// <summary>
        /// Max length of EngineerName
        /// </summary>
        public const int ENGINEER_NAME_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ProjectName
        /// </summary>
        public const int PROJECT_NAME_MAX_LENGTH = 150;
        /// <summary>
        /// Max length of Tel
        /// </summary>
        public const int TEL_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of Fax
        /// </summary>
        public const int FAX_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of ContactPerson
        /// </summary>
        public const int CONTACT_PERSON_MAX_LENGTH = 50;
        /// <summary>
        /// Max length of Memo
        /// </summary>
        public const int MEMO_MAX_LENGTH = 150;


        #endregion

        #region Variant

        public string QuoteNo { get; set; }

        /// <summary>
        /// QuoteDate
        /// </summary>
        private DateTime _quoteDate;
        /// <summary>
        /// expiryDate
        /// </summary>
        private DateTime _expiryDate;
        /// <summary>
        /// expectedOrderDate
        /// </summary>
        private DateTime _expectedOrderDate;
        /// <summary>
        /// expectedRevenueDate
        /// </summary>
        private DateTime _expectedRevenueDate;
        /// <summary>
        /// preparedCD
        /// </summary>
        private string _preparedCD;
        /// <summary>
        /// preparedName
        /// </summary>
        private string _preparedName;
        /// <summary>
        /// ApprovedCD
        /// </summary>
        private string _approvedCD;
        /// <summary>
        /// ApprovedName
        /// </summary>
        private string _approvedName;
        /// <summary>
        /// salesCD1
        /// </summary>
        private string _salesCD1;
        /// <summary>
        /// salesName1
        /// </summary>
        private string _salesName1;
        /// <summary>
        /// salesCD2
        /// </summary>
        private string _salesCD2;
        /// <summary>
        /// salesName2
        /// </summary>
        private string _salesName2;
        /// <summary>
        /// CustomerCD
        /// </summary>
        private string _customerCD;
        /// <summary>
        /// CustomerName
        /// </summary>
        private string _customerName;
        /// <summary>
        /// subjectName
        /// </summary>
        private string _subjectName;
        /// <summary>
        /// CustomerAddress1
        /// </summary>
        private string _customerAddress1;
        /// <summary>
        /// CustomerAddress2
        /// </summary>
        private string _customerAddress2;
        /// <summary>
        /// CustomerAddress3
        /// </summary>
        private string _customerAddress3;
        /// <summary>
        /// Tel
        /// </summary>
        private string _tel;
        /// <summary>
        /// Fax
        /// </summary>
        private string _fax;
        /// <summary>
        /// ContactPerson
        /// </summary>
        private string _contactPerson;
        /// <summary>
        /// CurrencyID
        /// </summary>
        private int _currencyID;
        /// <summary>
        /// MethodVat
        /// </summary>
        private short _methodVat;
        /// <summary>
        /// total
        /// </summary>
        private decimal _total;
        /// <summary>
        /// vat
        /// </summary>
        private decimal _vat;
        /// <summary>
        /// vatRatio
        /// </summary>
        private decimal _vatRatio;
        /// <summary>
        /// vatType
        /// </summary>
        private short _vatType;
        /// <summary>
        /// grandTotal
        /// </summary>
        private decimal _grandTotal;
        // Author: ISV-PHUONG
        // Date  : 2014/12/18
        // ---------------------- Start ------------------------------
        ///// <summary>
        ///// profitRatio
        ///// </summary>
        //private decimal _profitRatio;
        // ---------------------- End  ------------------------------
        // Description: Add
        // Author: ISV-PHUONG
        // Date  : 2014/12/05
        // ---------------------- Start ------------------------------
        /// <summary>
        /// Approved
        /// </summary>
        private string _approved;
        /// <summary>
        /// Position
        /// </summary>
        private string _position;
        // ---------------------- End  ------------------------------
        /// <summary>
        /// Memo
        /// </summary>
        private string _memo;
        /// <summary>
        /// newFlag
        /// </summary>
        private short _newFlag;
        /// <summary>
        /// StatusFlag
        /// </summary>
        private short _statusFlag;
        /// <summary>
        /// IssuedFlag
        /// </summary>
        private short _issuedFlag;
        /// <summary>
        /// DeleteFlag
        /// </summary>
        private short _deleteFlag;
        /// <summary>
        /// IssuedDate
        /// </summary>
        private DateTime _issuedDate;
        /// <summary>
        /// IssuedUID
        /// </summary>
        private int _issuedUID;

        #endregion

        #region Property

        /// <summary>
        /// StatusFlag
        /// </summary>
        public short StatusFlag
        {
            get { return this._statusFlag; }
            set
            {
                if (value != this._statusFlag)
                {
                    this._statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedFlag
        /// </summary>
        public short IssuedFlag
        {
            get { return this._issuedFlag; }
            set
            {
                if (value != this._issuedFlag)
                {
                    this._issuedFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return this._deleteFlag; }
            set
            {
                if (value != this._deleteFlag)
                {
                    this._deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// QuoteDate
        /// </summary>
        public DateTime QuoteDate
        {
            get { return this._quoteDate; }
            set
            {
                if (value != this._quoteDate)
                {
                    this._quoteDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ExpiryDate
        /// </summary>
        public DateTime ExpiryDate
        {
            get { return this._expiryDate; }
            set
            {
                if (value != this._expiryDate)
                {
                    this._expiryDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ExpectedOrderDate
        /// </summary>
        public DateTime ExpectedOrderDate
        {
            get { return this._expectedOrderDate; }
            set
            {
                if (value != this._expectedOrderDate)
                {
                    this._expectedOrderDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ExpectedRevenueDate
        /// </summary>
        public DateTime ExpectedRevenueDate
        {
            get { return this._expectedRevenueDate; }
            set
            {
                if (value != this._expectedRevenueDate)
                {
                    this._expectedRevenueDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedCD
        /// </summary>
        public string PreparedCD
        {
            get { return this._preparedCD; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_User.MAX_USER_CODE_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(this._preparedCD, M_User.MAX_USER_CODE_SHOW);
                if (val1 != val2)
                {
                    this._preparedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// PreparedName
        /// </summary>
        public string PreparedName
        {
            get { return this._preparedName; }
            set
            {
                if (value != this._preparedName)
                {
                    this._preparedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedCD
        /// </summary>
        public string ApprovedCD
        {
            get { return this._approvedCD; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_User.MAX_USER_CODE_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(this._approvedCD, M_User.MAX_USER_CODE_SHOW);
                if (val1 != val2)
                {
                    this._approvedCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApprovedName
        /// </summary>
        public string ApprovedName
        {
            get { return this._approvedName; }
            set
            {
                if (value != this._approvedName)
                {
                    this._approvedName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SalesCD1
        /// </summary>
        public string SalesCD1
        {
            get { return this._salesCD1; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_User.MAX_USER_CODE_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(this._salesCD1, M_User.MAX_USER_CODE_SHOW);
                if (val1 != val2)
                {
                    this._salesCD1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SalesName1
        /// </summary>
        public string SalesName1
        {
            get { return this._salesName1; }
            set
            {
                if (value != this._salesName1)
                {
                    this._salesName1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SalesCD2
        /// </summary>
        public string SalesCD2
        {
            get { return this._salesCD2; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_User.MAX_USER_CODE_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(this._salesCD2, M_User.MAX_USER_CODE_SHOW);
                if (val1 != val2)
                {
                    this._salesCD2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SalesName2
        /// </summary>
        public string SalesName2
        {
            get { return this._salesName2; }
            set
            {
                if (value != this._salesName2)
                {
                    this._salesName2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD
        {
            get { return this._customerCD; }
            set
            {
                var val1 = Utilities.EditDataUtil.ToFixCodeShow(value, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                var val2 = Utilities.EditDataUtil.ToFixCodeShow(this._customerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                if (val1 != val2)
                {
                    this._customerCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerName
        /// </summary>
        public string CustomerName
        {
            get { return this._customerName; }
            set
            {
                if (value != this._customerName)
                {
                    this._customerName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName
        {
            get { return this._subjectName; }
            set
            {
                if (value != this._subjectName)
                {
                    this._subjectName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress1
        /// </summary>
        public string CustomerAddress1
        {
            get { return this._customerAddress1; }
            set
            {
                if (value != this._customerAddress1)
                {
                    this._customerAddress1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress2
        /// </summary>
        public string CustomerAddress2
        {
            get { return this._customerAddress2; }
            set
            {
                if (value != this._customerAddress2)
                {
                    this._customerAddress2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CustomerAddress3
        /// </summary>
        public string CustomerAddress3
        {
            get { return this._customerAddress3; }
            set
            {
                if (value != this._customerAddress3)
                {
                    this._customerAddress3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Tel
        /// </summary>
        public string Tel
        {
            get { return this._tel; }
            set
            {
                if (value != this._tel)
                {
                    this._tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Fax
        /// </summary>
        public string FAX
        {
            get { return this._fax; }
            set
            {
                if (value != this._fax)
                {
                    this._fax = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ContactPerson
        /// </summary>
        public string ContactPerson
        {
            get { return this._contactPerson; }
            set
            {
                if (value != this._contactPerson)
                {
                    this._contactPerson = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// CurrencyID
        /// </summary>
        public int CurrencyID
        {
            get { return this._currencyID; }
            set
            {
                if (value != this._currencyID)
                {
                    this._currencyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// MethodVat
        /// </summary>
        public short MethodVat
        {
            get { return this._methodVat; }
            set
            {
                if (value != this._methodVat)
                {
                    this._methodVat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Total
        /// </summary>
        public decimal Total
        {
            get { return this._total; }
            set
            {
                if (value != this._total)
                {
                    this._total = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Vat
        /// </summary>
        public decimal Vat
        {
            get { return this._vat; }
            set
            {
                if (value != this._vat)
                {
                    this._vat = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatRatio
        /// </summary>
        public decimal VatRatio
        {
            get { return this._vatRatio; }
            set
            {
                if (value != this._vatRatio)
                {
                    this._vatRatio = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType
        {
            get { return this._vatType; }
            set
            {
                if (value != this._vatType)
                {
                    this._vatType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// GrandTotal
        /// </summary>
        public decimal GrandTotal
        {
            get { return this._grandTotal; }
            set
            {
                if (value != this._grandTotal)
                {
                    this._grandTotal = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        // Author: ISV-PHUONG
        // Date  : 2014/12/18
        // ---------------------- Start ------------------------------
        ///// <summary>
        ///// ProfitRatio
        ///// </summary>
        //public decimal ProfitRatio
        //{
        //    get { return _profitRatio; }
        //    set
        //    {
        //        if (value != _profitRatio)
        //        {
        //            _profitRatio = value;
        //            this.Status = DataStatus.Changed;
        //        }
        //    }
        //}
        // ---------------------- End  ------------------------------
        // Description: Add
        // Author: ISV-PHUONG
        // Date  : 2014/12/05
        // ---------------------- Start ------------------------------
        public string Approved
        {
            get { return this._approved; }
            set
            {
                if (value != this._approved)
                {
                    this._approved = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        public string Position
        {
            get { return this._position; }
            set
            {
                if (value != this._position)
                {
                    this._position = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        // ---------------------- End  ------------------------------
        /// <summary>
        /// Memo
        /// </summary>
        public string Memo
        {
            get { return this._memo; }
            set
            {
                if (value != _memo)
                {
                    _memo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IsNew
        /// </summary>
        public short NewFlag
        {
            get { return this._newFlag; }
            set
            {
                if (value != this._newFlag)
                {
                    this._newFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedDate
        /// </summary>
        public DateTime IssuedDate
        {
            get { return this._issuedDate; }
            set
            {
                if (value != this._issuedDate)
                {
                    this._issuedDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// IssuedUID
        /// </summary>
        public int IssuedUID
        {
            get { return this._issuedUID; }
            set
            {
                if (value != this._issuedUID)
                {
                    this._issuedUID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor T_Quotation_H
        /// </summary>
        public T_Quote_H()
            : base()
        {
            this.QuoteNo = string.Empty;
            this._statusFlag = 0;
            this._issuedFlag = 0;
            this._deleteFlag = 0;
            this._quoteDate = DateTime.MinValue;
            this._expiryDate = DateTime.MinValue;
            this._expectedOrderDate = DateTime.MinValue;
            this._expectedRevenueDate = DateTime.MinValue;
            this._preparedCD = string.Empty;
            this._preparedName = string.Empty;
            this._approvedCD = string.Empty;
            this._approvedName = string.Empty;
            this._salesCD1 = string.Empty;
            this._salesName1 = string.Empty;
            this._salesCD2 = string.Empty;
            this._salesName2 = string.Empty;
            this._customerCD = string.Empty;
            this._customerName = string.Empty;
            this._subjectName = string.Empty;
            this._customerAddress1 = string.Empty;
            this._customerAddress2 = string.Empty;
            this._customerAddress3 = string.Empty;
            this._tel = string.Empty;
            this._fax = string.Empty;
            this._contactPerson = string.Empty;
            this._currencyID = 0;
            this._methodVat = 0;

            this._total = 0;
            this._vat = 0;
            this._vatRatio = 0;
            this._vatType = 0;
            this._grandTotal = 0;
            //this._profitRatio = 0;

            this._memo = string.Empty;
            this._newFlag = 0;
            this._issuedDate = new DateTime(1900, 1, 1);
            this._issuedUID = 0;
        }

        /// <summary>
        /// Contructor T_Quotation_H
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Quote_H(DbDataReader dr)
            : base(dr)
        {
            this.QuoteNo = (string)dr["QuoteNo"];
            this._statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
            this._issuedFlag = short.Parse(string.Format("{0}", dr["IssuedFlag"]));
            this._deleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this._quoteDate = (DateTime)dr["QuoteDate"];
            this._expiryDate = (DateTime)dr["ExpiryDate"];
            this._expectedOrderDate = (DateTime)dr["ExpectedOrderDate"];
            this._expectedRevenueDate = (DateTime)dr["ExpectedRevenueDate"];
            this._preparedCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["PreparedCD"], M_User.MAX_USER_CODE_SHOW);
            this._preparedName = (string)dr["PreparedName"];
            this._approvedCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["ApprovedCD"], M_User.MAX_USER_CODE_SHOW);
            this._approvedName = (string)dr["ApprovedName"];
            this._salesCD1 = Utilities.EditDataUtil.ToFixCodeShow((string)dr["SalesCD1"], M_User.MAX_USER_CODE_SHOW);
            this._salesName1 = (string)dr["SalesName1"];
            this._salesCD2 = Utilities.EditDataUtil.ToFixCodeShow((string)dr["SalesCD2"], M_User.MAX_USER_CODE_SHOW);
            this._salesName2 = (string)dr["SalesName2"];
            this._customerCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this._customerName = (string)dr["CustomerName"];
            this._subjectName = (string)dr["SubjectName"];
            this._customerAddress1 = (string)dr["CustomerAddress1"];
            this._customerAddress2 = (string)dr["CustomerAddress2"];
            this._customerAddress3 = (string)dr["CustomerAddress3"];
            this._tel = (string)dr["Tel"];
            this._fax = (string)dr["FAX"];
            this._contactPerson = (string)dr["ContactPerson"];
            this._currencyID = (int)dr["CurrencyID"];
            this._methodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));

            this._total = (decimal)dr["Total"];
            this._vat = (decimal)dr["Vat"];
            this._vatRatio = (decimal)dr["VatRatio"];
            this._vatType = short.Parse(string.Format("{0}", dr["VatType"]));
            this._grandTotal = (decimal)dr["GrandTotal"];
            //this._profitRatio = (decimal)dr["ProfitRatio"];
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            this._approved = (string)dr["Approved"];
            this._position = (string)dr["Position"];
            // ---------------------- End  -------------------------------
            this._memo = (string)dr["Memo"];
            this._newFlag = short.Parse(string.Format("{0}", dr["NewFlag"]));
            this._issuedDate = (DateTime)dr["IssuedDate"];
            this._issuedUID = (int)dr["IssuedUID"];
        }
        #endregion
    }
}

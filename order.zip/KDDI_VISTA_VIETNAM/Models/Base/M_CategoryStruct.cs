﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class M_CategoryStruct Models
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class M_CategoryStruct : M_Base<M_CategoryStruct>
    {
        #region Vatiable

        /// <summary>
        /// Category children ID
        /// </summary>
        private int _categoryId;

        /// <summary>
        /// Category Parent ID
        /// </summary>
        private int _categoryStructId;

        /// <summary>
        /// Level
        /// </summary>
        private int level;

        /// <summary>
        /// Number Order
        /// </summary>
        private int numberOrder;

        #endregion

        #region Property

        /// <summary>
        /// Get or set Category Children ID
        /// </summary>
        public int CategoryID
        {
            get { return this._categoryId; }
            set
            {
                if (value != this._categoryId)
                {
                    this._categoryId = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Category Parent ID
        /// </summary>
        public int CategoryStructID
        {
            get { return this._categoryStructId; }
            set
            {
                if (value != this._categoryStructId)
                {
                    this._categoryStructId = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Level
        /// </summary>
        public int Level
        {
            get { return this.level; }
            set
            {
                if (value != this.level)
                {
                    this.level = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Number Order
        /// </summary>
        public int NumberOrder
        {
            get { return this.numberOrder; }
            set
            {
                if (value != this.numberOrder)
                {
                    this.numberOrder = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor Category Struct class
        /// </summary>
        public M_CategoryStruct()
            : base()
        {
        }

        /// <summary>
        /// Contructor Category Struc class
        /// </summary>
        /// <param name="dr"></param>
        public M_CategoryStruct(DbDataReader dr)
            : base(dr)
        {
            this._categoryId = (int)dr["CategoryID"];
            this._categoryStructId = (int)dr["CategoryStructID"];
            this.level = (int)dr["Level"];
            this.numberOrder = (int)dr["NumberOrder"];
        }

        #endregion
    }
}

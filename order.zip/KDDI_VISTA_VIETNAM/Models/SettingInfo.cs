﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Class SettingInfo
    /// </summary>
    [Serializable]
    public class SettingInfo
    {
        public int ID { get; set; }
        public string QuoteNo { get; set; }
        public string AcceptNo { get; set; }
        public string PurchaseNo { get; set; }
        public string InvoiceNo { get; set; }
        public string ShippingNo { get; set; }
        public string Logo1 { get; set; }
        public string Logo2 { get; set; }

        /// <summary>
        /// Constructor class SettingInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public SettingInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"]; ;
            this.AcceptNo = (string)dr["AcceptNo"];
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this.InvoiceNo = (string)dr["InvoiceNo"];
            this.ShippingNo = (string)dr["ShippingNo"];
            this.Logo1 = (string)dr["Logo1"];
            this.Logo2 = (string)dr["Logo2"];
        }

        /// <summary>
        /// Constructor class SettingInfo
        /// </summary>
        public SettingInfo()
        {
            this.QuoteNo = string.Empty;
            this.AcceptNo = string.Empty;
            this.PurchaseNo = string.Empty;
            this.InvoiceNo = string.Empty;
            this.ShippingNo = string.Empty;
            this.Logo1 = string.Empty;
            this.Logo2 = string.Empty;
        }
    }
}

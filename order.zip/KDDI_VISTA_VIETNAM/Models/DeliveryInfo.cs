﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Class Delivery Info
    /// </summary>
    //public class DeliveryInfo
    //{
    //    /// <summary>
    //    /// ShippingNo
    //    /// </summary>
    //    public string ShippingNo { get; set; }

    //    /// <summary>
    //    /// QuoteNo
    //    /// </summary>
    //    public string QuoteNo { get; set; }

    //    /// <summary>
    //    /// AcceptNo
    //    /// </summary>
    //    public string AcceptNo { get; set; }

    //    /// <summary>
    //    /// Get or set DeliveryDate
    //    /// </summary>
    //    public DateTime DeliveryDate { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerCD
    //    /// </summary>
    //    public string CustomerCD { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerName
    //    /// </summary>
    //    public string CustomerName { get; set; }

    //    /// <summary>
    //    /// Get or set ContactPerson
    //    /// </summary>
    //    public string ContactPerson { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerAddress1
    //    /// </summary>
    //    public string CustomerAddress1 { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerAddress2
    //    /// </summary>
    //    public string CustomerAddress2 { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerAddress3
    //    /// </summary>
    //    public string CustomerAddress3 { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerTel
    //    /// </summary>
    //    public string CustomerTel { get; set; }

    //    /// <summary>
    //    /// Get or set CustomerFax
    //    /// </summary>
    //    public string CustomerFax { get; set; }

    //    /// <summary>
    //    /// Get or set Subject
    //    /// </summary>
    //    public string Subject { get; set; }

    //    /// <summary>
    //    /// Get or set ExchangeRateID
    //    /// </summary>
    //    public string ExchangeRateID { get; set; }

    //    /// <summary>
    //    /// Get or set Status
    //    /// </summary>
    //    public string Status { get; set; }

    //    /// <summary>
    //    /// Ger or set List DeliveryDetailInfo
    //    /// </summary>
    //    public IList<DeliveryDetailInfo> Details { get; set; }

    //    public DeliveryInfo Clone()
    //    {
    //        return (DeliveryInfo)base.MemberwiseClone();
    //    }
    //}


    /// <summary>
    /// Class DeliveryDetailInfo
    /// </summary>
    [Serializable]
    public class DeliveryDetailInfo
    {
        /// <summary>
        /// Get or set InternalID
        /// </summary>
        public int InternalID { get; set; }

        ///// <summary>
        ///// Get or set NoDisp
        ///// </summary>
        //public int NoDisp { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set SalesSellID
        /// </summary>
        public int SalesSellID { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public short VatType { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set Delivery Quantity
        /// </summary>
        public decimal? DeliveryQuantity { get; set; }

        /// <summary>
        /// Get or set Delivery Date
        /// </summary>
        public DateTime? DeliveryDate { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set UnitPrice
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Remain Quantity
        /// </summary>
        public decimal? RemainQty { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }
        
        /// <summary>
        /// Get or set VAT
        /// </summary>
        public decimal? VAT { get; set; }
        
        /// <summary>
        /// Get or set Remark
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// Checked
        /// </summary>
        public bool Checked { get; set; }

        /// <summary>
        /// Serial Empty Flg
        /// </summary>
        public bool SerialEmptyFlg { get; set; }

        /// <summary>
        /// Ger or set SerialList
        /// </summary>
        public IList<SerialInfo> SerialList { get; set; }

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
           
            if (string.IsNullOrEmpty(this.ProductCD) &&
                string.IsNullOrEmpty(this.ProductName) &&
                string.IsNullOrEmpty(this.Description) &&
                !this.UnitPrice.HasValue &&
                !this.Quantity.HasValue &&
                this.UnitID == Constant.DEFAULT_ID &&
                !this.DeliveryQuantity.HasValue &&
                ((this.DeliveryDate == DateTime.MinValue) || this.DeliveryDate == null) &&
                string.IsNullOrEmpty(this.Remark) &&
                !this.Total.HasValue &&
                !this.VAT.HasValue &&
                this.SerialEmptyFlg
                )
            {
                return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Serial Info
    /// </summary>
    [Serializable]
    public class SerialInfo
    {
        public int No { get; set; }
        public int DeliveryID { get; set; }
        public int DetailNo { get; set; }
        public string SerialNo { get; set; }
        public short ContractType { get; set; }
        public decimal? Terms { get; set; }
        public int? TermUnit { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? FinishDate { get; set; }

        public string Collapsed { get; set; }

        /// <summary>
        /// Check Empty Item
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty(short defaultContractType)
        {
            if (string.IsNullOrEmpty(this.SerialNo) &&
                this.ContractType == defaultContractType &&
                (!this.TermUnit.HasValue || this.TermUnit == (int)WarrantyUnit.None) &&
                !this.Terms.HasValue &&
                ((this.StartDate == DateTime.MinValue) || this.StartDate == null) &&
                ((this.FinishDate == DateTime.MinValue) || this.FinishDate == null)
                )
            {
                return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Class Delivery Header Search
    /// </summary>
    [Serializable]
    public class DeliveryHeaderSearch
    {
        /// <summary>
        /// DeliveryNo
        /// </summary>
        public string DeliveryNo { get; set; }

        /// <summary>
        /// QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// AcceptNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Delivery Date From
        /// </summary>
        public DateTime? DeliveryDateFrom { get; set; }

        /// <summary>
        /// Delivery Date To
        /// </summary>
        public DateTime? DeliveryDateTo { get; set; }

        /// <summary>
        /// DelivererName
        /// </summary>
        public string DelivererName { get; set; }

        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// PreparedCD
        /// </summary>
        public string PreparedCD { get; set; }

        /// <summary>
        /// Subject
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// DeliveryPlace
        /// </summary>
        public string DeliveryPlace { get; set; }

        /// <summary>
        /// SerialNo
        /// </summary>
        public string SerialNo { get; set; }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public short FinishFlag { get; set; }
        public string FinishName { get; set; }

        /// <summary>
        /// InvalidFlag
        /// </summary>
        public short InvalidFlag { get; set; }
        public string InvalidName { get; set; }
    }

    /// <summary>
    /// Class Delivery Header Result Search
    /// </summary>
    [Serializable]
    public class DeliveryHeaderResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// ShippingNo
        /// </summary>
        public string DeliveryNo { get; set; }

        /// <summary>
        /// QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// DeliveryDate
        /// </summary>
        public DateTime DeliveryDate { get; set; }

        /// <summary>
        /// CustomerNm
        /// </summary>
        public string CustomerNm { get; set; }
        
        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        public short DecimalType { get; set; }
        public string Currency { get; set; }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public short FinishFlag { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// <summary>
        /// DeliveryDate String
        /// </summary>
        public string DeliveryDateStr { get; set; }

        /// <summary>
        /// Delivery Quantity
        /// </summary>
        public decimal DeliveryQuantity { get; set; }

        public decimal GrandTotal { get; set; }
        //public string GrandTotalStr { get; set; }
        //public string QuantityStr { get; set; }

        /// <summary>
        /// color
        /// </summary>
        public int Color { get; set; }

        public string ArrivalText { get; set; }

        /// <summary>
        /// Contructor class DeliveryHeaderResult
        /// </summary>
        public DeliveryHeaderResult()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.DeliveryNo = string.Empty;
            this.SalesNo = string.Empty;
            this.QuoteNo = string.Empty;
            this.DeliveryDate = DateTime.MinValue;
            this.DeliveryDateStr = string.Empty;
            this.CustomerNm = string.Empty;            
            this.SubjectName = string.Empty;
            this.DecimalType = 0;
            this.Currency = string.Empty;
            this.FinishFlag = 0;
            this.DeleteFlag = 0;
            //this.GrandTotalStr = string.Empty;
            //this.QuantityStr = string.Empty;
            this.Color = -1;
            this.ArrivalText=string.Empty;
         }

        /// <summary>
        /// Contructor class DeliveryHeaderResult
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public DeliveryHeaderResult(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.QuoteNo = (string)dr["QuoteNo"];                        
            this.SubjectName = (string)dr["SubjectName"];
            this.CustomerNm = (string)dr["CustomerName"];
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            this.Currency = (dr["Currency"] != DBNull.Value) ? (string)dr["Currency"] : string.Empty;
            this.Quantity = dr["Quantity"] == DBNull.Value ? 0 : (decimal)dr["Quantity"];

            //FinishFlag
            this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));

            //if (dr["DecimalType"] != DBNull.Value)
            //{
            //    this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
            //    if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
            //    {
            //        //this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
            //        this.QuantityStr = this.Quantity.ToString(Constants.FMT_DECIMAL);
            //    }
            //    else
            //    {
            //        //this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
            //        this.QuantityStr = this.Quantity.ToString(Constants.FMT_INTEGER);
            //    }
            //}

            this.DeliveryDate = (DateTime)dr["DeliveryDate"];
            this.DeliveryDateStr = this.DeliveryDate.ToString(Constants.FMT_DATE);

            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
                if ((int)this.DeleteFlag == (int)Models.DeleteFlag.Deleted)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }

            //ExpiryDate
            if (dr["ExpiryDate"] != DBNull.Value && (DateTime)dr["ExpiryDate"] != DEFAULT_DATE_TIME)
            {
                if (((DateTime)dr["ExpiryDate"] < DateTime.Now.Date) && ((int)this.FinishFlag == (int)Models.FinishedFlag.NotFinish) && this.Color == -1)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }

            this.DeliveryQuantity = dr["DeliveryQuantity"] == DBNull.Value ? 0 : (decimal)dr["DeliveryQuantity"];
            
            if (this.DeliveryQuantity == 0)
            {
                this.ArrivalText = "<span class='label label-white' style='width:70px; display: inline-block'>" + "Delivery" + "</span>";
                
            }
            else if (this.DeliveryQuantity < this.Quantity)
            {
                this.ArrivalText = "<span class='label label-master' style='width:70px; display: inline-block'>" + "Delivery" + "</span>";
            }
            else if (this.DeliveryQuantity == this.Quantity)
            {
                this.ArrivalText = "<span class='label label-delivery' style='width:70px; display: inline-block'>" + "Delivery" + "</span>";
            }
        }
    }

    /// <summary>
    /// Class DeliveryExcel
    /// </summary>
    [Serializable]
    public class DeliveryExcel
    {
        public int ID { get; set; }
        public string DeliveryNo { get; set; }//Deli No.
        public string SalesNo { get; set; }
        public string QuoteNo { get; set; }

        public DateTime DeliveryDate { get; set; }//Deli Date
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string SubjectName { get; set; }
        public string DeliveryPlace { get; set; }
        public decimal Total { get; set; }
        public string Currency { get; set; }
        public decimal Vat { get; set; }
        public string MethodVatName { get; set; }
        public decimal GrandTotal { get; set; }

        public string DeliveredName { get; set; }
        public string PreparedName { get; set; }
        public string ApprovedName { get; set; }

        public short DeleteFlag { get; set; }
        public short FinishFlag { get; set; }
        public DateTime ExpiryDate { get; set; }      
        public string ExpiryDateStr { get; set; }
        
        public string Memo { get; set; }
       
        //public string TotalStr { get; set; }
        //public string VatStr { get; set; }
        //public string GrandTotalStr { get; set; }
        public string DeliveryDateStr { get; set; }//Deli Date
        public short DecimalType { get; set; }

        /// <summary>
        /// Contructor class DeliveryExcel
        /// </summary>
        public DeliveryExcel()
        {
            this.ID = 0;
            this.DeliveryNo = string.Empty;
            this.SalesNo = string.Empty;
            this.QuoteNo = string.Empty;

            this.DeliveryDate = DateTime.MinValue;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.SubjectName = string.Empty;
            this.DeliveryPlace = string.Empty;
            this.Total = 0;
            this.Currency = string.Empty;
            this.Vat = 0;
            this.MethodVatName = string.Empty;
            this.GrandTotal = 0;

            this.DeliveredName = string.Empty;
            this.PreparedName = string.Empty;
            this.ApprovedName = string.Empty;

            this.DeleteFlag = 0;
            this.FinishFlag = 0;
            this.ExpiryDate = DateTime.MinValue;
            this.ExpiryDateStr = string.Empty;
            
            this.Memo = string.Empty;

            //this.TotalStr = string.Empty;
            //this.VatStr = string.Empty;
            //this.GrandTotalStr = string.Empty;

            this.DeliveryDateStr = string.Empty;
            this.DecimalType = 0;
        }

        /// <summary>
        /// Constructor class DeliveryExcel
        /// </summary>
        /// <param name="dr"></param>
        public DeliveryExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.QuoteNo = (string)dr["QuoteNo"];

            if (dr["DeliveryDate"] != DBNull.Value)
            {
                this.DeliveryDate = (DateTime)dr["DeliveryDate"];
                this.DeliveryDateStr = this.DeliveryDate.ToString(Constants.FMT_DATE);
            }

            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];

            this.SubjectName = (string)dr["SubjectName"];
            this.DeliveryPlace = (string)dr["DeliveryPlace"];
            this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                //}
            }

            if (dr["MethodVatName"] != DBNull.Value)
            {
                this.MethodVatName = (string)dr["MethodVatName"];
            }

            this.DeliveredName = (string)dr["DeliveredName"];
            this.PreparedName = (string)dr["PreparedName"];
            this.ApprovedName = (string)dr["ApprovedName"];
            
            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            }

            if (dr["ExpiryDate"] != DBNull.Value)
            {
                this.ExpiryDate = (DateTime)dr["ExpiryDate"];
                this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);
            }     

            if (dr["FinishFlag"] != DBNull.Value)
            {
                this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            }            

            this.Memo = (string)dr["Memo"];
        }
    }

    /// <summary>
    /// Class CreateDeliveryExcel
    /// ISV-Nguyen
    /// </summary>
    [Serializable]
    public class CreateDeliveryExcel
    {
        public int ID { get; set; }
        public string DeliveryNo { get; set; }
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }

        public DateTime DeliveryDate { get; set; }
        public DateTime DeliveryDateItem { get; set; }
        public string ProductName { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public decimal SalesQuantity { get; set; }
        public decimal Quantity { get; set; }
        //public string SalesQuantityStr { get; set; }
        public string DelivererName { get; set; }
        public string DeliveryDateStr { get; set; }
        public string DeliveryDateItemStr { get; set; }
        public string SalesDateStr { get; set; }
        //public string QuantityStr { get; set; }

        /// <summary>
        /// Contructor class DeliveryListExcel
        /// </summary>
        public CreateDeliveryExcel()
        {
            this.ID = 0;
            this.DeliveryNo = string.Empty;
            this.SalesNo = string.Empty;

            this.DeliveryDate = DateTime.MinValue;
            this.DeliveryDateItem = DateTime.MinValue;
            this.SalesDate = DateTime.MinValue;
            this.Quantity = 0;
            this.SalesQuantity = 0;
            //this.SalesQuantityStr = string.Empty;

            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.ProductName = string.Empty;
            this.SalesDateStr = string.Empty;
            this.DeliveryDateItemStr = string.Empty;
            this.DeliveryDateStr = string.Empty;
            this.DelivererName = string.Empty;
        }

        /// <summary>
        /// Constructor class PurchaseExcel
        /// </summary>
        /// <param name="dr"></param>
        public CreateDeliveryExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.ProductName = (string)dr["ProductName"];

            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.SalesQuantity = dr["SalesQuantity"] != DBNull.Value ? (decimal)dr["SalesQuantity"] : 0;

            this.DeliveryDate = (DateTime)dr["DeliveryDate"];
            this.DeliveryDateStr = this.DeliveryDate.ToString(Constants.FMT_DATE);

            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }

            if (dr["DeliveryDateItem"] != DBNull.Value)
            {
                this.DeliveryDateItem = (DateTime)dr["DeliveryDateItem"];
                this.DeliveryDateItemStr = this.DeliveryDateItem.ToString(Constants.FMT_DATE);
            }

            this.DelivererName = (string)dr["DelivererName"];
        }
    }

    /// <summary>
    /// Class UncreateDeliveryExcel
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class UncreateDeliveryExcel
    {
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }
        public string SalesDateStr { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string ProductName { get; set; }
        public decimal Quantity { get; set; }
       // public string QuantityStr { get; set; }
        public decimal UnitPrice { get; set; }
        //public string UnitPriceStr { get; set; }
        public short DecimalType { get; set; }
        public string Currency { get; set; }
        public decimal SubTotal { get; set; }
        //public string SubTotalStr { get; set; }

        /// <summary>
        /// Contructor class UncreateDeliveryExcel
        /// </summary>
        public UncreateDeliveryExcel()
        {
            this.SalesNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.ProductName = string.Empty;
            this.Quantity = 0;
            //this.QuantityStr = string.Empty;
            this.UnitPrice = 0;
            //this.UnitPriceStr = string.Empty;
            this.DecimalType = 0;
            this.Currency = string.Empty;
            this.SubTotal = 0;
            //this.SubTotalStr = string.Empty;
        }

        /// <summary>
        /// Constructor class UncreateDeliveryExcel
        /// </summary>
        /// <param name="dr"></param>
        public UncreateDeliveryExcel(DbDataReader dr)
        {
            this.SalesNo = (string)dr["SalesNo"];
            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.ProductName = (string)dr["ProductName"];
            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;

            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            this.SubTotal = dr["SubTotal"] != DBNull.Value ? (decimal)dr["SubTotal"] : 0;


            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_DECIMAL);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_INTEGER);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_INTEGER);
                //}
            }
        }
    }

    [Serializable]
    public class DeliverySelectInfo
    {
        /// <summary>
        /// Checked flag
        /// </summary>
        public bool CheckFlag { get; set; }

        /// <summary>
        /// Accept sell intenalID
        /// </summary>
        public int SalesSellID { get; set; }
        
        /// <summary>
        /// No
        /// </summary>
        public int No { get; set; }
        
        /// <summary>
        /// Remain Quatity
        /// </summary>
        public decimal? RemainQty { get; set; }

        /// <summary>
        /// Delivery Quantity
        /// </summary>
        public decimal? DeliveryQty { get; set; }
        
        /// <summary>
        /// Accept Quantity
        /// </summary>
        public decimal? SalesQty { get; set; }

        /// <summary>
        /// Product code
        /// </summary>
        public string ProductCD { get; set; }
        
        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Unit Price
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Get, set VATPercent
        /// </summary>
        public decimal VATPercent { get; set; }

        /// <summary>
        /// Get, set VATFlag
        /// </summary>
        public VATFlg VATFlag { get; set; }

        //------2014/12/12 ISV-HUNG Add Start----------//
        /// <summary>
        /// Get, set VATFlag
        /// </summary>
        public string VATFlagStr
        {
            get;
            set;
        }
        //------2014/12/12 ISV-HUNG Add End----------//

        /// <summary>
        /// Contructor
        /// </summary>
        public DeliverySelectInfo()
        { 
        }

        /// <summary>
        /// Contructor with DataReader
        /// </summary>
        /// <param name="dr"></param>
        public DeliverySelectInfo(DbDataReader dr)
        {
            this.SalesSellID = (int)dr["SalesSellID"];
            this.No = (int)dr["No"];
            this.RemainQty = decimal.Parse(dr["RemainQty"].ToString());
            this.DeliveryQty = (decimal)dr["DeliveryQty"];
            this.SalesQty = (decimal)dr["SalesQty"];
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.UnitPrice = (decimal)dr["UnitPrice"];
            this.Currency = (string)dr["Currency"];
            this.VATPercent = (decimal)dr["VATPercent"];
            this.VATFlag = (VATFlg)(byte)dr["VatType"];
            //------2014/12/12 ISV-HUNG Add Start----------//
            this.VATFlagStr = (string)dr["VATFlagStr"];
            //------2014/12/12 ISV-HUNG Add End----------//
        }
    }

    /// <summary>
    /// Delivery Product Search Model
    /// </summary>
    [Serializable]
    public class DeliveryProductSearchModel : BaseSearch
    {
        /// <summary>
        /// Gets or sets the Delivery date FRM.
        /// </summary>
        /// <value>
        /// The Delivery date FRM.
        /// </value>
        public DateTime? DeliveryDateFrm { get; set; }

        /// <summary>
        /// Gets or sets the Delivery date to.
        /// </summary>
        /// <value>
        /// The Delivery date to.
        /// </value>
        public DateTime? DeliveryDateTo { get; set; }

        /// <summary>
        /// Gets or sets the category i d1.
        /// </summary>
        /// <value>
        /// The category i d1.
        /// </value>
        public int CategoryID1 { get; set; }
        /// <summary>
        /// Gets or sets the category i d2.
        /// </summary>
        /// <value>
        /// The category i d2.
        /// </value>
        public int CategoryID2 { get; set; }
        /// <summary>
        /// Gets or sets the category i d3.
        /// </summary>
        /// <value>
        /// The category i d3.
        /// </value>
        public int CategoryID3 { get; set; }
        /// <summary>
        /// Gets or sets the product cd.
        /// </summary>
        /// <value>
        /// The product cd.
        /// </value>
        public string ProductCD { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the unit price FRM.
        /// </summary>
        /// <value>
        /// The unit price FRM.
        /// </value>
        public decimal? UnitPriceFrm { get; set; }

        /// <summary>
        /// Gets or sets the unit price to.
        /// </summary>
        /// <value>
        /// The unit price to.
        /// </value>
        public decimal? UnitPriceTo { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets the customer cd.
        /// </summary>
        /// <value>
        /// The customer cd.
        /// </value>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the currency identifier.
        /// </summary>
        /// <value>
        /// The currency identifier.
        /// </value>
        public int CurrencyID { get; set; }
    }

    /// <summary>
    /// Delivery Product Search Result
    /// </summary>
    [Serializable]
    public class DeliveryProductSearchResult
    {
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string CustomerInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.CustomerCD, this.CustomerName);
            }
        }
        public int CurrencyID { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string DeliveryDateStr
        {
            get
            {
                return this.DeliveryDate.ToString(Constants.FMT_DATE);
            }
        }
        public string DeliveryNo { get; set; }
        public int InternalID { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string ProductInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.ProductCD, this.ProductName);
            }
        }
        public string MoneyCode { get; set; }
        public int DecimalType { get; set; }
        public decimal UnitPrice { get; set; }
        public string UnitPriceStr
        {
            get
            {
                string span = string.Empty;
                if (this.UnitPrice >= 0)
                {
                    span = "<span>{0}</span>";
                }
                else
                {
                    span = "<span class='negative-num'>{0}</span>";
                }
                return string.Format(span, this.UnitPrice.ToString(this.DecimalType > 0 ? "N2" : "N0"));
            }
        }

        public int RowNumber { get; set; }

        #region Contructor
        public DeliveryProductSearchResult()
        {
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.CurrencyID = 0;
            this.DeliveryDate = CommonUtil.GetDefaultDate();
            this.DeliveryNo = string.Empty;
            this.InternalID = 0;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.MoneyCode = string.Empty;
            this.DecimalType = 0;
            this.UnitPrice = 0;
            this.RowNumber = 0;
        }

        public DeliveryProductSearchResult(DbDataReader dr)
        {
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.CurrencyID = (int)dr["CurrencyID"];
            this.DeliveryDate = (DateTime)dr["DeliveryDate"];
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.InternalID = (int)dr["InternalID"];
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.MoneyCode = (string)dr["MoneyCode"];
            this.DecimalType = (byte)dr["DecimalType"];
            this.UnitPrice = (decimal)dr["UnitPrice"];
            this.RowNumber = Convert.ToInt32(dr["RowNumber"]);
        }
        #endregion
    }

    /// <summary>
    /// Delivery Contract Period Result
    /// </summary>
    [Serializable]
    public class ContractPeriodSearch
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime? StartDateFrom { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime? EndDateFrom { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime? EndDateTo { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime? StartDateTo { get; set; }

        /// <summary>
        /// Gets or sets the Contract Type.
        /// </summary>
        /// <value>
        /// The Contract Type.
        /// </value>
        public short ContractType { get; set; }

        /// <summary>
        /// Gets or sets the Contract Type.
        /// </summary>
        /// <value>
        /// The Contract Type.
        /// </value>
        public string ContractTypeName { get; set; }
    }


    /// <summary>
    /// Delivery Contract Period Result
    /// </summary>
    [Serializable]
    public class ContractPeriodResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        public int Id { get; set; }

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the Delivery date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public DateTime DeliveryDate{get;set;}

         /// <summary>
        /// Gets or sets the Sales date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public DateTime SalesDate{get;set;}

        /// <summary>
        /// Gets or sets the Sales date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public string SalesDateStr{get;set;}

        /// <summary>
        /// Gets or sets the Delivery date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public string DeliveryDateStr{get;set;}

        /// <summary>
        /// Gets or sets the Delivery No.
        /// </summary>
        /// <value>
        /// The Delivery No.
        /// </value>
        public string DeliveryNo{get;set;}

        /// <summary>
        /// Gets or sets the Sales No.
        /// </summary>
        /// <value>
        /// The Sales No.
        /// </value>
        public string SalesNo{get;set;}

        /// <summary>
        /// Gets or sets the Contract Type.
        /// </summary>
        /// <value>
        /// The Contract Type.
        /// </value>
        public string ContractType{get;set;}


        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime StartDate{get;set;}

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public string StartDateStr{get;set;}

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime EndDate{get;set;}

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public string EndDateStr{get;set;}

        /// <summary>
        /// FormDetailName
        /// </summary>
        public string FormDetailName { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public int Color { get; set; }

         /// <summary>
        /// Contructor
        /// </summary>
        public ContractPeriodResult()
        {
            this.RowNumber = 0;
            this.Id = 0;
            this.Color = -1;
            this.ProductName = string.Empty;
            this.CustomerName = string.Empty;
            this.DeliveryNo = string.Empty;
            this.DeliveryDate = DateTime.MinValue;
            this.DeliveryDateStr = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartDateStr = string.Empty;
            this.EndDate = DateTime.MinValue;
            this.EndDateStr = string.Empty;
            this.ContractType = string.Empty;
            this.FormDetailName = string.Empty;
        }

         /// <summary>
        /// Contructor with DataReader
        /// </summary>
        /// <param name="dr"></param>
        public ContractPeriodResult(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.Id = (int)Convert.ChangeType(dr["ID"], this.Id.GetType());
            this.ProductName = (string)dr["ProductName"];
            this.CustomerName = (string)dr["CustomerName"];

            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.DeliveryDate = (DateTime)dr["DeliveryDate"];
            if (this.DeliveryDate!=null&&this.DeliveryDate != DEFAULT_DATE_TIME)
            {
                this.DeliveryDateStr = this.DeliveryDate.ToString(Constants.FMT_DATE);
            }
            else
            {
                this.DeliveryDateStr = string.Empty;
            }

            this.SalesNo = string.Format("{0}", dr["SalesNo"]);
            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
            }
            if (this.SalesDate != null && this.SalesDate != DEFAULT_DATE_TIME)
            {
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
            else
            {
                this.SalesDateStr = string.Empty;
            }

            if (!string.IsNullOrEmpty(this.SalesNo))
            {
                this.FormDetailName = "~/Sales/FrmSalesDetail.aspx";
            }
            else
            {
                this.FormDetailName = "~/Delivery/FrmDeliveryDetail.aspx";
                this.SalesNo = this.DeliveryNo;
                this.SalesDateStr = this.DeliveryDateStr;
            }

            this.StartDate = dr["StartDate"] != DBNull.Value ? (DateTime)dr["StartDate"] : DEFAULT_DATE_TIME;
            if (this.StartDate != DEFAULT_DATE_TIME)
            {
                this.StartDateStr = this.StartDate.ToString(Constants.FMT_DATE);
            }

            this.EndDate = dr["FinishDate"] != DBNull.Value ? (DateTime)dr["FinishDate"] : DEFAULT_DATE_TIME;
            if (this.EndDate != DEFAULT_DATE_TIME)
            {
                this.EndDateStr = this.EndDate.ToString(Constants.FMT_DATE);
            }

            this.ContractType = (string)dr["ContractType"];

            this.Color = -1;
            // EndDate
            if (dr["FinishDate"] != DBNull.Value && (DateTime)dr["FinishDate"] != DEFAULT_DATE_TIME)
            {
                if (((DateTime)dr["FinishDate"] < DateTime.Now.Date))
                {
                    this.Color = (int)ColorList.Danger;
                }

                var sDate = DateTime.Now.Date;
                var eDate = sDate.AddMonths(1);
                if (this.EndDate.CompareTo(sDate) >= 0
                    && this.EndDate.CompareTo(eDate) < 0)
                {
                    this.Color = (int)ColorList.Warning;
                }

                //if (DateTime.Now.Date <= (DateTime)dr["FinishDate"] && (DateTime)dr["FinishDate"] < DateTime.Now.AddMonths(+1).Date)
                //{
                //    this.Color = (int)ColorList.Warning;
                //}
            }
        }
    }






    /// <summary>
    /// Delivery Contract Period Result
    /// </summary>
    [Serializable]
    public class ContractPeriodExcel
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// Gets or sets the name of the product.
        /// </summary>
        /// <value>
        /// The name of the product.
        /// </value>
        public string ProductName { get; set; }

        /// <summary>
        /// Gets or sets the name of the customer.
        /// </summary>
        /// <value>
        /// The name of the customer.
        /// </value>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets the Delivery date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public DateTime DeliveryDate { get; set; }

        /// <summary>
        /// Gets or sets the Sales date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public DateTime SalesDate { get; set; }

        /// <summary>
        /// Gets or sets the Sales date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public string SalesDateStr { get; set; }

        /// <summary>
        /// Gets or sets the Delivery date.
        /// </summary>
        /// <value>
        /// The Delivery date.
        /// </value>
        public string DeliveryDateStr { get; set; }

        /// <summary>
        /// Gets or sets the Delivery No.
        /// </summary>
        /// <value>
        /// The Delivery No.
        /// </value>
        public string DeliveryNo { get; set; }

        /// <summary>
        /// Gets or sets the Sales No.
        /// </summary>
        /// <value>
        /// The Sales No.
        /// </value>
        public string SalesNo { get; set; }

        /// <summary>
        /// Gets or sets the Contract Type.
        /// </summary>
        /// <value>
        /// The Contract Type.
        /// </value>
        public string ContractType { get; set; }


        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public string StartDateStr { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public DateTime EndDate { get; set; }

        /// <summary>
        /// Gets or sets The Contract Expired.
        /// </summary>
        /// <value>
        /// The Contract Expired.
        /// </value>
        public string EndDateStr { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public int Color { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public ContractPeriodExcel()
        {
            this.ProductName = string.Empty;
            this.CustomerName = string.Empty;
            this.DeliveryNo = string.Empty;
            this.DeliveryDate = DateTime.MinValue;
            this.DeliveryDateStr = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartDateStr = string.Empty;
            this.EndDate = DateTime.MinValue;
            this.EndDateStr = string.Empty;
            this.ContractType = string.Empty;
        }

        /// <summary>
        /// Contructor with DataReader
        /// </summary>
        /// <param name="dr"></param>
        public ContractPeriodExcel(DbDataReader dr)
        {
            this.ProductName = (string)dr["ProductName"];
            this.CustomerName = (string)dr["CustomerName"];
            this.DeliveryNo = (string)dr["DeliveryNo"];
            this.SalesNo = dr["SalesNo"]!=DBNull.Value?(string)dr["SalesNo"]:string.Empty;

            this.DeliveryDate = (DateTime)dr["DeliveryDate"];
            if (this.DeliveryDate != null && this.DeliveryDate != DEFAULT_DATE_TIME)
            {
                this.DeliveryDateStr = this.DeliveryDate.ToString(Constants.FMT_DATE);
            }
            else
            {
                this.DeliveryDateStr = string.Empty;
            }
            this.SalesDate = dr["SalesDate"] != DBNull.Value ? (DateTime)dr["SalesDate"] : DEFAULT_DATE_TIME;
            if (this.SalesDate != null && this.SalesDate != DEFAULT_DATE_TIME)
            {
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
            else
            {
                this.SalesDateStr = string.Empty;
            }

            this.StartDate = dr["StartDate"] != DBNull.Value ? (DateTime)dr["StartDate"] : DEFAULT_DATE_TIME;
            if (this.StartDate != DEFAULT_DATE_TIME)
            {
                this.StartDateStr = this.StartDate.ToString(Constants.FMT_DATE);
            }

            this.EndDate = dr["FinishDate"] != DBNull.Value ? (DateTime)dr["FinishDate"] : DEFAULT_DATE_TIME;
            if (this.EndDate != DEFAULT_DATE_TIME)
            {
                this.EndDateStr = this.EndDate.ToString(Constants.FMT_DATE);
            }

            this.ContractType = (string)dr["ContractType"];

            this.Color = -1;
            // EndDate
            if (dr["FinishDate"] != DBNull.Value && (DateTime)dr["FinishDate"] != DEFAULT_DATE_TIME)
            {
                if (((DateTime)dr["FinishDate"] < DateTime.Now.Date))
                {
                    this.Color = (int)ColorList.Danger;
                }

                if (DateTime.Now.Date <= (DateTime)dr["FinishDate"] && (DateTime)dr["FinishDate"] < DateTime.Now.AddMonths(+1).Date)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }
        }
    }
}

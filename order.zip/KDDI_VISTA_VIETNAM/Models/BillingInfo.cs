﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Class BillingHeaderSearch
    /// Created by: ISV-GIAM
    /// </summary>
    [Serializable]
    public class BillingHeaderSearch
    {
        /// <summary>
        /// BillingNo
        /// </summary>
        public string BillingNo { get; set; }

        /// <summary>
        /// SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// BillingDateFrom
        /// </summary>
        public DateTime? BillingDateFrom { get; set; }

        /// <summary>
        /// BillingDateTo
        /// </summary>
        public DateTime? BillingDateTo { get; set; }

        /// <summary>
        /// CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// PreparedCD
        /// </summary>
        public string PreparedCD { get; set; }

        /// <summary>
        /// Deleted Flag
        /// </summary>
        public short DeletedFlg { get; set; }

        /// <summary>
        /// Deleted Flag Name
        /// </summary>
        public string DeletedName { get; set; }

        /// <summary>
        /// Finished Flag
        /// </summary>
        public short FinishedFlg { get; set; }

        /// <summary>
        /// Finished Flag Name
        /// </summary>
        public string FinishedName { get; set; }
    }

    [Serializable]
    public class BillingHeaderResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// GrandTotal
        /// </summary>
        public decimal GrandTotal { get; set; }

        /// <summary>
        /// BillingDate
        /// </summary>
        public DateTime BillingDate { get; set; }

        /// <summary>
        /// BillingNo
        /// </summary>
        public string BillingNo { get; set; }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// <summary>
        /// StatusFlag
        /// </summary>
        public short StatusFlag { get; set; }

        /// <summary>
        /// BillingDateStr
        /// </summary>
        public string BillingDateStr { get; set; }

        /// <summary>
        /// GrandTotalStr
        /// </summary>
        public string GrandTotalStr { get; set; }

        /// <summary>
        /// DecimalType
        /// </summary>
        public short DecimalType { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public int Color { get; set; }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public short FinishFlag { get; set; }

        /// <summary>
        /// DepositText
        /// </summary>
        public string DepositText { get; set; }

        /// <summary>
        /// TotalDeposit
        /// </summary>
        public decimal TotalDeposit { get; set; }

        /// <summary>
        /// Contructor class BillingHeaderResult
        /// </summary>
        public BillingHeaderResult()
        {
            this.RowNumber=0;
            this.ID =0;
            this.SalesNo =string.Empty;
            this.CustomerName=string.Empty;
            this.SubjectName =string.Empty;
            this.Currency=string.Empty;            
            this.GrandTotal = 0;
            this.BillingDate = DateTime.MinValue;
            this.BillingNo=string.Empty;
            this.DeleteFlag=0;
            this.StatusFlag=0;
            this.BillingDateStr=string.Empty;
            this.GrandTotalStr = string.Empty;
            this.DecimalType=0;
            this.Color=-1;
        }

        /// <summary>
        /// Constructor class BillingHeaderResult
        /// </summary>
        /// <param name="dr"></param>
        public BillingHeaderResult(DbDataReader dr)
        {
            //Color
            this.Color = -1;

            //RowNumber
            this.RowNumber = (long)dr["RowNumber"];

            //ID
            this.ID = int.Parse(dr["ID"].ToString());

            //SalesNo
            this.SalesNo = (string)dr["SalesNo"];

            //CustomerName
            this.CustomerName = (string)dr["CustomerName"];

            //SubjectName
            this.SubjectName = (string)dr["SubjectName"];

            //Currency
            this.Currency = (string)dr["Currency"];

            //GrandTotal
            this.GrandTotal = (decimal)dr["GrandTotal"];

            //TotalDeposit
            this.TotalDeposit = (decimal)dr["TotalDeposit"];

            //Total Format
            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                }
                else
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                }
            }

            //BillingDate
            this.BillingDate = (DateTime)dr["BillingDate"];
            this.BillingDateStr = this.BillingDate.ToString(Constants.FMT_DATE);

            //BillingNo
            this.BillingNo = (string)dr["BillingNo"];
            
            //FinishFlag
            this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));

            //DeleteFlag
            this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
                if ((int)this.DeleteFlag == (int)Models.DeleteFlag.Deleted)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }

            //ExpiryDate
            if (dr["ExpiryDate"] != DBNull.Value && (DateTime)dr["ExpiryDate"] != DEFAULT_DATE_TIME)
            {
                if (((DateTime)dr["ExpiryDate"] < DateTime.Now.Date) && ((int)this.FinishFlag == (int)Models.FinishedFlag.NotFinish) && this.Color == -1)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }
        }
    }

    /// <summary>
    /// Class BillingExcel
    /// </summary>
    [Serializable]
    public class BillingExcel
    {
        public int ID { get; set; }
        public string BillingNo { get; set; }
        public string QuoteNo { get; set; }
        public string SalesNo { get; set; }
        public DateTime BillingDate { get; set; }
        public string BillingDateStr { get; set; }
        public string CustomerName { get; set; }
        public string SubjectName { get; set; }
        public decimal Total { get; set; }
        //public string TotalStr { get; set; }
        public string Currency { get; set; }
        public decimal Vat { get; set; }
        //public string VatStr { get; set; }
        public string MethodVatName { get; set; }
        public decimal GrandTotal { get; set; }
        //public string GrandTotalStr { get; set; }
        public string PreparedName { get; set; }
        public string ApprovedName { get; set; }
        public string Memo { get; set; }
        public short DeleteFlag { get; set; }
        public short FinishFlag { get; set; }        
        public DateTime ExpiryDate { get; set; }        
        public string ExpiryDateStr { get; set; }        
        public short DecimalType { get; set; }
        
        /// <summary>
        /// Contructor class BillingExcel
        /// </summary>
        public BillingExcel()
        {
            this.ID = 0;
            this.BillingNo = string.Empty;
            this.QuoteNo = string.Empty;
            this.SalesNo = string.Empty;
            this.DeleteFlag = 0;
            this.Currency = string.Empty;
            this.ExpiryDate = DateTime.MinValue;
            this.PreparedName = string.Empty;
            this.ApprovedName = string.Empty;
            this.SubjectName = string.Empty;
            this.CustomerName = string.Empty;
            this.Total = 0;
            this.Vat = 0;
            this.GrandTotal = 0;
            this.Memo = string.Empty;
            //this.TotalStr = string.Empty;
            //this.VatStr = string.Empty;
            //this.GrandTotalStr = string.Empty;
            this.BillingDateStr = string.Empty;
            this.ExpiryDateStr = string.Empty;
            this.DecimalType = 0;
            this.MethodVatName = string.Empty;
        }

        /// <summary>
        /// Constructor class BillingExcel
        /// </summary>
        /// <param name="dr"></param>
        public BillingExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            BillingNo = (string)dr["BillingNo"];
            this.QuoteNo = (string)dr["QuoteNo"];
            this.SalesNo = (string)dr["SalesNo"];

            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            }

            if (dr["FinishFlag"] != DBNull.Value)
            {
                this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            }

            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            if (dr["BillingDate"] != DBNull.Value)
            {
                this.BillingDate = (DateTime)dr["BillingDate"];
                this.BillingDateStr = this.BillingDate.ToString(Constants.FMT_DATE);
            }
            if (dr["ExpiryDate"] != DBNull.Value)
            {
                this.ExpiryDate = (DateTime)dr["ExpiryDate"];
                this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);
            }            
            this.PreparedName = (string)dr["PreparedName"];
            this.ApprovedName = (string)dr["ApprovedName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.CustomerName = (string)dr["CustomerName"];
            this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            this.Memo = (string)dr["Memo"];

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                //}
            }

            if (dr["MethodVatName"] != DBNull.Value)
            {
                this.MethodVatName = (string)dr["MethodVatName"];
            }
        }
    }

    /// <summary>
    /// Class CreateBillingExcel
    /// ISV-Nguyen
    /// </summary>
    [Serializable]
    public class CreateBillingExcel
    {
        public int ID { get; set; }
        //public string QuoteNo { get; set; }
        public string BillingNo { get; set; }
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }

        public DateTime BillingDate { get; set; }
        public string ProductName { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string Currency { get; set; }

        public decimal VatTotal { get; set; }
        public decimal Vat { get; set; }
        //public string VatStr { get; set; }

        public decimal VatRatioTotal { get; set; }
        public decimal VatRatio { get; set; }
        //public string VatRatioStr { get; set; }

        public short MethodVat { get; set; }
        public short VatTypeTotal { get; set; }
        public short VatType { get; set; }
        public string VatTypeName { get; set; }

        public string BillingDateStr { get; set; }
        public string SalesDateStr { get; set; }
        public short DecimalType { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public decimal SubTotal { get; set; }
        //public string UnitPriceStr { get; set; }
        //public string QuantityStr { get; set; }
        //public string SubTotalStr { get; set; }
        //public string VatRatioTotalStr { get; set; }
        //public string VatTotalStr { get; set; }

        /// <summary>
        /// Contructor class DeliveryListExcel
        /// </summary>
        public CreateBillingExcel()
        {
            this.ID = 0;
            this.BillingNo = string.Empty;
            this.SalesNo = string.Empty;

            this.BillingDate = DateTime.MinValue;
            this.SalesDate = DateTime.MinValue;

            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.Currency = string.Empty;
            this.ProductName = string.Empty;
            this.SalesDateStr = string.Empty;
            this.DecimalType = 0;
            this.VatRatioTotal = 0;
            //this.VatRatioTotalStr = string.Empty;
            this.VatRatio = 0;
            //this.VatRatioStr = string.Empty;
            this.VatTypeName = string.Empty;
            this.VatTypeTotal = 0;
            this.VatTotal = 0;

            this.UnitPrice = 0;
            this.Quantity = 0;
            this.SubTotal = 0;
            this.MethodVat = 0;
            this.VatType = 0;
            this.VatTypeName = string.Empty;
            //this.UnitPriceStr = string.Empty;
            //this.QuantityStr = string.Empty;
            //this.SubTotalStr = string.Empty;
            //this.VatTotalStr = string.Empty;
        }

        /// <summary>
        /// Constructor class PurchaseExcel
        /// </summary>
        /// <param name="dr"></param>
        public CreateBillingExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.BillingNo = (string)dr["BillingNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.ProductName = (string)dr["ProductName"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;
            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.SubTotal = dr["SubTotal"] != DBNull.Value ? (decimal)dr["SubTotal"] : 0;
            this.VatRatio = dr["VatRatio"] != DBNull.Value ? (decimal)dr["VatRatio"] : 0;
            this.VatRatioTotal = dr["VatRatioTotal"] != DBNull.Value ? (decimal)dr["VatRatioTotal"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;

            if (dr["MethodVat"] != DBNull.Value)
            {
                this.MethodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            }

            if (dr["VatType"] != DBNull.Value)
            {
                this.VatType = short.Parse(string.Format("{0}", dr["VatType"]));
            }

            if (dr["VatTypeTotal"] != DBNull.Value)
            {
                this.VatTypeTotal = short.Parse(string.Format("{0}", dr["VatTypeTotal"]));
            }

            this.VatTypeName = dr["VatTypeName"] != DBNull.Value ? (string)dr["VatTypeName"] : string.Empty;

            //this.VatRatioTotalStr = this.VatRatioTotal.ToString(Constants.FMT_INTEGER);

            //this.VatRatioStr = this.VatRatio.ToString(Constants.FMT_INTEGER);


            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    //this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_DECIMAL);
                    //this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_DECIMAL);
                    //this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                }
                else
                {
                    //this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_INTEGER);
                    //this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_INTEGER);
                    //this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                }
            }

            this.BillingDate = (DateTime)dr["BillingDate"];
            this.BillingDateStr = this.BillingDate.ToString(Constants.FMT_DATE);

            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
        }
    }

    /// <summary>
    /// Class UncreateBillingExcel
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class UncreateBillingExcel
    {
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }
        public string SalesDateStr { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName { get; set; }
        public string ProductName { get; set; }
        public decimal Quantity { get; set; }
        //public string QuantityStr { get; set; }
        public decimal UnitPrice { get; set; }
        //public string UnitPriceStr { get; set; }
        public short DecimalType { get; set; }
        public string Currency { get; set; }
        public decimal SubTotal { get; set; }
        //public string SubTotalStr { get; set; }
        public decimal VatRatio { get; set; }
        //public string VatRatioStr { get; set; }
        public decimal VatRatioTotal { get; set; }
        //public string VatRatioTotalStr { get; set; }
        public decimal Vat { get; set; }
        public decimal VatTotal { get; set; }
        //public string VatStr { get; set; }
        //public string VatTotalStr { get; set; }
        public short VatTypeTotal { get; set; }
        public short MethodVat { get; set; }
        public short VatType { get; set; }
        public string VatTypeName { get; set; }

        /// <summary>
        /// Contructor class UncreateBillingExcel
        /// </summary>
        public UncreateBillingExcel()
        {
            this.SalesNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.ProductName = string.Empty;
            this.Quantity = 0;
            //this.QuantityStr = string.Empty;
            this.UnitPrice = 0;
            //this.UnitPriceStr = string.Empty;
            this.DecimalType = 0;
            this.Currency = string.Empty;
            this.SubTotal = 0;
            //this.SubTotalStr = string.Empty;
            this.VatRatio = 0;
            //this.VatRatioStr = string.Empty;
            this.VatRatioTotal = 0;
            //this.VatRatioTotalStr = string.Empty;
            this.Vat = 0;
            this.VatTotal = 0;
           // this.VatStr = string.Empty;
           // this.VatTotalStr = string.Empty;
            this.MethodVat = 0;
            this.VatType = 0;
            this.VatTypeTotal = 0;
            this.VatTypeName = string.Empty;
        }

        /// <summary>
        /// Constructor class UncreateBillingExcel
        /// </summary>
        /// <param name="dr"></param>
        public UncreateBillingExcel(DbDataReader dr)
        {
            this.SalesNo = (string)dr["SalesNo"];
            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.ProductName = (string)dr["ProductName"];
            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.SubTotal = dr["SubTotal"] != DBNull.Value ? (decimal)dr["SubTotal"] : 0;
            this.VatRatio = dr["VatRatio"] != DBNull.Value ? (decimal)dr["VatRatio"] : 0;
            //this.VatRatioStr = this.VatRatio.ToString(Constants.FMT_INTEGER);
            this.VatRatioTotal = dr["VatRatioTotal"] != DBNull.Value ? (decimal)dr["VatRatioTotal"] : 0;
           // this.VatRatioTotalStr = this.VatRatioTotal.ToString(Constants.FMT_INTEGER);
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;

            if (dr["MethodVat"] != DBNull.Value)
            {
                this.MethodVat = short.Parse(string.Format("{0}", dr["MethodVat"]));
            }

            if (dr["VatType"] != DBNull.Value)
            {
                this.VatType = short.Parse(string.Format("{0}", dr["VatType"]));
            }
            this.VatTypeName = dr["VatTypeName"] != DBNull.Value ? (string)dr["VatTypeName"] : string.Empty;

            if (dr["VatTypeTotal"] != DBNull.Value)
            {
                this.VatTypeTotal = short.Parse(string.Format("{0}", dr["VatTypeTotal"]));
            }

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_DECIMAL);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_INTEGER);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //}
            }
        }
    }

    /// <summary>
    /// Class BillingDetailInfo
    /// Create Date: 2014/12/17
    /// Create Author: ISV-GIAM
    /// </summary>
    [Serializable]
    public class BillingDetailInfo
    {
        /// <summary>
        /// Get or set InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// Get or set HID
        /// </summary>
        public int HID { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set SalesSellID
        /// </summary>
        public int SalesSellID { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public int VATType { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set Price
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set RemarkQuantity
        /// </summary>
        public decimal? RemainQuantity { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }
        
        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Get or set Profit
        /// </summary>
        public decimal? Profit { get; set; }

        /// <summary>
        /// Get or set Remark
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// Checked flag
        /// </summary>
        public bool CheckFlag { get; set; }
    }
}

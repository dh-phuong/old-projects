﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Product Info Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class ProductInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public Utilities.ProductType Type { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string CategoryName1 { get; set; }
        public string CategoryName2 { get; set; }
        public string CategoryName3 { get; set; }
        //public decimal UnitPrice { get; set; }
        public decimal UnitPriceSell { get; set; }
        public decimal UnitPriceCost { get; set; }
        //public string Currency { get; set; }

        public string CurrencySell { get; set; }
        public string CurrencyCost { get; set; }

        //public string VendorCD { get; set; }
        //public string VendorName { get; set; }
        public short DecimalTypeSell { get; set; }
        public short DecimalTypeCost { get; set; }

        public int StatusFlag { get; set; }
        public int Color { get; set; }
        
        public string UnitPriceSellString
        {
            get
            {
                string span1 = string.Empty;
                if (this.UnitPriceSell >= 0)
                {
                    span1 = "<span>{0}</span>&nbsp;<span>{1}</span>";
                }
                else
                {
                    span1 = "<span class='negative-num'>{0}</span>&nbsp;<span>{1}</span>";
                }                

                return string.Format(span1, this.UnitPriceSell.ToString(this.DecimalTypeSell > 0 ? "N2" : "N0")
                                                              , this.CurrencySell);
            }
        }

        public string UnitPriceCostString
        {
            get
            {
                string span2 = string.Empty;
                if (this.UnitPriceCost >= 0)
                {
                    span2 = "<span>{0}</span>&nbsp;<span>{1}</span>";
                }
                else
                {
                    span2 = "<span class='negative-num'>{0}</span>&nbsp;<span>{1}</span>";
                }

                return string.Format(span2, this.UnitPriceCost.ToString(this.DecimalTypeCost > 0 ? "N2" : "N0")
                                                              , this.CurrencyCost);
            }
        }

        /// <summary>
        /// Constructor Class ProductInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ProductInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.Type = (Utilities.ProductType)int.Parse(dr["Type"].ToString());
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.CategoryName1 = string.Format("{0}", dr["CategoryName1"]);
            this.CategoryName2 = string.Format("{0}", dr["CategoryName2"]);
            this.CategoryName3 = string.Format("{0}", dr["CategoryName3"]);
            //this.VendorCD = EditDataUtil.ToFixCodeShow(string.Format("{0}", dr["VendorCD"]),M_Vendor.VENDOR_CODE_MAX_SHOW);
            //this.VendorName = string.Format("{0}", dr["VendorName"]);
            this.DecimalTypeSell = short.Parse(dr["DecimalTypeSell"].ToString());
            this.DecimalTypeCost = short.Parse(dr["DecimalTypeCost"].ToString());

            this.UnitPriceSell = decimal.Parse(dr["UnitPriceSell"].ToString());
            this.UnitPriceCost = decimal.Parse(dr["UnitPriceCost"].ToString());

            this.CurrencySell = string.Format("{0}", dr["CurrencySell"]);
            this.CurrencyCost = string.Format("{0}", dr["CurrencyCost"]);

            this.StatusFlag = int.Parse(dr["StatusFlag"].ToString());
            this.Color = -1;
            if (this.StatusFlag ==(int)DeleteFlag.Deleted)
            {
                this.Color = (int)ColorList.Danger;
            }
        }

        /// <summary>
        /// Constructor class ProductInfo
        /// </summary>
        public ProductInfo()
        {
            this.Color = -1;
            this.RowNumber = 0;
            this.ID = 0;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.CategoryName1 = string.Empty;
            this.CategoryName2 = string.Empty;
            this.CategoryName3 = string.Empty;
            //this.UnitPrice = 0;
            //this.Currency = string.Empty;
            //this.VendorCD = string.Empty;
            //this.VendorName = string.Empty;
            //this.DecimalType = 0;
        }
    }

    /// <summary>
    /// Product Search Info Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class ProductSearchInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public Utilities.ProductType Type { get; set; }
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string CategoryName1 { get; set; }
        public string CategoryName2 { get; set; }
        public string CategoryName3 { get; set; }
        public string VendorCD { get; set; }
        public string VendorName { get; set; }        
        private decimal UnitPriceSell { get; set; }
        private decimal UnitPriceCost { get; set; }
        public string UnitPrice
        {
            get
            {
                string span1 = string.Empty;
                if (this.UnitPriceSell >= 0)
                {
                    span1 = "<span>{0}</span>&nbsp;<span>{1}</span>";
                }
                else
                {
                    span1 = "<span class='negative-num'>{0}</span>&nbsp;<span>{1}</span>";
                }

                string span2 = string.Empty;
                if (this.UnitPriceCost >= 0)
                {
                    span2 = "<span>{2}</span>&nbsp;<span>{3}</span>";
                }
                else
                {
                    span2 = "<span class='negative-num'>{2}</span>&nbsp;<span>{3}</span>";
                }

                return string.Format(span1 +
                                         "</br>" +
                                        span2, this.UnitPriceSell.ToString(this.DecimalTypeSell > 0 ? "N2" : "N0")
                                                              , this.MoneyCodeSell
                                                              , this.UnitPriceCost.ToString(this.DecimalTypeCost > 0 ? "N2" : "N0")
                                                              , this.MoneyCodeCost);
            }
        }

        private string MoneyCodeSell { get; set; }
        private string MoneyCodeCost { get; set; }
        

        private int DecimalTypeSell { get; set; }
        private int DecimalTypeCost { get; set; }


        /// <summary>
        /// Constructor Class ProductSearchInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ProductSearchInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.Type = (Utilities.ProductType)int.Parse(dr["Type"].ToString());
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.CategoryName1 = string.Format("{0}", dr["CategoryName1"]);
            this.CategoryName2 = string.Format("{0}", dr["CategoryName2"]);
            this.CategoryName3 = string.Format("{0}", dr["CategoryName3"]);
            this.VendorCD = string.Format("{0}", dr["VendorCD"]);
            this.VendorName = string.Format("{0}", dr["VendorName"]);
            this.UnitPriceSell = (decimal)dr["UnitPriceSell"];
            this.UnitPriceCost = (decimal)dr["UnitPriceCost"];            
            this.MoneyCodeSell = (string)dr["MoneyCodeSell"];
            this.MoneyCodeCost = (string)dr["MoneyCodeCost"];
            this.DecimalTypeSell = (byte)dr["DecimalTypeSell"];
            this.DecimalTypeCost = (byte)dr["DecimalTypeCost"];
        }

        /// <summary>
        /// Constructor class ProductSearchInfo
        /// </summary>
        public ProductSearchInfo()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.CategoryName1 = string.Empty;
            this.CategoryName2 = string.Empty;
            this.CategoryName3 = string.Empty;
            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
        }
    }

    /// <summary>
    /// Product Class For Excel 
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class ProductExcel
    {
        public string ProductCD { get; set; }
        public string ProductName { get; set; }
        public string CategoryName1 { get; set; }
        public string CategoryName2 { get; set; }
        public string CategoryName3 { get; set; }
        public short Type { get; set; }
        
        //Sell information
        public string DescriptionSell { get; set; }
        public string CurrencySell { get; set; }
        public decimal UnitPriceSell { get; set; }
        //public string UnitPriceSellStr { get; set; }
        public string UnitSellName { get; set; }
        public string VatTypeSell { get; set; }
        public decimal VatRatioSell { get; set; }
        public string RemarkSell { get; set; }
        public short DecimalTypeSell { get; set; }

        //Cost information
        public string DescriptionCost { get; set; }
        public string CurrencyCost { get; set; }
        public decimal UnitPriceCost { get; set; }
        //public string UnitPriceCostStr { get; set; }
        public string UnitCostName { get; set; }
        public string VatTypeCost { get; set; }
        public decimal VatRatioCost { get; set; }
        public string RemarkCost { get; set; }
        public short PurchaseFlag { get; set; }
        public short DecimalTypeCost { get; set; }
        public string VendorCD1 { get; set; }
        public string VendorName1 { get; set; }
        public string VendorCD2 { get; set; }
        public string VendorName2 { get; set; }
        public string VendorCD3 { get; set; }
        public string VendorName3 { get; set; }
        public string VendorProductCD1 { get; set; }
        public string VendorProductCD2 { get; set; }
        public string VendorProductCD3 { get; set; }

        public short StatusFlag { get; set; }

        /// <summary>
        /// Constructor class product excel
        /// </summary>
        public ProductExcel()
        {
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.CategoryName1 = string.Empty;
            this.CategoryName2 = string.Empty;
            this.CategoryName3 = string.Empty;
            this.Type = 0;
        
            //Sell information
            this.DescriptionSell = string.Empty;
            this.CurrencySell = string.Empty;
            this.UnitPriceSell = 0;
            //this.UnitPriceSellStr = string.Empty;
            this.UnitSellName = string.Empty;
            this.VatTypeSell = string.Empty;
            this.VatRatioSell = 0;
            this.RemarkSell = string.Empty;

            //Cost information
            this.DescriptionCost = string.Empty;
            this.CurrencyCost = string.Empty;
            this.UnitPriceCost = 0;
            //this.UnitPriceCostStr = string.Empty;
            this.UnitCostName = string.Empty;
            this.VatTypeCost = string.Empty;
            this.VatRatioCost = 0;
            this.RemarkCost = string.Empty;
            this.PurchaseFlag = 0;
            this.DecimalTypeSell = 0;
            this.DecimalTypeCost = 0;
            this.VendorCD1 = string.Empty;
            this.VendorName1 = string.Empty;
            this.VendorProductCD1 = string.Empty;
            this.VendorCD2 = string.Empty;
            this.VendorName2 = string.Empty;
            this.VendorProductCD2 = string.Empty;
            this.VendorCD3 = string.Empty;
            this.VendorName3 = string.Empty;
            this.VendorProductCD3 = string.Empty;

            this.StatusFlag = 0;
        }

        /// <summary>
        /// Constructor class product excel
        /// </summary>
        /// <param name="dr">Database Data reader</param>
        public ProductExcel(DbDataReader dr)
        {
            this.ProductCD = string.Format("{0}", dr["ProductCD"]);
            this.ProductName = string.Format("{0}", dr["ProductName"]);
            this.CategoryName1 = string.Format("{0}", dr["CategoryName1"]);
            this.CategoryName2 = string.Format("{0}", dr["CategoryName2"]);
            this.CategoryName3 = string.Format("{0}", dr["CategoryName3"]);
            this.Type = short.Parse(string.Format("{0}", dr["Type"]));
            //Sell information
            this.DescriptionSell = string.Format("{0}", dr["DescriptionSell"]);
            this.CurrencySell = string.Format("{0}", dr["CurrencySell"]);
            this.UnitPriceSell = decimal.Parse(string.Format("{0}", dr["UnitPriceSell"]));
            this.UnitSellName = string.Format("{0}", dr["UnitSellName"]);
            this.VatTypeSell = string.Format("{0}", dr["VatTypeSell"]);
            this.VatRatioSell = decimal.Parse(string.Format("{0}", dr["VatRatioSell"]));
            this.RemarkSell = string.Format("{0}", dr["RemarkSell"]);
            if (dr["DecimalTypeSell"] != DBNull.Value)
            {
                this.DecimalTypeSell = short.Parse(string.Format("{0}", dr["DecimalTypeSell"]));
                //if ((int)this.DecimalTypeSell == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceSellStr = this.UnitPriceSell.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceSellStr = this.UnitPriceSell.ToString(Constants.FMT_INTEGER);
                //}
            }

            //Cost information
            this.DescriptionCost = string.Format("{0}", dr["DescriptionCost"]);
            this.CurrencyCost = string.Format("{0}", dr["CurrencyCost"]);
            this.UnitPriceCost = decimal.Parse(string.Format("{0}", dr["UnitPriceCost"]));
            this.UnitCostName = string.Format("{0}", dr["UnitCostName"]);
            this.VatTypeCost = string.Format("{0}", dr["VatTypeCost"]);
            this.VatRatioCost = decimal.Parse(string.Format("{0}", dr["VatRatioCost"]));
            this.RemarkCost = string.Format("{0}", dr["RemarkCost"]);
            this.PurchaseFlag = short.Parse(string.Format("{0}", dr["PurchaseFlag"]));
            if (dr["DecimalTypeCost"] != DBNull.Value)
            {
                this.DecimalTypeCost = short.Parse(string.Format("{0}", dr["DecimalTypeCost"]));
                //if ((int)this.DecimalTypeCost == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceCostStr = this.UnitPriceCost.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceCostStr = this.UnitPriceCost.ToString(Constants.FMT_INTEGER);
                //}
            }
            this.VendorCD1 = string.Format("{0}", dr["VendorCD1"]);
            this.VendorName1 = string.Format("{0}", dr["VendorName1"]);
            this.VendorProductCD1 = string.Format("{0}", dr["VendorProductCD1"]);
            this.VendorCD2 = string.Format("{0}", dr["VendorCD2"]);
            this.VendorName2 = string.Format("{0}", dr["VendorName2"]);
            this.VendorProductCD2 = string.Format("{0}", dr["VendorProductCD2"]);
            this.VendorCD3 = string.Format("{0}", dr["VendorCD3"]);
            this.VendorName3 = string.Format("{0}", dr["VendorName3"]);
            this.VendorProductCD3 = string.Format("{0}", dr["VendorProductCD3"]);


            this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
        }
    }
}

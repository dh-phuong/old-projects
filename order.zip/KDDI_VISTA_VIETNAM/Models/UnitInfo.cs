﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// UnitInfo
    /// </summary>
    [Serializable]
    public class UnitInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string UnitName { get; set; }

        /// <summary>
        /// Constructor class UnitInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public UnitInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.UnitName = (string)dr["UnitName"]; 
        }
        
        /// <summary>
        /// Constructor class CustomerInfo
        /// </summary>
        public UnitInfo()
        {
            this.RowNumber = 0;
            this.UnitName = string.Empty;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.Common;

using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Class SalesHeaderSearch
    /// Create Author: ISV-TRAM
    /// </summary>
    [Serializable]
    public class SalesHeaderSearch
    {
        /// <summary>
        /// Get or set SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Get or set QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// Get or set SalesDateFrom
        /// </summary>
        public DateTime? SalesDateFrom { get; set; }

        /// <summary>
        /// Get or set SalesDateTo
        /// </summary>
        public DateTime? SalesDateTo { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// Get or set PreparedCD
        /// </summary>
        public string PreparedCD { get; set; }

        /// <summary>
        /// Get or set Sale1CD
        /// </summary>
        public string Sale1CD { get; set; }

        /// <summary>
        /// Get or set Sale2CD
        /// </summary>
        public string Sale2CD { get; set; }

        /// <summary>
        ///Get or set  Failed Flag
        /// </summary>
        public short FailedFlg { get; set; }
        public string FailedName { get; set; }

        /// <summary>
        /// Get or set Finished Flag
        /// </summary>
        public short FinishedFlg { get; set; }
        public string FinishedName { get; set; }
    }

    /// <summary>
    /// Class SalesHeaderResult
    /// ISV-TRAM
    /// </summary>
    [Serializable]
    public class SalesHeaderResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Get or set QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// Get or set SalesDate
        /// </summary>
        public DateTime SalesDate { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Get or set SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// Get or set GrandTotal
        /// </summary>
        public decimal GrandTotal { get; set; }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Get or set DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// <summary>
        /// Get or set StatusFlag
        /// </summary>
        public short StatusFlag { get; set; }

        /// <summary>
        /// Get or set FinishFlag
        /// </summary>
        public short FinishFlag { get; set; }

        /// <summary>
        /// Get or set StatusBilling
        /// </summary>
        public short StatusBilling { get; set; }

        /// <summary>
        /// Get or set StatusPO
        /// </summary>
        public short StatusPO { get; set; }

        /// <summary>
        /// Get or set StatusDelivery
        /// </summary>
        public short StatusDelivery { get; set; }

        /// <summary>
        /// Get or set BillingText
        /// </summary>
        public string BillingText { get; set; }

        /// <summary>
        /// Get or set PurchaseText
        /// </summary>
        public string PurchaseText { get; set; }

        /// <summary>
        /// Get or set DeliveryText
        /// </summary>
        public string DeliveryText { get; set; }

        /// <summary>
        /// Get or set SalesDateStr
        /// </summary>
        public string SalesDateStr { get; set; }

        /// <summary>
        /// Get or set GrandTotalStr
        /// </summary>
        public string GrandTotalStr { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public short DecimalType { get; set; }

        /// <summary>
        /// Get or set Color
        /// </summary>
        public int Color { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public SalesHeaderResult()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.SalesNo = string.Empty;
            this.QuoteNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.SubjectName = string.Empty;
            this.GrandTotal = 0;
            this.Currency = string.Empty;
            this.DecimalType = 0;

            this.StatusFlag = 0;
            this.FinishFlag = 0;

            this.StatusBilling = 0;
            this.StatusDelivery = 0;
            this.StatusPO = 0;

            this.SalesDateStr = string.Empty;
            this.GrandTotalStr = string.Empty;
            this.BillingText = string.Empty;
            this.DeliveryText = string.Empty;
            this.PurchaseText = string.Empty;
            this.Color = -1;
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public SalesHeaderResult(DbDataReader dr)
        {
            this.Color = -1;

            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.SalesNo = (string)dr["SalesNo"];
            this.QuoteNo = (string)dr["QuoteNo"];
            this.SalesDate = (DateTime)dr["SalesDate"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
                if ((int)this.StatusFlag == (int)Models.StatusFlag.Lost && this.Color == -1)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }

            this.StatusPO = short.Parse(string.Format("{0}", dr["StatusPO"]));
            this.StatusDelivery = short.Parse(string.Format("{0}", dr["StatusDelivery"]));
            this.StatusBilling = short.Parse(string.Format("{0}", dr["StatusBilling"]));

            this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                }
                else
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                }
            }

            this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));

            //CompleteDate
            if (dr["CompleteDate"] != DBNull.Value && (DateTime)dr["CompleteDate"] != DEFAULT_DATE_TIME)
            {
                if (((DateTime)dr["CompleteDate"] < DateTime.Now.Date) && ((int)this.FinishFlag == (int)Models.FinishedFlag.NotFinish) && this.Color == -1)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }
        }
    }

    /// <summary>
    /// Class SalesProductSearchHeader
    /// </summary>
    [Serializable]
    public class SalesProductSearchHeader
    {
        /// <summary>
        /// Get or set SalesDateFrom
        /// </summary>
        public DateTime? SalesDateFrom { get; set; }

        /// <summary>
        /// Get or set SalesDateTo
        /// </summary>
        public DateTime? SalesDateTo { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Category1
        /// </summary>
        public int CategoryID1 { get; set; }

        /// <summary>
        /// Get or set Category2
        /// </summary>
        public int CategoryID2 { get; set; }

        /// <summary>
        /// Get or set Category3
        /// </summary>
        public int CategoryID3 { get; set; }

        ///// <summary>
        ///// Get or set UnitPrice From
        ///// </summary>
        //public decimal? UnitPriceFrom { get; set; }

        ///// <summary>
        ///// Get or set UnitPrice To
        ///// </summary>
        //public decimal? UnitPriceTo { get; set; }

        ///// <summary>
        ///// Get or set Currency
        ///// </summary>
        //public int Currency { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }
    }

    /// <summary>
    /// Class SalesProductSearchResult
    /// </summary>
    [Serializable]
    public class SalesProductSearchResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set HID
        /// </summary>
        public int HID { get; set; }

        /// <summary>
        /// Get or set InternalSellID
        /// </summary>
        public int InternalSellID { get; set; }

        /// <summary>
        /// Get or set SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Get or set SalesDate
        /// </summary>
        public DateTime SalesDate { get; set; }

        /// <summary>
        /// Get or set SalesDateStr
        /// </summary>
        public string SalesDateStr { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }
        public string ProductInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.ProductCD, this.ProductName);
            }
        }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }
        public string CustomerInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.CustomerCD, this.CustomerName);
            }
        }

        /// <summary>
        /// Get or set UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }
        public string UnitPriceStr
        {
            get
            {
                string span = string.Empty;
                if (this.UnitPrice >= 0)
                {
                    span = "<span>{0}</span>";
                }
                else
                {
                    span = "<span class='negative-num'>{0}</span>";
                }
                return string.Format(span, this.UnitPrice.ToString(this.DecimalType > 0 ? "N2" : "N0"));
            }
        }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public short DecimalType { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public SalesProductSearchResult()
        {
            this.RowNumber = 0;
            this.HID = 0;
            this.InternalSellID = 0;
            this.SalesNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.UnitPrice = 0;
            this.Currency = string.Empty;
            this.DecimalType = 0;
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public SalesProductSearchResult(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.HID = int.Parse(dr["HID"].ToString());
            this.InternalSellID = int.Parse(dr["InternalSellID"].ToString());
            this.SalesNo = (string)dr["SalesNo"];
            this.SalesDate = (DateTime)dr["SalesDate"];
            this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
        }
    }

    /// <summary>
    /// Class SalesDetailInfo
    /// Create Date: 2014/08/05
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class SalesDetailInfo
    {
        /// <summary>
        /// Get or set Checked flag
        /// </summary>
        public bool CheckFlag { get; set; }

        /// <summary>
        /// Ger or set Sell
        /// </summary>
        public SalesSellInfo Sell { get; set; }

        /// <summary>
        /// Ger or set CostList
        /// </summary>
        public IList<SalesCostInfo> CostList { get; set; }
    }

    /// <summary>
    /// Class SalesCostInfo
    /// Create Date: 2014/08/05
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class SalesCostInfo
    {
        /// <summary>
        /// Get or set Collapsed
        /// </summary>
        public string Collapsed { get; set; }

        /// <summary>
        /// Get or set InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// Get or set Sell No
        /// </summary>
        public int SellNo { get; set; }
        public int SellNoDisp { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set Price
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Get or set CurrencyID
        /// </summary>
        public int CurrencyID { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set PurchaseFlag
        /// </summary>
        public bool PurchaseFlag { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public int VatType { get; set; }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }
    }

    /// <summary>
    /// Class SalesSellInfo
    /// Create Date: 2014/08/05
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class SalesSellInfo
    {
        /// <summary>
        /// Get or set Collapsed
        /// </summary>
        public string Collapsed { get; set; }

        /// <summary>
        /// Get or set InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Get or set Price
        /// </summary>
        public decimal? Price { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set Remark
        /// </summary>
        public string Remark { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public int VatType { get; set; }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Get or set Profit
        /// </summary>
        public decimal? Profit { get; set; }
    }

    /// <summary>
    /// Class SalesExcel
    /// </summary>
    [Serializable]
    public class SalesExcel
    {
        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Get or set QuoteNo
        /// </summary>
        public string QuoteNo { get; set; }

        /// <summary>
        /// Get or set SalesDate
        /// </summary>
        public DateTime SalesDate { get; set; }

        /// <summary>
        /// Get or set SalesDateStr
        /// </summary>
        public string SalesDateStr { get; set; }

        /// <summary>
        /// Get or set QuoteDate
        /// </summary>
        public DateTime QuoteDate { get; set; }

        /// <summary>
        /// Get or set QuoteDateStr
        /// </summary>
        public string QuoteDateStr { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// SubjectName
        /// </summary>
        public string SubjectName { get; set; }

        /// <summary>
        /// Get or set Get or set ProfitRatio
        /// </summary>
        public decimal ProfitRatio { get; set; }

        /// <summary>
        /// Get or set ProfitRatioStr
        /// </summary>
        //public string ProfitRatioStr { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal Total { get; set; }

        /// <summary>
        /// Get or set TotalStr
        /// </summary>
        //public string TotalStr { get; set; }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Get or set VatStr
        /// </summary>
        //public string VatStr { get; set; }

        /// <summary>
        /// Get or set MethodVatName
        /// </summary>
        public string MethodVatName { get; set; }

        /// <summary>
        /// Get or set GrandTotal
        /// </summary>
        public decimal GrandTotal { get; set; }

        /// <summary>
        /// Get or set GrandTotalStr
        /// </summary>
        //public string GrandTotalStr { get; set; }

        /// <summary>
        /// Get or set StatusFlagName
        /// </summary>
        public string StatusFlagName { get; set; }

        /// <summary>
        /// Get or set SalesName1
        /// </summary>
        public string SalesName1 { get; set; }

        /// <summary>
        /// Get or set SalesName2
        /// </summary>
        public string SalesName2 { get; set; }

        /// <summary>
        /// Get or set PreparedName
        /// </summary>
        public string PreparedName { get; set; }

        /// <summary>
        /// Get or set ApprovedName
        /// </summary>
        public string ApprovedName { get; set; }

        /// <summary>
        /// Get or set Memo
        /// </summary>
        public string Memo { get; set; }

        /// <summary>
        /// Get or set Vat
        /// </summary>
        public decimal Vat { get; set; }

        /// <summary>
        /// Get or set PreparedCD
        /// </summary>
        public string PreparedCD { get; set; }

        /// <summary>
        /// Get or set ApprovedCD
        /// </summary>
        public string ApprovedCD { get; set; }

        /// <summary>
        /// Get or set CustomerCD
        /// </summary>
        public string CustomerCD { get; set; }

        /// <summary>
        /// Get or set MethodVat
        /// </summary>
        public short MethodVat { get; set; }

        /// <summary>
        /// Get or set DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// <summary>
        /// Get or set StatusFlag
        /// </summary>
        public short StatusFlag { get; set; }

        /// <summary>
        /// Get or set FinishFlag
        /// </summary>
        public short FinishFlag { get; set; }

        /// <summary>
        /// CompleteDate
        /// </summary>
        public DateTime CompleteDate { get; set; }

        /// <summary>
        /// CompleteDateStr
        /// </summary>
        public string CompleteDateStr { get; set; }

        /// <summary>
        /// PaymentDate
        /// </summary>
        public DateTime PaymentDate { get; set; }

        /// <summary>
        /// PaymentDateStr
        /// </summary>
        public string PaymentDateStr { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public short DecimalType { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public SalesExcel()
        {
            this.ID = 0;
            this.SalesNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.QuoteNo = string.Empty;
            this.QuoteDate = DateTime.MinValue;
            this.SalesDate = DateTime.MinValue;
            this.PreparedCD = string.Empty;
            this.PreparedName = string.Empty;
            this.ApprovedCD = string.Empty;
            this.ApprovedName = string.Empty;
            this.SalesName1 = string.Empty;
            this.SalesName2 = string.Empty;
            this.CustomerCD = string.Empty;
            this.CustomerName = string.Empty;
            this.SubjectName = string.Empty;
            this.MethodVat = 0;
            this.DeleteFlag = 0;
            this.StatusFlag = 0;
            this.FinishFlag = 0;
            this.StatusFlagName = string.Empty;
            this.Currency = string.Empty;
            this.DecimalType = 0;
            //this.GrandTotalStr = string.Empty;
            this.MethodVatName = string.Empty;
            this.CompleteDateStr = string.Empty;
            this.PaymentDateStr = string.Empty;
            this.Memo = string.Empty;
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public SalesExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.CustomerName = (string)dr["CustomerName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            //this.ProfitRatio = dr["ProfitRatio"] != DBNull.Value ? (decimal)dr["ProfitRatio"] : 0;
            this.ProfitRatio = EditDataUtil.CalSumProfit((decimal)dr["TotalSell"], (decimal)dr["TotalCost"]);
            if (this.ProfitRatio > Constant.MAX_PROFIT)
            {
                this.ProfitRatio = Constant.MAX_PROFIT;
            }

            
            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                //}
            }

            //this.ProfitRatioStr = this.ProfitRatio.ToString(Constants.FMT_DECIMAL);
            
            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            }

            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
            }

            if (dr["FinishFlag"] != DBNull.Value)
            {
                this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            }

            if (dr["CompleteDate"] != DBNull.Value)
            {
                this.CompleteDate = (DateTime)dr["CompleteDate"];
                this.CompleteDateStr = this.CompleteDate.ToString(Constants.FMT_DATE);
            }
            if (dr["PaymentDate"] != DBNull.Value)
            {
                this.PaymentDate = (DateTime)dr["PaymentDate"];
                this.PaymentDateStr = this.PaymentDate.ToString(Constants.FMT_DATE);
            }

            if (dr["MethodVatName"] != DBNull.Value)
            {
                this.MethodVatName = (string)dr["MethodVatName"];
            }
            this.StatusFlagName = (string)dr["StatusFlagName"];
            this.SalesName1 = (string)dr["SalesName1"];
            this.SalesName2 = (string)dr["SalesName2"];
            this.ApprovedName = (string)dr["ApprovedName"];
            this.PreparedName = (string)dr["PreparedName"];
            this.Memo = (string)dr["Memo"];
            if (dr["QuoteDate"] != DBNull.Value)
            {
                this.QuoteDate = (DateTime)dr["QuoteDate"];
                this.QuoteDateStr = this.QuoteDate.ToString(Constants.FMT_DATE);
            }
            this.SalesDate = (DateTime)dr["SalesDate"];
            this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            this.SalesDate = (DateTime)dr["SalesDate"];
            this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
        }

        ///// <summary>
        ///// CalcProfit
        ///// </summary>
        ///// <param name="totalSell"></param>
        ///// <param name="totalCost"></param>
        ///// <param name="fractionType"></param>
        ///// <returns></returns>
        //private decimal CalcProfit(decimal totalSell, decimal totalCost, FractionType fractionType)
        //{
        //    decimal ret = 0;

        //    //Check  total sell

        //    if (totalSell <= 0)
        //    {
        //        return ret;
        //    }

        //    //calculate profit
        //    ret = Fraction.Round(fractionType, (decimal)((totalSell - totalCost) / totalSell) * 100, 2);

        //    if (ret < 0)
        //    {
        //        ret = 0;
        //    }
        //    return ret;

        //}
    }

    /// <summary>
    /// Billing Selection
    /// </summary>
    [Serializable]
    public class BillingSelection
    {
        #region Variable
        /// <summary>
        /// AccSellInternalID
        /// </summary>
        private int _accSellInternalID;

        /// <summary>
        /// No
        /// </summary>
        private int _no;

        /// <summary>
        /// SelectFlg
        /// </summary>
        private bool _selectFlg;

        /// <summary>
        /// Qty
        /// </summary>
        private decimal? _qty;

        /// <summary>
        /// SalesQty
        /// </summary>
        private decimal _salesQty;

        /// <summary>
        /// BillingQty
        /// </summary>
        private decimal _billingQty;

        /// <summary>
        /// CustomerCD
        /// </summary>
        private string _customerCD;

        /// <summary>
        /// CustomerName
        /// </summary>
        private string _customerName;

        /// <summary>
        /// ProductCD
        /// </summary>
        private string _productCD;

        /// <summary>
        /// ProductName
        /// </summary>
        private string _productName;

        /// <summary>
        /// UnitPrice
        /// </summary>
        private decimal _unitPrice;

        /// <summary>
        /// CurrencyId
        /// </summary>
        private int _currencyId;

        /// <summary>
        /// DecimalType
        /// </summary>
        private ExchangeRateDecType _decimalType;

        /// <summary>
        /// CurrencyName
        /// </summary>
        private string _currencyName;

        /// <summary>
        /// QuoteNo
        /// </summary>
        private string _quoteNo;

        /// <summary>
        /// SalesNo
        /// </summary>
        private string _salesNo;

        /// <summary>
        /// UpdDateSalesH
        /// </summary>
        private DateTime _updDateSalesH;

        /// <summary>
        /// VATFlag
        /// </summary>
        private VATFlg _VATFlag;

        /// <summary>
        /// VATPercent
        /// </summary>
        private decimal _VATPercent;
        #endregion

        #region Property
        /// <summary>
        /// Get or set Color
        /// </summary>
        public string Color { get; set; }

        /// <summary>
        /// Get or set State
        /// </summary>
        public int State { get; set; }

        /// <summary>
        /// Get or set Internal ID
        /// </summary>
        public int SalesSellIntenalID
        {
            get { return this._accSellInternalID; }
            set { this._accSellInternalID = value; }
        }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No
        {
            get { return this._no; }
            set { this._no = value; }
        }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Qty
        {
            get { return this._qty; }
            set { this._qty = value; }
        }

        /// <summary>
        /// Get or set Sales Quantity
        /// </summary>
        public decimal SalesQty
        {
            get { return this._salesQty; }
            set { this._salesQty = value; }
        }

        /// <summary>
        /// Get or set Billing Quantity
        /// </summary>
        public decimal BillingQty
        {
            get { return this._billingQty; }
            set { this._billingQty = value; }
        }

        /// <summary>
        /// Get Remain Qty
        /// </summary>
        public decimal RemainQty
        {
            get
            {
                return this.SalesQty - this.BillingQty;
            }
        }

        /// <summary>
        /// Get or set Select Flag
        /// </summary>
        public bool SelectFlg
        {
            get { return this._selectFlg; }
            set { this._selectFlg = value; }
        }

        /// <summary>
        /// Get or set Customer code
        /// </summary>
        public string CustomerCD
        {
            get { return this._customerCD; }
            set { this._customerCD = value; }
        }

        /// <summary>
        /// Get or set customer Name
        /// </summary>
        public string CustomerName
        {
            get { return this._customerName; }
            set { this._customerName = value; }
        }

        /// <summary>
        /// Get or set product Name
        /// </summary>
        public string ProductCD
        {
            get { return this._productCD; }
            set { this._productCD = value; }
        }

        /// <summary>
        /// Get or set product Name
        /// </summary>
        public string ProductName
        {
            get { return this._productName; }
            set { this._productName = value; }
        }

        /// <summary>
        /// Get or set Unit price VND
        /// </summary>
        public decimal UnitPrice
        {
            get
            {
                return this._unitPrice;
            }
            set { this._unitPrice = value; }
        }

        /// <summary>
        /// Get UnitPrice Display
        /// </summary>
        public string UnitPriceStr
        {
            get
            {
                var format = string.Format("N{0}", this._decimalType == ExchangeRateDecType.Decimal ? 2 : 0);
                return this.UnitPrice.ToString(format);
            }
        }

        /// <summary>
        /// Get or set Currency flag
        /// </summary>
        public int CurrencyID
        {
            get { return this._currencyId; }
            set { this._currencyId = value; }
        }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public string CurrencyName
        {
            get { return this._currencyName; }
            set { this._currencyName = value; }
        }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public ExchangeRateDecType DecimalType
        {
            get { return this._decimalType; }
            set { this._decimalType = value; }
        }

        /// <summary>
        /// Get or set quote No
        /// </summary>
        public string QuoteNo
        {
            get { return this._quoteNo; }
            set { this._quoteNo = value; }
        }

        /// <summary>
        /// Get or set quote No
        /// </summary>
        public string SalesNo
        {
            get { return this._salesNo; }
            set { this._salesNo = value; }
        }

        /// <summary>
        /// Get or set Update date of Sales Header
        /// </summary>
        public DateTime UpdDateSalesH
        {
            get { return this._updDateSalesH; }
            set { this._updDateSalesH = value; }
        }

        /// <summary>
        /// Get or set VATFlag
        /// </summary>
        public VATFlg VATFlag
        {
            get { return this._VATFlag; }
            set { this._VATFlag = value; }
        }

        /// <summary>
        /// Get or set VATFlag
        /// </summary>
        public string VATFlagStr
        {
            get;
            set;
        }

        /// <summary>
        /// Get or set VATPercent
        /// </summary>
        public decimal VATPercent
        {
            get { return this._VATPercent; }
            set { this._VATPercent = value; }
        }
        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        public BillingSelection()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public BillingSelection(DbDataReader dr)
        {
            this._accSellInternalID = (int)dr["SalesSellID"];
            this._salesNo = (string)dr["SalesNo"];
            this._quoteNo = (string)dr["QuoteNo"];
            this._updDateSalesH = (DateTime)dr["UpdDateSalesH"];
            this._salesQty = (decimal)dr["SalesQuantity"];
            this._billingQty = (decimal)dr["InvQuantity"];
            this._customerCD = (string)dr["CustomerCD"];
            this._currencyName = (string)dr["CustomerName"];
            this._productCD = (string)dr["ProductCD"];
            this._productName = (string)dr["ProductName"];
            this._unitPrice = (decimal)dr["UnitPrice"];
            this._currencyId = (int)dr["CurrencyID"];
            this._currencyName = (string)dr["MoneyCode"];
            this._decimalType = (ExchangeRateDecType)(byte)dr["DecimalType"];
            this._VATFlag = (VATFlg)(byte)dr["VatType"];
            this.VATFlagStr = (string)dr["VATFlagStr"];
            this._VATPercent = (decimal)dr["VATPercent"];
            this._no = (int)dr["GridNo"]; ;
        }
    }

    /// <summary>
    /// SalesReportChartByCustomer
    /// </summary>
    [Serializable]
    public class SalesReportChartByCustomer
    {
        /// <summary>
        /// Get or set CustomerCode
        /// </summary>
        public string CustomerCode { get; set; }

        /// <summary>
        /// Get or set CustomerName
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set CurrencyName
        /// </summary>
        public string CurrencyName { get; set; }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public ExchangeRateDecType DecimalType { get; set; }

        /// <summary>
        /// Get TotalStr
        /// </summary>
        public string TotalStr
        {
            get
            {
                var format = string.Format("N{0}", this.DecimalType == ExchangeRateDecType.Decimal ? 2 : 0);
                return this.Total.Value.ToString(format) + " " + this.CurrencyName;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public SalesReportChartByCustomer()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public SalesReportChartByCustomer(DbDataReader dr)
        {
            this.CustomerCode = EditDataUtil.ToFixCodeShow((string)dr["CustomerCode"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName = (string)dr["CustomerName"];
            this.Total = (decimal)dr["Total"];
            this.CurrencyName = (string)dr["CurrencyName"];
        }
    }

    /// <summary>
    /// SalesReportChartBySale
    /// </summary>
    [Serializable]
    public class SalesReportChartBySale
    {
        /// <summary>
        /// Get or set SaleCode
        /// </summary>
        public string SaleCode { get; set; }

        /// <summary>
        /// Get or set SaleName
        /// </summary>
        public string SaleName { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set CurrencyName
        /// </summary>
        public string CurrencyName { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public ExchangeRateDecType DecimalType { get; set; }

        /// <summary>
        /// Get TotalStr
        /// </summary>
        public string TotalStr
        {
            get
            {
                var format = string.Format("N{0}", this.DecimalType == ExchangeRateDecType.Decimal ? 2 : 0);
                return this.Total.Value.ToString(format) + " " + this.CurrencyName;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public SalesReportChartBySale()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dr"></param>
        public SalesReportChartBySale(DbDataReader dr)
        {
            this.SaleCode = EditDataUtil.ToFixCodeShow((string)dr["SaleCode"], M_User.MAX_USER_CODE_SHOW);
            this.SaleName = (string)dr["SaleName"];
            this.Total = (decimal)dr["Total"];
            this.CurrencyName = (string)dr["CurrencyName"];
        }
    }

    /// <summary>
    /// SalesReportChartByCategory
    /// </summary>
    [Serializable]
    public class SalesReportChartByCategory
    {
        /// <summary>
        /// Get or set CategoryCD1
        /// </summary>
        public string CategoryCD1 { get; set; }

        /// <summary>
        /// Get or set CategoryName1
        /// </summary>
        public string CategoryName1 { get; set; }

        /// <summary>
        /// Get or set CategoryCD2
        /// </summary>
        public string CategoryCD2 { get; set; }

        /// <summary>
        /// Get or set CategoryName2
        /// </summary>
        public string CategoryName2 { get; set; }

        /// <summary>
        /// Get or set CategoryCD3
        /// </summary>
        public string CategoryCD3 { get; set; }

        /// <summary>
        /// Get or set CategoryName3
        /// </summary>
        public string CategoryName3 { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// Get or set CurrencyName
        /// </summary>
        public string CurrencyName { get; set; }

        /// <summary>
        /// Get or set CategoryCD
        /// </summary>
        public string CategoryCD { get; set; }

        /// <summary>
        /// Get or set CategoryName
        /// </summary>
        public string CategoryName { get; set; }

        /// <summary>
        /// Get or set indexParent
        /// </summary>
        public int IndexParent { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public ExchangeRateDecType DecimalType { get; set; }

        /// <summary>
        /// Get TotalStr
        /// </summary>
        public string TotalStr
        {
            get
            {
                if (this.Total == null)
                {
                    return string.Empty;
                }
                var format = string.Format("N{0}", this.DecimalType == ExchangeRateDecType.Decimal ? 2 : 0);
                return this.Total.Value.ToString(format) + " " + this.CurrencyName;
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        public SalesReportChartByCategory()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public SalesReportChartByCategory(DbDataReader dr)
        {
            this.CategoryCD1 = (string)dr["CategoryCD1"];
            this.CategoryName1 = (string)dr["CategoryName1"];

            this.CategoryCD2 = (string)dr["CategoryCD2"];
            this.CategoryName2 = (string)dr["CategoryName2"];

            this.CategoryCD3 = (string)dr["CategoryCD3"];
            this.CategoryName3 = (string)dr["CategoryName3"];

            this.Total = (decimal)dr["Total"];
            this.CurrencyName = (string)dr["CurrencyName"];
        }
    }
}
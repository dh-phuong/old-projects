﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Struct Data 
    /// ISV-PHUONG
    /// 2014/08/07
    /// </summary>
    [Serializable]
    public class CategoryStructInfo
    {
        public long Identity { get; set; }

        public int ID { get; set; }

        public int CategoryID { get; set; }

        public int CategoryStructID { get; set; }

        public int Level { get; set; }
        
        public int NumberOrder { get; set; }
        
        public DateTime UpdateDate { get; set; }

        public string CategoryCD { get; set; }

        public string CategoryName { get; set; }

        /// <summary>
        /// 1 : Update
        /// 2 : Insert
        /// </summary>
        public int Status { get; private set; }

        /// <summary>
        /// Constructor class CategoryInfo
        /// </summary>
        public CategoryStructInfo()
        {
            //New
            this.Status = 2;

            this.Identity = (DateTime.Now.Ticks * -1);
        }

        /// <summary>
        /// Constructor class CategoryInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CategoryStructInfo(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.Identity = this.ID;

            this.CategoryID = (int)dr["CategoryID"];
            this.CategoryStructID = (int)dr["CategoryStructID"];
            this.Level = (int)dr["Level"];
            this.NumberOrder = (int)dr["NumberOrder"];
            this.UpdateDate = (DateTime)dr["UpdateDate"];

            this.CategoryCD = (string)dr["CategoryCD"];
            this.CategoryName = (string)dr["CategoryName"];

            //Update
            this.Status = 1;
        }
    }
}

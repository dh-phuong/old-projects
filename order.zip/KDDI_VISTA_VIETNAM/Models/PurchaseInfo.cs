﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Class PurchaseHeaderSearch
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class PurchaseHeaderSearch
    {
        public string PurchaseNo { get; set; }
        public string SalesNo { get; set; }
        public string QuoteNo { get; set; }
        public DateTime? PurchaseDateFrom { get; set; }
        public DateTime? PurchaseDateTo { get; set; }
        public string VendorCD { get; set; }
        public string SubjectName { get; set; }
        public string PreparedCD { get; set; }
        public string PreparedName { get; set; }
        public short FinishedFlag { get; set; }
        public string FinishedName { get; set; }
        public short DeletedFlag { get; set; }
        public string DeletedName { get; set; }
    }

    /// <summary>
    /// Class PurchaseHeaderResult
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class PurchaseHeaderResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string QuoteNo { get; set; }
        public string PurchaseNo { get; set; }
        public string SalesNo { get; set; }

        public string VendorCD { get; set; }
        public string VendorName { get; set; }
        public string SubjectName { get; set; }
        public string PreparedCD { get; set; }
        public string PreparedName { get; set; }

        public short DecimalType { get; set; }
        public string Currency { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string PurchaseDateStr { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string ExpiryDateStr { get; set; }
        public DateTime PaymentDate { get; set; }

        public string InchargeName { get; set; }
        public string ApprovedName { get; set; }

        public short FinishedFlag { get; set; }
        public short DeletedFlag { get; set; }
        public string ArrivalText { get; set; }
        public string PaymentText { get; set; }

        public decimal GrandTotal { get; set; }
        public string GrandTotalStr { get; set; }

        public int Color { get; set; }

        /// <summary>
        /// Contructor class PurchaseHeaderResult
        /// </summary>
        public PurchaseHeaderResult()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.QuoteNo = string.Empty;
            this.PurchaseNo = string.Empty;
            this.SalesNo = string.Empty;

            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
            this.SubjectName = string.Empty;
            this.PreparedCD = string.Empty;
            this.PreparedName = string.Empty;

            this.DecimalType = 0;
            this.Currency = string.Empty;
            this.PurchaseDate = DateTime.MinValue;
            this.PurchaseDateStr = string.Empty;
            this.ExpiryDate = DateTime.MinValue;
            this.ExpiryDateStr = string.Empty;
            this.PaymentDate = DateTime.MinValue;

            this.InchargeName = string.Empty;
            this.ApprovedName = string.Empty;

            this.FinishedFlag = 0;
            this.DeletedFlag = 0;

            this.GrandTotalStr = string.Empty;
            this.ArrivalText = string.Empty;
            this.PaymentText = string.Empty;
            this.Color = -1;
        }

        /// <summary>
        /// Contructor class PurchaseHeaderResult
        /// </summary>
        /// <param name="dr"></param>
        public PurchaseHeaderResult(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"];
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this.SalesNo = (string)dr["SalesNo"];

            this.VendorName = (string)dr["VendorName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.PreparedName = (dr["PreparedName"] != DBNull.Value) ? (string)dr["PreparedName"] : string.Empty;

            this.DecimalType = 0;
            this.Currency = (dr["Currency"] != DBNull.Value) ? (string)dr["Currency"] : string.Empty;
            this.PurchaseDate = (DateTime)dr["PurchaseDate"];
            this.PurchaseDateStr = this.PurchaseDate.ToString(Constants.FMT_DATE);
            this.ExpiryDate = (DateTime)dr["ExpiryDate"];
            this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);
            this.PaymentDate = (DateTime)dr["PaymentDate"];

            this.FinishedFlag = short.Parse(string.Format("{0}", dr["FinishedFlag"]));
            this.DeletedFlag = short.Parse(string.Format("{0}", dr["DeletedFlag"]));

            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;
            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                }
                else
                {
                    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                }
            }

            if (int.Parse(dr["DeletedFlag"].ToString()) == (int)OMS.Models.DeleteFlag.Deleted && this.Color == -1)
            {
                this.Color = (int)ColorList.Danger;
            }

            if (this.ExpiryDate != DEFAULT_DATE_TIME)
            {
                if (this.Color == -1 && (int)this.FinishedFlag == (int)Models.FinishedFlag.NotFinish && this.ExpiryDate < DateTime.Now.Date)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }

            if (this.PaymentDate != DEFAULT_DATE_TIME)
            {
                if (this.Color == -1 && (int)this.FinishedFlag == (int)Models.FinishedFlag.NotFinish && this.PaymentDate < DateTime.Now.Date)
                {
                    this.Color = (int)ColorList.Warning;
                }
            }

            //Set color for Arrival status
            decimal deliveryTotal = 0;
            decimal quantityTotal = 0;
            deliveryTotal = dr["DeliQuantityTotal"] != DBNull.Value ? (decimal)dr["DeliQuantityTotal"] : 0;
            quantityTotal = dr["QuantityTotal"] != DBNull.Value ? (decimal)dr["QuantityTotal"] : 0;

            if (deliveryTotal.Equals(0))
            {
                this.ArrivalText = "<span class='label label-white' style='width:70px; display: inline-block'>" + "Arrival" + "</span>";
            }
            else if (!deliveryTotal.Equals(quantityTotal))
            {
                this.ArrivalText = "<span class='label label-master' style='width:70px; display: inline-block'>" + "Arrival" + "</span>";
            }
            else if (deliveryTotal.Equals(quantityTotal))
            {
                this.ArrivalText = "<span class='label label-delivery' style='width:70px; display: inline-block'>" + "Arrival" + "</span>";
            }

            //Set color for Payment status
            decimal totalPayment = 0;
            totalPayment = dr["TotalPayment"] != DBNull.Value ? (decimal)dr["TotalPayment"] : 0;

            if (this.GrandTotal.Equals(0))
            {
                this.PaymentText = "<span class='label label-success' style='width:70px; display: inline-block'>" + "Payment" + "</span>";
            }
            else if (totalPayment.Equals(0))
            {
                this.PaymentText = "<span class='label label-white' style='width:70px; display: inline-block'>" + "Payment" + "</span>";
            }
            else if (!totalPayment.Equals(this.GrandTotal))
            {
                this.PaymentText = "<span class='label label-master' style='width:70px; display: inline-block'>" + "Payment" + "</span>";
            }
            else if (totalPayment.Equals(this.GrandTotal))
            {
                this.PaymentText = "<span class='label label-success' style='width:70px; display: inline-block'>" + "Payment" + "</span>";
            }
        }
    }

    /// <summary>
    /// Class PurchaseSelectInfo
    /// Create Date: 2014/08/29 11:15
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class PurchaseSelectInfo
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public PurchaseSelectInfo()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        public PurchaseSelectInfo(DbDataReader dr)
        {
            this.SalesCostIntenalID = (int)dr["SalesCostIntenalID"];
            this.No = (int)dr["No"];
            this.Quantity = Convert.ToDecimal(dr["Quantity"]);
            this.POQuantity = (decimal)dr["POQuantity"];
            this.DeliQuantity = (decimal)dr["DeliQuantity"];
            this.SalesQuantity = (decimal)dr["SalesQuantity"];
            this.VatType = short.Parse(dr["VatType"].ToString());
            this.VatTypeDisp = (string)dr["VatTypeDisp"];
            this.VatRatio = (decimal)dr["VatRatio"];
            this.VendorCD = (string)dr["VendorCD"];
            this.VendorName = (string)dr["VendorName"];
            this.ProductID = (int)dr["ProductID"];
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.UnitPrice = (decimal)dr["UnitPrice"];
            this.CurrencyID = (int)dr["CurrencyID"];
            this.CurrencyName = (string)dr["CurrencyName"];
            this.SalesNo = (string)dr["SalesNo"];
            this.QuotationNo = (string)dr["QuotationNo"];
            this.UpdDateSalesH = (DateTime)dr["UpdDateSalesH"];

            this.DecimalType = (ExchangeRateDecType)(byte)dr["DecimalType"];
        }

        /// <summary>
        /// IsDisable
        /// </summary>
        public bool IsDisable
        {
            get
            {
                return (this.SalesQuantity - this.POQuantity) == 0;
            }
        }

        /// <summary>
        /// ClassIsDisable
        /// </summary>
        public string ClassIsDisable
        {
            get
            {
                if (this.SalesQuantity - this.POQuantity == 0)
                    return "finish";
                return string.Empty;
            }
        }

        /// <summary>
        /// BackgroundColor
        /// </summary>
        public string BackgroundColor
        {
            get;
            set;
        }

        /// <summary>
        /// Checked flag
        /// </summary>
        public bool CheckFlag { get; set; }

        /// <summary>
        /// Get or set SalesCostIntenalID
        /// </summary>
        public int SalesCostIntenalID { get; set; }

        /// <summary>
        /// Get or set No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// Get or set Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Get or set POQuantity
        /// </summary>
        public decimal? POQuantity { get; set; }

        /// <summary>
        /// Get or set DeliQuantity
        /// </summary>
        public decimal? DeliQuantity { get; set; }

        /// <summary>
        /// Get or set SalesQuantity
        /// </summary>
        public decimal? SalesQuantity { get; set; }

        /// <summary>
        /// Get or set VatType
        /// </summary>
        public short VatType { get; set; }

        /// <summary>
        /// Get or set VatTypeDisp
        /// </summary>
        public string VatTypeDisp { get; set; }

        /// <summary>
        /// Get or set VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set UnitPrice
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// UnitPrice Display
        /// </summary>
        public string UnitPriceStr
        {
            get
            {
                var format = string.Format("N{0}", this.DecimalType == ExchangeRateDecType.Decimal ? 2 : 0);
                return this.UnitPrice.Value.ToString(format);
            }
        }

        /// <summary>
        /// Get or set CurrencyID
        /// </summary>
        public int CurrencyID { get; set; }

        /// <summary>
        /// Get or set CurrencyName
        /// </summary>
        public string CurrencyName { get; set; }

        /// <summary>
        /// Get or set SalesNo
        /// </summary>
        public string SalesNo { get; set; }

        /// <summary>
        /// Get or set QuotationNo
        /// </summary>
        public string QuotationNo { get; set; }

        /// <summary>
        /// Get or set UpdDateSalesH
        /// </summary>
        public DateTime UpdDateSalesH { get; set; }

        /// <summary>
        /// Get Currency
        /// </summary>
        public ExchangeRateDecType DecimalType { get; set; }

    }

    /// <summary>
    /// Class PurchaseSelectDataSource
    /// Create Date: 2014/08/29 11:15
    /// Create Author: ISV-HUNG
    /// </summary>
    [Serializable]
    public class PurchaseSelectDataSource
    {
        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorName { get; set; }

        /// <summary>
        /// Get or set list detail
        /// </summary>
        public IList<PurchaseSelectInfo> DetailList { get; set; }

        /// <summary>
        /// Get or set list detail(checked )
        /// </summary>
        public IList<PurchaseSelectInfo> DetailCheckedList
        {
            get
            {
                if (this.DetailList != null)
                {
                    return this.DetailList.Where(d => d.CheckFlag).ToList();
                }
                return new List<PurchaseSelectInfo>();
            }
        }

    }

    /// <summary>
    /// Class PurchaseProductSearchHeader
    /// Create by ISV-HUNG
    /// Create date: 2015/02/09
    /// </summary>
    [Serializable]
    public class PurchaseProductSearchHeader
    {
        /// <summary>
        /// Get or set PurchaseDateFrom
        /// </summary>
        public DateTime? PurchaseDateFrom { get; set; }

        /// <summary>
        /// Get or set PurchaseDateTo
        /// </summary>
        public DateTime? PurchaseDateTo { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set Category1
        /// </summary>
        public int CategoryID1 { get; set; }

        /// <summary>
        /// Get or set Category2
        /// </summary>
        public int CategoryID2 { get; set; }

        /// <summary>
        /// Get or set Category3
        /// </summary>
        public int CategoryID3 { get; set; }

        ///// <summary>
        ///// Get or set UnitPrice From
        ///// </summary>
        //public decimal? UnitPriceFrom { get; set; }

        ///// <summary>
        ///// Get or set UnitPrice To
        ///// </summary>
        //public decimal? UnitPriceTo { get; set; }

        ///// <summary>
        ///// Get or set Currency
        ///// </summary>
        //public int Currency { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>
        /// The description.
        /// </value>
        public string Description { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorName
        /// </summary>
        public string VendorName { get; set; }
    }

    /// <summary>
    /// Class PurchaseProductSearchResult
    /// Create by ISV-HUNG
    /// Create date: 2015/02/09
    /// </summary>
    [Serializable]
    public class PurchaseProductSearchResult
    {
        #region Constant
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set HID
        /// </summary>
        public int HID { get; set; }

        /// <summary>
        /// Get or set InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// Get or set PurchaseNo
        /// </summary>
        public string PurchaseNo { get; set; }

        /// <summary>
        /// Get or set PurchaseDate
        /// </summary>
        public DateTime PurchaseDate { get; set; }

        /// <summary>
        /// Get or set PurchaseDateStr
        /// </summary>
        public string PurchaseDateStr { get; set; }

        /// <summary>
        /// Get or set ProductCD
        /// </summary>
        public string ProductCD { get; set; }
        public string ProductInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.ProductCD, this.ProductName);
            }
        }

        /// <summary>
        /// Get or set ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Get or set VendorCD
        /// </summary>
        public string VendorCD { get; set; }

        /// <summary>
        /// Get or set VendorName
        /// </summary>
        public string VendorName { get; set; }
        public string VendorInfo
        {
            get
            {
                return string.Format("{0}</br>{1}", this.VendorCD, this.VendorName);
            }
        }

        /// <summary>
        /// Get or set UnitPrice
        /// </summary>
        public decimal UnitPrice { get; set; }
        public string UnitPriceStr
        {
            get
            {
                string span = string.Empty;
                if (this.UnitPrice >= 0)
                {
                    span = "<span>{0}</span>";
                }
                else
                {
                    span = "<span class='negative-num'>{0}</span>";
                }
                return string.Format(span, this.UnitPrice.ToString(this.DecimalType > 0 ? "N2" : "N0"));
            }
        }

        /// <summary>
        /// Get or set Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// Get or set DecimalType
        /// </summary>
        public short DecimalType { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public PurchaseProductSearchResult()
        {
            this.RowNumber = 0;
            this.HID = 0;
            this.InternalID = 0;
            this.PurchaseNo = string.Empty;
            this.PurchaseDate = DateTime.MinValue;
            this.PurchaseDateStr = string.Empty;
            this.ProductCD = string.Empty;
            this.ProductName = string.Empty;
            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
            this.UnitPrice = 0;
            this.Currency = string.Empty;
            this.DecimalType = 0;
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr"></param>
        public PurchaseProductSearchResult(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.HID = int.Parse(dr["HID"].ToString());
            this.InternalID = int.Parse(dr["InternalID"].ToString());
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this.PurchaseDate = (DateTime)dr["PurchaseDate"];
            this.PurchaseDateStr = this.PurchaseDate.ToString(Constants.FMT_DATE);
            this.ProductCD = (string)dr["ProductCD"];
            this.ProductName = (string)dr["ProductName"];
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName = (string)dr["VendorName"];
            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
        }
    }

    /// <summary>
    /// Class PurchaseDetailInfo
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class PurchaseDetailInfo
    {
        /// <summary>
        /// No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// InternalID
        /// </summary>
        public int InternalID { get; set; }

        /// <summary>
        /// SalesCostID
        /// </summary>
        public int SalesCostID { get; set; }

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID { get; set; }

        /// <summary>
        /// ProductCD
        /// </summary>
        public string ProductCD { get; set; }

        /// <summary>
        /// ProductName
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// VatType
        /// </summary>
        public short VatType { get; set; }

        /// <summary>
        /// VatRatio
        /// </summary>
        public decimal? VatRatio { get; set; }

        /// <summary>
        /// Vat
        /// </summary>
        public decimal? Vat { get; set; }

        /// <summary>
        /// Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// UnitPrice
        /// </summary>
        public decimal? UnitPrice { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// UnitID
        /// </summary>
        public int UnitID { get; set; }

        /// <summary>
        /// Total
        /// </summary>
        public decimal? Total { get; set; }

        /// <summary>
        /// DetailDeleted
        /// </summary>
        public bool DetailDeleted { get; set; }

        /// <summary>
        /// DeliverQuantity
        /// </summary>
        public decimal? DeliverQuantity { get; set; }

        /// <summary>
        /// DeliverDate
        /// </summary>
        public DateTime? DeliverDate { get; set; }

        /// <summary>
        /// Remark
        /// </summary>
        public string Remark { get; set; }

        public string DataCheck
        {
            get
            {
                if (this.DeliverQuantity.HasValue)
                    return "hidden";
                return string.Empty;
            }
            set { }
        }

        /// <summary>
        /// Serial Empty Flg
        /// </summary>
        public bool SerialEmptyFlg { get; set; }

        /// <summary>
        /// Get or set SerialList
        /// </summary>
        public IList<PurchaseSerialInfo> SerialList { get; set; }

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmptyRow(decimal defaultVATRatio)
        {
            if (string.IsNullOrEmpty(this.ProductCD) ||
                this.ProductCD == M_Product.PRODUCT_CODE_SUPPORT &&
                string.IsNullOrEmpty(this.ProductName) &&
                string.IsNullOrEmpty(this.Description) &&
                string.IsNullOrEmpty(this.Remark) &&
                this.UnitID == Constant.DEFAULT_ID &&
                !this.UnitPrice.HasValue &&
                !this.Quantity.HasValue &&
                //!this.DeliverQuantity.HasValue &&
                !this.Total.HasValue &&
                !this.Vat.HasValue &&
                (!this.VatRatio.HasValue || this.VatRatio.Value == defaultVATRatio)
                )
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Clone Object
        /// </summary>
        /// <typeparam name="T">Class to clone</typeparam>
        /// <returns></returns>
        public PurchaseDetailInfo Clone()
        {
            return (PurchaseDetailInfo)base.MemberwiseClone();
        }
    }

    /// <summary>
    /// Serial Info
    /// </summary>
    [Serializable]
    public class PurchaseSerialInfo
    {
        public int No { get; set; }
        public int PurchaseID { get; set; }
        public int DetailNo { get; set; }
        public string SerialNo { get; set; }
        public short ContractType { get; set; }
        public decimal? Terms { get; set; }
        public int? TermUnit { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? FinishDate { get; set; }

        public string Collapsed { get; set; }

        /// <summary>
        /// Check Empty Item
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty(short defaultContractType)
        {
            if (string.IsNullOrEmpty(this.SerialNo) &&
                this.ContractType == defaultContractType &&
                (!this.TermUnit.HasValue || this.TermUnit == (int)WarrantyUnit.None) &&
                !this.Terms.HasValue &&
                ((this.StartDate == DateTime.MinValue) || this.StartDate == null) &&
                ((this.FinishDate == DateTime.MinValue) || this.FinishDate == null)
                )
            {
                return true;
            }

            return false;
        }
    }

    /// <summary>
    /// Class PurchaseExcel
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class PurchaseExcel
    {
        public int ID { get; set; }
        public string QuoteNo { get; set; }
        public string PurchaseNo { get; set; }
        public string SalesNo { get; set; }

        public DateTime PurchaseDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public DateTime PaymentDate { get; set; }
        public string PreparedName { get; set; }
        public string ApprovedName { get; set; }
        public string Memo { get; set; }
        public string VendorCD { get; set; }
        public string VendorName { get; set; }
        public string SubjectName { get; set; }
        public string Currency { get; set; }
        public string MethodVatName { get; set; }
        public decimal Total { get; set; }
        public decimal Vat { get; set; }
        public decimal GrandTotal { get; set; }
        public short DeleteFlag { get; set; }
        public short FinishFlag { get; set; }

        //public string TotalStr { get; set; }
        //public string VatStr { get; set; }
        //public string GrandTotalStr { get; set; }
        public string PurchaseDateStr { get; set; }
        public string ExpiryDateStr { get; set; }
        public string PaymentDateStr { get; set; }
        public short DecimalType { get; set; }

        /// <summary>
        /// Contructor class PurchaseExcel
        /// </summary>
        public PurchaseExcel()
        {
            this.ID = 0;
            this.QuoteNo = string.Empty;
            this.PurchaseNo = string.Empty;
            this.SalesNo = string.Empty;

            this.PurchaseDate = DateTime.MinValue;
            this.ExpiryDate = DateTime.MinValue;
            this.PaymentDate = DateTime.MinValue;
            this.PreparedName = string.Empty;
            this.ApprovedName = string.Empty;
            this.Memo = string.Empty;
            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
            this.SubjectName = string.Empty;
            this.Currency = string.Empty;
            this.MethodVatName = string.Empty;
            this.Total = 0;
            this.Vat = 0;
            this.GrandTotal = 0;
            this.DeleteFlag = 0;
            this.FinishFlag = 0;

            //this.TotalStr = string.Empty;
            //this.VatStr = string.Empty;
            //this.GrandTotalStr = string.Empty;
            this.PurchaseDateStr = string.Empty;
            this.ExpiryDateStr = string.Empty;
            this.PaymentDateStr = string.Empty;
            this.DecimalType = 0;
        }

        /// <summary>
        /// Constructor class PurchaseExcel
        /// </summary>
        /// <param name="dr"></param>
        public PurchaseExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.QuoteNo = (string)dr["QuoteNo"];
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName = (string)dr["VendorName"];
            this.SubjectName = (string)dr["SubjectName"];
            this.Memo = (string)dr["Memo"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;
            this.Total = dr["Total"] != DBNull.Value ? (decimal)dr["Total"] : 0;
            this.Vat = dr["Vat"] != DBNull.Value ? (decimal)dr["Vat"] : 0;
            this.GrandTotal = dr["GrandTotal"] != DBNull.Value ? (decimal)dr["GrandTotal"] : 0;

            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_DECIMAL);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_DECIMAL);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.TotalStr = this.Total.ToString(Constants.FMT_INTEGER);
                //    this.VatStr = this.Vat.ToString(Constants.FMT_INTEGER);
                //    this.GrandTotalStr = this.GrandTotal.ToString(Constants.FMT_INTEGER);
                //}
            }
            this.ApprovedName = (string)dr["ApprovedName"];
            this.PreparedName = (string)dr["PreparedName"];

            if (dr["MethodVatName"] != DBNull.Value)
            {
                this.MethodVatName = (string)dr["MethodVatName"];
            }

            this.PurchaseDate = (DateTime)dr["PurchaseDate"];
            this.PurchaseDateStr = this.PurchaseDate.ToString(Constants.FMT_DATE);
            this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this.FinishFlag = short.Parse(string.Format("{0}", dr["FinishFlag"]));
            this.ExpiryDate = (DateTime)dr["ExpiryDate"];
            this.ExpiryDateStr = this.ExpiryDate.ToString(Constants.FMT_DATE);
            this.PaymentDate = (DateTime)dr["PaymentDate"];
            this.PaymentDateStr = this.PaymentDate.ToString(Constants.FMT_DATE);
        }
    }

    /// <summary>
    /// Class POListExcel
    /// ISV-Nguyen
    /// </summary>
    [Serializable]
    public class POListExcel
    {
        public int ID { get; set; }
        //public string QuoteNo { get; set; }
        public string PurchaseNo { get; set; }
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }

        public DateTime PurchaseDate { get; set; }
        public string ProductName { get; set; }
        public string VendorCD { get; set; }
        public string VendorName { get; set; }
        public string Currency { get; set; }
        public decimal SalesUnitPrice { get; set; }
        public decimal SalesQuantity { get; set; }
        public decimal SalesSubTotal { get; set; }
        public string SalesCurrency { get; set; }
        //public string SalesUnitPriceStr { get; set; }
        //public string SalesQuantityStr { get; set; }
        //public string SalesSubTotalStr { get; set; }

        public string PurchaseDateStr { get; set; }
        public string SalesDateStr { get; set; }
        public short DecimalType { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Quantity { get; set; }
        public decimal SubTotal { get; set; }
        //public string UnitPriceStr { get; set; }
        //public string QuantityStr { get; set; }
        //public string SubTotalStr { get; set; }

        /// <summary>
        /// Contructor class PurchaseExcel
        /// </summary>
        public POListExcel()
        {
            this.ID = 0;
            this.PurchaseNo = string.Empty;
            this.SalesNo = string.Empty;

            this.PurchaseDate = DateTime.MinValue;
            this.SalesDate = DateTime.MinValue;
           
            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
            this.Currency = string.Empty;
            this.ProductName = string.Empty;
            this.SalesDateStr = string.Empty;
            this.DecimalType = 0;
            
            this.UnitPrice = 0;
            this.Quantity = 0;
            this.SubTotal = 0;
            
            this.SalesUnitPrice = 0;
            this.SalesQuantity = 0;
            this.SalesSubTotal = 0;
            this.SalesCurrency = string.Empty;

            //this.UnitPriceStr = string.Empty;
            //this.QuantityStr = string.Empty;
            //this.SubTotalStr = string.Empty;

            //this.SalesUnitPriceStr = string.Empty;
            //this.SalesQuantityStr = string.Empty;
            //this.SalesSubTotalStr = string.Empty;
        }

        /// <summary>
        /// Constructor class PurchaseExcel
        /// </summary>
        /// <param name="dr"></param>
        public POListExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.PurchaseNo = (string)dr["PurchaseNo"];
            this.SalesNo = (string)dr["SalesNo"];
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName = (string)dr["VendorName"];
            this.ProductName = (string)dr["ProductName"];
            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;
            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.SubTotal = dr["SubTotal"] != DBNull.Value ? (decimal)dr["SubTotal"] : 0;

            this.SalesCurrency = dr["SalesCurrency"] != DBNull.Value ? (string)dr["SalesCurrency"] : string.Empty;

            this.SalesUnitPrice = dr["SalesUnitPrice"] != DBNull.Value ? (decimal)dr["SalesUnitPrice"] : 0;
            this.SalesQuantity = dr["SalesQuantity"] != DBNull.Value ? (decimal)dr["SalesQuantity"] : 0;
            this.SalesSubTotal = dr["SalesSubTotal"] != DBNull.Value ? (decimal)dr["SalesSubTotal"] : 0;


            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_DECIMAL);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_DECIMAL);

                //    this.SalesUnitPriceStr = this.SalesUnitPrice.ToString(Constants.FMT_DECIMAL);
                //    this.SalesSubTotalStr = this.SalesUnitPrice.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_INTEGER);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_INTEGER);

                //    this.SalesUnitPriceStr = this.SalesUnitPrice.ToString(Constants.FMT_INTEGER);
                //    this.SalesSubTotalStr = this.SalesUnitPrice.ToString(Constants.FMT_INTEGER);
                //}
            }

            this.PurchaseDate = (DateTime)dr["PurchaseDate"];
            this.PurchaseDateStr = this.PurchaseDate.ToString(Constants.FMT_DATE);

            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
        }
    }

    /// <summary>
    /// Class UncreatePOListExcel
    /// ISV-Giam
    /// </summary>
    [Serializable]
    public class UnPOListExcel
    {
        public string SalesNo { get; set; }
        public DateTime SalesDate { get; set; }
        public string SalesDateStr { get; set; }
        public string VendorCD { get; set; }
        public string VendorName { get; set; }
        public string ProductName { get; set; }
        public decimal Quantity { get; set; }
        //public string QuantityStr { get; set; }
        public decimal UnitPrice { get; set; }
        //public string UnitPriceStr { get; set; }
        public short DecimalType { get; set; }
        public string Currency { get; set; }
        public decimal SubTotal { get; set; }
        //public string SubTotalStr { get; set; }        

        /// <summary>
        /// Contructor class UncreatePOListExcel
        /// </summary>
        public UnPOListExcel()
        {
            this.SalesNo = string.Empty;
            this.SalesDate = DateTime.MinValue;
            this.SalesDateStr = string.Empty;
            this.VendorCD = string.Empty;
            this.VendorName = string.Empty;
            this.ProductName = string.Empty;
            this.Quantity = 0;
            //this.QuantityStr = string.Empty;
            this.UnitPrice = 0;
            //this.UnitPriceStr = string.Empty;
            this.DecimalType = 0;
            this.Currency = string.Empty;
            this.SubTotal = 0;
            //this.SubTotalStr = string.Empty;
        }

        /// <summary>
        /// Constructor class UncreatePOListExcel
        /// </summary>
        /// <param name="dr"></param>
        public UnPOListExcel(DbDataReader dr)
        {
            this.SalesNo = (string)dr["SalesNo"];
            if (dr["SalesDate"] != DBNull.Value)
            {
                this.SalesDate = (DateTime)dr["SalesDate"];
                this.SalesDateStr = this.SalesDate.ToString(Constants.FMT_DATE);
            }
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName = (string)dr["VendorName"];
            this.ProductName = (string)dr["ProductName"];
            this.Quantity = dr["Quantity"] != DBNull.Value ? (decimal)dr["Quantity"] : 0;
            this.UnitPrice = dr["UnitPrice"] != DBNull.Value ? (decimal)dr["UnitPrice"] : 0;

            this.Currency = dr["Currency"] != DBNull.Value ? (string)dr["Currency"] : string.Empty;

            this.SubTotal = dr["SubTotal"] != DBNull.Value ? (decimal)dr["SubTotal"] : 0;


            if (dr["DecimalType"] != DBNull.Value)
            {
                this.DecimalType = short.Parse(string.Format("{0}", dr["DecimalType"]));
                //if ((int)this.DecimalType == (int)ExchangeRateDecType.Decimal)
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_DECIMAL);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_DECIMAL);
                //}
                //else
                //{
                //    this.UnitPriceStr = this.UnitPrice.ToString(Constants.FMT_INTEGER);
                //    this.SubTotalStr = this.SubTotal.ToString(Constants.FMT_INTEGER);
                //}
            }            
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OMS.Models
{
    public class AuthorityInfo
    {
        public bool IsMasterView { get; set; }
        public bool IsMasterNew { get; set; }
        public bool IsMasterEdit { get; set; }
        public bool IsMasterCopy { get; set; }
        public bool IsMasterDelete { get; set; }
        public bool IsMasterExcel { get; set; }

        public bool IsQuotationView { get; set; }
        public bool IsQuotationNew { get; set; }
        public bool IsQuotationEdit { get; set; }
        public bool IsQuotationCopy { get; set; }
        public bool IsQuotationExcel { get; set; }
        public bool IsQuotationPDF { get; set; }
        public bool IsQuotationRevise { get; set; }
        public bool IsQuotationSales { get; set; }

        public bool IsSalesView { get; set; }
        public bool IsSalesNew { get; set; }
        public bool IsSalesEdit { get; set; }
        public bool IsSalesCopy { get; set; }
        public bool IsSalesExcel { get; set; }
        public bool IsSalesPDF { get; set; }
        public bool IsSalesDelete { get; set; }
        public bool IsSalesRemand { get; set; }
        public bool IsSalesCreateData { get; set; }

        public bool IsPurchaseView { get; set; }
        public bool IsPurchaseNew { get; set; }
        public bool IsPurchaseEdit { get; set; }
        public bool IsPurchaseCopy { get; set; }
        public bool IsPurchaseExcel { get; set; }
        public bool IsPurchaseDelete { get; set; }
        public bool IsPurchasePDF { get; set; }
        public bool IsPurchaseCheck { get; set; }

        public bool IsDeliveryView { get; set; }
        public bool IsDeliveryNew { get; set; }
        public bool IsDeliveryEdit { get; set; }
        public bool IsDeliveryCopy { get; set; }
        public bool IsDeliveryExcel { get; set; }
        public bool IsDeliveryDelete { get; set; }
        public bool IsDeliveryPDF { get; set; }
        public bool IsDeliveryCheck { get; set; }

        public bool IsBillingView { get; set; }
        public bool IsBillingEdit { get; set; }
        public bool IsBillingExcel { get; set; }
        public bool IsBillingPDF { get; set; }
        public bool IsBillingCheck { get; set; }
        public bool IsBillingDelete { get; set; }

        public bool IsContractPeriodView { get; set; }
        public bool IsContractPeriodExcel { get; set; }
        public bool IsContractPeriodPDF { get; set; }
    }
}

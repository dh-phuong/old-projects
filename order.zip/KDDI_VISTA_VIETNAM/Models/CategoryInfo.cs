﻿using System;
using System.Data.Common;

namespace OMS.Models
{
    /// <summary>
    /// Category model 
    /// </summary>
    [Serializable]
    public class CategoryInfo
    {
        public int ID { get; set; }
        public long RowNumber { get; set; }

        public int CategoryStructID { get; set; }

        public string CategoryCD { get; set; }
        public string CategoryName { get; set; }
        public string CssStyle { get; set; }

        public CategoryInfo()
        {
            this.ID = -1;
            this.RowNumber = -1;
            this.CategoryStructID = -1;
            this.CategoryCD = string.Empty;
            this.CategoryName = string.Empty;
            this.CssStyle = string.Empty;
        }
        
        /// <summary>
        /// Constructor class CategoryInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CategoryInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.RowNumber = (long)dr["RowNumber"];
            this.CategoryCD = (string)dr["CategoryCD"]; ;
            this.CategoryName = (string)dr["CategoryName"];
            this.CssStyle = string.Empty;
        }
    }
}

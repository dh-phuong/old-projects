﻿using System;
using System.Data.Common;
using OMS.Models;
using OMS.Utilities;

    /// <summary>
    /// CustomerInfo
    /// </summary>
    [Serializable]
    public class CustomerInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string CustomerAddress1 { get; set; }
        public string CustomerAddress2 { get; set; }
        public string CustomerAddress3 { get; set; }
        public string CustomerAddress4 { get; set; }
        public string CustomerAddress5 { get; set; }
        public string CustomerAddress6 { get; set; }
        public string Represent { get; set; }
        public string Position1 { get; set; }
        public string Position2 { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        public string TAXCode { get; set; }
        public string CustomerBank { get; set; }
        public string AccountCode { get; set; }
        public int StatusFlag { get; set; }
        public int Color { get; set; }

        /// <summary>
        /// Constructor class CustomerInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CustomerInfo(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());

            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW); 
            this.CustomerName1 = (string)dr["CustomerName1"];
            this.CustomerName2 = (string)dr["CustomerName2"];
            this.CustomerAddress1 = (string)dr["CustomerAddress1"];
            this.CustomerAddress2 = (string)dr["CustomerAddress2"];
            this.CustomerAddress3 = (string)dr["CustomerAddress3"];
            this.CustomerAddress4 = (string)dr["CustomerAddress4"];
            this.CustomerAddress5 = (string)dr["CustomerAddress5"];
            this.CustomerAddress6 = (string)dr["CustomerAddress6"];
            this.Represent = (string)dr["Represent"];
            this.Position1 = (string)dr["Position1"];
            this.Position2 = (string)dr["Position2"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)(dr["FAX"]);
            this.EmailAddress = (string)(dr["EmailAddress"]);
            this.ContactPerson = (string)(dr["ContactPerson"]);
            this.ContactTel = (string)(dr["ContactTel"]);
            this.TAXCode = (string)(dr["TAXCode"]);
            this.CustomerBank = (string)(dr["CustomerBank"]);
            this.AccountCode = (string)(dr["AccountCode"]);
            this.StatusFlag = int.Parse(dr["StatusFlag"].ToString());
            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
                if (this.StatusFlag==(int)DeleteFlag.Deleted && this.Color == -1)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }
        }

        /// <summary>
        /// Constructor class CustomerInfo
        /// </summary>
        public CustomerInfo()
        {
            this.Color = -1;
            this.RowNumber = 0;
            this.CustomerCD = string.Empty;
            this.CustomerName1 = string.Empty;
            this.CustomerName2 = string.Empty;
            this.CustomerAddress1 = string.Empty;
            this.CustomerAddress2 = string.Empty;
            this.CustomerAddress3 = string.Empty;
            this.CustomerAddress4 = string.Empty;
            this.CustomerAddress5 = string.Empty;
            this.CustomerAddress6 = string.Empty;
            this.Represent = string.Empty;
            this.Position1 = string.Empty;
            this.Position2 = string.Empty;
            this.Tel = string.Empty;
            this.FAX = string.Empty;
            this.EmailAddress = string.Empty;
            this.ContactPerson = string.Empty;
            this.ContactTel = string.Empty;
            this.TAXCode = string.Empty;
            this.CustomerBank = string.Empty;
            this.AccountCode = string.Empty;
        }

    }
    /// <summary>
    /// Class CustomerSearchInfo Model
    /// </summary>
    [Serializable]
    public class CustomerSearchInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string CustomerAddress1 { get; set; }
        public string CustomerAddress2 { get; set; }
        public string CustomerAddress3 { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        // Description: Add
        // Author: ISV-PHUONG
        // Date  : 2014/12/05
        // ---------------------- Start ------------------------------
        public string Represent { get; set; }
        public string Position { get; set; }
        // ---------------------- End  ------------------------------
        public short StatusFlg { get; set; }
        public int Color { get; set; }
        
        /// <summary>
        /// Constructor class CustomerSearchInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public CustomerSearchInfo(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName1 = (string)dr["CustomerName1"];
            this.CustomerName2 = (string)dr["CustomerName2"];
            this.CustomerAddress1 = (string)dr["CustomerAddress1"];
            this.CustomerAddress2 = (string)dr["CustomerAddress2"];
            this.CustomerAddress3 = (string)dr["CustomerAddress3"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)(dr["FAX"]);
            this.EmailAddress = (string)(dr["EmailAddress"]);
            this.ContactPerson = (string)(dr["ContactPerson"]);
            this.ContactTel = (string)(dr["ContactTel"]);
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            

            this.Represent = (string)(dr["Represent"]);
            this.Position = string.Format("{0} / {1}", dr["Position2"], dr["Position1"]).Trim(new char[] { ' ', '/' });

            var representAposition = string.Format("{0}{1}", this.Represent, this.Position).Trim();
            this.Position = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_POSITION : this.Position;
            this.Represent = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_REPRESENT : this.Represent;
            // ---------------------- End  ------------------------------
            if (dr["StatusFlag"] != DBNull.Value)
            {
                this.StatusFlg = short.Parse(string.Format("{0}", dr["StatusFlag"]));
                if ((int)this.StatusFlg == (int)DeleteFlag.Deleted)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }
        }

        /// <summary>
        /// Constructor class CustomerSearchInfo
        /// </summary>
        public CustomerSearchInfo()
        {
            this.RowNumber = 0;
            this.CustomerCD = null;
            this.CustomerName1 = null;
            this.CustomerName2 = null;
            this.CustomerAddress1 = null;
            this.CustomerAddress2 = null;
            this.CustomerAddress3 = null;
            this.Tel = null;
            this.FAX = null;
            this.EmailAddress = null;
            this.ContactPerson = null;
            this.ContactTel = null;
            this.StatusFlg = 0;
            this.Color = -1;
    }
}

    /// <summary>
    /// customer Class For Excel 
    /// ISV-Nguyen
    /// </summary>
    [Serializable]
    public class CustomerExcel
    {
        public int ID { get; set; }
        public string CustomerCD { get; set; }
        public string CustomerName1 { get; set; }
        public string CustomerName2 { get; set; }
        public string CustomerAddress1 { get; set; }
        public string CustomerAddress2 { get; set; }
        public string CustomerAddress3 { get; set; }
        public string CustomerAddress4 { get; set; }
        public string CustomerAddress5 { get; set; }
        public string CustomerAddress6 { get; set; }
        public string Represent { get; set; }
        public string Position1 { get; set; }
        public string Position2 { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        public string TAXCode { get; set; }
        public string CustomerBank { get; set; }
        public string AccountCode { get; set; }
        public int StatusFlag { get; set; }   

        /// <summary>
        /// Constructor class VendorExcel
        /// </summary>
        public CustomerExcel()
        {
            this.CustomerCD = string.Empty;
            this.CustomerName1 = string.Empty;
            this.CustomerName2 = string.Empty;
            this.CustomerAddress1 = string.Empty;
            this.CustomerAddress2 = string.Empty;
            this.CustomerAddress3 = string.Empty;
            this.CustomerAddress4 = string.Empty;
            this.CustomerAddress5 = string.Empty;
            this.CustomerAddress6 = string.Empty;
            this.Represent = string.Empty;
            this.Position1 = string.Empty;
            this.Position2 = string.Empty;
            this.Tel = string.Empty;
            this.FAX = string.Empty;
            this.EmailAddress = string.Empty;
            this.ContactPerson = string.Empty;
            this.ContactTel = string.Empty;
            this.TAXCode = string.Empty;
            this.CustomerBank = string.Empty;
            this.AccountCode = string.Empty;
            this.StatusFlag = 0;
        }

        /// <summary>
        /// Constructor class VendorExcel
        /// </summary>
        /// <param name="dr"></param>
        public CustomerExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.CustomerCD = EditDataUtil.ToFixCodeShow((string)dr["CustomerCD"], M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.CustomerName1 = (string)dr["CustomerName1"];
            this.CustomerName2 = (string)dr["CustomerName2"];
            this.CustomerAddress1 = (string)dr["CustomerAddress1"];
            this.CustomerAddress2 = (string)dr["CustomerAddress2"];
            this.CustomerAddress3 = (string)dr["CustomerAddress3"];
            this.CustomerAddress4 = (string)dr["CustomerAddress4"];
            this.CustomerAddress5 = (string)dr["CustomerAddress5"];
            this.CustomerAddress6 = (string)dr["CustomerAddress6"];
            this.Represent = (string)dr["Represent"];
            this.Position1 = (string)dr["Position1"];
            this.Position2 = (string)dr["Position2"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)(dr["FAX"]);
            this.EmailAddress = (string)(dr["EmailAddress"]);
            this.ContactPerson = (string)(dr["ContactPerson"]);
            this.ContactTel = (string)(dr["ContactTel"]);
            this.TAXCode = (string)(dr["TAXCode"]);
            this.CustomerBank = (string)(dr["CustomerBank"]);
            this.AccountCode = (string)(dr["AccountCode"]);
            this.StatusFlag = int.Parse(dr["StatusFlag"].ToString());
        }
    }

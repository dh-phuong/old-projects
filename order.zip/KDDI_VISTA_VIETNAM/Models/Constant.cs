﻿
namespace OMS.Models
{
    public class Constant
    {
        #region PK,FK,UN Key
        //M_Category
        public const string M_CATEGORY_PK = "M_Category_PK";
        public const string M_CATEGORY_UN = "M_Category_UN";
        public const string CATEGORY_ROOT_CODE = "0000";
        public const string CATEGORY_ROOT_NAME = "Root";

        //M_CategoryStruct
        public const string M_CATEGORYSTRUCT_PK = "PK_M_CategoryStruct";
        public const string M_CATEGORYSTRUCT_FK_CATEGORYID = "M_CategoryStruct_FK_CategoryID";
        //public const string M_CATEGORYSTRUCT_UN = "M_CategoryStruct_UN";

        //M_Company
        public const string M_COMPANY_PK = "M_Company_PK";

        //M_Condition
        public const string M_CONDITION_PK = "M_Condition_PK";
        public const string M_CONDITION_UN = "M_Condition_UN";

        //M_Config_D
        public const string M_CONFIG_D_PK = "PK_M_Config_D";

        //M_Config_H
        public const string M_CONFIG_H_PK = "PK_M_Config_H";
        public const string M_CONFIG_H_UN = "M_Config_H_UN";

        //M_Currency_D
        public const string M_CURRENCY_D_PK = "M_Currency_D_PK";
        public const string M_CURRENCY_D_FK_ID = "M_Currency_D_FK_ID";

        //M_Currency_H
        public const string M_CURRENCY_H_PK = "M_Currency_H_PK";
        public const string M_CURRENCY_H_UN1 = "M_Currency_H_UN1";

        //M_Customer
        public const string M_CUSTOMER_PK = "M_Customer_PK";
        public const string M_CUSTOMER_UN = "M_Customer_UN";
        public const string M_CUSTOMER_UN_TAXCODE = "M_Customer_UN_TAXCode";

        //M_GroupUser_D
        public const string PK_M_GROUPUSER_D = "PK_M_GroupUser_D";
        public const string FK_M_GROUPUSER_M_M_GROUPUSER = "FK_M_GroupUser_M_M_GroupUser";

        //M_GroupUser_H
        public const string M_GROUPUSER_DEFAULT_CODE = "0000";
        public const string M_GROUPUSER_PK = "M_GroupUser_PK";
        public const string M_GROUPUSER_UN = "M_GroupUser_UN";

        //M_Information
        public const string M_INFORMATION_PK = "M_Information_PK";

        //M_Message
        public const string M_MESSAGE_PK = "M_Message_PK";

        //M_Product
        public const string M_PRODUCT_PK = "PK_M_Product";
        public const string M_PRODUCT_FK_CATEGORY_STRUCT_ID = "M_Product_FK_CategoryStructID";
        public const string M_PRODUCT_FK_CURRENCYID_COST = "M_Product_FK_CurrencyIDCost";
        public const string M_PRODUCT_FK_CURRENCYID_SELL = "M_Product_FK_CurrencyIDSell";
        public const string M_PRODUCT_FK_UNITID_COST = "M_Product_FK_UnitIDCost";
        public const string M_PRODUCT_FK_UNITID_SELL = "M_Product_FK_UnitIDSell";
        public const string M_PRODUCT_UN = "M_Product_UN";

        //M_Setting
        public const string M_SETTING_PK = "M_Setting_PK";

        //M_Unit
        public const string M_UNIT_PK = "M_Unit_PK";
        public const string M_UNIT_UN = "M_Unit_UN";

        //M_User
        public const string M_USER_PK = "M_User_PK";
        public const string M_USER_DEFAULT_CODE = "0000";
        public const string M_USER_FK_GROUPID = "M_USER_FK_GroupID";
        public const string M_USER_UN_CODE = "M_User_UN1";
        public const string M_USER_UN_LOGINID = "M_User_UN2";

        //M_Vendor
        public const string M_VENDOR_PK = "M_Vendor_PK";
        public const string M_VENDOR_UN = "M_Vendor_UN";
        public const string M_VENDOR_UN_TAXCODE = "M_Vendor_UN_TAXCode";

        //M_VendorProduct
        public const string M_VENDORPRODUCT_PK = "PK_M_VendorProduct";
        public const string M_VENDORPRODUCT_FK_VENDOR = "M_VendorProduct_FK_Vendor";

        //T_Attached
        public const string T_Attached_PK = "PK_T_Attached";

        //T_Billing_C
        public const string T_BILLING_C_PK = "T_Billing_C_PK";

        //T_Billing_D
        public const string T_BILLING_D_PK = "T_Billing_D_PK";
        public const string T_BILLING_D_FK_PRODUCT = "T_Billing_D_FK_Product";
        public const string T_BILLING_D_FK_UNIT = "T_Billing_D_FK_Unit";
        public const string T_BILLING_D_UN = "T_Billing_D_UN";

        //T_Billing_H
        public const string T_BILLING_H_PK = "T_Billing_H_PK";
        public const string T_BILLING_H_FK_CURRENCY = "T_Billing_H_FK_Currency";
        public const string T_BILLING_H_FK_CUSTOMER = "T_Billing_H_FK_Customer";
        public const string T_BILLING_H_UN = "T_Billing_H_UN";

        //T_Delivery_C
        public const string T_DELIVERY_C_PK = "PK_T_Delivery_C";

        //T_Delivery_D
        public const string T_DELIVERY_D_PK = "T_Delivery_D_PK";
        public const string T_DELIVERY_D_FK_PRODUCT = "T_Delivery_D_FK_Product";
        public const string T_DELIVERY_D_FK_UNIT = "T_Delivery_D_FK_Unit";
        public const string T_DELIVERY_D_UN = "T_Delivery_D_UN";

        //T_Delivery_H
        public const string T_DELIVERY_H_PK = "T_Delivery_H_PK";
        public const string T_DELIVERY_H_FK_CURRENCY = "T_Delivery_H_FK_Currency";
        public const string T_DELIVERY_H_FK_CUSTOMER = "T_Delivery_H_FK_Customer";
        public const string T_DELIVERY_H_UN = "T_Delivery_H_UN";

        //T_Deposit
        public const string T_DEPOSIT_PK = "PK_T_Deposit";

        //T_No
        public const string T_NO_PK = "T_No_PK";

        //T_Payment
        public const string T_Payment_PK = "PK_T_Payment";

        //T_Purchase_C
        public const string T_PURCHASE_C_PK = "T_Purchase_C_PK";

        //T_Purchase_D
        public const string T_PURCHASE_D_PK = "T_Purchase_D_PK";
        public const string T_PURCHASE_D_FK_PRODUCT = "T_Purchase_D_FK_Product";
        public const string T_PURCHASE_D_FK_UNIT = "T_Purchase_D_FK_Unit";
        public const string T_PURCHASE_D_UN = "T_Purchase_D_UN";

        //T_Purchase_H
        public const string T_PURCHASE_H_PK = "T_Purchase_H_PK";
        public const string T_PURCHASE_H_FK_CURRENCY = "T_Purchase_H_FK_Currency";
        public const string T_PURCHASE_H_FK_VENDOR = "T_Purchase_H_FK_Vendor";
        public const string T_PURCHASE_H_UN = "T_Purchase_H_UN";

        //T_Quote_C
        public const string T_QUOTE_C_PK = "T_Quote_C_PK";

        //T_Quote_D_Cost
        public const string T_QUOTE_D_COST_PK = "T_Quote_D_Cost_PK";
        public const string T_QUOTE_D_COST_FK_CURRENCY = "T_Quote_D_Cost_FK_Currency";
        public const string T_QUOTE_D_COST_FK_PRODUCT = "T_Quote_D_Cost_FK_Product";
        public const string T_QUOTE_D_COST_FK_UNIT = "T_Quote_D_Cost_FK_Unit";
        public const string T_QUOTE_D_COST_FK_VENDOR = "T_Quote_D_Cost_FK_Vendor";

        //T_Quote_D_Sell
        public const string T_QUOTE_D_SELL_PK = "T_Quote_D_Sell_PK";
        public const string T_QUOTE_D_SELL_FK_PRODUCT = "T_Quote_D_Sell_FK_Product";
        public const string T_QUOTE_D_SELL_FK_UNIT = "T_Quote_D_Sell_FK_Unit";

        //T_Quote_H
        public const string T_QUOTE_H_PK = "T_Quote_H_PK";
        public const string T_QUOTE_H_FK_CURRENCY = "T_Quote_H_FK_Currency";
        public const string T_QUOTE_H_FK_CUSTOMER = "T_Quote_H_FK_Customer";
        public const string T_QUOTE_H_UN = "T_Quote_H_UN";

        //T_Sales_C
        public const string T_SALES_C_PK = "T_Sales_C_PK";

        //T_Sales_D_Cost
        public const string T_SALES_D_COST_PK = "T_Sales_D_Cost_PK";
        public const string T_SALES_D_COST_FK_CURRENCY = "T_Sales_D_Cost_FK_Currency";
        public const string T_SALES_D_COST_FK_PRODUCT = "T_Sales_D_Cost_FK_Product";
        public const string T_SALES_D_COST_FK_UNIT = "T_Sales_D_Cost_FK_Unit";
        public const string T_SALES_D_COST_FK_VENDOR = "T_Sales_D_Cost_FK_Vendor";
        public const string T_SALES_D_COST_UN = "T_Sales_D_Cost_UN";

        //T_Sales_D_Sell
        public const string T_SALES_D_SELL_PK = "T_Sales_D_Sell_PK";
        public const string T_SALES_D_SELL_FK_PRODUCT = "T_Sales_D_Sell_FK_Product";
        public const string T_SALES_D_SELL_FK_UNIT = "T_Sales_D_Sell_FK_Unit";
        public const string T_SALES_D_SELL_UN = "T_Sales_D_Sell_UN";

        //T_Sales_H
        public const string T_SALES_H_PK = "T_Sales_H_PK";
        public const string T_SALES_H_FK_CURRENCY = "T_Sales_H_FK_Currency";
        public const string T_SALES_H_FK_CUSTOMER = "T_Sales_H_FK_Customer";
        public const string T_SALES_H_UN = "T_Sales_H_UN";

        //T_Delivery_Serial_PK
        public const string T_DELIVERY_SERIAL_PK = "T_Delivery_Serial_PK";

        ////User
        //public const string USER_UN_CODE = "M_User_UN1";
        //public const string USER_UN_LOGINID = "M_User_UN2";
        //public const string USER_FK_GROUP_USER = "M_USER_FK_GroupID";

        ////Group User
        //public const string GROUP_USER_UN = "M_GroupUser_UN";

        ////Vendor
        //public const string VENDOR_UN = "M_Vendor_UN";
        //public const string VENDOR_CHK_TAXCODE = "M_Vendor_CHK_TAXCODE";

        ////Customer
        //public const string CUSTOMER_UN = "M_Customer_UN";
        //public const string CUSTOMER_CHK_TAXCODE = "M_Customer_CHK_TAXCODE";

        ////Condition
        //public const string CONDITION_UN = "M_Condition_UN";

        ////Category
        //public const string CATEGORY_ROOT_CODE = "0000";
        //public const string CATEGORY_ROOT_NAME = "Root";
        //public const string CATEGORY_UN_CODE = "M_Category_UN";
        //public const string CATEGORY_STRUCT_UN = "M_CategoryStruct_UN";
        //public const string CATEGORY_FK_CATEGORY = "M_CategoryStruct_FK_CategoryChildID";

        ////Product
        //public const string PRODUCT_UN_CODE = "M_Product_UN";
        //public const string PRODUCT_FK_CATEGORY = "M_Product_FK_CategoryID";
        //public const string PRODUCT_FK_CURRENCY_COST = "M_Product_FK_CurrencyIDCost";
        //public const string PRODUCT_FK_CURRENCY_SELL = "M_Product_FK_CurrencyIDSell";
        //public const string PRODUCT_FK_UNIT = "M_Product_FK_UnitID";
        //public const string PRODUCT_FK_CURRENCY_SELL = "M_Product_FK_CurrencyIDSell";
        //public const string PRODUCT_FK_UNIT_SELL = "M_Product_FK_UnitIDSell";
        //public const string PRODUCT_FK_CURRENCY_COST = "M_Product_FK_CurrencyIDCost";
        //public const string PRODUCT_FK_UNIT_COST = "M_Product_FK_UnitIDCost";

        ////Vendor product
        //public const string VENDOR_PRODUCT_FK_VENDORID = "M_VendorProduct_FK_Vendor";

        ////Quote
        //public const string QUOTE_H_UN = "T_Quote_H_UN";
        //public const string QUOTE_H_FK_CUSTOMER = "T_Quote_H_FK_Customer";
        //public const string QUOTE_H_FK_CURRENCY = "T_Quote_H_FK_Currency";

        //public const string QUOTE_COST_FK_CURRENCY = "T_Quote_D_Cost_FK_CurrencyFlag";
        //public const string QUOTE_COST_FK_PRODUCT = "T_Quote_D_Cost_FK_Product";
        //public const string QUOTE_COST_FK_UNIT = "T_Quote_D_Cost_FK_Unit";
        //public const string QUOTE_COST_FK_VENDOR = "T_Quote_D_Cost_FK_Vendor";
        
        //public const string QUOTE_SELL_FK_UNIT = "T_Quote_D_Sell_FK_Unit";
        //public const string QUOTE_SELL_FK_PRODUCT = "T_Quote_D_Sell_FK_Product";

        ////Acceptance
        ////public const string ACCEPT_H_ACCEPT_NO_UN = "T_Accept_H_UN";
        ////public const string ACCEPT_H_FK_CUSTOMER = "T_Accept_H_FK_Customer";

        ////public const string ACCEPT_COST_FK_CURRENCY = "T_Accept_D_Cost_FK_Currency";
        ////public const string ACCEPT_COST_FK_PRODUCT = "T_Accept_D_Cost_FK_Product";
        ////public const string ACCEPT_COST_FK_UNIT = "T_Accept_D_Cost_FK_Unit";
        ////public const string ACCEPT_COST_FK_VENDOR = "T_Accept_D_Cost_FK_Vendor";
        ////public const string ACCEPT_SELL_FK_PRODUCT = "T_Accept_D_Sell_FK_Product";
        ////public const string ACCEPT_SELL_FK_UNIT = "T_Accept_D_Sell_FK_Unit";


        ////Sales
        //public const string SALES_H_SALES_NO_UN = "T_Sales_H_UN";
        //public const string SALES_H_FK_CUSTOMER = "T_Sales_H_FK_Customer";
        //public const string SALES_H_FK_CURRENCY = "T_Sales_H_FK_Currency";

        //public const string SALES_COST_FK_CURRENCY = "T_Sales_D_Cost_FK_Currency";
        //public const string SALES_COST_FK_PRODUCT = "T_Sales_D_Cost_FK_Product";
        //public const string SALES_COST_FK_UNIT = "T_Sales_D_Cost_FK_Unit";
        //public const string SALES_COST_FK_VENDOR = "T_Sales_D_Cost_FK_Vendor";
        //public const string SALES_SELL_FK_PRODUCT = "T_Sales_D_Sell_FK_Product";
        //public const string SALES_SELL_FK_UNIT = "T_Sales_D_Sell_FK_Unit";

        ////Shipping
        ////public const string SHIPPING_H_FK_CUSTOMER = "T_Shipping_H_FK_Customer";
        ////public const string SHIPPING_H_FK_CURRENCY = "T_Shipping_H_FK_Currency";
        ////public const string SHIPPING_H_UN = "T_Shipping_H_UN";
        ////public const string SHIPPING_M_FK_UNIT = "T_Shipping_M_FK_Unit";
        ////public const string SHIPPING_M_FK_PRODUCT = "T_Shipping_M_FK_Product";

        ////Delivery
        //public const string DELIVERY_H_FK_CUSTOMER = "T_Delivery_H_FK_Customer";
        //public const string DELIVERY_H_FK_CURRENCY = "T_Delivery_H_FK_Currency";
        //public const string DELIVERY_H_UN = "T_Delivery_H_UN";
        //public const string DELIVERY_M_FK_UNIT = "T_Delivery_M_FK_Unit";
        //public const string DELIVERY_M_FK_PRODUCT = "T_Delivery_M_FK_Product";
        
        //////Invoice
        ////public const string INVOICE_H_UN = "T_Invoice_H_UN";
        ////public const string INVOICE_H_FK_CUSTOMER = "T_Invoice_H_FK_Customer";
        ////public const string INVOICE_H_FK_CURRENCY = "T_Invoice_H_FK_Currency";
        ////public const string INVOICE_D_FK_UNIT = "T_Invoice_D_FK_Unit";
        ////public const string INVOICE_D_FK_PRODUCT = "T_Invoice_D_FK_Product";

        ////Billing
        //public const string BILLING_H_UN = "T_Billing_H_UN";
        //public const string BILLING_H_FK_CUSTOMER = "T_Billing_H_FK_Customer";
        //public const string BILLING_H_FK_CURRENCY = "T_Billing_H_FK_Currency";
        //public const string BILLING_D_FK_UNIT = "T_Billing_D_FK_Unit";
        //public const string BILLING_D_FK_PRODUCT = "T_Billing_D_FK_Product";

        ////Purchase
        //public const string PURCHASE_H_UN = "T_Purchase_H_UN";
        //public const string PURCHASE_H_FK_CURRENCY = "T_Purchase_H_FK_Currency";
        //public const string PURCHASE_H_FK_VENDOR = "T_Purchase_H_FK_Vendor";

        //public const string PURCHASE_D_UN = "T_Purchase_D_UN";
        ////public const string PURCHASE_D_FK_ACCEPTCOST = "T_Purchase_D_FK_AcceptCost";
        //public const string PURCHASE_D_FK_SALESCOST = "T_Purchase_D_FK_SalesCost";
        //public const string PURCHASE_D_FK_PRODUCT = "T_Purchase_D_FK_Product";
        //public const string PURCHASE_D_FK_UNIT = "T_Purchase_D_FK_Unit";

        ////Unit
        //public const string UNIT_UN = "M_Unit_UN";

        ////ExchangeRate_H
        //public const string MONEY_CODE_UN = "M_Currency_H_UN1";

        #endregion

        /// <summary>
        /// Authorized Signature / Seal
        /// </summary>
        public const string DEFAULT_POSITION = "Authorized Signature / Seal";
        /// <summary>
        /// Ký tên và đóng dấu
        /// </summary>
        public const string DEFAULT_REPRESENT = "";

        /// <summary>
        /// Default id
        /// </summary>
        public const int DEFAULT_ID = 1;

        //Currency Master defaul row
        public const int DEFAULT_NUMBER_ROW = 50;

        #region Money

        //Max profit
        public const decimal MAX_PROFIT = 100.00m;

        //Vat Ration
        public const int MAX_VATRATIO = 99;

        //Quantity
        public const decimal MAX_QUANTITY_DECIMAL = 999999.99M;
        public const decimal MAX_QUANTITY_NOT_DECIMAL = 999999M;

        //Unit Price
        public const decimal MAX_UNIT_PRICE_DECIMAL = 9999999999.99M;
        public const decimal MAX_UNIT_PRICE_NOT_DECIMAL = 9999999999M;

        //Sub Total
        public const decimal MAX_SUB_TOTAL_DECIMAL = 9999999999999.99M;
        public const decimal MAX_SUB_TOTAL_NOT_DECIMAL = 9999999999999M;
        public const decimal MIN_SUB_TOTAL_DECIMAL = -9999999999999.99M;
        public const decimal MIN_SUB_TOTAL_NOT_DECIMAL = -9999999999999M;

        //Sub Vat
        public const decimal MAX_SUB_VAT_DECIMAL = 999999999999.99M;
        public const decimal MAX_SUB_VAT_NOT_DECIMAL = 999999999999M;
        public const decimal MIN_SUB_VAT_DECIMAL = -999999999999.99M;
        public const decimal MIN_SUB_VAT_NOT_DECIMAL = -999999999999M;

        //Total
        public const decimal MAX_SUM_TOTAL_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUM_TOTAL_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUM_TOTAL_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUM_TOTAL_NOT_DECIMAL = -99999999999999;

        //VAT
        public const decimal MAX_SUM_VAT_DECIMAL = 9999999999999.99M;
        public const decimal MAX_SUM_VAT_NOT_DECIMAL = 9999999999999;
        public const decimal MIN_SUM_VAT_DECIMAL = -9999999999999.99M;
        public const decimal MIN_SUM_VAT_NOT_DECIMAL = -9999999999999;

        //SUB AMOUNT
        public const decimal MAX_SUB_AMOUNT_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUB_AMOUNT_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUB_AMOUNT_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUB_AMOUNT_NOT_DECIMAL = -99999999999999;

        //SUM AMOUNT
        public const decimal MAX_SUM_AMOUNT_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUM_AMOUNT_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUM_AMOUNT_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUM_AMOUNT_NOT_DECIMAL = -99999999999999;

        //BALANCE
        public const decimal MAX_BALANCE_DECIMAL = 99999999999999.99M;
        public const decimal MAX_BALANCE_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_BALANCE_DECIMAL = -99999999999999.99M;
        public const decimal MIN_BALANCE_NOT_DECIMAL = -99999999999999;
        
        #endregion

        #region Width Column
        //Sell and Cost
        public const string GRID_WIDTH = "1138px;";
        public const string PRODUCT_COLUMN_WIDTH = "468px;";
        public const string UNITPRICE_PROFIT_COLUMN_WIDTH = "170px;";
        public const string QTY_UNIT_COLUMN_WIDTH = "140px;";
        public const string SUBTOTAL_REMARK_COLUMN_WIDTH = "180px;";
        public const string VAT_RATIO_COLUMN_WIDTH = "180px;";

        //Payment and Deposit
        public const string DATE_WIDTH = "220px;";
        public const string METHOD_WIDTH = "220px;";
        public const string PERSONAL_WIDTH = "165px;";
        public const string AMOUNT_WIDTH = "313px;";
        public const string REMARK_WIDTH = "172px;";
        #endregion
    }
}

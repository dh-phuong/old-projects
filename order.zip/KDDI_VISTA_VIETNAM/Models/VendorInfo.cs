﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{
    /// <summary>
    /// Vendor Info Class
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class VendorInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string VendorCD { get; set; }
        public string VendorName1 { get; set; }
        public string VendorName2 { get; set; }
        public string VendorAddress1 { get; set; }
        public string VendorAddress2 { get; set; }
        public string VendorAddress3 { get; set; }
        public string GroupSupply { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        public string TAXCode { get; set; }
        public string VendorBank { get; set; }
        public string AccountCode { get; set; }
        public short StatusFlag { get; set; }
        public int Color { get; set; }

        /// <summary>
        /// Constructor class VendorInfo
        /// </summary>
        public VendorInfo()
        {
            this.RowNumber = 0;
            this.VendorCD = string.Empty;
            this.VendorName1 = string.Empty;
            this.VendorName2 = string.Empty;
            this.VendorAddress1 = string.Empty;
            this.VendorAddress2 = string.Empty;
            this.VendorAddress3 = string.Empty;
            this.GroupSupply = string.Empty;
            this.Tel = string.Empty;
            this.FAX = string.Empty;
            this.EmailAddress = string.Empty;
            this.ContactPerson = string.Empty;
            this.ContactTel = string.Empty;
            this.TAXCode = string.Empty;
            this.VendorBank = string.Empty;
            this.AccountCode = string.Empty;
            this.StatusFlag = 0;
            this.Color = -1;
        }

        /// <summary>
        /// Constructor class VendorInfo
        /// </summary>
        /// <param name="dr"></param>
        public VendorInfo(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW); 
            this.VendorName1 = (string)dr["VendorName1"];
            this.VendorName2 = (string)dr["VendorName2"];
            this.VendorAddress1 = (string)dr["VendorAddress1"];
            this.VendorAddress2 = (string)dr["VendorAddress2"];
            this.VendorAddress3 = (string)dr["VendorAddress3"];
            this.GroupSupply = (string)dr["GroupSupply"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)dr["FAX"];
            this.EmailAddress = (string)dr["EmailAddress"];
            this.ContactPerson = (string)dr["ContactPerson"];
            this.ContactTel = (string)dr["ContactTel"];
            this.TAXCode = (string)dr["TAXCode"];
            this.VendorBank = (string)dr["VendorBank"];
            this.AccountCode = (string)dr["AccountCode"];
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());

            if (dr["StatusFlag"] != DBNull.Value)
            {
                if (this.StatusFlag == (int)DeleteFlag.Deleted && this.Color == -1)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }
        }
    }

    /// <summary>
    /// VendorInfo Class For Search 
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class VendorSearchInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string VendorCD { get; set; }
        public string VendorName1 { get; set; }
        public string VendorName2 { get; set; }
        public string VendorAddress1 { get; set; }
        public string VendorAddress2 { get; set; }
        public string VendorAddress3 { get; set; }
        public string GroupSupply { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        public string TAXCode { get; set; }
        public string VendorBank { get; set; }
        public string AccountCode { get; set; }
        public short StatusFlag { get; set; }

        /// <summary>
        /// Constructor class VendorSearchInfo
        /// </summary>
        public VendorSearchInfo()
        {
            this.RowNumber = 0;
            this.VendorCD = null;
            this.VendorName1 = null;
            this.VendorName2 = null;
            this.VendorAddress1 = null;
            this.VendorAddress2 = null;
            this.VendorAddress3 = null;
            this.GroupSupply = null;
            this.Tel = null;
            this.FAX = null;
            this.EmailAddress = null;
            this.ContactPerson = null;
            this.ContactTel = null;
            this.TAXCode = string.Empty;
            this.VendorBank = string.Empty;
            this.AccountCode = string.Empty;
            this.StatusFlag = 0;
        }

        /// <summary>
        /// Constructor class VendorSearchInfo
        /// </summary>
        /// <param name="dr"></param>
        public VendorSearchInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName1 = (string)dr["VendorName1"];
            this.VendorName2 = (string)dr["VendorName2"];
            this.VendorAddress1 = (string)dr["VendorAddress1"];
            this.VendorAddress2 = (string)dr["VendorAddress2"];
            this.VendorAddress3 = (string)dr["VendorAddress3"];
            this.GroupSupply = (string)dr["GroupSupply"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)dr["FAX"];
            this.EmailAddress = (string)dr["EmailAddress"];
            this.ContactPerson = (string)dr["ContactPerson"];
            this.ContactTel = (string)dr["ContactTel"];
            this.TAXCode = (string)dr["TAXCode"];
            this.VendorBank = (string)dr["VendorBank"];
            this.AccountCode = (string)dr["AccountCode"];
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());
        }
    }

    /// <summary>
    /// Vendor Class For Excel 
    /// ISV-TRUC
    /// </summary>
    [Serializable]
    public class VendorExcel
    {
        public int ID { get; set; }
        public string VendorCD { get; set; }
        public string VendorName1 { get; set; }
        public string VendorName2 { get; set; }
        public string VendorAddress1 { get; set; }
        public string VendorAddress2 { get; set; }
        public string VendorAddress3 { get; set; }
        public string GroupSupply { get; set; }
        public string Tel { get; set; }
        public string FAX { get; set; }
        public string EmailAddress { get; set; }
        public string ContactPerson { get; set; }
        public string ContactTel { get; set; }
        public string TAXCode { get; set; }
        public string VendorBank { get; set; }
        public string AccountCode { get; set; }
        public short StatusFlag { get; set; }

        /// <summary>
        /// Constructor class VendorExcel
        /// </summary>
        public VendorExcel()
        {
            this.VendorCD = string.Empty;
            this.VendorName1 = string.Empty;
            this.VendorName2 = string.Empty;
            this.VendorAddress1 = string.Empty;
            this.VendorAddress2 = string.Empty;
            this.VendorAddress3 = string.Empty;
            this.GroupSupply = string.Empty;
            this.Tel = string.Empty;
            this.FAX = string.Empty;
            this.EmailAddress = string.Empty;
            this.ContactPerson = string.Empty;
            this.ContactTel = string.Empty;
            this.TAXCode = string.Empty;
            this.VendorBank = string.Empty;
            this.AccountCode = string.Empty;
            this.StatusFlag = 0;
        }

        /// <summary>
        /// Constructor class VendorExcel
        /// </summary>
        /// <param name="dr"></param>
        public VendorExcel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.VendorCD = EditDataUtil.ToFixCodeShow((string)dr["VendorCD"], M_Vendor.VENDOR_CODE_MAX_SHOW);
            this.VendorName1 = (string)dr["VendorName1"];
            this.VendorName2 = (string)dr["VendorName2"];
            this.VendorAddress1 = (string)dr["VendorAddress1"];
            this.VendorAddress2 = (string)dr["VendorAddress2"];
            this.VendorAddress3 = (string)dr["VendorAddress3"];
            this.GroupSupply = (string)dr["GroupSupply"];
            this.Tel = (string)dr["Tel"];
            this.FAX = (string)dr["FAX"];
            this.EmailAddress = (string)dr["EmailAddress"];
            this.ContactPerson = (string)dr["ContactPerson"];
            this.ContactTel = (string)dr["ContactTel"];
            this.TAXCode = (string)dr["TAXCode"];
            this.VendorBank = (string)dr["VendorBank"];
            this.AccountCode = (string)dr["AccountCode"];
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());
        }
    }
}

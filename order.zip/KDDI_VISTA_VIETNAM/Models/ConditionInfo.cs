﻿using System;
using System.Data.Common;
using OMS.Utilities;

namespace OMS.Models
{

    /// <summary>
    /// Class ConditionInfo Model
    /// </summary>
    [Serializable]
    public class ConditionInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public int Type { get; set; }
        public string ConditionCD { get; set; }
        public string ConditionName { get; set; }
        public string Condition { get; set; }

        /// <summary>
        /// Constructor class ConditionInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ConditionInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.Type = int.Parse(dr["Type"].ToString());
            this.ConditionCD = EditDataUtil.ToFixCodeShow((string)dr["ConditionCD"], M_Condition.MAX_CONDITION_CODE_SHOW);
            this.ConditionName = (string)dr["ConditionName"];
            this.Condition = (string)dr["Condition"];
        }

        /// <summary>
        /// Constructor class ConditionInfo
        /// </summary>
        public ConditionInfo()
        {
            this.RowNumber = 0;
            this.Type = 0;
            this.ConditionCD = string.Empty;
            this.ConditionName = string.Empty;
            this.Condition = string.Empty;
        }
    }

    /// <summary>
    /// Condition information Class For Search 
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class ConditionSearchInfo
    {
        /// <summary>
        /// The number of row
        /// </summary>
        public long RowNumber { get; set; }
        
        /// <summary>
        /// Condition code
        /// </summary>
        public string ConditionCD { get; set; }

        /// <summary>
        /// Condtion Name
        /// </summary>
        public string ConditionName { get; set; }
        
        /// <summary>
        /// Condition
        /// </summary>
        public string Condition { get; set; }

        /// <summary>
        /// Constructor class ConditionSearchInfo
        /// </summary>
        public ConditionSearchInfo()
        {
            this.RowNumber = 0;
            this.ConditionCD = null;
            this.ConditionName = null;
            this.Condition = null;
        }

        /// <summary>
        /// Constructor class ConditionSearchInfo
        /// </summary>
        /// <param name="dr">Data Reader</param>
        public ConditionSearchInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ConditionCD = (string)dr["ConditionCD"];
            this.ConditionName = (string)dr["ConditionName"];
            this.Condition = (string)dr["Condition"];
        }
    }

}
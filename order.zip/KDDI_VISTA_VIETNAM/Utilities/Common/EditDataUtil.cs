﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Script.Serialization;

namespace OMS.Utilities
{
    public class EditDataUtil
    {
        /// <summary>
        /// Fix code to show
        /// </summary>
        /// <param name="iCode"></param>
        /// <param name="iLength"></param>
        /// <returns></returns>
        public static string ToFixCodeShow(string iCode, int iLength)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }
            Match match = Regex.Match(iCode, Constants.PATTERN_NUMERIC, RegexOptions.IgnoreCase);
            // Here we check the Match instance.
            if (match.Success)
            {
                return iCode.Substring(iCode.Length - iLength, iLength);
            }
            return iCode;
        }

        /// <summary>
        /// Fix code to db
        /// </summary>
        /// <param name="value"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string ToFixCodeDB(string iCode, int length)
        {
            if (string.IsNullOrEmpty(iCode))
            {
                return iCode;
            }
            Match match = Regex.Match(iCode, Constants.PATTERN_NUMERIC, RegexOptions.IgnoreCase);
            // Here we check the Match instance.
            if (match.Success)
            {
                if (iCode.Length > length)
                {
                    return iCode.Substring(iCode.Length - length, length);
                }
                return iCode.PadLeft(length, '0');
            }
            return iCode;
        }

        /// <summary>
        /// JSON Serialization
        /// </summary>
        public static string JsonSerializer<T>(T t)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            string jsonString = ser.Serialize(t);
            return jsonString;
        }
        
        /// <summary>
        /// JSON Deserialization
        /// </summary>
        public static T JsonDeserialize<T>(string jsonString)
        {
            JavaScriptSerializer ser = new JavaScriptSerializer();
            return (T)ser.Deserialize(jsonString, typeof(T));
        }

        public static string Decode(string value)
        {
            if (string.IsNullOrEmpty(value))
                return value;
            IDictionary<string, string> _specials_d = EditDataUtil.JsonDeserialize<Dictionary<string, string>>(Constants.SPECIALS_D);
            foreach (string key in _specials_d.Keys)
            {
                value = value.Replace(key, _specials_d[key]);
            }

            return value;
        }

        #region Report

        /// <summary>
        /// Spell Number
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <param name="CurrentCulture"></param>
        /// <param name="CurrencyUnit"></param>
        /// <param name="CurrencyUnitSmall"></param>
        /// <returns></returns>
        public static string SpellNumber(string MyNumber, Language CurrentCulture, string CurrencyUnit, string CurrencyUnitSmall = "")
        {            
            MyNumber = MyNumber.Replace(",", "");
            if (CurrentCulture == Language.English)
            {
                return ReadNumber(MyNumber, CurrencyUnit, CurrencyUnitSmall);
            }
            else
            {
                return ChuyenSo(MyNumber, CurrencyUnit, CurrencyUnitSmall);
            }
        }

        #region Doc so tieng viet

        /// <summary>
        /// cap do cua gia tri tien te
        /// </summary>
        /// <remarks></remarks>
        private enum CurrencyLevel : int
        {

            /// <summary>
            /// hang tram
            /// </summary>
            /// <remarks></remarks>
            Tram = 0,

            /// <summary>
            /// hang nghin
            /// </summary>
            /// <remarks></remarks>
            Nghin = 1,

            /// <summary>
            /// hang trieu
            /// </summary>
            /// <remarks></remarks>
            Trieu = 2,

            /// <summary>
            /// hang ty
            /// </summary>
            /// <remarks></remarks>
            Ty = 3

        }

        /// <summary>
        /// doc so thanh mot chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string ChuyenSo(string NumberStr, string CurrencyUnit, string CurrencyUnitSmall)
        {

            if (string.IsNullOrEmpty(NumberStr.Trim()))
                return string.Empty;
            decimal decNum = Convert.ToDecimal(NumberStr);

            //Number interger (lay phan nguyen)
            string intNumStr = Math.Truncate(decNum).ToString();

            //Number decimal (lay phan thap phan (sau dau phay))
            string decimalNumStr = decNum.ToString().Substring(intNumStr.Length);

            //chuoi so tra ve
            string readNumberString = string.Empty;

            //kiem tra so am

            if (NumberStr.IndexOf("-") >= 0 && NumberStr.IndexOf("-") == 0)
            {
                // doc theo so am
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();


                readNumberString = "âm " + ReadNumberToString(intNumStr.Replace("-", "")).Trim() + " " + CurrencyUnit + decimalNumStr;

            }
            else
            {
                //doc so binh thuong

                //doc 2 so sau dau phay
                decimalNumStr = ReadNumber2Decimal(decimalNumStr).Trim();

                decimalNumStr = (string.IsNullOrEmpty(decimalNumStr) ? string.Empty : " " + decimalNumStr + " " + CurrencyUnitSmall).ToString();

                readNumberString = ReadNumberToString(intNumStr).Trim() + " " + CurrencyUnit + decimalNumStr;

            }

            if (string.IsNullOrEmpty(readNumberString))
            {
                return string.Empty;

            }
            else
            {
                //dinh dang chuoi tra ve
                readNumberString = readNumberString.ToLower().Trim();

                //lay ki tu dau tien de viet hoa
                string FirstCharacter = readNumberString[0].ToString();

                //viet hoa donvi tien te
                if (readNumberString.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    readNumberString = readNumberString.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }

                //viet hoa chu dau
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), readNumberString.Substring(1));
            }


        }

        /// <summary>
        /// chuyen so thanh chuoi
        /// </summary>
        /// <param name="NumberStr"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string ReadNumberToString(string NumberStr)
        {


            if (NumberStr.Length > 3)
            {

                if (NumberStr.Length % 3 == 0)
                {
                    //Kiem tra neu chuoi so chua so khong het, thi khoi doc cac so dang sau
                    bool isZero = true;
                    for (int index = 0; index <= NumberStr.Length - 1; index++)
                    {
                        if (!NumberStr[index].Equals("0"))
                        {
                            isZero = false;
                        }
                    }
                    if (isZero)
                    {
                        return string.Empty;
                    }

                    //---------------- doc so lon hon hang ty

                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse((Math.Truncate(temp) - 1).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;
                        }
                    }

                    //-------------------------------------------
                    //lay 3 so dau
                    string NumTemp = NumberStr.Substring(0, 3);

                    // neu la 3 so 0 thi doc tiep day con lai
                    if (Convert.ToInt32(NumTemp) == 0)
                    {

                        return ReadNumberToString(NumberStr.Substring(NumTemp.Length));

                    }


                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));


                }
                else
                {
                    string Unit = string.Empty;

                    decimal temp = NumberStr.Length / 3;

                    int level = int.Parse(Math.Truncate(temp).ToString());

                    int levelSub = level;


                    while (levelSub > 3)
                    {
                        levelSub = levelSub - 3;

                        if ((CurrencyLevel)levelSub == CurrencyLevel.Nghin)
                        {
                            Unit = "nghìn " + Unit;
                        }
                        else if ((CurrencyLevel)levelSub == CurrencyLevel.Trieu)
                        {
                            Unit = "triệu " + Unit;
                        }
                        else if (levelSub > 0)
                        {
                            Unit = "tỷ " + Unit;

                        }
                    }

                    //lay ra so co hang don vi tien lon nhat
                    string NumTemp = NumberStr.Substring(0, NumberStr.Length % 3);

                    if ((CurrencyLevel)level == CurrencyLevel.Nghin)
                    {
                        Unit += "nghìn";
                    }
                    else if ((CurrencyLevel)level == CurrencyLevel.Trieu)
                    {
                        Unit += "triệu";
                    }
                    else if (level > 0)
                    {
                        Unit += "tỷ";
                    }

                    //doc 3 so dau roi ghep voi doc chuoi so con lai
                    return ReadNumber3Digit(NumTemp) + " " + Unit + " " + ReadNumberToString(NumberStr.Substring(NumTemp.Length));
                }


            }
            else
            {
                //doc 3 so cuoi
                return ReadNumber3Digit(NumberStr);

            }


        }

        /// <summary>
        /// doc chuoi so voi 3 chu so
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string ReadNumber3Digit(string readNumber)
        {

            string hangTram = string.Empty;
            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = string.Empty;


            if (readNumber.Length == 3)
            {
                //lay so o hang tram
                hangTram = readNumber[0].ToString();

                //lay so o hang chuc
                hangChuc = readNumber[1].ToString();

                //lay do o hang don vi
                hangDonVi = readNumber[2].ToString();

            }
            else if (readNumber.Length == 2)
            {
                hangChuc = readNumber[0].ToString();
                hangDonVi = readNumber[1].ToString();
            }
            else
            {
                hangDonVi = readNumber[0].ToString();
            }
            if (hangTram == "0" && hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }


            if (!string.IsNullOrEmpty(hangTram) && !string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                //Doc so hang Tram
                readString += NumberString(Convert.ToInt32(hangTram)) + " trăm";

                // doc so hang chuc
                if (hangChuc == "0" && hangDonVi == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "0")
                {
                    readString += " lẻ";
                }
                else if (hangChuc == "1")
                {
                    readString += " mười";
                }
                else
                {
                    readString += " " + NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString += string.Empty;
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi));
            }

            return readString;

        }

        /// <summary>
        /// doc so le (2 chu so)
        /// </summary>
        /// <param name="readNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string ReadNumber2Decimal(string readNumber)
        {


            if (string.IsNullOrEmpty(readNumber))
                return string.Empty;
            if (readNumber.Length > 3)
            {
                readNumber = readNumber.Substring(0, 3);
            }

            string hangChuc = string.Empty;
            string hangDonVi = string.Empty;
            string readString = "và ";
            if (readNumber.Length == 3)
            {
                hangChuc = readNumber[1].ToString();
                hangDonVi = readNumber[2].ToString();
            }
            else if (readNumber.Length == 2)
            {
                hangDonVi = readNumber[1].ToString();
            }
            if (hangChuc == "0" && hangDonVi == "0")
            {
                return string.Empty;
            }

            if (!string.IsNullOrEmpty(hangChuc) && !string.IsNullOrEmpty(hangDonVi))
            {
                if (hangChuc == "0")
                {
                    readString = readString.Trim();
                }
                else if (hangChuc == "1")
                {
                    readString += "mười";
                }
                else
                {
                    readString += NumberString(Convert.ToInt32(hangChuc)) + " mươi";
                }

                // doc so hang don vi
                if (Convert.ToInt32(hangChuc) >= 1 && hangDonVi == "5")
                {
                    readString += " lăm";
                }
                else if (Convert.ToInt32(hangChuc) > 1 && hangDonVi == "1")
                {
                    readString += " mốt";
                }
                else if (hangDonVi != "0")
                {
                    readString += " " + NumberString(Convert.ToInt32(hangDonVi));
                }

            }
            else if (!string.IsNullOrEmpty(hangDonVi))
            {
                readString += NumberString(Convert.ToInt32(hangDonVi)) + " mươi";
            }


            return readString;
        }

        /// <summary>
        /// so kieu chuoi
        /// </summary>
        /// <param name="intNum"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string NumberString(int intNum)
        {

            string ret = string.Empty;
            switch (intNum)
            {
                case 0:
                    ret = "không";
                    break;
                case 1:
                    ret = "một";
                    break;
                case 2:
                    ret = "hai";
                    break;
                case 3:
                    ret = "ba";
                    break;
                case 4:
                    ret = "bốn";
                    break;
                case 5:
                    ret = "năm";
                    break;
                case 6:
                    ret = "sáu";
                    break;
                case 7:
                    ret = "bảy";
                    break;
                case 8:
                    ret = "tám";
                    break;
                case 9:
                    ret = "chín";
                    break;
                case 10:
                    ret = "mười";
                    break;
            }

            return ret;
        }

        #endregion

        #region Doc so tieng anh

        /// <summary>
        /// Read number by English
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <param name="CurrencyUnit"></param>
        /// <param name="CurrencyUnitSmall"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string ReadNumber(string MyNumber, string CurrencyUnit, string CurrencyUnitSmall)
        {
            string Dollars = "";
            string Cents = "";
            string Temp = "";
            int DecimalPlace = 0;
            int Count = 0;
            string[] Place = new string[10];
            Place[2] = "Thousand ";
            Place[3] = "Million ";
            Place[4] = "Billion ";
            Place[5] = "Trillion ";
            // String representation of amount.
            if (string.IsNullOrEmpty(MyNumber))
            {
                return string.Empty;
            }
            MyNumber = MyNumber.Trim();
            // Position of decimal place 0 if none.
            DecimalPlace = MyNumber.IndexOf(".");
            // Convert cents and set MyNumber to dollar amount.
            if (DecimalPlace > 0)
            {
                Cents = GetTens(Left(Mid(MyNumber, DecimalPlace + 2) + "00", 2));
                MyNumber = (Left(MyNumber, DecimalPlace)).Trim();
            }
            Count = 1;
            while (!string.IsNullOrEmpty(MyNumber))
            {
                Temp = GetHundreds(Right(MyNumber, 3));
                if (!string.IsNullOrEmpty(Temp))
                    Dollars = Temp + Place[Count] + Dollars;
                if (MyNumber.Length > 3)
                {
                    MyNumber = Left(MyNumber, MyNumber.Length - 3);
                }
                else
                {
                    MyNumber = "";
                }
                Count = Count + 1;
            }
            switch (Dollars)
            {
                case "":
                    Dollars = "Zero " + CurrencyUnit;
                    break;
                case "One":
                    Dollars = "One " + CurrencyUnit;
                    break;
                default:
                    Dollars = Dollars + CurrencyUnit;
                    break;
            }
            switch (Cents)
            {
                case "":
                    break;
                //Cents = " Only"
                case "One":
                    Cents = " and One " + CurrencyUnitSmall;
                    break;
                default:
                    Cents = " and " + Cents + CurrencyUnitSmall;
                    break;
            }

            Dollars = Dollars + Cents;
            if (string.IsNullOrEmpty(Dollars))
            {
                return string.Empty;
            }
            else
            {
                Dollars = Dollars.ToLower().Trim();
                if (Dollars.IndexOf(CurrencyUnit, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    Dollars = Dollars.Replace(CurrencyUnit.ToLower(), CurrencyUnit);
                }
                dynamic FirstCharacter = Dollars[0];
                return string.Format("{0}{1}.", FirstCharacter.ToString().ToUpper(), Dollars.Substring(1));
            }

        }

        /// <summary>
        /// Get number Hundreds
        /// </summary>
        /// <param name="MyNumber"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string GetHundreds(string MyNumber)
        {
            string functionReturnValue = null;
            string Result = string.Empty;
            if (int.Parse(MyNumber) == 0)
            {
                return "";
                //return functionReturnValue;
            }
            MyNumber = Right("000" + MyNumber, 3);
            // Convert the hundreds place.
            if (Mid(MyNumber, 1, 1) != "0")
            {
                Result = GetDigit(Mid(MyNumber, 1, 1)) + "Hundred ";
            }
            // Convert the tens and ones place.
            if (Mid(MyNumber, 2, 1) != "0")
            {
                Result = Result + GetTens(Mid(MyNumber, 2));
            }
            else
            {
                Result = Result + GetDigit(Mid(MyNumber, 3));
            }
            functionReturnValue = Result;
            return functionReturnValue;
        }

        /// <summary>
        /// Get Number Tens
        /// </summary>
        /// <param name="TensText"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string GetTens(string TensText)
        {
            string Result = "";
            // Null out the temporary function value.
            // If value between 10-19...
            if (int.Parse(Left(TensText, 1)) == 1)
            {
                switch (int.Parse(TensText))
                {
                    case 10:
                        Result = "Ten ";
                        break;
                    case 11:
                        Result = "Eleven ";
                        break;
                    case 12:
                        Result = "Twelve ";
                        break;
                    case 13:
                        Result = "Thirteen ";
                        break;
                    case 14:
                        Result = "Fourteen ";
                        break;
                    case 15:
                        Result = "Fifteen ";
                        break;
                    case 16:
                        Result = "Sixteen ";
                        break;
                    case 17:
                        Result = "Seventeen ";
                        break;
                    case 18:
                        Result = "Eighteen ";
                        break;
                    case 19:
                        Result = "Nineteen ";
                        break;
                    default:
                        break;
                }
                // If value between 20-99...
            }
            else
            {
                switch (int.Parse(Left(TensText, 1)))
                {
                    case 2:
                        Result = "Twenty ";
                        break;
                    case 3:
                        Result = "Thirty ";
                        break;
                    case 4:
                        Result = "Forty ";
                        break;
                    case 5:
                        Result = "Fifty ";
                        break;
                    case 6:
                        Result = "Sixty ";
                        break;
                    case 7:
                        Result = "Seventy ";
                        break;
                    case 8:
                        Result = "Eighty ";
                        break;
                    case 9:
                        Result = "Ninety ";
                        break;
                    default:
                        break;
                }
                Result = Result + GetDigit(Right(TensText, 1));
                // Retrieve ones place.
            }
            return Result;
        }

        /// <summary>
        /// Get Number Digits
        /// </summary>
        /// <param name="Digit"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        private static string GetDigit(string Digit)
        {
            string functionReturnValue = null;
            switch (int.Parse(Digit))
            {
                case 1:
                    functionReturnValue = "One ";
                    break;
                case 2:
                    functionReturnValue = "Two ";
                    break;
                case 3:
                    functionReturnValue = "Three ";
                    break;
                case 4:
                    functionReturnValue = "Four ";
                    break;
                case 5:
                    functionReturnValue = "Five ";
                    break;
                case 6:
                    functionReturnValue = "Six ";
                    break;
                case 7:
                    functionReturnValue = "Seven ";
                    break;
                case 8:
                    functionReturnValue = "Eight ";
                    break;
                case 9:
                    functionReturnValue = "Nine ";
                    break;
                default:
                    functionReturnValue = "";
                    break;
            }
            return functionReturnValue;
        }

        public static string Left(string Original, int Count)
        {
            // Can't remember if the Left function throws an exception in this case,but for
            // this method, we will just return the original string.
            if (Original == null || Original == string.Empty
                || Original.Length < Count)
            {
                return Original;
            }
            else
            {
                // Return a sub-string of the original string, starting at index 0.
                return Original.Substring(0, Count);
            }
        }

        public static string Right(string Original, int Count)
        {
            // same thing as above.
            if (Original == null || Original == string.Empty
                || Original.Length < Count)
            {
                return Original;
            }
            else
            {
                // blah blah blah
                return Original.Substring(Original.Length - (Count));
            }
        }

        public static string Mid(string param, int startIndex, int length)
        {
            //start at the specified index in the string ang get N number of
            //characters depending on the lenght and assign it to a variable
            string result = param.Substring(startIndex - 1, length);
            //return the result of the operation
            return result;
        }

        public static string Mid(string param, int startIndex)
        {
            //start at the specified index and return all characters after it
            //and assign it to a variable
            string result = param.Substring(startIndex - 1);
            //return the result of the operation
            return result;
        }

        #endregion

        #endregion

        #region Calc
        /// <summary>
        /// Calclator Price by markup
        /// </summary>
        /// <param name="unitPrice"></param>
        /// <param name="markup"></param>
        /// <returns></returns>
        public static decimal CalcUnitPriceByMarkup(decimal unitPrice, decimal markup)
        {
            if (markup == 100m)
            {
                return unitPrice;
            }
            return unitPrice * 100 / (100 - markup);
        }

        /// <summary>
        /// Calculate Markup
        /// </summary>
        public static decimal CalProfit(decimal priceSell, decimal priceCost)
        {
            return Fraction.Round(FractionType.Round4Down5Up, 100 - (priceCost * 100 / priceSell), 2);
        }

        /// <summary>
        /// Update Profit
        /// </summary>
        public static decimal CalSumProfit(decimal totalSell, decimal totalCost)
        {
            decimal ret = 0;

            //Check  total sell
            if (totalSell <= 0)
            {
                return ret;
            }

            //calculate profit
            ret = Fraction.Round(FractionType.Round4Down5Up, ((totalSell - totalCost) / totalSell) * 100, 2);

            if (ret < 0)
            {
                ret = 0;
            }
            return ret;
        }
        #endregion
    }
}
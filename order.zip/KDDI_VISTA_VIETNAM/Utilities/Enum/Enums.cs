﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace OMS.Utilities
{
    /// <summary>
    /// Mode
    /// </summary>
    public enum Mode
    {
        View = 0,
        Insert,
        Update,
        Delete,
        Copy,
        Revise,
        Check
    }

    /// <summary>
    /// Format Type
    /// </summary>
    public enum TypeFormat
    {
        Int,
        Dec
    }
    
    /// <summary>
    /// Enum ExchangeRateDecType
    /// </summary>
    public enum ExchangeRateDecType
    {
        NotDecimal = 0,
        Decimal
    }

    /// <summary>
    /// Enum Color List
    /// </summary>
    public enum ColorList
    {
        Danger = 0,
        Warning,
        Info,
        Success,
        Finish
    }

    /// <summary>
    /// Enum Issued Flag
    /// </summary>
    public enum IssuedFlagEnum
    {
        Unissued = 0,
        Issued
    }

    /// <summary>
    /// Product type
    /// </summary>
    public enum ProductType
    {
        Both = 0,
        Sell,
        Cost
    }

    /// <summary>
    /// Enum VATFlg
    /// </summary>
    public enum VATFlg
    {
        Exclude = 0,
        Include,
        Free
    }

    /// <summary>
    /// Form ID Master
    /// </summary>
    public enum FormId
    {
        Customer = 1,
        Vendor,
        Product,
        Unit,
        Category,
        CategoryStruct,
        ConditionTemplate,
        User,
        GroupUser,
        ExchangeRate,
        CompanyInfo,
        Setting,
        Information,
        Quotation,
        Sales,
        Purchase,
        Delivery,
        Bill,
        [Description("Contract Period")]
        ContractPeriod
    }

    /// <summary>
    /// Authority BI Report
    /// </summary>
    public enum AuthorTypeBIReport
    {
        View = 1,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Authority Master
    /// </summary>
    public enum AuthorTypeMaster
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete,
        ExportExcel
    }

    /// <summary>
    /// Authority Quotation
    /// </summary>
    public enum AuthorTypeQuotation
    {
        View = 1,
        New,
        Edit,
        Copy,
        Sales,
        Revise,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Authority Sales
    /// </summary>
    public enum AuthorTypeSales
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete,
        Remand,
        CreateData,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Authority Puchase
    /// </summary>
    public enum AuthorTypePuchase
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete,
        Check,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Authority Delivery
    /// </summary>
    public enum AuthorTypeDelivery
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete,
        Check,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Authority Billing
    /// </summary>
    public enum AuthorTypeBilling
    {
        View = 1,
        Edit,
        Delete,
        Check,
        ExportExcel,
        ExportPDF
    }

    /// <summary>
    /// Language 
    /// </summary>
    /// <remarks></remarks>
    public enum Language
    {
        /// <summary>
        /// Read number with english
        /// </summary>
        /// <remarks></remarks>
        English,

        /// <summary>
        /// Read number with vietnam
        /// </summary>
        /// <remarks></remarks>
        Vietnam,

        /// <summary>
        /// Read number with japan
        /// </summary>
        /// <remarks></remarks>
        Japan

    }

    /// <summary>
    /// Get User result
    /// </summary>
    public enum UserResultStatus
    {
        EmptyUserCD = -2,
        NotExists = -1,
        NotApproved = 0,
        Disabled = 1,
        Sucessed = 2
    }

    /// <summary>
    /// Code srceen Call this
    /// </summary>
    /// <remarks></remarks>
    public enum FType
    {
        Quote = 1,
        Sales,
        Purchase,
        Billing,//Invoice,
        Delivery
    }

    /// <summary>
    /// Condition Flag
    /// </summary>
    public enum ConditionFlag : int
    {
        Quotation = 0,

        Sales,

        Purchase,

        Billing,//Invoice,

        Delivery
    }

    /// <summary>
    /// Warranty Unit
    /// </summary>
    public enum WarrantyUnit
    {
        None = 0,
        Years,
        Months,
        Weeks,
        Days
    }
}
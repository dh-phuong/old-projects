﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;

namespace OMS.Utilities
{
    /// <summary>
    /// Enum Helper
    /// </summary>
    public static class EnumHelper
    {
        /// <summary>
        /// Get Description
        /// </summary>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        public static string GetDescription(this Enum enumValue)
        {
            string output = null;
            Type type = enumValue.GetType();
            FieldInfo fi = type.GetField(enumValue.ToString());
            var attrs = fi.GetCustomAttributes(typeof(DescriptionAttribute), false) as DescriptionAttribute[];
            if (attrs.Length > 0) output = attrs[0].Description;
            return output;
        }

        ///// <summary>
        ///// Get Enum Values With Description
        ///// ISV-Giam
        ///// </summary>
        ///// <param name="type"></param>
        ///// <returns></returns>
        //public static IList GetEnumValuesWithDescription(this Type type)
        //{
        //    ArrayList list = new ArrayList();
        //    Array enumValues = System.Enum.GetValues(type);

        //    foreach (System.Enum value in enumValues)
        //    {
        //        list.Add(new KeyValuePair<int, string>(Convert.ToInt16(value), GetDescription(value)));
        //    }

        //    return list;
        //}
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Condition DAC
    /// </summary>
    public class ConditionService: BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private ConditionService() :base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public ConditionService(DB db):base(db)
        {
        }
        #endregion

        #region Get Data
        /// <summary>
        /// Get List By Condition
        /// ISV-GIAM
        /// </summary>
        /// <param name="type"></param>
        /// <param name="typeDefault"></param>
        /// <param name="conditionName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<ConditionInfo> GetListByCond(int type, int typeDefault, string conditionName,
            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetByCondition_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_Type_Default", typeDefault);
            base.AddParam(paras, "IN_ConditionName", conditionName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ConditionInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row
        /// ISV-GIAM
        /// </summary>
        /// <param name="type"></param>
        /// <param name="typeDefault"></param>
        /// <param name="conditionName"></param>
        /// <returns></returns>
        public int getTotalRow(int type, int typeDefault, string conditionName)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetTotalRow_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_Type_Default", typeDefault);
            base.AddParam(paras, "IN_ConditionName", conditionName, true);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by condition ID
        /// ISV-GIAM
        /// </summary>
        /// <param name="conditionID">conditionID</param>
        /// <returns></returns>
        public M_Condition GetByID(int conditionID)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetByID_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConditionID", conditionID);

            return this.db.Find<M_Condition>(cmdText, paras);
        }

        /// <summary>
        /// Get By Condition Code
        /// ISV-GIAM
        /// </summary>
        /// <param name="conditionCD">Condition Code</param>
        /// <param name="type">Condition type</param>
        /// <returns></returns>
        public M_Condition GetByCodeAndType(string conditionCD, int type)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetByCodeAndType_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ConditionCD", EditDataUtil.ToFixCodeDB(conditionCD, M_Condition.CONDITION_CODE_MAX_LENGTH));

            return this.db.Find<M_Condition>(cmdText, paras);
        }

        /// <summary>
        /// Get count of list by conditions for the search form
        /// VN-Nho
        /// </summary>
        /// <param name="type">Condtion type</param>
        /// <param name="conditionCD">Condition Code</param>
        /// <param name="conditionName">Condition Name</param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(int type, string conditionCD, string conditionName)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetCountByConditionForSeach_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ConditionCD", conditionCD);
            base.AddParam(paras, "IN_ConditionName", conditionName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list by conditions for the search form
        /// VN-Nho
        /// </summary>
        /// <param name="type">Condition type</param>
        /// <param name="conditionCD">Condition code</param>
        /// <param name="conditionName">Condition Name</param>
        /// <param name="pageIndex">index of page</param>
        /// <param name="pageSize">the number of lines on the page</param>
        /// <param name="sortField">Sort field</param>
        /// <param name="sortDirec">Sort direction</param>
        /// <returns>List of condition information</returns>
        public IList<ConditionSearchInfo> GetListByConditionForSearch(int type, string conditionCD, string conditionName, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Condition_GetByConditionsForSearch_W";

            // Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ConditionCD", conditionCD);
            base.AddParam(paras, "IN_ConditionName", conditionName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<ConditionSearchInfo>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// ISV-GIAM
        /// </summary>
        /// <param name="condition">M_Condition</param>
        /// <returns></returns>
        public int Insert(M_Condition condition)
        {
            //SQL String
            string cmdText = "P_M_Condition_Insert_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_Type", condition.Type);
            base.AddParam(paras,"IN_ConditionCD", EditDataUtil.ToFixCodeDB(condition.ConditionCD, M_Condition.CONDITION_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_ConditionName", condition.ConditionName);
            base.AddParam(paras,"IN_Condition", condition.Condition);
            base.AddParam(paras,"IN_CreateUID", condition.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", condition.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// ISV-GIAM
        /// </summary>
        /// <param name="condition">M_Condition</param>
        /// <returns></returns>
        public int Update(M_Condition condition)
        {
            //SQL String
            string cmdText = "P_M_Condition_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", condition.ID);
            base.AddParam(paras,"IN_Type", condition.Type);
            base.AddParam(paras,"IN_ConditionCD", condition.ConditionCD);
            base.AddParam(paras,"IN_ConditionName", condition.ConditionName);
            base.AddParam(paras,"IN_Condition", condition.Condition);
            base.AddParam(paras,"IN_UpdateDate", condition.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", condition.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// ISV-GIAM
        /// </summary>
        /// <param name="condition">M_Condition</param>
        /// <returns></returns>
        public int Delete(M_Condition condition)
        {
            //SQL String
            string cmdText = "P_M_Condition_Delete_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", condition.ID);
            base.AddParam(paras,"IN_UpdateDate", condition.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check
        #endregion

    }
}

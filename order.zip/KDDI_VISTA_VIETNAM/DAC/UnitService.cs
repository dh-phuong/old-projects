﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Class Unit Service
    /// VN-Nho
    /// </summary>
    public class UnitService :BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor Unit Service
        /// </summary>
        private UnitService() :base()
        {
        }

        /// <summary>
        /// Conructor Unit Service
        /// </summary>
        /// <param name="db">DB Class</param>
        public UnitService(DB db):base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get all data
        /// </summary>
        /// <returns></returns>
        public IList<M_Unit> GetAll()
        {
            string cmdText = "P_M_Unit_GetAll_W";

            return this.db.FindList<M_Unit>(cmdText);
        }

        /// <summary>
        /// Get data for dropdown list
        /// </summary>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(bool withBlank = false)
        {
            string cmdText = "P_M_Unit_GetDataForDropDownList_W";
            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetTotalRow
        /// </summary>
        /// <param name="unitName">unitName</param>
        /// <returns>TotalRow</returns>
        public int GetTotalRow(string unitName)
        {
            //SQL String
            string cmdText = "P_M_Unit_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UnitName", unitName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListCustomerByCondition
        /// </summary>
        /// <param name="unitName">unitName</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<UnitInfo> GetListByCond(string unitName,int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Unit_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UnitName", unitName,true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<UnitInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get by unit ID
        /// </summary>
        /// <param name="unitID">unitID</param>
        /// <returns></returns>
        public M_Unit GetByID(int unitID)
        {
            //SQL String
            string cmdText = "P_M_Unit_GetByID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UnitID", unitID);

            return this.db.Find<M_Unit>(cmdText, paras);
        }

        /// <summary>
        /// Get By unit Code
        /// </summary>
        /// <param name="unitName">unitName</param>
        /// <returns></returns>
        public M_Unit GetByUnitName(string unitName)
        {
            //SQL String
            string cmdText = "P_M_Unit_GetByUnitName_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UnitName", unitName);

            return this.db.Find<M_Unit>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="unit">unit</param>
        /// <returns></returns>
        public int Insert(M_Unit unit)
        {
            //SQL String
            string cmdText = "P_M_Unit_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_UnitName", unit.UnitName);
            base.AddParam(paras,"IN_CreateUID", unit.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", unit.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="customer">M_Customer</param>
        /// <returns></returns>
        public int Update(M_Unit unit)
        {
            //SQL String
            string cmdText = "P_M_Unit_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", unit.ID);
            base.AddParam(paras,"IN_UnitName", unit.UnitName);
            base.AddParam(paras,"IN_UpdateDate", unit.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", unit.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete unit
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int DeleteUnit(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Unit_Delete_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", ID);
            base.AddParam(paras, "@IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

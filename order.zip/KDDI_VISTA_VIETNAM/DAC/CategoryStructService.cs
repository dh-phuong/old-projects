﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Category Struct Service
    /// </summary>
    public class CategoryStructService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of category struct service
        /// </summary>        
        private CategoryStructService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of category struct service
        /// </summary>
        /// <param name="db">Class DB</param>
        public CategoryStructService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data       

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public IList<M_CategoryStruct> GetListByParentID(long structId)
        {
            string cmdText = "P_M_CategoryStruct_GetListByParentID_W";
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_CategoryStructID", structId);
            return this.db.FindList<M_CategoryStruct>(cmdText, prms);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataByLevelForDropDownList(int level, bool withBlank)
        {
            string cmdText = "P_M_CategoryStruct_GetDataByLevelForDropDownList_W";
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_Level", level);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, prms);
            
            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }
            return ret;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="structId"></param>
        /// <returns></returns>
        public IList<CategoryStructInfo> GetChilds(long structId)
        {
            string cmdText = "P_M_CategoryStruct_GetChildsByStructID_W";
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_CategoryStructID", structId);
            return this.db.FindList<CategoryStructInfo>(cmdText, prms);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_CategoryStruct GetByID(long id)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetByID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return base.db.Find<M_CategoryStruct>(cmdText, paras);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public IList<M_CategoryStruct> GetListCategoryParentID(int categoryID,int level)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetListCategoryParentID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryID", categoryID);
            base.AddParam(paras, "IN_Level", level);
            return base.db.FindList<M_CategoryStruct>(cmdText, paras);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public IList<DropDownModel> GetListByCategory1(int categoryId, int childLevel)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetListByCategory1_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryID", categoryId);
            base.AddParam(paras, "IN_ChildLevel", childLevel);
            return base.db.FindList<DropDownModel>(cmdText, paras);
        }

        /// <summary>
        /// Check exists in Product
        /// </summary>
        /// <param name="categoryStructId"></param>
        /// <returns></returns>
        public bool ExistsInProduct(int categoryStructId)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_ExistsInProduct_W";
            Hashtable args = new Hashtable();
            base.AddParam(args, "IN_CategoryStructID", categoryStructId);
            return ((int)base.db.ExecuteScalar(cmdText, args)) > 0;
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public IList<DropDownModel> GetListByCategory1AndCategory2(int categoryId1, int categoryId2)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetListByCategory1AndCategory2_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryID1", categoryId1);
            base.AddParam(paras, "IN_CategoryID2", categoryId2);
            return base.db.FindList<DropDownModel>(cmdText, paras);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_CategoryStruct GetByCategoryIDAndCategoryStructID(int categoryId, int categoryStructID)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetByCategoryIDAndCategoryStructID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryID", categoryId);
            base.AddParam(paras, "IN_CategoryStructID", categoryStructID);
            return base.db.Find<M_CategoryStruct>(cmdText, paras);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public IList<M_CategoryStruct> GetByCategoryIDAndLevel(int categoryId, int level)
        {
            // Command text
            string cmdText = "P_M_CategoryStruct_GetByCategoryIDAndLevel_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryID", categoryId);
            base.AddParam(paras, "IN_Level", level);
            return base.db.FindList<M_CategoryStruct>(cmdText, paras);
        }

        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">M_CategoryStruct</param>
        /// <returns></returns>
        public int Update(M_CategoryStruct data)
        {
            //SQL String
            string cmdText = "P_M_CategoryStruct_Update_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", data.ID);
            base.AddParam(paras, "IN_CategoryID", data.CategoryID);
            base.AddParam(paras, "IN_CategoryStructID", data.CategoryStructID);
            base.AddParam(paras, "IN_Level", data.Level);
            base.AddParam(paras, "IN_NumberOrder", data.NumberOrder);
            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">M_CategoryStruct</param>
        /// <returns></returns>
        public int Insert(M_CategoryStruct data)
        {
            //SQL String
            string cmdText = "P_M_CategoryStruct_Insert_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_CategoryID", data.CategoryID);
            base.AddParam(paras, "IN_CategoryStructID", data.CategoryStructID);
            base.AddParam(paras, "IN_Level", data.Level);
            base.AddParam(paras, "IN_NumberOrder", data.NumberOrder);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            if(this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<M_CategoryStruct>();
            }
            return 0;
        }
        #endregion

        #region Delete

        public int Delete(long ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_CategoryStruct_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Category DAC
    /// </summary>
    public class CategoryService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of category service
        /// </summary>        
        private CategoryService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of category service
        /// </summary>
        /// <param name="db">Class DB</param>
        public CategoryService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data
        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_Category GetByID(int id)
        {
            // Command text
            string cmdText = "P_M_Category_GetByID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return this.db.Find<M_Category>(cmdText, paras);
        }

        /// <summary>
        /// Get by CategoryCD
        /// </summary>
        /// <returns></returns>
        public M_Category GetByCD(string categoryCD)
        {
            // Command text
            string cmdText = "P_M_Category_GetByCD_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryCD", categoryCD);
            return this.db.Find<M_Category>(cmdText, paras);
        }

        /// <summary>
        /// Get by CategoryCD
        /// </summary>
        /// <returns></returns>
        public int GetCategoryParentID(int categoryStructID,int level)
        {
            // Command text
            string cmdText = "P_M_Category_GetCategoryParentID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryStructID", categoryStructID);
            base.AddParam(paras, "IN_Level", level);
            return (int)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get list
        /// </summary>
        /// <returns></returns>
        public IList<M_Category> GetListSortBy(int sortField, int sortDirec)
        {
            // Command text
            string cmdText = "P_M_Category_GetListSortBy_W";
            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_RootCategoryCD", Constant.CATEGORY_ROOT_CODE);

            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<M_Category>(cmdText, paras);
        }

        /// <summary>
        /// Get by condition
        /// </summary>
        /// <param name="categoryCD"></param>
        /// <param name="categoryName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<CategoryInfo> GetListByCond(string categoryCD, string categoryName,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Category_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            
            base.AddParam(paras, "IN_RootCategoryCD", Constant.CATEGORY_ROOT_CODE);

            base.AddParam(paras, "IN_CategoryCD", categoryCD);
            base.AddParam(paras, "IN_CategoryName", categoryName);


            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<CategoryInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get Total row number
        /// </summary>
        /// <param name="categoryCD"></param>
        /// <param name="categoryName"></param>
        /// <returns></returns>
        public int getTotalRow(string categoryCD, string categoryName)
        {
            //SQL String
            string cmdText = "P_M_Category_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CategoryCD", categoryCD);
            base.AddParam(paras, "IN_RootCategoryCD", Constant.CATEGORY_ROOT_CODE);

            base.AddParam(paras, "IN_CategoryName", categoryName);            

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get All Category Not In Struct
        /// </summary>
        /// <param name="conStr">Connect String</param>
        /// <returns>List M_Category</returns>
        public IList<CategoryInfo> GetListNotInStruct(int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            string cmdText = "P_M_Category_GetListNotInStruct_W";

            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_RootCategoryCD", Constant.CATEGORY_ROOT_CODE);
            
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<CategoryInfo>(cmdText, paras);

        }

        /// <summary>
        /// Get Total row number
        /// </summary>
        /// <param name="categoryCD"></param>
        /// <param name="categoryName"></param>
        /// <returns></returns>
        public int getTotalRowNotInStruct()
        {
            //SQL String
            string cmdText = "P_M_Category_GetTotalRow_NotInStruct_W";

            //Para
            Hashtable paras = new Hashtable();
            
            base.AddParam(paras, "IN_RootCategoryCD", Constant.CATEGORY_ROOT_CODE);            
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">M_Category</param>
        /// <returns></returns>
        public int Insert(M_Category data)
        {
            //SQL String
            string cmdText = "P_M_Category_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_CategoryCD", data.CategoryCD);
            base.AddParam(paras,"IN_CategoryName", data.CategoryName);

            base.AddParam(paras,"IN_CreateUID", data.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">M_Category</param>
        /// <returns></returns>
        public int Update(M_Category data)
        {
            //SQL String
            string cmdText = "P_M_Category_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", data.ID);

            base.AddParam(paras,"IN_CategoryCD", data.CategoryCD);
            base.AddParam(paras,"IN_CategoryName", data.CategoryName);
            
            base.AddParam(paras,"IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Category_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

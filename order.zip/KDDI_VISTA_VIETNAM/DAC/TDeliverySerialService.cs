﻿using System.Collections;
using System.Collections.Generic;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// TDeliverySerial DAC
    /// ISV-TRUC
    /// </summary>
    public class TDeliverySerialService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Serial service
        /// </summary>
        private TDeliverySerialService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Serial service
        /// </summary>
        /// <param name="db">Class DB</param>
        public TDeliverySerialService(DB db)
            : base(db)
        {
        }

        #endregion Contructor

        #region Get

        /// <summary>
        /// Get List By Key
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Delivery_Serial> GetListByKey(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_GetListByDeliveryID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Delivery_Serial>(cmdText, paras);
        }

        /// <summary>
        /// Get List By Key
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Delivery_Serial> GetListForDeliveryPDF(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_GetListForDeliveryPDF_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Delivery_Serial>(cmdText, paras);
        }

        public IList<T_Delivery_Serial> GetList()
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_GetList_W";

            //Param
            Hashtable paras = new Hashtable();

            return this.db.FindList<T_Delivery_Serial>(cmdText, paras);
        }

        /// <summary>
        /// Get List From Purchase Serial
        /// Create author: ISV-HUNG
        /// Create date: 2015/07/09
        /// </summary>
        /// <param name="salesDSellID"></param>
        /// <returns></returns>
        public IList<T_Delivery_Serial> GetListFromPurchaseSerial(int salesDSellID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_GetListFromPurchaseSerial_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDSellID", salesDSellID);

            return this.db.FindList<T_Delivery_Serial>(cmdText, paras);
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="acceptC"></param>
        /// <returns></returns>
        public int Insert(T_Delivery_Serial serial)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", serial.DeliveryDID);
            base.AddParam(paras, "IN_No", serial.No);

            base.AddParam(paras, "IN_SerialNo", serial.SerialNo);
            base.AddParam(paras, "IN_ContractType", serial.ContractType);
            base.AddParam(paras, "IN_Terms", serial.Terms);
            base.AddParam(paras, "IN_TermUnit", serial.TermUnit);
            base.AddParam(paras, "IN_StartDate", serial.StartDate);
            base.AddParam(paras, "IN_FinishDate", serial.FinishDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion Insert

        #region Delete

        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="id">ID</param>
        /// <param name="gridID">gridID</param>
        /// <returns></returns>
        public int Delete(int id, int gridID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_No", gridID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete By Shipping Detail ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public int DeleteByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_Serial_DeleteByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion Delete
    }
}
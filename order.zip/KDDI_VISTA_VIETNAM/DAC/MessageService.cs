﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Message Service
    /// </summary>
    public class MessageService
    {
        #region Constructor
        /// <summary>
        /// Class DB
        /// </summary>
        private DB db;

        private MessageService() 
        {
        }

        public MessageService(DB db)
        {
            this.db = db;
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get All
        /// </summary>
        /// <returns>List Message</returns>
        public IList<M_Message> GetAll()
        {
            string cmdText = "P_M_Message_GetAll_W";
            return this.db.FindList<M_Message>(cmdText, new Hashtable());
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;


namespace OMS.DAC
{
    /// <summary>
    /// Class Vendor product service
    /// Author: VN-Nho
    /// Create date: 2014/09/24
    /// </summary>
    public class VendorProductService : BaseService
    {

        #region Contructor

        /// <summary>
        /// Contructor of vendor product service
        /// </summary>
        private VendorProductService()
            : base()
        { 
        }

        /// <summary>
        /// Contructor of Vendor product servide
        /// </summary>
        /// <param name="db">Class DB</param>
        public VendorProductService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        /// <summary>
        /// Get by PK
        /// </summary>
        /// <param name="productID">product id</param>
        /// <param name="no">No</param>
        /// <returns>Vendor product</returns>
        public M_VendorProduct GetByPK(int productID, int no)
        {
            //Set command text
            string cmdText = "P_M_VendorProduct_GetByPK_W";

            //Set parameters
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "@IN_No", no);
            base.AddParam(prms, "@IN_ProductID", productID);

            return this.db.Find<M_VendorProduct>(cmdText, prms);
        }

        /// <summary>
        /// Get list by product id
        /// </summary>
        /// <param name="productID">ProductID</param>
        /// <returns>List Vendor product</returns>
        public IList<M_VendorProduct> GetListByProductID(int productID)
        {
            //Set command text
            string cmdText = "P_M_VendorProduct_GetListByProductID_W";

            //Set parameters
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "@IN_ProductID", productID);

            return this.db.FindList<M_VendorProduct>(cmdText, prms);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="model">Insert data</param>
        /// <returns></returns>
        public int Insert(M_VendorProduct model)
        {
            //Set command text
            string cmdText = "P_M_VendorProduct_Insert_W";

            //Set parameters
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "@IN_ProductID", model.ProductID);
            base.AddParam(prms, "@IN_No", model.No);
            base.AddParam(prms, "@IN_VendorID", model.VendorID);
            base.AddParam(prms, "@IN_VendorProductCD", model.VendorProductCD);

            return this.db.ExecuteNonQuery(cmdText, prms);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete by product id
        /// </summary>
        /// <param name="productID"></param>
        /// <returns></returns>
        public int DeleteByProductID(int productID)
        {
            //Set command text
            string cmdText = "P_M_VendorProduct_DeleteByProductID_W";

            //Set parameters
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "@IN_ProductID", productID);

            return this.db.ExecuteNonQuery(cmdText, prms);
        }

        #endregion

    }
}

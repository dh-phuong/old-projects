﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    public class SettingService : BaseService
    {
        #region Constructor

        private SettingService()
            : base()
        {
        }

        public SettingService(DB db)
            : base(db)
        {
        }

        #endregion

        /// <summary>
        /// Get data
        /// </summary>
        /// <returns>M_Setting</returns>
        public M_Setting GetData()
        {
            //SQL String
            string cmdText = "P_M_Setting_GetData_W";
            //Para
            Hashtable paras = new Hashtable();
            return this.db.Find<M_Setting>(cmdText, paras);
        }

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="setting">M_Setting</param>
        /// <returns></returns>
        public int Insert(M_Setting setting)
        {
            //SQL String
            string cmdText = "P_M_Setting_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", setting.QuoteNo);
            base.AddParam(paras, "IN_SalesNo", setting.SalesNo);
            base.AddParam(paras, "IN_PurchaseNo", setting.PurchaseNo);
            base.AddParam(paras, "IN_BillingNo", setting.BillingNo);
            base.AddParam(paras, "IN_DeliveryNo", setting.DeliveryNo);
            base.AddParam(paras, "IN_Logo1", setting.Logo1);
            base.AddParam(paras, "IN_Logo2", setting.Logo2);
            base.AddParam(paras, "IN_AttachPath", setting.AttachPath);
            base.AddParam(paras, "IN_SalesContractFile1", setting.SalesContractFile1);
            base.AddParam(paras, "IN_SalesContractFile2", setting.SalesContractFile2);
            base.AddParam(paras, "IN_SalesContractFile3", setting.SalesContractFile3);
            base.AddParam(paras, "IN_SalesContractFile4", setting.SalesContractFile4);
            base.AddParam(paras, "IN_SalesContractFile5", setting.SalesContractFile5);
            base.AddParam(paras, "IN_AcceptanceReportFile1", setting.AcceptanceReportFile1);
            base.AddParam(paras, "IN_AcceptanceReportFile2", setting.AcceptanceReportFile2);
            base.AddParam(paras, "IN_AcceptanceReportFile3", setting.AcceptanceReportFile3);
            base.AddParam(paras, "IN_AcceptanceReportFile4", setting.AcceptanceReportFile4);
            base.AddParam(paras, "IN_AcceptanceReportFile5", setting.AcceptanceReportFile5);
            base.AddParam(paras, "IN_CreateUID", setting.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", setting.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="setting">M_Setting</param>
        /// <returns></returns>
        public int Update(M_Setting setting)
        {
            //SQL String
            string cmdText = "P_M_Setting_Update_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_QuoteNo", setting.QuoteNo);
            base.AddParam(paras, "IN_SalesNo", setting.SalesNo);
            base.AddParam(paras, "IN_PurchaseNo", setting.PurchaseNo);
            base.AddParam(paras, "IN_BillingNo", setting.BillingNo);
            base.AddParam(paras, "IN_DeliveryNo", setting.DeliveryNo);
            base.AddParam(paras, "IN_Logo1", setting.Logo1);
            base.AddParam(paras, "IN_Logo2", setting.Logo2);
            base.AddParam(paras, "IN_AttachPath", setting.AttachPath);
            base.AddParam(paras, "IN_SalesContractFile1", setting.SalesContractFile1);
            base.AddParam(paras, "IN_SalesContractFile2", setting.SalesContractFile2);
            base.AddParam(paras, "IN_SalesContractFile3", setting.SalesContractFile3);
            base.AddParam(paras, "IN_SalesContractFile4", setting.SalesContractFile4);
            base.AddParam(paras, "IN_SalesContractFile5", setting.SalesContractFile5);
            base.AddParam(paras, "IN_AcceptanceReportFile1", setting.AcceptanceReportFile1);
            base.AddParam(paras, "IN_AcceptanceReportFile2", setting.AcceptanceReportFile2);
            base.AddParam(paras, "IN_AcceptanceReportFile3", setting.AcceptanceReportFile3);
            base.AddParam(paras, "IN_AcceptanceReportFile4", setting.AcceptanceReportFile4);
            base.AddParam(paras, "IN_AcceptanceReportFile5", setting.AcceptanceReportFile5);
            base.AddParam(paras, "IN_UpdateDate", setting.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", setting.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}


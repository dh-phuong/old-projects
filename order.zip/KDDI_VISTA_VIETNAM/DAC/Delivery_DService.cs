﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;


namespace OMS.DAC
{
    /// <summary>
    /// Shipping_D Service
    /// </summary>
    public class Delivery_DService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Shipping_D service
        /// </summary>        
        private Delivery_DService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Shipping_D service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Delivery_DService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get data
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IList<T_Delivery_D> GetListByHID(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_GetByHID_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Delivery_D>(cmdText, paras);
        }

        /// <summary>
        /// Get data by InternalID
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <returns></returns>
        public T_Delivery_D GetByInternalID(int internalId)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_GetByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalId);

            return this.db.Find<T_Delivery_D>(cmdText, paras);
        }

        /// <summary>
        /// Get List By AcceptID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/04
        /// </summary>
        /// <param name="accID"></param>
        /// <returns></returns>
        //public IList<T_Shipping_D> GetListByAcceptID(int accID)
        public int GetListBySalesID(int accID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_GetListBySalesID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesID", accID);

            //return this.db.FindList<T_Shipping_D>(cmdText, paras);
            return (int)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get Sum Quantity By Accept Sell ID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/05
        /// </summary>
        /// <param name="salesSellID"></param>
        /// <returns></returns>
        public decimal GetSumQuantityBySalesSellID(int salesSellID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_GetTotalQtyBySalesSellID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesSellID", salesSellID);

            return (decimal)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get remain quantity by accept sell id
        /// </summary>
        /// <param name="salesSellID">Accept sell id</param>
        /// <param name="deliveryID">Shipping id</param>
        /// <returns>Remain quantity</returns>
        public decimal GetRemainQtyBySalesSellID(int salesSellID, int deliveryID)
        {
            //Set command text
            string cmdText = "P_T_Delivery_D_GetRemainQtyBySalesSellID_W";

            //add prameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesSellID", salesSellID);
            base.AddParam(paras, "IN_DeliveryID", deliveryID);
            var result = this.db.ExecuteScalar(cmdText, paras);
            return decimal.Parse(result == null ? "0" : result.ToString());
        }

        /// <summary>
        /// Get Max Delivery Date By Header ID
        /// </summary>
        /// <param name="headerID"></param>
        /// <returns></returns>
        public DateTime GetMaxDeliveryDate(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_GetMaxDeliveryDate_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);
            var ret = this.db.ExecuteScalar(cmdText, paras);
            if (ret != DBNull.Value || !string.IsNullOrEmpty(ret.ToString()))
            {
                return (DateTime)ret;
            }
            return DateTime.MinValue;
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="deliD">T_Shipping_D</param>
        /// <returns></returns>
        public int Insert(T_Delivery_D deliD)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", deliD.No);
            base.AddParam(paras, "IN_HID", deliD.HID);
            base.AddParam(paras, "IN_SalesSellID", deliD.SalesSellID);
            //base.AddParam(paras, "IN_ProductID", deliD.ProductID);

            base.AddParam(paras, "IN_ProductCD", deliD.ProductCD);
            base.AddParam(paras, "IN_ProductCD_SP", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras, "IN_ProductName", deliD.ProductName);
            base.AddParam(paras, "IN_Description", deliD.Description);
            base.AddParam(paras, "IN_DeliveryQuantity", deliD.DeliveryQuantity);
            base.AddParam(paras, "IN_DeliveryDate", deliD.DeliveryDate);
            base.AddParam(paras, "IN_Remark", deliD.Remark);
            base.AddParam(paras, "IN_UnitID", deliD.UnitID);
            base.AddParam(paras, "IN_VatType", deliD.VATType);
            base.AddParam(paras, "IN_VatRatio", deliD.VATRatio);
            base.AddParam(paras, "IN_UnitPrice", deliD.UnitPrice);
            base.AddParam(paras, "IN_Quantity", deliD.Quantity);
            base.AddParam(paras, "IN_Total", deliD.Total);
            base.AddParam(paras, "IN_VAT", deliD.VAT);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Delivery_D>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update Delivery Qty - Date
        /// </summary>
        /// <param name="shipD">T_Shipping_D</param>
        /// <returns></returns>
        public int UpdateDelivery(T_Delivery_D shipD)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_UpdateDeliveryQuantity_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", shipD.InternalID);
            base.AddParam(paras, "IN_DeliveryQty", shipD.DeliveryQuantity);
            base.AddParam(paras, "IN_DeliveryDate", shipD.DeliveryDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        //Edit:-----ISV-HUNG-----Change update internalID--------------//
        /// <summary>
        /// Update No By InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <param name="sellNo">Sell No</param>
        /// <returns></returns>
        public int UpdateNoByInternalID(int internalID, int sellNo)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_UpdateNoByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);
            base.AddParam(paras, "IN_No", sellNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="item">T_Delivery_D</param>
        /// <returns></returns>
        public int Update(T_Delivery_D item)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_Update_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", item.InternalID);
            base.AddParam(paras, "IN_HID", item.HID);
            base.AddParam(paras, "IN_No", item.No);
            base.AddParam(paras, "IN_SalesSellID", item.SalesSellID);
            base.AddParam(paras, "IN_ProductCD", item.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras, "IN_ProductName", item.ProductName);
            base.AddParam(paras, "IN_Description", item.Description);
            base.AddParam(paras, "IN_Remark", item.Remark);
            base.AddParam(paras, "IN_DeliveryQuantity", item.DeliveryQuantity);
            base.AddParam(paras, "IN_DeliveryDate", item.DeliveryDate);
            base.AddParam(paras, "IN_UnitID", item.UnitID);
            base.AddParam(paras, "IN_UnitPrice", item.UnitPrice);
            base.AddParam(paras, "IN_Quantity", item.Quantity);
            base.AddParam(paras, "IN_Vat", item.VAT);
            base.AddParam(paras, "IN_VatRatio", item.VATRatio);
            base.AddParam(paras, "IN_VatType", item.VATType);
            base.AddParam(paras, "IN_Total", item.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        //Edit:-----ISV-HUNG-----Change update internalID--------------//
        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <param name="sellNo">SellNo</param>
        /// <returns></returns>
        //public int Delete(int hid, int no)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Quote_D_Sell_Delete_W";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_HID", hid);
        //    base.AddParam(paras, "IN_No", no);

        //    return this.db.ExecuteNonQuery(cmdText, paras);
        //}

        /// <summary>
        /// Delete by HID
        /// </summary>
        /// <param name="id">HID</param>
        /// <returns></returns>
        public int Delete(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_DeleteByHID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", id);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        //Edit:-----ISV-HUNG-----Change update internalID--------------//
        /// <summary>
        /// Delete data by InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <returns></returns>
        public int DeleteByInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_D_DeleteByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        //Edit:-----ISV-HUNG-----Change update internalID--------------//
        #endregion
    }
}

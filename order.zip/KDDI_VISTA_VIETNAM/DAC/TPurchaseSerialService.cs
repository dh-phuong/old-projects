﻿using System.Collections;
using System.Collections.Generic;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// TPurchaseSerial DAC
    /// ISV-GIAM
    /// </summary>
    public class TPurchaseSerialService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Serial service
        /// </summary>
        private TPurchaseSerialService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Serial service
        /// </summary>
        /// <param name="db">Class DB</param>
        public TPurchaseSerialService(DB db)
            : base(db)
        {
        }

        #endregion Contructor

        #region Get

        /// <summary>
        /// Get List By Key
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Purchase_Serial> GetListByKey(int id)
        {
            //SQL String
            string cmdText = "P_T_Purchase_Serial_GetListByPurchaseID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Purchase_Serial>(cmdText, paras);
        }

        /// <summary>
        /// Get List
        /// </summary>
        /// <returns></returns>
        public IList<T_Purchase_Serial> GetList()
        {
            //SQL String
            string cmdText = "P_T_Purchase_Serial_GetList_W";

            //Param
            Hashtable paras = new Hashtable();

            return this.db.FindList<T_Purchase_Serial>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="serial"></param>
        /// <returns></returns>
        public int Insert(T_Purchase_Serial serial)
        {
            //SQL String
            string cmdText = "P_T_Purchase_Serial_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", serial.PurchaseDID);
            base.AddParam(paras, "IN_No", serial.No);

            base.AddParam(paras, "IN_SerialNo", serial.SerialNo);
            base.AddParam(paras, "IN_ContractType", serial.ContractType);
            base.AddParam(paras, "IN_Terms", serial.Terms);
            base.AddParam(paras, "IN_TermUnit", serial.TermUnit);
            base.AddParam(paras, "IN_StartDate", serial.StartDate);
            base.AddParam(paras, "IN_FinishDate", serial.FinishDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion Insert

        #region Delete

        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="id">ID</param>
        /// <param name="gridID">gridID</param>
        /// <returns></returns>
        public int Delete(int id, int gridID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_Serial_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_No", gridID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete By Shipping Detail ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public int DeleteByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Purchase_Serial_DeleteByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion Delete
    }
}
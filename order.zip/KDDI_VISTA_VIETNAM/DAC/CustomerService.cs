﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Customer Service
    /// ISV:NGUYEN
    /// </summary>
    public class CustomerService : BaseService
    {

        #region Constructor
        private CustomerService() :base()
        {

        }

        public CustomerService(DB db) : base(db)
        {
        }

        #endregion

        #region Get Data
        /// <summary>
        /// Get list by conditions for the search form
        /// </summary>
        /// <returns>CustomerSearchInfo</returns>
        public IList<CustomerSearchInfo> GetListByConditionForSearch(string customerCD, string customerName, string status, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetByConditionsForSearch_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", customerName, true);
            if (string.IsNullOrEmpty(status))
            {
                base.AddParam(paras, "IN_Status", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Status", status);
            }

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<CustomerSearchInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerCD"></param>
        /// <param name="customerName"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string customerCD, string customerName, string status)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetCountByConditionForSeach_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", customerName, true);
            if(string.IsNullOrEmpty(status)){
                base.AddParam(paras, "IN_Status", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Status",status);
            }
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetTotalRow
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <param name="customerName1">customerName1</param>
        /// <param name="customerName2">customerName2</param>
        /// <param name="inValid">inValid</param>
        /// <param name="address">address</param>
        /// <returns>TotalRow</returns>
        public int GetTotalRow(string customerCD, string customerName1, string inValid, string address)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName1", customerName1, true);
            base.AddParam(paras, "IN_InValid", inValid);
            base.AddParam(paras, "IN_Address", address);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListCustomerByCondition
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <param name="customerName1">customerName1</param>
        /// <param name="customerName2">customerName2</param>
        /// <param name="inValid">inValid</param>
        /// <param name="address">address</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<CustomerInfo> GetListByCond(string customerCD, string customerName1, string inValid, string address,
                                           int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH),true);
            base.AddParam(paras, "IN_CustomerName1", customerName1, true);
            base.AddParam(paras, "IN_InValid", inValid);
            base.AddParam(paras, "IN_Address", address, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<CustomerInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get List For Excel
        /// </summary>
        /// <returns>List CustomerExcel</returns>
        public IList<CustomerExcel> GetListForExcel()
        {
            //SQL String
            string cmdText = "P_M_Customer_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();

            return this.db.FindList<CustomerExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get by customer ID
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns></returns>
        public M_Customer GetByID(int customerID)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetByID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerID", customerID);

            return this.db.Find<M_Customer>(cmdText, paras);
        }

        /// <summary>
        /// Get By Customer Code
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <returns></returns>
        public M_Customer GetByCustomerCD(string customerCD)
        {
            //SQL String
            string cmdText = "P_M_Customer_GetByCustomerCD_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));

            return this.db.Find<M_Customer>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="customer">M_Customer</param>
        /// <returns></returns>
        public int Insert(M_Customer customer)
        {
            //SQL String
            string cmdText = "P_M_Customer_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_CustomerCD", EditDataUtil.ToFixCodeDB(customer.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_CustomerName1", customer.CustomerName1);
            base.AddParam(paras,"IN_CustomerName2", customer.CustomerName2);
            base.AddParam(paras,"IN_CustomerAddress1", customer.CustomerAddress1);
            base.AddParam(paras,"IN_CustomerAddress2", customer.CustomerAddress2);
            base.AddParam(paras,"IN_CustomerAddress3", customer.CustomerAddress3);
            base.AddParam(paras,"IN_CustomerAddress4", customer.CustomerAddress4);
            base.AddParam(paras,"IN_CustomerAddress5", customer.CustomerAddress5);
            base.AddParam(paras,"IN_CustomerAddress6", customer.CustomerAddress6);
            base.AddParam(paras,"IN_Represent", customer.Represent);
            base.AddParam(paras,"IN_Position1", customer.Position1);
            base.AddParam(paras,"IN_Position2", customer.Position2);
            base.AddParam(paras,"IN_EmailAddress", customer.EmailAddress);
            base.AddParam(paras,"IN_Tel", customer.Tel);
            base.AddParam(paras,"IN_FAX", customer.FAX);
            base.AddParam(paras,"IN_ContactPerson", customer.ContactPerson);
            base.AddParam(paras,"IN_ContactTel", customer.ContactTel);
            base.AddParam(paras,"IN_TAXCode", customer.TAXCode);
            base.AddParam(paras,"IN_CustomerBank", customer.CustomerBank);
            base.AddParam(paras,"IN_AccountCode", customer.AccountCode);
            base.AddParam(paras,"IN_StatusFlag", customer.StatusFlag);
            base.AddParam(paras,"IN_CreateUID", customer.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", customer.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="customer">M_Customer</param>
        /// <returns></returns>
        public int Update(M_Customer customer)
        {
            //SQL String
            string cmdText = "P_M_Customer_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", customer.ID);
            base.AddParam(paras,"IN_CustomerCD", EditDataUtil.ToFixCodeDB(customer.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_CustomerName1", customer.CustomerName1);
            base.AddParam(paras,"IN_CustomerName2", customer.CustomerName2);
            base.AddParam(paras,"IN_CustomerAddress1", customer.CustomerAddress1);
            base.AddParam(paras,"IN_CustomerAddress2", customer.CustomerAddress2);
            base.AddParam(paras,"IN_CustomerAddress3", customer.CustomerAddress3);
            base.AddParam(paras,"IN_CustomerAddress4", customer.CustomerAddress4);
            base.AddParam(paras,"IN_CustomerAddress5", customer.CustomerAddress5);
            base.AddParam(paras,"IN_CustomerAddress6", customer.CustomerAddress6);
            base.AddParam(paras,"IN_Represent", customer.Represent);
            base.AddParam(paras,"IN_Position1", customer.Position1);
            base.AddParam(paras,"IN_Position2", customer.Position2);
            base.AddParam(paras,"IN_EmailAddress", customer.EmailAddress);
            base.AddParam(paras,"IN_Tel", customer.Tel);
            base.AddParam(paras,"IN_FAX", customer.FAX);
            base.AddParam(paras,"IN_ContactPerson", customer.ContactPerson);
            base.AddParam(paras,"IN_ContactTel", customer.ContactTel);
            base.AddParam(paras,"IN_TAXCode", customer.TAXCode);
            base.AddParam(paras,"IN_CustomerBank", customer.CustomerBank);
            base.AddParam(paras,"IN_AccountCode", customer.AccountCode);
            base.AddParam(paras,"IN_StatusFlag", customer.StatusFlag);
            base.AddParam(paras,"IN_UpdateDate", customer.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", customer.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete Customer
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int DeleteCustomer(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Customer_Delete_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", ID);
            base.AddParam(paras, "@IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Check

        ///<summary>
        ///Check exist Customer TAX Code in Customer table
        ///</summary>
        /// <param name="TaxCode">TAX Code</param>
        /// <returns>State</returns>
        /// <remarks>True: exist, False: Node exist</remarks>
        public bool IsExistTaxCode(string TaxCode)
        {
            string cmdText = "P_M_Customer_IsExistTaxCode_W";

            Hashtable paras = new Hashtable();

            //Add Para
            base.AddParam(paras,"@IN_TaxCode", TaxCode);

            return ((int)this.db.ExecuteScalar(cmdText, paras) > 0);

        }

        /// <summary>
        /// Is Exist Tax Code With CustomerCD
        /// </summary>
        /// <param name="customerCD">CustomerCD</param>
        /// <param name="taxCode">Tax Code</param>
        /// <returns></returns>
        public bool IsExistTaxCDWithCustomerCD(string customerCD, string taxCode)
        {
            //SQL String
            string cmdText = "P_M_Customer_IsExistTaxCodeWithCustomerCD_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_TaxCode", taxCode);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    public sealed class Quotation_D_CostService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Quotation_D_Cost service
        /// </summary>        
        private Quotation_D_CostService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Quotation_D_Cost service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Quotation_D_CostService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get
        /// <summary>
        /// Gets the by pk.
        /// </summary>
        /// <param name="hid">The hid.</param>
        /// <param name="sellNo">The sell no.</param>
        /// <returns></returns>
        public IList<T_Quote_D_Cost> GetBySell(int hid, int sellNo)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_GetBySell_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", hid);
            base.AddParam(paras, "IN_SellNo", sellNo);

            return this.db.FindList<T_Quote_D_Cost>(cmdText, paras);
        }

        /// <summary>
        /// Get List By HID
        /// </summary>
        public IList<T_Quote_D_Cost> GetListByHID(int id)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_GetByHID_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Quote_D_Cost>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="cost">Cost</param>
        /// <returns></returns>
        public int Insert(T_Quote_D_Cost cost)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", cost.HID);
            base.AddParam(paras, "IN_SellNo", cost.SellNo);
            base.AddParam(paras, "IN_No", cost.No);
            //base.AddParam(paras,"IN_ProductID", cost.ProductID);
            base.AddParam(paras, "IN_ProductCD", cost.ProductCD);
            base.AddParam(paras, "IN_ProductCD_SP", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras, "IN_ProductName", cost.ProductName);
            base.AddParam(paras, "IN_Description", cost.Description);
            base.AddParam(paras, "IN_UnitID", cost.UnitID);
            base.AddParam(paras, "IN_CurrencyID", cost.CurrencyID);
            base.AddParam(paras, "IN_VatType", cost.VatType);
            base.AddParam(paras, "IN_VatRatio", cost.VatRatio);
            base.AddParam(paras, "IN_PurchaseFlag", cost.PurchaseFlag);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(cost.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorCD_SP", EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorName", cost.VendorName);
            base.AddParam(paras, "IN_UnitPrice", cost.UnitPrice);
            base.AddParam(paras, "IN_Quantity", cost.Quantity);
            base.AddParam(paras, "IN_Total", cost.Total);
            base.AddParam(paras, "IN_Vat", cost.Vat);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        //#region Update
        ///// <summary>
        ///// Insert
        ///// </summary>
        ///// <param name="cost">Cost</param>
        ///// <returns></returns>
        //public int Update(T_Quote_D_Cost cost)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Quote_D_Cost_Update_W";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_HID", cost.HID);
        //    base.AddParam(paras, "IN_SellNo", cost.SellNo);
        //    base.AddParam(paras, "IN_No", cost.No);

        //    //base.AddParam(paras, "IN_ProductID", cost.ProductID);
        //    base.AddParam(paras, "IN_ProductCD", cost.ProductCD);
        //    base.AddParam(paras, "IN_ProductCD_SP", M_Product.PRODUCT_CODE_SUPPORT);
        //    base.AddParam(paras, "IN_ProductName", cost.ProductName);
        //    base.AddParam(paras, "IN_Description", cost.Description);
        //    base.AddParam(paras, "IN_UnitID", cost.UnitID);
        //    base.AddParam(paras, "IN_CurrencyID", cost.CurrencyID);
        //    base.AddParam(paras, "IN_VatType", cost.VatType);
        //    base.AddParam(paras, "IN_VatRatio", cost.VatRatio);
        //    base.AddParam(paras, "IN_PurchaseFlag", cost.PurchaseFlag);
        //    base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(cost.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
        //    base.AddParam(paras, "IN_VendorCD_SP", EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Vendor.VENDOR_CODE_MAX_LENGTH));
        //    base.AddParam(paras, "IN_VendorName", cost.VendorName);
        //    base.AddParam(paras, "IN_UnitPrice", cost.UnitPrice);
        //    base.AddParam(paras, "IN_Quantity", cost.Quantity);
        //    base.AddParam(paras, "IN_Total", cost.Total);
        //    base.AddParam(paras, "IN_Vat", cost.Vat);

        //    return this.db.ExecuteNonQuery(cmdText, paras);
        //}
        //#endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <param name="sellNo">SellNo</param>
        /// <param name="no">No</param>
        /// <returns></returns>
        public int Delete(int hid, int sellNo, int no)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_Delete_ByKey_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            base.AddParam(paras, "IN_SellNo", sellNo);
            base.AddParam(paras, "IN_No", no);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <param name="sellNo">SellNo</param>
        /// <returns></returns>
        public int Delete(int hid, int sellNo)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_Delete_Multi_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            base.AddParam(paras, "IN_SellNo", sellNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <returns></returns>
        public int Delete(int hid)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Cost_Delete_ByHID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

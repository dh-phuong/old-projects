﻿using System.Collections;

using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Class Sales_CService DAC
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Sales_CService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Sales_CService()
            :base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Sales_CService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public T_Sales_C GetByPK(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_C_GetByPK_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.Find<T_Sales_C>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/08/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="salesC">T_Sales_C</param>
        /// <returns></returns>
        public int Insert(T_Sales_C salesC)
        {
            //SQL String
            string cmdText = "P_T_Sales_C_Insert_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", salesC.HID);
            base.AddParam(paras, "IN_Conditions", salesC.Conditions);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Date: 2014/08/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_C_Delete_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
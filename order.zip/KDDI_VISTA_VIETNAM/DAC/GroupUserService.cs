﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// class GroupUser DAC
    /// ISV-TRUC
    /// </summary>
    public class GroupUserService: BaseService
    {
        #region Constructor
        private GroupUserService() :base()
        {

        }

        public GroupUserService(DB db):base(db)
        {
        }
        #endregion

        #region Get Data

        #region Entity

        /// <summary>
        /// Get by Group CD
        /// </summary>
        /// <returns>M_GroupUser</returns>
        public M_GroupUser_H GetByGroupCD(string groupCD)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_GetByCd_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupCD", EditDataUtil.ToFixCodeDB(groupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH));

            return this.db.Find<M_GroupUser_H>(cmdText, paras);
        }

        /// <summary>
        /// Get By Group ID
        /// </summary>
        /// <param name="groupID">groupID</param>
        /// <returns></returns>
        public M_GroupUser_H GetByGroupID(int groupID)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_H_GetByID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupID", groupID);

            return this.db.Find<M_GroupUser_H>(cmdText, paras);
        }

        #endregion

        #region List Entity

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<GroupUserInfo> GetListByCond(string groupCD, string groupName,
                                                  int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupCode", EditDataUtil.ToFixCodeDB(groupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH), true);
            base.AddParam(paras, "IN_GroupName", groupName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<GroupUserInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get List By Condition For Search
        /// </summary>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<GroupUserSearchInfo> GetListByConditionForSearch(string groupCD, string groupName,
                                                                        int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_GetByConditionsForSearch_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupCD", groupCD, true);
            base.AddParam(paras, "IN_GroupName", groupName, true);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<GroupUserSearchInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get List Group User Detail
        /// </summary>
        /// <returns></returns>
        public IList<M_GroupUser_D> GetListGroupUserDetail(int groupID)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_D_GetListForDetail_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupID", groupID);

            return this.db.FindList<M_GroupUser_D>(cmdText, paras);
        }

        #endregion

        #region Get Total Row

        /// <summary>
        /// Get Count By Condition For Search
        /// </summary>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string groupCD, string groupName)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_GetCountByConditionForSeach_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupCD", groupCD, true);
            base.AddParam(paras, "IN_GroupName", groupName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <returns></returns>
        public int getTotalRowForList(string groupCD, string groupName)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupCode", EditDataUtil.ToFixCodeDB(groupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH), true);
            base.AddParam(paras, "IN_GroupName", groupName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion

        public M_GroupUser_D GetByGroupAndFormID(int groupID, int formID)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_D_GetByGroupAndFormID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_GroupID", groupID);
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.Find<M_GroupUser_D>(cmdText, paras);
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">M_GroupUser</param>
        /// <returns></returns>
        public int Insert(M_GroupUser_H m_GroupUser)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_H_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_GroupCD", EditDataUtil.ToFixCodeDB(m_GroupUser.GroupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH));
            base.AddParam(paras,"IN_GroupName", m_GroupUser.GroupName);

            base.AddParam(paras,"IN_CreateUID", m_GroupUser.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", m_GroupUser.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="m_GroupUser">M_GroupUser_M</param>
        /// <returns></returns>
        public int Insert(M_GroupUser_D m_GroupUser)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_D_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_GroupID", m_GroupUser.GroupID);            
            base.AddParam(paras,"IN_FormID", m_GroupUser.FormID);
            base.AddParam(paras,"IN_FormName", m_GroupUser.FormName);

            base.AddParam(paras,"IN_AuthorityFlag1", m_GroupUser.AuthorityFlag1);
            base.AddParam(paras,"IN_AuthorityFlag2", m_GroupUser.AuthorityFlag2);
            base.AddParam(paras,"IN_AuthorityFlag3", m_GroupUser.AuthorityFlag3);
            base.AddParam(paras,"IN_AuthorityFlag4", m_GroupUser.AuthorityFlag4);
            base.AddParam(paras,"IN_AuthorityFlag5", m_GroupUser.AuthorityFlag5);
            base.AddParam(paras,"IN_AuthorityFlag6", m_GroupUser.AuthorityFlag6);
            base.AddParam(paras,"IN_AuthorityFlag7", m_GroupUser.AuthorityFlag7);
            base.AddParam(paras,"IN_AuthorityFlag8", m_GroupUser.AuthorityFlag8);
            base.AddParam(paras,"IN_AuthorityFlag9", m_GroupUser.AuthorityFlag9);
            base.AddParam(paras,"IN_AuthorityFlag10", m_GroupUser.AuthorityFlag10);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="m_GroupUser_H">M_GroupUser</param>
        /// <returns></returns>
        public int Update(M_GroupUser_H m_GroupUser_H)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_H_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_GroupID", m_GroupUser_H.ID);
            base.AddParam(paras,"IN_GroupCD", EditDataUtil.ToFixCodeDB(m_GroupUser_H.GroupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH));
            base.AddParam(paras,"IN_GroupName", m_GroupUser_H.GroupName);

            base.AddParam(paras,"IN_UpdateDate", m_GroupUser_H.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", m_GroupUser_H.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="m_GroupUser_M"></param>
        /// <returns></returns>
        public int Update(M_GroupUser_D m_GroupUser_M)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_D_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_GroupID", m_GroupUser_M.GroupID);            
            base.AddParam(paras,"IN_FormID", m_GroupUser_M.FormID);
            base.AddParam(paras,"IN_FormName", m_GroupUser_M.FormName);
            base.AddParam(paras,"IN_AuthorityFlag1", m_GroupUser_M.AuthorityFlag1);
            base.AddParam(paras,"IN_AuthorityFlag2", m_GroupUser_M.AuthorityFlag2);
            base.AddParam(paras,"IN_AuthorityFlag3", m_GroupUser_M.AuthorityFlag3);
            base.AddParam(paras,"IN_AuthorityFlag4", m_GroupUser_M.AuthorityFlag4);
            base.AddParam(paras,"IN_AuthorityFlag5", m_GroupUser_M.AuthorityFlag5);
            base.AddParam(paras,"IN_AuthorityFlag6", m_GroupUser_M.AuthorityFlag6);
            base.AddParam(paras,"IN_AuthorityFlag7", m_GroupUser_M.AuthorityFlag7);
            base.AddParam(paras,"IN_AuthorityFlag8", m_GroupUser_M.AuthorityFlag8);
            base.AddParam(paras,"IN_AuthorityFlag9", m_GroupUser_M.AuthorityFlag9);
            base.AddParam(paras,"IN_AuthorityFlag10", m_GroupUser_M.AuthorityFlag10);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete Group detail
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        public int DeleteDetail(int groupID)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_D_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", groupID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete group header
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int DeleteHeader(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_GroupUser_H_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check
        #endregion
    }
}

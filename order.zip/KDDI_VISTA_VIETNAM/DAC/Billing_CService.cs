﻿using System.Collections;
using OMS.Models;

namespace OMS.DAC
{
    public class Billing_CService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Billing_CService() :base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Billing_CService(DB db):base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get by ID
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public T_Billing_C GetByPK(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Billing_C_GetByPK_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.Find<T_Billing_C>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="billingC"></param>
        /// <returns></returns>
        public int Insert(T_Billing_C billingC)
        {
            //SQL String
            string cmdText = "P_T_Billing_C_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", billingC.HID);
            base.AddParam(paras,"IN_Conditions", billingC.Conditions);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Billing_C_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

    }
}

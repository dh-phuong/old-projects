﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Company service
    /// </summary>
    public class CompanyService:BaseService
    {

         #region Constructor
       
        private CompanyService():base()
        {

        }

        public CompanyService(DB db):base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get data
        /// </summary>
        /// <returns>M_User</returns>
        public M_Company GetData()
        {
            //SQL String
            string cmdText = "P_M_Company_GetData_W";
            //Para
            Hashtable paras = new Hashtable();
            return this.db.Find<M_Company>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="company">M_Company</param>
        /// <returns></returns>
        public int Insert(M_Company company)
        {
            //SQL String
            string cmdText = "P_M_Company_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_CompanyName1", company.CompanyName1);
            base.AddParam(paras,"IN_CompanyName2", company.CompanyName2);
            base.AddParam(paras,"IN_CompanyAddress1", company.CompanyAddress1);
            base.AddParam(paras,"IN_CompanyAddress2", company.CompanyAddress2);
            base.AddParam(paras,"IN_CompanyAddress3", company.CompanyAddress3);
            base.AddParam(paras,"IN_CompanyAddress4", company.CompanyAddress4);
            base.AddParam(paras,"IN_CompanyAddress5", company.CompanyAddress5);
            base.AddParam(paras,"IN_CompanyAddress6", company.CompanyAddress6);
            base.AddParam(paras,"IN_Tel", company.Tel);
            base.AddParam(paras,"IN_Tel2", company.Tel2);
            base.AddParam(paras,"IN_FAX", company.FAX);
            base.AddParam(paras,"IN_EmailAddress", company.EmailAddress);
            base.AddParam(paras,"IN_TAXCode", company.TAXCode);
            base.AddParam(paras,"IN_CompanyBank", company.CompanyBank);
            base.AddParam(paras,"IN_AccountCode", company.AccountCode);
            base.AddParam(paras,"IN_Represent", company.Represent);
            base.AddParam(paras,"IN_Position", company.Position);
            base.AddParam(paras,"IN_Position2", company.Position2);
            base.AddParam(paras,"IN_CreateUID", company.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", company.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_Company</param>
        /// <returns></returns>
        public int Update(M_Company company)
        {
            //SQL String
            string cmdText = "P_M_Company_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_CompanyName1", company.CompanyName1);
            base.AddParam(paras,"IN_CompanyName2", company.CompanyName2);
            base.AddParam(paras,"IN_CompanyAddress1", company.CompanyAddress1);
            base.AddParam(paras,"IN_CompanyAddress2", company.CompanyAddress2);
            base.AddParam(paras,"IN_CompanyAddress3", company.CompanyAddress3);
            base.AddParam(paras,"IN_CompanyAddress4", company.CompanyAddress4);
            base.AddParam(paras,"IN_CompanyAddress5", company.CompanyAddress5);
            base.AddParam(paras,"IN_CompanyAddress6", company.CompanyAddress6);
            base.AddParam(paras,"IN_Tel", company.Tel);
            base.AddParam(paras,"IN_Tel2", company.Tel2);
            base.AddParam(paras,"IN_FAX", company.FAX);
            base.AddParam(paras,"IN_EmailAddress", company.EmailAddress);
            base.AddParam(paras,"IN_TAXCode", company.TAXCode);
            base.AddParam(paras,"IN_CompanyBank", company.CompanyBank);
            base.AddParam(paras,"IN_AccountCode", company.AccountCode);
            base.AddParam(paras,"IN_Represent", company.Represent);
            base.AddParam(paras,"IN_Position", company.Position);
            base.AddParam(paras,"IN_Position2", company.Position2);
            base.AddParam(paras,"IN_UpdateDate", company.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", company.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

    }
}


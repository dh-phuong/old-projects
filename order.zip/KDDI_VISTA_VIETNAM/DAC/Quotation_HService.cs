﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Quotation_H Service
    /// </summary>
    public sealed class Quotation_HService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Quotation_H service
        /// </summary>        
        private Quotation_HService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Quotation_H service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Quotation_HService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get
        
        /// <summary>
        /// Get List By Condition
        /// ISV-TRUC
        /// </summary>
        /// <param name="inputModel">QuotationHeaderSearch</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns>QuotationHeaderResult List</returns>
        public IList<QuotationHeaderResult> GetListByCond(QuotationHeaderSearch inputModel,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            //string cmdText = "P_T_Quote_H_GetByCond_W";
            string cmdText = "P_T_Quote_H_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            //base.AddParam(paras, "IN_StatusName", inputModel.StatusName);
            //base.AddParam(paras, "IN_StatusFlag", inputModel.Status);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);

            base.AddParam(paras, "IN_StatusFlgLost",(int)Models.StatusFlag.Lost);
            base.AddParam(paras, "IN_StatusFlgSales", (int)Models.StatusFlag.Sales);

            if (inputModel.Status == -1)
            {
                base.AddParam(paras, "IN_StatusFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StatusFlag", inputModel.Status);
            }
            
            base.AddParam(paras, "IN_QuoteDateFrm", inputModel.QuoteDateFrom);
            base.AddParam(paras, "IN_QuoteDateTo", inputModel.QuoteDateTo);
            //base.AddParam(paras, "IN_EstRevenueDateFrm", inputModel.EstRevenueDateFrom);
            //base.AddParam(paras, "IN_EstRevenueDateTo", inputModel.EstRevenueDateTo);
            //base.AddParam(paras, "IN_EstOrderDateFrm", inputModel.EstOrderDateFrom);
            //base.AddParam(paras, "IN_EstOrderDateTo", inputModel.EstOrderDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(inputModel.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(inputModel.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            //base.AddParam(paras, "IN_TotalFrom", inputModel.TotalFrom);
            //base.AddParam(paras, "IN_TotalTo", inputModel.TotalTo);
            //base.AddParam(paras, "IN_GrandTotalFrom", inputModel.GrandTotalFrom);
            //base.AddParam(paras, "IN_GrandTotalTo", inputModel.GrandTotalTo);

            //base.AddParam(paras, "IN_FrontSalesCD", EditDataUtil.ToFixCodeDB(inputModel.FrontSalesCD, M_User.USER_CODE_MAX_LENGTH));
            //base.AddParam(paras, "IN_EngineerCD", EditDataUtil.ToFixCodeDB(inputModel.EngineerCD, M_User.USER_CODE_MAX_LENGTH));
            //base.AddParam(paras, "IN_InchargeCD", EditDataUtil.ToFixCodeDB(inputModel.InchargeCD, M_User.USER_CODE_MAX_LENGTH));

            //base.AddParam(paras, "IN_VatRatioFrom", inputModel.VatRatioFrom);
            //base.AddParam(paras, "IN_VatRatioTo", inputModel.VatRatioTo);
            //if (inputModel.Currency == -1)//not selected
            //{
            //    base.AddParam(paras, "IN_Currency", DBNull.Value);
            //}
            //else
            //{
            //    base.AddParam(paras, "IN_Currency", inputModel.Currency);
            //}
            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_InValid", inputModel.Invalid);
            base.AddParam(paras, "IN_Sales", inputModel.Sales);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<QuotationHeaderResult>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row By Condition
        /// ISV-TRUC
        /// </summary>
        /// <param name="inputModel">QuotationHeaderSearch</param>
        /// <returns>Total Row</returns>
        public int GetTotalRow(QuotationHeaderSearch inputModel)
        {
            //SQL String
            //string cmdText = "P_T_Quote_H_GetTotalRow_W";
            string cmdText = "P_T_Quote_H_GetTotalRow_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            //base.AddParam(paras, "IN_StatusName", inputModel.StatusName);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);

            base.AddParam(paras, "IN_StatusFlgLost",(int) Models.StatusFlag.Lost);
            base.AddParam(paras, "IN_StatusFlgSales", (int)Models.StatusFlag.Sales);
            if (inputModel.Status == -1)
            {
                base.AddParam(paras, "IN_StatusFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StatusFlag", inputModel.Status);
            }
            base.AddParam(paras, "IN_QuoteDateFrm", inputModel.QuoteDateFrom);
            base.AddParam(paras, "IN_QuoteDateTo", inputModel.QuoteDateTo);
            //base.AddParam(paras, "IN_EstRevenueDateFrm", inputModel.EstRevenueDateFrom);
            //base.AddParam(paras, "IN_EstRevenueDateTo", inputModel.EstRevenueDateTo);
            //base.AddParam(paras, "IN_EstOrderDateFrm", inputModel.EstOrderDateFrom);
            //base.AddParam(paras, "IN_EstOrderDateTo", inputModel.EstOrderDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(inputModel.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(inputModel.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            //base.AddParam(paras, "IN_TotalFrom", inputModel.TotalFrom);
            //base.AddParam(paras, "IN_TotalTo", inputModel.TotalTo);
            //base.AddParam(paras, "IN_GrandTotalFrom", inputModel.GrandTotalFrom);
            //base.AddParam(paras, "IN_GrandTotalTo", inputModel.GrandTotalTo);
            //base.AddParam(paras, "IN_VatRatioFrom", inputModel.VatRatioFrom);
            //base.AddParam(paras, "IN_VatRatioTo", inputModel.VatRatioTo);
            //base.AddParam(paras, "IN_FrontSalesCD", EditDataUtil.ToFixCodeDB(inputModel.FrontSalesCD, M_User.USER_CODE_MAX_LENGTH));
            //base.AddParam(paras, "IN_EngineerCD", EditDataUtil.ToFixCodeDB(inputModel.EngineerCD, M_User.USER_CODE_MAX_LENGTH));
            //base.AddParam(paras, "IN_InchargeCD", EditDataUtil.ToFixCodeDB(inputModel.InchargeCD, M_User.USER_CODE_MAX_LENGTH));

            //base.AddParam(paras, "IN_Currency", inputModel.Currency);
            //if (inputModel.Currency == -1)//not selected
            //{
            //    base.AddParam(paras, "IN_Currency", DBNull.Value);
            //}
            //else
            //{
            //    base.AddParam(paras, "IN_Currency", inputModel.Currency);
            //}
            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_InValid", inputModel.Invalid);
            base.AddParam(paras, "IN_Sales", inputModel.Sales);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by primary key
        /// Create Author: ISV-GIAM
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public T_Quote_H GetByPK(int id)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_GetByPK_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Quote_H>(cmdText, paras);
        }

        /// <summary>
        /// GetListForExcel
        /// </summary>
        /// <param name="inputModel">QuotationHeaderSearch</param>
        /// <returns>IList<QuotationeExcel></returns>
        public IList<QuotationExcel> GetListForExcel(QuotationHeaderSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);

            base.AddParam(paras, "IN_StatusFlgLost", (int)Models.StatusFlag.Lost);
            base.AddParam(paras, "IN_StatusFlgSales", (int)Models.StatusFlag.Sales);

            if (inputModel.Status == -1)
            {
                base.AddParam(paras, "IN_StatusFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StatusFlag", inputModel.Status);
            }

            base.AddParam(paras, "IN_QuoteDateFrm", inputModel.QuoteDateFrom);
            base.AddParam(paras, "IN_QuoteDateTo", inputModel.QuoteDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(inputModel.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(inputModel.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_InValid", inputModel.Invalid);
            base.AddParam(paras, "IN_Sales", inputModel.Sales);
            base.AddParam(paras, "IN_VatType", M_Config_H.CONFIG_CD_VAT_TYPE);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_FRACTION_TYPE);
            return this.db.FindList<QuotationExcel>(cmdText, paras);
        }

        /// <summary>
        /// Create Quote No Revise
        /// </summary>
        /// <param name="quoteNo">QuoteNo</param>
        /// <returns>Quote No Revise</returns>
        /// <remarks></remarks>
        public string CreateQuoteNoRevise(string quoteNo)
        {
            string cmdText = "P_T_Quote_H_CreateQuoteNoRevise_W";
            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", quoteNo);

            string ret =(string)base.db.ExecuteScalar(cmdText, paras); 

            return ret.Trim();
        }

        /// <summary>
        /// Get by quote No
        /// Create Date: 2014/08/25
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="quoteNo"></param>
        /// <returns></returns>
        public T_Quote_H GetByQuoteNo(string quoteNo)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_GetByQuoteNo_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", quoteNo);

            return this.db.Find<T_Quote_H>(cmdText, paras);
        }

        /// <summary>
        /// Get Newest Quote Header By quoteNo
        /// </summary>
        /// <param name="conStr">Connecting String</param>
        /// <param name="quoteNo">quoteNo</param>
        /// <returns>Quote Header</returns>
        public T_Quote_H GetNewestByQuoteNo(string quoteNo)
        {

            //SQL String
            string cmdText = "P_T_Quote_H_GetNewestByQuoteNo_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_QuoteNo", quoteNo);

            return this.db.Find<T_Quote_H>(cmdText, paras);
        }


        /// <summary>
        /// Gets the sell count item for search.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        public int GetSellCountForSearch(QuotationProductSearchModel input)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_GetSellCountForSearch";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_QuoteDateFrm", input.QuoteDateFrm);
            base.AddParam(paras, "IN_QuoteDateTo", input.QuoteDateTo);
            
            if (input.CategoryID1 < 0)
                base.AddParam(paras, "IN_CategoryID1", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID1", input.CategoryID1);

            if (input.CategoryID2 < 0)
                base.AddParam(paras, "IN_CategoryID2", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID2", input.CategoryID2);

            if (input.CategoryID3 < 0)
                base.AddParam(paras, "IN_CategoryID3", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID3", input.CategoryID3);

            base.AddParam(paras, "IN_ProductCD", input.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", input.ProductName, true);
            base.AddParam(paras, "IN_Description", input.Description, true);
            base.AddParam(paras, "IN_UnitPriceFrm", input.UnitPriceFrm);
            base.AddParam(paras, "IN_UnitPriceTo", input.UnitPriceTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(input.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", input.CustomerName, true);

            if (input.CurrencyID < 0)
            {

                base.AddParam(paras, "IN_CurrencyID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_CurrencyID", input.CurrencyID);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Gets the sell item for search.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        public IList<QuotationProductSearchResult> GetSellItemForSearch(QuotationProductSearchModel input)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_GetSellItemForSearch";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_QuoteDateFrm", input.QuoteDateFrm);
            base.AddParam(paras, "IN_QuoteDateTo", input.QuoteDateTo);
            if (input.CategoryID1 < 0)
                base.AddParam(paras, "IN_CategoryID1", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID1", input.CategoryID1);

            if (input.CategoryID2 < 0)
                base.AddParam(paras, "IN_CategoryID2", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID2", input.CategoryID2);

            if (input.CategoryID3 < 0)
                base.AddParam(paras, "IN_CategoryID3", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID3", input.CategoryID3);
            base.AddParam(paras, "IN_ProductCD", input.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", input.ProductName, true);
            base.AddParam(paras, "IN_Description", input.Description, true);

            base.AddParam(paras, "IN_UnitPriceFrm", input.UnitPriceFrm);
            base.AddParam(paras, "IN_UnitPriceTo", input.UnitPriceTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(input.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", input.CustomerName, true);
            if (input.CurrencyID < 0)
            {

                base.AddParam(paras, "IN_CurrencyID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_CurrencyID", input.CurrencyID);
            }

            base.AddParam(paras, "IN_PageIndex", input.PageIndex);
            base.AddParam(paras, "IN_PageSize", input.PageSize);
            base.AddParam(paras, "IN_SortField", input.SortField);
            base.AddParam(paras, "IN_SortDirec", input.SortDirec);

            return this.db.FindList<QuotationProductSearchResult>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="quotation">Quotation</param>
        /// <returns></returns>
        public int Insert(T_Quote_H quotation)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_Insert_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_QuoteNo", quotation.QuoteNo);
            base.AddParam(paras, "IN_QuoteDate", quotation.QuoteDate);
            base.AddParam(paras, "IN_ExpiryDate", quotation.ExpiryDate);
            base.AddParam(paras, "IN_ExpectedOrderDate", quotation.ExpectedOrderDate);
            base.AddParam(paras, "IN_ExpectedRevenueDate", quotation.ExpectedRevenueDate);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(quotation.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", quotation.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", EditDataUtil.ToFixCodeDB(quotation.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", quotation.ApprovedName);
            base.AddParam(paras, "IN_SalesCD1", EditDataUtil.ToFixCodeDB(quotation.SalesCD1, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName1", quotation.SalesName1);
            base.AddParam(paras, "IN_SalesCD2", EditDataUtil.ToFixCodeDB(quotation.SalesCD2, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName2", quotation.SalesName2);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(quotation.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCD_SP", EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", quotation.CustomerName);
            base.AddParam(paras, "IN_SubjectName", quotation.SubjectName);
            base.AddParam(paras, "IN_CustomerAddress1", quotation.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", quotation.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", quotation.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", quotation.Tel);
            base.AddParam(paras, "IN_FAX", quotation.FAX);
            base.AddParam(paras, "IN_ContactPerson", quotation.ContactPerson);
            base.AddParam(paras, "IN_CurrencyID", quotation.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", quotation.MethodVat);
            base.AddParam(paras, "IN_Total", quotation.Total);
            base.AddParam(paras, "IN_Vat", quotation.Vat);
            base.AddParam(paras, "IN_VatRatio", quotation.VatRatio);
            base.AddParam(paras, "IN_VatType", quotation.VatType);
            base.AddParam(paras, "IN_GrandTotal", quotation.GrandTotal);
            // Author: ISV-PHUONG
            // Date  : 2014/12/18
            // ---------------------- Start ------------------------------
            //base.AddParam(paras, "IN_ProfitRatio", quotation.ProfitRatio);
            // ---------------------- End  ------------------------------

            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            base.AddParam(paras, "IN_Approved", quotation.Approved);
            base.AddParam(paras, "IN_Position", quotation.Position);
            // ---------------------- End  ------------------------------
            base.AddParam(paras, "IN_Memo", quotation.Memo);
            base.AddParam(paras, "IN_NewFlag", quotation.NewFlag);
            base.AddParam(paras, "IN_StatusFlag", quotation.StatusFlag);
            base.AddParam(paras, "IN_IssuedFlag", quotation.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", quotation.DeleteFlag);
            base.AddParam(paras, "IN_IssuedDate", quotation.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", quotation.IssuedUID);
            base.AddParam(paras, "IN_CreateUID", quotation.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", quotation.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Quote_H>();
            }
            return 0;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="quotation">Quotation</param>
        /// <returns></returns>
        public int Update(T_Quote_H quotation)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_Update_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", quotation.ID);
            base.AddParam(paras, "IN_QuoteNo", quotation.QuoteNo);
            base.AddParam(paras, "IN_QuoteDate", quotation.QuoteDate);
            base.AddParam(paras, "IN_ExpiryDate", quotation.ExpiryDate);
            base.AddParam(paras, "IN_ExpectedOrderDate", quotation.ExpectedOrderDate);
            base.AddParam(paras, "IN_ExpectedRevenueDate", quotation.ExpectedRevenueDate);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(quotation.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", quotation.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", EditDataUtil.ToFixCodeDB(quotation.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", quotation.ApprovedName);
            base.AddParam(paras, "IN_SalesCD1", EditDataUtil.ToFixCodeDB(quotation.SalesCD1, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName1", quotation.SalesName1);
            base.AddParam(paras, "IN_SalesCD2", EditDataUtil.ToFixCodeDB(quotation.SalesCD2, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName2", quotation.SalesName2);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(quotation.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCD_SP", EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT , M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", quotation.CustomerName);
            base.AddParam(paras, "IN_SubjectName", quotation.SubjectName);
            base.AddParam(paras, "IN_CustomerAddress1", quotation.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", quotation.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", quotation.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", quotation.Tel);
            base.AddParam(paras, "IN_FAX", quotation.FAX);
            base.AddParam(paras, "IN_ContactPerson", quotation.ContactPerson);
            base.AddParam(paras, "IN_CurrencyID", quotation.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", quotation.MethodVat);
            base.AddParam(paras, "IN_Total", quotation.Total);
            base.AddParam(paras, "IN_Vat", quotation.Vat);
            base.AddParam(paras, "IN_VatRatio", quotation.VatRatio);
            base.AddParam(paras, "IN_VatType", quotation.VatType);
            base.AddParam(paras, "IN_GrandTotal", quotation.GrandTotal);
            // Author: ISV-PHUONG
            // Date  : 2014/12/18
            // ---------------------- Start ------------------------------
            //base.AddParam(paras, "IN_ProfitRatio", quotation.ProfitRatio);
            // ---------------------- End  ------------------------------
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            base.AddParam(paras, "IN_Approved", quotation.Approved);
            base.AddParam(paras, "IN_Position", quotation.Position);
            // ---------------------- End  ------------------------------
            base.AddParam(paras, "IN_Memo", quotation.Memo);
            base.AddParam(paras, "IN_NewFlag", quotation.NewFlag);
            base.AddParam(paras, "IN_StatusFlag", quotation.StatusFlag);

            base.AddParam(paras, "IN_IssuedFlag", quotation.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", quotation.IssuedUID);
            base.AddParam(paras, "IN_IssuedDate", quotation.IssuedDate);

            base.AddParam(paras, "IN_UpdateUID", quotation.UpdateUID);
            base.AddParam(paras, "IN_UpdateDate", quotation.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Flag
        /// ISV-Giam
        /// </summary>
        /// <param name="quotation"></param>
        /// <returns></returns>
        public int UpdateFlag(T_Quote_H quotation)
        {
            //SQL String
            string cmdText = "P_T_Quote_H_UpdateFlag_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", quotation.ID);
            base.AddParam(paras, "IN_IssuedFlag", quotation.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", quotation.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", quotation.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}


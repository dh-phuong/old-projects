﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;


namespace OMS.DAC
{
    /// <summary>
    /// Class Currency_HService DAC
    /// Create Date: 2014/07/24
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Currency_HService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Currency_HService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Currency_HService(DB db) : base(db)
        {
            
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get List Combo
        /// Create Author: ISV-NHO
        /// Edit Date: 2014/08/08
        /// Edit Author: ISV-HUNG
        /// Edit Content: Change store name
        /// </summary>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetDataForDropDownList_W";

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// Get List
        /// </summary>
        /// <returns></returns>
        public IList<M_Currency_H> GetListDropdown()
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetListDropdown_W";

            return this.db.FindList<M_Currency_H>(cmdText);
        }

        /// <summary>
        /// Get List
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="pageIndex">Page Index</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="sortField">Sort Field</param>
        /// <param name="sortDirec">Sort Direc</param>
        /// <returns></returns>
        public IList<CurrencyInfo> GetList(string moneyCode, string moneyNameUS, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetList_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_MoneyCode", moneyCode, true);
            base.AddParam(paras, "IN_MoneyNameUS", moneyNameUS, true);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<CurrencyInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get All by base date
        /// </summary>
        public IList<CurrencyInfo> GetAllByDate(DateTime baseDate)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetAllByDate_W";
           
            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BaseDate", baseDate);
            return base.db.FindList<CurrencyInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get total row
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="moneyCode">MoneyCode</param>
        /// <param name="moneyNameUS">MoneyNameUS</param>
        /// <returns></returns>
        public int GetTotalRow(string moneyCode, string moneyNameUS)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetTotalRow_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_MoneyCode", moneyCode, true);
            base.AddParam(paras, "IN_MoneyNameUS", moneyNameUS, true);

            return int.Parse(this.db.ExecuteScalar(cmdText,paras).ToString());
        }

        /// <summary>
        /// Get by user ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public M_Currency_H GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<M_Currency_H>(cmdText, paras);
        }

        /// <summary>
        /// Get by ID and Date
        /// Create Author: ISV-GIAM
        /// Edit date: 2014/08/08
        /// Edit Author: ISV-HUNG
        /// Edit Content: Change store name
        /// </summary>
        /// <param name="id">ID</param>
        /// <param name="baseDate">baseDate</param>
        /// <returns></returns>
        public M_Currency_H GetByIDAndDate(int id, DateTime baseDate)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_GetByIDAndDate_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_BaseDate", baseDate);

            return this.db.Find<M_Currency_H>(cmdText, paras);
        }
        #endregion

        #region Check data
        /// <summary>
        /// Check exist Currency by MoneyCode
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="moneyCode">moneyCode</param>
        /// <returns></returns>
        public bool IsExistMoneyCode(string moneyCode)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_IsExistMoneyCode_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_MoneyCode", moneyCode);

            int count = int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());

            return count > 0;
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="header">M_Currency_H</param>
        /// <returns></returns>
        public int Insert(M_Currency_H header)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_MoneyCode", header.MoneyCode);
            base.AddParam(paras,"IN_MoneyNameUS", header.MoneyNameUS);
            base.AddParam(paras,"IN_MoneyNameVN", header.MoneyNameVN);
            base.AddParam(paras,"IN_TaxName", header.TaxName);
            base.AddParam(paras,"IN_DecimalType", header.DecimalType);
            base.AddParam(paras,"IN_DecimalNameUS", header.DecimalNameUS);
            base.AddParam(paras,"IN_DecimalNameVN", header.DecimalNameVN);

            base.AddParam(paras,"IN_CreateUID", header.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="header">M_Currency_H</param>
        /// <returns></returns>
        public int Update(M_Currency_H header)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_Update_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", header.ID);
            base.AddParam(paras,"IN_MoneyNameUS", header.MoneyNameUS);
            base.AddParam(paras,"IN_MoneyNameVN", header.MoneyNameVN);
            base.AddParam(paras,"IN_TaxName", header.TaxName);
            base.AddParam(paras,"IN_DecimalType", header.DecimalType);
            base.AddParam(paras,"IN_DecimalNameUS", header.DecimalNameUS);
            base.AddParam(paras,"IN_DecimalNameVN", header.DecimalNameVN);

            base.AddParam(paras,"IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Currency_H_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
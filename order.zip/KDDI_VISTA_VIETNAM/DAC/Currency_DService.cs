﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;


namespace OMS.DAC
{
    /// <summary>
    /// Class Currency_DService DAC
    /// Create Date: 2014/07/28
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Currency_DService : BaseService
    {


        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Currency_DService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Currency_DService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get list by header ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public IList<M_Currency_D> GetByListByHeaderID(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Currency_D_GetByListByHeaderID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<M_Currency_D>(cmdText, paras);
        }

        /// <summary>
        /// Get by key
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="hid">HeaderID</param>
        /// /// <param name="baseDate">HeaderID</param>
        /// <returns></returns>
        public M_Currency_D GetByKey(int hid, DateTime baseDate)
        {
            //SQL String
            string cmdText = "P_M_Currency_D_GetByKey_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            this.AddParam(paras, "IN_BASEDATE", baseDate);

            return this.db.Find<M_Currency_D>(cmdText, paras);
        }
        #endregion
        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="detailItem">M_Currency_D</param>
        /// <returns></returns>
        public int Update(M_Currency_D detailItem)
        {
            return 0;
        }
        #endregion
        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="detailItem">M_Currency_D</param>
        /// <returns></returns>
        public int Insert(M_Currency_D detailItem)
        {
            //SQL String
            string cmdText = "P_M_Currency_D_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", detailItem.HID);
            base.AddParam(paras,"IN_EffectDate", detailItem.EffectDate);
            base.AddParam(paras,"IN_ExpireDate", detailItem.ExpireDate);
            base.AddParam(paras,"IN_ExchangeRate", detailItem.ExchangeRate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Currency_D_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public int Delete(int hid, DateTime baseDate)
        {
            //SQL String
            string cmdText = "P_M_Currency_D_Delete_ByKey_W";

            //Param
            Hashtable paras = new Hashtable();
            
            base.AddParam(paras, "IN_HID", hid);
            this.AddParam(paras, "IN_EffectDate", baseDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Vendor DAC
    /// ISV-TRUC
    /// </summary>
    public class VendorService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Vendor service
        /// </summary>        
        private VendorService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Vendor service
        /// </summary>
        /// <param name="db">Class DB</param>
        public VendorService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        /// <summary>
        /// Get list by conditions for the search form
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorCD"></param>
        /// <param name="vendorName"></param>
        /// <param name="groupSupply"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VendorSearchInfo> GetListByConditionForSearch(string vendorCD, string vendorName, string productCd, string productName, string groupSupply, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetByConditionsForSearch_W";

            // Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName", vendorName, true);

            base.AddParam(paras, "IN_ProductCD", productCd, true);
            base.AddParam(paras, "IN_ProductName", productName, true);

            base.AddParam(paras, "IN_GroupSupply", groupSupply, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VendorSearchInfo>(cmdText, paras);
        }

       /// <summary>
        /// Get count of list by conditions for the search form
        /// ISV-TRUC
       /// </summary>
       /// <returns></returns>
        public int GetCountByConditionForSearch(string vendorCD, string vendorName, string productCd, string productName, string groupSupply)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetCountByConditionForSeach_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName", vendorName, true);

            base.AddParam(paras, "IN_ProductCD", productCd, true);
            base.AddParam(paras, "IN_ProductName", productName, true);

            base.AddParam(paras, "IN_GroupSupply", groupSupply, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get List By Condition
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorCD"></param>
        /// <param name="vendorName1"></param>
        /// <param name="vendorName2"></param>
        /// <param name="address1"></param>
        /// <param name="address2"></param>
        /// <param name="address3"></param>
        /// <param name="inValid"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VendorInfo> GetListByCond(string vendorCD, string vendorName1, 
                                            string businessArea, string address, string inValid,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName1", vendorName1, true);
            base.AddParam(paras, "IN_GroupSupply", businessArea, true);
            base.AddParam(paras, "IN_Address", address, true);
            base.AddParam(paras, "IN_InValid", inValid);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<VendorInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorCD"></param>
        /// <param name="vendorName1"></param>
        /// <param name="vendorName2"></param>
        /// <param name="address1"></param>
        /// <param name="address2"></param>
        /// <param name="address3"></param>
        /// <param name="inValid"></param>
        /// <returns></returns>
        public int GetTotalRow(string vendorCD, string vendorName1, 
                                string businessArea, string address, string inValid)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetTotalRow_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName1", vendorName1, true);
            base.AddParam(paras, "IN_GroupSupply", businessArea, true);
            base.AddParam(paras, "IN_Address", address, true);
            base.AddParam(paras, "IN_InValid", inValid);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get List For Excel
        /// ISV-TRUC
        /// </summary>
        /// <returns>List VendorInfo</returns>
        public IList<VendorExcel> GetListForExcel()
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();

            return this.db.FindList<VendorExcel>(cmdText, paras);
        }


        /// <summary>
        /// Get By CD 
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorCD">vendorCD</param>
        /// <returns></returns>
        public M_Vendor GetByCD(string vendorCD)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetByVendorCD_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_VendorCD", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));

            return this.db.Find<M_Vendor>(cmdText, paras);
        }

        /// <summary>
        /// Get By ID
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorID">vendorID</param>
        /// <returns></returns>
        public M_Vendor GetByID(int vendorID)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetByID_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_VendorID", vendorID);

            return this.db.Find<M_Vendor>(cmdText, paras);
        }
        /// <summary>
        /// Get By ProductId
        /// ISV-PHUONG
        /// </summary>
        /// <param name="vendorID">vendorID</param>
        /// <returns></returns>
        public M_Vendor GetFirstOrDefaultByProductID(int productId)
        {
            //SQL String
            string cmdText = "P_M_Vendor_GetByProductID_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProductID", productId);

            return this.db.Find<M_Vendor>(cmdText, paras);
        }
        
        #endregion

        #region Check Exist
        /// <summary>
        /// Is Exist TaxCode
        /// ISV-TRUC
        /// </summary>
        /// <param name="taxCode"></param>
        /// <returns></returns>
        public bool IsExistTaxCode (string taxCode)
        {
            //SQL String
            string cmdText = "P_M_Vendor_IsExistTaxCode_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_TaxCode", taxCode);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;
        }

        /// <summary>
        /// Is Exist Tax Code With Vendor Code
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendorCD">Vendor Code</param>
        /// <param name="taxCode">Tax Code</param>
        /// <returns></returns>
        public bool IsExistTaxCDWithVendorCD(string vendorCD,string taxCode)
        {
            //SQL String
            string cmdText = "P_M_Vendor_IsExistTaxCodeWithVendorCD_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_VendorCode", EditDataUtil.ToFixCodeDB(vendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_TaxCode", taxCode);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public int Insert(M_Vendor vendor)
        {
            //SQL String
            string cmdText = "P_M_Vendor_Insert_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_VendorCD", EditDataUtil.ToFixCodeDB(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_VendorName1", vendor.VendorName1);
            base.AddParam(paras,"IN_VendorName2", vendor.VendorName2);
            base.AddParam(paras,"IN_VendorAddress1", vendor.VendorAddress1);
            base.AddParam(paras,"IN_VendorAddress2", vendor.VendorAddress2);
            base.AddParam(paras,"IN_VendorAddress3", vendor.VendorAddress3);
            base.AddParam(paras,"IN_GroupSupply", vendor.GroupSupply);
            base.AddParam(paras,"IN_Tel", vendor.Tel);
            base.AddParam(paras,"IN_FAX", vendor.FAX);
            base.AddParam(paras,"IN_EmailAddress", vendor.EmailAddress);
            base.AddParam(paras,"IN_ContactPerson", vendor.ContactPerson);
            base.AddParam(paras,"IN_ContactTel", vendor.ContactTel);
            base.AddParam(paras,"IN_TAXCode", vendor.TAXCode);
            base.AddParam(paras,"IN_VendorBank", vendor.VendorBank);
            base.AddParam(paras,"IN_AccountCode", vendor.AccountCode);
            base.AddParam(paras,"IN_StatusFlag", vendor.StatusFlag);

            base.AddParam(paras,"IN_CreateUID", vendor.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", vendor.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// ISV-TRUC
        /// </summary>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public int Update(M_Vendor vendor)
        {
            //SQL String
            string cmdText = "P_M_Vendor_Update_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", vendor.ID);
            base.AddParam(paras,"IN_VendorCD", EditDataUtil.ToFixCodeDB(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_VendorName1", vendor.VendorName1);
            base.AddParam(paras,"IN_VendorName2", vendor.VendorName2);
            base.AddParam(paras,"IN_VendorAddress1", vendor.VendorAddress1);
            base.AddParam(paras,"IN_VendorAddress2", vendor.VendorAddress2);
            base.AddParam(paras,"IN_VendorAddress3", vendor.VendorAddress3);
            base.AddParam(paras,"IN_GroupSupply", vendor.GroupSupply);
            base.AddParam(paras,"IN_Tel", vendor.Tel);
            base.AddParam(paras,"IN_FAX", vendor.FAX);

            base.AddParam(paras,"IN_EmailAddress", vendor.EmailAddress);
            base.AddParam(paras,"IN_ContactPerson",vendor.ContactPerson);
            base.AddParam(paras,"IN_ContactTel", vendor.ContactTel);
            base.AddParam(paras,"IN_TAXCode", vendor.TAXCode);
            base.AddParam(paras,"IN_VendorBank", vendor.VendorBank);
            base.AddParam(paras,"IN_AccountCode", vendor.AccountCode);
            base.AddParam(paras,"IN_StatusFlag", vendor.StatusFlag);
            base.AddParam(paras,"IN_UpdateDate",vendor.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", vendor.UpdateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// ISV-TRUC
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Vendor_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

    }
}

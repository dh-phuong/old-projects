﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Quotation_D_Sell Service
    /// </summary>
    public sealed class Quotation_D_SellService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Quotation_D_Sell service
        /// </summary>        
        private Quotation_D_SellService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Quotation_D_Sell service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Quotation_D_SellService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get
        /// <summary>
        /// Gets the by pk.
        /// </summary>
        /// <param name="id">The identifier.</param>
        /// <param name="no">The no.</param>
        /// <returns></returns>
        public T_Quote_D_Sell GetByPK(int id, int no)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_GetByPK_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_NO", no);

            return this.db.Find<T_Quote_D_Sell>(cmdText, paras);
        }

        /// <summary>
        /// Get Report By ID
        /// </summary>
        public IList<T_Quote_D_Sell> GetByIDForReport(int ID)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_GetByIDForReport_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);

            return this.db.FindList<T_Quote_D_Sell>(cmdText, paras);
        }

        /// <summary>
        /// Get List By HID
        /// </summary>
        public IList<T_Quote_D_Sell> GetListByHID(int id)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_GetByHID_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.FindList<T_Quote_D_Sell>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="sell">Quotation</param>
        /// <returns></returns>
        public int Insert(T_Quote_D_Sell sell)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", sell.HID);
            base.AddParam(paras,"IN_No", sell.No);
            base.AddParam(paras,"IN_HeadLineFlag", sell.HeadlineFlag);
            base.AddParam(paras,"IN_HeadLine", sell.Headline);
            //base.AddParam(paras,"IN_ProductID", sell.ProductID);
            base.AddParam(paras, "IN_ProductCD", sell.ProductCD);
            base.AddParam(paras, "IN_ProductCD_SP", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras, "IN_ProductName", sell.ProductName);
            base.AddParam(paras, "IN_Description", sell.Description);
            base.AddParam(paras, "IN_Remark", sell.Remark);
            base.AddParam(paras, "IN_UnitID", sell.UnitID);
            base.AddParam(paras, "IN_VatType", sell.VatType);
            base.AddParam(paras, "IN_VatRatio", sell.VatRatio);
            base.AddParam(paras, "IN_UnitPrice", sell.UnitPrice);
            base.AddParam(paras, "IN_Quantity", sell.Quantity);
            base.AddParam(paras, "IN_Total", sell.Total);
            base.AddParam(paras, "IN_Vat", sell.Vat);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <param name="sellNo">SellNo</param>
        /// <returns></returns>
        public int Delete(int hid, int no)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_Delete_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            base.AddParam(paras, "IN_No", no);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="hid">HID</param>
        /// <param name="sellNo">SellNo</param>
        /// <returns></returns>
        public int Delete(int hid)
        {
            //SQL String
            string cmdText = "P_T_Quote_D_Sell_Delete_Multi_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", hid);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

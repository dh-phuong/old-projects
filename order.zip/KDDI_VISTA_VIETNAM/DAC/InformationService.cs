﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Event DAC
    /// TRAM
    /// </summary>
    public class InformationService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of event service
        /// </summary>        
        private InformationService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of event service
        /// </summary>
        /// <param name="db">Class DB</param>
        public InformationService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data
        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_Information GetByID(int id)
        {
            // Command text
            string cmdText = "P_M_Information_GetByID_W";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return this.db.Find<M_Information>(cmdText, paras);
        }

        /// <summary>
        /// Get by condition
        /// </summary>
        /// <param name="informationName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<InformationInfo> GetListByCond(string informationName,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Information_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_InformationName", informationName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<InformationInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get All
        /// </summary>
        /// <returns></returns>
        public IList<M_Information> GetAll()
        {
            //SQL String
            string cmdText = "P_M_Information_GetAll_W";

            //Para
            Hashtable paras = new Hashtable();

            return this.db.FindList<M_Information>(cmdText, paras);
        }

        /// <summary>
        /// Get Total row number
        /// </summary>
        /// <param name="informationName">InformationName</param>
        /// <returns></returns>
        public int GetTotalRow(string informationName)
        {
            //SQL String
            string cmdText = "P_M_Information_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InformationName", informationName);            

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by Information model
        /// </summary>
        /// <param name="model">Information model</param>
        /// <returns>Information model</returns>
        public M_Information GetByInformation(M_Information model)
        {
            //SQL String
            string cmdText = "P_M_Information_GetByInformation_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InformationName", model.InformationName);
            base.AddParam(paras, "IN_BeginDate", model.BeginDate);
            base.AddParam(paras, "IN_EndDate", model.EndDate);
            base.AddParam(paras, "IN_InformationContent", model.InformationContent);
            base.AddParam(paras, "IN_CreateUID", model.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", model.UpdateUID);

            return this.db.Find<M_Information>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">M_Information</param>
        /// <returns></returns>
        public int Insert(M_Information data)
        {
            //SQL String
            string cmdText = "P_M_Information_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BeginDate", data.BeginDate);
            base.AddParam(paras, "IN_EndDate", data.EndDate);
            base.AddParam(paras, "IN_InformationName", data.InformationName);
            base.AddParam(paras, "IN_InformationContent", data.InformationContent);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">M_Information</param>
        /// <returns></returns>
        public int Update(M_Information data)
        {
            //SQL String
            string cmdText = "P_M_Information_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", data.ID);

            base.AddParam(paras, "IN_BeginDate", data.BeginDate);
            base.AddParam(paras, "IN_EndDate", data.EndDate);
            base.AddParam(paras, "IN_InformationName", data.InformationName);
            base.AddParam(paras, "IN_InformationContent", data.InformationContent);
            
            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Information_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

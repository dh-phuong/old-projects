﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class Product Service
    /// VN-Nho
    /// </summary>
    public class ProductService :BaseService
    {
        #region Constructor
        private ProductService() :base(){ }

        public ProductService(DB db):base(db)
        {
        }

        #endregion

        #region Method

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <param name="type">Product Type</param>
        /// <param name="productCd">Product code</param>
        /// <param name="productNm">Product name</param>
        /// <param name="categoryId1">Category id 1</param>
        /// <param name="categoryId2">Category id 2</param>
        /// <param name="categoryId3">Category id 3</param>
        /// <param name="vendorId">Vendor id</param>
        /// <param name="pageIndex">Page Index</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="sortField">Sort Field</param>
        /// <param name="sortDirec">Sort Directed</param>
        /// <returns>List Product Infomation</returns>
        public IList<ProductInfo> GetListByCond(short type, string productCd, string productNm, int categoryId1, int categoryId2, int categoryId3, int vendorId
                                                , string inValid, int pageIndex, int pageSize, int sortField, int sortDirec)
        {

            //Comand text
            string cmdText = "P_M_Product_GetByConditions_W";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ProductCode", productCd, true);
            base.AddParam(paras, "IN_ProductName", productNm, true);
            base.AddParam(paras, "IN_CategoryID1", categoryId1);
            base.AddParam(paras, "IN_CategoryID2", categoryId2);
            base.AddParam(paras, "IN_CategoryID3", categoryId3);
            base.AddParam(paras, "IN_VendorID", vendorId);
            base.AddParam(paras, "IN_InValid", inValid);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ProductInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="type">Product Type</param>
        /// <param name="productCd">Product Code</param>
        /// <param name="productNm">Product Name</param>
        /// <param name="categoryId1">Category id 1</param>
        /// <param name="categoryId2">Category id 2</param>
        /// <param name="categoryId3">Category id 3</param>
        /// <param name="vendorId">Vendor Id</param>
        /// <param name="inValid">InValid</param>
        /// <returns>count of List</returns>
        public int GetTotalRow(short type, string productCd, string productNm, int categoryId1, int categoryId2, int categoryId3, int vendorId, string inValid)
        {
            //Command text
            string cmdText = "P_M_Product_GetCountByConditions_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ProductCode", productCd, true);
            base.AddParam(paras, "IN_ProductName", productNm, true);
            base.AddParam(paras, "IN_CategoryID1", categoryId1);
            base.AddParam(paras, "IN_CategoryID2", categoryId2);
            base.AddParam(paras, "IN_CategoryID3", categoryId3);
            base.AddParam(paras, "IN_VendorID", vendorId);
            base.AddParam(paras, "IN_InValid", inValid);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <param name="type">Product Type</param>
        /// <param name="productCd">Product code</param>
        /// <param name="productNm">Product name</param>
        /// <param name="pageIndex">Page Index</param>
        /// <param name="pageSize">Page Size</param>
        /// <param name="sortField">Sort Field</param>
        /// <param name="sortDirec">Sort Directed</param>
        /// <returns>List Product Infomation</returns>
        public IList<ProductSearchInfo> GetListByCondForSearch(short type, string productCd, string productNm,
                                                                int categoryId1, int categoryId2, int categoryId3, string vendorCd,                                                   
                                                                int pageIndex, int pageSize, int sortField, int sortDirec)
        {

            //Comand text
            string cmdText = "P_M_Product_GetByConditionsForSearch_W";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ProductCode", productCd, true);
            base.AddParam(paras, "IN_ProductName", productNm, true);
            base.AddParam(paras, "IN_CategoryID1", categoryId1);
            base.AddParam(paras, "IN_CategoryID2", categoryId2);
            base.AddParam(paras, "IN_CategoryID3", categoryId3);
            base.AddParam(paras, "IN_VendorCD", vendorCd, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ProductSearchInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="type">Product Type</param>
        /// <param name="productCd">Product Code</param>
        /// <param name="productNm">Product Name</param>
        /// <returns>count of List</returns>
        public int GetTotalRowForSearch(short type, string productCd, string productNm,
                                        int categoryId1, int categoryId2, int categoryId3, string vendorCd)
        {
            //Command text
            string cmdText = "P_M_Product_GetCountByConditionsForSearch_W";

            //Parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_ProductCode", productCd, true);
            base.AddParam(paras, "IN_ProductName", productNm, true);
            base.AddParam(paras, "IN_CategoryID1", categoryId1);
            base.AddParam(paras, "IN_CategoryID2", categoryId2);
            base.AddParam(paras, "IN_CategoryID3", categoryId3);
            base.AddParam(paras, "IN_VendorCD", vendorCd, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get List For Excel
        /// </summary>
        /// <param name="configCD">Config code of VAT flag</param>
        /// <returns>List Product Excel Data</returns>
        public IList<ProductExcel> GetListForExcel(string configCD)
        {
            //SQL String
            string cmdText = "P_M_Product_GetListForExcel_W";

            //Add parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ConfigCD", configCD);

            return this.db.FindList<ProductExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get by id
        /// </summary>
        /// <param name="productId">Product ID</param>
        /// <returns>Product</returns>
        public M_Product GetByID(int productId)
        {
            //Command text
            string cmdText = "P_M_Product_GetByProductID_W";

            //Add parameters
            Hashtable prms = new Hashtable();
            prms.Add("IN_ProductID", productId);

            return this.db.Find<M_Product>(cmdText, prms);

        }

        /// <summary>
        /// Get by Code
        /// </summary>
        /// <param name="productId">Product Code</param>
        /// <returns>Product</returns>
        public M_Product GetByCDAndType(string productCD, ProductType type)
        {
            //Command text
            string cmdText = "P_M_Product_GetByCDAndType_W";

            //Add parameters
            Hashtable prms = new Hashtable();
            prms.Add("IN_ProductCD", productCD);
            prms.Add("IN_Type", (short)type);

            return this.db.Find<M_Product>(cmdText, prms);

        }

        /// <summary>
        /// Get by Code
        /// </summary>
        /// <param name="productId">Product Code</param>
        /// <returns>Product</returns>
        public M_Product GetByCD(string productCD)
        {
            //Command text
            string cmdText = "P_M_Product_GetByCD_W";

            //Add parameters
            Hashtable prms = new Hashtable();
            prms.Add("IN_ProductCD", productCD);

            return this.db.Find<M_Product>(cmdText, prms);
        }


        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="product">M_Product</param>
        /// <returns></returns>
        public int Insert(M_Product product)
        {
            //SQL String
            string cmdText = "P_M_Product_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProductCD", product.ProductCD);
            base.AddParam(paras, "IN_ProductName", product.ProductName);
            base.AddParam(paras, "IN_CategoryStructID", product.CategoryStructID);
            base.AddParam(paras, "IN_Type", product.Type);
            base.AddParam(paras, "IN_DescriptionSell", product.DescriptionSell);
            base.AddParam(paras, "IN_CurrencyIDSell", product.CurrencyIDSell);
            base.AddParam(paras, "IN_UnitPriceSell", product.UnitPriceSell);
            base.AddParam(paras, "IN_UnitIDSell", product.UnitIDSell);
            base.AddParam(paras, "IN_VatTypeSell", product.VatTypeSell);
            base.AddParam(paras, "IN_VatRatioSell", product.VatRatioSell);
            base.AddParam(paras, "IN_RemarkSell", product.RemarkSell);
            base.AddParam(paras, "IN_DescriptionCost", product.DescriptionCost);
            base.AddParam(paras, "IN_CurrencyIDCost", product.CurrencyIDCost);
            base.AddParam(paras, "IN_UnitPriceCost", product.UnitPriceCost);
            base.AddParam(paras, "IN_UnitIDCost", product.UnitIDCost);
            base.AddParam(paras, "IN_VatTypeCost", product.VatTypeCost);
            base.AddParam(paras, "IN_VatRatioCost", product.VatRatioCost);
            base.AddParam(paras, "IN_RemarkCost", product.RemarkCost);
            base.AddParam(paras, "IN_PurchaseFlag", product.PurchaseFlag);
            base.AddParam(paras, "IN_StatusFlag", product.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", product.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", product.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<M_Product>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="product">M_Product</param>
        /// <returns></returns>
        public int Update(M_Product product)
        {
            //SQL String
            string cmdText = "P_M_Product_Update_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", product.ID);
            base.AddParam(paras, "IN_ProductName", product.ProductName);
            base.AddParam(paras, "IN_CategoryStructID", product.CategoryStructID);
            base.AddParam(paras, "IN_Type", product.Type);
            base.AddParam(paras, "IN_DescriptionSell", product.DescriptionSell);
            base.AddParam(paras, "IN_CurrencyIDSell", product.CurrencyIDSell);
            base.AddParam(paras, "IN_UnitPriceSell", product.UnitPriceSell);
            base.AddParam(paras, "IN_UnitIDSell", product.UnitIDSell);
            base.AddParam(paras, "IN_VatTypeSell", product.VatTypeSell);
            base.AddParam(paras, "IN_VatRatioSell", product.VatRatioSell);
            base.AddParam(paras, "IN_RemarkSell", product.RemarkSell);
            base.AddParam(paras, "IN_DescriptionCost", product.DescriptionCost);
            base.AddParam(paras, "IN_CurrencyIDCost", product.CurrencyIDCost);
            base.AddParam(paras, "IN_UnitPriceCost", product.UnitPriceCost);
            base.AddParam(paras, "IN_UnitIDCost", product.UnitIDCost);
            base.AddParam(paras, "IN_VatTypeCost", product.VatTypeCost);
            base.AddParam(paras, "IN_VatRatioCost", product.VatRatioCost);
            base.AddParam(paras, "IN_RemarkCost", product.RemarkCost);
            base.AddParam(paras, "IN_PurchaseFlag", product.PurchaseFlag);
            base.AddParam(paras, "IN_StatusFlag", product.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", product.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", product.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="updateDate">Update date</param>
        /// <returns>number of rows deleted</returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Product_Delete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #endregion
    }
}

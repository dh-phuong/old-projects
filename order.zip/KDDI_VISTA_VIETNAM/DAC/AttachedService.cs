﻿using System.Collections;
using System.Collections.Generic;

using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// AttachedService
    /// </summary>
    public class AttachedService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private AttachedService()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public AttachedService(DB db)
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <returns>IList<AttachedInfo></returns>
        public IList<AttachedInfo> GetListByCond(int id, int type, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Attached_GetList_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", id);
            base.AddParam(paras, "@IN_Type", type);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<AttachedInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Attached</returns>
        public T_Attached GetByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Attached_GetByID_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", id);

            return this.db.Find<T_Attached>(cmdText, paras);
        }

        /// <summary>
        /// Count file
        /// Create Date: 2014/09/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerId"></param>
        /// <param name="formType"></param>
        /// <returns></returns>
        public int CountFile(int headerId, int formType)
        {
            //SQL String
            string cmdText = "P_T_Attached_CountFile_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_HID", headerId);
            base.AddParam(paras, "@IN_FormType", formType);

            return (int)this.db.ExecuteScalar(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="attached">M_Customer</param>
        /// <returns></returns>
        public int Insert(AttachedInfo attached)
        {
            //SQL String
            string cmdText = "P_T_Attached_Insert_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_No", attached.No);
            base.AddParam(paras,"IN_Path", attached.Path);
            base.AddParam(paras,"IN_CreateUID", attached.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        public int Delete(int id)
        {
            //SQL String
            string cmdText = "P_T_Attached_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", id);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
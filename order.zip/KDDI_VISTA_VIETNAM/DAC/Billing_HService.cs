﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Billing_HService class
    /// Author: TRAM
    /// </summary>
    public class Billing_HService : BaseService
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private Billing_HService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Billing_HService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// Author:TRAM
        /// </summary>
        /// <param name="model">BillingHeaderSearch</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns>BillingHeaderResult List</returns>
        public IList<BillingHeaderResult> GetListByConditions(BillingHeaderSearch model,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetListByConditions_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingNo", model.BillingNo, true);
            base.AddParam(paras, "IN_QuoteNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_BillingDateFrom", model.BillingDateFrom);
            base.AddParam(paras, "IN_BillingDateTo", model.BillingDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_SubjectName", model.SubjectName, true);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_DeletedFlag", model.DeletedFlg);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<BillingHeaderResult>(cmdText, paras);
        }

        /// <summary>
        /// Get list for excel
        /// Author:TRAM
        /// </summary>
        /// <param name="model">BillingHeaderSearch</param>
        /// <returns>BillingExcel List</returns>
        public IList<BillingExcel> GetListForExcel(BillingHeaderSearch model)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingNo", model.BillingNo, true);
            base.AddParam(paras, "IN_QuoteNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_BillingDateFrom", model.BillingDateFrom);
            base.AddParam(paras, "IN_BillingDateTo", model.BillingDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_SubjectName", model.SubjectName, true);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_DeletedFlag", model.DeletedFlg);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);
            return this.db.FindList<BillingExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get the row total by the conditions
        /// Author:TRAM
        /// </summary>
        /// <param name="model">BillingHeaderSearch</param>
        /// <returns>Total row</returns>
        public int GetTotalRow(BillingHeaderSearch model)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetCountByConditions_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingNo", model.BillingNo, true);
            base.AddParam(paras, "IN_QuoteNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_BillingDateFrom", model.BillingDateFrom);
            base.AddParam(paras, "IN_BillingDateTo", model.BillingDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_SubjectName", model.SubjectName, true);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_DeletedFlag", model.DeletedFlg);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by ID
        /// Create Author: ISV-Nguyen
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public T_Billing_H GetByPK(int id)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetByPK_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Billing_H>(cmdText, paras);
        }

        /// <summary>
        /// Get List For UnCreate Billing List Excel
        /// Create Author: ISV-GIAM
        /// Create Date: 2015/02/05
        /// </summary>
        /// <param name="billingDateFrom">billingDateFrom</param>
        /// <param name="billingDateTo">billingDateTo</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<UncreateBillingExcel> GetListForUnCreateBillingListExcel(DateTime? billingDateFrom, DateTime? billingDateTo)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetListForUncreateBillingListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingDateFrom", billingDateFrom);
            base.AddParam(paras, "IN_BillingDateTo", billingDateTo);
            base.AddParam(paras, "IN_VatType", M_Config_H.CONFIG_CD_VAT_TYPE);

            return this.db.FindList<UncreateBillingExcel>(cmdText, paras);
        }

        /// <summary>
        /// GetListForExcel
        /// Create Author: ISV-NGUYEN
        /// Create Date: 2015/02/04
        /// </summary>
        /// <param name="purchaseDateFrom">purchaseDateFrom</param>
        /// <param name="purchaseDateTo">purchaseDateTo</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<CreateBillingExcel> GetListForCreateBillingListExcel(DateTime? billingDateFrom, DateTime? billingDateTo)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_GetListForCreateBillingListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingDateFrom", billingDateFrom);
            base.AddParam(paras, "IN_BillingDateTo", billingDateTo);
            base.AddParam(paras, "IN_VatType", M_Config_H.CONFIG_CD_VAT_TYPE);

            return this.db.FindList<CreateBillingExcel>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="header">T_Billing_H</param>
        /// <returns></returns>
        public int Insert(T_Billing_H header)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_Insert_W";

            //Param
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_SalesNo", header.SalesNo);
            base.AddParam(paras, "IN_BillingNo", header.BillingNo);
            base.AddParam(paras, "IN_QuoteNo", header.QuoteNo);
            base.AddParam(paras, "IN_IssuedFlag", header.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras, "IN_FinishFlag", header.FinishFlag);

            base.AddParam(paras, "IN_BillingDate", header.BillingDate);
            base.AddParam(paras, "IN_ExpiryDate", header.ExpiryDate);

            base.AddParam(paras, "IN_PreparedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", header.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", header.ApprovedName);

            base.AddParam(paras, "IN_CustomerCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", header.CustomerName);
            base.AddParam(paras, "IN_SubjectName", header.SubjectName);
            base.AddParam(paras, "IN_CustomerAddress1", header.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", header.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", header.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", header.Tel);
            base.AddParam(paras, "IN_FAX", header.FAX);
            base.AddParam(paras, "IN_TAXCode", header.TAXCode);
            base.AddParam(paras, "IN_ContactPerson", header.ContactPerson);
            //---------------Add 2015/01/06 ISV-HUNG-----------------//
            base.AddParam(paras, "IN_RedInvoiceNo", header.RedInvoiceNo);
            base.AddParam(paras, "IN_RedInvoiceDate", header.RedInvoiceDate);
            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            base.AddParam(paras, "IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", header.MethodVat);
            base.AddParam(paras, "IN_PaymentMethod", header.PaymentMethod);
            base.AddParam(paras, "IN_Total", header.Total);
            base.AddParam(paras,"IN_Vat", header.Vat);
            base.AddParam(paras,"IN_VatRatio", header.VatRatio);
            base.AddParam(paras,"IN_VatType", header.VatType);
            base.AddParam(paras,"IN_GrandTotal", header.GrandTotal);
            base.AddParam(paras,"IN_Memo", header.Memo);

            base.AddParam(paras,"IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras,"IN_IssuedUID", header.IssuedUID);

            base.AddParam(paras, "IN_CreateUID", header.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Billing_H>();
            }
            return 0;
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="header">T_Sales_H</param>
        /// <returns></returns>
        public int Update(T_Billing_H header)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_Update_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", header.ID);
            base.AddParam(paras,"IN_SalesNo", header.SalesNo);
            base.AddParam(paras,"IN_BillingNo", header.BillingNo);
            base.AddParam(paras,"IN_QuoteNo", header.QuoteNo);
            base.AddParam(paras,"IN_BillingDate", header.BillingDate);
            base.AddParam(paras,"IN_ExpiryDate", header.ExpiryDate);
            base.AddParam(paras,"IN_PreparedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_PreparedName", header.PreparedName);
            base.AddParam(paras,"IN_ApprovedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_ApprovedName", header.ApprovedName);
            base.AddParam(paras,"IN_CustomerCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras,"IN_CustomerName", header.CustomerName);
            base.AddParam(paras,"IN_SubjectName", header.SubjectName);
            base.AddParam(paras,"IN_CustomerAddress1", header.CustomerAddress1);
            base.AddParam(paras,"IN_CustomerAddress2", header.CustomerAddress2);
            base.AddParam(paras,"IN_CustomerAddress3", header.CustomerAddress3);
            base.AddParam(paras,"IN_Tel", header.Tel);
            base.AddParam(paras,"IN_FAX", header.FAX);
            base.AddParam(paras,"IN_ContactPerson", header.ContactPerson);
            base.AddParam(paras,"IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras,"IN_MethodVat", header.MethodVat);
            base.AddParam(paras,"IN_PaymentMethod", header.PaymentMethod);
            base.AddParam(paras,"IN_TAXCode", header.TAXCode);
            //---------------Add 2015/01/06 ISV-HUNG-----------------//
            base.AddParam(paras, "IN_RedInvoiceNo", header.RedInvoiceNo);
            base.AddParam(paras, "IN_RedInvoiceDate", header.RedInvoiceDate);
            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            base.AddParam(paras,"IN_Total", header.Total);
            base.AddParam(paras,"IN_Vat", header.Vat);
            base.AddParam(paras,"IN_VatRatio", header.VatRatio);
            base.AddParam(paras,"IN_VatType", header.VatType);
            base.AddParam(paras,"IN_GrandTotal", header.GrandTotal);
            base.AddParam(paras,"IN_Memo", header.Memo);
            base.AddParam(paras,"IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras,"IN_FinishFlag", header.FinishFlag);
            
            base.AddParam(paras,"IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras,"IN_IssuedUID", header.IssuedUID);

            base.AddParam(paras,"IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Flag
        /// </summary>
        /// <param name="billing">T_Billing_H</param>
        /// <returns></returns>
        public int UpdateFlag(T_Billing_H billing)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_UpdateIssueFlag_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", billing.ID);
            base.AddParam(paras, "IN_IssuedFlag", billing.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", billing.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", billing.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="header">T_Sales_H</param>
        /// <returns></returns>
        public int Delete(T_Billing_H header)
        {
            //SQL String
            string cmdText = "P_T_Billing_H_Delete_W";

            //Param
            Hashtable paras = new Hashtable();

            base.AddParam(paras,"IN_ID", header.ID);
            base.AddParam(paras,"IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    public class Deposit_Service : BaseService
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private Deposit_Service()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Deposit_Service(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get Deposit Detail By ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Deposit> GetListByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Deposit_GetListByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", id);

            return this.db.FindList<T_Deposit>(cmdText, paras);
        }

        /// <summary>
        /// Get Deposit Detail By ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Deposit> GetListByIDForReport(int id)
        {
            //SQL String
            string cmdText = "P_T_Deposit_GetByBillingIDForReport_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_BillingID", id);

            return this.db.FindList<T_Deposit>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="acceptC"></param>
        /// <returns></returns>
        public int Insert(T_Deposit deposit)
        {
            //SQL String
            string cmdText = "P_T_Deposit_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", deposit.BillingID);
            base.AddParam(paras,"IN_No", deposit.No);
            base.AddParam(paras,"IN_DepositDate", deposit.DepositDate);
            base.AddParam(paras,"IN_Amount", deposit.Amount);
            base.AddParam(paras,"IN_PaymentMethod", deposit.PaymentMethod);
            base.AddParam(paras,"IN_Remark1", deposit.Remark1);
            base.AddParam(paras,"IN_Remark2", deposit.Remark2);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-NGUYEN
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Deposit_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

﻿using System.Collections;
using System.Collections.Generic;

using OMS.Models;
using System;

namespace OMS.DAC
{
    /// <summary>
    /// Class Sales_D_CostService DAC
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Sales_D_CostService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Sales_D_CostService()
            :base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Sales_D_CostService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <returns></returns>
        public T_Sales_D_Cost GetByPK(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_GetByPK_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.Find<T_Sales_D_Cost>(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Detail Cost By ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public IList<T_Sales_D_Cost> GetListByID(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_GetListByID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<T_Sales_D_Cost>(cmdText, paras);
        }

        /// <summary>
        /// Get For Purchase Select
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/03
        /// </summary>
        /// <param name="salesNo">Sales No</param>
        /// <param name="quoteNo">Quote No</param>
        /// <param name="vendorCD">Vendor CD</param>
        /// <returns></returns>
        public IList<PurchaseSelectInfo> GetForPurchaseSelect(string salesNo, string quoteNo, string vendorCD)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_GetDataPurchaseSelect_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", salesNo);
            base.AddParam(paras, "IN_QuoteNo", quoteNo);
            base.AddParam(paras, "IN_VendorCD", vendorCD);
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_VAT_TYPE);

            return this.db.FindList<PurchaseSelectInfo>(cmdText, paras);
        }        

        /// <summary>
        /// Gets the by sell.
        /// </summary>
        /// <param name="hid">The hid.</param>
        /// <param name="sellNo">The sell no.</param>
        /// <returns></returns>
        public IList<T_Sales_D_Cost> GetBySell(int hid, int sellNo)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_GetBySell_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", hid);
            base.AddParam(paras, "IN_SellNo", sellNo);

            return this.db.FindList<T_Sales_D_Cost>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="sales_D_Cost">T_Sales_D_Cost</param>
        /// <returns></returns>
        public int Insert(T_Sales_D_Cost sales_D_Cost)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_Insert_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", sales_D_Cost.HID);
            base.AddParam(paras,"IN_SellNo", sales_D_Cost.SellNo);
            base.AddParam(paras,"IN_No", sales_D_Cost.No);
            base.AddParam(paras,"IN_ProductCD", sales_D_Cost.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", sales_D_Cost.ProductName);
            base.AddParam(paras,"IN_Description", sales_D_Cost.Description);
            base.AddParam(paras, "IN_PurchaseFlag", sales_D_Cost.PurchaseFlag);
            base.AddParam(paras, "IN_VendorCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(sales_D_Cost.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorName", sales_D_Cost.VendorName);
            base.AddParam(paras, "IN_CurrencyID", sales_D_Cost.CurrencyID);
            base.AddParam(paras,"IN_UnitID", sales_D_Cost.UnitID);
            base.AddParam(paras, "IN_UnitPrice", sales_D_Cost.UnitPrice);
            base.AddParam(paras, "IN_Quantity", sales_D_Cost.Quantity);
            base.AddParam(paras, "IN_Vat", sales_D_Cost.Vat);
            base.AddParam(paras,"IN_VatType", sales_D_Cost.VatType);
            base.AddParam(paras,"IN_VatRatio", sales_D_Cost.VatRatio);
            base.AddParam(paras,"IN_Total", sales_D_Cost.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update No By InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <param name="costNo">Cost No</param>
        /// <returns></returns>
        public int UpdateNoByInternalID(int internalID, int costNo)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_UpdateCostNoByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", internalID);
            base.AddParam(paras,"IN_CostNo", costNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="salesDCost">T_Sales_D_Cost</param>
        /// <returns></returns>
        public int Update(T_Sales_D_Cost salesDCost)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_Update_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", salesDCost.InternalID);
            base.AddParam(paras,"IN_HID", salesDCost.HID);
            base.AddParam(paras,"IN_SellNo", salesDCost.SellNo);
            base.AddParam(paras,"IN_No", salesDCost.No);
            base.AddParam(paras,"IN_ProductCD", salesDCost.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", salesDCost.ProductName);
            base.AddParam(paras,"IN_Description", salesDCost.Description);
            base.AddParam(paras, "IN_PurchaseFlag", salesDCost.PurchaseFlag);
            base.AddParam(paras, "IN_VendorCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(salesDCost.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorName", salesDCost.VendorName);
            base.AddParam(paras, "IN_CurrencyID", salesDCost.CurrencyID);
            base.AddParam(paras,"IN_UnitID", salesDCost.UnitID);
            base.AddParam(paras, "IN_UnitPrice", salesDCost.UnitPrice);
            base.AddParam(paras, "IN_Quantity", salesDCost.Quantity);
            base.AddParam(paras, "IN_Vat", salesDCost.Vat);
            base.AddParam(paras,"IN_VatType", salesDCost.VatType);
            base.AddParam(paras,"IN_VatRatio", salesDCost.VatRatio);
            base.AddParam(paras,"IN_Total", salesDCost.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_Delete_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete data by InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <returns></returns>
        public int DeleteByInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Cost_DeleteByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", internalID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Delivery_CService
    /// </summary>
    public class Delivery_CService : BaseService
    {
         #region Contructor

        /// <summary>
        /// Contructor of Delivery_CService
        /// </summary>        
        private Delivery_CService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Delivery_CService
        /// </summary>
        /// <param name="db">Class DB</param>
        public Delivery_CService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get
        /// <summary>
        /// Get Shipping_C By ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public T_Delivery_C GetByID(int ID)
        {
            string cmdText = "P_T_Delivery_C_GetByID_W";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            return this.db.Find<T_Delivery_C>(cmdText, paras);
        }
        
        #endregion

        #region Insert

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="acceptC"></param>
        /// <returns></returns>
        public int Insert(T_Delivery_C shipC)
        {
            //SQL String
            string cmdText = "P_T_Delivery_C_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", shipC.HID);
            base.AddParam(paras, "IN_Conditions", shipC.Conditions);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_C_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

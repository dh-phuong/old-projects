﻿using System.Collections;
using System.Collections.Generic;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// PaymentService
    /// </summary>
    public class PaymentService : BaseService
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private PaymentService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public PaymentService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get Payment By ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Payment> GetListByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Payment_GetListByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", id);

            return this.db.FindList<T_Payment>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-Giam
        /// Create Date: 2014/09/19
        /// </summary>
        /// <param name="payment">T_Payment</param>
        /// <returns></returns>
        public int Insert(T_Payment payment)
        {
            //SQL String
            string cmdText = "P_T_Payment_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", payment.PurchaseID);
            base.AddParam(paras,"IN_No", payment.No);
            base.AddParam(paras,"IN_PaymentDate", payment.PaymentDate);
            base.AddParam(paras,"IN_Amount", payment.Amount);
            base.AddParam(paras,"IN_PaymentMethod", payment.PaymentMethod);
            base.AddParam(paras, "IN_Remark1", payment.Remark1);
            base.AddParam(paras, "IN_Remark2", payment.Remark2);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-Giam
        /// Create Date: 2014/09/19
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Payment_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;

using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// Class Sales_HService DAC
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    public class Sales_HService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Sales_HService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Sales_HService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get Data
        /// <summary>
        /// Get the list for searching
        /// </summary>
        /// <param name="model">SalesHeaderSearch</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<SalesHeaderResult> GetListForSearch(SalesHeaderSearch model, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetListForSearch_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_QuotationNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesDateFrm", model.SalesDateFrom);
            base.AddParam(paras, "IN_SalesDateTo", model.SalesDateTo);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(model.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(model.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Subject", model.SubjectName, true);
            base.AddParam(paras, "IN_FailedFlag", model.FailedFlg);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_LostValue", (int)Models.StatusFlag.Lost);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<SalesHeaderResult>(cmdText, paras);
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="model">Model</param>
        /// <returns></returns>
        public int GetTotalRow(SalesHeaderSearch model)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetCountByConditions_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_QuotationNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesDateFrm", model.SalesDateFrom);
            base.AddParam(paras, "IN_SalesDateTo", model.SalesDateTo);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(model.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(model.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Subject", model.SubjectName, true);
            base.AddParam(paras, "IN_FailedFlag", model.FailedFlg);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_LostValue", (int)Models.StatusFlag.Lost);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="model">Model</param>
        /// <returns></returns>
        public int GetTotalRowForSalesProductSearch(SalesProductSearchHeader model)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetTotalRowForSalesProductSearch_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDateFrm", model.SalesDateFrom);
            base.AddParam(paras, "IN_SalesDateTo", model.SalesDateTo);
            base.AddParam(paras, "IN_ProductCD", model.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", model.ProductName, true);
            base.AddParam(paras, "IN_CategoryID1", model.CategoryID1);
            base.AddParam(paras, "IN_CategoryID2", model.CategoryID2);
            base.AddParam(paras, "IN_CategoryID3", model.CategoryID3);
            //base.AddParam(paras, "IN_UnitPriceFrom", model.UnitPriceFrom,true);
            //base.AddParam(paras, "IN_UnitPriceTo", model.UnitPriceTo, true);
            base.AddParam(paras, "IN_Description", model.Description, true);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", model.CustomerName, true);
            //base.AddParam(paras, "IN_Currency", model.Currency);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get the list for searching
        /// </summary>
        /// <param name="model">SalesHeaderSearch</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<SalesProductSearchResult> GetListForSalesProductSearch(SalesProductSearchHeader model, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetListForSalesProductSearch_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDateFrm", model.SalesDateFrom);
            base.AddParam(paras, "IN_SalesDateTo", model.SalesDateTo);
            base.AddParam(paras, "IN_ProductCD", model.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", model.ProductName, true);
            base.AddParam(paras, "IN_CategoryID1", model.CategoryID1);
            base.AddParam(paras, "IN_CategoryID2", model.CategoryID2);
            base.AddParam(paras, "IN_CategoryID3", model.CategoryID3);
            //base.AddParam(paras, "IN_UnitPriceFrom", model.UnitPriceFrom, true);
            //base.AddParam(paras, "IN_UnitPriceTo", model.UnitPriceTo, true);
            base.AddParam(paras, "IN_Description", model.Description, true);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", model.CustomerName, true);
            //base.AddParam(paras, "IN_Currency", model.Currency);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<SalesProductSearchResult>(cmdText, paras);
        }

        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public T_Sales_H GetByPK(int id)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetByPK_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Sales_H>(cmdText, paras);
        }

        /// <summary>
        /// Get By Sales No
        /// </summary>
        /// <param name="salesNo">SalesNo</param>
        /// <returns></returns>
        public T_Sales_H GetBySalesNo(string salesNo)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetBySalesNo_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", salesNo);

            return this.db.Find<T_Sales_H>(cmdText, paras);
        }

        /// <summary>
        /// Get the list for Excel
        /// </summary>
        /// <param name="model">SalesanceHeaderSearch</param>
        /// <returns></returns>
        public IList<SalesExcel> GetListForExcel(SalesHeaderSearch model)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetListForExcel_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", model.SalesNo, true);
            base.AddParam(paras, "IN_QuotationNo", model.QuoteNo, true);
            base.AddParam(paras, "IN_SalesDateFrm", model.SalesDateFrom);
            base.AddParam(paras, "IN_SalesDateTo", model.SalesDateTo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(model.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(model.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale1CD", EditDataUtil.ToFixCodeDB(model.Sale1CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Sale2CD", EditDataUtil.ToFixCodeDB(model.Sale2CD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_Subject", model.SubjectName, true);
            base.AddParam(paras, "IN_FailedFlag", model.FailedFlg);
            base.AddParam(paras, "IN_FinishedFlag", model.FinishedFlg);
            base.AddParam(paras, "IN_LostValue", (int)Models.StatusFlag.Lost);
            base.AddParam(paras, "IN_StatusID", M_Config_H.CONFIG_CD_STATUS);
            base.AddParam(paras, "IN_VatType", M_Config_H.CONFIG_CD_VAT_TYPE);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_FRACTION_TYPE);

            return this.db.FindList<SalesExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get the finished data
        /// </summary>
        /// <param name="salesID">SalesID</param>
        /// <returns>T_Sales_H</returns>
        public T_Sales_H GetFinishedData(int salesID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetFinishedData_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesID", salesID);

            return this.db.Find<T_Sales_H>(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Header By Sales Detail Cost InternalID
        /// Create Date: 2014/09/08
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Sales Detail Cost InternalID</param>
        /// <returns></returns>
        public T_Sales_H GetBySalesCostInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetBySalesCostInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.Find<T_Sales_H>(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Header By Sales Detail Sell InternalID
        /// </summary>
        /// <param name="internalID">Sales Detail Cost InternalID</param>
        /// <returns></returns>
        public T_Sales_H GetBySalesSellInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetBySalesSellInternalID_W";
            
            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.Find<T_Sales_H>(cmdText, paras);
        }

        /// <summary>
        /// Get count Unfinished Referency records
        /// Create Date: 2014/09/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public int GetCountUnFinishRef(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetCountUnFinishRef_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", headerID);

            return (int)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// GetListReportChartByCustomer
        /// </summary>
        /// <param name="salesDateFrm">Sales Date From</param>
        /// <param name="salesDateTo">Sales Date To</param>
        /// <param name="categoryID1">Category 1</param>
        /// <param name="categoryID2">Category 2</param>
        /// <param name="categoryID3">Category 3</param>
        /// <param name="saleCD1">Sale CD 1</param>
        /// <param name="saleCD2">Sale CD 2</param>
        /// <returns></returns>
        public IList<SalesReportChartByCustomer> GetListReportChartByCustomer(DateTime? salesDateFrm, DateTime? salesDateTo,
            string categoryID1, string categoryID2, string categoryID3,
            string saleCD1, string saleCD2, string currencyID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetListReportChartByCustomer_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDateFrm", salesDateFrm);
            base.AddParam(paras, "IN_SalesDateTo", salesDateTo);
            base.AddParam(paras, "IN_CategoryID1", categoryID1);
            base.AddParam(paras, "IN_CategoryID2", categoryID2);
            base.AddParam(paras, "IN_CategoryID3", categoryID3);
            base.AddParam(paras, "IN_SaleCD1", saleCD1);
            base.AddParam(paras, "IN_SaleCD2", saleCD2);
            base.AddParam(paras, "IN_CurrencyID", currencyID);

            return this.db.FindList<SalesReportChartByCustomer>(cmdText, paras);
        }

        /// <summary>
        /// Get List Report Chart By Sale1
        /// </summary>
        /// <param name="salesDateFrm">Sales Date From</param>
        /// <param name="salesDateTo">Sales Date To</param>
        /// <param name="categoryID1">Category 1</param>
        /// <param name="categoryID2">Category 2</param>
        /// <param name="categoryID3">Category 3</param>
        /// <param name="saleCD1">Sale CD 1</param>
        /// <param name="saleCD2">Sale CD 2</param>
        /// <param name="currencyID">Currency ID</param>
        /// <param name="type">Type of report</param>
        /// <returns></returns>
        public IList<SalesReportChartBySale> GetListReportChartBySale1(DateTime? salesDateFrm, DateTime? salesDateTo,
            string categoryID1, string categoryID2, string categoryID3,
            string saleCD1, string saleCD2, string currencyID, string type)
        {
            //SQL String
            string cmdText = string.Empty;
            if (type == "3")
            {
                cmdText = "P_T_Sales_H_GetListReportChartBySale1_W";
            }
            else
            {
                cmdText = "P_T_Sales_H_GetListReportChartBySale2_W";
            }

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDateFrm", salesDateFrm);
            base.AddParam(paras, "IN_SalesDateTo", salesDateTo);
            base.AddParam(paras, "IN_CategoryID1", categoryID1);
            base.AddParam(paras, "IN_CategoryID2", categoryID2);
            base.AddParam(paras, "IN_CategoryID3", categoryID3);
            base.AddParam(paras, "IN_SaleCD1", saleCD1);
            base.AddParam(paras, "IN_SaleCD2", saleCD2);
            base.AddParam(paras, "IN_CurrencyID", currencyID);

            return this.db.FindList<SalesReportChartBySale>(cmdText, paras);
        }

        /// <summary>
        /// Get List Report Chart By Category
        /// </summary>
        /// <param name="salesDateFrm">Sales Date From</param>
        /// <param name="salesDateTo">Sales Date To</param>
        /// <param name="categoryID1">Category 1</param>
        /// <param name="categoryID2">Category 2</param>
        /// <param name="categoryID3">Category 3</param>
        /// <param name="saleCD1">Sale CD 1</param>
        /// <param name="saleCD2">Sale CD 2</param>
        /// <param name="currencyID">Currency ID</param>
        /// <returns></returns>
        public IList<SalesReportChartByCategory> GetListReportChartByCategory(DateTime? salesDateFrm, DateTime? salesDateTo,
            string categoryID1, string categoryID2, string categoryID3,
            string saleCD1, string saleCD2, string currencyID)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_GetListReportChartByCategory_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesDateFrm", salesDateFrm);
            base.AddParam(paras, "IN_SalesDateTo", salesDateTo);
            base.AddParam(paras, "IN_CategoryID1", categoryID1);
            base.AddParam(paras, "IN_CategoryID2", categoryID2);
            base.AddParam(paras, "IN_CategoryID3", categoryID3);
            base.AddParam(paras, "IN_SaleCD1", saleCD1);
            base.AddParam(paras, "IN_SaleCD2", saleCD2);
            base.AddParam(paras, "IN_CurrencyID", currencyID);

            return this.db.FindList<SalesReportChartByCategory>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/08/08
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        public int Insert(T_Sales_H header)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_Insert_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", header.SalesNo);
            base.AddParam(paras, "IN_SalesDate", header.SalesDate);
            base.AddParam(paras, "IN_QuoteNo", header.QuoteNo);
            base.AddParam(paras, "IN_QuoteDate", header.QuoteDate);
            base.AddParam(paras, "IN_PreparedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", header.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", header.ApprovedName);
            base.AddParam(paras, "IN_SalesCD1", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.SalesCD1, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName1", header.SalesName1);
            base.AddParam(paras, "IN_SalesCD2", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.SalesCD2, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName2", header.SalesName2);
            base.AddParam(paras, "IN_CustomerCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", header.CustomerName);
            base.AddParam(paras, "IN_SubjectName", header.SubjectName);
            base.AddParam(paras, "IN_Memo", header.Memo);
            base.AddParam(paras, "IN_ContractNo", header.ContractNo);
            base.AddParam(paras, "IN_ContractDate", header.ContractDate);
            base.AddParam(paras, "IN_CustomerAddress1", header.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", header.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", header.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", header.Tel);
            base.AddParam(paras, "IN_FAX", header.FAX);
            base.AddParam(paras, "IN_ContactPerson", header.ContactPerson);
            base.AddParam(paras, "IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", header.MethodVat);
            base.AddParam(paras, "IN_Vat", header.Vat);
            base.AddParam(paras, "IN_VatRatio", header.VatRatio);
            base.AddParam(paras, "IN_VatType", header.VatType);
            base.AddParam(paras, "IN_Total", header.Total);
            base.AddParam(paras, "IN_GrandTotal", header.GrandTotal);
            //2014/12/18 ISV-HUNG - Delete Start
            //base.AddParam(paras, "IN_ProfitRatio", header.ProfitRatio);
            //2014/12/18 ISV-HUNG - Delete End
            base.AddParam(paras, "IN_Approved", header.Approved);
            base.AddParam(paras, "IN_Position", header.Position);
            base.AddParam(paras, "IN_StatusFlag", header.StatusFlag);
            base.AddParam(paras, "IN_IssuedFlag", header.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras, "IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", header.IssuedUID);
            base.AddParam(paras, "IN_VersionUpdateUID", header.VersionUpdateUID);
            base.AddParam(paras, "IN_FinishFlag", header.FinishFlag);

            //---------------Add 2015/01/06-----------------//
            base.AddParam(paras, "IN_CompleteDate", header.CompleteDate);
            base.AddParam(paras, "IN_PaymentDate", header.PaymentDate);
            //---------------Add 2015/01/06-----------------//

            base.AddParam(paras, "IN_CreateUID", header.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update version
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        public int UpdateVersion(T_Sales_H header)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_UpdateVersion_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", header.ID);

            base.AddParam(paras, "IN_VersionUpdateDate", header.VersionUpdateDate);
            base.AddParam(paras, "IN_VersionUpdateUID", header.VersionUpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="header">T_Sales_H</param>
        /// <returns></returns>
        public int Update(T_Sales_H header)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_Update_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", header.ID);
            base.AddParam(paras, "IN_SalesNo", header.SalesNo);
            base.AddParam(paras, "IN_SalesDate", header.SalesDate);
            base.AddParam(paras, "IN_QuoteNo", header.QuoteNo);
            base.AddParam(paras, "IN_QuoteDate", header.QuoteDate);
            base.AddParam(paras, "IN_PreparedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", header.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", header.ApprovedName);
            base.AddParam(paras, "IN_SalesCD1", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.SalesCD1, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName1", header.SalesName1);
            base.AddParam(paras, "IN_SalesCD2", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.SalesCD2, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_SalesName2", header.SalesName2);
            base.AddParam(paras, "IN_CustomerCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", header.CustomerName);
            base.AddParam(paras, "IN_SubjectName", header.SubjectName);
            base.AddParam(paras, "IN_Memo", header.Memo);
            base.AddParam(paras, "IN_ContractNo", header.ContractNo);
            base.AddParam(paras, "IN_ContractDate", header.ContractDate);
            base.AddParam(paras, "IN_CustomerAddress1", header.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", header.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", header.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", header.Tel);
            base.AddParam(paras, "IN_FAX", header.FAX);
            base.AddParam(paras, "IN_ContactPerson", header.ContactPerson);
            base.AddParam(paras, "IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", header.MethodVat);
            base.AddParam(paras, "IN_Vat", header.Vat);
            base.AddParam(paras, "IN_VatRatio", header.VatRatio);
            base.AddParam(paras, "IN_VatType", header.VatType);
            base.AddParam(paras, "IN_Total", header.Total);
            base.AddParam(paras, "IN_GrandTotal", header.GrandTotal);
            //2014/12/18 ISV-HUNG - Delete Start
            //base.AddParam(paras, "IN_ProfitRatio", header.ProfitRatio);
            //2014/12/18 ISV-HUNG - Delete End
            base.AddParam(paras, "IN_Approved", header.Approved);
            base.AddParam(paras, "IN_Position", header.Position);
            base.AddParam(paras, "IN_StatusFlag", header.StatusFlag);
            base.AddParam(paras, "IN_IssuedFlag", header.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras, "IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", header.IssuedUID);
            base.AddParam(paras, "IN_VersionUpdateDate", header.VersionUpdateDate);
            base.AddParam(paras, "IN_VersionUpdateUID", header.VersionUpdateUID);
            base.AddParam(paras, "IN_FinishFlag", header.FinishFlag);

            //---------------Add 2015/01/06-----------------//
            base.AddParam(paras, "IN_CompleteDate", header.CompleteDate);
            base.AddParam(paras, "IN_PaymentDate", header.PaymentDate);
            //---------------Add 2015/01/06-----------------//

            base.AddParam(paras, "IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Flag
        /// </summary>
        /// <param name="sales_H">T_Sales_H</param>
        /// <returns></returns>
        public int UpdateFlag(T_Sales_H sales_H)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_UpdateFlag_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", sales_H.ID);
            base.AddParam(paras, "IN_IssuedFlag", sales_H.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", sales_H.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", sales_H.UpdateDate);
            base.AddParam(paras, "IN_VersionUpdateDate", sales_H.VersionUpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Finish Flag
        /// </summary>
        /// <param name="sales_H">T_Sales_H</param>
        /// <returns></returns>
        public int UpdateFinishFlag(T_Sales_H sales_H)
        {
            //SQL String
            string cmdText = "P_T_Sales_H_UpdateFinishFlag_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", sales_H.ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
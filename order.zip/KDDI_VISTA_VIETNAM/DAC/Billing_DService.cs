﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    public class Billing_DService : BaseService
    {

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Billing_DService() : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Billing_DService(DB db) :base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get List By SalesID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/04
        /// </summary>
        /// <param name="salesID"></param>
        /// <returns></returns>
        public int GetListBySalesID(int salesID)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_GetListBySalesID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesID", salesID);

            //return this.db.FindList<T_Billing_D>(cmdText, paras);
            return (int)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Detail Sell By ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public IList<T_Billing_D> GetListByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_GetListByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", id);

            return this.db.FindList<T_Billing_D>(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Detail Sell By ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public T_Billing_D GetByFK(int id)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_GetByFK_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Billing_D>(cmdText, paras);
        }

        /// <summary>
        /// Get Sum Quantity By Sales Sell ID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/05
        /// </summary>
        /// <param name="accSellID"></param>
        /// <returns></returns>
        public decimal GetSumQuantityBySalesSellID(int accSellID)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_GetQtyBySalesSellID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesSellID", accSellID);

            return (decimal)this.db.ExecuteScalar(cmdText, paras);
        }


        /// <summary>
        /// Get remain quantity by Sales sell id
        /// </summary>
        /// <param name="salesSellID">Sales sell id</param>
        /// <param name="billingID">Billing ID</param>
        /// <returns>Remain quantity</returns>
        public decimal GetRemainQtyBySalesSellID(int salesSellID, int billingID)
        {
            //Set command text
            string cmdText = "P_T_Billing_D_GetRemainQtyBySalesSellID_W";

            //add prameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesSellID", salesSellID);
            base.AddParam(paras, "IN_BillingID", billingID);

            return (decimal)this.db.ExecuteScalar(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="header">T_Billing_D</param>
        /// <returns></returns>
        public int Insert(T_Billing_D billing_D)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", billing_D.HID);
            base.AddParam(paras, "IN_No", billing_D.No);
            base.AddParam(paras, "IN_SalesSellID", billing_D.SalesSellID);

            base.AddParam(paras, "IN_ProductID", billing_D.ProductID);
            base.AddParam(paras, "IN_ProductCD", billing_D.ProductCD);
            base.AddParam(paras, "IN_ProductName", billing_D.ProductName);
            base.AddParam(paras, "IN_VatType", billing_D.VATType);
            base.AddParam(paras, "IN_VatRatio", billing_D.VatRatio);
            base.AddParam(paras, "IN_Description", billing_D.Description);
            base.AddParam(paras, "IN_UnitPrice", billing_D.UnitPrice);
            base.AddParam(paras, "IN_Quantity", billing_D.Quantity);
            base.AddParam(paras, "IN_UnitID", billing_D.UnitID);
            base.AddParam(paras, "IN_Total", billing_D.Total);
            base.AddParam(paras, "IN_Vat", billing_D.Vat);
            base.AddParam(paras, "IN_Remark", billing_D.Remark);


            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update No By InternalID
        /// Create Author: ISV-GIAM
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <param name="purchaseNo">Purchase No</param>
        /// <returns></returns>
        public int UpdateNoByInternalID(int internalID, int purchaseNo)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_UpdateNoByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);
            base.AddParam(paras, "IN_No", purchaseNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-NGUYEN
        /// Edited Author: ISV-GIAM
        /// </summary>
        /// <param name="header">T_Sales_H</param>
        /// <returns></returns>
        public int Update(T_Billing_D billing_D)
        {
            //SQL String
            string cmdText = "P_T_Billing_D_Update_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", billing_D.InternalID);
            base.AddParam(paras,"IN_HID", billing_D.HID);
            base.AddParam(paras,"IN_No", billing_D.No);
            base.AddParam(paras,"IN_SalesSellID", billing_D.SalesSellID);
            base.AddParam(paras,"IN_ProductCD", billing_D.ProductCD);
            base.AddParam(paras,"IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", billing_D.ProductName);
            base.AddParam(paras,"IN_Description", billing_D.Description);
            base.AddParam(paras,"IN_Remark", billing_D.Remark);
            base.AddParam(paras,"IN_UnitID", billing_D.UnitID);
            base.AddParam(paras,"IN_VatType", billing_D.VATType);
            base.AddParam(paras,"IN_VatRatio", billing_D.VatRatio);
            base.AddParam(paras,"IN_UnitPrice", billing_D.UnitPrice);
            base.AddParam(paras,"IN_Quantity", billing_D.Quantity);
            base.AddParam(paras,"IN_Total", billing_D.Total);
            base.AddParam(paras,"IN_Vat", billing_D.Vat);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

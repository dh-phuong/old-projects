﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Class Quotation_C
    /// Create Date: 2014/08/11
    /// Create Author: ISV-PHUONG
    /// </summary>
    public sealed class Quotation_CService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Quotation_C service
        /// </summary>        
        private Quotation_CService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Quotation_C service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Quotation_CService(DB db)
            : base(db)
        {
        }

        #endregion

        #region "Get Data"

        /// <summary>
        /// Get Quote Condition by Primary key
        /// </summary>
        /// <param name="conStr"></param>
        /// <param name="ID"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public T_Quote_C GetByPK(int ID)
        {
            string cmdText = "P_T_Quote_C_GetByPK_W";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            return this.db.Find <T_Quote_C>(cmdText, paras);
        }



        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/08/11
        /// Create Author: ISV-PHUONG
        /// </summary>
        /// <param name="acceptC"></param>
        /// <returns></returns>
        public int Insert(T_Quote_C quoteC)
        {
            //SQL String
            string cmdText = "P_T_Quote_C_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", quoteC.HID);
            base.AddParam(paras, "IN_Conditions", quoteC.Conditions);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Date: 2014/08/11
        /// Create Author: ISV-PHUONG
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Quote_C_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

    }
}

﻿
using System.Collections;
using OMS.Models;
namespace OMS.DAC
{
    /// <summary>
    /// Class Purchase_CService
    /// Create Date: 2014/09/03
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Purchase_CService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Purchase_CService() : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Purchase_CService(DB db) :base(db)
        {
        }
        #endregion

        #region Get

        /// <summary>
        /// Get Purchase Condition by Primary Key
        /// ISV-Giam
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public T_Purchase_C GetByPK(int ID)
        {
            string cmdText = "P_T_Purchase_C_GetByID_W";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            return this.db.Find<T_Purchase_C>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-Giam
        /// </summary>
        /// <param name="purchaseC"></param>
        /// <returns></returns>
        public int Insert(T_Purchase_C purchaseC)
        {
            //SQL String
            string cmdText = "P_T_Purchase_C_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", purchaseC.HID);
            base.AddParam(paras, "IN_Conditions", purchaseC.Conditions);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Date: 2014/08/11
        /// Create Author: ISV-Giam
        /// </summary>
        /// <param name="ID">id</param>
        /// <returns></returns>
        public int Delete(int ID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_C_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", ID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
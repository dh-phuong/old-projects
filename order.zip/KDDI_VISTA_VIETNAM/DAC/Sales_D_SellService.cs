﻿using System.Collections;
using System.Collections.Generic;

using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Class Sales_D_SellService DAC
    /// Create Date: 2014/12/16
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Sales_D_SellService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Sales_D_SellService()
            :base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Sales_D_SellService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get For Billing Selection
        /// </summary>
        /// <param name="salesNo">Sales No</param>
        /// <param name="quoteNo">Quote No</param>
        /// <param name="customerCD">Customer CD</param>
        /// <param name="billingID">Billing ID</param>
        /// <param name="methodVat">Method VAT</param>
        /// <returns></returns>
        public IList<BillingSelection> GetForBillingSelect(string salesNo, string quoteNo, string customerCD, int billingID, string methodVat)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_GetDataBillingSelect_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", salesNo);
            base.AddParam(paras, "IN_QuoteNo", quoteNo);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(customerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_BillingID", billingID);
            base.AddParam(paras, "IN_LostStatus", (int)StatusFlag.Lost);
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_VAT_TYPE);
            base.AddParam(paras, "IN_MethodVat", methodVat);

            return base.db.FindList<BillingSelection>(cmdText, paras);
        }

        /// <summary>
        /// Get Sales Detail Sell By ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public IList<T_Sales_D_Sell> GetListByID(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_GetListByID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<T_Sales_D_Sell>(cmdText, paras);
        }

        /// <summary>
        /// Get For Delivery Select
        /// Create Author: VN-Nho
        /// Create Date: 2014/09/09
        /// </summary>
        /// <param name="salesNo">Sales No</param>
        /// <param name="quoteNo">Quotation No</param>
        /// <param name="customerCD">Customer code</param>
        /// <param name="deliveryID">Delivery ID</param>
        /// <returns>List delivery select information</returns>
        public IList<DeliverySelectInfo> GetForDeliverySelect(string salesNo, string quoteNo, string customerCD, int deliveryID, string methodVat)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_GetDataDeliverySelect_W";

            //Add Param
            Hashtable paras = new Hashtable();
            this.AddParam(paras, "IN_SalesNo", salesNo);
            this.AddParam(paras, "IN_QuoteNo", quoteNo);
            this.AddParam(paras, "IN_CustomerCD", customerCD);
            this.AddParam(paras, "IN_DeliverID", deliveryID);
            this.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_VAT_TYPE);
            base.AddParam(paras, "IN_MethodVat", methodVat);

            return this.db.FindList<DeliverySelectInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get by internal id
        /// </summary>
        /// <param name="internalID">Internal Id</param>
        /// <returns>Sales Sell data</returns>
        public T_Sales_D_Sell GetByInternalID(int internalID)
        {
            //Set command text
            string cmdText = "P_T_Sales_D_Sell_GetByInternalID_W";

            //Add param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.Find<T_Sales_D_Sell>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="sales_D_Sell">T_Sales_D_Sell</param>
        /// <returns></returns>
        public int Insert(T_Sales_D_Sell sales_D_Sell)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_Insert_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", sales_D_Sell.HID);
            base.AddParam(paras,"IN_No", sales_D_Sell.No);
            base.AddParam(paras,"IN_ProductCD", sales_D_Sell.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", sales_D_Sell.ProductName);
            base.AddParam(paras,"IN_Description", sales_D_Sell.Description);
            base.AddParam(paras,"IN_Remark", sales_D_Sell.Remark);
            base.AddParam(paras,"IN_UnitID", sales_D_Sell.UnitID);
            base.AddParam(paras, "IN_UnitPrice", sales_D_Sell.UnitPrice);
            base.AddParam(paras, "IN_Quantity", sales_D_Sell.Quantity);
            base.AddParam(paras, "IN_Vat", sales_D_Sell.Vat);
            base.AddParam(paras, "IN_VatRatio", sales_D_Sell.VatRatio);
            base.AddParam(paras,"IN_VatType", sales_D_Sell.VatType);
            base.AddParam(paras,"IN_Total", sales_D_Sell.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update No By InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <param name="sellNo">Sell No</param>
        /// <returns></returns>
        public int UpdateNoByInternalID(int internalID, int sellNo)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_UpdateNoByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", internalID);
            base.AddParam(paras,"IN_No", sellNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="sell">T_Sales_D_Sell</param>
        /// <returns></returns>
        public int Update(T_Sales_D_Sell sell)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_Update_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", sell.InternalID);
            base.AddParam(paras,"IN_HID", sell.HID);
            base.AddParam(paras,"IN_No", sell.No);
            base.AddParam(paras,"IN_ProductCD", sell.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", sell.ProductName);
            base.AddParam(paras,"IN_Description", sell.Description);
            base.AddParam(paras,"IN_Remark", sell.Remark);
            base.AddParam(paras,"IN_UnitID", sell.UnitID);
            base.AddParam(paras, "IN_UnitPrice", sell.UnitPrice);
            base.AddParam(paras, "IN_Quantity", sell.Quantity);
            base.AddParam(paras, "IN_Vat", sell.Vat);
            base.AddParam(paras, "IN_VatRatio", sell.VatRatio);
            base.AddParam(paras,"IN_VatType", sell.VatType);
            base.AddParam(paras,"IN_Total", sell.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_Delete_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete data by InternalID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <returns></returns>
        public int DeleteByInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Sales_D_Sell_DeleteByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_InternalID", internalID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
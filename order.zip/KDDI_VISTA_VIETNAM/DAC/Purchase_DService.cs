﻿using System;
using System.Collections;
using System.Collections.Generic;
using OMS.Models;


namespace OMS.DAC
{
    /// <summary>
    /// Class Purchase_DService
    /// Create Date: 2014/09/03
    /// Create Author: ISV-HUNG
    /// </summary>
    public class Purchase_DService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private Purchase_DService() :base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public Purchase_DService(DB db):base(db)
        {
        }
        #endregion

        #region Get data
        /// <summary>
        /// Get by purchase ID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/03
        /// </summary>
        /// <param name="purchaseID"></param>
        /// <returns></returns>
        public IList<T_Purchase_D> GetByPurchaseID(int purchaseID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_GetByPurchaseID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", purchaseID);

            return this.db.FindList<T_Purchase_D>(cmdText, paras);
        }

        /// <summary>
        /// Get by Internal ID
        /// Create Author: ISV-HUNG
        /// Create Date: 2015/02/09
        /// </summary>
        /// <param name="internalID"></param>
        /// <returns></returns>
        public T_Purchase_D GetByInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_GetByInternalID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.Find<T_Purchase_D>(cmdText, paras);
        }

        /// <summary>
        /// Get List Sum Qty By SalesID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/04
        /// </summary>
        /// <param name="accID"></param>
        /// <returns></returns>
        //public IList<T_Purchase_D> GetListSumQtyBySalesID(int accID)
        public int GetListSumQtyBySalesID(int accID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_GetListSumQtyBySalesID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesID", accID);

            //return this.db.FindList<T_Purchase_D>(cmdText, paras);
            return (int)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get Sum Quantity By SalesCostID
        /// Create Author: ISV-HUNG
        /// Edited Author: ISV-Giam (2014/12/16)
        /// Create Date: 2014/09/05
        /// </summary>
        /// <param name="salesCostID">SalesCostID</param>
        /// <returns></returns>
        public decimal GetSumQuantityBySalesCostID(int salesCostID)
        {
            //SQL String
            //string cmdText = "P_T_Purchase_D_GetSumQuantityByAcceptCostID_W";
            string cmdText = "P_T_Purchase_D_GetSumQuantityBySalesCostID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesCostID", salesCostID);

            return (decimal)this.db.ExecuteScalar(cmdText, paras);
        }

        /// <summary>
        /// Get Remain Quantity by SalesCostID
        /// Create Author: ISV-HUNG
        /// Edited Author: ISV-Giam (2014/12/16)
        /// Create Date: 2014/09/08
        /// </summary>
        /// <param name="salesCostID"></param>
        /// <param name="purchaseID"></param>
        /// <returns></returns>
        public decimal GetRemainQtyBySalesCostID(int salesCostID,int purchaseID)
        {
            //SQL String
            //string cmdText = "P_T_Purchase_D_GetRemainQtyByAcceptCostID_W";
            string cmdText = "P_T_Purchase_D_GetRemainQtyBySalesCostID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesCostID", salesCostID);
            base.AddParam(paras, "IN_PurchaseID", purchaseID);

            return (decimal)this.db.ExecuteScalar(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-Giam
        /// </summary>
        /// <param name="header">T_Purchase_D</param>
        /// <returns></returns>
        public int Insert(T_Purchase_D purchase_D)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", purchase_D.HID);
            base.AddParam(paras,"IN_No", purchase_D.No);
            base.AddParam(paras,"IN_SalesCostID", purchase_D.SalesCostID);
            base.AddParam(paras,"IN_ProductID", purchase_D.ProductID);
            base.AddParam(paras,"IN_ProductCD", purchase_D.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras,"IN_ProductName", purchase_D.ProductName);
            base.AddParam(paras,"IN_Description", purchase_D.Description);
            base.AddParam(paras,"IN_UnitPrice", purchase_D.UnitPrice);
            base.AddParam(paras,"IN_Vat", purchase_D.Vat);
            base.AddParam(paras,"IN_VatType", purchase_D.VatType);
            base.AddParam(paras,"IN_VatRatio", purchase_D.VatRatio);
            base.AddParam(paras,"IN_Quantity", purchase_D.Quantity);
            base.AddParam(paras,"IN_UnitID", purchase_D.UnitID);
            base.AddParam(paras,"IN_Total", purchase_D.Total);
            base.AddParam(paras,"IN_DeliverQuantity", purchase_D.DeliverQuantity);
            base.AddParam(paras,"IN_DeliverDate", purchase_D.DeliverDate);
            base.AddParam(paras,"IN_Remark", purchase_D.Remark);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Purchase_D>();
            }
            return 0;
        }
        #endregion

        #region Update
        /// <summary>
        /// Update No By InternalID
        /// Create Author: ISV-GIAM
        /// </summary>
        /// <param name="internalID">Internal ID</param>
        /// <param name="purchaseNo">Purchase No</param>
        /// <returns></returns>
        public int UpdateNoByInternalID(int internalID, int purchaseNo)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_UpdateNoByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);
            base.AddParam(paras, "IN_No", purchaseNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update data
        /// Create Author: ISV-GIAM
        /// </summary>
        /// <param name="purchaseD">T_Purchase_D</param>
        /// <returns></returns>
        public int Update(T_Purchase_D purchaseD)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_Update_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", purchaseD.InternalID);
            base.AddParam(paras, "IN_HID", purchaseD.HID);
            base.AddParam(paras, "IN_No", purchaseD.No);
            base.AddParam(paras, "IN_SalesCostID", purchaseD.SalesCostID);            
            base.AddParam(paras, "IN_ProductCD", purchaseD.ProductCD);
            base.AddParam(paras, "IN_ProductCDSupport", M_Product.PRODUCT_CODE_SUPPORT);
            base.AddParam(paras, "IN_ProductName", purchaseD.ProductName);
            base.AddParam(paras, "IN_Description", purchaseD.Description);
            base.AddParam(paras, "IN_Remark", purchaseD.Remark);
            base.AddParam(paras, "IN_DeliverQuantity", purchaseD.DeliverQuantity);
            base.AddParam(paras, "IN_DeliverDate", purchaseD.DeliverDate);
            base.AddParam(paras, "IN_UnitID", purchaseD.UnitID);
            base.AddParam(paras, "IN_UnitPrice", purchaseD.UnitPrice);
            base.AddParam(paras, "IN_Quantity", purchaseD.Quantity);
            base.AddParam(paras, "IN_Vat", purchaseD.Vat);
            base.AddParam(paras, "IN_VatRatio", purchaseD.VatRatio);
            base.AddParam(paras, "IN_VatType", purchaseD.VatType);
            base.AddParam(paras, "IN_Total", purchaseD.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion


        #region Delete
        /// <summary>
        /// Delete data
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/08
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Delete data
        /// Create Author: ISV-GIAM
        /// Create Date: 2015/01/12
        /// </summary>
        /// <param name="internalID"></param>
        /// <returns></returns>
        public int DeleteByInternalID(int internalID)
        {
            //SQL String
            string cmdText = "P_T_Purchase_D_DeleteByInternalID_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_InternalID", internalID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
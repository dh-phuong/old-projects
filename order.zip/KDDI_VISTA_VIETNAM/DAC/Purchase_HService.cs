﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// Purchase_H Service
    /// </summary>
    public sealed class Purchase_HService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Purchase_H service
        /// </summary>
        private Purchase_HService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Purchase_H service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Purchase_HService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get
        /// <summary>
        /// Get List By Condition
        /// ISV-Giam
        /// </summary>
        /// <param name="inputModel"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<PurchaseHeaderResult> GetListByCond(PurchaseHeaderSearch inputModel,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetListByConditions_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseNo", inputModel.PurchaseNo);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_PurchaseDateFrom", inputModel.PurchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo", inputModel.PurchaseDateTo);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(inputModel.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);

            base.AddParam(paras, "IN_FinishedFlag", inputModel.FinishedFlag);
            base.AddParam(paras, "IN_DeletedFlag", inputModel.DeletedFlag);
            base.AddParam(paras, "IN_Subject", inputModel.SubjectName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<PurchaseHeaderResult>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row By Condition
        /// ISV-Giam
        /// </summary>
        /// <param name="inputModel"></param>
        /// <returns></returns>
        public int GetTotalRow(PurchaseHeaderSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetTotalRow_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseNo", inputModel.PurchaseNo, true);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_PurchaseDateFrom", inputModel.PurchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo", inputModel.PurchaseDateTo);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(inputModel.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);

            base.AddParam(paras, "IN_FinishedFlag", inputModel.FinishedFlag);
            base.AddParam(paras, "IN_DeletedFlag", inputModel.DeletedFlag);
            base.AddParam(paras, "IN_Subject", inputModel.SubjectName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get total row for purchase product search
        /// Create by ISV-HUNG
        /// Create date: 2015/02/09
        /// </summary>
        /// <param name="model">Model</param>
        /// <returns></returns>
        public int GetTotalRowForPurchaseProductSearch(PurchaseProductSearchHeader model)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetTotalRowForPurchaseProductSearch_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseDateFrm", model.PurchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo", model.PurchaseDateTo);
            base.AddParam(paras, "IN_ProductCD", model.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", model.ProductName, true);
            base.AddParam(paras, "IN_CategoryID1", model.CategoryID1);
            base.AddParam(paras, "IN_CategoryID2", model.CategoryID2);
            base.AddParam(paras, "IN_CategoryID3", model.CategoryID3);
            //base.AddParam(paras, "IN_UnitPriceFrom", model.UnitPriceFrom,true);
            //base.AddParam(paras, "IN_UnitPriceTo", model.UnitPriceTo, true);
            base.AddParam(paras, "IN_Description", model.Description, true);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(model.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName", model.VendorName, true);
            //base.AddParam(paras, "IN_Currency", model.Currency);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get the list for searching
        /// </summary>
        /// <param name="model">PurchaseHeaderSearch</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<PurchaseProductSearchResult> GetListForPurchaseProductSearch(PurchaseProductSearchHeader model, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetListForPurchaseProductSearch_W";

            //Add Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseDateFrm", model.PurchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo", model.PurchaseDateTo);
            base.AddParam(paras, "IN_ProductCD", model.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", model.ProductName, true);
            base.AddParam(paras, "IN_CategoryID1", model.CategoryID1);
            base.AddParam(paras, "IN_CategoryID2", model.CategoryID2);
            base.AddParam(paras, "IN_CategoryID3", model.CategoryID3);
            //base.AddParam(paras, "IN_UnitPriceFrom", model.UnitPriceFrom, true);
            //base.AddParam(paras, "IN_UnitPriceTo", model.UnitPriceTo, true);
            base.AddParam(paras, "IN_Description", model.Description, true);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(model.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_VendorName", model.VendorName, true);
            //base.AddParam(paras, "IN_Currency", model.Currency);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<PurchaseProductSearchResult>(cmdText, paras);
        }

        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/03
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public T_Purchase_H GetByPK(int id)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetByPK_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Purchase_H>(cmdText, paras);
        }

        /// <summary>
        /// Get current Purchase No
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/05
        /// </summary>
        /// <returns></returns>
        public int GetCurrentPurchaseNo()
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetCurrentPurchaseNo_W";

            return this.db.ExecuteNonQuery(cmdText);
        }

        /// <summary>
        /// GetListForExcel
        /// Create Author: ISV-Giam
        /// Create Date: 2014/10/01
        /// </summary>
        /// <param name="inputModel">PurchaseHeaderSearch</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<PurchaseExcel> GetListForExcel(PurchaseHeaderSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseNo", inputModel.PurchaseNo, true);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_PurchaseDateFrom", inputModel.PurchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo", inputModel.PurchaseDateTo);
            base.AddParam(paras, "IN_VendorCD", EditDataUtil.ToFixCodeDB(inputModel.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_FinishedFlag", inputModel.FinishedFlag);
            base.AddParam(paras, "IN_DeletedFlag", inputModel.DeletedFlag);
            base.AddParam(paras, "IN_Subject", inputModel.SubjectName, true);
            //base.AddParam(paras, "IN_VatType", M_Config_H.CONFIG_CD_VAT_TYPE);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);

            return this.db.FindList<PurchaseExcel>(cmdText, paras);
        }

        /// <summary>
        /// GetListForExcel
        /// Create Author: ISV-NGUYEN
        /// Create Date: 2015/02/04
        /// </summary>
        /// <param name="purchaseDateFrom">purchaseDateFrom</param>
        /// <param name="purchaseDateTo">purchaseDateTo</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<POListExcel> GetListForCreatePOListExcel(DateTime? purchaseDateFrom, DateTime? purchaseDateTo)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetListForCreatePOListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseDateFrom", purchaseDateFrom);
            base.AddParam(paras, "IN_PurchaseDateTo",  purchaseDateTo);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);

            return this.db.FindList<POListExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get List For UnCreate PO List Excel
        /// Create Author: ISV-GIAM
        /// Create Date: 2015/02/05
        /// </summary>
        /// <param name="purchaseDateFrom">purchaseDateFrom</param>
        /// <param name="purchaseDateTo">purchaseDateTo</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<UnPOListExcel> GetListForUnCreatePOListExcel(DateTime? purchaseDateFrom, DateTime? purchaseDateTo)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_GetListForUncreatePOListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateFrom", purchaseDateFrom);
            base.AddParam(paras, "IN_DateTo", purchaseDateTo);

            return this.db.FindList<UnPOListExcel>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// Create Date: 2014/09/08
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="header">T_Purchase_H</param>
        /// <returns></returns>
        public int Insert(T_Purchase_H header)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PurchaseNo", header.PurchaseNo);
            base.AddParam(paras, "IN_QuoteNo", header.QuoteNo);
            base.AddParam(paras, "IN_SalesNo", header.SalesNo);
            base.AddParam(paras, "IN_IssuedFlag", header.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras, "IN_FinishFlag", header.FinishFlag);
            base.AddParam(paras, "IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras, "IN_PurchaseDate", header.PurchaseDate);
            //base.AddParam(paras,"IN_DeliveredDate", header.DeliveredDate);
            base.AddParam(paras, "IN_ExpiryDate", header.ExpiryDate);
            base.AddParam(paras, "IN_SubjectName", header.SubjectName);
            base.AddParam(paras, "IN_PreparedCD", header.PreparedCD);
            base.AddParam(paras, "IN_PreparedName", header.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", header.ApprovedCD);
            base.AddParam(paras, "IN_ApprovedName", header.ApprovedName);
            base.AddParam(paras, "IN_VendorCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorName", header.VendorName);
            base.AddParam(paras, "IN_VendorAddress1", header.VendorAddress1);
            base.AddParam(paras, "IN_VendorAddress2", header.VendorAddress2);
            base.AddParam(paras, "IN_VendorAddress3", header.VendorAddress3);
            base.AddParam(paras, "IN_Tel", header.Tel);
            base.AddParam(paras, "IN_Fax", header.Fax);
            base.AddParam(paras, "IN_ContactPerson", header.ContactPerson);
            //base.AddParam(paras,"IN_EstPaymentDate", header.EstPaymentDate);
            base.AddParam(paras,"IN_PaymentDate", header.PaymentDate);
            base.AddParam(paras, "IN_Total", header.Total);
            base.AddParam(paras, "IN_GrandTotal", header.GrandTotal);
            base.AddParam(paras, "IN_Confirmed", header.Confirmed);
            base.AddParam(paras, "IN_Position", header.Position);
            base.AddParam(paras, "IN_MethodVat", header.MethodVat);
            base.AddParam(paras, "IN_Vat", header.Vat);
            base.AddParam(paras, "IN_VatRatio", header.VatRatio);
            base.AddParam(paras, "IN_VatType", header.VatType);
            base.AddParam(paras, "IN_Memo", header.Memo);
            base.AddParam(paras, "IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", header.IssuedUID);
            base.AddParam(paras, "IN_CreateUID", header.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Purchase_H>();
            }
            return 0;
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// Create Author: ISV-HUNG
        /// Create Date: 2014/09/08
        /// </summary>
        /// <param name="header">T_Purchase_H</param>
        /// <returns></returns>
        public int Update(T_Purchase_H header)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_Update_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", header.ID);
            base.AddParam(paras, "IN_IssuedFlag", header.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", header.DeleteFlag);
            base.AddParam(paras, "IN_FinishFlag", header.FinishFlag);
            base.AddParam(paras, "IN_CurrencyID", header.CurrencyID);
            base.AddParam(paras, "IN_PurchaseDate", header.PurchaseDate);
            //base.AddParam(paras,"IN_DeliveredDate", header.DeliveredDate);
            base.AddParam(paras, "IN_ExpiryDate", header.ExpiryDate);
            base.AddParam(paras, "IN_SubjectName", header.SubjectName);
            base.AddParam(paras, "IN_PreparedCD", header.PreparedCD);
            base.AddParam(paras, "IN_PreparedName", header.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", header.ApprovedCD);
            base.AddParam(paras, "IN_ApprovedName", header.ApprovedName);
            base.AddParam(paras, "IN_VendorCD", OMS.Utilities.EditDataUtil.ToFixCodeDB(header.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorCDSupport", OMS.Utilities.EditDataUtil.ToFixCodeDB(M_Vendor.VENDOR_CODE_SUPPORT, M_Vendor.VENDOR_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_VendorName", header.VendorName);
            base.AddParam(paras, "IN_VendorAddress1", header.VendorAddress1);
            base.AddParam(paras, "IN_VendorAddress2", header.VendorAddress2);
            base.AddParam(paras, "IN_VendorAddress3", header.VendorAddress3);
            base.AddParam(paras, "IN_Tel", header.Tel);
            base.AddParam(paras, "IN_Fax", header.Fax);
            base.AddParam(paras, "IN_ContactPerson", header.ContactPerson);
            //base.AddParam(paras,"IN_EstPaymentDate", header.EstPaymentDate);
            base.AddParam(paras, "IN_PaymentDate", header.PaymentDate);
            base.AddParam(paras, "IN_Total", header.Total);
            base.AddParam(paras, "IN_GrandTotal", header.GrandTotal);
            base.AddParam(paras, "IN_Confirmed", header.Confirmed);
            base.AddParam(paras, "IN_Position", header.Position);
            base.AddParam(paras, "IN_MethodVat", header.MethodVat);
            base.AddParam(paras, "IN_Vat", header.Vat);
            base.AddParam(paras, "IN_VatRatio", header.VatRatio);
            base.AddParam(paras, "IN_VatType", header.VatType);
            base.AddParam(paras, "IN_Memo", header.Memo);
            base.AddParam(paras, "IN_IssuedDate", header.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", header.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update delete flag
        /// Create Author: ISV-Giam
        /// Create Date: 2014/09/11
        /// </summary>
        /// <param name="header">T_Purchase_H</param>
        /// <returns></returns>
        public int UpdateForDelete(T_Purchase_H header)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_UpdateForDelete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", header.ID);
            base.AddParam(paras, "IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Flag
        /// </summary>
        /// <param name="accept"></param>
        /// <returns></returns>
        public int UpdateFlag(T_Purchase_H Purchase_H)
        {
            //SQL String
            string cmdText = "P_T_Purchase_H_UpdateFlag_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", Purchase_H.ID);
            base.AddParam(paras, "IN_IssuedFlag", Purchase_H.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", Purchase_H.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", Purchase_H.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

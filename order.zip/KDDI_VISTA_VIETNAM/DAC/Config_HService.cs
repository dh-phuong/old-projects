﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;

namespace OMS.DAC
{
    /// <summary>
    /// Class M_Config_H Service
    /// </summary>
    public class Config_HService: BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of M_Setting_H Service
        /// </summary>
        private Config_HService(): base()
        {
        }

        /// <summary>
        /// Contructor of M_Setting_H Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Config_HService(DB db): base(db)
        {
            
        }

        #endregion

        #region Get Data
        /// <summary>
        /// Create  :isv.thuy
        /// Date    :04/08/2014
        /// Get Default Value DropDownList
        /// </summary>
        /// <param name="configCd">Config Code</param>
        /// <returns></returns>
        public string GetDefaultValueDrop(string configCd)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetDefaultValueDrop_W";
            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCd);            

            return string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
        }

        /// <summary>
        /// Create  :isv.thuy
        /// Date    :04/08/2014
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(string configCd, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetDataForDropDownList_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCd);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// Get Data For DropDownList Without Status = Lost and Sales
        /// ISV-TRUC
        /// </summary>
        /// <param name="configCd">configCd</param>
        /// <param name="withBlank">has blank</param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownListWithoutLostSales(string configCd, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetDataForDropDownListWithoutLostSales_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCd);

            base.AddParam(paras, "IN_StatusFlgLost", Models.StatusFlag.Lost);
            base.AddParam(paras, "IN_StatusFlgSales", Models.StatusFlag.Sales);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", ""));
            }

            return ret;
        }

        /// <summary>
        /// Get List by condition
        /// </summary>
        /// <param name="configCD">Config Code</param>
        /// <param name="configName">Config Name</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="pageSize">Page size</param>
        /// <param name="sortField">Sort Field</param>
        /// <param name="sortDirec">Sort Direction</param>
        /// <returns>List Setting Info</returns>
        public IList<ConfigInfo> GetListByCond(string configCD, string configName,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCD, true);
            base.AddParam(paras, "IN_ConfigName", configName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ConfigInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row for list
        /// </summary>
        /// <param name="configCD">Config Code</param>
        /// <param name="configName">Config Name</param>
        /// <returns></returns>
        public int getTotalRow(string configCD, string configName)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetTotalRow_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCD, true);
            base.AddParam(paras, "IN_ConfigName", configName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public M_Config_H GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_Config_H_GetByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<M_Config_H>(cmdText, paras);
        }

        #endregion

        #region Check data
        /// <summary>
        /// Check exist Config by Config Code
        /// </summary>
        /// <param name="configCode">Config Code</param>
        /// <returns></returns>
        public bool IsExistConfigCode(string configCode)
        {
            //SQL String
            string cmdText = "P_M_Config_H_IsExistConfigCode_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCode);

            int count = int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());

            return count > 0;
        }

        ///// <summary>
        ///// Is Show product search type
        ///// </summary>
        ///// <returns>True: Show, false: not show</returns>
        //public bool IsShowProductSearchType()
        //{
        //    string valL018 = this.GetDefaultValueDrop(M_Config_H.CONFIG_CD_SELL_COST_RELATIVE);
        //    if (valL018.Equals("1"))
        //    {
        //        string valL016 = this.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_SETTING);
        //        if (valL016.Equals("1"))
        //        {
        //            return true;
        //        }
        //    }
        //    return false;
        //}
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="header">M_Config_H</param>
        /// <returns></returns>
        public int Insert(M_Config_H header)
        {
            //SQL String
            string cmdText = "P_M_Config_H_Insert_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ConfigCD", header.ConfigCD);
            base.AddParam(paras,"IN_ConfigName", header.ConfigName);

            base.AddParam(paras,"IN_CreateUID", header.CreateUID);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="header">M_Config_H</param>
        /// <returns></returns>
        public int Update(M_Config_H header)
        {
            //SQL String
            string cmdText = "P_M_Config_H_Update_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", header.ID);
            base.AddParam(paras,"IN_ConfigName", header.ConfigName);

            base.AddParam(paras,"IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Config_H_Delete_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

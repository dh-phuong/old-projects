﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OMS.Models;
using OMS.Utilities;

namespace OMS.DAC
{
    /// <summary>
    /// DeliveryH Service
    /// </summary>
    public class Delivery_HService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Shipping_H service
        /// </summary>        
        private Delivery_HService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Shipping_H service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Delivery_HService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        /// <summary>
        /// Get List By Condition
        /// ISV-TRUC
        /// </summary>
        /// <param name="inputModel">DeliveryHeaderSearch model</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<DeliveryHeaderResult> GetListByCond(DeliveryHeaderSearch inputModel,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeliveryNo", inputModel.DeliveryNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);

            base.AddParam(paras, "IN_DeliveryDateFrom", inputModel.DeliveryDateFrom);
            base.AddParam(paras, "IN_DeliveryDateTo", inputModel.DeliveryDateTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);

            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_DeliveryNm", inputModel.DelivererName, true);
            base.AddParam(paras, "IN_SerialNo", inputModel.SerialNo, true);

            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_Place", inputModel.DeliveryPlace, true);
            base.AddParam(paras, "IN_InvalidFlag", inputModel.InvalidFlag);
            base.AddParam(paras, "IN_FinishFlag", inputModel.FinishFlag);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<DeliveryHeaderResult>(cmdText, paras);
        }


        /// <summary>
        /// Get List By Condition
        /// </summary>
        /// <param name="inputModel">DeliveryHeaderSearch model</param>
        /// <param name="pageIndex">pageIndex</param>
        /// <param name="pageSize">pageSize</param>
        /// <param name="sortField">sortField</param>
        /// <param name="sortDirec">sortDirec</param>
        /// <returns></returns>
        public IList<ContractPeriodResult> GetContractPeriodByCond(ContractPeriodSearch inputModel,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetContractPeriodByCond_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SerialStartDateFrom", inputModel.StartDateFrom);
            base.AddParam(paras, "IN_SerialFinishDateFrom", inputModel.EndDateFrom);
            base.AddParam(paras, "IN_SerialStartDateTo", inputModel.StartDateTo);
            base.AddParam(paras, "IN_SerialFinishDateTo", inputModel.EndDateTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            if (inputModel.ContractType == -1)
            {
                base.AddParam(paras, "IN_ContractType", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ContractType", inputModel.ContractType);
            }
            base.AddParam(paras, "IN_ContractType_WARRANTY",short.Parse( M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY));
            base.AddParam(paras, "IN_ContractType_CD", M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ContractPeriodResult>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row By Condition
        /// </summary>
        /// <param name="inputModel">ContractPeriodSearch Model</param>
        /// <returns>Total row</returns>
        public int GetTotalContractPeriod(ContractPeriodSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetTotalRowContractPeriod_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SerialStartDateFrom", inputModel.StartDateFrom);
            base.AddParam(paras, "IN_SerialFinishDateFrom", inputModel.EndDateFrom);
            base.AddParam(paras, "IN_SerialStartDateTo", inputModel.StartDateTo);
            base.AddParam(paras, "IN_SerialFinishDateTo", inputModel.EndDateTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            if (inputModel.ContractType == -1)
            {
                base.AddParam(paras, "IN_ContractType", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ContractType", inputModel.ContractType);
            }
            base.AddParam(paras, "IN_ContractType_WARRANTY", short.Parse(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY));
            base.AddParam(paras, "IN_ContractType_CD", M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list for Excel
        /// ISV-TRAM
        /// </summary>
        /// <param name="model">DeliveryHeaderSearch model</param>
        /// <returns>DeliveryExcel List</returns>
        public IList<DeliveryExcel> GetListForExcel(DeliveryHeaderSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetListForExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeliveryNo", inputModel.DeliveryNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);

            base.AddParam(paras, "IN_DeliveryDateFrom", inputModel.DeliveryDateFrom);
            base.AddParam(paras, "IN_DeliveryDateTo", inputModel.DeliveryDateTo);
            base.AddParam(paras, "IN_DeliveryNm", inputModel.DelivererName, true);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_SerialNo", inputModel.SerialNo, true);

            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_Place", inputModel.DeliveryPlace, true);
            base.AddParam(paras, "IN_InvalidFlag", inputModel.InvalidFlag);
            base.AddParam(paras, "IN_FinishFlag", inputModel.FinishFlag);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);

            return this.db.FindList<DeliveryExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row By Condition
        /// ISV-TRUC
        /// </summary>
        /// <param name="inputModel">DeliveryHeaderSearch Model</param>
        /// <returns>Total row</returns>
        public int GetTotalRow(DeliveryHeaderSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetTotalRow_W";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeliveryNo", inputModel.DeliveryNo, true);
            base.AddParam(paras, "IN_SalesNo", inputModel.SalesNo, true);
            base.AddParam(paras, "IN_QuoteNo", inputModel.QuoteNo, true);

            base.AddParam(paras, "IN_DeliveryDateFrom", inputModel.DeliveryDateFrom);
            base.AddParam(paras, "IN_DeliveryDateTo", inputModel.DeliveryDateTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);

            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(inputModel.PreparedCD, M_User.USER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_DeliveryNm", inputModel.DelivererName, true);
            base.AddParam(paras, "IN_SerialNo", inputModel.SerialNo, true);
            base.AddParam(paras, "IN_Subject", inputModel.Subject, true);
            base.AddParam(paras, "IN_Place", inputModel.DeliveryPlace, true);
            base.AddParam(paras, "IN_InvalidFlag", inputModel.InvalidFlag);
            base.AddParam(paras, "IN_FinishFlag", inputModel.FinishFlag);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get Shipping_H By ID
        /// ISV-TRUC
        /// </summary>
        /// <param name="id">id of Shipping_H</param>
        /// <returns></returns>
        public T_Delivery_H GetByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetByID_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<T_Delivery_H>(cmdText, paras);
        }

        /// <summary>
        /// Get DeliveryPlace By AcceptNo
        /// ISV-GIAM
        /// </summary>
        /// <param name="acceptNo">AcceptNo</param>
        /// <returns></returns>
        public string GetDeliveryPlaceBySalesNo(string salesNo)
        {
            //SQL String
            string cmdText = "dbo.P_T_Delivery_H_GetDeliveryPlaceBySalesNo_W";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalesNo", salesNo);

            return string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
        }

        /// <summary>
        /// Get current shipping No
        /// </summary>
        /// <returns></returns>
        public int GetCurrentDeliveryNo()
        {
            string cmdText = "P_T_Delivery_H_GetCurrentDeliveryNo_W";
            return int.Parse(this.db.ExecuteScalar(cmdText).ToString());
        }

        /// <summary>
        /// Check Shipping No is overflow
        /// </summary>
        /// <returns></returns>
        public bool IsDeliveryNoOverflow()
        {
            int currNo = this.GetCurrentDeliveryNo();
            return currNo > OMS.Utilities.Constants.MAX_NO - 1;
        }

        /// <summary>
        /// ContractPeriodExcel
        /// Create Author: ISV-NGUYEN
        /// Create Date: 2015/02/04
        /// </summary>
        /// <param name="inputModel">ContractPeriodSearch</param>
        /// <returns>IList<CreateDeliveryExcel></returns>
        public IList<ContractPeriodExcel> GetListForContractPeriodExcel(ContractPeriodSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetListForContractPeriodExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SerialStartDateFrom", inputModel.StartDateFrom);
            base.AddParam(paras, "IN_SerialFinishDateFrom", inputModel.EndDateFrom);
            base.AddParam(paras, "IN_SerialStartDateTo", inputModel.StartDateTo);
            base.AddParam(paras, "IN_SerialFinishDateTo", inputModel.EndDateTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(inputModel.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            if (inputModel.ContractType == -1)
            {
                base.AddParam(paras, "IN_ContractType", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ContractType", inputModel.ContractType);
            }
            base.AddParam(paras, "IN_ContractType_WARRANTY", short.Parse(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY));
            base.AddParam(paras, "IN_ContractType_CD", M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);

            return this.db.FindList<ContractPeriodExcel>(cmdText, paras);
        }

        /// <summary>
        /// GetListForExcel
        /// Create Author: ISV-NGUYEN
        /// Create Date: 2015/02/04
        /// </summary>
        /// <param name="deliveryDateFrom">deliveryDateFrom</param>
        /// <param name="deliveryDateTo">deliveryDateTo</param>
        /// <returns>IList<CreateDeliveryExcel></returns>
        public IList<CreateDeliveryExcel> GetListForCreateDeliveryListExcel(DateTime? deliveryDateFrom, DateTime? deliveryDateTo)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetListForCreateDeliveryListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeliveryDateFrom", deliveryDateFrom);
            base.AddParam(paras, "IN_DeliveryDateTo", deliveryDateTo);
            base.AddParam(paras, "IN_MethodVat", M_Config_H.CONFIG_CD_METHOD_VAT);

            return this.db.FindList<CreateDeliveryExcel>(cmdText, paras);
        }

        /// <summary>
        /// Get List For UnCreate Delivery List Excel
        /// Create Author: ISV-GIAM
        /// Create Date: 2015/02/05
        /// </summary>
        /// <param name="deliveryDateFrom">deliveryDateFrom</param>
        /// <param name="deliveryDateTo">deliveryDateTo</param>
        /// <returns>IList<PurchaseExcel></returns>
        public IList<UncreateDeliveryExcel> GetListForUnCreateDeliveryListExcel(DateTime? deliveryDateFrom, DateTime? deliveryDateTo)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetListForUnCreateDeliveryListExcel_W";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeliveryDateFrom", deliveryDateFrom);
            base.AddParam(paras, "IN_DeliveryDateTo", deliveryDateTo);

            return this.db.FindList<UncreateDeliveryExcel>(cmdText, paras);
        }

        /// <summary>
        /// Gets the item count item for search.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        public int GetSellCountForSearch(DeliveryProductSearchModel input)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetItemCountForSearch";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_DeliveryDateFrm", input.DeliveryDateFrm);
            base.AddParam(paras, "IN_DeliveryDateTo", input.DeliveryDateTo);

            if (input.CategoryID1 < 0)
                base.AddParam(paras, "IN_CategoryID1", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID1", input.CategoryID1);

            if (input.CategoryID2 < 0)
                base.AddParam(paras, "IN_CategoryID2", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID2", input.CategoryID2);

            if (input.CategoryID3 < 0)
                base.AddParam(paras, "IN_CategoryID3", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID3", input.CategoryID3);

            base.AddParam(paras, "IN_ProductCD", input.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", input.ProductName, true);
            base.AddParam(paras, "IN_Description", input.Description, true);
            base.AddParam(paras, "IN_UnitPriceFrm", input.UnitPriceFrm);
            base.AddParam(paras, "IN_UnitPriceTo", input.UnitPriceTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(input.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", input.CustomerName, true);

            if (input.CurrencyID < 0)
            {

                base.AddParam(paras, "IN_CurrencyID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_CurrencyID", input.CurrencyID);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Gets the item item for search.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <returns></returns>
        public IList<DeliveryProductSearchResult> GetSellItemForSearch(DeliveryProductSearchModel input)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_GetItemForSearch";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_DeliveryDateFrm", input.DeliveryDateFrm);
            base.AddParam(paras, "IN_DeliveryDateTo", input.DeliveryDateTo);
            if (input.CategoryID1 < 0)
                base.AddParam(paras, "IN_CategoryID1", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID1", input.CategoryID1);

            if (input.CategoryID2 < 0)
                base.AddParam(paras, "IN_CategoryID2", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID2", input.CategoryID2);

            if (input.CategoryID3 < 0)
                base.AddParam(paras, "IN_CategoryID3", DBNull.Value);
            else
                base.AddParam(paras, "IN_CategoryID3", input.CategoryID3);
            base.AddParam(paras, "IN_ProductCD", input.ProductCD, true);
            base.AddParam(paras, "IN_ProductName", input.ProductName, true);
            base.AddParam(paras, "IN_Description", input.Description, true);

            base.AddParam(paras, "IN_UnitPriceFrm", input.UnitPriceFrm);
            base.AddParam(paras, "IN_UnitPriceTo", input.UnitPriceTo);

            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(input.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH), true);
            base.AddParam(paras, "IN_CustomerName", input.CustomerName, true);
            if (input.CurrencyID < 0)
            {

                base.AddParam(paras, "IN_CurrencyID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_CurrencyID", input.CurrencyID);
            }

            base.AddParam(paras, "IN_PageIndex", input.PageIndex);
            base.AddParam(paras, "IN_PageSize", input.PageSize);
            base.AddParam(paras, "IN_SortField", input.SortField);
            base.AddParam(paras, "IN_SortDirec", input.SortDirec);

            return this.db.FindList<DeliveryProductSearchResult>(cmdText, paras);
        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <param name="deliveryH"></param>
        /// <returns></returns>
        public int Insert(T_Delivery_H deliveryH)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_Insert_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_DeliveryNo", deliveryH.DeliveryNo);
            base.AddParam(paras, "IN_QuoteNo", deliveryH.QuoteNo);
            base.AddParam(paras, "IN_SalesNo", deliveryH.SalesNo);
            base.AddParam(paras, "IN_DeliveryPlace", deliveryH.DeliveryPlace);
            base.AddParam(paras, "IN_IssuedFlag", deliveryH.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", deliveryH.DeleteFlag);
            base.AddParam(paras, "IN_FinishFlag", deliveryH.FinishFlag);
            base.AddParam(paras, "IN_CurrencyID", deliveryH.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", deliveryH.MethodVat);
            base.AddParam(paras, "IN_DeliveryDate", deliveryH.DeliveryDate);
            base.AddParam(paras, "IN_ExpiryDate", deliveryH.ExpiryDate);
            base.AddParam(paras, "IN_SubjectName", deliveryH.SubjectName);
            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(deliveryH.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", deliveryH.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", EditDataUtil.ToFixCodeDB(deliveryH.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", deliveryH.ApprovedName);
            base.AddParam(paras, "IN_DelivererName", deliveryH.DelivererName);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(deliveryH.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCD_SP", EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", deliveryH.CustomerName);
            base.AddParam(paras, "IN_CustomerAddress1", deliveryH.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", deliveryH.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", deliveryH.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", deliveryH.Tel);
            base.AddParam(paras, "IN_Fax", deliveryH.Fax);
            base.AddParam(paras, "IN_ContactPerson", deliveryH.ContactPerson);
            base.AddParam(paras, "IN_Total", deliveryH.Total);
            base.AddParam(paras, "IN_GrandTotal", deliveryH.GrandTotal);
            base.AddParam(paras, "IN_VAT", deliveryH.VAT);
            base.AddParam(paras, "IN_VatRatio", deliveryH.VatRatio);
            base.AddParam(paras, "IN_VatType", deliveryH.VatType);
            base.AddParam(paras, "IN_Memo", deliveryH.Memo);
            base.AddParam(paras, "IN_AcceptanceNo", deliveryH.AcceptanceNo);
            base.AddParam(paras, "IN_AcceptanceDate", deliveryH.AcceptanceDate);
            base.AddParam(paras, "IN_Confirmed", deliveryH.Confirmed);
            base.AddParam(paras, "IN_Position", deliveryH.Position);
            base.AddParam(paras, "IN_IssuedDate", deliveryH.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", deliveryH.IssuedUID);
            base.AddParam(paras, "IN_CreateUID", deliveryH.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", deliveryH.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return db.GetIdentityId<T_Delivery_H>();
            }
            return 0;
        }


        #endregion

        #region Update

        /// <summary>
        /// Update Data
        /// </summary>
        /// <param name="deliveryH"></param>
        /// <returns></returns>
        public int Update(T_Delivery_H deliveryH)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_Update_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", deliveryH.ID);
            base.AddParam(paras, "IN_DeliveryNo", deliveryH.DeliveryNo);
            base.AddParam(paras, "IN_QuoteNo", deliveryH.QuoteNo);
            base.AddParam(paras, "IN_SalesNo", deliveryH.SalesNo);
            base.AddParam(paras, "IN_DeliveryPlace", deliveryH.DeliveryPlace);
            base.AddParam(paras, "IN_IssuedFlag", deliveryH.IssuedFlag);
            base.AddParam(paras, "IN_DeleteFlag", deliveryH.DeleteFlag);
            base.AddParam(paras, "IN_FinishFlag", deliveryH.FinishFlag);
            base.AddParam(paras, "IN_CurrencyID", deliveryH.CurrencyID);
            base.AddParam(paras, "IN_MethodVat", deliveryH.MethodVat);
            base.AddParam(paras, "IN_DeliveryDate", deliveryH.DeliveryDate);
            base.AddParam(paras, "IN_ExpiryDate", deliveryH.ExpiryDate);
            base.AddParam(paras, "IN_SubjectName", deliveryH.SubjectName);

            base.AddParam(paras, "IN_PreparedCD", EditDataUtil.ToFixCodeDB(deliveryH.PreparedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_PreparedName", deliveryH.PreparedName);
            base.AddParam(paras, "IN_ApprovedCD", EditDataUtil.ToFixCodeDB(deliveryH.ApprovedCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_ApprovedName", deliveryH.ApprovedName);
            base.AddParam(paras, "IN_DelivererName", deliveryH.DelivererName);
            base.AddParam(paras, "IN_CustomerCD", EditDataUtil.ToFixCodeDB(deliveryH.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerCD_SP", EditDataUtil.ToFixCodeDB(M_Customer.CUSTOMER_CODE_SUPPORT, M_Customer.CUSTOMER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_CustomerName", deliveryH.CustomerName);
            base.AddParam(paras, "IN_CustomerAddress1", deliveryH.CustomerAddress1);
            base.AddParam(paras, "IN_CustomerAddress2", deliveryH.CustomerAddress2);
            base.AddParam(paras, "IN_CustomerAddress3", deliveryH.CustomerAddress3);
            base.AddParam(paras, "IN_Tel", deliveryH.Tel);
            base.AddParam(paras, "IN_Fax", deliveryH.Fax);
            base.AddParam(paras, "IN_ContactPerson", deliveryH.ContactPerson);
            base.AddParam(paras, "IN_Total", deliveryH.Total);
            base.AddParam(paras, "IN_GrandTotal", deliveryH.GrandTotal);
            base.AddParam(paras, "IN_VAT", deliveryH.VAT);
            base.AddParam(paras, "IN_VatRatio", deliveryH.VatRatio);
            base.AddParam(paras, "IN_VatType", deliveryH.VatType);
            base.AddParam(paras, "IN_Memo", deliveryH.Memo);
            base.AddParam(paras, "IN_AcceptanceNo", deliveryH.AcceptanceNo);
            base.AddParam(paras, "IN_AcceptanceDate", deliveryH.AcceptanceDate);
            base.AddParam(paras, "IN_Confirmed", deliveryH.Confirmed);
            base.AddParam(paras, "IN_Position", deliveryH.Position);

            base.AddParam(paras, "IN_IssuedDate", deliveryH.IssuedDate);
            base.AddParam(paras, "IN_IssuedUID", deliveryH.IssuedUID);

            base.AddParam(paras, "IN_UpdateDate", deliveryH.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", deliveryH.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Flag
        /// </summary>
        /// <param name="accept"></param>
        /// <returns></returns>
        public int UpdateIssueFlag(T_Delivery_H item)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_UpdateIssueFlag_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", item.ID);
            base.AddParam(paras, "IN_IssuedFlag", item.IssuedFlag);
            base.AddParam(paras, "IN_IssuedUID", item.IssuedUID);
            base.AddParam(paras, "IN_UpdateDate", item.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Finish Flag
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public int UpdateFinishFlag(T_Delivery_H item)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_UpdateFinishFlag_W";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", item.ID);
            base.AddParam(paras, "IN_FinishFlag", item.FinishFlag);
            base.AddParam(paras, "IN_UpdateUID", item.UpdateUID);
            base.AddParam(paras, "IN_UpdateDate", item.UpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="updateDate">updateDate</param>
        /// <param name="updateUID">updateUID</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate, int updateUID)
        {
            //SQL String
            string cmdText = "P_T_Delivery_H_UpdateForDelete_W";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            base.AddParam(paras, "IN_UpdateUID", updateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

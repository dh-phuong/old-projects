﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.Utilities;
using OMS.Controls;
using System.Web.UI.HtmlControls;
using System.Collections;
using OMS.DAC;
using System.Data.SqlClient;
using OMS.Reports.PDF;
using Microsoft.Reporting.WebForms;

namespace OMS.Billing
{
    /// <summary>
    /// Billing Detail
    /// Author:ISV-NGUYEN 
    /// </summary>
    public partial class FrmBillingDetail : FrmBaseDetail
    {
        #region Constants

        private DateTime DATE_TIME_DEFAULT = new DateTime(1900, 1, 1);
        private const string LIST_PAGE = "FrmBillingList.aspx";
        private const string PDF_BILLING_DOWNLOAD = "Billing_{0}.pdf";
        private const string FMT_YMDHMM = "yyMMddHHmm";

        #endregion

        #region Variable

        /// <summary>
        /// Currency list
        /// </summary>
        private IList<DropDownModel> currencyList;

        /// <summary>
        /// Payment Method
        /// </summary>
        private IList<DropDownModel> paymentMethod;

        /// <summary>
        /// Payment Method
        /// </summary>
        private IList<DropDownModel> paymentMethodDeposit;

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string defaultPaymentMethod;

        /// <summary>
        /// MethodVatList
        /// </summary>
        private IList<DropDownModel> methodVatList;
        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string defaultMethodVat;

        /// <summary>
        /// FractionType
        /// </summary>
        private FractionType _fractionType;

        /// <summary>
        /// UnitList
        /// </summary>
        private IList<DropDownModel> unitList;

        /// <summary>
        /// VatTypeList
        /// </summary>
        private IList<DropDownModel> vatTypeList;

        /// <summary>
        /// VatTypeListEmpty
        /// </summary>
        private IList<DropDownModel> vatTypeListEmpty = new List<DropDownModel>();

        /// <summary>
        /// DefaultVatType
        /// </summary>
        private string defaultVatType;

        /// <summary>
        /// Index Sell
        /// </summary>
        private int index;

        /// <summary>
        /// DefaultProfit
        /// </summary>
        private string _defaultProfit;

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Product CD Used
        /// </summary>
        public int _productCDUsed;

        #endregion

        #region Property
        /// <summary>
        /// Get or set BillingID
        /// </summary>
        public int BillingID
        {
            get { return base.GetValueViewState<int>("BillingID"); }
            set { ViewState["BillingID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldUpdateDate"); }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set DefaultVAT
        /// </summary>
        public string DefaultVAT
        {
            get { return base.GetValueViewState<string>("DefaultVAT"); }
            private set { ViewState["DefaultVAT"] = value; }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return base.GetValueViewState<int>("QuantityDecimal"); }
            private set { ViewState["QuantityDecimal"] = value; }
        }

        /// <summary>
        /// FileAttachedCount
        /// </summary>
        public int FileAttachedCount
        {
            get { return base.GetValueViewState<int>("FileAttachedCount"); }
            private set { ViewState["FileAttachedCount"] = value; }
        }

        /// <summary>
        /// MethodVATEach Use for AJAX
        /// </summary>
        public string MethodVATEach
        {
            get { return M_Config_D.METHOD_VAT_EACH; }
        }

        /// <summary>
        /// Condition
        /// </summary>
        private string OldCondition
        {
            get { return base.GetValueViewState<string>("oldCondition"); }
            set { ViewState["oldCondition"] = value; }
        }

        /// <summary>
        ///RemoveSeletedRow
        /// </summary>
        private bool RemoveSeletedRow
        {
            get { return base.GetValueViewState<bool>("RemoveSeletedRow"); }
            set { ViewState["RemoveSeletedRow"] = value; }
        }

        /// <summary>
        /// DataIssuing
        /// </summary>
        private bool DataIssuing
        {
            get { return base.GetValueViewState<bool>("DataIssuing"); }
            set { ViewState["DataIssuing"] = value; }
        }

        ///// <summary>
        ///// DataInvoice
        ///// </summary>
        //private bool DataInvoice
        //{
        //    get { return base.GetValueViewState<bool>("DataInvoice"); }
        //    set { ViewState["DataInvoice"] = value; }
        //}

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public bool DeleteFlag
        {
            get { return base.GetValueViewState<bool>("DeleteFlag"); }
            private set { ViewState["DeleteFlag"] = value; }
        }

        /// <summary>
        /// FinishFlag
        /// </summary>
        public bool FinishFlag
        {
            get { return base.GetValueViewState<bool>("FinishFlag"); }
            private set { ViewState["FinishFlag"] = value; }
        }

        /// <summary>
        /// CheckFlag
        /// </summary>
        public bool CheckFlag
        {
            get { return base.GetValueViewState<bool>("CheckFlag"); }
            private set { ViewState["CheckFlag"] = value; }
        }

        /// <summary>
        /// Get or set VersionUpdateDate
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldVersionUpdateDate"); }
            set { ViewState["OldVersionUpdateDate"] = value; }
        }

        /// <summary>
        /// IsReferenced
        /// </summary>
        public bool IsReferenced
        {
            get { return base.GetValueViewState<bool>("IsReferenced"); }
            private set { ViewState["IsReferenced"] = value; }
        }

        /// <summary>
        /// ProductCDUsed
        /// </summary>
        public bool ProductCDUsed
        {
            get
            {
                return this._productCDUsed == int.Parse(M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON);
            }
        }

        /// <summary>
        /// DescriptionRow
        /// </summary>
        public int DescriptionRow
        {
            get
            {
                if (this.ProductCDUsed)
                {
                    return 4;
                }
                else
                {
                    return 6;
                }
            }
        }

        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e">EventArgs</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Billing";
            base.FormSubTitle = "";

            //Init Max Length
            this.txtAttn.MaxLength = M_Customer.CONTACT_PERSON_MAX_LENGTH;
            this.txtAdd1.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd2.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd3.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtTel.MaxLength = M_Customer.TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Customer.FAX_MAX_LENGTH;
            this.txtSubject.MaxLength = T_Billing_H.SUBJECT_NAME_MAX_LENGTH;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtApprovedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtMemo.MaxLength = T_Billing_H.MEMO_MAX_LENGTH;
            this.txtContractNo.MaxLength = T_Billing_H.CONTRACT_NO_MAX_LENGTH;

            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditions.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadPDF_Click);

            //Back
            this.btnBackView.Click += new EventHandler(btnBackView_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Bill);
            if (!base._authority.IsBillingView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Get Default Data
            this.GetDefaultDataDropDownList();

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_BILLING_LIST;
            }

            if (!base.IsPostBack)
            {
                this.RemoveSeletedRow = false;

                this.CheckFlag = false;

                //Init DropDownList currency list
                this.InitDropDownListData(this.cmbCurrency, this.currencyList);

                //Init DropDownList MethodVatList
                this.InitDropDownListData(this.cmbMethodVat, this.methodVatList);
                this.InitDropDownListData(this.cmbPaymentMethod, this.paymentMethod);
                this.hdnFractionType.Value = ((int)this._fractionType).ToString();

                if (base.PreviousPage != null)
                {
                    //Save Info
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        //Save URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        //Check para
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get Billing ID
                            this.BillingID = int.Parse(para["ID"].ToString());
                            var header = this.GetBilling(this.BillingID);
                            if (header != null)
                            {
                                //Show data
                                this.ShowHeaderData(header);

                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                base.RedirectUrl(FrmBase.URL_BILLING_LIST);
                            }
                        }
                        else
                        {
                            base.RedirectUrl(FrmBase.URL_BILLING_LIST);
                        }
                    }
                    else
                    {
                        base.RedirectUrl(FrmBase.URL_BILLING_LIST);
                    }
                }
                else
                {
                    base.RedirectUrl(FrmBase.URL_BILLING_LIST);
                }
            }

            //Set Back URL
            this.btnBackView.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            this.CheckFlag = false;
            //Get info by ID
            T_Billing_H billing = this.GetBilling(this.BillingID);

            //Check Billing
            if (billing != null)
            {
                var isOk = true;
                if (billing.UpdateDate != this.OldUpdateDate)
                {
                    //this.FocusControlId = this.btnCheck.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.ShowHeaderData(billing);

                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                    this.FocusControlId = this.txtAttn.ClientID;
                }
            }
            else
            {
                Server.Transfer(LIST_PAGE);
            }
        }

        /// <summary>
        /// Event Check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCheck_Click(object sender, EventArgs e)
        {
            this.CheckFlag = true;

            var header = this.GetBilling(this.BillingID);

            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.ShowHeaderData(header);
                using (DB db = new DB())
                {
                    Deposit_Service deposit_Service = new Deposit_Service(db);

                    var listDepositInfo = deposit_Service.GetListByID(header.ID);
                    if (listDepositInfo == null || listDepositInfo.Count == 0)
                    {
                        listDepositInfo = new List<T_Deposit>();
                        listDepositInfo.Add(new T_Deposit()
                        {
                            PaymentMethod = 255
                        });
                    }
                    //Reset datasource
                    this.rptListDeposit.DataSource = listDepositInfo;
                    this.rptListDeposit.DataBind();
                }
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Check);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_BILLING_LIST);
            }
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Billing_H billing = this.GetBilling(this.BillingID);

            //Check Billing
            if (billing != null)
            {
                var isOk = true;
                if (billing.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    this.ShowHeaderData(billing);
                    isOk = false;
                }
                T_Sales_H salesH = null;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    salesH = sales_HService.GetBySalesNo(billing.SalesNo);
                }

                if (salesH != null)
                {
                    if (salesH.VersionUpdateDate <= this.OldVersionUpdateDate)
                    {
                        //Show data
                        this.ShowHeaderData(billing);
                    }
                }
                else
                {
                    //Show data
                    this.ShowHeaderData(billing);
                }

                if (isOk)
                {
                    //Set Model
                    this.Mode = Mode.Delete;

                    //Show question delete
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
                }
            }
        }

        /// <summary>
        /// Event Isssue
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnIssue_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Billing_H billing = this.GetBilling(this.BillingID);

            //Check Billing
            if (billing != null)
            {
                var isOk = true;
                if (billing.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.ShowHeaderData(billing);

                if (isOk)
                {
                //    if (e.CommandArgument.ToString().Equals("Invoice"))
                //    {
                //        this.DataInvoice = true;
                //    }
                //    else
                //    {
                //        this.DataInvoice = false;
                //    }
                    this.DataIssuing = true;

                    if (billing.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, false, "PDF");
                    }
                }
            }
            else
            {
                Server.Transfer(LIST_PAGE);
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    var fileName = string.Format("{0}.pdf", this.txtBillingNo.Value);
                    Response.ContentType = "application/pdf";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                    Response.Flush(); // send it to the client to download
                }
            }
        }

        /// <summary>
        /// Event Update
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Mode normal
            if (this.Mode != Mode.View)
            {
                if (this.Mode == Mode.View)
                {
                    Server.Transfer(LIST_PAGE);
                }
                else if (this.Mode == Mode.Update || this.Mode == Mode.Check)
                {
                    //Get info by ID
                    T_Billing_H billing = this.GetBilling(this.BillingID);

                    //Check Billing
                    if (billing != null)
                    {
                        //Show data
                        this.ShowHeaderData(billing);

                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(LIST_PAGE);
                    }
                }
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBackView_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret = false;
            T_Billing_H billingH = null;

            this.SetConfirmData();

            if (this.RemoveSeletedRow)
            {
                //Get new list from screen
                var listDetail = this.GetDetailList();

                //Get list index remove item
                List<int> listDel = new List<int>();
                for (int i = listDetail.Count - 1; i >= 0; i--)
                {
                    if (listDetail[i].DelFlag)
                    {
                        listDel.Add(i);
                    }

                    listDetail[i].DelFlag = false;
                }

                //Remove row
                foreach (var item in listDel)
                {
                    listDetail.RemoveAt(item);
                }

                this.rptListDeposit.DataSource = listDetail;
                this.rptListDeposit.DataBind();
                this.RemoveSeletedRow = false;
                if (listDetail.Count == 0)
                {
                    this.FocusControlId = "btnAddRow";
                }
                else
                {
                    this.FocusControlId = "dtDepositDate_0";
                }

                this.SetConfirmData();
            }
            else
            {
                //Check Mode
                switch (this.Mode)
                {
                    case Utilities.Mode.Update:
                    case Utilities.Mode.Check:
                        //Update Data
                        ret = this.UpdateData();
                        break;

                    case Utilities.Mode.Delete:
                        //Delete Data
                        ret = this.DeleteData();
                        if (!ret)
                        {
                            this.ProcessMode(Mode.View);
                        }
                        break;

                    default:
                        if (this.DataIssuing)
                        {
                            BillingPDF billing = new BillingPDF();
                            billing.LoginInfo = this.LoginInfo;
                            //billing.InvoiceFlag = this.DataInvoice;
                            var uniqueFileName = string.Format(PDF_BILLING_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                            this.ExportPDF(billing.GetLocalReport(new LocalReport(), this.BillingID, this.OldUpdateDate), uniqueFileName, true);
                            //Get info by ID
                            billingH = this.GetBilling(this.BillingID);

                            //Show data
                            this.ShowHeaderData(billingH);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(FrmBase.URL_BILLING_DETAIL);
                        }
                        break;
                }

                if (ret)
                {
                    //Get info by ID
                    billingH = this.GetBilling(this.BillingID);

                    //Show data
                    this.ShowHeaderData(billingH);

                    //Set Mode
                    this.ProcessMode(Mode.View);

                    //Set Success
                    this.Success = true;
                }
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get info by ID
            var billingH = this.GetBilling(this.BillingID);
            //Delete row
            if (this.RemoveSeletedRow)
            {
                this.SetConfirmData();
                this.RemoveSeletedRow = false;
                return;
            }
            if (billingH != null)
            {
                //Show data
                this.ShowHeaderData(billingH);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(LIST_PAGE);
            }
        }

        /// <summary>
        /// Up row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnUp_Click(object sender, EventArgs e)
        {
            //Get Data
            IList<BillingDetailInfo> listDetail = this.GetData();

            //List empty return
            if (listDetail.Count == 0)
            {
                return;
            }

            //Process up
            IList<BillingDetailInfo> listUp = this.ProcessUpDown(true, listDetail);

            //Set data source
            this.rptDetail.DataSource = listUp;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Down row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDown_Click(object sender, EventArgs e)
        {
            //Get Data
            IList<BillingDetailInfo> listDetail = this.GetData();

            //List empty return
            if (listDetail.Count == 0)
            {
                return;
            }

            //Process up
            IList<BillingDetailInfo> listDown = this.ProcessUpDown(false, listDetail);

            //Set data source
            this.rptDetail.DataSource = listDown;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Event Button AddRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            //Get new list from screen
            var listDetail = this.GetDetailList();
            if (listDetail != null)
            {
                listDetail.Add(new T_Deposit()
                {
                    PaymentMethod = 255
                });
            }

            //Process list view
            this.rptListDeposit.DataSource = listDetail;
            this.rptListDeposit.DataBind();

            //Find control focus
            var dtDepositDate = this.rptListDeposit.Items[this.index].FindControl("dtDepositDate");
            if (dtDepositDate != null)
            {
                this.FocusControlId = dtDepositDate.ClientID;
            }

            this.SetConfirmData();
        }

        /// <summary>
        /// Event Button RemoveRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveRow_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            this.RemoveSeletedRow = true;

            //Show question delete row
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnReferenceYes_Click(object sender, CommandEventArgs e)
        {
            T_Billing_H billing = this.GetBilling(this.BillingID);
            if (billing != null)
            {
                //if (billing.UpdateDate != this.OldUpdateDate)
                //{
                //    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);

                //    //Reload data
                //    this.ShowHeaderData(billing);
                //    return;
                //}

                //Process reference parameter
                Hashtable currentPage = new Hashtable();
                currentPage.Add("ID", billing.ID);

                Hashtable nextPage = new Hashtable();
                nextPage.Add("FinishedFlag", M_Config_D.DATA_INCLUDE);
                nextPage.Add("DeletedFlag", M_Config_D.DATA_INCLUDE);

                if (!this.txtQuotationNo.IsEmpty)
                {
                    nextPage.Add("txtQuoteNo", this.txtQuotationNo.Value);
                    nextPage.Add("QuoteNoReadOnly", true);
                }

                if (!this.txtSalesNo.IsEmpty)
                {
                    nextPage.Add("txtSalesNo", this.txtSalesNo.Value);
                    nextPage.Add("SalesNoReadOnly", true);
                }

                var formId = e.CommandArgument;
                if (string.Equals(formId, "Quotation"))
                {
                    if (!this.txtQuotationNo.IsEmpty)
                    {
                        nextPage.Add("SalesData", M_Config_D.DATA_INCLUDE);
                    }
                }

                base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_BILLING_DETAIL);
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_BILLING_LIST);
            }
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDeposit_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                T_Deposit data = (T_Deposit)e.Item.DataItem;

                //Find Control
                IDateTextBox dtDepositDate = (IDateTextBox)e.Item.FindControl("dtDepositDate");
                INumberTextBox txtAmount = (INumberTextBox)e.Item.FindControl("txtAmount");
                DropDownList cmbPaymentMethodDeposit = (DropDownList)e.Item.FindControl("cmbPaymentMethodDeposit");
                HiddenField hdnDepositMethod = (HiddenField)e.Item.FindControl("hdnDepositMethod");

                ITextBox txtRemark1 = (ITextBox)e.Item.FindControl("txtRemark1");
                ITextBox txtRemark2 = (ITextBox)e.Item.FindControl("txtRemark2");

                this.cmbCurrency.SelectedValue = this.hdnCmbCurrency.Value;
                this.SetDecimalDigit(this.cmbCurrency, txtAmount, Constant.MAX_SUB_AMOUNT_DECIMAL, Constant.MAX_SUB_AMOUNT_NOT_DECIMAL);

                //Set maxlenght
                txtRemark1.MaxLength = T_Billing_H.REMARK_MAX_LENGTH;
                txtRemark2.MaxLength = T_Billing_H.REMARK_MAX_LENGTH;

                ////---------End Change sell unit price max,min, digit-------------//

                var param = string.Format("'{0}'",
                                                txtAmount.ClientID);

                txtAmount.Attributes.Add("onvaluechange", string.Format("calcAmountSell({0})", param));

                //txtAmount.Attributes.Add("onvaluechange", "calcAmountSell();");


                this.InitDropDownListData(cmbPaymentMethodDeposit, this.paymentMethodDeposit);
                cmbPaymentMethodDeposit.SelectedValue = data.PaymentMethod.ToString();
                hdnDepositMethod.Value = data.PaymentMethod.ToString();

                var billing = this.GetBilling(this.BillingID);
                if (billing != null)
                {
                    this.cmbMethodVat.SelectedValue = billing.MethodVat.ToString();
                    this.cmbCurrency.SelectedValue = billing.CurrencyID.ToString();
                }
            }
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                BillingDetailInfo data = (BillingDetailInfo)e.Item.DataItem;

                //Find Control
                INumberTextBox txtSellPrice = (INumberTextBox)e.Item.FindControl("txtSellPrice");
                ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtSellDescription");
                INumberTextBox txtSellTotal = (INumberTextBox)e.Item.FindControl("txtSellTotal");
                INumberTextBox txtSellVat = (INumberTextBox)e.Item.FindControl("txtSellVat");
                INumberTextBox txtSellQuantity = (INumberTextBox)e.Item.FindControl("txtSellQuantity");
                INumberTextBox txtSellVatRatio = (INumberTextBox)e.Item.FindControl("txtSellVatRatio");
                DropDownList cmbSellVatType = (DropDownList)e.Item.FindControl("cmbSellVatType");
                DropDownList cmbSellUnit = (DropDownList)e.Item.FindControl("cmbSellUnit");
                HiddenField hidInternalID = (HiddenField)e.Item.FindControl("hidInternalID");
                ITextBox txtSellRemark = (ITextBox)e.Item.FindControl("txtSellRemark");

                txtSellRemark.MaxLength = T_Billing_H.REMARK_MAX_LENGTH;

                //---------Set maxlength-------------------//
                txtSellDescription.MaxLength = T_Billing_H.DESCRIPTION_MAX_LENGTH;

                //---------End Set maxlength-------------------//

                //---------Change sell unit price max,min, digit------------------//
                this.cmbCurrency.SelectedValue = this.hdnCmbCurrency.Value;
                this.SetDecimalDigit(this.cmbCurrency, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                this.SetDecimalDigit(this.cmbCurrency, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(this.cmbCurrency, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                txtSellQuantity.DecimalDigit = this.QuantityDecimal;
                txtSellQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtSellQuantity.MinimumValue = 0;
                //---------End Change sell unit price max,min, digit-------------//

                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                                       cmbSellVatType.ClientID,
                                                                                       txtSellPrice.ClientID,
                                                                                       txtSellQuantity.ClientID,
                                                                                       txtSellTotal.ClientID,
                                                                                       txtSellVat.ClientID,
                                                                                       txtSellVatRatio.ClientID);

                txtSellPrice.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellPrice.ClientID, param));
                txtSellQuantity.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellQuantity.ClientID, param));
                txtSellTotal.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellTotal.ClientID, param));
                txtSellVatRatio.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellVatRatio.ClientID, param));

                txtSellVat.Attributes.Add("onvaluechange", "calcTotalSell();");
                //VatType
                this.InitDropDownListData(cmbSellUnit, this.unitList);
                if (this.CheckFlag)
                {
                    cmbSellUnit.SelectedValue = this.GetBillingD(int.Parse(hidInternalID.Value)).UnitID.ToString();
                }
                else
                {
                    cmbSellUnit.SelectedValue = data.UnitID.ToString();
                }
                var billing = this.GetBilling(this.BillingID);
                if (billing != null)
                {
                    this.cmbMethodVat.SelectedValue = billing.MethodVat.ToString();
                    this.cmbCurrency.SelectedValue = billing.CurrencyID.ToString();
                }
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
                {
                    //VatType
                    this.InitDropDownListData(cmbSellVatType, this.vatTypeList);
                    cmbSellVatType.SelectedValue = data.VATType.ToString();
                    txtSellVat.Enabled = true;
                    if (cmbSellVatType.SelectedItem != null)
                    {
                        if (Convert.ToInt32(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {

                            txtSellVat.Value = data.Vat;
                            txtSellVatRatio.Value = data.VatRatio.HasValue ? data.VatRatio.Value : decimal.Parse(this.DefaultVAT);
                        }
                        else
                        {
                            txtSellVat.ReadOnly = true;
                            txtSellVat.Value = null;
                            txtSellVatRatio.Value = null;
                        }
                    }
                }
                else//for total
                {
                    txtSellVat.Enabled = false;
                    //SellVat
                    txtSellVat.Value = null;

                    //SellVatRatio
                    txtSellVatRatio.Value = null;

                    //VatType
                    this.InitDropDownListData(cmbSellVatType, this.vatTypeListEmpty);
                }

                cmbSellVatType.Attributes.Add("disabled", "true");
            }
        }

        /// <summary>
        /// Get list by date
        /// </summary>
        /// <returns></returns>
        private Hashtable GetListByDate()
        {
            Hashtable ret = new Hashtable();
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);
                var list = currency_HService.GetAllByDate(this.txtBillingDate.Value.HasValue ? this.txtBillingDate.Value.Value : DateTime.Now);
                foreach (var item in list)
                {
                    ret.Add(item.HID, item);
                }
            }
            return ret;
        }

        /// <summary>
        /// Get user name
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(OMS.Utilities.EditDataUtil.ToFixCodeDB(in1, M_User.USER_CODE_MAX_LENGTH));
                    if (data != null && data.ID != Constant.DEFAULT_ID && data.StatusFlag != 1)
                    {
                        var result = new
                        {
                            userName1 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string conditionCd, string condition)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(conditionCd, (int)ConditionFlag.Billing);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            condition = condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion

        #region Method

        /// <summary>
        /// Get tax name
        /// </summary>
        /// <returns></returns>
        public string GetTaxName()
        {
            using (DB db = new DB())
            {
                Currency_HService currencyHService = new Currency_HService(db);
                var crcy = currencyHService.GetByID(int.Parse(this.cmbCurrency.SelectedValue));

                if (crcy != null)
                {
                    return string.Format("{0}/Ratio", crcy.TaxName);
                }
                return "VAT/Ratio";
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            this.FocusControlId = string.Empty;

            //Set Model
            this.Mode = mode;

            if (mode == Mode.Check)
            {
                this.FocusControlId = "dtDepositDate_0";
            }

            //---------------Set enable control at total------------------//
            //Reset value control
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
            {
                //Enable control
                this.cmbVatType.Enabled = false;
                this.txtVatRatio.ReadOnly = true;

                //vat ratio
                this.txtVatRatio.Value = null;

                //vat type
                this.cmbVatType.SelectedValue = null;
                this.InitDropDownListData(this.cmbVatType, this.vatTypeListEmpty);
            }
            else//for total
            {
                //Enable control
                this.cmbVatType.Enabled = true;
                this.txtVatRatio.ReadOnly = false;

                this.InitDropDownListData(this.cmbVatType, this.vatTypeList);
                var tempVat = this.txtSumVat.Value;
                var tempVatRatio = this.txtVatRatio.Value;

                this.SetEnableControlByVatType(this.cmbVatType, this.txtSumVat, this.txtVatRatio);
                this.txtSumVat.Value = tempVat;
                this.txtVatRatio.Value = tempVatRatio;
            }

            this.SetDecimalDigit(this.cmbCurrency, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtDepositTotal, Constant.MAX_SUM_AMOUNT_DECIMAL, Constant.MAX_SUM_AMOUNT_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtBalance, Constant.MAX_BALANCE_DECIMAL, Constant.MAX_BALANCE_NOT_DECIMAL);

            if (mode == Mode.View)
            {
                this.DisabledLink(this.btnEdit, !base._authority.IsBillingEdit);
                this.DisabledLink(this.btnIssue, !base._authority.IsBillingPDF);
                this.DisabledLink(this.btnCheck, !base._authority.IsBillingCheck);
                this.DisabledLink(this.btnDelete, !base._authority.IsBillingDelete);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                CustomerService customerService = new CustomerService(db);
                UserService userService = new UserService(db);
                ProductService productService = new ProductService(db);
                VendorService vendorService = new VendorService(db);

                var isDecimal = this.IsDecimalCurrency(this.cmbCurrency);
                string nf = string.Format("N{0}", isDecimal ? 2 : 0);

                //--------------------------------Subject check-----------------------------------------------------------------//
                if (this.txtSubject.IsEmpty)
                {
                    base.SetMessage(this.txtSubject.ID, M_Message.MSG_REQUIRE, "Subject");
                }
                //--------------------------------End Subject check-----------------------------------------------------------------//

                //--------------------------------SalesDate check---------------------------------------------------------------//
                if (this.Mode == Mode.Update)
                {
                    if (!this.txtBillingDate.Value.HasValue)//Check required
                    {
                        base.SetMessage(this.txtBillingDate.ID, M_Message.MSG_REQUIRE, "Bill Date");
                    }
                    if (!this.txtExpiryDate.Value.HasValue)//Check required
                    {
                        base.SetMessage(this.txtExpiryDate.ID, M_Message.MSG_REQUIRE, "Due Date");
                    }
                    if (this.txtBillingDate.Value.HasValue && this.txtExpiryDate.Value.HasValue)
                    {
                        if (this.txtExpiryDate.Value < this.txtBillingDate.Value)
                        {
                            base.SetMessage(this.txtExpiryDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Due Date", "Bill Date");
                        }
                    }
                    //--------------------------------End SalesDate check---------------------------------------------------------------//

                    //--------------------------------Prepared check-------------------------------------------------------------------//
                    if (this.txtPreparedCD.IsEmpty)
                    {
                        base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_REQUIRE, "Prepared Code");
                        this.txtPreparedName.Value = string.Empty;
                    }
                    else
                    {
                        //Check exists
                        var user = userService.GetByUserCD(this.txtPreparedCD.Value);
                        if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                        {
                            base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Prepared Code");
                            this.txtPreparedName.Value = string.Empty;
                        }
                        else if (user.StatusFlag == 1)//Check disbale
                        {
                            base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_CODE_DISABLE, "Prepared Code");
                            this.txtPreparedName.Value = string.Empty;
                        }
                        else
                        {
                            this.txtPreparedName.Value = user.UserName2;
                        }
                    }
                    //--------------------------------End Prepared check-------------------------------------------------------------------//

                    //--------------------------------Approved check-----------------------------------------------------------------//
                    if (this.txtApprovedCD.IsEmpty)
                    {
                        base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_REQUIRE, "Approved Code");
                        this.txtApprovedName.Value = string.Empty;
                    }
                    else
                    {
                        //Check exists
                        var user = userService.GetByUserCD(this.txtApprovedCD.Value);
                        if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                        {
                            base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Approved Code");
                            this.txtApprovedName.Value = string.Empty;
                        }
                        else if (user.StatusFlag == 1)//Check disbale
                        {
                            base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_CODE_DISABLE, "Approved Code");
                            this.txtApprovedName.Value = string.Empty;
                        }
                        else
                        {
                            this.txtApprovedName.Value = user.UserName2;
                        }
                    }

                    if (!this.txtTaxCode.IsEmpty)
                    {
                        if (!CheckDataUtil.IsCheckFormat(this.txtTaxCode.Value, Constants.PATTERN_TAX_CODE))
                        {
                            this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_INCORRECT_FORMAT, "Tax Code");
                        }
                    }

                    //--------------------------------End Approved check-----------------------------------------------------------------//

                    //--------------------------------Check detail sell----------------------------------------------------------//
                    var maxValue = 0m;
                    var minValue = 0m;

                    var listDetail = this.GetData();

                    for (int i = 0; i < listDetail.Count; i++)
                    {
                        int rowIndex = i + 1;
                        var item = listDetail[i];

                        //---------------------------------------------Check sell Quantity-------------------------------------------------//
                        if (!item.Quantity.HasValue)//Check required
                        {
                            base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", rowIndex);
                        }
                        else
                        {
                            if (item.Quantity.Value == 0)//Check must greater than 0
                            {
                                base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, rowIndex);
                            }

                            //Check max length
                            maxValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                            string numberFormat = string.Format("N{0}", this.QuantityDecimal);
                            if (item.Quantity.Value > maxValue)
                            {
                                base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(numberFormat), rowIndex);
                            }
                            var remainQuantity = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                            if (item.Quantity.Value > item.RemainQuantity.Value)
                            {
                                base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", item.RemainQuantity.Value.ToString(numberFormat), rowIndex);
                            }
                        }

                        //---------------------------------------------Check sub total--------------------------------------------------------//
                        if (item.Total.HasValue)//Check max length
                        {
                            maxValue = (isDecimal) ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                            var decimalDigit = (isDecimal) ? 2 : 0;
                            string numberFormat = string.Format("N{0}", decimalDigit);
                            if (item.Total.Value > maxValue)
                            {
                                base.SetMessage(string.Format("txtSellTotal_{0}", i), M_Message.MSG_LESS_THAN_GRID, "Sub Total", maxValue.ToString(numberFormat), rowIndex);
                            }
                        }
                        //---------------------------------------------End Check sub total--------------------------------------------------------//

                        //---------------------------------------------Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//
                        if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
                        {
                            if (item.VATType == (int)VATFlg.Exclude)
                            {
                                //--------------------------------------Check sell VAT------------------------------------------------------------//
                                if (item.Vat.HasValue)
                                {
                                    //Check max length
                                    maxValue = (isDecimal) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                    var decimalDigit = (isDecimal) ? 2 : 0;
                                    string numberFormat = string.Format("N{0}", decimalDigit);
                                    if (item.Vat.Value > maxValue)
                                    {
                                        base.SetMessage(string.Format("txtSellVat_{0}", i), M_Message.MSG_LESS_THAN_GRID, "VAT", maxValue.ToString(numberFormat), rowIndex);
                                    }
                                }
                                //--------------------------------------End Check sell VAT------------------------------------------------------------//

                                //--------------------------------------Check sell VatRatio-----------------------------------------------------------//
                                if (!item.VatRatio.HasValue)//Check required
                                {
                                    base.SetMessage(string.Format("txtSellVatRatio_{0}", i), M_Message.MSG_REQUIRE_GRID, "VatRatio", rowIndex);
                                }
                                else
                                {
                                    //Check max length
                                    if (item.VatRatio.Value > Constant.MAX_VATRATIO)
                                    {
                                        base.SetMessage(string.Format("txtSellVatRatio_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, rowIndex);
                                    }
                                }
                                //--------------------------------------End Check sell VatRatio-----------------------------------------------------------//
                            }
                        }
                        //---------------------------------------------End Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//

                        //---------------------------------------------End Check detail COST---------------------------------------------------------------------//
                    }
                    //---------------------------------End Check product code -----------------------------------------------------//
                    // }
                    //--------------------------------End Check detail sell----------------------------------------------------------//

                    //--------------------------------Check Sum Total,Sum VAT, Grand Total------------------------------------------//

                    var sumTotal = this.txtSumTotal.Value.GetValueOrDefault();
                    var sumVAT = this.txtSumVat.Value.GetValueOrDefault();
                    var grandTotal = this.txtGrandTotal.Value.GetValueOrDefault();

                    // var dec = isDecimal ? 2 : 0;
                    // string nf = string.Format("N{0}", dec);

                    maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                    if (sumTotal > maxValue)
                    {
                        this.SetMessage("txtSumTotal", M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(nf));
                    }
                    else if (sumTotal < minValue)
                    {
                        this.SetMessage("txtSumTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Total", minValue.ToString(nf));
                    }

                    maxValue = isDecimal ? Constant.MAX_SUM_VAT_DECIMAL : Constant.MAX_SUM_VAT_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_VAT_DECIMAL : Constant.MIN_SUM_VAT_NOT_DECIMAL;
                    if (sumVAT > maxValue)
                    {
                        this.SetMessage("txtSumVat", M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(nf));
                    }
                    else if (sumVAT < minValue)
                    {
                        this.SetMessage("txtSumVat", M_Message.MSG_GREATER_THAN_EQUAL, "VAT", minValue.ToString(nf));
                    }

                    maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                    if (grandTotal > maxValue)
                    {
                        this.SetMessage("txtGrandTotal", M_Message.MSG_LESS_THAN_EQUAL, "Grand Total", maxValue.ToString(nf));
                    }
                    else if (grandTotal < minValue)
                    {
                        this.SetMessage("txtGrandTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Grand Total", minValue.ToString(nf));
                    }

                    //Reset datasource
                    this.rptDetail.DataSource = listDetail;
                    this.rptDetail.DataBind();
                }
                if (this.Mode == Mode.Check)
                {
                    var listDeposit = this.GetDetailList();
                    for (int i = 0; i < listDeposit.Count; i++)
                    {
                        int rowIndex = i + 1;
                        var item = listDeposit[i];
                        if (item.DepositDate == null && item.Amount == null
                            && item.PaymentMethod == 255
                            && string.IsNullOrEmpty(item.Remark2) && string.IsNullOrEmpty(item.Remark1))
                        {
                            continue;
                        }
                        else
                        {
                            if (item.DepositDate != null)
                            {
                                if (item.PaymentMethod == 255)
                                {
                                    base.SetMessage(string.Format("cmbPaymentMethodDeposit_{0}", i), M_Message.MSG_REQUIRE_SELECT_GRID, "Payment Method", rowIndex);
                                }

                                if (item.Amount == null)
                                {
                                    base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_REQUIRE_GRID, "Amount", rowIndex);
                                }
                                else
                                {
                                    if (item.Amount == 0)
                                    {
                                        base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_MUST_BE_DIFFERENT_GRID, "Amount", "0", rowIndex);
                                    }
                                }
                            }
                            else
                            {
                                base.SetMessage(string.Format("dtDepositDate_{0}", i), M_Message.MSG_REQUIRE_GRID, "Deposit Date", rowIndex);
                                if (item.PaymentMethod == 255)
                                {
                                    base.SetMessage(string.Format("cmbPaymentMethodDeposit_{0}", i), M_Message.MSG_REQUIRE_SELECT_GRID, "Payment Method", rowIndex);
                                }
                                if (item.Amount == null)
                                {
                                    base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_REQUIRE_GRID, "Amount", rowIndex);
                                }
                                else
                                {
                                    if (item.Amount == 0)
                                    {
                                        base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_MUST_BE_DIFFERENT_GRID, "Amount", "0", rowIndex);
                                    }
                                }
                            }
                        }
                    }

                    //if (this.txtGrandTotal.Value > 0 && this.txtGrandTotal.Value < this.txtDepositTotal.Value)
                    //{
                    //    base.SetMessage("", M_Message.MSG_LESS_THAN, "Deposit Total", "Grand Total");
                    //}
                    //Reset datasource
                    this.rptListDeposit.DataSource = listDeposit;
                    this.rptListDeposit.DataBind();
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Get Default Data DropDownList
        /// </summary>
        private void GetDefaultDataDropDownList()
        {
            using (DB db = new DB())
            {
                //Get ExchangeRate
                Currency_HService currencyHService = new Currency_HService(db);
                var crcyItems = currencyHService.GetListDropdown();

                //Get ExchangeRate
                this.currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                //paymentMethod
                Config_HService configHService = new Config_HService(db);
                this.paymentMethod = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_PAYMENT_METHOD);
                this.paymentMethodDeposit = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_PAYMENT_METHOD);
                this.paymentMethodDeposit.Insert(0, new DropDownModel()
                {
                    Value = "255",
                    DisplayName = string.Empty
                });
                this.defaultPaymentMethod = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAYMENT_METHOD);

                this.methodVatList = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_VAT);
                this.defaultMethodVat = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_METHOD_VAT);

                this.QuantityDecimal = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                //VatTypeList
                this.vatTypeList = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
                this.defaultVatType = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);

                //Get Unit
                UnitService unitService = new UnitService(db);
                this.unitList = unitService.GetDataForDropDownList();

                //Default VAT
                this.DefaultVAT = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL);

                this._fractionType = (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));
                this._defaultProfit = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_PROFIT_VALUE);

                //-------2014/12/10 ISV-HUNG Edit Start -----------//
                //ProductCD Used
                this._productCDUsed = int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED));
                //-------2014/12/10 ISV-HUNG Edit End -----------//
            }
        }

        /// <summary>
        /// Init DropDownList
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        /// <param name="includeRowEmpty">Include row empty</param>
        private IList<BillingDetailInfo> GetData(bool includeDelete = true)
        {
            IList<BillingDetailInfo> ret = new List<BillingDetailInfo>();
            this.index = 1;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                HtmlInputCheckBox chkBillingDel = (HtmlInputCheckBox)item.FindControl("chkBillingDel");

                BillingDetailInfo detail = new BillingDetailInfo();

                //Check Type
                if (!includeDelete && chkBillingDel.Checked)
                {
                    continue;
                }

                detail.CheckFlag = chkBillingDel.Checked;

                HiddenField hdnId = (HiddenField)item.FindControl("hdnId");
                HiddenField hdnIdSalesSellID = (HiddenField)item.FindControl("hdnIdSalesSellID");
                HiddenField hidInternalID = (HiddenField)item.FindControl("hidInternalID");

                detail.HID = int.Parse(hdnId.Value);
                detail.SalesSellID = int.Parse(hdnIdSalesSellID.Value);
                detail.InternalID = int.Parse(hidInternalID.Value);

                //No
                detail.No = this.index++;

                //SellProductCD
                ICodeTextBox txtSellProductCD = (ICodeTextBox)item.FindControl("txtSellProductCD");
                detail.ProductCD = txtSellProductCD.Value;

                //SellProductName
                ITextBox txtSellProductName = (ITextBox)item.FindControl("txtSellProductName");
                detail.ProductName = txtSellProductName.Value;

                //SellDescription
                ITextBox txtSellDescription = (ITextBox)item.FindControl("txtSellDescription");
                detail.Description = txtSellDescription.Value;

                //SellPrice
                INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtSellPrice");
                detail.Price = txtSellPrice.Value;

                //SellQuantity
                INumberTextBox txtSellQuantity = (INumberTextBox)item.FindControl("txtSellQuantity");
                detail.Quantity = txtSellQuantity.Value;

                HiddenField hdnRemainQuantity = (HiddenField)item.FindControl("hdnRemainQuantity");
                detail.RemainQuantity = decimal.Parse(hdnRemainQuantity.Value);

                //SellUnit
                DropDownList cmbSellUnit = (DropDownList)item.FindControl("cmbSellUnit");
                detail.UnitID = Convert.ToInt32(cmbSellUnit.SelectedItem.Value);

                //SellTotal
                INumberTextBox txtSellTotal = (INumberTextBox)item.FindControl("txtSellTotal");
                detail.Total = txtSellTotal.Value;

                //SellVat
                INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");
                detail.Vat = txtSellVat.Value;

                //SellRemark
                ITextBox txtSellRemark = (ITextBox)item.FindControl("txtSellRemark");
                detail.Remark = txtSellRemark.Value;

                //VatType
                //DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbSellVatType");
                HiddenField hdnVatType = (HiddenField)item.FindControl("hdnVatType");
                if (this.hdnCmbMethodVat.Value == M_Config_D.METHOD_VAT_EACH)
                {
                    detail.VATType = Convert.ToInt32(hdnVatType.Value);
                }
                else
                {
                    detail.VATType = 255;
                }

                //SellVatRatio
                INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtSellVatRatio");
                detail.VatRatio = txtSellVatRatio.Value;

                ret.Add(detail);
            }

            return ret;
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Process up, down list detail
        /// </summary>
        /// <param name="processUp">true: Process Up false: Process Down</param>
        /// <param name="listData">List data</param>
        /// <returns></returns>
        private IList<BillingDetailInfo> ProcessUpDown(bool processUp, IList<BillingDetailInfo> listData)
        {
            IList<BillingDetailInfo> listResult = new List<BillingDetailInfo>();
            if (processUp) // Process up
            {
                listResult.Add(listData[0]);
                for (int i = 1; i < listData.Count; i++)
                {
                    var item = listData[i];
                    var itemPre = listResult[i - 1];

                    if (item.CheckFlag)
                    {
                        if (itemPre.CheckFlag)
                        {
                            listResult.Add(item);
                        }
                        else
                        {
                            listResult.Insert(i - 1, item);
                        }
                    }
                    else
                    {
                        listResult.Add(item);
                    }
                }
            }
            else // Process down
            {
                listResult.Add(listData[listData.Count - 1]);
                for (int i = listData.Count - 2; i >= 0; i--)
                {
                    var item = listData[i];
                    if (item.CheckFlag)
                    {
                        if (listResult[0].CheckFlag)
                        {
                            listResult.Insert(0, item);
                        }
                        else
                        {
                            listResult.Insert(1, item);
                        }
                    }
                    else
                    {
                        listResult.Insert(0, item);
                    }
                }
            }

            //Sort index
            int index = 1;
            for (int i = 0; i < listResult.Count; i++)
            {
                listResult[i].No = index++;
            }

            return listResult;
        }

        /// <summary>
        /// Insert Billing Condition
        /// </summary>
        /// <param name="headerId">Billing ID</param>
        private void InsertBillingCondition(DB db, int headerId, string condition)
        {
            Billing_CService billing_CService = new Billing_CService(db);
            billing_CService.Delete(headerId);

            T_Billing_C billingC = new T_Billing_C();
            billingC.HID = headerId;
            billingC.Conditions = condition;

            billing_CService.Insert(billingC);
        }

        /// <summary>
        /// Get sell info for insert
        /// </summary>
        /// <param name="sellInfo">BillingDetailInfo</param>
        /// <returns></returns>
        private T_Billing_D GetSellInfo(BillingDetailInfo sellInfo)
        {
            T_Billing_D result = new T_Billing_D();
            result.InternalID = sellInfo.InternalID;
            result.HID = sellInfo.HID;
            result.SalesSellID = sellInfo.SalesSellID;
            result.No = sellInfo.No;
            result.ProductCD = sellInfo.ProductCD;
            result.ProductName = sellInfo.ProductName;
            result.Description = sellInfo.Description;
            result.Remark = sellInfo.Remark;
            result.UnitID = sellInfo.UnitID;
            result.VATType = short.Parse(sellInfo.VATType.ToString());
            result.VatRatio = sellInfo.VatRatio.HasValue ? sellInfo.VatRatio.Value : 0;
            result.UnitPrice = sellInfo.Price.HasValue ? sellInfo.Price.Value : 0;
            result.Quantity = sellInfo.Quantity.HasValue ? sellInfo.Quantity.Value : 0;
            result.Total = sellInfo.Total.HasValue ? sellInfo.Total.Value : 0;
            result.Vat = sellInfo.Vat.HasValue ? sellInfo.Vat.Value : 0;

            return result;
        }

        /// <summary>
        /// Get header
        /// </summary>
        /// <param name="header">T_Billing_H</param>
        private void GetHeader(T_Billing_H header)
        {
            header.BillingNo = this.txtBillingNo.Value;
            header.BillingDate = this.txtBillingDate.IsEmpty ? DATE_TIME_DEFAULT : this.txtBillingDate.Value.Value;
            header.ExpiryDate = this.txtExpiryDate.IsEmpty ? DATE_TIME_DEFAULT : this.txtExpiryDate.Value.Value;
            header.FinishFlag = short.Parse(this.txtBalance.Value == 0 ? "1" : "0");
            header.QuoteNo = this.txtQuotationNo.IsEmpty ? string.Empty : this.txtQuotationNo.Value;
            header.SalesNo = this.txtSalesNo.IsEmpty ? string.Empty : this.txtSalesNo.Value;
            //header.ReceiptNo = this.txtReceiptNo.IsEmpty ? string.Empty : this.txtReceiptNo.Value;
            header.PreparedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.PreparedName = this.txtPreparedName.Value;
            header.ApprovedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.ApprovedName = this.txtApprovedName.Value;
            header.CustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
            header.CustomerName = this.txtCustomerName.Value;
            header.SubjectName = this.txtSubject.Value;
            header.CustomerAddress1 = this.txtAdd1.Value;
            header.CustomerAddress2 = this.txtAdd2.Value;
            header.CustomerAddress3 = this.txtAdd3.Value;
            header.Tel = this.txtTel.Value;
            header.FAX = this.txtFax.Value;
            header.TAXCode = this.txtTaxCode.Value;

            //---------------Add 2015/01/06 ISV-HUNG-----------------//
            //header.RedBillingNo = this.txtContractNo.Value;
            //header.RedBillingDate = this.dtContractDate.IsEmpty ? DATE_TIME_DEFAULT : this.dtContractDate.Value.Value;
            header.RedInvoiceNo = this.txtContractNo.Value;
            header.RedInvoiceDate = this.dtContractDate.IsEmpty ? DATE_TIME_DEFAULT : this.dtContractDate.Value.Value;
            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            header.ContactPerson = this.txtAttn.Value;
            header.CurrencyID = Convert.ToInt16(this.hdnCmbCurrency.Value);
            header.MethodVat = Convert.ToInt16(this.hdnCmbMethodVat.Value);
            header.PaymentMethod = Convert.ToInt16(this.cmbPaymentMethod.SelectedItem.Value);

            //Total check
            header.Total = (this.txtSumTotal.Value.HasValue) ? this.txtSumTotal.Value.Value : 0;

            //Total check
            header.Vat = (this.txtSumVat.Value.HasValue) ? this.txtSumVat.Value.Value : 0;

            //Total check
            header.GrandTotal = (this.txtGrandTotal.Value.HasValue) ? this.txtGrandTotal.Value.Value : 0;

            header.VatRatio = (this.txtVatRatio.Value.HasValue) ? this.txtVatRatio.Value.Value : 0;

            if (this.cmbVatType.Enabled)
            {
                header.VatType = short.Parse(this.cmbVatType.SelectedItem.Value);
            }
            else
            {
                header.VatType = 255;
            }

            header.Memo = this.txtMemo.Value;

            header.CreateUID = this.LoginInfo.User.ID;
            header.UpdateUID = this.LoginInfo.User.ID;

            if (this.Mode == Mode.Update || this.Mode == Mode.Delete)
            {
                header.UpdateDate = this.OldUpdateDate;
            }
        }

        /// <summary>
        /// Get Billing
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Billing_H GetBilling(int id)
        {
            using (DB db = new DB())
            {
                Billing_HService billing_HService = new Billing_HService(db);

                //Get Currency
                return billing_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Get Sales
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(string salesNo)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Currency
                return sales_HService.GetBySalesNo(salesNo);
            }
        }


        /// <summary>
        /// Get BillingD
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Billing_D GetBillingD(int id)
        {
            using (DB db = new DB())
            {
                Billing_DService billing_DService = new Billing_DService(db);

                //Get Currency
                return billing_DService.GetByFK(id);
            }
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        /// <param name="billing">T_Billing_H</param>
        private void ShowHeaderData(T_Billing_H billing)
        {
            //Display header
            this.BillingID = billing.ID;
            this.txtBillingNo.Value = billing.BillingNo;
            if (billing.BillingDate == DATE_TIME_DEFAULT)
            {
                this.txtBillingDate.Value = null;
            }
            else
            {
                this.txtBillingDate.Value = billing.BillingDate;
            }

            if (billing.ExpiryDate == DATE_TIME_DEFAULT)
            {
                this.txtExpiryDate.Value = null;
            }
            else
            {
                this.txtExpiryDate.Value = billing.ExpiryDate;
            }
            this.txtSalesNo.Value = billing.SalesNo;
            this.txtQuotationNo.Value = billing.QuoteNo;

            this.txtPreparedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(billing.PreparedCD, M_User.MAX_USER_CODE_SHOW);
            this.txtPreparedName.Value = billing.PreparedName;
            this.txtApprovedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(billing.ApprovedCD, M_User.MAX_USER_CODE_SHOW);
            this.txtApprovedName.Value = billing.ApprovedName;
            this.txtCustomerCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(billing.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.txtCustomerName.Value = billing.CustomerName;
            this.txtAttn.Value = billing.ContactPerson;
            this.txtAdd1.Value = billing.CustomerAddress1;
            this.txtAdd2.Value = billing.CustomerAddress2;
            this.txtAdd3.Value = billing.CustomerAddress3;
            this.txtTel.Value = billing.Tel;
            this.txtFax.Value = billing.FAX;
            this.txtSubject.Value = billing.SubjectName;
            this.txtMemo.Value = billing.Memo;
            this.txtTaxCode.Value = billing.TAXCode;
            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            //this.txtContractNo.Value = billing.RedBillingNo;
            //if (billing.RedBillingDate == DATE_TIME_DEFAULT)
            //{
            //    this.dtContractDate.Value = null;
            //}
            //else
            //{
            //    this.dtContractDate.Value = billing.RedBillingDate;
            //}

            this.txtContractNo.Value = billing.RedInvoiceNo;
            if (billing.RedInvoiceDate == DATE_TIME_DEFAULT)
            {
                this.dtContractDate.Value = null;
            }
            else
            {
                this.dtContractDate.Value = billing.RedInvoiceDate;
            }


            //---------------Add 2015/01/06 ISV-HUNG-----------------//

            this.cmbCurrency.SelectedValue = billing.CurrencyID.ToString();
            this.cmbPaymentMethod.SelectedValue = billing.PaymentMethod.ToString();
            this.cmbMethodVat.SelectedValue = billing.MethodVat.ToString();
            this.hdnCmbMethodVat.Value = billing.MethodVat.ToString();
            this.hdnCmbCurrency.Value = billing.CurrencyID.ToString();

            //Show condition
            this.txtConditions.Value = this.GetConditions(billing.ID);
            this.OldCondition = this.GetConditions(billing.ID);

            //Show detail
            this.ShowDetailData(billing.ID);
            this.txtSumTotal.Value = billing.Total;
            this.cmbVatType.SelectedValue = billing.VatType.ToString();
            this.txtSumVat.Value = billing.Vat;

            this.SetDecimalDigit(this.cmbCurrency, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);

            if (billing.VatType == 255)
            {
                this.cmbVatType.SelectedValue = null;
            }
            else
            {
                this.cmbVatType.SelectedValue = billing.VatType.ToString();

                if (billing.VatType == (int)VATFlg.Exclude)
                {
                    this.txtVatRatio.Value = billing.VatRatio;
                }
                else
                {
                    this.txtSumVat.Value = null;
                    this.txtVatRatio.Value = null;
                }
            }

            this.txtGrandTotal.Value = billing.GrandTotal;

            this.ShowDetailDepositData(billing.ID);

            this.DeleteFlag = billing.DeleteFlag == 1;

            this.FinishFlag = billing.FinishFlag == 1;

            this.OldUpdateDate = billing.UpdateDate;

            //this.txtIssueBy.Value = string.Empty;

            using (DB db = new DB())
            {
                UserService userService = new UserService(db);
                AttachedService attachedService = new AttachedService(db);
                Sales_HService sales_HService = new Sales_HService(db);
                //Issue
                var issueUser = userService.GetByID(billing.IssuedUID);
                if (issueUser != null)
                {
                    var issuedDate = (billing.IssuedDate == DATE_TIME_DEFAULT) ? string.Empty : billing.IssuedDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtIssueDate.Value = string.Format("{0} {1}", issueUser.UserName2, issuedDate);
                }
                else
                {
                    this.txtIssueDate.Value = string.Empty;
                }

                //Update
                var updateUser = userService.GetByID(billing.UpdateUID);
                if (updateUser != null)
                {
                    var updateDate = (billing.UpdateDate == DATE_TIME_DEFAULT) ? string.Empty : billing.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                else
                {
                    this.txtUpdateDate.Value = string.Empty;
                }

                //Create
                var createUser = userService.GetByID(billing.CreateUID);
                if (createUser != null)
                {
                    var createDate = (billing.CreateDate == DATE_TIME_DEFAULT) ? string.Empty : billing.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }
                else
                {
                    this.txtCreateDate.Value = string.Empty;
                }

                this.FileAttachedCount = attachedService.CountFile(this.BillingID, (int)FType.Billing);

                var accH = sales_HService.GetBySalesNo(billing.SalesNo);
                if (accH != null)
                {
                    this.OldVersionUpdateDate = accH.VersionUpdateDate;
                }
            }
        }

        /// <summary>
        /// Show condition
        /// </summary>
        /// <param name="headerID"></param>
        private string GetConditions(int headerID)
        {
            string conditions = string.Empty;
            using (DB db = new DB())
            {
                Billing_CService billing_CService = new Billing_CService(db);
                var billingC = billing_CService.GetByPK(headerID);
                if (billingC != null)
                {
                    conditions = billingC.Conditions;
                }
                return conditions;
            }
        }

        /// <summary>
        /// Show detail data on form
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void ShowDetailData(int headerID)
        {
            using (DB db = new DB())
            {
                Billing_DService billing_DService = new Billing_DService(db);

                var listBillingInfo = billing_DService.GetListByID(headerID);

                //Create list data
                IList<BillingDetailInfo> dataList = this.CreateListDetail(listBillingInfo);

                //Reset datasource
                this.rptDetail.DataSource = dataList;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Show detail data on form
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void ShowDetailDepositData(int headerID)
        {
            using (DB db = new DB())
            {
                Deposit_Service deposit_Service = new Deposit_Service(db);

                var listDepositInfo = deposit_Service.GetListByID(headerID);

                if (listDepositInfo != null)
                {
                    var sumTotalDeposit = 0m;
                    foreach (var item in listDepositInfo)
                    {
                        sumTotalDeposit += item.Amount.Value;
                    }
                    if (listDepositInfo.Count == 0 || listDepositInfo.Count == 1 && listDepositInfo.Any(x => x.DepositDate == null))
                    {
                        this.txtDepositTotal.Value = 0;
                    }
                    else
                    {
                        this.txtDepositTotal.Value = sumTotalDeposit;
                    }
                    this.txtBalance.Value = this.txtGrandTotal.Value - sumTotalDeposit;
                }

                //Reset datasource
                this.rptListDeposit.DataSource = listDepositInfo;
                this.rptListDeposit.DataBind();
            }
        }

        /// <summary>
        /// Create detail list
        /// </summary>
        /// <param name="sellList">T_Billing_D List</param>
        /// <returns></returns>
        private IList<BillingDetailInfo> CreateListDetail(IList<T_Billing_D> billingList)
        {
            IList<BillingDetailInfo> dataList = new List<BillingDetailInfo>();

            using (DB db = new DB(System.Data.IsolationLevel.Serializable))
            {
                Billing_DService billing_DService = new Billing_DService(db);

                foreach (var item in billingList)
                {
                    BillingDetailInfo itemBilling = new BillingDetailInfo();
                    itemBilling.InternalID = item.InternalID;
                    itemBilling.HID = item.HID;
                    itemBilling.SalesSellID = item.SalesSellID;
                    var remainQuantity = billing_DService.GetRemainQtyBySalesSellID(item.SalesSellID, this.BillingID);
                    itemBilling.No = item.No;
                    itemBilling.ProductCD = item.ProductCD;
                    itemBilling.ProductName = item.ProductName;
                    itemBilling.Description = item.Description;
                    itemBilling.Description = item.Description;
                    itemBilling.UnitID = item.UnitID;
                    itemBilling.Price = item.UnitPrice;
                    itemBilling.Quantity = item.Quantity;
                    itemBilling.RemainQuantity = remainQuantity;
                    itemBilling.Total = item.Total;
                    itemBilling.Remark = item.Remark;
                    itemBilling.VatRatio = item.VatRatio;
                    itemBilling.Vat = item.Vat;
                    itemBilling.VATType = item.VATType;

                    dataList.Add(itemBilling);
                }
            }
            return dataList;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                //int ret = 0;
                T_Billing_H header = this.GetBilling(this.BillingID);
                if (header != null)
                {
                    this.GetHeader(header);
                    IList<T_Deposit> listDetailDeposit = this.GetDetailList();
                    IList<BillingDetailInfo> listDetail = this.GetData();

                    //Update
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        if (header.Status == DataStatus.Changed || this.IsDetailChange(db) || this.IsDepositChange(db))
                        {
                            Sales_HService sales_HService = new Sales_HService(db);
                            Billing_DService billing_DService = new Billing_DService(db);
                            Billing_HService headerService = new Billing_HService(db);
                            T_Sales_H accH = sales_HService.GetBySalesNo(header.SalesNo);

                            if (accH != null)
                            {
                                //Update Version
                                accH.VersionUpdateUID = LoginInfo.User.ID;
                                accH.VersionUpdateDate = this.OldVersionUpdateDate;
                                if (sales_HService.UpdateVersion(accH) <= 0)
                                {
                                    //data has changed
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }
                            //Update header
                            if (headerService.Update(header) > 0)
                            {
                                //Mode check
                                if (this.Mode == Utilities.Mode.Check)
                                {
                                    //Delete Deposit
                                    Deposit_Service deposit_Service = new Deposit_Service(db);
                                    deposit_Service.Delete(header.ID);

                                    //Insert Deposit
                                    foreach (var item in listDetailDeposit)
                                    {
                                        if (item.DepositDate != null)
                                        {
                                            item.BillingID = header.ID;
                                            deposit_Service.Insert(item);
                                        }
                                    }
                                }
                                else
                                {
                                    //Insert Billing Condition
                                    this.InsertBillingCondition(db, header.ID, this.txtConditions.Value);

                                    //Get data from screen
                                    IList<T_Billing_D> listBill = new List<T_Billing_D>();

                                    //Create data from screen
                                    this.CreateDetail(listDetail, listBill);

                                    //Update detail
                                    //----------- ISV-Giam 2015/01/13 ------------
                                    this.UpdateBillingDetail(db, listBill);
                                    //--------------------------------------------
                                }

                                if (accH != null)
                                {
                                    //Update Finish Flag
                                    if (sales_HService.UpdateFinishFlag(accH) <= 0)
                                    {
                                        //data has changed
                                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                        return false;
                                    }
                                }

                                db.Commit();
                                return true;
                            }
                            else
                            {
                                //du lieu da thay doi
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_BILLING_H_FK_CURRENCY))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_BILLING_H_FK_CUSTOMER))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_BILLING_D_FK_UNIT))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Billing Detail
        /// </summary>
        /// <param name="db"></param>
        /// <param name="listDetail"></param>
        private void UpdateBillingDetail(DB db, IList<T_Billing_D> listDetail)
        {
            //get data in Database
            Billing_DService bill_DService = new Billing_DService(db);
            var dbDataList = bill_DService.GetListByID(this.BillingID);
            var no = dbDataList.Count + 1;

            //update data
            //update no in DB to greater number 
            foreach (var item in dbDataList)
            {
                bill_DService.UpdateNoByInternalID(item.InternalID, no);
                no += 1;
            }

            //Update data
            foreach (var item in listDetail)
            {
                item.HID = this.BillingID;
                bill_DService.Update(item);
            }
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                T_Billing_H header = this.GetBilling(this.BillingID);

                if (header != null)
                {
                    this.GetHeader(header);

                    //Delete customer                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        Sales_HService sales_HService = new Sales_HService(db);
                        T_Sales_H salesH = sales_HService.GetBySalesNo(header.SalesNo);

                        if (salesH != null)
                        {
                            //Sales_HService Sales_HService = new Sales_HService(db);
                            salesH.VersionUpdateUID = LoginInfo.User.ID;
                            salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                            if (sales_HService.UpdateVersion(salesH) <= 0)
                            {
                                //data has changed
                                this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                                T_Billing_H bill = this.GetBilling(this.BillingID);
                                if (bill != null)
                                {
                                    //Show data
                                    this.ShowHeaderData(bill);
                                }
                                return false;
                            }

                        }

                        Billing_HService headerService = new Billing_HService(db);
                        if (headerService.Delete(header) > 0)
                        {
                            if (salesH != null)
                            {
                                //Update Finish Flag
                                if (sales_HService.UpdateFinishFlag(salesH) <= 0)
                                {
                                    //data has changed
                                    this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                                    T_Billing_H bill = this.GetBilling(this.BillingID);
                                    if (bill != null)
                                    {
                                        //Show data
                                        this.ShowHeaderData(bill);
                                    }
                                    return false;
                                }
                            }
                            db.Commit();
                        }
                        else
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            T_Billing_H bill = this.GetBilling(this.BillingID);
                            if (bill != null)
                            {
                                //Show data
                                this.ShowHeaderData(bill);
                            }
                            return false;
                        }
                    }
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check detail change data
        /// </summary>
        /// <returns></returns>
        private bool IsDetailChange(DB db)
        {
            //Check condition
            if (!string.Equals(this.txtConditions.Value, this.OldCondition))
            {
                return true;
            }

            //List screen
            IList<BillingDetailInfo> listDetailScreen = this.GetData();

            //List data
            Billing_DService billing_DService = new Billing_DService(db);

            var listInfo = billing_DService.GetListByID(this.BillingID);

            //Create list data
            IList<BillingDetailInfo> listDetailData = this.CreateListDetail(listInfo);

            if (listDetailScreen.Count != listDetailData.Count)
            {
                return true;
            }
            foreach (var item in listDetailScreen)
            {
                var sell = listInfo.Where(s => s.No.Equals(item.No)).SingleOrDefault();
                sell.ProductCD = item.ProductCD;
                sell.ProductName = item.ProductName;
                sell.Description = item.Description;
                sell.UnitPrice = item.Price.Value;
                sell.Quantity = item.Quantity.Value;
                sell.UnitID = item.UnitID;
                sell.Remark = item.Remark;
                sell.Total = item.Total.Value;
                sell.Vat = item.Vat.GetValueOrDefault();
                sell.VATType = short.Parse(item.VATType.ToString());
                sell.VatRatio = item.VatRatio.GetValueOrDefault();
            }

            return listInfo.Any(s => s.Status == DataStatus.Changed);
        }

        /// <summary>
        /// Check detail change data
        /// </summary>
        /// <returns></returns>
        private bool IsDepositChange(DB db)
        {
            //List screen
            IList<T_Deposit> listDetailScreen = this.GetDetailList();

            //List data
            Deposit_Service deposit_Service = new Deposit_Service(db);

            var listInfo = deposit_Service.GetListByID(this.BillingID);

            for (int i = listDetailScreen.Count - 1; i >= 0; i--)
            {
                if (listDetailScreen[i].DepositDate == null)
                {
                    listDetailScreen.RemoveAt(i);
                }

            }
            if (listDetailScreen.Count != listInfo.Count)
            {
                if (listDetailScreen.Count == 1)
                {
                    var detail = listDetailScreen.Single();
                    if (detail.DepositDate == null)
                    {
                        return false;
                    }
                }
                return true;
            }
            foreach (var item in listDetailScreen)
            {
                var sell = listInfo.Where(s => s.No.Equals(item.No)).SingleOrDefault();
                sell.DepositDate = item.DepositDate;
                sell.Amount = item.Amount;
                sell.PaymentMethod = item.PaymentMethod;
                sell.Remark1 = item.Remark1;
                sell.Remark2 = item.Remark2;
            }

            return listInfo.Any(s => s.Status == DataStatus.Changed);
        }

        /// <summary>
        /// Set Confirm
        /// </summary>
        private void SetConfirmData()
        {
            using (DB db = new DB())
            {
                UserService userSrv = new UserService(db);

                Billing_HService billing_HService = new Billing_HService(db);
                //-----------------ISV-HUNG 2015/01/05
                AttachedService attachedService = new AttachedService(db);
                this.FileAttachedCount = attachedService.CountFile(this.BillingID, (int)FType.Billing);
                //-----------------ISV-HUNG 2015/01/05

                #region Header

                CustomerService custSrv = new CustomerService(db);
                if (!this.txtCustomerCD.IsEmpty && this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    var customerCd = this.txtCustomerCD.Value;
                    customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = custSrv.GetByCustomerCD(customerCd);
                    if (customer != null && customer.StatusFlag != 1)
                    {
                        this.txtCustomerName.Value = customer.CustomerName1;
                    }
                }

                M_User user = null;
                this.txtPreparedName.Value = null;
                //txtPreparedCD
                if (!this.txtPreparedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null)
                    {
                        this.txtPreparedName.Value = user.UserName2;
                    }
                }

                this.txtApprovedName.Value = null;
                //txtApprovedCD
                if (!this.txtApprovedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null)
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }
                #endregion

                var billing = this.GetBilling(this.BillingID);
                int vatType = 0;
                if (billing != null)
                {
                    if (this.Mode == Mode.Check || this.Mode == Mode.View || this.Mode == Mode.Update)
                    {
                        if (this.Mode != Mode.Update)
                        {
                            this.cmbPaymentMethod.SelectedValue = billing.PaymentMethod.ToString();
                        }

                        vatType = billing.VatType;
                        this.cmbVatType.SelectedValue = billing.VatType.ToString();
                    }
                    this.cmbMethodVat.SelectedValue = billing.MethodVat.ToString();
                    this.cmbCurrency.SelectedValue = billing.CurrencyID.ToString();
                    this.hdnCmbMethodVat.Value = billing.MethodVat.ToString();
                    this.hdnCmbCurrency.Value = billing.CurrencyID.ToString();
                }

                var methodType = this.cmbMethodVat.SelectedValue;
                var sumTotalSell = 0m;
                var sumVatSell = 0m;
                var sumTotalDeposit = 0m;


                //Currency
                var currency = this.GetListByDate();

                #region Detail
                foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
                {
                    DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbSellVatType");
                    DropDownList cmbSellUnit = (DropDownList)repeaterItem.FindControl("cmbSellUnit");
                    INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtSellVat");
                    INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtSellVatRatio");
                    INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtSellPrice");
                    INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtSellQuantity");
                    INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtSellTotal");
                    HiddenField hdnVatType = (HiddenField)repeaterItem.FindControl("hdnVatType");
                    var unitPrice = txtSellPrice.Value.GetValueOrDefault();
                    var quantity = txtSellQuantity.Value.GetValueOrDefault();
                    var total = Fraction.Round(this._fractionType, unitPrice * quantity, 2);

                    if (txtSellTotal.IsEmpty)
                    {
                        txtSellTotal.Value = total;
                    }

                    var vat = Fraction.Round(this._fractionType, (txtSellTotal.Value.Value * txtSellVatRatio.Value.GetValueOrDefault()) / 100, 2);

                    sumTotalSell += txtSellTotal.Value.GetValueOrDefault();

                    if (methodType == M_Config_D.METHOD_VAT_EACH &&
                        int.Parse(hdnVatType.Value) == (int)VATFlg.Exclude)
                    {
                        if (txtSellVat.IsEmpty)
                        {
                            txtSellVat.Value = vat;
                        }

                        sumVatSell += txtSellVat.Value.GetValueOrDefault();
                    }
                    else
                    {
                        txtSellVatRatio.Value = null;
                        txtSellVat.Value = null;
                    }
                }
                #endregion

                #region Deposit
                foreach (RepeaterItem repeaterItem in this.rptListDeposit.Items)
                {
                    INumberTextBox txtAmount = (INumberTextBox)repeaterItem.FindControl("txtAmount");

                    sumTotalDeposit += txtAmount.Value.GetValueOrDefault();

                }
                #endregion

                if (this.txtSumTotal.IsEmpty)
                {
                    this.txtSumTotal.Value = sumTotalSell;
                }
                sumTotalSell = this.txtSumTotal.Value.GetValueOrDefault();
                if (methodType == M_Config_D.METHOD_VAT_EACH)
                {
                    if (this.txtSumVat.IsEmpty || this.txtSumVat.Value == 0)
                    {
                        this.txtSumVat.Value = sumVatSell;
                    }
                    else
                    {
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                    }
                }
                else
                {
                    if (vatType == (int)VATFlg.Exclude)
                    {
                        var vatRatio = this.txtVatRatio.Value.GetValueOrDefault();
                        if (this.txtSumVat.IsEmpty)
                        {
                            this.txtSumVat.Value = Fraction.Round(this._fractionType, (sumTotalSell * vatRatio) / 100, 2);
                        }
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                        this.txtSumVat.SetReadOnly(false);
                        this.txtVatRatio.SetReadOnly(false);
                    }
                    else
                    {
                        sumVatSell = 0;
                        this.txtSumVat.SetReadOnly(true);
                        this.txtVatRatio.SetReadOnly(true);

                        this.txtSumVat.Value = null;
                        this.txtVatRatio.Value = null;
                    }
                }

                if (this.txtGrandTotal.IsEmpty)
                {
                    this.txtGrandTotal.Value = sumTotalSell + sumVatSell;
                }
                var listDepositInfo = this.GetDetailList();

                if (listDepositInfo.Count == 0 || listDepositInfo.Count == 1 && listDepositInfo.Any(x => x.DepositDate == null))
                {
                    this.txtDepositTotal.Value = 0;
                }
                else
                {
                    this.txtDepositTotal.Value = sumTotalDeposit;
                }

                this.txtBalance.Value = this.txtGrandTotal.Value - sumTotalDeposit;
            }

            this.rptDetail.DataSource = this.GetData();
            this.rptDetail.DataBind();

            this.rptListDeposit.DataSource = this.GetDetailList();
            this.rptListDeposit.DataBind();
        }

        /// <summary>
        /// Check all to reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidAllRef()
        {
            return this.IsValidQuotationRef() || this.IsValidSalesRef();
        }

        /// <summary>
        /// Check valid to quotation reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidQuotationRef()
        {
            return !this.txtQuotationNo.IsEmpty;
        }

        /// <summary>
        /// Check valid to Sales reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidSalesRef()
        {
            return !this.txtSalesNo.IsEmpty;
        }

        /// <summary>
        /// check button delete
        /// </summary>
        /// <returns></returns>
        protected bool HasDepositData()
        {
            IList<T_Deposit> listDepositInfo = new List<T_Deposit>();
            using (DB db = new DB())
            {
                Deposit_Service deposit_Service = new Deposit_Service(db);

                listDepositInfo = deposit_Service.GetListByID(this.BillingID);
            }
            return listDepositInfo != null && listDepositInfo.Count != 0;
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(DropDownList dropDownListControl, INumberTextBox numberControl, decimal maxDecimal, decimal maxNoneDecimal)
        {
            if (this.IsDecimalCurrency(dropDownListControl))
            {
                numberControl.DecimalDigit = 2;
                numberControl.MaximumValue = maxDecimal;
            }
            else
            {
                numberControl.DecimalDigit = 0;
                numberControl.MaximumValue = maxNoneDecimal;
            }
        }

        /// <summary>
        /// Check currency is decimal
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        private bool IsDecimalCurrency(DropDownList cmbCurrency, int? currencyId = null)
        {
            currencyId = currencyId.HasValue ? currencyId.Value : int.Parse(cmbCurrency.SelectedValue);

            var crcy = this.currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == currencyId).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Set enable control by vat type
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="vatControl">Vat Control</param>
        /// <param name="vatRatioControl">Vat Ratio Control</param>
        private void SetEnableControlByVatType(DropDownList dropDownListControl, INumberTextBox vatControl, INumberTextBox vatRatioControl)
        {
            if (Convert.ToInt32(dropDownListControl.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                vatControl.ReadOnly = false;
                vatControl.Value = null;

                vatRatioControl.ReadOnly = false;
                vatRatioControl.Value = decimal.Parse(this.DefaultVAT);
            }
            else
            {
                vatControl.ReadOnly = true;
                vatControl.Value = 0;

                vatRatioControl.ReadOnly = true;
                vatRatioControl.Value = 0;
            }
        }

        /// <summary>
        /// Get detail list from screen
        /// </summary>
        /// <returns>list currency detail</returns>
        private List<T_Deposit> GetDetailList()
        {
            List<T_Deposit> results = new List<T_Deposit>();
            this.index = 0;
            foreach (RepeaterItem item in this.rptListDeposit.Items)
            {
                HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");
                IDateTextBox dtDepositDate = (IDateTextBox)item.FindControl("dtDepositDate");
                INumberTextBox txtAmount = (INumberTextBox)item.FindControl("txtAmount");
                ITextBox txtRemark1 = (ITextBox)item.FindControl("txtRemark1");
                ITextBox txtRemark2 = (ITextBox)item.FindControl("txtRemark2");
                DropDownList cmbPaymentMethodDeposit = (DropDownList)item.FindControl("cmbPaymentMethodDeposit");
                HiddenField hdnDepositMethod = (HiddenField)item.FindControl("hdnDepositMethod");

                T_Deposit addItem = new T_Deposit();

                addItem.No = ++this.index;

                //Delete flag
                if (chkDelFlg != null)
                {
                    addItem.DelFlag = (chkDelFlg.Checked) ? true : false;
                }

                //Deposit date
                if (dtDepositDate != null)
                {
                    if (dtDepositDate.Value.HasValue)
                    {
                        if (dtDepositDate.Value == DATE_TIME_DEFAULT)
                        {
                            addItem.DepositDate = null;
                        }
                        else
                        {
                            addItem.DepositDate = dtDepositDate.Value.Value;
                        }
                    }
                }

                //Amount
                if (txtAmount != null)
                {
                    if (txtAmount.Value.HasValue)
                    {
                        addItem.Amount = txtAmount.Value.Value;
                    }
                }

                //PaymentMethod
                if (cmbPaymentMethodDeposit != null && cmbPaymentMethodDeposit.SelectedItem != null)
                {
                    if (this.Mode == Mode.Update)
                    {
                        addItem.PaymentMethod = short.Parse(hdnDepositMethod.Value);
                    }
                    else
                    {
                        addItem.PaymentMethod = short.Parse(cmbPaymentMethodDeposit.SelectedValue);
                    }
                }

                //PersonalDeposit
                if (txtRemark1 != null)
                {
                    addItem.Remark1 = txtRemark1.Value;
                }

                //Remark
                if (txtRemark2 != null)
                {
                    addItem.Remark2 = txtRemark2.Value;
                }

                results.Add(addItem);

            }

            return results;
        }

        /// <summary>
        /// Create Detail
        /// </summary>
        /// <param name="listDetail"></param>
        /// <param name="billingD"></param>
        private void CreateDetail(IList<BillingDetailInfo> listDetail, IList<T_Billing_D> listBilling)
        {
            foreach (var item in listDetail)
            {
                var bill = new T_Billing_D();
                bill.InternalID = item.InternalID;
                bill.HID = item.HID;
                bill.No = item.No;
                bill.SalesSellID = item.SalesSellID;
                bill.ProductID = item.ProductID;
                bill.ProductCD = item.ProductCD;
                bill.ProductName = item.ProductName;
                bill.Description = item.Description;
                bill.Remark = item.Remark;
                bill.UnitID = item.UnitID;
                bill.VATType = short.Parse(item.VATType.ToString());
                bill.VatRatio = item.VatRatio.GetValueOrDefault();
                bill.UnitPrice = item.Price.GetValueOrDefault();
                bill.Quantity = item.Quantity.GetValueOrDefault();
                bill.Vat = item.Vat.GetValueOrDefault();
                bill.Total = item.Total.GetValueOrDefault();

                listBilling.Add(bill);
            }
        }

        #endregion

        #region Ajax

        /// <summary>
        /// Calc Sell
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcSell(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtSellPrice") || senderId.Contains("txtSellQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);

                        var A1 = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 0);

                        var A2 = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);

                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtSellTotal") || senderId.Contains("txtSellVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count Attached File
        /// </summary>
        /// <param name="dataId">dataId</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(int dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId, (int)FType.Billing);
                    var result = new
                    {
                        count = count
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotal(string methodVAT
                                       , string[] totals, string[] VATs
                                       , string vatRatio
                                       , string deposit
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                if (string.IsNullOrEmpty(vatRatio))
                {
                    vatRatio = "0";
                }
                decimal? sumTotal = null;
                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = Utilities.Fraction.Round((FractionType)fractionType, totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);
                }
                decimal? sumVAT = null;
                if (sumTotal.HasValue)
                {
                    if (VATs.Any(s => !string.IsNullOrEmpty(s)))
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, VATs.Sum(v => string.IsNullOrEmpty(v) ? 0 : decimal.Parse(v)), 2);
                    }
                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, (sumTotal.GetValueOrDefault() * decimal.Parse(vatRatio)) / 100, 2);
                    }
                }

                string numberFormat = string.Format("N{0}", decimalDigit);

                decimal? grandTotal = null;

                if (sumTotal.HasValue && sumVAT.HasValue)
                {
                    grandTotal = sumTotal.GetValueOrDefault() + sumVAT.GetValueOrDefault();
                }

                decimal? balance = null;

                if (grandTotal == null)
                {
                    balance = grandTotal;
                }
                else
                {
                    balance = grandTotal - decimal.Parse(deposit);
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtSumTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtSumVat\":\"{0}\"", sumVAT.HasValue ? sumVAT.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtGrandTotal\":\"{0}\"", grandTotal.HasValue ? grandTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtBalance\":\"{0}\"", balance.HasValue ? balance.GetValueOrDefault().ToString(numberFormat) : string.Empty));


                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotalAmount(string[] Amounts
                                       , string grandTotal
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                var sumAmount = Utilities.Fraction.Round((FractionType)fractionType, Amounts.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);

                var balance = decimal.Parse(grandTotal) - sumAmount;

                string numberFormat = string.Format("N{0}", decimalDigit);


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtDepositTotal\":\"{0}\"", sumAmount.ToString(numberFormat)));
                result.Append(string.Format(",\"txtBalance\":\"{0}\"", balance.ToString(numberFormat)));

                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcGrandTotal(string grandTotal
                                       , string deposit
                                       , int decimalDigit)
        {
            try
            {
                decimal? balance = null;
                if (string.IsNullOrEmpty(grandTotal))
                {
                    balance = null;
                }
                else
                {
                    balance = decimal.Parse(grandTotal) - decimal.Parse(deposit);
                }

                string numberFormat = string.Format("N{0}", decimalDigit);


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtBalance\":\"{0}\"", balance.HasValue ? balance.GetValueOrDefault().ToString(numberFormat) : string.Empty));


                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion
    }
}
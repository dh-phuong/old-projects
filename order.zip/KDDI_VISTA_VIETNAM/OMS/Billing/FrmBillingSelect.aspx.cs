﻿using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using OMS.Controls;

using System;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Collections;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace OMS.Billing
{
    /// <summary>
    /// Class Billing select
    /// </summary>
    public partial class FrmBillingSelect : FrmBaseDetail
    {
        #region Constants
        private const int MAX_ROW_COUNT = 20;

        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        #region Variable
        /// <summary>
        /// Focus controls ID
        /// </summary>
        public string focusControlsID = "";
        private FractionType _defaultFractionType;

        //------2014/12/12 ISV-HUNG Add Start----------//
        /// <summary>
        /// Product CD Used
        /// </summary>
        public int _productCDUsed;
        public string _paymentMethod;
        //------2014/12/12 ISV-HUNG Add End----------//
        #endregion

        #region Property
        ///// <summary>
        ///// Is redirect to page
        ///// </summary>
        //public bool IsTransfer 
        //{
        //    get { return this.GetValueViewState<bool>("IsTransfer"); }
        //    private set { base.ViewState["IsTransfer"] = value; }
        //}
        /// <summary>
        /// Get or set SalesID
        /// </summary>
        public int DataID
        {
            get { return this.GetValueViewState<int>("DataID"); }
            private set
            {
                this.ViewState["DataID"] = value;
            }
        }

        ///// <summary>
        ///// Get or set FormType
        ///// </summary>
        //public int FormType
        //{
        //    get { return this.GetValueViewState<int>("FormType"); }
        //    private set { ViewState["FormType"] = value; }
        //}

        /// <summary>
        /// 
        /// </summary>
        public DateTime VersionUpdateDate
        {
            get { return this.GetValueViewState<DateTime>("VersionUpdateDate"); }
            private set
            {
                this.ViewState["VersionUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return this.GetValueViewState<int>("QuantityDecimal"); }
            private set
            {
                this.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public bool AllBillingDone
        {
            get { return this.GetValueViewState<bool>("AllBillingDone"); }
            private set
            {
                this.ViewState["AllBillingDone"] = value;
            }
        }

        /// <summary>
        /// DataSource Details
        /// </summary>
        private IList<BillingSelection> BillingSelections
        {
            get { return this.GetValueViewState<IList<BillingSelection>>("BillingSelections"); }
            set
            {
                this.ViewState["BillingSelections"] = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private Hashtable AccSellIDHtb
        {
            get { return this.GetValueViewState<Hashtable>("AccSellIDHtb"); }
            set
            {
                this.ViewState["AccSellIDHtb"] = value;
            }
        }

        //-------2014/12/10 ISV-HUNG Add Start -----------//
        public string ProductCDUsedClass
        {
            get
            {
                if (this._productCDUsed != int.Parse(M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON))
                {
                    return "hidden";
                }
                return string.Empty;
            }
        }
        //------2014/12/12 ISV-HUNG Add End----------//

        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
        /// <summary>
        /// IDRef
        /// </summary>
        public int IDRef
        {
            get { return this.GetValueViewState<int>("IDRef"); }
            set
            {
                this.ViewState["IDRef"] = value;
            }

        }

        /// <summary>
        /// NoRef
        /// </summary>
        public string NoRef
        {
            get { return this.GetValueViewState<string>("NoRef"); }
            set
            {
                this.ViewState["NoRef"] = value;
            }
        }
        //----------------2014/12/16 ISV-HUNG Add End----------------------//

        /// <summary>
        /// Has detail data
        /// </summary>
        public bool HasData
        {
            get { return this.GetValueViewState<bool>("HasData"); }
            set
            {
                base.ViewState["HasData"] = value;
            }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e">EventArgs</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Billing";
            base.FormSubTitle = "Select";

            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //------2014/12/15 ISV-HUNG Add Start----------//
            //Ref
            //this.btnBillRef.ServerClick += new EventHandler(btnBillRef_Click);
            //------2014/12/15 ISV-HUNG Add End----------//

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(ProcessData);

            this.AccSellIDHtb = new Hashtable();

        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.GetDefaultData();

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_SALES_DETAIL;
            }

            if (!base.IsPostBack)
            {
                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();
                    
                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            this.DataID = int.Parse(para["ID"].ToString());

                            this.ViewState["NoRef"] = para["NoRef"];
                            this.ViewState["IDRef"] = para["IDRef"];
                            this.ViewState["MesgID"] = para["MesgID"];

                            if (this.ViewState["MesgID"] != null)
                            {
                                this.SetMessage(string.Empty, this.ViewState["MesgID"].ToString(), "Billing", "Billing No.", this.ViewState["IDRef"], this.ViewState["NoRef"]);
                            }

                            //Show data
                            this.ShowHeaderData();

                            this.btnSearch_Click(null, null);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellService = new Sales_D_SellService(db);
                Sales_HService salesHService = new Sales_HService(db);

                var salesNo = this.txtSalesNo.Value;
                if (string.IsNullOrEmpty(salesNo))
                {
                    this.HasData = false;
                    this.chkSelectAll.Disabled = true;
                    return;
                }
                var quoteNo = this.txtQuotationNo.Value;
                var customerCd = this.txtCustomerCD.Value;

                var details = salesSellService.GetForBillingSelect(salesNo, quoteNo, customerCd, 0, M_Config_D.METHOD_VAT_EACH);
                this.chkSelectAll.Checked = false;
                this.HasData = true;
                if (details.Count == 0)
                {
                    this.HasData = false;
                    this.chkSelectAll.Disabled = true;
                    return;
                }

                var accH = salesHService.GetBySalesSellInternalID(details.FirstOrDefault().SalesSellIntenalID);
                if (accH != null)
                {
                    this.VersionUpdateDate = accH.VersionUpdateDate;
                }

                this.chkSelectAll.Disabled = false;

                var isCheckAll = true;
                this.AllBillingDone = true;
                foreach (var item in details)
                {
                    decimal remainQty = item.SalesQty - item.BillingQty;
                    item.SelectFlg = false;
                    if (this.AccSellIDHtb.ContainsKey(item.SalesSellIntenalID))
                    {
                        item.SelectFlg = true;
                        remainQty = (decimal)this.AccSellIDHtb[item.SalesSellIntenalID];
                    }
                    item.Qty = remainQty;

                    if (remainQty != 0)
                    {
                        this.AllBillingDone = false;
                        if (!item.SelectFlg)
                        {
                            isCheckAll = false;
                        }
                    }
                }
                this.chkSelectAll.Checked = isCheckAll;

                this.SetGridBackColor(details);

                //Save Detail data
                this.BillingSelections = details;
                this.rptDetail.DataSource = details;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.IsValidCreateBilling())
            {
                return;
            }
            if (this.CheckOverflowData())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_CREATE, Models.DefaultButton.No, false, "Billing");
        }

        /// <summary>
        /// Event Back Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, CommandEventArgs e)
        {
            base.BackPage();
        }

        //------2014/12/15 ISV-HUNG Add Start----------//
        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBillRef_Click(object sender, EventArgs e)
        {
            Hashtable currentPage = new Hashtable();
            currentPage.Add("ID", this.DataID);
            currentPage.Add("IDRef", this.IDRef);
            currentPage.Add("NoRef", this.NoRef);
            currentPage.Add("MesgID", M_Message.MSG_PROCESS_COMPLETED);

            Hashtable nextPage = new Hashtable();
            nextPage.Add("ID", this.hidBillID.Value);

            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_BILLING_SELECT);

        }
        //------2014/12/15 ISV-HUNG Add End----------//
        /// <summary>
        /// Process button
        /// </summary>
        /// <param name="source">object</param>
        /// <param name="e">RepeaterCommandEventArgs</param>
        protected void rptDetail_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                BillingSelection data = (BillingSelection)e.Item.DataItem;

                HtmlTableRow notRemainRow = (HtmlTableRow)e.Item.FindControl("NotRemaintQtyRow");
                HtmlTableRow remainRow = (HtmlTableRow)e.Item.FindControl("RemaintQtyRow");

                if (data.RemainQty == 0m)
                {
                    notRemainRow.Visible = true;
                    remainRow.Visible = false;
                }
                else
                {
                    notRemainRow.Visible = false;
                    remainRow.Visible = true;

                    //remainRow.BgColor = data.Color;
                    //Find Control
                    INumberTextBox txtQuantity = (INumberTextBox)e.Item.FindControl("txtQuantity");

                    txtQuantity.DecimalDigit = this.QuantityDecimal;
                    txtQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                    txtQuantity.MinimumValue = 0;
                }

            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void ProcessData(object sender, EventArgs e)
        {

            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                    //Insert Data
                    string billingNo = string.Empty;
                    //------2014/12/15 ISV-HUNG Add Start----------//
                    int billingID = 0;
                    //------2014/12/15 ISV-HUNG Add End----------//

                    //------2014/12/15 ISV-HUNG Edit Start----------//
                    //if (this.InsertInvoice(ref invoiceNo))
                    if (this.InsertBilling(ref billingNo, ref billingID))
                    //------2014/12/15 ISV-HUNG Edit End----------//
                    {
                        this.btnSearch_Click(null, null);

                        //------2014/12/15 ISV-HUNG Edit Start----------//
                        //this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Bill", "Bill No.", invoiceNo);
                        this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Billing", "Billing No.", billingID, billingNo);
                        //------2014/12/15 ISV-HUNG Edit End----------//

                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        this.IDRef = billingID;
                        this.NoRef = billingNo;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//
                    }
                    break;
                case Mode.Update:
                    //Update Data

                    break;
                default:
                    break;
            }

        }

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion

        #region Method

        ///// <summary>
        ///// Get Value
        ///// </summary>
        ///// <typeparam name="T">Type of value</typeparam>
        ///// <param name="property">property</param>
        ///// <returns></returns>
        //protected T GetValueViewState<T>(string property)
        //{
        //    var val = base.ViewState[property];
        //    if (val == null)
        //    {
        //        return default(T);
        //    }
        //    return (T)val;
        //}


        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Format quantity for display
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatQty(object qty)
        {
            if (qty != null)
            {
                return decimal.Parse(qty.ToString()).ToString(string.Format("N{0}", this.QuantityDecimal));
            }
            return string.Empty;
        }

        /// <summary>
        /// Get Default Data 
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                this.QuantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;
                this._defaultFractionType = (FractionType)int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                //-------2014/12/10 ISV-HUNG Edit Start -----------//
                //ProductCD Used
                this._productCDUsed = int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED));
                this._paymentMethod = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAYMENT_METHOD);
                //-------2014/12/10 ISV-HUNG Edit End -----------//
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            switch (this.Mode)
            {
                case Mode.Insert:
                    break;
                case Mode.Update:
                    this.txtCustomerCD.ReadOnly = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Get Sales
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Currency
                return sales_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Get Billing
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Billing_H GetBilling(int id)
        {
            using (DB db = new DB())
            {
                Billing_HService service = new Billing_HService(db);

                //Get Currency
                return service.GetByPK(id);
            }
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        private void ShowHeaderData()
        {
            using (DB db = new DB())
            {

                var sales = this.GetSales(this.DataID);
                this.txtSalesNo.Value = sales.SalesNo;
                this.txtQuotationNo.Value = sales.QuoteNo;
                this.txtCustomerCD.Value = EditDataUtil.ToFixCodeShow(sales.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);

                //-------2014/12/08 ISV-HUNG Add Start -----------//
                this.txtCustomerName.Value = sales.CustomerName;
                //-------2014/12/08 ISV-HUNG Add End -----------//

                this.txtSalesNo.ReadOnly = true;
                this.txtQuotationNo.ReadOnly = true;
                this.txtCustomerCD.ReadOnly = true;

                this.Mode = Utilities.Mode.Insert;

                //-------2014/12/08 ISV-HUNG Edit Start -----------//
                //CustomerService service = new CustomerService(db);
                //var dbCustomerCd = EditDataUtil.ToFixCodeDB(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                //var customer = service.GetByCustomerCD(dbCustomerCd);
                //if (customer != null)
                //{
                //    this.txtCustomerName.Value = customer.CustomerName1;
                //}
                //else
                //{
                //    this.txtCustomerName.Value = string.Empty;
                //}
                //-------2014/12/08 ISV-HUNG Edit End -----------//
            }
        }

        /// <summary>
        /// Show detail data on form
        /// </summary>
        private void ShowDetailData()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellService = new Sales_D_SellService(db);

                var salesNo = this.txtSalesNo.Value;
                var quoteNo = this.txtQuotationNo.Value;
                var customerCd = this.txtCustomerCD.Value;

                var details = salesSellService.GetForBillingSelect(salesNo, quoteNo, customerCd, 0, M_Config_D.METHOD_VAT_EACH);
                this.chkSelectAll.Checked = false;
                //if (details.Count == 0)
                //{
                //    this.chkSelectAll.Disabled = true;
                //    this.SetMessage(string.Empty, M_Message.MSG_DATA_EMPTY , "Data");
                //    this.txtCustomerCD.Focus();
                //    return;
                //}

                this.chkSelectAll.Disabled = false;
            }
        }

        /// <summary>
        /// Get Details data
        /// </summary>
        /// <param name="allOfthem"></param>
        /// <returns></returns>
        private IList<BillingSelection> GetDetails(bool allOfthem = false)
        {
            using (DB db = new DB())
            {
                IList<BillingSelection> uiItems = this.BillingSelections;
                foreach (RepeaterItem item in this.rptDetail.Items)
                {
                    HiddenField hdnSalesSellID = (HiddenField)item.FindControl("hdnSalesSellID");
                    var chkSelectFlg = (System.Web.UI.HtmlControls.HtmlInputCheckBox)item.FindControl("chkSelectFlg");
                    INumberTextBox txtQuantity = (INumberTextBox)item.FindControl("txtQuantity");
                    var salesSellID = int.Parse(hdnSalesSellID.Value);
                    var foundObj = uiItems.Where(s => s.SalesSellIntenalID == salesSellID).SingleOrDefault();
                    if (foundObj != null && txtQuantity != null)
                    {
                        foundObj.SelectFlg = chkSelectFlg.Checked;
                        foundObj.Qty = txtQuantity.Value;
                    }
                }
                return uiItems.Where(s => allOfthem || s.SelectFlg).ToList();
            }
        }

        /// <summary>
        /// Is Valid Creat Billing
        /// </summary>
        private bool IsValidCreateBilling()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellServive = new Sales_D_SellService(db);

                var salesNo = this.txtSalesNo.Value;
                var quoteNo = this.txtQuotationNo.Value;
                var customerCd = this.txtCustomerCD.Value;

                var dbItems = salesSellServive.GetForBillingSelect(salesNo, quoteNo, customerCd, 0, M_Config_D.METHOD_VAT_EACH);

                var uiItems = this.GetDetails(true);

                var selected = uiItems.Any(s => s.SelectFlg);
                if (!selected)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SELECT_ROW_DATA);
                    return false;
                }
                var vatFlg = VATFlg.Exclude;
                var vatPercent = 0m;
                var currencyId = 0;
                var index = 0;
                var haveError = false;
                for (int i = 0; i < uiItems.Count; i++)
                {
                    var invSec = uiItems[i];
                    if (invSec.SelectFlg)
                    {
                        if (index == 0)
                        {
                            vatFlg = invSec.VATFlag;
                            vatPercent = invSec.VATPercent;
                            currencyId = invSec.CurrencyID;
                        }
                        index++;
                        //check quantity required and value > 0
                        if (!invSec.Qty.HasValue)
                        {
                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", i + 1);
                            haveError = true;
                        }
                        if (invSec.Qty == 0m)
                        {
                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, i + 1);
                            haveError = true;
                        }
                        if (invSec.Qty > (invSec.SalesQty - invSec.BillingQty))
                        {
                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", (invSec.SalesQty - invSec.BillingQty).ToString(string.Format("N{0}", this.QuantityDecimal)), i + 1);
                            haveError = true;
                        }
                        //if (invSec.VATFlag != vatFlg)
                        //{
                        //    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_SELECT_ROW_SAME_VALUE, "VAT");
                        //    haveError = true;
                        //}
                        //if (invSec.VATPercent != vatPercent)
                        //{
                        //    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_SELECT_ROW_SAME_VALUE, "VAT(%)");
                        //    haveError = true;
                        //}
                        //if (currencyId != invSec.CurrencyID)
                        //{
                        //    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_SELECT_ROW_SAME_VALUE, "Currency");
                        //    haveError = true;
                        //}
                        if (!haveError)
                        {
                            var dbItem = dbItems.Where(s => s.SalesSellIntenalID == invSec.SalesSellIntenalID).SingleOrDefault();
                            if (dbItem != null)
                            {
                                if (invSec.Qty > (dbItem.SalesQty - dbItem.BillingQty))
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                                if (invSec.UpdDateSalesH != dbItem.UpdDateSalesH)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }
                            else
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                    }
                }
                this.rptDetail.DataSource = uiItems;
                this.rptDetail.DataBind();

                if (haveError)
                {
                    return false;
                }

            }
            return true;
        }

        /// <summary>
        /// Check Overflow Q'ty
        /// </summary>
        /// <returns></returns>
        private bool CheckOverflowData()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellService = new Sales_D_SellService(db);
                Currency_HService crcHService = new Currency_HService(db);

                var uiItems = this.GetDetails(true);

                var selected = uiItems.Any(s => s.SelectFlg);
                if (!selected)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SELECT_ROW_DATA);
                    return false;
                }

                #region GRID
                var index = 0;
                var sumTotal = 0m;
                var sumVat = 0m;
                M_Currency_H currencyH = null;
                var dec = 0;
                decimal maxValue = 0m;
                decimal maxQuantity = 0m;
                string numberFormat = string.Empty;
                bool haveError = false;
                for (int i = 0; i < uiItems.Count; i++)
                {
                    var invSec = uiItems[i];
                    if (invSec.SelectFlg)
                    {
                        if (currencyH == null)
                        {
                            currencyH = crcHService.GetByID(invSec.CurrencyID);
                        }

                        var unitPrice = invSec.UnitPrice;

                        dec = currencyH.DecimalType == ((int)ExchangeRateDecType.Decimal) ? 2 : 0;
                        numberFormat = string.Format("N{0}", dec);

                        var subTotal = Fraction.Round(this._defaultFractionType, unitPrice * invSec.Qty.GetValueOrDefault(), 2);
                        var subVat = Fraction.Round(this._defaultFractionType, (subTotal * invSec.VATPercent) / 100, 2);

                        //maxValue = dec > 0 ? MAX_UNIT_PRICE_DECIMAL : MAX_UNIT_PRICE_NOT_DECIMAL;
                        //if (unitPrice > maxValue)
                        //{
                        //    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), (i + 1));
                        //    haveError = true;
                        //}

                        maxValue = dec > 0 ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                        if (unitPrice != 0)
                        {
                            maxQuantity = Fraction.Round(this._defaultFractionType, (maxValue / Math.Abs(unitPrice)), dec);

                            if (invSec.Qty >= maxQuantity)
                            {
                                this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_GRID, "Q'ty", maxQuantity.ToString(numberFormat), (i + 1));
                                haveError = true;
                            }
                        }

                        //if (subTotal > maxValue)
                        //{
                        //    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(numberFormat), (i + 1));
                        //    haveError = true;
                        //}

                        //if (invSec.VATFlag == VATFlg.Exclude)
                        //{
                        //    maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                        //    if (subVat > maxValue)
                        //    {
                        //        this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total Vat", maxValue.ToString(numberFormat), (i + 1));
                        //        haveError = true;
                        //    }
                        //}

                        sumTotal += subTotal;
                        sumVat += subVat;

                        index++;
                    }
                }
                #endregion
                if (!haveError)
                {
                    maxValue = dec > 0 ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    if (sumTotal > maxValue)
                    {
                        var quantityAllow = Fraction.Round(this._defaultFractionType, (Math.Abs(sumTotal - maxValue) / Math.Abs(uiItems[0].UnitPrice)), dec);

                        quantityAllow = uiItems[0].Qty.Value - quantityAllow;

                        this.SetMessage(string.Format("txtQuantity_{0}", 0), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", quantityAllow.ToString(numberFormat), 1);
                        haveError = true;
                    }

                    //if (sumTotal > maxValue)
                    //{
                    //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(numberFormat));
                    //    haveError = true;
                    //}
                    //maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                    //if (sumVat > maxValue)
                    //{
                    //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(numberFormat));
                    //    haveError = true;
                    //}
                }

                this.rptDetail.DataSource = uiItems;
                this.rptDetail.DataBind();

                return haveError;
            }
        }

        /// <summary>
        /// Insert to Billing
        /// </summary>
        /// <returns></returns>
        private bool InsertBilling(ref string billingNo, ref int billingID)
        {
            try
            {
                if (!this.IsValidCreateBilling())
                {
                    return false;
                }
                if (this.CheckOverflowData())
                {
                    return false;
                }

                ///Get BillingNo
                using (DB db = new DB())
                {
                    billingNo = (new TNoService(db)).CreateNo(T_No.BillingNo);
                }                

                //Get data
                var details = this.GetDetails();

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Billing_HService invHservice = new Billing_HService(db);
                    Billing_CService invCService = new Billing_CService(db);
                    Billing_DService invDService = new Billing_DService(db);

                    Sales_HService accHService = new Sales_HService(db);
                    Sales_D_SellService accSService = new Sales_D_SellService(db);
                    CustomerService custService = new CustomerService(db);
                    Currency_HService crcHService = new Currency_HService(db);
                    Config_DService config_DService = new Config_DService(db);

                    var invHeader = new T_Billing_H();
                    var invDetails = new List<T_Billing_D>();

                    var firstItem = details.FirstOrDefault();
                    var currencyId = firstItem.CurrencyID;
                    var sysDate = db.NowDate;

                    var salesHeader = accHService.GetBySalesSellInternalID(firstItem.SalesSellIntenalID);

                    var methodVAT = salesHeader.MethodVat.ToString();

                    int gridNo = 0;
                    decimal total = 0;
                    decimal totalVAT = 0;
                    var vatRatio = 0m;
                    M_Currency_H currencyH = null;

                    foreach (var inv in details)
                    {
                        var accS = accSService.GetByInternalID(inv.SalesSellIntenalID);
                        if (currencyH == null)
                        {
                            currencyH = crcHService.GetByID(inv.CurrencyID);
                        }


                        var newItem = new T_Billing_D();

                        newItem.HID = 0;
                        newItem.No = ++gridNo;

                        newItem.SalesSellID = accS.InternalID;
                        newItem.ProductID = accS.ProductID;
                        newItem.ProductCD = accS.ProductCD;
                        newItem.ProductName = accS.ProductName;

                        newItem.Description = accS.Description;
                        newItem.UnitID = accS.UnitID;
                        newItem.Remark = accS.Remark;

                        newItem.UnitPrice = accS.UnitPrice;
                        newItem.Quantity = inv.Qty.GetValueOrDefault();

                        if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                        {
                            vatRatio = accS.VatRatio;
                            newItem.VatRatio = vatRatio;
                            newItem.VATType = accS.VatType;
                        }
                        else
                        {
                            newItem.VATType = 255;
                        }

                        var dec = currencyH.DecimalType == ((int)ExchangeRateDecType.Decimal) ? 2 : 0;
                        var subTotal = Fraction.Round(this._defaultFractionType, newItem.UnitPrice * newItem.Quantity, 2);
                        newItem.Total = subTotal;

                        if (newItem.VATType == (short)VATFlg.Exclude)
                        {
                            var subVat = Fraction.Round(this._defaultFractionType, (subTotal * vatRatio) / 100, 2);
                            newItem.Vat = subVat;
                            totalVAT += subVat;
                        }

                        total += subTotal;
                        invDetails.Add(newItem);
                    }

                    //-------2014/12/08 ISV-HUNG Edit Start -----------//
                    //var cust = custService.GetByCustomerCD(firstItem.CustomerCD);
                    //-------2014/12/08 ISV-HUNG Edit End -----------//

                    invHeader.BillingDate = db.NowDate;
                    var expiryDate = config_DService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Bill));
                    if (!expiryDate.HasValue)
                    {
                        invHeader.ExpiryDate = DEFAULT_DATE_TIME;
                    }
                    else
                    {
                        invHeader.ExpiryDate = invHeader.BillingDate.AddDays(expiryDate.Value);
                    }
                    invHeader.BillingNo = billingNo;
                    invHeader.QuoteNo = this.txtQuotationNo.Value;
                    invHeader.SalesNo = this.txtSalesNo.Value;
                    invHeader.IssuedFlag = 0;
                    invHeader.DeleteFlag = 0;

                    invHeader.CurrencyID = short.Parse(currencyId.ToString());
                    invHeader.MethodVat = salesHeader.MethodVat;

                    invHeader.BillingDate = sysDate;

                    invHeader.ApprovedCD = salesHeader.ApprovedCD;
                    invHeader.ApprovedName = salesHeader.ApprovedName;

                    invHeader.PreparedCD = salesHeader.PreparedCD;
                    invHeader.PreparedName = salesHeader.PreparedName;
                    invHeader.SubjectName = salesHeader.SubjectName;

                    invHeader.CustomerCD = EditDataUtil.ToFixCodeShow(salesHeader.CustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    invHeader.CustomerName = salesHeader.CustomerName;

                    invHeader.CustomerAddress1 = salesHeader.CustomerAddress1;
                    invHeader.CustomerAddress2 = salesHeader.CustomerAddress2;
                    invHeader.CustomerAddress3 = salesHeader.CustomerAddress3;
                    invHeader.Tel = salesHeader.Tel;
                    invHeader.FAX = salesHeader.FAX;

                    //----ISV-HUNG 2015/01/29
                    invHeader.RedInvoiceNo = string.Empty;
                    invHeader.RedInvoiceDate = DEFAULT_DATE_TIME;

                    if (EditDataUtil.ToFixCodeShow(firstItem.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW) != M_Customer.CUSTOMER_CODE_SUPPORT)
                    {
                        var cust = custService.GetByCustomerCD(firstItem.CustomerCD);

                        invHeader.TAXCode = cust.TAXCode;
                    }
                    else
                    {
                        invHeader.TAXCode = string.Empty;
                    }
                    invHeader.ContactPerson = salesHeader.ContactPerson;
                    
                    invHeader.PaymentMethod = short.Parse(this._paymentMethod);
                    invHeader.VatType = salesHeader.VatType;
                    invHeader.Total = total;

                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                    {
                        invHeader.Vat = totalVAT;
                        invHeader.GrandTotal = total + totalVAT;
                        invHeader.VatRatio = vatRatio;
                    }
                    else
                    {
                        var dec = currencyH.DecimalType == ((int)ExchangeRateDecType.Decimal) ? 2 : 0;
                        if (salesHeader.VatType == (short)VATFlg.Exclude)
                        {
                            totalVAT = Fraction.Round(this._defaultFractionType, (total * salesHeader.VatRatio) / 100, 2);
                            invHeader.Vat = totalVAT;
                            invHeader.GrandTotal = total + totalVAT;
                            invHeader.VatRatio = salesHeader.VatRatio;
                        }
                        else
                        {
                            invHeader.GrandTotal = total;
                        }
                    }
                    if (invHeader.GrandTotal != 0m)
                    {
                        invHeader.FinishFlag = 0;
                    }
                    else
                    {
                        invHeader.FinishFlag = 1;
                    }

                    invHeader.Memo = salesHeader.Memo;

                    invHeader.IssuedUID = 0;
                    invHeader.IssuedDate = DEFAULT_DATE_TIME;

                    invHeader.CreateUID = base.LoginInfo.User.ID;
                    invHeader.UpdateUID = base.LoginInfo.User.ID;

                    salesHeader.VersionUpdateDate = this.VersionUpdateDate;

                    if (accHService.UpdateVersion(salesHeader) == 0)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    //Insert Header
                    var billingId = invHservice.Insert(invHeader);

                    if (billingId > 0)
                    {
                        //------2014/12/15 ISV-HUNG Add Start----------//
                        billingID = billingId;
                        //------2014/12/15 ISV-HUNG Add End----------//

                        this.InsertBillingCondition(invCService, billingId);
                        foreach (var detail in invDetails)
                        {
                            detail.HID = billingId;
                            invDService.Insert(detail);
                        }
                    }

                    db.Commit();
                    return true;
                }
            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.BillingNo))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_SIZE_MAX_NO, "Billing No");
                }
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Constant.T_BILLING_H_UN))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, billingNo);
                    return false;
                }
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
        }

        /// <summary>
        /// Insert Billing condition
        /// </summary>
        private void InsertBillingCondition(Billing_CService service, int hid)
        {

            service.Delete(hid);
            var con = new T_Billing_C
            {
                HID = hid,
                Conditions = string.Empty,
            };
            service.Insert(con);
        }

        /// <summary>
        /// Set grid color
        /// </summary>
        private void SetGridBackColor(IList<BillingSelection> dataSource)
        {
            var first = dataSource.FirstOrDefault();

            VATFlg vatFlg = first.VATFlag;
            decimal vatPercent = first.VATPercent;
            bool isEvent = true;
            for (int i = 0; i < dataSource.Count; i++)
            {
                var invSec = dataSource[i];
                string color = string.Empty;
                if (invSec.RemainQty == 0m)
                {
                    color = String.Format("#{0:X2}{1:X2}{2:X2}", System.Drawing.Color.Silver.R, System.Drawing.Color.Silver.G, System.Drawing.Color.Silver.B);
                }
                else
                {
                    if (vatFlg == invSec.VATFlag && vatPercent == invSec.VATPercent)
                    {

                        color = string.Format("#{0:X2}{1:X2}{2:X2}", isEvent ? 215 : System.Drawing.Color.White.R,
                                                                      isEvent ? 228 : System.Drawing.Color.White.G,
                                                                      isEvent ? 242 : System.Drawing.Color.White.B);

                    }
                    else
                    {
                        isEvent = !isEvent;
                        vatFlg = invSec.VATFlag;
                        vatPercent = invSec.VATPercent;
                        color = string.Format("#{0:X2}{1:X2}{2:X2}", isEvent ? 215 : System.Drawing.Color.White.R,
                                                                      isEvent ? 228 : System.Drawing.Color.White.G,
                                                                      isEvent ? 242 : System.Drawing.Color.White.B);
                    }
                }
                invSec.Color = color;
            }
        }


        #endregion
    }
}
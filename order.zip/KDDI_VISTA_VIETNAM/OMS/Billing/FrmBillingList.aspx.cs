﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using OMS.DAC;
using OMS.Models;
using System.Collections;
using OMS.Utilities;
using NPOI.SS.UserModel;
using OMS.Reports.EXCEL;

namespace OMS.Billing
{
    /// <summary>
    /// Billing List
    /// TRAM
    /// </summary>
    public partial class FrmBillingList : FrmBaseList
    {
        #region Constant
        private const string EXCEL_BILLING_DOWNLOAD = "Billing_{0}.xls";
        private const string EXCEL_BILLING_CREATE_DOWNLOAD = "Create Billing List_{0}.xls";
        private const string EXCEL_BILLING_UNCREATE_DOWNLOAD = "Uncreate Billing List_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Variable

        string CONST_DANGER_TEXT = "Deleted";
        string CONST_WARNING_TEXT = "Expired";
        string CONST_DEPOSIT = "Deposit";

        #endregion

        #region Property

        /// <summary>
        /// Get or set BillingExcelFlag
        /// </summary>
        public string BillingExcelFlag
        {
            get { return (string)ViewState["BillingExcelFlag"]; }
            set { ViewState["BillingExcelFlag"] = value; }
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Billing";
            base.FormSubTitle = "List";

            // Sorting on the grid's header
            this.HeaderGrid.OnSortClick += Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // Paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;
            this.PagingHeader.DangerText = CONST_DANGER_TEXT;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Click the Download Excel button
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtSalesNo.MaxLength = T_Sales_H.SALES_NO_MAX_LENGTH;
            this.txtQuoteNo.MaxLength = T_Quote_H.QUOTE_NO_MAX_LENGTH;
            this.txtBillingNo.MaxLength = T_Billing_H.BILLING_NO_MAX_LENGTH;
            this.txtSubject.MaxLength = T_Billing_H.SUBJECT_NAME_MAX_LENGTH;
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
        }

        /// <summary>
        /// Page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.SetAuthority(FormId.Bill);
            if (!base._authority.IsBillingView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_MAIN_MENU;
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (base.PreviousPage != null)
                {
                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();

                    //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        this.ShowCondition(para);
                    }
                }

                //Show data on the grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.Collapse = string.Empty;
            }

            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnDownloadExcel_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var filename = string.Empty;
                if (this.BillingExcelFlag.Equals("CreateBillingList"))
                {
                    filename = string.Format(EXCEL_BILLING_CREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else if (this.BillingExcelFlag.Equals("Excel"))
                {
                    filename = string.Format(EXCEL_BILLING_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else
                {
                    filename = string.Format(EXCEL_BILLING_UNCREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Adding a new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save search conditions
            this.SaveCondition(null);
        }

        /// <summary>
        /// Adding a new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// View details of the row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(e.CommandArgument);
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            //Load data grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;

                //Load data grid
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                //Load data grid
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Billing Date
            if (!this.dtBillingDateFrm.IsEmpty && !this.dtBillingDateTo.IsEmpty)
            {
                if (this.dtBillingDateFrm.Value.Value.Date > this.dtBillingDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtBillingDateFrm.ID, M_Message.MSG_LESS_THAN_EQUAL, "Billing Date From", "Billing Date To");
                }
            }

            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptBillingList.DataSource = null;
                this.rptBillingList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Billing Date
            this.dtBillingDateFrm.Value = DateTime.Now.AddMonths(-3);
            //this.dtBillingDateTo.Value = DateTime.Now;
            this.dtBillingDateTo.Value = null;

            // Default data validate
            this.hdBillingDateFrmDefault.Value = this.dtBillingDateFrm.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            //this.hdBillingDateToDefault.Value = this.dtBillingDateTo.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            this.hdDeletedDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdFinishedDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            this.SetDataCombobox(this.cmbFinishedData, this.hdFinishedDefault.Value);
            this.SetDataCombobox(this.cmbDeletedData, this.hdDeletedDefault.Value);

            // Header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            base.DisabledLink(this.btnExcel, !base._authority.IsBillingExcel);
        }

        /// <summary>
        /// Save search conditions 
        /// </summary>
        private void SaveCondition(object id)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();

            currentPage.Add(this.txtBillingNo.ID, this.txtBillingNo.Value);
            currentPage.Add(this.txtSalesNo.ID, this.txtSalesNo.Value);
            currentPage.Add(this.txtQuoteNo.ID, this.txtQuoteNo.Value);
            currentPage.Add(this.dtBillingDateFrm.ID, this.dtBillingDateFrm.Value);
            currentPage.Add(this.dtBillingDateTo.ID, this.dtBillingDateTo.Value);
            currentPage.Add(this.txtCustomerCD.ID, this.txtCustomerCD.Value);

            M_Customer cus = this.GetCustomer(this.txtCustomerCD.Value);
            if (cus != null)
            {
                currentPage.Add(this.txtCustomerName.ID, cus.CustomerName1);
            }
            else
            {
                currentPage.Add(this.txtCustomerName.ID, string.Empty);
            }

            currentPage.Add(this.txtSubject.ID, this.txtSubject.Value);

            currentPage.Add(this.txtPreparedCD.ID, this.txtPreparedCD.Value);
            M_User user = this.GetUser(this.txtPreparedCD.Value);
            if (user != null)
            {
                currentPage.Add(this.txtPreparedName.ID, user.UserName1);
            }
            else
            {
                currentPage.Add(this.txtPreparedName.ID, string.Empty);
            }

            currentPage.Add(this.cmbDeletedData.ID, this.cmbDeletedData.SelectedValue);
            currentPage.Add(this.cmbFinishedData.ID, this.cmbFinishedData.SelectedValue);

            currentPage.Add("SalesNoReadOnly", this.txtSalesNo.ReadOnly);
            currentPage.Add("QuoteNoReadOnly", this.txtQuoteNo.ReadOnly);
            currentPage.Add("FinishedFlag", this.cmbFinishedData.SelectedValue);
            currentPage.Add("DeletedFlag", this.cmbDeletedData.SelectedValue);

            currentPage.Add("hdSalesNoDefaut", this.hdSalesNoDefaut.Value);
            currentPage.Add("hdQuotationNoDefaut", this.hdQuotationNoDefaut.Value);
            currentPage.Add("hdFinishedDataDefaultRef", this.hdFinishedDataDefaultRef.Value);
            currentPage.Add("hdDeletedDataDefaultRef", this.hdDeletedDataDefaultRef.Value);
            currentPage.Add("hdDeletedDefault", this.hdDeletedDefault.Value);
            currentPage.Add("hdFinishedDefault", this.hdFinishedDefault.Value);

            currentPage.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            currentPage.Add("CurrentPage", this.PagingHeader.CurrentPage);

            currentPage.Add("SortField", this.HeaderGrid.SortField);
            currentPage.Add("SortDirec", this.HeaderGrid.SortDirec);

            nextPage.Add("ID", id);

            //Next Page
            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_BILLING_LIST);
        }

        /// <summary>
        /// Show search conditions
        /// </summary>
        /// <param name="data">Data</param>
        private void ShowCondition(Hashtable data)
        {
            if (data.ContainsKey(this.txtBillingNo.ID))
            {
                this.txtBillingNo.Value = data[this.txtBillingNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtSalesNo.ID))
            {
                this.txtSalesNo.Value = data[this.txtSalesNo.ID].ToString();
                this.hdSalesNoDefaut.Value = data[this.txtSalesNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtQuoteNo.ID))
            {
                this.txtQuoteNo.Value = data[this.txtQuoteNo.ID].ToString();
                this.hdQuotationNoDefaut.Value = data[this.txtQuoteNo.ID].ToString();
            }

            this.dtBillingDateTo.Value = null;
            if (data.ContainsKey(this.dtBillingDateTo.ID))
            {
                if (data[this.dtBillingDateTo.ID] != null)
                {
                    this.dtBillingDateTo.Value = (DateTime)data[this.dtBillingDateTo.ID];
                }
            }

            this.dtBillingDateFrm.Value = null;
            if (data.ContainsKey(this.dtBillingDateFrm.ID))
            {
                if (data[this.dtBillingDateFrm.ID] != null)
                {
                    this.dtBillingDateFrm.Value = (DateTime)data[this.dtBillingDateFrm.ID];
                }
            }

            if (data.ContainsKey(this.txtCustomerCD.ID))
            {
                this.txtCustomerCD.Value = data[this.txtCustomerCD.ID].ToString();
            }

            if (data.ContainsKey(this.txtCustomerName.ID))
            {
                this.txtCustomerName.Value = data[this.txtCustomerName.ID].ToString();
            }

            if (data.ContainsKey(this.txtSubject.ID))
            {
                this.txtSubject.Value = data[this.txtSubject.ID].ToString();
            }

            if (data.ContainsKey(this.txtPreparedCD.ID))
            {
                this.txtPreparedCD.Value = data[this.txtPreparedCD.ID].ToString();
            }
            if (data.ContainsKey(this.txtPreparedName.ID))
            {
                this.txtPreparedName.Value = data[this.txtPreparedName.ID].ToString();
            }
            if (data.ContainsKey(this.cmbFinishedData.ID))
            {
                this.cmbFinishedData.SelectedValue = data[this.cmbFinishedData.ID].ToString();
            }

            if (data.ContainsKey(this.cmbDeletedData.ID))
            {
                this.cmbDeletedData.SelectedValue = data[this.cmbDeletedData.ID].ToString();
            }

            if (data.ContainsKey("SalesNoReadOnly"))
            {
                this.txtSalesNo.ReadOnly = (bool)data["SalesNoReadOnly"];
            }

            if (data.ContainsKey("QuoteNoReadOnly"))
            {
                this.txtQuoteNo.ReadOnly = (bool)data["QuoteNoReadOnly"];
            }

            if (data.ContainsKey("FinishedFlag"))
            {
                this.cmbFinishedData.SelectedValue = data["FinishedFlag"].ToString();
                this.hdFinishedDataDefaultRef.Value = data["FinishedFlag"].ToString();
            }

            if (data.ContainsKey("DeletedFlag"))
            {
                this.cmbDeletedData.SelectedValue = data["DeletedFlag"].ToString();
                this.hdDeletedDataDefaultRef.Value = data["DeletedFlag"].ToString();
            }

            if (data.ContainsKey("hdSalesNoDefaut"))
            {
                this.hdSalesNoDefaut.Value = data["hdSalesNoDefaut"].ToString();
            }

            if (data.ContainsKey("hdQuotationNoDefaut"))
            {
                this.hdQuotationNoDefaut.Value = data["hdQuotationNoDefaut"].ToString();
            }

            if (data.ContainsKey("hdFinishedDataDefaultRef"))
            {
                this.hdFinishedDataDefaultRef.Value = data["hdFinishedDataDefaultRef"].ToString();
            }

            if (data.ContainsKey("hdDeletedDataDefaultRef"))
            {
                this.hdDeletedDataDefaultRef.Value = data["hdDeletedDataDefaultRef"].ToString();
            }

            if (data.ContainsKey("hdDeletedDefault"))
            {
                this.hdDeletedDefault.Value = data["hdDeletedDefault"].ToString();
            }

            if (data.ContainsKey("hdFinishedDefault"))
            {
                this.hdFinishedDefault.Value = data["hdFinishedDefault"].ToString();
            }

            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = int.Parse(data["CurrentPage"].ToString());
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }

            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }

            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }
            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (this.CheckInput())
            {
                //Has error : end process
                return;
            }

            //Reload the Customer name and Prepared name for search conditions
            this.ReloadName();
            int totalRow = 0;

            IList<BillingHeaderResult> listResult;

            //Get model for search action
            BillingHeaderSearch model = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Billing_HService billingSer = new Billing_HService(db);
                //Get total row
                totalRow = billingSer.GetTotalRow(model);

                //Get the list for searching
                listResult = billingSer.GetListByConditions(model, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

                //SetRefInfo
                this.SetRefInfo(db, listResult);
            }

            //Show data
            if (listResult.Count == 0 || listResult == null)
            {
                this.rptBillingList.DataSource = null;
            }
            else
            {
                // Paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // Paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // Header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Bill No.", "Sales No.", "Bill Date", "Customer", "Subject", "N#Grand Total", "" });

                // Detail
                this.rptBillingList.DataSource = listResult;
            }

            this.rptBillingList.DataBind();
        }

        /// <summary>
        /// Reload the Customer name and Prepared name for search conditions
        /// </summary>
        private void ReloadName()
        {
            //CustomerName
            this.txtCustomerName.Value = null;
            M_Customer cus = this.GetCustomer(this.txtCustomerCD.Value);
            if (cus != null)
            {
                this.txtCustomerName.Value = cus.CustomerName1;
            }

            //PreparedName
            this.txtPreparedName.Value = null;
            M_User u = this.GetUser(this.txtPreparedCD.Value);
            if (u != null && u.ID != Constant.DEFAULT_ID
                          && u.StatusFlag == 0)
            {
                this.txtPreparedName.Value = u.UserName2;
            }
        }

        /// <summary>
        /// Get model for search action
        /// </summary>
        /// <returns></returns>
        private BillingHeaderSearch GetSearchModel()
        {
            BillingHeaderSearch ret = new BillingHeaderSearch();

            ret.BillingNo = this.txtBillingNo.Value;
            ret.SalesNo = this.txtSalesNo.Value;
            ret.QuoteNo = this.txtQuoteNo.Value;
            ret.BillingDateFrom = this.dtBillingDateFrm.Value;
            ret.BillingDateTo = this.dtBillingDateTo.Value;
            ret.CustomerCD = this.txtCustomerCD.Value;
            ret.PreparedCD = this.txtPreparedCD.Value;
            ret.SubjectName = this.txtSubject.Value;
            ret.FinishedFlg = short.Parse(this.cmbFinishedData.SelectedValue);
            ret.DeletedFlg = short.Parse(this.cmbDeletedData.SelectedValue);
            ret.FinishedName = this.cmbFinishedData.SelectedItem.Text;
            ret.DeletedName = this.cmbDeletedData.SelectedItem.Text;

            return ret;
        }

        /// <summary>
        /// Set the reference infomations of the purchase, delivery, billing  
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="listResult">List of the BillingHeaderResult model </param>
        private void SetRefInfo(DB db, IList<BillingHeaderResult> listResult)
        {
            foreach (BillingHeaderResult item in listResult)
            {
                var grandTotal = 0m;
                grandTotal = item.GrandTotal;

                var totalDeposit = item.TotalDeposit;
                if (grandTotal.Equals(0))
                {
                    item.DepositText = "<span class='label label-success' style='width:70px; display: inline-block'>" + CONST_DEPOSIT + "</span>";
                }
                else if (totalDeposit.Equals(0))
                {
                    item.DepositText = "<span class='label label-white' style='width:70px; display: inline-block'>" + CONST_DEPOSIT + "</span>";
                }
                else
                {
                    if (grandTotal.Equals(totalDeposit))
                    {
                        item.DepositText = "<span class='label label-success' style='width:70px; display: inline-block'>" + CONST_DEPOSIT + "</span>";
                    }
                    else
                    {
                        item.DepositText = "<span class='label label-master' style='width:70px; display: inline-block'>" + CONST_DEPOSIT + "</span>";
                    }
                }
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUser(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #endregion

        #region Set

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Format Customer Code
        /// </summary>
        /// <param name="in1">Customer CD</param>
        /// <returns>Customer CD</returns>
        [System.Web.Services.WebMethod]
        public static string ShowCustomerName(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string ShowUserName(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            this.BillingExcelFlag = "Excel";
            BillingListExcel excel = new BillingListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);

            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBillingList_Click(object sender, CommandEventArgs e)
        {
            this.BillingExcelFlag = "CreateBillingList";
            CreateBillingListExcel excel = new CreateBillingListExcel();
            excel.billingDateFrom = this.dtBillingDateFrm.Value;
            excel.billingDateTo = this.dtBillingDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnUncreatePOList Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUncreateBillingList_Click(object sender, CommandEventArgs e)
        {
            this.BillingExcelFlag = "UncreateBillingList";
            UncreateBillingListExcel excel = new UncreateBillingListExcel();
            excel.billingDateFrom = this.dtBillingDateFrm.Value;
            excel.billingDateTo = this.dtBillingDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections;
using System.Linq;

using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using NPOI.SS.UserModel;
using OMS.Reports.EXCEL;

namespace OMS.BIReport
{
    public partial class FrmContractPeriodList : FrmBaseList
    {
        #region Constant
           private const string EXCEL_REPORT_DOWNLOAD = "ContractPeriod_{0}.xls";
           private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Property

        /// <summary>
        /// Get or set DeliveryExcelFlag
        /// </summary>
        public string DeliveryExcelFlag
        {
            get { return (string)ViewState["DeliveryExcelFlag"]; }
            set { ViewState["DeliveryExcelFlag"] = value; }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return this.GetValueViewState<int>("QuantityDecimal"); }
            private set
            {
                this.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Contract Period";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = "Expired";
            this.PagingHeader.WarningText = "Within 1 Month";

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
        }

        /// <summary>
        /// Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.SetAuthority(FormId.ContractPeriod);
            //Check Authority
            if (!base._authority.IsContractPeriodView)
            {
                Response.Redirect(FrmBase.URL_REPORT_BI_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_REPORT_BI_MENU;
            }

            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                this.QuantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    base.DisabledLink(this.btnExcel, !base._authority.IsContractPeriodExcel);

                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();

                    //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];
                        this.ShowCondition(para);
                    }
                }
               
                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }

            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnSearch Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                string filename = string.Format(EXCEL_REPORT_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(e.CommandArgument);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Format quantity for display
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatQty(object qty)
        {
            if (qty != null)
            {
                return decimal.Parse(qty.ToString()).ToString(string.Format("N{0}", this.QuantityDecimal));
            }
            return string.Empty;
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Reset Name
        /// </summary>
        private void ResetName()
        {
            //CustomerName
            this.txtCustomerName.Value = null;
            M_Customer cus = this.GetCustomerModel(this.txtCustomerCD.Value);
            if (cus != null)
            {
                this.txtCustomerName.Value = cus.CustomerName1;
            }
        }


        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Quote Date
            this.dtStartDateFrom.Value = null;
            this.dtStartDateTo.Value = null;
            this.dtEndDateFrom.Value = DateTime.Now.AddMonths(-1);
            this.dtEndDateTo.Value = DateTime.Now.AddMonths(3);

            //ContractType
            this.InitCombobox(this.cmbContractType, "-1");
            
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            base.DisabledLink(this.btnExcel, !base._authority.IsContractPeriodExcel);

        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE)
                                 .Where(s => s.Value != M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY)
                                 .ToList();
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();

            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD,true);
                
            }   
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition(object id)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();

            currentPage.Add(this.cmbContractType.ID, this.cmbContractType.SelectedValue);
            currentPage.Add(this.dtStartDateFrom.ID, this.dtStartDateFrom.Value);
            currentPage.Add(this.dtStartDateTo.ID, this.dtStartDateTo.Value);

            currentPage.Add(this.dtEndDateFrom.ID, this.dtEndDateFrom.Value);
            currentPage.Add(this.dtEndDateTo.ID, this.dtEndDateTo.Value);
            currentPage.Add(this.txtCustomerCD.ID, this.txtCustomerCD.Value);

            currentPage.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            currentPage.Add("CurrentPage", this.PagingHeader.CurrentPage);

            currentPage.Add("SortField", this.HeaderGrid.SortField);
            currentPage.Add("SortDirec", this.HeaderGrid.SortDirec);

            nextPage.Add("ID", id);

            //Next Page
            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_CONTRACT_PERIOD_LIST);
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            if (data.ContainsKey(this.cmbContractType.ID))
            {
                this.cmbContractType.SelectedValue = data[this.cmbContractType.ID].ToString();
            }

            this.dtStartDateFrom.Value = null;
            if (data.ContainsKey(this.dtStartDateFrom.ID))
            {
                if (data[this.dtStartDateFrom.ID] != null)
                {
                    this.dtStartDateFrom.Value = (DateTime)data[this.dtStartDateFrom.ID];
                }
            }

            this.dtStartDateTo.Value = null;
            if (data.ContainsKey(this.dtStartDateTo.ID))
            {
                if (data[this.dtStartDateTo.ID] != null)
                {
                    this.dtStartDateTo.Value = (DateTime)data[this.dtStartDateTo.ID];
                }
            }

            this.dtEndDateFrom.Value = null;
            if (data.ContainsKey(this.dtEndDateFrom.ID))
            {
                if (data[this.dtEndDateFrom.ID] != null)
                {
                    this.dtEndDateFrom.Value = (DateTime)data[this.dtEndDateFrom.ID];
                }
            }

            this.dtEndDateTo.Value = null;
            if (data.ContainsKey(this.dtEndDateTo.ID))
            {
                if (data[this.dtEndDateTo.ID] != null)
                {
                    this.dtEndDateTo.Value = (DateTime)data[this.dtEndDateTo.ID];
                }
            }

            if (data.ContainsKey(this.txtCustomerCD.ID))
            {
                this.txtCustomerCD.Value = data[this.txtCustomerCD.ID].ToString();
            }
          

            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = int.Parse(data["CurrentPage"].ToString());
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }

            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }

            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }
            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }

        }

        /// <summary>
        /// Get model input for search action
        /// </summary>
        /// <returns></returns>
        private ContractPeriodSearch GetSearchModel()
        {
            ContractPeriodSearch ret = new ContractPeriodSearch();
            ret.StartDateTo = this.dtStartDateTo.Value;
            ret.EndDateTo = this.dtEndDateTo.Value;
            ret.StartDateFrom = this.dtStartDateFrom.Value;
            ret.EndDateFrom = this.dtEndDateFrom.Value;
            ret.CustomerCD = this.txtCustomerCD.Value;
            ret.ContractType = short.Parse(this.cmbContractType.SelectedValue);
            ret.ContractTypeName = this.cmbContractType.SelectedItem.Text;

            return ret;
        }

        /// <summary>
        /// Load data for grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }
            this.ResetName();

            int totalRow = 0;

            IList<ContractPeriodResult> listResult;
            ContractPeriodSearch modelInput = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Delivery_HService shipHService = new Delivery_HService(db);
                totalRow = shipHService.GetTotalContractPeriod(modelInput);
                listResult = shipHService.GetContractPeriodByCond(modelInput, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listResult.Count == 0)
            {
                this.rptContractPeriodList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Customer", "Sales Date", "Sales No.", "Product/Service Name", "Contract Type", "Start Date", "End Date" });

                // detail
                this.rptContractPeriodList.DataSource = listResult;
            }

            this.rptContractPeriodList.DataBind();
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (this.dtStartDateFrom.Value != null && this.dtStartDateTo.Value != null)
            {
                if (this.dtStartDateFrom.Value.Value.Date > this.dtStartDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtStartDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Contract Start Date From", "Contract Start Date To");
                }
            }

            if (this.dtEndDateFrom.Value != null && this.dtEndDateTo.Value != null)
            {
                if (this.dtEndDateFrom.Value.Value.Date > this.dtEndDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtEndDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Contract End Date From", "Contract End Date To");
                }
            }

            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptContractPeriodList.DataSource = null;
                this.rptContractPeriodList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD, false);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        
        #endregion

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            this.DeliveryExcelFlag = "Excel";
            ContractPeriodListExcel excel = new ContractPeriodListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);

            }

            this.btnSearch_Click(null, null);
        }

        #endregion
    }
}
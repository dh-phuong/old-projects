﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;

using NPOI.SS.UserModel;

using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using OMS.Reports.EXCEL;

namespace OMS.Sales
{
    /// <summary>
    /// SalesList Form
    /// TRAM
    /// </summary>
    public partial class FrmSalesList : FrmBaseList
    {
        #region Constants
        private const string CONST_DANGER_TEXT = "Deleted";
        private string CONST_WARNING_TEXT = "Expired";

        private const string CONST_BILL = "Billing";
        private const string CONST_DELIVERY = "Delivery";
        private const string CONST_PURCHASE = "Purchase";

        private const string EXCEL_SALES_DOWNLOAD = "Sales_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Property
        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return base.GetValueViewState<string>("Collapse"); }
            set { 
                base.ViewState["Collapse"] = value; 
            }
        }

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public string DataID
        {
            get { return base.GetValueViewState<string>("DataID"); }
            set { 
                base.ViewState["DataID"] = value; 
            }
        }
        #endregion
        
        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Sales Order";
            base.FormSubTitle = "List";

            // Header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // Paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = CONST_DANGER_TEXT;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtSalesNo.MaxLength = T_Sales_H.SALES_NO_MAX_LENGTH;
            this.txtQuoteNo.MaxLength = T_Quote_H.QUOTE_NO_MAX_LENGTH;
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSale1CD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSale2CD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSubject.MaxLength = T_Sales_H.SUBJECT_NAME_MAX_LENGTH;
        }

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Sales);

            //Check authority
            if (!base._authority.IsSalesView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_MAIN_MENU;
            } 

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();

                    //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        this.ShowCondition(para);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.Collapse = string.Empty;
            }

            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnDownloadExcel_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var filename = string.Format(EXCEL_SALES_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }
        
        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(null);
        }

        /// <summary>
        /// Adding a new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Back page
            base.BackPage();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(e.CommandArgument);
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            //Load data grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;

                //Load data grid
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                //Load data grid
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Sales Date
            if (!this.dtSalesDateFrm.IsEmpty && !this.dtSalesDateTo.IsEmpty)
            {
                if (this.dtSalesDateFrm.Value.Value.Date > this.dtSalesDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtSalesDateFrm.ID, M_Message.MSG_LESS_THAN_EQUAL, "Sales Date From", "Sales Date To");
                }
            }

            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptSalesList.DataSource = null;
                this.rptSalesList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Sales Date
            this.dtSalesDateFrm.Value = DateTime.Now.AddMonths(-3);
            //this.dtSalesDateTo.Value = DateTime.Now;
            this.dtSalesDateTo.Value = null;

            // Default data valide
            this.hdSalesDateFrmDefault.Value = this.dtSalesDateFrm.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            //this.hdSalesDateToDefault.Value = this.dtSalesDateTo.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);

            this.hdLostDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdFinishedDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO); 

            // Default data valid
            this.SetDataCombobox(this.cmbFinishedData, this.hdFinishedDefault.Value);
            this.SetDataCombobox(this.cmbLostData, this.hdLostDefault.Value);
            
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            //Disable button
            base.DisabledLink(this.btnNew, !base._authority.IsSalesNew);
            base.DisabledLink(this.btnExcel, !base._authority.IsSalesExcel);
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }
        
        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition(object id)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();
            
            currentPage.Add(this.txtSalesNo.ID, this.txtSalesNo.Value);
            currentPage.Add(this.txtQuoteNo.ID, this.txtQuoteNo.Value);
            currentPage.Add(this.dtSalesDateFrm.ID, this.dtSalesDateFrm.Value);
            currentPage.Add(this.dtSalesDateTo.ID, this.dtSalesDateTo.Value);
            currentPage.Add(this.txtCustomerCD.ID, this.txtCustomerCD.Value);
            currentPage.Add(this.txtCustomerName.ID, this.txtCustomerName.Value);
            currentPage.Add(this.txtSubject.ID, this.txtSubject.Value);
            currentPage.Add(this.txtPreparedCD.ID, this.txtPreparedCD.Value);
            currentPage.Add(this.txtPreparedName.ID, this.txtPreparedName.Value);
            currentPage.Add(this.txtSale1CD.ID, this.txtSale1CD.Value);
            currentPage.Add(this.txtSale1Name.ID, this.txtSale1Name.Value);
            currentPage.Add(this.txtSale2CD.ID, this.txtSale2CD.Value);
            currentPage.Add(this.txtSale2Name.ID, this.txtSale2Name.Value);

            currentPage.Add("SalesNoReadOnly", this.txtSalesNo.ReadOnly);
            currentPage.Add("QuoteNoReadOnly", this.txtQuoteNo.ReadOnly);
            currentPage.Add("DataID", this.DataID);
            currentPage.Add("FinishedFlag", this.cmbFinishedData.SelectedValue);
            currentPage.Add("DeletedFlag", this.cmbLostData.SelectedValue);

            currentPage.Add("hdSalesNoDefaut", this.hdSalesNoDefaut.Value);
            currentPage.Add("hdQuotationNoDefaut", this.hdQuotationNoDefaut.Value);
            currentPage.Add("hdFinishedSalesDataDefault", this.hdFinishedSalesDataDefault.Value);
            currentPage.Add("hdDeletedSalesDataDefault", this.hdDeletedSalesDataDefault.Value);
            currentPage.Add("hdLostDefault", this.hdLostDefault.Value);
            currentPage.Add("hdFinishedDefault", this.hdFinishedDefault.Value);
            
            currentPage.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            currentPage.Add("CurrentPage", this.PagingHeader.CurrentPage);

            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            currentPage.Add("SortField", this.HeaderGrid.SortField);
            currentPage.Add("SortDirec", this.HeaderGrid.SortDirec);
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//

            nextPage.Add("ID", id);

            //Next Page
            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_SALES_LIST);
        }

        /// <summary>
        /// get condition Save
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            //txtSalesNo
            if (data.ContainsKey(this.txtSalesNo.ID))
            {
                this.txtSalesNo.Value = string.Format("{0}", data[this.txtSalesNo.ID]);
                this.hdSalesNoDefaut.Value = this.txtSalesNo.Value;
            }

            //txtQuoteNo
            if (data.ContainsKey(this.txtQuoteNo.ID))
            {
                this.txtQuoteNo.Value = string.Format("{0}",data[this.txtQuoteNo.ID]);
                this.hdQuotationNoDefaut.Value = this.txtQuoteNo.Value;
            }

            //dtSalesDateFrm
            this.dtSalesDateFrm.Value = null;
            if (data.ContainsKey(this.dtSalesDateFrm.ID))
            {
                if (data[this.dtSalesDateFrm.ID] != null)
                {
                    this.dtSalesDateFrm.Value = (DateTime)data[this.dtSalesDateFrm.ID];
                }
            }
            //else
            //{
            //    this.dtSalesDateFrm.Value = null;
            //}

            //dtSalesDateTo
            this.dtSalesDateTo.Value = null;
            if (data.ContainsKey(this.dtSalesDateTo.ID))
            {
                if (data[this.dtSalesDateTo.ID] != null)
                {
                    this.dtSalesDateTo.Value = (DateTime)data[this.dtSalesDateTo.ID];
                }
            }
            //else 
            //{
            //    this.dtSalesDateTo.Value = null;
            //}

            //txtCustomerCD
            if (data.ContainsKey(this.txtCustomerCD.ID))
            {
                this.txtCustomerCD.Value = string.Format("{0}",data[this.txtCustomerCD.ID]);
            }

            //txtCustomerName
            if (data.ContainsKey(this.txtCustomerName.ID))
            {
                this.txtCustomerName.Value = string.Format("{0}",data[this.txtCustomerName.ID]);
            }

            //txtSubject
            if (data.ContainsKey(this.txtSubject.ID))
            {
                this.txtSubject.Value = string.Format("{0}",data[this.txtSubject.ID]);
            }

            //txtPreparedCD
            if (data.ContainsKey(this.txtPreparedCD.ID))
            {
                this.txtPreparedCD.Value =string.Format("{0}", data[this.txtPreparedCD.ID]);
            }

            //txtPreparedName
            if (data.ContainsKey(this.txtPreparedName.ID))
            {
                this.txtPreparedName.Value = string.Format("{0}",data[this.txtPreparedName.ID]);
            }

            //txtSale1CD
            if (data.ContainsKey(this.txtSale1CD.ID))
            {
                this.txtSale1CD.Value = string.Format("{0}",data[this.txtSale1CD.ID]);
            }

            //txtSale1Name
            if (data.ContainsKey(this.txtSale1Name.ID))
            {
                this.txtSale1Name.Value = string.Format("{0}",data[this.txtSale1Name.ID]);
            }

            //txtSale2CD
            if (data.ContainsKey(this.txtSale2CD.ID))
            {
                this.txtSale2CD.Value = string.Format("{0}",data[this.txtSale2CD.ID]);
            }

            //txtSale2Name
            if (data.ContainsKey(this.txtSale2Name.ID))
            {
                this.txtSale2Name.Value = string.Format("{0}",data[this.txtSale2Name.ID]);
            }

            //SalesNoReadOnly
            if (data.ContainsKey("SalesNoReadOnly"))
            {
                this.txtSalesNo.ReadOnly = (bool)data["SalesNoReadOnly"];
            }

            //QuoteNoReadOnly
            if (data.ContainsKey("QuoteNoReadOnly"))
            {
                this.txtQuoteNo.ReadOnly = (bool)data["QuoteNoReadOnly"];
            }

            //DataID
            if (data.ContainsKey("DataID"))
            {
                this.DataID = string.Format("{0}",data["DataID"]);
            }

            //FinishedFlag
            if (data.ContainsKey("FinishedFlag"))
            {
                this.cmbFinishedData.SelectedValue = string.Format("{0}",data["FinishedFlag"]);
                this.hdFinishedSalesDataDefault.Value = string.Format("{0}", data["FinishedFlag"]);
            }

            //DeletedFlag
            if (data.ContainsKey("DeletedFlag"))
            {
                this.cmbLostData.SelectedValue = string.Format("{0}",data["DeletedFlag"]);
                this.hdDeletedSalesDataDefault.Value = string.Format("{0}", data["DeletedFlag"]);
            }

            //hdSalesNoDefaut
            if (data.ContainsKey("hdSalesNoDefaut"))
            {
                this.hdSalesNoDefaut.Value = string.Format("{0}",data["hdSalesNoDefaut"]);
            }

            //hdQuotationNoDefaut
            if (data.ContainsKey("hdQuotationNoDefaut"))
            {
                this.hdQuotationNoDefaut.Value = string.Format("{0}",data["hdQuotationNoDefaut"]);
            }

            //hdFinishedSalesDataDefault
            if (data.ContainsKey("hdFinishedSalesDataDefault"))
            {
                this.hdFinishedSalesDataDefault.Value = string.Format("{0}",data["hdFinishedSalesDataDefault"]);
            }

            //hdDeletedSalesDataDefault
            if (data.ContainsKey("hdDeletedSalesDataDefault"))
            {
                this.hdDeletedSalesDataDefault.Value = string.Format("{0}",data["hdDeletedSalesDataDefault"]);
            }

            //hdLostDefault
            if (data.ContainsKey("hdLostDefault"))
            {
                this.hdLostDefault.Value = string.Format("{0}",data["hdLostDefault"]);
            }

            //hdFinishedDefault
            if (data.ContainsKey("hdFinishedDefault"))
            {
                this.hdFinishedDefault.Value = string.Format("{0}",data["hdFinishedDefault"]);
            }

            //CurrentPage
            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = int.Parse(string.Format("{0}",data["CurrentPage"]));

                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }

            //NumRowOnPage
            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = int.Parse(string.Format("{0}",data["NumRowOnPage"]));
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }

            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }
            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (this.CheckInput())
            {
                //Has error : end process
                return;
            }

            //Reload the Customer name and Prepared name for search conditions
            this.ReloadName();
            int totalRow = 0;

            IList<SalesHeaderResult> listResult;

            //Get model for search action
            SalesHeaderSearch model = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Sales_HService salesHService = new Sales_HService(db);
                //Get total row
                totalRow = salesHService.GetTotalRow(model);

                //Get the list for searching
                listResult = salesHService.GetListForSearch(model, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

                //Set color for the status: Finish, Purchase, Billing, Bill
                this.SetStatusColor(db, listResult);
            }

            //Show data
            if (listResult.Count == 0 || listResult==null)
            {
                this.rptSalesList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Sales No.", "Quote No.", "S.O Date", "Customer", "Subject", "N#Grand Total", "" });
                // detail
                this.rptSalesList.DataSource = listResult;
            }

            this.rptSalesList.DataBind();
            
        }
               
        /// <summary>
        /// Get model for search action
        /// </summary>
        /// <returns></returns>
        private SalesHeaderSearch GetSearchModel()
        {
            SalesHeaderSearch ret = new SalesHeaderSearch();

            ret.SalesNo = this.txtSalesNo.Value;
            ret.QuoteNo = this.txtQuoteNo.Value;
            ret.SalesDateFrom = this.dtSalesDateFrm.Value;
            ret.SalesDateTo = this.dtSalesDateTo.Value;
            ret.CustomerCD = this.txtCustomerCD.Value;
            ret.PreparedCD = this.txtPreparedCD.Value;
            ret.Sale1CD = this.txtSale1CD.Value;
            ret.Sale2CD = this.txtSale2CD.Value;
            ret.SubjectName = this.txtSubject.Value;
            ret.FinishedFlg = short.Parse(this.cmbFinishedData.SelectedValue);
            ret.FinishedName = this.cmbFinishedData.SelectedItem.Text;
            ret.FailedFlg = short.Parse(this.cmbLostData.SelectedValue);
            ret.FailedName = this.cmbLostData.SelectedItem.Text;

            return ret;

        }

        /// <summary>
        /// Reload the Customer name and Prepared name for search conditions
        /// </summary>
        private void ReloadName()
        {
            //CustomerName
            this.txtCustomerName.Value = null;
            M_Customer cus = this.GetCustomer(this.txtCustomerCD.Value);
            if (cus != null)
            {
                this.txtCustomerName.Value = cus.CustomerName1;
            }

            //PreparedName
            this.txtPreparedName.Value = null;
            M_User user = this.GetUser(this.txtPreparedCD.Value);
            if (user != null && user.ID != Constant.DEFAULT_ID
                && user.StatusFlag == 0)
            {
                this.txtPreparedName.Value = user.UserName2;
            }

            //Sale1Name
            this.txtSale1Name.Value = null;
            M_User sale1 = this.GetUser(this.txtSale1CD.Value);
            if (sale1 != null && sale1.ID != Constant.DEFAULT_ID
                && sale1.StatusFlag == 0)
            {
                this.txtSale1Name.Value = sale1.UserName2;
            }

            //Sale2Name
            this.txtSale2Name.Value = null;
            M_User sale2 = this.GetUser(this.txtSale2CD.Value);
            if (sale2 != null && sale2.ID != Constant.DEFAULT_ID
                && sale2.StatusFlag == 0)
            {
                this.txtSale2Name.Value = sale2.UserName2;
            }
        }

        /// <summary>
        /// Set color for the status: Finish, Purchase, Billing, Bill 
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="listResult">List of the SalesHeaderResult model </param>
        private void SetStatusColor(DB db, IList<SalesHeaderResult> listResult)
        {
            //-- 0 CAN NOT CREATE
            //-- 1 NOT YET CREATE
            //-- 2 HAVE DATA
            //-- 3 ONE FINISH
            //-- 4 CREATE ALL DATA
            //-- 5 ALL FINISH
            foreach (SalesHeaderResult item in listResult)
            {
                //Check PO status
                switch (item.StatusPO)
                {
                    case 0:
                        item.PurchaseText = string.Empty;
                        break;
                    case 1:
                    case 2:
                    case 3:
                        item.PurchaseText = "<span class='label label-white' style='width:70px; display: inline-block'>" + CONST_PURCHASE + "</span>";
                        break;
                    case 4:                    
                        item.PurchaseText = "<span class='label label-master' style='width:70px; display: inline-block'>" + CONST_PURCHASE + "</span>";
                        break;
                    default:
                        item.PurchaseText = "<span class='label label-warning' style='width:70px; display: inline-block'>" + CONST_PURCHASE + "</span>";
                        break;
                }

                //Check delivery status
                switch (item.StatusDelivery)
                {
                    case 0:
                        item.DeliveryText = string.Empty;
                        break;
                    case 1:
                    case 2:
                    case 3:
                        item.DeliveryText = "<span class='label label-white' style='width:70px; display: inline-block'>" + CONST_DELIVERY + "</span>";
                        break;
                    case 4:                    
                        item.DeliveryText = "<span class='label label-master' style='width:70px; display: inline-block'>" + CONST_DELIVERY + "</span>";
                        break;
                    default:
                        item.DeliveryText = "<span class='label label-delivery' style='width:70px; display: inline-block'>" + CONST_DELIVERY + "</span>";
                        break;

                }

                //checked biiling status
                switch (item.StatusBilling)
                {
                    case 0:
                        item.BillingText = string.Empty;
                        break;
                    case 1:
                    case 2:
                    case 3:
                        item.BillingText = "<span class='label label-white' style='width:70px; display: inline-block'>" + CONST_BILL + "</span>";
                        break;
                    case 4:                    
                        item.BillingText = "<span class='label label-master' style='width:70px; display: inline-block'>" + CONST_BILL + "</span>";
                        break;
                    default:
                        item.BillingText = "<span class='label label-success' style='width:70px; display: inline-block'>" + CONST_BILL + "</span>";
                        break;

                }
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUser(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #region Web Methods
        /// <summary>
        /// Format Customer Code
        /// </summary>
        /// <param name="in1">Customer CD</param>
        /// <returns>Customer CD</returns>
        [System.Web.Services.WebMethod]
        public static string ShowCustomerName(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string ShowUserName(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion

        #endregion

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            SalesListExcel excel = new SalesListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        #endregion
    }
}
﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.IO;

using OMS.Models;
using OMS.Controls;
using OMS.Utilities;
using OMS.DAC;

using Microsoft.Reporting.WebForms;
using NPOI.SS.UserModel;

using OMS.Reports.EXCEL;
using OMS.Reports.PDF;

namespace OMS.Sales
{
    /// <summary>
    /// Class Sales Detail
    /// Create Date: 2014/08/05
    /// Create Author: ISV-HUNG
    /// </summary>
    public partial class FrmSalesDetail : FrmBaseDetail
    {
        #region Enum
        /// <summary>
        /// Referent status
        /// </summary>
        private enum Referent
        {
            NotRef = 0,
            IncompleteRef,
            CompletedRef
        }
        #endregion

        #region Constants
        /// <summary>
        /// Default date time
        /// Create Date: 2014/08/22
        /// Create Author: ISV-HUNG
        /// </summary>
        private DateTime DATE_TIME_DEFAULT = new DateTime(1900, 1, 1);


        private const string PDF_SALES_DOWNLOAD = "Sales_{0}.pdf";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Variable
        /// <summary>
        /// Currency list
        /// </summary>
        private IList<DropDownModel> _currencyList;

        /// <summary>
        /// MethodVatList
        /// </summary>
        private IList<DropDownModel> _methodVatList;

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string _defaultMethodVat;

        /// <summary>
        /// FractionType
        /// </summary>
        private FractionType _fractionType;

        /// <summary>
        /// UnitList
        /// </summary>
        private IList<DropDownModel> _unitList;

        /// <summary>
        /// VatTypeList
        /// </summary>
        private IList<DropDownModel> _vatTypeList;
        private IList<DropDownModel> _vatTypeListEmpty = new List<DropDownModel>();

        /// <summary>
        /// DefaultVatType
        /// </summary>
        private string _defaultVatType;

        /// <summary>
        /// Index Sell
        /// </summary>
        private int _indexSell;

        /// <summary>
        /// Focus controls ID
        /// </summary>
        public string focusControlsID = "";

        /// <summary>
        /// DefaultProfit
        /// </summary>
        private string _defaultProfit;
        private string _profitSetting;

        /// <summary>
        /// MethodVATEach Use for AJAX
        /// </summary>
        public string MethodVATEach
        {
            get
            {
                return M_Config_D.METHOD_VAT_EACH;
            }
        }

        /// <summary>
        /// ProductCdSupport
        /// </summary>
        public string productCdSupport
        {
            get
            {
                return M_Product.PRODUCT_CODE_SUPPORT;
            }
        }

        //-------2014/12/08 ISV-HUNG Add Start -----------//
        /// <summary>
        /// CustomerCdSupport
        /// </summary>
        public string customerCdSupport
        {
            get
            {
                return M_Customer.CUSTOMER_CODE_SUPPORT;
            }
        }

        /// <summary>
        /// VendorCdSupport
        /// </summary>
        public string vendorCdSupport
        {
            get
            {
                return M_Vendor.VENDOR_CODE_SUPPORT;
            }
        }
        //-------2014/12/08 ISV-HUNG Add End -----------//

        //------2014/12/10 ISV-HUNG Add Start----------//
        /// <summary>
        /// Product CD Used
        /// </summary>
        public int _productCDUsed;
        //------2014/12/10 ISV-HUNG Add End----------//

        public bool usingOldValue = false;
        #endregion

        #region Property
        /// <summary>
        /// Get or set SalesID
        /// </summary>
        public int SalesID
        {
            get { return base.GetValueViewState<int>("SalesID"); }
            set
            {
                ViewState["SalesID"] = value;
            }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldUpdateDate"); }
            set
            {
                ViewState["OldUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Get or set OldVersionUpdateDate
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldVersionUpdateDate"); }
            set
            {
                ViewState["OldVersionUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Get or set DefaultVAT
        /// </summary>
        public string DefaultVAT
        {
            get { return base.GetValueViewState<string>("DefaultVAT"); }
            private set
            {
                base.ViewState["DefaultVAT"] = value;
            }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return base.GetValueViewState<int>("QuantityDecimal"); }
            private set
            {
                base.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// ProductCDSetting
        /// </summary>
        public int ProductCDSetting
        {
            get { return base.GetValueViewState<int>("ProductCDSetting"); }
            private set
            {
                base.ViewState["ProductCDSetting"] = value;
            }
        }

        /// <summary>
        /// ProductCDSettingDouble
        /// </summary>
        public bool ProductCDSettingDouble
        {
            get
            {
                return this.ProductCDSetting == int.Parse(M_Config_D.PRODUCT_CD_SETTING_DOUBLE);
            }
        }

        /// <summary>
        /// ProductCDSettingSingle
        /// </summary>
        public bool ProductCDSettingSingle
        {
            get
            {
                return this.ProductCDSetting == int.Parse(M_Config_D.PRODUCT_CD_SETTING_SINGLE);
            }
        }

        /// <summary>
        /// ProductCDSettingSame
        /// </summary>
        public bool ProductCDSettingSame
        {
            get
            {
                return this.ProductCDSetting == int.Parse(M_Config_D.PRODUCT_CD_SETTING_SAME);
            }
        }

        /// <summary>
        /// ProductCDSettingNotShow
        /// </summary>
        public bool ProductCDSettingNotShow
        {
            get
            {
                return this.ProductCDSetting == int.Parse(M_Config_D.PRODUCT_CD_SETTING_NOT_SHOW);
            }
        }

        //-------2014/12/10 ISV-HUNG Add Start -----------//
        public bool ProductCDUsed
        {
            get
            {
                return this._productCDUsed == int.Parse(M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON);
            }
        }

        /// <summary>
        /// DescriptionRow
        /// </summary>
        public int DescriptionRow
        {
            get
            {
                if (this.ProductCDUsed)
                {
                    return 4;
                }
                else
                {
                    return 6;
                }
            }
        }
        //-------2014/12/10 ISV-HUNG Add End -----------//

        /// <summary>
        /// Default cost view
        /// </summary>
        public string DefaultCostView
        {
            get { return base.GetValueViewState<string>("DefaultCostView"); }
            private set
            {
                base.ViewState["DefaultCostView"] = value;
            }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public string DefaultVatType
        {
            get
            {
                return this._defaultVatType;
            }
        }

        /// <summary>
        /// Condition
        /// </summary>
        private string OldCondition
        {
            get { return base.GetValueViewState<string>("OldCondition"); }
            set
            {
                base.ViewState["OldCondition"] = value;
            }
        }

        /// <summary>
        /// DataIssuing
        /// </summary>
        private bool DataIssuing
        {
            get { return base.GetValueViewState<bool>("DataIssuing"); }
            set
            {
                base.ViewState["DataIssuing"] = value;
            }
        }

        /// <summary>
        /// DataRemand
        /// </summary>
        private bool DataRemand
        {
            get { return base.GetValueViewState<bool>("DataRemand"); }
            set
            {
                base.ViewState["DataRemand"] = value;
            }
        }

        /// <summary>
        /// DataCopy
        /// </summary>
        private bool DataCopy
        {
            get { return base.GetValueViewState<bool>("DataCopy"); }
            set
            {
                base.ViewState["DataCopy"] = value;
            }
        }

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public bool DeleteFlag
        {
            get { return base.GetValueViewState<bool>("DeleteFlag"); }
            private set
            {
                base.ViewState["DeleteFlag"] = value;
            }
        }

        /// <summary>
        /// RemaindedFlag
        /// </summary>
        public bool RemaindedFlag
        {
            get { return base.GetValueViewState<bool>("RemaindedFlag"); }
            private set
            {
                base.ViewState["RemaindedFlag"] = value;
            }
        }

        /// <summary>
        /// RemoveSeletedRow
        /// </summary>
        private bool RemoveSeletedRow
        {
            get { return base.GetValueViewState<bool>("RemoveSeletedRow"); }
            set
            {
                base.ViewState["RemoveSeletedRow"] = value;
            }
        }

        /// <summary>
        /// RemoveSeletedRow
        /// </summary>
        private bool RemoveSeletedChildRow
        {
            get { return base.GetValueViewState<bool>("RemoveSeletedChildRow"); }
            set
            {
                base.ViewState["RemoveSeletedChildRow"] = value;
            }
        }

        //-------2014/12/11 ISV-HUNG Add Start -----------//
        /// <summary>
        /// CopyFromSell
        /// </summary>
        private bool CopyFromSell
        {
            get { return base.GetValueViewState<bool>("CopyFromSell"); }
            set
            {
                base.ViewState["CopyFromSell"] = value;
            }
        }

        /// <summary>
        /// CopyFromCost
        /// </summary>
        private bool CopyFromCost
        {
            get { return base.GetValueViewState<bool>("CopyFromCost"); }
            set
            {
                base.ViewState["CopyFromCost"] = value;
            }
        }
        //-------2014/12/11 ISV-HUNG Add End -----------//

        private string ChildRowCommandArgument
        {
            get { return base.GetValueViewState<string>("ChildRowCommandArgument"); }
            set
            {
                base.ViewState["ChildRowCommandArgument"] = value;
            }
        }

        /// <summary>
        /// IsPurchare
        /// </summary>
        public bool IsPurchase
        {
            get { return base.GetValueViewState<bool>("IsPurchase"); }
            private set
            {
                base.ViewState["IsPurchase"] = value;
            }
        }

        /// <summary>
        /// ChangeCurrency
        /// </summary>
        public bool ChangeCurrency
        {
            get { return base.GetValueViewState<bool>("ChangeCurrency"); }
            private set
            {
                ViewState["ChangeCurrency"] = value;
            }
        }

        /// <summary>
        /// ChangeMethodVAT
        /// </summary>
        public bool ChangeMethodVAT
        {
            get { return base.GetValueViewState<bool>("ChangeMethodVAT"); }
            private set
            {
                base.ViewState["ChangeMethodVAT"] = value;

            }
        }

        /// <summary>
        /// CurrencyOld
        /// </summary>
        public int CurrencyIDOld
        {
            get { return base.GetValueViewState<int>("CurrencyIDOld"); }
            private set
            {
                base.ViewState["CurrencyIDOld"] = value;

            }
        }

        /// <summary>
        /// ChangeMethodVAT
        /// </summary>
        public int MethodVATOld
        {
            get { return base.GetValueViewState<int>("MethodVATOld"); }
            private set
            {
                base.ViewState["MethodVATOld"] = value;
            }
        }

        /// <summary>
        /// FileAttachedCount
        /// </summary>
        public int FileAttachedCount
        {
            get { return base.GetValueViewState<int>("FileAttachedCount"); }
            private set
            {
                base.ViewState["FileAttachedCount"] = value;
            }
        }

        /// <summary>
        /// DefaultProfit
        /// </summary>
        public string DefaultProfit
        {
            get
            {
                if (!string.IsNullOrEmpty(this._defaultProfit))
                {
                    return decimal.Parse(this._defaultProfit).ToString("N2");
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get Or Set Type Of Issue
        /// </summary>
        public string TypeOfIssue
        {
            get { return base.GetValueViewState<string>("TypeOfIssue"); }
            private set
            {
                base.ViewState["TypeOfIssue"] = value;
            }
        }

        /// <summary>
        /// Get or set QuoteID
        /// </summary>
        public int QuoteID
        {
            get { return base.GetValueViewState<int>("QuoteID"); }
            set
            {
                base.ViewState["QuoteID"] = value;
            }
        }
        //------2014/12/15 ISV-HUNG Add End----------//

        //---------------Add 2014/12/29 ISV-HUNG-------------------------//
        public List<string> ListSalesContractFile
        {
            get { return base.GetValueViewState<List<string>>("ListSalesContractFile"); }
            set
            {
                base.ViewState["ListSalesContractFile"] = value;
            }
        }
        //---------------Add 2014/12/29 ISV-HUNG-------------------------//

        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e">EventArgs</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Sales Order";
            base.FormSubTitle = "Detail";

            //Set product type
            this.hdnProductSellType.Value = ((int)ProductType.Sell).ToString();
            this.hdnProductCostType.Value = ((int)ProductType.Cost).ToString();

            //Init max length
            this.InitMaxLength();

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnYesProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadPDF_Click);

            //Back
            this.btnBackView.Click += new EventHandler(btnBackView_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Sales);
            if (!base._authority.IsSalesView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Get Default Data
            this.GetDefaultDataDropDownList();

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_SALES_LIST;
            }

            if (!base.IsPostBack)
            {
                this.RemoveSeletedRow = false;
                this.RemoveSeletedChildRow = false;
                this.IsPurchase = false;
                this.ChangeCurrency = false;
                this.ChangeMethodVAT = false;
                this.FileAttachedCount = 0;

                //Init DropDownList currency list
                this.InitDropDownListData(this.cmbCurrency, this._currencyList);

                //Init DropDownList MethodVatList
                this.InitDropDownListData(this.cmbMethodVat, this._methodVatList);
                this.InitDropDownListData(this.cmbVatType, this._vatTypeList);

                this.hdnFractionType.Value = ((int)this._fractionType).ToString();
                this.hdnProductCdSetting.Value = this.ProductCDSetting.ToString();

                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        //Save URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        //Check Para
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get ID
                            this.SalesID = int.Parse(para["ID"].ToString());
                            T_Sales_H salesH = this.GetSales(this.SalesID);

                            //Check Sales
                            if (salesH != null)
                            {
                                //Show data
                                this.ShowHeaderData(salesH);

                                //Set Mode
                                this.ProcessMode(Mode.View);

                                //Reference from Sales
                                this.ViewState["QuoteNo"] = para["QuoteNo"];
                                this.ViewState["QuoteID"] = para["QuoteID"];
                                this.ViewState["MesgID"] = para["MesgID"];

                                if (this.ViewState["MesgID"] != null)
                                {
                                    this.SetMessage(string.Empty, this.ViewState["MesgID"].ToString(), "Remand", "Quote No.", this.ViewState["QuoteID"], this.ViewState["QuoteNo"]);
                                }
                            }
                            else
                            {
                                Server.Transfer(FrmBase.URL_SALES_LIST);
                            }
                        }
                        else
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);

                }
            }

            //Set init
            this.Success = false;

            //Set Back URL
            this.btnBackView.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            this.SetConfirmData();
            this.SetSellMarkup(this.txtSalesDate.Value.GetValueOrDefault());

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Sales_H salesH = this.GetSales(this.SalesID);

            //Check Sales
            if (salesH != null)
            {
                var isOk = true;
                if (salesH.UpdateDate != this.OldUpdateDate
                    || salesH.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    //this.focusControlsID = this.btnEdit.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (salesH.DeleteFlag == 1)
                    {
                        base.RedirectUrl(FrmBase.URL_SALES_LIST);
                        return;
                    }
                }

                //Show data
                this.ShowHeaderData(salesH);
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);

                    if (!this.txtQuotationDate.IsEmpty || this.HaveBillingOrDelivery(this.SalesID))
                    {
                        if (this.txtCustomerCD.Value != M_Customer.CUSTOMER_CODE_SUPPORT)
                        {
                            this.focusControlsID = this.txtAttn.ClientID;
                        }
                        else
                        {
                            this.focusControlsID = this.txtCustomerName.ClientID;
                        }
                    }
                    else
                    {
                        this.focusControlsID = this.txtCustomerCD.ClientID;
                    }
                }
            }
            else
            {

                Server.Transfer(FrmBase.URL_SALES_LIST);
            }
        }

        /// <summary>
        /// Event Update
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            this.SetConfirmData();
            this.SetSellMarkup(this.txtSalesDate.Value.GetValueOrDefault());

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Isssue
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnIssue_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Sales_H salesH = this.GetSales(this.SalesID);
            if (salesH != null)
            {
                var isOk = true;
                if (salesH.UpdateDate != this.OldUpdateDate
                    || salesH.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (salesH.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_SALES_LIST);
                        return;
                    }
                }

                //Show data
                this.ShowHeaderData(salesH);

                if (isOk)
                {
                    this.TypeOfIssue = "PDF";

                    this.DataIssuing = true;
                    this.DataRemand = false;
                    this.DataCopy = false;

                    if (salesH.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes,true);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, true, "PDF");
                    }
                }
            }
            else
            {
                Server.Transfer(FrmBase.URL_SALES_LIST);
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                M_Setting setting = new M_Setting();
                using (var db = new DB())
                {
                    SettingService settingSer = new SettingService(db);
                    setting = settingSer.GetData();
                }
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    var fileName = string.Empty;
                    if (this.TypeOfIssue == "PDF")
                    {
                        fileName = string.Format("{0}.pdf", this.txtSalesNo.Value);
                        Response.ContentType = "application/pdf";
                    }
                    else
                    {
                        fileName = this.TypeOfIssue;
                        Response.ContentType = "application/vnd.ms-excel";
                    }

                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                    Response.Flush(); // send it to the client to download
                }
            }
        }

        /// <summary>
        /// Event Remand
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnRemand_Click(object sender, EventArgs e)
        {
            var sales = this.GetSales(this.SalesID);
            if (sales != null)
            {
                bool haveErrors = false;
                if (sales.UpdateDate != this.OldUpdateDate
                    || sales.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    haveErrors = true;
                }

                //Reload data
                this.ShowHeaderData(sales);

                if (haveErrors)
                {
                    return;
                }

                this.DataRemand = true;
                this.DataIssuing = false;
                this.DataCopy = false;

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_REMAND_QUOTE, Models.DefaultButton.Yes, true);
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_SALES_LIST);
            }
        }

        //------2014/12/16 ISV-HUNG Add Start----------//
        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnQuotationMessageRef_Click(object sender, EventArgs e)
        {
            // Author: ISV-HUNG
            // Date  : 2014/12/19
            // ---------------------- Start ------------------------------
            Hashtable currentPage = new Hashtable();
            currentPage.Add("ID", this.SalesID);
            currentPage.Add("QuoteID", this.hidQuoteID.Value);
            currentPage.Add("QuoteNo", this.txtQuotationNo.Value);
            currentPage.Add("MesgID", M_Message.MSG_PROCESS_COMPLETED);

            Hashtable nextPage = new Hashtable();
            nextPage.Add("ID", this.hidQuoteID.Value);


            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_SALES_DETAIL);
            // ---------------------- End ------------------------------
        }
        //------2014/12/16 ISV-HUNG Add End----------//

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
            if (this.Mode != Mode.View)
            {
                //Get info by ID
                T_Sales_H sales = this.GetSales(this.SalesID);

                //Check Sales
                if (sales != null)
                {
                    //Show data
                    this.ShowHeaderData(sales);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(FrmBase.URL_SALES_LIST);
                }
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBackView_Click(object sender, EventArgs e)
        {
            //Back Page
            base.BackPage();
        }

        /// <summary>
        /// Event Copy
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            var hearder = this.GetSales(this.SalesID);
            if (hearder != null)
            {
                this.ShowHeaderData(hearder);
                this.DataCopy = true;

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_MAKE_COPY, Models.DefaultButton.Yes, true, "");
            }
            else
            {
                base.RedirectUrl(URL_SALES_LIST);
            }
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Sales_H salesH = this.GetSales(this.SalesID);

            //Check Sales
            if (salesH != null)
            {
                var isOk = true;
                if (salesH.UpdateDate != this.OldUpdateDate
                    || salesH.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    //this.focusControlsID = this.btnEdit.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (salesH.DeleteFlag == 1)
                    {
                        base.RedirectUrl(FrmBase.URL_SALES_LIST);
                        return;
                    }
                }

                //Show data
                this.ShowHeaderData(salesH);

                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Delete);

                    //Show question insert
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
                }
            }
            else
            {

                Server.Transfer(FrmBase.URL_SALES_LIST);
            }
        }

        /// <summary>
        /// Event Select
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSelect_Click(object sender, CommandEventArgs e)
        {
            T_Sales_H sales = this.GetSales(this.SalesID);
            if (sales != null && sales.DeleteFlag == 0 && sales.StatusFlag != (int)StatusFlag.Lost)
            {
                //if (sales.UpdateDate != this.OldUpdateDate
                //    && sales.VersionUpdateDate != this.OldVersionUpdateDate)
                //{
                //    base.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);

                //    //Reload data
                //    this.ShowHeaderData(sales);
                //    return;
                //}

                //Process reference parameter
                Hashtable currentPage = new Hashtable();
                Hashtable nextPage = new Hashtable();

                currentPage.Add("ID", sales.ID);

                nextPage.Add("ID", this.SalesID);

                base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_SALES_DETAIL);
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_SALES_LIST);
            }
        }

        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnReferenceYes_Click(object sender, CommandEventArgs e)
        {
            //Get data
            T_Sales_H sales = this.GetSales(this.SalesID);

            if (sales != null && sales.DeleteFlag == 0 && sales.StatusFlag != (int)StatusFlag.Lost)
            {
                ////Check data change
                //if (sales.UpdateDate != this.OldUpdateDate
                //   && sales.VersionUpdateDate != this.OldVersionUpdateDate)
                //{
                //    base.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);

                //    //Reload data
                //    this.ShowHeaderData(sales);
                //    return;
                //}

                //Process reference parameter
                Hashtable currentPage = new Hashtable();
                currentPage.Add("ID", sales.ID);

                Hashtable nextPage = new Hashtable();
                nextPage.Add("txtSalesNo", sales.SalesNo);
                nextPage.Add("SalesNoReadOnly", true);

                if (!this.txtQuotationNo.IsEmpty)
                {
                    nextPage.Add("txtQuoteNo", this.txtQuotationNo.Value);
                    nextPage.Add("QuoteNoReadOnly", true);
                }

                nextPage.Add("FinishedFlag", M_Config_D.DATA_INCLUDE);
                nextPage.Add("DeletedFlag", M_Config_D.DATA_INCLUDE);

                var formId = e.CommandArgument;
                if (string.Equals(formId, "Quotation"))
                {
                    if (!this.txtQuotationNo.IsEmpty)
                    {
                        nextPage.Add("SalesData", M_Config_D.DATA_INCLUDE);
                    }
                }
                //if (string.Equals(formId , "Purchase"))
                //{
                //    nextPage.Add("QuoteNoReadOnly", true);
                //    nextPage.Add("SalesNoReadOnly", true);
                //}
                //if (string.Equals(formId , "Delivery"))
                //{
                //    nextPage.Add("QuoteNoReadOnly", true);
                //    nextPage.Add("SalesNoReadOnly", true);
                //}
                //if (string.Equals(formId , "Billing"))
                //{
                //    nextPage.Add("QuoteNoReadOnly", true);
                //    nextPage.Add("SalesNoReadOnly", true);
                //}

                base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_SALES_DETAIL);

            }
            else
            {
                base.RedirectUrl(FrmBase.URL_SALES_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
            #region Delete data
            if (this.Mode == Utilities.Mode.Delete)
            {
                //Get info by ID
                var salesH = this.GetSales(this.SalesID);

                //Show data
                this.ShowHeaderData(salesH);

                //Set Mode
                this.ProcessMode(Mode.View);

                return;
            }
            #endregion

            #region Delete Row(Sell)
            //Delete row
            if (this.RemoveSeletedRow)
            {
                this.RemoveSeletedRow = false;
                return;
            }
            #endregion

            #region Delete child Row(Cost)
            //Delete row
            if (this.RemoveSeletedChildRow)
            {
                this.RemoveSeletedChildRow = false;
                return;
            }
            #endregion

            #region Change Currency
            //change currency
            if (this.ChangeCurrency)
            {
                this.cmbCurrency.SelectedValue = this.CurrencyIDOld.ToString();
                this.ChangeCurrency = false;

                this.ReloadListDetail();

                //Reset value
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = false;
                    this.txtVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);

                    //SellVatRatio
                    this.txtVatRatio.Value = null;
                }
                else//for total
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = true;
                    this.txtVatRatio.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeList);
                    this.SetEnableControlByVatType(this.cmbVatType, this.txtSumVat, this.txtVatRatio, true);
                }
                return;
            }
            #endregion

            #region Change Method VAT
            //change method vat
            if (this.ChangeMethodVAT)
            {
                this.cmbMethodVat.SelectedValue = this.MethodVATOld.ToString();
                this.ChangeMethodVAT = false;

                this.ReloadListDetail();

                //Reset value
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = false;
                    this.txtVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);

                    //SellVatRatio
                    this.txtVatRatio.Value = null;
                }
                else//for total
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = true;
                    this.txtVatRatio.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeList);
                    int defaultVatType = int.Parse(this._defaultVatType);
                    this.cmbVatType.SelectedValue = defaultVatType.ToString();
                    this.SetEnableControlByVatType(this.cmbVatType, this.txtSumVat, this.txtVatRatio, true);
                }
                return;
            }
            #endregion

            //-------2014/12/11 ISV-HUNG Add Start -----------//
            #region Copy from Sell
            if (this.CopyFromSell)
            {
                this.CopyFromSell = false;
                return;
            }
            #endregion

            #region Copy from Cost
            if (this.CopyFromCost)
            {
                this.CopyFromCost = false;
                return;
            }
            #endregion
            //-------2014/12/11 ISV-HUNG Add End -----------//

            #region Remand data
            if (this.DataRemand)
            {
                this.DataRemand = false;
                var header = this.GetSales(this.SalesID);
                if (header != null)
                {
                    this.ShowHeaderData(header);
                }
                return;
            }
            #endregion

            #region Issue
            if (this.DataIssuing)
            {
                this.DataIssuing = false;
                var header = this.GetSales(this.SalesID);
                if (header != null)
                {
                    this.ShowHeaderData(header);
                }
            }
            #endregion

            #region Copy
            if (this.DataCopy)
            {
                this.DataCopy = false;
                var header = this.GetSales(this.SalesID);
                if (header != null)
                {
                    this.ShowHeaderData(header);
                }
            }
            #endregion
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnYesProcessData(object sender, EventArgs e)
        {
            //-------2014/12/11 ISV-HUNG Add Start -----------//
            #region Copy Sell
            if (this.CopyFromSell)
            {
                //Get Data from screen
                IList<SalesDetailInfo> listScreen = this.GetData();

                string[] value = this.ChildRowCommandArgument.Split('_');
                int index1 = Convert.ToInt32(value[0]) - 1;//Index sell
                int index2 = Convert.ToInt32(value[1]) - 1;//Index cost

                if (string.IsNullOrEmpty(listScreen[index1].Sell.ProductCD) &&
                    string.IsNullOrEmpty(listScreen[index1].Sell.ProductName) &&
                    string.IsNullOrEmpty(listScreen[index1].Sell.Description))
                {
                    this.CopyFromSell = false;
                    return;
                }

                listScreen[index1].Sell.Collapsed = "in";

                Repeater cost = (Repeater)this.rptDetail.Items[index1].FindControl("rptCost");

                if (this.ProductCDUsed)
                {
                    if (listScreen[index1].Sell.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                    {
                        using (DB db = new DB())
                        {
                            ProductService productService = new ProductService(db);
                            VendorService vendorService = new VendorService(db);
                            var proInfo = productService.GetByCD(listScreen[index1].Sell.ProductCD);
                            if (proInfo != null && proInfo.StatusFlag == 0)
                            {
                                //From screen
                                listScreen[index1].CostList[index2].ProductCD = listScreen[index1].Sell.ProductCD;
                                listScreen[index1].CostList[index2].ProductName = listScreen[index1].Sell.ProductName;
                                listScreen[index1].CostList[index2].Description = listScreen[index1].Sell.Description;
                                listScreen[index1].CostList[index2].UnitID = listScreen[index1].Sell.UnitID;
                                listScreen[index1].CostList[index2].Quantity = listScreen[index1].Sell.Quantity;


                                //From master Product
                                listScreen[index1].CostList[index2].Price = proInfo.UnitPriceCost;
                                listScreen[index1].CostList[index2].VatType = proInfo.VatTypeCost;
                                listScreen[index1].CostList[index2].VatRatio = proInfo.VatRatioCost;
                                listScreen[index1].CostList[index2].CurrencyID = proInfo.CurrencyIDCost;
                                listScreen[index1].CostList[index2].PurchaseFlag = proInfo.PurchaseFlag == 1;
                                var vendor = vendorService.GetFirstOrDefaultByProductID(proInfo.ID);
                                if (vendor != null && vendor.ID != Constant.DEFAULT_ID)
                                {
                                    listScreen[index1].CostList[index2].VendorCD = vendor.VendorCD;
                                    listScreen[index1].CostList[index2].VendorName = vendor.VendorName1;
                                }

                            }
                        }
                    }
                    else
                    {
                        listScreen[index1].CostList[index2].ProductCD = listScreen[index1].Sell.ProductCD;
                        listScreen[index1].CostList[index2].ProductName = listScreen[index1].Sell.ProductName;
                        listScreen[index1].CostList[index2].Description = listScreen[index1].Sell.Description;
                        listScreen[index1].CostList[index2].UnitID = listScreen[index1].Sell.UnitID;
                        listScreen[index1].CostList[index2].Quantity = listScreen[index1].Sell.Quantity;
                    }
                    this.focusControlsID = cost.Items[index2].FindControl("txtCostProductCD").ClientID;
                }
                else
                {
                    listScreen[index1].CostList[index2].ProductName = listScreen[index1].Sell.ProductName;
                    listScreen[index1].CostList[index2].Description = listScreen[index1].Sell.Description;
                    listScreen[index1].CostList[index2].UnitID = listScreen[index1].Sell.UnitID;
                    listScreen[index1].CostList[index2].Quantity = listScreen[index1].Sell.Quantity;

                    this.focusControlsID = cost.Items[index2].FindControl("txtCostProductName").ClientID;
                }

                this.rptDetail.DataSource = listScreen;
                this.rptDetail.DataBind();

                this.SetConfirmData(false);

                this.CopyFromSell = false;
                return;
            }
            #endregion

            #region Copy Cost
            if (this.CopyFromCost)
            {
                //Get Data from screen
                IList<SalesDetailInfo> listScreen = this.GetData();

                int index = Convert.ToInt32(this.ChildRowCommandArgument) - 1;

                if (string.IsNullOrEmpty(listScreen[index].CostList[0].ProductCD) &&
                    string.IsNullOrEmpty(listScreen[index].CostList[0].ProductName) &&
                    string.IsNullOrEmpty(listScreen[index].CostList[0].Description))
                {
                    this.CopyFromCost = false;
                    return;
                }

                listScreen[index].Sell.Collapsed = "in";

                if (this.ProductCDUsed)
                {
                    if (listScreen[index].CostList[0].ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                    {
                        using (DB db = new DB())
                        {
                            ProductService productService = new ProductService(db);
                            var proInfo = productService.GetByCD(listScreen[index].CostList[0].ProductCD);
                            if (proInfo != null && proInfo.StatusFlag == 0)
                            {
                                //From screen
                                listScreen[index].Sell.ProductCD = listScreen[index].CostList[0].ProductCD;
                                listScreen[index].Sell.ProductName = listScreen[index].CostList[0].ProductName;
                                listScreen[index].Sell.Description = listScreen[index].CostList[0].Description;
                                listScreen[index].Sell.Quantity = listScreen[index].CostList[0].Quantity;
                                listScreen[index].Sell.UnitID = listScreen[index].CostList[0].UnitID;

                                //From master Product
                                var unitPrice = 0m;

                                if (Convert.ToInt32(this.cmbCurrency.SelectedValue) == proInfo.CurrencyIDSell)
                                {
                                    unitPrice = proInfo.UnitPriceSell;
                                }
                                else
                                {
                                    var baseDate = this.txtSalesDate.IsEmpty ? db.NowDate : this.txtSalesDate.Value;
                                    var crcyService = new Currency_HService(db);
                                    var crcyList = crcyService.GetAllByDate(baseDate.Value).ToDictionary(s => s.ID, s => s);

                                    //Change currency of product to default currency
                                    if (proInfo.CurrencyIDSell == Constant.DEFAULT_ID)
                                    {
                                        unitPrice = proInfo.UnitPriceSell;
                                    }
                                    else
                                    {
                                        unitPrice = CommonUtil.ConvertToVND(crcyList[proInfo.CurrencyIDSell].ExchangeRate, proInfo.UnitPriceSell);
                                    }

                                    if (Convert.ToInt32(this.cmbCurrency.SelectedValue) != Constant.DEFAULT_ID)
                                    {
                                        unitPrice = CommonUtil.ConvertToNotVND(crcyList[Convert.ToInt32(this.cmbCurrency.SelectedValue)].ExchangeRate, unitPrice);
                                    }

                                }
                                listScreen[index].Sell.Price = unitPrice;
                                listScreen[index].Sell.Remark = proInfo.RemarkSell;

                                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
                                {
                                    listScreen[index].Sell.VatType = proInfo.VatTypeSell;
                                    listScreen[index].Sell.VatRatio = proInfo.VatRatioSell;
                                }
                            }
                        }
                    }
                    else
                    {
                        listScreen[index].Sell.ProductCD = listScreen[index].CostList[0].ProductCD;
                        listScreen[index].Sell.ProductName = listScreen[index].CostList[0].ProductName;
                        listScreen[index].Sell.Description = listScreen[index].CostList[0].Description;
                        listScreen[index].Sell.Quantity = listScreen[index].CostList[0].Quantity;
                        listScreen[index].Sell.UnitID = listScreen[index].CostList[0].UnitID;
                    }

                    this.focusControlsID = this.rptDetail.Items[index].FindControl("txtSellProductCD").ClientID;
                }
                else
                {
                    listScreen[index].Sell.ProductName = listScreen[index].CostList[0].ProductName;
                    listScreen[index].Sell.Description = listScreen[index].CostList[0].Description;
                    listScreen[index].Sell.Quantity = listScreen[index].CostList[0].Quantity;
                    listScreen[index].Sell.UnitID = listScreen[index].CostList[0].UnitID;

                    this.focusControlsID = this.rptDetail.Items[index].FindControl("txtSellProductName").ClientID;
                }

                this.rptDetail.DataSource = listScreen;
                this.rptDetail.DataBind();

                this.SetConfirmData(false);

                this.CopyFromCost = false;
                return;
            }
            #endregion
            //-------2014/12/11 ISV-HUNG Add End -----------//

            #region Remove Row(Sell)
            //Delete row
            if (this.RemoveSeletedRow)
            {
                //Get Data from screen
                IList<SalesDetailInfo> listScreen = this.GetData();
                int index = 0;
                foreach (var item in listScreen)
                {
                    if (item.CheckFlag)
                    {
                        bool isErrors = false;
                        if (this.HaveBilling(item.Sell.InternalID))
                        {
                            base.SetMessage("", M_Message.MSG_CAN_NOT_DELETE_SELL_INVOICE_DELIVERY_GRID, "Billing", index + 1);
                            isErrors = true;
                        }

                        if (!isErrors && this.HaveDelivery(item.Sell.InternalID))
                        {
                            base.SetMessage("", M_Message.MSG_CAN_NOT_DELETE_SELL_INVOICE_DELIVERY_GRID, "Delivery", index + 1);
                            isErrors = true;
                        }

                        var havePOCost = item.CostList.Any(c => this.HavePO(c.InternalID));
                        if (!this.ProductCDSettingNotShow && havePOCost)
                        {
                            base.SetMessage("", M_Message.MSG_CAN_NOT_DELETE_SELL_INVOICE_DELIVERY_GRID, "Purchase", index + 1);
                            isErrors = true;
                        }
                    }
                    index++;
                }
                if (base.HaveError)
                {
                    this.RemoveSeletedRow = false;
                    return;
                }

                //Get data for delete
                IList<SalesDetailInfo> list = this.GetData(false);

                //Reset value total as null
                this.txtSumTotal.Value = null;
                this.txtSumVat.Value = null;
                this.txtGrandTotal.Value = null;

                //List empty
                if (list.Count == 0)
                {
                    //Init Data
                    //Init sell item
                    SalesDetailInfo emptyItemSell = new SalesDetailInfo();
                    emptyItemSell.Sell = new SalesSellInfo();
                    if (!string.IsNullOrEmpty(this._defaultProfit))
                    {
                        emptyItemSell.Sell.Profit = decimal.Parse(this._defaultProfit);
                    }
                    emptyItemSell.Sell.No = 1;
                    emptyItemSell.Sell.InternalID = -1;
                    emptyItemSell.Sell.VatType = int.Parse(this._defaultVatType);
                    if (emptyItemSell.Sell.VatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        emptyItemSell.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
                    }
                    emptyItemSell.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                    //Init cost item list
                    emptyItemSell.CostList = new List<SalesCostInfo>();
                    SalesCostInfo emptyItemCost = new SalesCostInfo();
                    emptyItemCost.InternalID = -1;
                    emptyItemCost.No = 1;
                    emptyItemCost.SellNo = 1;
                    emptyItemCost.SellNoDisp = 1;
                    emptyItemCost.VatType = int.Parse(this._defaultVatType);
                    if (emptyItemCost.VatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        emptyItemCost.VatRatio = decimal.Parse(this.DefaultVAT);
                    }

                    emptyItemSell.CostList.Add(emptyItemCost);

                    //Add item sell
                    list.Add(emptyItemSell);

                    if (this.cmbVatType.SelectedItem != null)
                    {
                        if (Convert.ToInt32(this.cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {
                            this.txtVatRatio.Value = decimal.Parse(this.DefaultVAT); ;
                        }
                    }
                }

                //Add data source
                this.rptDetail.DataSource = list;
                this.rptDetail.DataBind();

                this.SetConfirmData(false);

                this.RemoveSeletedRow = false;
                return;
            }
            #endregion

            #region Remove child Row(Cost)
            //Delete row
            if (this.RemoveSeletedChildRow)
            {
                string[] value = this.ChildRowCommandArgument.Split('_');
                int index1 = Convert.ToInt32(value[0]) - 1;
                int index2 = Convert.ToInt32(value[1]) - 1;
                int internalID = Convert.ToInt32(value[2]);

                if (this.HavePO(internalID))
                {
                    base.SetMessage("", M_Message.MSG_CAN_NOT_DELETE_SELL_INVOICE_DELIVERY_GRID, "Purchase", string.Format("{0}/{1}", index1 + 1, index2 + 1));
                    return;
                }

                //Get Data
                IList<SalesDetailInfo> list = this.GetData();
                list[index1].CostList.RemoveAt(index2);
                var costNo = 1;
                foreach (var cost in list[index1].CostList)
                {
                    cost.No = costNo++;
                }

                list[index1].Sell.Collapsed = "in";

                if (list[index1].CostList.Count == 0)
                {
                    //Init cost item list
                    list[index1].CostList = new List<SalesCostInfo>();
                    SalesCostInfo emptyItemCost = new SalesCostInfo();
                    emptyItemCost.No = 1;
                    emptyItemCost.InternalID = -1;
                    emptyItemCost.SellNo = list[index1].Sell.No;
                    emptyItemCost.SellNoDisp = list[index1].Sell.No;
                    emptyItemCost.VatType = int.Parse(this._defaultVatType);
                    if (emptyItemCost.VatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        emptyItemCost.VatRatio = decimal.Parse(this.DefaultVAT);
                    }
                    list[index1].CostList.Add(emptyItemCost);
                }

                this.rptDetail.DataSource = list;
                this.rptDetail.DataBind();

                this.RemoveSeletedChildRow = false;
                return;
            }
            #endregion

            #region Change MethodVAT
            //change method vat
            if (this.ChangeMethodVAT)
            {
                this.focusControlsID = this.cmbMethodVat.ClientID;

                var methodVAT = this.cmbMethodVat.SelectedValue;
                var defaultVatType = int.Parse(this._defaultVatType);

                //Set enable control at detail list with method vat type
                foreach (RepeaterItem item in this.rptDetail.Items)
                {
                    if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                    {
                        //Find control
                        INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");
                        DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbSellVatType");
                        INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtSellVatRatio");

                        //Reset value control
                        if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
                        {
                            //Enable control sell by method vat
                            txtSellVat.SetReadOnly(false);
                            cmbSellVatType.Enabled = true;
                            txtSellVatRatio.SetReadOnly(false);

                            txtSellVatRatio.Value = decimal.Parse(this.DefaultVAT);

                            //VatType
                            this.InitDropDownListData(cmbSellVatType, this._vatTypeList);
                            cmbSellVatType.SelectedValue = defaultVatType.ToString();
                        }
                        else//for total
                        {
                            //Enable control sell by method vat
                            txtSellVat.SetReadOnly(true);
                            cmbSellVatType.Enabled = false;
                            txtSellVatRatio.SetReadOnly(true);

                            //SellVatRatio
                            txtSellVat.Value = null;

                            //txtSellVatRatio
                            txtSellVatRatio.Value = null;

                            //VatType
                            this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                        }
                    }
                }

                //Reset value
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = false;
                    this.txtVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);

                    //SellVatRatio
                    this.txtVatRatio.Value = null;
                }
                else//for total
                {
                    //Set enable control at total with method vat type
                    this.cmbVatType.Enabled = true;
                    this.cmbVatType.SelectedValue = defaultVatType.ToString();
                    this.txtVatRatio.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeList);
                    this.SetEnableControlByVatType(this.cmbVatType, this.txtSumVat, this.txtVatRatio, false);
                }

                this.ReloadListDetail();
                this.SetConfirmData(false);

                this.ChangeMethodVAT = false;
                this.MethodVATOld = Convert.ToInt32(this.cmbMethodVat.SelectedValue);
                return;
            }
            #endregion

            #region Change Currency
            //change currency
            if (this.ChangeCurrency)
            {
                this.focusControlsID = this.cmbCurrency.ClientID;

                foreach (RepeaterItem item in this.rptDetail.Items)
                {
                    if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                    {
                        //Find control
                        INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtSellPrice");
                        INumberTextBox txtSellTotal = (INumberTextBox)item.FindControl("txtSellTotal");
                        INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");

                        //Set decimal digit control sell by exchange
                        this.SetDecimalDigit(this.cmbCurrency, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                        this.SetDecimalDigit(this.cmbCurrency, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                        this.SetDecimalDigit(this.cmbCurrency, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                        //Reset null value
                        txtSellPrice.Value = null;
                        txtSellTotal.Value = null;
                        txtSellVat.Value = null;
                    }
                }

                ////Set decimal digit control total by exchange
                this.SetDecimalDigit(this.cmbCurrency, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(this.cmbCurrency, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                this.SetDecimalDigit(this.cmbCurrency, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);

                this.ReloadListDetail();
                this.SetConfirmData(false);

                this.ChangeCurrency = false;
                this.CurrencyIDOld = Convert.ToInt32(this.cmbCurrency.SelectedValue);
                return;
            }
            #endregion

            #region Process Insert,Copy,Update,Delete
            bool ret;
            T_Sales_H salesH = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:
                    //Insert Data
                    int newID = 0;
                    ret = this.InsertData(ref newID);

                    this.SalesID = newID;
                    break;

                case Utilities.Mode.Update:

                    //Update Data
                    ret = this.UpdateData();

                    break;
                case Utilities.Mode.Delete:

                    //Delete data
                    ret = this.DeleteData();
                    if (!ret)
                    {
                        //Get info by ID
                        salesH = this.GetSales(this.SalesID);

                        //Show data
                        this.ShowHeaderData(salesH);

                        this.ProcessMode(Mode.View);
                    }
                    //if (!ret)
                    //{
                    //    //Set Mode
                    //    this.ProcessMode(Mode.View);
                    //}
                    //else
                    //{
                    //    Server.Transfer(FrmBase.URL_SALES_LIST);
                    //}
                    break;
                default:
                    ret = false;
                    //Remand data
                    if (this.DataRemand)
                    {
                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        var quoteID = 0;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//

                        //Remand data
                        //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                        //ret = this.RemandData();
                        ret = this.RemandData(ref quoteID);
                        //----------------2014/12/16 ISV-HUNG Edit End----------------------//
                        if (ret)
                        {
                            //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                            //this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Remand", "Quote No.", this.txtQuotationNo.Value);
                            this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Remand", "Quote No.", quoteID, this.txtQuotationNo.Value);
                            //----------------2014/12/16 ISV-HUNG Edit End----------------------//

                            //Get info by ID
                            salesH = this.GetSales(this.SalesID);

                            //Show data
                            this.ShowHeaderData(salesH);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                            return;
                        }
                        else
                        {
                            //Get info by ID
                            salesH = this.GetSales(this.SalesID);

                            //Show data
                            this.ShowHeaderData(salesH);

                            this.ProcessMode(Mode.View);
                        }
                    }

                    //Issue data
                    if (this.DataIssuing)
                    {
                        SalesPDF sales = new SalesPDF();
                        sales.LoginInfo = this.LoginInfo;
                        var uniqueFileName = string.Format(PDF_SALES_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                        this.ExportPDF(sales.GetLocalReport(new LocalReport(), this.SalesID, this.OldUpdateDate, this.OldVersionUpdateDate), uniqueFileName, true);

                        //Get info by ID
                        salesH = this.GetSales(this.SalesID);

                        //Show data
                        this.ShowHeaderData(salesH);

                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }

                    //Copy data
                    if (this.DataCopy)
                    {
                        //Get info by ID
                        T_Sales_H sales = this.GetSales(this.SalesID);

                        //Check sales
                        if (sales != null)
                        {
                            sales.SalesNo = string.Empty;
                            sales.QuoteNo = string.Empty;
                            sales.QuoteDate = DATE_TIME_DEFAULT;
                            sales.IssuedUID = 0;
                            sales.IssuedDate = DATE_TIME_DEFAULT;
                            sales.CreateUID = 0;
                            sales.CreateDate = DATE_TIME_DEFAULT;
                            sales.UpdateUID = 0;
                            sales.UpdateDate = DATE_TIME_DEFAULT;

                            //Show data
                            this.ShowHeaderData(sales);

                            //Set Mode
                            this.ProcessMode(Mode.Copy);
                        }
                        else
                        {
                            Server.Transfer(FrmBase.URL_SALES_LIST);
                        }

                        this.DataCopy = false;
                    }

                    break;
            }

            if (ret)
            {
                //Get info by ID
                salesH = this.GetSales(this.SalesID);

                //Show data
                this.ShowHeaderData(salesH);

                //Set Mode
                this.ProcessMode(Mode.View);

                //Set Success
                this.Success = true;
            }
            #endregion
        }

        /// <summary>
        /// Change value with currency
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ChangeCurrency = true;

            this.usingOldValue = true;
            this.SetConfirmData();
            this.ReloadListDetail();
            this.usingOldValue = false;

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_CODE_CURRENCY_CHANGED, Models.DefaultButton.Yes, true);
        }

        /// <summary>
        /// Change value with method vat
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbMethodVat_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ChangeMethodVAT = true;

            this.usingOldValue = true;
            this.SetConfirmData();
            this.ReloadListDetail();
            this.usingOldValue = false;

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_CODE_METHOD_CHANGED, Models.DefaultButton.Yes, true);
        }

        /// <summary>
        /// Add Row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            IList<SalesDetailInfo> list = this.GetData();

            //New Item Add
            SalesDetailInfo item = new SalesDetailInfo();
            var defaultVatType = -1;
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
            {
                defaultVatType = int.Parse(this._defaultVatType);
            }

            //Add sell info
            item.Sell = new SalesSellInfo();
            if (!string.IsNullOrEmpty(this._defaultProfit))
            {
                item.Sell.Profit = decimal.Parse(this._defaultProfit);
            }
            item.Sell.No = this._indexSell;
            item.Sell.InternalID = -1;
            item.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            item.Sell.VatType = defaultVatType;
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                item.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            //Add cost info list
            item.CostList = new List<SalesCostInfo>();
            SalesCostInfo costInfo = new SalesCostInfo();
            costInfo.No = 1;
            costInfo.SellNo = item.Sell.No;
            costInfo.SellNoDisp = costInfo.SellNo;
            costInfo.InternalID = -1;
            costInfo.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            defaultVatType = int.Parse(this._defaultVatType);
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                costInfo.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            costInfo.VatType = defaultVatType;
            item.CostList.Add(costInfo);

            //Add item
            list.Add(item);

            //Add data source
            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();

            this.SetConfirmData();

            //-------2014/12/10 ISV-HUNG Edit Start -----------//
            //Find control focus
            var txtSellProductCD = this.rptDetail.Items[this._indexSell - 1].FindControl("txtSellProductCD");
            var txtSellProductName = this.rptDetail.Items[this._indexSell - 1].FindControl("txtSellProductName");
            if (this.ProductCDUsed)
            {
                if (txtSellProductCD != null)
                {
                    this.focusControlsID = txtSellProductCD.ClientID;
                }
            }
            else
            {
                if (txtSellProductName != null)
                {
                    this.focusControlsID = txtSellProductName.ClientID;
                }
            }
            //-------2014/12/10 ISV-HUNG Edit End -----------//
        }

        /// <summary>
        /// Delete row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDeleteRow_Click(object sender, EventArgs e)
        {
            this.RemoveSeletedRow = true;

            this.ReloadListDetail();

            //Show question delete row
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Up row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnUp_Click(object sender, EventArgs e)
        {
            //Get Data
            IList<SalesDetailInfo> listDetail = this.GetData();

            //List empty return
            if (listDetail.Count == 0)
            {
                return;
            }

            //Process up
            IList<SalesDetailInfo> listUp = this.ProcessUpDown(true, listDetail);

            //Set data source
            this.rptDetail.DataSource = listUp;
            this.rptDetail.DataBind();

            this.SetConfirmData();
        }

        /// <summary>
        /// Down row
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDown_Click(object sender, EventArgs e)
        {
            //Get Data
            IList<SalesDetailInfo> listDetail = this.GetData();

            //List empty return
            if (listDetail.Count == 0)
            {
                return;
            }

            //Process up
            IList<SalesDetailInfo> listDown = this.ProcessUpDown(false, listDetail);

            //Set data source
            this.rptDetail.DataSource = listDown;
            this.rptDetail.DataBind();

            this.SetConfirmData();
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                SalesDetailInfo data = (SalesDetailInfo)e.Item.DataItem;
                data.CostList.AsParallel().ForAll(c => c.Collapsed = data.Sell.Collapsed);

                //Find Control
                ICodeTextBox txtSellProductCD = (ICodeTextBox)e.Item.FindControl("txtSellProductCD");
                ITextBox txtSellProductName = (ITextBox)e.Item.FindControl("txtSellProductName");
                INumberTextBox txtSellPrice = (INumberTextBox)e.Item.FindControl("txtSellPrice");
                ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtSellDescription");
                INumberTextBox txtSellTotal = (INumberTextBox)e.Item.FindControl("txtSellTotal");
                INumberTextBox txtSellVat = (INumberTextBox)e.Item.FindControl("txtSellVat");
                INumberTextBox txtSellQuantity = (INumberTextBox)e.Item.FindControl("txtSellQuantity");
                INumberTextBox txtSellVatRatio = (INumberTextBox)e.Item.FindControl("txtSellVatRatio");
                DropDownList cmbSellVatType = (DropDownList)e.Item.FindControl("cmbSellVatType");
                INumberTextBox txtProfit = (INumberTextBox)e.Item.FindControl("txtProfit");
                ITextBox txtSellRemark = (ITextBox)e.Item.FindControl("txtSellRemark");

                HtmlGenericControl lblSellPriceCurrency = (HtmlGenericControl)e.Item.FindControl("lblSellPriceCurrency");
                HtmlGenericControl lblSellTotalCurrency = (HtmlGenericControl)e.Item.FindControl("lblSellTotalCurrency");
                HtmlGenericControl lblSellVatCurrency = (HtmlGenericControl)e.Item.FindControl("lblSellVatCurrency");

                var currencyLabel = string.Empty;
                if (this.usingOldValue)
                {
                    currencyLabel = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == this.CurrencyIDOld).SingleOrDefault().DisplayName;
                }
                else
                {
                    currencyLabel = this.cmbCurrency.SelectedItem.Text;
                }
                lblSellPriceCurrency.InnerHtml = currencyLabel;
                lblSellTotalCurrency.InnerHtml = currencyLabel;
                lblSellVatCurrency.InnerHtml = currencyLabel;

                //---------Set maxlength-------------------//
                txtSellProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
                txtSellProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
                txtSellDescription.MaxLength = T_Quote_D_Sell.DESCRIPTION_MAX_LENGTH;
                txtSellRemark.MaxLength = T_Quote_D_Sell.REMARK_MAX_LENGTH;

                //---------End Set maxlength-------------------//

                //---------Search product------------------//
                HtmlButton btnSearchProduct = (HtmlButton)e.Item.FindControl("btnSearchProduct");
                string onclickSearchProduct = "callSearchProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID + "'," + (int)Utilities.ProductType.Sell + ")";

                btnSearchProduct.Attributes.Add("onclick", onclickSearchProduct);
                //---------End Search product-------------//

                //---------Search sales product------------------//
                HiddenField hdnSearchHID = (HiddenField)e.Item.FindControl("hdnSearchHID");
                HiddenField hdnSearchInternalID = (HiddenField)e.Item.FindControl("hdnSearchInternalID");
                LinkButton cmdSearchSell = (LinkButton)e.Item.FindControl("cmdSearchSell");


                HtmlButton btnSearchSalesProduct = (HtmlButton)e.Item.FindControl("btnSearchSalesProduct");
                string onclick = "callSearchSalesProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID;
                onclick += "','" + hdnSearchHID.ClientID + "','" + hdnSearchInternalID.ClientID + "','" + cmdSearchSell.ClientID + "');";
                btnSearchSalesProduct.Attributes.Add("onclick", onclick);
                //---------Search sales product------------------//

                //---------Change sell unit price max,min, digit------------------//
                if (this.usingOldValue)
                {
                    this.SetDecimalDigit(this.cmbCurrency, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL, this.CurrencyIDOld);
                    this.SetDecimalDigit(this.cmbCurrency, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL, this.CurrencyIDOld);
                    this.SetDecimalDigit(this.cmbCurrency, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL, this.CurrencyIDOld);
                }
                else
                {
                    this.SetDecimalDigit(this.cmbCurrency, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                    this.SetDecimalDigit(this.cmbCurrency, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                    this.SetDecimalDigit(this.cmbCurrency, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);
                }


                txtSellQuantity.DecimalDigit = this.QuantityDecimal;
                txtSellQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtSellQuantity.MinimumValue = 0;
                //---------End Change sell unit price max,min, digit-------------//

                //--------------Change unit price, q'ty, sub total,vat, vat ratio----------------//
                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                                        cmbSellVatType.ClientID,
                                                                                        txtSellPrice.ClientID,
                                                                                        txtSellQuantity.ClientID,
                                                                                        txtSellTotal.ClientID,
                                                                                        txtSellVat.ClientID,
                                                                                        txtSellVatRatio.ClientID);

                txtSellPrice.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellPrice.ClientID, param));
                txtSellQuantity.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellQuantity.ClientID, param));
                txtSellTotal.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellTotal.ClientID, param));
                txtSellVatRatio.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellVatRatio.ClientID, param));

                txtSellVat.Attributes.Add("onvaluechange", "calcTotalSell();");
                //--------------End Change unit price, q'ty, sub total, vat, vat ratio----------------//

                //---------Init Unit Sell----------------------//
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbSellUnit");
                this.InitDropDownListData(cmbUnit, this._unitList);
                cmbUnit.SelectedValue = data.Sell.UnitID.ToString();
                //---------End Init Unit Sell------------------//

                //------------------Set enable with method vat-------------------------//
                var methodVat = this.usingOldValue ? this.MethodVATOld.ToString() : this.cmbMethodVat.SelectedValue;
                //Reset value
                if (methodVat == M_Config_D.METHOD_VAT_EACH)//for each item
                {
                    //Enable control by method vat
                    txtSellVat.SetReadOnly(false);
                    cmbSellVatType.Enabled = true;
                    txtSellVatRatio.SetReadOnly(false);

                    //VatType
                    this.InitDropDownListData(cmbSellVatType, this._vatTypeList);
                    cmbSellVatType.SelectedValue = data.Sell.VatType.ToString();
                    if (cmbSellVatType.SelectedItem != null)
                    {
                        if (Convert.ToInt32(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {
                            txtSellVat.SetReadOnly(false);
                            txtSellVat.Value = data.Sell.Vat;

                            txtSellVatRatio.SetReadOnly(false);
                            txtSellVatRatio.Value = data.Sell.VatRatio;
                        }
                        else
                        {
                            txtSellVat.SetReadOnly(true);
                            txtSellVat.Value = null;

                            txtSellVatRatio.SetReadOnly(true);
                            txtSellVatRatio.Value = null;
                        }
                    }
                }
                else//for total
                {
                    //Enable control by method vat
                    txtSellVat.SetReadOnly(true);
                    cmbSellVatType.Enabled = false;
                    cmbSellVatType.CssClass += " aspNetDisabled";
                    txtSellVatRatio.SetReadOnly(true);

                    //SellVat
                    txtSellVat.Value = null;

                    //SellVatRatio
                    txtSellVatRatio.Value = null;

                    //VatType
                    this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                }
                //------------------End Set enable with method vat-------------------------//

                //----------------Set data cost detail----------------------//
                Repeater rptCost = (Repeater)e.Item.FindControl("rptCost");

                rptCost.DataSource = data.CostList;
                rptCost.DataBind();
                //----------------End Set data cost detail-----------------//

                //Lock control sell
                this.LockSell(data.Sell.InternalID, e.Item);

                var havePOCost = data.CostList.Any(c => this.HavePO(c.InternalID));
                if (this.ProductCDSettingSame && havePOCost)
                {
                    txtSellProductCD.SetReadOnly(havePOCost);
                    txtSellProductName.SetReadOnly(havePOCost);
                }
            }
        }

        /// <summary>
        /// Process button
        /// </summary>
        /// <param name="source">object</param>
        /// <param name="e">RepeaterCommandEventArgs</param>
        protected void rptDetail_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            #region Profit Process
            //Profit process
            if (e.CommandName == "cmdProfitProcess")
            {
                this.ReloadListDetail();

                if (!this.txtSalesDate.Value.HasValue)
                {
                    base.SetMessage(txtSalesDate.ClientID, M_Message.MSG_REQUIRE, "Sales Date");
                    return;
                }

                //Get index row sell curren
                int rowIndex = Convert.ToInt32(e.CommandArgument) - 1;

                //Find control
                INumberTextBox txtProfit = (INumberTextBox)e.Item.FindControl("txtProfit");

                LinkButton btnProfitProcess = (LinkButton)e.Item.FindControl("btnProfitProcess");

                //Check profit
                if (txtProfit != null)
                {
                    if (!txtProfit.Value.HasValue)
                    {
                        base.SetMessage(txtProfit.ClientID, M_Message.MSG_REQUIRE_GRID, "Profit", rowIndex + 1);
                        this.ReloadListDetail();
                    }
                    else
                    {
                        //Get Sell UnitPrice from total cost price with profit input
                        this.UpdateMarkupQtySell(rowIndex, txtProfit.Value.Value);

                        this.SetConfirmData(false);

                        this.focusControlsID = btnProfitProcess.ClientID;
                    }
                }
            }
            #endregion

            //-------2014/12/11 ISV-HUNG Add Start -----------//
            #region Copy From Cost
            if (e.CommandName == "cmdCopyFromCost")
            {
                this.CopyFromCost = true;
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                this.SetConfirmData();
                this.ReloadListDetail();

                //Show question delete row
                base.ShowQuestionMessage(M_Message.MSG_COPY_FROM_COST, Models.DefaultButton.Yes, true);
            }
            #endregion
            //-------2014/12/11 ISV-HUNG Add End -----------//

            #region cmdSellSearchProcess
            if (e.CommandName == "cmdSellSearchProcess")
            {
                this.SetConfirmData();
                
                //Get index row sell curren
                int sellNo = Convert.ToInt32(e.CommandArgument);
                this.ChildRowCommandArgument = sellNo.ToString();

                //Find control
                HiddenField hdnSearchHID = (HiddenField)e.Item.FindControl("hdnSearchHID");
                //Find control
                HiddenField hdnSearchInternalID = (HiddenField)e.Item.FindControl("hdnSearchInternalID");
                ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtSellDescription");

                //Get Data
                var details = this.GetData();

                //Old sell row
                var sellRow = details.Where(s => s.Sell.No == sellNo).SingleOrDefault();

                #region Copy
                using (DB db = new DB())
                {
                    var hid = int.Parse(hdnSearchHID.Value);
                    var internalID = int.Parse(hdnSearchInternalID.Value);

                    Sales_HService sales_HService = new Sales_HService(db);
                    Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
                    Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);

                    //header
                    var header = sales_HService.GetByPK(hid);

                    //New sell row
                    var newSell = sales_D_SellService.GetByInternalID(int.Parse(hdnSearchInternalID.Value));

                    sellRow.Sell.ProductCD = newSell.ProductCD;
                    sellRow.Sell.ProductName = newSell.ProductName;
                    sellRow.Sell.Description = newSell.Description;
                    sellRow.Sell.Price = this.CalcUnitPrice(newSell.UnitPrice, header.CurrencyID);
                    sellRow.Sell.Quantity = null;
                    sellRow.Sell.UnitID = newSell.UnitID;
                    sellRow.Sell.Total = null;
                    sellRow.Sell.Vat = null;
                    sellRow.Sell.VatType = newSell.VatType;
                    sellRow.Sell.VatRatio = newSell.VatRatio;
                    sellRow.Sell.Remark = newSell.Remark;

                    //New list Cost
                    var listNewCost = sales_D_CostService.GetBySell(hid, newSell.No);
                    if (listNewCost.Count >= sellRow.CostList.Count)
                    {
                        for (int i = 0; i < sellRow.CostList.Count; i++)
                        {
                            //Copy row
                            sellRow.CostList[i].ProductCD = listNewCost[i].ProductCD;
                            sellRow.CostList[i].ProductName = listNewCost[i].ProductName;
                            bool setInfoCost = false;
                            setInfoCost = this.ProductCDUsed ? !string.IsNullOrEmpty(sellRow.CostList[i].ProductCD) : !string.IsNullOrEmpty(sellRow.CostList[i].ProductName);

                            if (setInfoCost)
                            {
                                sellRow.CostList[i].VatRatio = listNewCost[i].VatRatio;
                            }
                            else
                            {
                                sellRow.CostList[i].VatRatio = null;
                            }
                            sellRow.CostList[i].Price = listNewCost[i].UnitPrice;
                            sellRow.CostList[i].Quantity = null;
                            sellRow.CostList[i].Total = null;
                            sellRow.CostList[i].Vat = null;

                            sellRow.CostList[i].Description = listNewCost[i].Description;
                         
                            sellRow.CostList[i].UnitID = listNewCost[i].UnitID;
                          
                            sellRow.CostList[i].VatType = listNewCost[i].VatType;
                           
                            sellRow.CostList[i].CurrencyID = listNewCost[i].CurrencyID;
                            sellRow.CostList[i].PurchaseFlag = listNewCost[i].PurchaseFlag == 1 ? true : false;
                            sellRow.CostList[i].VendorCD = listNewCost[i].VendorCD;
                            sellRow.CostList[i].VendorName = listNewCost[i].VendorName;
                        }
                        //Add new row
                        for (int i = sellRow.CostList.Count; i < listNewCost.Count; i++)
                        {
                            var addItem = new SalesCostInfo();
                             addItem.InternalID = -1;
                             addItem.No = listNewCost[i].No;
                             addItem.SellNo = sellRow.Sell.No;
                             addItem.Collapsed = "";
                             addItem.SellNoDisp = sellRow.Sell.No;
                             addItem.ProductCD = listNewCost[i].ProductCD;
                             addItem.ProductName = listNewCost[i].ProductName;
                             bool setInfoCost = false;
                             setInfoCost = this.ProductCDUsed ? !string.IsNullOrEmpty(addItem.ProductCD) : !string.IsNullOrEmpty(addItem.ProductName);

                             if (setInfoCost)
                             {
                                 addItem.VatRatio = listNewCost[i].VatRatio;
                             }
                             else
                             {
                                 addItem.VatRatio = null;
                             }
                             addItem.Price = listNewCost[i].UnitPrice;
                             addItem.Quantity = null;
                             addItem.Total = null;
                             addItem.Vat = null;

                             addItem.Description = listNewCost[i].Description;
                            
                             addItem.UnitID = listNewCost[i].UnitID;
                             
                             addItem.VatType = listNewCost[i].VatType;
                            
                             addItem.CurrencyID = listNewCost[i].CurrencyID;
                             addItem.PurchaseFlag = listNewCost[i].PurchaseFlag == 1 ? true : false;
                             addItem.VendorCD = listNewCost[i].VendorCD;
                             addItem.VendorName = listNewCost[i].VendorName;

                            sellRow.CostList.Add(addItem);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < listNewCost.Count; i++)
                        {
                            //Copy row
                            sellRow.CostList[i].ProductCD = listNewCost[i].ProductCD;
                            sellRow.CostList[i].ProductName = listNewCost[i].ProductName;
                            bool setInfoCost = false;
                            setInfoCost = this.ProductCDUsed ? !string.IsNullOrEmpty(sellRow.CostList[i].ProductCD) : !string.IsNullOrEmpty(sellRow.CostList[i].ProductName);

                            if (setInfoCost)
                            {
                                sellRow.CostList[i].VatRatio = listNewCost[i].VatRatio;
                            }
                            else
                            {
                                sellRow.CostList[i].VatRatio = null;
                            }
                            sellRow.CostList[i].Price = listNewCost[i].UnitPrice;
                            sellRow.CostList[i].Quantity = null;
                            sellRow.CostList[i].Total = null;
                            sellRow.CostList[i].Vat = null;

                            sellRow.CostList[i].Description = listNewCost[i].Description;
                          
                            sellRow.CostList[i].UnitID = listNewCost[i].UnitID;
                            
                           
                            sellRow.CostList[i].VatType = listNewCost[i].VatType;
                            
                            sellRow.CostList[i].CurrencyID = listNewCost[i].CurrencyID;
                            sellRow.CostList[i].PurchaseFlag = listNewCost[i].PurchaseFlag == 1 ? true : false;
                            sellRow.CostList[i].VendorCD = listNewCost[i].VendorCD;
                            sellRow.CostList[i].VendorName = listNewCost[i].VendorName;
                        }
                        //Delete row
                        //for (int i = listNewCost.Count; i < sellRow.CostList.Count; i++)
                        //{
                        //    sellRow.CostList.RemoveAt(i);
                        //}
                        for (int i = sellRow.CostList.Count-1; i >= listNewCost.Count; i--)
                        {
                            sellRow.CostList.RemoveAt(i);
                        }
                    }
                }
                #endregion

                this.rptDetail.DataSource = details;
                this.rptDetail.DataBind();

                if (this.txtQuotationDate.Value.HasValue)
                {
                    this.SetSellMarkup(this.txtQuotationDate.Value.GetValueOrDefault());
                }
                this.focusControlsID = txtSellDescription.ClientID;
            }
            #endregion
        }

        /// <summary>
        /// Calc unit price
        /// </summary>
        /// <param name="newUnitPrice"></param>
        /// <param name="newCurrency"></param>
        /// <returns></returns>
        private decimal? CalcUnitPrice(decimal? newUnitPrice,int newCurrency)
        {
            decimal? ret = null;
            if (int.Parse(this.cmbCurrency.SelectedValue) == newCurrency)
            {
                ret = newUnitPrice;
            }
            else
            {
                using (DB db = new DB())
                {
                    var baseDate = this.txtSalesDate.IsEmpty ? db.NowDate : this.txtSalesDate.Value.Value;
                    var crcyService = new Currency_HService(db);
                    var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                    if (newCurrency == Constant.DEFAULT_ID)
                    {
                        ret = newUnitPrice;
                    }
                    else
                    {
                        ret = CommonUtil.ConvertToVND(crcyList[newCurrency].ExchangeRate, newUnitPrice.Value);
                    }

                    if (int.Parse(this.cmbCurrency.SelectedValue) != Constant.DEFAULT_ID)
                    {
                        ret = CommonUtil.ConvertToNotVND(crcyList[int.Parse(this.cmbCurrency.SelectedValue)].ExchangeRate, ret.Value);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Event Cost ItemDataBound
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">RepeaterItemEventArgs</param>
        protected void rptCost_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                SalesCostInfo data = (SalesCostInfo)e.Item.DataItem;

                //Find control
                ICodeTextBox txtCostProductCD = (ICodeTextBox)e.Item.FindControl("txtCostProductCD");
                ITextBox txtCostProductName = (ITextBox)e.Item.FindControl("txtCostProductName");
                INumberTextBox txtCostPrice = (INumberTextBox)e.Item.FindControl("txtCostPrice");
                ITextBox txtCostDescription = (ITextBox)e.Item.FindControl("txtCostDescription");
                DropDownList cmbCostVatType = (DropDownList)e.Item.FindControl("cmbCostVatType");
                INumberTextBox txtCostQuantity = (INumberTextBox)e.Item.FindControl("txtCostQuantity");
                INumberTextBox txtCostTotal = (INumberTextBox)e.Item.FindControl("txtCostTotal");
                INumberTextBox txtCostVat = (INumberTextBox)e.Item.FindControl("txtCostVat");
                INumberTextBox txtCostVatRatio = (INumberTextBox)e.Item.FindControl("txtCostVatRatio");
                DropDownList cmbCostCurrency = (DropDownList)e.Item.FindControl("cmbCostCurrency");
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbCostUnit");
                ICodeTextBox txtCostVendorCD = (ICodeTextBox)e.Item.FindControl("txtCostVendorCD");
                ITextBox txtCostVendorName = (ITextBox)e.Item.FindControl("txtCostVendorName");

                //----------------Set max length----------------------//
                txtCostProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
                txtCostProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
                txtCostDescription.MaxLength = T_Quote_D_Cost.DESCRIPTION_MAX_LENGTH;
                txtCostVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
                txtCostVendorName.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;

                //----------------Search product----------------------//
                txtCostProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
                txtCostProductCD.SetReadOnly(this.ProductCDSettingSame);

                HtmlButton btnSearchCostProduct = (HtmlButton)e.Item.FindControl("btnSearchCostProduct");
                string onclickSearchCostProduct = "callSearchProduct('" + txtCostProductCD.ClientID + "','" + txtCostProductName.ClientID + "','" + txtCostDescription.ClientID + "'," + (int)Utilities.ProductType.Cost + ")";

                btnSearchCostProduct.Attributes.Add("onclick", onclickSearchCostProduct);
                txtCostProductCD.Attributes.Add("parent-item-no", (data.SellNo).ToString());
                //----------------End Search product----------------------//

                //--------------Change unit price, q'ty, sub total,vat, vat ratio----------------//
                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                               cmbCostVatType.ClientID,
                                                                               txtCostPrice.ClientID,
                                                                               txtCostQuantity.ClientID,
                                                                               txtCostTotal.ClientID,
                                                                               txtCostVat.ClientID,
                                                                               txtCostVatRatio.ClientID);
                txtCostPrice.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostPrice.ClientID, param));
                txtCostQuantity.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostQuantity.ClientID, param));
                txtCostTotal.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostTotal.ClientID, param));
                txtCostVatRatio.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostVatRatio.ClientID, param));
                //--------------End Change unit price, q'ty, sub total,vat, vat ratio----------------//

                //---------------Init ExchangeRate Cost------------------------//
                this.InitDropDownListData(cmbCostCurrency, this._currencyList);
                cmbCostCurrency.SelectedValue = data.CurrencyID.ToString();
                //---------------End Init ExchangeRate Cost------------------------//

                //---------------Set decimal digit by exchage rate---------------//
                this.SetDecimalDigit(cmbCostCurrency, txtCostPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                this.SetDecimalDigit(cmbCostCurrency, txtCostTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(cmbCostCurrency, txtCostVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                txtCostQuantity.DecimalDigit = this.QuantityDecimal;
                txtCostQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtCostQuantity.MinimumValue = 0;
                //---------------End Set decimal digit by exchage rate---------------//

                //---------------Set decimal digit by exchage rate text---------------//
                var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostVatExchangeRate");
                label.InnerHtml = cmbCostCurrency.SelectedItem.Text;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostTotalExchangeRate");
                label.InnerHtml = cmbCostCurrency.SelectedItem.Text;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostPriceExchangeRate");
                label.InnerHtml = cmbCostCurrency.SelectedItem.Text;
                //---------------End Set decimal digit by exchage rate text---------------//

                //--------------Init Unit Cost----------------------------//
                this.InitDropDownListData(cmbUnit, this._unitList);
                cmbUnit.SelectedValue = data.UnitID.ToString();
                //--------------End Init Unit Cost----------------------------//

                //--------------Init Vat Type Cost-------------------------//
                this.InitDropDownListData(cmbCostVatType, this._vatTypeList);
                cmbCostVatType.SelectedValue = data.VatType.ToString();
                //--------------End Init Vat Type Cost-------------------------//

                //--------------Enable control by vat type-------------------------//
                if (Convert.ToInt32(cmbCostVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                {
                    txtCostVat.SetReadOnly(false);
                    txtCostVat.Value = data.Vat;

                    txtCostVatRatio.SetReadOnly(false);
                    txtCostVatRatio.Value = data.VatRatio;
                }
                else
                {
                    txtCostVat.SetReadOnly(true);
                    txtCostVat.Value = null;

                    txtCostVatRatio.SetReadOnly(true);
                    txtCostVatRatio.Value = null;
                }
                //--------------End Enable control by vat type-------------------------//

                //--------------------Search vendor---------------------------------//
                //-------2014/12/08 ISV-HUNG Add Start -----------//
                txtCostVendorName.SetReadOnly(!(txtCostVendorCD.Value == this.vendorCdSupport));
                //-------2014/12/08 ISV-HUNG Add End -----------//
                HtmlButton btnVendorSearch = (HtmlButton)e.Item.FindControl("btnVendorSearch");
                string onclickSearchVendor = "callSearchVendor('" + txtCostVendorCD.ClientID + "','" + txtCostVendorName.ClientID +
                                                               "','" + txtCostProductCD.ClientID + "','" + txtCostProductName.ClientID +
                                                               "','" + cmbCostVatType.ClientID + "')";
                btnVendorSearch.Attributes.Add("onclick", onclickSearchVendor);
                //--------------------End Search vendor---------------------------------//

                //--------------------Change purchase flag---------------------------------//
                HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)e.Item.FindControl("chkPurchaseFlag");
                string onchange = "puchaseFlagChanged('" + chkPurchaseFlag.ClientID + "','" + btnVendorSearch.ClientID + "','" + txtCostVendorCD.ClientID + "','" + txtCostVendorName.ClientID + "')";
                chkPurchaseFlag.Attributes.Add("onchange", onchange);
                //--------------------End Change purchase flag---------------------------------//

                //Lock control cost
                this.LockCost(data.InternalID, e.Item);
            }
        }

        /// <summary>
        /// Process button
        /// </summary>
        /// <param name="source">object</param>
        /// <param name="e">RepeaterCommandEventArgs</param>
        protected void rptCost_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            #region Add Row
            if (e.CommandName == "cmdAddRow")
            {
                //-------------2014/12/12 ISV-HUNG Add Start----------------//
                //Get index row sell curren
                string[] value = e.CommandArgument.ToString().Split('_');

                //Index sell
                int index = Convert.ToInt32(value[0]) - 1;
                //Index cost
                int index2 = Convert.ToInt32(value[1]);
                //-------------2014/12/12 ISV-HUNG Add End----------------//

                //Get Data
                IList<SalesDetailInfo> list = this.GetData();

                //Add new item cost
                list[index].Sell.Collapsed = "in";

                SalesCostInfo costInfo = new SalesCostInfo();
                //-------------2014/12/12 ISV-HUNG Edit Start----------------//
                //costInfo.No = list[index].CostList.Count + 1;
                //-------------2014/12/12 ISV-HUNG Edit End----------------//
                costInfo.SellNo = list[index].Sell.No;
                costInfo.SellNoDisp = costInfo.SellNo;
                costInfo.InternalID = -1;

                if (this.ProductCDSettingSame || this.ProductCDSettingDouble)
                {
                    //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                    if (this.ProductCDUsed)
                    {
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//

                        if (!string.IsNullOrEmpty(list[index].Sell.ProductCD) && list[index].Sell.ProductCD != productCdSupport)
                        {
                            //Set info from prodcut
                            using (DB db = new DB())
                            {
                                ProductService productService = new ProductService(db);
                                VendorService vendorService = new VendorService(db);

                                var productInfo = productService.GetByCD(list[index].Sell.ProductCD);

                                //-------2014/12/08 ISV-HUNG Add Start -----------//
                                if (productInfo != null && productInfo.StatusFlag == 0)
                                {
                                    //-------2014/12/08 ISV-HUNG Add End -----------//
                                    costInfo.ProductCD = productInfo.ProductCD;
                                    costInfo.ProductName = productInfo.ProductName;
                                    costInfo.Description = productInfo.DescriptionCost;
                                    costInfo.Price = productInfo.UnitPriceCost;

                                    costInfo.UnitID = productInfo.UnitIDCost;
                                    costInfo.CurrencyID = productInfo.CurrencyIDCost;
                                    costInfo.PurchaseFlag = productInfo.PurchaseFlag == 1 ? true : false;
                                    if (costInfo.PurchaseFlag)
                                    {
                                        var vendor = vendorService.GetFirstOrDefaultByProductID(productInfo.ID);
                                        if (vendor != null && vendor.StatusFlag == 0)
                                        {
                                            costInfo.VendorCD = vendor.VendorCD;
                                            costInfo.VendorName = vendor.VendorName1;
                                        }
                                    }

                                    costInfo.VatType = productInfo.VatTypeCost;
                                    costInfo.VatRatio = productInfo.VatRatioCost;
                                }
                            }
                        }
                    }
                    else
                    {
                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        costInfo.ProductName = list[index].Sell.ProductName;
                        costInfo.Description = list[index].Sell.Description;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//
                    }
                }
                else
                {
                    costInfo.VatType = int.Parse(this._defaultVatType);
                    if (costInfo.VatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        costInfo.VatRatio = decimal.Parse(this.DefaultVAT);
                    }
                }

                //-------------2014/12/12 ISV-HUNG Edit Start----------------//
                //list[index].CostList.Add(costInfo);
                list[index].CostList.Insert(index2, costInfo);
                var newNo = 1;
                foreach (var item in list[index].CostList)
                {
                    item.No = newNo++;
                }

                //-------------2014/12/12 ISV-HUNG Edit End----------------//

                //Add data source
                this.rptDetail.DataSource = list;
                this.rptDetail.DataBind();

                //Find control focus
                if (!base.HaveError)
                {
                    Repeater cost = (Repeater)this.rptDetail.Items[index].FindControl("rptCost");
                    //-------------2014/12/12 ISV-HUNG Edit Start----------------//
                    //var indexCost = list[index].CostList.Count - 1;
                    var indexCost = index2;
                    //-------------2014/12/12 ISV-HUNG Edit End----------------//
                    var txtCostProductCD = cost.Items[indexCost].FindControl("txtCostProductCD");
                    var txtCostProductName = cost.Items[indexCost].FindControl("txtCostProductName");

                    //-------2014/12/10 ISV-HUNG Edit Start -----------//
                    if (this.ProductCDUsed)
                    {
                        this.focusControlsID = (this.ProductCDSettingSame) ? txtCostProductName.ClientID : txtCostProductCD.ClientID;
                    }
                    else
                    {
                        this.focusControlsID = txtCostProductName.ClientID;
                    }
                    //-------2014/12/10 ISV-HUNG Edit End -----------//
                }
            }
            #endregion

            #region Delete Row
            if (e.CommandName == "cmdDelRow")
            {
                this.RemoveSeletedChildRow = true;
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                this.ReloadListDetail();

                //Show question delete row
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            }
            #endregion

            //-------2014/12/11 ISV-HUNG Add Start -----------//
            #region Copy From Sell
            if (e.CommandName == "cmdCopyFromSell")
            {

                this.CopyFromSell = true;
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                this.SetConfirmData();
                this.ReloadListDetail();

                //Show question delete row
                base.ShowQuestionMessage(M_Message.MSG_COPY_FROM_SELL, Models.DefaultButton.Yes, true);
            }
            #endregion
            //-------2014/12/11 ISV-HUNG Add End -----------//
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSumProfit_Click(object sender, EventArgs e)
        {
            this.SetConfirmData(true);
            this.ReloadListDetail();

            this.focusControlsID = this.btnSumProfit.ClientID;
        }

        #region Ajax
        //-------2014/12/08 ISV-HUNG Edit Start -----------//
        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                if (in1 == OMS.Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var representAposition = string.Format("{0}{1}/{2}", customer.Represent, customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' });
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1,
                            customerAddress1 = customer.CustomerAddress1,
                            customerAddress2 = customer.CustomerAddress2,
                            customerAddress3 = customer.CustomerAddress3,
                            tel = customer.Tel,
                            fax = customer.FAX,
                            contactPerson = customer.ContactPerson,
                            represent = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_REPRESENT : customer.Represent,
                            position = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_POSITION : string.Format("{0} / {1}", customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' }),
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        //-------2014/12/08 ISV-HUNG Edit End -----------//

        /// <summary>
        /// Get user name
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(OMS.Utilities.EditDataUtil.ToFixCodeDB(in1, M_User.USER_CODE_MAX_LENGTH));
                    if (data != null && data.ID != Constant.DEFAULT_ID && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userName1 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        //-------2014/12/08 ISV-HUNG Edit Start -----------//
        /// <summary>
        /// Get vendor
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetVendor(string in1)
        {
            var vendorCd = in1;
            var vendorCdShow = in1;
            vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
            if (vendorCdShow == OMS.Models.M_Vendor.VENDOR_CODE_SUPPORT)
            {
                return string.Empty;
            }
            try
            {
                using (DB db = new DB())
                {
                    VendorService vendor = new VendorService(db);
                    M_Vendor model = vendor.GetByCD(vendorCd);
                    if (model != null && model.StatusFlag == 0)
                    {
                        var result = new
                        {
                            vendorCD = vendorCdShow,
                            vendorName1 = model.VendorName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
                var onlyCd = new
                {
                    vendorCD = vendorCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        //-------2014/12/08 ISV-HUNG Edit End -----------//

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string conditionCd, string condition)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(conditionCd, (int)ConditionFlag.Sales);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            condition = condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Decimal Type
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetDecimalType(int currencyId)
        {
            try
            {
                using (DB db = new DB())
                {
                    Currency_HService currency_HService = new Currency_HService(db);
                    var item = currency_HService.GetByID(currencyId);
                    System.Text.StringBuilder result = new System.Text.StringBuilder();

                    if (item != null)
                    {
                        result.Append("{");
                        var decimalDigit = (item.DecimalType == 1) ? 2 : 0;
                        result.Append(string.Format("\"DecimalDigit\":\"{0}\"", decimalDigit));

                        //Get max leng UnitPrice
                        var maxIntUnitPrice = (item.DecimalType == 1) ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                        result.Append(string.Format(", \"MaxIntUnitPrice\":\"{0}\"", GetMaxIntLength(maxIntUnitPrice)));

                        //Get max leng SubTotal
                        var maxIntSubTotal = (item.DecimalType == 1) ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                        result.Append(string.Format(", \"MaxIntSubTotal\":\"{0}\"", GetMaxIntLength(maxIntSubTotal)));

                        //Get max leng Vat
                        var maxIntVat = (item.DecimalType == 1) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                        result.Append(string.Format(", \"MaxIntVat\":\"{0}\"", GetMaxIntLength(maxIntVat)));

                        result.Append("}");
                        return result.ToString();
                    }
                    else
                    {
                        return string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Max Int Length
        /// </summary>
        /// <param name="maxValue"></param>
        /// <returns></returns>
        public static int GetMaxIntLength(decimal maxValue)
        {
            var maxInt = 0m;
            maxInt = Math.Truncate(maxValue);

            var maxIntLength = maxInt.ToString().Length;
            if (maxIntLength % 3 == 0)
            {
                maxIntLength += (maxIntLength / 3) - 1;
            }
            else
            {
                maxIntLength += (maxIntLength / 3);
            }

            return maxIntLength;
        }

        /// <summary>
        /// Get Product
        /// </summary>
        /// <param name="productCdSetting">Product cd setting</param>
        /// <param name="type">Type Cost or Sell</param>
        /// <param name="salesDate">Sales Date</param>
        /// <param name="productCd">Product CD</param>
        /// <param name="quantity">Quantity</param>
        /// <param name="currencyID">Currency</param>
        /// <param name="fractionType">fraction type</param>
        /// <param name="decimalDigit">decimal Digit</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(string productCdSetting, short type, string salesDate, string productCd, string quantity,
                                         int currencyID, int fractionType, int decimalDigit)
        {
            try
            {
                if (productCd == M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }


                using (DB db = new DB())
                {
                    ProductService service = new ProductService(db);
                    var mProd = service.GetByCD(productCd);

                    if (mProd == null || mProd.StatusFlag != 0)
                    {
                        return string.Empty;
                    }
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    System.Text.StringBuilder result = new System.Text.StringBuilder();
                    result.Append("{");

                    result.Append(string.Format("\"ProductName\":\"{0}\"", mProd.ProductName.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));

                    #region Sell
                    if (type == (short)ProductType.Sell)
                    {
                        //Sell
                        result.Append(string.Format(", \"DescriptionSell\":\"{0}\"", mProd.DescriptionSell.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        result.Append(string.Format(", \"RemarkSell\":\"{0}\"", mProd.RemarkSell.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        result.Append(string.Format(", \"UnitIDSell\":\"{0}\"", mProd.UnitIDSell));
                        result.Append(string.Format(", \"VatTypeSell\":\"{0}\"", mProd.VatTypeSell));

                        var _vatRatio = mProd.VatRatioSell;
                        var vatType = mProd.VatTypeSell;
                        var unitPrice = 0m;
                        var subTotal = 0m;
                        var vat = 0m;

                        #region Currency
                        if (currencyID == mProd.CurrencyIDSell)
                        {
                            unitPrice = mProd.UnitPriceSell;
                        }
                        else
                        {
                            var baseDate = string.IsNullOrEmpty(salesDate) ? db.NowDate : CommonUtil.ParseDate(salesDate);
                            var crcyService = new Currency_HService(db);
                            var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                            if (mProd.CurrencyIDSell == Constant.DEFAULT_ID)
                            {
                                unitPrice = mProd.UnitPriceSell;
                            }
                            else
                            {
                                unitPrice = CommonUtil.ConvertToVND(crcyList[mProd.CurrencyIDSell].ExchangeRate, mProd.UnitPriceSell);
                            }

                            if (currencyID != Constant.DEFAULT_ID)
                            {
                                unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyID].ExchangeRate, unitPrice);
                            }
                        }
                        result.Append(string.Format(", \"UnitPriceSell\":\"{0}\"", unitPrice.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, unitPrice * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"SellTotal\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"SellTotal\":\"{0}\"", string.Empty));
                        }

                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatioSell\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"SellVat\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatioSell\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                        }

                        #endregion
                    }
                    #endregion

                    #region Cost

                    if (type == (short)ProductType.Cost ||
                        productCdSetting == M_Config_D.PRODUCT_CD_SETTING_DOUBLE ||
                        productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME)
                    {
                        VendorService vendorService = new VendorService(db);
                        VendorProductService vendorProductService = new VendorProductService(db);
                        Currency_HService currency_HService = new Currency_HService(db);

                        var crcy = currency_HService.GetByID(mProd.CurrencyIDCost);
                        decimalDigit = crcy.DecimalType == (int)ExchangeRateDecType.Decimal ? 2 : 0;
                        numberFormat = string.Format("N{0}", decimalDigit);

                        //Cost
                        result.Append(string.Format(", \"DescriptionCost\":\"{0}\"", mProd.DescriptionCost.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        result.Append(string.Format(", \"UnitIDCost\":\"{0}\"", mProd.UnitIDCost));
                        result.Append(string.Format(", \"CostCurrency\":\"{0}\"", mProd.CurrencyIDCost));
                        result.Append(string.Format(", \"VatTypeCost\":\"{0}\"", mProd.VatTypeCost));

                        var _vatRatio = mProd.VatRatioCost;
                        var vatType = mProd.VatTypeCost;

                        result.Append(string.Format(", \"UnitPriceCost\":\"{0}\"", mProd.UnitPriceCost.ToString(numberFormat)));
                        var subTotal = 0m;
                        var vat = 0m;
                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, mProd.UnitPriceCost * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"CostTotal\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"CostTotal\":\"{0}\"", string.Empty));
                        }
                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatioCost\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"CostVat\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"CostVat\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatioCost\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                        }

                        result.Append(string.Format(", \"PurchaseFlag\":\"{0}\"", mProd.PurchaseFlag == 1));
                        var vendor = vendorService.GetFirstOrDefaultByProductID(mProd.ID);
                        if (vendor != null && vendor.ID != Constant.DEFAULT_ID)
                        {
                            result.Append(string.Format(", \"VendorProductCD\":\"{0}\"", EditDataUtil.ToFixCodeShow(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW)));
                            result.Append(string.Format(", \"VendorProductName\":\"{0}\"", vendor.VendorName1.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        }
                        else
                        {
                            result.Append(string.Format(", \"VendorProductCD\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"VendorProductName\":\"{0}\"", string.Empty));
                        }
                    }
                    #endregion

                    result.Append("}");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Sell
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcSell(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtSellPrice") || senderId.Contains("txtSellQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);

                        var A1 = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 0);

                        var A2 = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);

                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtSellTotal") || senderId.Contains("txtSellVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Cost
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcCost(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtCostPrice") || senderId.Contains("txtCostQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtCostTotal") || senderId.Contains("txtCostVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotal(string methodVAT
                                       , string[] totals, string[] VATs
                                       , string vatRatio
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                if (string.IsNullOrEmpty(vatRatio))
                {
                    vatRatio = "0";
                }
                decimal? sumTotal = null;
                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = Utilities.Fraction.Round((FractionType)fractionType, totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);
                }

                decimal? sumVAT = null;
                if (sumTotal.HasValue)
                {
                    if (VATs.Any(s => !string.IsNullOrEmpty(s)))
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, VATs.Sum(v => string.IsNullOrEmpty(v) ? 0 : decimal.Parse(v)), 2);
                    }

                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, (sumTotal.GetValueOrDefault() * decimal.Parse(vatRatio)) / 100, 2);
                    }
                }

                decimal? grandTotal = null;
                string numberFormat = string.Format("N{0}", decimalDigit);

                if (sumTotal.HasValue && sumVAT.HasValue)
                {
                    grandTotal = sumTotal.GetValueOrDefault() + sumVAT.GetValueOrDefault();
                }


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtSumTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtSumVat\":\"{0}\"", sumVAT.HasValue ? sumVAT.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtGrandTotal\":\"{0}\"", grandTotal.HasValue ? grandTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));

                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count Attached File
        /// </summary>
        /// <param name="dataId">dataId</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(int dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId, (int)FType.Sales);
                    var result = new
                    {
                        count = count
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion

        #endregion

        #region Method
        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    ctrlID.Length >= errorId.Length && errorId.Length >0 ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    ctrlID.Length >= infoId.Length && infoId.Length > 0 ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            var listDetail = this.GetData();

            //Check model
            switch (mode)
            {
                case Mode.Insert:

                    //Init Data
                    this.InitData();

                    break;
                case Mode.Copy:
                    //Reset data
                    this.txtIssueDate.Value = string.Empty;
                    this.txtUpdateDate.Value = string.Empty;
                    this.txtCreateDate.Value = string.Empty;
                    this.FileAttachedCount = 0;

                    this.txtCustomerCD.SetReadOnly(false);
                    this.txtCustomerNameSearch.SetReadOnly(false);
                    //-------2014/12/08 ISV-HUNG Add Start -----------//
                    this.txtCustomerName.SetReadOnly(!(this.txtCustomerCD.Value == this.customerCdSupport));
                    //-------2014/12/08 ISV-HUNG Add End -----------//
                    using (DB db = new DB())
                    {
                        this.txtSalesDate.Value = db.NowDate;
                        Config_DService configDService = new Config_DService(db);
                        //---------------Add 2015/01/06 ISV-HUNG-----------------//
                        //Comlete Date
                        var expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Complete_Date));
                        if (!expiryDay.HasValue)
                        {
                            this.txtCompleteDate.Value = null;
                        }
                        else
                        {
                            var completeDate = this.txtSalesDate.Value.Value.AddDays(expiryDay.Value);
                            this.txtCompleteDate.Value = completeDate;
                        }

                        //Payment Date
                        expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Payment_Date));
                        if (!expiryDay.HasValue)
                        {
                            this.txtPaymentDate.Value = null;
                        }
                        else
                        {
                            var paymentDate = this.txtSalesDate.Value.Value.AddDays(expiryDay.Value);
                            this.txtPaymentDate.Value = paymentDate;
                        }
                        //---------------Add 2015/01/06 ISV-HUNG-----------------//
                    }
                    //Init default value of PreparedCD
                    if (LoginInfo.User.ID != Constant.DEFAULT_ID)
                    {
                        this.txtPreparedCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                        this.txtPreparedName.Value = LoginInfo.User.UserName2;
                    }
                    //this.chkFinishedFlag.Checked = false;
                    //this.chkFinishedFlag.Disabled = true;

                    this.cmbCurrency.Enabled = true;
                    this.cmbMethodVat.Enabled = true;

                    listDetail.AsParallel().ForAll(s => s.Sell.InternalID = -1);
                    listDetail.AsParallel().ForAll(s => s.CostList.AsParallel().ForAll(c => c.InternalID = -1));
                    this.rptDetail.DataSource = listDetail;
                    this.rptDetail.DataBind();

                    break;
                case Mode.Update:

                    //lock Customer
                    this.txtCustomerCD.SetReadOnly(!this.txtQuotationDate.IsEmpty || this.HaveBillingOrDelivery(this.SalesID));
                    this.txtCustomerNameSearch.SetReadOnly(!this.txtQuotationDate.IsEmpty || this.HaveBillingOrDelivery(this.SalesID));
                    //-------2014/12/08 ISV-HUNG Add Start -----------//
                    if (!this.HaveBillingOrDelivery(this.SalesID))
                    {
                        this.txtCustomerName.SetReadOnly(!(this.txtCustomerCD.Value == this.customerCdSupport));
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(true);
                    }
                    //-------2014/12/08 ISV-HUNG Add End -----------//
                    this.btnSearchCustomer.Disabled = !this.txtQuotationDate.IsEmpty || this.HaveBillingOrDelivery(this.SalesID);

                    //lock Sales date
                    //this.txtSalesDate.SetReadOnly(this.HavePOBillingDelivery(this.SalesID));

                    this.LockHeader(listDetail);

                    //this.chkFinishedFlag.Disabled = false;

                    break;
                case Mode.View:
                    this.DataRemand = false;
                    this.DataCopy = false;

                    base.DisabledLink(this.btnEdit, !base._authority.IsSalesEdit);
                    //base.DisabledLink(this.btnIssue, !base._authority.IsSalesPDF);
                    //base.DisabledLink(this.btnSaleContract, !base._authority.IsSalesPDF);
                    base.DisabledLink(this.btnRemand, !base._authority.IsSalesRemand);
                    base.DisabledLink(this.btnCopy, !base._authority.IsSalesCopy);
                    base.DisabledLink(this.btnDelete, !base._authority.IsSalesDelete);

                    break;
                default:

                    break;
            }

            this.DataRemand = false;
            this.DataCopy = false;
            this.DataIssuing = false;
            //---------------Set enable control at total------------------//
            //Reset value control
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)//for each item
            {
                //Enable control
                this.cmbVatType.Enabled = false;
                this.txtVatRatio.SetReadOnly(true);

                //vat ratio
                this.txtVatRatio.Value = null;

                //vat type
                this.cmbVatType.SelectedValue = null;
                this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);
            }
            else//for total
            {
                //Enable control
                this.cmbVatType.Enabled = true;
                this.txtVatRatio.SetReadOnly(false);

                this.InitDropDownListData(this.cmbVatType, this._vatTypeList);

                bool keepOldValue = true;
                if (this.Mode == Mode.Insert)
                {
                    keepOldValue = false;
                }

                this.SetEnableControlByVatType(this.cmbVatType, this.txtSumVat, this.txtVatRatio, keepOldValue);
            }

            this.SetDecimalDigit(this.cmbCurrency, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                CustomerService customerService = new CustomerService(db);
                UserService userService = new UserService(db);
                ProductService productService = new ProductService(db);
                VendorService vendorService = new VendorService(db);
                Billing_DService billing_DService = new Billing_DService(db);
                Delivery_DService delivery_DService = new Delivery_DService(db);
                Purchase_DService purchase_DService = new Purchase_DService(db);

                var isDecimal = this.IsDecimalCurrency(this.cmbCurrency);

                #region Header Check
                //--------------------------------CustomerCD check----------------------------------------------------------//
                if (this.txtCustomerCD.IsEmpty)
                {
                    base.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_REQUIRE, "Customer Code");
                    this.txtCustomerName.Value = string.Empty;
                }
                else
                {
                    //-------2014/12/08 ISV-HUNG Edit Start -----------//
                    if (!string.Equals(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_SUPPORT))//Check equals product support
                    {
                        //Check exists
                        var customer = customerService.GetByCustomerCD(this.txtCustomerCD.Value);
                        if (customer == null)//Check exists
                        {
                            base.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                            this.txtCustomerName.Value = string.Empty;
                        }
                        else if (customer.StatusFlag != 0)//Check disbale
                        {
                            base.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_CODE_DISABLE, "Customer Code");
                            this.txtCustomerName.Value = string.Empty;
                        }
                        else
                        {
                            this.txtCustomerName.Value = customer.CustomerName1;
                        }
                    }
                    else
                    {
                        //---------------------------------------------Check customer Name--------------------------------------//
                        if (string.IsNullOrEmpty(this.txtCustomerName.Value))
                        {
                            base.SetMessage(this.txtCustomerName.ID, M_Message.MSG_REQUIRE, "Customer Name");
                        }
                    }

                    //---------------------------------------------Check prodcut Name End----------------------------------//
                    if (!this.HaveBillingOrDelivery(this.SalesID))
                    {
                        this.txtCustomerName.SetReadOnly(!(this.txtCustomerCD.Value == this.customerCdSupport));
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(true);
                    }
                    //-------2014/12/08 ISV-HUNG Edit End -----------//
                }
                //--------------------------------End CustomerCD check----------------------------------------------------------//

                //--------------------------------SalesDate check---------------------------------------------------------------//
                if (!this.txtSalesDate.Value.HasValue)//Check required
                {
                    base.SetMessage(this.txtSalesDate.ID, M_Message.MSG_REQUIRE, "Sales Date");
                }
                else
                {
                    if (this.txtQuotationDate.Value.HasValue)
                    {
                        if (this.txtSalesDate.Value < this.txtQuotationDate.Value)
                        {
                            base.SetMessage(this.txtSalesDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Sales Date", "Quote Date");
                        }
                    }
                }
                //--------------------------------End SalesDate check---------------------------------------------------------------//

                //--------------------------------Prepared check-------------------------------------------------------------------//
                if (this.txtPreparedCD.IsEmpty)
                {
                    base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_REQUIRE, "Prepared Code");
                    this.txtPreparedName.Value = string.Empty;
                }
                else
                {
                    //Check exists
                    var user = userService.GetByUserCD(this.txtPreparedCD.Value);
                    if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                    {
                        base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Prepared Code");
                        this.txtPreparedName.Value = string.Empty;
                    }
                    else if (user.StatusFlag != 0)//Check disbale
                    {
                        base.SetMessage(this.txtPreparedCD.ID, M_Message.MSG_CODE_DISABLE, "Prepared Code");
                        this.txtPreparedName.Value = string.Empty;
                    }
                    else
                    {
                        this.txtPreparedName.Value = user.UserName2;
                    }
                }
                //--------------------------------End Prepared check-------------------------------------------------------------------//

                //--------------------------------Approved check-----------------------------------------------------------------//
                if (this.txtApprovedCD.IsEmpty)
                {
                    base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_REQUIRE, "Approved Code");
                    this.txtApprovedName.Value = string.Empty;
                }
                else
                {
                    //Check exists
                    var user = userService.GetByUserCD(this.txtApprovedCD.Value);
                    if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                    {
                        base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Approved Code");
                        this.txtApprovedName.Value = string.Empty;
                    }
                    else if (user.StatusFlag != 0)//Check disbale
                    {
                        base.SetMessage(this.txtApprovedCD.ID, M_Message.MSG_CODE_DISABLE, "Approved Code");
                        this.txtApprovedName.Value = string.Empty;
                    }
                    else
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }
                //--------------------------------End Approved check-----------------------------------------------------------------//

                //--------------------------------Subject check-----------------------------------------------------------------//
                if (this.txtSubject.IsEmpty)
                {
                    base.SetMessage(this.txtSubject.ID, M_Message.MSG_REQUIRE, "Subject");
                }
                //--------------------------------End Subject check-----------------------------------------------------------------//

                //--------------------------------Sales1 Check-----------------------------------------------------------//
                if (!this.txtSalesCD1.IsEmpty)
                {
                    //Check exists
                    var user = userService.GetByUserCD(this.txtSalesCD1.Value);
                    if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                    {
                        base.SetMessage(this.txtSalesCD1.ID, M_Message.MSG_NOT_EXIST_CODE, "Sales Code 1");
                        this.txtSalesName1.Value = string.Empty;
                    }
                    else if (user.StatusFlag != 0)//Check disbale
                    {
                        base.SetMessage(this.txtSalesCD1.ID, M_Message.MSG_CODE_DISABLE, "Sales Code 1");
                        this.txtSalesName1.Value = string.Empty;
                    }
                    else
                    {
                        this.txtSalesName1.Value = user.UserName2;
                    }
                }
                //--------------------------------End Sales1 Check-----------------------------------------------------------//

                //--------------------------------Sales2 Check-----------------------------------------------------------//
                if (!this.txtSalesCD2.IsEmpty)
                {
                    //Check exists
                    var user = userService.GetByUserCD(this.txtSalesCD2.Value);
                    if (user == null || user.ID == Constant.DEFAULT_ID)//Check exists
                    {
                        base.SetMessage(this.txtSalesCD2.ID, M_Message.MSG_NOT_EXIST_CODE, "Sales Code 2");
                        this.txtSalesName2.Value = string.Empty;
                    }
                    else if (user.StatusFlag != 0)//Check disbale
                    {
                        base.SetMessage(this.txtSalesCD2.ID, M_Message.MSG_CODE_DISABLE, "Sales Code 2");
                        this.txtSalesName2.Value = string.Empty;
                    }
                    else
                    {
                        this.txtSalesName2.Value = user.UserName2;
                    }
                }
                //--------------------------------End Sales2 Check-----------------------------------------------------------//
                #endregion

                #region Detail Check
                //--------------------------------Check detail sell----------------------------------------------------------//
                var listDetail = this.GetData();

                for (int i = 0; i < listDetail.Count; i++)
                {
                    #region Check Sell
                    int rowIndex = i + 1;
                    var item = listDetail[i];

                    //---------------------------------Check sell product code -----------------------------------------------------//
                    //-------2014/12/10 ISV-HUNG Edit Start -----------//
                    if (string.IsNullOrEmpty(item.Sell.ProductCD) && this.ProductCDUsed)//check required
                    //-------2014/12/10 ISV-HUNG Edit End -----------//
                    {
                        base.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Code", rowIndex);
                    }

                    if (!string.Equals(item.Sell.ProductCD, M_Product.PRODUCT_CODE_SUPPORT) && this.ProductCDUsed)//Check equals product support
                    {
                        M_Product model = productService.GetByCD(item.Sell.ProductCD);//Check exists in database
                        if (model == null)//Check exists
                        {
                            base.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", rowIndex);
                        }
                        else if (model.StatusFlag != 0)//Check disable
                        {
                            base.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", rowIndex);
                        }
                        else
                        {
                            if (string.IsNullOrEmpty(item.Sell.ProductName))
                            {
                                item.Sell.ProductName = model.ProductName;
                            }
                        }
                    }

                    //---------------------------------------------Check prodcut Name--------------------------------------//
                    else if (string.IsNullOrEmpty(item.Sell.ProductName))
                    {
                        base.SetMessage(string.Format("txtSellProductName_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Name", rowIndex);
                    }
                    //---------------------------------------------End Check prodcut Name--------------------------------------//

                    //---------------------------------------------Check sell unit price-------------------------------------------//
                    if (!item.Sell.Price.HasValue)//Check required
                    {
                        base.SetMessage(string.Format("txtSellPrice_{0}", i), M_Message.MSG_REQUIRE_GRID, "Unit Price", rowIndex);
                    }
                    else
                    {
                        //Check max length
                        decimal maxValue = (isDecimal) ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                        var decimalDigit = (isDecimal) ? 2 : 0;
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        if (item.Sell.Price.Value > maxValue)
                        {
                            base.SetMessage(string.Format("txtSellPrice_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), rowIndex);
                        }
                    }
                    //---------------------------------------------End Check sell unit price-------------------------------------------//

                    //---------------------------------------------Check sell Quantity-------------------------------------------------//
                    if (!item.Sell.Quantity.HasValue)//Check required
                    {
                        base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", rowIndex);
                    }
                    else
                    {
                        if (item.Sell.Quantity.Value == 0)//Check must greater than 0
                        {
                            base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, rowIndex);
                        }

                        //Check max length
                        var maxValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                        string numberFormat = string.Format("N{0}", this.QuantityDecimal);
                        if (item.Sell.Quantity.Value > maxValue)
                        {
                            base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(numberFormat), rowIndex);
                        }

                        if (item.Sell.InternalID != -1)
                        {
                            var billingQuantity = billing_DService.GetSumQuantityBySalesSellID(item.Sell.InternalID);
                            if (item.Sell.Quantity.Value < billingQuantity)
                            {
                                base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Q'ty", string.Format("Bill Q'ty({0})", billingQuantity.ToString(numberFormat)), rowIndex);
                            }

                            var deliveryQuantity = delivery_DService.GetSumQuantityBySalesSellID(item.Sell.InternalID);
                            if (item.Sell.Quantity.Value < deliveryQuantity)
                            {
                                base.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Q'ty", string.Format("Delivery Q'ty({0})", deliveryQuantity.ToString(numberFormat)), rowIndex);
                            }
                        }
                    }
                    //---------------------------------------------End Check sell Quantity-------------------------------------------------//

                    //---------------------------------------------Check sub total--------------------------------------------------------//
                    if (item.Sell.Total.HasValue)//Check max length
                    {
                        var maxValue = (isDecimal) ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                        var minValue = (isDecimal) ? Constant.MIN_SUB_TOTAL_DECIMAL : Constant.MIN_SUB_TOTAL_NOT_DECIMAL;

                        var decimalDigit = (isDecimal) ? 2 : 0;
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        if (item.Sell.Total.Value > maxValue)
                        {
                            base.SetMessage(string.Format("txtSellTotal_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(numberFormat), rowIndex);
                        }
                        if (item.Sell.Total.Value < minValue)
                        {
                            base.SetMessage(string.Format("txtSellTotal_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Sub Total", minValue.ToString(numberFormat), rowIndex);
                        }
                    }
                    //---------------------------------------------End Check sub total--------------------------------------------------------//

                    //---------------------------------------------Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//
                    if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
                    {
                        if (item.Sell.VatType == (int)VATFlg.Exclude)
                        {
                            //--------------------------------------Check sell VAT------------------------------------------------------------//
                            if (item.Sell.Vat.HasValue)
                            {
                                //Check max length
                                var maxValue = (isDecimal) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                var minValue = (isDecimal) ? Constant.MIN_SUB_VAT_DECIMAL : Constant.MIN_SUB_VAT_NOT_DECIMAL;

                                var decimalDigit = (isDecimal) ? 2 : 0;
                                string numberFormat = string.Format("N{0}", decimalDigit);
                                if (item.Sell.Vat.Value > maxValue)
                                {
                                    base.SetMessage(string.Format("txtSellVat_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VAT", maxValue.ToString(numberFormat), rowIndex);
                                }
                                if (item.Sell.Vat.Value < minValue)
                                {
                                    base.SetMessage(string.Format("txtSellVat_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "VAT", minValue.ToString(numberFormat), rowIndex);
                                }
                            }
                            //--------------------------------------End Check sell VAT------------------------------------------------------------//

                            //--------------------------------------Check sell VatRatio-----------------------------------------------------------//
                            if (!item.Sell.VatRatio.HasValue)//Check required
                            {
                                if (string.IsNullOrEmpty(item.Sell.ProductCD) &&
                                    string.IsNullOrEmpty(item.Sell.ProductName) &&
                                    string.IsNullOrEmpty(item.Sell.Description) &&
                                    string.IsNullOrEmpty(item.Sell.Remark) &&
                                    item.Sell.UnitID == Constant.DEFAULT_ID &&
                                    !item.Sell.Price.HasValue &&
                                    !item.Sell.Quantity.HasValue &&
                                    !item.Sell.Total.HasValue &&
                                    !item.Sell.Vat.HasValue)
                                {
                                    if (!item.Sell.VatRatio.HasValue)
                                    {
                                        item.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
                                    }
                                }
                                else
                                {
                                    base.SetMessage(string.Format("txtSellVatRatio_{0}", i), M_Message.MSG_REQUIRE_GRID, "VatRatio", rowIndex);
                                }
                            }
                            else
                            {
                                //Check max length
                                if (item.Sell.VatRatio.Value > Constant.MAX_VATRATIO)
                                {
                                    base.SetMessage(string.Format("txtSellVatRatio_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, rowIndex);
                                }
                            }
                            //--------------------------------------End Check sell VatRatio-----------------------------------------------------------//
                        }
                    }
                    //---------------------------------------------End Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//

                    //---------------------------------------------Check detail COST---------------------------------------------------------------------//
                    item.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                    #endregion

                    for (int j = 0; j < item.CostList.Count; j++)
                    {
                        #region Check Cost
                        var rowCostIndex = string.Format("{0}/{1}", rowIndex, j + 1);

                        var itemCost = item.CostList[j];

                        if (this.ProductCDUsed)
                        {
                            if (!itemCost.PurchaseFlag && string.IsNullOrEmpty(itemCost.ProductCD) &&
                                string.IsNullOrEmpty(itemCost.ProductName) &&
                                string.IsNullOrEmpty(itemCost.Description) &&
                                !itemCost.Price.HasValue &&
                                !itemCost.Quantity.HasValue &&
                                !itemCost.Total.HasValue &&
                                !itemCost.Vat.HasValue)
                            {
                                if (!itemCost.VatRatio.HasValue)
                                {
                                    itemCost.VatRatio = decimal.Parse(DefaultVAT);
                                }
                                continue;
                            }
                        }
                        else
                        {
                            if (!itemCost.PurchaseFlag &&
                                string.IsNullOrEmpty(itemCost.ProductName) &&
                                string.IsNullOrEmpty(itemCost.Description) &&
                                !itemCost.Price.HasValue &&
                                !itemCost.Quantity.HasValue &&
                                !itemCost.Total.HasValue &&
                                !itemCost.Vat.HasValue)
                            {
                                if (!itemCost.VatRatio.HasValue)
                                {
                                    itemCost.VatRatio = decimal.Parse(DefaultVAT);
                                }
                                continue;
                            }
                        }

                        //Currency cost
                        var isDecimalCost = this.IsDecimalCurrency(null, itemCost.CurrencyID);

                        //------------------------------------------Check Cost product----------------------------------------------------//
                        if (itemCost.PurchaseFlag)
                        {
                            if (this.ProductCDSettingSame && string.IsNullOrEmpty(itemCost.ProductCD))
                            {
                                itemCost.ProductCD = item.Sell.ProductCD;
                            }
                        }

                        //--------------------------------------------Check product Name--------------------------------------------------//
                        //-------2014/12/10 ISV-HUNG Edit Start -----------//
                        if (string.IsNullOrEmpty(itemCost.ProductCD) && this.ProductCDUsed)
                        {
                            item.Sell.Collapsed = "in";
                            base.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Code", rowCostIndex);
                        }
                        //--------------------------------------------End Check product Name--------------------------------------------------//

                        else
                        {
                            if (!string.Equals(itemCost.ProductCD, M_Product.PRODUCT_CODE_SUPPORT))//Check product support
                            {
                                var product = productService.GetByCD(itemCost.ProductCD);
                                if (product == null)//Check exists
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", rowCostIndex);
                                }
                                else if (product.StatusFlag != 0)//Check disable
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", rowCostIndex);
                                }
                                else
                                {
                                    if (string.IsNullOrEmpty(itemCost.ProductName))
                                    {
                                        itemCost.ProductName = product.ProductName;
                                    }
                                }
                            }
                        }
                        //-------2014/12/10 ISV-HUNG Edit End -----------//
                        //------------------------------------------End Check Cost product----------------------------------------------------//

                        //--------------------------------------------Check product Name--------------------------------------------------//
                        if (string.IsNullOrEmpty(itemCost.ProductName))
                        {
                            item.Sell.Collapsed = "in";
                            base.SetMessage(string.Format("{0}_txtCostProductName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Name", rowCostIndex);
                        }
                        //--------------------------------------------End Check product Name--------------------------------------------------//


                        //------------------------------------------Check required------------------------------------------------------------//
                        if (itemCost.PurchaseFlag)//purchase flag check
                        {
                            //--------------------------------------------Check product Name--------------------------------------------------//
                            //if (string.IsNullOrEmpty(itemCost.ProductName))
                            //{
                            //    item.Sell.Collapsed = "in";
                            //    base.SetMessage(string.Format("{0}_txtCostProductName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Name", rowCostIndex);
                            //}
                            //--------------------------------------------End Check product Name--------------------------------------------------//

                            //--------------------------------------------Check unit price--------------------------------------------------------//
                            if (!itemCost.Price.HasValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostPrice_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Unit Price", rowCostIndex);
                            }
                            //--------------------------------------------End Check unit price--------------------------------------------------------//

                            //--------------------------------------------Check quantity-------------------------------------------------------------//
                            if (!itemCost.Quantity.HasValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Q'ty", rowCostIndex);
                            }
                            //--------------------------------------------End Check quantity-------------------------------------------------------------//

                            //--------------------------------------------Check vendor----------------------------------------------------------------//
                            if (string.IsNullOrEmpty(itemCost.VendorCD))
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Vendor Code", rowCostIndex);
                            }
                            //--------------------------------------------End Check vendor----------------------------------------------------------------//
                        }
                        //------------------------------------------End Check required------------------------------------------------------------//

                        //------------------------------------------Check input length------------------------------------------------------------------//
                        //------------------------------------------Check unit price--------------------------------------------------------------------//
                        if (itemCost.Price.HasValue)
                        {
                            //Check max length
                            decimal maxValue = (isDecimalCost) ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                            var decimalDigit = (isDecimalCost) ? 2 : 0;
                            string numberFormat = string.Format("N{0}", decimalDigit);
                            if (itemCost.Price.Value > maxValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostPrice_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), rowIndex);
                            }
                        }
                        //------------------------------------------End Check unit price--------------------------------------------------------------------//

                        //------------------------------------------Check quantity--------------------------------------------------------------------------//
                        if (itemCost.Quantity.HasValue)
                        {
                            if (itemCost.PurchaseFlag && itemCost.Quantity.Value == 0)//Check must greater than 0
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, rowCostIndex);
                            }

                            //Check max length
                            var maxValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                            string numberFormat = string.Format("N{0}", this.QuantityDecimal);
                            if (itemCost.Quantity.Value > maxValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(numberFormat), rowCostIndex);
                            }

                            if (itemCost.InternalID != -1)
                            {
                                var purchaseQuantity = purchase_DService.GetSumQuantityBySalesCostID(itemCost.InternalID);
                                if (itemCost.Quantity.Value < purchaseQuantity)
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Q'ty", string.Format("Purchase Q'ty({0})", purchaseQuantity.ToString(numberFormat)), rowCostIndex);
                                }
                            }
                        }
                        //------------------------------------------End Check quantity--------------------------------------------------------------------------//

                        //------------------------------------------Check sub total-------------------------------------------------------------------------//
                        if (itemCost.Total.HasValue)
                        {
                            var maxValue = (isDecimalCost) ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                            var minValue = (isDecimalCost) ? Constant.MIN_SUB_TOTAL_DECIMAL : Constant.MIN_SUB_TOTAL_NOT_DECIMAL;

                            var decimalDigit = (isDecimalCost) ? 2 : 0;
                            string numberFormat = string.Format("N{0}", decimalDigit);
                            if (itemCost.Total.Value > maxValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostTotal_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(numberFormat), rowIndex);
                            }
                            if (itemCost.Total.Value < minValue)
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostTotal_{1}", i, j), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Sub Total", minValue.ToString(numberFormat), rowIndex);
                            }
                        }
                        //------------------------------------------End Check sub total-------------------------------------------------------------------------//

                        //---------------------------------------------Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//
                        if (itemCost.VatType == (int)VATFlg.Exclude)
                        {
                            //--------------------------------------Check cost vat---------------------------------------------------------------//
                            if (itemCost.Vat.HasValue)
                            {
                                var maxValue = (isDecimalCost) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                var minValue = (isDecimalCost) ? Constant.MIN_SUB_VAT_DECIMAL : Constant.MIN_SUB_VAT_NOT_DECIMAL;

                                var decimalDigit = (isDecimalCost) ? 2 : 0;
                                string numberFormat = string.Format("N{0}", decimalDigit);
                                if (itemCost.Vat.Value > maxValue)
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVat_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VAT", maxValue.ToString(numberFormat), rowIndex);
                                }
                                if (itemCost.Vat.Value < minValue)
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVat_{1}", i, j), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "VAT", minValue.ToString(numberFormat), rowIndex);
                                }
                            }
                            //--------------------------------------End Check cost vat---------------------------------------------------------------//
                        }
                        //---------------------------------------------End Check VAT,VAT TYPE, VAT RATIO----------------------------------------------//

                        //---------------------------------------------Check vendor------------------------------------------------------------------//
                        if (!string.IsNullOrEmpty(itemCost.VendorCD))
                        {
                            //-------2014/12/08 ISV-HUNG Edit Start -----------//
                            if (!string.Equals(itemCost.VendorCD, M_Vendor.VENDOR_CODE_SUPPORT))//Check equals vendor support
                            {
                                var vendorCd = itemCost.VendorCD;
                                vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                                var vendor = vendorService.GetByCD(vendorCd);
                                if (vendor == null)//Check exists
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_NOT_EXIST_CODE_GRID, "Vendor Code", rowCostIndex);
                                }
                                else if (vendor.StatusFlag != 0)//Check disable
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_CODE_DISABLE_GRID, "Vendor Code", rowCostIndex);
                                }
                            }
                            else
                            {
                                //---------------------------------------------Check vendor Name--------------------------------------//
                                if (string.IsNullOrEmpty(itemCost.VendorName))
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVendorName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Vendor Name", rowCostIndex);
                                }
                                //---------------------------------------------Check vendor Name End----------------------------------//
                            }
                            //-------2014/12/08 ISV-HUNG Edit End -----------//
                        }
                        //---------------------------------------------End Check vendor------------------------------------------------------------------//

                        if (itemCost.VatType == (int)VATFlg.Exclude)
                        {
                            //--------------------------------------Check Cost VatRatio----------------------------------------------------------------//
                            if (!itemCost.VatRatio.HasValue)//Check required
                            {
                                item.Sell.Collapsed = "in";
                                base.SetMessage(string.Format("{0}_txtCostVatRatio_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "VatRatio", rowCostIndex);
                            }
                            else
                            {
                                //Check max length
                                if (itemCost.VatRatio.Value > Constant.MAX_VATRATIO)
                                {
                                    item.Sell.Collapsed = "in";
                                    base.SetMessage(string.Format("{0}_txtCostVatRatio_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO.ToString("#,###"), rowCostIndex);
                                }
                            }
                        }
                        //--------------------------------------End Check Cost VatRatio----------------------------------------------------------------//

                        //------------------------------------------End Check input length------------------------------------------------------------------//
                    }
                    //---------------------------------------------End Check detail COST---------------------------------------------------------------------//
                        #endregion
                    //---------------------------------End Check product code -----------------------------------------------------//
                }
                //--------------------------------End Check detail sell----------------------------------------------------------//
                #endregion

                //--------------------------------Check Sum Total,Sum VAT, Grand Total------------------------------------------//
                decimal maxSumValue = (isDecimal) ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                decimal minSumValue = (isDecimal) ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;

                var decimalSumDigit = (isDecimal) ? 2 : 0;
                string numberSumFormat = string.Format("N{0}", decimalSumDigit);

                if (this.txtSumTotal.Value.HasValue)
                {
                    if (this.txtSumTotal.Value.Value > maxSumValue)
                    {
                        base.SetMessage(this.txtSumTotal.ID, M_Message.MSG_LESS_THAN_EQUAL, "Total", maxSumValue.ToString(numberSumFormat));
                    }
                    if (this.txtSumTotal.Value.Value < minSumValue)
                    {
                        base.SetMessage(this.txtSumTotal.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Total", minSumValue.ToString(numberSumFormat));
                    }
                }

                maxSumValue = (isDecimal) ? Constant.MAX_SUM_VAT_DECIMAL : Constant.MAX_SUM_VAT_NOT_DECIMAL;
                minSumValue = (isDecimal) ? Constant.MIN_SUM_VAT_DECIMAL : Constant.MIN_SUM_VAT_NOT_DECIMAL;

                if (this.txtSumVat.Value.HasValue)
                {
                    if (this.txtSumVat.Value.Value > maxSumValue)
                    {
                        base.SetMessage(this.txtSumVat.ID, M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxSumValue.ToString(numberSumFormat));
                    }
                    if (this.txtSumVat.Value.Value < minSumValue)
                    {
                        base.SetMessage(this.txtSumVat.ID, M_Message.MSG_GREATER_THAN_EQUAL, "VAT", minSumValue.ToString(numberSumFormat));
                    }
                }

                maxSumValue = (isDecimal) ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                minSumValue = (isDecimal) ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;

                if (this.txtGrandTotal.Value.HasValue)
                {
                    if (this.txtGrandTotal.Value.Value > maxSumValue)
                    {
                        base.SetMessage(this.txtGrandTotal.ID, M_Message.MSG_LESS_THAN_EQUAL, "Grand Total", maxSumValue.ToString(numberSumFormat));
                    }
                    if (this.txtGrandTotal.Value.Value < minSumValue)
                    {
                        base.SetMessage(this.txtGrandTotal.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Grand Total", minSumValue.ToString(numberSumFormat));
                    }
                }
                //--------------------------------EndCheck Sum Total,Sum VAT, Grand Total------------------------------------------//

                //--------------------------------Check required input detail---------------------------------------------------//
                //Check vat ratio total require
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
                {
                    var vatType = Convert.ToInt32(this.cmbVatType.SelectedItem.Value);
                    if (vatType == (int)VATFlg.Exclude)
                    {
                        if (!this.txtVatRatio.Value.HasValue)
                        {
                            base.SetMessage(this.txtVatRatio.ID, M_Message.MSG_REQUIRE, "VatRatio");
                        }
                        this.txtVatRatio.SetReadOnly(false);
                        this.txtSumVat.SetReadOnly(false);
                    }
                    else
                    {
                        this.txtVatRatio.SetReadOnly(true);
                        this.txtSumVat.SetReadOnly(true);
                    }
                }
                //--------------------------------End Check required input detail---------------------------------------------------//

                //Reset datasource
                this.rptDetail.DataSource = listDetail;
                this.rptDetail.DataBind();
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Get Default Data DropDownList
        /// </summary>
        private void GetDefaultDataDropDownList()
        {
            using (DB db = new DB())
            {
                //Get ExchangeRate
                Currency_HService currencyHService = new Currency_HService(db);
                var crcyItems = currencyHService.GetListDropdown();

                //Get ExchangeRate
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                //MethodVatList
                Config_HService configHService = new Config_HService(db);
                Config_DService configDService = new Config_DService(db);
                this._methodVatList = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_VAT);
                this._defaultMethodVat = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_METHOD_VAT);

                //Quantity Decimal
                this.QuantityDecimal = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                //Default View Cost
                this.DefaultCostView = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_COST_VIEW);

                //Product Code Setting
                this.ProductCDSetting = int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_SETTING));

                //VatTypeList
                this._vatTypeList = configHService.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
                this._defaultVatType = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);

                //Get Unit
                UnitService unitService = new UnitService(db);
                this._unitList = unitService.GetDataForDropDownList();

                //Default VAT
                this.DefaultVAT = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL);

                //Fraction Type
                this._fractionType = (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                //Default Profit
                this._defaultProfit = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_PROFIT_VALUE);
                this._profitSetting = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PROFIT_SETTING);

                //-------2014/12/10 ISV-HUNG Edit Start -----------//
                //ProductCD Used
                this._productCDUsed = int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED));
                //-------2014/12/10 ISV-HUNG Edit End -----------//

                //---------------Add 2014/12/29 ISV-HUNG-------------------------//
                SettingService settingService = new SettingService(db);
                var settingFile = settingService.GetData();
                this.ListSalesContractFile = new List<string>();
                if (!string.IsNullOrEmpty(settingFile.SalesContractFile1) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.SalesContractFile1))
                {
                    this.ListSalesContractFile.Add(settingFile.SalesContractFile1);
                }
                if (!string.IsNullOrEmpty(settingFile.SalesContractFile2) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.SalesContractFile2))
                {
                    this.ListSalesContractFile.Add(settingFile.SalesContractFile2);
                }
                if (!string.IsNullOrEmpty(settingFile.SalesContractFile3) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.SalesContractFile3))
                {
                    this.ListSalesContractFile.Add(settingFile.SalesContractFile3);
                }
                if (!string.IsNullOrEmpty(settingFile.SalesContractFile4) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.SalesContractFile4))
                {
                    this.ListSalesContractFile.Add(settingFile.SalesContractFile4);
                }
                if (!string.IsNullOrEmpty(settingFile.SalesContractFile5) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.SalesContractFile5))
                {
                    this.ListSalesContractFile.Add(settingFile.SalesContractFile5);
                }

                this.rptListSalesContractFile.DataSource = this.ListSalesContractFile;
                this.rptListSalesContractFile.DataBind();
                //---------------Add 2014/12/29 ISV-HUNG-------------------------//

                if (!this.IsPostBack)
                {
                    var salesDate = db.NowDate;
                    this.txtSalesDate.Value = salesDate;

                    //---------------Add 2015/01/06 ISV-HUNG-----------------//
                    //Comlete Date
                    var expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Complete_Date));
                    if (!expiryDay.HasValue)
                    {
                        this.txtCompleteDate.Value = null;
                    }
                    else
                    {
                        var completeDate = salesDate.AddDays(expiryDay.Value);
                        this.txtCompleteDate.Value = completeDate;
                    }

                    //Payment Date
                    expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Payment_Date));
                    if (!expiryDay.HasValue)
                    {
                        this.txtPaymentDate.Value = null;
                    }
                    else
                    {
                        var paymentDate = salesDate.AddDays(expiryDay.Value);
                        this.txtPaymentDate.Value = paymentDate;
                    }
                    //---------------Add 2015/01/06 ISV-HUNG-----------------//
                }
            }
        }

        /// <summary>
        /// Init DropDownList
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.SalesID = 0;
            this.FileAttachedCount = 0;
            //-------2014/12/08 ISV-HUNG Add Start -----------//
            this.txtCustomerName.SetReadOnly(true);
            //-------2014/12/08 ISV-HUNG Add End -----------//

            //Init default value of PreparedCD
            if (LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtPreparedCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPreparedName.Value = LoginInfo.User.UserName2;
            }

            this.cmbMethodVat.SelectedValue = this._defaultMethodVat;
            this.CurrencyIDOld = Convert.ToInt32(this.cmbCurrency.SelectedValue);
            this.MethodVATOld = Convert.ToInt32(this.cmbMethodVat.SelectedValue);

            int defaultVatType = int.Parse(this._defaultVatType);
            if (this._defaultMethodVat == M_Config_D.METHOD_VAT_SUM)
            {
                this.cmbVatType.SelectedValue = defaultVatType.ToString();
                defaultVatType = -1;
            }

            //this.chkFinishedFlag.Checked = false;
            //this.chkFinishedFlag.Disabled = true;

            IList<SalesDetailInfo> initList = new List<SalesDetailInfo>();

            //Init sell item
            SalesDetailInfo emptyItemSell = new SalesDetailInfo();
            emptyItemSell.Sell = new SalesSellInfo();
            emptyItemSell.Sell.InternalID = -1;
            if (!string.IsNullOrEmpty(this._defaultProfit))
            {
                emptyItemSell.Sell.Profit = decimal.Parse(this._defaultProfit);
            }
            emptyItemSell.Sell.No = 1;
            emptyItemSell.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            emptyItemSell.Sell.VatRatio = defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE) ? (decimal?)decimal.Parse(this.DefaultVAT) : null;
            emptyItemSell.Sell.VatType = defaultVatType;

            //Init cost item list
            emptyItemSell.CostList = new List<SalesCostInfo>();
            defaultVatType = int.Parse(this._defaultVatType);
            SalesCostInfo emptyItemCost = new SalesCostInfo();
            emptyItemCost.InternalID = -1;
            emptyItemCost.No = 1;
            emptyItemCost.SellNo = 1;
            emptyItemCost.SellNoDisp = 1;
            emptyItemCost.VatRatio = defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE) ? (decimal?)decimal.Parse(this.DefaultVAT) : null;
            emptyItemCost.VatType = defaultVatType;
            emptyItemSell.CostList.Add(emptyItemCost);

            //Add item sell
            initList.Add(emptyItemSell);

            //Add data source
            this.rptDetail.DataSource = initList;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Init MaxLength
        /// </summary>
        private void InitMaxLength()
        {
            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;

            this.txtAttn.MaxLength = M_Customer.CONTACT_PERSON_MAX_LENGTH;

            this.txtAdd1.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd2.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd3.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;

            this.txtTel.MaxLength = M_Customer.TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Customer.FAX_MAX_LENGTH;

            this.txtSubject.MaxLength = T_Sales_H.PROJECT_NAME_MAX_LENGTH;
            this.txtMemo.MaxLength = T_Sales_H.MEMO_MAX_LENGTH;

            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtApprovedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;

            this.txtContractNo.MaxLength = T_Sales_H.CONTRACT_NO_MAX_LENGTH;

            this.txtSalesCD1.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSalesCD2.MaxLength = M_User.MAX_USER_CODE_SHOW;

            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditions.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            this.txtCustomerNameSearch.MaxLength = 10;
        }

        /// <summary>
        /// Get Sales
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Sales
                return sales_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        /// <param name="sales">T_Sales_H</param>
        private void ShowHeaderData(T_Sales_H sales)
        {
            this.CurrencyIDOld = sales.CurrencyID;
            this.MethodVATOld = sales.MethodVat;

            //Display header
            this.SalesID = sales.ID;
            this.txtSalesNo.Value = sales.SalesNo;
            this.txtSalesDate.Value = sales.SalesDate;
            this.txtQuotationNo.Value = sales.QuoteNo;
            if (sales.QuoteDate == DATE_TIME_DEFAULT)
            {
                this.txtQuotationDate.Value = null;
            }
            else
            {
                this.txtQuotationDate.Value = sales.QuoteDate;
            }

            this.txtPreparedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(sales.PreparedCD, M_User.MAX_USER_CODE_SHOW);
            this.txtPreparedName.Value = sales.PreparedName;
            this.txtApprovedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(sales.ApprovedCD, M_User.MAX_USER_CODE_SHOW);
            this.txtApprovedName.Value = sales.ApprovedName;
            this.txtContractNo.Value = sales.ContractNo;
            if (sales.ContractDate == DATE_TIME_DEFAULT)
            {
                this.txtContractDate.Value = null;
            }
            else
            {
                this.txtContractDate.Value = sales.ContractDate;
            }

            this.txtSalesCD1.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(sales.SalesCD1, M_User.MAX_USER_CODE_SHOW);
            this.txtSalesName1.Value = sales.SalesName1;
            this.txtSalesCD2.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(sales.SalesCD2, M_User.MAX_USER_CODE_SHOW);
            this.txtSalesName2.Value = sales.SalesName2;
            this.txtCustomerCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(sales.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.txtCustomerName.Value = sales.CustomerName;
            this.txtCustomerNameSearch.Value = string.Empty;
            this.txtAttn.Value = sales.ContactPerson;
            this.txtAdd1.Value = sales.CustomerAddress1;
            this.txtAdd2.Value = sales.CustomerAddress2;
            this.txtAdd3.Value = sales.CustomerAddress3;
            this.txtTel.Value = sales.Tel;
            this.txtFax.Value = sales.FAX;
            this.txtSubject.Value = sales.SubjectName;
            this.txtMemo.Value = sales.Memo;

            //-------2014/12/08 ISV-HUNG Add Start -----------//
            this.txtApproved.Value = sales.Approved;
            this.txtPosition.Value = sales.Position;
            //-------2014/12/08 ISV-HUNG Add End -----------//

            //---------------Add 2015/01/06-----------------//
            if (sales.CompleteDate == DATE_TIME_DEFAULT)
            {
                this.txtCompleteDate.Value = null;
            }
            else
            {
                this.txtCompleteDate.Value = sales.CompleteDate;
            }

            if (sales.PaymentDate == DATE_TIME_DEFAULT)
            {
                this.txtPaymentDate.Value = null;
            }
            else
            {
                this.txtPaymentDate.Value = sales.PaymentDate;
            }
            //---------------Add 2015/01/06-----------------//

            this.cmbCurrency.SelectedValue = sales.CurrencyID.ToString();
            this.cmbMethodVat.SelectedValue = sales.MethodVat.ToString();

            //Show condition
            this.txtConditions.Value = this.GetConditions(sales.ID);
            this.OldCondition = this.GetConditions(sales.ID);

            //Show detail
            this.ShowDetailData(sales.ID);

            this.SetDecimalDigit(this.cmbCurrency, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(this.cmbCurrency, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);

            this.txtSumTotal.Value = sales.Total;

            this.txtSumVat.Value = sales.Vat;

            this.txtGrandTotal.Value = sales.GrandTotal;

            //2014/12/18 ISV-HUNG - Delete Start
            //this.txtSumProfit.Value = sales.ProfitRatio;
            //2014/12/18 ISV-HUNG - Delete End

            if (sales.VatType == 255)
            {
                this.cmbVatType.SelectedValue = null;
            }
            else
            {
                this.cmbVatType.SelectedValue = sales.VatType.ToString();

                if (sales.VatType == (int)VATFlg.Exclude)
                {
                    this.txtVatRatio.Value = sales.VatRatio;
                }
                else
                {
                    this.txtSumVat.Value = null;
                    this.txtVatRatio.Value = null;
                }
            }

            this.DeleteFlag = sales.StatusFlag == (int)StatusFlag.Lost;
            this.RemaindedFlag = sales.DeleteFlag == 1;

            this.OldUpdateDate = sales.UpdateDate;
            this.OldVersionUpdateDate = sales.VersionUpdateDate;

            using (DB db = new DB())
            {
                UserService userService = new UserService(db);
                AttachedService attachedService = new AttachedService(db);

                //Issue
                var issueUser = userService.GetByID(sales.IssuedUID);
                if (issueUser != null)
                {
                    var issuedDate = (sales.IssuedDate == DATE_TIME_DEFAULT) ? string.Empty : sales.IssuedDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtIssueDate.Value = string.Format("{0} {1}", issueUser.UserName2, issuedDate);
                }
                else
                {
                    this.txtIssueDate.Value = string.Empty;
                }

                //Update
                var updateUser = userService.GetByID(sales.UpdateUID);
                if (updateUser != null)
                {
                    var updateDate = (sales.UpdateDate == DATE_TIME_DEFAULT) ? string.Empty : sales.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                else
                {
                    this.txtUpdateDate.Value = string.Empty;
                }

                //Create
                var createUser = userService.GetByID(sales.CreateUID);
                if (createUser != null)
                {
                    var createDate = (sales.CreateDate == DATE_TIME_DEFAULT) ? string.Empty : sales.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }
                else
                {
                    this.txtCreateDate.Value = string.Empty;
                }

                this.FileAttachedCount = attachedService.CountFile(this.SalesID, (int)FType.Sales);
            }

            SetConfirmData(true);
        }

        /// <summary>
        /// Show detail data on form
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void ShowDetailData(int headerID)
        {
            using (DB db = new DB())
            {
                Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
                Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);

                var listSellInfo = sales_D_SellService.GetListByID(headerID);
                var listCostInfo = sales_D_CostService.GetListByID(headerID);

                //Create list data
                IList<SalesDetailInfo> dataList = this.CreateListDetail(listSellInfo, listCostInfo);

                //Check is purchase
                this.IsPurchase = dataList.Any(s => s.CostList.Any(c => c.PurchaseFlag));

                //Reset datasource
                this.rptDetail.DataSource = dataList;
                this.rptDetail.DataBind();

                this.SetSellMarkup(this.txtSalesDate.Value.Value);
            }
        }

        /// <summary>
        /// Get list by date
        /// </summary>
        /// <returns></returns>
        private Hashtable GetListByDate()
        {
            Hashtable ret = new Hashtable();
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);
                var list = currency_HService.GetAllByDate(this.txtSalesDate.Value.HasValue ? this.txtSalesDate.Value.Value : DateTime.Now);
                foreach (var item in list)
                {
                    ret.Add(item.HID, item);
                }
            }
            return ret;
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        private IList<SalesDetailInfo> GetData(bool includeDelete = true)
        {
            IList<SalesDetailInfo> ret = new List<SalesDetailInfo>();
            this._indexSell = 1;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                //Find control
                HtmlInputCheckBox chkSellDel = (HtmlInputCheckBox)item.FindControl("chkSellDel");
                HiddenField hidInternalIDSell = (HiddenField)item.FindControl("hidInternalIDSell");
                HiddenField hidSellProductID = (HiddenField)item.FindControl("hidSellProductID");
                ICodeTextBox txtSellProductCD = (ICodeTextBox)item.FindControl("txtSellProductCD");
                INumberTextBox txtProfit = (INumberTextBox)item.FindControl("txtProfit");
                ITextBox txtSellProductName = (ITextBox)item.FindControl("txtSellProductName");
                ITextBox txtSellDescription = (ITextBox)item.FindControl("txtSellDescription");
                INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtSellPrice");
                INumberTextBox txtSellQuantity = (INumberTextBox)item.FindControl("txtSellQuantity");
                DropDownList cmbSellUnit = (DropDownList)item.FindControl("cmbSellUnit");
                INumberTextBox txtSellTotal = (INumberTextBox)item.FindControl("txtSellTotal");
                INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");
                ITextBox txtSellRemark = (ITextBox)item.FindControl("txtSellRemark");
                DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbSellVatType");
                INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtSellVatRatio");

                SalesDetailInfo detail = new SalesDetailInfo();

                //Check Type
                if (!includeDelete && chkSellDel.Checked)
                {
                    continue;
                }

                detail.CheckFlag = chkSellDel.Checked;

                detail.Sell = new SalesSellInfo();
                detail.CostList = new List<SalesCostInfo>();

                //Sell Collapsed
                detail.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                //InternalID
                detail.Sell.InternalID = Convert.ToInt32(hidInternalIDSell.Value);

                //No
                detail.Sell.No = this._indexSell++;

                //SellProdcutID
                detail.Sell.ProductID = Convert.ToInt32(hidSellProductID.Value);

                //SellProductCD
                detail.Sell.ProductCD = txtSellProductCD.Value;

                //Profit
                detail.Sell.Profit = txtProfit.Value;

                //SellProductName
                detail.Sell.ProductName = txtSellProductName.Value;

                //SellDescription
                detail.Sell.Description = txtSellDescription.Value;

                //SellPrice
                detail.Sell.Price = txtSellPrice.Value;

                //SellQuantity
                detail.Sell.Quantity = txtSellQuantity.Value;

                //SellUnit
                detail.Sell.UnitID = Convert.ToInt32(cmbSellUnit.SelectedItem.Value);

                //SellTotal
                detail.Sell.Total = txtSellTotal.Value;

                //SellVat
                detail.Sell.Vat = txtSellVat.Value;

                //SellRemark
                detail.Sell.Remark = txtSellRemark.Value;

                //VatType
                if (cmbSellVatType.SelectedItem != null)
                {
                    detail.Sell.VatType = Convert.ToInt32(cmbSellVatType.SelectedItem.Value);
                }
                else
                {
                    detail.Sell.VatType = 255;
                }

                //SellVatRatio

                detail.Sell.VatRatio = txtSellVatRatio.Value;

                Repeater cost = (Repeater)item.FindControl("rptCost");
                int indexCost = 1;
                foreach (RepeaterItem itemCost in cost.Items)
                {
                    //Find control
                    HiddenField hidInternalIDCost = (HiddenField)itemCost.FindControl("hidInternalIDCost");
                    HiddenField hidCostProductID = (HiddenField)itemCost.FindControl("hidCostProductID");
                    ICodeTextBox txtCostProductCD = (ICodeTextBox)itemCost.FindControl("txtCostProductCD");
                    ITextBox txtCostProductName = (ITextBox)itemCost.FindControl("txtCostProductName");
                    ITextBox txtCostDescription = (ITextBox)itemCost.FindControl("txtCostDescription");
                    INumberTextBox txtCostPrice = (INumberTextBox)itemCost.FindControl("txtCostPrice");
                    INumberTextBox txtCostQuantity = (INumberTextBox)itemCost.FindControl("txtCostQuantity");
                    DropDownList cmbCostUnit = (DropDownList)itemCost.FindControl("cmbCostUnit");
                    INumberTextBox txtCostTotal = (INumberTextBox)itemCost.FindControl("txtCostTotal");
                    INumberTextBox txtCostVat = (INumberTextBox)itemCost.FindControl("txtCostVat");
                    DropDownList cmbCostCurrency = (DropDownList)itemCost.FindControl("cmbCostCurrency");
                    HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)itemCost.FindControl("chkPurchaseFlag");
                    ICodeTextBox txtCostVendorCD = (ICodeTextBox)itemCost.FindControl("txtCostVendorCD");
                    ITextBox txtCostVendorName = (ITextBox)itemCost.FindControl("txtCostVendorName");
                    DropDownList cmbCostVatType = (DropDownList)itemCost.FindControl("cmbCostVatType");
                    INumberTextBox txtCostVatRatio = (INumberTextBox)itemCost.FindControl("txtCostVatRatio");

                    SalesCostInfo costInfo = new SalesCostInfo();

                    //Collapsed
                    costInfo.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                    //InternalID
                    costInfo.InternalID = Convert.ToInt32(hidInternalIDCost.Value);

                    //No
                    costInfo.No = indexCost++;
                    costInfo.SellNo = detail.Sell.No;
                    costInfo.SellNoDisp = costInfo.SellNo;

                    //CostProdcutID
                    detail.Sell.ProductID = Convert.ToInt32(hidCostProductID.Value);

                    //CostProductCD
                    costInfo.ProductCD = txtCostProductCD.Value;

                    //CostProductName
                    costInfo.ProductName = txtCostProductName.Value;

                    //CostDescription
                    costInfo.Description = txtCostDescription.Value;

                    //CostPrice
                    costInfo.Price = txtCostPrice.Value;

                    //CostQuantity
                    costInfo.Quantity = txtCostQuantity.Value;

                    //CostUnit
                    costInfo.UnitID = Convert.ToInt32(cmbCostUnit.SelectedItem.Value);

                    //CostTotal
                    costInfo.Total = txtCostTotal.Value;

                    //CostVat
                    costInfo.Vat = txtCostVat.Value;

                    //CostExchangeRate
                    costInfo.CurrencyID = Convert.ToInt32(cmbCostCurrency.SelectedItem.Value);

                    //PurchaseFlag
                    costInfo.PurchaseFlag = (chkPurchaseFlag.Checked) ? true : false;

                    //CostVendorCD
                    costInfo.VendorCD = txtCostVendorCD.Value;

                    //CostVendorName
                    costInfo.VendorName = txtCostVendorName.Value;

                    //VatType
                    costInfo.VatType = Convert.ToInt32(cmbCostVatType.SelectedItem.Value);

                    //CostVatRatio
                    costInfo.VatRatio = txtCostVatRatio.Value;

                    detail.CostList.Add(costInfo);
                }

                ret.Add(detail);
            }

            return ret;
        }

        /// <summary>
        /// Get header
        /// </summary>
        /// <param name="header">T_Sales_H</param>
        private void GetHeader(T_Sales_H header)
        {
            header.SalesDate = this.txtSalesDate.Value.Value;
            //header.ExpiryDate = this.txtExpiryDate.Value.Value;
            header.QuoteDate = this.txtQuotationDate.IsEmpty ? DATE_TIME_DEFAULT : this.txtQuotationDate.Value.Value;
            header.QuoteNo = this.txtQuotationNo.IsEmpty ? string.Empty : this.txtQuotationNo.Value;
            header.PreparedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.PreparedName = this.txtPreparedName.Value;
            header.ApprovedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.ApprovedName = this.txtApprovedName.Value;
            header.ContractNo = this.txtContractNo.Value;
            if (this.txtContractDate.Value.HasValue)
            {
                header.ContractDate = this.txtContractDate.Value.Value;
            }
            else
            {
                header.ContractDate = DATE_TIME_DEFAULT;
            }

            //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
            //if (this.txtInspectionDate.Value.HasValue)
            //{
            //    header.InspectionDate = this.txtInspectionDate.Value.Value;
            //}
            //else
            //{
            //    header.InspectionDate = DATE_TIME_DEFAULT;
            //}
            //----------------2014/12/16 ISV-HUNG Edit End----------------------//

            header.SalesCD1 = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtSalesCD1.Value, M_User.USER_CODE_MAX_LENGTH);
            header.SalesName1 = this.txtSalesName1.Value;
            header.SalesCD2 = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtSalesCD2.Value, M_User.USER_CODE_MAX_LENGTH);
            header.SalesName2 = this.txtSalesName2.Value;
            header.CustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
            header.CustomerName = this.txtCustomerName.Value;
            header.SubjectName = this.txtSubject.Value;
            header.CustomerAddress1 = this.txtAdd1.Value;
            header.CustomerAddress2 = this.txtAdd2.Value;
            header.CustomerAddress3 = this.txtAdd3.Value;
            header.Tel = this.txtTel.Value;
            header.FAX = this.txtFax.Value;
            header.ContactPerson = this.txtAttn.Value;
            header.CurrencyID = Convert.ToInt32(this.cmbCurrency.SelectedItem.Value);
            header.MethodVat = Convert.ToInt16(this.cmbMethodVat.SelectedItem.Value);

            //-------2014/12/08 ISV-HUNG Add Start -----------//
            header.Approved = this.txtApproved.Value;
            header.Position = this.txtPosition.Value;
            //-------2014/12/08 ISV-HUNG Add End -----------//

            //---------------Add 2015/01/06-----------------//
            header.CompleteDate = this.txtCompleteDate.IsEmpty ? DATE_TIME_DEFAULT : this.txtCompleteDate.Value.Value;
            header.PaymentDate = this.txtPaymentDate.IsEmpty ? DATE_TIME_DEFAULT : this.txtPaymentDate.Value.Value;
            //---------------Add 2015/01/06-----------------//

            ////Finished check
            //if (this.chkFinishedFlag.Checked)
            //{
            //    header.FinishDate = DateTime.Now;
            //    header.FinishFlag = 1;
            //}
            //else
            //{
            //    header.FinishDate = DATE_TIME_DEFAULT;
            //    header.FinishFlag = 0;
            //}

            //Total check
            header.Total = (this.txtSumTotal.Value.HasValue) ? this.txtSumTotal.Value.Value : 0;

            //Total check
            header.Vat = (this.txtSumVat.Value.HasValue) ? this.txtSumVat.Value.Value : 0;

            //Total check
            header.GrandTotal = (this.txtGrandTotal.Value.HasValue) ? this.txtGrandTotal.Value.Value : 0;

            header.VatRatio = (this.txtVatRatio.Value.HasValue) ? this.txtVatRatio.Value.Value : 0;

            if (this.cmbVatType.Enabled)
            {
                header.VatType = short.Parse(this.cmbVatType.SelectedItem.Value);
            }
            else
            {
                header.VatType = 255;
            }

            //2014/12/18 ISV-HUNG - Delete Start
            //header.ProfitRatio = this.txtSumProfit.Value.HasValue ? this.txtSumProfit.Value.Value : 0;
            //2014/12/18 ISV-HUNG - Delete End

            header.Memo = this.txtMemo.Value;

            header.CreateUID = this.LoginInfo.User.ID;
            header.UpdateUID = this.LoginInfo.User.ID;
            header.VersionUpdateUID = this.LoginInfo.User.ID;

            if (this.Mode == Mode.Update)
            {
                header.UpdateDate = this.OldUpdateDate;
                header.VersionUpdateDate = this.OldVersionUpdateDate;
            }
            else
            {
                header.StatusFlag = (short)StatusFlag.Sales;
                header.IssuedFlag = 0;
                header.DeleteFlag = 0;
                header.IssuedDate = DATE_TIME_DEFAULT;
                header.IssuedUID = 0;
            }
        }

        /// <summary>
        /// Get sell info for insert
        /// </summary>
        /// <param name="sellInfo">SalesSellInfo</param>
        /// <returns></returns>
        private T_Sales_D_Sell GetSellInfo(SalesSellInfo sellInfo)
        {
            T_Sales_D_Sell result = new T_Sales_D_Sell();
            result.No = sellInfo.No;

            //-------2014/12/10 ISV-HUNG Edit Start -----------//
            if (this.ProductCDUsed)
            {
                result.ProductCD = sellInfo.ProductCD;
            }
            else
            {
                result.ProductCD = M_Product.PRODUCT_CODE_SUPPORT;
            }
            //-------2014/12/10 ISV-HUNG Edit End -----------//
            result.ProductName = sellInfo.ProductName;

            result.Description = sellInfo.Description;
            result.Remark = sellInfo.Remark;
            result.UnitID = sellInfo.UnitID;
            result.VatType = short.Parse(sellInfo.VatType.ToString());
            result.VatRatio = sellInfo.VatRatio.HasValue ? sellInfo.VatRatio.Value : 0;
            result.UnitPrice = sellInfo.Price.HasValue ? sellInfo.Price.Value : 0;
            result.Quantity = sellInfo.Quantity.HasValue ? sellInfo.Quantity.Value : 0;
            result.Total = sellInfo.Total.HasValue ? sellInfo.Total.Value : 0;
            result.Vat = sellInfo.Vat.HasValue ? sellInfo.Vat.Value : 0;

            return result;
        }

        /// <summary>
        /// Get cost info for insert
        /// </summary>
        /// <param name="sellInfo">SalesCostInfo</param>
        /// <returns></returns>
        private T_Sales_D_Cost GetCostInfo(SalesCostInfo costInfo)
        {
            T_Sales_D_Cost result = new T_Sales_D_Cost();
            result.SellNo = costInfo.SellNo;
            result.No = costInfo.No;

            //-------2014/12/10 ISV-HUNG Edit Start -----------//
            if (this.ProductCDUsed)
            {
                result.ProductCD = costInfo.ProductCD;
            }
            else
            {
                if (string.IsNullOrEmpty(costInfo.ProductName))
                {
                    result.ProductCD = string.Empty;
                }
                else
                {
                    result.ProductCD = M_Product.PRODUCT_CODE_SUPPORT;
                }
            }
            //-------2014/12/10 ISV-HUNG Edit End -----------//
            result.ProductName = costInfo.ProductName;

            result.Description = costInfo.Description;
            result.UnitID = costInfo.UnitID;
            result.CurrencyID = costInfo.CurrencyID;
            result.VatType = short.Parse(costInfo.VatType.ToString());
            result.VatRatio = costInfo.VatRatio.HasValue ? costInfo.VatRatio.Value : 0;

            result.PurchaseFlag = Convert.ToInt16(costInfo.PurchaseFlag);
            result.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(costInfo.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            result.VendorName = costInfo.VendorName;
            result.UnitPrice = costInfo.Price.HasValue ? costInfo.Price.Value : 0;
            result.Quantity = costInfo.Quantity.HasValue ? costInfo.Quantity.Value : 0;
            result.Total = costInfo.Total.HasValue ? costInfo.Total.Value : 0;
            result.Vat = costInfo.Vat.HasValue ? costInfo.Vat.Value : 0;

            return result;
        }

        /// <summary>
        /// Show condition
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private string GetConditions(int headerID)
        {
            using (DB db = new DB())
            {
                Sales_CService sales_CService = new Sales_CService(db);
                var salesC = sales_CService.GetByPK(headerID);

                if (salesC != null)
                {
                    return salesC.Conditions;
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Insert data
        /// </summary>
        private bool InsertData(ref int newId)
        {
            try
            {
                int ret = 0;

                //Get data header
                T_Sales_H header = new T_Sales_H();
                this.GetHeader(header);
                header.QuoteNo = string.Empty;
                header.QuoteDate = DATE_TIME_DEFAULT;

                using (DB db = new DB())
                {
                    TNoService noService = new TNoService(db);
                    header.SalesNo = noService.CreateNo(T_No.SalesNo);
                }                

                //Get data detail
                IList<SalesDetailInfo> listDetail = this.GetData();

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
                    Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);
                    ProductService productService = new ProductService(db);

                    //Insert sales header
                    ret = sales_HService.Insert(header);

                    if (ret == 1)
                    {
                        newId = db.GetIdentityId<T_Sales_H>();

                        //Insert Sales Condition
                        this.InsertSalesCondition(db, newId, this.txtConditions.Value);

                        foreach (var item in listDetail)
                        {
                            T_Sales_D_Sell sellInfo = this.GetSellInfo(item.Sell);
                            sellInfo.HID = newId;

                            sales_D_SellService.Insert(sellInfo);

                            var countInsert = 0;
                            foreach (var itemCost in item.CostList)
                            {
                                if (string.IsNullOrEmpty(itemCost.ProductCD) &&
                                    string.IsNullOrEmpty(itemCost.ProductName) &&
                                    string.IsNullOrEmpty(itemCost.Description) &&
                                    !itemCost.Price.HasValue &&
                                    !itemCost.Quantity.HasValue &&
                                    !itemCost.Total.HasValue &&
                                    !itemCost.Vat.HasValue)
                                {
                                    continue;
                                }
                                countInsert++;
                                T_Sales_D_Cost costInfo = this.GetCostInfo(itemCost);
                                costInfo.HID = newId;

                                sales_D_CostService.Insert(costInfo);
                            }
                            if (countInsert == 0)
                            {
                                T_Sales_D_Cost emptyItemCost = new T_Sales_D_Cost();
                                emptyItemCost.HID = newId;
                                emptyItemCost.No = 1;
                                emptyItemCost.SellNo = sellInfo.No;
                                emptyItemCost.ProductCD = string.Empty;
                                emptyItemCost.ProductName = string.Empty;
                                emptyItemCost.Description = string.Empty;
                                emptyItemCost.VatRatio = int.Parse(this._defaultVatType) == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE) ? (decimal)decimal.Parse(this.DefaultVAT) : 0;
                                emptyItemCost.VatType = short.Parse(this._defaultVatType);
                                sales_D_CostService.Insert(emptyItemCost);
                            }
                        }
                    }

                    db.Commit();
                }
            }
            catch (OverflowException ex)
            {
                if (ex.Message.Contains(T_No.SalesNo))
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SIZE_MAX_NO, "Sales No");
                }
                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_UN))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CUSTOMER))
                //{
                //    base.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CURRENCY))
                //{
                //    base.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert Sales Condition
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="headerId">Header Id</param>
        /// <param name="condition">Condition</param>
        private void InsertSalesCondition(DB db, int headerId, string condition)
        {
            Sales_CService sales_CService = new Sales_CService(db);
            sales_CService.Delete(headerId);

            T_Sales_C salesC = new T_Sales_C();
            salesC.HID = headerId;
            salesC.Conditions = condition;

            sales_CService.Insert(salesC);
        }

        /// <summary>
        /// Create detail list
        /// </summary>
        /// <param name="sellList">T_Sales_D_Sell List</param>
        /// <param name="costList">T_Sales_D_Cost List</param>
        /// <returns></returns>
        private IList<SalesDetailInfo> CreateListDetail(IList<T_Sales_D_Sell> sellList, IList<T_Sales_D_Cost> costList)
        {
            IList<SalesDetailInfo> dataList = new List<SalesDetailInfo>();

            foreach (var item in sellList)
            {
                SalesDetailInfo itemSell = new SalesDetailInfo();
                itemSell.Sell = new SalesSellInfo();

                itemSell.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                itemSell.Sell.InternalID = item.InternalID;
                itemSell.Sell.No = item.No;
                itemSell.Sell.ProductCD = item.ProductCD;
                itemSell.Sell.ProductName = item.ProductName;
                itemSell.Sell.Description = item.Description;
                itemSell.Sell.Description = item.Description;
                itemSell.Sell.UnitID = item.UnitID;
                itemSell.Sell.Price = item.UnitPrice;
                itemSell.Sell.Quantity = item.Quantity;
                itemSell.Sell.Total = item.Total;
                itemSell.Sell.Remark = item.Remark;
                itemSell.Sell.VatRatio = item.VatRatio;
                itemSell.Sell.Vat = item.Vat;
                itemSell.Sell.VatType = item.VatType;

                itemSell.CostList = new List<SalesCostInfo>();
                foreach (var itemCost in costList)
                {
                    if (itemCost.SellNo == item.No)
                    {
                        SalesCostInfo itemCostInfo = new SalesCostInfo();
                        itemCostInfo.InternalID = itemCost.InternalID;
                        itemCostInfo.SellNo = itemCost.SellNo;
                        itemCostInfo.SellNoDisp = itemCost.SellNo;
                        itemCostInfo.No = itemCost.No;
                        itemCostInfo.ProductCD = itemCost.ProductCD;
                        itemCostInfo.ProductName = itemCost.ProductName;
                        itemCostInfo.Description = itemCost.Description;
                        itemCostInfo.CurrencyID = itemCost.CurrencyID;
                        itemCostInfo.UnitID = itemCost.UnitID;
                        if (itemCost.PurchaseFlag == 1)
                        {
                            itemCostInfo.PurchaseFlag = true;
                        }
                        else
                        {
                            itemCostInfo.PurchaseFlag = false;
                        }
                        itemCostInfo.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeShow(itemCost.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                        itemCostInfo.VendorName = itemCost.VendorName;
                        itemCostInfo.VatType = itemCost.VatType;

                        //-------2014/12/10 ISV-HUNG Edit Start -----------//
                        bool setInfoCost = false;
                        setInfoCost = this.ProductCDUsed ? !string.IsNullOrEmpty(itemCostInfo.ProductCD) : !string.IsNullOrEmpty(itemCostInfo.ProductName);

                        if (setInfoCost)
                        {
                            itemCostInfo.Price = itemCost.UnitPrice;
                            itemCostInfo.Quantity = itemCost.Quantity;
                            itemCostInfo.Total = itemCost.Total;
                            itemCostInfo.Vat = itemCost.Vat;

                            itemCostInfo.VatRatio = itemCost.VatRatio;
                        }
                        //-------2014/12/10 ISV-HUNG Edit End -----------//

                        itemSell.CostList.Add(itemCostInfo);
                    }
                }

                if (itemSell.CostList.Count == 0)
                {
                    SalesCostInfo emptyItemCost = new SalesCostInfo();
                    emptyItemCost.No = 0;
                    emptyItemCost.SellNo = item.No;
                    emptyItemCost.SellNoDisp = item.No + 1;
                    itemSell.CostList.Add(emptyItemCost);
                }

                dataList.Add(itemSell);
            }

            return dataList;
        }

        /// <summary>
        ///  Check detail change data
        /// </summary>
        /// <param name="db"></param>
        /// <param name="listDetailScreen"></param>
        /// <returns></returns>
        private bool IsDetailChange(DB db, IList<SalesDetailInfo> listDetailScreen)
        {
            //Check condition
            if (!string.Equals(this.txtConditions.Value, this.OldCondition))
            {
                return true;
            }

            //List data
            Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
            Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);

            var listSellInfo = sales_D_SellService.GetListByID(this.SalesID);
            var listCostInfo = sales_D_CostService.GetListByID(this.SalesID);

            //Create list data
            IList<SalesDetailInfo> listDetailData = this.CreateListDetail(listSellInfo, listCostInfo);

            if (listDetailScreen.Count != listDetailData.Count)
            {
                return true;
            }
            foreach (var item in listDetailScreen)
            {
                var sell = listSellInfo.Where(s => s.No.Equals(item.Sell.No)).SingleOrDefault();
                sell.ProductCD = item.Sell.ProductCD;
                sell.ProductName = item.Sell.ProductName;
                sell.Description = item.Sell.Description;
                sell.UnitPrice = item.Sell.Price.Value;
                sell.Quantity = item.Sell.Quantity.Value;
                sell.UnitID = item.Sell.UnitID;
                sell.Remark = item.Sell.Remark;
                sell.Total = item.Sell.Total.Value;
                sell.Vat = item.Sell.Vat.GetValueOrDefault();
                sell.VatType = short.Parse(item.Sell.VatType.ToString());
                sell.VatRatio = item.Sell.VatRatio.GetValueOrDefault();

                var costList = listCostInfo.Where(c => c.SellNo.Equals(sell.No)).ToList();
                if (item.CostList.Count != costList.Count)
                {
                    return true;
                }

                foreach (var itemCost in item.CostList)
                {
                    var cost = costList.Where(c => c.No.Equals(itemCost.No)).SingleOrDefault();
                    cost.ProductCD = itemCost.ProductCD;
                    cost.ProductName = itemCost.ProductName;
                    cost.Description = itemCost.Description;
                    cost.UnitPrice = itemCost.Price.GetValueOrDefault();
                    cost.Quantity = itemCost.Quantity.GetValueOrDefault();
                    cost.UnitID = itemCost.UnitID;
                    cost.Total = itemCost.Total.GetValueOrDefault();
                    cost.Vat = itemCost.Vat.GetValueOrDefault();
                    cost.CurrencyID = itemCost.CurrencyID;
                    cost.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(itemCost.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                    cost.VendorName = itemCost.VendorName;
                    cost.VatType = short.Parse(itemCost.VatType.ToString());
                    cost.VatRatio = itemCost.VatRatio.GetValueOrDefault();
                }
            }

            return listSellInfo.Any(s => s.Status == DataStatus.Changed) || listCostInfo.Any(c => c.Status == DataStatus.Changed);
        }

        /// <summary>
        /// Create detail
        /// </summary>
        /// <param name="listDetail"></param>
        /// <param name="listSell"></param>
        /// <param name="listCost"></param>
        private void CreateDetail(IList<SalesDetailInfo> listDetail, IList<T_Sales_D_Sell> listSell, IList<T_Sales_D_Cost> listCost)
        {
            foreach (var item in listDetail)
            {
                var sell = new T_Sales_D_Sell();
                sell.InternalID = item.Sell.InternalID;
                sell.No = item.Sell.No;
                sell.ProductID = item.Sell.ProductID;
                sell.ProductCD = item.Sell.ProductCD;
              
                sell.ProductName = item.Sell.ProductName;
                if (!this.ProductCDUsed)
                {
                    if (string.IsNullOrEmpty(sell.ProductName))
                    {
                        sell.ProductCD = string.Empty;
                    }
                    else
                    {
                        sell.ProductCD = M_Product.PRODUCT_CODE_SUPPORT;
                    }
                }
                sell.Description = item.Sell.Description;
                sell.Remark = item.Sell.Remark;
                sell.UnitID = item.Sell.UnitID;
                sell.VatType = short.Parse(item.Sell.VatType.ToString());
                sell.VatRatio = item.Sell.VatRatio.GetValueOrDefault();
                sell.UnitPrice = item.Sell.Price.GetValueOrDefault();
                sell.Quantity = item.Sell.Quantity.GetValueOrDefault();
                sell.Total = item.Sell.Total.GetValueOrDefault();
                sell.Vat = item.Sell.Vat.GetValueOrDefault();

                listSell.Add(sell);

                var itemCostNo = 1;
                foreach (var itemCost in item.CostList)
                {
                    if (string.IsNullOrEmpty(itemCost.ProductCD) &&
                        string.IsNullOrEmpty(itemCost.ProductName) &&
                        string.IsNullOrEmpty(itemCost.Description) &&
                        !itemCost.Price.HasValue &&
                        !itemCost.Quantity.HasValue &&
                        !itemCost.Total.HasValue &&
                        !itemCost.Vat.HasValue)
                    {
                        continue;
                    }
                    var cost = new T_Sales_D_Cost();
                    cost.InternalID = itemCost.InternalID;
                    cost.SellNo = itemCost.SellNo;
                    cost.No = itemCostNo++;
                    cost.ProductID = itemCost.ProductID;
                    cost.ProductCD = itemCost.ProductCD;

                    cost.ProductName = itemCost.ProductName;

                    if (!this.ProductCDUsed)
                    {
                        if (string.IsNullOrEmpty(itemCost.ProductName))
                        {
                            cost.ProductCD = string.Empty;
                        }
                        else
                        {
                            cost.ProductCD = M_Product.PRODUCT_CODE_SUPPORT;
                        }
                    }
                    cost.Description = itemCost.Description;
                    cost.UnitID = itemCost.UnitID;
                    cost.CurrencyID = itemCost.CurrencyID;
                    cost.VatType = short.Parse(itemCost.VatType.ToString());
                    cost.VatRatio = itemCost.VatRatio.GetValueOrDefault();
                    if (itemCost.PurchaseFlag)
                    {
                        cost.PurchaseFlag = 1;
                    }
                    else
                    {
                        cost.PurchaseFlag = 0;
                    }
                    cost.VendorCD = itemCost.VendorCD;
                    cost.VendorName = itemCost.VendorName;
                    cost.UnitPrice = itemCost.Price.GetValueOrDefault();
                    cost.Quantity = itemCost.Quantity.GetValueOrDefault();
                    cost.Total = itemCost.Total.GetValueOrDefault();
                    cost.Vat = itemCost.Vat.GetValueOrDefault();

                    listCost.Add(cost);
                }

                var listCostOfSell = listCost.Where(d => d.SellNo.Equals(item.Sell.No)).ToList();
                if (listCostOfSell.Count == 0)
                {
                    T_Sales_D_Cost emptyItemCost = new T_Sales_D_Cost();
                    emptyItemCost.ProductCD = string.Empty;
                    emptyItemCost.ProductName = string.Empty;
                    emptyItemCost.Description = string.Empty;
                    emptyItemCost.VendorCD = string.Empty;
                    emptyItemCost.VendorName = string.Empty;
                    emptyItemCost.CurrencyID = 1;
                    emptyItemCost.UnitID = 1;
                    emptyItemCost.InternalID = -1;
                    emptyItemCost.No = 1;
                    emptyItemCost.SellNo = item.Sell.No;
                    if (int.Parse(this._defaultVatType) == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                    {
                        emptyItemCost.VatRatio = decimal.Parse(this.DefaultVAT);
                    }

                    emptyItemCost.VatType = short.Parse(this._defaultVatType);

                    listCost.Add(emptyItemCost);
                }
            }
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Sales_H header = this.GetSales(this.SalesID);
                if (header != null)
                {
                    //Get Header
                    this.GetHeader(header);

                    //Get detail
                    var listDetail = this.GetData();

                    //Update
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        if (header.Status == DataStatus.Changed || this.IsDetailChange(db,listDetail))
                        {
                            //Update header
                            Sales_HService headerService = new Sales_HService(db);
                            ProductService productService = new ProductService(db);

                            header.IssuedFlag = 0;
                            header.IssuedUID = 0;
                            header.IssuedDate = DATE_TIME_DEFAULT;
                            ret = headerService.Update(header);

                            if (ret == 1)
                            {
                                //Insert Sales Condition
                                this.InsertSalesCondition(db, header.ID, this.txtConditions.Value);

                                //Get data from screen
                                IList<T_Sales_D_Sell> listSell = new List<T_Sales_D_Sell>();
                                IList<T_Sales_D_Cost> listCost = new List<T_Sales_D_Cost>();

                                //Create data from screen
                                this.CreateDetail(listDetail,listSell, listCost);

                                int sellNo = 1;

                                //Update Sales sell
                                this.UpdateSalesSells(db, listSell, sellNo);

                                //Update Sales cost
                                this.UpdateSalesCosts(db, listCost, sellNo);
                            }

                            //Update Finish Flag
                            headerService.UpdateFinishFlag(header);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }

                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_UN))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CUSTOMER))
                //{
                //    base.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CURRENCY))
                //{
                //    base.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}
                
                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_UNIT))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Sales Details Sell
        /// </summary>
        /// <param name="db"></param>
        /// <param name="listSell"></param>
        /// <param name="sellNo"></param>
        private void UpdateSalesSells(DB db, IList<T_Sales_D_Sell> listSell, int sellNo)
        {
            List<T_Sales_D_Sell> insDataList = new List<T_Sales_D_Sell>();

            //get insert data
            for (int i = listSell.Count - 1; i >= 0; i--)
            {
                var item = listSell[i];
                if (item.InternalID == -1)
                {
                    insDataList.Add(item);
                    listSell.RemoveAt(i);
                }
            }

            //get data in Database
            Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
            var dbDataList = sales_D_SellService.GetListByID(this.SalesID);
            var no = dbDataList.Count + listSell.Count;

            //delete DB when data not exist on screen
            Hashtable updDataHtb = new Hashtable();
            foreach (var item in listSell)
            {
                updDataHtb.Add(item.InternalID, item.HID);
            }

            for (int i = dbDataList.Count - 1; i >= 0; i--)
            {
                var item = dbDataList[i];
                if (!updDataHtb.ContainsKey(item.InternalID))
                {
                    sales_D_SellService.DeleteByInternalID(item.InternalID);
                    dbDataList.RemoveAt(i);
                }
            }

            //update data
            //update no in DB to greater number 
            foreach (var item in dbDataList)
            {
                sales_D_SellService.UpdateNoByInternalID(item.InternalID, no);
                no += 1;
            }

            //Update data
            foreach (var item in listSell)
            {
                sellNo = item.No;
                item.HID = this.SalesID;
                sales_D_SellService.Update(item);
            }

            //insert data
            foreach (var item in insDataList)
            {
                sellNo = item.No;
                item.HID = this.SalesID;
                sales_D_SellService.Insert(item);
            }
        }

        /// <summary>
        /// Update Sales Details Cost
        /// </summary>
        /// <param name="db"></param>
        /// <param name="listCost"></param>
        /// <param name="sellNo"></param>
        private void UpdateSalesCosts(DB db, IList<T_Sales_D_Cost> listCost, int sellNo)
        {
            //get insert data
            List<T_Sales_D_Cost> insDataList = new List<T_Sales_D_Cost>();

            for (int i = listCost.Count - 1; i >= 0; i--)
            {
                var item = listCost[i];
                if (item.InternalID == -1)
                {
                    insDataList.Add(item);
                    listCost.RemoveAt(i);
                }
            }

            //get data in Database
            Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);
            var dbDataList = sales_D_CostService.GetListByID(this.SalesID);

            //delete DB when data not exist on screen
            Hashtable updDataHtb = new Hashtable();
            foreach (var item in listCost)
            {
                updDataHtb.Add(item.InternalID, item.HID);
            }

            for (int i = dbDataList.Count - 1; i >= 0; i--)
            {
                var item = dbDataList[i];
                if (!updDataHtb.ContainsKey(item.InternalID))
                {
                    sales_D_CostService.DeleteByInternalID(item.InternalID);
                    dbDataList.RemoveAt(i);
                }
            }

            //update data
            //update sellNo in DB to great number
            int costNo = dbDataList.Count + listCost.Count;
            foreach (var item in dbDataList)
            {
                sales_D_CostService.UpdateNoByInternalID(item.InternalID, costNo);
                costNo += 1;
            }

            //Update data
            foreach (var item in listCost)
            {
                sellNo = item.No;
                item.HID = this.SalesID;
                sales_D_CostService.Update(item);
            }

            //insert data
            foreach (var item in insDataList)
            {
                sellNo = item.No;
                item.HID = this.SalesID;
                sales_D_CostService.Insert(item);
            }
        }

        /// <summary>
        /// Process up, down list detail
        /// </summary>
        /// <param name="processUp">true: Process Up false: Process Down</param>
        /// <param name="listData">List data</param>
        /// <returns></returns>
        private IList<SalesDetailInfo> ProcessUpDown(bool processUp, IList<SalesDetailInfo> listData)
        {
            IList<SalesDetailInfo> listResult = new List<SalesDetailInfo>();
            if (processUp) // Process up
            {
                listResult.Add(listData[0]);
                for (int i = 1; i < listData.Count; i++)
                {
                    var item = listData[i];
                    var itemPre = listResult[i - 1];

                    if (item.CheckFlag)
                    {
                        if (itemPre.CheckFlag)
                        {
                            listResult.Add(item);
                        }
                        else
                        {
                            listResult.Insert(i - 1, item);
                        }
                    }
                    else
                    {
                        listResult.Add(item);
                    }
                }
            }
            else // Process down
            {
                listResult.Add(listData[listData.Count - 1]);
                for (int i = listData.Count - 2; i >= 0; i--)
                {
                    var item = listData[i];
                    if (item.CheckFlag)
                    {
                        if (listResult[0].CheckFlag)
                        {
                            listResult.Insert(0, item);
                        }
                        else
                        {
                            listResult.Insert(1, item);
                        }
                    }
                    else
                    {
                        listResult.Insert(0, item);
                    }
                }
            }

            //Sort index
            int index = 1;
            for (int i = 0; i < listResult.Count; i++)
            {
                listResult[i].Sell.No = index++;
                int indexCost = 1;
                foreach (var item in listResult[i].CostList)
                {
                    item.SellNo = listResult[i].Sell.No;
                    item.SellNoDisp = item.SellNo;
                    item.No = indexCost++;
                }
            }

            return listResult;
        }

        /// <summary>
        /// Delete data
        /// </summary>
        /// <returns></returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Get Sales
                    Sales_HService sales_HService = new Sales_HService(db);
                    T_Sales_H sales = sales_HService.GetByPK(this.SalesID);

                    //check have PO or Billing
                    if (this.IsPOProcessed(sales.ID)
                        || this.IsBillingProcessed(sales.ID)
                        || this.IsDeliveryProcessed(sales.ID))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                        return false;
                    }

                    //Update Sales
                    sales.StatusFlag = (int)StatusFlag.Lost;
                    sales.UpdateUID = LoginInfo.User.ID;
                    sales.UpdateDate = this.OldUpdateDate;
                    sales.VersionUpdateUID = LoginInfo.User.ID;
                    sales.VersionUpdateDate = this.OldVersionUpdateDate;
                    ret = sales_HService.Update(sales);
                    if (ret > 0)
                    {
                        db.Commit();
                    }

                    //Check result update
                    if (ret == 0)
                    {
                        //Data change
                        this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Remand data
        /// </summary>
        /// <returns></returns>
        //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
        //private bool RemandData()
        private bool RemandData(ref int quoteID)
        //----------------2014/12/16 ISV-HUNG Edit End----------------------//
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Get sales
                    Sales_HService sales_HService = new Sales_HService(db);
                    T_Sales_H sales = sales_HService.GetByPK(this.SalesID);

                    //Get quotation
                    Quotation_HService quotation_HService = new Quotation_HService(db);
                    T_Quote_H quote = quotation_HService.GetByQuoteNo(this.txtQuotationNo.Value);

                    //check have PO or Billing
                    if (this.IsPOProcessed(sales.ID)
                        || this.IsBillingProcessed(sales.ID)
                        || this.IsDeliveryProcessed(sales.ID))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                        return false;
                    }

                    //Update Sales
                    sales.DeleteFlag = 1;
                    sales.UpdateUID = LoginInfo.User.ID;
                    sales.UpdateDate = this.OldUpdateDate;
                    sales.VersionUpdateUID = LoginInfo.User.ID;
                    sales.VersionUpdateDate = this.OldVersionUpdateDate;
                    ret = sales_HService.Update(sales);

                    if (ret == 1)
                    {
                        //Update quote 
                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        quoteID = quote.ID;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//
                        quote.StatusFlag = 1;
                        ret = quotation_HService.Update(quote);
                    }

                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Remand");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Set Confirm
        /// </summary>
        /// <param name="keepOldValue"></param>
        private void SetConfirmData(bool keepOldValue = true)
        {
            using (DB db = new DB())
            {
                CustomerService custSrv = new CustomerService(db);
                UserService userSrv = new UserService(db);
                ProductService prodSrv = new ProductService(db);
                VendorService vendorSrv = new VendorService(db);

                #region Header
                AttachedService attachedService = new AttachedService(db);
                this.FileAttachedCount = attachedService.CountFile(this.SalesID, (int)FType.Sales);

                //-------2014/12/08 ISV-HUNG Edit Start -----------//
                //txtCustomerCD
                if (!this.txtCustomerCD.IsEmpty && this.txtCustomerCD.Value != this.customerCdSupport && this.txtCustomerName.IsEmpty)
                {
                    var customerCd = this.txtCustomerCD.Value;
                    customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = custSrv.GetByCustomerCD(customerCd);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        this.txtCustomerName.Value = customer.CustomerName1;
                    }

                    if (!this.HaveBillingOrDelivery(this.SalesID))
                    {
                        this.txtCustomerName.SetReadOnly(!(this.txtCustomerCD.Value == this.customerCdSupport));
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(true);
                    }
                }
                //-------2014/12/08 ISV-HUNG Edit End -----------//

                M_User user = null;
                //this.txtPreparedName.Value = null;
                //txtPreparedCD
                if (!this.txtPreparedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID && user.StatusFlag == 0 && !keepOldValue)
                    {
                        this.txtPreparedName.Value = user.UserName2;
                    }
                }

                //this.txtApprovedName.Value = null;
                //txtApprovedCD
                if (!this.txtApprovedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID && user.StatusFlag == 0 && !keepOldValue)
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }

                //this.txtSalesName1.Value = null;
                //txtSalesCD1
                if (!this.txtSalesCD1.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtSalesCD1.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID && user.StatusFlag == 0 && !keepOldValue)
                    {
                        this.txtSalesName1.Value = user.UserName2;
                    }
                }

                //this.txtSalesName2.Value = null;
                //txtSalesCD2
                if (!this.txtSalesCD2.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtSalesCD2.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID && user.StatusFlag == 0 && !keepOldValue)
                    {
                        this.txtSalesName2.Value = user.UserName2;
                    }
                }
                #endregion

                var methodType = this.usingOldValue ? this.MethodVATOld.ToString() : this.cmbMethodVat.SelectedValue;
                var sumTotalSell = 0m;
                var sumVatSell = 0m;
                var sumTotalCost = 0m;

                //Currency
                var currency = this.GetListByDate();

                #region Detail
                foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
                {
                    ICodeTextBox txtSellProductCD = (ICodeTextBox)repeaterItem.FindControl("txtSellProductCD");
                    ITextBox txtSellProductName = (ITextBox)repeaterItem.FindControl("txtSellProductName");
                    DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbSellVatType");
                    INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtSellVat");
                    INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtSellVatRatio");
                    INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtSellPrice");
                    INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtSellQuantity");
                    INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtSellTotal");

                    if (this.ProductCDUsed)
                    {
                        if (!txtSellProductCD.IsEmpty && txtSellProductCD.Value != M_Product.PRODUCT_CODE_SUPPORT
                            && txtSellProductName.IsEmpty)
                        {
                            var product = prodSrv.GetByCD(txtSellProductCD.Value);
                            if (product != null && product.StatusFlag == 0)
                            {
                                txtSellProductName.Value = product.ProductName;
                            }
                        }
                    }

                    var unitPrice = txtSellPrice.Value.GetValueOrDefault();
                    var quantity = txtSellQuantity.Value.GetValueOrDefault();
                    var total = Fraction.Round(this._fractionType, unitPrice * quantity, 2);
                    var vat = Fraction.Round(this._fractionType, (total * txtSellVatRatio.Value.GetValueOrDefault()) / 100, 2);

                    if (!txtSellPrice.IsEmpty && !txtSellQuantity.IsEmpty)
                    {
                        if (txtSellTotal.IsEmpty || !keepOldValue)
                        {
                            txtSellTotal.Value = total;
                        }
                        sumTotalSell += txtSellTotal.Value.GetValueOrDefault();

                        if (methodType == M_Config_D.METHOD_VAT_EACH && cmbSellVatType.SelectedItem != null &&
                            int.Parse(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {
                            if (txtSellVat.IsEmpty || !keepOldValue)
                            {
                                txtSellVat.Value = vat;
                            }
                            sumVatSell += txtSellVat.Value.GetValueOrDefault();
                        }
                    }
                    if (methodType == M_Config_D.METHOD_VAT_SUM ||
                                cmbSellVatType.SelectedItem != null && int.Parse(cmbSellVatType.SelectedItem.Value) != (int)VATFlg.Exclude)
                    {
                        //txtSellVatRatio.Value = null;
                        //txtSellVat.Value = null;
                        if (methodType == M_Config_D.METHOD_VAT_SUM)
                        {
                            cmbSellVatType.Enabled = false;
                        }

                        txtSellVatRatio.SetReadOnly(true);
                        txtSellVat.SetReadOnly(true);
                    }
                    //else
                    //{
                    //    txtSellVatRatio.Value = null;
                    //    txtSellVat.Value = null;
                    //}

                    Repeater cost = (Repeater)repeaterItem.FindControl("rptCost");
                    foreach (RepeaterItem itemCost in cost.Items)
                    {
                        ICodeTextBox txtCostProductCD = (ICodeTextBox)itemCost.FindControl("txtCostProductCD");
                        ITextBox txtCostProductName = (ITextBox)itemCost.FindControl("txtCostProductName");
                        HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)itemCost.FindControl("chkPurchaseFlag");
                        ICodeTextBox txtCostVendorCD = (ICodeTextBox)itemCost.FindControl("txtCostVendorCD");
                        ITextBox txtCostVendorName = (ITextBox)itemCost.FindControl("txtCostVendorName");
                        DropDownList cmbCostVatType = (DropDownList)itemCost.FindControl("cmbCostVatType");
                        INumberTextBox txtCostVat = (INumberTextBox)itemCost.FindControl("txtCostVat");
                        INumberTextBox txtCostVatRatio = (INumberTextBox)itemCost.FindControl("txtCostVatRatio");
                        INumberTextBox txtCostPrice = (INumberTextBox)itemCost.FindControl("txtCostPrice");
                        INumberTextBox txtCostQuantity = (INumberTextBox)itemCost.FindControl("txtCostQuantity");
                        INumberTextBox txtCostTotal = (INumberTextBox)itemCost.FindControl("txtCostTotal");
                        DropDownList cmbCostCurrency = (DropDownList)itemCost.FindControl("cmbCostCurrency");

                        if (this.ProductCDUsed)
                        {
                            if (!txtCostProductCD.IsEmpty && txtCostProductCD.Value != M_Product.PRODUCT_CODE_SUPPORT
                                && txtCostProductName.IsEmpty)
                            {
                                var product = prodSrv.GetByCD(txtCostProductCD.Value);
                                if (product != null && product.StatusFlag == 0)
                                {
                                    txtCostProductName.Value = product.ProductName;
                                }
                            }
                        }

                        if (chkPurchaseFlag.Checked)
                        {
                            var vendorCd = txtCostVendorCD.Value;
                            vendorCd = EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);

                            //-------2014/12/08 ISV-HUNG Edit Start -----------//
                            if (!txtCostVendorCD.IsEmpty && txtCostVendorCD.Value != this.vendorCdSupport && txtCostVendorName.IsEmpty)
                            {
                                var vendor = vendorSrv.GetByCD(vendorCd);
                                if (vendor != null && vendor.StatusFlag == 0)
                                {
                                    txtCostVendorName.Value = vendor.VendorName1;
                                }
                            }
                            //-------2014/12/08 ISV-HUNG Edit End -----------//
                        }

                        unitPrice = txtCostPrice.Value.GetValueOrDefault();
                        quantity = txtCostQuantity.Value.GetValueOrDefault();

                        total = Fraction.Round(this._fractionType, unitPrice * quantity, 2);
                        vat = Fraction.Round(this._fractionType, (total * txtCostVatRatio.Value.GetValueOrDefault()) / 100, 2);

                        if (!txtCostPrice.IsEmpty && !txtCostQuantity.IsEmpty)
                        {
                            if (txtCostTotal.IsEmpty || !keepOldValue)
                            {
                                txtCostTotal.Value = total;
                            }

                            if (int.Parse(cmbCostVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                            {
                                if (txtCostVat.IsEmpty || !keepOldValue)
                                {
                                    txtCostVat.Value = vat;
                                }
                            }
                            //else
                            //{
                            //    txtCostVat.Value = null;
                            //    txtCostVatRatio.Value = null;
                            //}
                        }
                        if (cmbCostVatType.SelectedItem != null && int.Parse(cmbCostVatType.SelectedItem.Value) != (int)VATFlg.Exclude)
                        {
                            //txtCostVat.Value = null;
                            //txtCostVatRatio.Value = null;

                            txtCostVatRatio.SetReadOnly(true);
                            txtCostVat.SetReadOnly(true);
                        }

                        //-----------------------------------------Calc Total Cost----------------------//
                        if (cmbCostCurrency.SelectedItem.Value == Constant.DEFAULT_ID.ToString())
                        {
                            sumTotalCost += txtCostTotal.Value.GetValueOrDefault();
                        }
                        else
                        {
                            CurrencyInfo cur = (CurrencyInfo)currency[Convert.ToInt32(cmbCostCurrency.SelectedItem.Value)];
                            sumTotalCost += CommonUtil.ConvertToVND(cur.ExchangeRate, total);
                        }
                        //-----------------------------------------End Calc Total Cost----------------------//
                    }
                }
                #endregion

                if (this.txtSumTotal.IsEmpty || !keepOldValue)
                {
                    this.txtSumTotal.Value = sumTotalSell;
                }
                sumTotalSell = this.txtSumTotal.Value.GetValueOrDefault();

                if (methodType == M_Config_D.METHOD_VAT_EACH)
                {
                    if (this.txtSumVat.IsEmpty || !keepOldValue)
                    {
                        this.txtSumVat.Value = sumVatSell;
                    }
                    else
                    {
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                    }
                }
                else
                {
                    if (this.cmbVatType.SelectedItem != null && int.Parse(this.cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                    {
                        var vatRatio = this.txtVatRatio.Value.GetValueOrDefault();
                        var sumvat = Fraction.Round(this._fractionType, (sumTotalSell * vatRatio) / 100, 2);
                        if (this.txtSumVat.IsEmpty || !keepOldValue)
                        {
                            this.txtSumVat.Value = sumvat;
                        }
                        sumVatSell += this.txtSumVat.Value.GetValueOrDefault();

                        this.txtSumVat.SetReadOnly(false);
                        this.txtVatRatio.SetReadOnly(false);
                    }
                    else
                    {
                        sumVatSell = 0;

                        this.txtSumVat.SetReadOnly(true);
                        this.txtVatRatio.SetReadOnly(true);

                        this.txtSumVat.Value = null;
                        this.txtVatRatio.Value = null;
                    }
                }

                var grandTotal = sumTotalSell + sumVatSell;
                if (this.txtGrandTotal.IsEmpty || !keepOldValue)
                {
                    this.txtGrandTotal.Value = grandTotal;
                }

                var profit = 0m;
                if (this.cmbCurrency.SelectedValue != Constant.DEFAULT_ID.ToString())
                {
                    //Convert totalCost to ....
                    CurrencyInfo cur = (CurrencyInfo)currency[Convert.ToInt32(this.cmbCurrency.SelectedValue)];
                    sumTotalCost = CommonUtil.ConvertToNotVND(cur.ExchangeRate, sumTotalCost);
                }
                profit = EditDataUtil.CalSumProfit(sumTotalSell, sumTotalCost);
                if (profit > Constant.MAX_PROFIT)
                {
                    profit = Constant.MAX_PROFIT;
                }

                this.txtSumProfit.Value = profit;
            }
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(DropDownList dropDownListControl, INumberTextBox numberControl, decimal maxDecimal, decimal maxNoneDecimal, int? currencyId = null)
        {
            if (this.IsDecimalCurrency(dropDownListControl, currencyId))
            {
                numberControl.DecimalDigit = 2;
                numberControl.MaximumValue = maxDecimal;
            }
            else
            {
                numberControl.DecimalDigit = 0;
                numberControl.MaximumValue = maxNoneDecimal;
            }
        }

        /// <summary>
        /// Check currency is decimal
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        private bool IsDecimalCurrency(DropDownList cmbCurrency, int? currencyId = null)
        {
            currencyId = currencyId.HasValue ? currencyId.Value : int.Parse(cmbCurrency.SelectedValue);

            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == currencyId).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Set enable control by vat type
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="vatControl">Vat Control</param>
        /// <param name="vatRatioControl">Vat Ratio Control</param>
        /// <param name="keepOldValue">Keep old value</param>
        private void SetEnableControlByVatType(DropDownList dropDownListControl, INumberTextBox vatControl, INumberTextBox vatRatioControl, bool keepOldValue)
        {
            if (Convert.ToInt32(dropDownListControl.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                vatControl.SetReadOnly(false);

                vatRatioControl.SetReadOnly(false);
                if (!keepOldValue)
                {
                    vatControl.Value = null;
                    vatRatioControl.Value = decimal.Parse(this.DefaultVAT);
                }
            }
            else
            {
                vatControl.SetReadOnly(true);
                vatControl.Value = null;

                vatRatioControl.SetReadOnly(true);
                vatRatioControl.Value = null;
            }
        }

        /// <summary>
        /// Update markup qty sell
        /// </summary>
        /// <param name="rowIndex"></param>
        /// <param name="profit"></param>
        /// <returns></returns>
        private void UpdateMarkupQtySell(int rowIndex, decimal profit)
        {
            //Process profit
            decimal avrPriceCost = 0;
            decimal sumQty = 0;

            using (var db = new DB())
            {
                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(this.txtSalesDate.Value.Value).ToDictionary(s => s.ID, s => s);

                //Get list
                var listDetail = this.GetData();
                var listCost = listDetail[rowIndex].CostList;

                var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);
                //Default IS VND
                if (mainCurrencyId == Constant.DEFAULT_ID)
                {
                    foreach (var cost in listCost)
                    {
                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                            (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                        {
                            continue;
                        }

                        var unitPrice = 0m;
                        var quantity = cost.Quantity.GetValueOrDefault();
                        if (!cost.Quantity.HasValue)
                        {
                            quantity = 1;
                        }

                        //VND
                        if (cost.CurrencyID == Constant.DEFAULT_ID)
                        {
                            unitPrice = cost.Price.GetValueOrDefault();
                        }
                        else
                        {
                            var exchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                            unitPrice = CommonUtil.ConvertToVND(exchangeRate, cost.Price.GetValueOrDefault());
                        }

                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                        {
                            avrPriceCost += unitPrice * quantity;
                        }
                        else
                        {
                            avrPriceCost += unitPrice;
                        }

                        sumQty += quantity;
                    }
                }
                else
                {
                    var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                    foreach (var cost in listCost)
                    {
                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                            (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                        {
                            continue;
                        }
                        var unitPrice = 0m;
                        var quantity = cost.Quantity.GetValueOrDefault();
                        if (!cost.Quantity.HasValue)
                        {
                            quantity = 1;
                        }

                        //VND
                        if (cost.CurrencyID == Constant.DEFAULT_ID)
                        {
                            //VND => Other Currency
                            unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, cost.Price.GetValueOrDefault());
                        }
                        else if (cost.CurrencyID == mainCurrencyId)
                        {
                            //Other Currency = Other Currency
                            unitPrice = cost.Price.GetValueOrDefault();
                        }
                        else
                        {
                            //Other Currency => Other Currency
                            var costExchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                            var costPriceVND = CommonUtil.ConvertToVND(costExchangeRate, cost.Price.GetValueOrDefault());

                            unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, costPriceVND);
                        }

                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                        {
                            avrPriceCost += unitPrice * quantity;
                        }
                        else
                        {
                            avrPriceCost += unitPrice;
                        }

                        sumQty += quantity;
                    }
                }

                if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                    sumQty != 0)
                {
                    avrPriceCost = avrPriceCost / sumQty;
                }
                var priceByMarkup = EditDataUtil.CalcUnitPriceByMarkup(avrPriceCost, profit);
                if (this.IsDecimalCurrency(this.cmbCurrency))
                {
                    priceByMarkup = Fraction.Round(this._fractionType, priceByMarkup, 2);
                }
                else
                {
                    priceByMarkup = Fraction.Round(this._fractionType, priceByMarkup, 0);
                }
                listDetail[rowIndex].Sell.Price = priceByMarkup;


                if (priceByMarkup != 0m)
                {
                    var markUp = EditDataUtil.CalProfit(priceByMarkup, avrPriceCost);
                    markUp = Fraction.Round(this._fractionType, markUp, 2);

                    if (markUp > Constant.MAX_PROFIT || markUp < 0)
                    {
                        listDetail[rowIndex].Sell.Profit = null;
                    }
                    else
                    {
                        listDetail[rowIndex].Sell.Profit = markUp;
                    }
                }

                this.rptDetail.DataSource = listDetail;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Display markup number
        /// </summary>
        private void SetSellMarkup(DateTime quoteDate)
        {

            using (var db = new DB())
            {
                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(quoteDate).ToDictionary(s => s.ID, s => s);

                var sellList = this.GetData();

                #region MarkUp

                foreach (var sell in sellList)
                {
                    if (!sell.Sell.Price.HasValue || sell.Sell.Price == 0)
                    {
                        sell.Sell.Profit = 0;
                        continue;
                    }


                    decimal avrPriceCost = 0;
                    decimal sumQty = 0;

                    var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);
                    //Default IS VND
                    if (mainCurrencyId == Constant.DEFAULT_ID)
                    {

                        foreach (var cost in sell.CostList)
                        {
                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                                (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                            {
                                continue;
                            }
                            var unitPrice = 0m;
                            var quantity = cost.Quantity.GetValueOrDefault();
                            if (!cost.Quantity.HasValue)
                            {
                                quantity = 1;
                            }

                            //VND
                            if (cost.CurrencyID == Constant.DEFAULT_ID)
                            {
                                unitPrice = cost.Price.GetValueOrDefault();
                            }
                            else
                            {
                                var exchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                                unitPrice = CommonUtil.ConvertToVND(exchangeRate, cost.Price.GetValueOrDefault());
                            }

                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                            {
                                avrPriceCost += unitPrice * quantity;
                            }
                            else
                            {
                                avrPriceCost += unitPrice;
                            }

                            sumQty += cost.Quantity.GetValueOrDefault();
                        }
                    }
                    else
                    {
                        var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                        foreach (var cost in sell.CostList)
                        {
                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                                (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                            {
                                continue;
                            }
                            var unitPrice = 0m;
                            var quantity = cost.Quantity.GetValueOrDefault();
                            if (!cost.Quantity.HasValue)
                            {
                                quantity = 1;
                            }

                            //VND
                            if (cost.CurrencyID == Constant.DEFAULT_ID)
                            {
                                //VND => Other Currency
                                unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, cost.Price.GetValueOrDefault());
                            }
                            else if (cost.CurrencyID == mainCurrencyId)
                            {
                                //Other Currency = Other Currency
                                unitPrice = cost.Price.GetValueOrDefault();
                            }
                            else
                            {
                                //Other Currency => Other Currency
                                var costExchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                                var costPriceVND = CommonUtil.ConvertToVND(costExchangeRate, cost.Price.GetValueOrDefault());

                                unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, costPriceVND);
                            }

                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                            {
                                avrPriceCost += unitPrice * quantity;
                            }
                            else
                            {
                                avrPriceCost += unitPrice;
                            }
                            sumQty += cost.Quantity.GetValueOrDefault();
                        }
                    }

                    if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                        sumQty != 0)
                    {
                        avrPriceCost = avrPriceCost / sumQty;
                    }

                    var markUp = EditDataUtil.CalProfit(sell.Sell.Price.GetValueOrDefault(), avrPriceCost);
                    markUp = markUp > Constant.MAX_PROFIT ? Constant.MAX_PROFIT : markUp <= 0m ? 0m : markUp;
                    sell.Sell.Profit = markUp;
                }

                #endregion

                this.rptDetail.DataSource = sellList;
                this.rptDetail.DataBind();
            }
        }

        ///// <summary>
        ///// Calculate price from profit
        ///// </summary>
        ///// <param name="unitPrice"></param>
        ///// <param name="markup"></param>
        ///// <returns></returns>
        //private decimal CalcUnitPriceByMarkup(decimal unitPrice, decimal markup)
        //{
        //    //if (markup == 100m)
        //    //{
        //    //    return unitPrice;
        //    //}
        //    //return unitPrice * 100 / (100 - markup);

        //    if (markup == 100m)
        //    {
        //        return unitPrice;
        //    }
        //    if (markup > 100)
        //    {
        //        return unitPrice * (1 + (markup / 100));
        //    }
        //    return unitPrice / (1 - (markup / 100));
        //}

        ///// <summary>
        ///// Calculate markup from price cost and price sell
        ///// </summary>
        ///// <param name="priceCost"></param>
        ///// <param name="priceSell"></param>
        ///// <returns></returns>
        //private decimal CalProfit(decimal priceSell, decimal priceCost)
        //{
        //    //return Fraction.Round(this._fractionType, 100-(priceCost * 100 / priceSell), 2);

        //    if (priceSell >= (priceCost * 2))
        //    {
        //        var profit = (Fraction.Round(this._fractionType, (priceSell / priceCost), 2) - 1) * 100;
        //        return profit;
        //    }
        //    else
        //    {
        //        var profit = (1 - (Fraction.Round(this._fractionType, priceCost / priceSell, 2))) * 100;
        //        return profit;
        //    }
        //}

        ///// <summary>
        ///// Calculate profix
        ///// </summary>
        ///// <param name="totalSell"></param>
        ///// <param name="totalCost"></param>
        ///// <returns></returns>
        //private decimal CalSumProfit(decimal totalSell, decimal totalCost)
        //{
        //    decimal ret = 0;
        //    //Check total sell
        //    if (totalSell <= 0)
        //    {
        //        return ret;
        //    }

        //    //calculate profit
        //    //ret = Fraction.Round(this._fractionType, (decimal)((totalSell - totalCost) / totalSell) * 100, 2);

        //    if (totalSell >= (totalCost * 2))
        //    {
        //        ret = (Fraction.Round(this._fractionType, (totalSell / totalCost), 2) - 1) * 100;
        //    }
        //    else
        //    {
        //        ret = (1 - (Fraction.Round(this._fractionType, totalCost / totalSell, 2))) * 100;
        //    }

        //    if (ret < 0)
        //    {
        //        ret = 0;
        //    }
        //    return ret;
        //}

        /// <summary>
        /// Reload list detail to refresh errors class
        /// </summary>
        private void ReloadListDetail()
        {
            var listDetail = this.GetData();
            this.rptDetail.DataSource = listDetail;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Lock header
        /// </summary>
        /// <param name="listDetail">List SalesDetailInfo</param>
        /// <returns></returns>
        private void LockHeader(IList<SalesDetailInfo> listDetail)
        {
            bool isEnabled = true;
            foreach (var item in listDetail)
            {
                if (this.HaveBilling(item.Sell.InternalID)
                    || this.HaveDelivery(item.Sell.InternalID))
                {
                    isEnabled = false;
                    break;
                }
            }

            this.cmbCurrency.Enabled = isEnabled;
            this.cmbMethodVat.Enabled = isEnabled;
        }

        /// <summary>
        /// Lock Sell
        /// </summary>
        /// <param name="internalID">internalID</param>
        /// <param name="item">RepeaterItem</param>
        private void LockSell(int internalID, RepeaterItem item)
        {
            //Find Control
            ICodeTextBox txtSellProductCD = (ICodeTextBox)item.FindControl("txtSellProductCD");
            ITextBox txtSellProductName = (ITextBox)item.FindControl("txtSellProductName");
            INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtSellPrice");
            INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtSellVatRatio");
            DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbSellVatType");
            INumberTextBox txtProfit = (INumberTextBox)item.FindControl("txtProfit");
            LinkButton btnProfitProcess = (LinkButton)item.FindControl("btnProfitProcess");
            DropDownList cmbSellUnit = (DropDownList)item.FindControl("cmbSellUnit");
            HtmlButton btnProfitProcessDisable = (HtmlButton)item.FindControl("btnProfitProcessDisable");

            LinkButton btnCopyCost = (LinkButton)item.FindControl("btnCopyCost");
            HtmlButton btnSearchSalesProduct = (HtmlButton)item.FindControl("btnSearchSalesProduct");

            bool isEnabled = true;

            //Check sell Billing or Delivery
            if (internalID != -1
                && (this.HaveBilling(internalID)
                || this.HaveDelivery(internalID)))
            {
                isEnabled = false;
            }

            //Lock control
            if (isEnabled)
            {
                btnProfitProcess.Visible = true;
                btnProfitProcessDisable.Visible = false;
            }
            else
            {
                btnProfitProcess.Visible = false;
                btnProfitProcessDisable.Visible = true;
            }
            //cmbSellUnit.Enabled = isEnabled;

            btnCopyCost.Visible = isEnabled;
            if (btnSearchSalesProduct.Visible)
            {
                btnSearchSalesProduct.Visible = isEnabled;
            }
            txtSellProductCD.SetReadOnly(!isEnabled);
            txtSellProductName.SetReadOnly(!isEnabled);
            txtProfit.SetReadOnly(!isEnabled);
            txtSellPrice.SetReadOnly(!isEnabled);

            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
            {
                cmbSellVatType.Enabled = isEnabled;
                if (cmbSellVatType.SelectedItem != null)
                {
                    if (Convert.ToInt32(cmbSellVatType.SelectedValue) == (int)VATFlg.Exclude)
                    {
                        txtSellVatRatio.SetReadOnly(!isEnabled);
                    }
                }
            }
        }

        /// <summary>
        /// Lock Cost
        /// </summary>
        /// <param name="internalID">internalID</param>
        /// <param name="item">RepeaterItem</param>
        private void LockCost(int internalID, RepeaterItem item)
        {
            //Find control
            ICodeTextBox txtCostProductCD = (ICodeTextBox)item.FindControl("txtCostProductCD");
            ITextBox txtCostProductName = (ITextBox)item.FindControl("txtCostProductName");
            INumberTextBox txtCostPrice = (INumberTextBox)item.FindControl("txtCostPrice");
            DropDownList cmbCostVatType = (DropDownList)item.FindControl("cmbCostVatType");
            INumberTextBox txtCostVatRatio = (INumberTextBox)item.FindControl("txtCostVatRatio");
            DropDownList cmbCostCurrency = (DropDownList)item.FindControl("cmbCostCurrency");
            DropDownList cmbCostUnit = (DropDownList)item.FindControl("cmbCostUnit");
            ICodeTextBox txtCostVendorCD = (ICodeTextBox)item.FindControl("txtCostVendorCD");
            ITextBox txtCostVendorName = (ITextBox)item.FindControl("txtCostVendorName");
            HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)item.FindControl("chkPurchaseFlag");

            LinkButton btnCopySell = (LinkButton)item.FindControl("btnCopySell");
            HtmlButton btnSearchSalesProduct = (HtmlButton)item.Parent.Parent.FindControl("btnSearchSalesProduct");

            bool isEnabled = true;

            //Check cost have purchase
            if (internalID != -1 && this.HavePO(internalID))
            {
                isEnabled = false;
            }

            //Lock control
            cmbCostCurrency.Enabled = isEnabled;
            //cmbCostVatType.Enabled = isEnabled;
            //cmbCostUnit.Enabled = isEnabled;

            //if (cmbCostVatType.SelectedItem != null)
            //{
            //    if (Convert.ToInt32(cmbCostVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
            //    {
            //        txtCostVatRatio.SetReadOnly(!isEnabled);
            //    }
            //}
            chkPurchaseFlag.Disabled = !isEnabled;

            btnCopySell.Visible = isEnabled;
            btnSearchSalesProduct.Visible = isEnabled;
            if (!this.ProductCDSettingSame)
            {
                txtCostProductCD.SetReadOnly(!isEnabled);
            }
            txtCostProductName.SetReadOnly(!isEnabled);
            txtCostVendorCD.SetReadOnly(!isEnabled);
            txtCostVendorName.SetReadOnly(!isEnabled);
            txtCostPrice.SetReadOnly(!isEnabled);
        }

        /// <summary>
        /// check have PO Billing Delivery
        /// </summary>
        /// <param name="headerID">headerID</param>
        /// <returns></returns>
        public bool HavePOBillingDelivery(int headerID)
        {
            return this.IsPOProcessed(headerID)
                   || this.IsBillingProcessed(headerID)
                   || this.IsDeliveryProcessed(headerID);
        }

        /// <summary>
        /// check Have Billing Or Delivery
        /// </summary>
        /// <param name="headerID">headerID</param>
        private bool HaveBillingOrDelivery(int headerID)
        {
            if (this.IsDeliveryProcessed(headerID) || this.IsBillingProcessed(headerID))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// check Sales sell have Billing
        /// </summary>
        /// <param name="internalID">internalID</param>
        /// <returns></returns>
        private bool HaveBilling(int internalID)
        {
            if (internalID != 0)
            {
                using (DB db = new DB())
                {
                    Billing_DService billing_DService = new Billing_DService(db);

                    var sumQuantity = billing_DService.GetSumQuantityBySalesSellID(internalID);
                    return sumQuantity != 0
                        && sumQuantity != -1;
                }
            }
            return false;
        }

        /// <summary>
        /// check Sales sell have Delivery
        /// </summary>
        /// <param name="internalID">internalID</param>
        /// <returns></returns>
        private bool HaveDelivery(int internalID)
        {
            if (internalID != 0)
            {
                using (DB db = new DB())
                {
                    Delivery_DService delivery_DService = new Delivery_DService(db);

                    var sumQuantity = delivery_DService.GetSumQuantityBySalesSellID(internalID);
                    return sumQuantity != 0
                        && sumQuantity != -1;
                }
            }
            return false;
        }

        /// <summary>
        /// check Sales cost have PO
        /// </summary>
        /// <param name="internalID"></param>
        /// <returns></returns>
        private bool HavePO(int internalID)
        {
            if (internalID != 0)
            {
                using (DB db = new DB())
                {
                    Purchase_DService purchase_DService = new Purchase_DService(db);
                    var sumQuantity = purchase_DService.GetSumQuantityBySalesCostID(internalID);
                    return sumQuantity != 0;
                }
            }
            return false;
        }

        /// <summary>
        /// Check Sales PO Processed
        /// </summary>
        /// <param name="salesID">salesID</param>
        /// <returns></returns>
        public bool IsPOProcessed(int salesID)
        {
            using (DB db = new DB())
            {
                Purchase_DService purchase_DService = new Purchase_DService(db);

                return purchase_DService.GetListSumQtyBySalesID(salesID) != 0;
            }
        }

        /// <summary>
        /// Check Billing processed
        /// </summary>
        /// <param name="salesID">salesID</param>
        /// <returns></returns>
        public bool IsBillingProcessed(int salesID)
        {
            using (DB db = new DB())
            {
                Billing_DService billing_DService = new Billing_DService(db);

                return billing_DService.GetListBySalesID(salesID) != 0;
            }
        }

        /// <summary>
        /// Check Delivery processed
        /// </summary>
        /// <param name="salesID">salesID</param>
        /// <returns></returns>
        public bool IsDeliveryProcessed(int salesID)
        {
            using (DB db = new DB())
            {
                Delivery_DService delivery_DService = new Delivery_DService(db);

                return delivery_DService.GetListBySalesID(salesID) != 0;
            }
        }

        /// <summary>
        /// Check Valid to Billing
        /// </summary>
        /// <returns></returns>
        public bool IsValidBilling()
        {
            //Check Authority
            return true;
        }

        /// <summary>
        /// Check Valid to Delivery
        /// </summary>
        /// <returns></returns>
        public bool IsValidDelivery()
        {
            //Check Authority
            var listDetail = this.GetData();
            var isAllItemMinus = true;
            foreach (var item in listDetail)
            {
                if (item.Sell.Price > 0)
                {
                    isAllItemMinus = false;
                    break;
                }
            }

            return !isAllItemMinus;
        }

        /// <summary>
        /// Check all to reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidAllRef()
        {
            return this.IsValidQuotationRef()
                || this.IsPOProcessed(this.SalesID)
                || this.IsDeliveryProcessed(this.SalesID)
                || this.IsBillingProcessed(this.SalesID);
        }

        /// <summary>
        /// Check valid to quotation reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidQuotationRef()
        {
            return !this.txtQuotationNo.IsEmpty;
        }

        /// <summary>
        /// Get tax name
        /// </summary>
        /// <returns></returns>
        public string GetTaxName()
        {
            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == this.CurrencyIDOld).SingleOrDefault();
            if (crcy != null)
            {
                return string.Format("{0}/Ratio", ((M_Currency_H)crcy.DataboundItem).TaxName);
            }
            return "VAT/Ratio";
        }
        #endregion

        #region Excel

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSaleContract_Click(object sender, CommandEventArgs e)
        {
            var header = this.GetSales(this.SalesID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate
                    || header.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (header.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_SALES_LIST);
                        return;
                    }
                }

                if (isOk)
                {
                    var index = int.Parse(e.CommandArgument.ToString());

                    this.TypeOfIssue = this.ListSalesContractFile[index];
                    var salesContractFile = Path.GetFileNameWithoutExtension(this.ListSalesContractFile[index]);

                    SalesContractExcel excel =new SalesContractExcel();
                    excel.SalesID =this.SalesID;
                    excel.QuantityDecimal = this.QuantityDecimal;
                    excel._fractionType = this._fractionType;
                    IWorkbook wb = excel.OutputExcel(salesContractFile);

                    this.SaveFile(wb);
                }

                //Get info by ID
                var salesH = this.GetSales(this.SalesID);

                //Show data
                this.ShowHeaderData(salesH);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
        }

        /// <summary>
        /// Format display name button
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatFileName(string fileName)
        {
            return Path.GetFileNameWithoutExtension(fileName);
        }

        #endregion

        #endregion
    }
}
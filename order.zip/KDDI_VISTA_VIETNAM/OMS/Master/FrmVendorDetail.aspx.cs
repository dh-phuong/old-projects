﻿using System;
using System.Web.UI.WebControls; 
using OMS.Utilities;
using OMS.Models;
using OMS.DAC;
using System.Data.SqlClient;

namespace OMS.Master
{
    /// <summary>
    /// Vendor Detail
    /// ISV-TRUC
    /// </summary>
    public partial class FrmVendorDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmVendorList.aspx";
        #endregion

        #region Property

        /// <summary>
        /// Get or set VendorID
        /// </summary>
        public int VendorID
        {
            get { return (int)ViewState["VendorID"]; }
            set { ViewState["VendorID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vendor Master";
            base.FormSubTitle = "Detail";

            //Init Maxlength for control
            this.InitMaxLengthControl();

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Event Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Vendor);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];
                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.VendorID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Vendor vendor = this.GetVendor(this.VendorID);

                        //Check vendor
                        if (vendor != null)
                        {
                            //Show data
                            this.ShowData(vendor);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

        }

        /// <summary>
        /// Event Copy
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Vendor
            M_Vendor vendor = this.GetVendor(this.VendorID);

            //Check Vendor
            if (vendor != null)
            {
                //Show data
                this.ShowData(vendor);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get vendor
            M_Vendor vendor = this.GetVendor(this.VendorID);

            //Check vendor
            if (vendor != null)
            {
                //Show data
                this.ShowData(vendor);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;
            
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);            
        }
        

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);            

        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {            
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);            
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Vendor
            M_Vendor vendor = this.GetVendor(this.VendorID);

            //Check user
            if (vendor != null)
            {
                //Show data
                this.ShowData(vendor);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        M_Vendor vedor = this.GetVendor(this.txtVendorCD.Value);

                        //Show data
                        this.ShowData(vedor);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }            
                    break;

                case Utilities.Mode.Delete:

                    //Delete vendor
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_Vendor vendor = this.GetVendor(this.VendorID);

                        //Show data
                        this.ShowData(vendor);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get vendor
            M_Vendor vendor = this.GetVendor(this.VendorID);
            if (vendor != null)
            {
                //Show data
                this.ShowData(vendor);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtVendorCD.ReadOnly = true;
                       
                        this.chkStatusFlag.Disabled = false;
                    }
                    else
                    {
                        this.txtVendorCD.ReadOnly = false;
                        this.chkStatusFlag.Disabled = true;
                        this.chkStatusFlag.Checked = true;
                        
                    }

                    enable = false;

                    break;

                default:

                    this.txtVendorCD.ReadOnly = true;
                    this.chkStatusFlag.Disabled = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    enable = true;
                    break;
            }

            //Lock control
            this.txtVendorName1.ReadOnly = enable;       //Vendor Name 1
            this.txtVendorName2.ReadOnly = enable;       //Vendor Name 2
            this.txtVendorAddress1.ReadOnly = enable;    //Vendor Address 1
            this.txtVendorAddress2.ReadOnly = enable;    //Vendor Address 2
            this.txtVendorAddress3.ReadOnly = enable;    //Vendor Address 3
            this.txtBusinessAreas.ReadOnly = enable;     //Business Areas
            this.txtTel.ReadOnly = enable;               //Tel
            this.txtFax.ReadOnly = enable;               //Fax
            this.txtEmail.ReadOnly = enable;             //Email
            this.txtContactPerson.ReadOnly = enable;     //Contact Person
            this.txtContactTel.ReadOnly = enable;        //Contact Tel
            this.txtTaxCode.ReadOnly = enable;           //Taxcode
            this.txtVendorBank.ReadOnly = enable;        //Vendor Bank
            this.txtAccountNo.ReadOnly = enable;         //Account No.
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="vendor">M_Vendor</param>
        private void ShowData(M_Vendor vendor)
        {
            //Show data
            if (vendor != null)
            {
                this.txtVendorCD.Value = vendor.VendorCD;
                this.txtVendorName1.Value = vendor.VendorName1;
                this.txtVendorName2.Value = vendor.VendorName2;
                this.txtVendorAddress1.Value = vendor.VendorAddress1;
                this.txtVendorAddress2.Value = vendor.VendorAddress2;
                this.txtVendorAddress3.Value = vendor.VendorAddress3;
                this.txtBusinessAreas.Value = vendor.GroupSupply;
                this.txtTel.Value = vendor.Tel;
                this.txtFax.Value = vendor.FAX;
                this.txtEmail.Value = vendor.EmailAddress;
                this.txtContactPerson.Value = vendor.ContactPerson;
                this.txtContactTel.Value = vendor.ContactTel;
                this.txtTaxCode.Value = vendor.TAXCode;
                this.txtVendorBank.Value = vendor.VendorBank;
                this.txtAccountNo.Value = vendor.AccountCode;

                this.chkStatusFlag.Checked = vendor.StatusFlag == 0 ? true : false;

                //Save UserID and UpdateDate
                this.VendorID = vendor.ID;
                this.OldUpdateDate = vendor.UpdateDate;
            }
        }

        /// <summary>
        /// Get Vendor By ID
        /// </summary>
        /// <param name="vendorID">vendorID</param>
        /// <returns>M_Vendor</returns>
        private M_Vendor GetVendor(int vendorID)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.GetByID(vendorID);
            }
        }

        /// <summary>
        /// Get Vendor By Code
        /// </summary>
        /// <param name="vendorCD">vendorCD</param>
        /// <returns>M_Vendor</returns>
        private M_Vendor GetVendor(string vendorCD)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.GetByCD(vendorCD);
            }
        }

        /// <summary>
        /// Check TaxCode 
        /// </summary>
        /// <param name="taxCode"></param>
        /// <returns></returns>
        private bool GetTaxCode(string taxCode)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.IsExistTaxCode(taxCode);
            }
        }

        /// <summary>
        /// Check TaxCode Exist With VendorCD
        /// </summary>
        /// <param name="vendorCD">VendorCD</param>
        /// <param name="taxCode">TaxCode</param>
        /// <returns></returns>
        private bool GetTaxCodeWithVendorCD(string vendorCD, string taxCode)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.IsExistTaxCDWithVendorCD(vendorCD, taxCode);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Vendor CD
            if (this.txtVendorCD.IsEmpty)
            {
                this.SetMessage(this.txtVendorCD.ID, M_Message.MSG_REQUIRE, "Vendor Code");
            }
            else
            {
                ////Check length
                //if (this.txtVendorCD.Value.Length > M_Vendor.VENDOR_CODE_MAX_LENGTH)
                //{
                //    this.SetMessage(MessageType.Error, "txtVendorCD", "0007", "VendorCD", "VendorCD");
                //}
                //Check exist                
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.txtVendorCD.Value.Equals(M_Vendor.VENDOR_CODE_SUPPORT))
                    {
                        //Diff '999999'
                        this.SetMessage(this.txtVendorCD.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Vendor Code", M_Vendor.VENDOR_CODE_SUPPORT);
                    }
                    else if (this.GetVendor(this.txtVendorCD.Value) != null)
                    {
                        this.SetMessage(this.txtVendorCD.ID, M_Message.MSG_EXIST_CODE, "Vendor Code");
                    }
                }
            }

            //VendorName1
            if (this.txtVendorName1.IsEmpty)
            {
                this.SetMessage(this.txtVendorName1.ID, M_Message.MSG_REQUIRE, "Vendor Name 1");
            }            

            //VendorName2
            //if (this.txtVendorName2.IsEmpty)
            //{
            //    this.SetMessage(this.txtVendorName2.ID, M_Message.MSG_REQUIRE, "Vendor Name 2");
            //}

            //Check Tel
            if (!this.txtTel.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtTel.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtTel.ID, M_Message.MSG_INCORRECT_FORMAT, "Tel");
                }
            }

            //Check Fax
            if (!this.txtFax.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtFax.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtFax.ID, M_Message.MSG_INCORRECT_FORMAT, "Fax");
                }
            }
           
            //Check Email
            if (!this.txtEmail.IsEmpty)
            {
                if (!CheckDataUtil.IsEmail(this.txtEmail.Value))
                {
                    this.SetMessage(this.txtEmail.ID, M_Message.MSG_INCORRECT_FORMAT, "Email");
                }
            }
            //Check Contact Tel
            if (!this.txtContactTel.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtContactTel.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtContactTel.ID, M_Message.MSG_INCORRECT_FORMAT, "Contact Tel");
                }
            }
           
            //Check TaxCode
            if (!this.txtTaxCode.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtTaxCode.Value, Constants.PATTERN_TAX_CODE))
                {
                    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_INCORRECT_FORMAT, "Tax Code");
                }
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.GetTaxCode(this.txtTaxCode.Value))
                    {
                        this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                    }
                }
                else if (this.Mode == Mode.Update)
                {
                    if (!this.GetTaxCodeWithVendorCD(this.txtVendorCD.Value, this.txtTaxCode.Value))
                    {
                        if (this.GetTaxCode(this.txtTaxCode.Value))
                        {
                            this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                        }
                    }
                }
            }

            //Check Account No.
            if (!this.txtAccountNo.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtAccountNo.Value, Constants.PATTERN_ACCOUNT_NO))
                {
                    this.SetMessage(this.txtAccountNo.ID, M_Message.MSG_INCORRECT_FORMAT, "Account No");
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Vendor vendor = new M_Vendor();
                vendor.VendorCD = this.txtVendorCD.Value;
                vendor.VendorName1 = this.txtVendorName1.Value;
                vendor.VendorName2 = this.txtVendorName2.Value;
                vendor.VendorAddress1 = this.txtVendorAddress1.Value;
                vendor.VendorAddress2 = this.txtVendorAddress2.Value;
                vendor.VendorAddress3 = this.txtVendorAddress3.Value;
                vendor.GroupSupply = this.txtBusinessAreas.Value;
                vendor.Tel = this.txtTel.Value;
                vendor.FAX = this.txtFax.Value;
                vendor.EmailAddress = this.txtEmail.Value;
                vendor.ContactPerson = this.txtContactPerson.Value;
                vendor.ContactTel = this.txtContactTel.Value;
                vendor.TAXCode = this.txtTaxCode.Value;
                vendor.VendorBank = this.txtVendorBank.Value;
                vendor.AccountCode = this.txtAccountNo.Value;

                vendor.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                vendor.CreateUID = this.LoginInfo.User.ID;
                vendor.UpdateUID = this.LoginInfo.User.ID;

                //Insert Vendor
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    VendorService vendorSer = new VendorService(db);

                    //Insert vendor
                    vendorSer.Insert(vendor);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Models.Constant.M_VENDOR_UN_TAXCODE))
                {
                    this.SetMessage(this.txtVendorCD.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                    return false;
                }

                if (ex.Message.Contains(Models.Constant.M_VENDOR_UN))
                {
                    this.SetMessage(this.txtVendorCD.ID, M_Message.MSG_EXIST_CODE, "Vendor Code");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }
            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Vendor vendor = this.GetVendor(this.txtVendorCD.Value);
                if (vendor != null)
                {
                    //Create model
                    vendor.VendorCD = this.txtVendorCD.Value;
                    vendor.VendorName1 = this.txtVendorName1.Value;
                    vendor.VendorName2 = this.txtVendorName2.Value;
                    vendor.VendorAddress1 = this.txtVendorAddress1.Value;
                    vendor.VendorAddress2 = this.txtVendorAddress2.Value;
                    vendor.VendorAddress3 = this.txtVendorAddress3.Value;
                    vendor.GroupSupply = this.txtBusinessAreas.Value;
                    vendor.Tel = this.txtTel.Value;
                    vendor.FAX = this.txtFax.Value;
                    vendor.EmailAddress = this.txtEmail.Value;
                    vendor.ContactPerson = this.txtContactPerson.Value;
                    vendor.ContactTel = this.txtContactTel.Value;
                    vendor.TAXCode = this.txtTaxCode.Value;
                    vendor.VendorBank = this.txtVendorBank.Value;
                    vendor.AccountCode = this.txtAccountNo.Value;

                    vendor.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                    vendor.UpdateDate = this.OldUpdateDate;
                    vendor.UpdateUID = this.LoginInfo.User.ID;

                    //Update Vendor                   
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VendorService vendorSer = new VendorService(db);
                       
                        //Update Vendor
                        if (vendor.Status == DataStatus.Changed)
                        {
                            ret = vendorSer.Update(vendor);
                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_VENDOR_UN_TAXCODE))
                {
                    this.SetMessage(this.txtVendorName1.ID, M_Message.MSG_EXIST_CODE, "Tax code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns></returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;                             
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    VendorService vendorSer = new VendorService(db);

                    //Delete Vendor
                    ret = vendorSer.Delete(this.VendorID, this.OldUpdateDate);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_VENDOR) ||
                    ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_VENDOR) ||
                    ex.Message.Contains(Models.Constant.T_PURCHASE_H_FK_VENDOR) ||
                    ex.Message.Contains(Models.Constant.M_VENDORPRODUCT_FK_VENDOR)
                    )
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Vendor Code " + this.txtVendorCD.Value);
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Init Maxlength for control
        /// </summary>
        private void InitMaxLengthControl()
        {
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorName1.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;
            this.txtVendorName2.MaxLength = M_Vendor.VENDOR_NAME_2_MAX_LENGTH;
            this.txtVendorAddress1.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtVendorAddress2.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtVendorAddress3.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtBusinessAreas.MaxLength = M_Vendor.VENDOR_GROUP_SUPPLY_MAX_LENGTH;
            this.txtTel.MaxLength = M_Vendor.VENDOR_TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Vendor.VENDOR_FAX_MAX_LENGTH;
            this.txtEmail.MaxLength = M_Vendor.VENDOR_EMAIL_MAX_LENGTH;
            this.txtContactPerson.MaxLength = M_Vendor.VENDOR_CONTACT_PERSON_MAX_LENGTH;
            this.txtContactTel.MaxLength = M_Vendor.VENDOR_CONTACT_TEL_MAX_LENGTH;
            this.txtTaxCode.MaxLength = M_Vendor.VENDOR_TAX_CODE_MAX_LENGTH;
            this.txtVendorBank.MaxLength = M_Vendor.VENDOR_BANK_MAX_LENGTH;
            this.txtAccountNo.MaxLength = M_Vendor.VENDOR_ACCOUNT_CODE_MAX_LENGTH;
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            //Lock control
            this.txtVendorCD.Value = string.Empty;          //Vendor CD
            this.txtVendorName1.Value = string.Empty;       //Vendor Name 1
            this.txtVendorName2.Value = string.Empty;       //Vendor Name 2
            this.txtVendorAddress1.Value = string.Empty;    //Vendor Address 1
            this.txtVendorAddress2.Value = string.Empty;    //Vendor Address 2
            this.txtVendorAddress3.Value = string.Empty;    //Vendor Address 3
            this.txtBusinessAreas.Value = string.Empty;     //Business Areas
            this.txtTel.Value = string.Empty;               //Tel
            this.txtFax.Value = string.Empty;               //Fax
            this.txtEmail.Value = string.Empty;             //Email
            this.txtContactPerson.Value = string.Empty;     //Contact Person
            this.txtContactTel.Value = string.Empty;        //Contact Tel
            this.txtTaxCode.Value = string.Empty;           //Taxcode
            this.txtVendorBank.Value = string.Empty;        //Vendor Bank
            this.txtAccountNo.Value = string.Empty;         //Account No.
        }
        #endregion

        #region Web Methods

        /// <summary>
        /// Format vendor Code
        /// </summary>
        /// <param name="in1">VendorCD</param>
        /// <returns>Vendor CD</returns>
        [System.Web.Services.WebMethod]
        public static string FormatVendorCD(string in1)
        {
            try
            {
                var vendorCd = in1;
                var vendorCdShow = in1;
                vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
                var onlyCd = new
                {
                    txtVendorCD = vendorCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
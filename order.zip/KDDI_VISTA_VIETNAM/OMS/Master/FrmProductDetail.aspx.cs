﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using System.Data.SqlClient;

namespace OMS.Master
{
    /// <summary>
    /// Product detail
    /// VN-Nho
    /// </summary>
    public partial class FrmProductDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmProductList.aspx";
        #endregion

        #region Property
        /// <summary>
        /// DefaultVatType
        /// </summary>
        private string _defaultVatType;

        /// <summary>
        /// Get or set ProductID
        /// </summary>
        public int ProductID
        {
            get { return (int)ViewState["ProductID"]; }
            set { ViewState["ProductID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return this.GetValueViewState<DateTime>("OldUpdateDate"); }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public decimal DefaultVAT
        {
            get
            {
                return this.GetValueViewState<decimal>("DefaultVAT");
            }
            private set { ViewState["DefaultVAT"] = value; }
        }

        /// <summary>
        /// Focus ID
        /// </summary>
        protected string FocusID { get; set; }

        /// <summary>
        /// Is sell actived
        /// </summary>
        protected bool IsSellActive { get; set; }

        /// <summary>
        /// Is show search type
        /// </summary>
        protected bool IsShowSearchType { get; set; }

        #endregion

        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Product Master";
            base.FormSubTitle = "Detail";


            //Init Event
            this.cmbCategory1.SelectedIndexChanged += cmbCategory1_SelectedIndexChanged;
            this.cmbCategory2.SelectedIndexChanged += cmbCategory2_SelectedIndexChanged;
            //this.cmbCategory3.SelectedIndexChanged += cmbCategory3_SelectedIndexChanged;

            this.cmbCRCYSell.SelectedIndexChanged += cmbCRCY_SelectedIndexChanged;
            this.cmbCRCYCost.SelectedIndexChanged += cmbCRCY_SelectedIndexChanged;

            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);

            this.InitMaxLength();
        }

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Product);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            bool temp;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                temp = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }
            if (!temp)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            //Get is show search type flag
            this.IsShowSearchType = false;
            using (DB db = new DB())
            {
                Config_HService configHService = new Config_HService(db);
                this._defaultVatType = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);
                this.DefaultVAT = decimal.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL));
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYSell, null);
                this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYCost, null);
                this.FocusID = string.Empty;

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get product data by id
                        this.ProductID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Product product = this.GetProduct(this.ProductID);

                        //Check user
                        if (product != null)
                        {
                            //Show data
                            this.ShowData(product);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            else
            {

                //if (this.cmbVatTypeSell.SelectedValue.Equals("0"))
                if (Convert.ToInt32(this.cmbVatTypeSell.SelectedItem.Value) == (int)VATFlg.Exclude)
                {
                    this.txtVatRatioSell.ReadOnly = false;
                }
                else
                {
                    this.txtVatRatioSell.Value = null;
                    this.hdnVatRatioSell.Value = null;
                    this.txtVatRatioSell.ReadOnly = true;
                }

                //if (this.cmbVatTypeCost.SelectedValue.Equals("0"))
                if (Convert.ToInt32(this.cmbVatTypeCost.SelectedItem.Value) == (int)VATFlg.Exclude)
                {
                    this.txtVatRatioCost.ReadOnly = false;
                }
                else
                {
                    this.txtVatRatioCost.Value = null;
                    this.hdnVatRatioCost.Value = null;
                    this.txtVatRatioCost.ReadOnly = true;
                }
            }

            //Set confirm data
            this.SetConfirmData();

            //Set tab active
            this.SetTabActive();
        }

        /// <summary>
        /// Event Copy
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Product data
            M_Product product = this.GetProduct(this.ProductID);

            //Check product is exist
            if (product != null)
            {
                //Show data
                this.ShowData(product);

                //Set Mode
                this.ProcessMode(Mode.Copy);

                this.FocusID = string.Empty;

            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);

        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get product data
            M_Product product = this.GetProduct(this.ProductID);

            //Check product is exist
            if (product != null)
            {
                //Show data
                this.ShowData(product);

                //Set Mode
                this.ProcessMode(Mode.Update);

                this.FocusID = string.Empty;
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Back click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get product data
            M_Product product = this.GetProduct(this.ProductID);

            //Check product Exists
            if (product != null)
            {
                //Show data
                this.ShowData(product);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        //Get product data
                        M_Product product = this.GetProduct(this.txtProductCD.Value);

                        //Show data
                        this.ShowData(product);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:


                    //Delete product
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //Get product data
                        M_Product product = this.GetProduct(this.ProductID);

                        //Show data
                        this.ShowData(product);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get product data
            M_Product product = this.GetProduct(this.ProductID);
            if (product != null)
            {
                //Show data
                this.ShowData(product);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Copy data form Sell to Cost
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopySell_Click(object sender, EventArgs e)
        {
            this.txtDescriptionCost.Value = this.txtDescriptionSell.Value;
            this.cmbCRCYCost.SelectedValue = this.cmbCRCYSell.SelectedValue;
            this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYCost, null);
            this.txtUnitPriceCost.Value = this.txtUnitPriceSell.Value;
            this.cmbUnitCost.SelectedValue = this.cmbUnitSell.SelectedValue;
            this.cmbVatTypeCost.SelectedValue = this.cmbVatTypeSell.SelectedValue;
            this.txtVatRatioCost.Value = this.txtVatRatioSell.Value;
            this.txtRemarkCost.Value = this.txtRemarkSell.Value;

            //if (this.cmbVatTypeCost.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeCost.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                this.txtVatRatioCost.ReadOnly = false;
            }
            else
            {
                this.txtVatRatioCost.ReadOnly = true;
            }

            this.CalProfit();

            this.FocusID = this.txtDescriptionCost.ID;
        }

        /// <summary>
        /// Copy data form Cost to Sell
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopyCost_Click(object sender, EventArgs e)
        {
            this.txtDescriptionSell.Value = this.txtDescriptionCost.Value;
            this.cmbCRCYSell.SelectedValue = this.cmbCRCYCost.SelectedValue;
            this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYSell, null);
            this.txtUnitPriceSell.Value = this.txtUnitPriceCost.Value;
            this.cmbUnitSell.SelectedValue = this.cmbUnitCost.SelectedValue;
            this.cmbVatTypeSell.SelectedValue = this.cmbVatTypeCost.SelectedValue;
            this.txtVatRatioSell.Value = this.txtVatRatioCost.Value;
            this.txtRemarkSell.Value = this.txtRemarkCost.Value;

            //if (this.cmbVatTypeSell.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeSell.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                this.txtVatRatioSell.ReadOnly = false;
            }
            else
            {
                this.txtVatRatioSell.ReadOnly = true;
            }

            this.CalProfit();

            this.FocusID = this.txtDescriptionSell.ID;
        }        

        protected void cmbCategory1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var categoryId = int.Parse(this.cmbCategory1.SelectedValue);
            if (categoryId == -1)
            {
                this.SetComboByLevel(this.cmbCategory1, 1);
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                //this.SetComboByLevel(this.cmbCategory2, 2);
                //this.SetComboByLevel(this.cmbCategory3, 3);
                this.SetBlankCombo(this.cmbCategory2);
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }
            else
            {
                this.SetComboFromCategory1(this.cmbCategory2, categoryId, 2, "-1");
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                //this.SetComboFromCategory1(this.cmbCategory3, categoryId, 3, "-1");
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }

            this.FocusID = this.cmbCategory1.ClientID;
        }
        protected void cmbCategory2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
            int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);
            //IList<M_CategoryStruct> listCategory1;

            if (categoryId1 != -1)
            {
                if (categoryId2 != -1)
                {
                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, "-1");
                }
                else
                {
                    //2015/01/26
                    //Author: dh-phuong
                    //---------------------start
                    //this.SetComboFromCategory1(this.cmbCategory3, categoryId1, 3, "-1");
                    this.SetBlankCombo(this.cmbCategory3);
                    //---------------------end
                }
            }
            //2015/01/26
            //Author: dh-phuong
            //---------------------start
            //else
            //{
            //    if (categoryId2 != -1)
            //    {
            //        //Get list parent
            //        listCategory1 = this.GetListCategoryParentID(categoryId2, 2);
            //        if (listCategory1.Count != 0)
            //        {
            //            //Load combo
            //            this.SetComboFromCategory1AndCategory2(this.cmbCategory3, listCategory1[0].CategoryID, categoryId2, "-1");
            //            this.SetComboFromCategory1(this.cmbCategory2, listCategory1[0].CategoryID, 2, categoryId2.ToString());

            //            //Set value
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetValueCombo(this.cmbCategory1, listCategory1[0].CategoryID.ToString());
            //        }
            //        else
            //        {
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetComboByLevel(this.cmbCategory2, 2);
            //            this.SetComboByLevel(this.cmbCategory3, 3);
            //        }
            //    }
            //}
            //---------------------end
            this.FocusID = this.cmbCategory2.ClientID;
        }
        //protected void cmbCategory3_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
        //    int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);
        //    int categoryId3 = int.Parse(this.cmbCategory3.SelectedValue);

        //    IList<M_CategoryStruct> listCategory2;
        //    M_CategoryStruct categoryStruct;
        //    if (categoryId1 != -1)
        //    {
        //        if (categoryId2 != -1)
        //        {

        //        }
        //        else
        //        {
        //            if (categoryId3 != -1)
        //            {
        //                //Get list parent
        //                listCategory2 = this.GetListCategoryParentID(categoryId3, 3);
        //                if (listCategory2.Count != 0)
        //                {
        //                    this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, listCategory2[0].CategoryID.ToString());
        //                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, listCategory2[0].CategoryID, categoryId3.ToString());
        //                }
        //                else
        //                {
        //                    this.SetComboByLevel(this.cmbCategory2, 2);
        //                    this.SetComboByLevel(this.cmbCategory3, 3);
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        if (categoryId3 != -1)
        //        {
        //            //Category3
        //            int categoryStructID = this.GetCategoryStructID(categoryId3, 3);
        //            if (categoryStructID != -1)
        //            {
        //                //Category 2
        //                categoryStruct = this.GetCategoryStructID(categoryStructID);
        //                if (categoryStruct != null)
        //                {
        //                    //Category1
        //                    categoryId2 = categoryStruct.CategoryID;
        //                    categoryStruct = this.GetCategoryStructID(categoryStruct.CategoryStructID);
        //                    if (categoryStruct != null)
        //                    {
        //                        categoryId1 = categoryStruct.CategoryID;
        //                        this.SetComboByLevel(this.cmbCategory1, 1);
        //                        this.SetValueCombo(this.cmbCategory1, categoryId1.ToString());

        //                        this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, categoryId2.ToString());
        //                        this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, categoryId3.ToString());
        //                    }
        //                    else
        //                    {
        //                        this.SetComboByLevel(this.cmbCategory1, 1);
        //                        this.SetComboByLevel(this.cmbCategory2, 2);
        //                        this.SetComboByLevel(this.cmbCategory3, 3);
        //                    }
        //                }
        //                else
        //                {
        //                    this.SetComboByLevel(this.cmbCategory1, 1);
        //                    this.SetComboByLevel(this.cmbCategory2, 2);
        //                    this.SetComboByLevel(this.cmbCategory3, 3);
        //                }
        //            }
        //            else
        //            {
        //                this.SetComboByLevel(this.cmbCategory1, 1);
        //                this.SetComboByLevel(this.cmbCategory2, 2);
        //                this.SetComboByLevel(this.cmbCategory3, 3);
        //            }
        //        }
        //    }

        //    this.FocusID = this.cmbCategory3.ClientID;           
        //}

        /// <summary>
        /// Currency selected change event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCRCY_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList cmbCRCY = (DropDownList)sender;

            using (DB db = new DB())
            {
                Currency_HService currencyService = new Currency_HService(db);
                M_Currency_H currencyModel = currencyService.GetByID(int.Parse(cmbCRCY.SelectedValue));
                if (currencyModel != null)
                {
                    if (cmbCRCY.ID == this.cmbCRCYSell.ID)
                    {
                        this.lblVatTypeSell.InnerText = currencyModel.TaxName;
                        this.lblVatRatioSell.InnerHtml = currencyModel.TaxName + "Ratio ";
                        if (currencyModel.DecimalType == 1)
                        {
                            this.txtUnitPriceSell.DecimalDigit = 2;
                            this.txtUnitPriceSell.MaximumValue = M_Product.MAX_UNIT_PRICE_USD;
                        }
                        else
                        {
                            this.txtUnitPriceSell.DecimalDigit = 0;
                            this.txtUnitPriceSell.MaximumValue = M_Product.MAX_UNIT_PRICE_VND;
                        }
                    }
                    else
                    {
                        this.lblVatTypeCost.InnerText = currencyModel.TaxName;
                        this.lblVatRatioCost.InnerHtml = currencyModel.TaxName + "Ratio ";
                        if (currencyModel.DecimalType == 1)
                        {
                            this.txtUnitPriceCost.DecimalDigit = 2;
                            this.txtUnitPriceCost.MaximumValue = M_Product.MAX_UNIT_PRICE_USD;
                        }
                        else
                        {
                            this.txtUnitPriceCost.DecimalDigit = 0;
                            this.txtUnitPriceCost.MaximumValue = M_Product.MAX_UNIT_PRICE_VND;
                        }
                    }
                }
            }
            if (cmbCRCY.ID == this.cmbCRCYSell.ID)
            {
                this.FocusID = this.cmbCRCYSell.ID;
                this.txtUnitPriceSell.Value = null;
                this.IsSellActive = true;
            }
            else
            {
                this.FocusID = this.cmbCRCYCost.ID;
                this.txtUnitPriceCost.Value = null;
                this.IsSellActive = false;
            }

            this.CalProfit();
        }

        #endregion

        #region Method
        /// <summary>
        /// Init MaxLength
        /// </summary>
        private void InitMaxLength()
        {
            //Init maxlength control
            this.txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
            this.txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
            this.txtVendorCD1.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorProductCode1.MaxLength = M_VendorProduct.PRODUCT_VENDOR_PRODUCT_CODE_MAX_LENGTH;
            this.txtVendorCD2.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorProductCode2.MaxLength = M_VendorProduct.PRODUCT_VENDOR_PRODUCT_CODE_MAX_LENGTH;
            this.txtVendorCD3.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorProductCode3.MaxLength = M_VendorProduct.PRODUCT_VENDOR_PRODUCT_CODE_MAX_LENGTH;

            this.txtDescriptionSell.MaxLength = M_Product.DESCRIPTION_MAX_LENGTH;
            this.txtDescriptionCost.MaxLength = M_Product.DESCRIPTION_MAX_LENGTH;
            this.txtRemarkSell.MaxLength = M_Product.REMARK_MAX_LENGTH;
            this.txtRemarkCost.MaxLength = M_Product.REMARK_MAX_LENGTH;
        }

        /// <summary>
        /// Set confirm data
        /// </summary>
        private void SetConfirmData()
        {
            //Get vendor name
            this.txtVendorName1.Value = string.Empty;
            this.txtVendorName2.Value = string.Empty;
            this.txtVendorName3.Value = string.Empty;

            if (!string.IsNullOrEmpty(this.txtVendorCD1.Value))
            {
                M_Vendor vendor = this.GetVendor(this.txtVendorCD1.Value);
                if (vendor != null)
                {
                    this.txtVendorName1.Value = vendor.VendorName1;
                }
            }
            if (!string.IsNullOrEmpty(this.txtVendorCD2.Value))
            {
                M_Vendor vendor = this.GetVendor(this.txtVendorCD2.Value);
                if (vendor != null)
                {
                    this.txtVendorName2.Value = vendor.VendorName1;
                }
            }
            if (!string.IsNullOrEmpty(this.txtVendorCD3.Value))
            {
                M_Vendor vendor = this.GetVendor(this.txtVendorCD3.Value);
                if (vendor != null)
                {
                    this.txtVendorName3.Value = vendor.VendorName1;
                }
            }
            if (!string.IsNullOrEmpty(this.hdnVatRatioSell.Value))
            {
                this.txtVatRatioSell.Value = decimal.Parse(this.hdnVatRatioSell.Value);
            }
            if (!string.IsNullOrEmpty(this.hdnVatRatioCost.Value))
            {
                this.txtVatRatioCost.Value = decimal.Parse(this.hdnVatRatioCost.Value);
            }

            //Calculator profit
            this.CalProfit();
        }

        /// <summary>
        /// Calculator profit
        /// </summary>
        private void CalProfit()
        {
            using (var db = new DB())
            {
                var crcyService = new Currency_HService(db);
                var configSer = new Config_HService(db);
                var crcyList = crcyService.GetAllByDate(db.NowDate).ToDictionary(s => s.ID, s => s);

                decimal exchangeRateS = crcyList[int.Parse(this.cmbCRCYSell.SelectedValue)].ExchangeRate;
                decimal exchangeRateC = crcyList[int.Parse(this.cmbCRCYCost.SelectedValue)].ExchangeRate;

                decimal unitPriceS = this.txtUnitPriceSell.Value == null ? 0 : (decimal)this.txtUnitPriceSell.Value;
                decimal unitPriceC = this.txtUnitPriceCost.Value == null ? 0 : (decimal)this.txtUnitPriceCost.Value;

                unitPriceS = CommonUtil.ConvertToVND(exchangeRateS, unitPriceS);
                unitPriceC = CommonUtil.ConvertToVND(exchangeRateC, unitPriceC);

                decimal profit = 0;
                FractionType defaultFractionType = FractionType.Round4Down5Up;// (FractionType)int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                if (unitPriceS > 0)
                {
                    profit = Fraction.Round(defaultFractionType, (decimal)((unitPriceS - unitPriceC) / unitPriceS) * 100, 2);

                    if (profit < 0)
                    {
                        profit = 0;
                    }

                    if (profit > 100.00m)
                    {
                        profit = 100.00m;
                    }
                }

                this.txtProfitSell.Value = profit;
                this.txtProfitCost.Value = profit;
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtProductCD.ReadOnly = true;
                        this.chkStatusFlag.Disabled = false;
                    }
                    else
                    {
                        this.txtProductCD.ReadOnly = false;
                        if (mode == Utilities.Mode.Insert)
                        {
                            this.rdoTypeBoth.Checked = true;
                        }
                        this.chkStatusFlag.Disabled = true;
                        this.chkStatusFlag.Checked = true;
                    }

                    enable = false;

                    break;

                default:

                    this.txtProductCD.ReadOnly = true;
                    this.chkStatusFlag.Disabled = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//

                    enable = true;
                    break;
            }

            //Lock control
            this.txtProductName.ReadOnly = enable;
            this.cmbCategory1.Enabled = !enable;
            this.cmbCategory2.Enabled = !enable;
            this.cmbCategory3.Enabled = !enable;

            this.rdoTypeBoth.Enabled = !enable;
            this.rdoTypeSell.Enabled = !enable;
            this.rdoTypeCost.Enabled = !enable;

            this.btnCopySell.Enabled = !enable;
            this.btnCopyCost.Enabled = !enable;

            //Sell
            this.txtDescriptionSell.ReadOnly = enable;
            this.cmbCRCYSell.Enabled = !enable;
            this.txtUnitPriceSell.ReadOnly = enable;
            this.cmbUnitSell.Enabled = !enable;
            this.cmbVatTypeSell.Enabled = !enable;

            //if (!this.cmbVatTypeSell.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeSell.SelectedItem.Value) != (int)VATFlg.Exclude)
            {
                this.txtVatRatioSell.ReadOnly = true;
            }
            else
            {
                this.txtVatRatioSell.ReadOnly = enable;
            }
            this.txtRemarkSell.ReadOnly = enable;

            //Cost
            this.txtDescriptionCost.ReadOnly = enable;
            this.cmbCRCYCost.Enabled = !enable;
            this.txtUnitPriceCost.ReadOnly = enable;
            this.cmbUnitCost.Enabled = !enable;
            this.cmbVatTypeCost.Enabled = !enable;

            //if (!this.cmbVatTypeCost.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeCost.SelectedItem.Value) != (int)VATFlg.Exclude)
            {
                this.txtVatRatioCost.ReadOnly = true;
            }
            else
            {
                this.txtVatRatioCost.ReadOnly = enable;
            }
            this.txtRemarkCost.ReadOnly = enable;
            this.chkPurchase.Disabled = enable;
            this.btnSearchVendor1.Disabled = enable;
            this.txtVendorCD1.ReadOnly = enable;
            this.txtVendorName1.ReadOnly = true;
            this.txtVendorProductCode1.ReadOnly = enable;
            this.btnSearchVendor2.Disabled = enable;
            this.txtVendorCD2.ReadOnly = enable;
            this.txtVendorName2.ReadOnly = true;
            this.txtVendorProductCode2.ReadOnly = enable;
            this.btnSearchVendor3.Disabled = enable;
            this.txtVendorCD3.ReadOnly = enable;
            this.txtVendorName3.ReadOnly = true;
            this.txtVendorProductCode3.ReadOnly = enable;
            this.txtProfitSell.ReadOnly = true;
            this.txtProfitCost.ReadOnly = true;

            this.SetTabActive();
        }

        /// <summary>
        /// Set Tab active
        /// </summary>
        private void SetTabActive()
        {
            if (this.GetProductType() == ProductType.Cost)
            {
                this.IsSellActive = false;
            }
            else
            {
                this.IsSellActive = true;
            }
        }

        /// <summary>
        /// Init data
        /// </summary>
        private void InitData()
        {
            //Load data for drop down list
            this.SetComboByLevel(this.cmbCategory1, 1);
            //2015/01/26
            //Author: dh-phuong
            //---------------------start
            //this.SetComboByLevel(this.cmbCategory2, 2);
            //this.SetComboByLevel(this.cmbCategory3, 3);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            //---------------------end

            this.GetCmbCRCYData(this.cmbCRCYSell);
            this.GetCmbUnitData(this.cmbUnitSell);
            this.GetCmbTaxData(this.cmbVatTypeSell);

            this.GetCmbCRCYData(this.cmbCRCYCost);
            this.GetCmbUnitData(this.cmbUnitCost);
            this.GetCmbTaxData(this.cmbVatTypeCost);

            this.rdoTypeBoth.Checked = true;

            this.cmbVatTypeSell.SelectedValue = this._defaultVatType;
            if (Convert.ToInt32(this.cmbVatTypeSell.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                this.txtVatRatioSell.Value = this.DefaultVAT;
            }

            this.cmbVatTypeCost.SelectedValue = this._defaultVatType;
            if (Convert.ToInt32(this.cmbVatTypeCost.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                this.txtVatRatioCost.Value = this.DefaultVAT;
            }
            this.hdnDefaultVat.Value = this.DefaultVAT.ToString();
        }

        /// <summary>
        /// Get Unit DropDownList Data
        /// </summary>
        /// <param name="ctrl"></param>
        private void GetCmbUnitData(DropDownList ctrl)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                UnitService dbSerUnit = new UnitService(db);
                lst = dbSerUnit.GetDataForDropDownList();
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get Currency DropDownList Data
        /// </summary>
        /// <param name="ctrl">Control</param>
        private void GetCmbCRCYData(DropDownList ctrl)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                Currency_HService dbSer = new Currency_HService(db);
                lst = dbSer.GetDataForDropDownList();
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboByLevel(DropDownList ctrl, int level)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst = dbSer.GetDataByLevelForDropDownList(level, true);
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetBlankCombo(DropDownList ctrl)
        {
            IList<DropDownModel> lst = new List<DropDownModel>(new[]{
                new DropDownModel("-1", "---")
            });
            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        ///// <summary>
        ///// Get category data for DropDownList
        ///// </summary>
        ///// <param name="ctrl"></param>
        ///// <param name="parentId"></param>
        //private int GetCategoryStructID(int categoryId, int level)
        //{
        //    int ret = -1;
        //    IList<M_CategoryStruct> lst;
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        lst = dbSer.GetByCategoryIDAndLevel(categoryId, level);
        //    }
        //    if (lst.Count != 0)
        //    {
        //        ret = lst[0].CategoryStructID;
        //    }
        //    return ret;
        //}

        ///// <summary>
        ///// Get category data for DropDownList
        ///// </summary>
        ///// <param name="ctrl"></param>
        ///// <param name="parentId"></param>
        //private M_CategoryStruct GetCategoryStructID(int categoryStructID)
        //{
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        return dbSer.GetByID(categoryStructID);
        //    }
        //}

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1(DropDownList ctrl, int categoryId1, int childLevel, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1(categoryId1, childLevel));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1AndCategory2(DropDownList ctrl, int categoryId1, int categoryId2, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1AndCategory2(categoryId1, categoryId2));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Set Value
        /// </summary>
        /// <param name="ctr"></param>
        /// <param name="value"></param>
        private void SetValueCombo(DropDownList ctr, string value)
        {
            bool hasValue = false;
            List<DropDownModel> listValue = (List<DropDownModel>)ctr.DataSource;
            if (listValue != null)
            {
                foreach (var item in listValue)
                {
                    if (item.Value.Equals(value))
                    {
                        hasValue = true;
                        break;
                    }
                }
                if (hasValue)
                {
                    ctr.SelectedValue = value;
                }
                else
                {
                    ctr.SelectedValue = "-1";
                }
            }            
        }

        //private IList<M_CategoryStruct> GetListCategoryParentID(int categoryID, int childLevel)
        //{
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        return dbSer.GetListCategoryParentID(categoryID, childLevel);
        //    }
        //}

        /// <summary>
        /// Get VAT Type data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void GetCmbTaxData(DropDownList ctrl)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                Config_HService dbSer = new Config_HService(db);
                lst = dbSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="product">Product</param>
        private void ShowData(M_Product product)
        {
            //Show data
            if (product != null)
            {
                this.ProductID = product.ID;

                //Get data
                int categoryId1;
                int categoryId2;
                int categoryId3;

                this.SetComboByLevel(this.cmbCategory1, 1);
                using (DB db = new DB())
                {
                    CategoryService cateSer = new CategoryService(db);
                    categoryId1 = cateSer.GetCategoryParentID(product.CategoryStructID, 1);
                    categoryId2 = cateSer.GetCategoryParentID(product.CategoryStructID, 2);
                    categoryId3 = cateSer.GetCategoryParentID(product.CategoryStructID, 3);
                }

                if (categoryId2 == -1)
                {
                    this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, categoryId2.ToString());
                    //2015/01/26
                    //Author: dh-phuong
                    //---------------------start
                    //this.SetComboFromCategory1(this.cmbCategory3, categoryId1, 3, categoryId3.ToString());
                    this.SetBlankCombo(this.cmbCategory3);
                    //---------------------end
                }
                else
                {
                    this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, categoryId2.ToString());
                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, categoryId3.ToString());
                }

                this.SetValueCombo(this.cmbCategory1, categoryId1.ToString());
                

                this.txtProductCD.Value = product.ProductCD;
                this.txtProductName.Value = product.ProductName;
                if (product.Type == (int)ProductType.Both)
                {
                    this.rdoTypeBoth.Checked = true;
                    this.rdoTypeSell.Checked = false;
                    this.rdoTypeCost.Checked = false;
                }
                else if (product.Type == (int)ProductType.Sell)
                {
                    this.rdoTypeBoth.Checked = false;
                    this.rdoTypeSell.Checked = true;
                    this.rdoTypeCost.Checked = false;
                }
                else
                {
                    this.rdoTypeBoth.Checked = false;
                    this.rdoTypeSell.Checked = false;
                    this.rdoTypeCost.Checked = true;
                }

                //Sell information
                this.txtDescriptionSell.Value = product.DescriptionSell;
                this.cmbCRCYSell.SelectedValue = product.CurrencyIDSell.ToString();
                this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYSell, null);
                this.txtUnitPriceSell.Value = product.UnitPriceSell;
                this.cmbUnitSell.SelectedValue = product.UnitIDSell.ToString();
                this.cmbVatTypeSell.SelectedValue = product.VatTypeSell.ToString();
                this.txtVatRatioSell.Value = product.VatRatioSell;
                this.txtRemarkSell.Value = product.RemarkSell;

                //Cost information
                this.txtDescriptionCost.Value = product.DescriptionCost;
                this.cmbCRCYCost.SelectedValue = product.CurrencyIDCost.ToString();
                this.cmbCRCY_SelectedIndexChanged(this.cmbCRCYCost, null);
                this.txtUnitPriceCost.Value = product.UnitPriceCost;
                this.cmbUnitCost.SelectedValue = product.UnitIDCost.ToString();
                this.cmbVatTypeCost.SelectedValue = product.VatTypeCost.ToString();
                this.txtVatRatioCost.Value = product.VatRatioCost;
                this.txtRemarkCost.Value = product.RemarkCost;

                this.chkPurchase.Checked = product.PurchaseFlag == 1 ? true : false;

                //Show vendor data
                this.ShowVendorProduct(product.ID);

                this.chkStatusFlag.Checked = product.StatusFlag == 0 ? true : false;
                //if (!cmbVatTypeSell.SelectedValue.Equals("0"))
                if (Convert.ToInt32(cmbVatTypeSell.SelectedItem.Value) != (int)VATFlg.Exclude)
                {
                    this.txtVatRatioSell.Value = null;
                    this.txtVatRatioSell.ReadOnly = true;
                }
                //if (!cmbVatTypeCost.SelectedValue.Equals("0"))
                if (Convert.ToInt32(cmbVatTypeCost.SelectedItem.Value) != (int)VATFlg.Exclude)
                {
                    this.txtVatRatioCost.Value = null;
                    this.txtVatRatioCost.ReadOnly = true;
                }

                //Save UserID and UpdateDate
                this.ProductID = product.ID;
                this.OldUpdateDate = product.UpdateDate;

                //Calculator profit
                this.CalProfit();
            }
        }

        /// <summary>
        /// Show vendor data
        /// </summary>
        /// <param name="userID">ProductID</param>
        private void ShowVendorProduct(int prodyctID)
        {
            using (DB db = new DB())
            {
                VendorProductService dbSer = new VendorProductService(db);
                VendorService venSer = new VendorService(db);

                //Get verdor product
                List<M_VendorProduct> lstVendorProduct = dbSer.GetListByProductID(prodyctID).ToList();

                //Show vendor 1
                if (lstVendorProduct.Count >= 1)
                {
                    M_Vendor vendor = venSer.GetByID(lstVendorProduct[0].VendorID);
                    this.txtVendorCD1.Value = vendor.VendorCD;
                    this.txtVendorName1.Value = vendor.VendorName1;
                    this.txtVendorProductCode1.Value = lstVendorProduct[0].VendorProductCD;
                }
                else
                {
                    this.txtVendorCD1.Value = string.Empty;
                    this.txtVendorName1.Value = string.Empty;
                    this.txtVendorProductCode1.Value = string.Empty;
                }

                //Show vendor 2
                if (lstVendorProduct.Count >= 2)
                {
                    M_Vendor vendor = venSer.GetByID(lstVendorProduct[1].VendorID);
                    this.txtVendorCD2.Value = vendor.VendorCD;
                    this.txtVendorName2.Value = vendor.VendorName1;
                    this.txtVendorProductCode2.Value = lstVendorProduct[1].VendorProductCD;
                }
                else
                {
                    this.txtVendorCD2.Value = string.Empty;
                    this.txtVendorName2.Value = string.Empty;
                    this.txtVendorProductCode2.Value = string.Empty;
                }

                //Show vendor 3
                if (lstVendorProduct.Count >= 3)
                {
                    M_Vendor vendor = venSer.GetByID(lstVendorProduct[2].VendorID);
                    this.txtVendorCD3.Value = vendor.VendorCD;
                    this.txtVendorName3.Value = vendor.VendorName1;
                    this.txtVendorProductCode3.Value = lstVendorProduct[2].VendorProductCD;
                }
                else
                {
                    this.txtVendorCD3.Value = string.Empty;
                    this.txtVendorName3.Value = string.Empty;
                    this.txtVendorProductCode3.Value = string.Empty;
                }
            }
        }

        /// <summary>
        /// Get product by product ID
        /// </summary>
        /// <param name="userID">ProductID</param>
        /// <returns>Product</returns>
        private M_Product GetProduct(int prodyctID)
        {
            using (DB db = new DB())
            {
                ProductService proSer = new ProductService(db);

                //Get product
                return proSer.GetByID(prodyctID);
            }
        }

        /// <summary>
        /// Get Product By Code
        /// </summary>
        /// <param name="productCD">productCD</param>
        /// <returns>M_Product</returns>
        private M_Product GetProduct(string productCD)
        {
            using (DB db = new DB())
            {
                ProductService productSer = new ProductService(db);

                //Get Product
                return productSer.GetByCD(productCD);
            }
        }

        /// <summary>
        /// Get Vendor By Code
        /// </summary>
        /// <param name="vendorCD">vendorCD</param>
        /// <returns>M_Vendor</returns>
        private M_Vendor GetVendor(string vendorCD)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.GetByCD(vendorCD);
            }
        }


        /// <summary>
        /// Get data from Green
        /// </summary>
        /// <param name="db"></param>
        /// <returns></returns>
        private void GetData(M_Product product, List<M_VendorProduct> lstVendorProduct)
        {
            if (!(!this.IsShowSearchType && Mode == Utilities.Mode.Update))
            {
                product.Type = (short)this.GetProductType();
            }

            product.ProductCD = this.txtProductCD.Value;
            product.ProductName = this.txtProductName.Value;

            M_CategoryStruct categoryStruct;
            product.CategoryStructID = 1;
            using (DB db = new DB())
            {
                CategoryStructService ser = new CategoryStructService(db);

                //Get
                categoryStruct= ser.GetByCategoryIDAndCategoryStructID(int.Parse(this.cmbCategory1.SelectedValue), 1);
                if (categoryStruct != null)
                {
                    product.CategoryStructID = categoryStruct.ID;
                    if (this.cmbCategory2.SelectedIndex != 0)
                    {
                        categoryStruct = ser.GetByCategoryIDAndCategoryStructID(int.Parse(this.cmbCategory2.SelectedValue), product.CategoryStructID);
                        if (categoryStruct != null)
                        {
                            product.CategoryStructID = categoryStruct.ID;
                            if (this.cmbCategory3.SelectedIndex != 0)
                            {
                                categoryStruct = ser.GetByCategoryIDAndCategoryStructID(int.Parse(this.cmbCategory3.SelectedValue), product.CategoryStructID);
                                if (categoryStruct != null)
                                {
                                    product.CategoryStructID = categoryStruct.ID;
                                }
                                else
                                {
                                    product.CategoryStructID = 1;
                                }
                            }
                        }
                        else
                        {
                            product.CategoryStructID = 1;
                        }
                    }                    
                }                
            }            

            product.DescriptionSell = this.txtDescriptionSell.Value;
            product.CurrencyIDSell = int.Parse(this.cmbCRCYSell.SelectedValue);
            if (this.txtUnitPriceSell.Value != null)
            {
                product.UnitPriceSell = (decimal)this.txtUnitPriceSell.Value;
            }
            else
            {
                product.UnitPriceSell = 0;
            }
            product.UnitIDSell = int.Parse(this.cmbUnitSell.SelectedValue);
            product.VatTypeSell = short.Parse(this.cmbVatTypeSell.SelectedValue);
            if (this.txtVatRatioSell.Value != null)
            {
                product.VatRatioSell = (decimal)this.txtVatRatioSell.Value;
            }
            else
            {
                product.VatRatioSell = 0;
            }
            product.RemarkSell = this.txtRemarkSell.Value;

            product.DescriptionCost = this.txtDescriptionCost.Value;
            product.CurrencyIDCost = int.Parse(this.cmbCRCYCost.SelectedValue);
            if (this.txtUnitPriceCost.Value != null)
            {
                product.UnitPriceCost = (decimal)this.txtUnitPriceCost.Value;
            }
            else
            {
                product.UnitPriceCost = 0;
            }
            product.UnitIDCost = int.Parse(this.cmbUnitCost.SelectedValue);
            product.VatTypeCost = short.Parse(this.cmbVatTypeCost.SelectedValue);
            if (this.txtVatRatioCost.Value != null)
            {
                product.VatRatioCost = (decimal)this.txtVatRatioCost.Value;
            }
            else
            {
                product.VatRatioCost = 0;
            }
            product.RemarkCost = this.txtRemarkCost.Value;

            product.PurchaseFlag = 0;
            product.PurchaseFlag = Convert.ToInt16(this.chkPurchase.Checked == true ? 1 : 0);

            int no = 1;
            //VendorService vendorSer = new VendorService(db);
            if (!string.IsNullOrEmpty(this.txtVendorCD1.Value))
            {
                //Get vendor
                M_Vendor vendor = this.GetVendor(this.txtVendorCD1.Value);
                if (vendor != null)
                {
                    M_VendorProduct vendorPro = new M_VendorProduct();
                    vendorPro.No = no;
                    vendorPro.VendorID = vendor.ID;
                    vendorPro.VendorProductCD = this.txtVendorProductCode1.Value;
                    lstVendorProduct.Add(vendorPro);
                    no += 1;
                }
            }

            if (!string.IsNullOrEmpty(this.txtVendorCD2.Value))
            {
                //Get vendor
                M_Vendor vendor = this.GetVendor(this.txtVendorCD2.Value);
                if (vendor != null)
                {
                    M_VendorProduct vendorPro = new M_VendorProduct();
                    vendorPro.No = no;
                    vendorPro.VendorID = vendor.ID;
                    vendorPro.VendorProductCD = this.txtVendorProductCode2.Value;
                    lstVendorProduct.Add(vendorPro);
                    no += 1;
                }
            }

            if (!string.IsNullOrEmpty(this.txtVendorCD3.Value))
            {
                //Get vendor
                M_Vendor vendor = this.GetVendor(this.txtVendorCD3.Value);
                if (vendor != null)
                {
                    M_VendorProduct vendorPro = new M_VendorProduct();
                    vendorPro.No = no;
                    vendorPro.VendorID = vendor.ID;
                    vendorPro.VendorProductCD = this.txtVendorProductCode3.Value;
                    lstVendorProduct.Add(vendorPro);
                }
            }

            product.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

            product.UpdateDate = this.OldUpdateDate;
            product.CreateUID = this.LoginInfo.User.ID;
            product.UpdateUID = this.LoginInfo.User.ID;
        }

        /// <summary>
        /// Get product type
        /// </summary>
        /// <returns>Type</returns>
        private ProductType GetProductType()
        {
            if (!this.IsShowSearchType)
            {
                return ProductType.Both;
            }
            if (this.rdoTypeBoth.Checked)
            {
                return ProductType.Both;
            }
            else if (this.rdoTypeSell.Checked)
            {
                return ProductType.Sell;
            }
            else
            {
                return ProductType.Cost;
            }
        }

        #region Process Data

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Product product = new M_Product();
                List<M_VendorProduct> lstVendorProduct = new List<M_VendorProduct>();

                this.GetData(product, lstVendorProduct);

                //Category
                if (product.CategoryStructID == 1)
                {
                    this.SetComboByLevel(this.cmbCategory1, 1);
                    //2015/01/26
                    //Author: dh-phuong
                    //---------------------start
                    //this.SetComboByLevel(this.cmbCategory2, 2);
                    //this.SetComboByLevel(this.cmbCategory3, 3);
                    this.SetBlankCombo(this.cmbCategory2);
                    this.SetBlankCombo(this.cmbCategory3);
                    //---------------------end
                    this.SetMessage(this.cmbCategory1.ID, M_Message.MSG_REQUIRE, "Category");
                    return false;
                }

                //Insert Product
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ProductService productSer = new ProductService(db);
                    VendorProductService vendorProSer = new VendorProductService(db);

                    //Insert product
                    int productID = productSer.Insert(product);

                    if (productID != 0)
                    {
                        //Insert Vendor Product
                        foreach (var item in lstVendorProduct)
                        {
                            item.ProductID = productID;
                            vendorProSer.Insert(item);
                        }
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                //SQL Exception
                if (ex.Message.Contains(Models.Constant.M_PRODUCT_UN))
                {
                    this.SetMessage(this.txtProductCD.ID, M_Message.MSG_EXIST_CODE, "Product Code");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CATEGORY_STRUCT_ID))
                {
                    this.SetMessage(this.cmbCategory1.ID, M_Message.MSG_NOT_EXIST_CODE, "Category");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_SELL))
                {
                    this.SetMessage(this.cmbCRCYSell.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency Sell");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_COST))
                {
                    this.SetMessage(this.cmbCRCYCost.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency Cost");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_SELL))
                {
                    this.SetMessage(this.cmbUnitSell.ID, M_Message.MSG_NOT_EXIST_CODE, "Unit Sell");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_COST))
                {
                    this.SetMessage(this.cmbUnitCost.ID, M_Message.MSG_NOT_EXIST_CODE, "Unit Cost");
                }

                if (ex.Message.Contains(Models.Constant.M_VENDORPRODUCT_FK_VENDOR))
                {
                    this.SetMessage("", M_Message.MSG_NOT_EXIST_CODE, "Vendor Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Product product = this.GetProduct(this.ProductID);
                List<M_VendorProduct> lstVendorProduct = new List<M_VendorProduct>();
                if (product != null)
                {
                    //Get update data
                    this.GetData(product, lstVendorProduct);

                    //Category
                    if (product.CategoryStructID == 1)
                    {
                        this.SetComboByLevel(this.cmbCategory1, 1);
                        //2015/01/26
                        //Author: dh-phuong
                        //---------------------start
                        //this.SetComboByLevel(this.cmbCategory2, 2);
                        //this.SetComboByLevel(this.cmbCategory3, 3);
                        this.SetBlankCombo(this.cmbCategory2);
                        this.SetBlankCombo(this.cmbCategory3);
                        //---------------------end
                        this.SetMessage(this.cmbCategory1.ID, M_Message.MSG_REQUIRE, "Category");
                        return false;
                    }

                    //Update Product                   
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ProductService productSer = new ProductService(db);
                        VendorProductService vendorProSer = new VendorProductService(db);

                        //Update Product
                        if (product.Status == DataStatus.Changed || this.IsChangedVendorProduct(db, lstVendorProduct))
                        {

                            ret = productSer.Update(product);

                            if (ret != 0)
                            {
                                //Delete old vendor product data
                                vendorProSer.DeleteByProductID(this.ProductID);

                                //Insert new vendor product data
                                foreach (var item in lstVendorProduct)
                                {
                                    item.ProductID = this.ProductID;
                                    vendorProSer.Insert(item);
                                }
                            }

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                //SQL Expception
                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CATEGORY_STRUCT_ID))
                {
                    this.SetMessage(this.cmbCategory1.ID, M_Message.MSG_NOT_EXIST_CODE, "Category");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_SELL))
                {
                    this.SetMessage(this.cmbCRCYSell.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency Sell");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_COST))
                {
                    this.SetMessage(this.cmbCRCYCost.ID, M_Message.MSG_NOT_EXIST_CODE, "Currency Cost");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_SELL))
                {
                    this.SetMessage(this.cmbUnitSell.ID, M_Message.MSG_NOT_EXIST_CODE, "Unit Sell");
                }

                if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_COST))
                {
                    this.SetMessage(this.cmbUnitCost.ID, M_Message.MSG_NOT_EXIST_CODE, "Unit Cost");
                }

                if (ex.Message.Contains(Models.Constant.M_VENDORPRODUCT_FK_VENDOR))
                {
                    this.SetMessage("", M_Message.MSG_NOT_EXIST_CODE, "Vendor Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns></returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ProductService productSer = new ProductService(db);
                    VendorProductService vendorProSer = new VendorProductService(db);

                    //Delete Product
                    ret = productSer.Delete(this.ProductID, this.OldUpdateDate);

                    if (ret != 0)
                    {
                        //Delete vendor product
                        vendorProSer.DeleteByProductID(this.ProductID);
                    }

                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (
                    ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_PRODUCT) ||
                    ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_PRODUCT) ||

                    ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_PRODUCT) ||
                    ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_PRODUCT) ||

                    ex.Message.Contains(Models.Constant.T_PURCHASE_D_FK_PRODUCT) ||

                    ex.Message.Contains(Models.Constant.T_DELIVERY_D_FK_PRODUCT) ||
                    ex.Message.Contains(Models.Constant.T_BILLING_D_FK_PRODUCT)
                    )
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Product Code " + this.txtProductCD.Value);
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        #endregion

        #region Check input

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {

            //ProductCD
            if (this.txtProductCD.IsEmpty)
            {
                this.SetMessage(this.txtProductCD.ID, M_Message.MSG_REQUIRE, "Product Code");
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    // Description: Edit
                    // Author: ISV-PHUONG
                    // Date  : 2014/12/08
                    // ---------------------- Start ------------------------------
                    if (this.txtProductCD.Value == M_Product.PRODUCT_CODE_SUPPORT)
                    {
                        this.SetMessage(this.txtProductCD.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Product Code", M_Product.PRODUCT_CODE_SUPPORT);
                    }
                    else
                    {
                        // Check Product by productCD
                        if (this.GetProduct(this.txtProductCD.Value) != null)
                        {
                            this.SetMessage(this.txtProductCD.ID, M_Message.MSG_EXIST_CODE, "Product Code");
                        }
                    }
                    // ---------------------- End  -------------------------------
                }
            }

            //Product Name
            if (this.txtProductName.IsEmpty)
            {
                this.SetMessage(this.txtProductName.ID, M_Message.MSG_REQUIRE, "Product Name");
            }

            //Category
            if (this.cmbCategory1.SelectedIndex == 0)
            {
                this.SetMessage(this.cmbCategory1.ID, M_Message.MSG_REQUIRE, "Category");
            }

            ProductType proType = this.GetProductType();
            bool hasSellErr = false;
            bool hasCostErr = false;

            //Sell information check
            if (proType == ProductType.Both || proType == ProductType.Sell)
            {
                this.IsSellActive = true;
            }
            else
            {
                this.IsSellActive = false;
            }

            ////Description
            //if (string.IsNullOrEmpty(this.txtDescriptionSell.Value.Trim()))
            //{
            //    hasSellErr = true;
            //    this.SetMessage(this.txtDescriptionSell.ID, M_Message.MSG_REQUIRE, "Description Sell");
            //}

            //UnitPrice
            decimal unitPriceSell = 0;
            if (this.txtUnitPriceSell.Value != null)
            {
                if (!Utilities.CheckDataUtil.IsDecimal(this.txtUnitPriceSell.Value, ref unitPriceSell))
                {
                    hasSellErr = true;
                    this.SetMessage(this.txtUnitPriceSell.ID, M_Message.MSG_INCORRECT_FORMAT, "Unit Price Sell");
                }
                else
                {
                    using (DB db = new DB())
                    {
                        Currency_HService currencyService = new Currency_HService(db);
                        M_Currency_H currencyModel = currencyService.GetByID(int.Parse(this.cmbCRCYSell.SelectedValue));
                        if (currencyModel != null)
                        {
                            if (currencyModel.DecimalType == 1)
                            {
                                if (unitPriceSell > M_Product.MAX_UNIT_PRICE_USD)
                                {
                                    hasSellErr = true;
                                    this.SetMessage(this.txtUnitPriceSell.ID, M_Message.MSG_LESS_THAN_EQUAL, "Unit Price Sell", M_Product.MAX_UNIT_PRICE_USD.ToString("#,###.##"));
                                }
                            }
                            else
                            {
                                if (unitPriceSell > M_Product.MAX_UNIT_PRICE_VND)
                                {
                                    hasSellErr = true;
                                    this.SetMessage(this.txtUnitPriceSell.ID, M_Message.MSG_LESS_THAN_EQUAL, "Unit Price Sell", M_Product.MAX_UNIT_PRICE_USD.ToString("#,###"));
                                }
                            }
                        }
                    }
                }
            }

            //Tax Ratio
            decimal taxRatio = 0;
            if (this.txtVatRatioSell.Value != null)
            {
                if (!Utilities.CheckDataUtil.IsDecimal(this.txtVatRatioSell.Value, ref taxRatio))
                {
                    hasSellErr = true;
                    this.SetMessage(this.txtVatRatioSell.ID, M_Message.MSG_INCORRECT_FORMAT, "Tax Ratio Sell");
                }
                else if (taxRatio > 99)
                {
                    hasSellErr = true;
                    this.SetMessage(this.txtVatRatioSell.ID, M_Message.MSG_LESS_THAN_EQUAL, "Tax Ratio Sell", 99);
                }
            }


            //Cost information cost

            //Description
            //if (string.IsNullOrEmpty(this.txtDescriptionCost.Value.Trim()))
            //{
            //    hasCostErr = true;
            //    this.SetMessage(this.txtDescriptionCost.ID, M_Message.MSG_REQUIRE, "Description Cost");
            //}

            //UnitPrice
            decimal unitPriceCost = 0;
            if (this.txtUnitPriceCost.Value != null)
            {
                if (!Utilities.CheckDataUtil.IsDecimal(this.txtUnitPriceCost.Value, ref unitPriceCost))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtUnitPriceCost.ID, M_Message.MSG_INCORRECT_FORMAT, "Unit Price Cost");
                }
                else
                {
                    using (DB db = new DB())
                    {
                        Currency_HService currencyService = new Currency_HService(db);
                        M_Currency_H currencyModel = currencyService.GetByID(int.Parse(this.cmbCRCYCost.SelectedValue));
                        if (currencyModel != null)
                        {
                            if (currencyModel.DecimalType == 1)
                            {
                                if (unitPriceCost > M_Product.MAX_UNIT_PRICE_USD)
                                {
                                    hasCostErr = true;
                                    this.SetMessage(this.txtUnitPriceCost.ID, M_Message.MSG_LESS_THAN_EQUAL, "Unit Price Cost", M_Product.MAX_UNIT_PRICE_USD.ToString("#,###.##"));
                                }
                            }
                            else
                            {
                                if (unitPriceCost > M_Product.MAX_UNIT_PRICE_VND)
                                {
                                    hasCostErr = true;
                                    this.SetMessage(this.txtUnitPriceCost.ID, M_Message.MSG_LESS_THAN_EQUAL, "Unit Price Cost", M_Product.MAX_UNIT_PRICE_USD.ToString("#,###"));
                                }
                            }
                        }
                    }
                }
            }

            //Tax Ratio
            decimal taxRatioCost = 0;
            if (this.txtVatRatioCost.Value != null)
            {
                if (!Utilities.CheckDataUtil.IsDecimal(this.txtVatRatioCost.Value, ref taxRatioCost))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVatRatioCost.ID, M_Message.MSG_INCORRECT_FORMAT, "Tax Ratio Cost");
                }
                else if (taxRatioCost > 99)
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVatRatioCost.ID, M_Message.MSG_LESS_THAN_EQUAL, "Unit Price Cost", 99);
                }
            }

            List<string> lstVendorCd = new List<string>();

            //Vendor 1
            if (string.IsNullOrEmpty(this.txtVendorCD1.Value))
            {
                if (!string.IsNullOrEmpty(this.txtVendorProductCode1.Value))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD1.ID, M_Message.MSG_REQUIRE, "Vendor Code 1");
                }
            }
            else
            {
                //check vendor by vendor code
                if (this.GetVendor(this.txtVendorCD1.Value) == null)
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD1.ID, M_Message.MSG_NOT_EXIST_CODE, "Vendor Code 1");
                }
                else
                {
                    lstVendorCd.Add(this.txtVendorCD1.Value);
                }
            }


            //Vendor 2
            if (string.IsNullOrEmpty(this.txtVendorCD2.Value))
            {
                if (!string.IsNullOrEmpty(this.txtVendorProductCode2.Value))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD2.ID, M_Message.MSG_REQUIRE, "Vendor Code 2");
                }
            }
            else
            {
                //check vendor by vendor code
                if (this.GetVendor(this.txtVendorCD2.Value) == null)
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD2.ID, M_Message.MSG_NOT_EXIST_CODE, "Vendor Code 2");
                }
                else if (lstVendorCd.Contains(this.txtVendorCD2.Value))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD2.ID, M_Message.MSG_DUPLICATE, "Vendor Code 2");
                }
                else
                {
                    lstVendorCd.Add(this.txtVendorCD2.Value);
                }
            }

            //Vendor 3
            if (string.IsNullOrEmpty(this.txtVendorCD3.Value))
            {
                if (!string.IsNullOrEmpty(this.txtVendorProductCode3.Value))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD3.ID, M_Message.MSG_REQUIRE, "Vendor Code 3");
                }
            }
            else
            {
                //check vendor by vendor code
                if (this.GetVendor(this.txtVendorCD3.Value) == null)
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD3.ID, M_Message.MSG_NOT_EXIST_CODE, "Vendor Code 3");
                }
                else if (lstVendorCd.Contains(this.txtVendorCD3.Value))
                {
                    hasCostErr = true;
                    this.SetMessage(this.txtVendorCD3.ID, M_Message.MSG_DUPLICATE, "Vendor Code 3");
                }
                else
                {
                    lstVendorCd.Add(this.txtVendorCD3.Value);
                }
            }

            if (hasSellErr)
            {
                this.IsSellActive = true;
            }
            else if (hasCostErr)
            {
                this.IsSellActive = false;
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check: is changed vendor product list
        /// </summary>
        /// <param name="db">Class Db</param>
        /// <param name="lstNew">List new data</param>
        /// <returns>True: is changed, False: is not changed</returns>
        private bool IsChangedVendorProduct(DB db, List<M_VendorProduct> lstNew)
        {
            VendorProductService vendorProSer = new VendorProductService(db);
            List<M_VendorProduct> lstOld = vendorProSer.GetListByProductID(this.ProductID).ToList();

            if (lstNew.Count != lstOld.Count)
            {
                return true;
            }
            else
            {
                for (int i = 0; i < lstNew.Count - 1; i++)
                {
                    //Compare vendor id
                    if (!lstNew[i].VendorID.Equals(lstOld[i].VendorID))
                    {
                        return true;
                    }

                    //Compare vendor product code
                    if (!lstNew[i].VendorProductCD.Equals(lstOld[i].VendorProductCD))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            //Lock control
            this.txtProductCD.Value = string.Empty;
            this.txtProductName.Value = string.Empty;

            this.cmbCategory1.SelectedValue = "-1";
            this.cmbCategory2.SelectedValue = "-1";
            this.cmbCategory3.SelectedValue = "-1";

            this.rdoTypeBoth.Checked = true;
            this.rdoTypeSell.Checked = false;
            this.rdoTypeCost.Checked = false;

            this.btnCopySell.Enabled = true;
            this.btnCopyCost.Enabled = true;

            //Sell
            this.txtDescriptionSell.Value = string.Empty;
            this.cmbCRCYSell.SelectedIndex = 0;

            this.txtUnitPriceSell.Value = null;

            this.cmbUnitSell.SelectedIndex = 0;

            this.cmbVatTypeSell.SelectedValue = this._defaultVatType;

            //if (!this.cmbVatTypeSell.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeSell.SelectedItem.Value) != (int)VATFlg.Exclude)
            {
                this.txtVatRatioSell.ReadOnly = true;

                this.txtVatRatioSell.Value = null;
            }
            else
            {
                this.txtVatRatioSell.ReadOnly = false;
                this.txtVatRatioSell.Value = this.DefaultVAT;
            }
            this.txtRemarkSell.Value = string.Empty;

            //Cost
            this.txtDescriptionCost.Value = string.Empty;
            this.cmbCRCYCost.SelectedIndex = 0;

            this.txtUnitPriceCost.Value = null;

            this.cmbUnitCost.SelectedIndex = 0;

            this.cmbVatTypeCost.SelectedValue = this._defaultVatType;

            //if (!this.cmbVatTypeCost.SelectedValue.Equals("0"))
            if (Convert.ToInt32(this.cmbVatTypeCost.SelectedItem.Value) != (int)VATFlg.Exclude)
            {
                this.txtVatRatioCost.ReadOnly = true;
                this.txtVatRatioCost.Value = null;
            }
            else
            {
                this.txtVatRatioCost.ReadOnly = false;
                this.txtVatRatioCost.Value = this.DefaultVAT;
            }

            this.txtRemarkCost.Value = string.Empty;
            this.chkPurchase.Disabled = false;
            this.chkPurchase.Checked = false;

            this.btnSearchVendor1.Disabled = false;
            this.txtVendorCD1.Value = string.Empty;
            this.txtVendorName1.Value = string.Empty;
            this.txtVendorProductCode1.Value = string.Empty;

            this.btnSearchVendor2.Disabled = false;
            this.txtVendorCD2.Value = string.Empty;
            this.txtVendorName2.Value = string.Empty;
            this.txtVendorProductCode2.Value = string.Empty;

            this.btnSearchVendor3.Disabled = false;
            this.txtVendorCD3.Value = string.Empty;
            this.txtVendorName3.Value = string.Empty;
            this.txtVendorProductCode3.Value = string.Empty;

            this.txtProfitSell.ReadOnly = false;
            this.txtProfitSell.Value = null;
            this.txtProfitCost.ReadOnly = false;
            this.txtProfitCost.Value = null;

            this.SetTabActive();
        }
        #endregion

        #region WebMethod

        /// <summary>
        /// Get vendor Name
        /// </summary>
        /// <param name="groupCd">Vendor Code</param>
        /// <returns>Vendor Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetVendorName(string in1)
        {
            var vendorCd = in1;
            var vendorCdShow = in1;
            vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
            try
            {
                using (DB db = new DB())
                {
                    VendorService vendor = new VendorService(db);
                    M_Vendor model = vendor.GetByCD(vendorCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            vendorCD = vendorCdShow,
                            vendorName = model.VendorName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var onlyCd = new
                        {
                            vendorCD = vendorCdShow,
                            vendorName = string.Empty
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                    }
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        #endregion

        #endregion
    }
}
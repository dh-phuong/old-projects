﻿using OMS.Models;
using OMS.DAC;
using OMS.Utilities;

using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections;
using System.Linq;

using NPOI.SS.UserModel;
using OMS.UserControls;

using OMS.Reports.EXCEL;

namespace OMS.Master
{
    /// <summary>
    /// Product List
    /// VN-Nho
    /// </summary>
    public partial class FrmProductList : FrmBaseList
    {
        private const string CONST_DANGER_TEXT = "Invalid";
        #region Property
        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set PagingInfo
        /// </summary>
        private Hashtable OldPagingInfo
        {
            get { return (Hashtable)ViewState["OldPagingInfo"]; }
            set { ViewState["OldPagingInfo"] = value; }
        }

        /// <summary>
        /// Is show search type
        /// </summary>
        protected bool IsShowSearchType { get; set; }

        #endregion

        #region Event

        /// <summary>
        /// Init Form
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Product Master";
            base.FormSubTitle = "List";

            //Header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            //Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            //Paging Header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = CONST_DANGER_TEXT;

            //Search Button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
            this.btnClear.ServerClick += new EventHandler(btnClear_Click);

            //Download Excel click event
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Dropdownlist select index change event
            //Init Event
            this.cmbCategory1.SelectedIndexChanged += cmbCategory1_SelectedIndexChanged;
            this.cmbCategory2.SelectedIndexChanged += cmbCategory2_SelectedIndexChanged;
            //this.cmbCategory3.SelectedIndexChanged += cmbCategory3_SelectedIndexChanged;

            //Init Max Length
            this.txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
            this.txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            
        }

        /// <summary>
        /// Page Load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Product);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            bool temp;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                temp = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }
            if (!temp)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            //Get is show search type flag
            this.IsShowSearchType = false;

            if (!this.IsPostBack)
            {
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];
                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
            else
            {
                //Set confirm data
                this.SetConfirmData();
            }
        }

        /// <summary>
        /// Search Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "4";
            this.OldPagingInfo = null;

            //load grid data
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
            
        }

        /// <summary>
        /// Clear
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnClear_Click(object sender, EventArgs e)
        {
            this.cmbType.SelectedValue = "-1";
            
            this.txtProductCD.Value = string.Empty;
            this.txtProductName.Value = string.Empty;

            this.SetComboByLevel(this.cmbCategory1, 1);
            //2015/01/26
            //Author: dh-phuong
            //---------------------start
            //this.SetComboByLevel(this.cmbCategory2, 2);
            //this.SetComboByLevel(this.cmbCategory3, 3);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            //---------------------end

            this.cmbCategory1.SelectedValue = "-1";
            this.cmbCategory2.SelectedValue = "-1";
            this.cmbCategory3.SelectedValue = "-1";

            this.txtVendorCD.Value = string.Empty;
            this.txtVendorName.Value = string.Empty;
            this.cmbInvalidData.SelectedValue = this.hdInValideDefault.Value;
            this.Collapse = "in";
        }

        /// <summary>
        /// Event Button new click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event Button Detail click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["ID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// PagingFooter Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// PagingHeader Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sort click event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        protected void cmbCategory1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var categoryId = int.Parse(this.cmbCategory1.SelectedValue);
            if (categoryId == -1)
            {
                this.SetComboByLevel(this.cmbCategory1, 1);
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                //this.SetComboByLevel(this.cmbCategory2, 2);
                //this.SetComboByLevel(this.cmbCategory3, 3);
                this.SetBlankCombo(this.cmbCategory2);
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }
            else
            {
                this.SetComboFromCategory1(this.cmbCategory2, categoryId, 2, "-1");
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                //this.SetComboFromCategory1(this.cmbCategory3, categoryId, 3, "-1");
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }

            this.FocusControlId = this.cmbCategory1.ClientID;
            this.Collapse = "in";
        }
        protected void cmbCategory2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
            int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);

            if (categoryId1 != -1)
            {
                if (categoryId2 != -1)
                {
                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, "-1");
                }
                else
                {
                    //2015/01/26
                    //Author: dh-phuong
                    //---------------------start
                    //this.SetComboFromCategory1(this.cmbCategory3, categoryId1, 3, "-1");
                    this.SetBlankCombo(this.cmbCategory3);
                    //---------------------end
                }
            }
            //2015/01/26
            //Author: dh-phuong
            //---------------------start
            //else
            //{
            //    if (categoryId2 != -1)
            //    {
            //        //Get list parent
            //        listCategory1 = this.GetListCategoryParentID(categoryId2, 2);
            //        if (listCategory1.Count != 0)
            //        {
            //            //Load combo
            //            this.SetComboFromCategory1AndCategory2(this.cmbCategory3, listCategory1[0].CategoryID, categoryId2, "-1");
            //            this.SetComboFromCategory1(this.cmbCategory2, listCategory1[0].CategoryID, 2, categoryId2.ToString());

            //            //Set value
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetValueCombo(this.cmbCategory1, listCategory1[0].CategoryID.ToString());
            //        }
            //        else
            //        {
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetComboByLevel(this.cmbCategory2, 2);
            //            this.SetComboByLevel(this.cmbCategory3, 3);
            //        }
            //    }
            //}
            //---------------------end
            this.FocusControlId = this.cmbCategory2.ClientID;

            this.Collapse = "in";
        }
        //protected void cmbCategory3_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
        //    int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);
        //    int categoryId3 = int.Parse(this.cmbCategory3.SelectedValue);

        //    IList<M_CategoryStruct> listCategory2;
        //    M_CategoryStruct categoryStruct;
        //    if (categoryId1 != -1)
        //    {
        //        if (categoryId2 != -1)
        //        {

        //        }
        //        else
        //        {
        //            if (categoryId3 != -1)
        //            {
        //                //Get list parent
        //                listCategory2 = this.GetListCategoryParentID(categoryId3, 3);
        //                if (listCategory2.Count != 0)
        //                {
        //                    this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, listCategory2[0].CategoryID.ToString());
        //                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, listCategory2[0].CategoryID, categoryId3.ToString());
        //                }
        //                else
        //                {
        //                    this.SetComboByLevel(this.cmbCategory2, 2);
        //                    this.SetComboByLevel(this.cmbCategory3, 3);
        //                }
        //            }
        //        }
        //    }
        //    else
        //    {
        //        if (categoryId3 != -1)
        //        {
        //            //Category3
        //            int categoryStructID = this.GetCategoryStructID(categoryId3, 3);
        //            if (categoryStructID != -1)
        //            {
        //                //Category 2
        //                categoryStruct = this.GetCategoryStructID(categoryStructID);
        //                if (categoryStruct != null)
        //                {
        //                    //Category1
        //                    categoryId2 = categoryStruct.CategoryID;
        //                    categoryStruct = this.GetCategoryStructID(categoryStruct.CategoryStructID);
        //                    if (categoryStruct != null)
        //                    {
        //                        categoryId1 = categoryStruct.CategoryID;
        //                        this.SetComboByLevel(this.cmbCategory1, 1);
        //                        this.SetValueCombo(this.cmbCategory1, categoryId1.ToString());

        //                        this.SetComboFromCategory1(this.cmbCategory2, categoryId1, 2, categoryId2.ToString());
        //                        this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, categoryId3.ToString());
        //                    }
        //                    else
        //                    {
        //                        this.SetComboByLevel(this.cmbCategory1, 1);
        //                        this.SetComboByLevel(this.cmbCategory2, 2);
        //                        this.SetComboByLevel(this.cmbCategory3, 3);                    
        //                    }
        //                }
        //                else
        //                {
        //                    this.SetComboByLevel(this.cmbCategory1, 1);
        //                    this.SetComboByLevel(this.cmbCategory2, 2);
        //                    this.SetComboByLevel(this.cmbCategory3, 3);                    
        //                }
        //            }
        //            else
        //            {
        //                this.SetComboByLevel(this.cmbCategory1, 1);
        //                this.SetComboByLevel(this.cmbCategory2, 2);
        //                this.SetComboByLevel(this.cmbCategory3, 3);                    
        //            }                    
        //        }                
        //    }

        //    this.FocusControlId = this.cmbCategory3.ClientID;
        //    this.Collapse = "in";
        //}

        /// <summary>
        /// Get vendor Name
        /// </summary>
        /// <param name="groupCd">Group Code</param>
        /// <returns>Group Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetVendorName(string in1)
        {                       
            var vendorCd = in1;
            var vendorCdShow = in1;
            vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
            try
            {
                using (DB db = new DB())
                {                    
                    VendorService vendor = new VendorService(db);
                    M_Vendor model = vendor.GetByCD(vendorCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            txtVendorCD = vendorCdShow,
                            txtVendorName = model.VendorName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var onlyCd = new
                        {
                            txtVendorCD = vendorCdShow,
                            txtVendorName = string.Empty
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                    }
                }                
            }
            catch (Exception)
            {
                return string.Empty;
            }            
        }
        #endregion

        #region Method

        /// <summary>
        /// Set confirm data
        /// </summary>
        private void SetConfirmData()
        {
            //Get vendor name
            this.txtVendorName.Value = string.Empty;
            if (!string.IsNullOrEmpty(this.txtVendorCD.Value))
            {
                //Get vendor
                using (DB db = new DB())
                {
                    VendorService vendorSer = new VendorService(db);
                    M_Vendor vendor = vendorSer.GetByCD(this.txtVendorCD.Value);
                    
                    if (vendor != null)
                    {
                        this.txtVendorName.Value = vendor.VendorName1;
                    }
                }
            }
            if (this.OldPagingInfo != null)
            {
                //Paging header
                this.PagingHeader.RowNumFrom = (int)this.OldPagingInfo["RowNumFrom"];
                this.PagingHeader.RowNumTo = (int)this.OldPagingInfo["RowNumTo"];
                this.PagingHeader.TotalRow = (int)this.OldPagingInfo["TotalRow"];
                this.PagingHeader.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];

                //Paging footer
                this.PagingFooter.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];
                this.PagingFooter.NumberOnPage = (int)this.OldPagingInfo["NumberOnPage"];
                this.PagingFooter.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                //Header
                this.HeaderGrid.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                this.AddHeaderCols();
                this.OldPagingInfo = this.OldPagingInfo;
            }
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtProductCD.ID, this.txtProductCD.Value);
            hash.Add(this.txtProductName.ID, this.txtProductName.Value);
            hash.Add(this.cmbCategory1.ID, this.cmbCategory1.SelectedValue);
            hash.Add(this.cmbCategory2.ID, this.cmbCategory2.SelectedValue);
            hash.Add(this.cmbCategory3.ID, this.cmbCategory3.SelectedValue);
            hash.Add(this.txtVendorCD.ID, this.txtVendorCD.Value);
            hash.Add(this.txtVendorName.ID, this.txtVendorName.Value);
            hash.Add(this.cmbInvalidData.ID, this.cmbInvalidData.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);
            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtProductCD.Value = data[this.txtProductCD.ID].ToString();
            this.txtProductName.Value = data[this.txtProductName.ID].ToString();

            //Load data for drop down list
            string categoryId1 = data[this.cmbCategory1.ID].ToString();
            string categoryId2 = data[this.cmbCategory2.ID].ToString();
            string categoryId3 = data[this.cmbCategory3.ID].ToString();

            this.SetComboByLevel(this.cmbCategory1, 1);
            if (categoryId1 == "-1")
            {
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                this.SetBlankCombo(this.cmbCategory2);
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end

            }
            else if (categoryId2 == "-1")
            {
                this.SetComboFromCategory1(this.cmbCategory2, int.Parse(categoryId1), 2, categoryId2);
                //2015/01/26
                //Author: dh-phuong
                //---------------------start
                //this.SetComboFromCategory1(this.cmbCategory3, int.Parse(categoryId1), 3, categoryId3);
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }
            else
            {
                this.SetComboFromCategory1(this.cmbCategory2, int.Parse(categoryId1), 2, categoryId2);
                this.SetComboFromCategory1AndCategory2(this.cmbCategory3, int.Parse(categoryId1), int.Parse(categoryId2), categoryId3);
            }

            this.SetValueCombo(this.cmbCategory1, categoryId1);

            this.txtVendorCD.Value = data[this.txtVendorCD.ID].ToString();
            this.txtVendorName.Value = data[this.txtVendorName.ID].ToString();
            this.cmbInvalidData.SelectedValue = data[this.cmbInvalidData.ID].ToString();
           
            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }        

        /// <summary>
        /// Init data
        /// </summary>
        private void InitData()
        {
            //Default DropDownList Value
            this.hdInValideDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Load data for drop down list
            this.SetComboByLevel(this.cmbCategory1, 1);
            //2015/01/26
            //Author: dh-phuong
            //---------------------start
            //this.SetComboByLevel(this.cmbCategory2, 2);
            //this.SetComboByLevel(this.cmbCategory3, 3);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            //---------------------end

            this.GetCmbTypeData(this.cmbType);
            this.SetDataCombobox(this.cmbInvalidData);

            //Header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "4";            

            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
            base.DisabledLink(this.btnExcel, !base._authority.IsMasterExcel);
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboByLevel(DropDownList ctrl, int level)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst = dbSer.GetDataByLevelForDropDownList(level, true);
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetBlankCombo(DropDownList ctrl)
        {
            IList<DropDownModel> lst = new List<DropDownModel>(new[]{
                new DropDownModel("-1", "---")
            });
            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        ///// <summary>
        ///// Get category data for DropDownList
        ///// </summary>
        ///// <param name="ctrl"></param>
        ///// <param name="parentId"></param>
        //private int GetCategoryStructID(int categoryId, int level)
        //{
        //    int ret = -1;
        //    IList<M_CategoryStruct> lst;
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        lst = dbSer.GetByCategoryIDAndLevel(categoryId, level);
        //    }
        //    if (lst.Count != 0)
        //    {
        //        ret = lst[0].CategoryStructID;
        //    }
        //    return ret;
        //}

        ///// <summary>
        ///// Get category data for DropDownList
        ///// </summary>
        ///// <param name="ctrl"></param>
        ///// <param name="parentId"></param>
        //private M_CategoryStruct GetCategoryStructID(int categoryStructID)
        //{           
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        return dbSer.GetByID(categoryStructID);
        //    }            
        //}

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1(DropDownList ctrl, int categoryId1, int childLevel, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1(categoryId1, childLevel));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1AndCategory2(DropDownList ctrl, int categoryId1, int categoryId2, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1AndCategory2(categoryId1, categoryId2));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Set Value
        /// </summary>
        /// <param name="ctr"></param>
        /// <param name="value"></param>
        private void SetValueCombo(DropDownList ctr, string value)
        {
            bool hasValue = false;
            List<DropDownModel> listValue = (List<DropDownModel>)ctr.DataSource;
            foreach (var item in listValue)
            {
                if (item.Value.Equals(value))
                {
                    hasValue = true;
                    break;
                }
            }
            if (hasValue)
            {
                ctr.SelectedValue = value;
            }
            else
            {
                ctr.SelectedValue = "-1";
            }
        }

        //private IList<M_CategoryStruct> GetListCategoryParentID(int categoryID, int childLevel)
        //{
        //    using (DB db = new DB())
        //    {
        //        CategoryStructService dbSer = new CategoryStructService(db);
        //        return dbSer.GetListCategoryParentID(categoryID, childLevel);
        //    }
        //}

        /// <summary>
        /// Get Type DropDownList Data
        /// </summary>
        /// <param name="ctrl"></param>
        private void GetCmbTypeData(DropDownList ctrl)
        {
            IList<DropDownModel> lst = new List<DropDownModel>();
            lst.Add(new DropDownModel("-1", "---"));
            lst.Add(new DropDownModel(string.Format("{0}", (int)Utilities.ProductType.Both), Utilities.ProductType.Both.ToString()));
            lst.Add(new DropDownModel(string.Format("{0}", (int)Utilities.ProductType.Sell), Utilities.ProductType.Sell.ToString()));
            lst.Add(new DropDownModel(string.Format("{0}", (int)Utilities.ProductType.Cost), Utilities.ProductType.Cost.ToString()));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = this.hdInValideDefault.Value;
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        /// <summary>
        /// Load date grid
        /// </summary>
        /// <param name="pageIndex">page index</param>
        /// <param name="numOnPage">number of rows on a page</param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }

            int totalRow = 0;
            int vendorID = -1;

            IList<ProductInfo> listProductInfo;
            
            //Get data
            using (DB db = new DB())
            {
                ProductService productSer = new ProductService(db);
                VendorService vendorSer = new VendorService(db);
                if (!string.IsNullOrEmpty(this.txtVendorCD.Value))
                {
                    M_Vendor vendor = vendorSer.GetByCD(EditDataUtil.ToFixCodeDB(this.txtVendorCD.Value, M_Vendor.VENDOR_CODE_MAX_LENGTH));
                    if (vendor != null)
                    {
                        vendorID = vendor.ID;
                    }
                    else
                    {
                        vendorID = -2;
                    }
                }
                
                totalRow = productSer.GetTotalRow(short.Parse(this.cmbType.SelectedValue), this.txtProductCD.Value, this.txtProductName.Value, int.Parse(this.cmbCategory1.SelectedValue), int.Parse(this.cmbCategory2.SelectedValue),
                                                  int.Parse(this.cmbCategory3.SelectedValue), vendorID, this.cmbInvalidData.SelectedItem.Value);                

                listProductInfo = productSer.GetListByCond(short.Parse(this.cmbType.SelectedValue), this.txtProductCD.Value, this.txtProductName.Value, int.Parse(this.cmbCategory1.SelectedValue), int.Parse(this.cmbCategory2.SelectedValue),
                                                           int.Parse(this.cmbCategory3.SelectedValue), vendorID, this.cmbInvalidData.SelectedItem.Value,
                                                           pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listProductInfo.Count == 0)
            {
                this.rptProductList.DataSource = null;
                this.OldPagingInfo = null;

                //Paging header
                this.PagingHeader.RowNumFrom = 0;
                this.PagingHeader.RowNumTo = 0;
                this.PagingHeader.TotalRow = 0;
                this.PagingHeader.CurrentPage = 1;

                //Paging footer
                this.PagingFooter.CurrentPage = 1;
                this.PagingFooter.NumberOnPage = 0;
                this.PagingFooter.TotalRow = 0;

                //Header
                this.HeaderGrid.TotalRow = 0;
                this.HeaderGrid.Columns = new List<ColumnInfo>();
            }
            else
            {
                //Paging header
                this.PagingHeader.RowNumFrom = int.Parse(listProductInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listProductInfo[listProductInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                //Paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                //Header
                this.HeaderGrid.TotalRow = totalRow;

                this.AddHeaderCols();


                Hashtable pagingInfo = new Hashtable();
                pagingInfo.Add("RowNumFrom", this.PagingHeader.RowNumFrom);
                pagingInfo.Add("RowNumTo", this.PagingHeader.RowNumTo);
                pagingInfo.Add("TotalRow", totalRow);
                pagingInfo.Add("CurrentPage", pageIndex);
                pagingInfo.Add("NumberOnPage", numOnPage);
                pagingInfo.Add("ColumnHeader", this.HeaderGrid.Columns);

                this.OldPagingInfo = pagingInfo;

                //detail
                this.rptProductList.DataSource = listProductInfo;
            }
            this.rptProductList.DataBind();
        }

        /// <summary>
        /// AddheaderCols
        /// </summary>
        private void AddHeaderCols()
        {
            #region Create Column
            this.HeaderGrid.Columns = null;
            ColumnInfo item1 = new ColumnInfo();
            item1.Text = "#";
            this.HeaderGrid.AddColumms(item1);

            ColumnInfo item2 = new ColumnInfo();
            item2.Text = "";
            this.HeaderGrid.AddColumms(item2);

            ColumnInfo item3 = new ColumnInfo();
            item3.Text = "Type";
            item3.Hidden = true;
            this.HeaderGrid.AddColumms(item3);

            ColumnInfo item4 = new ColumnInfo();
            item4.Text = "CD";
            item4.Sorting = true;
            this.HeaderGrid.AddColumms(item4);

            ColumnInfo item5 = new ColumnInfo();
            item5.Text = "Product Name";
            item5.Sorting = true;
            this.HeaderGrid.AddColumms(item5);

            ColumnInfo item6 = new ColumnInfo();
            item6.Text = "Category 1";
            item6.Sorting = true;
            this.HeaderGrid.AddColumms(item6);

            ColumnInfo item7 = new ColumnInfo();
            item7.Text = "Category 2";
            item7.Sorting = true;
            this.HeaderGrid.AddColumms(item7);

            ColumnInfo item8 = new ColumnInfo();
            item8.Text = "Category 3";
            item8.Sorting = true;
            this.HeaderGrid.AddColumms(item8);

            ColumnInfo item9 = new ColumnInfo();
            item9.Text = "Unit Price Sell";
            item9.Sorting = true;
            item9.CssClass = "text-right";
            this.HeaderGrid.AddColumms(item9);

            ColumnInfo item10 = new ColumnInfo();
            item10.Text = "Unit Price Cost";
            item10.Sorting = true;
            item10.CssClass = "text-right";
            this.HeaderGrid.AddColumms(item10);

            #endregion
        }


        /// <summary>
        /// Check Input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptProductList.DataSource = null;
                this.rptProductList.DataBind();
                return true;
            }
            return false;
        }

        #endregion

        #region Excel

        #region Constant Excel

        private const string EXCEL_PRODUCT_DOWNLOAD = "Product_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";

        #endregion

        /// <summary>
        /// Download excel event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                //Create file name
                var fileName = string.Format(EXCEL_PRODUCT_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Event Button new click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            ProductListExcel excel = new ProductListExcel();
            IWorkbook wb = excel.OutputExcel();
            if (wb != null)
            {
                this.SaveFile(wb);

                this.btnSearch_Click(null, null);
            }
        }        

        #endregion
    }
}
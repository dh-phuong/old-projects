﻿using System;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using System.Data.SqlClient;

namespace OMS.Master
{
    /// <summary>
    /// Unit Detail
    /// ISV-NGUYEN
    /// </summary>
    public partial class FrmUnitDetail : FrmBaseDetail
    {
        #region constant
        private const string URL_LIST = "~/Master/FrmUnitList.aspx";
        #endregion

        #region Property

        /// <summary>
        /// Get or set UnitID
        /// </summary>
        public int UnitID
        {
            get { return (int)ViewState["UnitID"]; }
            set { ViewState["UnitID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Unit Master";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtUnitName.MaxLength = M_Unit.UNIT_NAME_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessDelete);
        }

        /// <summary>
        /// Page Load
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Unit);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }
            //if (!base.CheckAuthorityMaster(FormId.Unit, AuthorTypeMaster.View))
            //{
            //    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            //}

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set Mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        this.UnitID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Unit unit = this.GetUnit(this.UnitID);

                        //Check unit
                        if (unit != null)
                        {
                            //Show data
                            this.ShowData(unit);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get unit
            M_Unit unit = this.GetUnit(this.UnitID);

            //Check unit
            if (unit != null)
            {
                //Show data
                this.ShowData(unit);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get unit
            M_Unit unit = this.GetUnit(this.UnitID);

            //Check unit
            if (unit != null)
            {
                //Show data
                this.ShowData(unit);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get unit
            M_Unit unit = this.GetUnit(this.UnitID);

            //Check unit
            if (unit != null)
            {
                //Show data
                this.ShowData(unit);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        M_Unit unit = this.GetUnit(txtUnitName.Value);

                        //Show data
                        this.ShowData(unit);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete Data
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_Unit unit = this.GetUnit(txtUnitName.Value);

                        //Show data
                        this.ShowData(unit);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessDelete(object sender, EventArgs e)
        {
            //Get unit
            M_Unit unit = this.GetUnit(this.UnitID);
            if (unit != null)
            {
                //Show data
                this.ShowData(unit);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.txtUnitName.Value = string.Empty;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    this.txtUnitName.ReadOnly = false;
                    break;

                default:
                    this.txtUnitName.ReadOnly = true;

                    //this.btnEdit.Attributes.Add("class", this.CheckAuthorityMaster(FormId.Unit, AuthorTypeMaster.Edit) ? Constants.CSS_BTN_EDIT : Constants.CSS_BTN_EDIT_DISABLED);
                    //this.btnDelete.Attributes.Add("class", this.CheckAuthorityMaster(FormId.Unit, AuthorTypeMaster.Delete) ? Constants.CSS_BTN_DELETE : Constants.CSS_BTN_DELETE_DISABLED);
                    //this.btnCopy.Attributes.Add("class", this.CheckAuthorityMaster(FormId.Unit, AuthorTypeMaster.Copy) ? Constants.CSS_BTN_COPY : Constants.CSS_BTN_COPY_DISABLED);

                    //this.btnEdit.Attributes.Add("class", this._authority.IsMasterEdit ? Constants.CSS_BTN_EDIT : Constants.CSS_BTN_EDIT_DISABLED);
                    //this.btnDelete.Attributes.Add("class", this._authority.IsMasterDelete ? Constants.CSS_BTN_DELETE : Constants.CSS_BTN_DELETE_DISABLED);
                    //this.btnCopy.Attributes.Add("class", this._authority.IsMasterCopy ? Constants.CSS_BTN_COPY : Constants.CSS_BTN_COPY_DISABLED);

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="unit">unit</param>
        private void ShowData(M_Unit unit)
        {
            if (unit != null)
            {
                this.txtUnitName.Value = unit.UnitName;

                //Save UnitID and UpdateDate
                this.UnitID = unit.ID;
                this.OldUpdateDate = unit.UpdateDate;
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Unit unit = new M_Unit();
                unit.UnitName = this.txtUnitName.Value;


                unit.CreateUID = this.LoginInfo.User.ID;
                unit.UpdateUID = this.LoginInfo.User.ID;

                //Insert unit
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    UnitService unitSer = new UnitService(db);

                    //Insert unit
                    unitSer.Insert(unit);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {

                if (ex.Message.Contains(Models.Constant.M_UNIT_UN))
                {
                    this.SetMessage(this.txtUnitName.ID, M_Message.MSG_EXIST_CODE, "Unit Name");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Unit unit = this.GetUnit(this.UnitID);
                if (unit != null)
                {
                    //Create model
                    unit.UnitName = this.txtUnitName.Value;
                    unit.UpdateDate = this.OldUpdateDate;
                    unit.UpdateUID = this.LoginInfo.User.ID;

                    //Update unit
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        UnitService unitSer = new UnitService(db);

                        //Update unit
                        if (unit.Status == DataStatus.Changed)
                        {
                            ret = unitSer.Update(unit);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_UNIT_UN))
                {
                    this.SetMessage(this.txtUnitName.ClientID, M_Message.MSG_EXIST_CODE, "Unit Name");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;

                //Delete unit
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    UnitService unitSer = new UnitService(db);
                    ret = unitSer.DeleteUnit(this.UnitID, this.OldUpdateDate);
                    db.Commit();
                }
                //Check result Delete
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_UNIT) ||
                    ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_UNIT) ||

                    ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_UNIT) ||
                    ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_UNIT) ||

                    ex.Message.Contains(Models.Constant.T_PURCHASE_D_FK_UNIT) ||

                    ex.Message.Contains(Models.Constant.T_DELIVERY_D_FK_UNIT) ||

                    ex.Message.Contains(Models.Constant.T_BILLING_D_FK_UNIT) ||

                    ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_COST) ||
                    ex.Message.Contains(Models.Constant.M_PRODUCT_FK_UNITID_SELL)
                    )
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Unit Name " + this.txtUnitName.Value);
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Get unit by ID
        /// </summary>
        /// <param name="unitID">unitID</param>
        /// <returns>unit</returns>
        private M_Unit GetUnit(int unitID)
        {
            using (DB db = new DB())
            {
                UnitService unitSer = new UnitService(db);

                //Get unit
                return unitSer.GetByID(unitID);
            }
        }

        /// <summary>
        /// Get unit by Name
        /// </summary>
        /// <param name="unitName">unitName</param>
        /// <returns>unit</returns>
        private M_Unit GetUnit(string unitName)
        {
            using (DB db = new DB())
            {
                UnitService unitSer = new UnitService(db);

                //Get unit
                return unitSer.GetByUnitName(unitName);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //UnitName
            if (this.txtUnitName.IsEmpty)
            {
                this.SetMessage(txtUnitName.ID, M_Message.MSG_REQUIRE, "Unit Name");
            }
            else
            {
                if (this.Mode == Mode.Update)
                {
                    var m_Unit = this.GetUnit(this.txtUnitName.Value);
                    if (m_Unit != null)
                    {
                        if (m_Unit.Status == DataStatus.Changed)
                        {
                            this.SetMessage(txtUnitName.ID, M_Message.MSG_EXIST_CODE, "Unit Name");
                        }
                    }
                }
                else if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    var m_Unit = this.GetUnit(this.txtUnitName.Value);
                    if (m_Unit != null)
                    {
                        this.SetMessage(txtUnitName.ID, M_Message.MSG_EXIST_CODE, "Unit Name");
                    }
                }
            }
            //Check error
            return !base.HaveError;
        }

        #endregion
    }
}
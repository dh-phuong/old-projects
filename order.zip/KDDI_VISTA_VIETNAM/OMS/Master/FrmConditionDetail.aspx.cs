﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;

namespace OMS.Master
{
    /// <summary>
    /// Condition Detail
    /// ISV-GIAM
    /// </summary>
    public partial class FrmConditionDetail : FrmBaseDetail
    {
        private const string URL_LIST = "~/Master/FrmConditionList.aspx";
        #region Property
        /// <summary>
        /// Get or set ConditionID
        /// </summary>
        public int ConditionID
        {
            get { return (int)ViewState["ConditionID"]; }
            set { ViewState["ConditionID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Template Master";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditionName.MaxLength = M_Condition.CONDITION_NAME_MAX_LENGTH;
            this.txtCondition.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ConditionTemplate);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Set Default Type
                this.hdConditionTypeDefault.Value = "-1"; ;

                //Set data for combobox
                this.SetDataCombobox(this.cmbType, this.hdConditionTypeDefault.Value);

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get Condition ID
                        this.ConditionID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Condition condition = this.GetCondition(this.ConditionID);

                        //Check Condition
                        if (condition != null)
                        {
                            //Show data
                            this.ShowData(condition);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Condition
            M_Condition condition = this.GetCondition(this.ConditionID);

            //Check condition
            if (condition != null)
            {
                //Show data
                this.ShowData(condition);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Condition
            M_Condition condition = this.GetCondition(this.ConditionID);

            //Check condition
            if (condition != null)
            {
                //Show data
                this.ShowData(condition);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }


        /// <summary>
        /// Insert Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Update Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.Yes, true);
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Condition
            M_Condition condition = this.GetCondition(this.ConditionID);

            //Check condition
            if (condition != null)
            {
                //Show data
                this.ShowData(condition);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.cmbType.SelectedValue = "-1";
            this.txtConditionCD.Value = string.Empty;
            this.txtConditionName.Value = string.Empty;
            this.txtCondition.Value = string.Empty;

            //Set mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert condition
                    if (this.InsertData())
                    {
                        //Get condition
                        M_Condition condition = this.GetCondition(this.txtConditionCD.Value, int.Parse(this.cmbType.SelectedValue));

                        //Show data
                        this.ShowData(condition);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Update:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //Get condition
                        M_Condition condition = this.GetCondition(this.ConditionID);

                        //Show data
                        this.ShowData(condition);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                default:

                    //Delete condition
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Get condition
                        M_Condition condition = this.GetCondition(this.ConditionID);

                        //Show data
                        this.ShowData(condition);

                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get condition
            M_Condition condition = this.GetCondition(this.ConditionID);
            if (condition != null)
            {
                //Show data
                this.ShowData(condition);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        #endregion

        #region Methods

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            var source = this.GetDataForDropdownList(M_Config_H.CONFIG_CONDITION_TYPE);
            source.Insert(0, new DropDownModel("-1", "---"));
            ddl.DataSource = source;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Get Condition by ID
        /// </summary>
        /// <param name="conditionID">ConditionID</param>
        /// <returns>Condition</returns>
        private M_Condition GetCondition(int conditionID)
        {
            using (DB db = new DB())
            {
                ConditionService conditionSer = new ConditionService(db);

                //Get Condition
                return conditionSer.GetByID(conditionID);
            }
        }

        /// <summary>
        /// Get Condition by Code
        /// </summary>
        /// <param name="conditionCD">ConditionCD</param>
        /// <param name="type">Condition type</param>
        /// <returns>Condition</returns>
        private M_Condition GetCondition(string conditionCD, int type)
        {
            using (DB db = new DB())
            {
                ConditionService conditionSer = new ConditionService(db);

                //Get Condition
                return conditionSer.GetByCodeAndType(conditionCD, type);
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Condition condition = new M_Condition();
                condition.Type = int.Parse(this.cmbType.SelectedValue);
                condition.ConditionCD = this.txtConditionCD.Value;
                condition.ConditionName = this.txtConditionName.Value;
                condition.Condition = this.txtCondition.Value;

                condition.CreateUID = this.LoginInfo.User.ID;
                condition.UpdateUID = this.LoginInfo.User.ID;

                //Insert Condition
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ConditionService conditionSer = new ConditionService(db);
                    conditionSer.Insert(condition);
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_CONDITION_UN))
                {
                    this.SetMessage(this.txtConditionCD.ID, M_Message.MSG_EXIST_CODE, "Condition Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Condition condition = this.GetCondition(this.txtConditionCD.Value, int.Parse(this.cmbType.SelectedValue));
                if (condition != null)
                {
                    //Create model
                    condition.Type = int.Parse(this.cmbType.SelectedValue);
                    condition.ConditionName = this.txtConditionName.Value;
                    condition.Condition = this.txtCondition.Value;

                    condition.UpdateDate = this.OldUpdateDate;
                    condition.UpdateUID = this.LoginInfo.User.ID;

                    //Update Condition  
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ConditionService conditionSer = new ConditionService(db);

                        // If data change
                        if (condition.Status == DataStatus.Changed)
                        {
                            ret = conditionSer.Update(condition);
                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                M_Condition condition = this.GetCondition(this.txtConditionCD.Value, int.Parse(this.cmbType.SelectedValue));
                if (condition != null)
                {
                    condition.UpdateDate = this.OldUpdateDate;
                    //Delete Condition  
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ConditionService conditionSer = new ConditionService(db);
                        ret = conditionSer.Delete(condition);
                        db.Commit();
                    }
                }

                //Check result delete
                if (ret == 0)
                {
                    //Data changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Display data in form
        /// </summary>
        /// <param name="condition"></param>
        private void ShowData(M_Condition condition)
        {
            //Show data
            if (condition != null)
            {
                this.cmbType.SelectedValue = condition.Type.ToString();
                this.txtConditionCD.Value = Utilities.EditDataUtil.ToFixCodeShow(condition.ConditionCD, M_Condition.MAX_CONDITION_CODE_SHOW);
                this.txtConditionName.Value = condition.ConditionName;
                this.txtCondition.Value = condition.Condition;

                //Save ConditionID and UpdateDate
                this.ConditionID = condition.ID;
                this.OldUpdateDate = condition.UpdateDate;
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Condition Type
            if (this.cmbType.SelectedValue == null || this.cmbType.SelectedValue == "-1")
            {
                this.SetMessage(this.cmbType.ID, M_Message.MSG_PLEASE_SELECT, "Template Type");
            }

            //ConditionCD
            if (this.txtConditionCD.IsEmpty)
            {
                this.SetMessage(this.txtConditionCD.ID, M_Message.MSG_REQUIRE, "Template Code");
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    //Check exist ConditionCD
                    if (this.GetCondition(this.txtConditionCD.Value, int.Parse(this.cmbType.SelectedValue)) != null)
                    {
                        this.SetMessage(this.txtConditionCD.ID, M_Message.MSG_EXIST_CODE, "Template Code");
                    }
                }
            }

            //ConditionName
            if (this.txtConditionName.IsEmpty)
            {
                this.SetMessage(this.txtConditionName.ID, M_Message.MSG_REQUIRE, "Template Name");
            }

            //Condition
            if (this.txtCondition.IsEmpty)
            {
                this.SetMessage(this.txtCondition.ID, M_Message.MSG_REQUIRE, "Template");
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtConditionCD.ReadOnly = true;
                        this.cmbType.Enabled = false;
                    }
                    else
                    {
                        this.txtConditionCD.ReadOnly = false;
                        this.cmbType.Enabled = true;
                    }

                    enable = false;
                    break;

                default:

                    this.txtConditionCD.ReadOnly = true;
                    this.cmbType.Enabled = false;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//

                    enable = true;
                    break;
            }

            //Lock control
            this.txtConditionName.ReadOnly = enable;
            this.txtCondition.ReadOnly = enable;
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.DAC;
using OMS.Utilities;
using System.Collections;
using System.Data.SqlClient;

namespace OMS.Master
{
    /// <summary>
    /// Page:   Category struct
    /// Author: ISV-Phuong
    /// </summary>
    public partial class FrmCategoryStruct : FrmBaseDetail
    {
        /// <summary>
        /// Viewsate key: IS_DATA_CHANGE
        /// </summary>
        private const string IS_DATA_CHANGED = "IS_DATA_CHANGED";

        /// <summary>
        /// DataSource Of treeview
        /// </summary>
        private IList<ITreeData> TreeData
        {
            get
            {
                return (IList<ITreeData>)base.ViewState["TreeData"];
            }
            set
            {
                base.ViewState["TreeData"] = value;
            }
        }

        /// <summary>
        /// Nodes deleted
        /// </summary>
        private IList<ITreeData> RemoveNodes
        {
            get
            {
                return (IList<ITreeData>)base.ViewState["RemoveNode"];
            }
            set
            {
                base.ViewState["RemoveNode"] = value;
            }
        }

        private IList<CategoryInfo> DataSource
        {
            get
            {
                return (IList<CategoryInfo>)base.ViewState["DataSource"];
            }
            set
            {
                base.ViewState["DataSource"] = value;
            }
        }

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Category Struct Master";
            base.FormSubTitle = "Detail";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            this.PagingHeader.NumRowOnPage = this.GetDefaultValuePaging();
            this.PagingHeader.CurrentPage = 1;

            // Paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.CategoryStruct);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            bool temp;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                temp = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }
            if (!temp)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            //if (!base.CheckAuthorityMaster(FormId.CategoryStruct, AuthorTypeMaster.View))
            //{
            //    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            //}
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Set Mode
                this.ProcessMode(Mode.View);

                this.ShowData();

            }

        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                int sortField = 3;
                int sortDirec = 1;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                this.SaveCondition();
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int sortField = 3;
                int sortDirec = 1;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                this.SaveCondition();
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            int sortField = 3;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Set Mode
            this.ProcessMode(Mode.Update);

            //Get Data
            this.InitData();

            this.ShowData();
        }

        /// <summary>
        /// Click btnRemove
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemove_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                var removeId = this.hdnStructId.Value;
                if (string.IsNullOrEmpty(removeId))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_PLEASE_SELECT, "Category Code");
                    this.ShowData();
                    return;
                }
                this.ViewState[IS_DATA_CHANGED] = true;

                this.DeleteNode(this.TreeData, long.Parse(removeId));
                this.hdnStructId.Value = "";
                this.hdnStructId.DataBind();

                this.ShowData();

                if (removeId != this.hdnSelectedId.Value)
                {
                    this.hdnStructId.Value = this.hdnSelectedId.Value;
                    this.hdnStructId.DataBind();
                }
            }
        }

        /// <summary>
        /// Click btnAdd
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                //Identity
                var categoryStructIdStr = this.hdnStructId.Value;

                if (string.IsNullOrEmpty(categoryStructIdStr))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_PLEASE_SELECT, "Category Code");
                    this.ShowData();
                    return;
                }
                this.ViewState[IS_DATA_CHANGED] = true;

                //Identity Or ID
                var categoryStructId = long.Parse(categoryStructIdStr);

                //var rowNo = int.Parse((sender as LinkButton).CommandArgument);
                var keys = (sender as LinkButton).CommandArgument.Split(new char[] { '_' });

                var categories = (IList<CategoryInfo>)this.DataSource;
                var category = categories.Where(s => s.RowNumber == int.Parse(keys[0]) &&
                                                     s.ID == int.Parse(keys[1])).SingleOrDefault();

                //Get Selected Struct
                var structNode = this.FindNode(this.TreeData, categoryStructId, -1);

                /*
                 * Check duplicate in an level 
                 */
                var foundNode = this.FindNode(structNode.Nodes, category.CategoryCD, structNode.Node.Level + 1);
                if (foundNode != null)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_MUST_BE_DIFFERENT, "Category", string.Format("\"{0}: {1}\"", category.CategoryCD, category.CategoryName));
                    this.ShowData();
                    this.hdnStructId.Value = categoryStructIdStr;
                    return;
                }

                //Find it's in remove list
                var deletedNode = this.FindNode(this.RemoveNodes, category.CategoryStructID, -1);
                if (deletedNode != null)
                {
                    //Update Info for deleted node;
                    deletedNode.Node.Level = structNode.Node.Level + 1;
                    deletedNode.Node.NumberOrder = structNode.Nodes.Count + 1;
                    deletedNode.Node.CategoryStructID = structNode.Node.ID;
                    deletedNode.CssStyle = "style='color:blue;'";
                    structNode.Nodes.Add(deletedNode);

                    //Remove Backup
                    this.DeleteNode(this.RemoveNodes, deletedNode.Node.Identity);
                }
                else
                {
                    structNode.Nodes.Add(new ITreeData
                    {
                        Node = new CategoryStructInfo
                        {
                            CategoryID = category.ID,
                            CategoryStructID = structNode.Node.ID,
                            CategoryCD = category.CategoryCD,
                            CategoryName = category.CategoryName,
                            Level = structNode.Node.Level + 1,
                            NumberOrder = structNode.Nodes.Count + 1,
                        },
                        CssStyle = "style='color:blue;'"
                    });
                }

                /*
                 * Sort by CategoryCD
                 */
                structNode.Nodes = new List<ITreeData>(structNode.Nodes.OrderBy(s => s.Node.CategoryCD));

                /*
                 * Reset order number
                 */
                for (int i = 0; i < structNode.Nodes.Count; i++)
                {
                    structNode.Nodes[i].Node.NumberOrder = (i + 1);
                }

                this.ShowData();
                this.hdnStructId.Value = categoryStructIdStr;
                this.hdnStructId.DataBind();
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Check user
            if (this.Mode == Utilities.Mode.Update)
            {
                //Set Mode
                this.ProcessMode(Mode.View);
                this.InitData();
                this.ShowData();
            }
            else
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);

            this.ShowData();
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            #region ProcessTreeView
            bool isOk = this.UpdateData();

            //----------------------------- Reload data ----------------------------
            if (isOk)
            {
                //Set Mode
                this.ProcessMode(Mode.View);

                //Get Data
                this.InitData();

                //Set Success
                this.Success = true;
            }

            //Show data
            this.ShowData();
            //---------------------------------------------------------------------
        }


        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            this.ShowData();
        }

            #endregion

        #region Method
        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            if (this.Mode == Utilities.Mode.View)
            {
                this.HeaderGrid.SortField = string.Empty;
                this.HeaderGrid.SortDirec = string.Empty;
                this.PagingHeader.CurrentPage = 1;

                this.ViewState["Condition"] = null;
                this.RemoveNodes = new List<ITreeData>();
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";
            this.ViewState[IS_DATA_CHANGED] = false;

            using (var db = new DB())
            {
                var cateStructService = new CategoryStructService(db);
                var root = cateStructService.GetByID(Constant.DEFAULT_ID);

                var cateService = new CategoryService(db);
                ////Create Root Data
                //var rootData = new ITreeData
                //{
                //    Node = new CategoryStructInfo
                //    {
                //        ID = Constant.DEFAULT_ID,
                //        Identity = Constant.DEFAULT_ID,
                //        CategoryID = Constant.DEFAULT_ID,
                //        CategoryCD = Constant.CATEGORY_ROOT_CODE,
                //        CategoryName = Constant.CATEGORY_ROOT_NAME,
                //        CategoryStructID = -1,
                //        Level = 0,
                //        NumberOrder = 1,

                //    },
                //    Nodes = this.GetTreeViewDataSource(Constant.DEFAULT_ID, cateService, cateStructService)
                //};

                //Create Root Data
                var rootData = new ITreeData
                {
                    Node = new CategoryStructInfo
                    {
                        ID = root.ID,
                        Identity = Constant.DEFAULT_ID,
                        CategoryID = root.CategoryID,
                        CategoryCD = Constant.CATEGORY_ROOT_CODE,
                        CategoryName = Constant.CATEGORY_ROOT_NAME,
                        CategoryStructID = root.CategoryStructID,
                        Level = root.Level,
                        NumberOrder = root.NumberOrder,
                        UpdateDate = root.UpdateDate
                    },
                    Nodes = this.GetTreeViewDataSource(root.ID, cateService, cateStructService)
                };

                this.TreeData = new List<ITreeData>(new[]{
                    rootData
                });
            }
            this.RemoveNodes = new List<ITreeData>();

            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        private void ShowData()
        {
            //this.InitData();
            this.InitTreeView();

            int sortField = 3;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }

            //Show condition
            if (this.ViewState["Condition"] != null)
            {
                Hashtable data = (Hashtable)this.ViewState["Condition"];

                this.ShowCondition(data);
            }

            //Show data on grid
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

        }

        /// <summary>
        /// Get TreeView DataSource
        /// </summary>
        /// <param name="parentId">Parent id</param>
        /// <param name="cateService">Category service</param>
        /// <param name="cateStructservice">Category struct service</param>
        /// <returns>Tree data</returns>
        private IList<ITreeData> GetTreeViewDataSource(long parentId, CategoryService cateService, CategoryStructService cateStructservice)
        {
            var results = new List<ITreeData>();
            var subs = cateStructservice.GetChilds(parentId);
            foreach (var cateS in subs)
            {
                results.Add(new ITreeData(cateS, this.GetTreeViewDataSource(cateS.ID, cateService, cateStructservice)));
            }
            return results;
        }

        /// <summary>
        /// Init Node treeview
        /// </summary>
        private void InitTreeView()
        {
            if (this.Mode == Utilities.Mode.Update)
            {
                if (string.IsNullOrEmpty(this.hdnStructId.Value))
                {
                    this.hdnStructId.Value = "1";
                }
            }
            else
            {
                this.hdnStructId.Value = "";
            }
            this.hdnStructId.DataBind();

            tvStruct.Nodes.Clear();

            System.Text.StringBuilder nodeText = new System.Text.StringBuilder();
            //nodeText.AppendLine("<label>");
            nodeText.AppendLine(string.Format("<input type='radio' id='rad{0}' class='struct' name='structItem' value='{0}'/>" +
                                          "&nbsp;{1}:{2}", Constant.DEFAULT_ID, Constant.CATEGORY_ROOT_CODE, Constant.CATEGORY_ROOT_NAME));
            //nodeText.AppendLine("</label>");
            var root = new TreeNode(nodeText.ToString(), Constant.DEFAULT_ID.ToString());
            root.SelectAction = TreeNodeSelectAction.None;
            tvStruct.Nodes.Add(root);

            this.AddNodes(root, this.TreeData.First().Nodes);

            tvStruct.DataBind();
        }

        /// <summary>
        /// Add nodes
        /// </summary>
        /// <param name="root">root</param>
        /// <param name="childs">List children</param>
        private void AddNodes(TreeNode root, IList<ITreeData> childs)
        {
            foreach (var nodeData in childs)
            {
                var node = this.CreateNode(nodeData);
                root.ChildNodes.Add(node);
                if (nodeData.Nodes.Count != 0)
                {
                    this.AddNodes(node, nodeData.Nodes);
                }
            }
        }

        /// <summary>
        /// Create Node
        /// </summary>
        /// <param name="nodeData">Node data</param>
        /// <returns>Tree node</returns>
        private TreeNode CreateNode(ITreeData nodeData)
        {
            var node = new TreeNode();

            node.Value = nodeData.Node.ID.ToString();
            node.SelectAction = TreeNodeSelectAction.None;


            System.Text.StringBuilder nodeText = new System.Text.StringBuilder();
            nodeText.AppendLine("<div class='btn-group btn-group-justified'>");
            nodeText.AppendLine("<div>");

            if (nodeData.Node.Level == 3)
            {
                if (this.Mode == Utilities.Mode.Update)
                {
                    nodeText.AppendLine("<button id='btnRemove' class='btn-circle btn btn-default btn-xs' ");
                    nodeText.AppendLine(string.Format("            onclick='javascript:execRemove(\"{0}\"); return false;'>", nodeData.Node.Identity));
                    nodeText.AppendLine("<span class='glyphicon glyphicon-minus'></span>");
                    nodeText.AppendLine("</button>");
                }
            }
            else
            {
                nodeText.AppendLine(string.Format("<input type='radio' id='rad{0}' class='struct' name='structItem' value='{0}'/>", nodeData.Node.Identity));

                if (nodeData.Nodes.Count == 0)
                {
                    if (this.Mode == Utilities.Mode.Update)
                    {
                        nodeText.AppendLine("<button id='btnRemove' class='btn-circle btn btn-default btn-xs' ");
                        nodeText.AppendLine(string.Format("            onclick='javascript:execRemove(\"{0}\"); return false;'>", nodeData.Node.Identity));
                        nodeText.AppendLine("<span class='glyphicon glyphicon-minus'></span>");
                        nodeText.AppendLine("</button>");
                    }
                }
            }
            nodeText.AppendLine(string.Format("<span {0}>{1}: {2}</spanl>", nodeData.CssStyle, nodeData.Node.CategoryCD, nodeData.Node.CategoryName));
            nodeText.AppendLine("</div>");
            nodeText.AppendLine("</div>");
            node.Text = nodeText.ToString();
            return node;
        }

        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex">Index of page</param>
        /// <param name="numOnPage">The number of lines on a page</param>
        /// <param name="sortField">Sort field</param>
        /// <param name="sortDirec">Sort direction</param>
        private void LoadDataGrid(int pageIndex, int numOnPage, int sortField, int sortDirec)
        {
            int totalRow = 0;

            IList<CategoryInfo> dataSource = new List<CategoryInfo>();

            //Get data
            using (DB db = new DB())
            {
                CategoryService service = new CategoryService(db);
                CategoryStructService structService = new CategoryStructService(db);
                var categories = service.GetListSortBy(sortField, sortDirec);

                #region Struct In Product
                int rowNumber = 0;

                IOrderedEnumerable<ITreeData> orders = null;
                if (sortField == 3 && sortDirec == 1)
                {
                    orders = this.RemoveNodes.OrderBy(s => s.Node.CategoryCD);
                }
                else if (sortField == 3 && sortDirec == 2)
                {
                    orders = this.RemoveNodes.OrderByDescending(s => s.Node.CategoryCD);
                }
                else if (sortField == 4 && sortDirec == 1)
                {
                    orders = this.RemoveNodes.OrderBy(s => s.Node.CategoryName);
                }
                else if (sortField == 4 && sortDirec == 2)
                {
                    orders = this.RemoveNodes.OrderByDescending(s => s.Node.CategoryName); 
                }

                foreach (var deletedNode in orders)
                {
                    //Find node exists in product
                    if (deletedNode.Node.ID > 0 &&
                        structService.ExistsInProduct(deletedNode.Node.ID))
                    {
                        rowNumber += 1;
                        dataSource.Add(new CategoryInfo
                        {
                            ID = deletedNode.Node.CategoryID,
                            RowNumber = rowNumber,
                            CategoryCD = deletedNode.Node.CategoryCD,
                            CategoryName = deletedNode.Node.CategoryName,

                            //Mark for remove Node
                            CategoryStructID = deletedNode.Node.ID,
                            CssStyle = "class=\"warning\" style=\"color:red;\"",
                        });
                    }
                }
                //order by 
                //dataSource = new List<CategoryInfo>(dataSource.OrderBy(s=> s.CategoryCD));

                //
                #endregion

                #region Category List
                foreach (var category in categories)
                {
                    //if (this.FindNode(this.TreeData, category.CategoryCD) == null)
                    {
                        rowNumber += 1;
                        dataSource.Add(new CategoryInfo
                        {
                            ID = category.ID,
                            RowNumber = rowNumber,
                            CategoryCD = category.CategoryCD,
                            CategoryName = category.CategoryName
                        });
                    }
                }

                totalRow = dataSource.Count;

                //Paging
                dataSource = dataSource.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                #endregion

            }

            #region Set paging info
            //Show data
            if (dataSource.Count == 0)
            {
                if (this.ViewState["Condition"] != null)
                {
                    Hashtable data = (Hashtable)this.ViewState["Condition"];
                    int curPage = int.Parse(data["CurrentPage"].ToString());
                    if (curPage != 1)
                    {
                        curPage -= 1;

                        this.PagingHeader.CurrentPage = curPage;
                        this.PagingFooter.CurrentPage = curPage;

                        int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                        this.PagingHeader.NumRowOnPage = rowOfPage;

                        this.SaveCondition();

                        //Show data on grid
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

                        return;
                    }
                }

                this.repeater.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(dataSource[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(dataSource[dataSource.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                this.SaveCondition();

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Name" });

                // detail
                this.repeater.DataSource = dataSource;
            }
            #endregion
            this.repeater.DataBind();
            this.DataSource = dataSource;
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        private bool UpdateData()
        {
            var isChanged = (bool)this.ViewState[IS_DATA_CHANGED];
            if (isChanged)
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    try
                    {
                        CategoryStructService service = new CategoryStructService(db);

                        //Delete CategoryStruct
                        if (this.RemoveNodes != null)
                        {
                            foreach (var categoryStruct in this.RemoveNodes)
                            {

                                var categoryStructId = categoryStruct.Node.ID;
                                var updateDate = categoryStruct.Node.UpdateDate;

                                //Delete category struct
                                if (categoryStructId > 0 &&
                                    service.Delete(categoryStructId, updateDate) <= 0)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }
                        }

                        var rootNode = this.TreeData.First();
                        //Insert AND Update (Not Root)
                        var nodes = rootNode.Nodes;

                        foreach (var node in nodes)
                        {
                            if (!this.UpdateTree(Constant.DEFAULT_ID, node, service))
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                        //
                        //UpdateData ROOT
                        var root = this.CreateModel(rootNode);
                        if (service.Update(root) > 0)
                        {
                            db.Commit();
                        }
                        else
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        //

                        
                    }
                    catch (SqlException ex)
                    {
                        if (ex.Message.Contains(Models.Constant.M_CATEGORYSTRUCT_FK_CATEGORYID))
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        }
                        else if (ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CATEGORY_STRUCT_ID))
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Category Code");
                        }
                        else
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                        }
                        Log.Instance.WriteLog(ex);
                        return false;
                    }
                    catch (Exception ex)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                        Log.Instance.WriteLog(ex);
                        return false;
                    }
                }
            }
            return true;
        #endregion
        }

        /// <summary>
        /// Update tree
        /// </summary>
        /// <param name="node">Node</param>
        /// <param name="categoryStructservice">Service</param>
        /// <returns>True: update success/Flalse: update fail</returns>
        private bool UpdateTree(int structId, ITreeData node, CategoryStructService categoryStructservice)
        {
            var result = false;
            var model = this.CreateModel(node);

            var newId = 0;
            if (node.Node.Status == 1)
            {
                if (model.Status == DataStatus.Changed)
                {
                    newId = model.ID;

                    ////Update ID For Child Nodes
                    model.CategoryStructID = structId;
                    if (categoryStructservice.Update(model) > 0)
                    {
                        result = true;
                    }
                    else
                    {
                        return false;
                    }
                }

            }
            else
            {
                model.CategoryStructID = structId;

                ////Check Duplicate when insert
                //if (categoryStructservice.GetByCategoryIDAndCategoryStructID(model.CategoryID, model.CategoryStructID) != null)
                //{
                //    return false;
                //}

                newId = categoryStructservice.Insert(model);
                if (newId > 0)
                {
                    result = true;
                }
                else
                {
                    return false;
                }
            }
            if (node.Nodes.Count > 0)
            {
                foreach (var subNode in node.Nodes)
                {
                    result = this.UpdateTree(newId, subNode, categoryStructservice);
                    if (!result)
                    {
                        break;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Create Entity from node
        /// </summary>
        /// <param name="node">Node</param>
        /// <returns>Category struct</returns>
        private M_CategoryStruct CreateModel(ITreeData node)
        {
            M_CategoryStruct model = new M_CategoryStruct();

            model.CategoryID = node.Node.CategoryID;
            model.CategoryStructID = node.Node.CategoryStructID;
            model.Level = node.Node.Level;
            model.NumberOrder = node.Node.NumberOrder;

            model.CreateUID = base.LoginInfo.User.ID;
            model.UpdateUID = base.LoginInfo.User.ID;

            if (node.Node.Status == 1 || node.Node.CategoryCD == Constant.CATEGORY_ROOT_CODE)
            {
                //Update Key
                model.ID = int.Parse(node.Node.ID.ToString());
                model.UpdateDate = node.Node.UpdateDate;
            }

            return model;
        }

        /// <summary>
        /// Check list has record
        /// </summary>
        /// <returns></returns>
        public bool GetHasRecord()
        {
            var categories = (IList<CategoryInfo>)this.DataSource;
            int sortField = 3;
            int sortDirec = 1;
            //Show condition
            if (this.ViewState["Condition"] != null)
            {
                Hashtable data = (Hashtable)this.ViewState["Condition"];

                this.ShowCondition(data);

                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
            }
            if (categories == null)
            {
                this.PagingFooter.CurrentPage = this.PagingHeader.CurrentPage = 1;
                this.LoadDataGrid(this.PagingFooter.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                categories = (IList<CategoryInfo>)this.DataSource;
                this.SaveCondition();
                if (categories == null)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Get Default Value
        /// </summary>
        /// <returns></returns>
        private int GetDefaultValuePaging()
        {
            using (DB db = new DB())
            {
                Config_HService service = new Config_HService(db);
                string ret = service.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAGING);
                return string.IsNullOrEmpty(ret) ? 0 : int.Parse(ret);
            }
        }

        /// <summary>
        /// Delete node
        /// </summary>
        /// <param name="data">List tree Data</param>
        /// <param name="id">Id node</param>
        private void DeleteNode(IList<ITreeData> data, long identity)
        {
            int numberOrder = 1;
            foreach (var item in data)
            {
                item.Node.NumberOrder = numberOrder;
                if (item.Node.Identity == identity)
                {
                    if (!this.RemoveNodes.Contains(item))
                    {
                        //Backup node
                        this.RemoveNodes.Add(item);
                    }

                    //Remove node 
                    data.Remove(item);
                    return;
                }
                else
                {
                    this.DeleteNode(item.Nodes, identity);
                }
                numberOrder++;
            }
        }

        /// <summary>
        /// Find node by Id
        /// </summary>
        /// <param name="data">Nodes</param>
        /// <param name="id">Id of node</param>
        /// <param name="level">
        /// Search Location
        /// Level : -1 (Search all level)
        /// Level : 0 (Search Item in level 0
        /// Level : 1
        /// Level : 2
        /// Level : 3
        /// </param>
        /// <returns>Tree data</returns>
        private ITreeData FindNode(IList<ITreeData> data, long identity, int level)
        {
            foreach (ITreeData item in data)
            {
                if (item.Node.Identity == identity)
                {
                    return item;
                }
                else
                {
                    ITreeData result = this.FindNode(item.Nodes, identity, level);
                    if (level > 0)
                    {
                        if (result != null && result.Node.Level == level)
                        {
                            return result;
                        }
                    }
                    else
                    {
                        if (result != null)
                        {
                            return result;
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Find node by catagory code
        /// </summary>
        /// <param name="data">Nodes</param>
        /// <param name="categoryCd">categoryCd of node</param>
        /// <param name="level">
        /// Search Location
        /// Level : -1 (Search all level)
        /// Level : 0 (Search Item in level 0
        /// Level : 1
        /// Level : 2
        /// Level : 3
        /// </param>
        /// <returns>Node data</returns>
        private ITreeData FindNode(IList<ITreeData> data, string categoryCd, int level)
        {
            //ITreeData result = null;
            foreach (ITreeData item in data)
            {
                if (item.Node.CategoryCD == categoryCd)
                {
                    return item;
                }
                else
                {
                    ITreeData result = this.FindNode(item.Nodes, categoryCd, level);
                    if (level > 0)
                    {
                        if (result != null && result.Node.Level == level)
                        {
                            return result;
                        }
                    }
                    else
                    {
                        if (result != null)
                        {
                            return result;
                        }
                    }
                }
            }
            return null;
        }

        #endregion
    }

    [Serializable]
    internal sealed class ITreeData
    {
        public ITreeData()
        {
            this.Nodes = new List<ITreeData>();
        }

        public ITreeData(CategoryStructInfo node, IList<ITreeData> nodes)
        {
            this.Node = node;
            this.Nodes = nodes;
        }

        public CategoryStructInfo Node { get; set; }

        public IList<ITreeData> Nodes { get; set; }

        public string CssStyle { get; set; }
    }
}


﻿using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using OMS.Controls;

using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data;

namespace OMS.Master
{
    /// <summary>
    /// Class Currency Detail
    /// Create Date: 2014/07/28
    /// Create Author: ISV-HUNG
    /// </summary>
    public partial class FrmCurrencyDetail : FrmBaseDetail
    {
        #region Variable

        /// <summary>
        /// Control id will be focused
        /// </summary>
        public string focusControlsID = "";

        //private int PageSizeOnPage = 10;
        #endregion

        #region Constants

        /// <summary>
        /// Page list direction
        /// </summary>
        public const string URL_LIST = "~/Master/FrmCurrencyList.aspx";

        /// <summary>
        /// Date default
        /// </summary>
        public const string DEFAULT_DATE = "01/01/1900";

        /// <summary>
        /// Money code default
        /// </summary>
        public const string DEFAULT_MONEY_CODE = "VND";

        /// <summary>
        /// Max of year
        /// </summary>
        public const int MAX_YEAR = 9999;

        /// <summary>
        /// Max of month
        /// </summary>
        public const int MAX_MONTH = 12;

        /// <summary>
        /// Max of day
        /// </summary>
        public const int MAX_DAY = 31;

        /// <summary>
        /// Min of year
        /// </summary>
        public const int MIN_YEAR = 1900;

        /// <summary>
        /// Min of month
        /// </summary>
        public const int MIN_MONTH = 1;

        /// <summary>
        /// Min of day
        /// </summary>
        public const int MIN_DAY = 1;
        #endregion

        #region Property
        /// <summary>
        /// Get or set ID
        /// </summary>
        public int CurrencyID
        {
            get { return (int)base.ViewState["ID"]; }
            set { base.ViewState["ID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)base.ViewState["OldUpdateDate"]; }
            set { base.ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// DetailLists
        /// </summary>
        public IList<M_Currency_D> DetailLists
        {
            get { return this.GetValueViewState<IList<M_Currency_D>>("DetailLists"); }
            set { ViewState["DetailLists"] = value; }
        }

        /// <summary>
        /// CurrenIndex
        /// </summary>
        public int CurrenIndexPage
        {
            get { return this.GetValueViewState<int>("CurrenIndexPage"); }
            set { ViewState["CurrenIndexPage"] = value; }
        }

        /// <summary>
        /// FileName
        /// </summary>
        public string FileName
        {
            get { return this.GetValueViewState<string>("FileName"); }
            set { ViewState["FileName"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e">EventArgs</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Currency Master";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtMoneyCode.MaxLength = M_Currency_H.MONEY_CODE_MAX_LENGTH;
            this.txtMoneyNameUS.MaxLength = M_Currency_H.MONEY_NAME_MAX_LENGTH;
            this.txtMoneyNameVN.MaxLength = M_Currency_H.MONEY_NAME_MAX_LENGTH;
            this.txtTaxName.MaxLength = M_Currency_H.TAX_NAME_MAX_LENGTH;
            this.txtDecimalNameUS.MaxLength = M_Currency_H.DECIMAL_NAME_MAX_LENGTH;
            this.txtDecimalNameVN.MaxLength = M_Currency_H.DECIMAL_NAME_MAX_LENGTH;

            // Paging footer
            this.PagingFooter.OnClick += this.Paging_Click;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ExchangeRate);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Set default value
                this.CurrenIndexPage = 1;

                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.ViewState["Condition"] = base.PreviousPageViewState["Condition"];

                    //Check mode
                    if (base.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);

                        //Init detail list
                        this.InitDetailList();
                    }
                    else
                    {
                        //Get currency data by ID
                        this.CurrencyID = int.Parse(base.PreviousPageViewState["ID"].ToString());
                        M_Currency_H currency = this.GetCurrency(this.CurrencyID);

                        if (currency != null)
                        {
                            //Show data
                            this.ShowHeaderData(currency);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);

                    //Init detail list
                    this.InitDetailList();
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Edit Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get currency data by ID
            M_Currency_H currency = this.GetCurrency(this.CurrencyID);

            //Check currency
            if (currency != null)
            {
                this.CurrenIndexPage = 1;

                //Show data
                this.ShowHeaderData(currency);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Copy Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get currency data by ID
            M_Currency_H currency = this.GetCurrency(this.CurrencyID);

            //Check Currency
            if (currency != null)
            {
                //Show data
                this.ShowHeaderData(currency);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Delete Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            this.CurrenIndexPage = 1;

            // Paging footer
            this.SetPaging(this.DetailLists);

            //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            //this.PagingFooter.TotalRow = this.DetailLists.Count;

            //this.SetDataSourceWithPaging(this.DetailLists);

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Button Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            var isError = this.CheckInputHeader();//true co loi
            isError = this.CheckInputDetail(false,true,true) ? true: isError;

            //Check input
            if(isError)
            {
                return;
            }

            this.CurrenIndexPage = 1;

            // Paging footer
            this.SetPaging(this.DetailLists);

            //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            //this.PagingFooter.TotalRow = this.DetailLists.Count;

            //this.SetDataSourceWithPaging(this.DetailLists);

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Button Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            var isError = this.CheckInputHeader();//true co loi
            isError = this.CheckInputDetail(false,true,true) ? true : isError;

            //Check input
            if (isError)
            {
                return;
            }

            this.CurrenIndexPage = 1;

            // Paging footer
            this.SetPaging(this.DetailLists);

            //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            //this.PagingFooter.TotalRow = this.DetailLists.Count;

            //this.SetDataSourceWithPaging(this.DetailLists);

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Button Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (this.Mode == Mode.View || this.Mode == Mode.Insert)
            {
                Server.Transfer(URL_LIST);
            }
            else if (this.Mode == Mode.Update || this.Mode == Mode.Copy)
            {
                //Get currency data by ID
                M_Currency_H currency = this.GetCurrency(this.CurrencyID);

                //Check Currency
                if (currency != null)
                {
                    this.CurrenIndexPage = 1;

                    //Show data
                    this.ShowHeaderData(currency);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.txtMoneyCode.Value = string.Empty;
            this.txtMoneyNameUS.Value = string.Empty;
            this.txtMoneyNameVN.Value = string.Empty;
            this.txtDecimalNameVN.Value = string.Empty;
            this.txtDecimalNameUS.Value = string.Empty;
            this.txtTaxName.Value = string.Empty;
            this.chkDecimalType.Checked = false;
            //Set mode
            this.ProcessMode(Mode.Insert);

            //Set current page
            this.CurrenIndexPage = 1;

            //Init detail list
            this.InitDetailList();
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            M_Currency_H currency = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:
                    //Insert Data
                    int newID = 0;
                    ret = this.InsertData(ref newID);
                    if (ret)
                    {
                        //Get currency data by ID
                        currency = this.GetCurrency(newID);
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete Data
                    ret = this.DeleteData();
                    if (!ret)
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get currency data by ID
                        currency = this.GetCurrency(this.CurrencyID);
                    }

                    break;
            }

            if (ret)
            {
                //Show data
                this.ShowHeaderData(currency);

                //Set Mode
                this.ProcessMode(Mode.View);

                //Set Success
                this.Success = true;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get currency header by id
            M_Currency_H currency = this.GetCurrency(this.CurrencyID);
            if (currency != null)
            {
                //Show data
                this.ShowHeaderData(currency);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Button AddRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            if (this.CheckInputDetail(true,false,false))
            {
                return;
            }

            //Get new list from screen
            var listDetail = this.GetDetailList();

            if (listDetail != null && listDetail.Count != 0)
            {
                listDetail.Insert(0, new M_Currency_D() { EffectDate = null, ExpireDate = null, ExchangeRate = null });
            }

            this.DetailLists = listDetail;

            this.CurrenIndexPage = 1;

            //this.InitPagingList(listDetail);

            // Paging footer
            this.SetPaging(listDetail);

            //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            //this.PagingFooter.TotalRow = listDetail.Count;

            ////Process list view
            //this.SetDataSourceWithPaging(listDetail);

            //Set focus
            IDateTextBox dtEffectDate = (IDateTextBox)this.rptListCurrency.Items[0].FindControl("dtEffectDate");
            this.focusControlsID = dtEffectDate.ClientID;
        }

        /// <summary>
        /// Event Button RemoveRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveRow_Click(object sender, EventArgs e)
        {
            //Get new list from screen
            var listDetail = this.GetDetailList();

            //Get list index remove item
            List<int> listDel = new List<int>();
            for (int i = listDetail.Count - 1; i >= 0; i--)
            {
                if (listDetail[i].DelFlag)
                {
                    listDel.Add(i);
                }

                listDetail[i].DelFlag = false;
            }

            //Remove row
            foreach (var item in listDel)
            {

                //Remove row
                listDetail.RemoveAt(item);
            }

            //listDetail[0].ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
            this.ProcessEffectDate(listDetail);

            //Process list view
            this.DetailLists = listDetail;

            // Paging footer
            this.SetPaging(listDetail);

            //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            //this.PagingFooter.TotalRow = listDetail.Count;

            //this.SetDataSourceWithPaging(listDetail);
        }

        ///// <summary>
        ///// Event Button Previous Page
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //protected void btnPrevious_Click(object sender, EventArgs e)
        //{
        //    if (this.CheckInputDetail(true,false,false))
        //    {
        //        return;
        //    }

        //    this.CurrenIndexPage--;

        //    this.SetDataSourceWithPaging(this.DetailLists);
        //}

        ///// <summary>
        ///// Event Button Next Page
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //protected void btnNext_Click(object sender, EventArgs e)
        //{
        //    if (this.CheckInputDetail(true,false,false))
        //    {
        //        return;
        //    }

        //    this.CurrenIndexPage++;

        //    this.SetDataSourceWithPaging(this.DetailLists);
        //}

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                if (this.CheckInputDetail(true, false,false))
                {
                    return;
                }

                this.CurrenIndexPage = int.Parse((sender as LinkButton).CommandArgument);
                //this.InitPagingList(this.DetailLists);

                // Paging footer
                this.SetPaging(this.DetailLists);

                //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
                //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
                //this.PagingFooter.TotalRow = this.DetailLists.Count;

                //this.SetDataSourceWithPaging(this.DetailLists);
            }
        }

        /// <summary>
        /// Event ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptPager_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                ListItem item = (ListItem)e.Item.DataItem;
                HtmlGenericControl li = (HtmlGenericControl)e.Item.FindControl("liPage");
                LinkButton link = (LinkButton)e.Item.FindControl("linkPage");

                if (!item.Enabled)
                {
                    if (string.IsNullOrEmpty(item.Value))
                    {
                        li.Attributes.Add("class", "disabled");
                    }
                    else
                    {
                        li.Attributes.Add("class", "active");
                    }
                    link.Enabled = false;
                }
            }
        }          
        #endregion

        #region Method
        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set mode
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:
                    if (mode == Mode.Update)
                    {
                        this.txtMoneyCode.ReadOnly = true;
                    }
                    else
                    {
                        this.txtMoneyCode.ReadOnly = false;
                    }

                    enable = false;
                    break;

                default:
                    this.txtMoneyCode.ReadOnly = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    enable = true;

                    break;
            }

            //Lock control
            this.txtMoneyNameUS.ReadOnly = enable;
            this.txtMoneyNameVN.ReadOnly = enable;
            this.txtTaxName.ReadOnly = enable;
            this.chkDecimalType.Disabled = enable;
            this.txtDecimalNameUS.ReadOnly = enable;
            this.txtDecimalNameVN.ReadOnly = enable;
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        /// <param name="currency">M_Currency_H</param>
        private void ShowHeaderData(M_Currency_H currency)
        {
            //Display header
            this.CurrencyID = currency.ID;
            this.txtMoneyCode.Value = currency.MoneyCode;
            this.txtMoneyNameUS.Value = currency.MoneyNameUS;
            this.txtMoneyNameVN.Value = currency.MoneyNameVN;
            this.txtTaxName.Value = currency.TaxName;

            if (currency.DecimalType == 1)
            {
                this.chkDecimalType.Checked = true;
            }
            else
            {
                this.chkDecimalType.Checked = false;
            }

            this.txtDecimalNameUS.Value = currency.DecimalNameUS;
            this.txtDecimalNameVN.Value = currency.DecimalNameVN;

            this.OldUpdateDate = currency.UpdateDate;

            //Display detail
            this.ShowDetailData(currency.ID);
        }

        /// <summary>
        /// Show detail data by header id
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void ShowDetailData(int headerID)
        {
            using (DB db = new DB())
            {
                Currency_DService currenceDService = new Currency_DService(db);

                //Get Currency
                IList<M_Currency_D> listDetail = currenceDService.GetByListByHeaderID(headerID);
                if (listDetail != null)
                {
                    if (listDetail.Count != 0)
                    {
                        this.DetailLists = listDetail;
                        //this.InitPagingList(listDetail);

                        // Paging footer
                        this.SetPaging(listDetail);

                        //this.PagingFooter.CurrentPage = this.CurrenIndexPage;
                        //this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
                        //this.PagingFooter.TotalRow = listDetail.Count;

                        //this.SetDataSourceWithPaging(listDetail);
                    }
                }
            }
        }

        /// <summary>
        /// Get Currency header by id
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private M_Currency_H GetCurrency(int id)
        {
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);

                //Get Currency
                return currency_HService.GetByID(id);
            }
        }

        /// <summary>
        /// Check exist Currency by MoneyCode
        /// </summary>
        /// <param name="moneyCode">moneyCode</param>
        /// <returns></returns>
        private bool IsExistMoneyCode(string moneyCode)
        {
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);

                //Get Currency
                return currency_HService.IsExistMoneyCode(moneyCode);
            }
        }

        /// <summary>
        /// Init Detail List
        /// </summary>
        private void InitDetailList()
        {
            //Add data
            IList<M_Currency_D> listDetail = new List<M_Currency_D>();
            listDetail.Add(new M_Currency_D()
            {
                EffectDate = new DateTime(MIN_YEAR, MIN_MONTH, MIN_DAY),
                ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY),
                ExchangeRate = null
            });

            //Process list view
            this.DetailLists = listDetail;

            //this.InitPagingList(listDetail);

            // Paging footer
            this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            this.PagingFooter.TotalRow = listDetail.Count;

            this.rptListCurrency.DataSource = listDetail;
            this.rptListCurrency.DataBind();
        }

        /// <summary>
        /// Set Paging
        /// </summary>
        /// <param name="listDetail"></param>
        private void SetPaging(IList<M_Currency_D> listDetail)
        {
            // Paging footer
            this.PagingFooter.CurrentPage = this.CurrenIndexPage;
            this.PagingFooter.NumberOnPage = Constant.DEFAULT_NUMBER_ROW;
            this.PagingFooter.TotalRow = listDetail.Count;

            //Refresh data
            this.SetDataSourceWithPaging(listDetail);
        }

        ///// <summary>
        ///// Init Paging List
        ///// </summary>
        ///// <param name="listDetail"></param>
        //private void InitPagingList(IList<M_Currency_D> listDetail)
        //{
        //    List<ListItem> pages = new List<ListItem>();

        //    if (listDetail.Count > 1)
        //    {
        //        int pageTotal = (int)Math.Ceiling((double)listDetail.Count / Constant.DEFAULT_NUMBER_ROW);

        //        if (pageTotal > 1)
        //        {
        //            int mod = this.CurrenIndexPage % this.PageSizeOnPage;

        //            int firstPage = 0;
        //            int endPage = 0;

        //            //First Page
        //            if (mod < 7)
        //            {
        //                firstPage = this.CurrenIndexPage - mod;
        //                if (firstPage == 0)
        //                {
        //                    firstPage = 1;
        //                }
        //            }
        //            else
        //            {
        //                firstPage = (this.CurrenIndexPage - mod) + 5;
        //            }

        //            //End Page
        //            endPage = firstPage + this.PageSizeOnPage;
        //            if (endPage > pageTotal)
        //            {
        //                endPage = pageTotal + 1;
        //            }

        //            //First Page
        //            if (endPage - firstPage < this.PageSizeOnPage)
        //            {
        //                firstPage = endPage - this.PageSizeOnPage;
        //                if (firstPage <= 0)
        //                {
        //                    firstPage = 1;
        //                }
        //            }

        //            string prevPage = "1";
        //            string nextPage = pageTotal.ToString();

        //            if (this.CurrenIndexPage == pageTotal)
        //            {
        //                nextPage = string.Empty;
        //            }

        //            if (this.CurrenIndexPage == 1)
        //            {
        //                prevPage = string.Empty;
        //            }

        //            pages.Add(new ListItem("&laquo;", prevPage, !string.IsNullOrEmpty(prevPage)));
        //            for (int i = firstPage; i < endPage; i++)
        //            {
        //                pages.Add(new ListItem(i.ToString(), i.ToString(), i != this.CurrenIndexPage));
        //            }
        //            pages.Add(new ListItem("&raquo;", nextPage, !string.IsNullOrEmpty(nextPage)));
        //        }
        //    }
        //    //else
        //    //{
        //    //    pages.Add(new ListItem(1.ToString(), 1.ToString(), true));
        //    //}

        //    this.rptPaging.DataSource = pages;
        //    this.rptPaging.DataBind();
        //}

        /// <summary>
        /// Get header from screen
        /// </summary>
        /// <param name="header">M_Currency_H</param>
        private void GetHeader(M_Currency_H header)
        {
            header.MoneyCode = this.txtMoneyCode.Value;
            header.MoneyNameUS = this.txtMoneyNameUS.Value;
            header.MoneyNameVN = this.txtMoneyNameVN.Value;
            header.TaxName = this.txtTaxName.Value;
            if (this.chkDecimalType.Checked)
            {
                header.DecimalType = 1;
            }
            else
            {
                header.DecimalType = 0;
            }
            header.DecimalNameUS = this.txtDecimalNameUS.Value;
            header.DecimalNameVN = this.txtDecimalNameVN.Value;
            header.CreateUID = this.LoginInfo.User.ID;
            header.UpdateUID = this.LoginInfo.User.ID;
            if (this.Mode == Mode.Update)
            {
                header.UpdateDate = this.OldUpdateDate;
            }
        }

        /// <summary>
        /// Get detail list from screen
        /// </summary>
        /// <param name="isAsynDto"></param>
        /// <param name="isRemoveEmpty"></param>
        /// <returns>list currency detail</returns>
        private IList<M_Currency_D> GetDetailList(bool isRemoveEmpty = false)
        {
            IList<M_Currency_D> results = this.DetailLists;

            foreach (RepeaterItem item in this.rptListCurrency.Items)
            {
                HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");
                IDateTextBox dtEffectDate = (IDateTextBox)item.FindControl("dtEffectDate");
                IDateTextBox dtExpireDate = (IDateTextBox)item.FindControl("dtExpireDate");
                INumberTextBox inumExchangeRate = (INumberTextBox)item.FindControl("inumExchangeRate");

                var addItem = results[(this.CurrenIndexPage - 1) * Constant.DEFAULT_NUMBER_ROW + item.ItemIndex];

                //Delete flag
                addItem.DelFlag = (chkDelFlg.Checked) ? true : false;

                //Effect date
                addItem.EffectDate = dtEffectDate.Value;

                //Exchange rate
                addItem.ExchangeRate = inumExchangeRate.Value;
            }

            if (isRemoveEmpty)
            {
                return results.Where(d => (d.EffectDate.HasValue || d.ExchangeRate.HasValue)).ToList();
            }
            else
            {
                return results;
            }
        }

        /// <summary>
        /// Check Duplicate
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        /// <param name="listData"></param>
        /// <returns></returns>
        private bool CheckDuplicate(int index,DateTime value, IList<M_Currency_D> listData)
        {
            bool ret = false;
            for (int i = index+1; i < listData.Count; i++)
            {
                var item = listData[i];
                if (!item.EffectDate.HasValue)
                {
                    continue;
                }
                if (item.EffectDate.Value.CompareTo(value) == 0)
                {
                    ret = true;
                    break;
                }
            }
            return ret;
        }

        /// <summary>
        /// Check header
        /// </summary>
        /// <returns></returns>
        private bool CheckInputHeader()
        {
            //Money Code
            if (this.txtMoneyCode.IsEmpty)
            {
                base.SetMessage(this.txtMoneyCode.ID, M_Message.MSG_REQUIRE, "Money Code");
            }
            else
            {
                //Check Currency by MoneyCode
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.IsExistMoneyCode(this.txtMoneyCode.Value))
                    {
                        base.SetMessage(this.txtMoneyCode.ID, M_Message.MSG_EXIST_CODE, "Money Code");
                    }
                }
            }

            //MoneyNameUS
            if (this.txtMoneyNameUS.IsEmpty)
            {
                base.SetMessage(this.txtMoneyNameUS.ID, M_Message.MSG_REQUIRE, "Money Name (EN)");
            }

            //MoneyNameVN
            if (this.txtMoneyNameVN.IsEmpty)
            {
                base.SetMessage(this.txtMoneyNameVN.ID, M_Message.MSG_REQUIRE, "Money Name (VN)");
            }

            //TaxName
            if (this.txtTaxName.IsEmpty)
            {
                base.SetMessage(this.txtTaxName.ID, M_Message.MSG_REQUIRE, "Tax Name");
            }

            //DecimalType
            if (this.chkDecimalType.Checked)
            {
                //DecimalName (EN)
                if (this.txtDecimalNameUS.IsEmpty)
                {
                    base.SetMessage(this.txtDecimalNameUS.ID, M_Message.MSG_REQUIRE, "Decimal Name (EN)");
                }

                //DecimalName (VN)
                if (this.txtDecimalNameVN.IsEmpty)
                {
                    base.SetMessage(this.txtDecimalNameVN.ID, M_Message.MSG_REQUIRE, "Decimal Name (VN)");
                }
            }

            return base.HaveError;
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <param name="isRequiredInput"></param>
        /// <param name="isCheckDuplicate"></param>
        /// <param name="isProcessDate"></param>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInputDetail(bool isRequiredInput,bool isCheckDuplicate,bool isProcessDate)
        {
            //IDictionary<DateTime, int> lstDup = new Dictionary<DateTime, int>();

            var firstIndex = -1;

            var listDetail = this.GetDetailList();

            for (int i = 0; i < listDetail.Count; i++)
            {
                var index = i % Constant.DEFAULT_NUMBER_ROW;

                var item = listDetail[i];

                if (!item.EffectDate.HasValue && !item.ExchangeRate.HasValue)
                {
                    continue;
                }

                if (isRequiredInput && !item.EffectDate.HasValue)
                {
                    base.SetMessage(string.Format("dtEffectDate_{0}", index), M_Message.MSG_REQUIRE_GRID, "Effect Date", i + 1);
                }
                else
                {
                    if (!item.EffectDate.HasValue && !item.ExchangeRate.HasValue)
                    {
                        continue;
                    }

                    if (!item.EffectDate.HasValue)
                    {
                        base.SetMessage(string.Format("dtEffectDate_{0}", index), M_Message.MSG_REQUIRE_GRID, "Effect Date", i + 1);
                    }
                    else if (isCheckDuplicate && this.CheckDuplicate(i,item.EffectDate.Value,listDetail))
                    {
                        base.SetMessage(string.Format("dtEffectDate_{0}", index), M_Message.MSG_DUPLICATE_GRID, "Effect Date", i + 1);
                    }
                    //else if (isCheckDuplicate && lstDup.ContainsKey(item.EffectDate.Value))//Duplicate check
                    //{
                    //    base.SetMessage(string.Format("dtEffectDate_{0}", lstDup[item.EffectDate.Value]), M_Message.MSG_DUPLICATE_GRID, "Effect Date", lstDup[item.EffectDate.Value] + 1);
                    //    //lstDup.Remove(item.EffectDate.Value);
                    //    //lstDup.Add(item.EffectDate.Value, index);

                    //    //if (base.HaveError && firstIndex == -1)
                    //    //{
                    //    //    firstIndex = lstDup[item.EffectDate.Value]+1;
                    //    //}
                    //}
                    else
                    {
                        //if (!lstDup.ContainsKey(item.EffectDate.Value))
                        //{
                        //    lstDup.Add(item.EffectDate.Value, index);
                        //}

                        DateTime minDate = new DateTime(MIN_YEAR, MIN_MONTH, MIN_DAY);
                        DateTime maxDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);

                        if (index != listDetail.Count - 1 && item.EffectDate.Value.CompareTo(minDate) < 0)
                        {
                            base.SetMessage(string.Format("dtEffectDate_{0}", index), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Effect Date", minDate.ToString("dd/MM/yyyy"), i + 1);
                        }
                        else if (index != listDetail.Count - 1 && item.EffectDate.Value.CompareTo(maxDate) > 0)
                        {
                            base.SetMessage(string.Format("dtEffectDate_{0}", index), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Effect Date", maxDate.ToString("dd/MM/yyyy"), i + 1);
                        }
                        else
                        {
                            if (!item.ExchangeRate.HasValue)
                            {
                                base.SetMessage(string.Format("inumExchangeRate_{0}", index), M_Message.MSG_REQUIRE_GRID, "Exchange Rate", i + 1);
                            }
                            else if (item.ExchangeRate.Value.CompareTo(M_Currency_D.EXCHANGE_RATE_MAX_VALUE) > 0)//Exchange Rate less than max value check
                            {
                                base.SetMessage(string.Format("inumExchangeRate_{0}", index), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Exchange Rate", M_Currency_D.EXCHANGE_RATE_MAX_VALUE, i + 1);
                            }
                            else if (item.ExchangeRate.Value == 0)
                            {
                                base.SetMessage(string.Format("inumExchangeRate_{0}", index), M_Message.MSG_GREATER_THAN_GRID, "Exchange Rate", 0, i + 1);
                            }
                        }
                    }
                }

                if (base.HaveError && firstIndex == -1)
                {
                    firstIndex = i + 1;
                }
            }

            if (!base.HaveError)
            {
                if (isProcessDate)
                {
                    this.SortList(listDetail);
                    this.ProcessEffectDate(listDetail);
                }
            }
            else
            {
                this.CurrenIndexPage = firstIndex / Constant.DEFAULT_NUMBER_ROW + (firstIndex % Constant.DEFAULT_NUMBER_ROW == 0 ? 0 : 1);
            }

            this.SetPaging(listDetail);
            //this.SetDataSourceWithPaging(listDetail);

            //Check error
            return base.HaveError;
        }

        /// <summary>
        /// SortList
        /// </summary>
        /// <param name="listSort"></param>
        private void SortList(IList<M_Currency_D> listSort)
        {
            if (listSort.Count == 3)
            {
                if (listSort[1].EffectDate == null)
                {
                    return;
                }
                if (listSort[0].EffectDate < listSort[1].EffectDate)
                {
                    var temp = listSort[0].Clone();

                    listSort[0].DelFlag = listSort[1].DelFlag;
                    listSort[0].EffectDate = listSort[1].EffectDate;
                    listSort[0].ExchangeRate = listSort[1].ExchangeRate;

                    listSort[1].DelFlag = temp.DelFlag;
                    listSort[1].EffectDate = temp.EffectDate;
                    listSort[1].ExchangeRate = temp.ExchangeRate;
                }
            }
            else
            {
                for (int i = 0; i < listSort.Count - 2; i++)
                {
                    var itemBefore = listSort[i];
                    if (!itemBefore.EffectDate.HasValue)
                    {
                        continue;
                    }
                    for (int k = i + 1; k < listSort.Count - 1; k++)
                    {
                        var itemAfter = listSort[k];
                        if (!itemAfter.EffectDate.HasValue)
                        {
                            continue;
                        }

                        if (itemBefore.EffectDate.Value < itemAfter.EffectDate.Value)
                        {
                            var temp = itemBefore.Clone();

                            itemBefore.DelFlag = itemAfter.DelFlag;
                            itemBefore.EffectDate = itemAfter.EffectDate;
                            itemBefore.ExchangeRate = itemAfter.ExchangeRate;

                            itemAfter.DelFlag = temp.DelFlag;
                            itemAfter.EffectDate = temp.EffectDate;
                            itemAfter.ExchangeRate = temp.ExchangeRate;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0  && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Process effect date
        /// </summary>
        /// <param name="listDetail"></param>
        private void ProcessEffectDate(IList<M_Currency_D> listDetail)
        {
            if (listDetail.Count < 2)
            {
                listDetail[0].ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                return;
            }
            else if (listDetail.Count > 2)
            {
                bool isHaveData = false;
                for (int index = listDetail.Count - 2; index >= 0; index--)
                {
                    var item = listDetail[index];

                    if (!item.EffectDate.HasValue && !item.ExchangeRate.HasValue)
                    {
                        item.ExpireDate = null;
                        continue;
                    }
                    isHaveData = true;

                    //Find index previous not empty data
                    var preIndex = this.FindPreIndexNotEmptyData(index, listDetail);

                    //Find index next not empty data
                    var nextIndex = this.FindNextIndexNotEmptyData(index, listDetail);

                    var itemNext = listDetail[nextIndex];

                    var effectDate = new DateTime();

                    if (item.EffectDate.HasValue)
                    {
                        effectDate = item.EffectDate.Value.AddDays(-1);

                        //Set for Expire date with previous index
                        if (item.EffectDate.Value.CompareTo(itemNext.EffectDate) != 0)
                        {
                            itemNext.ExpireDate = effectDate;
                        }
                        else
                        {
                            itemNext.ExpireDate = item.EffectDate;
                        }

                        //Set for effect date with curren index
                        if (preIndex != -1)
                        {
                            var itemPre = listDetail[preIndex];
                            effectDate = itemPre.EffectDate.Value.AddDays(-1);

                            if (item.EffectDate.Value.CompareTo(itemPre.EffectDate.Value) != 0)
                            {
                                item.ExpireDate = effectDate;
                            }
                            else
                            {
                                item.ExpireDate = itemPre.EffectDate;
                            }
                        }
                        else
                        {
                            item.ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                        }
                    }
                    else
                    {
                        //Set for effect date with curren index
                        if (preIndex != -1)
                        {
                            var itemPre = listDetail[preIndex];
                            effectDate = itemPre.EffectDate.Value.AddDays(-1);
                        }
                        else
                        {
                            effectDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                        }

                        itemNext.ExpireDate = effectDate;
                    }
                }

                if (!isHaveData)
                {
                    listDetail[listDetail.Count - 1].ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                }
                else
                {
                    if (listDetail[0].EffectDate.HasValue && listDetail[0].ExchangeRate.HasValue)
                    {
                        listDetail[0].ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                    }
                }
            }
            else
            {
                var item0 = listDetail[0];
                var item1 = listDetail[1];

                //Set date
                if (item0.EffectDate.HasValue)
                {
                    item1.ExpireDate = item0.EffectDate.Value.AddDays(-1);
                    item0.ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                }
                else
                {
                    item1.ExpireDate = new DateTime(MAX_YEAR, MAX_MONTH, MAX_DAY);
                }
            }
            this.DetailLists = listDetail;
        }

        /// <summary>
        /// Is input date
        /// </summary>
        /// <param name="index">index</param>
        /// <returns></returns>
        private bool IsInputDate(int index, DateTime valueCheck)
        {
            bool ret = true;
            //check current date must greater than previous date
            for (int i = 0; i <= index - 1; i++)
            {
                IDateTextBox dtEffectDate = (IDateTextBox)this.rptListCurrency.Items[i].FindControl("dtEffectDate");
                if (!dtEffectDate.Value.HasValue)
                {
                    continue;
                }
                if (valueCheck < dtEffectDate.Value.Value)
                {
                    ret = false;
                    break;
                }
            }

            for (int i = index + 1; i < this.rptListCurrency.Items.Count; i++)
            {
                IDateTextBox dtEffectDate = (IDateTextBox)this.rptListCurrency.Items[i].FindControl("dtEffectDate");
                if (!dtEffectDate.Value.HasValue)
                {
                    continue;
                }
                if (valueCheck > dtEffectDate.Value.Value)
                {
                    ret = false;
                    break;
                }
            }

            return ret;
        }

        /// <summary>
        /// Find pre index with not empty data
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="listDetail">listDetail</param>
        /// <returns></returns>
        private int FindPreIndexNotEmptyData(int index, IList<M_Currency_D> listDetail)
        {
            for (int i = index - 1; i >= 0; i--)
            {
                if (listDetail[i].EffectDate.HasValue && listDetail[i].ExchangeRate.HasValue)
                {
                    return i;
                }
            }

            return -1;
        }

        /// <summary>
        /// Find next index with not empty data
        /// </summary>
        /// <param name="index">index</param>
        /// <param name="listDetail">listDetail</param>
        /// <returns></returns>
        private int FindNextIndexNotEmptyData(int index, IList<M_Currency_D> listDetail)
        {
            for (int i = index + 1; i < listDetail.Count; i++)
            {
                if (listDetail[i].EffectDate.HasValue && listDetail[i].ExchangeRate.HasValue)
                {
                    return i;
                }
            }

            return -1;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        private bool InsertData(ref int newId)
        {
            try
            {
                int ret = 0;

                M_Currency_H header = new M_Currency_H();
                this.GetHeader(header);

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Currency_HService headerService = new Currency_HService(db);
                    ret = headerService.Insert(header);

                    if (ret == 1)
                    {
                        newId = db.GetIdentityId<M_Currency_H>();

                        IList<M_Currency_D> detail = this.GetDetailList(true);

                        Currency_DService detailService = new Currency_DService(db);
                        foreach (var item in detail)
                        {
                            item.HID = newId;
                            detailService.Insert(item);
                        }
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_CURRENCY_H_UN1))
                {
                    this.SetMessage(this.txtMoneyCode.ID, M_Message.MSG_EXIST_CODE, "Money Code");
                }

                return false;
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Currency_H header = this.GetCurrency(this.CurrencyID);
                if (header != null)
                {
                    this.GetHeader(header);

                    //Update
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        if (header.Status == DataStatus.Changed || this.IsDetailChange(db))
                        {
                            //Update header
                            Currency_HService headerService = new Currency_HService(db);
                            ret = headerService.Update(header);

                            if (ret == 1)
                            {
                                //Update detail
                                Currency_DService detailService = new Currency_DService(db);
                                detailService.Delete(this.CurrencyID);

                                IList<M_Currency_D> detail = this.GetDetailList(true);
                                foreach (var item in detail)
                                {
                                    item.HID = this.CurrencyID;
                                    detailService.Insert(item);
                                }
                            }

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }

                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Currency_DService detailService = new Currency_DService(db);
                    detailService.Delete(this.CurrencyID);

                    Currency_HService headerService = new Currency_HService(db);
                    ret = headerService.Delete(this.CurrencyID, this.OldUpdateDate);

                    if (ret == 1)
                    {
                        db.Commit();
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_CURRENCY) ||
                    ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CURRENCY) ||

                    ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_CURRENCY) ||
                    ex.Message.Contains(Models.Constant.T_SALES_H_FK_CURRENCY) ||

                    ex.Message.Contains(Models.Constant.T_PURCHASE_H_FK_CURRENCY) ||

                    ex.Message.Contains(Models.Constant.T_BILLING_H_FK_CURRENCY) ||

                    ex.Message.Contains(Models.Constant.T_DELIVERY_H_FK_CURRENCY) ||

                    ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_COST) ||
                    ex.Message.Contains(Models.Constant.M_PRODUCT_FK_CURRENCYID_SELL)
                    )
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Money Code " + this.txtMoneyCode.Value);
                }

                return false;
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check detail change data
        /// </summary>
        /// <returns></returns>
        private bool IsDetailChange(DB db)
        {
            //Get list from data
            IList<M_Currency_D> listDetailData;

            Currency_DService detailService = new Currency_DService(db);
            listDetailData = detailService.GetByListByHeaderID(this.CurrencyID);

            //Get list from screen
            IList<M_Currency_D> listDetailSrceen = this.GetDetailList(true);

            //Check count change
            if (listDetailSrceen.Count != listDetailData.Count)
            {
                return true;
            }
            else
            {
                for (int i = 0; i < listDetailSrceen.Count; i++)
                {
                    var oldData = listDetailData[i];
                    var newData = listDetailSrceen[i];

                    //Check effect date change
                    if (oldData.EffectDate.Value.CompareTo(newData.EffectDate) != 0)
                    {
                        return true;
                    }

                    //Check expire date change
                    if (oldData.ExpireDate.Value.CompareTo(newData.ExpireDate) != 0)
                    {
                        return true;
                    }

                    //Check exchange rate change
                    if (oldData.ExchangeRate != newData.ExchangeRate)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Set data source with paging
        /// </summary>
        /// <param name="listDetail"></param>
        private void SetDataSourceWithPaging(IList<M_Currency_D> listDetail)
        {
            var newListPaging = listDetail.Skip(Constant.DEFAULT_NUMBER_ROW * (this.CurrenIndexPage - 1)).Take(Constant.DEFAULT_NUMBER_ROW).ToList();

            this.rptListCurrency.DataSource = newListPaging;
            this.rptListCurrency.DataBind();
        }

        /// <summary>
        /// Create File
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="listData"></param>
        private void CreateFile(string fileName, IList<M_Currency_D> listData)
        {
            var data = new DataTable("data");
            data.Columns.Add("EffectDate", typeof(string));
            data.Columns.Add("ExpireDate", typeof(string));
            data.Columns.Add("ExchangeRate", typeof(string));

            foreach (var item in listData)
            {
                var effectDate = item.EffectDate.Value.ToString(Constants.FMT_DATETIME);
                var expireDate = item.ExpireDate.Value.ToString(Constants.FMT_DATETIME);
                var exchangeRate = string.Empty;
                if (item.ExchangeRate.HasValue)
                {
                    exchangeRate = item.ExchangeRate.Value.ToString();
                }

                data.Rows.Add(effectDate, expireDate, exchangeRate);
            }

            data.WriteXml(string.Format("{0}/Upload/{1}", Server.MapPath("~"), fileName));
        }

        /// <summary>
        /// ReadFile
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private IList<M_Currency_D> ReadFile(string fileName)
        {
            var data = new DataTable("data");
            data.Columns.Add("EffectDate", typeof(string));
            data.Columns.Add("ExpireDate", typeof(string));
            data.Columns.Add("ExchangeRate", typeof(string));

            data.ReadXml(string.Format("{0}/Upload/{1}", Server.MapPath("~"), fileName));

            IList<M_Currency_D> result = new List<M_Currency_D>();

            foreach (DataRow item in data.Rows)
            {
                M_Currency_D itemAdd = new M_Currency_D();
                itemAdd.EffectDate = CommonUtil.ParseDate(item["EffectDate"].ToString(), Constants.FMT_DATETIME);
                itemAdd.ExpireDate = CommonUtil.ParseDate(item["ExpireDate"].ToString(), Constants.FMT_DATETIME);
                if (!string.IsNullOrEmpty(item["ExchangeRate"].ToString()))
                {
                    itemAdd.ExchangeRate = CommonUtil.ParseDecimal(item["ExchangeRate"].ToString());
                }

                result.Add(itemAdd);
            }

            return result;
        }
        #endregion
    }
}
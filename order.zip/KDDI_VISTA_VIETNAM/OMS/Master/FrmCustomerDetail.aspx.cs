﻿using System;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using System.Data.SqlClient;

namespace OMS.Master
{
    /// <summary>
    /// Customer Detail
    /// ISV:NGUYEN
    /// </summary>
    public partial class FrmCustomerDetail : FrmBaseDetail
    {
        private const string URL_LIST = "~/Master/FrmCustomerList.aspx";
        #region Constant

        /// <summary>
        /// View state key: ID
        /// </summary>
        public const string C_ID_VIEWSTATE = "ViewID";

        /// <summary>
        /// View state key: Mode
        /// </summary>
        public const string C_MODE_VIEWSTATE = "OnMode";

        /// <summary>
        /// View state key: Update date
        /// </summary>
        public const string C_UPDATE_DATE_VIEWSTATE = "UpdDate";

        #endregion

        #region Property

        /// <summary>
        /// Get or set CustomerID
        /// </summary>
        public int CustomerID
        {
            get { return (int)ViewState["CustomerID"]; }
            set { ViewState["CustomerID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Customer Master";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName1.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;
            this.txtCustomerName2.MaxLength = M_Customer.CUSTOMER_NAME2_MAX_LENGTH;
            this.txtAddress1.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAddress2.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAddress3.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAddress4.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAddress5.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAddress6.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtRepresent.MaxLength = M_Customer.REPRESENT_MAX_LENGTH;
            this.txtPosition1.MaxLength = M_Customer.POSITION_MAX_LENGTH;
            this.txtPosition2.MaxLength = M_Customer.POSITION_MAX_LENGTH;
            this.txtEmail.MaxLength = M_Customer.EMAIL_ADDRESS_MAX_LENGTH;
            this.txtTel.MaxLength = M_Customer.TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Customer.FAX_MAX_LENGTH;
            this.txtContactPerson.MaxLength = M_Customer.CONTACT_PERSON_MAX_LENGTH;
            this.txtContactTel.MaxLength = M_Customer.CONTACT_TEL_MAX_LENGTH;
            this.txtTaxCode.MaxLength = M_Customer.TAX_CODE_MAX_LENGTH;
            this.txtCustomerBank.MaxLength = M_Customer.CUSTOMER_BANK_MAX_LENGTH;
            this.txtAccountNo.MaxLength = M_Customer.ACCOUNT_NO_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);
        }

        /// <summary>
        /// Page Load
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Customer);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set Mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get customer data by id
                        this.CustomerID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Customer customer = this.GetCustomer(this.CustomerID);

                        //Check customer
                        if (customer != null)
                        {
                            //Show data
                            this.ShowData(customer);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get customer by id
            M_Customer customer = this.GetCustomer(this.CustomerID);

            //Check customer
            if (customer != null)
            {
                //Show data
                this.ShowData(customer);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get customer
            M_Customer customer = this.GetCustomer(this.CustomerID);

            //Check customer
            if (customer != null)
            {
                //Show data
                this.ShowData(customer);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get customer by id
            M_Customer customer = this.GetCustomer(this.CustomerID);

            //Check customer
            if (customer != null)
            {
                //Show data
                this.ShowData(customer);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        //Get customer data by code
                        M_Customer customer = this.GetCustomer(this.txtCustomerCD.Value);

                        //Show data
                        this.ShowData(customer);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete Data
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_Customer customer = this.GetCustomer(this.CustomerID);

                        //Show data
                        this.ShowData(customer);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get customer by id
            M_Customer customer = this.GetCustomer(this.CustomerID);
            if (customer != null)
            {
                //Show data
                this.ShowData(customer);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        #endregion

        #region Methods

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtCustomerCD.ReadOnly = true;
                        this.chkStatusFlag.Disabled = false;
                    }
                    else
                    {
                        this.txtCustomerCD.ReadOnly = false;
                        this.chkStatusFlag.Disabled = true;
                        this.chkStatusFlag.Checked = true;
                    }

                    enable = false;

                    break;

                default:

                    this.txtCustomerCD.ReadOnly = true;
                    this.chkStatusFlag.Disabled = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    enable = true;
                    break;

            }

            //Lock control
            this.txtCustomerName1.ReadOnly = enable;
            this.txtCustomerName2.ReadOnly = enable;
            this.txtAddress1.ReadOnly = enable;
            this.txtAddress2.ReadOnly = enable;
            this.txtAddress3.ReadOnly = enable;
            this.txtAddress4.ReadOnly = enable;
            this.txtAddress5.ReadOnly = enable;
            this.txtAddress6.ReadOnly = enable;
            this.txtRepresent.ReadOnly = enable;
            this.txtPosition1.ReadOnly = enable;
            this.txtPosition2.ReadOnly = enable;
            this.txtEmail.ReadOnly = enable;
            this.txtTel.ReadOnly = enable;
            this.txtFax.ReadOnly = enable;
            this.txtContactPerson.ReadOnly = enable;
            this.txtContactTel.ReadOnly = enable;
            this.txtTaxCode.ReadOnly = enable;
            this.txtCustomerBank.ReadOnly = enable;
            this.txtAccountNo.ReadOnly = enable;
        }

        /// <summary>
        /// Show data to the screen
        /// </summary>
        /// <param name="customer">customer</param>
        private void ShowData(M_Customer customer)
        {
            if (customer != null)
            {
                this.txtCustomerCD.Value = Utilities.EditDataUtil.ToFixCodeShow(customer.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                this.txtCustomerName1.Value = customer.CustomerName1;
                this.txtCustomerName2.Value = customer.CustomerName2;
                this.txtAddress1.Value = customer.CustomerAddress1;
                this.txtAddress2.Value = customer.CustomerAddress2;
                this.txtAddress3.Value = customer.CustomerAddress3;
                this.txtAddress4.Value = customer.CustomerAddress4;
                this.txtAddress5.Value = customer.CustomerAddress5;
                this.txtAddress6.Value = customer.CustomerAddress6;
                this.txtRepresent.Value = customer.Represent;
                this.txtPosition1.Value = customer.Position1;
                this.txtPosition2.Value = customer.Position2;
                this.txtEmail.Value = customer.EmailAddress;
                this.txtTel.Value = customer.Tel;
                this.txtFax.Value = customer.FAX;
                this.txtContactPerson.Value = customer.ContactPerson;
                this.txtContactTel.Value = customer.ContactTel;
                this.txtTaxCode.Text = customer.TAXCode;
                this.txtCustomerBank.Value = customer.CustomerBank;
                this.txtAccountNo.Value = customer.AccountCode;
                this.chkStatusFlag.Checked = customer.StatusFlag == 0 ? true : false;

                //Save CustomerID and UpdateDate
                this.CustomerID = customer.ID;
                this.OldUpdateDate = customer.UpdateDate;
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Customer customer = new M_Customer();
                customer.CustomerCD = this.txtCustomerCD.Value;
                customer.CustomerName1 = this.txtCustomerName1.Value;
                customer.CustomerName2 = this.txtCustomerName2.Value;
                customer.CustomerAddress1 = this.txtAddress1.Value;
                customer.CustomerAddress2 = this.txtAddress2.Value;
                customer.CustomerAddress3 = this.txtAddress3.Value;
                customer.CustomerAddress4 = this.txtAddress4.Value;
                customer.CustomerAddress5 = this.txtAddress5.Value;
                customer.CustomerAddress6 = this.txtAddress6.Value;
                customer.Represent = this.txtRepresent.Value;
                customer.Position1 = this.txtPosition1.Value;
                customer.Position2 = this.txtPosition2.Value;
                customer.EmailAddress = this.txtEmail.Value;
                customer.Tel = this.txtTel.Value;
                customer.FAX = this.txtFax.Value;
                customer.ContactPerson = this.txtContactPerson.Value;
                customer.ContactTel = this.txtContactTel.Value;
                customer.TAXCode = this.txtTaxCode.Value;
                customer.CustomerBank = this.txtCustomerBank.Value;
                customer.AccountCode = this.txtAccountNo.Value;
                customer.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                customer.CreateUID = this.LoginInfo.User.ID;
                customer.UpdateUID = this.LoginInfo.User.ID;

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    CustomerService customerSer = new CustomerService(db);

                    //Insert customer
                    customerSer.Insert(customer);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                {
                    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                    return false;
                }

                if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN))
                {
                    this.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_EXIST_CODE, "Customer Code");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Customer customer = this.GetCustomer(this.txtCustomerCD.Value);
                if (customer != null)
                {
                    //Create model
                    customer.CustomerCD = this.txtCustomerCD.Value;
                    customer.CustomerName1 = this.txtCustomerName1.Value;
                    customer.CustomerName2 = this.txtCustomerName2.Value;
                    customer.CustomerAddress1 = this.txtAddress1.Value;
                    customer.CustomerAddress2 = this.txtAddress2.Value;
                    customer.CustomerAddress3 = this.txtAddress3.Value;
                    customer.CustomerAddress4 = this.txtAddress4.Value;
                    customer.CustomerAddress5 = this.txtAddress5.Value;
                    customer.CustomerAddress6 = this.txtAddress6.Value;
                    customer.Represent = this.txtRepresent.Value;
                    customer.Position1 = this.txtPosition1.Value;
                    customer.Position2 = this.txtPosition2.Value;
                    customer.EmailAddress = this.txtEmail.Value;
                    customer.Tel = this.txtTel.Value;
                    customer.FAX = this.txtFax.Value;
                    customer.ContactPerson = this.txtContactPerson.Value;
                    customer.ContactTel = this.txtContactTel.Value;
                    customer.TAXCode = this.txtTaxCode.Value;
                    customer.CustomerBank = this.txtCustomerBank.Value;
                    customer.AccountCode = this.txtAccountNo.Value;
                    customer.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                    customer.UpdateDate = this.OldUpdateDate;
                    customer.UpdateUID = this.LoginInfo.User.ID;

                    //Update customer                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        CustomerService customerSer = new CustomerService(db);

                        //Update customer
                        if (customer.Status == DataStatus.Changed)
                        {
                            ret = customerSer.Update(customer);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                {
                    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;

                //Delete customer                    
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    CustomerService customerSer = new CustomerService(db);
                    ret = customerSer.DeleteCustomer(this.CustomerID, this.OldUpdateDate);
                    db.Commit();
                }
                //Check result Delete
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CUSTOMER) ||
                    ex.Message.Contains(Models.Constant.T_SALES_H_FK_CUSTOMER) ||
                    ex.Message.Contains(Models.Constant.T_DELIVERY_H_FK_CUSTOMER) ||
                    ex.Message.Contains(Models.Constant.T_BILLING_H_FK_CUSTOMER)
                    )
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Customer Code " + this.txtCustomerCD.Value);
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Get Customer by ID
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(int customerID)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByID(customerID);
            }
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomer(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //customerCD
            if (this.txtCustomerCD.IsEmpty)
            {
                this.SetMessage(txtCustomerCD.ID, M_Message.MSG_REQUIRE, "Customer Code");
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.txtCustomerCD.Value.Equals(M_Customer.CUSTOMER_CODE_SUPPORT))
                    {
                        this.SetMessage(txtCustomerCD.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Customer Code", this.txtCustomerCD.Value);

                    }
                    else if (this.GetCustomer(this.txtCustomerCD.Value) != null)
                    {
                        this.SetMessage(txtCustomerCD.ID, M_Message.MSG_EXIST_CODE, "Customer Code");
                    }
                }
            }

            //CustomerName1
            if (this.txtCustomerName1.IsEmpty)
            {
                this.SetMessage(this.txtCustomerName1.ID, M_Message.MSG_REQUIRE, "Customer Name 1");
            }

            //CustomerName2
            //if (this.txtCustomerName2.IsEmpty)
            //{
            //    this.SetMessage(this.txtCustomerName2.ID, M_Message.MSG_REQUIRE, "Customer Name 2");
            //}

            //Check Tel
            if (!this.txtTel.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtTel.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtTel.ID, M_Message.MSG_INCORRECT_FORMAT, "Tel");
                }
            }

            //Check Fax
            if (!this.txtFax.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtFax.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtFax.ID, M_Message.MSG_INCORRECT_FORMAT, "Fax");
                }
            }

            //Check Email
            if (!this.txtEmail.IsEmpty)
            {
                if (!CheckDataUtil.IsEmail(this.txtEmail.Value))
                {
                    this.SetMessage(this.txtEmail.ID, M_Message.MSG_INCORRECT_FORMAT, "Email");
                }
            }
            //Check Contact Tel
            if (!this.txtContactTel.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtContactTel.Value, Constants.PATTERN_TEL))
                {
                    this.SetMessage(this.txtContactTel.ID, M_Message.MSG_INCORRECT_FORMAT, "Contact Tel");
                }
            }

            //Check TaxCode
            if (!this.txtTaxCode.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtTaxCode.Value, Constants.PATTERN_TAX_CODE))
                {
                    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_INCORRECT_FORMAT, "Tax Code");
                }
                else if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.GetTaxCode(this.txtTaxCode.Value))
                    {
                        this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                    }
                }
                else if (this.Mode == Mode.Update)
                {
                    if (!this.GetTaxCodeWithCustomerCD(this.txtCustomerCD.Value, this.txtTaxCode.Value))
                    {
                        if (this.GetTaxCode(this.txtTaxCode.Value))
                        {
                            this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                        }
                    }
                }
            }

            //Check Account No.
            if (!this.txtAccountNo.IsEmpty)
            {
                if (!CheckDataUtil.IsCheckFormat(this.txtAccountNo.Value, Constants.PATTERN_ACCOUNT_NO))
                {
                    this.SetMessage(this.txtAccountNo.ID, M_Message.MSG_INCORRECT_FORMAT, "Account No");
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check TaxCode 
        /// </summary>
        /// <param name="taxCode">taxCode</param>
        /// <returns></returns>
        private bool GetTaxCode(string taxCode)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get taxcode
                return customerSer.IsExistTaxCode(taxCode);
            }
        }

        /// <summary>
        /// Check TaxCode Exist With CustomerCD
        /// </summary>
        /// <param name="customerCD">customerCD</param>
        /// <param name="taxCode">TaxCode</param>
        /// <returns></returns>
        private bool GetTaxCodeWithCustomerCD(string customerCD, string taxCode)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.IsExistTaxCDWithCustomerCD(customerCD, taxCode);
            }
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.txtCustomerCD.Value = string.Empty;
            this.txtCustomerName1.Value = string.Empty;
            this.txtCustomerName2.Value = string.Empty;
            this.txtAddress1.Value = string.Empty;
            this.txtAddress2.Value = string.Empty;
            this.txtAddress3.Value = string.Empty;
            this.txtAddress4.Value = string.Empty;
            this.txtAddress5.Value = string.Empty;
            this.txtAddress6.Value = string.Empty;
            this.txtRepresent.Value = string.Empty;
            this.txtPosition1.Value = string.Empty;
            this.txtPosition2.Value = string.Empty;
            this.txtEmail.Value = string.Empty;
            this.txtTel.Value = string.Empty;
            this.txtFax.Value = string.Empty;
            this.txtContactPerson.Value = string.Empty;
            this.txtContactTel.Value = string.Empty;
            this.txtTaxCode.Value = string.Empty;
            this.txtCustomerBank.Value = string.Empty;
            this.txtAccountNo.Value = string.Empty;
        }
        #endregion

        #region Web Methods

        /// <summary>
        /// Format Customer Code
        /// </summary>
        /// <param name="in1">CustomerCD</param>
        /// <returns>CustomerCD</returns>
        [System.Web.Services.WebMethod]
        public static string FormatCustomerCD(string in1)
        {
            try
            {
                var customerCd = in1;
                var customerCdShow = in1;
                customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                customerCdShow = EditDataUtil.ToFixCodeShow(customerCd, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                var onlyCd = new
                {
                    txtCustomerCD = customerCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
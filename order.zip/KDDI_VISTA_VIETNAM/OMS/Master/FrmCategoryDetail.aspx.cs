﻿using System;
using System.Data.SqlClient;

using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using System.Web.UI.WebControls;

namespace OMS.Master
{
    /// <summary>
    /// Form:   Category detail
    /// Author: ISV-Phuong
    /// </summary>
    public partial class FrmCategoryDetail : FrmBaseDetail
    {
        private const string URL_LIST = "~/Master/FrmCategoryList.aspx";
        #region Property

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Category Master";
            base.FormSubTitle = "Detail";

            //Init Max Length                        
            this.txtCategoryCode.MaxLength = M_Category.CATEGORY_CODE_MAX_LENGTH;
            this.txtCategoryName.MaxLength = M_Category.CATEGORY_NAME_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Category);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            bool temp;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                temp = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }
            if (!temp)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["DataID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["DataID"].ToString());
                        M_Category data = this.GetCategory(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get data
            M_Category data = this.GetCategory(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            M_Category data = this.GetCategory(this.DataID);

            //Check data
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }


        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            M_Category data = this.GetCategory(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Format Category Code
        /// </summary>
        /// <param name="in1">Category Code</param>
        /// <returns>Category Name</returns>
        [System.Web.Services.WebMethod]
        public static string FormatCategoryCD(string in1)
        {
            try
            {
                var categoryCD = in1;
                categoryCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(categoryCD, M_Category.CATEGORY_CODE_MAX_LENGTH);
                var onlyCd = new
                {
                    txtCategoryCode = categoryCD
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            M_Category data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetCategory(this.txtCategoryCode.Value);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete vendor
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;
                case Utilities.Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetCategory(this.txtCategoryCode.Value);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }

        }


        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get vendor
            M_Category data = this.GetCategory(this.DataID);
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.txtCategoryCode.Value = string.Empty;
            this.txtCategoryName.Value = string.Empty;
        }
        #endregion

        #region Methods

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                    this.txtCategoryCode.ReadOnly = false;
                    this.txtCategoryName.ReadOnly = false;
                    break;

                case Mode.Update:
                    this.txtCategoryCode.ReadOnly = true;
                    this.txtCategoryName.ReadOnly = false;
                    break;

                default:
                    this.txtCategoryCode.ReadOnly = true;
                    this.txtCategoryName.ReadOnly = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//

                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">M_Category</param>
        private void ShowData(M_Category category)
        {
            //Show data
            if (category != null)
            {
                this.txtCategoryCode.Value = category.CategoryCD;
                this.txtCategoryName.Value = category.CategoryName;

                //Save UserID and UpdateDate
                this.DataID = category.ID;
                this.OldUpdateDate = category.UpdateDate;
            }
        }

        /// <summary>
        /// Get Category by Category id
        /// </summary>
        /// <param name="categoryId">Category id</param>
        /// <returns>Category data</returns>
        private M_Category GetCategory(int categoryId)
        {
            using (DB db = new DB())
            {
                CategoryService service = new CategoryService(db);

                //Get User
                return service.GetByID(categoryId);
            }
        }

        /// <summary>
        /// Get Category by Category code
        /// </summary>
        /// <param name="categoryCd">CategoryCd</param>
        /// <returns>Category data</returns>
        private M_Category GetCategory(string categoryCd)
        {
            using (DB db = new DB())
            {
                CategoryService service = new CategoryService(db);

                //Get User
                return service.GetByCD(categoryCd);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //CategoryCode
            if (this.txtCategoryCode.IsEmpty)
            {
                this.SetMessage("txtCategoryCode", M_Message.MSG_REQUIRE, "Category Code");
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    if (this.txtCategoryCode.Value == Constant.CATEGORY_ROOT_CODE)
                    {
                        //Diff '0000'
                        this.SetMessage(this.txtCategoryCode.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Category Code", Constant.CATEGORY_ROOT_CODE);
                    }
                    else
                    {
                        // Check catagory
                        if (this.GetCategory(this.txtCategoryCode.Value) != null)
                        {
                            this.SetMessage("txtCategoryCode", M_Message.MSG_EXIST_CODE, "Category Code");
                        }
                    }

                }
            }

            //CategoryName
            if (this.txtCategoryName.IsEmpty)
            {
                this.SetMessage("txtCategoryName", M_Message.MSG_REQUIRE, "Category Name");
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Category data = new M_Category();
                data.CategoryCD = this.txtCategoryCode.Value;
                data.CategoryName = this.txtCategoryName.Value;

                data.CreateUID = base.LoginInfo.User.ID;
                data.UpdateUID = base.LoginInfo.User.ID;

                //Insert Category
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    CategoryService serive = new CategoryService(db);

                    //Insert Category
                    serive.Insert(data);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_CATEGORY_UN))
                {
                    this.SetMessage(this.txtCategoryCode.ID, M_Message.MSG_EXIST_CODE, "Category Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Category data = this.GetCategory(this.txtCategoryCode.Value);
                if (data != null)
                {
                    //Create model
                    data.CategoryName = this.txtCategoryName.Value;

                    data.UpdateDate = this.OldUpdateDate;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Update category
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        CategoryService service = new CategoryService(db);

                        //Update category
                        if (data.Status == DataStatus.Changed)
                        {
                            ret = service.Update(data);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    CategoryService service = new CategoryService(db);

                    //Delete Vendor
                    ret = service.Delete(this.DataID, this.OldUpdateDate);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Constant.M_PRODUCT_FK_CATEGORY_STRUCT_ID) || 
                    ex.Message.Contains(Constant.M_CATEGORYSTRUCT_FK_CATEGORYID))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Category Code " + this.txtCategoryCode.Value);
                }

                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using System.Xml;
using System.Data;

namespace OMS.Master
{
    /// <summary>
    /// Currency Rate List
    /// Create Date: 2014/07/24
    /// Create Author: ISV-HUNG
    /// </summary>
    public partial class FrmCurrencyList : FrmBaseList
    {
        #region Constants

        /// <summary>
        /// Money code default
        /// </summary>
        public const string DEFAULT_MONEY_CODE = "VND";

        #endregion

        #region Property
        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Currency Master";
            base.FormSubTitle = "List";

            // Header grid sort
            this.HeaderGrid.OnSortClick += this.Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += this.PagingFooter_Click;

            // Paging header
            this.PagingHeader.OnClick += this.PagingHeader_Click;
            this.PagingHeader.OnPagingClick += this.PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtMoneyCode.MaxLength = M_Currency_H.MONEY_CODE_MAX_LENGTH;
            this.txtMoneyNameUS.MaxLength = M_Currency_H.MONEY_NAME_MAX_LENGTH;
            //this.txtMoneyNameVN.MaxLength = M_Currency_H.MONEY_NAME_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ExchangeRate);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            //if (!base.CheckAuthorityMaster(FormId.ExchangeRate, AuthorTypeMaster.View))
            //{
            //    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            //}

            if (!base.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (base.PreviousPage != null)
                {
                    if (base.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)base.PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Event Search
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// RSS
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">CommandEventArgs</param>
        //protected void btnRSS_Click(object sender, CommandEventArgs e)
        //{
        //    try
        //    {
        //        #region Get ExchangeRate Online

        //        using (var db = new DB(IsolationLevel.Serializable))
        //        {
        //            var cfgHService = new Config_HService(db);
        //            var crcHService = new Currency_HService(db);
        //            var crcDService = new Currency_DService(db);

        //            var rssLink = cfgHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_RSS);

        //            var xmlReader = new XmlTextReader(rssLink);

        //            var ds = new DataSet();
        //            ds.ReadXml(xmlReader);

        //            var header = ds.Tables["ExrateList"].Rows[0];
        //            var exrateListId = (int)header["ExrateList_Id"];
        //            var exrateDate = Convert.ToDateTime(header["DateTime"]).Date;

        //            var dbList = crcHService.GetAllByDate(exrateDate);

        //            foreach (var exrate in dbList)
        //            {
        //                if (exrate.EffectDate != exrateDate)
        //                {
        //                    var rssItem = ds.Tables["Exrate"].Select(string.Format("ExrateList_Id={0} AND CurrencyCode ='{1}'", exrateListId, exrate.MoneyCode));
        //                    if (rssItem.Length > 0)
        //                    {
        //                        var exchangeRate = decimal.Parse(rssItem[0]["Sell"].ToString());
        //                        //delete
        //                        crcDService.Delete(exrate.ID, exrate.EffectDate);

        //                        //update 
        //                        var udtItem = new M_Currency_D
        //                        {
        //                            HID = exrate.ID,
        //                            EffectDate = exrate.EffectDate,
        //                            ExpireDate = exrateDate.AddDays(-1),
        //                            ExchangeRate = exchangeRate
        //                        };

        //                        crcDService.Insert(udtItem);

        //                        //insert
        //                        var newItem = new M_Currency_D
        //                        {
        //                            HID = exrate.ID,
        //                            EffectDate = exrateDate,
        //                            ExpireDate = exrate.ExpireDate,
        //                            ExchangeRate = exchangeRate
        //                        };
        //                        crcDService.Insert(newItem);
        //                    }
        //                }
        //            }
        //            db.Commit();
        //        }
        //        #endregion

        //        // Refresh sort header
        //        this.HeaderGrid.SortDirec = "1";
        //        this.HeaderGrid.SortField = "1";

        //        // Refresh load grid
        //        this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }

        //}

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">CommandEventArgs</param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">CommandEventArgs</param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //ID
            base.ViewState["ID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Paging change list
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Paging change list
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sort change list
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }
        #endregion

        #region Method
        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtMoneyCode.ID, this.txtMoneyCode.Value);
            hash.Add(this.txtMoneyNameUS.ID, this.txtMoneyNameUS.Value);
            //hash.Add(this.txtMonkeyNameVN.ID, this.txtMoneyNameVN.Value);
            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Get condition Save
        /// </summary>
        /// <param name="data">Data</param>
        private void ShowCondition(Hashtable data)
        {
            this.txtMoneyCode.Value = data[this.txtMoneyCode.ID].ToString();
            this.txtMoneyNameUS.Value = data[this.txtMoneyNameUS.ID].ToString();
            //this.txtMoneyNameVN.Value = data[this.txtMoneyNameVN.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            //----------------Add 2014/12/29 ISV-HUNG-----------------------//
            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        /// <summary>
        /// Init control
        /// </summary>
        private void InitData()
        {
            // Header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            //this.btnNew.Attributes.Add("class", this.CheckAuthorityMaster(FormId.ExchangeRate, AuthorTypeMaster.New) ? Constants.CSS_BTN_NEW : Constants.CSS_BTN_NEW_DISABLED);
            //this.btnNew.Attributes.Add("class", this._authority.IsMasterNew ? Constants.CSS_BTN_NEW : Constants.CSS_BTN_NEW_DISABLED);
            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
        }

        /// <summary>
        /// Load data gird
        /// </summary>
        /// <param name="pageIndex">Page Index</param>
        /// <param name="numOnPage">Number On Page</param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int totalRow = 0;
            IList<CurrencyInfo> listCurrencyInfo;

            //Get data
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);

                //Get total row
                totalRow = currency_HService.GetTotalRow(this.txtMoneyCode.Value, this.txtMoneyNameUS.Value);

                //Get list
                listCurrencyInfo = currency_HService.GetList(this.txtMoneyCode.Value, this.txtMoneyNameUS.Value,
                                                                    pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listCurrencyInfo.Count == 0)
            {
                this.rptCurrencyList.DataSource = null;
            }
            else
            {
                // Paging header
                this.PagingHeader.RowNumFrom = int.Parse(listCurrencyInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listCurrencyInfo[listCurrencyInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // Paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // Header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Money Name", "Money Name (VN)", "Effect Date", "Expire Date", "N#Exchange Rate", "Tax Name" }, new string[] { "Money Name (VN)" });

                // Detail
                this.rptCurrencyList.DataSource = listCurrencyInfo;
            }

            this.rptCurrencyList.DataBind();
        }
        #endregion
    }
}
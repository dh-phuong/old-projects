﻿using System;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using System.Text.RegularExpressions;
using OMS.Controls;

namespace OMS.Master
{
    /// <summary>
    /// User Detail
    /// ISV-TRUC    
    /// </summary>
    public partial class FrmUserDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmUserList.aspx";
        #endregion

        #region Property

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int UserID
        {
            get { return (int)ViewState["UserID"]; }
            set { ViewState["UserID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// DefaultMaxUser
        /// </summary>
        public int DefaultMaxActiveUser
        {
            get { return (int)ViewState["DefaultMaxActiveUser"]; }
            set { ViewState["DefaultMaxActiveUser"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "User Master";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtGroupCD.MaxLength = M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH;
            this.txtGroupNm.MaxLength = M_GroupUser_H.GROUP_NAME_MAX_LENGTH;
            this.txtLoginID.MaxLength = M_User.LOGIN_ID_MAX_LENGTH;
            this.txtPassword.MaxLength = M_User.PASSWORD_MAX_LENGTH;
            this.txtUserCode.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtUserName1.MaxLength = M_User.USER_NAME_1_MAX_LENGTH;
            this.txtUserName2.MaxLength = M_User.USER_NAME_2_MAX_LENGTH;
            this.txtPosition1.MaxLength = M_User.POSITION_1_MAX_LENGTH;
            this.txtPosition2.MaxLength = M_User.POSITION_2_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.User);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            //Get Default Data
            this.GetDefaultValue();

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.UserID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_User user = this.GetUser(this.UserID, new DB());

                        //Check user
                        if (user != null)
                        {
                            //Show data
                            this.ShowData(user);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get User
            M_User user = this.GetUser(this.UserID, new DB());

            //Check user
            if (user != null)
            {
                //Show data
                this.ShowData(user);

                //Clear loginID and password
                this.txtLoginID.Value = string.Empty;
                this.txtPassword.Attributes.Add("value", string.Empty);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get User
            M_User user = this.GetUser(this.UserID, new DB());

            //Check user
            if (user != null)
            {
                //Show data
                this.ShowData(user);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.ResetGroupName();

            var password = this.GetPassword(this.txtPassword);
            if (!string.IsNullOrEmpty(password))
            {
                password = Security.Instance.Encrypt(password);
            }
            this.txtPassword.Value = password;
            this.txtPassword.Attributes.Add("value", this.txtPassword.Value);

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.ResetGroupName();
            var password = this.GetPassword(this.txtPassword);
            if (!string.IsNullOrEmpty(password))
            {
                password = Security.Instance.Encrypt(password);
            }
            this.txtPassword.Value = password;
            this.txtPassword.Attributes.Add("value", this.txtPassword.Value);

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.txtUserCode.Value = string.Empty;
            this.txtUserName1.Value = string.Empty;
            this.txtUserName2.Value = string.Empty;
            this.txtPosition1.Value = string.Empty;
            this.txtPosition2.Value = string.Empty;
            this.txtLoginID.Value = string.Empty;
            this.txtPassword.Value = string.Empty;
            this.txtPassword.Attributes.Add("value", string.Empty);

            this.txtGroupCD.Value = string.Empty;
            this.txtGroupNm.Value = string.Empty;
            this.chkStatusFlag.Checked = true;
            //Set mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            M_User user = this.GetUser(this.UserID, new DB());

            //Check user
            if (user != null)
            {
                //Show data
                this.ShowData(user);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        M_User user = this.GetUser(this.txtUserCode.Value, new DB());

                        //Show data
                        this.ShowData(user);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_User user = this.GetUser(this.UserID, new DB());

                        //Show data
                        this.ShowData(user);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;

            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Get Default Value
        /// </summary>
        private void GetDefaultValue()
        {
            using (DB db = new DB())
            {
                Config_HService configHSer = new Config_HService(db);
                this.DefaultMaxActiveUser = int.Parse(configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_MAX_ACTIVE_USER));
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtUserCode.ReadOnly = true;
                        this.chkStatusFlag.Disabled = false;
                    }
                    else
                    {
                        this.txtUserCode.ReadOnly = false;
                        this.chkStatusFlag.Disabled = true;
                        this.chkStatusFlag.Checked = true;
                    }

                    enable = false;

                    break;

                default:

                    this.txtUserCode.ReadOnly = true;
                    this.chkStatusFlag.Disabled = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    //---------------Add 2014/12/29 ISV-HUNG--------------------//
                    enable = true;
                    break;
            }

            //Lock control
            this.txtUserName1.ReadOnly = enable;     //
            this.txtUserName2.ReadOnly = enable;     //
            this.txtPosition1.ReadOnly = enable;     //
            this.txtPosition2.ReadOnly = enable;     //
            this.txtLoginID.ReadOnly = enable;       //
            this.txtPassword.ReadOnly = enable;      //
            this.btnSearchGroup.Disabled = enable; //
            this.txtGroupCD.ReadOnly = enable;       //

        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(M_User user)
        {
            M_GroupUser_H grp = null;
            //Get data
            using (DB db = new DB())
            {
                GroupUserService groupSer = new GroupUserService(db);

                //Get Group User
                grp = groupSer.GetByGroupID(user.GroupID);
            }
            //Show data
            if (user != null)
            {

                this.txtUserCode.Value = Utilities.EditDataUtil.ToFixCodeShow(user.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtUserName1.Value = user.UserName1;
                this.txtUserName2.Value = user.UserName2;
                this.txtPosition1.Value = user.Position1;
                this.txtPosition2.Value = user.Position2;
                this.txtGroupCD.Value = grp != null ? Utilities.EditDataUtil.ToFixCodeShow(grp.GroupCD, M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH) : string.Empty;
                this.txtGroupNm.Value = grp.GroupName;
                this.txtLoginID.Value = user.LoginID;

                this.txtPassword.Value = Security.Instance.Encrypt(user.Password);
                this.txtPassword.Attributes.Add("value", this.txtPassword.Value);
                this.chkStatusFlag.Checked = user.StatusFlag == 0 ? true : false;

                //Save UserID and UpdateDate
                this.UserID = user.ID;
                this.OldUpdateDate = user.UpdateDate;
            }
        }

        /// <summary>
        /// Get User BY User ID
        /// </summary>
        /// <param name="userID">UserID</param>
        /// <returns>User</returns>
        private M_User GetUser(int userID, DB db)
        {
            UserService userSer = new UserService(db);

            //Get User
            return userSer.GetByID(userID);
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUser(string userCD, DB db, bool includeDelete = true)
        {
            UserService userSer = new UserService(db);

            //Get User
            return userSer.GetByUserCD(userCD, includeDelete);

        }

        /// <summary>
        /// Get User By User Code and Login ID
        /// </summary>
        /// <param name="userCD"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private M_User GetUser(string userCD, string loginID, DB db)
        {
            UserService userSer = new UserService(db);

            //Get User
            return userSer.GetByKey(userCD, loginID);
        }

        /// <summary>
        /// Get User By LoginID
        /// </summary>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private M_User GetUserByLoginID(string loginID, DB db)
        {
            UserService userSer = new UserService(db);

            //Get User
            return userSer.GetByLoginID(loginID);
        }

        /// <summary>
        /// Get Count Active User
        /// </summary>
        /// <returns></returns>
        private int GetCountActiveUser()
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get Count Active User
                return userSer.GetCountActiveUser();
            }
        }

        /// <summary>
        /// Get group by group code
        /// </summary>
        /// <param name="groupCD"></param>
        /// <returns></returns>
        private M_GroupUser_H GetGroup(string groupCD)
        {
            using (DB db = new DB())
            {
                GroupUserService grpSer = new GroupUserService(db);

                //Get Group User
                return grpSer.GetByGroupCD(groupCD);
            }
        }

        /// <summary>
        /// Get Group By Group ID
        /// </summary>
        /// <param name="groupID"></param>
        /// <returns></returns>
        private M_GroupUser_H GetGroup(int groupID)
        {
            using (DB db = new DB())
            {
                GroupUserService grpSer = new GroupUserService(db);

                //Get Group User
                return grpSer.GetByGroupID(groupID);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                //UserCD
                if (this.txtUserCode.IsEmpty)
                {
                    this.SetMessage(this.txtUserCode.ID, M_Message.MSG_REQUIRE, "User Code");
                }
                else
                {
                    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                    {
                        if (this.txtUserCode.Value == Constant.M_USER_DEFAULT_CODE)
                        {
                            //Diff '0000'
                            this.SetMessage(this.txtUserCode.ID, M_Message.MSG_MUST_BE_DIFFERENT, "User Code", Constant.M_USER_DEFAULT_CODE);
                        }
                        else
                        {
                            // Check user by userCD 
                            if (this.GetUser(this.txtUserCode.Value, db) != null)
                            {
                                this.SetMessage(this.txtUserCode.ID, M_Message.MSG_EXIST_CODE, "User Code");
                            }
                        }
                    }
                }

                //UserName1
                if (this.txtUserName1.IsEmpty)
                {
                    this.SetMessage(this.txtUserName1.ID, M_Message.MSG_REQUIRE, "User Name 1");
                }

                //UserName2
                if (this.txtUserName2.IsEmpty)
                {
                    this.SetMessage(this.txtUserName2.ID, M_Message.MSG_REQUIRE, "User Name 2");
                }

                //GroupCD
                if (this.txtGroupCD.IsEmpty)
                {
                    this.SetMessage(this.txtGroupCD.ID, M_Message.MSG_REQUIRE, "Group Code");
                }
                else
                {
                    //check group by groupCD
                    if (this.GetGroup(this.txtGroupCD.Value) == null)
                    {
                        this.SetMessage(this.txtGroupCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Group Code");
                    }
                }

                //LoginID
                if (this.txtLoginID.IsEmpty)
                {
                    this.SetMessage(this.txtLoginID.ID, M_Message.MSG_REQUIRE, "Login-ID");
                }
                else
                {
                    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                    {
                        //check user by LoginID 
                        if (this.GetUserByLoginID(this.txtLoginID.Value, db) != null)
                        {
                            this.SetMessage(this.txtLoginID.ID, M_Message.MSG_EXIST_CODE, "Login-ID");
                        }
                    }
                    else if (this.Mode == Mode.Update)
                    {
                        //Check userCd and LoginId exist
                        if (this.GetUser(this.txtUserCode.Value, this.txtLoginID.Value, db) == null)
                        {
                            //UserCd and LoginId not exist, check exist loginID
                            if (this.GetUserByLoginID(this.txtLoginID.Value, db) != null)
                            {
                                this.SetMessage(this.txtLoginID.ID, M_Message.MSG_EXIST_CODE, "Login-ID");
                            }
                        }
                    }
                }
                var password = this.GetPassword(this.txtPassword);
                //Password
                if (this.txtPassword.IsEmpty)
                {
                    this.SetMessage(this.txtPassword.ID, M_Message.MSG_REQUIRE, "Password");
                }
                else if (password.Length < 8 || Regex.Matches(password, "[a-zA-Z]").Count == 0 || Regex.Matches(password, "[0-9]").Count == 0)
                {
                    this.SetMessage(this.txtPassword.ID, M_Message.MSG_PASSWORD_RULE);
                }

                //Condition input is correct
                //Check max active user
                if (!base.HaveError)
                {
                    //Insert New User
                    if (this.Mode == Mode.Copy || this.Mode == Mode.Insert)
                    {
                        if (this.GetCountActiveUser() >= this.DefaultMaxActiveUser)
                        {
                            this.SetMessage(this.txtUserCode.ID, M_Message.MSG_LESS_THAN_EQUAL, "All user", this.DefaultMaxActiveUser);
                        }
                    }

                    //Update Status Of User Deleted->Not Delete
                    //this.chkStatusFlag.Checked = true: On-> Status = 0, this.chkStatusFlag.Checked = false: Off-> Status = 1
                    if (this.Mode == Mode.Update)
                    {
                        M_User u = this.GetUser(this.txtUserCode.Value, db);
                        if (u != null)
                        {
                            u.StatusFlag = short.Parse(this.chkStatusFlag.Checked ? ((short)DeleteFlag.NotDelete).ToString() : ((short)DeleteFlag.Deleted).ToString());
                            if (u.Status == DataStatus.Changed && u.StatusFlag == (short)DeleteFlag.NotDelete)//statusFlag changed : delete ~~> not delete
                            {
                                if (this.GetCountActiveUser() >= this.DefaultMaxActiveUser)
                                {
                                    this.SetMessage(this.txtUserName1.ID, M_Message.MSG_LESS_THAN_EQUAL, "All user", this.DefaultMaxActiveUser);
                                }
                            }
                        }
                    }

                }
            }
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_User user = new M_User();
                user.UserCD = this.txtUserCode.Value;
                user.UserName1 = this.txtUserName1.Value;
                user.UserName2 = this.txtUserName2.Value;
                user.Position1 = this.txtPosition1.Value;
                user.Position2 = this.txtPosition2.Value;
                user.LoginID = this.txtLoginID.Value;
                user.Password = this.GetPassword(this.txtPassword);
                user.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                user.CreateUID = this.LoginInfo.User.ID;
                user.UpdateUID = this.LoginInfo.User.ID;

                //Insert User
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    UserService userSer = new UserService(db);
                    GroupUserService groupSer = new GroupUserService(db);

                    //Get Group User
                    M_GroupUser_H groupUser = groupSer.GetByGroupCD(this.txtGroupCD.Value);
                    if (groupUser != null)
                    {
                        user.GroupID = groupUser.ID;
                    }

                    //Insert User
                    userSer.Insert(user);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_USER_UN_CODE))
                {
                    this.SetMessage(this.txtUserCode.ID, M_Message.MSG_EXIST_CODE, "User Code");
                }

                if (ex.Message.Contains(Models.Constant.M_USER_UN_LOGINID))
                {
                    this.SetMessage(this.txtLoginID.ID, M_Message.MSG_EXIST_CODE, "Login-ID");
                }

                if (ex.Message.Contains(Models.Constant.M_USER_FK_GROUPID))
                {
                    this.SetMessage(this.txtGroupCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Group");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    M_User user = this.GetUser(this.txtUserCode.Value, db);
                    if (user != null)
                    {
                        //Create model
                        user.UserCD = this.txtUserCode.Value;
                        user.UserName1 = this.txtUserName1.Value;
                        user.UserName2 = this.txtUserName2.Value;
                        user.Position1 = this.txtPosition1.Value;
                        user.Position2 = this.txtPosition2.Value;
                        user.LoginID = this.txtLoginID.Value;
                        user.Password = this.GetPassword(this.txtPassword);
                        user.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                        user.UpdateDate = this.OldUpdateDate;
                        user.UpdateUID = this.LoginInfo.User.ID;

                        //Update User                    

                        UserService userSer = new UserService(db);
                        GroupUserService groupSer = new GroupUserService(db);

                        //Get Group User
                        M_GroupUser_H groupUser = groupSer.GetByGroupCD(this.txtGroupCD.Value);
                        if (groupUser != null)
                        {
                            user.GroupID = groupUser.ID;
                        }

                        //Update User
                        if (user.Status == DataStatus.Changed)
                        {
                            ret = userSer.Update(user);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_USER_UN_LOGINID))
                {
                    this.SetMessage(this.txtLoginID.ClientID, M_Message.MSG_EXIST_CODE, "Login-ID");
                }

                if (ex.Message.Contains(Models.Constant.M_USER_FK_GROUPID))
                {

                    this.SetMessage(this.txtGroupCD.ClientID, M_Message.MSG_NOT_EXIST_CODE, "Group");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Reset Group Name
        /// </summary>
        private void ResetGroupName()
        {
            this.txtGroupNm.Value = string.Empty;
            if (!this.txtGroupCD.IsEmpty)
            {
                using (DB db = new DB())
                {
                    GroupUserService groupSer = new GroupUserService(db);
                    M_GroupUser_H grp = groupSer.GetByGroupCD(this.txtGroupCD.Value);
                    if (grp != null)
                    {
                        this.txtGroupNm.Value = grp.GroupName;
                    }
                }
            }
        }

        /// <summary>
        /// Get Password from textbox
        /// </summary>
        /// <param name="txtPassword"></param>
        /// <returns></returns>
        protected string GetPassword(ITextBox txtPassword)
        {
            try
            {
                return Security.Instance.Decrypt(txtPassword.Value);
            }
            catch (Exception)
            {
                return txtPassword.Value;
            }
        }
        #endregion

        #region Web Methods

        /// <summary>
        /// Get Group Name By Group Code
        /// </summary>
        /// <param name="groupCd">Group Code</param>
        /// <returns>Group Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetGroupName(string in1)
        {
            var groupCd = in1;
            var groupCdShow = in1;
            groupCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(groupCd, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH);
            groupCdShow = EditDataUtil.ToFixCodeShow(groupCd, M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);

            try
            {
                using (DB db = new DB())
                {
                    GroupUserService grpSer = new GroupUserService(db);
                    M_GroupUser_H model = grpSer.GetByGroupCD(groupCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            groupCD = groupCdShow,
                            groupNm = model.GroupName
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var groupCD = new
                    {
                        groupCD = groupCdShow
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(groupCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
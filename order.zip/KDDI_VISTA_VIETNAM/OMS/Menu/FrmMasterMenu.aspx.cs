﻿using System;
using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using System.Collections.Generic;

namespace OMS.Menu
{
    public partial class FrmMasterMenu : FrmBase
    {
        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Main Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";

            bool temp;
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                temp = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }

            base.SetAuthority(FormId.Customer);
            this.btnFrmCustomerList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.Vendor);
            this.btnFrmVendorList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.Product);
            this.btnFrmProductList.Attributes.Add("class", base._authority.IsMasterView && temp ? enableClass : disableClass);
            base.SetAuthority(FormId.Category);
            this.btnFrmCategoryList.Attributes.Add("class", base._authority.IsMasterView && temp ? enableClass : disableClass);
            base.SetAuthority(FormId.CategoryStruct);
            this.btnFrmCategoryStruct.Attributes.Add("class", base._authority.IsMasterView && temp ? enableClass : disableClass);
            base.SetAuthority(FormId.Unit);
            this.btnFrmUnitList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.ConditionTemplate);
            this.btnFrmConditionList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.User);
            this.btnFrmUserList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.GroupUser);
            this.btnFrmGroupUserList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.ExchangeRate);
            this.btnFrmCurrencyList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.CompanyInfo);
            this.btnFrmCompanyInfo.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.Setting);
            this.btnFrmSetting.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            base.SetAuthority(FormId.Information);
            this.btnFrmInformation.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
            
            this.btnFrmConfigList.Attributes.Add("class", base.IsAdmin() ? enableClass : disableClass);                       
        }

        #endregion

    }
}
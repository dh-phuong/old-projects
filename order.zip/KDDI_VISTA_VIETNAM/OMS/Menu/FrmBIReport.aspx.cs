﻿using System;
using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using System.Collections.Generic;

namespace OMS.Menu
{
    public partial class FrmBIReport : FrmBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";

            base.SetAuthority(FormId.ContractPeriod);
            this.btnFrmContractPeriod.Attributes.Add("class", base._authority.IsContractPeriodView ? enableClass : disableClass);
        }
    }
}
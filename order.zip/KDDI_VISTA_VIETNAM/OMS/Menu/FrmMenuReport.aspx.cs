﻿using System;

namespace OMS.Menu
{
    public partial class FrmMenuReport : FrmBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}
﻿using System;
using System.Collections.Generic;

using OMS.Models;
using OMS.DAC;
using System.Collections;
using OMS.Utilities;

namespace OMS.Menu
{
    public partial class FrmMainMenu : FrmBase
    {

        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Main Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            IList<M_Information> data;

            //Get data
            using (DB db = new DB())
            {
                InformationService service = new InformationService(db);
                data = service.GetAll();                
            }

            this.rptData.DataSource = data;
            this.rptData.DataBind();


            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";

            base.SetAuthority(FormId.Quotation);
            this.btnQuotation.Attributes.Add("class", base._authority.IsQuotationView ? enableClass : disableClass);

            base.SetAuthority(FormId.Sales);
            this.btnSales.Attributes.Add("class", base._authority.IsSalesView ? enableClass : disableClass);

            base.SetAuthority(FormId.Purchase);
            this.btnPurchase.Attributes.Add("class", base._authority.IsPurchaseView ? enableClass : disableClass);

            base.SetAuthority(FormId.Delivery);
            this.btnDelivery.Attributes.Add("class", base._authority.IsDeliveryView ? enableClass : disableClass);

            base.SetAuthority(FormId.Bill);
            this.btnBilling.Attributes.Add("class", base._authority.IsBillingView ? enableClass : disableClass);
        }

        #endregion
    }
}
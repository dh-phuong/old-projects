﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using OMS.Controls;
using OMS.DAC;
using OMS.Models;
using OMS.UserControls;
using OMS.Utilities;

namespace OMS.Search
{
    public partial class FrmQuotationProductSearch : FrmBaseList
    {
        #region Property

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set PagingInfo
        /// </summary>
        private Hashtable OldPagingInfo
        {
            get { return (Hashtable)ViewState["OldPagingInfo"]; }
            set { ViewState["OldPagingInfo"] = value; }
        }

        #endregion Property

        #region Variable

        /// <summary>
        /// ExchangeRateList
        /// </summary>
        private IList<DropDownModel> _currencyList;

        #endregion Variable

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            #region Category

            this.cmbCategory1.SelectedIndexChanged += (sender, arg) =>
                {
                    var categoryId = int.Parse(this.cmbCategory1.SelectedValue);
                    if (categoryId == -1)
                    {
                        this.SetComboByLevel(this.cmbCategory1, 1);
                        this.SetBlankCombo(this.cmbCategory2);
                        this.SetBlankCombo(this.cmbCategory3);
                    }
                    else
                    {
                        this.SetComboFromCategory1(this.cmbCategory2, categoryId, 2, "-1");
                        this.SetBlankCombo(this.cmbCategory3);
                    }

                    this.FocusControlId = this.cmbCategory1.ClientID;
                    this.Collapse = "in";
                };

            this.cmbCategory2.SelectedIndexChanged += (sender, arg) =>
            {
                int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
                int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);

                if (categoryId1 != -1)
                {
                    if (categoryId2 != -1)
                    {
                        this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, "-1");
                    }
                    else
                    {
                        this.SetBlankCombo(this.cmbCategory3);
                    }
                }
                this.FocusControlId = this.cmbCategory2.ClientID;
                this.Collapse = "in";
            };

            #endregion Category

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;
            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
            this.btnClear.ServerClick += (sender, arg) =>
            {
                this.Clear();
            };

            //Get Default Data
            this.GetDefaultData();
            this.InitMaxLength();
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.InitDropDownListData(this.cmbCRCY, this._currencyList);
                //Set data into control
                this.InitData();

                //this.txtProductName.SetReadOnly(true);
                //if (this.txtProductCD.Value.Equals(M_Product.PRODUCT_CODE_SUPPORT))
                //{
                //    this.txtProductName.SetReadOnly(false);
                //}
                this.txtCustomerName.SetReadOnly(true);
                if (this.txtCustomerCD.Value.Equals(M_Customer.CUSTOMER_CODE_SUPPORT))
                {
                    this.txtCustomerName.SetReadOnly(false);
                }

                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                // set default paging header
                this.PagingHeader.IsCloseForm = true;

                //Load data into grid
                this.LoadDataGrid();
            }
            else
            {
                //Set confirm data
                this.SetConfirmData();
            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            this.PagingHeader.CurrentPage = 1;
            //this.OldPagingInfo = null;
            this.LoadDataGrid();
            this.Collapse = "in";
        }

        /// <summary>
        /// Change value with exchange rate
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbCRCY_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.FocusControlId = this.cmbCRCY.ClientID;
            var crcyId = int.Parse(this.cmbCRCY.SelectedValue);
            M_Currency_H crcySelected = null;
            if (crcyId != -1)
            {
                crcySelected = this._currencyList.Where(c => c.DataboundItem != null &&
                                 ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
            }
            else
            {
                crcySelected = this._currencyList.Where(c => c.DataboundItem != null &&
                                ((M_Currency_H)c.DataboundItem).ID == Constant.DEFAULT_ID).SingleOrDefault().DataboundItem as M_Currency_H;
            }

            this.SetDecimalDigit(crcySelected, this.txtUnitPriceFrom, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtUnitPriceTo, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);

            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.PagingHeader.CurrentPage = int.Parse((sender as LinkButton).CommandArgument);
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.PagingHeader.CurrentPage = 1;
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.PagingHeader.CurrentPage = 1;
            this.LoadDataGrid();
        }

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                if (in1 == OMS.Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1,
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Product Info
        /// </summary>
        /// <param name="in1">customerCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(string in1)
        {
            try
            {
                if (in1 == OMS.Models.M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    ProductService prodSrv = new ProductService(db);

                    var product = prodSrv.GetByCD(in1);
                    if (product != null && product.StatusFlag == 0)
                    {
                        var result = new
                        {
                            productCD = in1,
                            productName = product.ProductName,
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        productCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Init MaxLength
        /// </summary>
        private void InitMaxLength()
        {
            //Init Max Length
            this.txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
            this.txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
            this.txtDescription.MaxLength = M_Product.DESCRIPTION_MAX_LENGTH;
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;

            var crcySelected = this._currencyList.Where(c => c.DataboundItem != null &&
                                                       ((M_Currency_H)c.DataboundItem).ID == Constant.DEFAULT_ID).SingleOrDefault().DataboundItem as M_Currency_H;
            this.SetDecimalDigit(crcySelected, this.txtUnitPriceFrom, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtUnitPriceTo, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
        }

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            using (DB db = new DB())
            {
                var quoteDate = db.NowDate;
                //Init default value of Quote Date
                this.dtQuoteDateFrom.Value = quoteDate.AddMonths(-6);
                this.dtQuoteDateTo.Value = quoteDate;
            }

            this.SetComboByLevel(this.cmbCategory1, 1);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);

            //Set product code
            if (Request.QueryString["in1"] != null)
            {
                this.txtProductCD.Value = Request.QueryString["in1"];
            }

            //Set product name
            if (Request.QueryString["in2"] != null)
            {
                this.txtProductName.Value = Request.QueryString["in2"];
            }

            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }
        }

        /// <summary>
        /// Init Unit Data
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboByLevel(DropDownList ctrl, int level)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst = dbSer.GetDataByLevelForDropDownList(level, true);
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetBlankCombo(DropDownList ctrl)
        {
            IList<DropDownModel> lst = new List<DropDownModel>(new[]{
                new DropDownModel("-1", "---")
            });
            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1(DropDownList ctrl, int categoryId1, int childLevel, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1(categoryId1, childLevel));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1AndCategory2(DropDownList ctrl, int categoryId1, int categoryId2, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1AndCategory2(categoryId1, categoryId2));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Set Value
        /// </summary>
        /// <param name="ctr"></param>
        /// <param name="value"></param>
        private void SetValueCombo(DropDownList ctr, string value)
        {
            bool hasValue = false;
            List<DropDownModel> listValue = (List<DropDownModel>)ctr.DataSource;
            foreach (var item in listValue)
            {
                if (item.Value.Equals(value))
                {
                    hasValue = true;
                    break;
                }
            }
            if (hasValue)
            {
                ctr.SelectedValue = value;
            }
            else
            {
                ctr.SelectedValue = "-1";
            }
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(M_Currency_H crcyItem, INumberTextBox txtNumberInput, decimal maxDecimal, decimal maxNotDecimal)
        {
            if (crcyItem != null)
            {
                if (crcyItem.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtNumberInput.DecimalDigit = 2;
                    txtNumberInput.MaximumValue = maxDecimal;
                }
                else
                {
                    txtNumberInput.DecimalDigit = 0;
                    txtNumberInput.MaximumValue = maxNotDecimal;
                }
            }
        }

        /// <summary>
        /// Set confirm data
        /// </summary>
        private void SetConfirmData()
        {
            using (DB db = new DB())
            {
                CustomerService custSrv = new CustomerService(db);
                //ProductService prodSrv = new ProductService(db);

                ////txtCustomerCD
                //if (!this.txtProductCD.IsEmpty && this.txtProductCD.Value != Models.M_Product.PRODUCT_CODE_SUPPORT)
                //{
                //    this.txtProductName.SetReadOnly(true);
                //    var product = prodSrv.GetByCD(txtProductCD.Value);
                //    if (product != null && product.StatusFlag != 1)
                //    {
                //        this.txtProductName.Value = product.ProductName;
                //    }
                //}
                //else
                //{
                //    if (this.txtProductCD.Value != Models.M_Product.PRODUCT_CODE_SUPPORT)
                //    {
                //        this.txtProductName.Value = null;
                //        this.txtProductName.SetReadOnly(true);
                //    }
                //    else
                //    {
                //        this.txtProductName.SetReadOnly(false);
                //    }
                //}

                //txtCustomerCD
                if (!this.txtCustomerCD.IsEmpty && this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    this.txtCustomerName.SetReadOnly(true);
                    var customerCd = this.txtCustomerCD.Value;
                    customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = custSrv.GetByCustomerCD(customerCd);
                    if (customer != null && customer.StatusFlag != 1)
                    {
                        this.txtCustomerName.Value = customer.CustomerName1;
                    }
                }
                else
                {
                    if (this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                    {
                        this.txtCustomerName.Value = null;
                        this.txtCustomerName.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(false);
                    }
                }
            }
            if (this.OldPagingInfo != null)
            {
                //Paging header
                this.PagingHeader.RowNumFrom = (int)this.OldPagingInfo["RowNumFrom"];
                this.PagingHeader.RowNumTo = (int)this.OldPagingInfo["RowNumTo"];
                this.PagingHeader.TotalRow = (int)this.OldPagingInfo["TotalRow"];
                this.PagingHeader.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];

                //Paging footer
                this.PagingFooter.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];
                this.PagingFooter.NumberOnPage = (int)this.OldPagingInfo["NumberOnPage"];
                this.PagingFooter.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                //Header
                this.HeaderGrid.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                this.OldPagingInfo = this.OldPagingInfo;
            }
            this.AddHeaderCols();
        }

        /// <summary>
        /// AddheaderCols
        /// </summary>
        private void AddHeaderCols()
        {
            #region Create Column

            this.HeaderGrid.Columns = null;
            ColumnInfo item1 = new ColumnInfo();
            item1.Text = "#";
            this.HeaderGrid.AddColumms(item1);

            ColumnInfo item2 = new ColumnInfo();
            item2.Text = "";
            this.HeaderGrid.AddColumms(item2);

            ColumnInfo item3 = new ColumnInfo();
            item3.Text = "Date";
            item3.Sorting = true;
            this.HeaderGrid.AddColumms(item3);

            ColumnInfo item4 = new ColumnInfo();
            item4.Text = "Quote No";
            item4.Sorting = true;
            this.HeaderGrid.AddColumms(item4);

            ColumnInfo item5 = new ColumnInfo();
            item5.Text = "CD/Product Name";
            item5.Sorting = true;
            this.HeaderGrid.AddColumms(item5);

            ColumnInfo item6 = new ColumnInfo();
            item6.Text = "Unit Price";
            item6.Sorting = true;
            item6.CssClass = "text-right";
            this.HeaderGrid.AddColumms(item6);

            ColumnInfo item7 = new ColumnInfo();
            item7.Text = "Currency";
            item7.Sorting = true;
            this.HeaderGrid.AddColumms(item7);

            ColumnInfo item8 = new ColumnInfo();
            item8.Text = "CD/Customer";
            item8.Sorting = true;
            this.HeaderGrid.AddColumms(item8);

            ColumnInfo colHide = new ColumnInfo();
            colHide.Text = "";
            colHide.Sorting = false;
            colHide.CssClass = "hidden";
            this.HeaderGrid.AddColumms(colHide);

            #endregion Create Column
        }

        /// <summary>
        /// Get Default Data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                Currency_HService currencyHService = new Currency_HService(db);
                Config_HService configSer = new Config_HService(db);
                Config_DService config_DSer = new Config_DService(db);

                var crcyItems = currencyHService.GetListDropdown();
                //Get ExchangeRate
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));
                this._currencyList.Insert(0, new DropDownModel("-1", "---"));
            }
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid()
        {
            int totalRow = 0;

            using (DB db = new DB())
            {
                Quotation_HService sellSer = new Quotation_HService(db);
                var searchModel = this.GetSearchModel();

                totalRow = sellSer.GetSellCountForSearch(searchModel);
                var results = sellSer.GetSellItemForSearch(searchModel);

                #region Display Data

                Hashtable pagingInfo = null;
                if (results != null && results.Count != 0)
                {
                    this.PagingHeader.RowNumFrom = int.Parse(results[0].RowNumber.ToString());
                    this.PagingHeader.RowNumTo = int.Parse(results[results.Count - 1].RowNumber.ToString());
                    this.PagingHeader.TotalRow = totalRow;
                    this.PagingHeader.CurrentPage = searchModel.PageIndex;

                    // paging footer
                    this.PagingFooter.CurrentPage = searchModel.PageIndex;
                    this.PagingFooter.NumberOnPage = searchModel.PageSize;
                    this.PagingFooter.TotalRow = totalRow;

                    // header
                    this.HeaderGrid.TotalRow = totalRow;

                    this.AddHeaderCols();

                    pagingInfo = new Hashtable();
                    pagingInfo.Add("RowNumFrom", this.PagingHeader.RowNumFrom);
                    pagingInfo.Add("RowNumTo", this.PagingHeader.RowNumTo);
                    pagingInfo.Add("TotalRow", totalRow);
                    pagingInfo.Add("CurrentPage", searchModel.PageIndex);
                    pagingInfo.Add("NumberOnPage", searchModel.PageSize);
                    pagingInfo.Add("ColumnHeader", this.HeaderGrid.Columns);
                }
                else
                {
                    //Paging header
                    this.PagingHeader.RowNumFrom = 0;
                    this.PagingHeader.RowNumTo = 0;
                    this.PagingHeader.TotalRow = 0;
                    this.PagingHeader.CurrentPage = 1;

                    // paging footer
                    this.PagingFooter.CurrentPage = 1;
                    this.PagingFooter.NumberOnPage = 0;
                    this.PagingFooter.TotalRow = 0;

                    //Header
                    this.HeaderGrid.TotalRow = 0;
                    this.HeaderGrid.Columns = null;
                }

                #endregion Display Data

                this.OldPagingInfo = pagingInfo;
                this.Collapse = results.Count > 0 ? string.Empty : "in";
                this.rptList.DataSource = results;
                this.rptList.DataBind();
            }
        }

        /// <summary>
        /// Gets the search model.
        /// </summary>
        /// <returns></returns>
        private QuotationProductSearchModel GetSearchModel()
        {
            var pageIndex = 0;
            var numOnPage = 0;

            pageIndex = this.PagingHeader.CurrentPage;
            numOnPage = this.PagingHeader.NumRowOnPage;

            int sortField = int.Parse(this.HeaderGrid.SortField);
            int sortDirec = int.Parse(this.HeaderGrid.SortDirec);

            return new QuotationProductSearchModel
            {
                QuoteDateFrm = this.dtQuoteDateFrom.Value,
                QuoteDateTo = this.dtQuoteDateTo.Value,
                CategoryID1 = int.Parse(this.cmbCategory1.SelectedValue),
                CategoryID2 = int.Parse(this.cmbCategory2.SelectedValue),
                CategoryID3 = int.Parse(this.cmbCategory3.SelectedValue),
                ProductCD = this.txtProductCD.Value,
                ProductName = this.txtProductName.Value,
                Description = this.txtDescription.Value,
                UnitPriceFrm = this.txtUnitPriceFrom.Value,
                UnitPriceTo = this.txtUnitPriceTo.Value,
                CurrencyID = int.Parse(this.cmbCRCY.SelectedValue),
                CustomerCD = this.txtCustomerCD.Value,
                CustomerName = this.txtCustomerName.Value,
                PageIndex = pageIndex,
                PageSize = numOnPage,
                SortField = sortField,
                SortDirec = sortDirec,
            };
        }

        /// <summary>
        /// Clears this instance.
        /// </summary>
        private void Clear()
        {
            this.dtQuoteDateFrom.Value = null;
            this.dtQuoteDateTo.Value = null;

            this.txtProductCD.Value = string.Empty;
            this.txtProductName.Value = string.Empty;

            this.SetComboByLevel(this.cmbCategory1, 1);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            //---------------------end
            this.cmbCategory1.SelectedValue = "-1";
            this.cmbCategory2.SelectedValue = "-1";
            this.cmbCategory3.SelectedValue = "-1";

            this.InitDropDownListData(this.cmbCRCY, this._currencyList);
            this.cmbCRCY_SelectedIndexChanged(null, null);

            this.txtDescription.Value = string.Empty;
            this.txtCustomerCD.Value = string.Empty;
            this.txtCustomerName.Value = string.Empty;

            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            this.PagingHeader.CurrentPage = 1;
            this.FocusControlId = dtQuoteDateFrom.ClientID;
            this.LoadDataGrid();
            this.Collapse = "in";
        }

        #endregion Method
    }
}
﻿using System;
using System.Collections;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Linq;

using OMS.Models;
using OMS.DAC;
using OMS.UserControls;
using OMS.Utilities;
using OMS.Controls;

namespace OMS.Search
{
    /// <summary>
    /// Form Purchase Product Search
    /// </summary>
    public partial class FrmPurchaseProductSearch : FrmBaseList
    {
        #region Property
        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set PagingInfo
        /// </summary>
        private Hashtable OldPagingInfo
        {
            get { return (Hashtable)ViewState["OldPagingInfo"]; }
            set { ViewState["OldPagingInfo"] = value; }
        }

        #endregion
        
        #region Variable
        /// <summary>
        /// Currency list
        /// </summary>
        private IList<DropDownModel> _currencyList;
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;
            //Init Event
            //this.cmbCurrency.SelectedIndexChanged += cmbCurrency_SelectedIndexChanged;
            this.cmbCategory1.SelectedIndexChanged += cmbCategory1_SelectedIndexChanged;
            this.cmbCategory2.SelectedIndexChanged += cmbCategory2_SelectedIndexChanged;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.InitMaxLength();

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
            this.btnClear.ServerClick += new EventHandler(btnClear_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.GetDefaultDataDropDownList();

            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //this.txtProductName.SetReadOnly(true);
                //if (this.txtProductCD.Value.Equals(M_Product.PRODUCT_CODE_SUPPORT))
                //{
                //    this.txtProductName.SetReadOnly(false);
                //}
                this.txtVendorName.SetReadOnly(true);
                if (this.txtVendorCD.Value.Equals(M_Vendor.VENDOR_CODE_SUPPORT))
                {
                    this.txtVendorName.SetReadOnly(false);
                }

                //Load data into grid
                this.LoadDataGrid();
            }
            else
            {
                //Set confirm data
                this.SetConfirmData();
            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            this.PagingHeader.CurrentPage = 1;
            //this.OldPagingInfo = null;
            this.LoadDataGrid();
            this.Collapse = "in";

        }

        /// <summary>
        /// Clear
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnClear_Click(object sender, EventArgs e)
        {
            this.dtPurchaseDateFrm.Value = null;
            this.dtPurchaseDateTo.Value = null;

            this.txtProductCD.Value = string.Empty;
            this.txtProductName.Value = string.Empty;

            this.SetComboByLevel(this.cmbCategory1, 1);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            //this.txtUnitPriceFrm.Value = null;
            //this.txtUnitPriceTo.Value = null;
            this.cmbCategory1.SelectedValue = "-1";
            this.cmbCategory2.SelectedValue = "-1";
            this.cmbCategory3.SelectedValue = "-1";

            //this.cmbCurrency.SelectedValue = "-1";
            this.txtDescription.Value = string.Empty;
            this.txtVendorCD.Value = string.Empty;
            this.txtVendorName.Value = string.Empty;

            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            this.PagingHeader.CurrentPage = 1;

            this.LoadDataGrid();
            this.Collapse = "in";

        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.PagingHeader.CurrentPage = int.Parse((sender as LinkButton).CommandArgument);
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.PagingHeader.CurrentPage = 1;
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.PagingHeader.CurrentPage = 1;
            this.LoadDataGrid();
        }

        ///// <summary>
        ///// Currency change
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //protected void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    this.FocusControlId = this.cmbCurrency.ClientID;
        //    this.Collapse = "in";

        //    this.SetDecimalDigit(this.cmbCurrency, this.txtUnitPriceFrm, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
        //    this.SetDecimalDigit(this.cmbCurrency, this.txtUnitPriceTo, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);

        //    this.LoadDataGrid();
        //}

        /// <summary>
        /// Change category 1
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCategory1_SelectedIndexChanged(object sender, EventArgs e)
        {

            var categoryId = int.Parse(this.cmbCategory1.SelectedValue);
            if (categoryId == -1)
            {
                this.SetComboByLevel(this.cmbCategory1, 1);
                // start:2015/01/26 ---
                //Author: dh-phuong
                //---------------------start
                //this.SetComboByLevel(this.cmbCategory2, 2);
                //this.SetComboByLevel(this.cmbCategory3, 3);
                this.SetBlankCombo(this.cmbCategory2);
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }
            else
            {
                this.SetComboFromCategory1(this.cmbCategory2, categoryId, 2, "-1");
                // start:2015/01/26 ---
                //Author: dh-phuong
                //---------------------start
                //this.SetComboFromCategory1(this.cmbCategory3, categoryId, 3, "-1");
                this.SetBlankCombo(this.cmbCategory3);
                //---------------------end
            }

            this.FocusControlId = this.cmbCategory1.ClientID;
            //this.LoadDataGrid(false);
            this.Collapse = "in";
        }

        /// <summary>
        /// Change category 2
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCategory2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int categoryId1 = int.Parse(this.cmbCategory1.SelectedValue);
            int categoryId2 = int.Parse(this.cmbCategory2.SelectedValue);
            //IList<M_CategoryStruct> listCategory1;

            if (categoryId1 != -1)
            {
                if (categoryId2 != -1)
                {
                    this.SetComboFromCategory1AndCategory2(this.cmbCategory3, categoryId1, categoryId2, "-1");
                }
                else
                {
                    // start:2015/01/26 ---
                    //Author: dh-phuong
                    //---------------------start
                    //this.SetComboFromCategory1(this.cmbCategory3, categoryId1, 3, "-1");
                    this.SetBlankCombo(this.cmbCategory3);
                    //---------------------end
                }
            }
            //else
            //{
            //    if (categoryId2 != -1)
            //    {
            //        //Get list parent
            //        listCategory1 = this.GetListCategoryParentID(categoryId2, 2);
            //        if (listCategory1.Count != 0)
            //        {
            //            //Load combo
            //            this.SetComboFromCategory1AndCategory2(this.cmbCategory3, listCategory1[0].CategoryID, categoryId2, "-1");
            //            this.SetComboFromCategory1(this.cmbCategory2, listCategory1[0].CategoryID, 2, categoryId2.ToString());

            //            //Set value
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetValueCombo(this.cmbCategory1, listCategory1[0].CategoryID.ToString());
            //        }
            //        else
            //        {
            //            this.SetComboByLevel(this.cmbCategory1, 1);
            //            this.SetComboByLevel(this.cmbCategory2, 2);
            //            this.SetComboByLevel(this.cmbCategory3, 3);
            //        }
            //    }
            //}

            this.FocusControlId = this.cmbCategory2.ClientID;
            //this.LoadDataGrid(false);
            this.Collapse = "in";
        }
        #endregion

        #region Method
        /// <summary>
        /// Init MaxLength
        /// </summary>
        private void InitMaxLength()
        {
            //Init Max Length
            this.txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
            this.txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;
            this.txtDescription.MaxLength = M_Product.DESCRIPTION_MAX_LENGTH;
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorName.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;
        }

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            //Init default value of Purchase Date
            this.dtPurchaseDateFrm.Value = DateTime.Now.AddMonths(-6);
            this.dtPurchaseDateTo.Value = DateTime.Now;

            //Load data for drop down list
            this.SetComboByLevel(this.cmbCategory1, 1);
            this.SetBlankCombo(this.cmbCategory2);
            this.SetBlankCombo(this.cmbCategory3);
            ////Init DropDownList currency list
            //this.InitDropDownListData(this.cmbCurrency, this._currencyList);

            //this.SetDecimalDigit(this.cmbCurrency, this.txtUnitPriceFrm, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
            //this.SetDecimalDigit(this.cmbCurrency, this.txtUnitPriceTo, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);

            //Set product code
            if (Request.QueryString["in1"] != null)
            {
                this.txtProductCD.Value = Request.QueryString["in1"];
            }
            //Set product name
            if (Request.QueryString["in2"] != null)
            {
                this.txtProductName.Value = Request.QueryString["in2"];
            }

            //Set id of product code in parent page
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set id of product name in parent page
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(DropDownList dropDownListControl, INumberTextBox numberControl, decimal maxDecimal, decimal maxNoneDecimal)
        {
            if (this.IsDecimalCurrency(dropDownListControl))
            {
                numberControl.DecimalDigit = 2;
                numberControl.MaximumValue = maxDecimal;
            }
            else
            {
                numberControl.DecimalDigit = 0;
                numberControl.MaximumValue = maxNoneDecimal;
            }
        }

        /// <summary>
        /// Check currency is decimal
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        private bool IsDecimalCurrency(DropDownList cmbCurrency)
        {
            if (cmbCurrency.SelectedValue == "-1")
            {
                return false;
            }

            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == int.Parse(cmbCurrency.SelectedValue)).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Get Default Data DropDownList
        /// </summary>
        private void GetDefaultDataDropDownList()
        {
            using (DB db = new DB())
            {
                //Get ExchangeRate
                Currency_HService currencyHService = new Currency_HService(db);
                var crcyItems = currencyHService.GetListDropdown();

                //Get ExchangeRate
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                this._currencyList.Insert(0, new DropDownModel()
                {
                    Value = "-1",
                    DisplayName = "---",
                    DataboundItem = new M_Currency_H()
                });
            }
        }

        /// <summary>
        /// Init DropDownList
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Get model for search action
        /// </summary>
        /// <returns></returns>
        private PurchaseProductSearchHeader GetSearchModel()
        {
            PurchaseProductSearchHeader ret = new PurchaseProductSearchHeader();
            ret.PurchaseDateFrom = this.dtPurchaseDateFrm.Value;
            ret.PurchaseDateTo = this.dtPurchaseDateTo.Value;

            ret.ProductCD = this.txtProductCD.Value;
            ret.ProductName = this.txtProductName.Value;
            ret.CategoryID1 = int.Parse(this.cmbCategory1.SelectedValue);
            ret.CategoryID2 = int.Parse(this.cmbCategory2.SelectedValue);
            ret.CategoryID3 = int.Parse(this.cmbCategory3.SelectedValue);

            //ret.UnitPriceFrom = this.txtUnitPriceFrm.Value;
            //ret.UnitPriceTo = this.txtUnitPriceTo.Value;
            //ret.Currency = int.Parse(this.cmbCurrency.SelectedValue);
            ret.Description = this.txtDescription.Value;
            ret.VendorCD = this.txtVendorCD.Value;
            ret.VendorName = this.txtVendorName.Value;
            return ret;
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid()
        {
            int totalRow = 0;
            var pageIndex = 0;
            var numOnPage = 0;

            pageIndex = this.PagingHeader.CurrentPage;
            numOnPage = this.PagingHeader.NumRowOnPage;

            int sortField = int.Parse(this.HeaderGrid.SortField);
            int sortDirec = int.Parse(this.HeaderGrid.SortDirec);

            IList<PurchaseProductSearchResult> listResult;

            //Get model for search action
            PurchaseProductSearchHeader model = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Purchase_HService purchaseHService = new Purchase_HService(db);

                //Get total row
                totalRow = purchaseHService.GetTotalRowForPurchaseProductSearch(model);

                //Get the list for searching
                listResult = purchaseHService.GetListForPurchaseProductSearch(model, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            }
            Hashtable pagingInfo = null;
            if (listResult != null && listResult.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;

                this.AddHeaderCols();

                pagingInfo = new Hashtable();
                pagingInfo.Add("RowNumFrom", this.PagingHeader.RowNumFrom);
                pagingInfo.Add("RowNumTo", this.PagingHeader.RowNumTo);
                pagingInfo.Add("TotalRow", totalRow);
                pagingInfo.Add("CurrentPage", pageIndex);
                pagingInfo.Add("NumberOnPage", numOnPage);
                pagingInfo.Add("ColumnHeader", this.HeaderGrid.Columns);
            }
            else
            {
                //Paging header
                this.PagingHeader.RowNumFrom = 0;
                this.PagingHeader.RowNumTo = 0;
                this.PagingHeader.TotalRow = 0;
                this.PagingHeader.CurrentPage = 1;

                // paging footer
                this.PagingFooter.CurrentPage = 1;
                this.PagingFooter.NumberOnPage = 0;
                this.PagingFooter.TotalRow = 0;

                //Header
                this.HeaderGrid.TotalRow = 0;
                this.HeaderGrid.Columns = null;

            }
            this.OldPagingInfo = pagingInfo;
            this.Collapse = listResult.Count > 0 ? string.Empty : "in";
            this.rptList.DataSource = listResult;
            this.rptList.DataBind();
        }

        /// <summary>
        /// AddheaderCols
        /// </summary>
        private void AddHeaderCols()
        {
            #region Create Column

            this.HeaderGrid.Columns = null;
            ColumnInfo item1 = new ColumnInfo();
            item1.Text = "#";
            this.HeaderGrid.AddColumms(item1);

            ColumnInfo item2 = new ColumnInfo();
            item2.Text = "";
            this.HeaderGrid.AddColumms(item2);

            ColumnInfo item3 = new ColumnInfo();
            item3.Text = "Purchase Date";
            item3.Sorting = true;
            this.HeaderGrid.AddColumms(item3);

            ColumnInfo item4 = new ColumnInfo();
            item4.Text = "Purchase No";
            item4.Sorting = true;
            this.HeaderGrid.AddColumms(item4);

            ColumnInfo item5 = new ColumnInfo();
            item5.Text = "CD/Product Name";
            item5.Sorting = true;
            this.HeaderGrid.AddColumms(item5);

            ColumnInfo item6 = new ColumnInfo();
            item6.Text = "Unit Price";
            item6.Sorting = true;
            item6.CssClass = "text-right";
            this.HeaderGrid.AddColumms(item6);

            ColumnInfo item7 = new ColumnInfo();
            item7.Text = "Currency";
            item7.Sorting = true;
            this.HeaderGrid.AddColumms(item7);

            ColumnInfo item8 = new ColumnInfo();
            item8.Text = "CD/Vendor";
            item8.Sorting = true;
            this.HeaderGrid.AddColumms(item8);

            ColumnInfo colHide = new ColumnInfo();
            colHide.Text = "";
            colHide.Sorting = false;
            colHide.CssClass = "hidden";
            this.HeaderGrid.AddColumms(colHide);

            #endregion
        }

        /// <summary>
        /// Set confirm data
        /// </summary>
        private void SetConfirmData()
        {
            using (DB db = new DB())
            {
                VendorService vendorService = new VendorService(db);
                ProductService prodSrv = new ProductService(db);

                //txtProductCD
                //if (!this.txtProductCD.IsEmpty && this.txtProductCD.Value != Models.M_Product.PRODUCT_CODE_SUPPORT)
                //{
                //    this.txtProductName.SetReadOnly(true);
                //    var product = prodSrv.GetByCD(txtProductCD.Value);
                //    if (product != null && product.StatusFlag != 1)
                //    {
                //        this.txtProductName.Value = product.ProductName;
                //    }
                //}
                //else
                //{
                //    if (this.txtProductCD.Value != Models.M_Product.PRODUCT_CODE_SUPPORT)
                //    {
                //        this.txtProductName.Value = null;
                //        this.txtProductName.SetReadOnly(true);
                //    }
                //    else
                //    {
                //        this.txtProductName.SetReadOnly(false);
                //    }
                //}

                //txtVendorCD
                if (!this.txtVendorCD.IsEmpty && this.txtVendorCD.Value != Models.M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    this.txtVendorName.SetReadOnly(true);
                    var vendorCd = this.txtVendorCD.Value;
                    vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                    var vendor = vendorService.GetByCD(vendorCd);
                    if (vendor != null && vendor.StatusFlag != 1)
                    {
                        this.txtVendorName.Value = vendor.VendorName1;
                    }
                }
                else
                {
                    if (this.txtVendorCD.Value != Models.M_Vendor.VENDOR_CODE_SUPPORT)
                    {
                        this.txtVendorName.Value = null;
                        this.txtVendorName.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtVendorName.SetReadOnly(false);
                    }
                }
            }
            if (this.OldPagingInfo != null)
            {
                //Paging header
                this.PagingHeader.RowNumFrom = (int)this.OldPagingInfo["RowNumFrom"];
                this.PagingHeader.RowNumTo = (int)this.OldPagingInfo["RowNumTo"];
                this.PagingHeader.TotalRow = (int)this.OldPagingInfo["TotalRow"];
                this.PagingHeader.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];

                //Paging footer
                this.PagingFooter.CurrentPage = (int)this.OldPagingInfo["CurrentPage"];
                this.PagingFooter.NumberOnPage = (int)this.OldPagingInfo["NumberOnPage"];
                this.PagingFooter.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                //Header
                this.HeaderGrid.TotalRow = (int)this.OldPagingInfo["TotalRow"];

                this.OldPagingInfo = this.OldPagingInfo;
            }
            this.AddHeaderCols();

        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboByLevel(DropDownList ctrl, int level)
        {
            IList<DropDownModel> lst;
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst = dbSer.GetDataByLevelForDropDownList(level, true);
            }

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetBlankCombo(DropDownList ctrl)
        {
            IList<DropDownModel> lst = new List<DropDownModel>(new[]{
                new DropDownModel("-1", "---")
            });
            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1(DropDownList ctrl, int categoryId1, int childLevel, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1(categoryId1, childLevel));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Get category data for DropDownList
        /// </summary>
        /// <param name="ctrl"></param>
        /// <param name="parentId"></param>
        private void SetComboFromCategory1AndCategory2(DropDownList ctrl, int categoryId1, int categoryId2, string defaultValue)
        {
            List<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                CategoryStructService dbSer = new CategoryStructService(db);
                lst.AddRange(dbSer.GetListByCategory1AndCategory2(categoryId1, categoryId2));
            }

            lst.Insert(0, new DropDownModel("-1", "---"));

            ctrl.DataSource = lst;
            ctrl.DataValueField = "Value";
            ctrl.DataTextField = "DisplayName";
            ctrl.DataBind();

            this.SetValueCombo(ctrl, defaultValue);
        }

        /// <summary>
        /// Set Value
        /// </summary>
        /// <param name="ctr"></param>
        /// <param name="value"></param>
        private void SetValueCombo(DropDownList ctr, string value)
        {
            bool hasValue = false;
            List<DropDownModel> listValue = (List<DropDownModel>)ctr.DataSource;
            foreach (var item in listValue)
            {
                if (item.Value.Equals(value))
                {
                    hasValue = true;
                    break;
                }
            }
            if (hasValue)
            {
                ctr.SelectedValue = value;
            }
            else
            {
                ctr.SelectedValue = "-1";
            }
        }


        #endregion

        #region Web Methods

        /// <summary>
        /// Get Vendor Info
        /// </summary>
        /// <param name="in1">VendorCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetVendor(string in1)
        {
            try
            {
                var dbVendorCD = in1;
                dbVendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                if (in1 == OMS.Models.M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    VendorService service = new VendorService(db);

                    var vendor = service.GetByCD(dbVendorCD);
                    if (vendor != null && vendor.StatusFlag == 0)
                    {
                        var result = new
                        {
                            vendorCD = in1,
                            vendorName1 = vendor.VendorName1,
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        vendorCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Product Info
        /// </summary>
        /// <param name="in1">ProductCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(string in1)
        {
            try
            {
                if (in1 == OMS.Models.M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    ProductService prodSrv = new ProductService(db);

                    var product = prodSrv.GetByCD(in1);
                    if (product != null && product.StatusFlag == 0)
                    {
                        var result = new
                        {
                            productCD = in1,
                            productName = product.ProductName,
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        productCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion
    }
}
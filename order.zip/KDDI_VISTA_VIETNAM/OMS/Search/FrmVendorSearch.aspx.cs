﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.DAC;
using OMS.Utilities;

namespace OMS.Search
{
    /// <summary>
    /// Vendor Search
    /// ISV-TRUC
    /// </summary>
    public partial class FrmVendorSearch : FrmBaseList
    {
        public IList<VendorSearchInfo> listVendorInfo;

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set Status
        /// </summary>
        public string Status
        {
            get { return (string)ViewState["Status"]; }
            set { ViewState["Status"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtVendorCode.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorName.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;

            this.txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;
            this.txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;

            this.txtBusinessAreas.MaxLength = M_Vendor.VENDOR_GROUP_SUPPLY_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, true);
            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, false);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage, false);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, false);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, false);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            #region IN
            //Set VendorCd
            if (Request.QueryString["in1"] != null)
            {
                this.txtVendorCode.Value = Request.QueryString["in1"];
            }

            //Set VendorName
            if (Request.QueryString["in2"] != null)
            {
                this.txtVendorName.Value = Request.QueryString["in2"];
            }

            //Set VendorCd
            if (Request.QueryString["in3"] != null)
            {
                this.txtProductCD.Value = Request.QueryString["in3"];
            }

            //Set VendorName
            if (Request.QueryString["in4"] != null)
            {
                this.txtProductName.Value = Request.QueryString["in4"];
            }

            //Set in3
            if (Request.QueryString["in5"] != null)
            {
                this.Status = Request.QueryString["in5"];
            }
            #endregion

            #region OUT

            //Set VendorCdCtrl
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set VendorNameCtrl
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            if (Request.QueryString["out3"] != null)
            {
                this.Out3.Value = Request.QueryString["out3"];
            }

            if (Request.QueryString["out4"] != null)
            {
                this.Out4.Value = Request.QueryString["out4"];
            }

            if (Request.QueryString["out5"] != null)
            {
                this.Out5.Value = Request.QueryString["out5"];
            }

            if (Request.QueryString["out6"] != null)
            {
                this.Out6.Value = Request.QueryString["out6"];
            }

            if (Request.QueryString["out7"] != null)
            {
                this.Out7.Value = Request.QueryString["out7"];
            }

            if (Request.QueryString["out8"] != null)
            {
                this.Out8.Value = Request.QueryString["out8"];
            }

            if (Request.QueryString["out9"] != null)
            {
                this.Out9.Value = Request.QueryString["out9"];
            }

            #endregion
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage, bool clearWhenEmpty)
        {
            
            string vendorCd = null;
            string vendorName = null;
            string productCd = null;
            string productNm = null;
            string groupApply = null;
            int totalRow = 0;

            if (!this.txtVendorCode.IsEmpty)
            {
                vendorCd = Utilities.EditDataUtil.ToFixCodeDB(this.txtVendorCode.Value, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            }

            if (!this.txtVendorName.IsEmpty)
            {
                vendorName = this.txtVendorName.Value;
            }

            if (!this.txtProductCD.IsEmpty)
            {
                productCd = this.txtProductCD.Value;
            }

            if (!this.txtProductName.IsEmpty)
            {
                productNm = this.txtProductName.Value;
            }


            if (!this.txtBusinessAreas.IsEmpty)
            {
                groupApply = this.txtBusinessAreas.Value;
            }

            using (DB db = new DB())
            {
                VendorService vendorService = new VendorService(db);
                totalRow = vendorService.GetCountByConditionForSearch(vendorCd, vendorName, productCd, productNm, groupApply);
                if (totalRow == 0)
                {
                    if (clearWhenEmpty)
                    {
                        this.txtProductCD.Value = productCd = string.Empty;
                        this.txtProductName.Value = productNm = string.Empty;
                    }
                    totalRow = vendorService.GetCountByConditionForSearch(vendorCd, vendorName, productCd, productNm, groupApply);
                }
                this.listVendorInfo = vendorService.GetListByConditionForSearch(vendorCd, vendorName, productCd, productNm, groupApply, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));                
            }

            if (this.listVendorInfo != null && this.listVendorInfo.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.listVendorInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.listVendorInfo[listVendorInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;
                
                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Vendor Name 1", "Vendor Name 2", "Business Category", "Tel", "Contact Person" });
            }

            this.Collapse = this.listVendorInfo.Count > 0 ? string.Empty : "in";
            this.rptVendorList.DataSource = this.listVendorInfo;
            this.rptVendorList.DataBind();
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Format vendor Code
        /// </summary>
        /// <param name="in1">VendorCD</param>
        /// <returns>Vendor CD</returns>
        [System.Web.Services.WebMethod]
        public static string FormatVendorCD(string in1)
        {
            try
            {
                var vendorCd = in1;
                var vendorCdShow = in1;
                vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
                var onlyCd = new
                {
                    txtVendorCode = vendorCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Get Product
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(string productCd)
        {
            try
            {
                if (productCd == M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    ProductService service = new ProductService(db);

                    var mProd = service.GetByCD(productCd);

                    if (mProd == null || mProd.StatusFlag != 0)
                    {
                        return string.Empty;
                    }

                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(new
                    {
                        productName = mProd.ProductName
                    });
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
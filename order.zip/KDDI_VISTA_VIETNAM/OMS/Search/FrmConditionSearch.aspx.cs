﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.DAC;

namespace OMS.Search
{
    /// <summary>
    /// Condition Search
    /// VN-Nho
    /// </summary>
    public partial class FrmConditionSearch : FrmBaseList
    {
        public IList<ConditionSearchInfo> listConditionInfo;

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditionName.MaxLength = M_Condition.CONDITION_NAME_MAX_LENGTH;

        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Methods

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            //Set condition type
            if (Request.QueryString["Type"] != null)
            {
                this.hidType.Value = Request.QueryString["Type"];
            }
            else
            {
                this.hidType.Value = "0";
            }

            //Set ConditionCtrl
            if (Request.QueryString["ConditionCtrl"] != null)
            {
                this.Out1.Value = Request.QueryString["ConditionCtrl"];
            }
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            string conditionCD = null;
            string conditionName = null;
            int totalRow = 0;

            if (!this.txtConditionCD.IsEmpty)
            {
                conditionCD = this.txtConditionCD.Value;
            }

            if (!this.txtConditionName.IsEmpty)
            {
                conditionName = this.txtConditionName.Value;
            }

            using (DB db = new DB())
            {
                ConditionService conditionService = new ConditionService(db);
                totalRow = conditionService.GetCountByConditionForSearch(int.Parse(this.hidType.Value), conditionCD, conditionName);

                this.listConditionInfo = conditionService.GetListByConditionForSearch(int.Parse(this.hidType.Value), conditionCD, conditionName, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));               
            }

            if (this.listConditionInfo != null && this.listConditionInfo.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.listConditionInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.listConditionInfo[listConditionInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Name" });
            }

            this.Collapse = this.listConditionInfo.Count > 0 ? string.Empty : "in";
            this.rptVendorList.DataSource = this.listConditionInfo;
            this.rptVendorList.DataBind();
        }

        #endregion

    }
}
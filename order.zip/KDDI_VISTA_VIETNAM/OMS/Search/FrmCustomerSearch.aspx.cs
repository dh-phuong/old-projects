﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.DAC;

namespace OMS.Search
{
    /// <summary>
    /// FrmCustomerSearch
    /// </summary>
    public partial class FrmCustomerSearch  : FrmBaseList
    {
        public IList<CustomerSearchInfo> listCustomerInfo;

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }
                
        public string Status
        {
            get { return (string)ViewState["Status"]; }
            set { ViewState["Status"] = value; }
        }
        #endregion

        #region "Event"

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;

        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion
      
        #region "Method"

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            #region IN
            //Set CustomerCd
            if (Request.QueryString["in1"] != null)
            {
                this.txtCustomerCD.Value = Request.QueryString["in1"];
            }

            //Set CustomerName
            if (Request.QueryString["in2"] != null)
            {
                this.txtCustomerName.Value = Request.QueryString["in2"];
            }

            if (Request.QueryString["in3"] != null)
            {
                this.Status = Request.QueryString["in3"];
            }
            #endregion

            #region OUT

            //Set CustomerCdCtrl
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set CustomerNameCtrl
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            if (Request.QueryString["out3"] != null)
            {
                this.Out3.Value = Request.QueryString["out3"];
            }

            if (Request.QueryString["out4"] != null)
            {
                this.Out4.Value = Request.QueryString["out4"];
            }

            if (Request.QueryString["out5"] != null)
            {
                this.Out5.Value = Request.QueryString["out5"];
            }

            if (Request.QueryString["out6"] != null)
            {
                this.Out6.Value = Request.QueryString["out6"];
            }

            if (Request.QueryString["out7"] != null)
            {
                this.Out7.Value = Request.QueryString["out7"];
            }

            if (Request.QueryString["out8"] != null)
            {
                this.Out8.Value = Request.QueryString["out8"];
            }

            if (Request.QueryString["out9"] != null)
            {
                this.Out9.Value = Request.QueryString["out9"];
            }
            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            if (Request.QueryString["out10"] != null)
            {
                this.Out10.Value = Request.QueryString["out10"];
            }

            if (Request.QueryString["out11"] != null)
            {
                this.Out11.Value = Request.QueryString["out11"];
            }
            // ---------------------- End  ------------------------------
            #endregion

        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            string customerCd = null;
            string customerName = null;
            int totalRow = 0;

            if (!this.txtCustomerCD.IsEmpty)
            {
                customerCd = Utilities.EditDataUtil.ToFixCodeDB(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
            }

            if (!this.txtCustomerName.IsEmpty)
            {
                customerName = this.txtCustomerName.Value;
            }

            using (DB db = new DB())
            {
                CustomerService customerService = new CustomerService(db);
                totalRow = customerService.GetCountByConditionForSearch(customerCd, customerName, this.Status);

                this.listCustomerInfo = customerService.GetListByConditionForSearch(customerCd, customerName, this.Status, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));                
            }

            if (this.listCustomerInfo != null && this.listCustomerInfo.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.listCustomerInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.listCustomerInfo[listCustomerInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Customer Name 1", "Customer Name 2", "Tel", "Contact Person" });
            }
            this.Collapse = this.listCustomerInfo.Count > 0 ? string.Empty : "in";
            this.rptCustomerList.DataSource = this.listCustomerInfo;
            this.rptCustomerList.DataBind();
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Format Customer Code
        /// </summary>
        /// <param name="in1">CustomerCD</param>
        /// <returns>CustomerCD</returns>
        [System.Web.Services.WebMethod]
        public static string FormatCustomerCD(string in1)
        {
            try
            {
                var customerCd = in1;
                var customerCdShow = in1;
                customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                customerCdShow = OMS.Utilities.EditDataUtil.ToFixCodeShow(customerCd, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                var onlyCd = new
                {
                    txtCustomerCD = customerCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
       
    }
}
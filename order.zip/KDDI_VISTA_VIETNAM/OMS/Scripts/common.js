﻿/*
* Script on page load
*/
$(function () {

    var sessionId = '#stay';
    var history_api = typeof history.pushState != 'undefined';

    if (history_api) {
        history.pushState(null, '', sessionId);
    } else {
        location.hash = sessionId;
    }
    window.onhashchange = function () {
        // User tried to go back; warn user, rinse and repeat
        if (history_api) {
            history.pushState(null, '', sessionId);
        } else {
            location.hash = sessionId;
        }
    } 

    if (typeof OnPageLoad != 'undefined') {
        OnPageLoad();
    }
    $specials_e = eval('(' + $("#specials_e").val() + ')'); 
    disableIme();
    dateInputSetting();
    numberInputSetting();
    codeInputSetting();
    inputDisplay();
    registLoading();
    hideLoading();
});


///////////////////////////////////////////
//  GET CONTROL BY ID
//  Create  : isv.thuy
//  Date    : 16/07/2014  
///////////////////////////////////////////
function getCtrlById(id, index) {

    /// <summary locid='1'>Get element by id start with</summary>
    /// <param name='id' locid='2'>element id</param>
    /// <param name='index' locid='3'>index (use for data grid)</param>
    if ($.trim(id) === "") {
        return null;
    }
    if (index == undefined) {
        return $("[id$=" + id + "]");
    } else {
        return $("[id$=" + id + "_" + index + "]");
    }
}

///////////////////////////////////////////
//  FOCUS CONTROL ERROR
//  Create  : isv.thuy
//  Date    : 16/07/2014  
///////////////////////////////////////////
function focusErrors() {
    /// <summary locid='1'>Focus to error element</summary>

    var $divs = $(".has-error, .has-warning");
    if ($divs.length > 0) {
        $divs.first().find("input, select, textarea").focus().select();
    }
}

function showLoading() {
    /// <summary locid='1'>Show loading panel</summary>
    $('#loading').modal('show');
}
function hideLoading() {
    /// <summary locid='1'>Hide loading panel</summary>
    $('#loading').modal('hide');
}

function showSuccess() {
    /// <summary locid='1'>Show success panel</summary>
    $("#success").removeClass("hidden");
    $("#success").fadeIn();
}
function hideSuccess() {
    /// <summary locid='1'>Hide success panel</summary>
    $("#success").hide();
}

//
//Get Value of Querry String
//
function getParameter(key) {
    key = key.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + key + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
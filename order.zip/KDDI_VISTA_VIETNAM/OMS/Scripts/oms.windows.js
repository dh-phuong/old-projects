﻿
/****************************************
* Call Customer Search form
*****************************************/
function showSearchCustomer(in1, in2, in3,
                            out1, out2, out3,
                            out4, out5, out6,
                            out7, out8, out9, out10, out11 ,callBackFunctionName
                            ) {

    /// <summary locid='1'>show Customer Search Popup</summary>
    /// <param name='in1' locid='2'>Customer Cd</param>
    /// <param name='in2' locid='3'>Customer Name</param>
    /// <param name='in3' locid='4'>StatusFlag</param>
    /// <param name='out1' locid='5'>Customer Cd</param>
    /// <param name='out2' locid='6'>CustomerName1</param>
    /// <param name='out3' locid='7'>CustomerName2</param>
    /// <param name='out4' locid='8'>CustomerAddress1</param>
    /// <param name='out5' locid='9'>CustomerAddress2</param>
    /// <param name='out6' locid='10'>CustomerAddress3</param>
    /// <param name='out7' locid='11'>Tel</param>
    /// <param name='out8' locid='12'>Fax</param>
    /// <param name='out9' locid='13'>Contact Person</param>
    // Description: Add
    // Author: ISV-PHUONG
    // Date  : 2014/12/05
    // ---------------------- Start ------------------------------
    /// <param name='out10' locid='14'>Represent</param>
    /// <param name='out11' locid='15'>Position</param>
    // ---------------------- End  ------------------------------
    //var url = "../Search/FrmCustomerSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmCustomerSearch.aspx?in1=" + in1;

    if ('undefined' != typeof in3) {
        url = url + "&in3=" + in3;
    }
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 3; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out"+ (i - 2) +"=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmCustomerSearch", 1100, 600);
}

/****************************************
* Call Customer Search form
*****************************************/
function showSearchCustomerWithName(in1, in2, in3,
                            out1, out2, out3,
                            out4, out5, out6,
                            out7, out8, out9, out10, out11, callBackFunctionName
                            ) {

    /// <summary locid='1'>show Customer Search Popup</summary>
    /// <param name='in1' locid='2'>Customer Cd</param>
    /// <param name='in2' locid='3'>Customer Name</param>
    /// <param name='in3' locid='4'>StatusFlag</param>
    /// <param name='out1' locid='5'>Customer Cd</param>
    /// <param name='out2' locid='6'>CustomerName1</param>
    /// <param name='out3' locid='7'>CustomerName2</param>
    /// <param name='out4' locid='8'>CustomerAddress1</param>
    /// <param name='out5' locid='9'>CustomerAddress2</param>
    /// <param name='out6' locid='10'>CustomerAddress3</param>
    /// <param name='out7' locid='11'>Tel</param>
    /// <param name='out8' locid='12'>Fax</param>
    /// <param name='out9' locid='13'>Contact Person</param>
    // Description: Add
    // Author: ISV-PHUONG
    // Date  : 2014/12/05
    // ---------------------- Start ------------------------------
    /// <param name='out10' locid='14'>Represent</param>
    /// <param name='out11' locid='15'>Position</param>
    // ---------------------- End  ------------------------------
    //var url = "../Search/FrmCustomerSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmCustomerSearch.aspx?in1=" + in1 + "&in2=" + in2;

    if ('undefined' != typeof in3) {
        url = url + "&in3=" + in3;
    }
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 3; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 2) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmCustomerSearch", 1100, 600);
}

/****************************************
* Call Product Search form
*****************************************/
function showSearchProduct(in1, in2, in3, in4, out1, out2, callBackFunctionName) {

    /// <summary locid='1'>Type Product Search Popup</summary>
    /// <param name='in1' locid='2'>Product Type</param>
    /// <param name='in2' locid='3'>Product Code</param>
    /// <param name='in3' locid='4'>Product Name</param>
    /// <param name='in4' locid='5'>Vendor Code</param>

    /// <param name='out1' locid='6'>Product Code</param>
    /// <param name='out2' locid='7'>Product Name</param>
    /// <param name='callBackFunctionName' locid='8'>callBackFunctionName</param>

    //function showSearchProduct(type, productCd, productName, productCdCtrlId, productNmCtrlId, callBackFunctionName) {
    //var url = "../Search/FrmProductSearch.aspx?Type=" + type + "&ProductCd=" + productCd + "&ProductName=" + productName + "&ProductCdCtrl=" + productCdCtrlId + "&ProductNameCtrl=" + productNmCtrlId;

    //var url = "../Search/FrmProductSearch.aspx?in1=" + in1 + "&in2=" + in2.encode() + "&in3=" + in3.encode() + "&in4=" + in4.encode();
    var url = "../Search/FrmProductSearch.aspx?in1=" + in1 + "&in2=" + in2 + "&in4=" + in4;
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 4; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 3) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmProductSearch", 1100, 600);
}

/****************************************
* Call User Search form
*****************************************/
function showSearchUser(in1, in2, in3, in4, out1, out2, out3, out4) {

    /// <summary locid='1'>show User Search Popup</summary>
    /// <param name='in1' locid='2'>User Cd</param>
    /// <param name='in2' locid='3'>User Name1</param>
    /// <param name='in3' locid='4'>User Name2</param>
    /// <param name='in4' locid='5'>Group Cd</param>

    /// <param name='out1' locid='6'>User Cd</param>
    /// <param name='out2' locid='7'>User Name1</param>
    /// <param name='out3' locid='8'>User Name2</param>
    /// <param name='out4' locid='9'>CustomerAddress1</param>

    //var url = "../Search/FrmUserSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode() + "&in3=" + in3.encode() + "&in4=" + in4.encode();
    var url = "../Search/FrmUserSearch.aspx?in1=" + in1 + "&in4=" + in4;
    var length = arguments.length;
    for (var i = 4; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 3) + "=" + arguments[i];
        }
    }
    openWindow(url, "FrmUserSearch", 800, 600);
}

/****************************************
* Call Group User Search form
*****************************************/
function showSearchGroupUser(groupCd, groupNm, groupCdCtrlId, groupNmCtrlId) {
    var url = "../Search/FrmGroupSearch.aspx?GroupCD=" + groupCd + "&GroupCDCtrl=" + groupCdCtrlId + "&GroupNmCtrl=" + groupNmCtrlId;
    openWindow(url, "FrmGroupSearch", 800, 600);
}

/****************************************
* Call Vendor Search form
*****************************************/
function showSearchVendor(in1, in2, in3, in4, in5,
                            out1, out2, out3,
                            out4, out5, out6,
                            out7, out8, out9, callBackFunctionName
                            ) {

    /// <summary locid='1'>show Vendor Search Popup</summary>
    /// <param name='in1' locid='2'>Vendor Cd</param>
    /// <param name='in2' locid='3'>Vendor Name</param>
    
    /// <param name='in3' locid='4'>Product Cd</param>
    /// <param name='in4' locid='5'>Product Name</param>

    /// <param name='in5' locid='6'>StatusFlag</param>
    /// <param name='out1' locid='7'>Vendor Cd</param>
    /// <param name='out2' locid='8'>VendorName1</param>
    /// <param name='out3' locid='9'>VendorName2</param>
    /// <param name='out4' locid='10'>VendorAddress1</param>
    /// <param name='out5' locid='11'>VendorAddress2</param>
    /// <param name='out6' locid='12'>VendorAddress3</param>
    /// <param name='out7' locid='13'>Tel</param>
    /// <param name='out8' locid='14'>Fax</param>
    /// <param name='out9' locid='15'>Contact Person</param>

    //var url = "../Search/FrmVendorSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode() + "&in3=" + in3.encode() + "&in4=" + in4.encode();
    var url = "../Search/FrmVendorSearch.aspx?in1=" + in1 + "&in3=" + in3;
    if ('undefined' != typeof in5) {
        url = url + "&in5=" + in5;
    }
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 5; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 4) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }

    openWindow(url, "FrmVendorSearch", 1100, 600);
}

/****************************************
* Call Condition Search form
*****************************************/
function showSearchCondition(type, conditionCtrlId) {
    var url = "../Search/FrmConditionSearch.aspx?Type=" + type + "&ConditionCtrl=" + conditionCtrlId;
    openWindow(url,"FrmConditionSearch", 800, 600);
}

/****************************************
* Call Attached form
*****************************************/
function showAttached(idFormType, formType, callBackFunctionName) {
    var url = "../AttachedFile/FrmAttachedFile.aspx?IDFormType=" + idFormType + "&FormType=" + formType + "&CallBackFunction=" + callBackFunctionName;
    openWindow(url, 'FrmAttachedFile', 800, 600);
}



/****************************************
* Call Quotation Product Search form
*****************************************/
function showSearchQuotationProduct(in1, in2, out1, out2, callBackFunctionName) {

    /// <summary>
    /// Shows the search quotation product.
    /// </summary>
    /// <param name="in1">The in1.(Product Code)</param>
    /// <param name="in2">The in2.(Product Name)</param>
    /// <param name="out1">The out1.(QuoteID)</param>
    /// <param name="out2">The out2.(Sell No)</param>
    /// <param name="callBackFunctionName">Name of the call back function.</param>
    /// <returns></returns>

    //var url = "../Search/FrmQuotationProductSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmQuotationProductSearch.aspx?in1=" + in1;
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 2; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 1) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmQuotationProductSearch", 1100, 600);
}

/****************************************
* Call Sales Product Search form
*****************************************/
function showSearchSalesProduct(in1, in2, out1, out2, callBackFunctionName) {

    /// <summary>
    /// Shows the search sales product.
    /// </summary>
    /// <param name="in1">The in1.(Product Code)</param>
    /// <param name="in2">The in2.(Product Name)</param>
    /// <param name="out1">The out1.(SalesID)</param>
    /// <param name="out2">The out2.(InternalID)</param>
    /// <param name="callBackFunctionName">Name of the call back function.</param>
    /// <returns></returns>

    //var url = "../Search/FrmSalesProductSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmSalesProductSearch.aspx?in1=" + in1;
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 2; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 1) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmSalesProductSearch", 1100, 600);
}

/****************************************
* Call Purchase Product Search form
*****************************************/
function showSearchPurchaseProduct(in1, in2, out1, out2, callBackFunctionName) {

    /// <summary>
    /// Shows the search sales product.
    /// </summary>
    /// <param name="in1">The in1.(Product Code)</param>
    /// <param name="in2">The in2.(Product Name)</param>
    /// <param name="out1">The out1.(PurchaseID)</param>
    /// <param name="out2">The out2.(InternalID)</param>
    /// <param name="callBackFunctionName">Name of the call back function.</param>
    /// <returns></returns>

    //var url = "../Search/FrmPurchaseProductSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmPurchaseProductSearch.aspx?in1=" + in1;
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 2; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 1) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmPurchaseProductSearch", 1100, 600);
}


/****************************************
* Call Delivery Product Search form
*****************************************/
function showSearchDeliveryProduct(in1, in2, out1, callBackFunctionName) {

    /// <summary>
    /// Shows the search quotation product.
    /// </summary>
    /// <param name="in1">The in1.(Product Code)</param>
    /// <param name="in2">The in2.(Product Name)</param>
    /// <param name="out1">The out1.(InternalID)</param>
    /// <param name="callBackFunctionName">Name of the call back function.</param>
    /// <returns></returns>

    //var url = "../Search/FrmQuotationProductSearch.aspx?in1=" + in1.encode() + "&in2=" + in2.encode();
    var url = "../Search/FrmDeliveryProductSearch.aspx?in1=" + in1;
    var length = arguments.length;
    if ('undefined' != typeof callBackFunctionName) {
        length -= 1;
    }
    for (var i = 2; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 1) + "=" + arguments[i];
        }
    }
    if ('undefined' != typeof callBackFunctionName) {
        url = url + "&CallBackFunction=" + callBackFunctionName;
    }
    openWindow(url, "FrmDeliveryProductSearch", 1100, 600);
}

var $opener;
var $iopn = false;

/**
* windowのポップアップ
*/
function openWindow(url, name, width, height) {

    /// <summary locid='1'>windowのポップアップ</summary>
    /// <param name='url' locid='2'>URL</param>
    /// <param name='name' locid='3'>Window Name</param>
    /// <param name='width' locid='4'>Width</param>
    /// <param name='height' locid='5'>Height</param>

    var windowFeatures = "";
    //windowFeatures = "menubar=no,location=no,resizable=yes,scrollbars=yes,status=no";
    windowFeatures = "menubar=no, titlebar=no, toolbar=no,scrollbars=yes, resizable=no, left=" + (screen.availWidth - width) / 2 + ",top=" + (screen.availHeight - height) / 2 + ", width=" + width + ", height=" + height + ", directories=no,location=no";
    if (!$iopn) {
        $iopn = true;

        $opener = window.open(url, name, windowFeatures);
        isOpenerClosed();
    }
}

var timeOutStack = [0, 0];
/**
* Check Window.opener is closing
*/
function isOpenerClosed() {
    if ($opener.closed) {
        $iopn = false;
        $.each(timeOutStack, function (i, id) {
            clearTimeout(id);
        });
        hideLoading();
    } else {
        var id = window.setTimeout("isOpenerClosed()", 500);
        if (id % 2 == 0) {
            timeOutStack[1] = id;
        } else {
            timeOutStack[0] = id;
        }
    }
    //console.log(new Date());
}

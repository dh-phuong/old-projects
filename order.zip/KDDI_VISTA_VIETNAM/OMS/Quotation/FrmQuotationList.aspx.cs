﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;

//----------------------
using NPOI.SS.UserModel;
using OMS.DAC;
using OMS.Models;
using OMS.Reports.EXCEL;
using OMS.Utilities;

//-----------------------

namespace OMS.Quotation
{
    public partial class FrmQuotationList : FrmBaseList
    {
        #region Contanst Excel

        private const string EXCEL_QUOTATION_DOWNLOAD = "Quotation_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";

        #endregion Contanst Excel

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)this.ViewState["Collapse"]; }
            set { this.ViewState["Collapse"] = value; }
        }

        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Quotation";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = "Expired";
            this.PagingHeader.DangerText = "Lost";

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtQuoteNo.MaxLength = T_Quote_H.QUOTE_NO_MAX_LENGTH;
            this.txtSubject.MaxLength = T_Quote_H.PROJECT_NAME_MAX_LENGTH;
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSale1CD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSale2CD.MaxLength = M_User.MAX_USER_CODE_SHOW;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.SetAuthority(FormId.Quotation);
            if (!base._authority.IsQuotationView)
            {
                base.RedirectUrl(URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = URL_MAIN_MENU;
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();
                    //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        this.ShowCondition(para);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnSearch Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var filename = string.Format(EXCEL_QUOTATION_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            Hashtable nextPage = new Hashtable();
            nextPage.Add("ID", null);

            //Next Page
            base.NextPage(this.BackUpCondition(), nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_QUOTE_LIST);
        }

        /// <summary>
        /// Adding a new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            Hashtable nextPage = new Hashtable();
            nextPage.Add("ID", int.Parse(e.CommandArgument.ToString()));

            //Next Page
            base.NextPage(this.BackUpCondition(), nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_QUOTE_LIST);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion Event

        #region Methods

        /// <summary>
        /// Save condition search
        /// </summary>
        private Hashtable BackUpCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.cmbInvalidData.ID, this.cmbInvalidData.SelectedValue);
            hash.Add(this.cmbStatus.ID, this.cmbStatus.SelectedValue);
            hash.Add(this.cmbSalesData.ID, this.cmbSalesData.SelectedValue);

            hash.Add(this.txtQuoteNo.ID, this.txtQuoteNo.Value);
            hash.Add(this.dtQuoteDateFrom.ID, this.dtQuoteDateFrom.Value);
            hash.Add(this.dtQuoteDateTo.ID, this.dtQuoteDateTo.Value);
            hash.Add(this.txtCustomerCD.ID, this.txtCustomerCD.Value);
            M_Customer cus = this.GetCustomerModel(this.txtCustomerCD.Value);
            if (cus != null)
            {
                hash.Add(this.txtCustomerName.ID, cus.CustomerName1);
            }
            else
            {
                hash.Add(this.txtCustomerName.ID, string.Empty);
            }
            hash.Add(this.txtSubject.ID, this.txtSubject.Value);
            hash.Add(this.txtPreparedCD.ID, this.txtPreparedCD.Value);
            M_User uPre = this.GetUserModel(this.txtPreparedCD.Value);
            if (uPre != null)
            {
                hash.Add(this.txtPreparedName.ID, uPre.UserName2);
            }
            else
            {
                hash.Add(this.txtPreparedName.ID, string.Empty);
            }

            hash.Add(this.txtSale1CD.ID, this.txtSale1CD.Value);
            M_User uSale1 = this.GetUserModel(this.txtSale1CD.Value);
            if (uSale1 != null)
            {
                hash.Add(this.txtSale1Name.ID, uSale1.UserName2);
            }
            else
            {
                hash.Add(this.txtSale1Name.ID, string.Empty);
            }

            hash.Add(this.txtSale2CD.ID, this.txtSale2CD.Value);
            M_User uSale2 = this.GetUserModel(this.txtSale2CD.Value);
            if (uSale2 != null)
            {
                hash.Add(this.txtSale2Name.ID, uSale2.UserName2);
            }
            else
            {
                hash.Add(this.txtSale2Name.ID, string.Empty);
            }
            hash.Add("QuoteNoReadOnly", this.txtQuoteNo.ReadOnly);
            hash.Add("DeletedFlag", this.cmbInvalidData.SelectedValue);
            hash.Add("SalesData", this.cmbSalesData.SelectedValue);

            hash.Add("hdQuotationNoDefaut", this.hdQuotationNoDefaut.Value);
            hash.Add("hdDeletedDataDefaultRef", this.hdDeletedDataDefaultRef.Value);
            hash.Add("hdSalesDataRef", this.hdSalesDataRef.Value);
            hash.Add("hdInValidDefault", this.hdInValidDefault.Value);
            hash.Add("hdSalesDefault", this.hdSalesDefault.Value);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            return hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            if (data.ContainsKey(this.cmbInvalidData.ID))
            {
                this.cmbInvalidData.SelectedValue = (string)data[this.cmbInvalidData.ID];
            }
            if (data.ContainsKey(this.cmbStatus.ID))
            {
                this.cmbStatus.SelectedValue = (string)data[this.cmbStatus.ID];
            }
            if (data.ContainsKey(this.cmbSalesData.ID))
            {
                this.cmbSalesData.SelectedValue = (string)data[this.cmbSalesData.ID];
            }
            if (data.ContainsKey(this.txtQuoteNo.ID))
            {
                this.txtQuoteNo.Value = (string)data[this.txtQuoteNo.ID];
                this.hdQuotationNoDefaut.Value = (string)data[this.txtQuoteNo.ID];
            }

            this.dtQuoteDateFrom.Value = null;
            if (data.ContainsKey(this.dtQuoteDateFrom.ID))
            {
                if (data[this.dtQuoteDateFrom.ID] != null)
                {
                    this.dtQuoteDateFrom.Value = (DateTime)data[this.dtQuoteDateFrom.ID];
                }
            }

            this.dtQuoteDateTo.Value = null;
            if (data.ContainsKey(this.dtQuoteDateTo.ID))
            {
                if (data[this.dtQuoteDateTo.ID] != null)
                {
                    this.dtQuoteDateTo.Value = (DateTime)data[this.dtQuoteDateTo.ID];
                }
            }
            if (data.ContainsKey(this.txtCustomerCD.ID))
            {
                this.txtCustomerCD.Value = (string)data[this.txtCustomerCD.ID];
            }
            if (data.ContainsKey(this.txtCustomerName.ID))
            {
                this.txtCustomerName.Value = (string)data[this.txtCustomerName.ID];
            }
            if (data.ContainsKey(this.txtSubject.ID))
            {
                this.txtSubject.Value = (string)data[this.txtSubject.ID];
            }
            if (data.ContainsKey(this.txtPreparedCD.ID))
            {
                this.txtPreparedCD.Value = (string)data[this.txtPreparedCD.ID];
            }
            if (data.ContainsKey(this.txtPreparedName.ID))
            {
                this.txtPreparedName.Value = (string)data[this.txtPreparedName.ID];
            }
            if (data.ContainsKey(this.txtSale1CD.ID))
            {
                this.txtSale1CD.Value = (string)data[this.txtSale1CD.ID];
            }
            if (data.ContainsKey(this.txtSale1Name.ID))
            {
                this.txtSale1Name.Value = (string)data[this.txtSale1Name.ID];
            }
            if (data.ContainsKey(this.txtSale2CD.ID))
            {
                this.txtSale2CD.Value = (string)data[this.txtSale2CD.ID];
            }
            if (data.ContainsKey(this.txtSale2Name.ID))
            {
                this.txtSale2Name.Value = (string)data[this.txtSale2Name.ID];
            }

            if (data.ContainsKey("DeletedFlag"))
            {
                this.cmbInvalidData.SelectedValue = (string)data["DeletedFlag"];
                this.hdDeletedDataDefaultRef.Value = (string)data["DeletedFlag"];
            }
            if (data.ContainsKey("SalesData"))
            {
                this.cmbSalesData.SelectedValue = (string)data["SalesData"];
                this.hdSalesDataRef.Value = (string)data["SalesData"];
            }

            if (data.ContainsKey("QuoteNoReadOnly"))
            {
                this.txtQuoteNo.ReadOnly = (bool)data["QuoteNoReadOnly"];
                if (this.txtQuoteNo.ReadOnly)
                {
                    this.hdQuotationNoDefaut.Value = this.txtQuoteNo.Value;
                }
            }
            if (data.ContainsKey("hdQuotationNoDefaut"))
            {
                this.hdQuotationNoDefaut.Value = (string)data["hdQuotationNoDefaut"];
            }

            if (data.ContainsKey("hdDeletedDataDefaultRef"))
            {
                this.hdDeletedDataDefaultRef.Value = (string)data["hdDeletedDataDefaultRef"];
            }
            if (data.ContainsKey("hdSalesDataRef"))
            {
                this.hdSalesDataRef.Value = (string)data["hdSalesDataRef"];
            }
            if (data.ContainsKey("hdInValidDefault"))
            {
                this.hdInValidDefault.Value = (string)data["hdInValidDefault"];
            }
            if (data.ContainsKey("hdSalesDefault"))
            {
                this.hdSalesDefault.Value = (string)data["hdSalesDefault"];
            }
            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = (int)data["CurrentPage"];
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }
            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = (int)data["NumRowOnPage"];
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }
            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }
            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Quote Date
            this.dtQuoteDateFrom.Value = DateTime.Now.AddMonths(-3);
            //this.dtQuoteDateTo.Value = DateTime.Now;
            this.dtQuoteDateTo.Value = null;

            // Default data valid
            this.hdInValidDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdQuoteDateFrmDefault.Value = this.dtQuoteDateFrom.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            //this.hdQuoteDateToDefault.Value = this.dtQuoteDateTo.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            // Default status data
            this.hdStatusDefault.Value = "-1";
            // Default data sales
            this.hdSalesDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Invalid
            this.InitCombobox(this.cmbInvalidData, this.hdInValidDefault.Value);

            //Status
            this.InitCmbStatus();

            //Sold
            this.InitCombobox(this.cmbSalesData, this.hdSalesDefault.Value);

            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            //Disable button
            base.DisabledLink(this.btnNew, !base._authority.IsQuotationNew);
            base.DisabledLink(this.btnExcel, !base._authority.IsQuotationExcel);
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();

            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Init Combobox Status
        /// </summary>
        private void InitCmbStatus()
        {
            // init combox
            IList<DropDownModel> lstStatus = null;
            using (DB db = new DB())
            {
                Config_HService configHSer = new Config_HService(db);
                lstStatus = configHSer.GetDataForDropDownListWithoutLostSales(M_Config_H.CONFIG_CD_STATUS, true);
            }
            if (lstStatus != null)
            {
                this.cmbStatus.DataSource = lstStatus;
                this.cmbStatus.DataValueField = "Value";
                this.cmbStatus.DataTextField = "DisplayName";
                this.cmbStatus.DataBind();
            }
        }

        /// <summary>
        /// Get model input for search action
        /// </summary>
        /// <returns></returns>
        private QuotationHeaderSearch GetSearchModel()
        {
            QuotationHeaderSearch ret = new QuotationHeaderSearch();

            ret.QuoteNo = this.txtQuoteNo.Value;
            ret.QuoteDateFrom = this.dtQuoteDateFrom.Value;
            ret.QuoteDateTo = this.dtQuoteDateTo.Value;
            ret.CustomerCD = this.txtCustomerCD.Value;
            ret.PreparedCD = this.txtPreparedCD.Value;
            ret.Sale1CD = this.txtSale1CD.Value;
            ret.Sale2CD = this.txtSale2CD.Value;
            ret.Subject = this.txtSubject.Value;
            ret.Status = short.Parse(this.cmbStatus.SelectedValue);
            ret.StatusName = this.cmbStatus.SelectedItem.Text;
            ret.Invalid = short.Parse(this.cmbInvalidData.SelectedValue);
            ret.InvalidName = this.cmbInvalidData.SelectedItem.Text;
            ret.Sales = short.Parse(this.cmbSalesData.SelectedValue);
            ret.SalesName = this.cmbSalesData.SelectedItem.Text;

            return ret;
        }

        /// <summary>
        /// Load data for grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }
            //Reset Name for condition search
            this.ResetName();
            int totalRow = 0;

            IList<QuotationHeaderResult> listResult;
            QuotationHeaderSearch modelInput = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Quotation_HService quotationSer = new Quotation_HService(db);
                totalRow = quotationSer.GetTotalRow(modelInput);
                listResult = quotationSer.GetListByCond(modelInput, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listResult.Count == 0)
            {
                this.rptQuoteList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Quote No.", "Date", "Exp. Date", "Customer", "Subject", "N#Grand Total" });

                // detail
                this.rptQuoteList.DataSource = listResult;
            }

            this.rptQuoteList.DataBind();
        }

        /// <summary>
        /// Reset Name For Search Condition
        /// </summary>
        private void ResetName()
        {
            //CustomerName
            this.txtCustomerName.Value = null;
            M_Customer cus = this.GetCustomerModel(this.txtCustomerCD.Value);
            if (cus != null)
            {
                this.txtCustomerName.Value = cus.CustomerName1;
            }
            //PreparedName
            this.txtPreparedName.Value = null;
            M_User u = this.GetUserModel(this.txtPreparedCD.Value);
            if (u != null && u.ID != Constant.DEFAULT_ID
                          && u.StatusFlag == 0)
            {
                this.txtPreparedName.Value = u.UserName2;
            }

            //Sale1 Name
            this.txtSale1Name.Value = null;
            u = this.GetUserModel(this.txtSale1CD.Value);
            if (u != null && u.ID != Constant.DEFAULT_ID
                          && u.StatusFlag == 0)
            {
                this.txtSale1Name.Value = u.UserName2;
            }

            //Sale2 Name
            this.txtSale2Name.Value = null;
            u = this.GetUserModel(this.txtSale2CD.Value);
            if (u != null && u.ID != Constant.DEFAULT_ID
                          && u.StatusFlag == 0)
            {
                this.txtSale2Name.Value = u.UserName2;
            }
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Quote Date
            if (this.dtQuoteDateFrom.Value != null && this.dtQuoteDateTo.Value != null)
            {
                if (this.dtQuoteDateFrom.Value.Value.Date > this.dtQuoteDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtQuoteDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Quote Date From", "Quote Date To");
                }
            }
            //Has errors
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptQuoteList.DataSource = null;
                this.rptQuoteList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #endregion Methods

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            QuotationListExcel excel = new QuotationListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        #endregion Event Excel

        #region Web Methods

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion Web Methods
    }
}
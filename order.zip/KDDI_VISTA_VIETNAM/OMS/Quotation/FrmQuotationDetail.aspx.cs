﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using OMS.Controls;
using OMS.DAC;
using OMS.Models;
using OMS.Reports.PDF;
using OMS.Utilities;

namespace OMS.Quotation
{
    /// <summary>
    /// Class FrmQuotationDetail
    /// </summary>
    public partial class FrmQuotationDetail : FrmBaseDetail
    {
        #region Constant

        private const string FMT_YMDHMM = "yyMMddHHmm";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        private const string PDF_QUOTATION_DOWNLOAD = "Quotation_{0}.pdf";

        #endregion Constant

        #region Property

        #region Public

        /// <summary>
        /// Get or set QuoteID
        /// </summary>
        public int DataID
        {
            get
            {
                return base.GetValueViewState<int>("DataID");
            }
            set { this.ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldUpdateDate"); }
            set { this.ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public string DefaultVAT
        {
            get { return base.GetValueViewState<string>("DefaultVAT"); }
            private set { this.ViewState["DefaultVAT"] = value; }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public string DefaultVatType
        {
            get
            {
                return this._defaultVatType;
            }
        }

        /// <summary>
        /// Decimal digit of quantity
        /// </summary>
        private int QtyDecDigit
        {
            get { return base.GetValueViewState<int>("QtyDecDigit"); }
            set { this.ViewState["QtyDecDigit"] = value; }
        }

        /// <summary>
        /// Default row cost status
        /// </summary>
        public string DefaultCostView
        {
            get { return base.GetValueViewState<string>("DefaultCostView"); }
            private set { this.ViewState["DefaultCostView"] = value; }
        }

        /// <summary>
        /// Use for AJAX
        /// </summary>
        public string MethodVATEach
        {
            get
            {
                return M_Config_D.METHOD_VAT_EACH;
            }
        }

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        public bool IsNew
        {
            get { return base.GetValueViewState<bool>("IsNew"); }
            private set { this.ViewState["IsNew"] = value; }
        }

        public bool Issued
        {
            get { return base.GetValueViewState<bool>("Issued"); }
            private set { this.ViewState["Issued"] = value; }
        }

        public bool Losted
        {
            get { return base.GetValueViewState<bool>("Losted"); }
            private set { this.ViewState["Losted"] = value; }
        }

        public bool Sold
        {
            get { return base.GetValueViewState<bool>("Sold"); }
            private set { this.ViewState["Sold"] = value; }
        }

        public bool Prev
        {
            get { return base.GetValueViewState<bool>("Prev"); }
            private set { this.ViewState["Prev"] = value; }
        }

        public bool Next
        {
            get { return base.GetValueViewState<bool>("Next"); }
            private set { this.ViewState["Next"] = value; }
        }

        /// <summary>
        /// File count
        /// </summary>
        public int FileCount
        {
            get { return base.GetValueViewState<int>("FileCount"); }
            private set { this.ViewState["FileCount"] = value; }
        }

        /// <summary>
        /// 商品情報設定
        /// </summary>
        public string ProductCdSetting
        {
            get
            {
                return this._productCdSetting;
            }
        }

        /// <summary>
        /// 使用する商品コード
        /// </summary>
        public bool ProductCdUsed
        {
            get;
            private set;
        }

        #endregion Public

        #region private

        private string OldCondition
        {
            get { return base.GetValueViewState<string>("oldCondition"); }
            set { this.ViewState["oldCondition"] = value; }
        }

        private ActionMode Action
        {
            get { return base.GetValueViewState<ActionMode>("ActionMode"); }
            set { this.ViewState["ActionMode"] = value; }
        }

        /// <summary>
        /// ChildRowCommandArgument
        /// </summary>
        private string ChildRowCommandArgument
        {
            get { return base.GetValueViewState<string>("ChildRowCommandArgument"); }
            set { this.ViewState["ChildRowCommandArgument"] = value; }
        }

        #endregion private

        #endregion Property

        #region Variable

        private enum ActionMode
        {
            /// <summary>
            /// None
            /// </summary>
            None = 0,

            /// <summary>
            /// Issue
            /// </summary>
            Issue = 1,

            /// <summary>
            /// Sales
            /// </summary>
            Sales = 2,

            /// <summary>
            /// DeleteRow
            /// </summary>
            DeleteRow = 3,

            /// <summary>
            /// Prev
            /// </summary>
            Prev = 4,

            /// <summary>
            /// Next
            /// </summary>
            Next = 5,

            /// <summary>
            /// CurrencyChanged
            /// </summary>
            CurrencyChanged = 6,

            /// <summary>
            /// MethodChanged
            /// </summary>
            MethodChanged = 7,

            /// <summary>
            /// CurrencyCostChanged
            /// </summary>
            CurrencyCostChanged = 8,

            /// <summary>
            /// Copy
            /// </summary>
            Copy = 9,

            /// <summary>
            /// Revise
            /// </summary>
            Revise = 10,

            /// <summary>
            /// Remove Child Row(Cost)
            /// </summary>
            RemoveChildRow = 11,

            /// <summary>
            /// Copy data from sell row
            /// </summary>
            CopyFromSellRow = 12,

            /// <summary>
            /// Copy data from cost row
            /// </summary>
            CopyFromCostRow = 13
        }

        /// <summary>
        /// Have Pre and next quotation status
        /// </summary>
        private enum PreNextStatus
        {
            NoPreNoNext = 0,
            HavePreNoNext,
            NoPreHaveNext,
            HavePreHaveNext
        }

        /// <summary>
        /// UnitList
        /// </summary>
        private IList<DropDownModel> _unitList;

        /// <summary>
        /// ExchangeRateList
        /// </summary>
        private IList<DropDownModel> _currencyList;

        /// <summary>
        /// MethodVatList
        /// </summary>
        private IList<DropDownModel> _methodVatList;

        /// <summary>
        /// StatusList
        /// </summary>
        private IList<DropDownModel> _statusList;

        /// <summary>
        /// VatTypeList
        /// </summary>
        private IList<DropDownModel> _vatTypeList;

        private IList<DropDownModel> _vatTypeListEmpty = new List<DropDownModel>();

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string _defaultMethodVat;

        /// <summary>
        /// DefaultStatus
        /// </summary>
        private string _defaultStatus;

        /// <summary>
        /// DefaultStatus
        /// </summary>
        private string _defaultVatType;

        /// <summary>
        /// Round type
        /// </summary>
        private FractionType _defaultFractionType;

        /// <summary>
        /// Default profit value
        /// </summary>
        private decimal? _defaultProfit;

        private string _profitSetting;

        /// <summary>
        /// ProductCD Mode
        /// </summary>
        private string _productCdSetting;

        /// <summary>
        /// SellNo when Databound
        /// </summary>
        private int _sellNoDataBound = 0;

        #endregion Variable

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Quotation";
            base.FormSubTitle = "Detail";

            this.hdnProductSellType.Value = ((int)ProductType.Sell).ToString();
            this.hdnProductCostType.Value = ((int)ProductType.Cost).ToString();

            this.InitMaxLength();

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(ProcessConfirm);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(RestoreValue);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadPDF_Click);

            //Back
            this.btnBackView.Click += new EventHandler(btnBackView_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get Default Data
            this.GetDefaultData();
            if (!base._authority.IsQuotationView)
            {
                base.RedirectUrl(URL_MAIN_MENU);
            }
            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = URL_QUOTE_LIST;
            }

            #region OnLoad

            if (!this.IsPostBack)
            {
                this.Action = ActionMode.None;

                //Init DropDownList
                this.InitDropDownListData(this.cmbCurrency, this._currencyList);
                this.InitDropDownListData(this.cmbStatus, this._statusList);
                this.InitDropDownListData(this.cmbMethodVat, this._methodVatList);
                this.InitDropDownListData(this.cmbVatType, this._vatTypeList);

                this.hdnFractionType.Value = ((int)this._defaultFractionType).ToString();
                this.hdnProductCdSetting.Value = this._productCdSetting;

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        //Save URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        //Check para
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get Quote ID
                            this.DataID = int.Parse(para["ID"].ToString());
                            var header = this.GetByID(this.DataID);
                            if (header != null)
                            {
                                //Show data
                                this.SetQuoteInfo(this.DataID);
                                //Set Mode
                                this.ProcessMode(Mode.View);

                                //Reference from Sales
                                this.ViewState["SalesNo"] = para["SalesNo"];
                                this.ViewState["MesgID"] = para["MesgID"];
                                if (para["MesgID"] != null)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Sales", "Sales No.", this.ViewState["SalesNo"], this.ViewState["SalesNo"]);
                                }
                            }
                            else
                            {
                                base.RedirectUrl(URL_QUOTE_LIST);
                            }
                        }
                        else
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            #endregion OnLoad

            //Set Back URL
            this.btnBackView.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Add Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();

            IList<QuotationDetailInfo> list = this.GetDetailData();

            QuotationDetailInfo sell = new QuotationDetailInfo();
            sell.Type = QuotationDetailType.Sell;
            sell.Sell = new SellInfo();
            sell.Sell.Profit = this._defaultProfit;
            sell.No = list.Count + 1;
            var defaultVatType = -1;
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
            {
                defaultVatType = int.Parse(this._defaultVatType);
            }
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                sell.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            sell.Sell.VatType = defaultVatType;
            sell.Sell.SellNoDisp = list.Where(s => s.Type == QuotationDetailType.Sell).Count() + 1;
            sell.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            sell.CostList = new List<CostInfo>();
            CostInfo costInfo = new CostInfo();
            costInfo.SellNo = sell.Sell.SellNoDisp;

            costInfo.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            costInfo.No = 1;
            defaultVatType = int.Parse(this._defaultVatType);
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                costInfo.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            costInfo.VatType = defaultVatType;
            sell.CostList.Add(costInfo);

            list.Add(sell);
            this.chkDelAll.Checked = false;

            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();

            if (this.ProductCdUsed)
            {
                this.FocusControlId = string.Format("txtSellProductCD_{0}", sell.No - 1);
            }
            else
            {
                this.FocusControlId = string.Format("txtSellProductName_{0}", sell.No - 1);
            }
        }

        /// <summary>
        /// Add HeadLine
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddHeadLine_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            //Get Data
            IList<QuotationDetailInfo> list = this.GetDetailData();

            QuotationDetailInfo head = new QuotationDetailInfo();
            head.No = list.Count + 1;
            head.Type = QuotationDetailType.HeadLine;
            list.Add(head);

            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();

            this.FocusControlId = string.Format("txtHeadLine_{0}", head.No - 1);
        }

        /// <summary>
        /// Delete row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRow_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            this.Action = ActionMode.DeleteRow;
        }

        /// <summary>
        /// Up row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUp_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            //Get Data
            this.SwapDetail(true);
        }

        /// <summary>
        /// Down row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDown_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            //Get Data
            this.SwapDetail(false);
        }

        /// <summary>
        /// Calc total profit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSumProfitProcess_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();

            this.RefreshDetails();
            this.FocusControlId = this.btnSumProfitProcess.ClientID;
        }

        /// <summary>
        /// Revise Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnRevise_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnRevise.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (header.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                        return;
                    }
                }
                //Show data
                this.SetQuoteInfo(this.DataID);
                this.ProcessMode(Utilities.Mode.View);
                if (isOk)
                {
                    //Show question copy data
                    base.ShowQuestionMessage(M_Message.MSG_MAKE_REVISE, Models.DefaultButton.Yes, true, "");

                    this.Action = ActionMode.Revise;
                }
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnEdit.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (header.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                        return;
                    }
                }

                //Show data
                this.SetQuoteInfo(this.DataID);
                this.ProcessMode(Utilities.Mode.View);
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// Prev Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnPrev_Click(object sender, EventArgs e)
        {
            this.Action = ActionMode.None;
            this.ViewPrevQuote();
        }

        /// <summary>
        /// Next Edit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnNext_Click(object sender, EventArgs e)
        {
            this.Action = ActionMode.None;
            this.ViewNextQuote();
        }

        /// <summary>
        /// Event Copy
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                //Show data
                this.SetQuoteInfo(this.DataID);

                //Show question copy data
                base.ShowQuestionMessage(M_Message.MSG_MAKE_COPY, Models.DefaultButton.Yes, true);
                this.Action = ActionMode.Copy;
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// btnSales Click
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSales_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnSales.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (header.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                        return;
                    }
                }

                //Show data
                this.SetQuoteInfo(this.DataID);
                this.ProcessMode(Utilities.Mode.View);
                if (isOk)
                {
                    this.Action = ActionMode.Sales;

                    //Show question insert
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_MOVED_TO_SALES, Models.DefaultButton.Yes);
                }
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// Event Isssue
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnIssue_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnIssue.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (header.DeleteFlag == 1)
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                        return;
                    }
                }

                //Show data
                this.SetQuoteInfo(this.DataID);
                this.ProcessMode(Utilities.Mode.View);
                if (isOk)
                {
                    this.Action = ActionMode.Issue;
                    if (header.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, false, "PDF");
                    }
                }
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    var fileName = string.Format("{0}.pdf", this.txtQuotationNo.Value);
                    Response.ContentType = "application/pdf";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                    Response.Flush(); // send it to the client to download
                }
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            this.SetSellMarkup(this.txtQuotationDate.Value.GetValueOrDefault());
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            this.SetSellMarkup(this.txtQuotationDate.Value.GetValueOrDefault());
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                //Show data
                this.SetQuoteInfo(this.DataID);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_QUOTE_LIST);
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBackView_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// Reference to Sales
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRef_Click(object sender, EventArgs e)
        {
            //Sales No
            var salesNo = this.hdnSalesNo.Value;

            Hashtable currentPage = new Hashtable();
            currentPage.Add("ID", this.DataID);
            currentPage.Add("SalesNo", salesNo);
            currentPage.Add("MesgID", M_Message.MSG_PROCESS_COMPLETED);

            //Get QuoteNo
            using (DB db = new DB())
            {
                var acptHSrv = new Sales_HService(db);
                //Process reference parameter
                Hashtable nextPage = new Hashtable();
                nextPage.Add("ID", acptHSrv.GetBySalesNo(salesNo).ID);
                base.NextPage(currentPage, nextPage, (string)this.ViewState["BACK_URL"], FrmBase.URL_QUOTE_DETAIL);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void ProcessConfirm(object sender, EventArgs e)
        {
            var methodVAT = this.cmbMethodVat.SelectedValue;
            var defaultVatType = int.Parse(this._defaultVatType);
            switch (this.Action)
            {
                case ActionMode.None:
                    T_Quote_H quoteH = null;
                    IList<QuotationDetailInfo> details = null;
                    int sellNo, no;
                    string[] keys;
                    break;

                case ActionMode.Issue:

                    #region Issue

                    this.Action = ActionMode.None;

                    QuotationPDF rptQuotation = new QuotationPDF();
                    rptQuotation.LoginInfo = this.LoginInfo;
                    var uniqueFileName = string.Format(PDF_QUOTATION_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                    this.ExportPDF(rptQuotation.GetLocalReport(new LocalReport(), this.DataID, this.OldUpdateDate), uniqueFileName, true);

                    //Show data
                    this.SetQuoteInfo(this.DataID);
                    //Set Mode
                    this.ProcessMode(Mode.View);
                    return;

                    #endregion Issue

                case ActionMode.Sales:

                    #region Sales

                    this.Action = ActionMode.None;
                    string salesNo = string.Empty;
                    if (this.MakeSalesData(ref salesNo))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Sales", "Sales No.", salesNo, salesNo);
                    }
                    //Show data
                    this.SetQuoteInfo(this.DataID);

                    //Set Mode
                    this.ProcessMode(Mode.View);

                    return;

                    #endregion Sales

                case ActionMode.DeleteRow:

                    #region DeleteRow

                    this.Action = ActionMode.None;

                    //Get Data
                    details = this.GetDetailData(false);
                    if (details.Count == 0)
                    {
                        this.AddEmptyRow(1, ref details);

                        this.chkDelAll.Checked = false;
                    }
                    this.RefreshDetails(details);

                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData(false);
                    return;

                    #endregion DeleteRow

                case ActionMode.RemoveChildRow:

                    #region Delete Child Row(Cost)

                    this.Action = ActionMode.None;

                    keys = this.ChildRowCommandArgument.Split('_');
                    sellNo = Convert.ToInt32(keys[0]);
                    no = Convert.ToInt32(keys[1]);

                    //Get Data
                    details = this.GetDetailData();

                    var removedSell = details.Where(s => s.Type == QuotationDetailType.Sell && s.Sell.SellNoDisp == sellNo).SingleOrDefault();
                    removedSell.Sell.Collapsed = "in";
                    if (removedSell.CostList.Count != 0)
                    {
                        removedSell.CostList.RemoveAt(no - 1);
                        var costNo = 1;
                        foreach (var cost in removedSell.CostList)
                        {
                            cost.No = costNo++;
                        }
                    }

                    if (removedSell.CostList.Count == 0)
                    {
                        var costInfo = new CostInfo
                        {
                            SellNo = sellNo,
                            No = 1,
                            VatRatio = decimal.Parse(this.DefaultVAT),
                            //Collapsed = "in"
                        };
                        defaultVatType = int.Parse(this._defaultVatType);
                        if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            costInfo.VatRatio = decimal.Parse(this.DefaultVAT);
                        }
                        costInfo.VatType = defaultVatType;
                        removedSell.CostList.Add(costInfo);
                    }
                    this.RefreshDetails(details);
                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData();

                    var lastOfCost = removedSell.CostList.LastOrDefault();
                    this.FocusControlId = string.Format("{0}_txtCostProductCD_{1}", removedSell.No - 1, lastOfCost.No - 1);

                    if (this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME || !this.ProductCdUsed)
                    {
                        this.FocusControlId = string.Format("{0}_txtCostProductName_{1}", removedSell.No - 1, lastOfCost.No - 1);
                    }
                    return;

                    #endregion Delete Child Row(Cost)

                case ActionMode.CurrencyChanged:

                    #region CurrencyChanged

                    this.FocusControlId = this.cmbCurrency.ClientID;
                    var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                    var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtSellPrice");
                            INumberTextBox txtSellTotal = (INumberTextBox)item.FindControl("txtSellTotal");
                            INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");

                            //Set decimal digit control sell by exchange
                            this.SetDecimalDigit(crcySelected, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                            //Reset null value
                            txtSellPrice.Value = null;
                            txtSellTotal.Value = null;
                            txtSellVat.Value = null;

                            var label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellVatExchangeRate");
                            label.InnerHtml = crcySelected.MoneyCode;
                            this.lblSumTotalExchangeRate.InnerText = crcySelected.MoneyCode;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellTotalExchangeRate");
                            label.InnerHtml = this.cmbCurrency.SelectedItem.Text;
                            this.lblSumVATExchangeRate.InnerText = crcySelected.MoneyCode;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellPriceExchangeRate");
                            label.InnerHtml = this.cmbCurrency.SelectedItem.Text;
                            this.lblGrandTotalExchangeRate.InnerText = crcySelected.MoneyCode;

                            this.lblVATRatio.InnerText = string.Format("{0}/Ratio", crcySelected.TaxName);
                        }
                    }

                    ////Set decimal digit control total by exchange
                    this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                    this.Action = ActionMode.None;
                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData();
                    this.RefreshDetails();

                    if (this.ViewState["HEADER"] != null)
                    {
                        quoteH = (T_Quote_H)this.ViewState["HEADER"];
                        quoteH.CurrencyID = crcyId;
                        this.ViewState["HEADER"] = quoteH;
                    }
                    return;

                    #endregion CurrencyChanged

                case ActionMode.MethodChanged:

                    #region MethodChanged

                    this.Action = ActionMode.None;

                    this.FocusControlId = this.cmbMethodVat.ClientID;

                    defaultVatType = int.Parse(this._defaultVatType);

                    //Set enable control at detail list with method vat type
                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtSellVat");
                            DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbSellVatType");
                            INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtSellVatRatio");

                            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                            {
                                //Enable control sell by method vat
                                txtSellVat.SetReadOnly(false);
                                txtSellVatRatio.SetReadOnly(false);
                                cmbSellVatType.Enabled = true;
                                txtSellVatRatio.Value = decimal.Parse(this.DefaultVAT);
                                this.InitDropDownListData(cmbSellVatType, this._vatTypeList);
                                cmbSellVatType.SelectedValue = defaultVatType.ToString();
                            }
                            else
                            {
                                //Enable control sell by method vat
                                txtSellVat.SetReadOnly(true);
                                txtSellVatRatio.SetReadOnly(true);
                                cmbSellVatType.Enabled = false;
                                txtSellVat.Value = null;
                                txtSellVatRatio.Value = null;
                                this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                            }
                        }
                    }
                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                    {
                        //Set enable control at total with method vat type
                        this.txtVatRatio.SetReadOnly(true);
                        this.txtSumVat.SetReadOnly(false);

                        this.cmbVatType.Enabled = false;

                        this.txtSumProfit.Value = null;
                        this.txtVatRatio.Value = null;
                        this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);
                    }
                    else
                    {
                        //SUM
                        this.InitDropDownListData(this.cmbVatType, this._vatTypeList);
                        this.cmbVatType.SelectedValue = defaultVatType.ToString();
                        this.cmbVatType.Enabled = true;

                        if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            //Set enable control at total with method vat type
                            this.txtVatRatio.SetReadOnly(false);
                            this.txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
                        }
                    }
                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData(false);
                    this.RefreshDetails();
                    if (this.ViewState["HEADER"] != null)
                    {
                        quoteH = (T_Quote_H)this.ViewState["HEADER"];
                        quoteH.MethodVat = short.Parse(methodVAT);
                        this.ViewState["HEADER"] = quoteH;
                    }
                    return;

                    #endregion MethodChanged

                case ActionMode.CurrencyCostChanged:
                    break;

                case ActionMode.Copy:

                    #region Copy

                    this.Action = ActionMode.None;
                    quoteH = this.GetByID(this.DataID);
                    //Check data
                    if (quoteH != null)
                    {
                        var isOk = true;
                        if (quoteH.UpdateDate != this.OldUpdateDate)
                        {
                            this.FocusControlId = this.btnCopy.ClientID;
                            base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            isOk = false;
                            if (quoteH.DeleteFlag == 1)
                            {
                                base.RedirectUrl(URL_QUOTE_LIST);
                                return;
                            }
                        }

                        //Show data
                        this.SetQuoteInfo(this.DataID);
                        this.cmbStatus.SelectedValue = this._defaultStatus;

                        if (isOk)
                        {
                            //Set Mode
                            this.ProcessMode(Mode.Copy);
                        }
                    }
                    else
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                    }
                    return;

                    #endregion Copy

                case ActionMode.Revise:

                    #region Revise

                    this.Action = ActionMode.None;
                    quoteH = this.GetByID(this.DataID);
                    //Check data
                    if (quoteH != null)
                    {
                        var isOk = true;
                        if (quoteH.UpdateDate != this.OldUpdateDate)
                        {
                            this.FocusControlId = this.btnRevise.ClientID;
                            base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            isOk = false;
                            if (quoteH.DeleteFlag == 1)
                            {
                                base.RedirectUrl(URL_QUOTE_LIST);
                                return;
                            }
                        }
                        //Show data
                        this.SetQuoteInfo(this.DataID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        if (isOk)
                        {
                            using (var db = new DB())
                            {
                                var hService = new Quotation_HService(db);

                                var reviseNo = hService.CreateQuoteNoRevise(this.txtQuotationNo.Value);
                                if (!string.IsNullOrEmpty(reviseNo))
                                {
                                    this.txtQuotationNo.Value = reviseNo;
                                    this.FileCount = 0;
                                    //Set Mode
                                    this.ProcessMode(Mode.Revise);
                                }
                                else
                                {
                                    this.SetMessage(this.btnEdit.ClientID, M_Message.MSG_OVERFLOWING_QUOTE);
                                }
                            }
                        }
                    }
                    else
                    {
                        base.RedirectUrl(URL_QUOTE_LIST);
                    }
                    return;

                    #endregion Revise

                case ActionMode.CopyFromCostRow:

                    #region CopyFromCostRow

                    this.Action = ActionMode.None;

                    //Get Data
                    details = this.GetDetailData(true);
                    keys = this.ChildRowCommandArgument.Split('_');

                    int toSellNo = Convert.ToInt32(keys[0]);
                    var toSell = details.Where(s => s.Type == QuotationDetailType.Sell && s.Sell.SellNoDisp == toSellNo).SingleOrDefault();
                    var fromCost = toSell.CostList.FirstOrDefault();
                    if (string.IsNullOrEmpty(fromCost.ProductCD) && string.IsNullOrEmpty(fromCost.ProductName) && string.IsNullOrEmpty(fromCost.Description))
                    {
                        return;
                    }

                    toSell.Sell.Collapsed = "in";
                    if (this.ProductCdUsed)
                    {
                        if (fromCost.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                        {
                            using (var db = new DB())
                            {
                                var prodService = new ProductService(db);
                                var mProd = prodService.GetByCD(fromCost.ProductCD);
                                if (mProd != null && mProd.StatusFlag == 0)
                                {
                                    toSell.Sell.ProductCD = fromCost.ProductCD;
                                    toSell.Sell.ProductName = fromCost.ProductName;
                                    toSell.Sell.Description = fromCost.Description;

                                    toSell.Sell.UnitID = fromCost.UnitID;
                                    toSell.Sell.Quantity = fromCost.Quantity;

                                    toSell.Sell.Remark = mProd.RemarkSell;

                                    var unitPrice = 0m;
                                    var currencyId = int.Parse(this.cmbCurrency.SelectedValue);
                                    if (currencyId == mProd.CurrencyIDSell)
                                    {
                                        unitPrice = mProd.UnitPriceSell;
                                    }
                                    else
                                    {
                                        var baseDate = this.txtQuotationDate.IsEmpty ? db.NowDate : txtQuotationDate.Value.Value;
                                        var crcyService = new Currency_HService(db);
                                        var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                                        //Chuyen tien cua product ve tien mac dinh
                                        if (mProd.CurrencyIDSell == Constant.DEFAULT_ID)
                                        {
                                            unitPrice = mProd.UnitPriceSell;
                                        }
                                        else
                                        {
                                            unitPrice = CommonUtil.ConvertToVND(crcyList[mProd.CurrencyIDSell].ExchangeRate, mProd.UnitPriceSell);
                                        }
                                        // Neu chon loai tien mac dinh thi set tra ve
                                        // Con neu nguoc lai thi chuyen tien ve kieu tien duoc chon
                                        if (currencyId != Constant.DEFAULT_ID)
                                        {
                                            unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyId].ExchangeRate, unitPrice);
                                        }
                                    }
                                    toSell.Sell.Price = unitPrice;

                                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                                    {
                                        toSell.Sell.VatType = mProd.VatTypeSell;
                                        toSell.Sell.VatRatio = mProd.VatRatioSell;
                                    }
                                }
                                this.FocusControlId = string.Format("txtSellProductCD_{0}", toSell.No - 1);
                            }
                        }
                        else
                        {
                            toSell.Sell.ProductCD = fromCost.ProductCD;
                            toSell.Sell.ProductName = fromCost.ProductName;
                            toSell.Sell.Description = fromCost.Description;

                            toSell.Sell.Quantity = fromCost.Quantity;
                            toSell.Sell.UnitID = fromCost.UnitID;

                            this.FocusControlId = string.Format("txtSellProductCD_{0}", toSell.No - 1);
                        }
                    }
                    else
                    {
                        toSell.Sell.ProductName = fromCost.ProductName;
                        toSell.Sell.Description = fromCost.Description;

                        toSell.Sell.Quantity = fromCost.Quantity;
                        toSell.Sell.UnitID = fromCost.UnitID;

                        this.FocusControlId = string.Format("txtSellProductName_{0}", toSell.No - 1);
                    }

                    #endregion CopyFromCostRow

                    this.RefreshDetails(details);
                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData(false);
                    return;

                case ActionMode.CopyFromSellRow:

                    #region CopyFromSellRow

                    this.Action = ActionMode.None;

                    //Get Data
                    details = this.GetDetailData(true);
                    keys = this.ChildRowCommandArgument.Split('_');

                    toSellNo = Convert.ToInt32(keys[0]);
                    var fromCostNo = Convert.ToInt32(keys[1]);

                    toSell = details.Where(s => s.Type == QuotationDetailType.Sell && s.Sell.SellNoDisp == toSellNo).SingleOrDefault();
                    fromCost = toSell.CostList.Where(c => c.No == fromCostNo).FirstOrDefault();
                    if (string.IsNullOrEmpty(toSell.Sell.ProductCD) && string.IsNullOrEmpty(toSell.Sell.ProductName) && string.IsNullOrEmpty(toSell.Sell.Description))
                    {
                        return;
                    }
                    toSell.Sell.Collapsed = "in";
                    if (this.ProductCdUsed)
                    {
                        if (toSell.Sell.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                        {
                            using (var db = new DB())
                            {
                                var prodService = new ProductService(db);
                                var vendService = new VendorService(db);

                                var mProd = prodService.GetByCD(toSell.Sell.ProductCD);
                                if (mProd != null && mProd.StatusFlag == 0)
                                {
                                    fromCost.ProductCD = toSell.Sell.ProductCD;
                                    fromCost.ProductName = toSell.Sell.ProductName;
                                    fromCost.Description = toSell.Sell.Description;

                                    fromCost.Price = mProd.UnitPriceCost;

                                    fromCost.UnitID = toSell.Sell.UnitID;
                                    fromCost.Quantity = toSell.Sell.Quantity;

                                    fromCost.VatType = mProd.VatTypeCost;
                                    fromCost.VatRatio = mProd.VatRatioCost;
                                    fromCost.CurrencyID = mProd.CurrencyIDCost;
                                    fromCost.PurchaseFlag = mProd.PurchaseFlag == 1;
                                    var mVend = vendService.GetFirstOrDefaultByProductID(mProd.ID);
                                    if (mVend != null && mVend.ID != Constant.DEFAULT_ID)
                                    {
                                        fromCost.VendorCD = EditDataUtil.ToFixCodeShow(mVend.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                                        fromCost.VendorName = mVend.VendorName1;
                                    }
                                }
                                this.FocusControlId = string.Format("{0}_txtCostProductCD_{1}", toSellNo - 1, fromCostNo - 1);
                            }
                        }
                        else
                        {
                            fromCost.ProductCD = toSell.Sell.ProductCD;
                            fromCost.ProductName = toSell.Sell.ProductName;
                            fromCost.Description = toSell.Sell.Description;

                            fromCost.Quantity = toSell.Sell.Quantity;
                            fromCost.UnitID = toSell.Sell.UnitID;

                            this.FocusControlId = string.Format("{0}_txtCostProductCD_{1}", toSellNo - 1, fromCostNo - 1);
                        }
                    }
                    else
                    {
                        fromCost.ProductName = toSell.Sell.ProductName;
                        fromCost.Description = toSell.Sell.Description;

                        fromCost.Quantity = toSell.Sell.Quantity;
                        fromCost.UnitID = toSell.Sell.UnitID;

                        this.FocusControlId = string.Format("{0}_txtCostProductName_{1}", toSellNo - 1, fromCostNo - 1);
                    }

                    #endregion CopyFromSellRow

                    this.RefreshDetails(details);
                    this.SetConfirmHeaderData();
                    this.SetConfirmDetailData(false);
                    return;

                default:
                    break;
            }

            #region Check mode

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:
                    //Insert Data
                    if (this.InsertData())
                    {
                        //Show data
                        this.SetQuoteInfo(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Mode.Update:
                    //Update Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.SetQuoteInfo(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Revise:

                    //Revise Data
                    if (this.ReviseData())
                    {
                        //Show data
                        this.SetQuoteInfo(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;
            }

            #endregion Check mode
        }

        /// <summary>
        /// RestoreValue
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void RestoreValue(object sender, EventArgs e)
        {
            if (this.Mode == Utilities.Mode.View)
            {
                this.SetQuoteInfo(this.DataID);
                this.ProcessMode(Utilities.Mode.View);
            }
            else
            {
                switch (this.Action)
                {
                    case ActionMode.None:
                        break;

                    case ActionMode.CurrencyChanged:
                        //Show old value
                        if (this.ViewState["HEADER"] != null)
                        {
                            T_Quote_H header = (T_Quote_H)this.ViewState["HEADER"];
                            this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();
                        }
                        break;

                    case ActionMode.MethodChanged:
                        if (this.ViewState["HEADER"] != null)
                        {
                            T_Quote_H header = (T_Quote_H)this.ViewState["HEADER"];
                            this.cmbMethodVat.SelectedValue = header.MethodVat.ToString();
                        }
                        break;

                    default:
                        break;
                }
            }

            this.Action = ActionMode.None;
        }

        /// <summary>
        /// Change value with exchange rate
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_CURRENCY_CHANGED, Models.DefaultButton.Yes, true);
            this.Action = ActionMode.CurrencyChanged;
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            this.RefreshDetails();
        }

        /// <summary>
        /// Change value with method vat
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbMethodVat_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_METHOD_CHANGED, Models.DefaultButton.Yes, true);
            this.Action = ActionMode.MethodChanged;
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            this.RefreshDetails();
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                QuotationDetailInfo dataItem = (QuotationDetailInfo)e.Item.DataItem;

                //Init Unit Sell
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbSellUnit");
                this.InitDropDownListData(cmbUnit, this._unitList);

                //Init Vat Type Sell
                DropDownList cmbSellVatType = (DropDownList)e.Item.FindControl("cmbSellVatType");
                this.InitDropDownListData(cmbSellVatType, this._vatTypeList);

                HtmlTableRow rowHeadLine = (HtmlTableRow)e.Item.FindControl("rowHeadLine");
                HtmlTableRow rowSell1 = (HtmlTableRow)e.Item.FindControl("rowSell1");
                HtmlTableRow rowSell2 = (HtmlTableRow)e.Item.FindControl("rowSell2");
                Repeater rptCost = (Repeater)e.Item.FindControl("rptCost");

                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                if (this.Action == ActionMode.CurrencyChanged)
                {
                    crcyId = ((T_Quote_H)this.ViewState["HEADER"]).CurrencyID;
                }
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;

                if (dataItem.Type == QuotationDetailType.HeadLine)
                {
                    var txtHeadLine = (ITextBox)e.Item.FindControl("txtHeadLine");
                    txtHeadLine.MaxLength = T_Quote_D_Sell.HEADLINE_MAX_LENGTH;
                    rowSell1.Visible = false;
                    rowSell2.Visible = false;
                }
                else
                {
                    //Set For rptCost_ItemDataBound (parent-item-no)
                    this._sellNoDataBound = dataItem.No;

                    foreach (var item in dataItem.CostList)
                    {
                        item.Collapsed = dataItem.Sell.Collapsed;
                    }

                    var methodVAT = this.cmbMethodVat.SelectedValue;
                    if (this.Action == ActionMode.MethodChanged)
                    {
                        methodVAT = ((T_Quote_H)this.ViewState["HEADER"]).MethodVat.ToString();
                    }

                    //Set selected item for dropdownlist
                    cmbUnit.SelectedValue = dataItem.Sell.UnitID.ToString();

                    var txtSellPrice = (INumberTextBox)e.Item.FindControl("txtSellPrice");
                    var txtSellQuantity = (INumberTextBox)e.Item.FindControl("txtSellQuantity");
                    var txtSellTotal = (INumberTextBox)e.Item.FindControl("txtSellTotal");
                    var txtSellVat = (INumberTextBox)e.Item.FindControl("txtSellVat");
                    var txtSellVatRatio = (INumberTextBox)e.Item.FindControl("txtSellVatRatio");

                    txtSellQuantity.DecimalDigit = this.QtyDecDigit;

                    //---------------Set decimal digit by exchage rate---------------//
                    this.SetDecimalDigit(crcySelected, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);
                    //---------------End Set decimal digit by exchage rate---------------//
                    if (crcySelected.DecimalType == (int)ExchangeRateDecType.Decimal)
                    {
                        txtSellQuantity.MaximumValue = Constant.MAX_QUANTITY_DECIMAL;
                    }
                    else
                    {
                        txtSellQuantity.MaximumValue = Constant.MAX_QUANTITY_NOT_DECIMAL;
                    }

                    rowHeadLine.Visible = false;
                    rptCost.DataSource = dataItem.CostList;
                    rptCost.DataBind();

                    //Set max length
                    var txtSellProductCD = (ICodeTextBox)e.Item.FindControl("txtSellProductCD");

                    txtSellProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;

                    //Search product
                    ITextBox txtSellProductName = (ITextBox)e.Item.FindControl("txtSellProductName");
                    txtSellProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;

                    ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtSellDescription");
                    txtSellDescription.MaxLength = T_Quote_D_Sell.DESCRIPTION_MAX_LENGTH;

                    ITextBox txtSellRemark = (ITextBox)e.Item.FindControl("txtSellRemark");
                    txtSellRemark.MaxLength = T_Quote_D_Sell.REMARK_MAX_LENGTH;

                    HtmlButton btnSearchSellProduct = (HtmlButton)e.Item.FindControl("btnSellProduct");
                    string onclickSearchProduct = "callSearchProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID + "'," + (int)Utilities.ProductType.Sell + ")";

                    btnSearchSellProduct.Attributes.Add("onclick", onclickSearchProduct);

                    var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                                        cmbSellVatType.ClientID,
                                                                                        txtSellPrice.ClientID,
                                                                                        txtSellQuantity.ClientID,
                                                                                        txtSellTotal.ClientID,
                                                                                        txtSellVat.ClientID,
                                                                                        txtSellVatRatio.ClientID);

                    txtSellPrice.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellPrice.ClientID, param));
                    txtSellQuantity.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellQuantity.ClientID, param));
                    txtSellTotal.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellTotal.ClientID, param));
                    txtSellVatRatio.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellVatRatio.ClientID, param));

                    txtSellVat.Attributes.Add("onvaluechange", "calcTotalSell();");
                    //------------------Set enable with method vat-------------------------//

                    this.InitDropDownListData(cmbSellVatType, this._vatTypeList);
                    //Reset value

                    var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellVatExchangeRate");
                    label.InnerHtml = crcySelected.MoneyCode;

                    label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellTotalExchangeRate");
                    label.InnerHtml = crcySelected.MoneyCode;

                    label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellPriceExchangeRate");
                    label.InnerHtml = crcySelected.MoneyCode;

                    //---------------------------Quotation Sell Search Start----------------------//

                    HiddenField hdnQuoteID = (HiddenField)e.Item.FindControl("hdnQuoteID");
                    HiddenField hdnSellNo = (HiddenField)e.Item.FindControl("hdnSellNo");
                    LinkButton cmdSearchSell = (LinkButton)e.Item.FindControl("cmdSearchSell");

                    HtmlButton btnSearchQuotationSell = (HtmlButton)e.Item.FindControl("btnSearchQuotationSell");
                    string onclick = "callSearchQuotationProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID;
                    onclick += "','" + hdnQuoteID.ClientID + "','" + hdnSellNo.ClientID + "','" + cmdSearchSell.ClientID + "');";
                    btnSearchQuotationSell.Attributes.Add("onclick", onclick);

                    //---------------------------Quotation Sell Search End  ----------------------//

                    #region Set Confirm

                    //SellVat
                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        txtSellVat.SetReadOnly(true);
                        txtSellVatRatio.SetReadOnly(true);

                        cmbSellVatType.Enabled = false;
                        txtSellVat.Value = null;
                        txtSellVatRatio.Value = null;
                        this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                    }
                    else
                    {
                        txtSellVat.SetReadOnly(false);
                        txtSellVatRatio.SetReadOnly(false);
                        cmbSellVatType.Enabled = true;

                        cmbSellVatType.SelectedValue = dataItem.Sell.VatType.ToString();

                        if (Convert.ToInt32(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {
                            txtSellVat.SetReadOnly(false);
                            txtSellVat.Value = dataItem.Sell.Vat;

                            txtSellVatRatio.Value = dataItem.Sell.VatRatio;
                        }
                        else
                        {
                            txtSellVat.SetReadOnly(true);
                            txtSellVat.Value = null;

                            txtSellVatRatio.SetReadOnly(true);
                            txtSellVatRatio.Value = null;
                        }
                    }

                    #endregion Set Confirm
                }
                this.lblSumTotalExchangeRate.InnerText = crcySelected.MoneyCode;
                this.lblSumVATExchangeRate.InnerText = crcySelected.MoneyCode;
                this.lblGrandTotalExchangeRate.InnerText = crcySelected.MoneyCode;
                this.lblVATRatio.InnerText = string.Format("{0}/Ratio", crcySelected.TaxName);
            }
        }

        /// <summary>
        /// Event Cost ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptCost_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                CostInfo dataItem = (CostInfo)e.Item.DataItem;

                //Search product
                ICodeTextBox txtCostProductCD = (ICodeTextBox)e.Item.FindControl("txtCostProductCD");

                txtCostProductCD.Attributes.Add("parent-item-no", this._sellNoDataBound.ToString());

                if (this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME)
                {
                    txtCostProductCD.SetReadOnly(true);
                }

                txtCostProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;

                ITextBox txtCostProductName = (ITextBox)e.Item.FindControl("txtCostProductName");
                txtCostProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;

                //Init Unit Cost
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbCostUnit");
                this.InitDropDownListData(cmbUnit, this._unitList);
                cmbUnit.SelectedValue = dataItem.UnitID.ToString();

                //Init ExchangeRate Cost
                DropDownList cmbCostCurrency = (DropDownList)e.Item.FindControl("cmbCostCurrency");
                this.InitDropDownListData(cmbCostCurrency, this._currencyList);
                cmbCostCurrency.SelectedValue = dataItem.CurrencyID.ToString();
                var crcyId = int.Parse(cmbCostCurrency.SelectedValue);
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;

                //Init Vat Type Cost
                DropDownList cmbCostVatType = (DropDownList)e.Item.FindControl("cmbCostVatType");
                this.InitDropDownListData(cmbCostVatType, this._vatTypeList);
                cmbCostVatType.SelectedValue = dataItem.VatType.ToString();

                ICodeTextBox txtCostVendorCD = (ICodeTextBox)e.Item.FindControl("txtCostVendorCD");
                ITextBox txtCostVendorName = (ITextBox)e.Item.FindControl("txtCostVendorName");
                txtCostVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
                txtCostVendorName.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;

                HtmlButton btnVendorSearch = (HtmlButton)e.Item.FindControl("btnVendorSearch");
                string onclick = "callSearchVendor('" + txtCostVendorCD.ClientID + "','" + txtCostVendorName.ClientID +
                                                   "','" + txtCostProductCD.ClientID + "','" + txtCostProductName.ClientID +
                                                   "','" + cmbCostVatType.ClientID + "')";
                btnVendorSearch.Attributes.Add("onclick", onclick);

                HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)e.Item.FindControl("chkPurchaseFlag");
                chkPurchaseFlag.Checked = dataItem.PurchaseFlag;

                string onchange = "puchaseFlagChanged('" + chkPurchaseFlag.ClientID + "','" + btnVendorSearch.ClientID + "','" + txtCostVendorCD.ClientID + "','" + txtCostVendorName.ClientID + "')";
                chkPurchaseFlag.Attributes.Add("onchange", onchange);

                ITextBox txtCostDescription = (ITextBox)e.Item.FindControl("txtCostDescription");
                txtCostDescription.MaxLength = T_Quote_D_Cost.DESCRIPTION_MAX_LENGTH;

                INumberTextBox txtCostPrice = (INumberTextBox)e.Item.FindControl("txtCostPrice");

                INumberTextBox txtCostQuantity = (INumberTextBox)e.Item.FindControl("txtCostQuantity");
                txtCostQuantity.DecimalDigit = this.QtyDecDigit;

                INumberTextBox txtCostTotal = (INumberTextBox)e.Item.FindControl("txtCostTotal");

                INumberTextBox txtCostVat = (INumberTextBox)e.Item.FindControl("txtCostVat");
                INumberTextBox txtCostVatRatio = (INumberTextBox)e.Item.FindControl("txtCostVatRatio");

                if (Convert.ToInt32(cmbCostVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                {
                    txtCostVat.SetReadOnly(false);
                    txtCostVat.Value = dataItem.Vat;

                    txtCostVatRatio.SetReadOnly(false);
                    txtCostVatRatio.Value = dataItem.VatRatio;
                }
                else
                {
                    txtCostVat.SetReadOnly(true);
                    txtCostVat.Value = null;

                    txtCostVatRatio.SetReadOnly(true);
                    txtCostVatRatio.Value = null;
                }

                //---------------Set decimal digit by exchage rate---------------//
                this.SetDecimalDigit(crcySelected, txtCostPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtCostTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtCostVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);
                //---------------End Set decimal digit by exchage rate---------------//
                if (crcySelected.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtCostQuantity.MaximumValue = Constant.MAX_QUANTITY_DECIMAL;
                }
                else
                {
                    txtCostQuantity.MaximumValue = Constant.MAX_QUANTITY_NOT_DECIMAL;
                }

                HtmlButton btnSearchCostProduct = (HtmlButton)e.Item.FindControl("btnCostProduct");
                string onclickSearchCostProduct = "callSearchProduct('" + txtCostProductCD.ClientID + "','" + txtCostProductName.ClientID + "','" + txtCostDescription.ClientID + "'," + (int)Utilities.ProductType.Cost + ")";

                btnSearchCostProduct.Attributes.Add("onclick", onclickSearchCostProduct);

                var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostVatExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostTotalExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblCostPriceExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                               cmbCostVatType.ClientID,
                                                                               txtCostPrice.ClientID,
                                                                               txtCostQuantity.ClientID,
                                                                               txtCostTotal.ClientID,
                                                                               txtCostVat.ClientID,
                                                                               txtCostVatRatio.ClientID);
                txtCostPrice.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostPrice.ClientID, param));
                txtCostQuantity.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostQuantity.ClientID, param));
                txtCostTotal.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostTotal.ClientID, param));
                txtCostVatRatio.Attributes.Add("onvaluechange", string.Format("costOnChanged('{0}', {1})", txtCostVatRatio.ClientID, param));
            }
        }

        /// <summary>
        /// Process button
        /// </summary>
        /// <param name="source">object</param>
        /// <param name="e">RepeaterCommandEventArgs</param>
        protected void rptDetail_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            #region cmdProfitProcess

            if (e.CommandName == "cmdProfitProcess")
            {
                if (!this.txtQuotationDate.Value.HasValue)
                {
                    base.SetMessage(txtQuotationDate.ClientID, M_Message.MSG_REQUIRE, "Quote Date");
                    return;
                }

                //Get index row sell curren
                int sellNo = Convert.ToInt32(e.CommandArgument);

                //Find control
                INumberTextBox txtProfit = (INumberTextBox)e.Item.FindControl("txtProfit");

                //Check profit
                if (txtProfit != null)
                {
                    if (!txtProfit.Value.HasValue)
                    {
                        base.SetMessage(txtProfit.ClientID, M_Message.MSG_REQUIRE_GRID, "Profit", sellNo);
                        this.RefreshDetails();
                    }
                    else
                    {
                        this.UpdateMarkupQtySell(sellNo, this.txtQuotationDate.Value.GetValueOrDefault());
                        this.SetConfirmHeaderData();
                        this.SetConfirmDetailData(false);

                        var btnProfitProcess = (LinkButton)e.Item.FindControl("btnProfitProcess");
                        this.FocusControlId = btnProfitProcess.ClientID;
                    }
                }
            }

            #endregion cmdProfitProcess

            #region cmdCopyFrom

            else if (e.CommandName == "cmdCopyFrom")
            {
                this.SetConfirmHeaderData();
                this.SetConfirmDetailData();
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_COPY_FROM_COST, Models.DefaultButton.Yes, true);

                this.Action = ActionMode.CopyFromCostRow;
            }

            #endregion cmdCopyFrom

            #region cmdSellSearchProcess

            else if (e.CommandName == "cmdSellSearchProcess")
            {
                this.SetConfirmHeaderData();
                //Get index row sell curren
                int sellNo = Convert.ToInt32(e.CommandArgument);
                this.ChildRowCommandArgument = sellNo.ToString();

                //Find control
                HiddenField hdnQuoteID = (HiddenField)e.Item.FindControl("hdnQuoteID");
                //Find control
                HiddenField hdnSellNo = (HiddenField)e.Item.FindControl("hdnSellNo");
                ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtSellDescription");

                //Get Data
                var details = this.GetDetailData(true);

                var sellRow = details.Where(s => s.No == sellNo).SingleOrDefault();

                #region Copy

                using (DB db = new DB())
                {
                    var hid = int.Parse(hdnQuoteID.Value);
                    var selSellNo = int.Parse(hdnSellNo.Value);

                    Quotation_HService hService = new Quotation_HService(db);
                    Quotation_D_SellService sService = new Quotation_D_SellService(db);
                    Quotation_D_CostService cService = new Quotation_D_CostService(db);
                    Currency_HService crcyService = new Currency_HService(db);

                    var header = hService.GetByPK(hid);
                    var sell = sService.GetByPK(hid, selSellNo);
                    var costs = cService.GetBySell(hid, selSellNo);

                    var selCurrencyId = header.CurrencyID;
                    var currencyId = int.Parse(this.cmbCurrency.SelectedValue);
                    var unitPrice = 0m;
                    var baseDate = this.txtQuotationDate.Value.HasValue ? this.txtQuotationDate.Value.GetValueOrDefault() : db.NowDate;
                    var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);
                    if (selCurrencyId != currencyId)
                    {
                        unitPrice = CommonUtil.ConvertToVND(crcyList[selCurrencyId].ExchangeRate, sell.UnitPrice);

                        if (currencyId != Constant.DEFAULT_ID)
                        {
                            unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyId].ExchangeRate, unitPrice);
                        }
                    }
                    else
                    {
                        unitPrice = sell.UnitPrice;
                    }
                    sellRow.Sell = new SellInfo
                    {
                        SellNoDisp = sellRow.Sell.SellNoDisp,
                        Collapsed = sellRow.Sell.Collapsed,
                        ProductCD = sell.ProductCD,
                        ProductName = sell.ProductName,
                        Description = sell.Description,
                        Price = unitPrice,
                        UnitID = sell.UnitID,
                        Remark = sell.Remark,
                        VatRatio = sell.VatRatio,
                        VatType = sell.VatType,
                    };
                    sellRow.CostList = new List<CostInfo>(costs.Select(c => new CostInfo
                    {
                        SellNo = sellRow.Sell.SellNoDisp,
                        No = c.No,
                        ProductCD = c.ProductCD,
                        ProductName = c.ProductName,
                        Description = c.Description,
                        Price = (decimal?)c.UnitPrice,
                        UnitID = c.UnitID,
                        CurrencyID = c.CurrencyID,
                        PurchaseFlag = c.PurchaseFlag == 1 ? true : false,
                        VendorCD = c.PurchaseFlag == 1 ? c.VendorCD : string.Empty,
                        VendorName = c.PurchaseFlag == 1 ? c.VendorName : string.Empty,
                        VatType = c.VatType,
                        VatRatio = c.VatRatio
                    }));
                }

                #endregion Copy

                this.RefreshDetails(details);
                this.SetConfirmDetailData(false);

                if (this.txtQuotationDate.Value.HasValue)
                {
                    this.SetSellMarkup(this.txtQuotationDate.Value.GetValueOrDefault());
                }
                this.FocusControlId = txtSellDescription.ClientID;
            }

            #endregion cmdSellSearchProcess
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void rptCost_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            this.SetConfirmHeaderData();
            this.SetConfirmDetailData();
            if (e.CommandName == "cmdAddRow")
            {
                #region cmdAddRow

                var keys = e.CommandArgument.ToString().Split('_');
                int sellNo = Convert.ToInt32(keys[0]);
                int costNo = Convert.ToInt32(keys[1]);

                //Get Data
                IList<QuotationDetailInfo> sellList = this.GetDetailData();

                var sell = sellList.Where(s => s.Type == QuotationDetailType.Sell && s.Sell.SellNoDisp == sellNo).SingleOrDefault();
                sell.Sell.Collapsed = "in";

                var costInfo = new CostInfo
                {
                    SellNo = sellNo,
                    No = costNo + 1,
                    VatType = int.Parse(this._defaultVatType),
                    VatRatio = M_Config_D.VAT_TYPE_EXCLUDE == this._defaultVatType ? (decimal?)decimal.Parse(this.DefaultVAT) : null,
                };
                if (this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_DOUBLE ||
                    this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME)
                {
                    if (this.ProductCdUsed)
                    {
                        costInfo.ProductCD = sell.Sell.ProductCD;
                        if (!string.IsNullOrEmpty(costInfo.ProductCD) &&
                            costInfo.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                        {
                            using (DB db = new DB())
                            {
                                ProductService service = new ProductService(db);
                                VendorService vService = new VendorService(db);
                                var mProd = service.GetByCD(costInfo.ProductCD);

                                if (mProd != null && mProd.StatusFlag == 0)
                                {
                                    costInfo.ProductName = mProd.ProductName;
                                    costInfo.Description = mProd.DescriptionCost;
                                    costInfo.Price = mProd.UnitPriceCost;
                                    costInfo.CurrencyID = mProd.CurrencyIDCost;
                                    costInfo.UnitID = mProd.UnitIDCost;
                                    costInfo.VatRatio = mProd.VatRatioCost;
                                    costInfo.VatType = mProd.VatTypeCost;
                                    costInfo.PurchaseFlag = mProd.PurchaseFlag == 1;
                                    if (costInfo.PurchaseFlag)
                                    {
                                        //costInfo.VendorCD =
                                        var vendor = vService.GetFirstOrDefaultByProductID(mProd.ID);
                                        if (vendor != null && vendor.ID != Constant.DEFAULT_ID)
                                        {
                                            costInfo.VendorCD = EditDataUtil.ToFixCodeShow(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                                            costInfo.VendorName = vendor.VendorName1;
                                        }
                                    }
                                }
                            }
                        }
                        this.FocusControlId = string.Format("{0}_txtCostProductName_{1}", sell.No - 1, costInfo.No - 1);
                    }
                    else
                    {
                        costInfo.ProductName = sell.Sell.ProductName;
                        costInfo.Description = sell.Sell.Description;
                        this.FocusControlId = string.Format("{0}_txtCostProductName_{1}", sell.No - 1, costInfo.No - 1);
                    }
                }
                else
                {
                    if (this.ProductCdUsed)
                    {
                        this.FocusControlId = string.Format("{0}_txtCostProductCD_{1}", sell.No - 1, costInfo.No - 1);
                    }
                    else
                    {
                        this.FocusControlId = string.Format("{0}_txtCostProductName_{1}", sell.No - 1, costInfo.No - 1);
                    }
                }
                sell.CostList.Insert(costNo, costInfo);
                for (int i = costNo; i < sell.CostList.Count; i++)
                {
                    sell.CostList[i].No = i + 1;
                }
                this.RefreshDetails(sellList);

                #endregion cmdAddRow
            }

            if (e.CommandName == "cmdDelRow")
            {
                #region cmdDelRow

                this.SetConfirmHeaderData();
                this.SetConfirmDetailData();
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);

                this.Action = ActionMode.RemoveChildRow;

                #endregion cmdDelRow
            }

            if (e.CommandName == "cmdCopyFrom")
            {
                this.SetConfirmHeaderData();
                this.SetConfirmDetailData();
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_COPY_FROM_SELL, Models.DefaultButton.Yes, true);

                this.Action = ActionMode.CopyFromSellRow;
            }
        }

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                if (in1 == OMS.Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var representAposition = string.Format("{0}{1}/{2}", customer.Represent, customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' });
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1,
                            customerAddress1 = customer.CustomerAddress1,
                            customerAddress2 = customer.CustomerAddress2,
                            customerAddress3 = customer.CustomerAddress3,
                            tel = customer.Tel,
                            fax = customer.FAX,
                            contactPerson = customer.ContactPerson,
                            represent = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_REPRESENT : customer.Represent,
                            position = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_POSITION : string.Format("{0} / {1}", customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' }),
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(OMS.Utilities.EditDataUtil.ToFixCodeDB(in1, M_User.USER_CODE_MAX_LENGTH));
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userName = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get vendor
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetVendor(string in1)
        {
            var vendorCd = in1;
            var vendorCdShow = in1;
            vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            vendorCdShow = EditDataUtil.ToFixCodeShow(vendorCd, M_Vendor.VENDOR_CODE_MAX_SHOW);
            if (vendorCdShow == OMS.Models.M_Vendor.VENDOR_CODE_SUPPORT)
            {
                return string.Empty;
            }
            try
            {
                using (DB db = new DB())
                {
                    VendorService vendor = new VendorService(db);
                    M_Vendor model = vendor.GetByCD(vendorCd);
                    if (model != null && model.StatusFlag == 0)
                    {
                        var result = new
                        {
                            vendorCD = vendorCdShow,
                            vendorName1 = model.VendorName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
                var onlyCd = new
                {
                    vendorCD = vendorCdShow
                };
                return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string conditionCd, string condition)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(conditionCd, (int)ConditionFlag.Quotation);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            condition = condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Sell
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcSell(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtSellPrice") || senderId.Contains("txtSellQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtSellTotal") || senderId.Contains("txtSellVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Cost
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcCost(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtCostPrice") || senderId.Contains("txtCostQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtCostTotal") || senderId.Contains("txtCostVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotal(string methodVAT
                                       , string[] totals, string[] VATs
                                       , string vatRatio
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                if (string.IsNullOrEmpty(vatRatio))
                {
                    vatRatio = "0";
                }
                decimal? sumTotal = null;
                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = Utilities.Fraction.Round((FractionType)fractionType, totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);
                }

                decimal? sumVAT = null;
                if (sumTotal.HasValue)
                {
                    if (VATs.Any(s => !string.IsNullOrEmpty(s)))
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, VATs.Sum(v => string.IsNullOrEmpty(v) ? 0 : decimal.Parse(v)), 2);
                    }

                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, (sumTotal.GetValueOrDefault() * decimal.Parse(vatRatio)) / 100, 2);
                    }
                }

                decimal? grandTotal = null;
                string numberFormat = string.Format("N{0}", decimalDigit);

                if (sumTotal.HasValue && sumVAT.HasValue)
                {
                    grandTotal = sumTotal.GetValueOrDefault() + sumVAT.GetValueOrDefault();
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtSumTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtSumVat\":\"{0}\"", sumVAT.HasValue ? sumVAT.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtGrandTotal\":\"{0}\"", grandTotal.HasValue ? grandTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));

                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count Attached File
        /// </summary>
        /// <param name="dataId">dataId</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(int dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId, (int)FType.Quote);
                    var result = new
                    {
                        count = count
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Product
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(string productCdSetting, short type, string quoteDate, string productCd, string quantity,
                                        int currencyID, int fractionType, int decimalDigit)
        {
            try
            {
                if (productCd == M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    ProductService service = new ProductService(db);

                    var mProd = service.GetByCD(productCd);

                    if (mProd == null || mProd.StatusFlag != 0)
                    {
                        return string.Empty;
                    }
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    System.Text.StringBuilder result = new System.Text.StringBuilder();
                    result.Append("{");

                    result.Append(string.Format("\"ProductName\":\"{0}\"", mProd.ProductName.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));

                    #region Sell

                    if (type == (short)ProductType.Sell)
                    {
                        //Sell
                        result.Append(string.Format(", \"DescriptionSell\":\"{0}\"", mProd.DescriptionSell.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        result.Append(string.Format(", \"RemarkSell\":\"{0}\"", mProd.RemarkSell.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        result.Append(string.Format(", \"UnitIDSell\":\"{0}\"", mProd.UnitIDSell));
                        result.Append(string.Format(", \"VatTypeSell\":\"{0}\"", mProd.VatTypeSell));

                        var _vatRatio = mProd.VatRatioSell;
                        var vatType = mProd.VatTypeSell;
                        var unitPrice = 0m;
                        var subTotal = 0m;
                        var vat = 0m;

                        #region Currency

                        if (currencyID == mProd.CurrencyIDSell)
                        {
                            unitPrice = mProd.UnitPriceSell;
                        }
                        else
                        {
                            var baseDate = string.IsNullOrEmpty(quoteDate) ? db.NowDate : CommonUtil.ParseDate(quoteDate);
                            var crcyService = new Currency_HService(db);
                            var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                            //Chuyen tien cua product ve tien mac dinh
                            if (mProd.CurrencyIDSell == Constant.DEFAULT_ID)
                            {
                                unitPrice = mProd.UnitPriceSell;
                            }
                            else
                            {
                                unitPrice = CommonUtil.ConvertToVND(crcyList[mProd.CurrencyIDSell].ExchangeRate, mProd.UnitPriceSell);
                            }
                            // Neu chon loai tien mac dinh thi set tra ve
                            // Con neu nguoc lai thi chuyen tien ve kieu tien duoc chon
                            if (currencyID != Constant.DEFAULT_ID)
                            {
                                unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyID].ExchangeRate, unitPrice);
                            }
                        }
                        result.Append(string.Format(", \"UnitPriceSell\":\"{0}\"", unitPrice.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, unitPrice * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"SellTotal\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"SellTotal\":\"{0}\"", string.Empty));
                        }

                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatioSell\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"SellVat\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatioSell\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                        }

                        #endregion Currency
                    }

                    #endregion Sell

                    #region Cost

                    if (type == (short)ProductType.Cost ||
                        productCdSetting == M_Config_D.PRODUCT_CD_SETTING_DOUBLE ||
                        productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME)
                    {
                        VendorService vService = new VendorService(db);
                        Currency_HService cHService = new Currency_HService(db);
                        var crcy = cHService.GetByID(mProd.CurrencyIDCost);
                        decimalDigit = crcy.DecimalType == (int)ExchangeRateDecType.Decimal ? 2 : 0;
                        numberFormat = string.Format("N{0}", decimalDigit);

                        //Cost
                        result.Append(string.Format(", \"DescriptionCost\":\"{0}\"", mProd.DescriptionCost.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        result.Append(string.Format(", \"UnitIDCost\":\"{0}\"", mProd.UnitIDCost));
                        result.Append(string.Format(", \"VatTypeCost\":\"{0}\"", mProd.VatTypeCost));
                        result.Append(string.Format(", \"CurrencyIDCost\":\"{0}\"", mProd.CurrencyIDCost));

                        var _vatRatio = mProd.VatRatioCost;
                        var vatType = mProd.VatTypeCost;

                        result.Append(string.Format(", \"UnitPriceCost\":\"{0}\"", mProd.UnitPriceCost.ToString(numberFormat)));
                        var subTotal = 0m;
                        var vat = 0m;
                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, mProd.UnitPriceCost * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"CostTotal\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"CostTotal\":\"{0}\"", string.Empty));
                        }
                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatioCost\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"CostVat\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"CostVat\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatioCost\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"SellVat\":\"{0}\"", string.Empty));
                        }
                        result.Append(string.Format(", \"PurchaseFlag\":\"{0}\"", mProd.PurchaseFlag == 1));

                        var vendor = vService.GetFirstOrDefaultByProductID(mProd.ID);
                        if (vendor != null && vendor.ID != Constant.DEFAULT_ID)
                        {
                            result.Append(string.Format(", \"VendorProductCD\":\"{0}\"", EditDataUtil.ToFixCodeShow(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW)));
                            result.Append(string.Format(", \"VendorProductName\":\"{0}\"", vendor.VendorName1.Replace("\"", "\\\"").Replace("\r", "").Replace("\n", "</br>")));
                        }
                        else
                        {
                            result.Append(string.Format(", \"VendorProductCD\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"VendorProductName\":\"{0}\"", string.Empty));
                        }
                    }

                    #endregion Cost

                    result.Append("}");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Currency Info
        /// </summary>
        /// <param name="currencyId"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCurrencyInfo(int currencyId)
        {
            try
            {
                using (DB db = new DB())
                {
                    Currency_HService service = new Currency_HService(db);
                    var currency = service.GetByID(currencyId);

                    System.Text.StringBuilder result = new System.Text.StringBuilder();
                    result.Append("{");
                    //
                    var decimalDigit = currency.DecimalType == (int)ExchangeRateDecType.Decimal ? 2 : 0;
                    var maxValue = decimalDigit > 0 ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;

                    result.Append(string.Format("\"decimalDigit\":\"{0}\"", decimalDigit));

                    result.Append(string.Format(", \"maxUnitPriceValue\":\"{0}\"", maxValue));
                    result.Append(string.Format(", \"unitPriceLength\":\"{0}\"", GetMaxLengthNumber(maxValue)));

                    maxValue = decimalDigit > 0 ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                    result.Append(string.Format(", \"maxTotalValue\":\"{0}\"", maxValue));
                    result.Append(string.Format(", \"totalLength\":\"{0}\"", GetMaxLengthNumber(maxValue)));

                    maxValue = decimalDigit > 0 ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                    result.Append(string.Format(", \"maxVatValue\":\"{0}\"", maxValue));
                    result.Append(string.Format(", \"vatLength\":\"{0}\"", GetMaxLengthNumber(maxValue)));

                    result.Append(string.Format(", \"moneyCode\":\"{0}\"", currency.MoneyCode));

                    result.Append("}");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Max Length Can Input
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        private static int GetMaxLengthNumber(decimal number)
        {
            var maxInt = Math.Truncate(number);
            var maxIntLength = maxInt.ToString().Length;
            if (maxIntLength % 3 == 0)
            {
                maxIntLength += (maxIntLength / 3) - 1;
            }
            else
            {
                maxIntLength += (maxIntLength / 3);
            }
            return maxIntLength;
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                     errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;
            this.Action = ActionMode.None;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.ClearUpdateInfo();
                    //Init Data
                    this.InitData();

                    break;

                case Mode.Copy:
                    this.FileCount = 0;
                    this.txtQuotationNo.Value = string.Empty;
                    this.ClearUpdateInfo();
                    using (DB db = new DB())
                    {
                        Config_DService config_DSer = new Config_DService(db);
                        var quoteDate = db.NowDate;
                        var expiryDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Quotation));
                        if (!expiryDay.HasValue)
                        {
                            this.txtExpDate.Value = null;
                        }
                        else
                        {
                            var expiryDate = quoteDate.AddDays(expiryDay.Value);
                            this.txtExpDate.Value = expiryDate;
                        }

                        this.txtQuotationDate.Value = quoteDate;
                    }

                    if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
                    {
                        this.txtInchargeCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                        this.txtInchargeName.Value = base.LoginInfo.User.UserName2;
                    }
                    break;

                case Utilities.Mode.Revise:
                    this.ClearUpdateInfo();
                    break;

                case Mode.View:

                    //!((this.Losted || this.IsNew) && !this.Sold)
                    if ((this.Losted || this.IsNew) && !this.Sold)
                    {
                        base.DisabledLink(this.btnEdit, false);
                    }
                    else
                    {
                        base.DisabledLink(this.btnEdit, true);
                    }

                    if (this.IsNew && !this.Losted && !this.Sold)
                    {
                        base.DisabledLink(this.btnRevise, false);
                        base.DisabledLink(this.btnIssue, false);
                    }
                    else
                    {
                        base.DisabledLink(this.btnRevise, true);
                        base.DisabledLink(this.btnSales, true);

                        if (this.IsNew && !this.Losted)
                        {
                            base.DisabledLink(this.btnIssue, false);
                        }
                        else
                        {
                            base.DisabledLink(this.btnIssue, true);
                        }
                    }

                    //this.OldCondition = string.Empty;
                    switch (this.GetPreNextQuotation())
                    {
                        case PreNextStatus.NoPreNoNext:
                            this.Prev = false;
                            this.Next = false;
                            break;

                        case PreNextStatus.HavePreNoNext:
                            this.Prev = true;
                            this.Next = false;
                            break;

                        case PreNextStatus.NoPreHaveNext:
                            this.Prev = false;
                            this.Next = true;
                            break;

                        default:
                            this.Prev = true;
                            this.Next = true;
                            break;
                    }
                    base.DisabledLink(this.btnPrev, !this.Prev);
                    base.DisabledLink(this.btnNext, !this.Next);

                    if (this.IsNew)
                    {
                        base.DisabledLink(this.btnCopy, false);
                    }
                    else
                    {
                        base.DisabledLink(this.btnCopy, true);
                    }

                    base.DisabledLink(this.btnEdit, !this.btnEdit.Enabled || !base._authority.IsQuotationEdit);
                    base.DisabledLink(this.btnCopy, !this.btnCopy.Enabled || !base._authority.IsQuotationCopy);

                    base.DisabledLink(this.btnIssue, !this.btnIssue.Enabled || !base._authority.IsQuotationPDF);
                    base.DisabledLink(this.btnRevise, !this.btnRevise.Enabled || !base._authority.IsQuotationRevise);
                    base.DisabledLink(this.btnSales, !this.btnSales.Enabled || !base._authority.IsQuotationSales);

                    break;

                default:
                    break;
            }
            var methodVAT = this.cmbMethodVat.SelectedValue;

            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
            {
                //SellVatRatio
                this.txtVatRatio.SetReadOnly(true);
                this.txtSumVat.SetReadOnly(false);

                //VatType
                this.cmbVatType.Enabled = false;

                this.txtVatRatio.Value = null;
                this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);
            }
            else
            {
                //SellVatRatio
                this.txtVatRatio.SetReadOnly(false);
                //VatType
                this.cmbVatType.Enabled = true;

                //SUM
                var bakVal = this.cmbVatType.SelectedValue;
                this.InitDropDownListData(this.cmbVatType, this._vatTypeList);
                if (!string.IsNullOrEmpty(bakVal))
                {
                    this.cmbVatType.SelectedValue = bakVal;
                }
                if (int.Parse(this.cmbVatType.SelectedValue) != (int)VATFlg.Exclude)
                {
                    this.txtVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(true);
                    this.txtVatRatio.Value = null;
                }
                else
                {
                    this.txtVatRatio.SetReadOnly(false);
                    this.txtSumVat.SetReadOnly(false);
                    if (!this.txtVatRatio.Value.HasValue)
                    {
                        this.txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
                    }
                }
            }
            var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
            var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;

            this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);

            this.txtCustomerName.SetReadOnly(true);
            if (this.txtCustomerCD.Value == Models.M_Customer.CUSTOMER_CODE_SUPPORT)
            {
                this.txtCustomerName.SetReadOnly(false);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                CustomerService custSrv = new CustomerService(db);
                UserService userSrv = new UserService(db);
                ProductService prodSrv = new ProductService(db);
                VendorService vdorSrv = new VendorService(db);

                #region Header

                var status = int.Parse(this.cmbStatus.SelectedValue);
                if (status == -1)
                {
                    this.SetMessage(this.cmbStatus.ClientID, M_Message.MSG_REQUIRE, "Status");
                }

                if (this.txtCustomerCD.IsEmpty)
                {
                    this.SetMessage("txtCustomerCD", M_Message.MSG_REQUIRE, "Customer Code");
                }
                else
                {
                    var customerCd = this.txtCustomerCD.Value;
                    if (customerCd == Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                    {
                        if (this.txtCustomerName.IsEmpty)
                        {
                            this.SetMessage("txtCustomerName", M_Message.MSG_REQUIRE, "Customer Name");
                        }
                    }
                    else
                    {
                        customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                        var customer = custSrv.GetByCustomerCD(customerCd);
                        if (customer == null)
                        {
                            this.SetMessage("txtCustomerCD", M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                        }
                        else
                        {
                            if (customer.StatusFlag != 0)
                            {
                                this.SetMessage("txtCustomerCD", M_Message.MSG_CODE_DISABLE, "Customer Code");
                            }
                        }
                    }
                }

                if (this.txtQuotationDate.IsEmpty)
                {
                    this.SetMessage("txtQuotationDate", M_Message.MSG_REQUIRE, "Quote Date");
                }

                if (this.txtExpDate.IsEmpty)
                {
                    this.SetMessage("txtExpDate", M_Message.MSG_REQUIRE, "Expiry Date");
                }
                if (!this.txtQuotationDate.IsEmpty && !this.txtExpDate.IsEmpty)
                {
                    var dateFrom = this.txtQuotationDate.Value.GetValueOrDefault();
                    var dateTo = this.txtExpDate.Value.GetValueOrDefault();
                    if (dateTo.CompareTo(dateFrom) < 0)
                    {
                        this.SetMessage("txtExpDate", M_Message.MSG_GREATER_THAN_EQUAL, "Expiry Date", "Quote Date");
                    }
                }

                M_User user = null;
                if (this.txtInchargeCD.IsEmpty)
                {
                    this.SetMessage("txtInchargeCD", M_Message.MSG_REQUIRE, "Prepared Code");
                }
                else
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtInchargeCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtInchargeCD", M_Message.MSG_NOT_EXIST_CODE, "Prepared Code");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtInchargeCD", M_Message.MSG_CODE_DISABLE, "Prepared Code");
                        }
                    }
                }

                if (this.txtApprovedCD.IsEmpty)
                {
                    this.SetMessage("txtApprovedCD", M_Message.MSG_REQUIRE, "Approved Code");
                }
                else
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtApprovedCD", M_Message.MSG_NOT_EXIST_CODE, "Approved Code");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtApprovedCD", M_Message.MSG_CODE_DISABLE, "Approved Code");
                        }
                    }
                }
                if (!this.txtFrontSalesCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtFrontSalesCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtFrontSalesCD", M_Message.MSG_NOT_EXIST_CODE, "Sales 1");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtFrontSalesCD", M_Message.MSG_CODE_DISABLE, "Sales 1");
                        }
                    }
                }
                if (!this.txtEngineerCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtEngineerCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtEngineerCD", M_Message.MSG_NOT_EXIST_CODE, "Sales 2");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtEngineerCD", M_Message.MSG_CODE_DISABLE, "Sales 2");
                        }
                    }
                }

                if (this.txtSubject.IsEmpty)
                {
                    this.SetMessage("txtSubject", M_Message.MSG_REQUIRE, "Subject");
                }

                #endregion Header

                var isDecimal = this.IsDecimal(int.Parse(this.cmbCurrency.SelectedValue));
                string nf = string.Format("N{0}", isDecimal ? 2 : 0);

                var details = this.GetDetailData();
                var methodVAT = this.cmbMethodVat.SelectedValue;

                if (details.Count > 0)
                {
                    var maxValue = 0m;
                    var minValue = 0m;

                    #region Detail

                    for (int i = 0; i < details.Count; i++)
                    {
                        QuotationDetailInfo detail = details[i];
                        if (detail.Type != QuotationDetailType.HeadLine
                            && !detail.Sell.IsEmpty(decimal.Parse(this.DefaultVAT)))
                        {
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // start
                            if (this.ProductCdUsed)
                            {
                                if (string.IsNullOrEmpty(detail.Sell.ProductCD))
                                {
                                    this.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Code", detail.Sell.SellNoDisp);
                                }
                                else
                                {
                                    if (detail.Sell.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                                    {
                                        var model = prodSrv.GetByCD(detail.Sell.ProductCD);
                                        if (model == null)
                                        {
                                            this.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", detail.Sell.SellNoDisp);
                                        }
                                        else if (model.StatusFlag != 0)
                                        {
                                            this.SetMessage(string.Format("txtSellProductCD_{0}", i), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", detail.Sell.SellNoDisp);
                                        }
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(detail.Sell.ProductName))
                                        {
                                            this.SetMessage(string.Format("txtSellProductName_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Name", detail.Sell.SellNoDisp);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(detail.Sell.ProductName))
                                {
                                    this.SetMessage(string.Format("txtSellProductName_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Name", detail.Sell.SellNoDisp);
                                }
                            }
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // end

                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // start
                            //Price
                            if (detail.Sell.Price.HasValue)
                            {
                                maxValue = isDecimal ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;

                                if (detail.Sell.Price > maxValue)
                                {
                                    this.SetMessage(string.Format("txtSellPrice_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(nf), detail.Sell.SellNoDisp);
                                }
                            }
                            else
                            {
                                this.SetMessage(string.Format("txtSellPrice_{0}", i), M_Message.MSG_REQUIRE_GRID, "Unit Price", detail.Sell.SellNoDisp);
                            }
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // end

                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // start
                            //Quantity
                            if (detail.Sell.Quantity.HasValue)
                            {
                                maxValue = this.QtyDecDigit == 2 ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                                if (detail.Sell.Quantity > maxValue)
                                {
                                    this.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(string.Format("N{0}", this.QtyDecDigit)), detail.Sell.SellNoDisp);
                                }
                            }
                            else
                            {
                                this.SetMessage(string.Format("txtSellQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", detail.Sell.SellNoDisp);
                            }
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // end

                            //Total
                            if (detail.Sell.Total.HasValue)
                            {
                                maxValue = isDecimal ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                                minValue = isDecimal ? Constant.MIN_SUB_TOTAL_DECIMAL : Constant.MIN_SUB_TOTAL_NOT_DECIMAL;

                                if (detail.Sell.Total > maxValue)
                                {
                                    this.SetMessage(string.Format("txtSellTotal_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(nf), detail.Sell.SellNoDisp);
                                }
                                else if (detail.Sell.Total < minValue)
                                {
                                    this.SetMessage(string.Format("txtSellTotal_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Sub Total", minValue.ToString(nf), detail.Sell.SellNoDisp);
                                }
                            }

                            if (methodVAT == M_Config_D.METHOD_VAT_EACH && detail.Sell.VatType == (int)VATFlg.Exclude)
                            {
                                if (detail.Sell.Vat.HasValue)
                                {
                                    maxValue = (isDecimal) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                    minValue = (isDecimal) ? Constant.MIN_SUB_VAT_DECIMAL : Constant.MIN_SUB_VAT_NOT_DECIMAL;
                                    if (detail.Sell.Vat > maxValue)
                                    {
                                        this.SetMessage(string.Format("txtSellVat_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VAT", maxValue.ToString(nf), detail.Sell.SellNoDisp);
                                    }
                                    else if (detail.Sell.Vat < minValue)
                                    {
                                        this.SetMessage(string.Format("txtSellVat_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "VAT", minValue.ToString(nf), detail.Sell.SellNoDisp);
                                    }
                                }

                                if (!detail.Sell.VatRatio.HasValue)
                                {
                                    this.SetMessage("txtSellVatRatio_" + i.ToString(), M_Message.MSG_REQUIRE_GRID, "VatRatio", detail.Sell.SellNoDisp);
                                }
                                else
                                {
                                    if (detail.Sell.VatRatio > Constant.MAX_VATRATIO)
                                    {
                                        base.SetMessage(string.Format("txtSellVatRatio_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, detail.Sell.SellNoDisp);
                                    }
                                }
                            }
                        }
                        if (detail.Type == QuotationDetailType.HeadLine)
                        {
                            continue;
                        }
                        if (detail.Sell.IsEmpty(decimal.Parse(this.DefaultVAT)))
                        {
                            detail.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
                        }

                        detail.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                        #region SubDetails

                        for (int j = 0; j < detail.CostList.Count; j++)
                        {
                            CostInfo subDetail = detail.CostList[j];
                            if (subDetail.IsEmpty(decimal.Parse(this.DefaultVAT)))
                            {
                                subDetail.VatRatio = decimal.Parse(this.DefaultVAT);
                                continue;
                            }
                            var subIsDecimal = this.IsDecimal(subDetail.CurrencyID);
                            var subNf = string.Format("N{0}", subIsDecimal ? 2 : 0);

                            var costProductNameErr = false;

                            #region product cd
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // start
                            if (this.ProductCdUsed)
                            {
                                if (!string.IsNullOrEmpty(subDetail.ProductCD))
                                {
                                    if (subDetail.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                                    {
                                        var model = prodSrv.GetByCD(subDetail.ProductCD);
                                        if (model == null)
                                        {
                                            detail.Sell.Collapsed = "in";
                                            this.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                        else if (model.StatusFlag != 0)
                                        {
                                            detail.Sell.Collapsed = "in";
                                            this.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(subDetail.ProductName))
                                        {
                                            costProductNameErr = true;
                                            detail.Sell.Collapsed = "in";
                                            this.SetMessage(string.Format("{0}_txtCostProductName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Name", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                    }
                                }
                                else
                                {
                                    costProductNameErr = true;
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(subDetail.ProductName))
                                {
                                    costProductNameErr = true;
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostProductName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Name", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }
                            // 2015/03/04 Check Sales order data
                            // check require 
                            // author: dh-phuong 
                            // end
                            #endregion product cd

                            if (subDetail.PurchaseFlag)
                            {
                                if (this.ProductCdUsed && string.IsNullOrEmpty(subDetail.ProductCD) && !costProductNameErr)
                                {
                                    detail.Sell.Collapsed = "in";
                                    if (this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME)
                                    {
                                        this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                    else
                                    {
                                        this.SetMessage(string.Format("{0}_txtCostProductCD_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                }

                                if (!costProductNameErr && !string.IsNullOrEmpty(subDetail.ProductCD) &&
                                        string.IsNullOrEmpty(subDetail.ProductName))
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostProductName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Product Name", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                if (!subDetail.Price.HasValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostPrice_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Unit Price", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                if (!subDetail.Quantity.HasValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Q'ty", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                else if (subDetail.Quantity.Value == 0)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }

                                //Check sell vendor
                                if (!string.IsNullOrEmpty(subDetail.VendorCD))
                                {
                                    if (subDetail.VendorCD == Models.M_Vendor.VENDOR_CODE_SUPPORT)
                                    {
                                        if (string.IsNullOrEmpty(subDetail.VendorName))
                                        {
                                            detail.Sell.Collapsed = "in";
                                            base.SetMessage(string.Format("{0}_txtCostVendorName_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Vendor Name", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                    }
                                    else
                                    {
                                        var vendorCd = subDetail.VendorCD;
                                        vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                                        var vendor = vdorSrv.GetByCD(vendorCd);
                                        if (vendor == null)
                                        {
                                            detail.Sell.Collapsed = "in";
                                            this.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_NOT_EXIST_CODE_GRID, "Vendor Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                        else if (vendor.StatusFlag != 0)
                                        {
                                            detail.Sell.Collapsed = "in";
                                            this.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_CODE_DISABLE_GRID, "Vendor Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                        }
                                    }
                                }
                                else
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostVendorCD_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Vendor Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }
                            if (subDetail.Price.HasValue)
                            {
                                maxValue = subIsDecimal ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                                if (subDetail.Price > maxValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostPrice_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(subNf), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }
                            if (subDetail.Quantity.HasValue)
                            {
                                maxValue = this.QtyDecDigit == 2 ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                                if (subDetail.Quantity > maxValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostQuantity_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(string.Format("N{0}", this.QtyDecDigit)), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }
                            //Total
                            if (subDetail.Total.HasValue)
                            {
                                maxValue = subIsDecimal ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                                minValue = subIsDecimal ? Constant.MIN_SUB_TOTAL_DECIMAL : Constant.MIN_SUB_TOTAL_NOT_DECIMAL;

                                if (subDetail.Total > maxValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostTotal_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(subNf), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                else if (subDetail.Total < minValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostTotal_{1}", i, j), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Sub Total", minValue.ToString(subNf), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }

                            if (subDetail.VatType == (int)VATFlg.Exclude)
                            {
                                if (subDetail.Vat.HasValue)
                                {
                                    maxValue = subIsDecimal ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                    minValue = subIsDecimal ? Constant.MIN_SUB_VAT_DECIMAL : Constant.MIN_SUB_VAT_NOT_DECIMAL;

                                    if (subDetail.Vat > maxValue)
                                    {
                                        detail.Sell.Collapsed = "in";
                                        this.SetMessage(string.Format("{0}_txtCostVat_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VAT", maxValue.ToString(subNf), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                    else if (subDetail.Vat < minValue)
                                    {
                                        detail.Sell.Collapsed = "in";
                                        this.SetMessage(string.Format("{0}_txtCostVat_{1}", i, j), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "VAT", minValue.ToString(subNf), string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                }
                                if (!subDetail.VatRatio.HasValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Format("{0}_txtCostVatRatio_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "VatRatio", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                else
                                {
                                    if (subDetail.VatRatio > Constant.MAX_VATRATIO)
                                    {
                                        detail.Sell.Collapsed = "in";
                                        this.SetMessage(string.Format("{0}_txtCostVatRatio_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                }
                            }
                        }

                        #endregion SubDetails
                    }

                    #endregion Detail

                    #region Total

                    var sumTotal = this.txtSumTotal.Value.GetValueOrDefault();
                    var sumVAT = this.txtSumVat.Value.GetValueOrDefault();
                    var grandTotal = this.txtGrandTotal.Value.GetValueOrDefault();

                    maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                    if (sumTotal > maxValue)
                    {
                        this.SetMessage("txtSumTotal", M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(nf));
                    }
                    else if (sumTotal < minValue)
                    {
                        this.SetMessage("txtSumTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Total", minValue.ToString(nf));
                    }

                    maxValue = isDecimal ? Constant.MAX_SUM_VAT_DECIMAL : Constant.MAX_SUM_VAT_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_VAT_DECIMAL : Constant.MIN_SUM_VAT_NOT_DECIMAL;
                    if (sumVAT > maxValue)
                    {
                        this.SetMessage("txtSumVat", M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(nf));
                    }
                    else if (sumVAT < minValue)
                    {
                        this.SetMessage("txtSumVat", M_Message.MSG_GREATER_THAN_EQUAL, "VAT", minValue.ToString(nf));
                    }

                    maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                    if (grandTotal > maxValue)
                    {
                        this.SetMessage("txtGrandTotal", M_Message.MSG_LESS_THAN_EQUAL, "Grand Total", maxValue.ToString(nf));
                    }
                    else if (grandTotal < minValue)
                    {
                        this.SetMessage("txtGrandTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Grand Total", minValue.ToString(nf));
                    }

                    //Check vat ratio total require
                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        var vatType = Convert.ToInt32(this.cmbVatType.SelectedItem.Value);
                        if (vatType == (int)VATFlg.Exclude)
                        {
                            if (!this.txtVatRatio.Value.HasValue)
                            {
                                base.SetMessage(this.txtVatRatio.ID, M_Message.MSG_REQUIRE, "VatRatio");
                            }
                        }
                    }

                    #endregion Total
                }
                else
                {
                    this.SetMessage(string.Empty, M_Message.MSG_REQUIRE, "detail infomation");
                }

                this.RefreshDetails(details);
            }

            //Check error
            return !base.HaveError;
        }

        // 2015/03/04 Check Sales order data
        // check require 
        // author: dh-phuong 
        // start

        /// <summary>
        /// Check input for sales order
        /// </summary>
        /// <returns>
        /// Valid:true, Invalid:false
        /// </returns>
        private bool CheckSalesOrderInput()
        {
            var isDecimal = this.IsDecimal(int.Parse(this.cmbCurrency.SelectedValue));
            string nf = string.Format("N{0}", isDecimal ? 2 : 0);

            var details = this.GetDetailData();
            var methodVAT = this.cmbMethodVat.SelectedValue;

            #region Detail

            for (int i = 0; i < details.Count; i++)
            {
                QuotationDetailInfo detail = details[i];
                if (detail.Type == QuotationDetailType.HeadLine)
                {
                    continue;
                }
                if (detail.Sell.IsEmpty(decimal.Parse(this.DefaultVAT)))
                {
                    detail.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
                }
                detail.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                if (detail.Type != QuotationDetailType.HeadLine
                    && !detail.Sell.IsEmpty(decimal.Parse(this.DefaultVAT)))
                {
                    //Quantity
                    if (detail.Sell.Quantity.HasValue && detail.Sell.Quantity.GetValueOrDefault() != 0)
                    {
                        if (this.ProductCdUsed)
                        {
                            if (string.IsNullOrEmpty(detail.Sell.ProductCD))
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Product Code", detail.Sell.SellNoDisp);
                            }
                        }
                        else if (string.IsNullOrEmpty(detail.Sell.ProductName))
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Product Name", detail.Sell.SellNoDisp);
                        }

                        //Price
                        if (!detail.Sell.Price.HasValue)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Unit Price", detail.Sell.SellNoDisp);
                        }

                        #region SubDetails

                        for (int j = 0; j < detail.CostList.Count; j++)
                        {
                            CostInfo subDetail = detail.CostList[j];
                            if (subDetail.IsEmpty(decimal.Parse(this.DefaultVAT)))
                            {
                                subDetail.VatRatio = decimal.Parse(this.DefaultVAT);
                                continue;
                            }
                            //Quantity
                            if (subDetail.Quantity.HasValue && subDetail.Quantity.GetValueOrDefault() != 0)
                            {
                                if (this.ProductCdUsed)
                                {
                                    if (string.IsNullOrEmpty(subDetail.ProductCD))
                                    {
                                        detail.Sell.Collapsed = "in";
                                        this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Product Code", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                    }
                                }
                                else if (string.IsNullOrEmpty(subDetail.ProductName))
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Product Name", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                                if (subDetail.PurchaseFlag && !subDetail.Price.HasValue)
                                {
                                    detail.Sell.Collapsed = "in";
                                    this.SetMessage(string.Empty, M_Message.MSG_REQUIRE_GRID, "Unit Price", string.Format("{0}/{1}", detail.Sell.SellNoDisp, subDetail.No));
                                }
                            }

                        }

                        #endregion SubDetails
                    }
                }

            }

            #endregion Detail

            this.RefreshDetails(details);

            //Check error
            return !base.HaveError;
        }

        // 2015/03/04 Check Sales order data
        // check require 
        // author: dh-phuong 
        // end


        /// <summary>
        /// Get Default Data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                UnitService unitSer = new UnitService(db);
                Currency_HService currencyHService = new Currency_HService(db);
                Config_HService configSer = new Config_HService(db);
                Config_DService config_DSer = new Config_DService(db);

                base.SetAuthority(FormId.Quotation);

                //Get Unit
                this._unitList = unitSer.GetDataForDropDownList();

                var crcyItems = currencyHService.GetListDropdown();

                //Get ExchangeRate
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                //StatusList
                this._statusList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_STATUS)
                                            .Where(s => int.Parse(s.Value) != (int)StatusFlag.Sales)
                                            .ToList();
                this._defaultStatus = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_STATUS);

                //MethodVatList
                this._methodVatList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_VAT);
                this._defaultMethodVat = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_METHOD_VAT);

                //VatTypeList
                this._vatTypeList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
                this._defaultVatType = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);

                this._defaultFractionType = (FractionType)int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));
                var profit = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_PROFIT_VALUE);
                if (!string.IsNullOrEmpty(profit))
                {
                    this._defaultProfit = decimal.Parse(profit);
                }
                this._profitSetting = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PROFIT_SETTING);
                this._productCdSetting = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_SETTING);

                this.DefaultVAT = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL);
                this.QtyDecDigit = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                this.DefaultCostView = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_COST_VIEW);
                this.ProductCdUsed = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
            }
        }

        /// <summary>
        /// Init Unit Data
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            using (DB db = new DB())
            {
                Config_DService config_DSer = new Config_DService(db);
                var quoteDate = db.NowDate;
                var expiryDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Quotation));
                if (!expiryDay.HasValue)
                {
                    this.txtExpDate.Value = null;
                }
                else
                {
                    var expiryDate = quoteDate.AddDays(expiryDay.Value);
                    this.txtExpDate.Value = expiryDate;
                }
                this.txtQuotationDate.Value = quoteDate;
            }

            if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtInchargeCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtInchargeName.Value = base.LoginInfo.User.UserName2;
            }

            this.cmbStatus.SelectedValue = this._defaultStatus;
            this.cmbMethodVat.SelectedValue = this._defaultMethodVat;
            this.txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
            this.ViewState["HEADER"] = new T_Quote_H
            {
                MethodVat = short.Parse(this._defaultMethodVat),
                CurrencyID = Constant.DEFAULT_ID
            };

            int defaultVatType = int.Parse(this._defaultVatType);
            if (this._defaultMethodVat == M_Config_D.METHOD_VAT_SUM)
            {
                this.cmbVatType.SelectedValue = defaultVatType.ToString();
                defaultVatType = -1;
            }

            IList<QuotationDetailInfo> list = new List<QuotationDetailInfo>();
            this.AddEmptyRow(1, ref list);

            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Init MaxLength
        /// </summary>
        private void InitMaxLength()
        {
            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;
            this.txtAttn.MaxLength = M_Customer.CONTACT_PERSON_MAX_LENGTH;

            this.txtAdd1.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd2.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd3.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;

            this.txtTel.MaxLength = M_Customer.TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Customer.FAX_MAX_LENGTH;

            this.txtSubject.MaxLength = T_Quote_H.PROJECT_NAME_MAX_LENGTH;
            this.txtMemo.MaxLength = T_Quote_H.MEMO_MAX_LENGTH;

            this.txtInchargeCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtApprovedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;

            this.txtFrontSalesCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtEngineerCD.MaxLength = M_User.MAX_USER_CODE_SHOW;

            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditions.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            this.txtCustomerNameSearch.MaxLength = 10;
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        /// <returns>QuotationDetailInfo List</returns>
        private IList<QuotationDetailInfo> GetDetailData(bool includeDelete = true)
        {
            IList<QuotationDetailInfo> ret = new List<QuotationDetailInfo>();
            var sellNo = 1;
            var sellNoDsp = 1;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                HiddenField hidType = (HiddenField)item.FindControl("hidType");

                var deleted = false;
                //Check Type
                if (hidType.Value == QuotationDetailType.HeadLine.ToString())
                {
                    CheckBox chkHeadLineDel = (CheckBox)item.FindControl("chkHeadLineDel");
                    deleted = chkHeadLineDel.Checked;
                }
                else
                {
                    CheckBox chkSellDel = (CheckBox)item.FindControl("chkSellDel");
                    deleted = chkSellDel.Checked;
                }

                if (!includeDelete && deleted)
                {
                    continue;
                }

                QuotationDetailInfo detail = this.GetDetailRow(item);

                //Reset [No]
                ////////////////////////////////////////////////
                detail.No = sellNo;

                if (detail.Type == QuotationDetailType.Sell)
                {
                    detail.Sell.SellNoDisp = sellNoDsp++;

                    var costNo = 1;
                    foreach (var cost in detail.CostList)
                    {
                        cost.No = costNo++;
                        cost.SellNo = detail.Sell.SellNoDisp;
                    }
                }

                ret.Add(detail);
                ////////////////////////////////////////////////
                sellNo++;
            }

            return ret;
        }

        /// <summary>
        /// Get Row
        /// </summary>
        /// <param name="rptI"></param>
        /// <returns></returns>
        private QuotationDetailInfo GetDetailRow(RepeaterItem rptI)
        {
            HiddenField hidType = (HiddenField)rptI.FindControl("hidType");

            QuotationDetailInfo detail = new QuotationDetailInfo();

            CheckBox chkHeadLineDel = (CheckBox)rptI.FindControl("chkHeadLineDel");
            CheckBox chkSellDel = (CheckBox)rptI.FindControl("chkSellDel");
            var methodVAT = this.cmbMethodVat.SelectedValue;
            if (this.Action == ActionMode.MethodChanged)
            {
                methodVAT = ((T_Quote_H)this.ViewState["HEADER"]).MethodVat.ToString();
            }

            //Check Type
            if (hidType.Value == QuotationDetailType.HeadLine.ToString())
            {
                //detail.No = rowNo;
                detail.Type = QuotationDetailType.HeadLine;
                detail.Checked = chkHeadLineDel.Checked;
                //HeadLine
                ITextBox txtHeadLine = (ITextBox)rptI.FindControl("txtHeadLine");
                detail.HeadLine = txtHeadLine.Value;
            }
            else
            {
                //detail.No = rowNo;
                detail.Type = QuotationDetailType.Sell;
                detail.Sell = new SellInfo();

                detail.CostList = new List<CostInfo>();
                detail.Checked = chkSellDel.Checked;

                detail.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                //SellProductCD
                ICodeTextBox txtSellProductCD = (ICodeTextBox)rptI.FindControl("txtSellProductCD");
                detail.Sell.ProductCD = txtSellProductCD.Value;

                //SellProductName
                ITextBox txtSellProductName = (ITextBox)rptI.FindControl("txtSellProductName");
                detail.Sell.ProductName = txtSellProductName.Value;

                //SellDescription
                ITextBox txtSellDescription = (ITextBox)rptI.FindControl("txtSellDescription");
                detail.Sell.Description = txtSellDescription.Value;

                //SellUnit
                DropDownList cmbSellUnit = (DropDownList)rptI.FindControl("cmbSellUnit");
                detail.Sell.UnitID = Convert.ToInt32(cmbSellUnit.SelectedValue);

                //SellPrice
                INumberTextBox txtSellPrice = (INumberTextBox)rptI.FindControl("txtSellPrice");
                detail.Sell.Price = txtSellPrice.Value;

                //SellQuantity
                INumberTextBox txtSellQuantity = (INumberTextBox)rptI.FindControl("txtSellQuantity");
                detail.Sell.Quantity = txtSellQuantity.Value;

                //SellTotal
                INumberTextBox txtSellTotal = (INumberTextBox)rptI.FindControl("txtSellTotal");
                detail.Sell.Total = txtSellTotal.Value;

                INumberTextBox txtProfit = (INumberTextBox)rptI.FindControl("txtProfit");
                detail.Sell.Profit = txtProfit.Value;

                //SellRemark
                ITextBox txtSellRemark = (ITextBox)rptI.FindControl("txtSellRemark");
                detail.Sell.Remark = txtSellRemark.Value;

                if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                {
                    //SellVat
                    INumberTextBox txtSellVat = (INumberTextBox)rptI.FindControl("txtSellVat");
                    detail.Sell.Vat = txtSellVat.Value;

                    //VatType
                    DropDownList cmbSellVatType = (DropDownList)rptI.FindControl("cmbSellVatType");
                    if (!string.IsNullOrEmpty(cmbSellVatType.SelectedValue))
                    {
                        detail.Sell.VatType = Convert.ToInt32(cmbSellVatType.SelectedValue);
                    }

                    //SellVatRatio
                    INumberTextBox txtSellVatRatio = (INumberTextBox)rptI.FindControl("txtSellVatRatio");
                    detail.Sell.VatRatio = txtSellVatRatio.Value;
                }

                Repeater cost = (Repeater)rptI.FindControl("rptCost");

                foreach (RepeaterItem itemCost in cost.Items)
                {
                    CostInfo costInfo = new CostInfo();

                    //CostProductCD
                    ICodeTextBox txtCostProductCD = (ICodeTextBox)itemCost.FindControl("txtCostProductCD");
                    costInfo.ProductCD = txtCostProductCD.Value;

                    //CostProductName
                    ITextBox txtCostProductName = (ITextBox)itemCost.FindControl("txtCostProductName");
                    costInfo.ProductName = txtCostProductName.Value;

                    //CostDescription
                    ITextBox txtCostDescription = (ITextBox)itemCost.FindControl("txtCostDescription");
                    costInfo.Description = txtCostDescription.Value;

                    //CostExchangeRate
                    DropDownList cmbCostCurrency = (DropDownList)itemCost.FindControl("cmbCostCurrency");
                    costInfo.CurrencyID = Convert.ToInt32(cmbCostCurrency.SelectedItem.Value);

                    //CostPrice
                    INumberTextBox txtCostPrice = (INumberTextBox)itemCost.FindControl("txtCostPrice");
                    costInfo.Price = txtCostPrice.Value;

                    //CostQuantity
                    INumberTextBox txtCostQuantity = (INumberTextBox)itemCost.FindControl("txtCostQuantity");
                    costInfo.Quantity = txtCostQuantity.Value;

                    //CostTotal
                    INumberTextBox txtCostTotal = (INumberTextBox)itemCost.FindControl("txtCostTotal");
                    costInfo.Total = txtCostTotal.Value;

                    //CostVat
                    INumberTextBox txtCostVat = (INumberTextBox)itemCost.FindControl("txtCostVat");
                    costInfo.Vat = txtCostVat.Value;

                    //CostUnit
                    DropDownList cmbCostUnit = (DropDownList)itemCost.FindControl("cmbCostUnit");
                    costInfo.UnitID = Convert.ToInt32(cmbCostUnit.SelectedValue);

                    //PurchaseFlag
                    HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)itemCost.FindControl("chkPurchaseFlag");
                    costInfo.PurchaseFlag = (chkPurchaseFlag.Checked) ? true : false;

                    //CostVendorCD
                    ICodeTextBox txtCostVendorCD = (ICodeTextBox)itemCost.FindControl("txtCostVendorCD");
                    costInfo.VendorCD = txtCostVendorCD.Value;

                    //CostVendorName
                    ITextBox txtCostVendorName = (ITextBox)itemCost.FindControl("txtCostVendorName");
                    costInfo.VendorName = txtCostVendorName.Value;

                    //VatType
                    DropDownList cmbCostVatType = (DropDownList)itemCost.FindControl("cmbCostVatType");
                    costInfo.VatType = Convert.ToInt32(cmbCostVatType.SelectedItem.Value);

                    //CostVatRatio
                    INumberTextBox txtCostVatRatio = (INumberTextBox)itemCost.FindControl("txtCostVatRatio");
                    costInfo.VatRatio = txtCostVatRatio.Value;

                    detail.CostList.Add(costInfo);
                }
            }
            return detail;
        }

        /// <summary>
        /// Up or Down Item
        /// </summary>
        /// <param name="up">Up Flg</param>
        private void SwapDetail(bool up)
        {
            IList<QuotationDetailInfo> details = this.GetDetailData();

            if (details.Count == 0)
            {
                return;
            }

            IList<QuotationDetailInfo> results = new List<QuotationDetailInfo>();

            if (up)
            {
                results.Add(details.First());
                for (int i = 1; i < details.Count; i++)
                {
                    var item = details[i];
                    var itemPre = results[i - 1];

                    if (item.Checked)
                    {
                        if (itemPre.Checked)
                        {
                            results.Add(item);
                        }
                        else
                        {
                            results.Insert(i - 1, item);
                        }
                    }
                    else
                    {
                        results.Add(item);
                    }
                }
            }
            else
            {
                results.Add(details.Last());
                for (int i = details.Count - 2; i >= 0; i--)
                {
                    var item = details[i];
                    if (item.Checked)
                    {
                        if (results[0].Checked)
                        {
                            results.Insert(0, item);
                        }
                        else
                        {
                            results.Insert(1, item);
                        }
                    }
                    else
                    {
                        results.Insert(0, item);
                    }
                }
            }

            var sellNo = 1;

            for (int i = 0; i < results.Count; i++)
            {
                var row = results[i];
                row.No = i + 1;
                if (row.Type == QuotationDetailType.Sell)
                {
                    row.Sell.SellNoDisp = sellNo++;
                    var costNo = 1;
                    foreach (var item in row.CostList)
                    {
                        item.SellNo = row.Sell.SellNoDisp;
                        item.No = costNo++;
                    }
                }
            }

            this.rptDetail.DataSource = results;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Set Confirm
        /// </summary>
        private void SetConfirmDetailData(bool keepOldValue = true)
        {
            using (DB db = new DB())
            {
                ProductService prodSrv = new ProductService(db);
                VendorService vendorSrv = new VendorService(db);

                var baseDate = db.NowDate;
                if (!this.txtQuotationDate.IsEmpty)
                {
                    baseDate = this.txtQuotationDate.Value.GetValueOrDefault();
                }

                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                var methodType = this.cmbMethodVat.SelectedValue;
                if (this.Action == ActionMode.MethodChanged)
                {
                    //Show old value
                    methodType = ((T_Quote_H)this.ViewState["HEADER"]).MethodVat.ToString();
                }

                var sumTotalSell = 0m;

                var sumVatSell = 0m;
                var sumTotalCost = 0m;
                //var allHeadLine = true;

                #region Detail

                foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
                {
                    HiddenField hidType = (HiddenField)repeaterItem.FindControl("hidType");
                    //Check Type
                    if (hidType.Value != QuotationDetailType.HeadLine.ToString())
                    {
                        //allHeadLine = false;
                        ICodeTextBox txtSellProductCD = (ICodeTextBox)repeaterItem.FindControl("txtSellProductCD");
                        ITextBox txtSellProductName = (ITextBox)repeaterItem.FindControl("txtSellProductName");
                        if (!txtSellProductCD.IsEmpty && txtSellProductCD.Value != M_Product.PRODUCT_CODE_SUPPORT
                            && txtSellProductName.IsEmpty)
                        {
                            var product = prodSrv.GetByCD(txtSellProductCD.Value);
                            if (product != null && product.StatusFlag == 0)
                            {
                                txtSellProductName.Value = product.ProductName;
                            }
                        }

                        DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbSellVatType");

                        INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtSellVat");
                        INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtSellVatRatio");

                        INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtSellPrice");
                        INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtSellQuantity");
                        INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtSellTotal");

                        var unitPrice = txtSellPrice.Value.GetValueOrDefault();
                        var quantity = txtSellQuantity.Value.GetValueOrDefault();
                        var total = Fraction.Round(this._defaultFractionType, unitPrice * quantity, 2);
                        var vat = Fraction.Round(this._defaultFractionType, (total * txtSellVatRatio.Value.GetValueOrDefault()) / 100, 2);

                        if (!txtSellPrice.IsEmpty && !txtSellQuantity.IsEmpty)
                        {
                            if (txtSellTotal.IsEmpty || !keepOldValue)
                            {
                                txtSellTotal.Value = total;
                            }
                            sumTotalSell += txtSellTotal.Value.GetValueOrDefault();

                            if (methodType == M_Config_D.METHOD_VAT_EACH &&
                                int.Parse(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                            {
                                if (txtSellVat.IsEmpty || !keepOldValue)
                                {
                                    txtSellVat.Value = vat;
                                }
                                sumVatSell += txtSellVat.Value.GetValueOrDefault();
                            }
                        }
                        if (methodType == M_Config_D.METHOD_VAT_SUM ||
                                int.Parse(cmbSellVatType.SelectedItem.Value) != (int)VATFlg.Exclude)
                        {
                            txtSellVatRatio.Value = null;
                            txtSellVat.Value = null;

                            txtSellVatRatio.SetReadOnly(true);
                            txtSellVat.SetReadOnly(true);
                        }
                        else
                        {
                            txtSellVatRatio.SetReadOnly(false);
                            txtSellVat.SetReadOnly(false);
                        }

                        Repeater cost = (Repeater)repeaterItem.FindControl("rptCost");
                        foreach (RepeaterItem itemCost in cost.Items)
                        {
                            ICodeTextBox txtCostProductCD = (ICodeTextBox)itemCost.FindControl("txtCostProductCD");
                            ITextBox txtCostProductName = (ITextBox)itemCost.FindControl("txtCostProductName");
                            if (!txtCostProductCD.IsEmpty && txtCostProductCD.Value != M_Product.PRODUCT_CODE_SUPPORT
                                && txtCostProductName.IsEmpty)
                            {
                                var product = prodSrv.GetByCD(txtCostProductCD.Value);
                                if (product != null && product.StatusFlag == 0)
                                {
                                    txtCostProductName.Value = product.ProductName;
                                }
                            }

                            HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)itemCost.FindControl("chkPurchaseFlag");
                            if (chkPurchaseFlag.Checked)
                            {
                                if (this._productCdSetting == M_Config_D.PRODUCT_CD_SETTING_SAME && txtCostProductCD.IsEmpty)
                                {
                                    txtCostProductCD.Value = txtSellProductCD.Value;
                                }
                                ICodeTextBox txtCostVendorCD = (ICodeTextBox)itemCost.FindControl("txtCostVendorCD");
                                ITextBox txtCostVendorName = (ITextBox)itemCost.FindControl("txtCostVendorName");

                                txtCostVendorName.SetReadOnly(true);
                                if (!txtCostVendorCD.IsEmpty)
                                {
                                    if (txtCostVendorCD.Value != M_Vendor.VENDOR_CODE_SUPPORT)
                                    {
                                        var vendorCd = txtCostVendorCD.Value;
                                        vendorCd = EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                                        var vendor = vendorSrv.GetByCD(vendorCd);
                                        txtCostVendorName.Value = null;
                                        if (vendor != null)
                                        {
                                            txtCostVendorName.Value = vendor.VendorName1;
                                        }
                                    }
                                    else
                                    {
                                        txtCostVendorName.SetReadOnly(false);
                                    }
                                }
                                else
                                {
                                    txtCostVendorName.Value = null;
                                }
                            }
                            //CostExchangeRate
                            DropDownList cmbCostCurrency = (DropDownList)itemCost.FindControl("cmbCostCurrency");

                            DropDownList cmbCostVatType = (DropDownList)itemCost.FindControl("cmbCostVatType");
                            INumberTextBox txtCostVat = (INumberTextBox)itemCost.FindControl("txtCostVat");
                            INumberTextBox txtCostVatRatio = (INumberTextBox)itemCost.FindControl("txtCostVatRatio");
                            INumberTextBox txtCostPrice = (INumberTextBox)itemCost.FindControl("txtCostPrice");
                            INumberTextBox txtCostQuantity = (INumberTextBox)itemCost.FindControl("txtCostQuantity");
                            INumberTextBox txtCostTotal = (INumberTextBox)itemCost.FindControl("txtCostTotal");

                            unitPrice = txtCostPrice.Value.GetValueOrDefault();
                            quantity = txtCostQuantity.Value.GetValueOrDefault();

                            total = Fraction.Round(this._defaultFractionType, unitPrice * quantity, 2);
                            vat = Fraction.Round(this._defaultFractionType, (total * txtCostVatRatio.Value.GetValueOrDefault()) / 100, 2);

                            if (!txtCostPrice.IsEmpty && !txtCostQuantity.IsEmpty)
                            {
                                if (txtCostTotal.IsEmpty || !keepOldValue)
                                {
                                    txtCostTotal.Value = total;
                                }

                                if (int.Parse(cmbCostVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                                {
                                    if (txtCostVat.IsEmpty || !keepOldValue)
                                    {
                                        txtCostVat.Value = vat;
                                    }
                                }
                            }
                            if (int.Parse(cmbCostVatType.SelectedItem.Value) != (int)VATFlg.Exclude)
                            {
                                txtCostVat.Value = null;
                                txtCostVatRatio.Value = null;

                                txtCostVatRatio.SetReadOnly(true);
                                txtCostVat.SetReadOnly(true);
                            }
                            else
                            {
                                txtCostVatRatio.SetReadOnly(false);
                                txtCostVat.SetReadOnly(false);
                            }

                            int costCurrencyId = int.Parse(cmbCostCurrency.SelectedValue);
                            //VND
                            if (costCurrencyId == Constant.DEFAULT_ID)
                            {
                                sumTotalCost += txtCostTotal.Value.GetValueOrDefault();
                            }
                            else
                            {
                                // convert to VND
                                var exchangeRate = crcyList[costCurrencyId].ExchangeRate;
                                sumTotalCost += CommonUtil.ConvertToVND(exchangeRate, txtCostTotal.Value.GetValueOrDefault());
                            }
                        }
                    }
                }

                #endregion Detail

                #region SumTotal

                if (this.txtSumTotal.IsEmpty || !keepOldValue)
                {
                    this.txtSumTotal.Value = sumTotalSell;
                }
                sumTotalSell = this.txtSumTotal.Value.GetValueOrDefault();

                if (methodType == M_Config_D.METHOD_VAT_EACH)
                {
                    if (this.txtSumVat.IsEmpty || !keepOldValue)
                    {
                        this.txtSumVat.Value = sumVatSell;
                    }
                    else
                    {
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                    }
                }
                else
                {
                    var vatType = int.Parse(this._defaultVatType);
                    if (!string.IsNullOrEmpty(this.cmbVatType.SelectedValue))
                    {
                        vatType = int.Parse(this.cmbVatType.SelectedValue);
                    }
                    if (vatType == (int)VATFlg.Exclude && !string.IsNullOrEmpty(this.cmbVatType.SelectedValue))
                    {
                        var vatRatio = this.txtVatRatio.Value.GetValueOrDefault();
                        if (this.txtSumVat.IsEmpty || !keepOldValue)
                        {
                            this.txtSumVat.Value = Fraction.Round(this._defaultFractionType, (sumTotalSell * vatRatio) / 100, 2);
                        }
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();

                        this.txtSumVat.SetReadOnly(false);
                        this.txtVatRatio.SetReadOnly(false);
                    }
                    else
                    {
                        sumVatSell = 0;
                        this.txtSumVat.SetReadOnly(true);
                        this.txtVatRatio.SetReadOnly(true);

                        this.txtSumVat.Value = null;
                        this.txtVatRatio.Value = null;
                    }
                }

                if (!this.txtGrandTotal.Value.HasValue || !keepOldValue)
                {
                    this.txtGrandTotal.Value = sumTotalSell + sumVatSell;
                }
                var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);

                var profit = 0m;
                if (mainCurrencyId != Constant.DEFAULT_ID)
                {
                    //Convert totalCost to ....
                    var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                    sumTotalCost = CommonUtil.ConvertToNotVND(exchangeRate, sumTotalCost);
                }
                profit = EditDataUtil.CalSumProfit(sumTotalSell, sumTotalCost);
                if (profit > Constant.MAX_PROFIT)
                {
                    profit = Constant.MAX_PROFIT;
                }
                this.txtSumProfit.Value = profit;

                #endregion SumTotal
            }
        }

        /// <summary>
        /// Set Header confirm
        /// </summary>
        private void SetConfirmHeaderData()
        {
            using (DB db = new DB())
            {
                CustomerService custSrv = new CustomerService(db);
                UserService userSrv = new UserService(db);
                //-----------------ISV-HUNG 2015/01/05
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(this.DataID, (int)FType.Quote);
                //-----------------ISV-HUNG 2015/01/05

                #region Header

                //txtCustomerCD
                if (!this.txtCustomerCD.IsEmpty && this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    this.txtCustomerName.SetReadOnly(true);
                    var customerCd = this.txtCustomerCD.Value;
                    customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = custSrv.GetByCustomerCD(customerCd);
                    if (customer != null && customer.StatusFlag != 1)
                    {
                        this.txtCustomerName.Value = customer.CustomerName1;
                    }
                }
                else
                {
                    if (this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                    {
                        this.txtCustomerName.Value = null;
                        this.txtCustomerName.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(false);
                    }
                }

                M_User user = null;
                this.txtInchargeName.Value = null;
                //txtInchargeCD
                if (!this.txtInchargeCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtInchargeCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtInchargeName.Value = user.UserName2;
                    }
                }

                this.txtApprovedName.Value = null;
                //txtApprovedCD
                if (!this.txtApprovedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }

                this.txtFrontSalesName.Value = null;
                //txtFrontSalesCD
                if (!this.txtFrontSalesCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtFrontSalesCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtFrontSalesName.Value = user.UserName2;
                    }
                }

                this.txtEngineerName.Value = null;
                //txtEngineerCD
                if (!this.txtEngineerCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtEngineerCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtEngineerName.Value = user.UserName2;
                    }
                }

                #endregion Header
            }
        }

        /// <summary>
        /// Check exist data
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private T_Quote_H GetByID(int id)
        {
            using (DB db = new DB())
            {
                Quotation_HService service = new Quotation_HService(db);
                return service.GetByPK(id);
            }
        }

        /// <summary>
        /// Get Category by Category id
        /// </summary>
        /// <param name="categoryId">Category id</param>
        /// <returns>User</returns>
        private void SetQuoteInfo(int id)
        {
            using (DB db = new DB())
            {
                Quotation_HService hService = new Quotation_HService(db);
                Quotation_D_SellService sService = new Quotation_D_SellService(db);
                Quotation_D_CostService cService = new Quotation_D_CostService(db);
                Quotation_CService condService = new Quotation_CService(db);

                UserService userService = new UserService(db);
                AttachedService attachedService = new AttachedService(db);

                var header = hService.GetByPK(id);

                this.txtCustomerCD.Value = header.CustomerCD;

                if (header.CustomerCD == Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    this.txtCustomerName.SetReadOnly(false);
                }

                this.txtCustomerNameSearch.Value = string.Empty;

                this.txtCustomerName.Value = header.CustomerName;

                this.txtAttn.Value = header.ContactPerson;

                this.txtAdd1.Value = header.CustomerAddress1;
                this.txtAdd2.Value = header.CustomerAddress2;
                this.txtAdd3.Value = header.CustomerAddress3;

                this.txtTel.Value = header.Tel;
                this.txtFax.Value = header.FAX;
                this.txtSubject.Value = header.SubjectName;

                var lastest = hService.GetNewestByQuoteNo(header.QuoteNo);
                this.Sold = lastest.StatusFlag == (short)StatusFlag.Sales;

                this.InitDropDownListData(this.cmbStatus, this._statusList);
                if (!this.Sold)
                {
                    this.cmbStatus.SelectedValue = header.StatusFlag.ToString();
                }
                else
                {
                    //StatusList
                    this._statusList.Insert(0, new DropDownModel
                    {
                        DataboundItem = null,
                        DisplayName = string.Empty,
                        Value = "-1"
                    });
                    this.InitDropDownListData(this.cmbStatus, this._statusList);
                    this.cmbStatus.SelectedValue = "-1";
                }

                this.txtQuotationNo.Value = header.QuoteNo;
                this.txtQuotationDate.Value = header.QuoteDate;
                this.txtExpDate.Value = header.ExpiryDate;


                if (header.ExpectedOrderDate == DEFAULT_DATE_TIME)
                {
                    this.txtExpectedOrderDate.Value = null;
                }
                else
                {
                    this.txtExpectedOrderDate.Value = header.ExpectedOrderDate;
                }
                if (header.ExpectedRevenueDate == DEFAULT_DATE_TIME)
                {
                    this.txtExpectedRevenueDate.Value = null;
                }
                else
                {
                    this.txtExpectedRevenueDate.Value = header.ExpectedRevenueDate;
                }
                this.txtInchargeCD.Value = header.PreparedCD;
                this.txtInchargeName.Value = header.PreparedName;
                this.txtApprovedCD.Value = header.ApprovedCD;
                this.txtApprovedName.Value = header.ApprovedName;
                this.txtFrontSalesCD.Value = header.SalesCD1;
                this.txtFrontSalesName.Value = header.SalesName1;
                this.txtEngineerCD.Value = header.SalesCD2;
                this.txtEngineerName.Value = header.SalesName2;

                this.InitDropDownListData(this.cmbCurrency, this._currencyList);
                this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();

                var methodVat = header.MethodVat.ToString();
                this.InitDropDownListData(this.cmbMethodVat, this._methodVatList);
                this.cmbMethodVat.SelectedValue = methodVat;

                this.txtMemo.Value = header.Memo;
                //
                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                //
                if (methodVat.Equals(M_Config_D.METHOD_VAT_SUM))
                {
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeList);

                    this.cmbVatType.SelectedValue = header.VatType.ToString();
                    this.txtVatRatio.Value = header.VatRatio;
                    this.txtSumVat.Value = null;
                    if (this.cmbVatType.SelectedValue == ((int)VATFlg.Exclude).ToString())
                    {
                        this.txtSumVat.Value = header.Vat;
                    }
                }
                else
                {
                    this.InitDropDownListData(this.cmbVatType, this._vatTypeListEmpty);

                    this.cmbVatType.SelectedValue = null;
                    this.txtVatRatio.Value = null;
                    this.txtSumVat.Value = header.Vat;
                }

                this.txtSumTotal.Value = header.Total;
                this.txtGrandTotal.Value = header.GrandTotal;

                this.IsNew = header.NewFlag == 0;
                this.Issued = header.IssuedFlag == 1;
                this.Losted = header.StatusFlag == (short)StatusFlag.Lost;

                //Save UserID and UpdateDate
                this.DataID = header.ID;
                this.OldUpdateDate = header.UpdateDate;

                this.txtConditionCD.Value = string.Empty;
                T_Quote_C model = condService.GetByPK(header.ID);
                if (model != null)
                {
                    //Load Condition
                    this.txtConditions.Value = model.Conditions;
                    this.OldCondition = model.Conditions;
                }
                this.txtApproved.Value = header.Approved;
                this.txtPosition.Value = header.Position;

                //Issue
                var issueUser = userService.GetByID(header.IssuedUID);
                if (issueUser != null)
                {
                    var issuedDate = (header.IssuedDate == DEFAULT_DATE_TIME) ? string.Empty : header.IssuedDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtIssueDate.Value = string.Format("{0} {1}", issueUser.UserName2, issuedDate);
                }
                else
                {
                    this.txtIssueDate.Value = string.Empty;
                }
                //Update
                var updateUser = userService.GetByID(header.UpdateUID);
                if (updateUser != null)
                {
                    var updateDate = (header.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : header.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                else
                {
                    this.txtUpdateDate.Value = string.Empty;
                }
                //Create
                var createUser = userService.GetByID(header.CreateUID);
                if (createUser != null)
                {
                    var createDate = (header.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : header.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }
                else
                {
                    this.txtCreateDate.Value = string.Empty;
                }

                this.ViewState["HEADER"] = header;

                var sellNo = 0;
                var sells = sService.GetListByHID(id);
                var cost = cService.GetListByHID(id);
                var details = new List<QuotationDetailInfo>(sells.Select(s => new QuotationDetailInfo
                {
                    Type = s.HeadlineFlag == 1 ? QuotationDetailType.HeadLine : QuotationDetailType.Sell,
                    HeadLine = s.HeadlineFlag == 1 ? s.Headline : string.Empty,
                    No = s.No,
                    Sell = new SellInfo
                    {
                        SellNoDisp = s.HeadlineFlag == 0 ? ++sellNo : 0,
                        ProductCD = s.ProductCD,
                        ProductName = s.ProductName,
                        Description = s.Description,
                        Price = s.UnitPrice,
                        Quantity = s.Quantity,
                        Total = s.Total,
                        Vat = s.Vat,
                        UnitID = s.UnitID,
                        Remark = s.Remark,
                        VatType = s.VatType,
                        VatRatio = s.VatRatio,
                        Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty
                    },
                    CostList = new List<CostInfo>(cost.Where(c => c.SellNo == s.No).Select(c => new CostInfo
                    {
                        SellNo = sellNo,
                        No = c.No,
                        ProductCD = c.ProductCD,
                        ProductName = c.ProductName,
                        Description = c.Description,
                        Price = (decimal?)c.UnitPrice,
                        Quantity = (decimal?)c.Quantity,
                        Total = (decimal?)c.Total,
                        Vat = (decimal?)c.Vat,

                        UnitID = c.UnitID,
                        CurrencyID = c.CurrencyID,
                        PurchaseFlag = c.PurchaseFlag == 1 ? true : false,
                        VendorCD = c.PurchaseFlag == 1 ? c.VendorCD : string.Empty,
                        VendorName = c.PurchaseFlag == 1 ? c.VendorName : string.Empty,
                        VatType = c.VatType,
                        VatRatio = c.VatRatio
                    }))
                }));
                this.FileCount = attachedService.CountFile(this.DataID, (int)FType.Quote);

                if (!this.Sold)
                {
                    base.DisabledLink(this.btnSales, !details.Any(s => ((this.ProductCdUsed && !string.IsNullOrEmpty(s.Sell.ProductCD)) || (!this.ProductCdUsed && !string.IsNullOrEmpty(s.Sell.ProductName))) && s.Sell.Quantity != 0m));
                }
                else
                {
                    base.DisabledLink(this.btnSales, true);
                }
                this.chkDelAll.Checked = false;
                this.RefreshDetails(details);
                this.SetSellMarkup(header.QuoteDate);

                this.SetConfirmDetailData(true);
            }
        }

        /// <summary>
        /// Insert data into database
        /// </summary>
        private bool InsertData()
        {
            //Get insert data
            var header = new T_Quote_H();
            this.GetHeader(header);
            header.IssuedFlag = 0;
            header.IssuedDate = DEFAULT_DATE_TIME;
            header.IssuedUID = 0;

            IList<T_Quote_D_Sell> sellList = null;
            IList<T_Quote_D_Cost> costList = null;
            this.CreateDetail(ref sellList, ref costList);

            try
            {
                //Get QuoteNo
                using (DB db = new DB())
                {
                    header.QuoteNo = (new TNoService(db)).CreateNo(T_No.QuoteNo);
                }                

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var quoteSrv = new Quotation_HService(db);

                    Quotation_CService quoteCSrv = new Quotation_CService(db);

                    //Insert Header
                    var quoteId = quoteSrv.Insert(header);

                    if (quoteId > 0)
                    {
                        //Insert quote Condition
                        this.InsertQuoteCondition(quoteCSrv, quoteId);

                        var quoteSellSrv = new Quotation_D_SellService(db);

                        var quoteCostSrv = new Quotation_D_CostService(db);

                        foreach (var sell in sellList)
                        {
                            sell.HID = quoteId;
                            quoteSellSrv.Insert(sell);
                        }

                        foreach (var cost in costList)
                        {
                            cost.HID = quoteId;
                            quoteCostSrv.Insert(cost);
                        }

                        this.DataID = quoteId;
                        db.Commit();
                        return true;
                    }
                }
            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.QuoteNo))
                {
                    this.SetMessage(this.txtQuotationNo.ClientID, M_Message.MSG_SIZE_MAX_NO, "Quote No");
                }
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_UN))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CURRENCY))
                //{
                //    this.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Selling Currency");
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CUSTOMER))
                //{
                //    this.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return false;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                // UI Items
                //------------------------------------------------------
                IList<T_Quote_D_Sell> sellUIList = null;
                IList<T_Quote_D_Cost> costUIList = null;

                this.CreateDetail(ref sellUIList, ref costUIList);
                //------------------------------------------------------

                //Get QuoteNo
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var id = this.DataID;

                    Quotation_HService hService = new Quotation_HService(db);
                    Quotation_D_SellService sService = new Quotation_D_SellService(db);
                    Quotation_D_CostService cService = new Quotation_D_CostService(db);
                    Quotation_CService condService = new Quotation_CService(db);

                    var header = hService.GetByPK(id);

                    //Get Update data
                    this.GetHeader(header);

                    var headerChanged = header.Status == DataStatus.Changed;

                    header.UpdateDate = this.OldUpdateDate;

                    //DB Items
                    //------------------------------------------------------
                    var detailChanged = false;
                    var sellDbList = sService.GetListByHID(id);
                    var costDbList = cService.GetListByHID(id);
                    if (sellUIList.Count != sellDbList.Count || costUIList.Count != costDbList.Count)
                    {
                        detailChanged = true;
                    }

                    this.CreateDetail(ref sellDbList, ref costDbList);
                    //------------------------------------------------------
                    if (!detailChanged)
                    {
                        detailChanged = sellDbList.Any(s => s.Status == DataStatus.Changed) || costDbList.Any(c => c.Status == DataStatus.Changed);
                    }
                    if (!detailChanged)
                    {
                        detailChanged = this.txtConditions.Value != this.OldCondition;
                    }

                    if (headerChanged || detailChanged)
                    {
                        header.IssuedFlag = 0;
                        header.IssuedUID = 0;
                        header.IssuedDate = DEFAULT_DATE_TIME;

                        if (hService.Update(header) > 0)
                        {
                            //Update Quote Condition
                            this.InsertQuoteCondition(condService, header.ID);

                            sService.Delete(id);
                            foreach (var sell in sellUIList)
                            {
                                sell.HID = id;
                                sService.Insert(sell);
                            }

                            cService.Delete(id);
                            foreach (var cost in costUIList)
                            {
                                cost.HID = id;
                                cService.Insert(cost);
                            }

                            db.Commit();
                            return true;
                        }
                        else
                        {
                            //du lieu da thay doi
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                    }
                    return true;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_UN))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CURRENCY))
                //{
                //    this.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Selling Currency");
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CUSTOMER))
                //{
                //    this.SetMessage(this.txtCustomerCD.ID , M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
        }

        /// <summary>
        /// Revise data into database
        /// </summary>
        /// <returns></returns>
        private bool ReviseData()
        {
            try
            {
                IList<T_Quote_D_Sell> sellList = null;
                IList<T_Quote_D_Cost> costList = null;
                this.CreateDetail(ref sellList, ref costList);

                //Get QuoteNo
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var id = this.DataID;

                    Quotation_HService hService = new Quotation_HService(db);
                    Quotation_D_SellService sService = new Quotation_D_SellService(db);
                    Quotation_D_CostService cService = new Quotation_D_CostService(db);
                    Quotation_CService condService = new Quotation_CService(db);

                    var header = hService.GetByPK(id);
                    header.NewFlag = 1;
                    header.UpdateDate = this.OldUpdateDate;
                    if (hService.Update(header) > 0)
                    {
                        this.GetHeader(header);
                        header.QuoteNo = this.txtQuotationNo.Value;
                        header.IssuedFlag = 0;
                        header.IssuedDate = DEFAULT_DATE_TIME;
                        header.IssuedUID = 0;

                        //Insert Header
                        var quoteId = hService.Insert(header);

                        //insert Condition
                        this.InsertQuoteCondition(condService, quoteId);

                        foreach (var sell in sellList)
                        {
                            sell.HID = quoteId;
                            sService.Insert(sell);
                        }

                        foreach (var cost in costList)
                        {
                            cost.HID = quoteId;
                            cService.Insert(cost);
                        }

                        this.DataID = quoteId;
                        db.Commit();
                        return true;
                    }
                    else
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_UN))
                //{
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CURRENCY))
                //{
                //    this.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Selling Currency");
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_QUOTE_H_FK_CUSTOMER))
                //{
                //    this.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_QUOTE_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
        }

        /// <summary>
        /// Sales data into database
        /// </summary>
        /// <returns></returns>
        private bool MakeSalesData(ref string salesNo)
        {
            try
            {
                using (DB db = new DB())
                {
                    TNoService noService = new TNoService(db);
                    salesNo = noService.CreateNo(T_No.SalesNo);
                }                

                //Get QuoteNo
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var quoteHSrv = new Quotation_HService(db);
                    var quoteDSSrv = new Quotation_D_SellService(db);
                    var quoteDCSrv = new Quotation_D_CostService(db);

                    //Get Quote data
                    var header = quoteHSrv.GetByPK(this.DataID);
                    if (header.StatusFlag == (int)StatusFlag.Sales)
                    {
                        base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                        return false;
                    }
                    var salesH = this.GetSalesHeader(header);

                    var sysDate = db.NowDate;
                    salesH.QuoteNo = this.txtQuotationNo.Value;
                    salesH.SalesNo = salesNo;
                    salesH.SalesDate = sysDate;

                    //---------------Add 2015/01/06 ISV-HUNG-----------------//
                    Config_DService configDService = new Config_DService(db);
                    //Comlete Date
                    var expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Complete_Date));
                    if (!expiryDay.HasValue)
                    {
                        salesH.CompleteDate = DEFAULT_DATE_TIME;
                    }
                    else
                    {
                        var completeDate = sysDate.AddDays(expiryDay.Value);
                        salesH.CompleteDate = completeDate;
                    }

                    //Payment Date
                    expiryDay = configDService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Payment_Date));
                    if (!expiryDay.HasValue)
                    {
                        salesH.PaymentDate = DEFAULT_DATE_TIME;
                    }
                    else
                    {
                        var paymentDate = sysDate.AddDays(expiryDay.Value);
                        salesH.PaymentDate = paymentDate;
                    }
                    //---------------Add 2015/01/06 ISV-HUNG-----------------//

                    IList<T_Quote_D_Sell> sellList = quoteDSSrv.GetListByHID(header.ID);
                    IList<T_Quote_D_Cost> costList = quoteDCSrv.GetListByHID(header.ID);

                    IList<T_Sales_D_Sell> salesSellList = null;
                    IList<T_Sales_D_Cost> salesCostList = null;
                    this.CopyToSalesDetail(ref salesSellList, ref salesCostList, sellList, costList);

                    #region Update Quote

                    var quoH = quoteHSrv.GetByPK(this.DataID);

                    quoH.StatusFlag = (short)StatusFlag.Sales;
                    quoH.UpdateUID = base.LoginInfo.User.ID;
                    quoH.UpdateDate = this.OldUpdateDate;
                    if (quoteHSrv.Update(quoH) == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                        return false;
                    }

                    #endregion Update Quote

                    #region Insert Sales

                    Sales_HService sales_HService = new Sales_HService(db);

                    //Insert Sales header
                    if (sales_HService.Insert(salesH) > 0)
                    {
                        var salesId = db.GetIdentityId<T_Sales_H>();
                        Sales_CService salesCSrv = new Sales_CService(db);

                        //Insert Sales Condition
                        this.InsertSalesCondition(salesCSrv, salesId);

                        Sales_D_SellService sales_D_SellService = new Sales_D_SellService(db);
                        Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);

                        foreach (var sell in salesSellList)
                        {
                            sell.HID = salesId;
                            sales_D_SellService.Insert(sell);
                        }

                        foreach (var cost in salesCostList)
                        {
                            cost.HID = salesId;
                            sales_D_CostService.Insert(cost);
                        }
                    }

                    #endregion Insert Sales

                    db.Commit();
                    return true;
                }
            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.SalesNo))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_SIZE_MAX_NO, "Sales No");
                }
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_UN))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CURRENCY))
                //{
                //    this.SetMessage(this.cmbCurrency.ID, M_Message.MSG_NOT_EXIST_CODE, "Selling Currency");
                //    return false;
                //}
                //if (ex.Message.Contains(Models.Constant.T_SALES_H_FK_CUSTOMER))
                //{
                //    this.SetMessage(this.txtCustomerCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_SELL_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_UNIT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_SALES_D_COST_FK_VENDOR))
                //{
                //    return false;
                //}

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
        }

        /// <summary>
        /// View Prev Quotation
        /// </summary>
        private void ViewPrevQuote()
        {
            //Get QuoteNo
            using (DB db = new DB())
            {
                var hService = new Quotation_HService(db);
                //Get prev quote No
                var quoteNo = this.txtQuotationNo.Value;

                var header = hService.GetByQuoteNo(quoteNo);
                if (header.UpdateDate != this.OldUpdateDate && header.DeleteFlag == 1)
                {
                    base.RedirectUrl(URL_QUOTE_LIST);
                }
                else
                {
                    string prevQuoteNo = string.Empty;
                    if (quoteNo.Substring(quoteNo.Length - 3, 1).ToLower() == "r")
                    {
                        int tail = int.Parse(quoteNo.Substring(quoteNo.Length - 2, 2)) - 1;

                        if (tail == 0)
                        {
                            prevQuoteNo = quoteNo.Substring(0, quoteNo.Length - 4);
                        }
                        else
                        {
                            prevQuoteNo = quoteNo.Substring(0, quoteNo.Length - 2) + tail.ToString("00");
                        }
                    }

                    header = hService.GetByQuoteNo(prevQuoteNo);
                    this.DataID = header.ID;

                    this.SetQuoteInfo(header.ID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
        }

        /// <summary>
        /// View Next Quotation
        /// </summary>
        private void ViewNextQuote()
        {
            //Get QuoteNo
            using (DB db = new DB())
            {
                var hService = new Quotation_HService(db);
                //Get prev quote No
                var quoteNo = this.txtQuotationNo.Value;
                var header = hService.GetByQuoteNo(quoteNo);
                if (header.UpdateDate != this.OldUpdateDate && header.DeleteFlag == 1)
                {
                    base.RedirectUrl(URL_QUOTE_LIST);
                }
                else
                {
                    //  //Get next quote No
                    string nextQuoteNo = this.GetNextReviseNo();

                    header = hService.GetByQuoteNo(nextQuoteNo);

                    this.DataID = header.ID;

                    this.SetQuoteInfo(header.ID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        private T_Sales_H GetSalesHeader(T_Quote_H header)
        {
            return new T_Sales_H
            {
                //ExpiryDate = header.ExpiryDate,
                QuoteNo = header.QuoteNo,
                QuoteDate = header.QuoteDate,
                PreparedCD = header.PreparedCD,
                PreparedName = header.PreparedName,
                ApprovedCD = header.ApprovedCD,
                ApprovedName = header.ApprovedName,
                SalesCD1 = header.SalesCD1,
                SalesName1 = header.SalesName1,
                SalesCD2 = header.SalesCD2,
                SalesName2 = header.SalesName2,
                CustomerCD = header.CustomerCD,
                CustomerName = header.CustomerName,
                SubjectName = header.SubjectName,
                CustomerAddress1 = header.CustomerAddress1,
                CustomerAddress2 = header.CustomerAddress2,
                CustomerAddress3 = header.CustomerAddress3,
                Tel = header.Tel,
                FAX = header.FAX,
                ContactPerson = header.ContactPerson,
                CurrencyID = header.CurrencyID,
                MethodVat = header.MethodVat,
                Total = header.Total,
                Vat = header.Vat,
                VatRatio = header.VatRatio,
                VatType = header.VatType,
                GrandTotal = header.GrandTotal,
                Memo = header.Memo,
                StatusFlag = (short)StatusFlag.Sales,
                IssuedFlag = 0,
                DeleteFlag = 0,
                ContractNo = string.Empty,
                ContractDate = DEFAULT_DATE_TIME,

                //---------------Add 2015/01/06 ISV-HUNG-----------------//
                CompleteDate = DEFAULT_DATE_TIME,
                PaymentDate = DEFAULT_DATE_TIME,
                //---------------Add 2015/01/06 ISV-HUNG-----------------//

                IssuedDate = DEFAULT_DATE_TIME,
                IssuedUID = 0,

                VersionUpdateDate = DEFAULT_DATE_TIME,
                VersionUpdateUID = 0,
                Approved = header.Approved,
                Position = header.Position,

                CreateUID = base.LoginInfo.User.ID,
                UpdateUID = base.LoginInfo.User.ID,
            };
        }

        /// <summary>
        /// Copy Detail to Sales
        /// </summary>
        /// <param name="aSellList"></param>
        /// <param name="aCostList"></param>
        /// <param name="qSellList"></param>
        /// <param name="qCostList"></param>
        private void CopyToSalesDetail(ref IList<T_Sales_D_Sell> aSellList, ref  IList<T_Sales_D_Cost> aCostList,
                                           IList<T_Quote_D_Sell> qSellList, IList<T_Quote_D_Cost> qCostList)
        {
            aSellList = new List<T_Sales_D_Sell>();
            aCostList = new List<T_Sales_D_Cost>();

            var sells = qSellList.Where(s => s.HeadlineFlag == 0 && !string.IsNullOrEmpty(s.ProductCD) && s.Quantity != 0m);
            var sellNo = 0;

            foreach (var s in sells)
            {
                var salesSell = new T_Sales_D_Sell();
                salesSell.No = ++sellNo;
                salesSell.ProductCD = s.ProductCD;
                salesSell.ProductName = s.ProductName;
                salesSell.Description = s.Description;
                salesSell.Remark = s.Remark;
                salesSell.UnitID = s.UnitID;
                salesSell.VatType = s.VatType;
                salesSell.VatRatio = s.VatRatio;
                salesSell.UnitPrice = s.UnitPrice;
                salesSell.Quantity = s.Quantity;
                salesSell.Total = s.Total;
                salesSell.Vat = s.Vat;
                aSellList.Add(salesSell);

                var costs = qCostList.Where(c => c.SellNo == s.No);
                var costNo = 0;
                foreach (var c in costs)
                {
                    var salesCost = new T_Sales_D_Cost();
                    salesCost.SellNo = salesSell.No;
                    salesCost.No = ++costNo;
                    salesCost.ProductCD = c.ProductCD;
                    salesCost.ProductName = c.ProductName;
                    salesCost.Description = c.Description;
                    salesCost.UnitID = c.UnitID;
                    salesCost.CurrencyID = c.CurrencyID;
                    salesCost.VatType = c.VatType;
                    salesCost.VatRatio = c.VatRatio;
                    salesCost.PurchaseFlag = c.PurchaseFlag;
                    salesCost.VendorCD = c.VendorCD;
                    salesCost.VendorName = c.VendorName;
                    salesCost.UnitPrice = c.UnitPrice;
                    salesCost.Quantity = c.Quantity;
                    salesCost.Total = c.Total;
                    salesCost.Vat = c.Vat;

                    aCostList.Add(salesCost);
                }
            }
        }

        /// <summary>
        /// Insert quote Condition
        /// </summary>
        private void InsertQuoteCondition(Quotation_CService service, int hid)
        {
            service.Delete(hid);
            var con = new T_Quote_C
            {
                HID = hid,
                Conditions = this.txtConditions.Value
            };
            service.Insert(con);
        }

        /// <summary>
        /// Insert Sales Condition
        /// </summary>
        /// <param name="headerId">Sales ID</param>
        private void InsertSalesCondition(Sales_CService salesCService, int headerId)
        {
            salesCService.Delete(headerId);

            T_Sales_C salesC = new T_Sales_C();
            salesC.HID = headerId;
            salesC.Conditions = this.txtConditions.Value;

            salesCService.Insert(salesC);
        }

        /// <summary>
        /// Get header
        /// </summary>
        private void GetHeader(T_Quote_H header)
        {
            if (this.txtQuotationDate.Value.HasValue)
            {
                header.QuoteDate = this.txtQuotationDate.Value.GetValueOrDefault();
            }
            else
            {
                header.QuoteDate = DEFAULT_DATE_TIME;
            }

            if (this.txtExpDate.Value.HasValue)
            {
                header.ExpiryDate = this.txtExpDate.Value.GetValueOrDefault();
            }
            else
            {
                header.ExpiryDate = DEFAULT_DATE_TIME;
            }

            if (this.txtExpectedOrderDate.Value.HasValue)
            {
                header.ExpectedOrderDate = this.txtExpectedOrderDate.Value.GetValueOrDefault();
            }
            else
            {
                header.ExpectedOrderDate = DEFAULT_DATE_TIME;
            }

            if (this.txtExpectedRevenueDate.Value.HasValue)
            {
                header.ExpectedRevenueDate = this.txtExpectedRevenueDate.Value.GetValueOrDefault();
            }
            else
            {
                header.ExpectedRevenueDate = DEFAULT_DATE_TIME;
            }

            header.PreparedCD = EditDataUtil.ToFixCodeDB(this.txtInchargeCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.PreparedName = this.txtInchargeName.Value;

            header.ApprovedCD = EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.ApprovedName = this.txtApprovedName.Value;

            header.SalesCD1 = EditDataUtil.ToFixCodeDB(this.txtFrontSalesCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.SalesName1 = this.txtFrontSalesName.Value;

            header.SalesCD2 = EditDataUtil.ToFixCodeDB(this.txtEngineerCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.SalesName2 = this.txtEngineerName.Value;

            var customerCd = this.txtCustomerCD.Value;
            customerCd = EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
            header.CustomerCD = customerCd;
            header.CustomerName = this.txtCustomerName.Value;

            header.SubjectName = this.txtSubject.Value;

            header.CustomerAddress1 = this.txtAdd1.Value;
            header.CustomerAddress2 = this.txtAdd2.Value;
            header.CustomerAddress3 = this.txtAdd3.Value;

            header.Tel = this.txtTel.Value;
            header.FAX = this.txtFax.Value;

            header.ContactPerson = this.txtAttn.Value;

            header.CurrencyID = int.Parse(this.cmbCurrency.SelectedItem.Value);
            header.MethodVat = short.Parse(this.cmbMethodVat.SelectedItem.Value);

            header.Memo = this.txtMemo.Value;

            header.Total = this.txtSumTotal.Value.GetValueOrDefault();
            header.Vat = this.txtSumVat.Value.GetValueOrDefault();
            header.VatRatio = this.txtVatRatio.Value.GetValueOrDefault();
            header.GrandTotal = this.txtGrandTotal.Value.GetValueOrDefault();
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
            {
                header.VatType = short.Parse(this.cmbVatType.SelectedValue);
            }
            else
            {
                header.VatType = 255;
            }
            header.NewFlag = 0;

            header.StatusFlag = short.Parse(this.cmbStatus.SelectedItem.Value);
            header.Approved = this.txtApproved.Value;
            header.Position = this.txtPosition.Value;
            header.CreateUID = base.LoginInfo.User.ID;
            header.UpdateUID = base.LoginInfo.User.ID;
        }

        /// <summary>
        /// Create Detail
        /// </summary>
        /// <param name="sellList">sellList</param>
        /// <param name="costList">costList</param>
        private void CreateDetail(ref IList<T_Quote_D_Sell> sellList, ref  IList<T_Quote_D_Cost> costList)
        {
            if (sellList == null)
            {
                sellList = new List<T_Quote_D_Sell>();
            }
            if (costList == null)
            {
                costList = new List<T_Quote_D_Cost>();
            }

            var methodVAT = this.cmbMethodVat.SelectedValue;

            //var sellNo = 1;

            #region Create Detail

            foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
            {
                HiddenField hidType = (HiddenField)repeaterItem.FindControl("hidType");
                HiddenField hidNo = (HiddenField)repeaterItem.FindControl("hidNo");
                var rowNo = int.Parse(hidNo.Value);

                //Check Type
                if (hidType.Value == QuotationDetailType.HeadLine.ToString())
                {
                    ITextBox txtHeadLine = (ITextBox)repeaterItem.FindControl("txtHeadLine");

                    var headLine = sellList.Where(s => s.No.Equals(rowNo)).SingleOrDefault();
                    if (headLine == null)
                    {
                        headLine = new T_Quote_D_Sell();
                        headLine.No = rowNo;
                        headLine.UnitID = Constant.DEFAULT_ID;
                        sellList.Add(headLine);
                    }
                    headLine.HeadlineFlag = 1;
                    headLine.Headline = txtHeadLine.Value;
                }
                else
                {
                    ICodeTextBox txtSellProductCD = (ICodeTextBox)repeaterItem.FindControl("txtSellProductCD");
                    ITextBox txtSellProductName = (ITextBox)repeaterItem.FindControl("txtSellProductName");
                    ITextBox txtSellDescription = (ITextBox)repeaterItem.FindControl("txtSellDescription");
                    INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtSellPrice");
                    INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtSellQuantity");
                    DropDownList cmbSellUnit = (DropDownList)repeaterItem.FindControl("cmbSellUnit");
                    INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtSellTotal");
                    INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtSellVat");
                    ITextBox txtSellRemark = (ITextBox)repeaterItem.FindControl("txtSellRemark");
                    DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbSellVatType");
                    INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtSellVatRatio");

                    var sell = sellList.Where(s => s.No.Equals(rowNo)).SingleOrDefault();
                    if (sell == null)
                    {
                        sell = new T_Quote_D_Sell();
                        sell.No = rowNo;
                        sellList.Add(sell);
                    }
                    sell.HeadlineFlag = 0;
                    sell.Headline = string.Empty;
                    sell.ProductCD = this.ProductCdUsed ? txtSellProductCD.Value : M_Product.PRODUCT_CODE_SUPPORT;
                    sell.ProductName = txtSellProductName.Value;
                    if (!this.ProductCdUsed && string.IsNullOrEmpty(sell.ProductName))
                    {
                        sell.ProductCD = string.Empty;
                    }
                    sell.Description = txtSellDescription.Value;
                    sell.Remark = txtSellRemark.Value;
                    sell.UnitID = int.Parse(cmbSellUnit.SelectedItem.Value);
                    sell.UnitPrice = txtSellPrice.Value.GetValueOrDefault();
                    sell.Quantity = txtSellQuantity.Value.GetValueOrDefault();
                    sell.Total = txtSellTotal.Value.GetValueOrDefault();

                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                    {
                        sell.VatType = short.Parse(cmbSellVatType.SelectedItem.Value);
                        sell.VatRatio = txtSellVatRatio.Value.GetValueOrDefault();
                        sell.Vat = txtSellVat.Value.GetValueOrDefault();
                    }
                    else
                    {
                        sell.VatType = 255;
                    }

                    #region Create Cost Item

                    Repeater rptCost = (Repeater)repeaterItem.FindControl("rptCost");
                    int costNo = 1;
                    foreach (RepeaterItem itemCost in rptCost.Items)
                    {
                        ICodeTextBox txtCostProductCD = (ICodeTextBox)itemCost.FindControl("txtCostProductCD");
                        ITextBox txtCostProductName = (ITextBox)itemCost.FindControl("txtCostProductName");
                        ITextBox txtCostDescription = (ITextBox)itemCost.FindControl("txtCostDescription");

                        INumberTextBox txtCostPrice = (INumberTextBox)itemCost.FindControl("txtCostPrice");
                        DropDownList cmbCostCurrency = (DropDownList)itemCost.FindControl("cmbCostCurrency");

                        INumberTextBox txtCostQuantity = (INumberTextBox)itemCost.FindControl("txtCostQuantity");
                        DropDownList cmbCostUnit = (DropDownList)itemCost.FindControl("cmbCostUnit");

                        INumberTextBox txtCostTotal = (INumberTextBox)itemCost.FindControl("txtCostTotal");
                        INumberTextBox txtCostVat = (INumberTextBox)itemCost.FindControl("txtCostVat");

                        HtmlInputCheckBox chkPurchaseFlag = (HtmlInputCheckBox)itemCost.FindControl("chkPurchaseFlag");
                        ICodeTextBox txtCostVendorCD = (ICodeTextBox)itemCost.FindControl("txtCostVendorCD");
                        ITextBox txtCostVendorName = (ITextBox)itemCost.FindControl("txtCostVendorName");
                        DropDownList cmbCostVatType = (DropDownList)itemCost.FindControl("cmbCostVatType");
                        INumberTextBox txtCostVatRatio = (INumberTextBox)itemCost.FindControl("txtCostVatRatio");

                        var cost = costList.Where(c => c.SellNo.Equals(sell.No)
                                                  && c.No.Equals(costNo)).SingleOrDefault();

                        if (cost == null)
                        {
                            cost = new T_Quote_D_Cost();
                            cost.No = costNo;
                            costList.Add(cost);
                        }
                        cost.SellNo = rowNo;
                        cost.ProductCD = this.ProductCdUsed ? txtCostProductCD.Value : M_Product.PRODUCT_CODE_SUPPORT;
                        cost.ProductName = txtCostProductName.Value;
                        if (!this.ProductCdUsed && string.IsNullOrEmpty(cost.ProductName))
                        {
                            cost.ProductCD = string.Empty;
                        }
                        cost.Description = txtCostDescription.Value;
                        cost.UnitID = int.Parse(cmbCostUnit.SelectedItem.Value);
                        cost.CurrencyID = int.Parse(cmbCostCurrency.SelectedItem.Value);

                        cost.VatType = short.Parse(cmbCostVatType.SelectedItem.Value);
                        cost.VatRatio = txtCostVatRatio.Value.GetValueOrDefault();
                        cost.Vat = txtCostVat.Value.GetValueOrDefault();

                        cost.PurchaseFlag = (short)(txtCostVendorCD.IsEmpty ? 0 : 1);
                        cost.VendorCD = txtCostVendorCD.Value;
                        cost.VendorName = txtCostVendorName.Value;
                        cost.UnitPrice = txtCostPrice.Value.GetValueOrDefault();
                        cost.Quantity = txtCostQuantity.Value.GetValueOrDefault();
                        cost.Total = txtCostTotal.Value.GetValueOrDefault();

                        costNo++;
                    }

                    #endregion Create Cost Item
                }
            }

            #endregion Create Detail

            #region Remove Empty Row

            var sellNo = 1;
            IList<T_Quote_D_Sell> sellListEmpty = new List<T_Quote_D_Sell>();
            IList<T_Quote_D_Cost> costListEmpty = new List<T_Quote_D_Cost>();

            var hasInput = sellList.Any(s => !s.IsEmpty()) || costList.Any(c => !c.IsEmpty());

            foreach (var sell in sellList)
            {
                if (sell.HeadlineFlag == 1)
                {
                    sell.No = sellNo;
                    sellNo++;
                    continue;
                }
                // COST::Not Empty
                var costItems = costList.Where(s => s.SellNo == sell.No && !s.IsEmpty());
                var sz = costItems.Count();

                //Neu toan bo COST dang empty va SELL cung empty
                if (sz == 0 && sell.IsEmpty())
                {
                    sellListEmpty.Add(sell);

                    //Remmove Item Emtpty
                    var flgF = true;
                    foreach (var empt in costList.Where(s => s.SellNo == sell.No))
                    {
                        //Neu nhu Detail ko dc nhap
                        if (!hasInput)
                        {
                            //thi chi xoa nhung COST::No > 1
                            if (!flgF)
                                costListEmpty.Add(empt);
                            flgF = false;
                        }
                        else
                        {
                            //Xoa toan bo COST cua SELL::empty
                            costListEmpty.Add(empt);
                        }
                    }
                }
                else
                {
                    //Neu COST empty
                    if (sz == 0)
                    {
                        //Reset No for fist empty item
                        foreach (var first in costList.Where(s => s.SellNo == sell.No && s.No == 1))
                        {
                            first.SellNo = sellNo;
                        }
                        //Remove cost Emtpty and ignore No = 1
                        var flgF = true;
                        foreach (var empt in costList.Where(s => s.SellNo == sell.No))
                        {
                            if (!flgF)
                                costListEmpty.Add(empt);
                            flgF = false;
                        }
                    }
                    else // Neu SELL empty
                    {
                        //Reset No
                        var costNo = 1;
                        foreach (var cost in costItems)
                        {
                            cost.No = costNo;
                            cost.SellNo = sellNo;
                            costNo++;
                        }

                        foreach (var empt in costList.Where(s => s.SellNo == sell.No && s.IsEmpty()))
                        {
                            costListEmpty.Add(empt);
                        }
                    }

                    sell.No = sellNo;
                    sellNo++;
                }
            }

            for (int i = sellListEmpty.Count - 1; i >= 0; i--)
            {
                var emptySellItem = sellListEmpty[i];
                if (sellList.Count > 1)
                {
                    sellList.Remove(emptySellItem);
                }
                else
                {
                    break;
                }
            }
            var groups = costListEmpty.GroupBy(c => c.SellNo);
            foreach (var grp in groups)
            {
                var sell = sellList.Where(s => s.No == grp.Key).SingleOrDefault();
                if (sell == null)
                {
                    foreach (var emptyCostItem in grp)
                    {
                        costList.Remove(emptyCostItem);
                    }
                }
                else
                {
                    var allEmpty = costList.Where(c => c.SellNo == sell.No && !c.IsEmpty()).Count() == 0;

                    foreach (var emptyCostItem in grp)
                    {
                        if (!allEmpty && emptyCostItem.IsEmpty())
                        {
                            costList.Remove(emptyCostItem);
                        }
                        else if (emptyCostItem.No > 1)
                        {
                            costList.Remove(emptyCostItem);
                        }
                        else
                        {
                            //thuoc ve sell bi remove
                            var sellEmpty = sellListEmpty.Where(s => s.No == emptyCostItem.SellNo).SingleOrDefault();
                            if (sellEmpty != null)
                            {
                                costList.Remove(emptyCostItem);
                            }
                        }
                    }
                }
            }

            #endregion Remove Empty Row
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(M_Currency_H crcyItem, INumberTextBox txtNumberInput, decimal maxDecimal, decimal maxNotDecimal)
        {
            if (crcyItem != null)
            {
                if (crcyItem.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtNumberInput.DecimalDigit = 2;
                    txtNumberInput.MaximumValue = maxDecimal;
                }
                else
                {
                    txtNumberInput.DecimalDigit = 0;
                    txtNumberInput.MaximumValue = maxNotDecimal;
                }
            }
        }

        /// <summary>
        /// Set enable control by vat type
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="vatControl">Vat Control</param>
        /// <param name="vatRatioControl">Vat Ratio Control</param>
        private void SetVATControl(DropDownList cmbVatType, INumberTextBox txtVat, INumberTextBox txtVatRatio)
        {
            if (int.Parse(cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                txtVat.SetReadOnly(false);
                txtVatRatio.SetReadOnly(false);

                txtVat.Value = null;
                txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
            }
            else
            {
                txtVat.SetReadOnly(true);
                txtVatRatio.SetReadOnly(true);

                txtVat.Value = null;
                txtVatRatio.Value = null;
            }
        }

        /// <summary>
        /// Check currency is decimal
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <returns></returns>
        private bool IsDecimal(int currencyId)
        {
            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == currencyId).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Update Unit price of Sell
        /// </summary>
        private void UpdateMarkupQtySell(int sellNo, DateTime quoteDate)
        {
            decimal avrPriceCost = 0;
            decimal sumQty = 0;

            using (var db = new DB())
            {
                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(quoteDate).ToDictionary(s => s.ID, s => s);

                var sellList = this.GetDetailData();

                var sell = sellList.Where(s => s.No == sellNo).SingleOrDefault();

                var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);
                //Default IS VND
                if (mainCurrencyId == Constant.DEFAULT_ID)
                {
                    foreach (var cost in sell.CostList)
                    {
                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                            (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                        {
                            continue;
                        }

                        var unitPrice = 0m;
                        var quantity = cost.Quantity.GetValueOrDefault();
                        if (!cost.Quantity.HasValue)
                        {
                            quantity = 1;
                        }

                        //VND
                        if (cost.CurrencyID == Constant.DEFAULT_ID)
                        {
                            unitPrice = cost.Price.GetValueOrDefault();
                        }
                        else
                        {
                            var exchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                            unitPrice = CommonUtil.ConvertToVND(exchangeRate, cost.Price.GetValueOrDefault());
                        }

                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                        {
                            avrPriceCost += unitPrice * quantity;
                        }
                        else
                        {
                            avrPriceCost += unitPrice;
                        }

                        sumQty += quantity;
                    }
                }
                else
                {
                    var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                    foreach (var cost in sell.CostList)
                    {
                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                            (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                        {
                            continue;
                        }
                        var unitPrice = 0m;
                        var quantity = cost.Quantity.GetValueOrDefault();
                        if (!cost.Quantity.HasValue)
                        {
                            quantity = 1;
                        }

                        //VND
                        if (cost.CurrencyID == Constant.DEFAULT_ID)
                        {
                            //VND => Other Currency
                            unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, cost.Price.GetValueOrDefault());
                        }
                        else if (cost.CurrencyID == mainCurrencyId)
                        {
                            //Other Currency = Other Currency
                            unitPrice = cost.Price.GetValueOrDefault();
                        }
                        else
                        {
                            //Other Currency => Other Currency
                            var costExchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                            var costPriceVND = CommonUtil.ConvertToVND(costExchangeRate, cost.Price.GetValueOrDefault());

                            unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, costPriceVND);
                        }

                        if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                        {
                            avrPriceCost += unitPrice * quantity;
                        }
                        else
                        {
                            avrPriceCost += unitPrice;
                        }

                        sumQty += quantity;
                    }
                }

                if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                    sumQty != 0)
                {
                    avrPriceCost = avrPriceCost / sumQty;
                }
                var priceByMarkup = EditDataUtil.CalcUnitPriceByMarkup(avrPriceCost, sell.Sell.Profit.GetValueOrDefault());
                if (this.IsDecimal(int.Parse(this.cmbCurrency.SelectedValue)))
                {
                    priceByMarkup = Fraction.Round(this._defaultFractionType, priceByMarkup, 2);
                }
                else
                {
                    priceByMarkup = Fraction.Round(this._defaultFractionType, priceByMarkup, 0);
                }
                sell.Sell.Price = priceByMarkup;

                if (priceByMarkup != 0m)
                {
                    var markUp = EditDataUtil.CalProfit(priceByMarkup, avrPriceCost);
                    if (markUp > Constant.MAX_PROFIT || markUp < 0)
                    {
                        sell.Sell.Profit = null;
                    }
                    else
                    {
                        sell.Sell.Profit = markUp;
                    }
                }

                this.rptDetail.DataSource = sellList;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Display markup number
        /// </summary>
        private void SetSellMarkup(DateTime quoteDate)
        {
            using (var db = new DB())
            {
                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(quoteDate).ToDictionary(s => s.ID, s => s);

                var sellList = this.GetDetailData();

                #region MarkUp

                foreach (var sell in sellList)
                {
                    if (sell.Type != QuotationDetailType.Sell)
                    {
                        continue;
                    }

                    if (!sell.Sell.Price.HasValue || sell.Sell.Price == 0)
                    {
                        sell.Sell.Profit = 0;
                        continue;
                    }

                    decimal avrPriceCost = 0;
                    decimal sumQty = 0;

                    var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);
                    //Default IS VND
                    if (mainCurrencyId == Constant.DEFAULT_ID)
                    {
                        foreach (var cost in sell.CostList)
                        {
                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                                (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                            {
                                continue;
                            }
                            var unitPrice = 0m;
                            var quantity = cost.Quantity.GetValueOrDefault();
                            if (!cost.Quantity.HasValue)
                            {
                                quantity = 1;
                            }

                            //VND
                            if (cost.CurrencyID == Constant.DEFAULT_ID)
                            {
                                unitPrice = cost.Price.GetValueOrDefault();
                            }
                            else
                            {
                                var exchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                                unitPrice = CommonUtil.ConvertToVND(exchangeRate, cost.Price.GetValueOrDefault());
                            }

                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                            {
                                avrPriceCost += unitPrice * quantity;
                            }
                            else
                            {
                                avrPriceCost += unitPrice;
                            }

                            sumQty += cost.Quantity.GetValueOrDefault();
                        }
                    }
                    else
                    {
                        var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                        foreach (var cost in sell.CostList)
                        {
                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                                (!cost.Price.HasValue || cost.Price == 0 || cost.Quantity == 0))
                            {
                                continue;
                            }
                            var unitPrice = 0m;
                            var quantity = cost.Quantity.GetValueOrDefault();
                            if (!cost.Quantity.HasValue)
                            {
                                quantity = 1;
                            }

                            //VND
                            if (cost.CurrencyID == Constant.DEFAULT_ID)
                            {
                                //VND => Other Currency
                                unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, cost.Price.GetValueOrDefault());
                            }
                            else if (cost.CurrencyID == mainCurrencyId)
                            {
                                //Other Currency = Other Currency
                                unitPrice = cost.Price.GetValueOrDefault();
                            }
                            else
                            {
                                //Other Currency => Other Currency
                                var costExchangeRate = crcyList[cost.CurrencyID].ExchangeRate;
                                var costPriceVND = CommonUtil.ConvertToVND(costExchangeRate, cost.Price.GetValueOrDefault());

                                unitPrice = CommonUtil.ConvertToNotVND(exchangeRate, costPriceVND);
                            }

                            if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0)
                            {
                                avrPriceCost += unitPrice * quantity;
                            }
                            else
                            {
                                avrPriceCost += unitPrice;
                            }
                            sumQty += cost.Quantity.GetValueOrDefault();
                        }
                    }

                    if (this._profitSetting == M_Config_D.CONFIG_CD_PROFIT_SETTING_0 &&
                        sumQty != 0)
                    {
                        avrPriceCost = avrPriceCost / sumQty;
                    }

                    var markUp = EditDataUtil.CalProfit(sell.Sell.Price.GetValueOrDefault(), avrPriceCost);
                    markUp = markUp > Constant.MAX_PROFIT ? Constant.MAX_PROFIT : markUp <= 0m ? 0m : markUp;
                    sell.Sell.Profit = markUp;
                }

                #endregion MarkUp

                this.rptDetail.DataSource = sellList;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails(IList<QuotationDetailInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailData();
            }
            this.rptDetail.DataSource = dataSource;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Get index quote header
        /// </summary>
        private PreNextStatus GetPreNextQuotation()
        {
            using (var db = new DB())
            {
                var hService = new Quotation_HService(db);
                //Check the  Next quotation is exist
                bool isExistNextQuo;
                T_Quote_H quoH;
                string nextQuoNo = this.GetNextReviseNo();

                if (string.IsNullOrEmpty(nextQuoNo))
                {
                    isExistNextQuo = false;
                }
                else
                {
                    quoH = hService.GetByQuoteNo(nextQuoNo);
                    isExistNextQuo = quoH != null;
                }

                //Check the  Pre quotation is exist
                bool isExistPreQuo;
                string preQuoNo = this.GetPreReviseNo();

                if (string.IsNullOrEmpty(preQuoNo))
                {
                    isExistPreQuo = false;
                }
                else
                {
                    quoH = hService.GetByQuoteNo(preQuoNo);
                    isExistPreQuo = quoH != null;
                }

                //Return result

                if (isExistPreQuo && isExistNextQuo)
                {
                    return PreNextStatus.HavePreHaveNext;
                }
                else if (isExistNextQuo)
                {
                    return PreNextStatus.NoPreHaveNext;
                }
                else if (isExistPreQuo)
                {
                    return PreNextStatus.HavePreNoNext;
                }
                else
                {
                    return PreNextStatus.NoPreNoNext;
                }
            }
        }

        /// <summary>
        /// Create Rivse quote No.
        /// </summary>
        private string GetNextReviseNo()
        {
            string ret;
            var quoteNo = this.txtQuotationNo.Value;
            if (quoteNo.Substring(quoteNo.Length - 3, 1).ToLower() == "r")
            {
                int tail = int.Parse(quoteNo.Substring(quoteNo.Length - 2, 2)) + 1;

                if (tail == 100)
                {
                    return string.Empty;
                }
                ret = quoteNo.Substring(0, quoteNo.Length - 2) + tail.ToString("00");
            }
            else
            {
                ret = quoteNo + "-R01";
            }
            return ret;
        }

        /// <summary>
        /// Get Pre quote No.
        /// </summary>
        private string GetPreReviseNo()
        {
            string ret;
            var quoteNo = this.txtQuotationNo.Value;
            if (quoteNo.Substring(quoteNo.Length - 3, 1).ToLower() == "r")
            {
                int tail = int.Parse(quoteNo.Substring(quoteNo.Length - 2, 2)) - 1;

                if (tail == 0)
                {
                    ret = quoteNo.Substring(0, quoteNo.Length - 4);
                }
                else
                {
                    ret = quoteNo.Substring(0, quoteNo.Length - 2) + tail.ToString("00");
                }
            }
            else
            {
                ret = string.Empty;
            }
            return ret;
        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtIssueDate.Value = string.Empty;
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        private void AddEmptyRow(int size, ref IList<QuotationDetailInfo> dataSource)
        {
            if (dataSource == null)
            {
                dataSource = new List<QuotationDetailInfo>();
            }
            var methodVAT = this.cmbMethodVat.SelectedValue;

            for (int i = 0; i < size; i++)
            {
                QuotationDetailInfo sell = new QuotationDetailInfo();
                sell.No = i + 1;
                sell.Type = QuotationDetailType.Sell;
                sell.Sell = new SellInfo();
                sell.Sell.Collapsed = this.DefaultCostView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                sell.Sell.Profit = this._defaultProfit;
                sell.Sell.SellNoDisp = i + 1;

                var defaultVatType = -1;
                if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                {
                    defaultVatType = int.Parse(this._defaultVatType);
                }

                if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                {
                    sell.Sell.VatRatio = decimal.Parse(this.DefaultVAT);
                }
                sell.Sell.VatType = defaultVatType;

                sell.CostList = new List<CostInfo>();

                CostInfo costInfo = new CostInfo();
                costInfo.No = 1;
                costInfo.SellNo = sell.Sell.SellNoDisp;

                defaultVatType = int.Parse(this._defaultVatType);
                if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                {
                    costInfo.VatRatio = decimal.Parse(this.DefaultVAT);
                }
                costInfo.VatType = defaultVatType;

                sell.CostList.Add(costInfo);
                dataSource.Add(sell);
            }
        }

        #endregion Method
    }
}
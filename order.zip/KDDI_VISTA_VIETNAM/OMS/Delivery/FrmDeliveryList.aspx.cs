﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using NPOI.SS.UserModel;
using OMS.Reports.EXCEL;

namespace OMS.Delivery
{
    /// <summary>
    /// Form Delivery List
    /// </summary>
    public partial class FrmDeliveryList : FrmBaseList
    {
        #region Constant
        private const string EXCEL_DELIVERY_DOWNLOAD = "Delivery_{0}.xls";
        private const string EXCEL_DELIVERY_CREATE_DOWNLOAD = "Create Delivery List_{0}.xls";
        private const string EXCEL_DELIVERY_UNCREATE_DOWNLOAD = "Uncreate Delivery List_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Property

        /// <summary>
        /// Get or set DeliveryExcelFlag
        /// </summary>
        public string DeliveryExcelFlag
        {
            get { return (string)ViewState["DeliveryExcelFlag"]; }
            set { ViewState["DeliveryExcelFlag"] = value; }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return this.GetValueViewState<int>("QuantityDecimal"); }
            private set
            {
                this.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Delivery";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = "Deleted";
            this.PagingHeader.WarningText = "Expired";

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtDeliveryNo.MaxLength = T_Delivery_H.DELIVERY_NO_MAX_LENGTH;
            this.txtQuoteNo.MaxLength = T_Quote_H.QUOTE_NO_MAX_LENGTH;
            this.txtSalesNo.MaxLength = T_Sales_H.SALES_NO_MAX_LENGTH;
            this.txtDeliveryPlace.MaxLength = T_Delivery_H.DELIVERY_PLACE_MAX_LENGTH;
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtSubject.MaxLength = T_Delivery_H.SUBJECT_NAME_MAX_LENGTH;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
        }

        /// <summary>
        /// Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            this.SetAuthority(FormId.Delivery);
            //Check Authority
            if (!base._authority.IsDeliveryView)
            {
                Response.Redirect(FrmBase.URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_MAIN_MENU;
            }

            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                this.QuantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    base.DisabledLink(this.btnNew, !base._authority.IsDeliveryNew);
                    base.DisabledLink(this.btnExcel, !base._authority.IsDeliveryExcel);

                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();

                     //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        this.ShowCondition(para);
                    }
                }
               
                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }

            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";
            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnSearch Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var filename = string.Empty;
                if (this.DeliveryExcelFlag.Equals("CreateDeliveryList"))
                {
                    filename = string.Format(EXCEL_DELIVERY_CREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else if (this.DeliveryExcelFlag.Equals("Excel"))
                {
                    filename = string.Format(EXCEL_DELIVERY_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else
                {
                    filename = string.Format(EXCEL_DELIVERY_UNCREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(null);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            base.BackPage(); 
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(e.CommandArgument);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Format quantity for display
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatQty(object qty)
        {
            if (qty != null)
            {
                return decimal.Parse(qty.ToString()).ToString(string.Format("N{0}", this.QuantityDecimal));
            }
            return string.Empty;
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Reset Name
        /// </summary>
        private void ResetName()
        {
            //CustomerName
            this.txtCustomerName.Value = null;
            M_Customer cus = this.GetCustomerModel(this.txtCustomerCD.Value);
            if (cus != null)
            {
                this.txtCustomerName.Value = cus.CustomerName1;
            }
            //PreparedName
            this.txtPreparedName.Value = null;
            M_User u = this.GetUserModel(this.txtPreparedCD.Value);
            if (u != null && u.ID != Constant.DEFAULT_ID
                          && u.StatusFlag == 0)
            {
                this.txtPreparedName.Value = u.UserName2;
            }
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition(object id)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();

            currentPage.Add(this.cmbInvalidData.ID, this.cmbInvalidData.SelectedValue);
            currentPage.Add(this.cmbFinishedData.ID, this.cmbFinishedData.SelectedValue);

            currentPage.Add(this.txtSalesNo.ID, this.txtSalesNo.Value);
            currentPage.Add(this.txtDeliveryNo.ID, this.txtDeliveryNo.Value);
            currentPage.Add(this.txtQuoteNo.ID, this.txtQuoteNo.Value);
            currentPage.Add(this.dtDeliveryDateFrom.ID, this.dtDeliveryDateFrom.Value);
            currentPage.Add(this.dtDeliveryDateTo.ID, this.dtDeliveryDateTo.Value);
            currentPage.Add(this.txtCustomerCD.ID, this.txtCustomerCD.Value);
            currentPage.Add(this.txtSubject.ID, this.txtSubject.Value);
            currentPage.Add(this.txtDeliveryPlace.ID, this.txtDeliveryPlace.Value);
            currentPage.Add(this.txtPreparedCD.ID, this.txtPreparedCD.Value);
            currentPage.Add(this.txtDeliveredName.ID, this.txtDeliveredName.Value);
            currentPage.Add(this.txtSerialNo.ID, this.txtSerialNo.Value);

            currentPage.Add("SalesNoReadOnly", this.txtSalesNo.ReadOnly);
            currentPage.Add("QuoteNoReadOnly", this.txtQuoteNo.ReadOnly);

            currentPage.Add("FinishedFlag", this.cmbFinishedData.SelectedValue);
            currentPage.Add("DeletedFlag", this.cmbInvalidData.SelectedValue);
            
            currentPage.Add("hdSalesNoDefaut", this.hdSalesNoDefaut.Value);
            currentPage.Add("hdQuotationNoDefaut", this.hdQuotationNoDefaut.Value);
            currentPage.Add("hdFinishedDataDefaultRef", this.hdFinishedDataDefaultRef.Value);
            currentPage.Add("hdDeletedDataDefaultRef", this.hdDeletedDataDefaultRef.Value);
            currentPage.Add("hdInValidDefault", this.hdInValidDefault.Value);
            currentPage.Add("hdFinishDefault", this.hdFinishDefault.Value);

            currentPage.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            currentPage.Add("CurrentPage", this.PagingHeader.CurrentPage);

            currentPage.Add("SortField", this.HeaderGrid.SortField);
            currentPage.Add("SortDirec", this.HeaderGrid.SortDirec);

            nextPage.Add("ID", id);

            //Next Page
            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_DELIVERY_LIST);
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            if (data.ContainsKey(this.cmbFinishedData.ID))
            {
                this.cmbFinishedData.SelectedValue = data[this.cmbFinishedData.ID].ToString();
            }

            if (data.ContainsKey(this.cmbInvalidData.ID))
            {
                this.cmbInvalidData.SelectedValue = data[this.cmbInvalidData.ID].ToString();
            }

            if (data.ContainsKey(this.txtDeliveryNo.ID))
            {
                this.txtDeliveryNo.Value = data[this.txtDeliveryNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtDeliveredName.ID))
            {
                this.txtDeliveredName.Value = data[this.txtDeliveredName.ID].ToString();
            }

            if (data.ContainsKey(this.txtSerialNo.ID))
            {
                this.txtSerialNo.Value = data[this.txtSerialNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtSalesNo.ID))
            {
                this.txtSalesNo.Value = data[this.txtSalesNo.ID].ToString();
                this.hdSalesNoDefaut.Value = data[this.txtSalesNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtQuoteNo.ID))
            {
                this.txtQuoteNo.Value = data[this.txtQuoteNo.ID].ToString();
                this.hdQuotationNoDefaut.Value = data[this.txtQuoteNo.ID].ToString();
            }

            this.dtDeliveryDateTo.Value = null;
            if (data.ContainsKey(this.dtDeliveryDateTo.ID))
            {
                if (data[this.dtDeliveryDateTo.ID] != null)
                {
                    this.dtDeliveryDateTo.Value = (DateTime)data[this.dtDeliveryDateTo.ID];
                }
            }

            this.dtDeliveryDateFrom.Value = null;
            if (data.ContainsKey(this.dtDeliveryDateFrom.ID))
            {
                if (data[this.dtDeliveryDateFrom.ID] != null)
                {
                    this.dtDeliveryDateFrom.Value = (DateTime)data[this.dtDeliveryDateFrom.ID];
                }
            }

            if (data.ContainsKey(this.txtCustomerCD.ID))
            {
                this.txtCustomerCD.Value = data[this.txtCustomerCD.ID].ToString();
            }
            if (data.ContainsKey(this.txtSubject.ID))
            {
                this.txtSubject.Value = data[this.txtSubject.ID].ToString();
            }

            if (data.ContainsKey(this.txtDeliveryPlace.ID))
            {
                this.txtDeliveryPlace.Value = data[this.txtDeliveryPlace.ID].ToString();
            }

            if (data.ContainsKey(this.txtPreparedCD.ID))
            {
                this.txtPreparedCD.Value = data[this.txtPreparedCD.ID].ToString();
            }

            if (data.ContainsKey("SalesNoReadOnly"))
            {
                this.txtSalesNo.ReadOnly = (bool)data["SalesNoReadOnly"];
            }

            if (data.ContainsKey("QuoteNoReadOnly"))
            {
                this.txtQuoteNo.ReadOnly = (bool)data["QuoteNoReadOnly"];
            }
            
            if (data.ContainsKey("FinishedFlag"))
            {
                this.cmbFinishedData.SelectedValue = data["FinishedFlag"].ToString();
                this.hdFinishedDataDefaultRef.Value = data["FinishedFlag"].ToString();
            }

            if (data.ContainsKey("DeletedFlag"))
            {
                this.cmbInvalidData.SelectedValue = data["DeletedFlag"].ToString();
                this.hdDeletedDataDefaultRef.Value = data["DeletedFlag"].ToString();
            }

            if (data.ContainsKey("hdSalesNoDefaut"))
            {
                this.hdSalesNoDefaut.Value = data["hdSalesNoDefaut"].ToString();
            }
            if (data.ContainsKey("hdQuotationNoDefaut"))
            {
                this.hdQuotationNoDefaut.Value = data["hdQuotationNoDefaut"].ToString();
            }
            if (data.ContainsKey("hdFinishedDataDefaultRef"))
            {
                this.hdFinishedDataDefaultRef.Value = data["hdFinishedDataDefaultRef"].ToString();
            }
            if (data.ContainsKey("hdDeletedDataDefaultRef"))
            {
                this.hdDeletedDataDefaultRef.Value = data["hdDeletedDataDefaultRef"].ToString();
            }
            if (data.ContainsKey("hdInValidDefault"))
            {
                this.hdInValidDefault.Value = data["hdInValidDefault"].ToString();
            }
            if (data.ContainsKey("hdFinishDefault"))
            {
                this.hdFinishDefault.Value = data["hdFinishDefault"].ToString();
            }

            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = int.Parse(data["CurrentPage"].ToString());
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }

            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }

            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }
            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }

        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Quote Date
            this.dtDeliveryDateFrom.Value = DateTime.Now.AddMonths(-3);
            //this.dtDeliveryDateTo.Value = DateTime.Now;
            this.dtDeliveryDateTo.Value = null;

            // Default data valide
            this.hdInValidDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdDeliDateFrmDefault.Value = this.dtDeliveryDateFrom.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            //this.hdDeliDateToDefault.Value = this.dtDeliveryDateTo.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            this.hdFinishDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Invalid
            this.InitCombobox(this.cmbInvalidData, this.hdInValidDefault.Value);

            //Finish
            this.InitCombobox(this.cmbFinishedData, this.hdFinishDefault.Value);
            
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();

            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
                
            }   
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Get model input for search action
        /// </summary>
        /// <returns></returns>
        private DeliveryHeaderSearch GetSearchModel()
        {
            DeliveryHeaderSearch ret = new DeliveryHeaderSearch();

            ret.DeliveryNo = this.txtDeliveryNo.Value;
            ret.SalesNo = this.txtSalesNo.Value;
            ret.QuoteNo = this.txtQuoteNo.Value;
            ret.DeliveryDateFrom = this.dtDeliveryDateFrom.Value;
            ret.DeliveryDateTo = this.dtDeliveryDateTo.Value;
            ret.CustomerCD = this.txtCustomerCD.Value;
            ret.PreparedCD = this.txtPreparedCD.Value;
            ret.Subject = this.txtSubject.Value;
            ret.DeliveryPlace = this.txtDeliveryPlace.Value;
            ret.DelivererName = this.txtDeliveredName.Value;
            ret.FinishFlag = short.Parse(this.cmbFinishedData.SelectedValue);
            ret.FinishName = this.cmbFinishedData.SelectedItem.Text;
            ret.InvalidFlag = short.Parse(this.cmbInvalidData.SelectedValue);
            ret.InvalidName = this.cmbInvalidData.SelectedItem.Text;
            ret.SerialNo = this.txtSerialNo.Value;

            return ret;
        }

        /// <summary>
        /// Load data for grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }
            this.ResetName();

            int totalRow = 0;

            IList<DeliveryHeaderResult> listResult;
            DeliveryHeaderSearch modelInput = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Delivery_HService shipHService = new Delivery_HService(db);
                totalRow = shipHService.GetTotalRow(modelInput);
                listResult = shipHService.GetListByCond(modelInput, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listResult.Count == 0)
            {
                this.rptDeliveryList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Deli No.", "Sales No.", "Deli Date", "Customer", "Subject", "N#Q'ty Total", "" });

                // detail
                this.rptDeliveryList.DataSource = listResult;
            }

            this.rptDeliveryList.DataBind();
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Delivery Date            
            if (this.dtDeliveryDateFrom.Value != null && this.dtDeliveryDateTo.Value != null)
            {
                if (this.dtDeliveryDateFrom.Value.Value.Date > this.dtDeliveryDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtDeliveryDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Delivery Date From", "Delivery Date To");
                }
            }

            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptDeliveryList.DataSource = null;
                this.rptDeliveryList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get Customer by code
        /// </summary>
        /// <param name="customerID">customerID</param>
        /// <returns>Customer</returns>
        private M_Customer GetCustomerModel(string customerCD)
        {
            using (DB db = new DB())
            {
                CustomerService customerSer = new CustomerService(db);

                //Get Customer
                return customerSer.GetByCustomerCD(customerCD);
            }
        }

        /// <summary>
        /// Get User By User Code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD, false);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        
        #endregion

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            this.DeliveryExcelFlag = "Excel";
            DeliveryListExcel excel = new DeliveryListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);

            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeliveryList_Click(object sender, CommandEventArgs e)
        {
            this.DeliveryExcelFlag = "CreateDeliveryList";
            CreateDeliveryListExcel excel = new CreateDeliveryListExcel();
            excel.deliveryDateFrom = this.dtDeliveryDateFrom.Value;
            excel.deliveryDateTo = this.dtDeliveryDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnUncreatePOList Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUncreateDeliveryList_Click(object sender, CommandEventArgs e)
        {
            this.DeliveryExcelFlag = "UncreateDeliveryList";
            UncreateDeliveryListExcel excel = new UncreateDeliveryListExcel();
            excel.deliveryDateFrom = this.dtDeliveryDateFrom.Value;
            excel.deliveryDateTo = this.dtDeliveryDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        #endregion

    }
}
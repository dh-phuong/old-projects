﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Microsoft.Reporting.WebForms;
using NPOI.SS.UserModel;
using OMS.Controls;
using OMS.DAC;
using OMS.Models;
using OMS.Reports.EXCEL;
using OMS.Reports.PDF;
using OMS.Utilities;

namespace OMS.Delivery
{
    /// <summary>
    /// Form Delivery
    /// ISV-TRUC
    /// </summary>
    public partial class FrmDeliveryDetail : FrmBaseDetail
    {
        #region Constant

        private const string PDF_DELIVERY_DOWNLOAD = "Delivery_{0}.pdf";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);

        private const string ZERO_STRING = "0";
        private const decimal INT_4D = 9999m;
        private const int INT_0 = 0;

        #endregion Constant

        #region Property

        /// <summary>
        /// Get or set DeliveryID
        /// </summary>
        public int DataID
        {
            get { return base.GetValueViewState<int>("DataID"); }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldUpdateDate"); }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get Or Set Deleted
        /// </summary>
        public bool Deleted
        {
            get
            {
                return base.GetValueViewState<bool>("Deleted");
            }
            private set { ViewState["Deleted"] = value; }
        }

        /// <summary>
        /// Get Or Set Finished
        /// </summary>
        public bool Finished
        {
            get
            {
                return base.GetValueViewState<bool>("Finished");
            }
            private set { ViewState["Finished"] = value; }
        }

        /// <summary>
        /// Get Or Set Count file attached
        /// </summary>
        public int FileAttachedCount
        {
            get { return base.GetValueViewState<int>("FileAttachedCount"); }
            private set { ViewState["FileAttachedCount"] = value; }
        }

        /// <summary>
        /// Get Or Set Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Get Or Set Default VAT value
        /// </summary>
        public string DefaultVAT
        {
            get
            {
                return base.GetValueViewState<string>("DefaultVAT");
            }
            private set { ViewState["DefaultVAT"] = value; }
        }

        /// <summary>
        /// Get Or Set Default VAT value
        /// </summary>
        public string DefaultVatType
        {
            get
            {
                return this._defaultVatType;
            }
        }

        /// <summary>
        /// Decimal digit of quantity
        /// </summary>
        private int QtyDecDigit
        {
            get
            {
                return base.GetValueViewState<int>("QtyDecDigit");
            }
            set { ViewState["QtyDecDigit"] = value; }
        }

        /// <summary>
        /// Save Old Condition
        /// </summary>
        private string OldCondition
        {
            get
            {
                return base.GetValueViewState<string>("oldCondition");
            }
            set { ViewState["oldCondition"] = value; }
        }

        /// <summary>
        /// Get Or Set Use for AJAX
        /// </summary>
        public string MethodVATEach
        {
            get
            {
                return M_Config_D.METHOD_VAT_EACH;
            }
        }

        /// <summary>
        /// 使用する商品コード
        /// </summary>
        public bool ProductCdUsed
        {
            get;
            private set;
        }

        /// <summary>
        /// Get Or Set Type Of Issue
        /// </summary>
        public string TypeOfIssue
        {
            get { return base.GetValueViewState<string>("TypeOfIssue"); }
            private set { ViewState["TypeOfIssue"] = value; }
        }

        /// <summary>
        /// Get Or Set Action Methods
        /// </summary>
        private ActionMode _actionMode
        {
            get
            {
                return base.GetValueViewState<ActionMode>("ActionMode");
            }
            set { ViewState["ActionMode"] = value; }
        }

        /// <summary>
        /// Get Or Set Default Serial View
        /// </summary>
        public string DefaultSerialView
        {
            get
            {
                return base.GetValueViewState<string>("DefaultSerialView");
            }
            private set { ViewState["DefaultSerialView"] = value; }
        }

        /// <summary>
        /// Get Or Set Default Serial Hidden
        /// </summary>
        public int DefaultSerialHidden
        {
            get
            {
                return base.GetValueViewState<int>("DefaultSerialHidden");
            }
            private set { ViewState["DefaultSerialHidden"] = value; }
        }

        /// <summary>
        /// Get or set Old Version Update Date Sales
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return base.GetValueViewState<DateTime>("OldVersionUpdateDate"); }
            set { ViewState["OldVersionUpdateDate"] = value; }
        }

        /// <summary>
        /// Get Or Set Has Sales
        /// </summary>
        public bool HasSales
        {
            get
            {
                return base.GetValueViewState<bool>("HasSales");
            }
            private set { ViewState["HasSales"] = value; }
        }

        /// <summary>
        /// Get Or Set Is Referenced
        /// </summary>
        public bool IsReferenced
        {
            get
            {
                return base.GetValueViewState<bool>("IsReferenced");
            }
            private set { ViewState["IsReferenced"] = value; }
        }

        /// <summary>
        /// IDRef
        /// </summary>
        public int IDRef
        {
            get { return base.GetValueViewState<int>("IDRef"); }
            set { ViewState["IDRef"] = value; }
        }

        /// <summary>
        /// NoRef
        /// </summary>
        public string NoRef
        {
            get { return base.GetValueViewState<string>("NoRef"); }
            set { ViewState["NoRef"] = value; }
        }

        /// <summary>
        /// Child Row Command Argument
        /// </summary>
        private string ChildRowCommandArgument
        {
            get
            {
                return base.GetValueViewState<string>("ChildRowCommandArgument");
            }
            set { ViewState["ChildRowCommandArgument"] = value; }
        }

        public List<string> ListAcceptReportFile
        {
            get { return base.GetValueViewState<List<string>>("ListAcceptReportFile"); }
            set
            {
                base.ViewState["ListAcceptReportFile"] = value;
            }
        }

        #endregion Property

        #region Variable

        /// <summary>
        /// Action mode
        /// </summary>
        private enum ActionMode
        {
            /// <summary>
            /// None
            /// </summary>
            None = 0,

            /// <summary>
            /// Issue
            /// </summary>
            Issue = 1,

            /// <summary>
            /// DeleteRow
            /// </summary>
            DeleteRow = 2,

            /// <summary>
            /// CurrencyChanged
            /// </summary>
            CurrencyChanged = 3,

            /// <summary>
            /// MethodChanged
            /// </summary>
            MethodChanged = 4,

            /// <summary>
            /// Copy
            /// </summary>
            Copy = 5,

            /// <summary>
            /// Issue ISV
            /// </summary>
            IssueISV = 6,

            /// <summary>
            /// Remove Child Row
            /// </summary>
            RemoveChildRow = 7
        }

        /// <summary>
        /// Serial Hidden
        /// </summary>
        protected enum SerialHidden
        {
            /// <summary>
            /// Show
            /// </summary>
            Show = 0,

            /// <summary>
            /// Hidden
            /// </summary>
            Hidden
        }

        /// <summary>
        /// UnitList
        /// </summary>
        private IList<DropDownModel> _unitList;

        /// <summary>
        /// ExchangeRateList
        /// </summary>
        private IList<DropDownModel> _currencyList;

        /// <summary>
        /// MethodVatList
        /// </summary>
        private IList<DropDownModel> _methodVatList;

        /// <summary>
        /// VatTotalTypeList
        /// </summary>
        private IList<DropDownModel> _vatTotalTypeList;

        /// <summary>
        /// Vat Total Type List Empty
        /// </summary>
        private IList<DropDownModel> _vatTypeListEmpty = new List<DropDownModel>();
        /// <summary>
        /// The Contract type list
        /// </summary>
        private IList<DropDownModel> _contractTypeList;
        /// <summary>
        /// Index Sell
        /// </summary>
        private int _indexSell;

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string _defaultMethodVat;

        /// <summary>
        /// The default contract type
        /// </summary>
        private string _defaultContractType;

        /// <summary>
        /// Default VatType
        /// </summary>
        private string _defaultVatType;

        /// <summary>
        /// Default FractionType
        /// </summary>
        private FractionType _defaultFractionType;

        /// <summary>
        /// Get roductCdSupport
        /// </summary>
        public string productCdSupport
        {
            get
            {
                return M_Product.PRODUCT_CODE_SUPPORT;
            }
        }

        /// <summary>
        /// Is Detail Empty
        /// </summary>
        private bool isDetailEmpty;

        #endregion Variable

        #region Events

        /// <summary>
        /// Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            this.hdnProductSellType.Value = ((int)ProductType.Sell).ToString();

            //Set Title
            base.FormTitle = "Delivery";
            base.FormSubTitle = "";

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(ProcessConfirm);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(RestoreValue);

            //Download PDF Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadPDF_Click);

            //Init Max Length
            this.txtCustomerCD.MaxLength = M_Customer.MAX_CUSTOMER_CODE_SHOW;
            this.txtCustomerName.MaxLength = M_Customer.CUSTOMER_NAME1_MAX_LENGTH;
            this.txtAttn.MaxLength = M_Customer.CONTACT_PERSON_MAX_LENGTH;
            this.txtAdd1.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd2.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtAdd3.MaxLength = M_Customer.ADDRESS_MAX_LENGTH;
            this.txtTel.MaxLength = M_Customer.TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Customer.FAX_MAX_LENGTH;
            this.txtSubject.MaxLength = T_Delivery_H.SUBJECT_NAME_MAX_LENGTH;
            this.txtPrepareCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtApprovedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtDeliveryPlace.MaxLength = T_Delivery_H.DELIVERY_PLACE_MAX_LENGTH;
            this.txtMemo.MaxLength = T_Delivery_H.MEMO_MAX_LENGTH;

            this.txtDeliveryName.MaxLength = T_Delivery_H.DELIVERY_NAME_MAX_LENGTH;
            this.txtAcceptanceNo.MaxLength = T_Delivery_H.ACCEPTANCE_NO_MAX_LENGTH;

            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditions.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            //Back
            this.btnBackView.Click += new EventHandler(btnBackView_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Get Default Data
            this.GetDefaultData();
            this.SetAuthority(FormId.Delivery);
            //Check Authority
            if (!base._authority.IsDeliveryView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_DELIVERY_LIST;
            }

            if (!this.IsPostBack)
            {
                this._actionMode = ActionMode.None;

                //Init DropDownList
                this.InitDropDownListData(this.cmbCurrency, this._currencyList);

                this.InitDropDownListData(this.cmbMethodVat, this._methodVatList);
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTotalTypeList);

                this.hdnFractionType.Value = ((int)this._defaultFractionType).ToString();

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        this.ViewState["BACK_URL"] = para["BACK_URL"];
                        //Check para
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get Delivery ID
                            this.DataID = int.Parse(para["ID"].ToString());
                            var header = this.GetByID(this.DataID);
                            if (header != null)
                            {
                                //Show data
                                this.SetDeliveryInfo(this.DataID);
                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
                            }
                        }
                        else
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set Back URL
            this.btnBackView.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Add Row Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            IList<DeliveryDetailInfo> list = this.GetDetailData();

            DeliveryDetailInfo detail = new DeliveryDetailInfo();
            detail.No = list.Count + 1;

            var defaultVatType = -1;
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
            {
                defaultVatType = int.Parse(this._defaultVatType);
            }
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                detail.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            detail.VatType = (short)defaultVatType;

            detail.SerialList = new List<SerialInfo>();
            SerialInfo serial = new SerialInfo();
            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            
            serial.ContractType = short.Parse(this._defaultContractType);
            serial.StartDate = null;
            serial.FinishDate = null;

            serial.No = 1;
            serial.DetailNo = detail.No;
            detail.SerialList.Add(serial);
            list.Add(detail);
            this.chkDelAll.Checked = false;
            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();

            // Description: Add
            // Author: ISV-PHUONG
            // Date  : 2014/12/10
            // ---------------------- Start ------------------------------
            if (this.ProductCdUsed)
            {
                this.FocusControlId = string.Format("txtProductCD_{0}", detail.No - 1);
            }
            else
            {
                this.FocusControlId = string.Format("txtProductName_{0}", detail.No - 1);
            }
            // ---------------------- End   ------------------------------
        }

        /// <summary>
        /// Delete Row Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRow_Click(object sender, EventArgs e)
        {
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            this._actionMode = ActionMode.DeleteRow;
        }

        /// <summary>
        /// Up Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUp_Click(object sender, EventArgs e)
        {
            //Get Data
            this.SwapDetail(true);
        }

        /// <summary>
        /// Down Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDown_Click(object sender, EventArgs e)
        {
            //Get Data
            this.SwapDetail(false);
        }

        /// <summary>
        /// UnitSerial SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbUnitSerial_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList cmbUnit = (DropDownList)sender;
            this.FocusControlId = cmbUnit.ClientID;

            INumberTextBox txtTerms = (INumberTextBox)cmbUnit.Parent.FindControl("txtTerms");
            IDateTextBox txtWarranty = (IDateTextBox)cmbUnit.Parent.FindControl("txtSerialFinishDate");
            if (txtTerms.Value.HasValue)
            {
                //set value on Term and Warranty
                switch (int.Parse(cmbUnit.SelectedItem.Value))
                {
                    case (int)WarrantyUnit.None:
                        break;

                    case (int)WarrantyUnit.Years://year
                        txtWarranty.Value = this.txtDeliveryDateHeader.Value.Value.AddYears(Convert.ToInt32(txtTerms.Value.Value));
                        break;

                    case (int)WarrantyUnit.Months:
                        txtWarranty.Value = this.txtDeliveryDateHeader.Value.Value.AddMonths(Convert.ToInt32(txtTerms.Value.Value));
                        break;

                    case (int)WarrantyUnit.Weeks:
                        txtWarranty.Value = this.txtDeliveryDateHeader.Value.Value.AddDays(Convert.ToInt32(txtTerms.Value.Value) * 7);
                        break;

                    case (int)WarrantyUnit.Days:
                        txtWarranty.Value = this.txtDeliveryDateHeader.Value.Value.AddDays(Convert.ToInt32(txtTerms.Value.Value));
                        break;

                    default:
                        break;
                }
            }
            this.SetConfirmData(false);
            this.RefreshDetails();
        }

        /// <summary>
        /// Currency SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_CURRENCY_CHANGED, Models.DefaultButton.Yes, true);
            this._actionMode = ActionMode.CurrencyChanged;
            this.SetConfirmData();
            this.RefreshDetails();
        }

        /// <summary>
        /// Repeater Detail Item Data Bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DeliveryDetailInfo item = (DeliveryDetailInfo)e.Item.DataItem;

                //Init Unit
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbUnit");
                this.InitDropDownListData(cmbUnit, this._unitList);

                //Set selected item for dropdownlist
                cmbUnit.SelectedValue = item.UnitID.ToString();

                //Init Vat Type
                DropDownList cmbSellVatType = (DropDownList)e.Item.FindControl("cmbVatType");
                this.InitDropDownListData(cmbSellVatType, this._vatTotalTypeList);

                //Hidden VatType
                HiddenField hdVatType = (HiddenField)e.Item.FindControl("hdVatType");
                hdVatType.Value = item.VatType.ToString();

                Repeater rptSerial = (Repeater)e.Item.FindControl("rptSerial");

                var methodVAT = this.cmbMethodVat.SelectedValue;
                if (this._actionMode == ActionMode.MethodChanged)
                {
                    methodVAT = this.GetValueViewState<T_Delivery_H>("HEADER").MethodVat.ToString();
                }

                var txtSellPrice = (INumberTextBox)e.Item.FindControl("txtUnitPrice");
                var txtSellQuantity = (INumberTextBox)e.Item.FindControl("txtQuantity");
                var txtDeliQuantity = (INumberTextBox)e.Item.FindControl("txtDeliQuantity");
                var txtSellTotal = (INumberTextBox)e.Item.FindControl("txtTotal");
                var txtSellVat = (INumberTextBox)e.Item.FindControl("txtVAT");
                var txtSellVatRatio = (INumberTextBox)e.Item.FindControl("txtVatRatio");

                txtSellQuantity.DecimalDigit = this.QtyDecDigit;
                txtDeliQuantity.DecimalDigit = this.QtyDecDigit;
                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                if (this._actionMode == ActionMode.CurrencyChanged)
                {
                    crcyId = this.GetValueViewState<T_Delivery_H>("HEADER").CurrencyID;
                }
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                //---------------Set decimal digit by exchage rate---------------//
                this.SetDecimalDigit(crcySelected, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);
                //---------------End Set decimal digit by exchage rate---------------//

                var selectedItem = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                if (selectedItem.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtSellQuantity.MaximumValue = Constant.MAX_QUANTITY_DECIMAL;
                    txtDeliQuantity.MaximumValue = Constant.MAX_QUANTITY_DECIMAL;
                }
                else
                {
                    txtDeliQuantity.MaximumValue = Constant.MAX_QUANTITY_NOT_DECIMAL;
                    txtSellQuantity.MaximumValue = Constant.MAX_QUANTITY_NOT_DECIMAL;
                }
                if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                {
                    rptSerial.DataSource = item.SerialList;
                    rptSerial.DataBind();
                }
                //Set max length
                var txtSellProductCD = (ICodeTextBox)e.Item.FindControl("txtProductCD");
                txtSellProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;

                ITextBox txtSellProductName = (ITextBox)e.Item.FindControl("txtProductName");
                txtSellProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;

                ITextBox txtSellDescription = (ITextBox)e.Item.FindControl("txtDescription");
                txtSellDescription.MaxLength = T_Delivery_D.DESCRIPTION_MAX_LENGTH;
                //Remark
                ITextBox txtRemark = (ITextBox)e.Item.FindControl("txtRemark");
                txtRemark.MaxLength = T_Delivery_D.REMARK_MAX_LENGTH;

                //Search product
                HtmlButton btnSearchSellProduct = (HtmlButton)e.Item.FindControl("btnSearchProduct");
                string onclickSearchProduct = "callSearchProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID + "'," + (int)Utilities.ProductType.Sell + ")";

                btnSearchSellProduct.Attributes.Add("onclick", onclickSearchProduct);

                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                                    cmbSellVatType.ClientID,
                                                                                    txtSellPrice.ClientID,
                                                                                    txtSellQuantity.ClientID,
                                                                                    txtSellTotal.ClientID,
                                                                                    txtSellVat.ClientID,
                                                                                    txtSellVatRatio.ClientID);

                txtSellPrice.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellPrice.ClientID, param));
                txtSellQuantity.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellQuantity.ClientID, param));
                txtSellTotal.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellTotal.ClientID, param));
                txtSellVatRatio.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtSellVatRatio.ClientID, param));

                txtSellVat.Attributes.Add("onvaluechange", "calcTotalSell();");
                //------------------Set enable with method vat-------------------------//

                //---------------------------Delivery Item Search Start----------------------//

                //InternalID
                HiddenField hidDetailID = (HiddenField)e.Item.FindControl("hidDetailID");
                LinkButton cmdSearchItem = (LinkButton)e.Item.FindControl("cmdSearchDeliveryItem");
                HtmlButton btnSearchDeliveryItem = (HtmlButton)e.Item.FindControl("btnSearchDeliveryItem");

                string onclick = "callSearchDeliveryProduct('" + txtSellProductCD.ClientID + "','" + txtSellProductName.ClientID + "','" + txtSellDescription.ClientID;
                onclick += "','" + hidDetailID.ClientID + "','" + cmdSearchItem.ClientID + "');";
                btnSearchDeliveryItem.Attributes.Add("onclick", onclick);

                //---------------------------Delivery Item Search End  ----------------------//

                var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellVatExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;
                this.lblSumVATExchangeRate.InnerText = label.InnerHtml;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellTotalExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;
                this.lblSumTotalExchangeRate.InnerText = label.InnerHtml;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblSellPriceExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;
                this.lblGrandTotalExchangeRate.InnerText = label.InnerHtml;

                this.lblVATRatio.InnerText = string.Format("{0}/Ratio", crcySelected.TaxName);

                if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                {
                    txtSellVat.SetReadOnly(true);
                    txtSellVatRatio.SetReadOnly(true);
                    cmbSellVatType.Enabled = false;
                    txtSellVat.Value = null;
                    txtSellVatRatio.Value = null;
                    this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                }
                else
                {
                    txtSellVat.SetReadOnly(false);
                    txtSellVatRatio.SetReadOnly(false);
                    cmbSellVatType.Enabled = true;

                    cmbSellVatType.SelectedValue = item.VatType.ToString();

                    if (Convert.ToInt32(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                    {
                        txtSellVat.SetReadOnly(false);
                        txtSellVat.Value = item.VAT;

                        txtSellVatRatio.SetReadOnly(false);
                        txtSellVatRatio.Value = item.VatRatio;
                    }
                    else
                    {
                        txtSellVat.SetReadOnly(true);
                        txtSellVat.Value = null;

                        txtSellVatRatio.SetReadOnly(true);
                        txtSellVatRatio.Value = null;
                    }
                }
            }
        }

        /// <summary>
        /// Repeater Serial Item Data Bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptSerial_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                SerialInfo info = (SerialInfo)e.Item.DataItem;

                //Init Unit Serial
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbUnitSerial");
                HiddenField hdUnit = (HiddenField)e.Item.FindControl("hdUnitSerial");

                //Init Unit Serial
                DropDownList cmbContractType = (DropDownList)e.Item.FindControl("cmbContractType");
                HiddenField hdContractType = (HiddenField)e.Item.FindControl("hdContractType");

                hdUnit.Value = info.TermUnit == null ? ((int)WarrantyUnit.None).ToString() : info.TermUnit.ToString();
                hdContractType.Value = info.ContractType.ToString();

                this.InitDropDownListData(cmbUnit, InitDataForWarrantyType(cmbUnit));
                this.InitDropDownListData(cmbContractType, this._contractTypeList);

                cmbUnit.SelectedValue = info.TermUnit.ToString();
                cmbContractType.SelectedValue = info.ContractType.ToString();

                ITextBox txtSerial = (ITextBox)e.Item.FindControl("txtSerial");
                txtSerial.MaxLength = T_Delivery_Serial.SERIAL_NO_MAX_LENGTH;

                INumberTextBox txtTerms = (INumberTextBox)e.Item.FindControl("txtTerms");
                txtTerms.MaxLength = 5;
                txtTerms.DecimalDigit = INT_0;
                txtTerms.MaximumValue = INT_4D;

                IDateTextBox txtFinishDate = (IDateTextBox)e.Item.FindControl("txtSerialFinishDate");
                IDateTextBox txtStartDate = (IDateTextBox)e.Item.FindControl("txtSerialStartDate");

                var param = string.Format("'{0}', '{1}', '{2}','{3}','{4}','{5}'", this.txtDeliveryDateHeader.ClientID, cmbContractType.ClientID, txtTerms.ClientID, cmbUnit.ClientID, txtStartDate.ClientID, txtFinishDate.ClientID);
                txtTerms.Attributes.Add("onvaluechange", string.Format("serialOnChanged('{0}', {1})", txtTerms.ClientID, param));
                cmbUnit.Attributes.Add("onchange", string.Format("serialOnChanged('{0}', {1})", cmbUnit.ClientID, param));

                var balanceParam = string.Format("'{0}', '{1}', '{2}'", cmbContractType.ClientID, txtTerms.ClientID, cmbUnit.ClientID);
                txtFinishDate.Attributes.Add("onvaluechange", string.Format("startDatevsFinishDateOnChanged('{0}','{1}', {2});", txtFinishDate.ClientID, txtStartDate.ClientID, balanceParam));
                txtStartDate.Attributes.Add("onvaluechange", string.Format("startDatevsFinishDateOnChanged('{0}','{1}', {2});", txtStartDate.ClientID, txtFinishDate.ClientID, balanceParam));

                if (cmbContractType.SelectedValue.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                {
                    //txtTerms.SetReadOnly(false);
                    //cmbUnit.Attributes.Remove("disabled");
                    txtStartDate.SetReadOnly(true);
                }
                else
                {
                    //txtTerms.SetReadOnly(true);
                    //cmbUnit.Attributes.Add("disabled", "true");
                    txtStartDate.SetReadOnly(false);
                }
            }
        }

        /// <summary>
        /// Repeater Detail Item Command
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptDetail_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {
            #region cmdSearchDeliveryItemProcess

            if (e.CommandName == "cmdSearchDeliveryItemProcess")
            {
                //Get index row current
                int itemNo = Convert.ToInt32(e.CommandArgument);
                this.ChildRowCommandArgument = itemNo.ToString();

                //InternalID
                HiddenField hidDetailID = (HiddenField)e.Item.FindControl("hidDetailID");
                ITextBox txtDescription = (ITextBox)e.Item.FindControl("txtDescription");

                var details = this.GetDetailData();
                var sellRow = details.Where(s => s.No == itemNo).SingleOrDefault();

                #region Copy

                using (DB db = new DB())
                {
                    var internalId = int.Parse(hidDetailID.Value);

                    Delivery_HService hService = new Delivery_HService(db);
                    Delivery_DService dService = new Delivery_DService(db);
                    Currency_HService crcyService = new Currency_HService(db);

                    var detail = dService.GetByInternalID(internalId);
                    var header = hService.GetByID(detail.HID);

                    var headerCurrencyId = header.CurrencyID;
                    var currencyId = int.Parse(this.cmbCurrency.SelectedValue);
                    var unitPrice = 0m;
                    var baseDate = this.txtDeliveryDateHeader.Value.HasValue ? this.txtDeliveryDateHeader.Value.GetValueOrDefault() : db.NowDate;
                    var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);
                    if (headerCurrencyId != currencyId)
                    {
                        unitPrice = CommonUtil.ConvertToVND(crcyList[headerCurrencyId].ExchangeRate, detail.UnitPrice);

                        if (currencyId != Constant.DEFAULT_ID)
                        {
                            unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyId].ExchangeRate, unitPrice);
                        }
                    }
                    else
                    {
                        unitPrice = detail.UnitPrice;
                    }

                    sellRow.ProductID = detail.ProductID;
                    sellRow.ProductCD = detail.ProductCD;
                    sellRow.ProductName = detail.ProductName;
                    sellRow.Description = detail.Description;
                    sellRow.UnitPrice = unitPrice;
                    sellRow.Quantity = null;
                    sellRow.Total = null;
                    sellRow.VAT = null;
                    sellRow.UnitID = detail.UnitID;
                    sellRow.Remark = detail.Remark;
                    sellRow.VatType = detail.VATType;
                    sellRow.VatRatio = detail.VATRatio;

                    #region Unknown

                    foreach (var item in details)
                    {
                        if (item.DeliveryDate == DEFAULT_DATE_TIME)
                        {
                            item.DeliveryDate = null;
                        }
                        if (item.DeliveryQuantity == 0)
                        {
                            item.DeliveryQuantity = null;
                        }

                        if (item.SalesSellID != 0)
                        {
                            item.RemainQty = dService.GetRemainQtyBySalesSellID(item.SalesSellID, this.DataID);
                        }
                        else
                        {
                            item.RemainQty = null;
                        }
                        //********************
                        if (item.SerialList == null || item.SerialList.Count == 0)
                        {
                            SerialInfo serial = new SerialInfo();
                            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                            serial.No = 1;
                            serial.DetailNo = item.No;
                            serial.ContractType = short.Parse(this._defaultContractType);
                            serial.FinishDate = null;
                            serial.StartDate = null;
                            item.SerialList.Add(serial);
                        }
                        else
                        {
                            int indexSeri = 1;
                            foreach (var seriItem in item.SerialList)
                            {
                                seriItem.No = indexSeri++;
                                if (seriItem.StartDate == DEFAULT_DATE_TIME)
                                {
                                    seriItem.StartDate = null;
                                }
                                if (seriItem.FinishDate == DEFAULT_DATE_TIME)
                                {
                                    seriItem.FinishDate = null;
                                }
                                if (seriItem.Terms == 0)
                                {
                                    seriItem.Terms = null;
                                }
                            }
                        }
                    }

                    #endregion Unknown

                    this.RefreshDetails(details);

                    this.SetConfirmData();
                    this.FocusControlId = txtDescription.ClientID;
                }

                #endregion Copy
            }

            #endregion cmdSearchDeliveryItemProcess
        }

        /// <summary>
        /// Repeater Serial Item Command
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void rptSerial_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "cmdAddRow")
            {
                //int detailNo = Convert.ToInt32(e.CommandArgument);
                string[] value = e.CommandArgument.ToString().Split('_');
                int detailNo = Convert.ToInt32(value[0]);
                int no = Convert.ToInt32(value[1]);

                //Get Data
                IList<DeliveryDetailInfo> sellList = this.GetDetailData();
                var sell = sellList.Where(s => s.No == detailNo).SingleOrDefault();
                sell.SerialList.AsParallel().ForAll(s => s.Collapsed = "in");

                var seriInfo = new SerialInfo
                {
                    DeliveryID = sell.InternalID,
                    No = sell.SerialList.Count + 1,
                    FinishDate = null,
                    StartDate = null,
                    ContractType = short.Parse(this._defaultContractType),
                    DetailNo = detailNo,
                    Collapsed = "in"
                };
                if (sell.SerialList.Count != 0)
                {
                    sell.SerialList.Insert(no, seriInfo);
                    var seriNo = 1;
                    foreach (var seri in sell.SerialList)
                    {
                        seri.No = seriNo++;
                    }
                }
                else
                {
                    sell.SerialList.Add(seriInfo);
                }
                this.RefreshDetails(sellList);

                this.FocusControlId = string.Format((seriInfo.DetailNo - 1) + "_txtSerial_{0}", seriInfo.No == 1 ? 1 : (seriInfo.No - 1));
            }

            if (e.CommandName == "cmdDelRow")
            {
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
                this._actionMode = ActionMode.RemoveChildRow;
            }
        }

        /// <summary>
        /// Download Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                M_Setting setting = new M_Setting();
                using (var db = new DB())
                {
                    SettingService settingSer = new SettingService(db);
                    setting = settingSer.GetData();
                }
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    var fileName = string.Empty;
                    if (this.TypeOfIssue == "PDF")
                    {
                        fileName = string.Format("{0}.pdf", this.txtDeliveryNo.Value);
                        Response.ContentType = "application/pdf";
                    }
                    else
                    {
                        fileName = this.TypeOfIssue;
                        Response.ContentType = "application/vnd.ms-excel";
                    }

                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                    Response.Flush(); // send it to the client to download
                }
            }
        }

        /// <summary>
        /// Method VAT select changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbMethodVat_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_METHOD_CHANGED, Models.DefaultButton.Yes, true);

            this._actionMode = ActionMode.MethodChanged;
            this.SetConfirmData();
            this.RefreshDetails();
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_MAKE_COPY, Models.DefaultButton.Yes, true, "");
            this._actionMode = ActionMode.Copy;
        }

        /// <summary>
        /// Update Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }
                //Show data
                this.SetDeliveryInfo(this.DataID);
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
            }
        }

        /// <summary>
        /// Reference Click OK
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnReferenceYes_Click(object sender, CommandEventArgs e)
        {
            int deliveryId = this.DataID;
            T_Delivery_H delivery = this.GetByID(deliveryId);
            if (delivery != null)
            {
                //if (delivery.UpdateDate != this.OldUpdateDate)
                //{
                //    this.FocusControlId = this.btnIssue.ClientID;
                //    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);

                //    //Reload data
                //    this.SetDeliveryInfo(deliveryId);
                //    return;
                //}

                //Process reference parameter
                Hashtable currentPage = new Hashtable();
                currentPage.Add("ID", delivery.ID);

                Hashtable nextPage = new Hashtable();

                nextPage.Add("FinishedFlag", M_Config_D.DATA_INCLUDE);
                nextPage.Add("DeletedFlag", M_Config_D.DATA_INCLUDE);

                if (!this.txtQuotationNo.IsEmpty)
                {
                    nextPage.Add("txtQuoteNo", this.txtQuotationNo.Value);
                    nextPage.Add("QuoteNoReadOnly", true);
                }

                if (!this.txtSalesNo.IsEmpty)
                {
                    nextPage.Add("txtSalesNo", this.txtSalesNo.Value);
                    nextPage.Add("SalesNoReadOnly", true);
                }

                var formId = e.CommandArgument;
                if (string.Equals(formId, "Quotation"))
                {
                    if (!this.txtQuotationNo.IsEmpty)
                    {
                        nextPage.Add("SalesData", M_Config_D.DATA_INCLUDE);
                    }

                    base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_DELIVERY_DETAIL);
                }

                if (string.Equals(formId, "Sales"))
                {
                    base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_DELIVERY_DETAIL);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
            }
        }

        /// <summary>
        /// Check Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCheck_Click(object sender, EventArgs e)
        {
            var header = this.GetByID(this.DataID);
            this._actionMode = ActionMode.None;
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnCheck.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.SetDeliveryInfo(this.DataID);
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Check);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
            }
        }

        /// <summary>
        /// Event Check Confirm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCheckConfirm_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check mode Check
            if (!this.CheckInputDeliveryCheck())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Get info by ID
            T_Delivery_H deliveryH = this.GetByID(this.DataID);

            //Check Shipping
            if (deliveryH != null)
            {
                var isOk = true;
                if (deliveryH.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    this.SetDeliveryInfo(this.DataID);
                    isOk = false;
                }

                T_Sales_H salesH = null;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    salesH = sales_HService.GetBySalesNo(deliveryH.SalesNo);
                }

                if (salesH != null)
                {
                    if (salesH.VersionUpdateDate <= this.OldVersionUpdateDate)
                    {
                        //Show data
                        this.SetDeliveryInfo(this.DataID);
                    }
                }
                else
                {
                    this.SetDeliveryInfo(this.DataID);
                }

                if (isOk)
                {
                    //Set Model
                    this.ProcessMode(Mode.Delete);

                    //Show question insert
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
                }
            }
        }

        /// <summary>
        /// Issue Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIssue_Click(object sender, EventArgs e)
        {
            this.TypeOfIssue = "PDF";
            int id = this.DataID;
            //Get info by ID
            T_Delivery_H deliveryH = this.GetByID(id);

            //Check Shipping
            if (deliveryH != null)
            {
                var isOk = true;
                if (deliveryH.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }
                //Show data
                this.SetDeliveryInfo(id);
                if (isOk)
                {
                    this._actionMode = ActionMode.Issue;

                    // this.Issued = true;

                    if (deliveryH.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes, true);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, true, "PDF");
                    }
                }
            }
            else
            {
                Server.Transfer(FrmBase.URL_DELIVERY_LIST);
            }
        }

        protected void btnIssueISV_Click(object sender, EventArgs e)
        {
            int id = this.DataID;
            //Get info by ID
            T_Delivery_H shipH = this.GetByID(id);

            //Check Shipping
            if (shipH != null)
            {
                this._actionMode = ActionMode.IssueISV;

                using (var db = new DB())
                {
                    // this.Issued = true;

                    if (shipH.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, false, "PDF");
                    }

                    //Show data
                    this.SetDeliveryInfo(id);
                }
            }
            else
            {
                Server.Transfer(FrmBase.URL_DELIVERY_LIST);
            }
        }

        /// <summary>
        /// Insert Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            this.SetConfirmData();

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Mode normal
            if (this.Mode != Mode.View)
            {
                var header = this.GetByID(this.DataID);
                //Check data
                if (header != null)
                {
                    //Set Model
                    this.Mode = Mode.View;

                    //Show data
                    this.SetDeliveryInfo(this.DataID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
                }
            }
        }

        /// <summary>
        /// btnBackList_Click Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBackView_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        #endregion Events

        #region Methods

        /// <summary>
        /// Check exist data
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private T_Delivery_H GetByID(int id)
        {
            using (DB db = new DB())
            {
                Delivery_HService service = new Delivery_HService(db);
                return service.GetByID(id);
            }
        }

        /// <summary>
        /// Process Confirm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ProcessConfirm(object sender, EventArgs e)
        {
            T_Delivery_H shipH = null;
            var methodVAT = this.cmbMethodVat.SelectedValue;
            var defaultVatType = int.Parse(this._defaultVatType);

            switch (this._actionMode)
            {
                case ActionMode.None:
                    break;

                case ActionMode.Issue:

                    #region Issue

                    DeliveryPDF rptDelivery = new DeliveryPDF();
                    rptDelivery.LoginInfo = this.LoginInfo;
                    var uniqueFileName = string.Format(PDF_DELIVERY_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                    this.ExportPDF(rptDelivery.GetLocalReport(new LocalReport(), this.DataID, this.OldUpdateDate), uniqueFileName, true);

                    //Show data
                    this.SetDeliveryInfo(this.DataID);
                    //Set Mode
                    this.ProcessMode(Mode.View);

                    this._actionMode = ActionMode.None;
                    return;

                    #endregion Issue

                case ActionMode.DeleteRow:

                    #region DeleteRow

                    //Get Data
                    IList<DeliveryDetailInfo> list = this.GetDetailData(includeDelete: false);
                    if (list.Count == 0)
                    {
                        DeliveryDetailInfo detail = new DeliveryDetailInfo();
                        detail.No = 1;
                        defaultVatType = -1;
                        if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                        {
                            defaultVatType = int.Parse(this._defaultVatType);
                        }

                        if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            detail.VatRatio = decimal.Parse(this.DefaultVAT);
                        }
                        detail.VatType = (short)defaultVatType;

                        // detail.NoDisp = detail.No;
                        detail.VatRatio = decimal.Parse(this.DefaultVAT);

                        detail.SerialList = new List<SerialInfo>();
                        SerialInfo serial = new SerialInfo();
                        serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;// this.DefaultSerialView == 1 ? "in" : string.Empty;

                        serial.No = 1;
                        serial.FinishDate = null;
                        serial.StartDate = null;
                        serial.ContractType = short.Parse(this._defaultContractType);
                        serial.DetailNo = detail.No;
                        detail.SerialList.Add(serial);
                        list.Add(detail);
                        this.chkDelAll.Checked = false;
                    }
                    this._indexSell = 1;
                    for (int i = 0; i < list.Count; i++)
                    {
                        var row = list[i];
                        row.No = this._indexSell++;
                        foreach (var seri in row.SerialList)
                        {
                            seri.DetailNo = row.No;
                        }
                    }
                    this.RefreshDetails(list);

                    this.SetConfirmData(false);

                    this._actionMode = ActionMode.None;

                    // Description: Add
                    // Author: ISV-PHUONG
                    // Date  : 2014/12/10
                    // ---------------------- Start ------------------------------
                    if (this.ProductCdUsed)
                    {
                        this.FocusControlId = string.Format("txtProductCD_{0}", 0);
                    }
                    else
                    {
                        this.FocusControlId = string.Format("txtProductName_{0}", 0);
                    }
                    // ---------------------- End   ------------------------------
                    return;

                    #endregion DeleteRow

                case ActionMode.RemoveChildRow:

                    #region Delete Child Row(Cost)

                    string[] value = this.ChildRowCommandArgument.Split('_');
                    int detailNo = Convert.ToInt32(value[0]);
                    int no = Convert.ToInt32(value[1]);

                    //Get Data
                    IList<DeliveryDetailInfo> sellList = this.GetDetailData();

                    var sell = sellList.Where(s => s.No == detailNo).SingleOrDefault();
                    sell.SerialList.AsParallel().ForAll(s => s.Collapsed = "in");
                    if (sell.SerialList.Count != 0)
                    {
                        sell.SerialList.RemoveAt(no - 1);
                        var seriNo = 1;
                        foreach (var seri in sell.SerialList)
                        {
                            seri.No = seriNo++;
                        }
                    }

                    if (sell.SerialList.Count == 0)
                    {
                        var seriInfo = new SerialInfo
                        {
                            DeliveryID = sell.InternalID,
                            No = sell.SerialList.Count + 1,
                            DetailNo = detailNo,
                            FinishDate = null,
                            StartDate = null,
                            ContractType = short.Parse(this._defaultContractType),
                            Collapsed = "in"
                        };
                        sell.SerialList.Add(seriInfo);
                    }

                    this.RefreshDetails(sellList);

                    this.SetConfirmData(true);

                    var lastCostItem = sell.SerialList.LastOrDefault();
                    this.FocusControlId = string.Format("{0}_txtSerial_{1}", sell.No - 1, lastCostItem.No - 1);
                    this._actionMode = ActionMode.None;
                    return;

                    #endregion Delete Child Row(Cost)

                case ActionMode.CurrencyChanged:

                    #region CurrencyChanged

                    this.FocusControlId = this.cmbCurrency.ClientID;
                    var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                    var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtSellPrice = (INumberTextBox)item.FindControl("txtUnitPrice");
                            INumberTextBox txtSellTotal = (INumberTextBox)item.FindControl("txtTotal");
                            INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtVAT");

                            //Set decimal digit control sell by exchange
                            this.SetDecimalDigit(crcySelected, txtSellPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtSellTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtSellVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                            var label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellVatExchangeRate");
                            label.InnerHtml = this.cmbCurrency.SelectedItem.Text;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellTotalExchangeRate");
                            label.InnerHtml = this.cmbCurrency.SelectedItem.Text;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblSellPriceExchangeRate");
                            label.InnerHtml = this.cmbCurrency.SelectedItem.Text;

                            //Reset null value
                            txtSellPrice.Value = null;
                            txtSellTotal.Value = null;
                            txtSellVat.Value = null;
                        }
                    }

                    ////Set decimal digit control total by exchange
                    this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                    this._actionMode = ActionMode.None;
                    this.SetConfirmData(true);
                    this.RefreshDetails();
                    if (this.ViewState["HEADER"] != null)
                    {
                        var header = (T_Delivery_H)this.ViewState["HEADER"];
                        header.CurrencyID = crcyId;
                        this.ViewState["HEADER"] = header;
                    }
                    return;

                    #endregion CurrencyChanged

                case ActionMode.MethodChanged:

                    #region Method VAT Changed

                    this._actionMode = ActionMode.None;
                    this.FocusControlId = this.cmbMethodVat.ClientID;
                    defaultVatType = int.Parse(this._defaultVatType);

                    #region Detail

                    //Set enable control at detail list with method vat type
                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtSellVat = (INumberTextBox)item.FindControl("txtVat");
                            DropDownList cmbSellVatType = (DropDownList)item.FindControl("cmbVatType");
                            INumberTextBox txtSellVatRatio = (INumberTextBox)item.FindControl("txtVatRatio");

                            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                            {
                                //Enable control sell by method vat
                                txtSellVat.SetReadOnly(false);
                                txtSellVatRatio.SetReadOnly(false);
                                cmbSellVatType.Enabled = true;
                                txtSellVatRatio.Value = decimal.Parse(this.DefaultVAT);//????????????????
                                this.InitDropDownListData(cmbSellVatType, this._vatTotalTypeList);
                                cmbSellVatType.SelectedValue = defaultVatType.ToString();
                            }
                            else
                            {
                                //Enable control sell by method vat
                                txtSellVat.SetReadOnly(true);
                                txtSellVatRatio.SetReadOnly(true);
                                cmbSellVatType.Enabled = false;
                                txtSellVat.Value = null;
                                txtSellVatRatio.Value = null;
                                this.InitDropDownListData(cmbSellVatType, this._vatTypeListEmpty);
                            }
                        }
                    }

                    #endregion Detail

                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                    {
                        //Set enable control at total with method vat type
                        this.txtTotalVatRatio.SetReadOnly(true);
                        this.txtSumVat.SetReadOnly(false);

                        this.cmbTotalVatType.Enabled = false;

                        this.txtTotalVatRatio.Value = null;
                        this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeListEmpty);
                    }
                    else
                    {
                        // this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
                        //SUM
                        this.InitDropDownListData(this.cmbTotalVatType, this._vatTotalTypeList);

                        this.cmbTotalVatType.SelectedValue = defaultVatType.ToString();
                        //Set enable control at total with method vat type
                        this.cmbTotalVatType.Enabled = true;

                        if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
                            this.txtTotalVatRatio.SetReadOnly(false);
                        }
                    }
                    this.SetConfirmData(false);
                    this.RefreshDetails();
                    if (this.ViewState["HEADER"] != null)
                    {
                        var header = (T_Delivery_H)this.ViewState["HEADER"];
                        header.MethodVat = short.Parse(methodVAT);
                        this.ViewState["HEADER"] = header;
                    }
                    //this._actionMode = ActionMode.None;
                    return;

                    #endregion Method VAT Changed

                case ActionMode.Copy:

                    #region Copy

                    this._actionMode = ActionMode.None;
                    shipH = this.GetByID(this.DataID);
                    //Check data
                    if (shipH != null)
                    {
                        var isOk = true;
                        if (shipH.UpdateDate != this.OldUpdateDate)
                        {
                            this.FocusControlId = this.btnCopy.ClientID;
                            base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            isOk = false;
                            if (shipH.DeleteFlag == 1)
                            {
                                base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
                                return;
                            }
                        }

                        //Show data
                        this.SetDeliveryInfo(this.DataID);

                        if (isOk)
                        {
                            //Set Mode
                            this.ProcessMode(Mode.Copy);
                        }
                    }
                    else
                    {
                        base.RedirectUrl(FrmBase.URL_DELIVERY_LIST);
                    }
                    return;

                    #endregion Copy

                default:
                    break;
            }

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    #region Insert/Copy

                    //Insert Data
                    if (this.InsertData())
                    {
                        //Show data
                        this.SetDeliveryInfo(this.DataID);
                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                    #endregion Insert/Copy

                case Mode.Update:

                    #region Update Data

                    //Update Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.SetDeliveryInfo(this.DataID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }

                    #endregion Update Data

                    break;

                case Mode.Check:

                    #region Check Data

                    if (this.UpdateDataCheck())
                    {
                        //Show data
                        this.SetDeliveryInfo(this.DataID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }

                    break;

                    #endregion Check Data

                case Mode.Delete:

                    #region Delete Data

                    //Delete Data
                    if (this.DeleteData())
                    {
                        //Show data
                        this.SetDeliveryInfo(this.DataID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ProcessMode(Mode.View);
                    }

                    #endregion Delete Data

                    break;
            }
        }

        /// <summary>
        /// Restore value
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void RestoreValue(object sender, EventArgs e)
        {
            if (this.Mode == Mode.Delete)
            {
                //Show data
                this.SetDeliveryInfo(this.DataID);

                //Set Mode
                this.ProcessMode(Mode.View);
            }

            switch (this._actionMode)
            {
                case ActionMode.None:
                    break;

                case ActionMode.CurrencyChanged:
                    //Show condition
                    if (this.ViewState["HEADER"] != null)
                    {
                        T_Delivery_H header = this.GetValueViewState<T_Delivery_H>("HEADER");

                        this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();
                    }
                    break;

                case ActionMode.MethodChanged:
                    if (this.ViewState["HEADER"] != null)
                    {
                        var header = this.GetValueViewState<T_Delivery_H>("HEADER");
                        this.cmbMethodVat.SelectedValue = header.MethodVat.ToString();
                    }
                    break;

                default:
                    if (this.Mode == Mode.View || this.HasSales || this.Mode == Mode.Check)
                    {
                        this.SetDeliveryInfo(this.DataID);
                    }
                    break;
            }
            this._actionMode = ActionMode.None;
        }

        /// <summary>
        /// Set Confirm Data
        /// </summary>
        /// <param name="keepOldValue"></param>
        private void SetConfirmData(bool keepOldValue = true)
        {
            using (DB db = new DB())
            {
                CustomerService custSrv = new CustomerService(db);
                UserService userSrv = new UserService(db);
                //-----------------ISV-HUNG 2015/01/05

                AttachedService attachedService = new AttachedService(db);
                this.FileAttachedCount = attachedService.CountFile(this.DataID, (int)FType.Delivery);
                //-----------------ISV-HUNG 2015/01/05

                var baseDate = db.NowDate;

                var crcyService = new Currency_HService(db);
                var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                #region Header

                //txtCustomerCD
                if (!this.txtCustomerCD.IsEmpty && this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    // Description: Add
                    // Author: ISV-NGUYEN
                    // Date  : 2014/12/05
                    // ---------------------- Start ------------------------------
                    this.txtCustomerName.SetReadOnly(true);
                    // ---------------------- End  -------------------------------
                    var customerCd = this.txtCustomerCD.Value;
                    customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(customerCd, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                    var customer = custSrv.GetByCustomerCD(customerCd);
                    if (customer != null && customer.StatusFlag != 1)
                    {
                        this.txtCustomerName.Value = customer.CustomerName1;
                    }
                }

                // Description: Add
                // Author: ISV-NGUYEN
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                else
                {
                    if (this.txtCustomerCD.Value != Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                    {
                        this.txtCustomerName.Value = null;
                        this.txtCustomerName.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtCustomerName.SetReadOnly(false);
                    }
                }
                // ---------------------- End  -------------------------------

                M_User user = null;
                this.txtPrepareName.Value = null;
                //txtPrepareCD
                if (!this.txtPrepareCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPrepareCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtPrepareName.Value = user.UserName2;
                    }
                }

                this.txtApprovedName.Value = null;
                //txtApprovedCD
                if (!this.txtApprovedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }

                this.HasSales = !this.txtSalesNo.IsEmpty;

                #endregion Header

                var methodType = this.cmbMethodVat.SelectedValue;
                if (this._actionMode == ActionMode.MethodChanged)
                {
                    //Show old value
                    methodType = this.GetValueViewState<T_Delivery_H>("HEADER").MethodVat.ToString();
                }

                var sumTotalSell = 0m;

                var sumVatSell = 0m;
                var sumTotalCost = 0m;

                #region Detail

                foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
                {
                    DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbVatType");
                    HiddenField hdVatType = (HiddenField)repeaterItem.FindControl("hdVatType");
                    if (this.Mode == Mode.View || this.Mode == Mode.Check || (this.Mode == Mode.Update && this.HasSales))
                    {
                        cmbSellVatType.SelectedValue = hdVatType.Value;
                    }

                    DropDownList cmbSellUnit = (DropDownList)repeaterItem.FindControl("cmbUnit");
                    HiddenField hdUnit = (HiddenField)repeaterItem.FindControl("hdUnit");

                    INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtVAT");
                    INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtVatRatio");

                    INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtUnitPrice");
                    INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtQuantity");
                    INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtTotal");
                    if (this.Mode == Mode.View || this.Mode == Mode.Check)
                    {
                        if (!hdUnit.Value.Equals("0"))
                        {
                            cmbSellUnit.SelectedValue = hdUnit.Value;
                        }
                    }

                    var unitPrice = txtSellPrice.Value.GetValueOrDefault();
                    var quantity = txtSellQuantity.Value.GetValueOrDefault();
                    var total = Fraction.Round(this._defaultFractionType, unitPrice * quantity, 2);
                    var vat = Fraction.Round(this._defaultFractionType, (total * txtSellVatRatio.Value.GetValueOrDefault()) / 100, 2);

                    if (!txtSellPrice.IsEmpty && !txtSellQuantity.IsEmpty)
                    {
                        if (txtSellTotal.IsEmpty || !keepOldValue)
                        {
                            txtSellTotal.Value = total;
                        }
                        sumTotalSell += txtSellTotal.Value.GetValueOrDefault();

                        if (methodType == M_Config_D.METHOD_VAT_EACH && int.Parse(cmbSellVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                        {
                            if (txtSellVat.IsEmpty || !keepOldValue)
                            {
                                txtSellVat.Value = vat;
                            }
                            sumVatSell += txtSellVat.Value.GetValueOrDefault();
                        }
                    }

                    if (methodType == M_Config_D.METHOD_VAT_SUM ||
                        int.Parse(cmbSellVatType.SelectedItem.Value) != (int)VATFlg.Exclude)
                    {
                        txtSellVatRatio.Value = null;
                        txtSellVat.Value = null;

                        txtSellVatRatio.SetReadOnly(true);
                        txtSellVat.SetReadOnly(true);
                    }
                    else
                    {
                        txtSellVatRatio.SetReadOnly(false);
                        txtSellVat.SetReadOnly(false);
                    }

                    if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                    {
                        Repeater rptSerial = (Repeater)repeaterItem.FindControl("rptSerial");
                        foreach (RepeaterItem item in rptSerial.Items)
                        {
                            DropDownList cmbUnitSerial = (DropDownList)item.FindControl("cmbUnitSerial");
                            HiddenField hdUnitSerial = (HiddenField)item.FindControl("hdUnitSerial");

                            DropDownList cmbContractType = (DropDownList)item.FindControl("cmbContractType");
                            HiddenField hdContractType = (HiddenField)item.FindControl("hdContractType");

                            if (this.Mode == Mode.Check)
                            {
                                cmbUnitSerial.SelectedValue = hdUnitSerial.Value;
                                cmbContractType.SelectedValue = hdContractType.Value;
                            }
                        }
                    }
                }

                #endregion Detail

                #region SumTotal

                if (this.txtSumTotal.IsEmpty || !keepOldValue)
                {
                    this.txtSumTotal.Value = sumTotalSell;
                }
                sumTotalSell = this.txtSumTotal.Value.GetValueOrDefault();

                if (methodType == M_Config_D.METHOD_VAT_EACH)
                {
                    if (this.txtSumVat.IsEmpty || !keepOldValue)
                    {
                        this.txtSumVat.Value = sumVatSell;
                    }
                    else
                    {
                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                    }
                }
                else
                {
                    int vatType = 0;
                    if (this.Mode == Mode.View || this.HasSales || this.Mode == Mode.Check)
                    {
                        var delivery = this.GetDelivery(this.DataID);
                        if (delivery != null)
                        {
                            vatType = delivery.VatType;
                            this.cmbTotalVatType.SelectedValue = delivery.VatType.ToString();
                        }
                    }
                    else
                    {
                        vatType = int.Parse(this._defaultVatType);
                        if (!string.IsNullOrEmpty(this.cmbTotalVatType.SelectedValue))
                        {
                            vatType = int.Parse(this.cmbTotalVatType.SelectedValue);
                        }
                    }

                    if (vatType == (int)VATFlg.Exclude)
                    {
                        var vatRatio = this.txtTotalVatRatio.Value.GetValueOrDefault();
                        if (this.txtSumVat.IsEmpty || !keepOldValue)
                        {
                            this.txtSumVat.Value = Fraction.Round(this._defaultFractionType, (sumTotalSell * vatRatio) / 100, 2);
                        }

                        sumVatSell = this.txtSumVat.Value.GetValueOrDefault();
                        this.txtSumVat.SetReadOnly(false);
                        this.txtTotalVatRatio.SetReadOnly(false);
                    }
                    else
                    {
                        sumVatSell = 0;
                        this.txtSumVat.SetReadOnly(true);
                        this.txtTotalVatRatio.SetReadOnly(true);

                        this.txtSumVat.Value = null;
                        this.txtTotalVatRatio.Value = null;
                    }
                }

                if (!this.txtGrandTotal.Value.HasValue || !keepOldValue)
                {
                    this.txtGrandTotal.Value = sumTotalSell + sumVatSell;
                }
                var mainCurrencyId = int.Parse(this.cmbCurrency.SelectedValue);

                if (mainCurrencyId != Constant.DEFAULT_ID)
                {
                    //Convert totalCost to ....
                    var exchangeRate = crcyList[mainCurrencyId].ExchangeRate;
                    sumTotalCost = CommonUtil.ConvertToNotVND(exchangeRate, sumTotalCost);
                }

                #endregion SumTotal
            }
        }

        /// <summary>
        /// Get Default Data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                UnitService unitSer = new UnitService(db);
                Currency_HService currHService = new Currency_HService(db);
                Config_HService configHSer = new Config_HService(db);
                Config_DService configDSer = new Config_DService(db);

                //Get Unit
                this._unitList = unitSer.GetDataForDropDownList();

                var crcyItems = currHService.GetListDropdown();

                //Get ExchangeRate
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                //MethodVatList
                this._methodVatList = configHSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_VAT);
                this._defaultMethodVat = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_METHOD_VAT);

                this._contractTypeList = configHSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);
                this._defaultContractType = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);

                //VatTypeList
                this._vatTotalTypeList = configHSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
                this._defaultVatType = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);

                this.DefaultVAT = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL);

                this.QtyDecDigit = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                this.DefaultSerialView = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_COST_VIEW);
                this.DefaultSerialHidden = int.Parse(configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_SERIAL_HIDDEN));//0: Show, 1:Hidden

                //Product Code Setting
                //+++ this.ProductCDSetting = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_SETTING);

                this._defaultFractionType = (FractionType)int.Parse(configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                // Description: Add
                // Author: ISV-PHUONG
                // Date  : 2014/12/10
                // ---------------------- Start ------------------------------
                this.ProductCdUsed = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
                // ---------------------- End   ------------------------------

                //---------------Add 2014/12/29 ISV-Nguyen-------------------------//
                SettingService settingService = new SettingService(db);
                var settingFile = settingService.GetData();
                this.ListAcceptReportFile = new List<string>();
                if (!string.IsNullOrEmpty(settingFile.AcceptanceReportFile1) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.AcceptanceReportFile1))
                {
                    this.ListAcceptReportFile.Add(settingFile.AcceptanceReportFile1);
                }
                if (!string.IsNullOrEmpty(settingFile.AcceptanceReportFile2) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.AcceptanceReportFile2))
                {
                    this.ListAcceptReportFile.Add(settingFile.AcceptanceReportFile2);
                }
                if (!string.IsNullOrEmpty(settingFile.AcceptanceReportFile3) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.AcceptanceReportFile3))
                {
                    this.ListAcceptReportFile.Add(settingFile.AcceptanceReportFile3);
                }
                if (!string.IsNullOrEmpty(settingFile.AcceptanceReportFile4) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.AcceptanceReportFile4))
                {
                    this.ListAcceptReportFile.Add(settingFile.AcceptanceReportFile4);
                }
                if (!string.IsNullOrEmpty(settingFile.AcceptanceReportFile5) && File.Exists(Server.MapPath("~") + "/TemplateExcel/" + settingFile.AcceptanceReportFile5))
                {
                    this.ListAcceptReportFile.Add(settingFile.AcceptanceReportFile5);
                }

                this.rptListAcceptReportFile.DataSource = this.ListAcceptReportFile;
                this.rptListAcceptReportFile.DataBind();
                //---------------Add 2014/12/29 ISV-Nguyen-------------------------//

                if (!this.IsPostBack)
                {
                    var deliDate = db.NowDate;
                    var expiryDay = configDSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Delivery));

                    //------------- Edited by ISV-Giam 2015/01/06 --------------
                    //Set Delivery Date
                    this.txtDeliveryDateHeader.Value = deliDate;

                    //Set Expiry Date
                    if (!expiryDay.HasValue)
                    {
                        this.txtExpiryDateHeader.Value = null;
                    }
                    else
                    {
                        var expiryDate = deliDate.AddDays(expiryDay.Value);
                        this.txtExpiryDateHeader.Value = expiryDate;
                    }
                    //----------------------------------------------------------
                }
            }
        }

        /// <summary>
        /// Get Detail Data on Screen
        /// </summary>
        /// <param name="includeDelete">false: only get row not check delete, true: get all include had check delete</param>
        /// <returns></returns>
        private IList<DeliveryDetailInfo> GetDetailData(bool includeEmpty = true, bool includeDelete = true)
        {
            this.isDetailEmpty = true;
            IList<DeliveryDetailInfo> ret = new List<DeliveryDetailInfo>();
            this._indexSell = 1;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                HtmlInputCheckBox chkSellDel = (HtmlInputCheckBox)item.FindControl("chkSellDel");

                if (!includeDelete && chkSellDel.Checked)
                {
                    continue;
                }

                DeliveryDetailInfo detail = this.GetDetailRow(item);
                if (includeEmpty)
                {
                    if (!detail.IsEmpty())
                    {
                        this.isDetailEmpty = false;
                    }
                    else
                    {
                        detail.VatRatio = decimal.Parse(this.DefaultVAT);
                    }
                    ret.Add(detail);
                }
                else
                {
                    if (!detail.IsEmpty())
                    {
                        this.isDetailEmpty = false;
                        ret.Add(detail);
                    }
                }
            }

            //Reset index for row
            if (!includeEmpty)
            {
                foreach (var deli in ret)
                {
                    deli.No = this._indexSell++;
                    foreach (var seri in deli.SerialList)
                    {
                        seri.DetailNo = deli.No;
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Get Detail Row
        /// </summary>
        /// <param name="repeaterItem"></param>
        /// <returns></returns>
        private DeliveryDetailInfo GetDetailRow(RepeaterItem repeaterItem)
        {
            HiddenField hidNo = (HiddenField)repeaterItem.FindControl("hidNo");
            var rowNo = int.Parse(hidNo.Value);
            HiddenField hidSalesSellID = (HiddenField)repeaterItem.FindControl("hidSalesSellID");
            var salesSellID = int.Parse(hidSalesSellID.Value);

            DeliveryDetailInfo detail = new DeliveryDetailInfo();

            HtmlInputCheckBox chkSellDel = (HtmlInputCheckBox)repeaterItem.FindControl("chkSellDel");
            var methodVAT = this.cmbMethodVat.SelectedValue;
            if (this._actionMode == ActionMode.MethodChanged)
            {
                methodVAT = this.GetValueViewState<T_Delivery_H>("HEADER").MethodVat.ToString();
            }

            detail.SerialList = new List<SerialInfo>();
            detail.SerialEmptyFlg = true;
            detail.Checked = chkSellDel.Checked;
            detail.No = rowNo;
            detail.SalesSellID = salesSellID;

            //InternalID
            HiddenField hidDetailID = (HiddenField)repeaterItem.FindControl("hidDetailID");
            detail.InternalID = Convert.ToInt32(hidDetailID.Value);

            //SellProductID
            HiddenField hidSellProductID = (HiddenField)repeaterItem.FindControl("hdProductID");
            detail.ProductID = Convert.ToInt32(hidSellProductID.Value);

            //SellProductCD
            ICodeTextBox txtSellProductCD = (ICodeTextBox)repeaterItem.FindControl("txtProductCD");
            detail.ProductCD = txtSellProductCD.Value;

            //SellProductName
            ITextBox txtSellProductName = (ITextBox)repeaterItem.FindControl("txtProductName");
            detail.ProductName = txtSellProductName.Value;

            //SellDescription
            ITextBox txtSellDescription = (ITextBox)repeaterItem.FindControl("txtDescription");
            detail.Description = txtSellDescription.Value;

            //SellUnit
            DropDownList cmbSellUnit = (DropDownList)repeaterItem.FindControl("cmbUnit");
            HiddenField hdUnit = (HiddenField)repeaterItem.FindControl("hdUnit");
            if (this.Mode != Mode.Check)
            {
                detail.UnitID = Convert.ToInt32(cmbSellUnit.SelectedValue);
            }
            else
            {
                detail.UnitID = Convert.ToInt32(hdUnit.Value);
            }

            //SellPrice
            INumberTextBox txtSellPrice = (INumberTextBox)repeaterItem.FindControl("txtUnitPrice");
            detail.UnitPrice = txtSellPrice.Value;

            //SellQuantity
            INumberTextBox txtSellQuantity = (INumberTextBox)repeaterItem.FindControl("txtQuantity");
            detail.Quantity = txtSellQuantity.Value;

            //DeliQuantity
            INumberTextBox txtDeliQuantity = (INumberTextBox)repeaterItem.FindControl("txtDeliQuantity");
            detail.DeliveryQuantity = txtDeliQuantity.Value;

            //DeliveryDate
            IDateTextBox txtDeliveryDate = (IDateTextBox)repeaterItem.FindControl("txtDeliveryDate");
            detail.DeliveryDate = txtDeliveryDate.Value;

            //Get Remain Quantity
            if (!this.txtSalesNo.IsEmpty)
            {
                using (DB db = new DB())
                {
                    Sales_HService accHSrv = new Sales_HService(db);
                    T_Sales_H accH = accHSrv.GetBySalesNo(this.txtSalesNo.Value);
                    if (accH != null)
                    {
                        Delivery_DService deliveryDSrv = new Delivery_DService(db);
                        detail.RemainQty = deliveryDSrv.GetRemainQtyBySalesSellID(salesSellID, this.DataID);
                    }
                }
                this.HasSales = true;
            }

            //SellTotal
            INumberTextBox txtSellTotal = (INumberTextBox)repeaterItem.FindControl("txtTotal");
            detail.Total = txtSellTotal.Value;

            //SellRemark
            ITextBox txtSellRemark = (ITextBox)repeaterItem.FindControl("txtRemark");
            detail.Remark = txtSellRemark.Value;

            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
            {
                //SellVat
                INumberTextBox txtSellVat = (INumberTextBox)repeaterItem.FindControl("txtVAT");
                detail.VAT = txtSellVat.Value;

                //VatType
                DropDownList cmbSellVatType = (DropDownList)repeaterItem.FindControl("cmbVatType");
                HiddenField hdVatType = (HiddenField)repeaterItem.FindControl("hdVatType");

                if (this.Mode == Mode.Check || (this.Mode == Mode.Update && this.HasSales))
                {
                    cmbSellVatType.SelectedValue = hdVatType.Value;
                }

                if (!string.IsNullOrEmpty(cmbSellVatType.SelectedValue))
                {
                    detail.VatType = short.Parse(cmbSellVatType.SelectedValue);
                }

                //SellVatRatio
                INumberTextBox txtSellVatRatio = (INumberTextBox)repeaterItem.FindControl("txtVatRatio");
                detail.VatRatio = txtSellVatRatio.Value;
            }
            if (this.DefaultSerialHidden == (int)SerialHidden.Show)
            {
                Repeater serial = (Repeater)repeaterItem.FindControl("rptSerial");
                var serialNo = 1;
                foreach (RepeaterItem itemSerial in serial.Items)
                {
                    //Serial
                    ITextBox txtSerial = (ITextBox)itemSerial.FindControl("txtSerial");

                    //Terms
                    INumberTextBox txtTerms = (INumberTextBox)itemSerial.FindControl("txtTerms");

                    //UnitSerial
                    DropDownList cmbUnitSerial = (DropDownList)itemSerial.FindControl("cmbUnitSerial");
                    HiddenField hdUnitSerial = (HiddenField)itemSerial.FindControl("hdUnitSerial");

                    //cmbContractType
                    DropDownList cmbContractType = (DropDownList)itemSerial.FindControl("cmbContractType");
                    HiddenField hdContractType = (HiddenField)itemSerial.FindControl("hdContractType");
                    if (this.Mode == Mode.Check)
                    {
                        cmbUnitSerial.SelectedValue = hdUnitSerial.Value;
                        cmbContractType.SelectedValue = hdContractType.Value;
                    }

                    //SerialFinishDate
                    IDateTextBox txtSerialFinishDate = (IDateTextBox)itemSerial.FindControl("txtSerialFinishDate");
                    IDateTextBox txtSerialStartDate = (IDateTextBox)itemSerial.FindControl("txtSerialStartDate");

                    SerialInfo serialInfo = new SerialInfo();
                    serialInfo.No = serialNo++;
                    serialInfo.DetailNo = detail.No;
                    serialInfo.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                    serialInfo.SerialNo = txtSerial.Value;
                    serialInfo.Terms = txtTerms.Value;
                    serialInfo.ContractType = short.Parse(cmbContractType.SelectedItem.Value);
                    serialInfo.TermUnit = Convert.ToInt32(cmbUnitSerial.SelectedItem.Value);
                    serialInfo.FinishDate = txtSerialFinishDate.Value;
                    serialInfo.StartDate = txtSerialStartDate.Value;
                    detail.SerialEmptyFlg = detail.SerialEmptyFlg && serialInfo.IsEmpty(short.Parse(this._defaultContractType));

                    detail.SerialList.Add(serialInfo);
                }
            }
            else
            {
                using (DB db = new DB())
                {
                    TDeliverySerialService serialSer = new TDeliverySerialService(db);
                    var lstSerialDB = serialSer.GetListByKey(int.Parse(hidDetailID.Value));
                    if (lstSerialDB.Count != 0)
                    {
                        foreach (var item in lstSerialDB)
                        {
                            SerialInfo serialInfo = new SerialInfo();
                            serialInfo.No = item.No;
                            serialInfo.DetailNo = detail.No;
                            serialInfo.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                            serialInfo.SerialNo = item.SerialNo;
                            serialInfo.Terms = item.Terms;
                            serialInfo.TermUnit = item.TermUnit;
                            serialInfo.ContractType = item.ContractType;
                            serialInfo.FinishDate = item.FinishDate;
                            serialInfo.StartDate = item.StartDate;
                            detail.SerialList.Add(serialInfo);
                        }
                    }
                }
            }

            return detail;
        }

        /// <summary>
        /// Set empty data for mode copy
        /// </summary>
        private void SetEmptyDataForCopyMode()
        {
            //Header
            this.txtDeliveryNo.Value = string.Empty;
            this.txtSalesNo.Value = string.Empty;
            this.txtQuotationNo.Value = string.Empty;
            this.HasSales = false;
            if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtPrepareCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPrepareName.Value = base.LoginInfo.User.UserName2;
            }
            using (DB db = new DB())
            {
                Config_DService configDSer = new Config_DService(db);
                var deliDate = db.NowDate;
                var expiryDay = configDSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Delivery));

                //------------- Edited by ISV-Giam 2015/01/06 --------------
                //Set Delivery Date
                this.txtDeliveryDateHeader.Value = deliDate;

                //Set Expiry Date
                if (!expiryDay.HasValue)
                {
                    this.txtExpiryDateHeader.Value = null;
                }
                else
                {
                    var expiryDate = deliDate.AddDays(expiryDay.Value);
                    this.txtExpiryDateHeader.Value = expiryDate;
                }
                //----------------------------------------------------------
            }
            //Footer
            this.txtIssueDate.Value = string.Empty;
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;

            foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
            {
                //DeliQuantity
                INumberTextBox txtDeliQuantity = (INumberTextBox)repeaterItem.FindControl("txtDeliQuantity");
                txtDeliQuantity.Value = null;

                //DeliveryDate
                IDateTextBox txtDeliveryDate = (IDateTextBox)repeaterItem.FindControl("txtDeliveryDate");
                txtDeliveryDate.Value = null;
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.FocusControlId = this.txtCustomerCD.ID;
                    //Init Data
                    this.InitData();
                    break;

                case Mode.Copy:
                    this.FileAttachedCount = 0;
                    this.FocusControlId = this.txtCustomerCD.ID;
                    this.txtCustomerCD.SetReadOnly(false);
                    this.SetEmptyDataForCopyMode();
                    break;

                case Mode.Update:
                    if (this.HasSales)
                    {
                        this.txtCustomerCD.SetReadOnly(true);
                        this.FocusControlId = this.txtAttn.ID;
                    }
                    else
                    {
                        this.FocusControlId = this.txtCustomerCD.ID;
                    }
                    break;

                case Mode.Delete:

                    this.txtCustomerCD.SetReadOnly(true);
                    break;

                case Mode.Check:
                    this.FocusControlId = "txtDeliQuantity_0";

                    break;

                case Mode.View:

                    base.DisabledLink(this.btnEdit, !base._authority.IsDeliveryEdit);
                    //base.DisabledLink(this.btnIssue, !base._authority.IsDeliveryPDF);
                    //base.DisabledLink(this.btnAcceptanceReport, !base._authority.IsDeliveryPDF);
                    base.DisabledLink(this.btnCheck, !base._authority.IsDeliveryCheck);
                    base.DisabledLink(this.btnCopy, !base._authority.IsDeliveryCopy);
                    base.DisabledLink(this.btnDelete, !base._authority.IsDeliveryDelete);

                    break;

                default:
                    break;
            }

            var methodVAT = this.cmbMethodVat.SelectedValue;

            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
            {
                //SellVatRatio
                this.txtTotalVatRatio.SetReadOnly(true);
                //VatType
                this.cmbTotalVatType.Enabled = false;

                this.txtTotalVatRatio.Value = null;
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeListEmpty);
            }
            else
            {
                //TotalVatRatio
                this.txtTotalVatRatio.SetReadOnly(false);
                //VatType
                this.cmbTotalVatType.Enabled = true;

                //SUM
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTotalTypeList);
                if (int.Parse(this.cmbTotalVatType.SelectedValue) != (int)VATFlg.Exclude)
                {
                    this.txtTotalVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(true);
                    this.txtTotalVatRatio.Value = null;
                }
                else
                {
                    this.txtTotalVatRatio.SetReadOnly(false);
                    this.txtSumVat.SetReadOnly(false);
                    if (!this.txtTotalVatRatio.Value.HasValue)
                    {
                        this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
                    }
                }
            }

            var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
            var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
            this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            // Description: Add
            // Author: ISV-NGUYEN
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            this.txtCustomerName.SetReadOnly(true);
            if (this.txtCustomerCD.Value == Models.M_Customer.CUSTOMER_CODE_SUPPORT && this.txtSalesNo.IsEmpty)
            {
                this.txtCustomerName.SetReadOnly(false);
            }
            // ---------------------- End  -------------------------------
        }

        /// <summary>
        /// Update Data for Mode Check quantity
        /// </summary>
        /// <returns></returns>
        private bool UpdateDataCheck()
        {
            try
            {
                IList<DeliveryDetailInfo> lstDetailScreen = this.GetDetailData();

                //Get Delivery
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var id = this.DataID;

                    Delivery_HService hService = new Delivery_HService(db);
                    Delivery_DService dService = new Delivery_DService(db);
                    TDeliverySerialService sService = new TDeliverySerialService(db);
                    Sales_HService salesService = new Sales_HService(db);

                    IList<T_Delivery_D> lstDetailDB = dService.GetListByHID(id);

                    //Get header
                    var header = hService.GetByID(id);

                    //Hashtable save list Serial of all detail
                    Hashtable hashSerial = new Hashtable();

                    //List Serial in DB
                    IList<T_Delivery_Serial> lstSerialDB = sService.GetList();

                    //List Shipping for update
                    IList<T_Delivery_D> shipLst = null;
                    bool isFinishCheck = false;
                    var detailChanged = this.CreateDetailDataForUpdate(lstDetailScreen, lstDetailDB, lstSerialDB, ref hashSerial, ref shipLst, ref isFinishCheck);
                    if (detailChanged)
                    {
                        //update sales
                        T_Sales_H sales = salesService.GetBySalesNo(header.SalesNo);
                        if (sales != null)
                        {
                            sales.VersionUpdateDate = this.OldVersionUpdateDate;
                            sales.VersionUpdateUID = LoginInfo.User.ID;
                            if (salesService.UpdateVersion(sales) <= 0)
                            {
                                //data has changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }

                        header.FinishFlag = short.Parse(isFinishCheck ? "1" : "0");
                        header.UpdateDate = this.OldUpdateDate;
                        header.UpdateUID = LoginInfo.User.ID;
                        if (hService.UpdateFinishFlag(header) <= 0)
                        {
                            //data has changed
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        List<T_Delivery_D> insDataList = new List<T_Delivery_D>();
                        //Get data insert
                        for (int i = shipLst.Count - 1; i >= 0; i--)
                        {
                            var item = shipLst[i];
                            if (item.InternalID == -1)
                            {
                                insDataList.Add(item);
                                shipLst.RemoveAt(i);
                            }
                        }

                        var no = lstDetailDB.Count + shipLst.Count;

                        //Delete database when data not exists on screen
                        Hashtable updDataHtb = new Hashtable();
                        foreach (var item in shipLst)
                        {
                            updDataHtb.Add(item.InternalID, item.HID);
                        }

                        for (int i = lstDetailDB.Count - 1; i >= 0; i--)
                        {
                            var item = lstDetailDB[i];
                            if (!updDataHtb.ContainsKey(item.InternalID))
                            {
                                dService.DeleteByInternalID(item.InternalID);
                                lstDetailDB.RemoveAt(i);

                                //Delete serial no
                                sService.DeleteByID(item.InternalID);
                            }
                        }

                        //update no in database to greater number
                        foreach (var item in lstDetailDB)
                        {
                            dService.UpdateNoByInternalID(item.InternalID, no);
                            no += 1;
                        }

                        //Update data
                        foreach (var item in shipLst)
                        {
                            item.HID = id;
                            dService.Update(item);

                            List<T_Delivery_Serial> seriLst = (List<T_Delivery_Serial>)hashSerial[item.InternalID];
                            if (seriLst != null && seriLst.Count > 0)
                            {
                                sService.DeleteByID(item.InternalID);
                                foreach (var seItem in seriLst)
                                {
                                    seItem.DeliveryDID = item.InternalID;
                                    sService.Insert(seItem);
                                }
                            }
                            else
                            {
                                sService.DeleteByID(item.InternalID);
                            }
                        }

                        //Insert data
                        foreach (var item in insDataList)
                        {
                            item.HID = id;
                            var shipDetailID = dService.Insert(item);
                            List<T_Delivery_Serial> seriLst = (List<T_Delivery_Serial>)hashSerial[item.InternalID];
                            if (seriLst != null && seriLst.Count > 0)
                            {
                                foreach (var seItem in seriLst)
                                {
                                    seItem.DeliveryDID = shipDetailID;
                                    sService.Insert(seItem);
                                }
                            }
                        }
                        //Edit:-----ISV-HUNG-----Change update internalID--------------//

                        if (sales != null)
                        {
                            //Update Finish Flag
                            if (salesService.UpdateFinishFlag(sales) <= 0)
                            {
                                //data has changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }

                        db.Commit();
                        return true;
                    }

                    return true;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
        }

        /// <summary>
        /// Copy List Info To List Entity
        /// </summary>
        /// <param name="lstInput"></param>
        /// <returns></returns>
        private List<T_Delivery_D> CopyDataDetail(List<DeliveryDetailInfo> lstInput)
        {
            List<T_Delivery_D> ret = null;
            if (lstInput != null)
            {
                ret = new List<T_Delivery_D>();
                foreach (DeliveryDetailInfo item in lstInput)
                {
                    T_Delivery_D ship = new T_Delivery_D();
                    ship.No = item.No;
                    ship.ProductID = item.ProductID;
                    ship.ProductCD = item.ProductCD;
                    ship.ProductName = item.ProductName;
                    ship.Quantity = item.Quantity.Value;
                    ship.Remark = item.Remark;
                    ship.SalesSellID = item.SalesSellID;
                    ship.DeliveryDate = item.DeliveryDate.GetValueOrDefault();
                    ship.DeliveryQuantity = item.DeliveryQuantity.GetValueOrDefault();
                    ship.Description = item.ProductCD;
                    ship.Total = item.Total.GetValueOrDefault();
                    ship.UnitID = item.UnitID;
                    ship.UnitPrice = item.UnitPrice.GetValueOrDefault();
                    ship.VAT = item.VAT.Value;
                    ship.VATRatio = item.VatRatio.GetValueOrDefault();
                    ship.VATType = item.VatType;
                    ret.Add(ship);
                }
            }
            return ret;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtPrepareCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPrepareName.Value = base.LoginInfo.User.UserName2;
            }

            this.cmbMethodVat.SelectedValue = this._defaultMethodVat;
            this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
            this.ViewState["HEADER"] = new T_Delivery_H
            {
                MethodVat = short.Parse(this._defaultMethodVat),
                CurrencyID = Constant.DEFAULT_ID
            };

            int defaultVatType = int.Parse(this._defaultVatType);
            if (this._defaultMethodVat == M_Config_D.METHOD_VAT_SUM)
            {
                this.cmbTotalVatType.SelectedValue = defaultVatType.ToString();
                defaultVatType = -1;
            }

            List<DeliveryDetailInfo> details = new List<DeliveryDetailInfo>();

            DeliveryDetailInfo item = new DeliveryDetailInfo();
            //item.NoDisp = 1;
            item.No = ++this._indexSell;
            item.VatType = (short)defaultVatType;
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                item.VatRatio = decimal.Parse(this.DefaultVAT);
            }

            item.SerialList = new List<SerialInfo>();
            SerialInfo serial = new SerialInfo();
            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            serial.No = 1;
            serial.ContractType = short.Parse(this._defaultContractType);
            serial.DetailNo = item.No;
            serial.StartDate = null;
            serial.FinishDate = null;
            item.SerialList.Add(serial);
            details.Add(item);

            this.rptDetail.DataSource = details;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Init Model Detail
        /// </summary>
        /// <returns></returns>
        private DeliveryDetailInfo InitModelDetail()
        {
            DeliveryDetailInfo detail = new DeliveryDetailInfo();
            detail.No = 1;
            detail.VatRatio = decimal.Parse(this.DefaultVAT);
            detail.SerialList = new List<SerialInfo>();
            SerialInfo serial = new SerialInfo();
            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            serial.No = 1;
            serial.ContractType = short.Parse(this._defaultContractType);
            serial.FinishDate = null;
            serial.StartDate = null;
            serial.DetailNo = detail.No;
            detail.SerialList.Add(serial);
            return detail;
        }

        /// <summary>
        /// Check Input Data For Delivery Check
        /// </summary>
        /// <returns></returns>
        private bool CheckInputDeliveryCheck()
        {
            var details = this.GetDetailData();

            for (int i = 0; i < details.Count; i++)
            {
                var item = details[i];
                if (item.DeliveryQuantity.HasValue && item.DeliveryQuantity > item.Quantity)
                {
                    //txtDeliQuantity
                    this.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Deli Q'ty", item.Quantity.Value.ToString(string.Format("N{0}", this.QtyDecDigit)), item.No);
                }

                if (item.DeliveryDate == null && item.DeliveryQuantity != null)
                {
                    //DeliveryDate
                    this.SetMessage(string.Format("txtDeliveryDate_{0}", i), M_Message.MSG_REQUIRE_GRID, "Deli Date", item.No);
                }

                if (item.DeliveryDate != null && item.DeliveryQuantity == null)
                {
                    //txtDeliQuantity
                    this.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Deli Q'ty", item.No);
                }

                //Check DeliveryDate with Shipping Date
                if (item.DeliveryDate != null && item.DeliveryDate < this.txtDeliveryDateHeader.Value)
                {
                    this.SetMessage(string.Format("txtDeliveryDate_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Deli Date", "Delivery Date", item.No);
                }

                if (item.DeliveryQuantity != null && item.DeliveryQuantity.Value == 0)
                {
                    this.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Deli Q'ty", 0, item.No);
                }
            }
            this.RefreshDetails(details);

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Set Delivery Info on Screen
        /// </summary>
        /// <param name="id"></param>
        private void SetDeliveryInfo(int id)
        {
            using (DB db = new DB())
            {
                Delivery_HService hService = new Delivery_HService(db);
                Delivery_DService dService = new Delivery_DService(db);
                Delivery_CService condService = new Delivery_CService(db);
                TDeliverySerialService serialService = new TDeliverySerialService(db);

                var header = hService.GetByID(id);

                this.txtCustomerCD.Value = header.CustomerCD;
                // Description: Add
                // Author: ISV-NGUYEN
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                if (header.CustomerCD == Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    this.txtCustomerName.SetReadOnly(false);
                }
                // ---------------------- End  -------------------------------
                this.txtCustomerName.Value = header.CustomerName;

                this.txtAttn.Value = header.ContactPerson;

                this.txtAdd1.Value = header.CustomerAddress1;
                this.txtAdd2.Value = header.CustomerAddress2;
                this.txtAdd3.Value = header.CustomerAddress3;
                // Description: Add
                // Author: ISV-NGUYEN
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                this.txtPosition.Value = header.Position;
                this.txtConfirmed.Value = header.Confirmed;
                // ---------------------- End  -------------------------------

                this.txtTel.Value = header.Tel;
                this.txtFax.Value = header.Fax;
                this.txtSubject.Value = header.SubjectName;
                this.Deleted = header.DeleteFlag == (int)DeleteFlag.Deleted;
                this.Finished = header.FinishFlag == (int)FinishedFlag.Finished;
                this.txtDeliveryPlace.Value = header.DeliveryPlace;
                this.txtDeliveryDateHeader.Value = header.DeliveryDate;
                if (header.ExpiryDate == DEFAULT_DATE_TIME)
                {
                    this.txtExpiryDateHeader.Value = null;
                }
                else
                {
                    this.txtExpiryDateHeader.Value = header.ExpiryDate;
                }
                this.txtPrepareCD.Value = header.PreparedCD;
                this.txtPrepareName.Value = header.PreparedName;
                this.txtApprovedCD.Value = header.ApprovedCD;
                this.txtApprovedName.Value = header.ApprovedName;
                this.txtDeliveryName.Value = header.DelivererName;
                this.txtGrandTotal.Value = header.GrandTotal;
                this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();
                this.cmbMethodVat.SelectedValue = header.MethodVat.ToString();
                this.txtMemo.Value = header.Memo;
                this.txtSalesNo.Value = header.SalesNo;
                this.chkDelAll.Checked = false;
                this.txtAcceptanceNo.Value = header.AcceptanceNo;
                if (header.AcceptanceDate == DEFAULT_DATE_TIME)
                {
                    this.txtAcceptanceDate.Value = null;
                }
                else
                {
                    this.txtAcceptanceDate.Value = header.AcceptanceDate;
                }

                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
                {
                    this.cmbTotalVatType.SelectedValue = header.VatType.ToString();
                    this.txtTotalVatRatio.Value = header.VatRatio;
                    if (this.cmbTotalVatType.SelectedValue == ((int)VATFlg.Exclude).ToString())
                    {
                        this.txtSumVat.Value = header.VAT;
                    }
                }
                else
                {
                    this.txtSumVat.Value = header.VAT;
                }
                this.txtSumTotal.Value = header.Total;
                this.txtGrandTotal.Value = header.GrandTotal;

                //Save UserID and UpdateDate
                this.DataID = header.ID;
                this.OldUpdateDate = header.UpdateDate;

                this.txtDeliveryNo.Value = header.DeliveryNo;
                this.txtSalesNo.Value = header.SalesNo;
                this.txtQuotationNo.Value = header.QuoteNo;
                this.HasSales = string.IsNullOrEmpty(header.SalesNo) ? false : true;
                Sales_HService salesService = new Sales_HService(db);
                T_Sales_H salesH = salesService.GetBySalesNo(header.SalesNo);
                if (salesH != null)
                {
                    this.OldVersionUpdateDate = salesH.VersionUpdateDate;
                }

                AttachedService attachedService = new AttachedService(db);
                this.FileAttachedCount = attachedService.CountFile(this.DataID, (int)FType.Delivery);

                this.txtConditionCD.Value = string.Empty;
                T_Delivery_C model = condService.GetByID(header.ID);
                if (model != null)
                {
                    //Load Condition
                    this.txtConditions.Value = model.Conditions;
                    this.OldCondition = model.Conditions;
                }

                UserService userService = new UserService(db);

                ////Issue
                var issueUser = userService.GetByID(header.IssuedUID);
                if (issueUser != null)
                {
                    var issuedDate = (header.IssuedDate == DEFAULT_DATE_TIME) ? string.Empty : header.IssuedDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtIssueDate.Value = string.Format("{0} {1}", issueUser.UserName2, issuedDate);
                }
                else
                {
                    this.txtIssueDate.Value = string.Empty;
                }

                var updateUser = userService.GetByID(header.UpdateUID);
                if (updateUser != null)
                {
                    var updateDate = (header.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : header.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                else
                {
                    this.txtUpdateDate.Value = string.Empty;
                }

                ////Create
                var createUser = userService.GetByID(header.CreateUID);
                if (createUser != null)
                {
                    var createDate = (header.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : header.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }
                else
                {
                    this.txtCreateDate.Value = string.Empty;
                }

                this.ViewState["HEADER"] = header;

                this._indexSell = 0;
                var detailModel = dService.GetListByHID(id);
                var serialModel = serialService.GetList();
                var details = new List<DeliveryDetailInfo>(detailModel.Select(s => new DeliveryDetailInfo
                {
                    InternalID = s.InternalID,
                    No = s.No,
                    SalesSellID = s.SalesSellID,
                    ProductID = s.ProductID,
                    ProductCD = s.ProductCD,
                    ProductName = s.ProductName,
                    Description = s.Description,
                    DeliveryDate = s.DeliveryDate,
                    DeliveryQuantity = s.DeliveryQuantity,
                    UnitPrice = s.UnitPrice,
                    Quantity = s.Quantity,
                    Total = s.Total,
                    VAT = s.VAT,
                    VatType = s.VATType,
                    UnitID = s.UnitID,
                    Remark = s.Remark,
                    VatRatio = s.VATRatio,

                    SerialList = new List<SerialInfo>(serialModel.Where(c => c.DeliveryDID == s.InternalID).Select(c => new SerialInfo
                    {
                        No = ++this._indexSell,
                        DeliveryID = c.DeliveryDID,
                        DetailNo = s.No,
                        SerialNo = c.SerialNo,
                        Terms = c.Terms,
                        TermUnit = c.TermUnit,
                        StartDate = c.StartDate,
                        FinishDate = c.FinishDate,
                        ContractType = c.ContractType,

                        Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty,
                    }))
                }));

                foreach (var item in details)
                {
                    if (item.DeliveryDate == DEFAULT_DATE_TIME)
                    {
                        item.DeliveryDate = null;
                    }
                    if (item.DeliveryQuantity == 0)
                    {
                        item.DeliveryQuantity = null;
                    }

                    if (item.SalesSellID != 0)
                    {
                        item.RemainQty = dService.GetRemainQtyBySalesSellID(item.SalesSellID, this.DataID);
                    }
                    else
                    {
                        item.RemainQty = null;
                    }
                    //********************
                    if (item.SerialList == null || item.SerialList.Count == 0)
                    {
                        SerialInfo serial = new SerialInfo();
                        serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                        serial.No = 1;
                        serial.DetailNo = item.No;
                        serial.ContractType = short.Parse(this._defaultContractType);
                        serial.StartDate = null;
                        serial.FinishDate = null;
                        item.SerialList.Add(serial);
                    }
                    else
                    {
                        int indexSeri = 1;
                        foreach (var seriItem in item.SerialList)
                        {
                            seriItem.No = indexSeri++;
                            if (seriItem.StartDate == DEFAULT_DATE_TIME)
                            {
                                seriItem.StartDate = null;
                            }
                            if (seriItem.FinishDate == DEFAULT_DATE_TIME)
                            {
                                seriItem.FinishDate = null;
                            }
                            
                            if (seriItem.Terms == 0)
                            {
                                seriItem.Terms = null;
                            }
                        }
                    }
                }

                this.RefreshDetails(details);
            }
        }

        /// <summary>
        /// Refresh Details
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails(IList<DeliveryDetailInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailData();
            }
            this.rptDetail.DataSource = dataSource;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Init DropDownList Data
        /// </summary>
        /// <param name="dropDownList"></param>
        /// <param name="data"></param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Up or Down Item
        /// </summary>
        /// <param name="up">Up Flg</param>
        private void SwapDetail(bool up)
        {
            IList<DeliveryDetailInfo> details = this.GetDetailData();

            if (details.Count == 0)
            {
                return;
            }

            IList<DeliveryDetailInfo> results = new List<DeliveryDetailInfo>();

            if (up)
            {
                results.Add(details.First());
                for (int i = 1; i < details.Count; i++)
                {
                    var item = details[i];
                    var itemPre = results[i - 1];

                    if (item.Checked)
                    {
                        if (itemPre.Checked)
                        {
                            results.Add(item);
                        }
                        else
                        {
                            results.Insert(i - 1, item);
                        }
                    }
                    else
                    {
                        results.Add(item);
                    }
                }
            }
            else
            {
                results.Add(details.Last());
                for (int i = details.Count - 2; i >= 0; i--)
                {
                    var item = details[i];
                    if (item.Checked)
                    {
                        if (results[0].Checked)
                        {
                            results.Insert(0, item);
                        }
                        else
                        {
                            results.Insert(1, item);
                        }
                    }
                    else
                    {
                        results.Insert(0, item);
                    }
                }
            }

            this._indexSell = 1;
            for (int i = 0; i < results.Count; i++)
            {
                var row = results[i];
                row.No = this._indexSell++;
                // row.NoDisp = row.No;
                foreach (var seri in row.SerialList)
                {
                    seri.DetailNo = row.No;
                }
            }

            if (this.HasSales)
            {
                var delivery = this.GetDelivery(this.DataID);
                if (delivery != null)
                {
                    this.cmbTotalVatType.SelectedValue = delivery.VatType.ToString();
                }
            }

            this.rptDetail.DataSource = results;
            this.rptDetail.DataBind();
        }

        #region Check Input

        /// <summary>
        /// Check Customer has error
        /// </summary>
        /// <param name="customerCD"></param>
        /// <returns>true : has error, false : has not error</returns>
        private bool CheckCustomer(string customerCD, string customerID, DB db)
        {
            if (string.IsNullOrEmpty(customerCD))
            {
                this.SetMessage(customerID, M_Message.MSG_REQUIRE, "Customer Code");
                return true;
            }
            else
            {
                if (!string.Equals(this.txtCustomerCD.Value, Models.M_Customer.CUSTOMER_CODE_SUPPORT))
                {
                    CustomerService cusSer = new CustomerService(db);
                    M_Customer c = cusSer.GetByCustomerCD(customerCD);
                    if (c != null)
                    {
                        if ((int)c.StatusFlag == (int)DeleteFlag.Deleted)
                        {
                            this.SetMessage(customerID, M_Message.MSG_CODE_DISABLE, "Customer Code");
                            return true;
                        }
                    }
                    else
                    {
                        this.SetMessage(customerID, M_Message.MSG_NOT_EXIST_CODE, "Customer Code");
                        return true;
                    }
                }
                // Description: Add
                // Author: ISV-NGUYEN
                // Date  : 2014/12/05
                // ---------------------- Start ------------------------------
                else
                {
                    if (this.txtCustomerName.IsEmpty)
                    {
                        this.SetMessage("txtCustomerName", M_Message.MSG_REQUIRE, "Customer Name");
                        return true;
                    }
                }
                // ---------------------- End  -------------------------------
            }
            return false;
        }

        /// <summary>
        /// Chech Delivery Date
        /// </summary>
        /// <returns></returns>
        private bool CheckDeliveryDate(DB db)
        {
            if (!this.txtDeliveryDateHeader.Value.HasValue)
            {
                this.SetMessage(this.txtDeliveryDateHeader.ID, M_Message.MSG_REQUIRE, "Delivery Date");
                return true;
            }
            //else
            //{
            //    if (!this.txtAcceptNo.IsEmpty)
            //    {
            //        Acceptance_HService acceptHSer = new Acceptance_HService(db);
            //        T_Accept_H acceptH = acceptHSer.GetByAcceptNo(this.txtAcceptNo.Value);
            //        if (acceptH != null)
            //        {
            //            if (acceptH.AcceptDate > this.txtShippingDate.Value.GetValueOrDefault())
            //            {
            //                this.SetMessage(this.txtShippingDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Delivery Date", "Accept Date");
            //                return true;
            //            }
            //        }

            //    }
            //}
            return false;
        }

        /// <summary>
        /// Check Delivered Date [Delivery is complete]
        /// </summary>
        /// <returns></returns>
        //private bool CheckDeliveredDate(DB db)
        //{
        //    if (!this.txtConfirmDate.Value.HasValue)
        //    {
        //        //this.SetMessage(this.txtConfirmDate.ID, M_Message.MSG_REQUIRE, "Confirm Date");
        //        //return true;
        //    }
        //    else
        //    {
        //        if (!this.txtAcceptNo.IsEmpty)
        //        {
        //            Acceptance_HService acceptHSer = new Acceptance_HService(db);
        //            T_Accept_H acceptH = acceptHSer.GetByAcceptNo(this.txtAcceptNo.Value);
        //            if (acceptH != null)
        //            {
        //                if (acceptH.AcceptDate > this.txtConfirmDate.Value.GetValueOrDefault())
        //                {
        //                    this.SetMessage(this.txtConfirmDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Confirm Date", "Accept Date");
        //                    return true;
        //                }
        //            }

        //            //Delivered Date have to greater Shipping Date
        //            if (this.txtConfirmDate.Value.GetValueOrDefault() < this.txtShippingDate.Value.GetValueOrDefault())
        //            {
        //                this.SetMessage(this.txtConfirmDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Confirm Date", "Delivery Date");
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}

        ///// <summary>
        ///// Check Prepared
        ///// </summary>
        ///// <param name="customerCD"></param>
        ///// <param name="customerID"></param>
        ///// <returns></returns>
        //private bool CheckPrepared(string preparedCD, string preparedID)
        //{
        //    if (string.IsNullOrEmpty(preparedCD))
        //    {
        //        this.SetMessage(preparedID, M_Message.MSG_REQUIRE, "Prepared Code");
        //        return true;
        //    }
        //    else
        //    {
        //        using (DB db = new DB())
        //        {
        //            UserService userSer = new UserService(db);
        //            M_User u = userSer.GetByUserCD(preparedCD, true);
        //            if (u != null)
        //            {
        //                if ((int)u.StatusFlag == (int)DeleteFlag.Deleted)
        //                {
        //                    this.SetMessage(preparedID, M_Message.MSG_CODE_DISABLE, "Prepared Code " + preparedCD);
        //                    return true;
        //                }

        //                if (u.LoginID.Equals(LOGIN_USER_ADMIN))
        //                {
        //                    this.SetMessage(preparedID, M_Message.MSG_NOT_EXIST_CODE, "Prepared Code" + preparedCD);
        //                    return true;
        //                }
        //            }
        //            else
        //            {
        //                this.SetMessage(preparedID, M_Message.MSG_NOT_EXIST_CODE, "Prepared Code" + preparedCD);
        //                return true;
        //            }
        //        }
        //    }
        //    return false;
        //}

        /// <summary>
        /// Check Approved
        /// </summary>
        /// <param name="approvedCD"></param>
        /// <param name="approvedID"></param>
        /// <returns></returns>
        //private bool CheckApproved(string approvedCD, string approvedID,ITextBox ctrlName, DB db)
        //{
        //    //*******con thieu check quyen approved trong config*******

        //    //**********************************************************
        //    if (string.IsNullOrEmpty(approvedCD))
        //    {
        //        this.SetMessage(approvedID, M_Message.MSG_REQUIRE, "Approved Code");
        //        ctrlName.Value = string.Empty;
        //        return true;
        //    }
        //    else
        //    {
        //        UserService userSer = new UserService(db);
        //        M_User u = userSer.GetByUserCD(approvedCD, true);
        //        if (u != null)
        //        {
        //            if ((int)u.StatusFlag == (int)DeleteFlag.Deleted)
        //            {
        //                this.SetMessage(approvedID, M_Message.MSG_CODE_DISABLE, "Approved Code " + approvedCD);
        //                ctrlName.Value = string.Empty;
        //                return true;
        //            }
        //        }
        //        else
        //        {
        //            this.SetMessage(approvedID, M_Message.MSG_NOT_EXIST_CODE, "Approved Code" + approvedCD);
        //            return true;
        //        }
        //    }
        //    return false;
        //}

        /// <summary>
        /// Check User Code
        /// </summary>
        /// <param name="userCD"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private bool CheckUserCD(string userCD, string userID, string userLabel, ITextBox ctrlName, DB db, bool isRequire)
        {
            if (isRequire)
            {
                if (string.IsNullOrEmpty(userCD))
                {
                    this.SetMessage(userID, M_Message.MSG_REQUIRE, userLabel);
                    ctrlName.Value = string.Empty;
                    return true;
                }
            }
            if (!string.IsNullOrEmpty(userCD))
            {
                UserService userSer = new UserService(db);
                M_User u = userSer.GetByUserCD(userCD, true);
                if (u == null || u.ID == Constant.DEFAULT_ID)
                {
                    this.SetMessage(userID, M_Message.MSG_NOT_EXIST_CODE, userLabel + " " + userCD);
                    ctrlName.Value = string.Empty;
                    return true;
                }
                else
                {
                    if ((int)u.StatusFlag == (int)DeleteFlag.Deleted)
                    {
                        this.SetMessage(userID, M_Message.MSG_CODE_DISABLE, userLabel + " " + userCD);
                        ctrlName.Value = string.Empty;
                        return true;
                    }
                    ctrlName.Value = u.UserName2;
                }
            }
            return false;
        }

        /// <summary>
        /// Check Currency
        /// </summary>
        /// <returns></returns>
        private bool CheckCurrency()
        {
            if (this.cmbCurrency.SelectedIndex == -1)
            {
                this.SetMessage(this.cmbCurrency.ID, M_Message.MSG_PLEASE_SELECT, "Currency");
                return true;
            }
            return false;
        }

        /// <summary>
        /// Check Input Data
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                //Check Customer
                this.CheckCustomer(this.txtCustomerCD.Value, this.txtCustomerCD.ID, db);
                //Check Shipping Date
                this.CheckDeliveryDate(db);
                //Check Expiry Date
                //if (this.txtExpiryDate.IsEmpty)
                //{
                //    this.SetMessage(txtExpiryDate.ID, M_Message.MSG_REQUIRE, "Expiry Date");
                //}
                //Check Expiry Date and Shipping Date
                //if (!this.txtShippingDate.IsEmpty && !this.txtExpiryDate.IsEmpty)
                //{
                //    var dateFrom = this.txtShippingDate.Value.GetValueOrDefault();
                //    var dateTo = this.txtExpiryDate.Value.GetValueOrDefault();
                //    if (dateTo.CompareTo(dateFrom) < 0)
                //    {
                //        this.SetMessage(txtExpiryDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Expiry Date", "Delivery Date");
                //    }
                //}
                //Check Subject Name
                if (this.txtSubject.IsEmpty)
                {
                    this.SetMessage(this.txtSubject.ID, M_Message.MSG_REQUIRE, "Subject");
                }

                //Check Prepared CD
                this.CheckUserCD(this.txtPrepareCD.Value, this.txtPrepareCD.ID, "Prepared Code", this.txtPrepareName, db, true);
                //Check Delivered Date
                //this.CheckDeliveredDate(db);
                //Check Approved CD
                //****this.CheckApproved(this.txtApprovedCD.Value, this.txtApprovedCD.ID, db);
                this.CheckUserCD(this.txtApprovedCD.Value, this.txtApprovedCD.ID, "Approved Code", this.txtApprovedName, db, true);
                ////Check Delivered CD
                //this.CheckUserCD(this.txtDeliveryCD.Value, this.txtDeliveryCD.ID, "Delivered code", this.txtDeliveryName, db, false);
                //Check Currency
                this.CheckCurrency();

                ProductService prodSrv = new ProductService(db);
                var isDecimal = this.IsDecimal(int.Parse(this.cmbCurrency.SelectedValue));

                var details = this.GetDetailData();
                var methodVAT = this.cmbMethodVat.SelectedValue;
                var maxValue = 0m;
                //if (details.Count == 1)
                //{
                //    if (details[0].IsEmpty())
                //    {
                //        this.SetMessage(string.Empty, M_Message.MSG_REQUIRE, "Product Code");
                //    }
                //}
                //else
                if (this.isDetailEmpty)
                {
                    // Author: ISV-PHUONG
                    // Date  : 2014/12/10
                    // ---------------------- Start ------------------------------
                    if (this.ProductCdUsed)
                    {
                        this.SetMessage(string.Format("txtProductCD_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Product Code", 1);
                    }
                    else
                    {
                        this.SetMessage(string.Format("txtProductName_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Product Name", 1);
                    }
                    // ---------------------- End   ------------------------------
                    this.SetMessage(string.Format("txtUnitPrice_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Unit Price", 1);
                    this.SetMessage(string.Format("txtQuantity_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Q'ty", 1);
                }
                else
                {
                    if (details.Count > 0)
                    {
                        #region Detail

                        for (int i = 0; i < details.Count; i++)
                        {
                            DeliveryDetailInfo detail = details[i];

                            if (!detail.IsEmpty())
                            {
                                // Author: ISV-PHUONG
                                // Date  : 2014/12/10
                                // ---------------------- Start ------------------------------
                                //Check sell product
                                //if (string.IsNullOrEmpty(detail.ProductCD))
                                if (this.ProductCdUsed && string.IsNullOrEmpty(detail.ProductCD))
                                {
                                    // ---------------------- End   ------------------------------
                                    this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Code", detail.No);
                                }
                                else
                                {
                                    //Product

                                    #region Product

                                    // Author: ISV-PHUONG
                                    // Date  : 2014/12/10
                                    // ---------------------- Start ------------------------------
                                    //if (detail.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                                    if (this.ProductCdUsed && detail.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                                    // ---------------------- End   ------------------------------
                                    {
                                        M_Product model = prodSrv.GetByCD(detail.ProductCD);
                                        if (model == null)
                                        {
                                            this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", detail.No);
                                        }
                                        else if (model.StatusFlag == (int)DeleteFlag.Deleted)
                                        {
                                            this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", detail.No);
                                        }
                                        else
                                        {
                                            if (string.IsNullOrEmpty(detail.ProductName))
                                            {
                                                detail.ProductName = model.ProductName;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (string.IsNullOrEmpty(detail.ProductName))
                                        {
                                            this.SetMessage(string.Format("txtProductName_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Name", detail.No);
                                        }
                                    }

                                    #endregion Product
                                }

                                //UnitPrice

                                #region UnitPrice

                                if (!detail.UnitPrice.HasValue)
                                {
                                    this.SetMessage(string.Format("txtUnitPrice_{0}", i), M_Message.MSG_REQUIRE_GRID, "Unit Price", detail.No);
                                }
                                else
                                {
                                    maxValue = isDecimal ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                                    var decimalDigit = isDecimal ? 2 : 0;
                                    string numberFormat = string.Format("N{0}", decimalDigit);
                                    if (detail.UnitPrice > maxValue)
                                    {
                                        this.SetMessage(string.Format("txtUnitPrice_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), detail.No);
                                    }
                                }

                                #endregion UnitPrice

                                //Quantity

                                #region Quantity

                                if (detail.Quantity.HasValue)
                                {
                                    //CHeck Quantity compare with Remain Quantity
                                    if (detail.RemainQty.HasValue)
                                    {
                                        if (detail.Quantity > detail.RemainQty)
                                        {
                                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", detail.RemainQty.Value.ToString(string.Format("N{0}", this.QtyDecDigit)), detail.No);
                                        }
                                    }
                                    else
                                    {
                                        maxValue = this.QtyDecDigit == 2 ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                                        if (detail.Quantity.Value > maxValue)
                                        {
                                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(string.Format("N{0}", this.QtyDecDigit)), detail.No);
                                        }
                                    }
                                    //CHeck Quantity compare with Delivery Quantity
                                    if (detail.DeliveryQuantity.HasValue)
                                    {
                                        if (detail.Quantity < detail.DeliveryQuantity)
                                        {
                                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Q'ty", detail.DeliveryQuantity.Value.ToString(string.Format("N{0}", this.QtyDecDigit)), detail.No);
                                        }
                                    }
                                }
                                else
                                {
                                    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", detail.No);
                                }

                                #endregion Quantity

                                //Total

                                #region Total-Vat-Ratio

                                if (detail.Total.HasValue)
                                {
                                    maxValue = isDecimal ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                                    var decimalDigit = isDecimal ? 2 : 0;

                                    string numberFormat = string.Format("N{0}", decimalDigit);
                                    if (detail.Total > maxValue)
                                    {
                                        this.SetMessage(string.Format("txtTotal_{0}", i), M_Message.MSG_LESS_THAN_GRID, "Sub Total", maxValue.ToString(string.Format("N{0}", decimalDigit)), detail.No);
                                    }
                                }

                                if (methodVAT == M_Config_D.METHOD_VAT_EACH && detail.VatType == (int)VATFlg.Exclude)
                                {
                                    if (detail.VAT.HasValue)
                                    {
                                        maxValue = (isDecimal) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                        var decimalDigit = (isDecimal) ? 2 : 0;
                                        string numberFormat = string.Format("N{0}", decimalDigit);
                                        if (detail.VAT > maxValue)
                                        {
                                            this.SetMessage(string.Format("txtVAT_{0}", i), M_Message.MSG_LESS_THAN_GRID, "VAT", maxValue.ToString(string.Format("N{0}", decimalDigit)), detail.No);
                                        }
                                    }

                                    if (!detail.VatRatio.HasValue)
                                    {
                                        this.SetMessage("txtVatRatio_" + i.ToString(), M_Message.MSG_REQUIRE_GRID, "VatRatio", detail.No);
                                    }
                                    else
                                    {
                                        if (detail.VatRatio > Constant.MAX_VATRATIO)
                                        {
                                            base.SetMessage(string.Format("txtVatRatio_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, detail.No);
                                        }
                                    }
                                }

                                #endregion Total-Vat-Ratio

                                //Serial

                                #region SubDetails

                                if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                                {
                                    bool hasErrSerial = false;
                                    for (int j = 0; j < detail.SerialList.Count; j++)
                                    {
                                        SerialInfo subDetail = detail.SerialList[j];
                                        if (subDetail == null)
                                        {
                                            continue;
                                        }

                                        subDetail.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                                        if (subDetail.Terms.HasValue && subDetail.Terms.Value == 0)
                                        {
                                            this.SetMessage(string.Format("{0}_txtTerms_{1}", i, j), M_Message.MSG_GREATER_THAN_GRID, "Warranty Unit", ZERO_STRING, string.Format("{0}/{1}", detail.No, j + 1));
                                            hasErrSerial = true;
                                        }

                                        if (subDetail.Terms.HasValue && subDetail.TermUnit == 0)
                                        {
                                            this.SetMessage(string.Format("{0}_cmbUnitSerial_{1}", i, j), M_Message.MSG_REQUIRE_SELECT_GRID, "Warranty Type", string.Format("{0}/{1}", detail.No, j + 1));
                                            hasErrSerial = true;
                                        }

                                        if (!subDetail.Terms.HasValue && subDetail.TermUnit != 0)
                                        {
                                            this.SetMessage(string.Format("{0}_txtTerms_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Warranty Unit", string.Format("{0}/{1}", detail.No, j + 1));
                                            hasErrSerial = true;
                                        }

                                        if (subDetail.ContractType != short.Parse(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                                        {
                                            //if ((!subDetail.StartDate.HasValue || subDetail.StartDate == DEFAULT_DATE_TIME) ^
                                            //    (!subDetail.FinishDate.HasValue || subDetail.FinishDate == DEFAULT_DATE_TIME))
                                            //{
                                            //    if ((!subDetail.StartDate.HasValue || subDetail.StartDate == DEFAULT_DATE_TIME))
                                            //    {
                                            //        this.SetMessage(string.Format("{0}_txtSerialStartDate_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Start date", string.Format("{0}/{1}", detail.No, j + 1));
                                            //    }
                                            //    if ((!subDetail.FinishDate.HasValue || subDetail.FinishDate == DEFAULT_DATE_TIME))
                                            //    {
                                            //        this.SetMessage(string.Format("{0}_txtSerialFinishDate_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "End date", string.Format("{0}/{1}", detail.No, j + 1));
                                            //    }
                                            //    hasErrSerial = true;

                                            //}

                                            if (subDetail.StartDate.HasValue &&
                                                subDetail.StartDate != DEFAULT_DATE_TIME &&
                                                subDetail.FinishDate.HasValue &&
                                                subDetail.FinishDate != DEFAULT_DATE_TIME)
                                            {
                                                if (subDetail.FinishDate.GetValueOrDefault().CompareTo(subDetail.StartDate.GetValueOrDefault()) < 0)
                                                {
                                                    this.SetMessage(string.Format("{0}_txtSerialStartDate_{1}", i, j), M_Message.MSG_LESS_THAN_GRID, "Start date", "End date", string.Format("{0}/{1}", detail.No, j + 1));
                                                    hasErrSerial = true;
                                                }
                                            }
                                        }
                                    }

                                    if (hasErrSerial)
                                    {
                                        foreach (var item in detail.SerialList)
                                        {
                                            item.Collapsed = "in";
                                        }
                                    }
                                }

                                #endregion SubDetails
                            }
                        }

                        #endregion Detail
                    }
                }

                #region Sum-Footer

                var sumTotal = this.txtSumTotal.Value.GetValueOrDefault();
                var sumVAT = this.txtSumVat.Value.GetValueOrDefault();
                var grandTotal = this.txtGrandTotal.Value.GetValueOrDefault();

                var dec = isDecimal ? 2 : 0;
                string nf = string.Format("N{0}", dec);

                maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                if (sumTotal > maxValue)
                {
                    this.SetMessage(this.txtSumTotal.ID, M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(nf));
                }

                maxValue = isDecimal ? Constant.MAX_SUM_VAT_DECIMAL : Constant.MAX_SUM_VAT_NOT_DECIMAL;
                if (sumVAT > maxValue)
                {
                    this.SetMessage(this.txtSumVat.ID, M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(nf));
                }

                maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                if (grandTotal > maxValue)
                {
                    this.SetMessage(this.txtGrandTotal.ID, M_Message.MSG_LESS_THAN_EQUAL, "Grand Total", maxValue.ToString(nf));
                }

                //Check vat ratio total require
                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
                {
                    var vatType = Convert.ToInt32(this.cmbTotalVatType.SelectedItem.Value);
                    if (vatType == (int)VATFlg.Exclude)
                    {
                        if (!this.txtTotalVatRatio.Value.HasValue)
                        {
                            base.SetMessage(this.txtTotalVatRatio.ID, M_Message.MSG_REQUIRE, "VatRatio");
                        }
                        this.txtTotalVatRatio.SetReadOnly(false);
                        this.txtSumVat.SetReadOnly(false);
                    }
                    else
                    {
                        this.txtTotalVatRatio.SetReadOnly(true);
                        this.txtSumVat.SetReadOnly(true);
                    }
                }

                #endregion Sum-Footer

                //}
                //Reset datasource
                this.RefreshDetails(details);
            }

            //---------------------------------------------Check prodcut Name End----------------------------------//
            this.txtCustomerName.SetReadOnly(!(this.txtCustomerCD.Value == Models.M_Customer.CUSTOMER_CODE_SUPPORT));
            //-------2014/12/08 ISV-Nguyen Edit End -----------//

            //Check error
            return !base.HaveError;
        }

        #endregion Check Input

        /// <summary>
        /// Check is decimal
        /// </summary>
        /// <param name="currencyId">currencyId</param>
        /// <returns></returns>
        private bool IsDecimal(int currencyId)
        {
            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == currencyId).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Get Header
        /// </summary>
        /// <param name="header"></param>
        private void GetHeader(T_Delivery_H header)
        {
            //Delivery Date
            if (this.txtDeliveryDateHeader.Value.HasValue)
            {
                header.DeliveryDate = this.txtDeliveryDateHeader.Value.GetValueOrDefault();
            }
            else
            {
                header.DeliveryDate = DEFAULT_DATE_TIME;
            }

            //Expiry Date
            if (this.txtExpiryDateHeader.Value.HasValue)
            {
                header.ExpiryDate = this.txtExpiryDateHeader.Value.GetValueOrDefault();
            }
            else
            {
                header.ExpiryDate = DEFAULT_DATE_TIME;
            }

            //  header.FinishFlag = short.Parse(this.chkFinishedFlag.Checked ? "1" : "0");
            header.CurrencyID = int.Parse(this.cmbCurrency.SelectedItem.Value);

            header.PreparedCD = this.txtPrepareCD.Value;
            header.PreparedName = this.txtPrepareName.Value;

            header.ApprovedCD = this.txtApprovedCD.Value;
            header.ApprovedName = this.txtApprovedName.Value;

            //header.DelivererCD = this.txtDeliveryCD.Value;
            header.DelivererName = this.txtDeliveryName.Value;

            header.DeliveryPlace = this.txtDeliveryPlace.Value;
            header.SubjectName = this.txtSubject.Value;
            header.ContactPerson = this.txtAttn.Value;

            header.CustomerCD = this.txtCustomerCD.Value;
            header.CustomerName = this.txtCustomerName.Value;
            header.CustomerAddress1 = this.txtAdd1.Value;
            header.CustomerAddress2 = this.txtAdd2.Value;
            header.CustomerAddress3 = this.txtAdd3.Value;

            header.Tel = this.txtTel.Value;
            header.Fax = this.txtFax.Value;
            // Description: Add
            // Author: ISV-NGUYEN
            // Date  : 2014/12/05
            // ---------------------- Start ------------------------------
            header.Confirmed = this.txtConfirmed.Value;
            header.Position = this.txtPosition.Value;
            // ---------------------- End  ------------------------------

            header.MethodVat = short.Parse(this.cmbMethodVat.SelectedItem.Value);

            header.Memo = this.txtMemo.Value;
            header.SalesNo = this.txtSalesNo.Value;
            header.AcceptanceNo = this.txtAcceptanceNo.Value;
            //Contract Date
            if (this.txtAcceptanceDate.Value.HasValue)
            {
                header.AcceptanceDate = this.txtAcceptanceDate.Value.GetValueOrDefault();
            }
            else
            {
                header.AcceptanceDate = DEFAULT_DATE_TIME;
            }
            header.Total = this.txtSumTotal.Value.GetValueOrDefault();
            header.GrandTotal = this.txtGrandTotal.Value.GetValueOrDefault();
            header.VAT = this.txtSumVat.Value.GetValueOrDefault();
            header.VatRatio = this.txtTotalVatRatio.Value.GetValueOrDefault();

            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
            {
                if (!this.HasSales)
                {
                    header.VatType = short.Parse(this.cmbTotalVatType.SelectedValue);
                }
            }
            else
            {
                header.VatType = 255;
            }
            header.CreateUID = base.LoginInfo.User.ID;
            header.UpdateUID = base.LoginInfo.User.ID;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns></returns>
        private bool InsertData()
        {
            var header = new T_Delivery_H();
            //Get data header for insert
            this.GetHeader(header);
            header.IssuedDate = DEFAULT_DATE_TIME;
            header.IssuedUID = 0;

            //Get data detail for insert
            IList<DeliveryDetailInfo> lstDetail = this.GetDetailData(includeEmpty: false);

            try
            {
                //Get New ShippingNo
                using (DB db = new DB())
                {
                    header.DeliveryNo = (new TNoService(db)).CreateNo(T_No.DeliveryNo);
                }                

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var shipHSer = new Delivery_HService(db);

                    Delivery_CService shipCSer = new Delivery_CService(db);
                    TDeliverySerialService serialSer = new TDeliverySerialService(db);

                    //Insert Header - get Header ID must be inserted
                    var headerId = shipHSer.Insert(header);

                    if (headerId > 0)
                    {
                        //Insert Delivery Condition
                        this.InsertCondition(shipCSer, headerId);

                        var shipDSer = new Delivery_DService(db);

                        //Insert List Delivery Detail
                        foreach (var item in lstDetail)
                        {
                            T_Delivery_D detail = new T_Delivery_D();
                            detail.HID = headerId;
                            detail.No = item.No;
                            detail.SalesSellID = 0;
                            detail.ProductID = item.ProductID;
                            // Author: ISV-PHUONG
                            // Date  : 2014/12/10
                            // ---------------------- Start ------------------------------
                            //detail.ProductCD = item.ProductCD;
                            detail.ProductCD = this.ProductCdUsed ? item.ProductCD : M_Product.PRODUCT_CODE_SUPPORT;
                            // ---------------------- End   ------------------------------
                            detail.ProductName = item.ProductName;
                            detail.VATType = item.VatType;
                            detail.VATRatio = item.VatRatio.GetValueOrDefault();
                            detail.VAT = item.VAT.GetValueOrDefault();
                            detail.Description = item.Description;
                            detail.UnitPrice = item.UnitPrice.GetValueOrDefault();
                            detail.Quantity = item.Quantity.GetValueOrDefault();
                            detail.UnitID = item.UnitID;
                            detail.Total = item.Total.GetValueOrDefault();
                            detail.Remark = item.Remark;
                            detail.DeliveryDate = DEFAULT_DATE_TIME;
                            detail.DeliveryQuantity = 0;
                            //Insert Detail - get Detail ID must be inserted
                            int detailID = shipDSer.Insert(detail);

                            //Insert List Serial
                            foreach (var seriItem in item.SerialList)
                            {
                                if (!seriItem.IsEmpty(short.Parse(this._defaultContractType)))
                                {
                                    T_Delivery_Serial seri = new T_Delivery_Serial();
                                    seri.DeliveryDID = detailID;
                                    seri.No = seriItem.No;
                                    seri.SerialNo = seriItem.SerialNo;
                                    seri.Terms = Convert.ToInt32(seriItem.Terms.GetValueOrDefault());
                                    seri.ContractType = seriItem.ContractType;
                                    seri.TermUnit = seriItem.TermUnit.GetValueOrDefault();
                                    seri.StartDate = seriItem.StartDate == null ? DEFAULT_DATE_TIME : seriItem.StartDate.Value;
                                    seri.FinishDate = seriItem.FinishDate == null ? DEFAULT_DATE_TIME : seriItem.FinishDate.Value;
                                    serialSer.Insert(seri);
                                }
                            }
                        }

                        this.DataID = headerId;
                        db.Commit();
                        return true;
                    }
                }
            }
            catch (OverflowException ex)
            {
                if (ex.Message.Contains(T_No.DeliveryNo))
                {
                    base.SetMessage(this.txtCustomerCD.ClientID, M_Message.MSG_SIZE_MAX_NO, "Delivery No");
                }
                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return false;
        }

        /// <summary>
        /// Create Detail Data For Update
        /// </summary>
        /// <param name="lstDetail"></param>
        /// <param name="lstDetailDB"></param>
        /// <param name="lstSerialDB"></param>
        /// <param name="hashSerial"></param>
        /// <param name="shipLst"></param>
        /// <returns></returns>
        private bool CreateDetailDataForUpdate(IList<DeliveryDetailInfo> lstDetail,
                                                IList<T_Delivery_D> lstDetailDB,
                                                IList<T_Delivery_Serial> lstSerialDB,
                                                ref Hashtable hashSerial,
                                                ref IList<T_Delivery_D> shipLst,
                                                ref bool isFinish)
        {
            var detailChanged = false;
            if (shipLst == null)
            {
                shipLst = new List<T_Delivery_D>();
            }
            isFinish = true;
            var no = 1;
            foreach (var item in lstDetail)
            {
                if (!item.IsEmpty())
                {
                    var detail = lstDetailDB.Where(s => s.InternalID.Equals(item.InternalID)).SingleOrDefault();
                    if (detail == null)//add new
                    {
                        detail = new T_Delivery_D();
                        detail.SalesSellID = 0;

                        //Edit:-----ISV-HUNG-----Change update internalID--------------//
                        detail.InternalID = -1;
                        //Edit:-----ISV-HUNG-----Change update internalID--------------//
                    }
                    else
                    {
                        //Edit:-----ISV-HUNG-----Change update internalID--------------//
                        detail.InternalID = item.InternalID;
                        //Edit:-----ISV-HUNG-----Change update internalID--------------//
                    }

                    detail.No = no++;
                    detail.ProductID = item.ProductID;
                    //------------- ISV-Giam 2015/01/22 ------------
                    //detail.ProductCD = item.ProductCD;
                    detail.ProductCD = this.ProductCdUsed ? item.ProductCD : M_Product.PRODUCT_CODE_SUPPORT;
                    //-----------------------------------------------
                    detail.ProductName = item.ProductName;
                    detail.VATType = item.VatType;
                    detail.VATRatio = item.VatRatio.GetValueOrDefault();
                    detail.Description = item.Description;
                    detail.DeliveryDate = item.DeliveryDate == null ? DEFAULT_DATE_TIME : item.DeliveryDate.Value;
                    detail.UnitPrice = item.UnitPrice.GetValueOrDefault();
                    detail.Quantity = item.Quantity.GetValueOrDefault();
                    detail.DeliveryQuantity = item.DeliveryQuantity.GetValueOrDefault();
                    if (detail.DeliveryQuantity != detail.Quantity)//is finish after check
                    {
                        isFinish = false;
                    }
                    detail.UnitID = item.UnitID;
                    detail.Total = item.Total.GetValueOrDefault();
                    detail.VAT = item.VAT.GetValueOrDefault();
                    detail.Remark = item.Remark;
                    IList<T_Delivery_Serial> lstSerial = new List<T_Delivery_Serial>();
                    var serialChanged = /*(lstSeriDBItem != null) ? (lstSeriDBItem.Count != item.SerialList.Count) : */false;

                    //Get list serial by Detail ID
                    var lstSeriDBItem = lstSerialDB.Where(i => i.DeliveryDID == detail.InternalID).ToList();

                    if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                    {
                        foreach (var serialItem in item.SerialList)//lap tren man hinh
                        {
                            if (!serialItem.IsEmpty(short.Parse(this._defaultContractType)))
                            {
                                //Search on DB
                                var serial = lstSeriDBItem != null ? lstSeriDBItem.Where(s => s.No.Equals(serialItem.No)).SingleOrDefault() : null;
                                if (serial == null)//Add new
                                {
                                    serial = new T_Delivery_Serial();
                                    serial.No = serialItem.No;
                                }

                                serial.SerialNo = serialItem.SerialNo;
                                serial.Terms = serialItem.Terms == null ? 0 : Convert.ToInt32(serialItem.Terms.Value);
                                serial.ContractType = serialItem.ContractType;
                                serial.TermUnit = serialItem.TermUnit == null ? 0 : Convert.ToInt32(serialItem.TermUnit.Value);
                                serial.StartDate = serialItem.StartDate == null ? DEFAULT_DATE_TIME : serialItem.StartDate.Value;
                                serial.FinishDate = serialItem.FinishDate == null ? DEFAULT_DATE_TIME : serialItem.FinishDate.Value;
                                serialChanged = serialChanged || (serial.Status == DataStatus.Changed);

                                lstSerial.Add(serial);
                            }
                        }
                        //ISV-TRUC Edit 2014/12/30
                        //if (!hashSerial.ContainsKey(detail.No))
                        //{
                        //    hashSerial.Add(detail.No, lstSerial);
                        //}

                        if (!hashSerial.ContainsKey(detail.InternalID))
                        {
                            hashSerial.Add(detail.InternalID, lstSerial);
                        }
                        //End ISV-TRUC Edit 2014/12/30
                        serialChanged = serialChanged || (lstSeriDBItem != null && lstSeriDBItem.Count != lstSerial.Count);
                    }
                    else
                    {
                        hashSerial.Add(detail.InternalID, lstSeriDBItem);
                    }

                    detailChanged = detailChanged || (detail.Status == DataStatus.Changed) || serialChanged;

                    shipLst.Add(detail);
                }
            }
            return detailChanged;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            try
            {
                IList<DeliveryDetailInfo> lstDetailScreen = this.GetDetailData(includeEmpty: false);

                //Get Delivery
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    var id = this.DataID;

                    Delivery_HService hService = new Delivery_HService(db);
                    Delivery_DService dService = new Delivery_DService(db);
                    Delivery_CService condService = new Delivery_CService(db);
                    TDeliverySerialService sService = new TDeliverySerialService(db);
                    var header = hService.GetByID(id);
                    IList<T_Delivery_D> lstDetailDB = dService.GetListByHID(id);
                    IList<T_Delivery_Serial> lstSerialDB = sService.GetList();

                    //Get Update data
                    this.GetHeader(header);

                    var headerChanged = header.Status == DataStatus.Changed;
                    header.UpdateDate = this.OldUpdateDate;
                    header.UpdateUID = LoginInfo.User.ID;

                    //condition
                    var condChanged = false;
                    T_Delivery_C shipC = condService.GetByID(id);
                    if (shipC != null)
                    {
                        shipC.Conditions = this.txtConditions.Value;
                        condChanged = shipC.Status == DataStatus.Changed;
                    }

                    //Hashtable save list Serial of all detail
                    Hashtable hashSerial = new Hashtable();

                    //List Shipping for update
                    IList<T_Delivery_D> shipLst = null;
                    bool isFinishCheck = false;
                    var detailChanged = this.CreateDetailDataForUpdate(lstDetailScreen, lstDetailDB, lstSerialDB, ref hashSerial, ref shipLst, ref isFinishCheck);

                    if (condChanged || headerChanged || detailChanged || (lstDetailDB.Count != lstDetailScreen.Count))
                    {
                        Sales_HService salesService = new Sales_HService(db);
                        T_Sales_H salesH = salesService.GetBySalesNo(header.SalesNo);

                        if (salesH != null)
                        {
                            salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                            salesH.VersionUpdateUID = LoginInfo.User.ID;
                            if (salesService.UpdateVersion(salesH) <= 0)
                            {
                                //data has changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                        header.FinishFlag = short.Parse(isFinishCheck ? "1" : "0");
                        header.IssuedUID = 0;
                        header.IssuedDate = DEFAULT_DATE_TIME;
                        if (hService.Update(header) > 0)
                        {
                            if (condChanged)
                            {
                                //Update Delivery Condition
                                this.InsertCondition(condService, header.ID);
                            }

                            List<T_Delivery_D> insDataList = new List<T_Delivery_D>();
                            //Get data insert
                            for (int i = shipLst.Count - 1; i >= 0; i--)
                            {
                                var item = shipLst[i];
                                if (item.InternalID == -1)
                                {
                                    insDataList.Add(item);
                                    shipLst.RemoveAt(i);
                                }
                            }

                            var no = lstDetailDB.Count + shipLst.Count;

                            //Delete database when data not exists on screen
                            Hashtable updDataHtb = new Hashtable();
                            foreach (var item in shipLst)
                            {
                                updDataHtb.Add(item.InternalID, item.HID);
                            }

                            for (int i = lstDetailDB.Count - 1; i >= 0; i--)
                            {
                                var item = lstDetailDB[i];
                                if (!updDataHtb.ContainsKey(item.InternalID))
                                {
                                    dService.DeleteByInternalID(item.InternalID);
                                    lstDetailDB.RemoveAt(i);

                                    //Delete serial no
                                    sService.DeleteByID(item.InternalID);
                                }
                            }

                            //update no in database to greater number
                            foreach (var item in lstDetailDB)
                            {
                                dService.UpdateNoByInternalID(item.InternalID, no);
                                no += 1;
                            }

                            //Update data
                            foreach (var item in shipLst)
                            {
                                item.HID = id;
                                dService.Update(item);

                                List<T_Delivery_Serial> seriLst = (List<T_Delivery_Serial>)hashSerial[item.InternalID];
                                if (seriLst != null && seriLst.Count > 0)
                                {
                                    sService.DeleteByID(item.InternalID);
                                    foreach (var seItem in seriLst)
                                    {
                                        seItem.DeliveryDID = item.InternalID;
                                        sService.Insert(seItem);
                                    }
                                }
                                else
                                {
                                    sService.DeleteByID(item.InternalID);
                                }
                            }

                            //Insert data
                            foreach (var item in insDataList)
                            {
                                item.HID = id;
                                var shipDetailID = dService.Insert(item);
                                List<T_Delivery_Serial> seriLst = (List<T_Delivery_Serial>)hashSerial[item.InternalID];
                                if (seriLst != null && seriLst.Count > 0)
                                {
                                    foreach (var seItem in seriLst)
                                    {
                                        seItem.DeliveryDID = shipDetailID;
                                        sService.Insert(seItem);
                                    }
                                }
                            }
                            //Edit:-----ISV-HUNG-----Change update internalID--------------//

                            if (salesH != null)
                            {
                                //Update Finish Flag
                                if (salesService.UpdateFinishFlag(salesH) <= 0)
                                {
                                    //data has changed
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }

                            db.Commit();
                            return true;
                        }
                        else
                        {
                            //data has changed
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                    }
                    return true;


                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
               
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
        }

        /// <summary>
        /// Insert Condition
        /// </summary>
        /// <param name="service"></param>
        /// <param name="hid"></param>
        private void InsertCondition(Delivery_CService service, int hid)
        {
            service.Delete(hid);
            var con = new T_Delivery_C
            {
                HID = hid,
                Conditions = this.txtConditions.Value
            };
            service.Insert(con);
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns></returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Delivery_H header = this.GetDelivery(this.DataID);
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    T_Sales_H salesH = sales_HService.GetBySalesNo(header.SalesNo);
                    if (salesH != null)
                    {
                        salesH.VersionUpdateUID = LoginInfo.User.ID;
                        salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                        ret = sales_HService.UpdateVersion(salesH);

                        if (ret <= 0)
                        {
                            //data has changed
                            this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            this.SetDeliveryInfo(this.DataID);
                            return false;
                        }
                    }

                    Delivery_HService deliveryH = new Delivery_HService(db);

                    //Delete Delivery
                    ret = deliveryH.Delete(this.DataID, this.OldUpdateDate, this.LoginInfo.User.ID);
                    if (ret > 0)
                    {
                        if (salesH != null)
                        {
                            if (sales_HService.UpdateFinishFlag(salesH) <= 0)
                            {
                                //data has changed
                                this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                                this.SetDeliveryInfo(this.DataID);
                                return false;
                            }
                        }
                        db.Commit();
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //data changed
                    this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    this.SetDeliveryInfo(this.DataID);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Init data for Warranty type
        /// </summary>
        /// <param name="ddlWarranty"></param>
        /// <returns></returns>
        private List<DropDownModel> InitDataForWarrantyType(DropDownList ddlWarranty)
        {
            // init combox
            List<DropDownModel> items = new List<DropDownModel>();
            items.Add(new DropDownModel(((int)WarrantyUnit.None).ToString(), "---"));
            items.Add(new DropDownModel(((int)WarrantyUnit.Years).ToString(), WarrantyUnit.Years.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Months).ToString(), WarrantyUnit.Months.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Weeks).ToString(), WarrantyUnit.Weeks.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Days).ToString(), WarrantyUnit.Days.ToString()));
            return items;
        }

        public bool IsValidAllRef()
        {
            return this.IsValidQuotationRef() || this.IsValidSalesRef();
        }

        /// <summary>
        /// Check valid to quotation reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidQuotationRef()
        {
            return !this.txtQuotationNo.IsEmpty;
        }

        /// <summary>
        /// Check valid to Sales reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidSalesRef()
        {
            return !this.txtSalesNo.IsEmpty;
        }

        /// <summary>
        /// Format display name button
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatFileName(string fileName)
        {
            return Path.GetFileNameWithoutExtension(fileName);
        }

        /// <summary>
        /// check button delete
        /// </summary>
        /// <returns></returns>
        protected bool HasDeliveryQuantity()
        {
            IList<T_Delivery_D> detailModel = new List<T_Delivery_D>();
            using (DB db = new DB())
            {
                Delivery_DService dService = new Delivery_DService(db);
                detailModel = dService.GetListByHID(this.DataID);
            }
            return detailModel != null && detailModel.Any(x => x.DeliveryQuantity != 0);
        }

        #region Base Methods

        /// <summary>
        /// Set VAT Control
        /// </summary>
        /// <param name="cmbVatType"></param>
        /// <param name="txtVat"></param>
        /// <param name="txtVatRatio"></param>
        private void SetVATControl(DropDownList cmbVatType, INumberTextBox txtVat, INumberTextBox txtVatRatio)
        {
            if (int.Parse(cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                txtVat.SetReadOnly(false);
                txtVatRatio.SetReadOnly(false);

                txtVat.Value = null;
                txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
            }
            else
            {
                txtVat.SetReadOnly(true);
                txtVatRatio.SetReadOnly(true);

                txtVat.Value = null;
                txtVatRatio.Value = null;
            }
        }

        /// <summary>
        /// Set Decimal Digit
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <param name="txtNumberInput"></param>
        /// <param name="maxDecimal"></param>
        /// <param name="maxNotDecimal"></param>
        private void SetDecimalDigit(M_Currency_H crcyItem, INumberTextBox txtNumberInput, decimal maxDecimal, decimal maxNotDecimal)
        {
            if (crcyItem != null)
            {
                if (crcyItem.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtNumberInput.DecimalDigit = 2;
                    txtNumberInput.MaximumValue = maxDecimal;
                }
                else
                {
                    txtNumberInput.DecimalDigit = 0;
                    txtNumberInput.MaximumValue = maxNotDecimal;
                }
            }
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                     infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Get GetDelivery
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Delivery_H GetDelivery(int id)
        {
            using (DB db = new DB())
            {
                Delivery_HService delivery_HService = new Delivery_HService(db);

                //Get Currency
                return delivery_HService.GetByID(id);
            }
        }

        #endregion Base Methods

        #endregion Methods

        #region Web Methods

        /// <summary>
        /// Get Product
        /// </summary>
        /// <param name="type">type</param>
        /// <param name="shippingDate">shippingDate</param>
        /// <param name="productCd">productCd</param>
        /// <param name="quantity">quantity</param>
        /// <param name="currencyID">currencyID</param>
        /// <param name="fractionType">fractionType</param>
        /// <param name="decimalDigit">decimalDigit</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(short type,
                                         string shippingDate, string productCd,
                                         string quantity, int currencyID,
                                         int fractionType, int decimalDigit)
        {
            try
            {
                if (productCd == M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }

                using (DB db = new DB())
                {
                    ProductService service = new ProductService(db);
                    var mProd = service.GetByCD(productCd);

                    if (mProd == null || mProd.StatusFlag != 0)
                    {
                        return string.Empty;
                    }
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    System.Text.StringBuilder result = new System.Text.StringBuilder();
                    result.Append("{");

                    result.Append(string.Format("\"ProductName\":\"{0}\"", mProd.ProductName.Replace("\"", "\\\"").Replace("\r\n", "</br>")));

                    #region Sell

                    if (type == (short)ProductType.Sell)
                    {
                        //Sell
                        result.Append(string.Format(", \"Description\":\"{0}\"", mProd.DescriptionSell.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        result.Append(string.Format(", \"Remark\":\"{0}\"", mProd.RemarkSell.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        result.Append(string.Format(", \"UnitID\":\"{0}\"", mProd.UnitIDSell));
                        result.Append(string.Format(", \"VatType\":\"{0}\"", mProd.VatTypeSell));
                        var _vatRatio = mProd.VatRatioSell;
                        var vatType = mProd.VatTypeSell;
                        var unitPrice = 0m;
                        var subTotal = 0m;
                        var vat = 0m;

                        #region Currency

                        if (currencyID == mProd.CurrencyIDSell)
                        {
                            unitPrice = mProd.UnitPriceSell;
                        }
                        else
                        {
                            var baseDate = string.IsNullOrEmpty(shippingDate) ? db.NowDate : CommonUtil.ParseDate(shippingDate);
                            var crcyService = new Currency_HService(db);
                            var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                            //Chuyen tien cua product ve tien mac dinh
                            if (mProd.CurrencyIDSell == Constant.DEFAULT_ID)
                            {
                                unitPrice = mProd.UnitPriceSell;
                            }
                            else
                            {
                                unitPrice = CommonUtil.ConvertToVND(crcyList[mProd.CurrencyIDSell].ExchangeRate, mProd.UnitPriceSell);
                            }
                            // Neu chon loai tien mac dinh thi set tra ve
                            // Con neu nguoc lai thi chuyen tien ve kieu tien duoc chon
                            if (currencyID != Constant.DEFAULT_ID)
                            {
                                unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyID].ExchangeRate, unitPrice);
                            }
                        }
                        result.Append(string.Format(", \"UnitPrice\":\"{0}\"", unitPrice.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, unitPrice * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"Total\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"Total\":\"{0}\"", string.Empty));
                        }

                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatio\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"VAT\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"VAT\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatio\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"VAT\":\"{0}\"", string.Empty));
                        }

                        #endregion Currency
                    }

                    #endregion Sell

                    result.Append("}");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(in1, 1);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return string.Empty;
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Get Customer Info
        /// </summary>
        /// <param name="in1">customerCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCustomer(string in1)
        {
            try
            {
                var dbCustomerCD = in1;
                dbCustomerCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbCustomerCD, M_Customer.CUSTOMER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbCustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
                if (in1 == OMS.Models.M_Customer.CUSTOMER_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                using (DB db = new DB())
                {
                    CustomerService service = new CustomerService(db);

                    var customer = service.GetByCustomerCD(dbCustomerCD);
                    if (customer != null && customer.StatusFlag == 0)
                    {
                        var representAposition = string.Format("{0}{1}/{2}", customer.Represent, customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' });
                        var result = new
                        {
                            customerCD = in1,
                            customerName1 = customer.CustomerName1,
                            customerAddress1 = customer.CustomerAddress1,
                            customerAddress2 = customer.CustomerAddress2,
                            customerAddress3 = customer.CustomerAddress3,
                            tel = customer.Tel,
                            fax = customer.FAX,
                            contactPerson = customer.ContactPerson,
                            // Description: Add
                            // Author: ISV-NGUYEN
                            // Date  : 2014/12/05
                            // ---------------------- Start ------------------------------
                            confirmed = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_REPRESENT : customer.Represent,
                            position = string.IsNullOrEmpty(representAposition) ? Constant.DEFAULT_POSITION : string.Format("{0} / {1}", customer.Position2, customer.Position1).Trim(new char[] { ' ', '/' }),
                            // ---------------------- End  ------------------------------
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        customerCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Call Sell
        /// </summary>
        /// <param name="senderId"></param>
        /// <param name="vatType"></param>
        /// <param name="unitPrice"></param>
        /// <param name="quantity"></param>
        /// <param name="total"></param>
        /// <param name="vatRatio"></param>
        /// <param name="decimalDigit"></param>
        /// <param name="fractionType"></param>
        /// <param name="totalId"></param>
        /// <param name="vatId"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcSell(string senderId, string vatType, string unitPrice, string quantity, string total, string vatRatio,
                                      int decimalDigit, int fractionType, string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtUnitPrice") || senderId.Contains("txtQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtTotal") || senderId.Contains("txtVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        /// <param name="methodVAT"></param>
        /// <param name="totals"></param>
        /// <param name="VATs"></param>
        /// <param name="vatRatio"></param>
        /// <param name="decimalDigit"></param>
        /// <param name="fractionType"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcTotal(string methodVAT
                                       , string[] totals, string[] VATs
                                       , string vatRatio
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                if (string.IsNullOrEmpty(vatRatio))
                {
                    vatRatio = "0";
                }
                decimal? sumTotal = null;
                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = Utilities.Fraction.Round((FractionType)fractionType, totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);
                }

                decimal? sumVAT = null;
                if (sumTotal.HasValue)
                {
                    if (VATs.Any(s => !string.IsNullOrEmpty(s)))
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, VATs.Sum(v => string.IsNullOrEmpty(v) ? 0 : decimal.Parse(v)), 2);
                    }

                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, (sumTotal.GetValueOrDefault() * decimal.Parse(vatRatio)) / 100, 2);
                    }
                }
                decimal? grandTotal = null;
                if (sumTotal.HasValue && sumVAT.HasValue)
                {
                    grandTotal = sumTotal.GetValueOrDefault() + sumVAT.GetValueOrDefault();
                }

                string numberFormat = string.Format("N{0}", decimalDigit);

                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtSumTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtSumVat\":\"{0}\"", sumVAT.HasValue ? sumVAT.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtGrandTotal\":\"{0}\"", grandTotal.HasValue ? grandTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));

                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string conditionCd, string condition)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(conditionCd, (int)ConditionFlag.Delivery);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            condition = condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calculate Warranty Date
        /// </summary>
        /// <param name="senderId"></param>
        /// <param name="terms"></param>
        /// <param name="unit"></param>
        /// <param name="warranty"></param>
        /// <param name="termsId"></param>
        /// <param name="warrantyId"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcWarrantyDate(string senderId, string deliveryDate, string contractType, string terms
                                    , string unit,string startDateId, string finishDateId)
        {
            try
            {
                DateTime date = CommonUtil.GetDefaultDate();
                if (!string.IsNullOrEmpty(deliveryDate))
                {
                    date = CommonUtil.ParseDate(deliveryDate);
                }
                else
                {
                    using (var db = new DB())
                    {
                        date = db.NowDate;
                    }
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtTerms") || senderId.Contains("cmbUnitSerial"))
                {
                    if (string.IsNullOrEmpty(terms) || Convert.ToInt32(unit) == 0)
                    {
                        if (!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                            result.Append(string.Format("\"{0}\":\"{1}\", ", startDateId, string.Empty));
                        result.Append(string.Format("\"{0}\":\"{1}\"", finishDateId, string.Empty));
                        
                    }
                    else
                    {
                        var termsVal = Convert.ToInt32(terms);
                        DateTime deliDate = DateTime.MinValue;
                        DateTime maxdate = new DateTime(9999, 12, 31);
                        switch (int.Parse(unit))
                        {
                            case (int)WarrantyUnit.None://not select
                                break;

                            case (int)WarrantyUnit.Years://years
                                if (termsVal + deliDate.Year > maxdate.Year)
                                {
                                    deliDate = maxdate;
                                }
                                else
                                {
                                    deliDate = date.AddYears(termsVal);
                                }
                                break;

                            case (int)WarrantyUnit.Months://months
                                deliDate = date.AddMonths(termsVal);
                                break;

                            case (int)WarrantyUnit.Weeks://weeks
                                deliDate = date.AddDays(termsVal * 7);
                                break;

                            case (int)WarrantyUnit.Days://days
                                deliDate = date.AddDays(termsVal);
                                break;

                            default:
                                break;
                        }
                        if(!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                            result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\", ", startDateId, date));
                        result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\"", finishDateId, deliDate));
                    }
                }

                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calculates the balance start datevs finish date.
        /// </summary>
        /// <param name="senderId">The sender identifier.</param>
        /// <param name="targetId">The target identifier.</param>
        /// <param name="date">The date.</param>
        /// <param name="terms">The terms.</param>
        /// <param name="unit">The unit.</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcBalanceStartDatevsFinishDate(string senderId,
                                                              string targetId,
                                                              string contractType, 
                                                              string terms, string unit,
                                                              string date)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (string.IsNullOrEmpty(date))
                {
                    result.Append(string.Format("\"{0}\":\"{1}\"", targetId, string.Empty));
                    result.Append("}");
                    return result.ToString();
                }
                var iDate = CommonUtil.ParseDate(date);

                
                var termsVal = CommonUtil.ParseInteger(terms);
                DateTime oDate = DateTime.MinValue;

                DateTime maxdate = new DateTime(9999, 12, 31);
                DateTime minDate = CommonUtil.GetDefaultDate();

                #region Calc
                switch (int.Parse(unit))
                {
                    case (int)WarrantyUnit.None://not select
                        break;

                    case (int)WarrantyUnit.Years://years

                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            if (termsVal + iDate.Year > maxdate.Year)
                            {
                                oDate = maxdate;
                            }
                            else
                            {
                                oDate = iDate.AddYears(termsVal);
                            }
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            if (termsVal - iDate.Year > minDate.Year)
                            {
                                oDate = minDate;
                            }
                            else
                            {
                                oDate = iDate.AddYears(termsVal * -1);
                            }
                        }
                        break;

                    case (int)WarrantyUnit.Months://months
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddMonths(termsVal);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddMonths(termsVal * -1);
                        }
                        break;

                    case (int)WarrantyUnit.Weeks://weeks
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * 7);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * -7);
                        }

                        break;

                    case (int)WarrantyUnit.Days://days
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * -1);
                        }
                        break;
                    default:
                        break;
                } 
                #endregion

                if (!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                {
                    result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\"", targetId, oDate));
                }
                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count File Attached
        /// </summary>
        /// <param name="dataId"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(int dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId, (int)FType.Delivery);
                    var result = new
                    {
                        count = count
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion Web Methods

        #region Event Excel

        /// <summary>
        /// btnAcceptanceReport Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAcceptanceReport_Click(object sender, CommandEventArgs e)
        {
            var header = this.GetByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.SetDeliveryInfo(this.DataID);

                if (isOk)
                {
                    var index = int.Parse(e.CommandArgument.ToString());

                    this.TypeOfIssue = this.ListAcceptReportFile[index];
                    var acceptanceReportFile = Path.GetFileNameWithoutExtension(this.ListAcceptReportFile[index]);

                    AcceptanceReportExcel excel = new AcceptanceReportExcel();
                    excel.DataID = this.DataID;
                    //excel.QuantityDecimal = this.QuantityDecimal;
                    //excel._fractionType = this._fractionType;
                    IWorkbook wb = excel.OutputExcel(acceptanceReportFile);

                    ////Create Sheet
                    //IWorkbook wb = this.CreateWorkbook(acceptanceReportFile);

                    ////Get Sheet
                    //ISheet sheet = wb.GetSheet(acceptanceReportFile);

                    //if (sheet != null)
                    //{
                    //    //Show data
                    //    this.FillDataAcceptanceReport(wb, sheet);
                    //}

                    this.SaveFile(wb);

                    //Show data
                    this.SetDeliveryInfo(DataID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
        }

        #endregion Event Excel
    }
}
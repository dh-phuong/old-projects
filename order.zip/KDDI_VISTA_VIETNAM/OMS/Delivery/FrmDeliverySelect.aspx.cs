﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using OMS.Models;
using OMS.DAC;
using OMS.Utilities;
using System.Web.UI.HtmlControls;
using OMS.Controls;
using System.Data.SqlClient;
using System.Collections;

namespace OMS.Delivery
{
    /// <summary>
    /// Delivery select form
    /// Create date: 2014/09/08
    /// Create author: VN-Nho
    /// </summary>
    public partial class FrmDeliverySelect : FrmBaseDetail
    {
        #region Constans
        /// <summary>
        /// Default Date
        /// </summary>
        public readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        #region Variable
        /// <summary>
        /// Focus controls ID
        /// </summary>
        public string focusControlsID = "";
        private FractionType _defaultFractionType;

        //------2014/12/12 ISV-HUNG Add Start----------//
        /// <summary>
        /// Product CD Used
        /// </summary>
        public int _productCDUsed;
        //------2014/12/12 ISV-HUNG Add End----------//
        #endregion

        #region property

        /// <summary>
        /// Get or set SalesID
        /// </summary>
        public int SalesID
        {
            get { return this.GetValueViewState<int>("SalesID"); }
            set
            {
                base.ViewState["SalesID"] = value;
            }
        }

        /// <summary>
        /// Get or set Old Version Update Date
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return this.GetValueViewState<DateTime>("OldVersionUpdateDate"); }
            set
            {
                base.ViewState["OldVersionUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Get or set Quantity Decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return this.GetValueViewState<int>("QuantityDecimal"); }
            set
            {
                base.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// Get or set Decimal Type
        /// </summary>
        public int DecimalType
        {
            get { return this.GetValueViewState<int>("DecimalType"); }
            set
            {
                base.ViewState["DecimalType"] = value;
            }
        }
        
        /// <summary>
        /// Get max of remain quantity
        /// </summary>
        public decimal MaxRemainQty
        {
            get {

                if (QuantityDecimal == 0)
                {
                    return 99999;
                }
                else
                {
                    return 99999.99M;
                }
            }
        }

        /// <summary>
        /// Has detail data
        /// </summary>
        public bool HasData
        {
            get { return this.GetValueViewState<bool>("HasData"); }
            set
            {
                base.ViewState["HasData"] = value;
            }
        }

        /// <summary>
        /// Completed Delivery flag
        /// </summary>
        public bool CompletedDelivery
        {
            get { return this.GetValueViewState<bool>("CompletedDelivery"); }
            set
            {
                base.ViewState["CompletedDelivery"] = value;
            }
        }

        //-------2014/12/10 ISV-HUNG Add Start -----------//
        public string ProductCDUsedClass
        {
            get
            {
                if (this._productCDUsed != int.Parse(M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON))
                {
                    return "hidden";
                }
                return string.Empty;
            }
        }
        //------2014/12/12 ISV-HUNG Add End----------//

        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
        /// <summary>
        /// IDRef
        /// </summary>
        public int IDRef
        {
            get { return this.GetValueViewState<int>("IDRef"); }
            set
            {
                base.ViewState["IDRef"] = value;
            }
        }

        /// <summary>
        /// NoRef
        /// </summary>
        public string NoRef
        {
            get { return this.GetValueViewState<string>("NoRef"); }
            set
            {
                base.ViewState["NoRef"] = value;
            }
        }
        //----------------2014/12/16 ISV-HUNG Add End----------------------//
        #endregion

        #region Event
        /// <summary>
        /// Init event
        /// </summary>
        /// <param name="e">Event argument</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set title
            base.FormTitle = "Delivery";
            base.FormSubTitle = "Select";

            //Search button event
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //------2014/12/15 ISV-HUNG Add Start----------//
            //Ref
            //this.btnDeliveryRef.ServerClick += new EventHandler(btnDeliveryRef_Click);
            //------2014/12/15 ISV-HUNG Add End----------//

            //Yes button event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

        }

        /// <summary>
        /// Page load event
        /// </summary>
        /// <param name="sender">Object</param>
        /// <param name="e">Event Argument</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                Config_HService configHService = new Config_HService(db);
                this.QuantityDecimal = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;
                this._defaultFractionType = (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                //-------2014/12/10 ISV-HUNG Edit Start -----------//
                //ProductCD Used
                this._productCDUsed = int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED));
                //-------2014/12/10 ISV-HUNG Edit End -----------//
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_SALES_DETAIL;
            }

            if (!base.IsPostBack)
            {
                if(base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get Sales id
                            this.SalesID = int.Parse(para["ID"].ToString());

                            T_Sales_H salesH = this.GetSales(this.SalesID);
                            this.OldVersionUpdateDate = salesH.VersionUpdateDate;
                            this.DecimalType = this.GetDecimalType(salesH.CurrencyID);

                            this.ViewState["NoRef"] = para["NoRef"];
                            this.ViewState["IDRef"] = para["IDRef"];
                            this.ViewState["MesgID"] = para["MesgID"];

                            if (this.ViewState["MesgID"] != null)
                            {
                                this.SetMessage(string.Empty, this.ViewState["MesgID"].ToString(), "Delivery", "Delivery No.", this.ViewState["IDRef"], this.ViewState["NoRef"]);
                            }

                            //Show Data
                            this.ShowHeaderData(salesH);

                            //Set Mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Search event
        /// </summary>
        /// <param name="sender">Sender</param>
        /// <param name="e">Event argument</param>
        protected void btnSearch_Click(Object sender, EventArgs e) {

            //Get header data
            T_Sales_H salesH = this.GetSales(this.SalesID);
            if (salesH == null)
                return;

            //Show header data
            this.ShowHeaderData(salesH);

            this.ProcessMode(Utilities.Mode.Insert);
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            IList<DeliverySelectInfo> listDetail = this.GetData();
            
            //Check input
            using (DB db = new DB())
            {
                if (!this.CheckInput(db, listDetail))
                {
                    return;
                }
            }

            //Show Question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_CREATE, Models.DefaultButton.No, false, "Delivery");
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">Event Arguments</param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            switch (this.Mode)
            {
                case Mode.Insert:
                    string shipNo = string.Empty;
                    //------2014/12/15 ISV-HUNG Add Start----------//
                    int shipID = 0;
                    //------2014/12/15 ISV-HUNG Add End----------//
                    

                    //------2014/12/15 ISV-HUNG Edit Start----------//
                    //if (this.InsertData(ref shipNo))
                    if (this.InsertData(ref shipNo, ref shipID))
                    //------2014/12/15 ISV-HUNG Edit End----------//
                    
                    {
                        T_Sales_H sales = this.GetSales(this.SalesID);
                        this.OldVersionUpdateDate = sales.VersionUpdateDate;

                        //Show Data
                        this.ShowHeaderData(sales);

                        this.ProcessMode(Utilities.Mode.Insert);

                        //------2014/12/15 ISV-HUNG Edit Start----------//
                        //Set Success
                        //this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Delivery", "Delivery No.", shipNo);
                        this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Delivery", "Delivery No.", shipID, shipNo);
                        //------2014/12/15 ISV-HUNG Edit End----------//

                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        this.IDRef = shipID;
                        this.NoRef = shipNo;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//
                    }
                    break;
                case Mode.Update:
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Event Back Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, CommandEventArgs e)
        {
            base.BackPage();
        }

        //------2014/12/15 ISV-HUNG Add Start----------//
        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnDeliveryRef_Click(object sender, EventArgs e)
        {
            Hashtable currentPage = new Hashtable();
            currentPage.Add("ID", this.SalesID);
            currentPage.Add("IDRef", this.IDRef);
            currentPage.Add("NoRef", this.NoRef);
            currentPage.Add("MesgID", M_Message.MSG_PROCESS_COMPLETED);

            Hashtable nextPage = new Hashtable();
            nextPage.Add("ID",this.hidDeliveryID.Value);

            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_DELIVERY_SELECT);
        }
        //------2014/12/15 ISV-HUNG Add End----------//
        
        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                DeliverySelectInfo data = (DeliverySelectInfo)e.Item.DataItem;

                //remainRow.BgColor = data.Color;
                //Find Control
                INumberTextBox txtRemainQty = (INumberTextBox)e.Item.FindControl("txtRemainQty");

                txtRemainQty.DecimalDigit = this.QuantityDecimal;
                txtRemainQty.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtRemainQty.MinimumValue = 0;
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            this.Mode = mode;
            this.CompletedDelivery = true;
            bool isFocused = false;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                //Row template
                HtmlTableRow rowData = (HtmlTableRow)item.FindControl("rowData");
                //Delivery Quantity
                HiddenField hidDeliveryQty = (HiddenField)item.FindControl("hidDeliveryQty");
                //Sales Quatity
                HiddenField hidSalesQty = (HiddenField)item.FindControl("hidSalesQty");
                //Check Flag
                HtmlInputCheckBox chkSelect = (HtmlInputCheckBox)item.FindControl("chkSel");
                //Remain Quantity
                INumberTextBox txtRemainQty = (INumberTextBox)item.FindControl("txtRemainQty");

                decimal dbRemainQty = Convert.ToDecimal(hidSalesQty.Value) - Convert.ToDecimal(hidDeliveryQty.Value);

                txtRemainQty.MaximumValue = this.MaxRemainQty;
                txtRemainQty.DecimalDigit = this.QuantityDecimal;

                if (dbRemainQty == 0)
                {
                    //Disable row if completed Delivery
                    chkSelect.Disabled = true;
                    txtRemainQty.ReadOnly = true;
                    rowData.Attributes.Add("style", "background-color:Silver");
                }
                else if (!isFocused)
                {
                    rowData.Attributes.Remove("style");
                    this.CompletedDelivery = false;
                    this.focusControlsID = chkSelect.ClientID;
                    isFocused = true;
                }
                
            }
        }

        /// <summary>
        /// Get Sales header
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns>Sales Header</returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService dbSer = new Sales_HService(db);

                //Get Sales header
                return dbSer.GetByPK(id);
            }
        }

        /// <summary>
        /// Get decimal type
        /// </summary>
        /// <param name="currencyID"Currency ID></param>
        /// <returns>Decimal type</returns>
        private int GetDecimalType(int currencyID)
        {
            using (DB db = new DB())
            {
                Currency_HService dbSer = new Currency_HService(db);

                return dbSer.GetByID(currencyID).DecimalType;
            }
        }

        /// <summary>
        /// Get version update date
        /// </summary>
        /// <param name="SalesNo">Sales no</param>
        /// <returns>Version update date</returns>
        private DateTime GetVersionUpdateDate(string SalesNo)
        {
            using (DB db = new DB())
            {
                Sales_HService dbSer = new Sales_HService(db);

                //Get Version Update Date
                return dbSer.GetBySalesNo(SalesNo).VersionUpdateDate;
            }
        }

        /// <summary>
        /// Get Delivery header data by id
        /// </summary>
        /// <param name="id">Delivery id</param>
        /// <returns>Delivery header data</returns>
        private T_Delivery_H GetDelivery(int id)
        {
            using (DB db = new DB())
            {
                Delivery_HService dbSer = new Delivery_HService(db);

                //Get Delivery header data
                return dbSer.GetByID(id);
            }
        }

        /// <summary>
        /// Show header data
        /// </summary>
        /// <param name="salesH">Sales header model</param>
        private void ShowHeaderData(T_Sales_H salesH)
        {
            this.SalesID = salesH.ID;
            this.txtSalesNo.Value = salesH.SalesNo;
            this.txtQuoteNo.Value = salesH.QuoteNo;
            this.txtCustomerCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeShow(salesH.CustomerCD, M_Customer.MAX_CUSTOMER_CODE_SHOW);
            this.txtCustomerName.Value = salesH.CustomerName;

            this.OldVersionUpdateDate = salesH.VersionUpdateDate;

            //Show detail
            this.ShowDetailData();
        }

        /// <summary>|
        /// Get and show detail data
        /// </summary>
        private void ShowDetailData()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellSer = new Sales_D_SellService(db);
                string customerCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtCustomerCD.Value, M_Customer.CUSTOMER_CODE_MAX_LENGTH);

                IList<DeliverySelectInfo> lstData = salesSellSer.GetForDeliverySelect(this.txtSalesNo.Value, this.txtQuoteNo.Value, customerCd, -1, M_Config_D.METHOD_VAT_EACH);

                this.HasData = lstData.Count > 0;

                //Set data source for gird
                this.rptDetail.DataSource = lstData;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <param name="deliveryNo">Delivery No</param>
        /// <param name="deliveryID">Delivery ID</param>
        /// <returns></returns>
        //------2014/12/15 ISV-HUNG Edit Start----------//
        //private bool InsertData(ref string DeliveryNo)
        private bool InsertData(ref string deliveryNo, ref int deliveryID)
        //------2014/12/15 ISV-HUNG Edit End----------//
        {
            try
            {
                IList<DeliverySelectInfo> lstData = this.GetData();
                using (DB db = new DB())
                {
                    if (!this.CheckInput(db, lstData, false))
                    {
                        return false;
                    }
                }

                //Get deliveryNo
                using (DB db = new DB())
                {
                    deliveryNo = (new TNoService(db)).CreateNo(T_No.DeliveryNo);
                }
                
                using(DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService salesHSer = new Sales_HService(db);
                    Delivery_CService deliveryCSer = new Delivery_CService(db);
                    Delivery_DService deliveryDSer = new Delivery_DService(db);
                    Delivery_HService deliveryHSer = new Delivery_HService(db);
                    Config_DService config_DService = new Config_DService(db);
                    TDeliverySerialService tDeliverySerialService = new TDeliverySerialService(db);

                    int ret = 0;
                    T_Sales_H salesH = salesHSer.GetByPK(this.SalesID);
                    salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                    salesH.VersionUpdateUID = LoginInfo.User.ID;

                    //Update Sales version update date
                    ret = salesHSer.UpdateVersion(salesH);

                    if (ret == 1)
                    {
                        T_Delivery_H deliveryH = new T_Delivery_H();
                        List<T_Delivery_D> lstDeliveryD = new List<T_Delivery_D>();
                        this.GetInsertData(db, salesH, lstData, ref deliveryH, ref lstDeliveryD);
                        deliveryH.DeliveryNo = deliveryNo;
                        deliveryH.DeliveryDate = db.NowDate;
                        var expiryDate = config_DService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY,int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Delivery));
                        if (!expiryDate.HasValue)
                        {
                            deliveryH.ExpiryDate = DEFAULT_DATE_TIME;
                        }
                        else
                        {
                            deliveryH.ExpiryDate = deliveryH.DeliveryDate.AddDays(expiryDate.Value);
                        }

                        //Insert delivery header
                        int headerID = deliveryHSer.Insert(deliveryH);
                        //------2014/12/15 ISV-HUNG Add Start----------//
                        deliveryID = headerID;
                        //------2014/12/15 ISV-HUNG Add End----------//
                        if (headerID != 0)
                        {
                            //Insert delivery conditions
                            T_Delivery_C deliveryC  = new T_Delivery_C
                            {
                                HID = headerID,
                                Conditions = string.Empty
                            };
                            deliveryCSer.Insert(deliveryC);

                            //Insert delivery detail
                            foreach (T_Delivery_D item in lstDeliveryD)
                            {
                                item.HID = headerID;
                                int detailID = deliveryDSer.Insert(item);

                                if (detailID != 0)
                                {
                                    //-------------------------------Insert Delivery Serial From Purchase Serial 2015/07/09 ISV-HUNG---------------------------//
                                    var lstDeliverySerial = tDeliverySerialService.GetListFromPurchaseSerial(item.SalesSellID);
                                    int no = 1;
                                    foreach (T_Delivery_Serial deliverSerialItem in lstDeliverySerial)
                                    {
                                        deliverSerialItem.DeliveryDID = detailID;
                                        deliverSerialItem.No = no;
                                        tDeliverySerialService.Insert(deliverSerialItem);

                                        no++;
                                    }
                                    //-------------------------------Insert Delivery Serial From Purchase Serial 2015/07/09 ISV-HUNG---------------------------//
                                }
                                else
                                {
                                    base.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                                    return false;
                                }
                            }
                        }
                        else
                        {
                            base.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                            return false;
                        }
                    }
                    else
                    {
                        base.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                }

            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.DeliveryNo))
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SIZE_MAX_NO, "Delivery No");
                }
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Models.Constant.T_DELIVERY_H_UN))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "Delivery No");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Get insert data
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="salesH">T_Sales_H</param>
        /// <param name="lstData">List DeliverySelectInfo</param>
        /// <param name="deliveryH">T_Delivery_H</param>
        /// <param name="lstDeliveryD">List T_Delivery_D</param>
        private void GetInsertData(DB db, T_Sales_H salesH, IList<DeliverySelectInfo> lstData, ref T_Delivery_H deliveryH, ref List<T_Delivery_D> lstDeliveryD)
        {
            Sales_D_SellService salesDSellSer = new Sales_D_SellService(db);
            Currency_HService crrHSer = new Currency_HService(db);

            M_Currency_H crrH = crrHSer.GetByID(salesH.CurrencyID);

            int no = 1;
            decimal total = 0;
            decimal vatTotal = 0;
            foreach (DeliverySelectInfo item in lstData)
            {
                if (!item.CheckFlag)
                {
                    continue;
                }
                T_Sales_D_Sell salesDSell = salesDSellSer.GetByInternalID(item.SalesSellID);
                T_Delivery_D deliveryD = new T_Delivery_D();

                deliveryD.No = no;
                deliveryD.SalesSellID = item.SalesSellID;
                deliveryD.ProductID = salesDSell.ProductID;
                deliveryD.ProductCD = salesDSell.ProductCD;
                deliveryD.ProductName = salesDSell.ProductName;
                deliveryD.VATType = salesDSell.VatType;
                deliveryD.VATRatio = salesDSell.VatRatio;
                deliveryD.Description = salesDSell.Description;
                deliveryD.DeliveryDate = Utilities.CommonUtil.GetDefaultDate();
                deliveryD.DeliveryQuantity = 0;
                deliveryD.UnitPrice = salesDSell.UnitPrice;
                deliveryD.Quantity = (decimal)item.RemainQty;
                deliveryD.UnitID = salesDSell.UnitID;
                deliveryD.Total = deliveryD.UnitPrice * deliveryD.Quantity;

                deliveryD.VAT = this.GetVAT(deliveryD.Total, deliveryD.VATRatio, crrH.DecimalType);
                deliveryD.Remark = salesDSell.Remark;
                
                lstDeliveryD.Add(deliveryD);
                total += deliveryD.Total;
                vatTotal += deliveryD.VAT;

                no += 1;
            }

            DateTime sysDate = db.NowDate;
            deliveryH.DeliveryNo = string.Empty;
            deliveryH.QuoteNo = salesH.QuoteNo;
            deliveryH.SalesNo = salesH.SalesNo;
            deliveryH.DeliveryPlace = string.Empty;
            deliveryH.IssuedFlag = (short)Models.PrintedFlag.NotPrinted;
            deliveryH.DeleteFlag = (short)Models.DeleteFlag.NotDelete;
            deliveryH.FinishFlag = (short)Models.FinishedFlag.NotFinish;
            deliveryH.DeliveryDate = sysDate;
            deliveryH.SubjectName = salesH.SubjectName;
            deliveryH.Memo = salesH.Memo;
            deliveryH.AcceptanceNo = string.Empty;
            deliveryH.AcceptanceDate = DEFAULT_DATE_TIME;
            deliveryH.PreparedCD = salesH.PreparedCD;
            deliveryH.PreparedName = salesH.PreparedName;
            deliveryH.ApprovedCD = salesH.ApprovedCD;
            deliveryH.ApprovedName = salesH.ApprovedName;
            deliveryH.DelivererName = string.Empty;
            deliveryH.CustomerCD = salesH.CustomerCD;
            deliveryH.CustomerName = salesH.CustomerName;
            deliveryH.CustomerAddress1 = salesH.CustomerAddress1;
            deliveryH.CustomerAddress2 = salesH.CustomerAddress2;
            deliveryH.CustomerAddress3 = salesH.CustomerAddress3;
            deliveryH.Tel = salesH.Tel;
            deliveryH.Fax = salesH.FAX;
            deliveryH.ContactPerson = salesH.ContactPerson;
            deliveryH.CurrencyID = salesH.CurrencyID;
            deliveryH.MethodVat = salesH.MethodVat;

            deliveryH.Total = total;
            deliveryH.VatRatio = salesH.VatRatio;
            deliveryH.VatType = salesH.VatType;

            if (deliveryH.MethodVat == short.Parse(M_Config_D.METHOD_VAT_EACH))
            {
                deliveryH.VAT = vatTotal;
            }
            else
            {
                deliveryH.VAT = OMS.Utilities.Fraction.Round(this._defaultFractionType, deliveryH.Total * deliveryH.VatRatio / 100, 2);
            }
            
            deliveryH.GrandTotal = deliveryH.Total + deliveryH.VAT;
            deliveryH.Confirmed = salesH.Approved;
            deliveryH.Position = salesH.Position;
            deliveryH.IssuedDate = DEFAULT_DATE_TIME;
            deliveryH.IssuedUID = 0;
            deliveryH.CreateDate = sysDate;
            deliveryH.CreateUID = LoginInfo.User.ID;
            deliveryH.UpdateDate = sysDate;
            deliveryH.UpdateUID = LoginInfo.User.ID;
        }

        /// <summary>
        /// Get vat
        /// </summary>
        /// <param name="subTotal">Total</param>
        /// <param name="vatPercent">VAT Ratio</param>
        /// <param name="decimalType">Decimal type</param>
        /// <returns>vat</returns>
        private decimal GetVAT(decimal subTotal, decimal vatRatio, int decimalType)
        {
            return OMS.Utilities.Fraction.Round(this._defaultFractionType, subTotal * vatRatio / 100, 2);
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(DB db, IList<DeliverySelectInfo> lstData, bool checkOverDeliveryNo = true)
        {
            Delivery_HService deliveryHSer = new Delivery_HService(db);
            Delivery_DService deliveryDSer = new Delivery_DService(db);
            Sales_D_SellService salesDSellSer = new Sales_D_SellService(db);

            bool hasSelect = false;
            int index = -1;
            string focusCtrlID = string.Empty;
            decimal total = 0;
            decimal vatTotal = 0;
            foreach (DeliverySelectInfo item in lstData)
            {
                index += 1;
                HtmlInputCheckBox chkSelect = (HtmlInputCheckBox)this.rptDetail.Items[index].FindControl("chkSel");
                HtmlGenericControl divRemainQty = (HtmlGenericControl)this.rptDetail.Items[index].FindControl("txtRemainQtyErr");
                divRemainQty.Attributes.Remove("class");

                //Find first constrol enable for focus
                if (string.IsNullOrEmpty(focusCtrlID) && !chkSelect.Disabled)
                {
                    focusCtrlID = chkSelect.ClientID;
                }

                if (!item.CheckFlag)
                {
                    continue;
                }
                hasSelect = true;

                //---------------ISV-HUNG Fig bug 2015/01/13----------------------
                if (this.CheckDataChangedSales(db))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
                //---------------ISV-HUNG Fig bug 2015/01/13----------------------

                string remainClientID = this.rptDetail.Items[index].FindControl("txtRemainQty").ClientID;

                //Check require
                if (item.RemainQty == null)
                {
                    //base.SetMessage(remainClientID, M_Message.MSG_REQUIRE_GRID, "Remain Q'ty", index+1);
                    this.SetMessage(string.Format("txtRemainQty_{0}", index), M_Message.MSG_REQUIRE_GRID, "Q'ty", index + 1);
                    //AddErrorForListItem(divRemainQty, remainClientID);
                } //Check greater than 0
                else if (item.RemainQty == 0)
                {
                    //base.SetMessage(remainClientID, M_Message.MSG_GREATER_THAN_GRID, "Remain Q'ty", 0, index+1);
                    this.SetMessage(string.Format("txtRemainQty_{0}", index), M_Message.MSG_GREATER_THAN_GRID, "Q'ty",0, index + 1);
                    //AddErrorForListItem(divRemainQty, remainClientID);
                }
                else 
                {
                    decimal dbRemainQty = deliveryDSer.GetRemainQtyBySalesSellID(item.SalesSellID, -1);
                    if (item.RemainQty > dbRemainQty)
                    {
                        //base.SetMessage(remainClientID, M_Message.MSG_LESS_THAN_EQUAL_GRID, "Remain Qty", dbRemainQty.ToString(string.Format("N{0}",this.QuantityDecimal)), item.No+1);
                        this.SetMessage(string.Format("txtRemainQty_{0}", index), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", dbRemainQty.ToString(string.Format("N{0}", this.QuantityDecimal)), index + 1);
                        //AddErrorForListItem(divRemainQty, remainClientID);
                    }
                    else
                    {
                        T_Sales_D_Sell salesDSell = salesDSellSer.GetByInternalID(item.SalesSellID);
                        total += salesDSell.UnitPrice * (decimal)item.RemainQty;
                        vatTotal += this.GetVAT(total, salesDSell.VatRatio, this.DecimalType);
                    }
                }
            }

            //Check has select data
            if (!hasSelect)
            {
                base.SetMessage(string.Empty, M_Message.MSG_SELECT_ROW_DATA);
                this.focusControlsID = focusCtrlID;
                return false;
            }

            //Check overflow
            if (!base.HaveError && this.CheckOverflowData())
            {
                //decimal maxTotal = this.DecimalType == 0? Constant.MAX_TOTAL_VND: Constant.MAX_TOTAL_USD;
                //decimal maxTotalVal = this.DecimalType == 0? Constant.MAX_TOTAL_VAT_VND: Constant.MAX_TOTAL_VAT_USD;
                //if(total > maxTotal)
                //{
                //    base.SetMessage("", M_Message.MSG_OVERFLOW_DATA, "Total");
                //    this.focusControlsID = focusCtrlID;
                //}

                //if (vatTotal > maxTotalVal)
                //{
                //    base.SetMessage("", M_Message.MSG_OVERFLOW_DATA, "VAT");
                //    this.focusControlsID = focusCtrlID;
                //}
                return false;

            }

            this.rptDetail.DataSource = lstData;
            this.rptDetail.DataBind();

            //-------------ISV-HUNG Fix bug 2015/01/13--------------//
            this.ProcessMode(Utilities.Mode.Insert);
            //-------------ISV-HUNG Fix bug 2015/01/13--------------//

            return !base.HaveError;
        }

        ///// <summary>
        ///// Add display error for control
        ///// </summary>
        ///// <param name="divCtrl">div error control</param>
        ///// <param name="errorKey">Error Control ID</param>
        //private void AddErrorForListItem(HtmlGenericControl divCtrl, string errorKey)
        //{
        //    divCtrl.Attributes.Add("class", "form-group " + base.GetClassError(errorKey));
        //    //Control ctrError = ParseControl(base.GetSpanError(errorKey));
        //    //divCtrl.Controls.Add(ctrError);
        //}

        /// <summary>
        /// Check Sales data changed
        /// </summary>
        /// <param name="db">Database</param>
        /// <returns>True: Changed/ False: Not changed</returns>
        private bool CheckDataChangedSales(DB db)
        {
            Sales_HService salesHSer = new Sales_HService(db);
            T_Sales_H salesH = salesHSer.GetByPK(this.SalesID);

            if (salesH != null)
            {
                if (salesH.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return true;
            }
        }

        /// <summary>
        /// Check Overflow Q'ty
        /// </summary>
        /// <returns></returns>
        private bool CheckOverflowData()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellServive = new Sales_D_SellService(db);
                Currency_HService crcHService = new Currency_HService(db);

                var uiItems = this.GetData();

                var selected = uiItems.Any(s => s.CheckFlag);
                if (!selected)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_PLEASE_SELECT, "row data");
                    return false;
                }

                #region GRID
                var index = 0;
                var sumTotal = 0m;
                var sumVat = 0m;
                var dec = 0;
                decimal maxValue = 0m;
                decimal maxQuantity = 0m;
                string numberFormat = string.Empty;
                bool haveError = false;
                for (int i = 0; i < uiItems.Count; i++)
                {
                    var invSec = uiItems[i];
                    if (invSec.CheckFlag)
                    {
                        var unitPrice = invSec.UnitPrice;

                        dec = this.DecimalType == ((int)ExchangeRateDecType.Decimal) ? 2 : 0;
                        numberFormat = string.Format("N{0}", dec);

                        var subTotal = Fraction.Round(this._defaultFractionType, unitPrice * invSec.RemainQty.GetValueOrDefault(), 2);
                        var subVat = Fraction.Round(this._defaultFractionType, (subTotal * invSec.VATPercent) / 100, 2);

                        //maxValue = dec > 0 ? MAX_UNIT_PRICE_DECIMAL : MAX_UNIT_PRICE_NOT_DECIMAL;
                        //if (unitPrice > maxValue)
                        //{
                        //    this.SetMessage(string.Format("txtRemainQty_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), (i + 1));
                        //    haveError = true;
                        //}

                        maxValue = dec > 0 ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                        if (unitPrice != 0)
                        {
                            maxQuantity = Fraction.Round(this._defaultFractionType, (maxValue / Math.Abs(unitPrice)), dec);

                            if (invSec.RemainQty >= maxQuantity)
                            {
                                this.SetMessage(string.Format("txtRemainQty_{0}", i), M_Message.MSG_LESS_THAN_GRID, "Q'ty", maxQuantity.ToString(numberFormat), (i + 1));
                                haveError = true;
                            }
                        }

                        //if (subTotal > maxValue)
                        //{
                        //    this.SetMessage(string.Format("txtRemainQty_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(numberFormat), (i + 1));
                        //    haveError = true;
                        //}

                        //if (invSec.VATFlag == VATFlg.Exclude)
                        //{
                        //    maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                        //    if (subVat > maxValue)
                        //    {
                        //        this.SetMessage(string.Format("txtRemainQty_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total Vat", maxValue.ToString(numberFormat), (i + 1));
                        //        haveError = true;
                        //    }
                        //}

                        sumTotal += subTotal;
                        sumVat += subVat;

                        index++;
                    }
                }
                #endregion

                if (!haveError)
                {
                    maxValue = dec > 0 ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                    if (sumTotal > maxValue)
                    {
                        var quantityAllow = Fraction.Round(this._defaultFractionType, (Math.Abs(sumTotal - maxValue) / Math.Abs(uiItems[0].UnitPrice)), dec);

                        quantityAllow = uiItems[0].RemainQty.Value - quantityAllow;

                        this.SetMessage(string.Format("txtRemainQty_{0}",0), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", quantityAllow.ToString(numberFormat), 1);
                        haveError = true;
                    }

                    //if (sumTotal > maxValue)
                    //{
                    //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(numberFormat));
                    //    haveError = true;
                    //}
                    //maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                    //if (sumVat > maxValue)
                    //{
                    //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(numberFormat));
                    //    haveError = true;
                    //}
                }

                this.rptDetail.DataSource = uiItems;
                this.rptDetail.DataBind();

                return haveError;
            }
        }

        /// <summary>
        /// Get data form screen
        /// </summary>
        /// <returns>List Delivery select information</returns>
        private IList<DeliverySelectInfo> GetData()
        {
            IList<DeliverySelectInfo> retLst = new List<DeliverySelectInfo>();

            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                DeliverySelectInfo addItem = new DeliverySelectInfo();

                //Sales sell id
                HiddenField hidSalesSellID = (HiddenField)item.FindControl("hidSalesSellID");
                addItem.SalesSellID = int.Parse(hidSalesSellID.Value);

                //Check Flag
                HtmlInputCheckBox chkSelect = (HtmlInputCheckBox)item.FindControl("chkSel");
                addItem.CheckFlag = chkSelect.Checked;

                //Remain Quantity
                INumberTextBox txtRemainQty = (INumberTextBox)item.FindControl("txtRemainQty");
                addItem.RemainQty = txtRemainQty.Value;

                //Delivery Quantity
                HiddenField hidDeliveryQty = (HiddenField)item.FindControl("hidDeliveryQty");
                addItem.DeliveryQty = Convert.ToDecimal(hidDeliveryQty.Value);

                //Sales Quatity
                HiddenField hidSalesQty = (HiddenField)item.FindControl("hidSalesQty");
                addItem.SalesQty = Convert.ToDecimal(hidSalesQty.Value);

                //Product code
                HiddenField hidProductCD = (HiddenField)item.FindControl("hidProductCD");
                addItem.ProductCD = hidProductCD.Value;

                //Product name
                HiddenField hidProductName = (HiddenField)item.FindControl("hidProductName");
                addItem.ProductName = hidProductName.Value;

                //Unit price
                HiddenField hidUnitPrice = (HiddenField)item.FindControl("hidUnitPrice");
                addItem.UnitPrice = Convert.ToDecimal(hidUnitPrice.Value);

                //Currency
                HiddenField hidCurrency = (HiddenField)item.FindControl("hidCurrency");
                addItem.Currency = hidCurrency.Value;

                //VATPercent
                HiddenField hidVATPercent = (HiddenField)item.FindControl("hidVATPercent");
                addItem.VATPercent = Convert.ToDecimal(hidVATPercent.Value);

                //hidVATFlagStr
                HiddenField hidVATFlagStr = (HiddenField)item.FindControl("hidVATFlagStr");
                addItem.VATFlagStr = hidVATFlagStr.Value;

                //Add item to list
                retLst.Add(addItem);
            }

            return retLst;
        }

        /// <summary>
        /// Format quantity for display
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatQty(object qty)
        {
            if (qty != null)
            {
                return decimal.Parse(qty.ToString()).ToString(string.Format("N{0}", this.QuantityDecimal));
            }
            return string.Empty;
        }
        #endregion
    }
}
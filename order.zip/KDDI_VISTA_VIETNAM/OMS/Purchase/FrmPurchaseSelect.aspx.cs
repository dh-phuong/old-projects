﻿using OMS.Models;
using OMS.Utilities;
using OMS.DAC;
using OMS.Controls;

using System;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections.Generic;
using System.Collections;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace OMS.Purchase
{
    /// <summary>
    /// Class PurchaseSelect
    /// Create Date: 2014/08/29
    /// Create Author: ISV-HUNG
    /// </summary>
    public partial class FrmPurchaseSelect : FrmBaseDetail
    {
        #region Constans
        private const int MAX_ROW_COUNT = 20;
        private DateTime DATE_TIME_DEFAULT = new DateTime(1900, 1, 1);
        #endregion

        #region Variable
        /// <summary>
        /// Focus controls ID
        /// </summary>
        public string focusControlsID = "";

        /// <summary>
        /// FractionType
        /// </summary>
        private FractionType _fractionType;

        //------2014/12/12 ISV-HUNG Add Start----------//
        /// <summary>
        /// Product CD Used
        /// </summary>
        public int _productCDUsed;
        //------2014/12/12 ISV-HUNG Add End----------//
        #endregion

        #region Property
        /// <summary>
        /// Get or set SalesID
        /// </summary>
        public int SalesID
        {
            get { return this.GetValueViewState<int>("SalesID"); }
            set
            {
                base.ViewState["SalesID"] = value;
            }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return this.GetValueViewState<DateTime>("OldUpdateDate"); }
            set
            {
                base.ViewState["OldUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Get or set VersionUpdateDate
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return this.GetValueViewState<DateTime>("OldVersionUpdateDate"); }
            set
            {
                base.ViewState["OldVersionUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Quantity decimal
        /// </summary>
        public int QuantityDecimal
        {
            get { return this.GetValueViewState<int>("QuantityDecimal"); }
            private set
            {
                base.ViewState["QuantityDecimal"] = value;
            }
        }

        /// <summary>
        /// DetailLists
        /// </summary>
        public IList<PurchaseSelectDataSource> DetailLists
        {
            get { return this.GetValueViewState<IList<PurchaseSelectDataSource>>("DetailLists"); }
            set
            {
                base.ViewState["DetailLists"] = value;
            }
        }

        /// <summary>
        /// AllPurchaseDone
        /// </summary>
        public bool AllPurchaseDone
        {
            get { return this.GetValueViewState<bool>("AllPurchaseDone"); }
            private set
            {
                base.ViewState["AllPurchaseDone"] = value;
            }
        }

        //-------2014/12/10 ISV-HUNG Add Start -----------//
        public string ProductCDUsedClass
        {
            get
            {
                if (this._productCDUsed != int.Parse(M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON))
                {
                    return "hidden";
                }
                return string.Empty;
            }
        }
        //------2014/12/12 ISV-HUNG Add End----------//

        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
        /// <summary>
        /// IDRef
        /// </summary>
        public IList<int> IDRef
        {
            get { return this.GetValueViewState<IList<int>>("IDRef"); }
            set
            {
                base.ViewState["IDRef"] = value;
            }
        }

        /// <summary>
        /// NoRef
        /// </summary>
        public IList<string> NoRef
        {
            get { return this.GetValueViewState<IList<string>>("NoRef"); }
            set
            {
                base.ViewState["NoRef"] = value;
            }
        }
        //----------------2014/12/16 ISV-HUNG Add End----------------------//

        /// <summary>
        /// Has detail data
        /// </summary>
        public bool HasData
        {
            get { return this.GetValueViewState<bool>("HasData"); }
            set
            {
                base.ViewState["HasData"] = value;
            }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e">EventArgs</param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Purchase";
            base.FormSubTitle = "Select";

            //Init Max Length
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //------2014/12/15 ISV-HUNG Add Start----------//
            //Ref
            //this.btnPurchaseRef.ServerClick += new EventHandler(btnPurchaseRef_Click);
            //------2014/12/15 ISV-HUNG Add End----------//

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                Config_HService configHService = new Config_HService(db);
                this.QuantityDecimal = configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;
                this._fractionType = (FractionType)int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                //-------2014/12/10 ISV-HUNG Edit Start -----------//
                //ProductCD Used
                this._productCDUsed = int.Parse(configHService.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED));
                //-------2014/12/10 ISV-HUNG Edit End -----------//
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_SALES_DETAIL;
            }

            if (!base.IsPostBack)
            {
                
                if(base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            var salesId = para["ID"].ToString();

                            this.ViewState["NoRef"] = para["NoRef"];
                            this.ViewState["IDRef"] = para["IDRef"];
                            this.ViewState["MesgID"] = para["MesgID"];

                            if (this.ViewState["MesgID"] != null)
                            {
                                var listID = (List<int>)this.ViewState["IDRef"];
                                var listNo = (List<string>)this.ViewState["NoRef"];
                                for (int i = 0; i < listNo.Count; i++)
                                {
                                    this.SetMessage(string.Empty, this.ViewState["MesgID"].ToString(), "Purchase", "Purchase No.", listID[i], listNo[i]);
                                }
                            }

                            //Get Sales ID
                            this.SalesID = int.Parse(salesId);

                            T_Sales_H salesH = this.GetSales(this.SalesID);

                            //Show data
                            this.ShowHeaderData(salesH);

                            //Set Mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (!this.CheckSearch())
            {
                return;
            }

            T_Sales_H salesH = this.GetSales(this.SalesID);
            if (salesH == null)
                return;

            //Show data
            this.ShowHeaderData(salesH);
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_CREATE, Models.DefaultButton.No, false, "Purchase");
        }

        /// <summary>
        /// Event Back Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, CommandEventArgs e)
        {
            base.BackPage();             
        }

        //------2014/12/15 ISV-HUNG Add Start----------//
        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnPurchaseRef_Click(object sender, EventArgs e)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();

            currentPage.Add("ID", this.SalesID);
            currentPage.Add("IDRef", this.IDRef);
            currentPage.Add("NoRef", this.NoRef);
            currentPage.Add("MesgID", M_Message.MSG_PROCESS_COMPLETED);

            nextPage.Add("ID", this.hidPurchaseID.Value);

            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_PURCHASE_SELECT);            
        }
        //------2014/12/15 ISV-HUNG Add End----------//

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetailChild_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //Get data
                PurchaseSelectInfo data = (PurchaseSelectInfo)e.Item.DataItem;

                //Find Control
                HtmlTableRow rowData = (HtmlTableRow)e.Item.FindControl("rowData");
                INumberTextBox txtQuantity = (INumberTextBox)e.Item.FindControl("txtQuantity");

                //Set color row
                //rowData.BgColor = data.DetailList[e.Item.ItemIndex].BackgroundColor;

                //Set decimal digit quantity
                txtQuantity.DecimalDigit = this.QuantityDecimal;
                txtQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtQuantity.MinimumValue = 0;
            }
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            PurchaseSelectDataSource data = (PurchaseSelectDataSource)e.Item.DataItem;

            //Find control
            Repeater rptCost = (Repeater)e.Item.FindControl("rptDetailChild");


            //----------------Set data cost detail----------------------//

            rptCost.DataSource = data.DetailList;
            rptCost.DataBind();
            //----------------End Set data cost detail-----------------//
        }
        #endregion

        #region Method
        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            switch (this.Mode)
            {
                case Mode.Insert:
                    break;
                case Mode.Update:
                    this.txtVendorCD.ReadOnly = true;
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Get Sales
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Sales
                return sales_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Get Purchase
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private T_Purchase_H GetPurchase(int id)
        {
            using (DB db = new DB())
            {
                Purchase_HService purchase_HService = new Purchase_HService(db);

                //Get Currency
                return purchase_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        /// <param name="sales">T_Sales_H</param>
        private void ShowHeaderData(T_Sales_H sales)
        {
            //Display header
            this.SalesID = sales.ID;

            this.txtSalesNo.Value = sales.SalesNo;
            this.txtQuotationNo.Value = sales.QuoteNo;

            this.OldUpdateDate = sales.UpdateDate;
            this.OldVersionUpdateDate = sales.VersionUpdateDate;

            //Show detail
            this.ShowDetailData();
        }

        /// <summary>
        /// Show detail data on form
        /// </summary>
        private void ShowDetailData()
        {
            using (DB db = new DB())
            {
                Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);
                var vendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtVendorCD.Value, M_Vendor.VENDOR_CODE_MAX_LENGTH);

                var listInfo = sales_D_CostService.GetForPurchaseSelect(this.txtSalesNo.Value, this.txtQuotationNo.Value, vendorCD);

                //Create list data
                IList<PurchaseSelectDataSource> dataList = this.CreateListDetail(listInfo);
                
                this.HasData = dataList.Count > 0;

                this.AllPurchaseDone = dataList.All(m => m.DetailList.All(d=>d.SalesQuantity - d.POQuantity == 0));

                //Set color
                //this.SetBackgroundColor(dataList);

                //Reset datasource
                this.DetailLists = dataList;
                this.rptDetail.DataSource = dataList;
                this.rptDetail.DataBind();
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret=true;
            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                    //Insert Data
                    List<string> purchaseNo = new List<string>();
                    //------2014/12/15 ISV-HUNG Add Start----------//
                    List<int> purchaseID = new List<int>();
                    //------2014/12/15 ISV-HUNG Add End----------//

                    //------2014/12/15 ISV-HUNG Edit Start----------//
                    //ret = this.InsertData(ref purchaseNo);
                    ret = this.InsertData(ref purchaseNo, ref purchaseID);
                    //------2014/12/15 ISV-HUNG Edit End----------//
                    
                    if (ret)
                    {
                        this.txtVendorCD.Value = string.Empty;
                        btnSearch_Click(null, null);
                        //------2014/12/15 ISV-HUNG Add Start----------//
                        var index = 0;
                        //------2014/12/15 ISV-HUNG Add End----------//
                        
                        foreach (var item in purchaseNo)
                        {
                            //------2014/12/15 ISV-HUNG Edit Start----------//
                            //this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Purchase", "Purchase No.", item);
                            this.SetMessage(string.Empty, M_Message.MSG_PROCESS_COMPLETED, "Purchase", "Purchase No.", purchaseID[index], item);
                            //------2014/12/15 ISV-HUNG Edit End----------//

                            //------2014/12/15 ISV-HUNG Add Start----------//
                            index++;
                            //------2014/12/15 ISV-HUNG Add End----------//
                        }

                        //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                        this.IDRef = purchaseID;
                        this.NoRef = purchaseNo;
                        //----------------2014/12/16 ISV-HUNG Add End----------------------//
                    }

                    break;
                case Mode.Update:
                    //Update Data
                    ret = this.UpdateData();
                    break;
                default:
                    ret = false;
                    break;
            }
        }

        /// <summary>
        /// Create detail list
        /// </summary>
        /// <param name="costList">T_Sales_D_Cost List</param>
        /// <returns></returns>
        private IList<PurchaseSelectDataSource> CreateListDetail(IList<PurchaseSelectInfo> costList)
        {
            IList<PurchaseSelectDataSource> dataList = new List<PurchaseSelectDataSource>();

            if (costList.Count == 0)
            {
                return dataList;
            }
            var firstItem = costList[0];

            //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
            //var vendorCd = firstItem.VendorCD;
            var vendorCd = string.Format("{0}{1}", firstItem.VendorCD,firstItem.VendorName);
            //----------------2014/12/16 ISV-HUNG Edit End----------------------//

            PurchaseSelectDataSource header = new PurchaseSelectDataSource();
            header.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeShow(firstItem.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
            header.VendorName = firstItem.VendorName;

            var detail = new List<PurchaseSelectInfo>();
            header.DetailList = detail;
            dataList.Add(header);

            foreach (var itemCost in costList)
            {
                //----------------2014/12/16 ISV-HUNG Add Start----------------------//
                var vendorCompare = string.Format("{0}{1}", itemCost.VendorCD, itemCost.VendorName);
                //----------------2014/12/16 ISV-HUNG Add End----------------------//

                //----------------2014/12/16 ISV-HUNG Edit Start----------------------//
                //if (vendorCd != itemCost.VendorCD)
                if (!string.Equals(vendorCd,vendorCompare))
                //----------------2014/12/16 ISV-HUNG Edit End----------------------//
                {
                    //Reset data
                    vendorCd = vendorCompare;
                    header = new PurchaseSelectDataSource();
                    header.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeShow(itemCost.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                    header.VendorName = itemCost.VendorName;

                    detail = new List<PurchaseSelectInfo>();
                    header.DetailList = detail;
                    dataList.Add(header);
                }

                var itemDetail = new PurchaseSelectInfo();

                itemDetail.SalesCostIntenalID = itemCost.SalesCostIntenalID;
                itemDetail.No = itemCost.No;
                itemDetail.Quantity = itemCost.SalesQuantity - itemCost.POQuantity; ;
                itemDetail.POQuantity = itemCost.POQuantity;
                itemDetail.DeliQuantity = itemCost.DeliQuantity;
                itemDetail.SalesQuantity = itemCost.SalesQuantity;
                itemDetail.VatType = itemCost.VatType;
                itemDetail.VatTypeDisp = itemCost.VatTypeDisp;
                itemDetail.VatRatio = itemCost.VatRatio;
                itemDetail.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeShow(itemCost.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                itemDetail.VendorName = itemCost.VendorName;
                itemDetail.ProductID = itemCost.ProductID;
                itemDetail.ProductCD = itemCost.ProductCD;
                itemDetail.ProductName = itemCost.ProductName;
                itemDetail.DecimalType = itemCost.DecimalType;
                itemDetail.UnitPrice = itemCost.UnitPrice;
                itemDetail.CurrencyID = itemCost.CurrencyID;
                itemDetail.CurrencyName = itemCost.CurrencyName;
                itemDetail.SalesNo = itemCost.SalesNo;
                itemDetail.QuotationNo = itemCost.QuotationNo;

                detail.Add(itemDetail);
            }

            return dataList;
        }

        /// <summary>
        /// Check search
        /// </summary>
        /// <returns></returns>
        private bool CheckSearch()
        {
            using (DB db = new DB())
            {
                VendorService vendorService = new VendorService(db);
                //--------------------------------Vendor check----------------------------------------------------------//
                this.txtVendorNm.Value = string.Empty;
                if (!this.txtVendorCD.IsEmpty && this.txtVendorCD.Value != M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    //Check exists
                    var vendor = vendorService.GetByCD(this.txtVendorCD.Value);
                    if (vendor == null)
                    {
                        base.SetMessage(this.txtVendorCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Vendor Code");
                        this.txtVendorNm.Value = string.Empty;
                    }
                    else
                    {
                        this.txtVendorNm.Value = vendor.VendorName1;
                    }
                }
                //--------------------------------End Vendor check----------------------------------------------------------//
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Set confirm data
        /// </summary>
        private void SetConfirmData()
        {
            if (!this.txtVendorCD.IsEmpty)
            {
                using (DB db = new DB())
                {
                    VendorService vendorService = new VendorService(db);
                    var vendor = vendorService.GetByCD(this.txtVendorCD.Value);
                    if (vendor != null && vendor.StatusFlag == 0)
                    {
                        this.txtVendorNm.Value = vendor.VendorName1;
                    }
                    else
                    {
                        this.txtVendorNm.Value = string.Empty;
                    }
                }
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                Currency_HService currency_HService = new Currency_HService(db);
                Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);
                Purchase_DService purchase_DService = new Purchase_DService(db);

                //if (!this.CheckSearch())
                //{
                //    return false;
                //}

                //--------------------------------Check Bill no overflow-----------------------------------------------------//
                if (this.IsPurNoOverflow(db))
                {
                    base.SetMessage(M_Message.MSG_SIZE_MAX_NO, "Bill No");
                }
                //--------------------------------End Check Bill no overflow-----------------------------------------------------//

                //--------------------------------Check Select row--------------------------------------------------------------//
                var listDetail = this.GetData();
                var isCheck = listDetail.Any(m => m.DetailList.Any(d=>d.CheckFlag));
                if (!isCheck)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SELECT_ROW_DATA);

                    this.DetailLists = listDetail;
                    this.rptDetail.DataSource = listDetail;
                    this.rptDetail.DataBind();

                    return false;
                }
                //--------------------------------End Check Select row--------------------------------------------------------------//

                //--------------------------------Check Sales change data----------------------------------------------------------//
                T_Sales_H sales = this.GetSales(this.SalesID);
                if (sales.VersionUpdateDate != this.OldVersionUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);

                    this.DetailLists = listDetail;
                    this.rptDetail.DataSource = listDetail;
                    this.rptDetail.DataBind();

                    return false;
                }
                //--------------------------------End Check Sales change data----------------------------------------------------------//
                bool isCurrencyDifference = false;

                for (int index = 0; index < listDetail.Count; index++)
                {
                    string vendorCDSelect = string.Empty;
                    int currencyId = -1;

                    var item = listDetail[index];
                    for (int i = 0; i < item.DetailList.Count; i++)
                    {
                        var childItem = item.DetailList[i];
                        if (!childItem.CheckFlag)
                        {
                            continue;
                        }
                        if (string.IsNullOrEmpty(vendorCDSelect))
                        {
                            vendorCDSelect = childItem.VendorCD;
                            currencyId = childItem.CurrencyID;
                        }

                        //Check required
                        if (!childItem.Quantity.HasValue)
                        {
                            base.SetMessage(string.Format("{0}_txtQuantity_{1}", index,i), M_Message.MSG_REQUIRE_GRID, "Q'ty", string.Format("{0}/{1}",index+1,i+1));
                        }
                        else
                        {
                            //Check must greater than 0
                            if (childItem.Quantity.Value == 0)
                            {
                                base.SetMessage(string.Format("{0}_txtQuantity_{1}", index, i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty",0, string.Format("{0}/{1}", index+1, i+1));
                            }

                            var dbRemaindQty = purchase_DService.GetRemainQtyBySalesCostID(childItem.SalesCostIntenalID,-1);
                            var dbRemaindQtyStr = dbRemaindQty.ToString(string.Format("N{0}",this.QuantityDecimal));
                            if (childItem.Quantity.Value > dbRemaindQty)
                            {
                                base.SetMessage(string.Format("{0}_txtQuantity_{1}", index, i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", dbRemaindQtyStr, string.Format("{0}/{1}", index + 1, i + 1));
                            }
                        }

                        ////Check same vendors selection
                        //if (!string.Equals(vendorCDSelect, item.VendorCD))
                        //{
                        //    base.SetMessage(string.Format("{0}_txtQuantity_{1}", index, i), M_Message.MSG_SELECT_ROW_SAME_VALUE, "Vendor");

                        //    if (!this.txtVendorCD.ReadOnly)
                        //    {
                        //        this.txtVendorCD.Value = string.Empty;
                        //        this.txtVendorNm.Value = string.Empty;
                        //    }

                        //    this.btnSearch_Click(null, null);
                        //}
                        //else
                        //{
                        //    //Check same currencies selection
                        //    if (currencyId != childItem.CurrencyID)
                        //    {
                        //        base.SetMessage(string.Format("{0}_txtQuantity_{1}", index, i), M_Message.MSG_SELECT_ROW_SAME_VALUE, "Currency");
                        //    }
                        //}

                        if (string.Equals(vendorCDSelect, item.VendorCD))
                        {
                            //Check same currencies selection
                            if (currencyId != childItem.CurrencyID)
                            {
                                isCurrencyDifference = true;
                            }
                        }
                        else
                        {
                            vendorCDSelect = string.Empty;
                        }
                    }
                }

                if (isCurrencyDifference)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_SELECT_ROW_SAME_VALUE, "Currency");
                }

                //Check overflow
                if (base.HaveError == false && this.CheckOverflowData())
                {
                    return false;
                }

                this.DetailLists = listDetail;
                this.rptDetail.DataSource = listDetail;
                this.rptDetail.DataBind();
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Get Vendor Name
        /// </summary>
        /// <param name="in1">VendorCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetVendorName(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new VendorService(db);

                    var data = service.GetByCD(OMS.Utilities.EditDataUtil.ToFixCodeDB(in1, M_Vendor.VENDOR_CODE_MAX_LENGTH));
                    if (data != null && data.ID != Constant.DEFAULT_ID && data.StatusFlag != 1)
                    {
                        var result = new
                        {
                            vendorName1 = data.VendorName1,
                            vendorCD = EditDataUtil.ToFixCodeShow(data.VendorCD,M_Vendor.VENDOR_CODE_MAX_SHOW)
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return null;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Check overflow Purchase No
        /// </summary>
        /// <returns></returns>
        private bool IsPurNoOverflow(DB db)
        {
            Purchase_HService purchase_HService = new Purchase_HService(db);
            var cur = purchase_HService.GetCurrentPurchaseNo();

            return cur > Constants.MAX_NO - 1;
        }

        /// <summary>
        /// Get Data
        /// </summary>
        private IList<PurchaseSelectDataSource> GetData()
        {
            IList<PurchaseSelectDataSource> ret = this.DetailLists;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                var index = item.ItemIndex;
                var listDetail = ret[index].DetailList;

                Repeater rptDetailChild = (Repeater)item.FindControl("rptDetailChild");
                foreach (RepeaterItem itemDetail in rptDetailChild.Items)
                {
                    HtmlInputCheckBox chkSellDel = (HtmlInputCheckBox)itemDetail.FindControl("chkSellDel");
                    INumberTextBox txtQuantity = (INumberTextBox)itemDetail.FindControl("txtQuantity");
                    HiddenField hidSalesCostIntenalID = (HiddenField)itemDetail.FindControl("hidSalesCostIntenalID");
                    var salesCostIntenalID = Convert.ToInt32(hidSalesCostIntenalID.Value);

                    var purchaseInfo = listDetail.Where(p => p.SalesCostIntenalID == salesCostIntenalID).SingleOrDefault();
                    if (purchaseInfo != null)
                    {
                        purchaseInfo.CheckFlag = chkSellDel.Checked;
                        purchaseInfo.Quantity = txtQuantity.Value;
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="purchaseNo">Purchase No</param>
        /// <param name="purchaseID">Purchase ID</param>
        /// <returns></returns>
        //------2014/12/15 ISV-HUNG Edit Start----------//
        //private bool InsertData(ref List<string> purchaseNo)
        private bool InsertData(ref List<string> purchaseNo, ref List<int> purchaseID)
        //------2014/12/15 ISV-HUNG Edit End----------//
        {
            try
            {
                if (!this.CheckInput())
                {
                    return false;
                }
                int ret = 0;

                //Get data from screen
                IList<PurchaseSelectDataSource> listScreenData = this.GetData();

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    Purchase_HService purchase_HService = new Purchase_HService(db);
                    Purchase_DService purchase_DService = new Purchase_DService(db);
                    Purchase_CService purchase_CService = new Purchase_CService(db);
                    Config_DService config_DService = new Config_DService(db);
                    TNoService noService = new TNoService(db);

                    //set data insert
                    List<T_Purchase_H> header = new List<T_Purchase_H>();
                    List<T_Purchase_D> detail = new List<T_Purchase_D>();

                    this.SetPurchaseData(db,listScreenData, header, detail);

                    T_Sales_H salesH = sales_HService.GetBySalesCostInternalID(detail[0].SalesCostID);

                    //Update Sales Header
                    salesH.VersionUpdateUID = LoginInfo.User.ID;
                    salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                    ret = sales_HService.UpdateVersion(salesH);

                    //Insert PO header
                    if (ret == 1)
                    {
                        foreach (var item in header)
                        {
                            //Purchase no
                            var curPurchaseNo = noService.CreateNo(T_No.PurchaseNo);
                            item.PurchaseNo = curPurchaseNo;
                            purchaseNo.Add(curPurchaseNo);

                            //Purchase date
                            item.PurchaseDate = db.NowDate;

                            //---------------Add 2015/01/06 ISV-HUNG-----------------//
                            //Expiry Date
                            var expiryDate = config_DService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase));
                            if (!expiryDate.HasValue)
                            {
                                item.ExpiryDate = DATE_TIME_DEFAULT;
                            }
                            else
                            {
                                item.ExpiryDate = item.PurchaseDate.AddDays(expiryDate.Value);
                            }

                            //Payment Date
                            expiryDate = config_DService.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase_Payment_Date));
                            if (!expiryDate.HasValue)
                            {
                                item.PaymentDate = DATE_TIME_DEFAULT;
                            }
                            else
                            {
                                item.PaymentDate = item.PurchaseDate.AddDays(expiryDate.Value);
                            }
                            //---------------Add 2015/01/06 ISV-HUNG-----------------//

                            ret = purchase_HService.Insert(item);

                            //insert detail
                            if (ret != 0)
                            {
                                //------2014/12/15 ISV-HUNG Add Start----------//
                                purchaseID.Add(ret);
                                //------2014/12/15 ISV-HUNG Add End----------//

                                var detailList = detail.Where(d => d.HID.Equals(item.ID));

                                //Get detail
                                foreach (var itemDetail in detailList)
                                {
                                    itemDetail.HID = ret;
                                    purchase_DService.Insert(itemDetail);
                                }

                                var condition = new T_Purchase_C();
                                condition.HID = ret;
                                condition.Conditions = string.Empty;
                                purchase_CService.Insert(condition);
                            }
                        }
                    }
                    else
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    //Commit
                    db.Commit();
                }

            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.PurchaseNo))
                {
                    base.SetMessage(string.Empty,M_Message.MSG_SIZE_MAX_NO, "Purchase No");
                }

                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(Models.Constant.T_PURCHASE_H_UN))
                {
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Set Purchase data
        /// </summary>
        /// <param name="db">db</param>
        /// <param name="db">listScreenData</param>
        /// <param name="header">List T_Purchase_H</param>
        /// <param name="detail">List T_Purchase_D</param>
        private void SetPurchaseData(DB db,IList<PurchaseSelectDataSource> listScreenData, List<T_Purchase_H> header, List<T_Purchase_D> detail)
        {
            //Create service
            Sales_HService sales_HService = new Sales_HService(db);
            Sales_D_CostService sales_D_CostService = new Sales_D_CostService(db);
            VendorService vendorService = new VendorService(db);
            Currency_HService currency_HService = new Currency_HService(db);

            var hid = 1;
            foreach (var item in listScreenData)//List header
            {
                if (item.DetailCheckedList.Count == 0)
                {
                    continue;
                }

                //Get info from sales header
                T_Sales_H salesH = sales_HService.GetBySalesCostInternalID(item.DetailCheckedList[0].SalesCostIntenalID);

                //Get Currency
                int currencyID = item.DetailCheckedList[0].CurrencyID;
                M_Currency_H currencyH = currency_HService.GetByID(currencyID);

                //Get vendor master
                M_Vendor vendor = vendorService.GetByCD(item.DetailCheckedList[0].VendorCD);
                    
                //set purchase details
                int no = 1;
                decimal totalUSD = 0;
                decimal totalVATUSD = 0;

                foreach (var childItem in item.DetailCheckedList)//List detail
                {
                    T_Sales_D_Cost salesC = sales_D_CostService.GetByPK(childItem.SalesCostIntenalID);
                    T_Purchase_D purM = this.GetPurchaseDetail(salesC, salesH, childItem);
                    purM.HID = hid;
                    purM.No = no;
                    detail.Add(purM);

                    totalUSD += purM.Total.Value;
                    totalVATUSD += purM.Vat.Value;

                    no += 1;
                }

                //Set purchase Header
                var headerAdd = new T_Purchase_H();
                headerAdd.ID = hid;

                //header.ExpiryDate = accH.ExpiryDate;
                headerAdd.PurchaseNo = String.Empty;
                headerAdd.QuoteNo = salesH.QuoteNo;
                headerAdd.SalesNo = salesH.SalesNo;
                headerAdd.IssuedFlag = 0;
                headerAdd.DeleteFlag = 0;
                headerAdd.FinishFlag = 0;
                headerAdd.CurrencyID = currencyID;
                headerAdd.PurchaseDate = db.NowDate;
                headerAdd.SubjectName = salesH.SubjectName;
                headerAdd.PreparedCD = salesH.PreparedCD;
                headerAdd.PreparedName = salesH.PreparedName;
                headerAdd.ApprovedCD = salesH.ApprovedCD;
                headerAdd.ApprovedName = salesH.ApprovedName;

                //-------2014/12/08 ISV-HUNG Edit Start -----------//
                if (item.DetailCheckedList[0].VendorCD == M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    headerAdd.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(item.DetailCheckedList[0].VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                    headerAdd.VendorName = item.DetailCheckedList[0].VendorName;
                }
                else if(vendor != null && vendor.StatusFlag == 0)
                {
                    headerAdd.VendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendor.VendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                    headerAdd.VendorName = vendor.VendorName1;
                    headerAdd.VendorAddress1 = vendor.VendorAddress1;
                    headerAdd.VendorAddress2 = vendor.VendorAddress2;
                    headerAdd.VendorAddress3 = vendor.VendorAddress3;
                    headerAdd.Tel = vendor.Tel;
                    headerAdd.Fax = vendor.FAX;
                    headerAdd.ContactPerson = vendor.ContactPerson;
                }
                //-------2014/12/08 ISV-HUNG Edit End -----------//

                headerAdd.Total = totalUSD;
                headerAdd.Vat = totalVATUSD;
                headerAdd.GrandTotal = totalUSD + totalVATUSD;
                //headerAdd.Confirmed = Constant.DEFAULT_CONFIRMED;
                headerAdd.Confirmed = string.Empty;
                headerAdd.Position = Constant.DEFAULT_POSITION;
                headerAdd.Confirmed = Constant.DEFAULT_REPRESENT;

                headerAdd.MethodVat = short.Parse(M_Config_D.METHOD_VAT_EACH);//Vat On Each item
                headerAdd.VatType = 255;//Not set for each item method
                headerAdd.VatRatio = 0;//Not set for each item method

                headerAdd.Memo = salesH.Memo;
                headerAdd.IssuedDate = DATE_TIME_DEFAULT;
                headerAdd.IssuedUID = 0;

                //---------------Add 2015/01/06 ISV-HUNG-----------------//
                headerAdd.PaymentDate = DATE_TIME_DEFAULT;
                //---------------Add 2015/01/06 ISV-HUNG-----------------//


                headerAdd.CreateUID = this.LoginInfo.User.ID;
                headerAdd.UpdateUID = this.LoginInfo.User.ID;

                header.Add(headerAdd);

                hid++;
            }
        }

        /// <summary>
        /// Ger Purchase Detail
        /// </summary>
        /// <param name="salesC">T_Sales_D_Cost</param>
        /// <param name="salesH">T_Sales_H</param>
        /// <param name="purSec">PurchaseSelectInfo</param>
        /// <param name="currencyH">M_Currency_H</param>
        /// <returns></returns>
        public T_Purchase_D GetPurchaseDetail(T_Sales_D_Cost salesC, T_Sales_H salesH, PurchaseSelectInfo purSec)
        {
            T_Purchase_D ret = new T_Purchase_D();
            ret.SalesCostID = purSec.SalesCostIntenalID;
            ret.ProductID = purSec.ProductID;
            ret.ProductCD = purSec.ProductCD;
            ret.ProductName = purSec.ProductName;
            ret.Description = salesC.Description;
            ret.UnitPrice = salesC.UnitPrice;
            ret.VatType = salesC.VatType;
            ret.VatRatio = salesC.VatRatio;
            ret.Quantity = purSec.Quantity;
            ret.UnitID = salesC.UnitID;
            ret.Total =Fraction.Round(this._fractionType, (decimal)(ret.UnitPrice * ret.Quantity), 2);
            ret.Vat = Fraction.Round(this._fractionType, (ret.Total.Value * ret.VatRatio.Value) / 100, 2);
            ret.DeliverQuantity = 0;
            ret.DeliverDate = DATE_TIME_DEFAULT;
            ret.Remark = string.Empty;

            return ret;
        }

        /// <summary>
        /// Update data
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            return true;
        }

        /// <summary>
        /// Format display quantity
        /// </summary>
        /// <param name="qty"></param>
        /// <returns></returns>
        protected string FormatQty(object qty)
        {
            if (qty != null)
            {
                return decimal.Parse(qty.ToString()).ToString(string.Format("N{0}", this.QuantityDecimal));
            }
            return string.Empty;
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Check Overflow Q'ty
        /// </summary>
        /// <returns></returns>
        private bool CheckOverflowData()
        {
            using (DB db = new DB())
            {
                Sales_D_SellService salesSellServive = new Sales_D_SellService(db);
                Currency_HService crcHService = new Currency_HService(db);

                var uiItems = this.GetData();

                //var selected = uiItems.Any(s => s.DetailList.Any(d=>d.CheckFlag));
                //if (!selected)
                //{
                //    base.SetMessage(string.Empty, M_Message.MSG_PLEASE_SELECT, "row data");
                //    return false;
                //}

                int index = 0;
                bool haveError = false;
                for (int i = 0; i < uiItems.Count; i++)
                {
                    var sumTotal = 0m;
                    var sumVat = 0m;
                    M_Currency_H currencyH = null;
                    var dec = 0;
                    decimal maxValue = 0m;
                    decimal maxQuantity = 0m;
                    string numberFormat = string.Empty;

                    var invCost = uiItems[i];

                    int indexChild = 0;
                    for (int j = 0; j < invCost.DetailList.Count; j++)
                    {
                        var chilInvCost = invCost.DetailList[j];
                        if (chilInvCost.CheckFlag)
                        {
                            if (currencyH == null)
                            {
                                currencyH = crcHService.GetByID(chilInvCost.CurrencyID);
                            }

                            var unitPrice = chilInvCost.UnitPrice;

                            dec = currencyH.DecimalType == ((int)ExchangeRateDecType.Decimal) ? 2 : 0;
                            numberFormat = string.Format("N{0}", dec);

                            var subTotal = Fraction.Round(this._fractionType, unitPrice.Value * chilInvCost.Quantity.GetValueOrDefault(), 2);
                            var subVat = Fraction.Round(this._fractionType, (subTotal * chilInvCost.VatRatio.Value) / 100, 2);

                            //maxValue = dec > 0 ? MAX_UNIT_PRICE_DECIMAL : MAX_UNIT_PRICE_NOT_DECIMAL;
                            //if (unitPrice > maxValue)
                            //{
                            //    this.SetMessage(string.Format("{0}_txtQuantity_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), (string.Format("{0}/{1}", i + 1, j + 1)));
                            //    haveError = true;
                            //}

                            maxValue = dec > 0 ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                            if (unitPrice.Value != 0)
                            {
                                maxQuantity = Fraction.Round(this._fractionType, (maxValue / Math.Abs(unitPrice.Value)), dec);

                                if (chilInvCost.Quantity >= maxQuantity)
                                {
                                    this.SetMessage(string.Format("{0}_txtQuantity_{1}", index, indexChild), M_Message.MSG_LESS_THAN_GRID, "Q'ty", maxQuantity.ToString(numberFormat), (string.Format("{0}/{1}", index + 1, indexChild + 1)));
                                    haveError = true;
                                }
                            }

                            //if (subTotal > maxValue)
                            //{
                            //    this.SetMessage(string.Format("{0}_txtQuantity_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total", maxValue.ToString(numberFormat), (string.Format("{0}/{1}", i + 1, j + 1)));
                            //    haveError = true;
                            //}

                            //if (chilInvCost.VatType == (int)VATFlg.Exclude)
                            //{
                            //    maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                            //    if (subVat > maxValue)
                            //    {
                            //        this.SetMessage(string.Format("{0}_txtQuantity_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Sub Total Vat", maxValue.ToString(numberFormat), (string.Format("{0}/{1}", i + 1, j + 1)));
                            //        haveError = true;
                            //    }
                            //}

                            sumTotal += subTotal;
                            sumVat += subVat;
                       }
                       
                        indexChild++;
                    }

                    if (!haveError)
                    {
                        maxValue = dec > 0 ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                        if (sumTotal > maxValue)
                        {
                            var quantityAllow = Fraction.Round(this._fractionType, (Math.Abs(sumTotal - maxValue) / Math.Abs(invCost.DetailCheckedList[0].UnitPrice.Value)), dec);

                            quantityAllow = invCost.DetailCheckedList[0].Quantity.Value - quantityAllow;

                            this.SetMessage(string.Format("{0}_txtQuantity_{1}", i, 0), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", quantityAllow.ToString(numberFormat), (string.Format("{0}/{1}", i + 1, 1)));
                            haveError = true;
                        }

                        //if (sumTotal > maxValue)
                        //{
                        //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL_GRID, "Total", maxValue.ToString(numberFormat), index + 1);
                        //    haveError = true;
                        //}
                        //maxValue = dec > 0 ? MAX_VAT_VALUE_DECIMAL : MAX_VAT_VALUE_NOT_DECIMAL;
                        //if (sumVat > maxValue)
                        //{
                        //    this.SetMessage(string.Empty, M_Message.MSG_LESS_THAN_EQUAL_GRID, "VAT", maxValue.ToString(numberFormat), index + 1);
                        //    haveError = true;
                        //}
                    }

                    index++;
                }

                this.rptDetail.DataSource = uiItems;
                this.rptDetail.DataBind();

                return haveError;
            }
        }

        ///// <summary>
        ///// Get Value
        ///// </summary>
        ///// <typeparam name="T">Type of value</typeparam>
        ///// <param name="property">property</param>
        ///// <returns></returns>
        //protected T GetValueViewState<T>(string property)
        //{
        //    var val = base.ViewState[property];
        //    if (val == null)
        //    {
        //        return default(T);
        //    }
        //    return (T)val;
        //}
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Collections;
using OMS.DAC;
using OMS.Models;
using OMS.Utilities;
using NPOI.SS.UserModel;
using OMS.Reports.EXCEL;

namespace OMS.Purchase
{
    /// <summary>
    /// Purchase List
    /// Author: ISV-Giam
    /// </summary>
    public partial class FrmPurchaseList : FrmBaseList
    {
        #region Constant Excel
        private const string EXCEL_PURCHASE_DOWNLOAD = "Purchase_{0}.xls";
        private const string EXCEL_PURCHASE_CREATE_DOWNLOAD = "P.O List_{0}.xls";
        private const string EXCEL_PURCHASE_UNCREATE_DOWNLOAD = "Uncreate P.O List_{0}.xls";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        #endregion

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set PurchaseExcelFlag
        /// </summary>
        public string PurchaseExcelFlag
        {
            get { return (string)ViewState["PurchaseExcelFlag"]; }
            set { ViewState["PurchaseExcelFlag"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Purchase";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = "Expired";
            this.PagingHeader.DangerText = "Deleted";

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);

            //Init Max Length
            this.txtPurchaseNo.MaxLength = T_Purchase_H.PURCHASE_NO_MAX_LENGTH;
            this.txtSalesNo.MaxLength = T_Sales_H.SALES_NO_MAX_LENGTH;
            this.txtQuoteNo.MaxLength = T_Quote_H.QUOTE_NO_MAX_LENGTH;
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_LENGTH;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtSubject.MaxLength = T_Quote_H.PROJECT_NAME_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Purchase);

            if (!base._authority.IsPurchaseView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_MAIN_MENU;
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    base.DisabledLink(this.btnExcel, !base._authority.IsPurchaseExcel);

                    //Save Back Page Info
                    base.SaveBackPage();

                    //Get paramater
                    Hashtable para = base.GetParamater();

                    //Check Para
                    if (para != null)
                    {
                        //Back URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        this.ShowCondition(para);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.Collapse = string.Empty;
            }

            //Set Back URL
            this.btnBack.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// btnSearch Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var filename = string.Empty;
                if (this.PurchaseExcelFlag.Equals("CreatePOList"))
                {
                    filename = string.Format(EXCEL_PURCHASE_CREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else if (this.PurchaseExcelFlag.Equals("Excel"))
                {
                    filename = string.Format(EXCEL_PURCHASE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                else
                {
                    filename = string.Format(EXCEL_PURCHASE_UNCREATE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                }
                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = "application/vnd.ms-excel";
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// New
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(null);
        }

        /// <summary>
        /// Adding a new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        /// <summary>
        /// Detail page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition(e.CommandArgument);
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Quote Date
            this.dtPurchaseDateFrom.Value = DateTime.Now.AddMonths(-3);
            //this.dtPurchaseDateTo.Value = DateTime.Now;
            this.dtPurchaseDateTo.Value = null;

            // Default data
            this.hdFinishedDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdDeletedDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            this.hdPurchaseDateFromDefault.Value = this.dtPurchaseDateFrom.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);
            //this.hdPurchaseDateToDefault.Value = this.dtPurchaseDateTo.Value.Value.ToString(OMS.Utilities.Constants.FMT_DATE);

            //Set data for combobox
            this.SetDataCombobox(this.cmbFinishedData, this.hdFinishedDefault.Value);
            this.SetDataCombobox(this.cmbDeletedData, this.hdDeletedDefault.Value);

            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            //Disable button
            base.DisabledLink(this.btnNew, !base._authority.IsPurchaseNew);
            base.DisabledLink(this.btnExcel, !base._authority.IsPurchaseExcel);
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition(object id)
        {
            Hashtable currentPage = new Hashtable();
            Hashtable nextPage = new Hashtable();

            currentPage.Add(this.txtPurchaseNo.ID, this.txtPurchaseNo.Value);
            currentPage.Add(this.txtSalesNo.ID, this.txtSalesNo.Value);
            currentPage.Add("SalesNoReadOnly", this.txtSalesNo.ReadOnly);
            currentPage.Add(this.txtQuoteNo.ID, this.txtQuoteNo.Value);
            currentPage.Add("QuoteNoReadOnly", this.txtQuoteNo.ReadOnly);
            currentPage.Add(this.dtPurchaseDateFrom.ID, this.dtPurchaseDateFrom.Value);
            currentPage.Add(this.dtPurchaseDateTo.ID, this.dtPurchaseDateTo.Value);
            currentPage.Add(this.cmbFinishedData.ID, this.cmbFinishedData.SelectedValue);
            currentPage.Add(this.cmbDeletedData.ID, this.cmbDeletedData.SelectedValue);
            currentPage.Add(this.txtVendorCD.ID, this.txtVendorCD.Value);
            M_Vendor ven = this.GetVendorModel(this.txtVendorCD.Value);
            if (ven != null)
            {
                currentPage.Add(this.txtVendorName.ID, ven.VendorName1);
            }
            else
            {
                currentPage.Add(this.txtVendorName.ID, string.Empty);
            }
            currentPage.Add(this.txtPreparedCD.ID, this.txtPreparedCD.Value);
            M_User u = this.GetUserModel(this.txtPreparedCD.Value);
            if (u != null)
            {
                currentPage.Add(this.txtPreparedName.ID, u.UserName1);
            }
            else
            {
                currentPage.Add(this.txtPreparedName.ID, string.Empty);
            }
            currentPage.Add(this.txtSubject.ID, this.txtSubject.Value);
            currentPage.Add("FinishedFlag", this.cmbFinishedData.SelectedValue);
            currentPage.Add("DeletedFlag", this.cmbDeletedData.SelectedValue);
            currentPage.Add("hdSalesNoDefaut", this.hdSalesNoDefaut.Value);
            currentPage.Add("hdQuotationNoDefaut", this.hdQuotationNoDefaut.Value);
            currentPage.Add("hdFinishedDataDefaultRef", this.hdFinishedDataDefaultRef.Value);
            currentPage.Add("hdDeletedDataDefaultRef", this.hdDeletedDataDefaultRef.Value);
            currentPage.Add("hdFinishedDefault", this.hdFinishedDefault.Value);
            currentPage.Add("hdDeletedDefault", this.hdDeletedDefault.Value);
            currentPage.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            currentPage.Add("CurrentPage", this.PagingHeader.CurrentPage);

            //------------------ ISV-GIAM Edited 2014/12/29 ------------------
            currentPage.Add("SortField", this.HeaderGrid.SortField);
            currentPage.Add("SortDirec", this.HeaderGrid.SortDirec);
            //----------------------------------------------------------------

            nextPage.Add("ID", id);

            //Next Page
            base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_PURCHASE_LIST);
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            if (data.ContainsKey(this.txtPurchaseNo.ID))
            {
                this.txtPurchaseNo.Value = data[this.txtPurchaseNo.ID].ToString();
            }

            if (data.ContainsKey(this.txtSalesNo.ID))
            {
                this.txtSalesNo.Value = data[this.txtSalesNo.ID].ToString();
                this.hdSalesNoDefaut.Value = this.txtSalesNo.Value;
            }

            if (data.ContainsKey(this.txtQuoteNo.ID))
            {
                this.txtQuoteNo.Value = data[this.txtQuoteNo.ID].ToString();
                this.hdQuotationNoDefaut.Value = this.txtQuoteNo.Value;
            }

            this.dtPurchaseDateFrom.Value = null;
            if (data.ContainsKey(this.dtPurchaseDateFrom.ID))
            {
                if (data[this.dtPurchaseDateFrom.ID] != null)
                {
                    this.dtPurchaseDateFrom.Value = (DateTime)data[this.dtPurchaseDateFrom.ID];
                }
            }

            this.dtPurchaseDateTo.Value = null;
            if (data.ContainsKey(this.dtPurchaseDateTo.ID))
            {
                if (data[this.dtPurchaseDateTo.ID] != null)
                {
                    this.dtPurchaseDateTo.Value = (DateTime)data[this.dtPurchaseDateTo.ID];
                }
            }

            if (data.ContainsKey(this.cmbFinishedData.ID))
            {
                this.cmbFinishedData.SelectedValue = data[this.cmbFinishedData.ID].ToString();
            }

            if (data.ContainsKey(this.cmbDeletedData.ID))
            {
                this.cmbDeletedData.SelectedValue = data[this.cmbDeletedData.ID].ToString();
            }

            if (data.ContainsKey(this.txtVendorCD.ID))
            {
                this.txtVendorCD.Value = data[this.txtVendorCD.ID].ToString();
            }

            if (data.ContainsKey(this.txtPreparedCD.ID))
            {
                this.txtPreparedCD.Value = data[this.txtPreparedCD.ID].ToString();
            }

            if (data.ContainsKey(this.txtSubject.ID))
            {
                this.txtSubject.Value = data[this.txtSubject.ID].ToString();
            }

            if (data.ContainsKey("SalesNoReadOnly"))
            {
                this.txtSalesNo.ReadOnly = (bool)data["SalesNoReadOnly"];
            }

            if (data.ContainsKey("QuoteNoReadOnly"))
            {
                this.txtQuoteNo.ReadOnly = (bool)data["QuoteNoReadOnly"];
            }

            if (data.ContainsKey("FinishedFlag"))
            {
                this.cmbFinishedData.SelectedValue = data["FinishedFlag"].ToString();
                this.hdFinishedDataDefaultRef.Value = data["FinishedFlag"].ToString();
            }

            if (data.ContainsKey("DeletedFlag"))
            {
                this.cmbDeletedData.SelectedValue = data["DeletedFlag"].ToString();
                this.hdDeletedDataDefaultRef.Value = data["DeletedFlag"].ToString();
            }

            if (data.ContainsKey("hdSalesNoDefaut"))
            {
                this.hdSalesNoDefaut.Value = data["hdSalesNoDefaut"].ToString();
            }

            if (data.ContainsKey("hdQuotationNoDefaut"))
            {
                this.hdQuotationNoDefaut.Value = data["hdQuotationNoDefaut"].ToString();
            }

            if (data.ContainsKey("hdFinishedDataDefaultRef"))
            {
                this.hdFinishedDataDefaultRef.Value = data["hdFinishedDataDefaultRef"].ToString();
            }

            if (data.ContainsKey("hdDeletedDataDefaultRef"))
            {
                this.hdDeletedDataDefaultRef.Value = data["hdDeletedDataDefaultRef"].ToString();
            }

            if (data.ContainsKey("hdFinishedDefault"))
            {
                this.hdFinishedDefault.Value = data["hdFinishedDefault"].ToString();
            }

            if (data.ContainsKey("hdDeletedDefault"))
            {
                this.hdDeletedDefault.Value = data["hdDeletedDefault"].ToString();
            }

            if (data.ContainsKey("CurrentPage"))
            {
                int curPage = int.Parse(data["CurrentPage"].ToString());
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
            }

            if (data.ContainsKey("NumRowOnPage"))
            {
                int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                this.PagingHeader.NumRowOnPage = rowOfPage;
            }

            //------------------ ISV-GIAM Edited 2014/12/29 ------------------
            if (data.ContainsKey("SortField"))
            {
                this.HeaderGrid.SortField = data["SortField"].ToString();
            }

            if (data.ContainsKey("SortDirec"))
            {
                this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            }
            //----------------------------------------------------------------
        }

        /// <summary>
        /// Load data for grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }

            //Reset Name for condition search
            this.ResetName();

            int totalRow = 0;

            IList<PurchaseHeaderResult> listResult;
            PurchaseHeaderSearch modelInput = this.GetSearchModel();

            //Get data
            using (DB db = new DB())
            {
                Purchase_HService purchaseHSer = new Purchase_HService(db);
                totalRow = purchaseHSer.GetTotalRow(modelInput);
                listResult = purchaseHSer.GetListByCond(modelInput, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listResult.Count == 0)
            {
                this.rptPurchaseList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listResult[listResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "P.O No.", "Sales No.", "P.O Date", "Vendor", "Subject", "N#Grand Total", "" });

                // detail
                this.rptPurchaseList.DataSource = listResult;
            }

            this.rptPurchaseList.DataBind();
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //P.O Date
            if (this.dtPurchaseDateFrom.Value != null && this.dtPurchaseDateTo.Value != null)
            {
                if (this.dtPurchaseDateFrom.Value.Value.Date > this.dtPurchaseDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtPurchaseDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "P.O Date From", "P.O Date To");
                }
            }
            //Has errors
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptPurchaseList.DataSource = null;
                this.rptPurchaseList.DataBind();
                return true;
            }
            return false;
        }

        /// <summary>
        /// Get model input for search action
        /// </summary>
        /// <returns></returns>
        private PurchaseHeaderSearch GetSearchModel()
        {
            PurchaseHeaderSearch ret = new PurchaseHeaderSearch();

            ret.PurchaseNo = this.txtPurchaseNo.Value;
            ret.SalesNo = this.txtSalesNo.Value;
            ret.QuoteNo = this.txtQuoteNo.Value;
            ret.PurchaseDateFrom = this.dtPurchaseDateFrom.Value;
            ret.PurchaseDateTo = this.dtPurchaseDateTo.Value;
            ret.VendorCD = this.txtVendorCD.Value;
            ret.PreparedCD = this.txtPreparedCD.Value;
            ret.SubjectName = this.txtSubject.Value;
            ret.FinishedFlag = short.Parse(this.cmbFinishedData.SelectedValue);
            ret.FinishedName = this.cmbFinishedData.SelectedItem.Text;
            ret.DeletedFlag = short.Parse(this.cmbDeletedData.SelectedValue);
            ret.DeletedName = this.cmbDeletedData.SelectedItem.Text;

            return ret;
        }

        /// <summary>
        /// Reset Name For Search Condition
        /// </summary>
        private void ResetName()
        {
            //VendorName
            this.txtVendorName.Value = null;
            M_Vendor ven = this.GetVendorModel(this.txtVendorCD.Value);
            if (ven != null)
            {
                this.txtVendorName.Value = ven.VendorName1;
            }

            //PreparedName
            this.txtPreparedName.Value = null;
            M_User user = this.GetUserModel(this.txtPreparedCD.Value);
            if (user != null && user.ID != Constant.DEFAULT_ID && user.StatusFlag == 0)
            {
                this.txtPreparedName.Value = user.UserName2;
            }
        }

        /// <summary>
        /// Get Vendor by code
        /// </summary>
        /// <param name="vendorCD">vendorCD</param>
        /// <returns>Customer</returns>
        private M_Vendor GetVendorModel(string vendorCD)
        {
            using (DB db = new DB())
            {
                VendorService vendorSer = new VendorService(db);

                //Get Vendor
                return vendorSer.GetByCD(vendorCD);
            }
        }

        /// <summary>
        /// Get User by code
        /// </summary>
        /// <param name="userCD">UserCD</param>
        /// <returns>User</returns>
        private M_User GetUserModel(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);

                //Get User
                return userSer.GetByUserCD(userCD);
            }
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Format Vendor Code
        /// </summary>
        /// <param name="in1">VendorCD</param>
        /// <returns>Vendor CD</returns>
        [System.Web.Services.WebMethod]
        public static string GetVendor(string in1)
        {
            try
            {
                var dbVendorCD = in1;
                dbVendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                using (DB db = new DB())
                {
                    VendorService service = new VendorService(db);

                    var vendor = service.GetByCD(dbVendorCD);
                    if (vendor != null && vendor.StatusFlag == 0)
                    {
                        var result = new
                        {
                            vendorCD = in1,
                            vendorName1 = vendor.VendorName1
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        vendorCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                var dbUserCD = in1;
                dbUserCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbUserCD, M_User.USER_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbUserCD, M_User.MAX_USER_CODE_SHOW);
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(dbUserCD);
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userCD = in1,
                            userName2 = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        userCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        #endregion

        #region Event Excel

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            this.PurchaseExcelFlag = "Excel";
            PurchaseListExcel excel = new PurchaseListExcel();
            excel.modelInput = this.GetSearchModel();
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnExcel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPOList_Click(object sender, CommandEventArgs e)
        {
            this.PurchaseExcelFlag = "CreatePOList";
            CreatePOListExcel excel = new CreatePOListExcel();
            excel.purchaseDateFrom = this.dtPurchaseDateFrom.Value;
            excel.purchaseDateTo = this.dtPurchaseDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// btnUncreatePOList Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUncreatePOList_Click(object sender, CommandEventArgs e)
        {
            this.PurchaseExcelFlag = "UncreatePOList";
            UncreatePOListExcel excel = new UncreatePOListExcel();
            excel.purchaseDateFrom = this.dtPurchaseDateFrom.Value;
            excel.purchaseDateTo = this.dtPurchaseDateTo.Value;
            IWorkbook wb = excel.OutputExcel();

            if (wb != null)
            {
                this.SaveFile(wb);
            }

            this.btnSearch_Click(null, null);
        }

        #endregion
    }
}
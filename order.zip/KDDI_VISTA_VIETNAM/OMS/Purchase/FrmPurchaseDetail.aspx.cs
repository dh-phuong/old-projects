﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using Microsoft.Reporting.WebForms;

using OMS.Controls;
using OMS.DAC;
using OMS.Models;
using OMS.Reports.PDF;
using OMS.Utilities;

namespace OMS.Purchase
{
    /// <summary>
    /// Class FrmPurchaseDetail
    /// Author: ISV-Giam
    /// </summary>
    public partial class FrmPurchaseDetail : FrmBaseDetail
    {
        #region Constant
        private const string PDF_PURCHASE_DOWNLOAD = "Purchase_{0}.pdf";
        private const string FMT_YMDHMM = "yyMMddHHmm";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);

        private const string ZERO_STRING = "0";
        private const decimal INT_4D = 9999m;
        private const int INT_0 = 0;
        #endregion

        #region Property

        /// <summary>
        /// Get or set PurchaseID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public string DefaultVAT
        {
            get { return (string)ViewState["DefaultVAT"]; }
            private set { ViewState["DefaultVAT"] = value; }
        }

        /// <summary>
        /// Decimal digit of quantity
        /// </summary>
        public int QuantityDecimal
        {
            get { return (int)ViewState["QuantityDecimal"]; }
            private set { ViewState["QuantityDecimal"] = value; }
        }

        /// <summary>
        /// Use for AJAX
        /// </summary>
        public string MethodVATEach
        {
            get { return M_Config_D.METHOD_VAT_EACH; }
        }

        /// <summary>
        /// ProductCode Support
        /// </summary>
        public string productCdSupport
        {
            get { return M_Product.PRODUCT_CODE_SUPPORT; }
        }

        /// <summary>
        /// Default VAT value
        /// </summary>
        public string DefaultVatType
        {
            get { return this._defaultVatType; }
        }

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Issued
        /// </summary>
        public bool Issued
        {
            get { return (bool)ViewState["Issued"]; }
            private set { ViewState["Issued"] = value; }
        }

        /// <summary>
        /// Deleted
        /// </summary>
        public bool Deleted
        {
            get { return (bool)ViewState["Deleted"]; }
            private set { ViewState["Deleted"] = value; }
        }

        /// <summary>
        /// File count
        /// </summary>
        public int FileCount
        {
            get { return (int)ViewState["FileCount"]; }
            set { ViewState["FileCount"] = value; }
        }

        /// <summary>
        /// OldCondition
        /// </summary>
        private string OldCondition
        {
            get { return (string)ViewState["OldCondition"]; }
            set { ViewState["OldCondition"] = value; }
        }

        /// <summary>
        /// Get or set VersionUpdateDate
        /// </summary>
        public DateTime OldVersionUpdateDate
        {
            get { return (DateTime)ViewState["OldVersionUpdateDate"]; }
            set { ViewState["OldVersionUpdateDate"] = value; }
        }

        /// <summary>
        /// _actionMode
        /// </summary>
        private ActionMode _actionMode
        {
            get { return (ActionMode)ViewState["ActionMode"]; }
            set { ViewState["ActionMode"] = value; }
        }

        /// <summary>
        /// Detail Payment source
        /// </summary>
        public IList<T_Payment> PaymentDataSource
        {
            get { return (IList<T_Payment>)ViewState["PaymentDataSource"]; }
            set { ViewState["PaymentDataSource"] = value; }
        }

        /// <summary>
        /// ProductCdUsed Flag
        /// </summary>
        public bool ProductCdUsed { get; private set; }

        /// <summary>
        /// Payment Row Count
        /// </summary>
        public int PaymentRowCount
        {
            get { return (int)ViewState["PaymentRowCount"]; }
            set { ViewState["PaymentRowCount"] = value; }
        }

        /// <summary>
        /// Get Or Set Default Serial View
        /// </summary>
        public string DefaultSerialView
        {
            get
            {
                return base.GetValueViewState<string>("DefaultSerialView");
            }
            private set { ViewState["DefaultSerialView"] = value; }
        }

        /// <summary>
        /// Get Or Set Default Serial Hidden
        /// </summary>
        public int DefaultSerialHidden
        {
            get
            {
                return base.GetValueViewState<int>("DefaultSerialHidden");
            }
            private set { ViewState["DefaultSerialHidden"] = value; }
        }

        /// <summary>
        /// Child Row Command Argument
        /// </summary>
        private string ChildRowCommandArgument
        {
            get
            {
                return base.GetValueViewState<string>("ChildRowCommandArgument");
            }
            set { ViewState["ChildRowCommandArgument"] = value; }
        }

        #endregion

        #region Variable
        /// <summary>
        /// ActionMode
        /// </summary>
        private enum ActionMode
        {
            /// <summary>
            /// None
            /// </summary>
            None = 0,

            /// <summary>
            /// Copy
            /// </summary>
            Copy,

            /// <summary>
            /// Issue
            /// </summary>
            Issue,

            /// <summary>
            /// DeleteRowPurchase
            /// </summary>
            DeleteRowPurchase,

            /// <summary>
            /// DeleteRowPurchase
            /// </summary>
            DeleteRowPayment,

            /// <summary>
            /// CurrencyChanged
            /// </summary>
            CurrencyChanged,

            /// <summary>
            /// MethodChanged
            /// </summary>
            MethodChanged,

            /// <summary>
            /// Remove Child Row
            /// </summary>
            RemoveChildRow
        }

        /// <summary>
        /// Serial Hidden
        /// </summary>
        protected enum SerialHidden
        {
            /// <summary>
            /// Show
            /// </summary>
            Show = 0,

            /// <summary>
            /// Hidden
            /// </summary>
            Hidden
        }

        /// <summary>
        /// UnitList
        /// </summary>
        private IList<DropDownModel> _unitList;

        /// <summary>
        /// CurrencyList
        /// </summary>
        private IList<DropDownModel> _currencyList;

        /// <summary>
        /// MethodVatList
        /// </summary>
        private IList<DropDownModel> _methodVatList;

        /// <summary>
        /// Payment Method
        /// </summary>
        private IList<DropDownModel> _paymentMethodPayment;

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string _defaultPaymentMethod;

        /// <summary>
        /// VatTypeList
        /// </summary>
        private IList<DropDownModel> _vatTypeList;

        /// <summary>
        /// VatTypeListEmpty
        /// </summary>
        private IList<DropDownModel> _vatTypeListEmpty = new List<DropDownModel>();

        /// <summary>
        /// The Contract type list
        /// </summary>
        private IList<DropDownModel> _contractTypeList;

        /// <summary>
        /// Index Detail
        /// </summary>
        private int _indexDetail;

        /// <summary>
        /// Index Payment
        /// </summary>
        private int _indexPayment;

        /// <summary>
        /// DefaultMethodVat
        /// </summary>
        private string _defaultMethodVat;

        /// <summary>
        /// The default contract type
        /// </summary>
        private string _defaultContractType;

        /// <summary>
        /// DefaultStatus
        /// </summary>
        private string _defaultVatType;

        /// <summary>
        /// FractionType
        /// </summary>
        private FractionType _defaultFractionType;

        /// <summary>
        /// Is Detail Empty
        /// </summary>
        private bool isDetailEmpty;

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Purchase";

            //ProductType
            this.hdnProductType.Value = null;

            //Init Max Length
            this.txtVendorCD.MaxLength = M_Vendor.VENDOR_CODE_MAX_SHOW;
            this.txtVendorName.MaxLength = M_Vendor.VENDOR_NAME_1_MAX_LENGTH;
            this.txtAttn.MaxLength = M_Vendor.VENDOR_CONTACT_PERSON_MAX_LENGTH;
            this.txtAdd1.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtAdd2.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtAdd3.MaxLength = M_Vendor.VENDOR_ADDRESS_MAX_LENGTH;
            this.txtTel.MaxLength = M_Vendor.VENDOR_TEL_MAX_LENGTH;
            this.txtFax.MaxLength = M_Vendor.VENDOR_FAX_MAX_LENGTH;
            this.txtSubject.MaxLength = T_Purchase_H.PROJECT_NAME_MAX_LENGTH;
            this.txtMemo.MaxLength = T_Purchase_H.MEMO_MAX_LENGTH;
            this.txtPreparedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtApprovedCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtConditionCD.MaxLength = M_Condition.CONDITION_CODE_MAX_LENGTH;
            this.txtConditions.MaxLength = M_Condition.CONDITION_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnYesProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);

            //Back view
            this.btnBackView.Click += new EventHandler(btnBackView_Click);

            //Download Pdf Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadPDF_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Purchase);
            if (!base._authority.IsPurchaseView)
            {
                base.RedirectUrl(FrmBase.URL_MAIN_MENU);
            }

            //Get Default Data
            this.GetDefaultData();

            //Save BACK URL
            if (this.ViewState["BACK_URL"] == null)
            {
                this.ViewState["BACK_URL"] = FrmBase.URL_PURCHASE_LIST;
            }

            if (!this.IsPostBack)
            {
                this._actionMode = ActionMode.None;

                //Init DropDownList
                this.InitDropDownListData(this.cmbCurrency, this._currencyList);
                this.InitDropDownListData(this.cmbMethodVat, this._methodVatList);
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeList);

                //Init hdnFractionType
                this.hdnFractionType.Value = ((int)this._defaultFractionType).ToString();

                if (this.PreviousPage != null)
                {
                    //Save Info
                    base.SaveBackPage();

                    //Get Para
                    Hashtable para = base.GetParamater();
                    if (para != null)
                    {
                        //Save URL
                        this.ViewState["BACK_URL"] = para["BACK_URL"];

                        //Check para
                        if (para.ContainsKey("ID") && para["ID"] != null)
                        {
                            //Get Purchase ID
                            this.DataID = int.Parse(para["ID"].ToString());
                            var header = this.GetPurchaseByID(this.DataID);
                            if (header != null)
                            {

                                //Show data
                                this.ShowPurchaseInfo(this.DataID);

                                //Show payment
                                this.ShowDetailPaymentData(this.DataID);

                                //------ Edited  by ISV-Giam 2014/12/23 ------
                                //Set Mode
                                this.ProcessMode(Mode.View);
                                //--------------------------------------------

                            }
                            else
                            {
                                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
                            }
                        }
                        else
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set Back URL
            this.btnBackView.PostBackUrl = this.ViewState["BACK_URL"].ToString();
        }
        
        /// <summary>
        /// Process button
        /// </summary>
        /// <param name="source">object</param>
        /// <param name="e">RepeaterCommandEventArgs</param>
        protected void rptDetail_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            #region cmdSellSearchProcess
            if (e.CommandName == "cmdSellSearchProcess")
            {
                this.SetConfirmData();


                //Get index row sell curren
                int sellNo = Convert.ToInt32(e.CommandArgument);

                //Find control
                HiddenField hdnSearchHID = (HiddenField)e.Item.FindControl("hdnSearchHID");
                //Find control
                HiddenField hdnSearchInternalID = (HiddenField)e.Item.FindControl("hdnSearchInternalID");
                ITextBox txtDescription = (ITextBox)e.Item.FindControl("txtDescription");

                
                //Get new detail Purchase
                var listDetail = this.GetDetailPurchaseData();

                //Old sell row
                var sellRow = listDetail.Where(s=>s.No.Equals(sellNo)).SingleOrDefault();
                
                #region Copy
                using (DB db = new DB())
                {
                    var hid = int.Parse(hdnSearchHID.Value);
                    var internalID = int.Parse(hdnSearchInternalID.Value);

                    Purchase_HService purchase_HService = new Purchase_HService(db);
                    Purchase_DService purchase_DService = new Purchase_DService(db);

                    //header
                    var header = purchase_HService.GetByPK(hid);

                    //New sell row
                    var newSell = purchase_DService.GetByInternalID(int.Parse(hdnSearchInternalID.Value));

                    sellRow.ProductCD = newSell.ProductCD;
                    sellRow.ProductName = newSell.ProductName;
                    sellRow.Description = newSell.Description;
                    sellRow.UnitPrice = this.CalcUnitPrice(newSell.UnitPrice, header.CurrencyID);
                    sellRow.Quantity = null;
                    sellRow.UnitID = newSell.UnitID;
                    sellRow.Total = null;
                    sellRow.Vat = null;
                    sellRow.VatType = newSell.VatType;
                    sellRow.VatRatio = newSell.VatRatio;
                    sellRow.Remark = newSell.Remark;

                    #region Unknown

                    foreach (var item in listDetail)
                    {
                        /*???
                        if (item.DeliveryDate == DEFAULT_DATE_TIME)
                        {
                            item.DeliveryDate = null;
                        }
                        if (item.DeliveryQuantity == 0)
                        {
                            item.DeliveryQuantity = null;
                        }

                        if (item.SalesSellID != 0)
                        {
                            item.RemainQty = dService.GetRemainQtyBySalesSellID(item.SalesSellID, this.DataID);
                        }
                        else
                        {
                            item.RemainQty = null;
                        }
                        */
                        //********************
                        if (item.SerialList == null || item.SerialList.Count == 0)
                        {
                            PurchaseSerialInfo serial = new PurchaseSerialInfo();
                            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                            serial.No = 1;
                            serial.DetailNo = item.No;
                            serial.ContractType = short.Parse(this._defaultContractType);
                            serial.FinishDate = null;
                            serial.StartDate = null;
                            item.SerialList.Add(serial);
                        }
                        else
                        {
                            int indexSeri = 1;
                            foreach (var seriItem in item.SerialList)
                            {
                                seriItem.No = indexSeri++;
                                if (seriItem.StartDate == DEFAULT_DATE_TIME)
                                {
                                    seriItem.StartDate = null;
                                }
                                if (seriItem.FinishDate == DEFAULT_DATE_TIME)
                                {
                                    seriItem.FinishDate = null;
                                }
                                if (seriItem.Terms == 0)
                                {
                                    seriItem.Terms = null;
                                }
                            }
                        }
                    }

                    #endregion Unknown

                }
                #endregion

                this.rptDetail.DataSource = listDetail;
                this.rptDetail.DataBind();
                this.FocusControlId = txtDescription.ClientID;
            }
            #endregion
        }

        /// <summary>
        /// Calc unit price
        /// </summary>
        /// <param name="newUnitPrice"></param>
        /// <param name="newCurrency"></param>
        /// <returns></returns>
        private decimal? CalcUnitPrice(decimal? newUnitPrice, int newCurrency)
        {
            decimal? ret = null;
            if (int.Parse(this.cmbCurrency.SelectedValue) == newCurrency)
            {
                ret = newUnitPrice;
            }
            else
            {
                using (DB db = new DB())
                {
                    var baseDate = this.txtPurchaseDate.IsEmpty ? db.NowDate : this.txtPurchaseDate.Value.Value;
                    var crcyService = new Currency_HService(db);
                    var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                    if (newCurrency == Constant.DEFAULT_ID)
                    {
                        ret = newUnitPrice;
                    }
                    else
                    {
                        ret = CommonUtil.ConvertToVND(crcyList[newCurrency].ExchangeRate, newUnitPrice.Value);
                    }

                    if (int.Parse(this.cmbCurrency.SelectedValue) != Constant.DEFAULT_ID)
                    {
                        ret = CommonUtil.ConvertToNotVND(crcyList[int.Parse(this.cmbCurrency.SelectedValue)].ExchangeRate, ret.Value);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //--------------------- Edited by ISV-Giam 2014/12/15 -----------------------
                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                if (this._actionMode == ActionMode.CurrencyChanged)
                {
                    crcyId = ((T_Purchase_H)this.ViewState["HEADER"]).CurrencyID;
                }
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                //---------------------------------------------------------------------------

                //Init Unit
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbUnit");
                this.InitDropDownListData(cmbUnit, this._unitList);

                //Init Vat Type
                DropDownList cmbVatType = (DropDownList)e.Item.FindControl("cmbVatType");
                this.InitDropDownListData(cmbVatType, this._vatTypeList);

                Repeater rptSerial = (Repeater)e.Item.FindControl("rptSerial");

                //Get methodVAT
                var methodVAT = this.cmbMethodVat.SelectedValue;
                //------------- Edited by ISV-Giam 2014/12/16 --------
                if (this._actionMode == ActionMode.MethodChanged)
                {
                    methodVAT = ((T_Purchase_H)this.ViewState["HEADER"]).MethodVat.ToString();
                }
                //----------------------------------------------------

                //Set selected item for dropdownlist
                PurchaseDetailInfo item = (PurchaseDetailInfo)e.Item.DataItem;
                cmbUnit.SelectedValue = item.UnitID.ToString();

                var txtPrice = (INumberTextBox)e.Item.FindControl("txtPrice");
                var txtQuantity = (INumberTextBox)e.Item.FindControl("txtQuantity");
                var txtTotal = (INumberTextBox)e.Item.FindControl("txtTotal");
                var txtVat = (INumberTextBox)e.Item.FindControl("txtVat");
                var txtVatRatio = (INumberTextBox)e.Item.FindControl("txtVatRatio");
                var txtDeliQuantity = (INumberTextBox)e.Item.FindControl("txtDeliQuantity");

                //---------------Set decimal digit by exchage rate---------------//
                txtQuantity.DecimalDigit = this.QuantityDecimal;
                txtQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtQuantity.MinimumValue = 0;

                txtDeliQuantity.DecimalDigit = this.QuantityDecimal;
                txtDeliQuantity.MaximumValue = (this.QuantityDecimal == 2) ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;
                txtDeliQuantity.MinimumValue = 0;

                this.SetDecimalDigit(crcySelected, txtPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, txtVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);
                //---------------End Set decimal digit by exchage rate---------------//

                if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                {
                    rptSerial.DataSource = item.SerialList;
                    rptSerial.DataBind();
                }

                //Set max length
                var txtProductCD = (ICodeTextBox)e.Item.FindControl("txtProductCD");
                txtProductCD.MaxLength = M_Product.PRODUCT_CODE_MAX_LENGTH;

                //Search product
                ITextBox txtProductName = (ITextBox)e.Item.FindControl("txtProductName");
                txtProductName.MaxLength = M_Product.PRODUCT_NAME_MAX_LENGTH;

                ITextBox txtRemark = (ITextBox)e.Item.FindControl("txtRemark");
                txtRemark.MaxLength = T_Purchase_D.REMARK_MAX_LENGTH;

                ITextBox txtDescription = (ITextBox)e.Item.FindControl("txtDescription");
                txtDescription.MaxLength = T_Purchase_D.DESCRIPTION_MAX_LENGTH;

                HtmlButton btnSearchProduct = (HtmlButton)e.Item.FindControl("btnProduct");
                string onclickSearchProduct = "callSearchProduct('" + txtProductCD.ClientID + "','" + txtProductName.ClientID + "','" + this.txtVendorCD.ClientID + "','" + txtDescription.ClientID + "'," + (int)Utilities.ProductType.Cost + ")";

                btnSearchProduct.Attributes.Add("onclick", onclickSearchProduct);

                //---------Search sales product------------------//
                HiddenField hdnSearchHID = (HiddenField)e.Item.FindControl("hdnSearchHID");
                HiddenField hdnSearchInternalID = (HiddenField)e.Item.FindControl("hdnSearchInternalID");
                LinkButton cmdSearchSell = (LinkButton)e.Item.FindControl("cmdSearchSell");


                HtmlButton btnSearchPurchaseProduct = (HtmlButton)e.Item.FindControl("btnSearchPurchaseProduct");
                string onclick = "callSearchPurchaseProduct('" + txtProductCD.ClientID + "','" + txtProductName.ClientID + "','" + txtDescription.ClientID;
                onclick += "','" + hdnSearchHID.ClientID + "','" + hdnSearchInternalID.ClientID + "','" + cmdSearchSell.ClientID + "');";
                btnSearchPurchaseProduct.Attributes.Add("onclick", onclick);
                //---------Search sales product------------------//

                //Set Onchange
                var param = string.Format("'{0}', '{1}', '{2}', '{3}', '{4}' ,'{5}'",
                                                                                        cmbVatType.ClientID,
                                                                                        txtPrice.ClientID,
                                                                                        txtQuantity.ClientID,
                                                                                        txtTotal.ClientID,
                                                                                        txtVat.ClientID,
                                                                                        txtVatRatio.ClientID);

                txtPrice.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtPrice.ClientID, param));
                txtQuantity.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtQuantity.ClientID, param));
                txtTotal.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtTotal.ClientID, param));
                txtVatRatio.Attributes.Add("onvaluechange", string.Format("sellOnChanged('{0}', {1})", txtVatRatio.ClientID, param));
                txtVat.Attributes.Add("onvaluechange", "calcTotalDetail();");

                //Reset value
                if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                {
                    txtVat.SetReadOnly(true);
                    txtVatRatio.SetReadOnly(true);
                    cmbVatType.Enabled = false;
                    txtVat.Value = null;
                    txtVatRatio.Value = null;
                    this.InitDropDownListData(cmbVatType, this._vatTypeListEmpty);
                }
                else
                {
                    txtVat.SetReadOnly(false);
                    txtVatRatio.SetReadOnly(false);
                    cmbVatType.Enabled = true;

                    cmbVatType.SelectedValue = item.VatType.ToString();

                    if (Convert.ToInt32(cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
                    {
                        txtVat.SetReadOnly(false);
                        txtVat.Value = item.Vat;

                        txtVatRatio.SetReadOnly(false);
                        txtVatRatio.Value = item.VatRatio;
                    }
                    else
                    {
                        txtVat.SetReadOnly(true);
                        txtVat.Value = null;

                        txtVatRatio.SetReadOnly(true);
                        txtVatRatio.Value = null;
                    }
                }

                //Get Exchange Rate
                var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblVatExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblTotalExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblPriceExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;

                this.lblSumTotalExchangeRate.InnerText = crcySelected.MoneyCode;
                this.lblSumVatExchangeRate.InnerText = crcySelected.MoneyCode;
                this.lblGrandTotalExchangeRate.InnerText = crcySelected.MoneyCode;

                this.lblPaymentTotalExchangeRate.InnerHtml = crcySelected.MoneyCode;
                this.lblBalanceExchangeRate.InnerHtml = crcySelected.MoneyCode;

                this.lblVATRatio.InnerText = string.Format("{0}/Ratio", crcySelected.TaxName);
            }
        }

        /// <summary>
        /// Repeater Serial Item Data Bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptSerial_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                PurchaseSerialInfo info = (PurchaseSerialInfo)e.Item.DataItem;

                //Init Unit Serial
                DropDownList cmbUnit = (DropDownList)e.Item.FindControl("cmbUnitSerial");
                HiddenField hdUnit = (HiddenField)e.Item.FindControl("hdUnitSerial");

                //Init Unit Serial
                DropDownList cmbContractType = (DropDownList)e.Item.FindControl("cmbContractType");
                HiddenField hdContractType = (HiddenField)e.Item.FindControl("hdContractType");

                hdUnit.Value = info.TermUnit == null ? ((int)WarrantyUnit.None).ToString() : info.TermUnit.ToString();
                hdContractType.Value = info.ContractType.ToString();

                this.InitDropDownListData(cmbUnit, InitDataForWarrantyType(cmbUnit));
                this.InitDropDownListData(cmbContractType, this._contractTypeList);

                cmbUnit.SelectedValue = info.TermUnit.ToString();
                cmbContractType.SelectedValue = info.ContractType.ToString();

                ITextBox txtSerial = (ITextBox)e.Item.FindControl("txtSerial");
                txtSerial.MaxLength = T_Purchase_Serial.SERIAL_NO_MAX_LENGTH;

                INumberTextBox txtTerms = (INumberTextBox)e.Item.FindControl("txtTerms");
                txtTerms.MaxLength = 5;
                txtTerms.DecimalDigit = INT_0;
                txtTerms.MaximumValue = INT_4D;

                IDateTextBox txtFinishDate = (IDateTextBox)e.Item.FindControl("txtSerialFinishDate");
                IDateTextBox txtStartDate = (IDateTextBox)e.Item.FindControl("txtSerialStartDate");

                var param = string.Format("'{0}', '{1}', '{2}','{3}','{4}','{5}'", this.txtPurchaseDate.ClientID, cmbContractType.ClientID, txtTerms.ClientID, cmbUnit.ClientID, txtStartDate.ClientID, txtFinishDate.ClientID);
                txtTerms.Attributes.Add("onvaluechange", string.Format("serialOnChanged('{0}', {1})", txtTerms.ClientID, param));
                cmbUnit.Attributes.Add("onchange", string.Format("serialOnChanged('{0}', {1})", cmbUnit.ClientID, param));

                var balanceParam = string.Format("'{0}', '{1}', '{2}'", cmbContractType.ClientID, txtTerms.ClientID, cmbUnit.ClientID);
                txtFinishDate.Attributes.Add("onvaluechange", string.Format("startDatevsFinishDateOnChanged('{0}','{1}', {2});", txtFinishDate.ClientID, txtStartDate.ClientID, balanceParam));
                txtStartDate.Attributes.Add("onvaluechange", string.Format("startDatevsFinishDateOnChanged('{0}','{1}', {2});", txtStartDate.ClientID, txtFinishDate.ClientID, balanceParam));

                if (cmbContractType.SelectedValue.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                {
                    //txtTerms.SetReadOnly(false);
                    //cmbUnit.Attributes.Remove("disabled");
                    txtStartDate.SetReadOnly(true);
                }
                else
                {
                    //txtTerms.SetReadOnly(true);
                    //cmbUnit.Attributes.Add("disabled", "true");
                    txtStartDate.SetReadOnly(false);
                }
            }
        }

        /// <summary>
        /// Repeater Serial Item Command
        /// </summary>
        /// <param name="source"></param>
        /// <param name="e"></param>
        protected void rptSerial_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "cmdAddRow")
            {
                //int detailNo = Convert.ToInt32(e.CommandArgument);
                string[] value = e.CommandArgument.ToString().Split('_');
                int detailNo = Convert.ToInt32(value[0]);
                int no = Convert.ToInt32(value[1]);

                //Get Data
                IList<PurchaseDetailInfo> sellList = this.GetDetailPurchaseData();
                var sell = sellList.Where(s => s.No == detailNo).SingleOrDefault();
                sell.SerialList.AsParallel().ForAll(s => s.Collapsed = "in");

                var seriInfo = new PurchaseSerialInfo
                {
                    PurchaseID = sell.InternalID,
                    No = sell.SerialList.Count + 1,
                    StartDate = null,
                    FinishDate = null,
                    ContractType = short.Parse(this._defaultContractType),
                    DetailNo = detailNo,
                    Collapsed = "in"
                };
                if (sell.SerialList.Count != 0)
                {
                    sell.SerialList.Insert(no, seriInfo);
                    var seriNo = 1;
                    foreach (var seri in sell.SerialList)
                    {
                        seri.No = seriNo++;
                    }
                }
                else
                {
                    sell.SerialList.Add(seriInfo);
                }
                this.RefreshPurchaseDetails(sellList);

                this.FocusControlId = string.Format((seriInfo.DetailNo - 1) + "_txtSerial_{0}", seriInfo.No == 1 ? 1 : (seriInfo.No - 1));
            }

            if (e.CommandName == "cmdDelRow")
            {
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
                this._actionMode = ActionMode.RemoveChildRow;
            }
        }

        /// <summary>
        /// Change value with exchange rate
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_CURRENCY_CHANGED, Models.DefaultButton.Yes, true);
            this._actionMode = ActionMode.CurrencyChanged;
            //----------------- Edit by ISV-Giam 2014/12/15 -------------------
            this.SetConfirmData();
            this.RefreshPurchaseDetails();
            //-----------------------------------------------------------------
        }

        /// <summary>
        /// Change value with method vat
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void cmbMethodVat_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShowQuestionMessage(M_Message.MSG_CODE_METHOD_CHANGED, Models.DefaultButton.Yes, true);
            this._actionMode = ActionMode.MethodChanged;
            this.SetConfirmData();
            //----------------- Edit by ISV-Giam 2014/12/15 -------------------
            this.RefreshPurchaseDetails();
            //-----------------------------------------------------------------
        }

        /// <summary>
        /// Add row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            IList<PurchaseDetailInfo> list = this.GetDetailPurchaseData();

            PurchaseDetailInfo detail = new PurchaseDetailInfo();
            detail.No = list.Count + 1;
            //--------------- ISV-GIAM 2014/01/12 --------------
            detail.InternalID = -1;
            //--------------------------------------------------
            short defaultVatType = -1;
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_EACH)
            {
                defaultVatType = short.Parse(this._defaultVatType);
            }
            if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
            {
                detail.VatRatio = decimal.Parse(this.DefaultVAT);
            }
            detail.VatType = defaultVatType;

            detail.SerialList = new List<PurchaseSerialInfo>();
            PurchaseSerialInfo serial = new PurchaseSerialInfo();
            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

            serial.ContractType = short.Parse(this._defaultContractType);
            serial.StartDate = null;
            serial.FinishDate = null;

            serial.No = 1;
            serial.DetailNo = detail.No;
            detail.SerialList.Add(serial);

            list.Add(detail);
            this.chkDelAll.Checked = false;

            this.rptDetail.DataSource = list;
            this.rptDetail.DataBind();

            //-------------------------- Edited 2014/12/10 ------------------------
            //this.FocusControlId = string.Format("txtProductCD_{0}", detail.No - 1);
            if (this.ProductCdUsed)
            {
                this.FocusControlId = string.Format("txtProductCD_{0}", detail.No - 1);
            }
            else
            {
                this.FocusControlId = string.Format("txtProductName_{0}", detail.No - 1);
            }
            //---------------------------------------------------------------------
        }

        /// <summary>
        /// Delete Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRow_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Show question delete row
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            this._actionMode = ActionMode.DeleteRowPurchase;
        }

        /// <summary>
        /// Up row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUp_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Get Data
            this.SwapDetail(true);
        }

        /// <summary>
        /// Down row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDown_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Get Data
            this.SwapDetail(false);
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            var header = this.GetPurchaseByID(this.DataID);

            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    this.FocusControlId = this.btnEdit.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show Purchase data
                this.ShowPurchaseInfo(this.DataID);

                //Show Payment data
                this.ShowDetailPaymentData(this.DataID);

                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// Event Update
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            var header = this.GetPurchaseByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    //this.FocusControlId = this.btnIssue.ClientID;
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;

                    //Show data
                    this.ShowPurchaseInfo(this.DataID);
                    this.ShowDetailPaymentData(this.DataID);
                }

                T_Sales_H salesH = null;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    salesH = sales_HService.GetBySalesNo(header.SalesNo);
                }

                if (salesH != null)
                {
                    if (salesH.VersionUpdateDate <= this.OldVersionUpdateDate)
                    {
                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);
                    }
                }
                else
                {
                    //Show data
                    this.ShowPurchaseInfo(this.DataID);
                    this.ShowDetailPaymentData(this.DataID);
                }

                if (isOk)
                {
                    this.SetConfirmData();

                    //Set Mode
                    this.ProcessMode(Mode.Delete);

                    //Show question insert
                    this.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// Event Copy
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            var header = this.GetPurchaseByID(this.DataID);
            //Check data
            if (header != null)
            {
                //Show data
                this.ShowPurchaseInfo(this.DataID);
                this.ShowDetailPaymentData(this.DataID);

                //Show question copy data
                base.ShowQuestionMessage(M_Message.MSG_MAKE_COPY, Models.DefaultButton.Yes, true, "");
                this._actionMode = ActionMode.Copy;
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// Event Check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCheck_Click(object sender, EventArgs e)
        {
            this._actionMode = ActionMode.None;
            var header = this.GetPurchaseByID(this.DataID);

            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    //----------------- Edited 2014/12/09 ---------------
                    //this.FocusControlId = this.btnCheck.ClientID;
                    //---------------------------------------------------
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show prchase data
                this.ShowPurchaseInfo(header.ID);

                //Show payment data
                this.ShowDetailPaymentData(header.ID);

                //Init 1st row defaul Payment
                using (DB db = new DB())
                {
                    PaymentService payService = new PaymentService(db);

                    var listPaymentInfo = payService.GetListByID(header.ID);
                    if (listPaymentInfo == null || listPaymentInfo.Count == 0)
                    {
                        listPaymentInfo = new List<T_Payment>();
                        listPaymentInfo.Add(new T_Payment()
                        {
                            PaymentMethod = 255,
                            Amount = null
                        });

                        //Reset datasource
                        this.rptPayment.DataSource = listPaymentInfo;
                        this.rptPayment.DataBind();
                    }
                }

                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Check);
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// Event Check Confirm
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCheckConfirm_Click(object sender, EventArgs e)
        {
            this.SetConfirmData();
            //----------------- Edited 2014/12/09 ----------------
            //this.FocusControlId = this.btnCheckConfirm.ClientID;
            this.FocusControlId = this.txtVendorCD.ClientID;
            //----------------------------------------------------

            //Check mode Check
            if (!this.CheckModeCheck())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Mode normal
            if (this.Mode != Mode.View)
            {
                var header = this.GetPurchaseByID(this.DataID);
                //Check data
                if (header != null)
                {
                    //Show data
                    this.ShowPurchaseInfo(this.DataID);
                    this.ShowDetailPaymentData(this.DataID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
                }
            }
        }

        /// <summary>
        /// Event Isssue
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnIssue_Click(object sender, EventArgs e)
        {
            var header = this.GetPurchaseByID(this.DataID);
            //Check data
            if (header != null)
            {
                var isOk = true;
                if (header.UpdateDate != this.OldUpdateDate)
                {
                    
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                }

                //Show data
                this.ShowPurchaseInfo(this.DataID);
                this.ShowDetailPaymentData(this.DataID);

                if (isOk)
                {
                    this._actionMode = ActionMode.Issue;
                    if (header.IssuedFlag == 1)
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_DATA_ISSUED, Models.DefaultButton.Yes,true);
                    }
                    else
                    {
                        this.ShowQuestionMessage(M_Message.MSG_QUESTION_OUTPUT_FILE, Models.DefaultButton.Yes, true, "PDF");
                    }
                }
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// btnDownload Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadPDF_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    var fileName = string.Format("{0}.pdf", this.txtPurchaseNo.Value);
                    Response.ContentType = "application/pdf";
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename={0}", fileName));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                    Response.Flush(); // send it to the client to download
                }
            }
        }

        /// <summary>
        /// Event Reference
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnReferenceYes_Click(object sender, CommandEventArgs e)
        {
            T_Purchase_H purchase = this.GetPurchaseByID(this.DataID);
            if (purchase != null)
            {
                //if (purchase.UpdateDate != this.OldUpdateDate)
                //{
                //    base.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);

                //    //Reload data
                //    this.ShowPurchaseInfo(this.DataID);
                //    return;
                //}

                //Process reference parameter
                Hashtable currentPage = new Hashtable();
                currentPage.Add("ID", purchase.ID);

                Hashtable nextPage = new Hashtable();
                nextPage.Add("FinishedFlag", M_Config_D.DATA_INCLUDE);
                nextPage.Add("DeletedFlag", M_Config_D.DATA_INCLUDE);

                var formId = e.CommandArgument;
                if (string.Equals(formId, "Quotation"))
                {
                    if (!this.txtQuotationNo.IsEmpty)
                    {
                        nextPage.Add("txtQuoteNo", this.txtQuotationNo.Value);
                        nextPage.Add("QuoteNoReadOnly", true);
                        nextPage.Add("SalesData", M_Config_D.DATA_INCLUDE);
                    }
                }
                if (string.Equals(formId, "Sales"))
                {
                    nextPage.Add("SalesNoReadOnly", true);
                    nextPage.Add("QuoteNoReadOnly", true);

                    if (!this.txtSalesNo.IsEmpty)
                    {
                        nextPage.Add("txtSalesNo", this.txtSalesNo.Value);
                    }

                    if (!this.txtQuotationNo.IsEmpty)
                    {
                        nextPage.Add("txtQuoteNo", this.txtQuotationNo.Value);
                    }
                }
                base.NextPage(currentPage, nextPage, this.ViewState["BACK_URL"].ToString(), FrmBase.URL_PURCHASE_DETAIL);
            }
            else
            {
                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
            }
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBackView_Click(object sender, EventArgs e)
        {
            base.BackPage();
        }

        #endregion

        #region Payment Event

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptPayment_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                //----------------- Edited by ISV-Giam 2014/12/15 -----------------
                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                if (this._actionMode == ActionMode.CurrencyChanged)
                {
                    crcyId = ((T_Purchase_H)this.ViewState["HEADER"]).CurrencyID;
                }
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                //-----------------------------------------------------------------

                //Get data
                T_Payment data = (T_Payment)e.Item.DataItem;

                //Find Control
                IDateTextBox dtPaymentDate = (IDateTextBox)e.Item.FindControl("dtPaymentDate");
                INumberTextBox txtAmount = (INumberTextBox)e.Item.FindControl("txtAmount");
                DropDownList cmbPaymentMethod = (DropDownList)e.Item.FindControl("cmbPaymentMethod");
                this.SetDecimalDigit(crcySelected, txtAmount, Constant.MAX_SUB_AMOUNT_DECIMAL, Constant.MAX_SUB_AMOUNT_NOT_DECIMAL);

                //---------End Change sell unit price max,min, digit-------------//
                var param = string.Format("'{0}'", txtAmount.ClientID);
                txtAmount.Attributes.Add("onvaluechange", string.Format("calcAmount({0})", param));

                this.InitDropDownListData(cmbPaymentMethod, this._paymentMethodPayment);
                cmbPaymentMethod.SelectedValue = data.PaymentMethod.ToString();

                //Get Exchange Rate
                var label = (System.Web.UI.HtmlControls.HtmlGenericControl)e.Item.FindControl("lblAmountExchangeRate");
                label.InnerHtml = crcySelected.MoneyCode;
            }
        }

        /// <summary>
        /// Event Button AddRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRowPay_Click(object sender, EventArgs e)
        {
            //--------- ISV-Giam 2015/01/29 ---------
            this.SetConfirmData();
            //---------------------------------------

            //Get new list from screen
            var listPayDetail = this.GetDetailPaymentData();
            if (listPayDetail != null)
            {
                listPayDetail.Add(new T_Payment()
                {
                    PaymentMethod = 255
                });
            }

            //Process list view
            this.rptPayment.DataSource = listPayDetail;
            this.rptPayment.DataBind();

            //Find control focus
            var dtPaymentDate = this.rptPayment.Items[this._indexPayment].FindControl("dtPaymentDate");
            if (dtPaymentDate != null)
            {
                this.FocusControlId = dtPaymentDate.ClientID;
            }
        }

        /// <summary>
        /// Event Button RemoveRow
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRowPay_Click(object sender, EventArgs e)
        {
            //--------- ISV-Giam 2015/01/29 ---------
            this.SetConfirmData();
            //---------------------------------------

            //Show question delete row
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            this._actionMode = ActionMode.DeleteRowPayment;

            //Find control focus
            if (this.rptPayment.Items.Count > 0)
            {
                var dtPaymentDate = this.rptPayment.Items[this._indexPayment].FindControl("dtPaymentDate");
                if (dtPaymentDate != null)
                {
                    this.FocusControlId = dtPaymentDate.ClientID;
                }
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Process Confirm
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnYesProcessData(object sender, EventArgs e)
        {
            T_Purchase_H purchaseH = null;
            var methodVAT = this.cmbMethodVat.SelectedValue;
            short defaultVatType = short.Parse(this._defaultVatType);

            switch (this._actionMode)
            {
                case ActionMode.None:
                    break;
                case ActionMode.Issue:
                    #region Issue
                    PurchasePDF purchase = new PurchasePDF();
                    purchase.LoginInfo = this.LoginInfo;
                    var uniqueFileName = string.Format(PDF_PURCHASE_DOWNLOAD, DateTime.Now.ToString(FMT_YMDHMM));
                    this.ExportPDF(purchase.GetLocalReport(new LocalReport(), this.DataID, this.OldUpdateDate), uniqueFileName, true);

                    //Show data
                    this.ShowPurchaseInfo(this.DataID);
                    this.ShowDetailPaymentData(this.DataID);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                    this._actionMode = ActionMode.None;
                    return;
                    #endregion
                case ActionMode.Copy:
                    #region Copy
                    purchaseH = this.GetPurchaseByID(this.DataID);
                    //Check data
                    if (purchaseH != null)
                    {
                        var isOk = true;
                        if (purchaseH.UpdateDate != this.OldUpdateDate)
                        {
                            this.FocusControlId = this.btnCopy.ClientID;
                            base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                            isOk = false;
                            if (purchaseH.DeleteFlag == 1)
                            {
                                base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
                                return;
                            }
                        }

                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        //this.cmbStatus.SelectedValue = this._defaultStatus;

                        if (isOk)
                        {
                            //Set Mode
                            this.ProcessMode(Mode.Copy);
                            this._actionMode = ActionMode.None;
                        }
                    }
                    else
                    {
                        base.RedirectUrl(FrmBase.URL_PURCHASE_LIST);
                    }
                    return;
                    #endregion
                case ActionMode.DeleteRowPurchase:
                    #region DeleteRowPurchase
                    //Get Data

                    IList<PurchaseDetailInfo> listPurchase = this.GetDetailPurchaseData(includeDelete: false);
                    if (listPurchase.Count == 0)
                    {
                        PurchaseDetailInfo detail = new PurchaseDetailInfo();
                        detail.No = 1;
                        //----------- ISV-Giam 2015/01/12 -----------
                        detail.InternalID = -1;
                        //-------------------------------------------

                        if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                        {
                            defaultVatType = short.Parse(this._defaultVatType);
                        }

                        if (defaultVatType == short.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            detail.VatRatio = decimal.Parse(this.DefaultVAT);
                        }
                        detail.VatType = defaultVatType;

                        detail.SerialList = new List<PurchaseSerialInfo>();
                        PurchaseSerialInfo serial = new PurchaseSerialInfo();
                        serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;// this.DefaultSerialView == 1 ? "in" : string.Empty;

                        serial.No = 1;
                        serial.FinishDate = null;
                        serial.StartDate = null;
                        serial.ContractType = short.Parse(this._defaultContractType);
                        serial.DetailNo = detail.No;
                        detail.SerialList.Add(serial);

                        listPurchase.Add(detail);
                    }
                    this.RefreshPurchaseDetails(listPurchase);
                    this.chkDelAll.Checked = false;

                    this.SetConfirmData(false);
                    this._actionMode = ActionMode.None;
                    return;
                    #endregion
                case ActionMode.RemoveChildRow:
                    #region Delete Child Row(Cost)

                    string[] value = this.ChildRowCommandArgument.Split('_');
                    int detailNo = Convert.ToInt32(value[0]);
                    int no = Convert.ToInt32(value[1]);

                    //Get Data
                    IList<PurchaseDetailInfo> purchaseDInfoList = this.GetDetailPurchaseData();

                    var purchaseDInfo = purchaseDInfoList.Where(s => s.No == detailNo).SingleOrDefault();
                    purchaseDInfo.SerialList.AsParallel().ForAll(s => s.Collapsed = "in");
                    if (purchaseDInfo.SerialList.Count != 0)
                    {
                        purchaseDInfo.SerialList.RemoveAt(no - 1);
                        var seriNo = 1;
                        foreach (var seri in purchaseDInfo.SerialList)
                        {
                            seri.No = seriNo++;
                        }
                    }

                    if (purchaseDInfo.SerialList.Count == 0)
                    {
                        var seriInfo = new PurchaseSerialInfo
                        {
                            PurchaseID = purchaseDInfo.InternalID,
                            No = purchaseDInfo.SerialList.Count + 1,
                            DetailNo = detailNo,
                            StartDate = null,
                            FinishDate = null,
                            ContractType = short.Parse(this._defaultContractType),
                            Collapsed = "in"
                        };
                        purchaseDInfo.SerialList.Add(seriInfo);
                    }

                    this.RefreshPurchaseDetails(purchaseDInfoList);

                    this.SetConfirmData(true);

                    var lastCostItem = purchaseDInfo.SerialList.LastOrDefault();
                    this.FocusControlId = string.Format("{0}_txtSerial_{1}", purchaseDInfo.No - 1, lastCostItem.No - 1);
                    this._actionMode = ActionMode.None;
                    return;

                    #endregion Delete Child Row(Cost)
                case ActionMode.DeleteRowPayment:
                    #region DeleteRowPayment
                    //Get new list from screen
                    var listPayment = this.GetDetailPaymentData();

                    //Get list index remove item
                    List<int> listDel = new List<int>();
                    for (int i = listPayment.Count - 1; i >= 0; i--)
                    {
                        if (listPayment[i].DelFlag)
                        {
                            listDel.Add(i);
                        }
                        listPayment[i].DelFlag = false;
                    }

                    //Remove row
                    foreach (var item in listDel)
                    {
                        listPayment.RemoveAt(item);
                    }

                    this.rptPayment.DataSource = listPayment;
                    this.rptPayment.DataBind();

                    //Set Action Mode
                    this.SetConfirmData(false);
                    this._actionMode = ActionMode.None;
                    this.FocusControlId = this.btnDeleteRowPay.ClientID;
                    return;
                    #endregion
                case ActionMode.CurrencyChanged:
                    #region CurrencyChanged
                    this.FocusControlId = this.cmbCurrency.ClientID;
                    //----------------- Edited by ISV-Giam 2014/12/15 -----------------
                    var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                    var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                    //-----------------------------------------------------------------

                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtPrice = (INumberTextBox)item.FindControl("txtPrice");
                            INumberTextBox txtTotal = (INumberTextBox)item.FindControl("txtTotal");
                            INumberTextBox txtVat = (INumberTextBox)item.FindControl("txtVat");

                            //Set decimal digit control sell by exchange
                            this.SetDecimalDigit(crcySelected, txtPrice, Constant.MAX_UNIT_PRICE_DECIMAL, Constant.MAX_UNIT_PRICE_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtTotal, Constant.MAX_SUB_TOTAL_DECIMAL, Constant.MAX_SUB_TOTAL_NOT_DECIMAL);
                            this.SetDecimalDigit(crcySelected, txtVat, Constant.MAX_SUB_VAT_DECIMAL, Constant.MAX_SUB_VAT_NOT_DECIMAL);

                            //Reset null value
                            txtPrice.Value = null;
                            txtTotal.Value = null;
                            txtVat.Value = null;

                            //Get ExchangeRate
                            var label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblVatExchangeRate");
                            label.InnerHtml = crcySelected.MoneyCode;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblTotalExchangeRate");
                            label.InnerHtml = crcySelected.MoneyCode;

                            label = (System.Web.UI.HtmlControls.HtmlGenericControl)item.FindControl("lblPriceExchangeRate");
                            label.InnerHtml = crcySelected.MoneyCode;

                            this.lblSumTotalExchangeRate.InnerText = crcySelected.MoneyCode;
                            this.lblSumVatExchangeRate.InnerText = crcySelected.MoneyCode;
                            this.lblGrandTotalExchangeRate.InnerText = crcySelected.MoneyCode;

                            this.lblPaymentTotalExchangeRate.InnerText = crcySelected.MoneyCode;
                            this.lblBalanceExchangeRate.InnerText = crcySelected.MoneyCode;

                            this.lblVATRatio.InnerText = string.Format("{0}/Ratio", crcySelected.TaxName);
                        }
                    }

                    //Set decimal digit control total by exchange
                    this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                    this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);

                    this._actionMode = ActionMode.None;
                    this.SetConfirmData(true);
                    this.RefreshPurchaseDetails();
                    this.RefreshPaymentDetails();

                    if (this.ViewState["HEADER"] != null)
                    {
                        var header = (T_Purchase_H)this.ViewState["HEADER"];
                        header.CurrencyID = int.Parse(this.cmbCurrency.SelectedValue);
                        this.ViewState["HEADER"] = header;
                    }
                    return;
                    #endregion
                case ActionMode.MethodChanged:
                    #region MethodChanged
                    this._actionMode = ActionMode.None;

                    this.FocusControlId = this.cmbMethodVat.ClientID;

                    //Set enable control at detail list with method vat type
                    foreach (RepeaterItem item in this.rptDetail.Items)
                    {
                        if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
                        {
                            //Find control
                            INumberTextBox txtVat = (INumberTextBox)item.FindControl("txtVat");
                            DropDownList cmbVatType = (DropDownList)item.FindControl("cmbVatType");
                            INumberTextBox txtVatRatio = (INumberTextBox)item.FindControl("txtVatRatio");

                            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                            {
                                //Enable control sell by method vat
                                txtVat.SetReadOnly(false);
                                txtVatRatio.SetReadOnly(false);
                                cmbVatType.Enabled = true;
                                txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
                                this.InitDropDownListData(cmbVatType, this._vatTypeList);
                                cmbVatType.SelectedValue = defaultVatType.ToString();
                            }
                            else
                            {
                                //Enable control sell by method vat
                                txtVat.SetReadOnly(true);
                                txtVatRatio.SetReadOnly(true);
                                cmbVatType.Enabled = false;
                                txtVat.Value = null;
                                txtVatRatio.Value = null;
                                this.InitDropDownListData(cmbVatType, this._vatTypeListEmpty);
                            }
                        }
                    }

                    if (methodVAT == M_Config_D.METHOD_VAT_EACH)
                    {
                        //Set enable control at total with method vat type
                        this.txtTotalVatRatio.SetReadOnly(true);
                        this.txtSumVat.SetReadOnly(false);

                        this.cmbTotalVatType.Enabled = false;

                        this.txtTotalVatRatio.Value = null;
                        this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeListEmpty);
                    }
                    else
                    {
                        //SUM
                        this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeList);
                        this.cmbTotalVatType.SelectedValue = defaultVatType.ToString();
                        this.cmbTotalVatType.Enabled = true;

                        if (defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE))
                        {
                            //Set enable control at total with method vat type
                            this.txtTotalVatRatio.SetReadOnly(false);
                            this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
                        }
                    }
                    this.SetConfirmData(false);
                    this.RefreshPurchaseDetails();
                    if (this.ViewState["HEADER"] != null)
                    {
                        purchaseH = (T_Purchase_H)this.ViewState["HEADER"];
                        purchaseH.MethodVat = short.Parse(this.cmbMethodVat.SelectedValue);
                        this.ViewState["HEADER"] = purchaseH;
                    }
                    return;
                    #endregion
                default:
                    break;
            }

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:
                    //Insert Data
                    if (this.InsertData())
                    {
                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Mode.Update:
                    //Update Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Mode.Check:
                    //Check Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:
                    //Delete Data
                    if (this.DeleteData())
                    {
                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Utilities.Mode.View:
                    break;
            }
        }

        /// <summary>
        /// RestoreValue
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
            switch (this._actionMode)
            {
                case ActionMode.None:
                    break;
                case ActionMode.CurrencyChanged:
                    //Show old value
                    if (this.ViewState["HEADER"] != null)
                    {
                        T_Purchase_H header = (T_Purchase_H)this.ViewState["HEADER"];
                        this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();
                    }
                    break;

                case ActionMode.MethodChanged:
                    if (this.ViewState["HEADER"] != null)
                    {
                        T_Purchase_H header = (T_Purchase_H)this.ViewState["HEADER"];
                        this.cmbMethodVat.SelectedValue = header.MethodVat.ToString();
                    }
                    this.ShowDetailPaymentData(this.DataID);
                    break;

                //------ ISV-Giam 2015/02/03 -------
                case ActionMode.DeleteRowPurchase:
                    this.FocusControlId = this.btnTopDeleteRow.ClientID;
                    this.SetConfirmData();
                    break;
                //----------------------------------

                case ActionMode.DeleteRowPayment:
                    this.FocusControlId = this.btnDeleteRowPay.ClientID;
                    this.SetConfirmData(false);
                    break;

                default:
                    //Show data mode Copy
                    this.ShowPurchaseInfo(this.DataID);
                    this.ShowDetailPaymentData(this.DataID);
                    break;
            }
            this._actionMode = ActionMode.None;

            //Non-Delete
            if (this.Mode == Utilities.Mode.Delete)
            {
                //Show data
                this.ShowPurchaseInfo(this.DataID);
                this.ShowDetailPaymentData(this.DataID);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.ClearUpdateInfo();
                    //Init Data
                    this.InitData();
                    break;

                case Mode.Copy:
                    this.FileCount = 0;
                    this.txtPurchaseNo.Value = string.Empty;
                    this.txtSalesNo.Value = string.Empty;
                    this.txtQuotationNo.Value = string.Empty;
                    //------------------------Add 2014/12/30 ISV-HUNG----------------//
                    this.SetDefaultDataForCopyMode();
                    var listDetail = this.GetDetailPurchaseData();
                    listDetail.AsParallel().ForAll(s => s.DataCheck = string.Empty);
                    this.rptDetail.DataSource = listDetail;
                    this.rptDetail.DataBind();
                    //------------------------Add 2014/12/30 ISV-HUNG----------------//
                    this.ClearUpdateInfo();
                    break;

                case Mode.Update:
                    break;

                case Mode.Check:
                    this.FocusControlId = "txtDeliQuantity_0";
                    break;

                case Mode.View:
                    this.DisabledLink(this.btnEdit, !base._authority.IsPurchaseEdit);
                    this.DisabledLink(this.btnIssue, !base._authority.IsPurchasePDF);
                    this.DisabledLink(this.btnCheck, !base._authority.IsPurchaseCheck);
                    this.DisabledLink(this.btnCopy, !base._authority.IsPurchaseCopy);
                    this.DisabledLink(this.btnDelete, !base._authority.IsPurchaseDelete);
                    break;
                default:
                    break;
            }

            var methodVAT = this.cmbMethodVat.SelectedValue;

            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
            {
                //TotalVatRatio
                this.txtTotalVatRatio.SetReadOnly(true);
                //TotalVatType
                this.cmbTotalVatType.Enabled = false;

                this.txtTotalVatRatio.Value = null;
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeListEmpty);
            }
            else
            {
                //TotalVatRatio
                this.txtTotalVatRatio.SetReadOnly(false);
                //TotalVatType
                this.cmbTotalVatType.Enabled = true;

                //SUM
                this.InitDropDownListData(this.cmbTotalVatType, this._vatTypeList);
                if (int.Parse(this.cmbTotalVatType.SelectedValue) != (int)VATFlg.Exclude)
                {
                    this.txtTotalVatRatio.SetReadOnly(true);
                    this.txtSumVat.SetReadOnly(true);
                    this.txtTotalVatRatio.Value = null;
                }
                else
                {
                    this.txtTotalVatRatio.SetReadOnly(false);
                    this.txtSumVat.SetReadOnly(false);
                    if (!this.txtTotalVatRatio.Value.HasValue)
                    {
                        this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
                    }
                }
            }

            //------------------- Edited by ISV-Giam 2014/12/15 ----------------------
            var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
            var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
            //------------------------------------------------------------------------

            this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            //------------- Edited 2014/12/08 by ISV Giam ---------------
            this.txtVendorName.SetReadOnly(true);
            if (this.txtVendorCD.Value == Models.M_Vendor.VENDOR_CODE_SUPPORT && this.txtSalesNo.IsEmpty)
            {
                this.txtVendorName.SetReadOnly(false);
            }
            //-----------------------------------------------------------

            //Payment Table
            this.SetDecimalDigit(crcySelected, this.txtPaymentTotal, Constant.MAX_SUM_AMOUNT_DECIMAL, Constant.MAX_SUM_AMOUNT_NOT_DECIMAL);
            this.SetDecimalDigit(crcySelected, this.txtBalance, Constant.MAX_BALANCE_DECIMAL, Constant.MAX_BALANCE_NOT_DECIMAL);
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        /// <returns>PurchaseDetailInfo List</returns>
        private IList<PurchaseDetailInfo> GetDetailPurchaseData(bool includeEmpty = true, bool includeDelete = true)
        {
            this.isDetailEmpty = true;
            IList<PurchaseDetailInfo> ret = new List<PurchaseDetailInfo>();
            this._indexDetail = 1;
            foreach (RepeaterItem item in this.rptDetail.Items)
            {
                HtmlInputCheckBox chkDetailDel = (HtmlInputCheckBox)item.FindControl("chkDetailDel");

                if (!includeDelete && chkDetailDel.Checked)
                {
                    continue;
                }

                PurchaseDetailInfo detail = this.GetRowPurchaseDetail(item);

                if (includeEmpty)
                {
                    if (!detail.IsEmptyRow(decimal.Parse(this.DefaultVAT)))
                    {
                        this.isDetailEmpty = false;
                    }
                    else
                    {
                        detail.VatRatio = decimal.Parse(this.DefaultVAT);
                    }
                    ret.Add(detail);
                }
                else
                {
                    if (!detail.IsEmptyRow(decimal.Parse(this.DefaultVAT)))
                    {
                        this.isDetailEmpty = false;
                        ret.Add(detail);
                    }
                }
            }

            //Reset index for row
            if (!includeEmpty)
            {
                foreach (var pur in ret)
                {
                    pur.No = this._indexDetail++;
                    foreach (var seri in pur.SerialList)
                    {
                        seri.DetailNo = pur.No;
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Get header by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private T_Purchase_H GetPurchaseByID(int id)
        {
            using (DB db = new DB())
            {
                Purchase_HService service = new Purchase_HService(db);
                return service.GetByPK(this.DataID);
            }
        }

        /// <summary>
        /// Refresh Purchase Details
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshPurchaseDetails(IList<PurchaseDetailInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailPurchaseData();
            }
            this.rptDetail.DataSource = dataSource;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Set Confirm
        /// </summary>
        private void SetConfirmData(bool keepOldValue = true)
        {
            using (DB db = new DB())
            {
                UserService userSrv = new UserService(db);
                ProductService prodSrv = new ProductService(db);
                VendorService vendorSrv = new VendorService(db);
                //-----------------ISV-HUNG 2015/01/05
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(this.DataID, (int)FType.Purchase);
                //-----------------ISV-HUNG 2015/01/05

                #region Header

                //txtVendorCD
                if (!this.txtVendorCD.IsEmpty && this.txtVendorCD.Value != Models.M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    //---------- Edited 2014/12/08 by ISV Giam ----------
                    this.txtVendorName.SetReadOnly(true);
                    //---------------------------------------------------
                    var vendorCd = this.txtVendorCD.Value;
                    vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                    var vendor = vendorSrv.GetByCD(vendorCd);
                    if (vendor != null && vendor.StatusFlag != 1)
                    {
                        this.txtVendorName.Value = vendor.VendorName1;
                    }
                }
                //---------- Edited 2014/12/08 by ISV Giam ----------
                else
                {
                    if (this.txtVendorCD.Value != Models.M_Vendor.VENDOR_CODE_SUPPORT)
                    {
                        this.txtVendorName.Value = null;
                        this.txtVendorName.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtVendorName.SetReadOnly(false);
                    }
                }
                //---------------------------------------------------

                M_User user = null;
                this.txtPreparedName.Value = null;
                //txtPreparedCD
                if (!this.txtPreparedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtPreparedName.Value = user.UserName2;
                    }
                }

                this.txtApprovedName.Value = null;
                //txtApprovedCD
                if (!this.txtApprovedCD.IsEmpty)
                {
                    var userCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(userCD, false);
                    if (user != null && user.ID != Constant.DEFAULT_ID)
                    {
                        this.txtApprovedName.Value = user.UserName2;
                    }
                }

                #endregion

                var methodType = this.cmbMethodVat.SelectedValue;
                if (this._actionMode == ActionMode.MethodChanged)
                {
                    //Show old value
                    T_Purchase_H header = (T_Purchase_H)this.ViewState["HEADER"];
                    methodType = header.MethodVat.ToString();
                }

                var sumTotalDetail = 0m;
                var sumVatDetail = 0m;
                var sumTotalPayment = 0m;

                #region Detail
                foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
                {
                    ICodeTextBox txtProductCD = (ICodeTextBox)repeaterItem.FindControl("txtProductCD");
                    ITextBox txtProductName = (ITextBox)repeaterItem.FindControl("txtProductName");
                    if (!txtProductCD.IsEmpty && txtProductCD.Value != M_Product.PRODUCT_CODE_SUPPORT
                        && txtProductName.IsEmpty)
                    {
                        var product = prodSrv.GetByCD(txtProductCD.Value);
                        if (product != null)
                        {
                            txtProductName.Value = product.ProductName;
                        }
                    }

                    INumberTextBox txtPrice = (INumberTextBox)repeaterItem.FindControl("txtPrice");
                    INumberTextBox txtQuantity = (INumberTextBox)repeaterItem.FindControl("txtQuantity");
                    INumberTextBox txtTotal = (INumberTextBox)repeaterItem.FindControl("txtTotal");
                    INumberTextBox txtVat = (INumberTextBox)repeaterItem.FindControl("txtVat");
                    DropDownList cmbUnit = (DropDownList)repeaterItem.FindControl("cmbUnit");
                    DropDownList cmbVatType = (DropDownList)repeaterItem.FindControl("cmbVatType");
                    INumberTextBox txtVatRatio = (INumberTextBox)repeaterItem.FindControl("txtVatRatio");

                    var unitPrice = txtPrice.Value.GetValueOrDefault();
                    var quantity = txtQuantity.Value.GetValueOrDefault();
                    var total = Fraction.Round(this._defaultFractionType, unitPrice * quantity, 2);
                    var vat = Fraction.Round(this._defaultFractionType, (total * txtVatRatio.Value.GetValueOrDefault()) / 100, 2);
                    //--------- ISV-Giam 2015/01/29 --------
                    short curVatType = -1;
                    if (this.Mode == Utilities.Mode.Check)
                    {
                        //hdnVatType
                        HiddenField hdnVatType = (HiddenField)repeaterItem.FindControl("hdnVatType");
                        curVatType = Convert.ToInt16(hdnVatType.Value);
                        cmbVatType.SelectedValue = hdnVatType.Value;

                        //hdnUnitID
                        HiddenField hdnUnitID = (HiddenField)repeaterItem.FindControl("hdnUnitID");
                        cmbUnit.SelectedValue = hdnUnitID.Value;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(cmbVatType.SelectedValue))
                        {
                            curVatType = Convert.ToInt16(cmbVatType.SelectedItem.Value);
                        }
                    }
                    //--------------------------------------

                    if (!txtPrice.IsEmpty && !txtQuantity.IsEmpty)
                    {
                        if (txtTotal.IsEmpty || !keepOldValue)
                        {
                            txtTotal.Value = total;
                        }
                        sumTotalDetail += txtTotal.Value.GetValueOrDefault();

                        if (methodType == M_Config_D.METHOD_VAT_EACH && curVatType == (int)VATFlg.Exclude)
                        {
                            if (txtVat.IsEmpty || !keepOldValue)
                            {
                                txtVat.Value = vat;
                            }
                            sumVatDetail += txtVat.Value.GetValueOrDefault();
                        }
                    }

                    if (methodType == M_Config_D.METHOD_VAT_SUM || curVatType != (int)VATFlg.Exclude)
                    {
                        txtVatRatio.Value = null;
                        txtVat.Value = null;

                        txtVatRatio.SetReadOnly(true);
                        txtVat.SetReadOnly(true);
                    }
                    else
                    {
                        txtVatRatio.SetReadOnly(false);
                        txtVat.SetReadOnly(false);
                    }

                    if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                    {
                        Repeater rptSerial = (Repeater)repeaterItem.FindControl("rptSerial");
                        foreach (RepeaterItem item in rptSerial.Items)
                        {
                            DropDownList cmbUnitSerial = (DropDownList)item.FindControl("cmbUnitSerial");
                            HiddenField hdUnitSerial = (HiddenField)item.FindControl("hdUnitSerial");
                            if (this.Mode == Mode.Check)
                            {
                                cmbUnitSerial.SelectedValue = hdUnitSerial.Value;
                            }
                        }
                    }
                }
                #endregion

                #region Payment
                foreach (RepeaterItem repeaterItem in this.rptPayment.Items)
                {
                    INumberTextBox txtAmount = (INumberTextBox)repeaterItem.FindControl("txtAmount");

                    sumTotalPayment += txtAmount.Value.GetValueOrDefault();

                    if (this.Mode == Utilities.Mode.Update)
                    {
                        //hdnUnitID
                        DropDownList cmbPaymentMethod = (DropDownList)repeaterItem.FindControl("cmbPaymentMethod");
                        HiddenField hdnPaymentMethod = (HiddenField)repeaterItem.FindControl("hdnPaymentMethod");
                        cmbPaymentMethod.SelectedValue = hdnPaymentMethod.Value;
                    }
                }
                #endregion

                #region SumTotal

                if (this.txtSumTotal.IsEmpty || !keepOldValue)
                {
                    this.txtSumTotal.Value = sumTotalDetail;
                }
                sumTotalDetail = this.txtSumTotal.Value.GetValueOrDefault();

                if (methodType == M_Config_D.METHOD_VAT_EACH)
                {
                    if (this.txtSumVat.IsEmpty || !keepOldValue)
                    {
                        this.txtSumVat.Value = sumVatDetail;
                    }
                    else
                    {
                        sumVatDetail = this.txtSumVat.Value.GetValueOrDefault();
                    }
                }
                else
                {
                    var vatType = int.Parse(this._defaultVatType);
                    //----------- ISV-Giam 2015/01/29 -----------
                    if (this.Mode == Utilities.Mode.Check)
                    {
                        T_Purchase_H header = (T_Purchase_H)this.ViewState["HEADER"];
                        this.cmbTotalVatType.SelectedValue = header.VatType.ToString();
                        vatType = header.VatType;
                    }
                    else
                    {
                        //VatType
                        if (!string.IsNullOrEmpty(this.cmbTotalVatType.SelectedValue))
                        {
                            vatType = int.Parse(this.cmbTotalVatType.SelectedValue);
                        }
                    }
                    //-------------------------------------------                    

                    if (vatType == (int)VATFlg.Exclude)
                    {
                        var vatRatio = this.txtTotalVatRatio.Value.GetValueOrDefault();
                        if (this.txtSumVat.IsEmpty || !keepOldValue)
                        {
                            this.txtSumVat.Value = Fraction.Round(this._defaultFractionType, (sumTotalDetail * vatRatio) / 100, 2);
                        }

                        sumVatDetail = this.txtSumVat.Value.GetValueOrDefault();

                        this.txtSumVat.SetReadOnly(false);
                        this.txtTotalVatRatio.SetReadOnly(false);
                    }
                    else
                    {
                        sumVatDetail = 0;
                        this.txtSumVat.SetReadOnly(true);
                        this.txtTotalVatRatio.SetReadOnly(true);

                        this.txtSumVat.Value = null;
                        this.txtTotalVatRatio.Value = null;
                    }
                }

                if (!this.txtGrandTotal.Value.HasValue || !keepOldValue)
                {
                    this.txtGrandTotal.Value = sumTotalDetail + sumVatDetail;
                }

                //txtPaymentTotal
                if (sumTotalPayment.Equals(0) && this.rptPayment.Items.Count == 0)
                {
                    //this.txtPaymentTotal.Value = null;
                    this.txtPaymentTotal.Value = 0;
                }
                else
                {
                    this.txtPaymentTotal.Value = sumTotalPayment;
                }

                //txtBalance
                this.txtBalance.Value = this.txtGrandTotal.Value - sumTotalPayment;

                #endregion
            }
        }

        /// <summary>
        /// Up or Down Item
        /// </summary>
        /// <param name="up">Up Flg</param>
        private void SwapDetail(bool up)
        {
            IList<PurchaseDetailInfo> details = this.GetDetailPurchaseData();

            if (details.Count == 0)
            {
                return;
            }

            IList<PurchaseDetailInfo> results = new List<PurchaseDetailInfo>();

            if (up)
            {
                results.Add(details.First());
                for (int i = 1; i < details.Count; i++)
                {
                    var item = details[i];
                    var itemPre = results[i - 1];

                    if (item.DetailDeleted)
                    {
                        if (itemPre.DetailDeleted)
                        {
                            results.Add(item);
                        }
                        else
                        {
                            results.Insert(i - 1, item);
                        }
                    }
                    else
                    {
                        results.Add(item);
                    }
                }
            }
            else
            {
                results.Add(details.Last());
                for (int i = details.Count - 2; i >= 0; i--)
                {
                    var item = details[i];
                    if (item.DetailDeleted)
                    {
                        if (results[0].DetailDeleted)
                        {
                            results.Insert(0, item);
                        }
                        else
                        {
                            results.Insert(1, item);
                        }
                    }
                    else
                    {
                        results.Insert(0, item);
                    }
                }
            }

            this._indexDetail = 1;

            for (int i = 0; i < results.Count; i++)
            {
                var row = results[i];
                row.No = i + 1;

                foreach (var seri in row.SerialList)
                {
                    seri.DetailNo = row.No;
                }
            }

            this.rptDetail.DataSource = results;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //init
            this.FileCount = 0;
            this.DataID = 0;

            if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtPreparedCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPreparedName.Value = base.LoginInfo.User.UserName2;
            }

            this.cmbMethodVat.SelectedValue = this._defaultMethodVat;
            this.txtTotalVatRatio.Value = decimal.Parse(this.DefaultVAT);
            //this.txtConfirmed.Value = Constant.DEFAULT_CONFIRMED;
            this.txtConfirmed.Value = string.Empty;
            this.txtPosition.Value = Constant.DEFAULT_POSITION;
            this.txtConfirmed.Value = Constant.DEFAULT_REPRESENT;

            //Save ViewState
            this.ViewState["HEADER"] = new T_Purchase_H
            {
                MethodVat = short.Parse(this._defaultMethodVat),
                CurrencyID = Constant.DEFAULT_ID
            };

            short defaultVatType = short.Parse(this._defaultVatType);
            if (this._defaultMethodVat == M_Config_D.METHOD_VAT_SUM)
            {
                this.cmbTotalVatType.SelectedValue = defaultVatType.ToString();
                defaultVatType = -1;
            }

            IList<PurchaseDetailInfo> details = new List<PurchaseDetailInfo>();
            PurchaseDetailInfo item = new PurchaseDetailInfo();
            item.No = 1;
            item.VatRatio = defaultVatType == int.Parse(M_Config_D.VAT_TYPE_EXCLUDE) ? (decimal?)decimal.Parse(this.DefaultVAT) : null;
            item.VatType = defaultVatType;

            //SerialList
            item.SerialList = new List<PurchaseSerialInfo>();
            PurchaseSerialInfo serial = new PurchaseSerialInfo();
            serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
            serial.No = 1;
            serial.ContractType = short.Parse(this._defaultContractType);
            serial.DetailNo = item.No;
            serial.StartDate = null;
            serial.FinishDate = null;
            item.SerialList.Add(serial);
            details.Add(item);

            this.rptDetail.DataSource = details;
            this.rptDetail.DataBind();
        }

        /// <summary>
        /// Get Default Data 
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                UnitService unitSer = new UnitService(db);
                Currency_HService currencyHService = new Currency_HService(db);
                Config_HService configSer = new Config_HService(db);
                Config_DService config_DSer = new Config_DService(db);

                //Get Unit
                this._unitList = unitSer.GetDataForDropDownList();

                var crcyItems = currencyHService.GetListDropdown();

                //Get currency list
                this._currencyList = new List<DropDownModel>(crcyItems.Select(c => new DropDownModel
                {
                    Value = c.ID.ToString(),
                    DisplayName = c.MoneyCode,
                    DataboundItem = c
                }));

                //MethodVatList
                this._methodVatList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_VAT);
                this._defaultMethodVat = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_METHOD_VAT);

                //Contract Type List
                this._contractTypeList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);
                this._defaultContractType = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_SERIAL_CONTRACT_TYPE);

                //VatTypeList
                this._vatTypeList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_VAT_TYPE);
                this._defaultVatType = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_VAT_TYPE);

                //Payment
                this._paymentMethodPayment = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_PAYMENT_METHOD);
                this._paymentMethodPayment.Insert(0, new DropDownModel()
                {
                    Value = "255",
                    DisplayName = string.Empty
                });
                this._defaultPaymentMethod = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAYMENT_METHOD);

                this.DefaultVAT = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_VAT_VAL);

                this.QuantityDecimal = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_QUANTITY_DECIMAL) == M_Config_D.QUANTITY_DECIMAL ? 2 : 0;

                this.DefaultSerialView = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_COST_VIEW);
                this.DefaultSerialHidden = int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_SERIAL_HIDDEN));//0: Show, 1:Hidden

                this._defaultFractionType = (FractionType)int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_FRACTION_TYPE));

                // ---------------------- Edited 2014/12/10-----------------------
                this.ProductCdUsed = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PRODUCT_CD_USED) == M_Config_D.CONFIG_CD_PRODUCT_CD_USED_ON;
                // -------------------------- End   ------------------------------

                if (!this.IsPostBack)
                {
                    var purchaseDate = db.NowDate;
                    var expiryDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase));
                    var paymentDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase_Payment_Date));

                    //Set Purchase Date
                    this.txtPurchaseDate.Value = purchaseDate;

                    //Set Expiry Date
                    if (!expiryDay.HasValue)
                    {
                        this.txtExpiryDate.Value = null;
                    }
                    else
                    {
                        var expiryDate = purchaseDate.AddDays(expiryDay.Value);
                        this.txtExpiryDate.Value = expiryDate;
                    }

                    //Set Payment Date
                    if (!paymentDay.HasValue)
                    {
                        this.txtPaymentDate.Value = null;
                    }
                    else
                    {
                        var paymentDate = purchaseDate.AddDays(paymentDay.Value);
                        this.txtPaymentDate.Value = paymentDate;
                    }
                }
            }
        }

        /// <summary>
        /// Init Unit Data
        /// </summary>
        /// <param name="dropDownList">DropDownList</param>
        /// <param name="data">DropDownModel</param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Init data for Warranty type
        /// </summary>
        /// <param name="ddlWarranty"></param>
        /// <returns></returns>
        private List<DropDownModel> InitDataForWarrantyType(DropDownList ddlWarranty)
        {
            // init combox
            List<DropDownModel> items = new List<DropDownModel>();
            items.Add(new DropDownModel(((int)WarrantyUnit.None).ToString(), "---"));
            items.Add(new DropDownModel(((int)WarrantyUnit.Years).ToString(), WarrantyUnit.Years.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Months).ToString(), WarrantyUnit.Months.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Weeks).ToString(), WarrantyUnit.Weeks.ToString()));
            items.Add(new DropDownModel(((int)WarrantyUnit.Days).ToString(), WarrantyUnit.Days.ToString()));
            return items;
        }

        //------------------------Add 2014/12/30 ISV-HUNG----------------//
        /// <summary>
        /// Set default data for mode copy
        /// </summary>
        private void SetDefaultDataForCopyMode()
        {
            //Header
            if (base.LoginInfo.User.ID != Constant.DEFAULT_ID)
            {
                this.txtPreparedCD.Value = EditDataUtil.ToFixCodeShow(base.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPreparedName.Value = base.LoginInfo.User.UserName2;
            }

            using (DB db = new DB())
            {
                Config_DService config_DSer = new Config_DService(db);
                var purchaseDate = db.NowDate;
                var expiryDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase));
                var paymentDay = config_DSer.GetValue(M_Config_H.CONFIG_CD_DEFAULT_EXPIRY_DAY, int.Parse(M_Config_D.CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase_Payment_Date));

                //Set Purchase Date
                this.txtPurchaseDate.Value = purchaseDate;

                //Set Expiry Date
                if (!expiryDay.HasValue)
                {
                    this.txtExpiryDate.Value = null;
                }
                else
                {
                    var expiryDate = purchaseDate.AddDays(expiryDay.Value);
                    this.txtExpiryDate.Value = expiryDate;
                }

                //Set Payment Date
                if (!paymentDay.HasValue)
                {
                    this.txtPaymentDate.Value = null;
                }
                else
                {
                    var paymentDate = purchaseDate.AddDays(paymentDay.Value);
                    this.txtPaymentDate.Value = paymentDate;
                }
            }

            //Detail
            foreach (RepeaterItem repeaterItem in this.rptDetail.Items)
            {
                //DeliQuantity
                INumberTextBox txtDeliQuantity = (INumberTextBox)repeaterItem.FindControl("txtDeliQuantity");
                txtDeliQuantity.Value = null;

                //DeliveryDate
                IDateTextBox txtDeliverDate = (IDateTextBox)repeaterItem.FindControl("txtDeliverDate");
                txtDeliverDate.Value = null;
            }
        }
        //------------------------Add 2014/12/30 ISV-HUNG----------------//

        /// <summary>
        /// Get Purchase by Purchase id
        /// </summary>
        /// <param name="id">Purchase ID</param>
        private void ShowPurchaseInfo(int id)
        {
            using (DB db = new DB())
            {
                Purchase_HService hService = new Purchase_HService(db);
                Purchase_DService dService = new Purchase_DService(db);
                Purchase_CService condService = new Purchase_CService(db);
                AttachedService attachedService = new AttachedService(db);
                Sales_HService sales_HService = new Sales_HService(db);
                TPurchaseSerialService serialService = new TPurchaseSerialService(db);

                var header = hService.GetByPK(id);

                this.txtVendorCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(header.VendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                this.txtVendorName.Value = header.VendorName;

                this.txtAttn.Value = header.ContactPerson;

                this.txtAdd1.Value = header.VendorAddress1;
                this.txtAdd2.Value = header.VendorAddress2;
                this.txtAdd3.Value = header.VendorAddress3;

                this.txtTel.Value = header.Tel;
                this.txtFax.Value = header.Fax;
                this.txtSubject.Value = header.SubjectName;
                this.txtPurchaseNo.Value = header.PurchaseNo;
                this.txtQuotationNo.Value = header.QuoteNo;
                this.txtSalesNo.Value = header.SalesNo;
                this.txtPurchaseDate.Value = header.PurchaseDate;

                if (header.ExpiryDate == DEFAULT_DATE_TIME)
                {
                    this.txtExpiryDate.Value = null;
                }
                else
                {
                    this.txtExpiryDate.Value = header.ExpiryDate;
                }

                if (header.PaymentDate == DEFAULT_DATE_TIME)
                {
                    this.txtPaymentDate.Value = null;
                }
                else
                {
                    this.txtPaymentDate.Value = header.PaymentDate;
                }

                this.txtPreparedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(header.PreparedCD, M_User.MAX_USER_CODE_SHOW);
                this.txtPreparedName.Value = header.PreparedName;
                this.txtApprovedCD.Value = OMS.Utilities.EditDataUtil.ToFixCodeDB(header.ApprovedCD, M_User.MAX_USER_CODE_SHOW);
                this.txtApprovedName.Value = header.ApprovedName;

                this.cmbCurrency.SelectedValue = header.CurrencyID.ToString();
                this.cmbMethodVat.SelectedValue = header.MethodVat.ToString();
                this.txtMemo.Value = header.Memo;
                this.chkDelAll.Checked = false;

                if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
                {
                    this.cmbTotalVatType.SelectedValue = header.VatType.ToString();
                    this.txtTotalVatRatio.Value = header.VatRatio;
                    if (this.cmbTotalVatType.SelectedValue == ((int)VATFlg.Exclude).ToString())
                    {
                        this.txtSumVat.Value = header.Vat;
                    }
                }
                else
                {
                    this.txtSumVat.Value = header.Vat;
                }

                this.txtSumTotal.Value = header.Total;

                this.txtGrandTotal.Value = header.GrandTotal;
                this.txtConfirmed.Value = header.Confirmed;
                this.txtPosition.Value = header.Position;

                this.Issued = header.IssuedFlag == 1;
                this.Deleted = header.DeleteFlag == 1;

                //Save UserID and UpdateDate
                this.DataID = header.ID;
                this.OldUpdateDate = header.UpdateDate;

                this.txtConditionCD.Value = string.Empty;
                T_Purchase_C model = condService.GetByPK(header.ID);
                if (model != null)
                {
                    //Load Condition
                    this.txtConditions.Value = model.Conditions;
                    this.OldCondition = model.Conditions;
                }

                UserService userService = new UserService(db);

                //Issue
                var issueUser = userService.GetByID(header.IssuedUID);
                if (issueUser != null)
                {
                    var issuedDate = (header.IssuedDate == DEFAULT_DATE_TIME) ? string.Empty : header.IssuedDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtIssueDate.Value = string.Format("{0} {1}", issueUser.UserName2, issuedDate);
                }
                else
                {
                    this.txtIssueDate.Value = string.Empty;
                }

                //Update
                var updateUser = userService.GetByID(header.UpdateUID);
                if (updateUser != null)
                {
                    var updateDate = (header.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : header.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                else
                {
                    this.txtUpdateDate.Value = string.Empty;
                }

                //Create
                var createUser = userService.GetByID(header.CreateUID);
                if (createUser != null)
                {
                    var createDate = (header.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : header.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);

                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }
                else
                {
                    this.txtCreateDate.Value = string.Empty;
                }

                //Save ViewState
                this.ViewState["HEADER"] = header;

                this._indexDetail = 0;

                //Get purchaseList
                var purchaseList = dService.GetByPurchaseID(id);

                //Get list Purchase serial Model
                var serialModel = serialService.GetList();

                var details = new List<PurchaseDetailInfo>();
                foreach (var item in purchaseList)
                {
                    PurchaseDetailInfo purchDetail = new PurchaseDetailInfo();
                    //------------- ISV-Giam 2015/01/12 -------------
                    purchDetail.InternalID = item.InternalID;
                    //-----------------------------------------------
                    purchDetail.No = item.No;
                    if (this._actionMode == ActionMode.Copy)
                    {
                        purchDetail.SalesCostID = 0;
                    }
                    else
                    {
                        purchDetail.SalesCostID = item.SalesCostID;
                    }
                    purchDetail.ProductCD = item.ProductCD;
                    purchDetail.ProductName = item.ProductName;
                    purchDetail.Description = item.Description;
                    purchDetail.UnitPrice = item.UnitPrice;
                    purchDetail.Quantity = item.Quantity;
                    purchDetail.UnitID = item.UnitID;
                    purchDetail.Total = item.Total;
                    purchDetail.Remark = item.Remark;
                    purchDetail.Vat = item.Vat;
                    purchDetail.VatType = item.VatType;
                    purchDetail.VatRatio = item.VatRatio;
                    if (!item.DeliverQuantity.HasValue)
                    {
                        purchDetail.DeliverQuantity = null;
                    }
                    else
                    {
                        if (item.DeliverQuantity.Value.Equals(0))
                        {
                            purchDetail.DeliverQuantity = null;
                        }
                        else
                        {
                            purchDetail.DeliverQuantity = item.DeliverQuantity;
                        }
                    }

                    if (item.DeliverDate == DEFAULT_DATE_TIME)
                    {
                        purchDetail.DeliverDate = null;
                    }
                    else
                    {
                        purchDetail.DeliverDate = item.DeliverDate;
                    }

                    purchDetail.SerialList = new List<PurchaseSerialInfo>(serialModel.Where(c => c.PurchaseDID == purchDetail.InternalID).Select(c => new PurchaseSerialInfo
                    {
                        No = ++this._indexDetail,
                        PurchaseID = c.PurchaseDID,
                        DetailNo = purchDetail.No,
                        SerialNo = c.SerialNo,
                        Terms = c.Terms,
                        TermUnit = c.TermUnit,
                        StartDate = c.StartDate,
                        FinishDate = c.FinishDate,
                        ContractType = c.ContractType,

                        Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty,
                    }));

                    details.Add(purchDetail);
                }

                //Show data fixed
                foreach (var item in details)
                {
                    /*
                    if (item.DeliverDate == DEFAULT_DATE_TIME)
                    {
                        item.DeliverDate = null;
                    }
                    if (item.DeliverQuantity == 0)
                    {
                        item.DeliverQuantity = null;
                    }

                    if (item.SalesCostID != 0)
                    {
                        item.RemainQty = dService.GetRemainQtyBySalesSellID(item.SalesSellID, this.DataID);
                    }
                    else
                    {
                        item.RemainQty = null;
                    }
                    */

                    //********************
                    if (item.SerialList == null || item.SerialList.Count == 0)
                    {
                        PurchaseSerialInfo serial = new PurchaseSerialInfo();
                        serial.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                        serial.No = 1;
                        serial.DetailNo = item.No;
                        serial.ContractType = short.Parse(this._defaultContractType);
                        serial.StartDate = null;
                        serial.FinishDate = null;
                        item.SerialList.Add(serial);
                    }
                    else
                    {
                        int indexSeri = 1;
                        foreach (var seriItem in item.SerialList)
                        {
                            seriItem.No = indexSeri++;
                            if (seriItem.StartDate == DEFAULT_DATE_TIME)
                            {
                                seriItem.StartDate = null;
                            }
                            if (seriItem.FinishDate == DEFAULT_DATE_TIME)
                            {
                                seriItem.FinishDate = null;
                            }

                            if (seriItem.Terms == 0)
                            {
                                seriItem.Terms = null;
                            }
                        }
                    }
                }

                //Count File
                this.FileCount = attachedService.CountFile(this.DataID, (int)FType.Purchase);

                //Set OldVersionUpdateDate
                var salesH = sales_HService.GetBySalesNo(header.SalesNo);
                //------------ Edited by ISV-Giam 2014/12/23 -------------
                if (salesH != null)
                {
                    //--------------------------------------------------------
                    this.OldVersionUpdateDate = salesH.VersionUpdateDate;
                }

                //refresh source
                this.RefreshPurchaseDetails(details);

                //----------------- Edited by ISV-Giam 2014/12/15 -----------------
                var crcyId = int.Parse(this.cmbCurrency.SelectedValue);
                var crcySelected = this._currencyList.Where(c => ((M_Currency_H)c.DataboundItem).ID == crcyId).SingleOrDefault().DataboundItem as M_Currency_H;
                //-----------------------------------------------------------------

                //set decimal
                this.SetDecimalDigit(crcySelected, this.txtSumTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, this.txtSumVat, Constant.MAX_SUM_VAT_DECIMAL, Constant.MAX_SUM_VAT_NOT_DECIMAL);
                this.SetDecimalDigit(crcySelected, this.txtGrandTotal, Constant.MAX_SUM_TOTAL_DECIMAL, Constant.MAX_SUM_TOTAL_NOT_DECIMAL);
            }
        }

        /// <summary>
        /// Set decimal digit control
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="numberControl">Number Control</param>
        private void SetDecimalDigit(M_Currency_H crcyItem, INumberTextBox txtNumberInput, decimal maxDecimal, decimal maxNotDecimal)
        {
            if (crcyItem != null)
            {
                if (crcyItem.DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    txtNumberInput.DecimalDigit = 2;
                    txtNumberInput.MaximumValue = maxDecimal;
                }
                else
                {
                    txtNumberInput.DecimalDigit = 0;
                    txtNumberInput.MaximumValue = maxNotDecimal;
                }
            }
        }

        /// <summary>
        /// Set enable control by vat type
        /// </summary>
        /// <param name="dropDownListControl">DropDownList Control</param>
        /// <param name="vatControl">Vat Control</param>
        /// <param name="vatRatioControl">Vat Ratio Control</param>
        private void SetVATControl(DropDownList cmbVatType, INumberTextBox txtVat, INumberTextBox txtVatRatio)
        {
            if (int.Parse(cmbVatType.SelectedItem.Value) == (int)VATFlg.Exclude)
            {
                txtVat.SetReadOnly(false);
                txtVatRatio.SetReadOnly(false);

                txtVat.Value = null;
                txtVatRatio.Value = decimal.Parse(this.DefaultVAT);
            }
            else
            {
                txtVat.SetReadOnly(true);
                txtVatRatio.SetReadOnly(true);

                txtVat.Value = null;
                txtVatRatio.Value = null;
            }
        }

        /// <summary>
        /// Get row of Purchase Detail
        /// </summary>
        /// <param name="repeaterItem"></param>
        /// <returns></returns>
        private PurchaseDetailInfo GetRowPurchaseDetail(RepeaterItem repeaterItem)
        {
            //------------- ISV-Giam 2015/01/12 --------------
            HiddenField hidInternalID = (HiddenField)repeaterItem.FindControl("hidInternalID");
            var rowInternalID = int.Parse(hidInternalID.Value);
            //------------------------------------------------

            //------------- ISV-Giam 2015/07/10 --------------
            HiddenField hidNo = (HiddenField)repeaterItem.FindControl("hidNo");
            var rowNo = int.Parse(hidNo.Value);
            //------------------------------------------------

            HiddenField hidSalesCostID = (HiddenField)repeaterItem.FindControl("hidSalesCostID");
            var rowSalesCostID = int.Parse(hidSalesCostID.Value);

            PurchaseDetailInfo detail = new PurchaseDetailInfo();
            HtmlInputCheckBox chkDetailDel = (HtmlInputCheckBox)repeaterItem.FindControl("chkDetailDel");
            var methodVAT = this.cmbMethodVat.SelectedValue;
            if (this._actionMode == ActionMode.MethodChanged)
            {
                methodVAT = ((T_Purchase_H)this.ViewState["HEADER"]).MethodVat.ToString();
            }

            //------------- ISV-Giam 2015/07/09 --------------
            detail.SerialList = new List<PurchaseSerialInfo>();
            detail.SerialEmptyFlg = true;
            //------------------------------------------------

            detail.No = rowNo;// this._indexDetail++;
            //------------- ISV-Giam 2015/01/12 --------------
            detail.InternalID = rowInternalID;
            //------------------------------------------------
            detail.SalesCostID = rowSalesCostID;
            detail.DetailDeleted = chkDetailDel.Checked;

            //ProductID
            HiddenField hidProductID = (HiddenField)repeaterItem.FindControl("hidProductID");
            detail.ProductID = Convert.ToInt32(hidProductID.Value);

            //ProductCD
            ICodeTextBox txtProductCD = (ICodeTextBox)repeaterItem.FindControl("txtProductCD");
            //---------------------- Edited 2014/12/10-------------------------
            if (this.ProductCdUsed)
            {
                detail.ProductCD = txtProductCD.Value;
            }
            else
            {
                detail.ProductCD = txtProductCD.Value != string.Empty ? txtProductCD.Value : M_Product.PRODUCT_CODE_SUPPORT;
            }
            //-----------------------------------------------

            //ProductName
            ITextBox txtProductName = (ITextBox)repeaterItem.FindControl("txtProductName");
            detail.ProductName = txtProductName.Value;

            //Description
            ITextBox txtDescription = (ITextBox)repeaterItem.FindControl("txtDescription");
            detail.Description = txtDescription.Value;

            //Unit
            if (this.Mode == Utilities.Mode.Check)
            {
                HiddenField hdnUnitID = (HiddenField)repeaterItem.FindControl("hdnUnitID");
                var rowUnitID = int.Parse(hdnUnitID.Value);
                detail.UnitID = Convert.ToInt32(rowUnitID.ToString());
            }
            else
            {
                DropDownList cmbUnit = (DropDownList)repeaterItem.FindControl("cmbUnit");
                detail.UnitID = Convert.ToInt32(cmbUnit.SelectedValue);
            }

            //Price
            INumberTextBox txtPrice = (INumberTextBox)repeaterItem.FindControl("txtPrice");
            detail.UnitPrice = txtPrice.Value;

            //Quantity
            INumberTextBox txtQuantity = (INumberTextBox)repeaterItem.FindControl("txtQuantity");
            detail.Quantity = txtQuantity.Value;

            //Total
            INumberTextBox txtTotal = (INumberTextBox)repeaterItem.FindControl("txtTotal");
            detail.Total = txtTotal.Value;

            //Remark
            ITextBox txtRemark = (ITextBox)repeaterItem.FindControl("txtRemark");
            detail.Remark = txtRemark.Value;

            if (methodVAT == M_Config_D.METHOD_VAT_EACH)
            {
                //Vat
                INumberTextBox txtVat = (INumberTextBox)repeaterItem.FindControl("txtVat");
                detail.Vat = txtVat.Value;

                //----------- ISV-Giam 2015/01/29 -----------
                if (this.Mode == Utilities.Mode.Check)
                {
                    HiddenField hdnVatType = (HiddenField)repeaterItem.FindControl("hdnVatType");
                    detail.VatType = Convert.ToInt16(hdnVatType.Value);
                }
                else
                {
                    //VatType
                    DropDownList cmbVatType = (DropDownList)repeaterItem.FindControl("cmbVatType");
                    if (!string.IsNullOrEmpty(cmbVatType.SelectedValue))
                    {
                        detail.VatType = Convert.ToInt16(cmbVatType.SelectedValue);
                    }
                }
                //-------------------------------------------

                //VatRatio
                INumberTextBox txtVatRatio = (INumberTextBox)repeaterItem.FindControl("txtVatRatio");
                detail.VatRatio = txtVatRatio.Value;
            }

            //Deliver Quantity
            INumberTextBox txtDeliQuantity = (INumberTextBox)repeaterItem.FindControl("txtDeliQuantity");
            detail.DeliverQuantity = txtDeliQuantity.Value;

            //DeliverDate
            IDateTextBox txtDeliverDate = (IDateTextBox)repeaterItem.FindControl("txtDeliverDate");
            if (txtDeliverDate.Value.HasValue)
            {
                detail.DeliverDate = txtDeliverDate.Value.Value;
            }
            else
            {
                detail.DeliverDate = null;
            }

            //rptSerial
            if (this.DefaultSerialHidden == (int)SerialHidden.Show)
            {
                Repeater serial = (Repeater)repeaterItem.FindControl("rptSerial");
                var serialNo = 1;
                foreach (RepeaterItem itemSerial in serial.Items)
                {
                    //Serial
                    ITextBox txtSerial = (ITextBox)itemSerial.FindControl("txtSerial");

                    //Terms
                    INumberTextBox txtTerms = (INumberTextBox)itemSerial.FindControl("txtTerms");

                    //UnitSerial
                    DropDownList cmbUnitSerial = (DropDownList)itemSerial.FindControl("cmbUnitSerial");
                    HiddenField hdUnitSerial = (HiddenField)itemSerial.FindControl("hdUnitSerial");
                    
                    //cmbContractType
                    DropDownList cmbContractType = (DropDownList)itemSerial.FindControl("cmbContractType");
                    HiddenField hdContractType = (HiddenField)itemSerial.FindControl("hdContractType");
                    if (this.Mode == Mode.Check)
                    {
                        cmbUnitSerial.SelectedValue = hdUnitSerial.Value;
                        cmbContractType.SelectedValue = hdContractType.Value;
                    }

                    //SerialFinishDate
                    IDateTextBox txtSerialStartDate = (IDateTextBox)itemSerial.FindControl("txtSerialStartDate");
                    IDateTextBox txtSerialFinishDate = (IDateTextBox)itemSerial.FindControl("txtSerialFinishDate");

                    PurchaseSerialInfo serialInfo = new PurchaseSerialInfo();
                    serialInfo.No = serialNo++;
                    serialInfo.DetailNo = detail.No;
                    serialInfo.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                    serialInfo.SerialNo = txtSerial.Value;
                    serialInfo.Terms = txtTerms.Value;
                    serialInfo.ContractType = short.Parse(cmbContractType.SelectedItem.Value);
                    serialInfo.TermUnit = Convert.ToInt32(cmbUnitSerial.SelectedItem.Value);
                    serialInfo.StartDate = txtSerialStartDate.Value;
                    serialInfo.FinishDate = txtSerialFinishDate.Value;
                    
                    detail.SerialEmptyFlg = detail.SerialEmptyFlg && serialInfo.IsEmpty(short.Parse(this._defaultContractType));
                    detail.SerialList.Add(serialInfo);
                }
            }
            else
            {
                using (DB db = new DB())
                {
                    TPurchaseSerialService serialSer = new TPurchaseSerialService(db);
                    var lstSerialDB = serialSer.GetListByKey(int.Parse(rowInternalID.ToString()));
                    if (lstSerialDB.Count != 0)
                    {
                        foreach (var item in lstSerialDB)
                        {
                            PurchaseSerialInfo serialInfo = new PurchaseSerialInfo();
                            serialInfo.No = item.No;
                            serialInfo.DetailNo = detail.No;
                            serialInfo.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;
                            serialInfo.SerialNo = item.SerialNo;
                            serialInfo.Terms = item.Terms;
                            serialInfo.TermUnit = item.TermUnit;
                            serialInfo.ContractType = item.ContractType;
                            serialInfo.StartDate = item.StartDate;
                            serialInfo.FinishDate = item.FinishDate;
                            detail.SerialList.Add(serialInfo);
                        }
                    }
                }
            }

            return detail;
        }

        /// <summary>
        /// Insert data into database
        /// </summary>
        private bool InsertData()
        {
            //Get insert data
            var header = new T_Purchase_H();
            this.GetHeader(header);
            header.DeleteFlag = 0;
            header.IssuedFlag = 0;
            header.IssuedDate = DEFAULT_DATE_TIME;
            header.IssuedUID = 0;

            //IList<T_Purchase_D> detailPurList = null;
            //this.CreateDetailPurchase(ref detailPurList);

            //Get data detail for insert
            IList<PurchaseDetailInfo> lstDetail = this.GetDetailPurchaseData(includeEmpty: false);

            try
            {
                //Get PurchaseNo
                using (DB db = new DB())
                {
                    header.PurchaseNo = (new TNoService(db)).CreateNo(T_No.PurchaseNo);
                }                

                //Get QuoteNo
                header.QuoteNo = string.Empty;

                //Get SalesNo
                header.SalesNo = string.Empty;

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Purchase_HService purchaseHSer = new Purchase_HService(db);
                    Purchase_CService purchaseCSer = new Purchase_CService(db);
                    Purchase_DService purchaseDSer = new Purchase_DService(db);
                    TPurchaseSerialService serialSer = new TPurchaseSerialService(db);

                    //Insert Header
                    var purchaseId = purchaseHSer.Insert(header);

                    if (purchaseId > 0)
                    {
                        //Insert Purchase Condition
                        this.InsertPurchaseCondition(purchaseCSer, purchaseId);

                        foreach (var item in lstDetail)
                        {
                            T_Purchase_D detail = new T_Purchase_D();
                            detail.HID = purchaseId;
                            detail.No = item.No;
                            detail.SalesCostID = 0;
                            detail.ProductID = item.ProductID;
                            detail.ProductCD = this.ProductCdUsed ? item.ProductCD : M_Product.PRODUCT_CODE_SUPPORT;
                            detail.ProductName = item.ProductName;
                            detail.VatType = item.VatType;
                            detail.VatRatio = item.VatRatio.GetValueOrDefault();
                            detail.Vat = item.Vat.GetValueOrDefault();
                            detail.Description = item.Description;
                            detail.UnitPrice = item.UnitPrice.GetValueOrDefault();
                            detail.Quantity = item.Quantity.GetValueOrDefault();
                            detail.UnitID = item.UnitID;
                            detail.Total = item.Total.GetValueOrDefault();
                            detail.Remark = item.Remark;
                            detail.DeliverDate = item.DeliverDate.HasValue ? item.DeliverDate.Value : DEFAULT_DATE_TIME;
                            detail.DeliverQuantity = 0;
                            //Insert Detail - get Detail ID must be inserted
                            int detailID = purchaseDSer.Insert(detail);

                            //Insert List Serial
                            foreach (var seriItem in item.SerialList)
                            {
                                if (!seriItem.IsEmpty(short.Parse(this._defaultContractType)))
                                {
                                    T_Purchase_Serial seri = new T_Purchase_Serial();
                                    seri.PurchaseDID = detailID;
                                    seri.No = seriItem.No;
                                    seri.SerialNo = seriItem.SerialNo;
                                    seri.Terms = Convert.ToInt32(seriItem.Terms.GetValueOrDefault());
                                    seri.ContractType = seriItem.ContractType;
                                    seri.TermUnit = seriItem.TermUnit.GetValueOrDefault();
                                    seri.StartDate = seriItem.StartDate == null ? DEFAULT_DATE_TIME : seriItem.StartDate.Value;
                                    seri.FinishDate = seriItem.FinishDate == null ? DEFAULT_DATE_TIME : seriItem.FinishDate.Value;
                                    serialSer.Insert(seri);
                                }
                            }
                        }

                        this.DataID = purchaseId;
                        db.Commit();
                        return true;
                    }
                }
            }
            catch (OverflowException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(T_No.PurchaseNo))
                {
                    this.SetMessage(this.txtPurchaseNo.ClientID, M_Message.MSG_SIZE_MAX_NO, "Purchase No");
                }
                return false;
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_H_UN))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_H_FK_CURRENCY))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_H_FK_VENDOR))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_D_FK_UNIT))
                //{
                //    return false;
                //}

                ////if (ex.Message.Contains(Models.Constant.PURCHASE_D_FK_SALESCOST))
                ////{
                ////    return false;
                ////}

                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_D_FK_PRODUCT))
                //{
                //    return false;
                //}

                //if (ex.Message.Contains(Models.Constant.T_PURCHASE_D_FK_UNIT))
                //{
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }

            return false;
        }

        /// <summary>
        /// Update Data For Mode Edit & Check
        /// </summary>
        /// <returns>Success:true, Fail:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 1;

                //Get new detail Purchase
                IList<T_Purchase_D> detailPurUIList = null;
                Hashtable hashSerial = new Hashtable();
                this.CreateDetailPurchase(ref detailPurUIList, ref hashSerial);

                //Get new detail Payment
                IList<T_Payment> detailPayUIList = null;
                this.CreateDetailPayment(ref detailPayUIList);

                //Set hdnIsFullCheck
                this.hdnIsNotFullCheck.Value = detailPurUIList.Any(x => x.Quantity.Value != x.DeliverQuantity.Value).ToString();

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Purchase_HService hService = new Purchase_HService(db);
                    Purchase_DService dService = new Purchase_DService(db);
                    Purchase_CService condService = new Purchase_CService(db);
                    PaymentService payService = new PaymentService(db);
                    Sales_HService salesService = new Sales_HService(db);

                    var header = hService.GetByPK(this.DataID);

                    if (header != null)
                    {
                        //Get Update data
                        this.GetHeader(header);
                        header.UpdateDate = this.OldUpdateDate;

                        if (header.Status == DataStatus.Changed || this.IsDetailChange(db) || this.IsSerialChange(db, detailPurUIList, hashSerial))
                        {
                            //Clear Issue
                            header.IssuedFlag = 0;
                            header.IssuedUID = 0;
                            header.IssuedDate = DEFAULT_DATE_TIME;

                            //Update Version
                            T_Sales_H salesH = salesService.GetBySalesNo(header.SalesNo);

                            //Have SalesNo
                            if (salesH != null)
                            {
                                salesH.VersionUpdateUID = LoginInfo.User.ID;
                                salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                                ret = salesService.UpdateVersion(salesH);
                            }

                            if (ret == 1)
                            {
                                //Update header
                                ret = hService.Update(header);
                                if (ret == 1)
                                {
                                    //Update Purchase Condition
                                    this.InsertPurchaseCondition(condService, header.ID);

                                    //----------- ISV-Giam 2015/01/12 ------------
                                    //Update Purchase detail
                                    this.UpdatePurchaseDetail(db, detailPurUIList, hashSerial);
                                    //--------------------------------------------

                                    //Update Payment detail
                                    if (this.Mode == Utilities.Mode.Check)
                                    {
                                        payService.Delete(header.ID);
                                        foreach (var detail in detailPayUIList)
                                        {
                                            if (detail.PaymentDate == null && detail.Amount == null
                                                && detail.PaymentMethod == 255)
                                            {
                                                continue;
                                            }
                                            else
                                            {
                                                detail.PurchaseID = header.ID;
                                                ret = payService.Insert(detail);
                                            }
                                        }
                                    }

                                    //Update Finish Flag
                                    if (salesH != null)
                                    {
                                        if (salesService.UpdateFinishFlag(salesH) <= 0)
                                        {
                                            //data has changed
                                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                            return false;
                                        }
                                    }

                                    //Commit
                                    if (ret == 1)
                                    {
                                        db.Commit();
                                        return true;
                                    }
                                }
                            }
                        }
                    }

                    //Check result update
                    if (ret == 0)
                    {
                        //Data changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
        }

        /// <summary>
        /// Update Purchase Detail
        /// </summary>
        /// <param name="db"></param>
        /// <param name="listDetail"></param>
        private void UpdatePurchaseDetail(DB db, IList<T_Purchase_D> listDetail, Hashtable hashSerial)
        {
            //Get insert list
            List<T_Purchase_D> insDataList = new List<T_Purchase_D>();
            for (int i = listDetail.Count - 1; i >= 0; i--)
            {
                var item = listDetail[i];
                if (item.InternalID == -1)
                {
                    insDataList.Add(item);
                    listDetail.RemoveAt(i);
                }
            }

            //get data in Database
            Purchase_DService purchase_DService = new Purchase_DService(db);
            TPurchaseSerialService serialService = new TPurchaseSerialService(db);
            var dbDataList = purchase_DService.GetByPurchaseID(this.DataID);
            var no = dbDataList.Count + listDetail.Count;

            //delete DB when data not exist on screen
            Hashtable updDataHtb = new Hashtable();
            foreach (var item in listDetail)
            {
                updDataHtb.Add(item.InternalID, item.HID);
            }

            for (int i = dbDataList.Count - 1; i >= 0; i--)
            {
                var item = dbDataList[i];
                if (!updDataHtb.ContainsKey(item.InternalID))
                {
                    purchase_DService.DeleteByInternalID(item.InternalID);
                    dbDataList.RemoveAt(i);
                }

                //Delete serial
                serialService.DeleteByID(item.InternalID);
            }

            //update data
            //update no in DB to greater number 
            foreach (var item in dbDataList)
            {
                purchase_DService.UpdateNoByInternalID(item.InternalID, no);
                no += 1;
            }

            //Update data
            foreach (var item in listDetail)
            {
                item.HID = this.DataID;
                purchase_DService.Update(item);

                //Serial List
                List<T_Purchase_Serial> serialLst = (List<T_Purchase_Serial>)hashSerial[item.InternalID];
                if (serialLst != null && serialLst.Count > 0)
                {
                    serialService.DeleteByID(item.InternalID);
                    foreach (var seItem in serialLst)
                    {
                        seItem.PurchaseDID = item.InternalID;
                        serialService.Insert(seItem);
                    }
                }
                else
                {
                    serialService.DeleteByID(item.InternalID);
                }
            }

            //insert data
            foreach (var item in insDataList)
            {
                item.HID = this.DataID;
                int itemId = purchase_DService.Insert(item);

                //Serial List
                List<T_Purchase_Serial> serialLst = (List<T_Purchase_Serial>)hashSerial[item.InternalID];
                if (serialLst != null && serialLst.Count > 0)
                {
                    serialService.DeleteByID(item.InternalID);
                    foreach (var seItem in serialLst)
                    {
                        //seItem.PurchaseDID = item.InternalID;
                        seItem.PurchaseDID = itemId;
                        serialService.Insert(seItem);
                    }
                }
            }
        }


        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Fail:false</returns>
        private bool DeleteData()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Sales_HService sales_HService = new Sales_HService(db);
                    Purchase_HService hService = new Purchase_HService(db);
                    //Get by PurchaseID
                    var header = hService.GetByPK(this.DataID);

                    //Get Sales header
                    T_Sales_H salesH = sales_HService.GetBySalesNo(header.SalesNo);
                    if (salesH != null)
                    {
                        salesH.VersionUpdateUID = LoginInfo.User.ID;
                        salesH.VersionUpdateDate = this.OldVersionUpdateDate;
                        //Update Version
                        if (sales_HService.UpdateVersion(salesH) <= 0)
                        {
                            //Data changed
                            this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);

                            //Show data
                            this.ShowPurchaseInfo(this.DataID);
                            this.ShowDetailPaymentData(this.DataID);

                            return false;
                        }
                    }

                    //Get Update data
                    this.GetHeader(header);
                    header.UpdateDate = this.OldUpdateDate;

                    //Update delete flag
                    if (hService.UpdateForDelete(header) > 0)
                    {
                        //Update Finish Flag
                        if (salesH != null)
                        {
                            if (sales_HService.UpdateFinishFlag(salesH) <= 0)
                            {
                                //Data changed
                                this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                                //Show data
                                this.ShowPurchaseInfo(this.DataID);
                                this.ShowDetailPaymentData(this.DataID);
                                return false;
                            }
                        }
                        db.Commit();
                        return true;
                    }
                    else
                    {
                        //Data changed
                        this.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);

                        //Show data
                        this.ShowPurchaseInfo(this.DataID);
                        this.ShowDetailPaymentData(this.DataID);

                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }
        }

        /// <summary>
        /// Insert Purchase Condition
        /// </summary>
        private void InsertPurchaseCondition(Purchase_CService service, int hid)
        {
            service.Delete(hid);
            var con = new T_Purchase_C
            {
                HID = hid,
                Conditions = this.txtConditions.Value
            };
            service.Insert(con);
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                VendorService venSrv = new VendorService(db);
                UserService userSrv = new UserService(db);
                ProductService prodSrv = new ProductService(db);
                Purchase_DService pur_DStv = new Purchase_DService(db);

                #region Header

                //VendorCD
                if (this.txtVendorCD.IsEmpty)
                {
                    this.SetMessage("txtVendorCD", M_Message.MSG_REQUIRE, "Vendor Code");
                }
                else
                {
                    var vendorCd = this.txtVendorCD.Value;

                    //--------- Edited 2014/12/08 by ISV Giam ----------
                    if (vendorCd == Models.M_Vendor.VENDOR_CODE_SUPPORT)
                    {
                        if (this.txtVendorName.IsEmpty)
                        {
                            this.SetMessage("txtVendorName", M_Message.MSG_REQUIRE, "Vendor Name");
                        }
                    }
                    //--------------------------------------------------
                    else
                    {
                        vendorCd = OMS.Utilities.EditDataUtil.ToFixCodeDB(vendorCd, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                        var vendor = venSrv.GetByCD(vendorCd);
                        if (vendor == null)
                        {
                            this.SetMessage("txtVendorCD", M_Message.MSG_NOT_EXIST_CODE, "Vendor Code");
                        }
                        else
                        {
                            if (vendor.StatusFlag != 0)
                            {
                                this.SetMessage("txtVendorCD", M_Message.MSG_CODE_DISABLE, "Vendor Code");
                            }
                        }
                    }
                }

                //PurchaseDate
                if (this.txtPurchaseDate.IsEmpty)
                {
                    this.SetMessage("txtPurchaseDate", M_Message.MSG_REQUIRE, "Purchase Date");
                }

                //Expiry Date
                //if (this.txtExpiryDate.IsEmpty)
                //{
                //    this.SetMessage("txtExpiryDate", M_Message.MSG_REQUIRE, "Sched. Delivery");
                //}

                M_User user = null;
                //PreparedCD
                if (this.txtPreparedCD.IsEmpty)
                {
                    this.SetMessage("txtPreparedCD", M_Message.MSG_REQUIRE, "Prepared Code");
                }
                else
                {
                    var preparedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(preparedCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtPreparedCD", M_Message.MSG_NOT_EXIST_CODE, "Prepared Code");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtPreparedCD", M_Message.MSG_CODE_DISABLE, "Prepared Code");
                            this.txtPreparedName.Value = string.Empty;
                        }
                    }
                }

                //ApprovedCD
                if (this.txtApprovedCD.IsEmpty)
                {
                    this.SetMessage("txtApprovedCD", M_Message.MSG_REQUIRE, "Approved Code");
                }
                else
                {
                    var approvedCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
                    user = userSrv.GetByUserCD(approvedCD);
                    if (user == null || user.ID == Constant.DEFAULT_ID)
                    {
                        this.SetMessage("txtApprovedCD", M_Message.MSG_NOT_EXIST_CODE, "Approved Code");
                    }
                    else
                    {
                        if (user.StatusFlag != 0)
                        {
                            this.SetMessage("txtApprovedCD", M_Message.MSG_CODE_DISABLE, "Approved Code");
                            this.txtApprovedName.Value = string.Empty;
                        }
                    }
                }

                //Subject
                if (this.txtSubject.IsEmpty)
                {
                    this.SetMessage("txtSubject", M_Message.MSG_REQUIRE, "Subject");
                }
                #endregion

                var isDecimal = this.IsDecimal(int.Parse(this.cmbCurrency.SelectedValue));
                string numberFormat = string.Format("N{0}", isDecimal ? 2 : 0);
                var detailPurchase = this.GetDetailPurchaseData();
                var methodVAT = this.cmbMethodVat.SelectedValue;

                if (this.isDetailEmpty)
                {
                    if (this.ProductCdUsed)
                    {
                        this.SetMessage(string.Format("txtProductCD_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Product Code", 1);
                    }
                    else
                    {
                        this.SetMessage(string.Format("txtProductName_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Product Name", 1);
                    }
                    this.SetMessage(string.Format("txtPrice_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Unit Price", 1);
                    this.SetMessage(string.Format("txtQuantity_{0}", 0), M_Message.MSG_REQUIRE_GRID, "Q'ty", 1);
                }
                else
                {
                    if (detailPurchase.Count > 0)
                    {
                        var maxValue = 0m;
                        var minValue = 0m;

                        #region Detail
                        for (int i = 0; i < detailPurchase.Count; i++)
                        {
                            PurchaseDetailInfo detail = detailPurchase[i];

                            //Check is empty row
                            if (detail.IsEmptyRow(decimal.Parse(this.DefaultVAT)))
                                continue;

                            //Check product
                            if (string.IsNullOrEmpty(detail.ProductCD))
                            {
                                this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Code", detail.No);
                            }
                            else if (detail.ProductCD != M_Product.PRODUCT_CODE_SUPPORT)
                            {
                                M_Product product = prodSrv.GetByCD(detail.ProductCD);
                                if (product == null)
                                {
                                    this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_NOT_EXIST_CODE_GRID, "Product Code", detail.No);
                                }
                                else if (product.StatusFlag != 0)
                                {
                                    this.SetMessage(string.Format("txtProductCD_{0}", i), M_Message.MSG_CODE_DISABLE_GRID, "Product Code", detail.No);
                                }
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(detail.ProductName))
                                {
                                    this.SetMessage(string.Format("txtProductName_{0}", i), M_Message.MSG_REQUIRE_GRID, "Product Name", detail.No);
                                }
                            }

                            //Unit Price
                            if (!detail.UnitPrice.HasValue)
                            {
                                this.SetMessage(string.Format("txtPrice_{0}", i), M_Message.MSG_REQUIRE_GRID, "Unit Price", detail.No);
                            }
                            else
                            {
                                maxValue = isDecimal ? Constant.MAX_UNIT_PRICE_DECIMAL : Constant.MAX_UNIT_PRICE_NOT_DECIMAL;
                                if (detail.UnitPrice > maxValue)
                                {
                                    this.SetMessage(string.Format("txtPrice_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Unit Price", maxValue.ToString(numberFormat), detail.No);
                                }
                            }

                            //Quantity
                            if (!detail.Quantity.HasValue)
                            {
                                this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Q'ty", detail.No);
                            }
                            else
                            {
                                maxValue = this.QuantityDecimal == 2 ? Constant.MAX_QUANTITY_DECIMAL : Constant.MAX_QUANTITY_NOT_DECIMAL;

                                //Quantity == 0
                                if (detail.Quantity == 0)
                                {
                                    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", 0, detail.No);
                                }

                                //Quantity > maxValue
                                if (detail.Quantity > maxValue)
                                {
                                    this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", maxValue.ToString(string.Format("N{0}", this.QuantityDecimal)), detail.No);
                                }

                                //Quantity < deliver quantity
                                if (detail.DeliverQuantity != null)
                                {
                                    if (detail.Quantity < detail.DeliverQuantity)
                                    {
                                        this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Q'ty", "Deliver Q'ty", detail.No);
                                    }
                                }

                                //Quantity > remain quantity
                                if (detail.SalesCostID != 0)// # default SalesCostID
                                {
                                    decimal? remainQuantity = pur_DStv.GetRemainQtyBySalesCostID(detail.SalesCostID, this.DataID);
                                    if (remainQuantity.HasValue)
                                    {
                                        if (detail.Quantity > remainQuantity)
                                        {
                                            //-------------------- Edited by ISV-Giam 2014/12/15 -----------------------
                                            //this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", "Accept Q'ty", detail.No);
                                            this.SetMessage(string.Format("txtQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Q'ty", remainQuantity.Value.ToString(string.Format("N{0}", this.QuantityDecimal)), detail.No);
                                            //--------------------------------------------------------------------------
                                        }
                                    }
                                }
                            }

                            //Total
                            if (detail.Total.HasValue)
                            {
                                maxValue = isDecimal ? Constant.MAX_SUB_TOTAL_DECIMAL : Constant.MAX_SUB_TOTAL_NOT_DECIMAL;
                                minValue = isDecimal ? Constant.MIN_SUB_TOTAL_DECIMAL : Constant.MIN_SUB_TOTAL_NOT_DECIMAL;

                                if (detail.Total > maxValue)
                                {
                                    this.SetMessage(string.Format("txtTotal_{0}", i), M_Message.MSG_LESS_THAN_GRID, "Total", maxValue.ToString(numberFormat), detail.No);
                                }
                                else if (detail.Total < minValue)
                                {
                                    this.SetMessage(string.Format("txtTotal_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Total", minValue.ToString(numberFormat), detail.No);
                                }
                            }

                            // Vat & VatRatio
                            if (methodVAT == M_Config_D.METHOD_VAT_EACH && detail.VatType == (int)VATFlg.Exclude)
                            {
                                //Vat
                                if (detail.Vat.HasValue)
                                {
                                    maxValue = (isDecimal) ? Constant.MAX_SUB_VAT_DECIMAL : Constant.MAX_SUB_VAT_NOT_DECIMAL;
                                    minValue = (isDecimal) ? Constant.MIN_SUB_VAT_DECIMAL : Constant.MIN_SUB_VAT_NOT_DECIMAL;

                                    if (detail.Vat > maxValue)
                                    {
                                        this.SetMessage(string.Format("txtVat_{0}", i), M_Message.MSG_LESS_THAN_GRID, "VAT", maxValue.ToString(numberFormat), detail.No);
                                    }
                                    else if (detail.Vat < minValue)
                                    {
                                        this.SetMessage(string.Format("txtVat_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "VAT", minValue.ToString(numberFormat), detail.No);
                                    }
                                }

                                //VatRatio
                                if (!detail.VatRatio.HasValue)
                                {
                                    this.SetMessage(string.Format("txtVatRatio_{0}", i), M_Message.MSG_REQUIRE_GRID, "VatRatio", detail.No);
                                }
                                else
                                {
                                    if (detail.VatRatio > Constant.MAX_VATRATIO)
                                    {
                                        this.SetMessage(string.Format("txtVatRatio_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "VatRatio", Constant.MAX_VATRATIO, detail.No);
                                    }
                                }
                            }

                            #region SubDetails (Serial)

                            if (this.DefaultSerialHidden == (int)SerialHidden.Show)
                            {
                                bool hasErrSerial = false;
                                for (int j = 0; j < detail.SerialList.Count; j++)
                                {
                                    PurchaseSerialInfo subDetail = detail.SerialList[j];
                                    if (subDetail == null)
                                    {
                                        continue;
                                    }

                                    subDetail.Collapsed = this.DefaultSerialView == OMS.Models.M_Config_D.DEFAULT_VIEW_SHOW ? "in" : string.Empty;

                                    if (subDetail.Terms.HasValue && subDetail.Terms.Value == 0)
                                    {
                                        this.SetMessage(string.Format("{0}_txtTerms_{1}", i, j), M_Message.MSG_GREATER_THAN_GRID, "Warranty Unit", ZERO_STRING, string.Format("{0}/{1}", detail.No, j + 1));
                                        hasErrSerial = true;
                                    }

                                    if (subDetail.Terms.HasValue && subDetail.TermUnit == 0)
                                    {
                                        this.SetMessage(string.Format("{0}_cmbUnitSerial_{1}", i, j), M_Message.MSG_REQUIRE_SELECT_GRID, "Warranty Type", string.Format("{0}/{1}", detail.No, j + 1));
                                        hasErrSerial = true;
                                    }

                                    if (!subDetail.Terms.HasValue && subDetail.TermUnit != 0)
                                    {
                                        this.SetMessage(string.Format("{0}_txtTerms_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Warranty Unit", string.Format("{0}/{1}", detail.No, j + 1));
                                        hasErrSerial = true;
                                    }

                                    if (subDetail.ContractType != short.Parse(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                                    {
                                        //if ((!subDetail.StartDate.HasValue || subDetail.StartDate == DEFAULT_DATE_TIME) ^
                                        //    (!subDetail.FinishDate.HasValue || subDetail.FinishDate == DEFAULT_DATE_TIME))
                                        //{
                                        //    if ((!subDetail.StartDate.HasValue || subDetail.StartDate == DEFAULT_DATE_TIME))
                                        //    {
                                        //        this.SetMessage(string.Format("{0}_txtSerialStartDate_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Start date", string.Format("{0}/{1}", detail.No, j + 1));
                                        //    }
                                        //    if ((!subDetail.FinishDate.HasValue || subDetail.FinishDate == DEFAULT_DATE_TIME))
                                        //    {
                                        //        this.SetMessage(string.Format("{0}_txtSerialFinishDate_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "End date", string.Format("{0}/{1}", detail.No, j + 1));
                                        //    }
                                        //    hasErrSerial = true;

                                        //}

                                        if (subDetail.StartDate.HasValue &&
                                            subDetail.StartDate != DEFAULT_DATE_TIME &&
                                            subDetail.FinishDate.HasValue &&
                                            subDetail.FinishDate != DEFAULT_DATE_TIME)
                                        {
                                            if (subDetail.FinishDate.GetValueOrDefault().CompareTo(subDetail.StartDate.GetValueOrDefault()) < 0)
                                            {
                                                this.SetMessage(string.Format("{0}_txtSerialStartDate_{1}", i, j), M_Message.MSG_LESS_THAN_GRID, "Start date", "End date", string.Format("{0}/{1}", detail.No, j + 1));
                                                hasErrSerial = true;
                                            }
                                        }
                                    }
                                }

                                if (hasErrSerial)
                                {
                                    foreach (var item in detail.SerialList)
                                    {
                                        item.Collapsed = "in";
                                    }
                                }
                            }

                        #endregion SubDetails
                        }
                        #endregion

                        #region Total
                        var sumTotal = this.txtSumTotal.Value.GetValueOrDefault();
                        var sumVAT = this.txtSumVat.Value.GetValueOrDefault();
                        var grandTotal = this.txtGrandTotal.Value.GetValueOrDefault();

                        maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                        minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                        if (sumTotal > maxValue)
                        {
                            this.SetMessage("txtSumTotal", M_Message.MSG_LESS_THAN_EQUAL, "Total", maxValue.ToString(numberFormat));
                        }
                        else if (sumTotal < minValue)
                        {
                            this.SetMessage("txtSumTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Total", minValue.ToString(numberFormat));
                        }

                        maxValue = isDecimal ? Constant.MAX_SUM_VAT_DECIMAL : Constant.MAX_SUM_VAT_NOT_DECIMAL;
                        minValue = isDecimal ? Constant.MIN_SUM_VAT_DECIMAL : Constant.MIN_SUM_VAT_NOT_DECIMAL;
                        if (sumVAT > maxValue)
                        {
                            this.SetMessage("txtSumVat", M_Message.MSG_LESS_THAN_EQUAL, "VAT", maxValue.ToString(numberFormat));
                        }
                        else if (sumVAT < minValue)
                        {
                            this.SetMessage("txtSumVat", M_Message.MSG_GREATER_THAN_EQUAL, "VAT", minValue.ToString(numberFormat));
                        }

                        maxValue = isDecimal ? Constant.MAX_SUM_TOTAL_DECIMAL : Constant.MAX_SUM_TOTAL_NOT_DECIMAL;
                        minValue = isDecimal ? Constant.MIN_SUM_TOTAL_DECIMAL : Constant.MIN_SUM_TOTAL_NOT_DECIMAL;
                        if (grandTotal > maxValue)
                        {
                            this.SetMessage("txtGrandTotal", M_Message.MSG_LESS_THAN_EQUAL, "Grand Total", maxValue.ToString(numberFormat));
                        }
                        else if (grandTotal < minValue)
                        {
                            this.SetMessage("txtGrandTotal", M_Message.MSG_GREATER_THAN_EQUAL, "Grand Total", minValue.ToString(numberFormat));
                        }

                        //Check vat ratio total require
                        if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
                        {
                            var vatType = Convert.ToInt32(this.cmbTotalVatType.SelectedItem.Value);
                            if (vatType == (int)VATFlg.Exclude)
                            {
                                if (!this.txtTotalVatRatio.Value.HasValue)
                                {
                                    base.SetMessage(this.txtTotalVatRatio.ID, M_Message.MSG_REQUIRE, "VatRatio");
                                }
                            }
                        }
                        #endregion
                    }
                }

                //Set data source for Purchase
                this.RefreshPurchaseDetails(detailPurchase);

                // Set data source for Payment
                this.rptPayment.DataSource = this.PaymentDataSource;
                this.rptPayment.DataBind();
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check Mode Check
        /// </summary>
        /// <returns></returns>
        private bool CheckModeCheck()
        {
            T_Purchase_H header;
            using (DB db = new DB())
            {
                Purchase_HService hService = new Purchase_HService(db);
                header = hService.GetByPK(this.DataID);
            }            

            var detailPurchase = this.GetDetailPurchaseData();
            var detailPayment = this.GetDetailPaymentData();

            #region detail Purchase
            //Check on detail Purchase
            if (detailPurchase.Count > 0)
            {
                for (int i = 0; i < detailPurchase.Count; i++)
                {
                    PurchaseDetailInfo detail = detailPurchase[i];

                    if (detail.DeliverQuantity.HasValue)
                    {
                        if (!detail.DeliverDate.HasValue)
                        {
                            base.SetMessage(string.Format("txtDeliverDate_{0}", i), M_Message.MSG_REQUIRE_GRID, "Deli Date", detail.No);
                        }

                        //Check DeliverQuantity = 0
                        if (detail.DeliverQuantity.Value.Equals(0))
                        {
                            base.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_GREATER_THAN_GRID, "Deli Q'ty", 0, detail.No);
                        }
                        //DeliverQuantity > Quantity
                        else if (detail.DeliverQuantity.Value.CompareTo(detail.Quantity.Value) > 0)
                        {
                            base.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Deli Q'ty", detail.Quantity, detail.No);
                        }
                    }

                    if (detail.DeliverDate.HasValue)
                    {
                        //DeliverQuantity
                        if (!detail.DeliverQuantity.HasValue)
                        {
                            base.SetMessage(string.Format("txtDeliQuantity_{0}", i), M_Message.MSG_REQUIRE_GRID, "Deli Q'ty", detail.No);
                        }

                        //DeliverDate < PurchaseDate
                        if (detail.DeliverDate.Value.CompareTo(header.PurchaseDate) < 0)
                        {
                            base.SetMessage(string.Format("txtDeliverDate_{0}", i), M_Message.MSG_GREATER_THAN_EQUAL_GRID, "Deli Date", "Purchase Date", detail.No);
                        }
                    }
                }
            }
            #endregion

            #region detail Paymet
            //Check on detail Payment
            if (detailPayment.Count > 0)
            {
                for (int i = 0; i < detailPayment.Count; i++)
                {
                    int rowIndex = i + 1;
                    var item = detailPayment[i];
                    if (item.PaymentDate == null && item.Amount == null
                        && string.IsNullOrEmpty(item.Remark1) && string.IsNullOrEmpty(item.Remark2)
                        && item.PaymentMethod == 255)
                    {
                        continue;
                    }
                    else
                    {
                        //Payment Date
                        if (item.PaymentDate == null)
                        {
                            base.SetMessage(string.Format("dtPaymentDate_{0}", i), M_Message.MSG_REQUIRE_GRID, "Payment Date", rowIndex);
                        }

                        //PaymentMethod
                        if (item.PaymentMethod == 255)
                        {
                            base.SetMessage(string.Format("cmbPaymentMethod_{0}", i), M_Message.MSG_REQUIRE_SELECT_GRID, "Payment Method", rowIndex);
                        }

                        //Amount
                        if (!item.Amount.HasValue)
                        {
                            base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_REQUIRE_GRID, "Amount", rowIndex);
                        }
                        else
                        {
                            if (item.Amount.Value == 0)
                            {
                                base.SetMessage(string.Format("txtAmount_{0}", i), M_Message.MSG_MUST_BE_DIFFERENT_GRID, "Amount", "0", rowIndex);
                            }
                        }
                    }
                }
            }
            #endregion

            //Refresh resource
            this.RefreshPurchaseDetails(detailPurchase);
            this.RefreshPaymentDetails(detailPayment);

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check currency is decimal
        /// </summary>
        /// <param name="cmbCurrency"></param>
        /// <returns></returns>
        private bool IsDecimal(int currencyId)
        {
            var crcy = this._currencyList.Where(s => ((M_Currency_H)s.DataboundItem).ID == currencyId).SingleOrDefault();
            if (crcy != null)
            {
                if (((M_Currency_H)crcy.DataboundItem).DecimalType == (int)ExchangeRateDecType.Decimal)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Check detail change data
        /// </summary>
        /// <returns></returns>
        private bool IsDetailChange(DB db)
        {
            Purchase_DService dService = new Purchase_DService(db);
            PaymentService payService = new PaymentService(db);
            var detailChanged = false;

            //------- Detail Purchase ----------
            //UI Items
            IList<T_Purchase_D> detailPurUIList = null;
            Hashtable hashSerial1 = new Hashtable();
            this.CreateDetailPurchase(ref detailPurUIList, ref hashSerial1);

            //DB Items
            var detailPurDbList = dService.GetByPurchaseID(this.DataID);
            Hashtable hashSerial2 = new Hashtable();
            this.CreateDetailPurchase(ref detailPurDbList, ref hashSerial2);

            if (detailPurUIList.Count != detailPurDbList.Count)
            {
                detailChanged = true;
            }
            else
            {
                detailChanged = detailPurDbList.Any(s => s.Status == DataStatus.Changed);
            }

            //------- Detail Payment ----------
            if (this.Mode == Utilities.Mode.Check && !detailChanged)
            {
                //UI Items
                IList<T_Payment> detailPayUIList = null;
                this.CreateDetailPayment(ref detailPayUIList);

                //DB Items
                var detailPayDbList = payService.GetListByID(this.DataID);
                this.CreateDetailPayment(ref detailPayDbList);

                if (detailPayUIList.Count != detailPayDbList.Count)
                {
                    detailChanged = true;
                }
                else
                {
                    if (detailPayDbList.Any(x => x.PaymentDate != null))
                    {
                        detailChanged = detailPayDbList.Any(s => s.Status == DataStatus.Changed);
                    }
                }
            }

            //------- Condition -------------
            if (!detailChanged)
            {
                detailChanged = this.txtConditions.Value != this.OldCondition;
            }

            return detailChanged;
        }

        /// <summary>
        /// Check serial change data
        /// </summary>
        /// <returns></returns>
        private bool IsSerialChange(DB db, IList<T_Purchase_D> detailPurList, Hashtable hashSerial)
        {
            bool serialChanged = false;

            TPurchaseSerialService serialService = new TPurchaseSerialService(db);
            IList<T_Purchase_Serial> lstSerialDB = serialService.GetList();

            foreach (var item in detailPurList)
            {
                //Get data list from DB
                var lstSeriDBItem = lstSerialDB.Where(i => i.PurchaseDID == item.InternalID).ToList();

                //Get data list from screen
                List<T_Purchase_Serial> seriLst = (List<T_Purchase_Serial>)hashSerial[item.InternalID];

                if (lstSeriDBItem.Count != seriLst.Count)
                {
                    serialChanged = true;
                    break;
                }
                else
                {
                    for (int i = 0; i < lstSeriDBItem.Count; i++)
                    {
                        if (lstSeriDBItem[i].No != seriLst[i].No
                            || lstSeriDBItem[i].ContractType != seriLst[i].ContractType
                            || lstSeriDBItem[i].Terms != seriLst[i].Terms
                            || lstSeriDBItem[i].TermUnit != seriLst[i].TermUnit
                            || lstSeriDBItem[i].SerialNo != seriLst[i].SerialNo
                            || lstSeriDBItem[i].StartDate != seriLst[i].StartDate
                            || lstSeriDBItem[i].FinishDate != seriLst[i].FinishDate)
                        {
                            serialChanged = true;
                            break;
                        }
                    }
                }
            }

            return serialChanged;
        }

        /// <summary>
        /// Get header
        /// </summary>
        private void GetHeader(T_Purchase_H header)
        {
            //PurchaseDate
            if (this.txtPurchaseDate.Value.HasValue)
            {
                header.PurchaseDate = this.txtPurchaseDate.Value.GetValueOrDefault();
            }
            else
            {
                header.PurchaseDate = DEFAULT_DATE_TIME;
            }

            //ExpiryDate
            if (this.txtExpiryDate.Value.HasValue)
            {
                header.ExpiryDate = this.txtExpiryDate.Value.GetValueOrDefault();
            }
            else
            {
                header.ExpiryDate = DEFAULT_DATE_TIME;
            }

            //ExpiryDate
            if (this.txtPaymentDate.Value.HasValue)
            {
                header.PaymentDate = this.txtPaymentDate.Value.GetValueOrDefault();
            }
            else
            {
                header.PaymentDate = DEFAULT_DATE_TIME;
            }

            //FinishFlag
            if (this.Mode == Utilities.Mode.Update || this.Mode == Utilities.Mode.Check)
            {
                bool isBalanced = this.txtBalance.Value == 0 ? true : false;
                if (!bool.Parse(this.hdnIsNotFullCheck.Value) && isBalanced)
                {
                    header.FinishFlag = 1;
                }
                else
                {
                    header.FinishFlag = 0;
                }
            }
            else
            {
                header.FinishFlag = 0;
            }

            //Confirmed
            header.Confirmed = this.txtConfirmed.Value;
            header.Position = this.txtPosition.Value;

            //Prepared
            header.PreparedCD = EditDataUtil.ToFixCodeDB(this.txtPreparedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.PreparedName = this.txtPreparedName.Value;

            //Approved
            header.ApprovedCD = EditDataUtil.ToFixCodeDB(this.txtApprovedCD.Value, M_User.USER_CODE_MAX_LENGTH);
            header.ApprovedName = this.txtApprovedName.Value;

            //Vendor
            header.VendorCD = EditDataUtil.ToFixCodeDB(this.txtVendorCD.Value, M_Vendor.VENDOR_CODE_MAX_LENGTH);
            header.VendorName = this.txtVendorName.Value;

            //Subject
            header.SubjectName = this.txtSubject.Value;

            //Address
            header.VendorAddress1 = this.txtAdd1.Value;
            header.VendorAddress2 = this.txtAdd2.Value;
            header.VendorAddress3 = this.txtAdd3.Value;

            //Tel-Fax
            header.Tel = this.txtTel.Value;
            header.Fax = this.txtFax.Value;

            //ContactPerson
            header.ContactPerson = this.txtAttn.Value;

            //CurrencyID
            header.CurrencyID = int.Parse(this.cmbCurrency.SelectedItem.Value);

            //MethodVat
            header.MethodVat = short.Parse(this.cmbMethodVat.SelectedItem.Value);

            //Memo
            header.Memo = this.txtMemo.Value;

            //Total-Vat-VatRatio-GrandTotal
            header.Total = this.txtSumTotal.Value.GetValueOrDefault();
            header.Vat = this.txtSumVat.Value.GetValueOrDefault();
            header.VatRatio = this.txtTotalVatRatio.Value.GetValueOrDefault();
            if (this.cmbMethodVat.SelectedValue == M_Config_D.METHOD_VAT_SUM)
            {
                //----------- ISV-Giam 2015/01/29 -----------
                if (this.Mode == Utilities.Mode.Check)
                {
                    T_Purchase_H purchaseH = (T_Purchase_H)this.ViewState["HEADER"];
                    header.VatType = purchaseH.VatType;
                }
                else
                {
                    //VatType
                    if (!string.IsNullOrEmpty(this.cmbTotalVatType.SelectedValue))
                    {
                        header.VatType = short.Parse(this.cmbTotalVatType.SelectedValue);
                    }
                }
                //-------------------------------------------   
            }
            else
            {
                header.VatType = 255;
            }
            header.GrandTotal = this.txtGrandTotal.Value.GetValueOrDefault();

            //CreateUser - Update User
            header.CreateUID = base.LoginInfo.User.ID;
            header.UpdateUID = base.LoginInfo.User.ID;
        }

        /// <summary>
        /// Create Detail Purchase
        /// </summary>
        /// <param name="detailPurList"></param>
        private void CreateDetailPurchase(ref IList<T_Purchase_D> detailPurList, ref Hashtable hashSerial)
        {
            if (detailPurList == null)
            {
                detailPurList = new List<T_Purchase_D>();
            }

            //rptDetail Purchase
            foreach (RepeaterItem repeaterDetailItem in this.rptDetail.Items)
            {
                HiddenField hidNo = (HiddenField)repeaterDetailItem.FindControl("hidNo");
                var rowNo = int.Parse(hidNo.Value);

                HiddenField hidSalesCostID = (HiddenField)repeaterDetailItem.FindControl("hidSalesCostID");
                var rowSalesCostID = int.Parse(hidSalesCostID.Value);

                //------------- ISV-Giam 2015/01/12 --------------
                HiddenField hidInternalID = (HiddenField)repeaterDetailItem.FindControl("hidInternalID");
                var rowInternalID = int.Parse(hidInternalID.Value);
                //------------------------------------------------

                ICodeTextBox txtProductCD = (ICodeTextBox)repeaterDetailItem.FindControl("txtProductCD");
                ITextBox txtProductName = (ITextBox)repeaterDetailItem.FindControl("txtProductName");
                ITextBox txtDescription = (ITextBox)repeaterDetailItem.FindControl("txtDescription");
                INumberTextBox txtPrice = (INumberTextBox)repeaterDetailItem.FindControl("txtPrice");
                INumberTextBox txtQuantity = (INumberTextBox)repeaterDetailItem.FindControl("txtQuantity");
                DropDownList cmbUnit = (DropDownList)repeaterDetailItem.FindControl("cmbUnit");
                INumberTextBox txtTotal = (INumberTextBox)repeaterDetailItem.FindControl("txtTotal");
                ITextBox txtRemark = (ITextBox)repeaterDetailItem.FindControl("txtRemark");
                INumberTextBox txtVat = (INumberTextBox)repeaterDetailItem.FindControl("txtVat");
                DropDownList cmbVatType = (DropDownList)repeaterDetailItem.FindControl("cmbVatType");
                INumberTextBox txtVatRatio = (INumberTextBox)repeaterDetailItem.FindControl("txtVatRatio");

                INumberTextBox txtDeliQuantity = (INumberTextBox)repeaterDetailItem.FindControl("txtDeliQuantity");
                IDateTextBox txtDeliverDate = (IDateTextBox)repeaterDetailItem.FindControl("txtDeliverDate");

                //Check empty row                
                if (string.IsNullOrEmpty(txtProductCD.Value) ||
                txtProductCD.Value.Equals(M_Product.PRODUCT_CODE_SUPPORT) &&
                string.IsNullOrEmpty(txtProductName.Value) &&
                string.IsNullOrEmpty(txtDescription.Value) &&
                string.IsNullOrEmpty(txtRemark.Value) &&
                int.Parse(cmbUnit.SelectedValue) == Constant.DEFAULT_ID &&
                !txtPrice.Value.HasValue &&
                !txtQuantity.Value.HasValue &&
                !txtTotal.Value.HasValue &&
                !txtVat.Value.HasValue &&
                (!txtVatRatio.Value.HasValue || txtVatRatio.Value == decimal.Parse(this.DefaultVAT))
                )
                {
                    continue;
                }

                var detailPurchase = detailPurList.Where(x => x.No.Equals(rowNo)).SingleOrDefault();
                if (detailPurchase == null)
                {
                    detailPurchase = new T_Purchase_D();
                    detailPurList.Add(detailPurchase);
                }

                detailPurchase.SalesCostID = rowSalesCostID;
                //------------- ISV-Giam 2015/01/12 --------------
                detailPurchase.InternalID = rowInternalID;
                //------------------------------------------------
                detailPurchase.ProductCD = txtProductCD.Value;
                detailPurchase.ProductName = txtProductName.Value;

                using (DB db = new DB())
                {
                    ProductService productSer = new ProductService(db);
                    var product = productSer.GetByCD(detailPurchase.ProductCD);
                    if (product != null)
                    {
                        detailPurchase.ProductID = product.ID;
                    }
                    else
                    {
                        detailPurchase.ProductID = 1;
                    }
                }

                detailPurchase.Description = txtDescription.Value;

                if (this.Mode == Utilities.Mode.Check)
                {
                    HiddenField hdnUnitID = (HiddenField)repeaterDetailItem.FindControl("hdnUnitID");
                    var rowUnitID = int.Parse(hdnUnitID.Value);
                    detailPurchase.UnitID = rowUnitID;
                }
                else
                {
                    detailPurchase.UnitID = int.Parse(cmbUnit.SelectedItem.Value);
                }

                detailPurchase.UnitPrice = txtPrice.Value.GetValueOrDefault();
                detailPurchase.Quantity = txtQuantity.Value.GetValueOrDefault();
                detailPurchase.Total = txtTotal.Value.GetValueOrDefault();
                detailPurchase.Remark = txtRemark.Value;
                detailPurchase.Vat = txtVat.Value.GetValueOrDefault();

                //----------- ISV-Giam 2015/01/29 -----------
                if (this.Mode == Utilities.Mode.Check)
                {
                    HiddenField hdnVatType = (HiddenField)repeaterDetailItem.FindControl("hdnVatType");
                    detailPurchase.VatType = Convert.ToInt16(hdnVatType.Value);
                }
                else
                {
                    //VatType
                    if (!string.IsNullOrEmpty(cmbVatType.SelectedValue))
                    {
                        detailPurchase.VatType = Convert.ToInt16(cmbVatType.SelectedValue);
                    }
                }
                //-------------------------------------------

                detailPurchase.VatRatio = txtVatRatio.Value.GetValueOrDefault();
                detailPurchase.DeliverQuantity = txtDeliQuantity.Value.GetValueOrDefault();
                if (txtDeliverDate.Value.HasValue)
                {
                    detailPurchase.DeliverDate = txtDeliverDate.Value.GetValueOrDefault();
                }
                else
                {
                    detailPurchase.DeliverDate = DEFAULT_DATE_TIME;
                }

                //----------- Get item for rptSerial ISV-Giam 2015/07/10-------------
                IList<T_Purchase_Serial> lstSerial = new List<T_Purchase_Serial>();
                Repeater rptSerial = (Repeater)repeaterDetailItem.FindControl("rptSerial");
                int purchSerialNo = 1;
                foreach (RepeaterItem itemSerial in rptSerial.Items)
                {
                    //Serial
                    ITextBox txtSerial = (ITextBox)itemSerial.FindControl("txtSerial");

                    //Terms
                    INumberTextBox txtTerms = (INumberTextBox)itemSerial.FindControl("txtTerms");

                    //UnitSerial
                    DropDownList cmbUnitSerial = (DropDownList)itemSerial.FindControl("cmbUnitSerial");
                    HiddenField hdUnitSerial = (HiddenField)itemSerial.FindControl("hdUnitSerial");

                    //cmbContractType
                    DropDownList cmbContractType = (DropDownList)itemSerial.FindControl("cmbContractType");
                    HiddenField hdContractType = (HiddenField)itemSerial.FindControl("hdContractType");
                    if (this.Mode == Mode.Check)
                    {
                        cmbUnitSerial.SelectedValue = hdUnitSerial.Value;
                        cmbContractType.SelectedValue = hdContractType.Value;
                    }

                    //SerialFinishDate
                    IDateTextBox txtSerialStartDate = (IDateTextBox)itemSerial.FindControl("txtSerialStartDate");
                    IDateTextBox txtSerialFinishDate = (IDateTextBox)itemSerial.FindControl("txtSerialFinishDate");

                    //Check not empty serial record 
                    if (!string.IsNullOrEmpty(txtSerial.Value) ||
                        short.Parse(cmbContractType.SelectedItem.Value) != short.Parse(this._defaultContractType) ||
                        Convert.ToInt32(cmbUnitSerial.SelectedItem.Value) != (int)WarrantyUnit.None ||
                        txtTerms.Value != null ||
                        ((txtSerialStartDate.Value != DateTime.MinValue) && txtSerialStartDate.Value != null) &&
                        ((txtSerialFinishDate.Value != DateTime.MinValue) && txtSerialFinishDate.Value != DEFAULT_DATE_TIME))
                    {
                        T_Purchase_Serial purchaseSerial = new T_Purchase_Serial();
                        purchaseSerial.PurchaseDID = detailPurchase.InternalID;
                        purchaseSerial.No = purchSerialNo++;
                        purchaseSerial.SerialNo = txtSerial.Value;
                        purchaseSerial.Terms = Convert.ToInt32(txtTerms.Value);
                        purchaseSerial.ContractType = short.Parse(cmbContractType.SelectedItem.Value);
                        purchaseSerial.TermUnit = Convert.ToInt32(cmbUnitSerial.SelectedItem.Value);
                        purchaseSerial.StartDate = txtSerialStartDate.Value.HasValue ? txtSerialStartDate.Value.Value : DEFAULT_DATE_TIME;
                        purchaseSerial.FinishDate = txtSerialFinishDate.Value.HasValue ? txtSerialFinishDate.Value.Value : DEFAULT_DATE_TIME;

                        lstSerial.Add(purchaseSerial);
                    }
                }

                //Add to hastable
                hashSerial.Add(detailPurchase.InternalID, lstSerial);
                //--------------------------------------------------------------------

                //Reset no grid
                this._indexDetail = 1;
                foreach (var item in detailPurList)
                {
                    item.No = this._indexDetail++;
                }
            }
        }

        /// <summary>
        /// Create Detail Payment
        /// </summary>
        /// <param name="detailPayList"></param>
        private void CreateDetailPayment(ref IList<T_Payment> detailPayList)
        {
            if (detailPayList == null)
            {
                detailPayList = new List<T_Payment>();
            }

            //rptDetail Payment
            foreach (RepeaterItem item in this.rptPayment.Items)
            {
                HiddenField hdnNoPayment = (HiddenField)item.FindControl("hdnNoPayment");
                var rowNo = int.Parse(hdnNoPayment.Value);

                HtmlInputCheckBox chkDelPayFlg = (HtmlInputCheckBox)item.FindControl("deletePayFlag");
                IDateTextBox dtPaymentDate = (IDateTextBox)item.FindControl("dtPaymentDate");
                INumberTextBox txtAmount = (INumberTextBox)item.FindControl("txtAmount");
                DropDownList cmbPaymentMethod = (DropDownList)item.FindControl("cmbPaymentMethod");
                ITextBox txtPayRemark1 = (ITextBox)item.FindControl("txtPayRemark1");
                ITextBox txtPayRemark2 = (ITextBox)item.FindControl("txtPayRemark2");

                //Check empty row
                if (!dtPaymentDate.Value.HasValue &&
                    //-------------------- Edited by ISV-Giam 2014/12/12 --------------------------
                    //int.Parse(cmbPaymentMethod.SelectedValue) == Constant.DEFAULT_ID &&
                    int.Parse(cmbPaymentMethod.SelectedValue) == 255 &&
                    //-------------------------------- End ----------------------------------------
                    string.IsNullOrEmpty(txtPayRemark1.Value) &&
                    !txtAmount.Value.HasValue &&
                     string.IsNullOrEmpty(txtPayRemark2.Value))
                {
                    continue;
                }

                var detailPurchase = detailPayList.Where(x => x.No.Equals(rowNo)).SingleOrDefault();
                if (detailPurchase == null)
                {
                    detailPurchase = new T_Payment();
                    detailPayList.Add(detailPurchase);
                }

                //Delete flag
                if (chkDelPayFlg != null)
                {
                    detailPurchase.DelFlag = (chkDelPayFlg.Checked) ? true : false;
                }

                //Payment date
                if (dtPaymentDate.Value.HasValue)
                {
                    detailPurchase.PaymentDate = dtPaymentDate.Value.Value;
                }

                //Amount
                if (txtAmount != null)
                {
                    if (txtAmount.Value.HasValue)
                    {
                        detailPurchase.Amount = txtAmount.Value.Value;
                    }
                }

                //PaymentMethod
                if (cmbPaymentMethod != null && cmbPaymentMethod.SelectedItem != null)
                {
                    detailPurchase.PaymentMethod = short.Parse(cmbPaymentMethod.SelectedValue);
                }

                //Remark1
                if (txtPayRemark1 != null)
                {
                    detailPurchase.Remark1 = txtPayRemark1.Value;
                }

                //Remark2
                if (txtPayRemark2 != null)
                {
                    detailPurchase.Remark2 = txtPayRemark2.Value;
                }

                this._indexPayment = 1;
                //Reset no grid
                foreach (var detail in detailPayList)
                {
                    detail.No = this._indexPayment++;
                }
            }
        }

        /// <summary>
        /// Get Sales by No
        /// </summary>
        /// <param name="salesNo">Sales No</param>
        /// <returns></returns>
        private T_Sales_H GetSales(string salesNo)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Currency
                return sales_HService.GetBySalesNo(salesNo);
            }
        }

        /// <summary>
        /// Get Sales by ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Sales_H GetSales(int id)
        {
            using (DB db = new DB())
            {
                Sales_HService sales_HService = new Sales_HService(db);

                //Get Currency
                return sales_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Check all to reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidAllRef()
        {
            return this.IsValidQuotationRef() || this.IsValidSalesRef();
        }

        /// <summary>
        /// Check valid to quotation reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidQuotationRef()
        {
            return !this.txtQuotationNo.IsEmpty;
        }

        /// <summary>
        /// Check valid to Sales reference
        /// </summary>
        /// <returns></returns>
        public bool IsValidSalesRef()
        {
            return !this.txtSalesNo.IsEmpty;
        }

        /// <summary>
        /// check button delete
        /// </summary>
        /// <returns></returns>
        protected bool HasDataCheck()
        {
            IList<T_Payment> listPaymentInfo = new List<T_Payment>();
            IList<T_Purchase_D> detailModel = new List<T_Purchase_D>();
            using (DB db = new DB())
            {
                PaymentService paymentService = new PaymentService(db);
                Purchase_DService purchase_DService = new Purchase_DService(db);
                detailModel = purchase_DService.GetByPurchaseID(this.DataID);
                listPaymentInfo = paymentService.GetListByID(this.DataID);
            }
            return (listPaymentInfo != null && listPaymentInfo.Count != 0) || (detailModel != null && detailModel.Any(x => x.DeliverQuantity != 0));
        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            //this.txtIssueBy.Value = string.Empty;
            this.txtIssueDate.Value = string.Empty;
            //this.txtUpdateBy.Value = string.Empty;
            this.txtUpdateDate.Value = string.Empty;
            //this.txtCreateBy.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        #endregion

        #region Payment Method

        /// <summary>
        /// Get Billing
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private T_Billing_H GetBilling(int id)
        {
            using (DB db = new DB())
            {
                Billing_HService billing_HService = new Billing_HService(db);

                //Get Currency
                return billing_HService.GetByPK(id);
            }
        }

        /// <summary>
        /// Show detail payment data on form
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void ShowDetailPaymentData(int headerID)
        {
            using (DB db = new DB())
            {
                PaymentService payService = new PaymentService(db);

                var listPaymentInfo = payService.GetListByID(headerID);

                if (listPaymentInfo != null)
                {
                    var sumTotalPayment = 0m;
                    foreach (var item in listPaymentInfo)
                    {
                        sumTotalPayment += item.Amount.HasValue ? item.Amount.Value : 0;
                    }

                    if (sumTotalPayment.Equals(0) && listPaymentInfo.Count == 0)
                    {
                        //this.txtPaymentTotal.Value = null;
                        this.txtPaymentTotal.Value = 0;
                    }
                    else
                    {
                        this.txtPaymentTotal.Value = sumTotalPayment;
                    }

                    this.txtBalance.Value = this.txtGrandTotal.Value - sumTotalPayment;
                }

                //Reset datasource
                this.PaymentDataSource = listPaymentInfo;
                this.rptPayment.DataSource = listPaymentInfo;
                this.rptPayment.DataBind();

                //Set row count
                this.PaymentRowCount = listPaymentInfo.Count;
            }
        }

        /// <summary>
        /// Get detail payment list from screen
        /// </summary>
        /// <returns>list currency detail</returns>
        private List<T_Payment> GetDetailPaymentData()
        {
            List<T_Payment> results = new List<T_Payment>();
            this._indexPayment = 0;
            foreach (RepeaterItem item in this.rptPayment.Items)
            {
                HtmlInputCheckBox chkDelPayFlg = (HtmlInputCheckBox)item.FindControl("deletePayFlag");
                IDateTextBox dtPaymentDate = (IDateTextBox)item.FindControl("dtPaymentDate");
                INumberTextBox txtAmount = (INumberTextBox)item.FindControl("txtAmount");
                DropDownList cmbPaymentMethod = (DropDownList)item.FindControl("cmbPaymentMethod");
                ITextBox txtPayRemark1 = (ITextBox)item.FindControl("txtPayRemark1");
                ITextBox txtPayRemark2 = (ITextBox)item.FindControl("txtPayRemark2");

                T_Payment addItem = new T_Payment();

                addItem.No = this._indexPayment++;

                //Delete flag
                if (chkDelPayFlg != null)
                {
                    addItem.DelFlag = (chkDelPayFlg.Checked) ? true : false;
                }

                //Payment date
                if (dtPaymentDate != null)
                {
                    if (dtPaymentDate.Value.HasValue)
                    {
                        if (dtPaymentDate.Value == DEFAULT_DATE_TIME)
                        {
                            addItem.PaymentDate = null;
                        }
                        else
                        {
                            addItem.PaymentDate = dtPaymentDate.Value.Value;
                        }
                    }
                }

                //Amount
                if (txtAmount != null)
                {
                    if (txtAmount.Value.HasValue)
                    {
                        addItem.Amount = txtAmount.Value.Value;
                    }
                }

                //PaymentMethod
                if (cmbPaymentMethod != null && cmbPaymentMethod.SelectedItem != null)
                {
                    addItem.PaymentMethod = short.Parse(cmbPaymentMethod.SelectedValue);
                }

                //Remark1
                if (txtPayRemark1 != null)
                {
                    addItem.Remark1 = txtPayRemark1.Value;
                }

                //Remark2
                if (txtPayRemark2 != null)
                {
                    addItem.Remark2 = txtPayRemark2.Value;
                }

                results.Add(addItem);
            }

            return results;
        }

        /// <summary>
        /// Refresh Payment Details
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshPaymentDetails(IList<T_Payment> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailPaymentData();
            }
            this.rptPayment.DataSource = dataSource;
            this.rptPayment.DataBind();
        }

        #endregion

        #region WebMethod

        /// <summary>
        /// Get Vendor Info
        /// </summary>
        /// <param name="in1">vendorCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetVendor(string in1)
        {
            try
            {
                var dbVendorCD = in1;
                dbVendorCD = OMS.Utilities.EditDataUtil.ToFixCodeDB(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_LENGTH);
                in1 = OMS.Utilities.EditDataUtil.ToFixCodeShow(dbVendorCD, M_Vendor.VENDOR_CODE_MAX_SHOW);
                //-------------- Edited 2014/12/08 by ISV Giam --------------
                if (in1 == OMS.Models.M_Vendor.VENDOR_CODE_SUPPORT)
                {
                    return string.Empty;
                }
                //-----------------------------------------------------------

                using (DB db = new DB())
                {
                    VendorService service = new VendorService(db);

                    var vendor = service.GetByCD(dbVendorCD);
                    if (vendor != null && vendor.StatusFlag == 0)
                    {
                        var result = new
                        {
                            vendorCD = in1,
                            vendorName1 = vendor.VendorName1,
                            attn = vendor.ContactPerson,
                            add1 = vendor.VendorAddress1,
                            add2 = vendor.VendorAddress2,
                            add3 = vendor.VendorAddress3,
                            tel = vendor.Tel,
                            fax = vendor.FAX
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        vendorCD = in1
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get User Info
        /// </summary>
        /// <param name="in1">userCD</param>        
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUser(string in1)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new UserService(db);

                    var data = service.GetByUserCD(OMS.Utilities.EditDataUtil.ToFixCodeDB(in1, M_User.USER_CODE_MAX_LENGTH));
                    if (data != null && data.ID != Constant.DEFAULT_ID
                                     && data.StatusFlag == 0)
                    {
                        var result = new
                        {
                            userName = data.UserName2
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    return string.Empty;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Product
        /// </summary>
        /// <param name="in1">vendorCd</param>
        /// <returns>vendor info</returns>
        [System.Web.Services.WebMethod]
        public static string GetProduct(short type, string purchaseDate, string productCd, string quantity,
                                        int currencyID, int fractionType, int decimalDigit)
        {
            try
            {
                if (productCd == M_Product.PRODUCT_CODE_SUPPORT)
                {
                    return string.Empty;
                }

                using (DB db = new DB())
                {
                    ProductService service = new ProductService(db);

                    var mProd = service.GetByCD(productCd);

                    if (mProd == null || mProd.StatusFlag != 0)
                    {
                        return string.Empty;
                    }
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    System.Text.StringBuilder result = new System.Text.StringBuilder();
                    result.Append("{");

                    result.Append(string.Format("\"ProductName\":\"{0}\"", mProd.ProductName.Replace("\"", "\\\"").Replace("\r\n", "</br>")));

                    #region Cost
                    if (type == (short)ProductType.Cost)
                    {
                        //Cost
                        result.Append(string.Format(", \"Description\":\"{0}\"", mProd.DescriptionCost.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        result.Append(string.Format(", \"Remark\":\"{0}\"", mProd.RemarkCost.Replace("\"", "\\\"").Replace("\r\n", "</br>")));
                        result.Append(string.Format(", \"UnitID\":\"{0}\"", mProd.UnitIDCost));
                        result.Append(string.Format(", \"VatType\":\"{0}\"", mProd.VatTypeCost));

                        var _vatRatio = mProd.VatRatioCost;
                        var vatType = mProd.VatTypeCost;
                        var unitPrice = 0m;
                        var subTotal = 0m;
                        var vat = 0m;

                        //Check Currency
                        if (currencyID == mProd.CurrencyIDCost)
                        {
                            unitPrice = mProd.UnitPriceCost;
                        }
                        else
                        {
                            var baseDate = string.IsNullOrEmpty(purchaseDate) ? db.NowDate : CommonUtil.ParseDate(purchaseDate);
                            var crcyService = new Currency_HService(db);
                            var crcyList = crcyService.GetAllByDate(baseDate).ToDictionary(s => s.ID, s => s);

                            //Chuyen tien cua product ve tien mac dinh
                            if (mProd.CurrencyIDCost == Constant.DEFAULT_ID)
                            {
                                unitPrice = mProd.UnitPriceCost;
                            }
                            else
                            {
                                unitPrice = CommonUtil.ConvertToVND(crcyList[mProd.CurrencyIDCost].ExchangeRate, mProd.UnitPriceCost);
                            }
                            // Neu chon loai tien mac dinh thi set tra ve
                            // Con neu nguoc lai thi chuyen tien ve kieu tien duoc chon
                            if (currencyID != Constant.DEFAULT_ID)
                            {
                                unitPrice = CommonUtil.ConvertToNotVND(crcyList[currencyID].ExchangeRate, unitPrice);
                            }
                        }

                        result.Append(string.Format(", \"UnitPrice\":\"{0}\"", unitPrice.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(quantity))
                        {
                            subTotal = Fraction.Round((FractionType)fractionType, unitPrice * decimal.Parse(quantity), 2);
                            result.Append(string.Format(", \"Total\":\"{0}\"", subTotal.ToString(numberFormat)));
                        }
                        else
                        {
                            result.Append(string.Format(", \"Total\":\"{0}\"", string.Empty));
                        }

                        if (vatType == (int)VATFlg.Exclude)
                        {
                            result.Append(string.Format(", \"VatRatio\":\"{0}\"", _vatRatio.ToString("N0")));
                            if (!string.IsNullOrEmpty(quantity))
                            {
                                vat = Fraction.Round((FractionType)fractionType, (subTotal * _vatRatio) / 100, 2);
                                result.Append(string.Format(", \"Vat\":\"{0}\"", vat.ToString(numberFormat)));
                            }
                            else
                            {
                                result.Append(string.Format(", \"Vat\":\"{0}\"", string.Empty));
                            }
                        }
                        else
                        {
                            result.Append(string.Format(", \"VatRatio\":\"{0}\"", string.Empty));
                            result.Append(string.Format(", \"Vat\":\"{0}\"", string.Empty));
                        }
                    }
                    #endregion

                    result.Append("}");
                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Condition
        /// </summary>
        /// <param name="in1">ConditionCD</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetCondition(string conditionCd, string condition)
        {
            try
            {
                using (DB db = new DB())
                {
                    var service = new ConditionService(db);
                    var mCond = service.GetByCodeAndType(conditionCd, (int)ConditionFlag.Purchase);
                    if (mCond != null)
                    {
                        var result = new
                        {
                            condition = mCond.Condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            condition = condition
                        };
                        return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calculate Warranty Date
        /// </summary>
        /// <param name="senderId"></param>
        /// <param name="terms"></param>
        /// <param name="unit"></param>
        /// <param name="warranty"></param>
        /// <param name="termsId"></param>
        /// <param name="warrantyId"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcWarrantyDate(string senderId, string deliveryDate, string contractType, string terms
                                    , string unit, string startDateId, string finishDateId)
        {
            try
            {
                DateTime date = CommonUtil.GetDefaultDate();
                if (!string.IsNullOrEmpty(deliveryDate))
                {
                    date = CommonUtil.ParseDate(deliveryDate);
                }
                else
                {
                    using (var db = new DB())
                    {
                        date = db.NowDate;
                    }
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtTerms") || senderId.Contains("cmbUnitSerial"))
                {
                    if (string.IsNullOrEmpty(terms) || Convert.ToInt32(unit) == 0)
                    {
                        if (!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                            result.Append(string.Format("\"{0}\":\"{1}\", ", startDateId, string.Empty));
                        result.Append(string.Format("\"{0}\":\"{1}\"", finishDateId, string.Empty));

                    }
                    else
                    {
                        var termsVal = Convert.ToInt32(terms);
                        DateTime deliDate = DateTime.MinValue;
                        DateTime maxdate = new DateTime(9999, 12, 31);
                        switch (int.Parse(unit))
                        {
                            case (int)WarrantyUnit.None://not select
                                break;

                            case (int)WarrantyUnit.Years://years
                                if (termsVal + deliDate.Year > maxdate.Year)
                                {
                                    deliDate = maxdate;
                                }
                                else
                                {
                                    deliDate = date.AddYears(termsVal);
                                }
                                break;

                            case (int)WarrantyUnit.Months://months
                                deliDate = date.AddMonths(termsVal);
                                break;

                            case (int)WarrantyUnit.Weeks://weeks
                                deliDate = date.AddDays(termsVal * 7);
                                break;

                            case (int)WarrantyUnit.Days://days
                                deliDate = date.AddDays(termsVal);
                                break;

                            default:
                                break;
                        }
                        if (!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                            result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\", ", startDateId, date));
                        result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\"", finishDateId, deliDate));
                    }
                }

                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calculates the balance start datevs finish date.
        /// </summary>
        /// <param name="senderId">The sender identifier.</param>
        /// <param name="targetId">The target identifier.</param>
        /// <param name="date">The date.</param>
        /// <param name="terms">The terms.</param>
        /// <param name="unit">The unit.</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalcBalanceStartDatevsFinishDate(string senderId,
                                                              string targetId,
                                                              string contractType,
                                                              string terms, string unit,
                                                              string date)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (string.IsNullOrEmpty(date))
                {
                    result.Append(string.Format("\"{0}\":\"{1}\"", targetId, string.Empty));
                    result.Append("}");
                    return result.ToString();
                }
                var iDate = CommonUtil.ParseDate(date);


                var termsVal = CommonUtil.ParseInteger(terms);
                DateTime oDate = DateTime.MinValue;

                DateTime maxdate = new DateTime(9999, 12, 31);
                DateTime minDate = CommonUtil.GetDefaultDate();

                #region Calc
                switch (int.Parse(unit))
                {
                    case (int)WarrantyUnit.None://not select
                        break;

                    case (int)WarrantyUnit.Years://years

                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            if (termsVal + iDate.Year > maxdate.Year)
                            {
                                oDate = maxdate;
                            }
                            else
                            {
                                oDate = iDate.AddYears(termsVal);
                            }
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            if (termsVal - iDate.Year > minDate.Year)
                            {
                                oDate = minDate;
                            }
                            else
                            {
                                oDate = iDate.AddYears(termsVal * -1);
                            }
                        }
                        break;

                    case (int)WarrantyUnit.Months://months
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddMonths(termsVal);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddMonths(termsVal * -1);
                        }
                        break;

                    case (int)WarrantyUnit.Weeks://weeks
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * 7);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * -7);
                        }

                        break;

                    case (int)WarrantyUnit.Days://days
                        if (senderId.IndexOf("txtSerialStartDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal);
                        }
                        else if (senderId.IndexOf("txtSerialFinishDate") != -1)
                        {
                            oDate = iDate.AddDays(termsVal * -1);
                        }
                        break;
                    default:
                        break;
                }
                #endregion

                if (!contractType.Equals(M_Config_D.CONFIG_CD_SERIAL_CONTRACT_TYPE_WARRANTY))
                {
                    result.Append(string.Format("\"{0}\":\"{1:dd/MM/yyyy}\"", targetId, oDate));
                }
                result.Append("}");
                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Sell
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcDetail(string senderId, string vatType
                                    , string unitPrice, string quantity, string total, string vatRatio
                                    , int decimalDigit
                                    , int fractionType
                                    , string totalId, string vatId)
        {
            try
            {
                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (senderId.Contains("txtPrice") || senderId.Contains("txtQuantity"))
                {
                    if (string.IsNullOrEmpty(unitPrice) || string.IsNullOrEmpty(quantity))
                    {
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, string.Empty));
                        result.Append(string.Format(",\"{0}\":\"{1}\"", vatId, string.Empty));
                    }
                    else
                    {
                        var subTotal = Utilities.Fraction.Round((FractionType)fractionType, decimal.Parse(unitPrice) * decimal.Parse(quantity), 2);
                        string numberFormat = string.Format("N{0}", decimalDigit);
                        result.Append(string.Format("\"{0}\":\"{1}\"", totalId, subTotal.ToString(numberFormat)));

                        if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                        {
                            if (string.IsNullOrEmpty(vatRatio))
                            {
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, string.Empty));
                            }
                            else
                            {
                                var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                                result.Append(string.Format(", \"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                            }
                        }
                    }
                }
                else if (senderId.Contains("txtTotal") || senderId.Contains("txtVatRatio"))
                {
                    var subTotal = decimal.Parse(total);
                    string numberFormat = string.Format("N{0}", decimalDigit);

                    if (!string.IsNullOrEmpty(vatType) && int.Parse(vatType) == (int)VATFlg.Exclude)
                    {
                        if (string.IsNullOrEmpty(vatRatio))
                        {
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, string.Empty));
                        }
                        else
                        {
                            var subVat = Utilities.Fraction.Round((FractionType)fractionType, (subTotal * decimal.Parse(vatRatio)) / 100, 2);
                            result.Append(string.Format("\"{0}\":\"{1}\"", vatId, subVat.ToString(numberFormat)));
                        }
                    }
                }
                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotal(string methodVAT
                                       , string[] totals
                                       , string[] VATs
                                       , string vatRatio
                                       , string payment
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                if (string.IsNullOrEmpty(vatRatio))
                {
                    vatRatio = "0";
                }

                decimal? sumTotal = null;
                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = Utilities.Fraction.Round((FractionType)fractionType, totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);
                }

                decimal? sumVAT = null;
                if (sumTotal.HasValue)
                {
                    if (VATs.Any(s => !string.IsNullOrEmpty(s)))
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, VATs.Sum(v => string.IsNullOrEmpty(v) ? 0 : decimal.Parse(v)), 2);
                    }

                    if (methodVAT == M_Config_D.METHOD_VAT_SUM)
                    {
                        sumVAT = Utilities.Fraction.Round((FractionType)fractionType, (sumTotal.GetValueOrDefault() * decimal.Parse(vatRatio)) / 100, 2);
                    }
                }

                decimal? grandTotal = null;
                string numberFormat = string.Format("N{0}", decimalDigit);

                if (sumTotal.HasValue && sumVAT.HasValue)
                {
                    grandTotal = sumTotal.GetValueOrDefault() + sumVAT.GetValueOrDefault();
                }

                //Balance
                decimal? balance = null;
                balance = grandTotal - decimal.Parse(payment);
                //if (string.IsNullOrEmpty(payment))
                //{
                //    balance = grandTotal;
                //}
                //else
                //{
                //    balance = grandTotal - decimal.Parse(payment);
                //}


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtSumTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtSumVat\":\"{0}\"", sumVAT.HasValue ? sumVAT.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtGrandTotal\":\"{0}\"", grandTotal.HasValue ? grandTotal.GetValueOrDefault().ToString(numberFormat) : string.Empty));
                result.Append(string.Format(", \"txtBalance\":\"{0}\"", balance.HasValue ? balance.GetValueOrDefault().ToString(numberFormat) : string.Empty));

                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count Attached File
        /// </summary>
        /// <param name="dataId">dataId</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(int dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId, (int)FType.Purchase);
                    var result = new
                    {
                        count = count
                    };
                    return OMS.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcTotalAmount(string[] Amounts
                                       , string grandTotal
                                       , int decimalDigit
                                       , int fractionType)
        {
            try
            {
                var sumAmount = Utilities.Fraction.Round((FractionType)fractionType, Amounts.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s)), 2);

                var balance = decimal.Parse(grandTotal) - sumAmount;

                string numberFormat = string.Format("N{0}", decimalDigit);


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                result.Append(string.Format("\"txtPaymentTotal\":\"{0}\"", sumAmount.ToString(numberFormat)));
                result.Append(string.Format(",\"txtBalance\":\"{0}\"", balance.ToString(numberFormat)));

                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Calc Grand Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcGrandTotal(string grandTotal
                                           , string payment
                                           , int decimalDigit)
        {
            try
            {
                decimal? balance = null;
                if (string.IsNullOrEmpty(grandTotal))
                {
                    balance = null;
                    //if (string.IsNullOrEmpty(payment))
                    //{
                    //    balance = null;
                    //}
                    //else
                    //{
                    //    balance = 0 - decimal.Parse(payment);
                    //}
                }
                else
                {
                    balance = decimal.Parse(grandTotal) - decimal.Parse(payment);
                    //if (string.IsNullOrEmpty(payment))
                    //{
                    //    balance = decimal.Parse(grandTotal);
                    //}
                    //else
                    //{
                    //    balance = decimal.Parse(grandTotal) - decimal.Parse(payment);
                    //}
                }

                string numberFormat = string.Format("N{0}", decimalDigit);


                System.Text.StringBuilder result = new System.Text.StringBuilder();
                result.Append("{");

                if (balance != null)
                {
                    result.Append(string.Format("\"txtBalance\":\"{0}\"", balance.GetValueOrDefault().ToString(numberFormat)));
                }
                else
                {
                    result.Append(string.Format("\"txtBalance\":\"{0}\"", string.Empty));
                }

                result.Append("}");
                return result.ToString();

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion
    }
}
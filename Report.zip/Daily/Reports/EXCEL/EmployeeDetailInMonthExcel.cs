﻿using System;
using System.Collections.Generic;
using System.Linq;

using NPOI.SS.UserModel;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Reports.EXCEL
{
    /// <summary>
    /// Class EmployeeDetailInMonth Excel
    /// </summary>
    public class EmployeeDetailInMonthExcel : BaseExcel
    {
        #region Contanst Excel
        private const int defaultRowHeight = 300;

        //Sys Date
        private const int SYS_DAY_COL_INDEX = 0;

        //Shift Pattern Start
        private const int SHIFT_PATTERN_START_COL_INDEX = 1;

        //Shift Pattern end
        private const int SHIFT_PATTERN_END_COL_INDEX = 2;

        //Shift Pattern Out
        private const int SHIFT_PATTERN_OUT_COL_INDEX = 3;

        //Shift Pattern Return
        private const int SHIFT_PATTERN_RETURN_COL_INDEX = 4;

        //Work Time  Work
        private const int WORK_TIME_WORK_COL_INDEX = 5;

        //Work Time  Late
        private const int WORK_TIME_LATE_COL_INDEX = 6;

        //Work Time Early
        private const int WORK_TIME_EARLY_COL_INDEX = 7;

        //Work Time Out
        private const int WORK_TIME_OUT_COL_INDEX = 8;

        //Work Time Day Off
        private const int WORK_TIME_DAY_OFF_COL_INDEX = 9;

        //Work Time Absence
        private const int WORK_TIME_ABSENCE_COL_INDEX = 10;

        //OverTime Early
        private const int OVER_TIME_EARLY_COL_INDEX = 11;

        //OverTime Normal
        private const int OVER_TIME_NORMAL_COL_INDEX = 12;

        //OverTime Sat
        private const int OVER_TIME_SAT_COL_INDEX = 13;

        //OverTime Late 
        private const int OVER_TIME_LATE_COL_INDEX = 14;

        //OverTime Sun
        private const int OVER_TIME_SUN_COL_INDEX = 15;

        //OverTime Holiday
        private const int OVER_TIME_HOLIDAY_COL_INDEX = 16;

        //Remark
        private const int REMARK_COL_INDEX = 17;
        #endregion Contanst Excel

        #region Properties
        /// <summary>
        /// Staff ID
        /// </summary>
        public int StaffID { get; set; }

        /// <summary>
        /// Staff Name
        /// </summary>
        public String StaffNm { get; set; }

        /// <summary>
        /// Date
        /// </summary>
        public DateTime Date { get; set; }
        #endregion

        #region Method
        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;

            AccountingPeriod _period = new AccountingPeriod();
            List<WorkInfo> items = new List<WorkInfo>();
            WorkTotalInfo work_total = new WorkTotalInfo();
            WorkTotalInfo totals = new WorkTotalInfo();

            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                _period = _ser.GetAccountingMonth(this.Date);

                WorkService _workService = new WorkService(db);
                items = _workService.GetListByCond(this.StaffID, _period.StartDate, _period.EndDate).OrderBy(m => m.WorkDate).ToList();

                WorkTotalService _workTotalService = new WorkTotalService(db);
                work_total = _workTotalService.GetByKey(this.StaffID, Date);
                totals = _workService.GetTotalByCond(this.StaffID, _period.StartDate, _period.EndDate);
                
            }

            IList<EmployeeDetailInMonthList> lstData = this.GetListByCondForEmployeeDetailInMonthExcel(this.StaffID, _period.StartDate, _period.EndDate);

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("Employee Detail in Month");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Employee Detail In Month");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                SetTotalDataForExcel(sheet, work_total, totals);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// Get List By Cond For EmployeeDetailInMonth Excel
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns>IList<EmployeeDetailInMonthList></returns>
        private IList<EmployeeDetailInMonthList> GetListByCondForEmployeeDetailInMonthExcel(int staffID, DateTime dateForm, DateTime dateTo)
        {
            IList<EmployeeDetailInMonthList> results = null;

            using (DB db = new DB())
            {
                WorkService workService = new WorkService(db);
                results = workService.GetListByCondForEmployeeDetailInMonth(staffID, dateForm, dateTo);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);
            //employee
            ICell cellEmployee = row1.GetCell(0);
            string employee = "Employee Name: " + this.StaffNm;
            cellEmployee.SetCellValue(employee);

            
            //--------------- Row 2 ----------------
            IRow row2 = sheet.GetRow(2);
            //month
            ICell cellMonth = row2.GetCell(0);
            string month = "Month: " + string.Format(Constants.FMT_MMYYYY, this.Date);
            cellMonth.SetCellValue(month);
        }

        /// <summary>
        /// Set Total Data For Excel
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="work_total"></param>
        /// <param name="totals"></param>
        private void SetTotalDataForExcel(ISheet sheet, WorkTotalInfo work_total, WorkTotalInfo totals)
        {
            //--------------- Row 9 ----------------
            IRow row = sheet.GetRow(9);

            //Work
            ICell cellWork = row.GetCell(WORK_TIME_WORK_COL_INDEX);
            //Late
            ICell cellLate = row.GetCell(WORK_TIME_LATE_COL_INDEX);
            //Early
            ICell cellEarly = row.GetCell(WORK_TIME_EARLY_COL_INDEX);
            //Out
            ICell cellOut = row.GetCell(WORK_TIME_OUT_COL_INDEX);
            //DayOff
            ICell cellDayOff = row.GetCell(WORK_TIME_DAY_OFF_COL_INDEX);
            //Absence
            ICell cellAbsence = row.GetCell(WORK_TIME_ABSENCE_COL_INDEX);
            //OTEarly
            ICell cellOTEarly = row.GetCell(OVER_TIME_EARLY_COL_INDEX);
            //Normal
            ICell cellNormal = row.GetCell(OVER_TIME_NORMAL_COL_INDEX);
            //Sat
            ICell cellSat = row.GetCell(OVER_TIME_SAT_COL_INDEX);
            //Late
            ICell cellOTLate = row.GetCell(OVER_TIME_LATE_COL_INDEX);
            //Sun
            ICell cellSun = row.GetCell(OVER_TIME_SUN_COL_INDEX);
            //Holiday
            ICell cellHoliday = row.GetCell(OVER_TIME_HOLIDAY_COL_INDEX);
            
            if (work_total != null)
            {
                cellWork.SetCellValue(work_total.TimeWork.Replace("&nbsp;", ""));
                cellLate.SetCellValue(work_total.TimeLate.Replace("&nbsp;", ""));
                cellEarly.SetCellValue(work_total.TimeEarly.Replace("&nbsp;", ""));
                cellOut.SetCellValue(work_total.TimeOut.Replace("&nbsp;", ""));
                cellDayOff.SetCellValue(work_total.VacationLeavesStr.Replace("&nbsp;", ""));
                cellAbsence.SetCellValue(work_total.AbsenceLeavesStr.Replace("&nbsp;", ""));
                cellOTEarly.SetCellValue(work_total.OTEarly.Replace("&nbsp;", ""));
                cellNormal.SetCellValue(work_total.OTNormal1.Replace("&nbsp;", ""));
                cellSat.SetCellValue(work_total.OTNormal2.Replace("&nbsp;", ""));
                cellOTLate.SetCellValue(work_total.OTLate.Replace("&nbsp;", ""));
                cellSun.SetCellValue(work_total.OTHoliday1.Replace("&nbsp;", ""));
                cellHoliday.SetCellValue(work_total.OTHoliday2.Replace("&nbsp;", ""));
            }
            else
            {
                if (totals != null)
                {
                    cellWork.SetCellValue(totals.TimeWork.Replace("&nbsp;", ""));
                    cellLate.SetCellValue(totals.TimeLate.Replace("&nbsp;", ""));
                    cellEarly.SetCellValue(totals.TimeEarly.Replace("&nbsp;", ""));
                    cellOut.SetCellValue(totals.TimeOut.Replace("&nbsp;", ""));
                    cellDayOff.SetCellValue(totals.VacationLeavesStr.Replace("&nbsp;", ""));
                    cellAbsence.SetCellValue(totals.AbsenceLeavesStr.Replace("&nbsp;", ""));
                    cellOTEarly.SetCellValue(totals.OTEarly.Replace("&nbsp;", ""));
                    cellNormal.SetCellValue(totals.OTNormal1.Replace("&nbsp;", ""));
                    cellSat.SetCellValue(totals.OTNormal2.Replace("&nbsp;", ""));
                    cellOTLate.SetCellValue(totals.OTLate.Replace("&nbsp;", ""));
                    cellSun.SetCellValue(totals.OTHoliday1.Replace("&nbsp;", ""));
                    cellHoliday.SetCellValue(totals.OTHoliday2.Replace("&nbsp;", ""));
                }
            }
        }

        /// <summary>
        /// Fill Data
        /// </summary>
        /// <param name="wb"></param>
        /// <param name="sheet"></param>
        /// <param name="lstData"></param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<EmployeeDetailInMonthList> lstData)
        {
            int rowStart = 9;
            for (int k = 0; k < lstData.Count; k++)
            {
                if (lstData[k].TypeOfDay == (int)TypeOfDay.DayOff)
                {
                    this.CopyRow(wb, sheet, 8, rowStart + k);
                }
                else if (lstData[k].VacationLeaves == decimal.One)
                {
                    this.CopyRow(wb, sheet, 7, rowStart + k);
                }
                else
                {
                    this.CopyRow(wb, sheet, 6, rowStart + k);
                }

                IRow rowTemp = sheet.GetRow(rowStart + k);

                rowTemp.GetCell(SYS_DAY_COL_INDEX).SetCellValue(lstData[k].WorkDateDsp);

                rowTemp.GetCell(SHIFT_PATTERN_START_COL_INDEX).SetCellValue(lstData[k].StartWork);

                rowTemp.GetCell(SHIFT_PATTERN_END_COL_INDEX).SetCellValue(lstData[k].EndWork);

                rowTemp.GetCell(SHIFT_PATTERN_OUT_COL_INDEX).SetCellValue(this.SetStartOutTime(lstData[k].WorkStartOutInfos));

                rowTemp.GetCell(SHIFT_PATTERN_RETURN_COL_INDEX).SetCellValue(this.SetEndOutTime(lstData[k].WorkEndOutInfos));

                rowTemp.GetCell(WORK_TIME_WORK_COL_INDEX).SetCellValue(lstData[k].TimeWork);

                rowTemp.GetCell(WORK_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].TimeLate);

                rowTemp.GetCell(WORK_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].TimeEarly);

                rowTemp.GetCell(WORK_TIME_OUT_COL_INDEX).SetCellValue(lstData[k].TimeOut);

                rowTemp.GetCell(WORK_TIME_DAY_OFF_COL_INDEX).SetCellValue(lstData[k].VacationLeavesStr);

                rowTemp.GetCell(WORK_TIME_ABSENCE_COL_INDEX).SetCellValue(string.Empty);

                rowTemp.GetCell(OVER_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].OTEarly);

                rowTemp.GetCell(OVER_TIME_NORMAL_COL_INDEX).SetCellValue(lstData[k].OTNormal1);

                rowTemp.GetCell(OVER_TIME_SAT_COL_INDEX).SetCellValue(lstData[k].OTNormal2);

                rowTemp.GetCell(OVER_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].OTLate);

                rowTemp.GetCell(OVER_TIME_SUN_COL_INDEX).SetCellValue(lstData[k].OTHoliday1);

                rowTemp.GetCell(OVER_TIME_HOLIDAY_COL_INDEX).SetCellValue(lstData[k].OTHoliday2);

                rowTemp.GetCell(REMARK_COL_INDEX).SetCellValue(lstData[k].Remark);

                IRow excRowHeight = sheet.GetRow(rowStart - 3 + k);
                this.setHeight(lstData[k].WorkStartOutInfos, lstData[k].WorkEndOutInfos, excRowHeight);
            }

            if (lstData.Count <= 3)
            {
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 3, -3);
            }
            else
            {
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -3);
            }
        }

        /// <summary>
        /// SetStartOutTime
        /// </summary>
        /// <param name="workStartOutInfos">workStartOutInfos</param>
        /// <returns>outTime</returns>
        private string SetStartOutTime(IList<WorkStartOutInfo> workStartOutInfos)
        {
            var outTime = string.Empty;

            if (workStartOutInfos.Count > 0)
            {
                outTime = string.Join(Environment.NewLine, workStartOutInfos.Select(x => x.StartOut));
            }

            return outTime;
        }

        /// <summary>
        /// SetEndOutTime
        /// </summary>
        /// <param name="workStartOutInfos">workStartOutInfos</param>
        /// <returns>outTime</returns>
        private string SetEndOutTime(IList<WorkEndOutInfo> workEndOutInfos)
        {
            var outTime = string.Empty;

            if (workEndOutInfos.Count > 0)
            {
                outTime = string.Join(Environment.NewLine, workEndOutInfos.Select(x=>x.EndOut)); 
            }

            return outTime;
        }

        /// <summary>
        /// setHeight
        /// </summary>
        /// <param name="workStartOutInfos">workStartOutInfos</param>
        /// <param name="workEndOutInfos">workEndOutInfos</param>
        /// <param name="row">row</param>
        private void setHeight(IList<WorkStartOutInfo> workStartOutInfos, IList<WorkEndOutInfo> workEndOutInfos, IRow row)
        {
            short heightStartOut = (short)(workStartOutInfos.Count * defaultRowHeight);
            short heightEndOut = (short)(workEndOutInfos.Count * defaultRowHeight);

            short height = heightStartOut < heightEndOut ? heightEndOut : heightStartOut;
            if (height > defaultRowHeight)
            {
                row.Height = height;
            }
        }
        #endregion
    }
}
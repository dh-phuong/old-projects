﻿using System;
using System.IO;
using System.Web;

using DailyReport.Utilities;

using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.HSSF.UserModel;

namespace DailyReport.Reports.EXCEL
{
    /// <summary>
    /// Base Excel
    /// </summary>
    public class BaseExcel
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BaseExcel()
        {
        }

        /// <summary>
        /// Create Workbook
        /// </summary>
        /// <param name="fileName">File Name</param>
        /// <returns>Workbook</returns>
        protected IWorkbook CreateWorkbook(string fileName, bool isIsvExcel = false)
        {
            const string TEMPLATE_FOLDER = @"\TemplateExcel";
            var server = HttpContext.Current.Server.MapPath("~");
            var folder = server + TEMPLATE_FOLDER;
            var fullPath = System.IO.Path.Combine(folder, string.Format("{0}.{1}", fileName, Constants.EXCEL_EXTEND));
            using (FileStream temp = new FileStream(fullPath, FileMode.Open, FileAccess.Read))
            {

                return new HSSFWorkbook(temp);
            }
        }

        /// <summary>
        /// Copy Row
        /// </summary>
        /// <param name="workBook">IWorkbook</param>
        /// <param name="workSheet">ISheet</param>
        /// <param name="sourceRowNum">SourceRowNum</param>
        /// <param name="destinationRowNum">DestinationRowNum</param>
        protected void CopyRow(IWorkbook workBook, ISheet workSheet, int sourceRowNum, int destinationRowNum, bool copyValue = true)
        {

            // Get the source / new row
            IRow newRow = workSheet.GetRow(destinationRowNum);
            IRow sourceRow = workSheet.GetRow(sourceRowNum);

            // If the row exist in destination, push down all rows by 1 else create a new row
            if (newRow != null)
            {
                workSheet.ShiftRows(destinationRowNum, workSheet.LastRowNum, 1, true, true);

                //Add 2015-07-23
                //newRow = workSheet.CreateRow(destinationRowNum);
            }
            else
            {
                newRow = workSheet.CreateRow(destinationRowNum);
            }
            newRow.Height = sourceRow.Height;
            // Loop through source columns to add to new row
            for (int i = 0; i < sourceRow.LastCellNum; i++)
            {
                // Grab a copy of the old/new cell
                ICell oldCell = sourceRow.GetCell(i);
                ICell newCell = newRow.CreateCell(i);

                // If the old cell is null jump to next cell
                if (oldCell == null)
                {
                    newCell = null;
                    continue;
                }

                // Copy style from old cell and apply to new cell
                //ICellStyle newCellStyle = workbook.CreateCellStyle();
                //newCellStyle.CloneStyleFrom(oldCell.CellStyle); ;
                newCell.CellStyle = oldCell.CellStyle;

                // If there is a cell comment, copy
                if (newCell.CellComment != null) newCell.CellComment = oldCell.CellComment;

                // If there is a cell hyperlink, copy
                if (oldCell.Hyperlink != null) newCell.Hyperlink = oldCell.Hyperlink;

                // Set the cell data type
                newCell.SetCellType(oldCell.CellType);
                if (copyValue)
                {
                    // Set the cell data value
                    switch (oldCell.CellType)
                    {
                        case CellType.Blank:
                            newCell.SetCellValue(oldCell.StringCellValue);
                            break;
                        case CellType.Boolean:
                            newCell.SetCellValue(oldCell.BooleanCellValue);
                            break;
                        case CellType.Error:
                            newCell.SetCellErrorValue(oldCell.ErrorCellValue);
                            break;
                        case CellType.Formula:
                            newCell.SetCellFormula(oldCell.CellFormula);
                            break;
                        case CellType.Numeric:
                            newCell.SetCellValue(oldCell.NumericCellValue);
                            break;
                        case CellType.String:
                            newCell.SetCellValue(oldCell.RichStringCellValue);
                            break;
                        case CellType.Unknown:
                            newCell.SetCellValue(oldCell.StringCellValue);
                            break;
                    }
                }

            }

            // If there are are any merged regions in the source row, copy to new row
            for (int i = 0; i < workSheet.NumMergedRegions; i++)
            {
                CellRangeAddress cellRangeAddress = workSheet.GetMergedRegion(i);
                if (cellRangeAddress.FirstRow == sourceRow.RowNum)
                {
                    CellRangeAddress newCellRangeAddress = new CellRangeAddress(newRow.RowNum,
                                                                                (newRow.RowNum +
                                                                                 (cellRangeAddress.FirstRow -
                                                                                  cellRangeAddress.LastRow)),
                                                                                cellRangeAddress.FirstColumn,
                                                                                cellRangeAddress.LastColumn);
                    workSheet.AddMergedRegion(newCellRangeAddress);
                }
            }
        }

        /// <summary>
        /// Set Value Double
        /// </summary>
        /// <param name="wb">Workbook</param>
        /// <param name="sheet">sheet</param>
        /// <param name="keyMap">keyMap</param>
        /// <param name="value">value</param>
        protected void SetValueDouble(IWorkbook wb, ISheet sheet, string keyMap, double value)
        {
            IName range = wb.GetName(keyMap);
            if (range != null && (!range.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName))))
            {
                CellReference cellRef = new CellReference(range.RefersToFormula);
                IRow row = sheet.GetRow(cellRef.Row);
                ICell cell = row.GetCell(cellRef.Col);

                cell.SetCellValue(value);
            }
        }

        /// <summary>
        /// Set Value Index
        /// </summary>
        /// <param name="wb">Workbook</param>
        /// <param name="sheet">sheet</param>
        /// <param name="keyMap">keyMap</param>
        /// <param name="value">value</param>
        /// <param name="replaceStr">replaceStr</param>
        /// <param name="fomular">fomular</param>
        /// <param name="replaceAll">replaceAll</param>
        protected void SetValueIndex(IWorkbook wb, ISheet sheet, string keyMap, Object value, string replaceStr = "", bool fomular = false, bool replaceAll = false)
        {
            IName range = wb.GetName(keyMap);
            if (range != null && (!range.RefersToFormula.Equals(string.Format("'{0}'!#REF!", sheet.SheetName))
                && !range.RefersToFormula.Equals(string.Format("{0}!#REF!", sheet.SheetName))))
            {
                CellReference cellRef = new CellReference(range.RefersToFormula);
                IRow row = sheet.GetRow(cellRef.Row);
                ICell cell = row.GetCell(cellRef.Col);
                var findCellString = cell.StringCellValue;

                var cellString = string.Empty;

                if (value != null)
                {
                    cellString = value.ToString();
                }

                if (string.IsNullOrEmpty(findCellString))
                {
                    cell.SetCellValue(cellString);
                }
                else
                {
                    if (!string.IsNullOrEmpty(replaceStr) && findCellString.IndexOf(replaceStr) >= 0)
                    {
                        if (replaceAll)
                        {
                            findCellString = findCellString.Replace(replaceStr, cellString);
                        }
                        else
                        {
                            var endPoint = findCellString.IndexOf(replaceStr);
                            var tempStr1 = findCellString.Substring(0, endPoint + replaceStr.Length);
                            var tempStr2 = tempStr1.Replace(replaceStr, cellString);
                            findCellString = findCellString.Replace(tempStr1, tempStr2);
                        }
                        cell.SetCellValue(findCellString);
                    }
                }
            }
        }

        /// <summary>
        /// Gets the day string.
        /// </summary>
        /// <param name="day">The day.[1 -> 31]</param>
        /// <returns></returns>
        protected string GetDayString(int day)
        {
            if (day < 0 || day > 31)
            {
                return string.Empty;
            }
            var suffixDay = string.Empty;
            switch (day)
            {
                case 1:
                case 21:
                case 31:
                    suffixDay = "st";
                    break;
                case 2:
                case 22:
                    suffixDay = "nd";
                    break;
                case 3:
                case 23:
                    suffixDay = "rd";
                    break;
                default:
                    suffixDay = "th";
                    break;
            }
            return string.Format("{0:00}{1}", day, suffixDay);
        }

        /// <summary>
        /// Gets the height.
        /// </summary>
        /// <param name="enterList">The enter list.</param>
        /// <param name="rowCount">The row count.</param>
        /// <param name="maxLengthOfCell">The maximum length of cell.</param>
        /// <param name="defaultRowHeight">Default height of the row.</param>
        /// <returns></returns>
        protected short GetHeight(string[] enterList, int rowCount, int maxLengthOfCell, int defaultRowHeight)
        {
            foreach (var item in enterList)
            {
                if (item.Length > maxLengthOfCell)
                {
                    int _temp = 0;
                    _temp = (int)Math.Truncate((double)item.Length / maxLengthOfCell);
                    rowCount += _temp;
                }
            }
            return (short)(rowCount * defaultRowHeight);
        }

        /// <summary>
        /// Gets the height (2).
        /// </summary>
        /// <param name="enterList">The enter list.</param>
        /// <param name="rowCount">The row count.</param>
        /// <param name="maxLengthOfCell">The maximum length of cell.</param>
        /// <param name="defaultRowHeight">Default height of the row.</param>
        /// <returns></returns>
        protected short GetHeight2(string[] enterList, int rowCount, int maxLengthOfCell, int defaultRowHeight)
        {
            foreach (var item in enterList)
            {
                if (item.Length > maxLengthOfCell)
                {
                    int _temp = 0;
                    _temp = (int)Math.Truncate((double)item.Length / maxLengthOfCell);
                    rowCount += _temp;
                }
                else
                {
                    rowCount += 1;
                }
            }
            return (short)(rowCount * defaultRowHeight);
        }

        /// <summary>
        /// Interface Excel
        /// </summary>
        public interface IExcel
        {
            /// <summary>
            /// Gets or sets the data identifier.
            /// </summary>
            /// <value>
            /// The data identifier.
            /// </value>
            int DataID { set; get; }

            /// <summary>
            /// Outputs the excel.
            /// </summary>
            /// <returns></returns>
            IWorkbook OutputExcel();
        }

        /// <summary>
        /// Excel API
        /// </summary>
        public abstract class IExcelAPI : BaseExcel, IExcel
        {
            #region Properties
            /// <summary>
            /// Gets or sets the data identifier.
            /// </summary>
            /// <value>
            /// The data identifier.
            /// </value>
            public int DataID
            {
                get;
                set;
            }

            /// <summary>
            /// Gets or sets the template folder.
            /// </summary>
            /// <value>
            /// The template folder.
            /// </value>
            public string TemplateFolder { get; set; }

            /// <summary>
            /// Gets or sets the name of the template file.
            /// </summary>
            /// <value>
            /// The name of the template file.
            /// </value>
            public string TemplateFileName
            {
                get;
                set;
            }
            #endregion Properties

            #region Constructor
            /// <summary>
            /// Constructor
            /// </summary>
            public IExcelAPI()
            {
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="PurchaseContract"/> class.
            /// </summary>
            /// <param name="dataId">The data identifier.</param>
            public IExcelAPI(int dataId, string templateFolder)
                : base()
            {
                this.DataID = dataId;
                this.TemplateFolder = templateFolder;
            }
            #endregion Constructor

            #region Method
            /// <summary>
            /// Outputs the excel.
            /// </summary>
            /// <returns></returns>
            public abstract IWorkbook OutputExcel();
            #endregion

            #region Private method
            /// <summary>
            /// Sets the cell value.
            /// </summary>
            /// <param name="sheet">The sheet.</param>
            /// <param name="name">The name.</param>
            /// <param name="value">The value.</param>
            /// <param name="keyWord">The key word.</param>
            protected void SetStringCellValue(ISheet sheet, string name, string value, string keyWord = "")
            {
                var cell = this.GetCell(sheet, name);
                if (cell == null)
                {
                    return;
                }
                this.SetStringCellValue(cell, value, keyWord);
            }

            /// <summary>
            /// Sets the cell value.
            /// </summary>
            /// <param name="cell">The cell.</param>
            /// <param name="value">The value.</param>
            /// <param name="keyWord">The key word.</param>
            protected void SetStringCellValue(ICell cell, string value, string keyWord = "")
            {
                var cellVal = cell.StringCellValue;

                var dataText = value;
                if (string.IsNullOrEmpty(cellVal) ||
                    string.IsNullOrEmpty(keyWord))
                {
                    cell.SetCellValue(dataText);
                }
                else
                {
                    if (cellVal.IndexOf(keyWord) >= 0)
                    {
                        var startIndex = cellVal.IndexOf(keyWord);
                        var subString = cellVal.Substring(0, startIndex + keyWord.Length);
                        var replace = subString.Replace(keyWord, dataText);
                        cellVal = cellVal.Replace(subString, replace);
                        cell.SetCellValue(cellVal);
                    }
                }
            }

            /// <summary>
            /// Sets the cell value.
            /// </summary>
            /// <typeparam name="IType">The type of the type.</typeparam>
            /// <param name="sheet">The sheet.</param>
            /// <param name="name">The name.</param>
            /// <param name="value">The value.</param>
            /// <param name="dataFormat">The data format.</param>
            protected void SetCellValue<IType>(ISheet sheet, string name, IType value, short dataFormat = 0)
            {
                var cell = this.GetCell(sheet, name);
                if (cell == null)
                {
                    return;
                }
                if (dataFormat != 0)
                {
                    cell.CellStyle.DataFormat = dataFormat;
                }
                var methodInfo = cell.GetType().GetMethod("SetCellValue", new Type[] { value.GetType() });
                methodInfo.Invoke(cell, new object[] { value });
            }

            /// <summary>
            /// Gets the string cell value.
            /// </summary>
            /// <param name="sheet">The sheet.</param>
            /// <param name="name">The name.</param>
            /// <returns></returns>
            /// <exception cref="System.Exception">Cell not found</exception>
            protected string GetStringCellValue(ISheet sheet, string name)
            {
                var cell = this.GetCell(sheet, name);
                if (cell == null)
                {
                    throw new Exception(name + ": Cell not found");
                }
                var cellVal = cell.StringCellValue;
                return cellVal;
            }

            /// <summary>
            /// Gets the string cell value.
            /// </summary>
            /// <param name="sheet">The sheet.</param>
            /// <param name="name">The name.</param>
            /// <returns></returns>
            /// <exception cref="System.Exception">Cell not found</exception>
            protected double GetNumberCellValue(ISheet sheet, string name)
            {
                var cell = this.GetCell(sheet, name);
                if (cell == null)
                {
                    throw new Exception(name + ": Cell not found");
                }
                var cellVal = cell.NumericCellValue;
                return cellVal;
            }

            /// <summary>
            /// Gets the cell.
            /// </summary>
            /// <param name="name">The name.</param>
            /// <returns></returns>
            protected ICell GetCell(ISheet sheet, string name)
            {
                var wb = sheet.Workbook;
                var cellName = wb.GetName(name);
                CellReference cellRef = null;
                if (cellName == null)
                {
                    cellRef = new CellReference(name);
                }
                else
                {
                    cellRef = new CellReference(cellName.RefersToFormula);
                }
                ISheet refSheet = sheet;
                if (!string.IsNullOrEmpty(cellRef.SheetName))
                {
                    refSheet = wb.GetSheet(cellRef.SheetName);
                }
                var row = refSheet.GetRow(cellRef.Row);
                if (row != null)
                {
                    return row.GetCell(cellRef.Col);
                }
                return null;
            }

            /// <summary>
            /// Formats the key word.
            /// </summary>
            /// <param name="key">The key.</param>
            /// <returns></returns>
            protected string FormatKeyWord(string key)
            {
                return string.Format("[{0}]", key);
            }
            #endregion Private method
        }
    }
}
﻿using System.Collections.Generic;

using NPOI.SS.UserModel;

using DailyReport.DAC;
using DailyReport.Models;

namespace DailyReport.Reports.EXCEL
{
    /// <summary>
    /// Class ListEmployeeInMonth Excel
    /// </summary>
    public class ListEmployeeInMonthExcel : BaseExcel
    {
        #region Contanst Excel
        private const int defaultRowLength = 40;
        private const int defaultRowHeight = 210;

        //Sys Date
        private const int Employee = 0;

        //Work Time  Work
        private const int WORK_TIME_WORK_COL_INDEX = 1;

        //Work Time  Late
        private const int WORK_TIME_LATE_COL_INDEX = 2;

        //Work Time Early
        private const int WORK_TIME_EARLY_COL_INDEX = 3;

        //Work Time Out
        private const int WORK_TIME_OUT_COL_INDEX = 4;

        //Work Time Day Off
        private const int WORK_TIME_DAY_OFF_COL_INDEX = 5;

        //Work Time Absence
        private const int WORK_TIME_ABSENCE_COL_INDEX = 6;

        //OverTime Early
        private const int OVER_TIME_EARLY_COL_INDEX = 7;

        //OverTime Normal
        private const int OVER_TIME_NORMAL_COL_INDEX = 8;

        //OverTime Sat
        private const int OVER_TIME_SAT_COL_INDEX = 9;

        //OverTime Late 
        private const int OVER_TIME_LATE_COL_INDEX = 10;

        //OverTime Sun
        private const int OVER_TIME_SUN_COL_INDEX = 11;

        //OverTime Holiday
        private const int OVER_TIME_HOLIDAY_COL_INDEX = 12;
        #endregion Contanst Excel

        #region Properties
        /// <summary>
        /// Month
        /// </summary>
        public int Month { get; set; }

        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }
        #endregion

        #region Method
        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<ListEmployeeInMonthExcelList> lstData = this.GetListByCondForListEmployeeInMonthExcel(Month, Year);

            if (lstData.Count != 0)
            {
                //Create Sheet
                wb = this.CreateWorkbook("List Employee in Month");

                // Get Sheet
                ISheet sheet = wb.GetSheet("List Employee in Month");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //Fill data
                this.FillData(wb, sheet, lstData);
            }

            return wb;
        }

        /// <summary>
        /// Get List By Cond For List EmployeeInMonth Excel
        /// </summary>
        /// <param name="Month"></param>
        /// <param name="Year"></param>
        /// <returns></returns>
        private IList<ListEmployeeInMonthExcelList> GetListByCondForListEmployeeInMonthExcel(int Month, int Year)
        {
            IList<ListEmployeeInMonthExcelList> results = null;

            using (DB db = new DB())
            {
                WorkService workService = new WorkService(db);
                results = workService.GetListByCondForListEmployeeInMonthExcel(Month, Year);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            string curDate = string.Empty;

            //QuoteNo
            ICell cellCreation = row1.GetCell(0);
            string creationDate = "Month: " + Month + "/" + Year;
            cellCreation.SetCellValue(creationDate);
        }

        /// <summary>
        /// Fill Data
        /// </summary>
        /// <param name="wb"></param>
        /// <param name="sheet"></param>
        /// <param name="lstData">IList<ListEmployeeInMonthExcelList></param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<ListEmployeeInMonthExcelList> lstData)
        {
            int rowStart = 6;
            for (int k = 0; k < lstData.Count; k++)
            {
                this.CopyRow(wb, sheet, 5, rowStart + k);

                IRow rowTemp = sheet.GetRow(rowStart + k);

                rowTemp.GetCell(Employee).SetCellValue(lstData[k].DisplayName);

                rowTemp.GetCell(WORK_TIME_WORK_COL_INDEX).SetCellValue(lstData[k].TimeWork);

                rowTemp.GetCell(WORK_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].TimeWorkLate);

                rowTemp.GetCell(WORK_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].TimeWorkEarly);

                rowTemp.GetCell(WORK_TIME_OUT_COL_INDEX).SetCellValue(lstData[k].TimeWorkOut);

                rowTemp.GetCell(WORK_TIME_DAY_OFF_COL_INDEX).SetCellValue(lstData[k].TimeWorkDayOff);

                rowTemp.GetCell(WORK_TIME_ABSENCE_COL_INDEX).SetCellValue(lstData[k].TimeWorkAbsence);


                rowTemp.GetCell(OVER_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].OverTimeEarly);

                rowTemp.GetCell(OVER_TIME_NORMAL_COL_INDEX).SetCellValue(lstData[k].OverTimeNormal);

                rowTemp.GetCell(OVER_TIME_SAT_COL_INDEX).SetCellValue(lstData[k].OverTimeSat);

                rowTemp.GetCell(OVER_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].OverTimeLate);

                rowTemp.GetCell(OVER_TIME_SUN_COL_INDEX).SetCellValue(lstData[k].OverTimeSun);

                rowTemp.GetCell(OVER_TIME_HOLIDAY_COL_INDEX).SetCellValue(lstData[k].OverTimeHoliday);

                //------------------------------Start Set Row Height-----------------------------------------------------------

                IRow excRowHeight = sheet.GetRow(rowStart - 1 + k);

                //------------------------------ End Set Row Height-----------------------------------------------------------
            }

            if (lstData.Count <= 1)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 1, -1);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -1);
            }
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;

using NPOI.SS.UserModel;

using DailyReport.DAC;
using DailyReport.Models;

namespace DailyReport.Reports.EXCEL
{
    /// <summary>
    /// Class EmployeeDetailInYear Excel
    /// </summary>
    public class EmployeeDetailInYearExcel : BaseExcel
    {
        #region Contanst Excel
        private const int defaultRowLength = 40;
        private const int defaultRowHeight = 210;

        //Sys Month
        private const int SYS_MONTH_COL_INDEX = 0;

        //Work Time  Work
        private const int WORK_TIME_WORK_COL_INDEX = 1;

        //Work Time  Late
        private const int WORK_TIME_LATE_COL_INDEX = 2;

        //Work Time Early
        private const int WORK_TIME_EARLY_COL_INDEX = 3;

        //Work Time Out
        private const int WORK_TIME_OUT_COL_INDEX = 4;

        //Work Time Day Off
        private const int WORK_TIME_DAY_OFF_COL_INDEX = 5;

        //Work Time Absence
        private const int WORK_TIME_ABSENCE_COL_INDEX = 6;

        //OverTime Early
        private const int OVER_TIME_EARLY_COL_INDEX = 7;

        //OverTime Normal
        private const int OVER_TIME_NORMAL_COL_INDEX = 8;

        //OverTime Sat
        private const int OVER_TIME_SAT_COL_INDEX = 9;

        //OverTime Late 
        private const int OVER_TIME_LATE_COL_INDEX = 10;

        //OverTime Sun
        private const int OVER_TIME_SUN_COL_INDEX = 11;

        //OverTime Holiday
        private const int OVER_TIME_HOLIDAY_COL_INDEX = 12;
        #endregion Contanst Excel

        #region Properties
        /// <summary>
        /// Staff ID
        /// </summary>
        public int StaffID { get; set; }

        /// <summary>
        /// Staff Name
        /// </summary>
        public string StaffNm { get; set; }

        /// <summary>
        /// Year
        /// </summary>
        public int Year { get; set; }
        #endregion

        #region Method
        /// <summary>
        /// Output Excel
        /// </summary>
        /// <returns></returns>
        public IWorkbook OutputExcel()
        {
            IWorkbook wb = null;
            IList<EmployeeDetailInYearExcelList> lstData = this.GetListByCondForEmployeeDetailInYearExcel(this.StaffID, this.Year);

                //Create Sheet
                wb = this.CreateWorkbook("Employee Detail in Year");

                // Get Sheet
                ISheet sheet = wb.GetSheet("Employee Detail In Year");

                //Set data header
                this.SetHeaderDataForExcel(sheet);

                //SetTotalDataForExcel
                this.SetTotalDataForExcel(sheet, lstData);
                //Fill data
                this.FillData(wb, sheet, lstData);

            return wb;
        }

        /// <summary>
        /// Get List By Cond For EmployeeDetailInYear Excel
        /// </summary>
        /// <param name="staffID">int</param>
        /// <param name="year">int</param>
        /// <returns>IList<EmployeeDetailInYearExcelList><QuotationeExcel></returns>
        private IList<EmployeeDetailInYearExcelList> GetListByCondForEmployeeDetailInYearExcel(int staffID, int year)
        {
            IList<EmployeeDetailInYearExcelList> results = null;

            using (DB db = new DB())
            {
                WorkService workService = new WorkService(db);
                results = workService.GetListByCondForEmployeeDetailInYearExcel(staffID, year);
            }

            return results;
        }

        /// <summary>
        /// Set Header Data For Excel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        private void SetHeaderDataForExcel(ISheet sheet)
        {
            //--------------- Row 1 ----------------
            IRow row1 = sheet.GetRow(1);

            //employee
            ICell cellEmployee = row1.GetCell(0);
            string employee = "Employee Name: " + this.StaffNm;
            cellEmployee.SetCellValue(employee);

            //--------------- Row 2 ----------------
            IRow row2 = sheet.GetRow(2);
            //Year
            ICell cellMonth = row2.GetCell(0);
            string YearValue = "Year: " + this.Year;
            cellMonth.SetCellValue(YearValue);
        }

        /// <summary>
        /// SetTotalDataInYear
        /// </summary>
        /// <param name="lstData">IList<EmployeeDetailInYearExcelList></param>
        /// <returns>EmployeeDetailInYearExcelList</returns>
        private EmployeeDetailInYearExcelList SetTotalDataInYear(IList<EmployeeDetailInYearExcelList> lstData)
        {
            EmployeeDetailInYearExcelList lstCountData = new EmployeeDetailInYearExcelList();
            for (int i = 0; i < lstData.Count; i++)
            {
                lstCountData.TimeWorkHour = lstCountData.TimeWorkHour + lstData[i].TimeWorkHour;
                lstCountData.TimeWorkMinute = lstCountData.TimeWorkMinute + lstData[i].TimeWorkMinute;
                lstCountData.CountTimeWork = lstCountData.CountTimeWork + lstData[i].CountTimeWork;

                lstCountData.TimeLateHour = lstCountData.TimeLateHour + lstData[i].TimeLateHour;
                lstCountData.TimeLateMinute = lstCountData.TimeLateMinute + lstData[i].TimeLateMinute;
                lstCountData.CountTimeLate = lstCountData.CountTimeLate + lstData[i].CountTimeLate;

                lstCountData.TimeEarlyHour = lstCountData.TimeEarlyHour + lstData[i].TimeEarlyHour;
                lstCountData.TimeEarlyMinute = lstCountData.TimeEarlyMinute + lstData[i].TimeEarlyMinute;
                lstCountData.CountTimeEarly = lstCountData.CountTimeEarly + lstData[i].CountTimeEarly;

                lstCountData.TimeOutHour = lstCountData.TimeOutHour + lstData[i].TimeOutHour;
                lstCountData.TimeOutMinute = lstCountData.TimeOutMinute + lstData[i].TimeOutMinute;
                lstCountData.CountTimeOut = lstCountData.CountTimeOut + lstData[i].CountTimeOut;

                lstCountData.DayOff = lstCountData.DayOff + lstData[i].DayOff;
                lstCountData.CountTimeWorkDayOff = lstCountData.CountTimeWorkDayOff + lstData[i].CountTimeWorkDayOff;

                lstCountData.Absence = lstCountData.Absence + lstData[i].Absence;
                lstCountData.CountTimeWorkAbsence = lstCountData.CountTimeWorkAbsence + lstData[i].CountTimeWorkAbsence;

                lstCountData.OTEarlyHour = lstCountData.OTEarlyHour + lstData[i].OTEarlyHour;
                lstCountData.OTEarlyMinute = lstCountData.OTEarlyMinute + lstData[i].OTEarlyMinute;
                lstCountData.CountOTEarly = lstCountData.CountOTEarly + lstData[i].CountOTEarly;

                lstCountData.OTNormal1Hour = lstCountData.OTNormal1Hour + lstData[i].OTNormal1Hour;
                lstCountData.OTNormal1Minute = lstCountData.OTNormal1Minute + lstData[i].OTNormal1Minute;
                lstCountData.CountOTNormal1 = lstCountData.CountOTNormal1 + lstData[i].CountOTNormal1;

                lstCountData.OTSatHour = lstCountData.OTSatHour + lstData[i].OTSatHour;
                lstCountData.OTSatMinute = lstCountData.OTSatMinute + lstData[i].OTSatMinute;
                lstCountData.CountOTSat = lstCountData.CountOTSat + lstData[i].CountOTSat;

                lstCountData.OTLateHour = lstCountData.OTLateHour + lstData[i].OTLateHour;
                lstCountData.OTLateMinute = lstCountData.OTLateMinute + lstData[i].OTLateMinute;
                lstCountData.CountOTLate = lstCountData.CountOTLate + lstData[i].CountOTLate;

                lstCountData.OTSunHour = lstCountData.OTSunHour + lstData[i].OTSunHour;
                lstCountData.OTSunMinute = lstCountData.OTSunMinute + lstData[i].OTSunMinute;
                lstCountData.CountOTSun = lstCountData.CountOTSun + lstData[i].CountOTSun;

                lstCountData.OTHoliday2Hour = lstCountData.OTHoliday2Hour + lstData[i].OTHoliday2Hour;
                lstCountData.OTHoliday2Minute = lstCountData.OTHoliday2Minute + lstData[i].OTHoliday2Minute;
                lstCountData.CountOTHoliday2 = lstCountData.CountOTHoliday2 + lstData[i].CountOTHoliday2;
            }
            return lstCountData;
        }

        /// <summary>
        /// SetTotalDataForExcel
        /// </summary>
        /// <param name="sheet">ISheet</param>
        /// <param name="lstData">IList<EmployeeDetailInYearExcelList></param>
        private void SetTotalDataForExcel(ISheet sheet, IList<EmployeeDetailInYearExcelList> lstData)
        {
            //--------------- Row 7 ----------------
            IRow row = sheet.GetRow(7);

            //ICellWork
            ICell cellTimeWork = row.GetCell(WORK_TIME_WORK_COL_INDEX);

            //ICellLate
            ICell cellTimeLate = row.GetCell(WORK_TIME_LATE_COL_INDEX);

            //ICellEarly
            ICell cellTimeEarly = row.GetCell(WORK_TIME_EARLY_COL_INDEX);

            //ICellOut
            ICell cellTimeOut = row.GetCell(WORK_TIME_OUT_COL_INDEX);

            //ICellDayOff
            ICell cellDayOff = row.GetCell(WORK_TIME_DAY_OFF_COL_INDEX);

            //ICellAbsence
            ICell cellAbsence = row.GetCell(WORK_TIME_ABSENCE_COL_INDEX);

            //ICellOTEarly
            ICell cellOTEarly = row.GetCell(OVER_TIME_EARLY_COL_INDEX);

            //ICellOTNormal
            ICell cellNormal = row.GetCell(OVER_TIME_NORMAL_COL_INDEX);

            //ICellOTSat
            ICell cellOTSat = row.GetCell(OVER_TIME_SAT_COL_INDEX);

            //ICellOTLate
            ICell cellLate = row.GetCell(OVER_TIME_LATE_COL_INDEX);

            //ICellOTSun
            ICell cellOTSun = row.GetCell(OVER_TIME_SUN_COL_INDEX);

            //ICellOTHoliday
            ICell cellHoliday = row.GetCell(OVER_TIME_HOLIDAY_COL_INDEX);

            EmployeeDetailInYearExcelList lstCountData = SetTotalDataInYear(lstData);

            if (lstCountData != null)
            {
                cellTimeWork.SetCellValue(lstCountData.CountTimeWorkStr + Environment.NewLine + lstCountData.TimeWork);
                cellTimeLate.SetCellValue(lstCountData.CountTimeLateStr + Environment.NewLine + lstCountData.TimeLate);
                cellTimeEarly.SetCellValue(lstCountData.CountTimeEarlyStr + Environment.NewLine + lstCountData.TimeEarly);
                cellTimeOut.SetCellValue(lstCountData.CountTimeOutStr + Environment.NewLine + lstCountData.TimeOut);
                cellDayOff.SetCellValue(lstCountData.CountTimeWorkDayOffStr + Environment.NewLine + lstCountData.DayOffStr);
                cellAbsence.SetCellValue(lstCountData.CountTimeWorkAbsenceStr + Environment.NewLine + lstCountData.AbsenceStr);
                cellOTEarly.SetCellValue(lstCountData.CountOTEarlyStr + Environment.NewLine + lstCountData.OTEarly);
                cellNormal.SetCellValue(lstCountData.CountOTNormal1Str + Environment.NewLine + lstCountData.OTNormal1);
                cellOTSat.SetCellValue(lstCountData.CountOTSatStr + Environment.NewLine + lstCountData.OTSat);
                cellLate.SetCellValue(lstCountData.CountOTLateStr + Environment.NewLine + lstCountData.OTLate);
                cellOTSun.SetCellValue(lstCountData.CountOTSunStr + Environment.NewLine + lstCountData.OTSun);
                cellHoliday.SetCellValue(lstCountData.CountOTHoliday2Str + Environment.NewLine + lstCountData.OTHoliday2);
            }
        }

        /// <summary>
        /// Set Full Data
        /// </summary>
        /// <param name="lstData">IList<EmployeeDetailInYearExcelList></param>
        /// <returns>IList<EmployeeDetailInYearExcelList></returns>
        private IList<EmployeeDetailInYearExcelList> SetFullData(IList<EmployeeDetailInYearExcelList> lstData)
        {
            bool ok = false;
            IList<EmployeeDetailInYearExcelList> lstDataNew = new List<EmployeeDetailInYearExcelList>();
            EmployeeDetailInYearExcelList rowNull = new EmployeeDetailInYearExcelList();
            for (int i = 1; i <= 12; i++)
            {
                for (int j = 0; j < lstData.Count; j++)
                {
                    if (i == lstData[j].WorkMonth)
                    {
                        rowNull = lstData[j];
                        ok = true;
                        break;
                    }
                }
                if (ok)
                {
                    lstDataNew.Add(rowNull);
                    rowNull = new EmployeeDetailInYearExcelList();
                    ok = false;
                }
                else
                {
                    rowNull = new EmployeeDetailInYearExcelList();
                    rowNull.WorkMonth = i;
                    rowNull.WorkYear = this.Year;
                    lstDataNew.Add(rowNull);
                }
            }
            return lstDataNew;
        }

        /// <summary>
        /// Fill Data
        /// </summary>
        /// <param name="wb"></param>
        /// <param name="sheet"></param>
        /// <param name="lstData">IList<EmployeeDetailInYearExcelList></param>
        private void FillData(IWorkbook wb, ISheet sheet, IList<EmployeeDetailInYearExcelList> lstData)
        {
            lstData = SetFullData(lstData);
            int rowStart = 7;
            for (int k = 0; k < lstData.Count; k++)
            {
                this.CopyRow(wb, sheet, 6, rowStart + k);

                IRow rowTemp = sheet.GetRow(rowStart + k);

                rowTemp.GetCell(SYS_MONTH_COL_INDEX).SetCellValue(lstData[k].WorkMMYYYY);

                rowTemp.GetCell(WORK_TIME_WORK_COL_INDEX).SetCellValue(lstData[k].CountTimeWorkStr + Environment.NewLine + lstData[k].TimeWork);

                rowTemp.GetCell(WORK_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].CountTimeLateStr + Environment.NewLine + lstData[k].TimeLate);

                rowTemp.GetCell(WORK_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].CountTimeEarlyStr + Environment.NewLine + lstData[k].TimeEarly);

                rowTemp.GetCell(WORK_TIME_OUT_COL_INDEX).SetCellValue(lstData[k].CountTimeOutStr + Environment.NewLine + lstData[k].TimeOut);

                rowTemp.GetCell(WORK_TIME_DAY_OFF_COL_INDEX).SetCellValue(lstData[k].CountTimeWorkDayOffStr + Environment.NewLine + lstData[k].DayOffStr);

                rowTemp.GetCell(WORK_TIME_ABSENCE_COL_INDEX).SetCellValue(lstData[k].CountTimeWorkAbsenceStr + Environment.NewLine + lstData[k].AbsenceStr);

                rowTemp.GetCell(OVER_TIME_EARLY_COL_INDEX).SetCellValue(lstData[k].CountOTEarlyStr + Environment.NewLine + lstData[k].OTEarly);

                rowTemp.GetCell(OVER_TIME_NORMAL_COL_INDEX).SetCellValue(lstData[k].CountOTNormal1Str + Environment.NewLine + lstData[k].OTNormal1);

                rowTemp.GetCell(OVER_TIME_SAT_COL_INDEX).SetCellValue(lstData[k].CountOTSatStr + Environment.NewLine + lstData[k].OTSat);

                rowTemp.GetCell(OVER_TIME_LATE_COL_INDEX).SetCellValue(lstData[k].CountOTLateStr + Environment.NewLine + lstData[k].OTLate);

                rowTemp.GetCell(OVER_TIME_SUN_COL_INDEX).SetCellValue(lstData[k].CountOTSunStr + Environment.NewLine + lstData[k].OTSun);

                rowTemp.GetCell(OVER_TIME_HOLIDAY_COL_INDEX).SetCellValue(lstData[k].CountOTHoliday2Str + Environment.NewLine + lstData[k].OTHoliday2);

                //------------------------------Start Set Row Height-----------------------------------------------------------

                IRow excRowHeight = sheet.GetRow(rowStart - 1 + k);

                //------------------------------ End Set Row Height-----------------------------------------------------------
            }

            if (lstData.Count <= 1)
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart + 1, -1);
            }
            else
            {
                //Delete row template
                sheet.ShiftRows(rowStart, lstData.Count + rowStart, -1);
            }
        }
        #endregion
    }
}
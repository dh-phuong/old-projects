﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using Microsoft.Reporting.WebForms;
using DailyReport.DAC;

namespace DailyReport.Reports.PDF
{
    public class PayslipReport : BaseReport<PayslipReport>
    {

    }

    public class PayslipPDF : BaseReport
    {
        /// <summary>
        /// Get LoginInfo
        /// </summary>
        public LoginInfo LoginInfo;

        public LocalReport GetLocalReport(LocalReport localReport, int id)
        {
            localReport.EnableExternalImages = true;
            this.LoadData(localReport, id);
            localReport.Refresh();

            return localReport;
        }

        private ReportParameterCollection InitParams(int id)
        {
            ReportParameterCollection paras = new ReportParameterCollection();

            //-------------------------------
            //  Header Page
            //-------------------------------      
            M_Company company = base.GetCompany();
            paras.Add(new ReportParameter("companyName", company.CompanyName1));
            paras.Add(new ReportParameter("payrollCycle", "wwwwwww"));

            M_User _user =new M_User();
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                _user = userSer.GetByID(id);
                
            }

            paras.Add(new ReportParameter("employeeCode", Utilities.EditDataUtil.ToFixCodeShow(_user.UserCD, M_User.MAX_USER_CODE_SHOW)));
            paras.Add(new ReportParameter("employeeName", _user.UserName1));

            paras.Add(new ReportParameter("contractSalary", "wwwwwww"));
            paras.Add(new ReportParameter("standardDays", "wwwwwww"));
            paras.Add(new ReportParameter("paidDays", "wwwwwww"));
            paras.Add(new ReportParameter("dependents", "wwwwwww"));
            paras.Add(new ReportParameter("paidSalary", "10,000,000"));

            return paras;
        }

        private void LoadData(LocalReport localReport, int id)
        {
            localReport.ReportPath = Server.MapPath("~/Reports/RptUserInfo.rdlc");
            localReport.SetParameters(InitParams(id));
        }
    }
}

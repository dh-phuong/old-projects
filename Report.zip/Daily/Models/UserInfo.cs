﻿using System;
using System.Data.Common;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class UserInfo Model
    /// </summary>
    [Serializable]
    public class UserInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string UserCD { get; set; }
        public string LoginID { get; set; }
        public string UserName1 { get; set; }
        public string UserName2 { get; set; }
        public string GroupCD { get; set; }
        public string GroupName { get; set; }
        public string Password { get; set; }
        public int StatusFlag { get; set; }
        public int Color { get; set; }

        //ISV-TRUC Add new 2015/02/26
        public string CssStyle { get; set; }


        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public UserInfo(DbDataReader dr)
        {

            ISecurity sec = Security.Instance;

            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserCD = EditDataUtil.ToFixCodeShow((string)dr["UserCD"], M_User.MAX_USER_CODE_SHOW);
            this.LoginID = (string)dr["LoginID"];
            this.UserName1 = (string)dr["UserName1"];
            this.UserName2 = (string)dr["UserName2"];
            this.GroupCD = EditDataUtil.ToFixCodeShow((string)dr["GroupCD"], M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);
            this.GroupName = (string)dr["GroupName"];
            this.Password = sec.Decrypt((string)dr["Password"]);
            this.StatusFlag = int.Parse(dr["StatusFlag"].ToString());
            this.Color = -1;
            if (this.StatusFlag == (int)DeleteFlag.Deleted)
            {
                this.Color = (int)ColorList.Danger;
            }
            this.CssStyle = string.Empty;
        }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        public UserInfo()
        {
            this.RowNumber = 0;
            this.UserCD = string.Empty;
            this.LoginID = string.Empty;
            this.UserName1 = string.Empty;
            this.UserName2 = string.Empty;
            this.GroupCD = string.Empty;
            this.GroupName = string.Empty;
            this.Password = string.Empty;
            this.CssStyle = string.Empty;
        }
    }

    /// <summary>
    /// Class UserSearchInfo Model
    /// </summary>
    [Serializable]
    public class UserSearchInfo
    {
        public long RowNumber { get; set; }
        public string UserCD { get; set; }
        public string LoginID { get; set; }
        public string UserName1 { get; set; }
        public string UserName2 { get; set; }
        public string GroupCD { get; set; }
        public string GroupName { get; set; }
        public string Password { get; set; }
        public string DepartmentName { get; set; }
        public string Position1 { get; set; }
        public string Position2 { get; set; }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public UserSearchInfo(DbDataReader dr)
        {
            ISecurity sec = Security.Instance;

            this.RowNumber = (long)dr["RowNumber"];
            this.UserCD = EditDataUtil.ToFixCodeShow((string)dr["UserCD"], M_User.MAX_USER_CODE_SHOW);
            this.LoginID = (string)dr["LoginID"];
            this.UserName1 = (string)dr["UserName1"];
            this.UserName2 = (string)dr["UserName2"];
            this.GroupCD = EditDataUtil.ToFixCodeShow((string)dr["GroupCD"], M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);
            this.GroupName = (string)dr["GroupName"];
            this.Password = sec.Decrypt((string)dr["Password"]);
            this.DepartmentName = (string)dr["DepartmentName"];
            this.Position1 = (string)dr["Position1"];
            this.Position2 = (string)dr["Position2"];

        }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        public UserSearchInfo()
        {
            this.RowNumber = 0;
            this.UserCD = null;
            this.LoginID = null;
            this.UserName1 = null;
            this.UserName2 = null;
            this.GroupCD = null;
            this.GroupName = null;
            this.Password = null;
            this.DepartmentName = null;
            this.Position1 = null;
            this.Position2 = null;
        }
    }

    public class M_UserInfo
    {
        #region Property

        public int ID { get; set; }

        /// <summary>
        /// UserCD
        /// </summary>
        public string UserCD { get; set; }

        /// <summary>
        /// Get or set LoginID
        /// </summary>
        public string LoginID { get; set; }

        /// <summary>
        /// Get or set UserName1
        /// </summary>
        public string UserName1 { get; set; }

        /// <summary>
        /// Get or set UserName2
        /// </summary>
        public string UserName2 { get; set; }

        /// <summary>
        /// Get or set Position1
        /// </summary>
        public string Position1 { get; set; }

        /// <summary>
        /// Get or set Position2
        /// </summary>
        public string Position2 { get; set; }

        /// <summary>
        /// Get or set Email
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Get or set Staff ID
        /// </summary>
        public int StaffID { get; set; }
       
        /// <summary>
        /// Get or set Group ID
        /// </summary>
        public int GroupID { get; set; }

        /// <summary>
        /// Get or set Group ID
        /// </summary>
        public int DepartmentID { get; set; }

        /// <summary>
        /// Get or set Group ID
        /// </summary>
        public string DepartmentCD { get; set; }

        /// <summary>
        /// Get or set Group ID
        /// </summary>
        public string DepartmentName { get; set; }

        /// <summary>
        /// Get or set Status Flag
        /// </summary>
        public short StatusFlag  { get; set; }

        /// <summary>
        /// CreateDate
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// CreateUID
        /// </summary>
        public int CreateUID { get; set; }
        /// <summary>
        /// UpdateDate
        /// </summary>
        public DateTime UpdateDate { get; set; }
        /// <summary>
        /// UpdateUID
        /// </summary>
        public int UpdateUID { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_User
        /// </summary>
        public M_UserInfo()
        {

        }

        /// <summary>
        /// Contructor M_User
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_UserInfo(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.CreateDate = (DateTime)dr["CreateDate"];
            this.CreateUID = (int)dr["CreateUID"];
            this.UpdateDate = (DateTime)dr["UpdateDate"];
            this.UpdateUID = (int)dr["UpdateUID"];

            this.UserCD = (string)dr["UserCD"];
            this.LoginID = (string)dr["LoginID"];
            this.UserName1 = (string)dr["UserName1"];
            this.UserName2 = (string)dr["UserName2"];
            this.Position1 = (string)dr["Position1"];
            this.Position2 = (string)dr["Position2"];
            this.Email = (string)dr["Email"];

            this.StaffID = (int)dr["StaffID"];
            this.GroupID = (int)dr["GroupID"];
            this.DepartmentID = (int)dr["DepartmentID"];
            this.DepartmentCD = (string)dr["DepartmentCD"];
            this.DepartmentName = (string)dr["DepartmentName"];
            this.StatusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
        }
        #endregion
    }
}

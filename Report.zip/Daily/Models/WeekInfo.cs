﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{
    [Serializable]
    public class WeekInfo
    {
        public M_UserInfo info { get; set; }
        public DayOfWeekInfo SunDay { get; set; }
        public DayOfWeekInfo MonDay { get; set; }
        public DayOfWeekInfo TueDay { get; set; }
        public DayOfWeekInfo WedDay { get; set; }
        public DayOfWeekInfo ThuDay { get; set; }
        public DayOfWeekInfo FriDay { get; set; }
        public DayOfWeekInfo SatDay { get; set; }

        public void AddDayInfo(DayOfWeekInfo dayInfo, bool isDayOf = true)
        {
            if (isDayOf)
            {
                switch (dayInfo.Day.DayOfWeek)
                {
                    case DayOfWeek.Sunday:
                        this.SunDay = dayInfo;
                        break;
                    case DayOfWeek.Monday:
                        this.MonDay = dayInfo;
                        break;
                    case DayOfWeek.Tuesday:
                        this.TueDay = dayInfo;
                        break;
                    case DayOfWeek.Wednesday:
                        this.WedDay = dayInfo;
                        break;
                    case DayOfWeek.Thursday:
                        this.ThuDay = dayInfo;
                        break;
                    case DayOfWeek.Friday:
                        this.FriDay = dayInfo;
                        break;
                    case DayOfWeek.Saturday:
                        this.SatDay = dayInfo;
                        break;
                }
            }
            else
            {
                this.SunDay = dayInfo;
            }
        }
    }
}

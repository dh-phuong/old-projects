﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Approved Info Model
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    [Serializable]
    public class ApprovedWorkInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string ApproveNo { get; set; }
        public int UserID { get; set; }
        public string Username { get; set; }
        public DateTime ConfirmDate { get; set; }
        public string ConfirmDateDisp { get { return ConfirmDate == DateTime.MinValue ? "" : ConfirmDate.ToString("dd/MM/yyyy"); } }
        public short Status { get; set; }
        public int TypeApplyID { get; set; }
        public string Typename { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public string StartDateStr { get; set; }
        public string EndDateStr { get; set; }
        public string Content { get; set; }
        public short DeleteFlag { get; set; }
        public int Color { get; set; }


        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ApprovedWorkInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.ApproveNo = (string)dr["ApproveNo"];
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.Username = (string)dr["Username2"];

            if (dr["ConfirmDate"] != DBNull.Value)
            {
                this.ConfirmDate = DateTime.Parse(dr["ConfirmDate"].ToString());
            }
           
            this.Status = short.Parse(dr["Status"].ToString());
            this.TypeApplyID = (int)dr["TypeApplyID"];
            this.Typename = (string)dr["TypeName"];
            this.StartDate = DateTime.Parse(dr["StartDate"].ToString());
            this.StartHour = short.Parse(dr["StartHour"].ToString());
            this.StartMinute = short.Parse(dr["StartMinute"].ToString());
            this.EndDate = DateTime.Parse(dr["EndDate"].ToString());
            this.EndHour = short.Parse(dr["EndHour"].ToString());
            this.EndMinute = short.Parse(dr["EndMinute"].ToString());
            this.StartDateStr = (string)dr["StartDateStr"];
            this.EndDateStr = (string)dr["EndDateStr"];
            this.Content = (string)dr["Content"];
            this.DeleteFlag = short.Parse(dr["DeleteFlag"].ToString());
            this.Color = -1;
        }

        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        public ApprovedWorkInfo()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.ApproveNo = string.Empty;
            this.UserID = 0;
            this.Username = string.Empty;
            this.ConfirmDate = DateTime.MinValue;
            this.Status = 0;
            this.TypeApplyID = 0;
            this.Typename = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartHour = 0;
            this.StartMinute = 0;
            this.EndDate = DateTime.MinValue;
            this.EndHour = 0;
            this.EndMinute = 0;
            this.StartDateStr = string.Empty;
            this.EndDateStr = string.Empty;
            this.Content = string.Empty;
            this.DeleteFlag = 0;                       
        }
    }

    [Serializable]
    public class ApproveDetailInfo: M_Base<T_Approve>    
    {        
        public string ApproveNo { get; set; }
        public int UserID { get; set; }
        public string Username { get; set; }
        public DateTime ConfirmDate { get; set; }
        public string ConfirmDateDisp { get { return ConfirmDate == DateTime.MinValue ? "" : ConfirmDate.ToString("dd/MM/yyyy"); } }
        public short StatusApprove { get; set; }
        public string StatusName { get; set; }
        public int TypeApplyID { get; set; }
        public string Typename { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public string Content { get; set; }
        public short DeleteFlag { get; set; }

        /// <summary>
        /// ISV-TRUC Add 2015/03/09
        /// </summary>
        public short ListApproveStatus { get; set; }
        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public ApproveDetailInfo()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public ApproveDetailInfo(DbDataReader dr)
            : base(dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.ApproveNo = (string)dr["ApproveNo"];
            this.Username = (string)dr["Username1"];
            this.UserID = (int)dr["UserID"];
            
            if (dr["ConfirmDate"] != DBNull.Value)
            {
                this.ConfirmDate = (DateTime)dr["ConfirmDate"];
            }

            this.StatusApprove = short.Parse(string.Format("{0}", dr["Status"]));
            this.StatusName = (string)dr["StatusName"];
            this.TypeApplyID = (int)dr["TypeApplyID"];
            this.Typename = (string)dr["TypeName"];
            this.StartDate = (DateTime)dr["StartDate"];
            this.StartHour = short.Parse(string.Format("{0}", dr["StartHour"]));
            this.StartMinute = short.Parse(string.Format("{0}", dr["StartMinute"]));

            this.EndDate = (DateTime)dr["EndDate"];
            this.EndHour = short.Parse(string.Format("{0}", dr["EndHour"]));
            this.EndMinute = short.Parse(string.Format("{0}", dr["EndMinute"]));
            this.ListApproveStatus = short.Parse(string.Format("{0}", dr["ListApproveStatus"]));
            this.Content = (string)dr["Content"];
           
        }

        #endregion
    }


    /// <summary>
    /// ISV-TRUC
    /// 2015/03/09
    /// Add to replace in Approve List Form
    /// </summary>
    [Serializable]
    public class ApprovedResultSearch
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string ApproveNo { get; set; }
        public int UserID { get; set; }
        public string Username { get; set; }
        public DateTime ConfirmDate { get; set; }
        public string ConfirmDateDisp { get { return ConfirmDate == DateTime.MinValue ? "" : ConfirmDate.ToString("dd/MM/yyyy"); } }
        public short Status { get; set; }
        public int TypeApplyID { get; set; }
        public string Typename { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public string StartDateStr { get; set; }
        public string EndDateStr { get; set; }
        public string Content { get; set; }
        public short DeleteFlag { get; set; }
        public int Color { get; set; }
        public short ListApproveStatus { get; set; }
        /// <summary>
        /// Get or set ApprovedText
        /// </summary>
        public string ApprovedText { get; set; }

        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ApprovedResultSearch(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.ApproveNo = (string)dr["ApproveNo"];
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.Username = (string)dr["Username2"];

            if (dr["ConfirmDate"] != DBNull.Value)
            {
                this.ConfirmDate = DateTime.Parse(dr["ConfirmDate"].ToString());
            }

            this.Status = short.Parse(dr["Status"].ToString());
            this.TypeApplyID = (int)dr["TypeApplyID"];
            this.Typename = (string)dr["TypeName"];
            this.StartDate = DateTime.Parse(dr["StartDate"].ToString());
            this.StartHour = short.Parse(dr["StartHour"].ToString());
            this.StartMinute = short.Parse(dr["StartMinute"].ToString());
            this.EndDate = DateTime.Parse(dr["EndDate"].ToString());
            this.EndHour = short.Parse(dr["EndHour"].ToString());
            this.EndMinute = short.Parse(dr["EndMinute"].ToString());
            this.StartDateStr = (string)dr["StartDateStr"];
            this.EndDateStr = (string)dr["EndDateStr"];
            this.Content = (string)dr["Content"];
            this.DeleteFlag = short.Parse(dr["DeleteFlag"].ToString());
            this.ListApproveStatus = short.Parse(string.Format("{0}", dr["ListApproveStatus"]));
            if (this.Status == (int)StatusApprove.Complete)
            {
                this.ApprovedText = "<span class='label label-master' style='width:70px; display: inline-block'>" + "Complete" + "</span>";
            }
            else if (this.Status == (int)StatusApprove.Confirm)
            {
                this.ApprovedText = "<span class='label label-white' style='width:70px; display: inline-block'>" + "Arrival" + "</span>";
            }
            else if (this.Status == (int)StatusApprove.Approve)
            {
                if ((int)this.ListApproveStatus == (int)Models.ApproveListStatusFlag.Approved)
                {
                    this.ApprovedText = "<span class='label label-warning' style='width:70px; display: inline-block'>" + "Approved" + "</span>";
                }
                else
                {
                    this.ApprovedText = "<span class='label label-info' style='width:70px; display: inline-block'>" + "Approving" + "</span>";
                }
            }         
        }

        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        public ApprovedResultSearch()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.ApproveNo = string.Empty;
            this.UserID = 0;
            this.Username = string.Empty;
            this.ConfirmDate = DateTime.MinValue;
            this.Status = 0;
            this.TypeApplyID = 0;
            this.Typename = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartHour = 0;
            this.StartMinute = 0;
            this.EndDate = DateTime.MinValue;
            this.EndHour = 0;
            this.EndMinute = 0;
            this.StartDateStr = string.Empty;
            this.EndDateStr = string.Empty;
            this.Content = string.Empty;
            this.DeleteFlag = 0;
            this.ListApproveStatus = 0;
        }
    }


    /// <summary>
    /// 
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    [Serializable]
    public class WorkConditionSearch
    {
        public string ApproveNo { get; set; }
        public DateTime? ConfirmDateFrm { get; set; }
        public DateTime? ConfirmDateTo { get; set; }
        public int UserID { get; set; }
        public short Status { get; set; }
        public short Type { get; set; }
        public short Invalid { get; set; }
    }

    /// <summary>
    /// 
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    [Serializable]
    public class WorkResultSearch
    {
        public int ID { get; set; }
        public string ApproveNo { get; set; }
        public int UserID { get; set; }
        public DateTime? ConfirmDate { get; set; }
        public string ConfirmDateStr { get; set; }
        public short Status { get; set; }
        public int TypeApplyID { get; set; }
        public string StatusName { get; set; }
        public string TypeName { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public string Content { get; set; }
        public short DeleteFlag { get; set; }

        public string StartDateStr { get; set; }
        public string EndDateStr { get; set; }

        public long RowNumber { get; set; }
        public int Color { get; set; }

        /// <summary>
        /// Contructor Empty
        /// </summary>
        public WorkResultSearch()
        {
            this.ApproveNo = string.Empty;
            this.UserID = 0;
            this.ID = 0;
            this.Status = 0;
            this.StatusName = string.Empty;
            this.TypeApplyID = 0;
            this.TypeName = string.Empty;
            this.ConfirmDate = DateTime.MinValue;
            this.ConfirmDateStr = string.Empty;
            this.StartDate = DateTime.MinValue;            
            this.StartHour = 0;
            this.StartMinute = 0;
            this.EndDate = DateTime.MinValue;
            this.EndHour = 0;
            this.EndMinute = 0;
            this.StartDateStr = string.Empty;
            this.EndDateStr = string.Empty;
            this.Content = string.Empty;
            this.RowNumber = 0;
            this.Color = -1;
        }

        /// <summary>
        /// Constructor by data row
        /// </summary>
        /// <param name="dr"></param>
        public WorkResultSearch(DbDataReader dr)
        {
            this.Color = -1;
            this.ID = (int)dr["ID"];
            this.RowNumber = (long)dr["RowNumber"];
            this.ApproveNo = (string)dr["ApproveNo"];
            this.Status = short.Parse(string.Format("{0}", dr["Status"]));

            //if (this.Status == (short)StatusApprove.Complete)
            //{
            //    this.Color = (int)ColorList.Finish;
            //}
            this.TypeApplyID = (int)dr["TypeApplyID"];
           
            this.StatusName = (string)dr["StatusName"];
            this.TypeName = (string)dr["TypeName"];

            if(dr["ConfirmDate"]!= DBNull.Value)
            {
                this.ConfirmDate = (DateTime)dr["ConfirmDate"];
            }
            this.ConfirmDateStr = this.ConfirmDate != null ? this.ConfirmDate.Value.ToString(Constants.FMT_DATE) : string.Empty;
            this.StartDate = (DateTime)dr["StartDate"];
            this.StartHour = short.Parse(string.Format("{0}", dr["StartHour"]));
            this.StartMinute = short.Parse(string.Format("{0}", dr["StartMinute"]));
            this.EndDate = (DateTime)dr["EndDate"];
            this.EndHour = short.Parse(string.Format("{0}", dr["EndHour"]));
            this.EndMinute = short.Parse(string.Format("{0}", dr["EndMinute"]));

            this.StartDateStr = (string)dr["StartDateStr"];
            this.EndDateStr = (string)dr["EndDateStr"];
            this.Content = (string)dr["Content"];
            if (dr["DeleteFlag"] != DBNull.Value)
            {
                this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
                if ((int)this.DeleteFlag == (int)Models.DeleteFlag.Deleted)
                {
                    this.Color = (int)ColorList.Danger;
                }
            }
        }
    }
}
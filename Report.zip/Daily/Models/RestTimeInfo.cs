﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class RestTime
    {
        public int RestTimeSH { get; set; }
        public int RestTimeSM { get; set; }
        public int RestTimeEH { get; set; }
        public int RestTimeEM { get; set; }

        public DateTime RestTimeS
        {
            get 
            {
                return new DateTime(1, 1, 1).AddHours(RestTimeSH).AddMinutes(RestTimeSM);
            }
        }

        public DateTime RestTimeE
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(RestTimeEH).AddMinutes(RestTimeEM);
            }
        }

        public RestTime()
        { }

        public RestTime(DbDataReader dr)
        {
            RestTimeSH = (int)dr["RestTimeSH"];
            RestTimeSM = (int)dr["RestTimeSM"];
            RestTimeEH = (int)dr["RestTimeEH"];
            RestTimeEM = (int)dr["RestTimeEM"];
        }
    }
}

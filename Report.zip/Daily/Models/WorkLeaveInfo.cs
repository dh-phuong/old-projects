﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    public class WorkLeaveInfo
    {
        #region Contructor
        public WorkLeaveInfo()
            : base()
        {
        }
        #endregion
    }

    public class WorkLeaveDay
    {
        private int L_StartHour { get; set; }
        private int L_StartMinute { get; set; }
        private int L_EndHour { get; set; }
        private int L_EndMinute { get; set; }
        private int L_DurationHour { get; set; }
        private int L_DurationMinute { get; set; }

        private int S_StartHour { get; set; }
        private int S_StartMinute { get; set; }
        private int S_EndHour { get; set; }
        private int S_EndMinute { get; set; }

        public int Type { get; set; }
        public DateTime WorkDate { get; set; }

        public TimeSpan Duration
        {
            get
            {
                TimeSpan ret = ret = new TimeSpan(L_DurationHour, L_DurationMinute, 0);
                return ret;
            }
        }

        public WorkLeaveDay()
            : base()
        {
        }

        public WorkLeaveDay(DbDataReader dr)
        {
            this.L_StartHour = int.Parse(dr["L_StartHour"].ToString());
            this.L_StartMinute = int.Parse(dr["L_StartMinute"].ToString());
            this.L_EndHour = int.Parse(dr["L_EndHour"].ToString());
            this.L_EndMinute = int.Parse(dr["L_EndMinute"].ToString());
            this.L_DurationHour = int.Parse(dr["L_DurationHour"].ToString());
            this.L_DurationMinute = int.Parse(dr["L_DurationMinute"].ToString());

            this.S_StartHour = int.Parse(dr["S_StartHour"].ToString());
            this.S_StartMinute = int.Parse(dr["S_StartMinute"].ToString());
            this.S_EndHour = int.Parse(dr["S_EndHour"].ToString());
            this.S_EndMinute = int.Parse(dr["S_EndMinute"].ToString());
            this.Type = int.Parse(dr["Type"].ToString());
            this.WorkDate = DateTime.Parse(dr["WorkDate"].ToString());
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Province information
    /// </summary>
    [Serializable]
    public class ProvinceInfo
    {
        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set Province code
        /// </summary>
        public string ProvinceCD { get; set; }

        /// <summary>
        /// Get or set province name
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public ProvinceInfo() { }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr"></param>
        public ProvinceInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.RowNumber = (long)dr["RowNumber"];
            this.ProvinceCD = EditDataUtil.ToFixCodeShow((string)dr["ProvinceCD"], M_Province.PROVINCE_CODE_MAX_LEN_SHOW);
            this.ProvinceName = dr["ProvinceName"].ToString();
        }
    }
}

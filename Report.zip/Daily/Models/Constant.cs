﻿
namespace DailyReport.Models
{
    public class Constant
    {
        #region PK,FK,UN Key        

        //dbo.M_Template_WorkDay
        public const string M_Template_WorkDay_FK_Work_Shift_SUN = "M_Template_WorkDay_FK_SunShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_MON = "M_Template_WorkDay_FK_MonShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_TUE = "M_Template_WorkDay_FK_TueShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_WED = "M_Template_WorkDay_FK_WedShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_THU = "M_Template_WorkDay_FK_ThuShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_FRI = "M_Template_WorkDay_FK_FriShiftID";
        public const string M_Template_WorkDay_FK_Work_Shift_SAT = "M_Template_WorkDay_FK_SatShiftID";


        //M_Staff
        public const string M_STAFF_UN = "M_Staff_UN";
        public const string M_STAFF_FK_DEPARTMENTID = "M_Staff_FK_DepartmentID";
        
        //M_WorkingShift
        public const string M_WORKINGSHIFT_UN = "M_Work_Shift_UN";

        //M_Form
        public const string M_FORM_PK = "PK_M_Form";

        //M_Form_Route
        public const string M_FORM_ROUTE_FK = "M_Form_Route_FK_RouteID";
        public const string M_FORM_LINK_FK = "M_Form_Link_FK_RouteID";

        // T_Approve
        public const string T_APPROVE_PK = "PK_T_Approve";
        public const string T_Approve_FK_TypeApplyID = "T_Approve_FK_TypeApplyID";

        //M_Category
        public const string M_CATEGORY_PK = "M_Category_PK";
        public const string M_CATEGORY_UN = "M_Category_UN";
        public const string CATEGORY_ROOT_CODE = "0000";
        public const string CATEGORY_ROOT_NAME = "Root";

        //M_UserStruct
        public const string M_USERSTRUCT_PK = "PK_M_UserStruct";
        public const string M_USERSTRUCT_FK_USERID = "M_UserStruct_FK_UserID";
        //public const string M_CATEGORYSTRUCT_UN = "M_CategoryStruct_UN";

        //M_Company
        public const string M_COMPANY_PK = "M_Company_PK";

        //M_Condition
        public const string M_CONDITION_PK = "M_Condition_PK";
        public const string M_CONDITION_UN = "M_Condition_UN";

        //M_Config_D
        public const string M_CONFIG_D_PK = "PK_M_Config_D";

        //M_Config_H
        public const string M_CONFIG_H_PK = "PK_M_Config_H";
        public const string M_CONFIG_H_UN = "M_Config_H_UN";

        //M_Currency_D
        public const string M_CURRENCY_D_PK = "M_Currency_D_PK";
        public const string M_CURRENCY_D_FK_ID = "M_Currency_D_FK_ID";

        //M_Currency_H
        public const string M_CURRENCY_H_PK = "M_Currency_H_PK";
        public const string M_CURRENCY_H_UN1 = "M_Currency_H_UN1";

        //M_Customer
        public const string M_CUSTOMER_PK = "M_Customer_PK";
        public const string M_CUSTOMER_UN = "M_Customer_UN";
        public const string M_CUSTOMER_UN_TAXCODE = "M_Customer_UN_TAXCode";

        //M_Department
        public const string M_DEPARTMENT_PK = "M_Department_PK";
        public const string M_DEPARTMENT_DEFAULT_CODE = "0000";
        public const string M_DEPARTMENT_UN = "M_Department_UN";

        //M_Form_Link
        public const string M_FORM_LINK_PK = "PK_M_Form_Link";

        //M_Province
        public const string M_PROVINCE_PK = "M_Province_PK";
        public const string M_PROVINCE_UN = "M_Province_UN";
        
        //M_GroupUser_D
        public const string PK_M_GROUPUSER_D = "PK_M_GroupUser_D";
        public const string FK_M_GROUPUSER_M_M_GROUPUSER = "FK_M_GroupUser_M_M_GroupUser";

        //M_GroupUser_H
        public const string M_GROUPUSER_DEFAULT_CODE = "0000";
        public const string M_GROUPUSER_PK = "M_GroupUser_PK";
        public const string M_GROUPUSER_UN = "M_GroupUser_UN";

        //Route
        public const string M_ROUTE_H_PK = "PK_M_Route_H";
        public const string M_ROUTE_H_UN = "M_Route_H_UN";
        public const string M_ROUTE_D_FK_USERID = "M_Route_D_FK_UserID";

        //M_Information
        public const string M_INFORMATION_PK = "M_Information_PK";

        //M_Message
        public const string M_MESSAGE_PK = "M_Message_PK";

        //M_Product
        public const string M_PRODUCT_PK = "PK_M_Product";
        public const string M_PRODUCT_FK_CATEGORY_STRUCT_ID = "M_Product_FK_CategoryStructID";
        public const string M_PRODUCT_FK_CURRENCYID_COST = "M_Product_FK_CurrencyIDCost";
        public const string M_PRODUCT_FK_CURRENCYID_SELL = "M_Product_FK_CurrencyIDSell";
        public const string M_PRODUCT_FK_UNITID_COST = "M_Product_FK_UnitIDCost";
        public const string M_PRODUCT_FK_UNITID_SELL = "M_Product_FK_UnitIDSell";
        public const string M_PRODUCT_UN = "M_Product_UN";

        //M_Setting
        public const string M_SETTING_PK = "M_Setting_PK";

        //M_Unit
        public const string M_UNIT_PK = "M_Unit_PK";
        public const string M_UNIT_UN = "M_Unit_UN";

        //M_User
        public const string M_USER_PK = "M_User_PK";
        public const string M_USER_DEFAULT_CODE = "0000";
        public const string M_USER_FK_GROUPID = "M_User_FK_GroupID";        
        public const string M_USER_FK_PROVINCE_ID = "M_USER_FK_ProvinceID";
        public const string M_USER_UN_CODE = "M_User_UN1";
        public const string M_USER_UN_LOGINID = "M_User_UN2";

        //M_Vendor
        public const string M_VENDOR_PK = "M_Vendor_PK";
        public const string M_VENDOR_UN = "M_Vendor_UN";
        public const string M_VENDOR_UN_TAXCODE = "M_Vendor_UN_TAXCode";

        //M_WorkingDate
        public const string M_WorkingDate_PK = "PK_M_WorkingDate";
        public const string M_WorkingDate_FK_ShiftID = "M_WorkingDate_FK_ShiftID";
        public const string M_WorkingDate_UN = "M_WorkingDate_UN";

        //M_VendorProduct
        public const string M_VENDORPRODUCT_PK = "PK_M_VendorProduct";
        public const string M_VENDORPRODUCT_FK_VENDOR = "M_VendorProduct_FK_Vendor";
        
        //T_Attached
        public const string T_Attached_PK = "PK_T_Attached";

        //T_Apply
        public const string T_Apply_PK = "T_Apply_PK";
        public const string T_Apply_UK = "T_Apply_UN";

        //dbo.T_Work_Vacation
        public const string T_Work_Vacation_PK = "PK_T_Work_Vacation";

        //dbo.T_Work_Absence
        public const string T_Work_Absence_PK = "PK_T_Work_Absence";

        //T_Work_Leave
        public const string T_Work_Leave_PK = "PK_T_Work_Leave";

        //T_Work_Total
        public const string T_Work_Total_PK = "PK_T_Work_Total";
        public const string T_Work_Total_UN = "T_Work_Total_UN";     

        //T_No
        public const string T_NO_PK = "T_No_PK";

        //T_Work
        public const string T_WORK_UN = "T_Work_UN";
        public const string T_WORK_FK_WORKSHIFTID = "T_Work_FK_WorkShiftID";

        //T_Serial
        public const string T_SERIAL_PK = "T_Serial_PK";

        //M_SpecialVacation_H
        public const string M_SPVACATION_H_PK = "M_SpecialVacation_H_PK";
        public const string M_SPVACATION_H_UN = "M_SpecialVacation_H_UN";        

        #endregion

        /// <summary>
        /// Authorized Signature / Seal
        /// </summary>
        public const string DEFAULT_POSITION = "Authorized Signature / Seal";
        /// <summary>
        /// Ký tên và đóng dấu
        /// </summary>
        public const string DEFAULT_REPRESENT = "Ký tên và đóng dấu";

        /// <summary>
        /// Default id
        /// </summary>
        public const int DEFAULT_ID = 1;

        //Currency Master defaul row
        public const int DEFAULT_NUMBER_ROW = 50;

        #region Money

        //Max profit
        public const decimal MAX_PROFIT = 100.00m;

        //Vat Ration
        public const int MAX_VATRATIO = 99;

        //Quantity
        public const decimal MAX_QUANTITY_DECIMAL = 999999.99M;
        public const decimal MAX_QUANTITY_NOT_DECIMAL = 999999M;

        //Unit Price
        public const decimal MAX_UNIT_PRICE_DECIMAL = 9999999999.99M;
        public const decimal MAX_UNIT_PRICE_NOT_DECIMAL = 9999999999M;

        //Sub Total
        public const decimal MAX_SUB_TOTAL_DECIMAL = 9999999999999.99M;
        public const decimal MAX_SUB_TOTAL_NOT_DECIMAL = 9999999999999M;
        public const decimal MIN_SUB_TOTAL_DECIMAL = -9999999999999.99M;
        public const decimal MIN_SUB_TOTAL_NOT_DECIMAL = -9999999999999M;

        //Sub Vat
        public const decimal MAX_SUB_VAT_DECIMAL = 999999999999.99M;
        public const decimal MAX_SUB_VAT_NOT_DECIMAL = 999999999999M;
        public const decimal MIN_SUB_VAT_DECIMAL = -999999999999.99M;
        public const decimal MIN_SUB_VAT_NOT_DECIMAL = -999999999999M;

        //Total
        public const decimal MAX_SUM_TOTAL_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUM_TOTAL_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUM_TOTAL_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUM_TOTAL_NOT_DECIMAL = -99999999999999;

        //VAT
        public const decimal MAX_SUM_VAT_DECIMAL = 9999999999999.99M;
        public const decimal MAX_SUM_VAT_NOT_DECIMAL = 9999999999999;
        public const decimal MIN_SUM_VAT_DECIMAL = -9999999999999.99M;
        public const decimal MIN_SUM_VAT_NOT_DECIMAL = -9999999999999;

        //SUB AMOUNT
        public const decimal MAX_SUB_AMOUNT_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUB_AMOUNT_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUB_AMOUNT_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUB_AMOUNT_NOT_DECIMAL = -99999999999999;

        //SUM AMOUNT
        public const decimal MAX_SUM_AMOUNT_DECIMAL = 99999999999999.99M;
        public const decimal MAX_SUM_AMOUNT_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_SUM_AMOUNT_DECIMAL = -99999999999999.99M;
        public const decimal MIN_SUM_AMOUNT_NOT_DECIMAL = -99999999999999;

        //BALANCE
        public const decimal MAX_BALANCE_DECIMAL = 99999999999999.99M;
        public const decimal MAX_BALANCE_NOT_DECIMAL = 99999999999999;
        public const decimal MIN_BALANCE_DECIMAL = -99999999999999.99M;
        public const decimal MIN_BALANCE_NOT_DECIMAL = -99999999999999;
        
        #endregion

        #region Width Column
        //Sell and Cost
        public const string GRID_WIDTH = "1138px;";
        public const string PRODUCT_COLUMN_WIDTH = "468px;";
        public const string UNITPRICE_PROFIT_COLUMN_WIDTH = "170px;";
        public const string QTY_UNIT_COLUMN_WIDTH = "140px;";
        public const string SUBTOTAL_REMARK_COLUMN_WIDTH = "180px;";
        public const string VAT_RATIO_COLUMN_WIDTH = "180px;";

        //Payment and Deposit
        public const string DATE_WIDTH = "220px;";
        public const string METHOD_WIDTH = "220px;";
        public const string PERSONAL_WIDTH = "165px;";
        public const string AMOUNT_WIDTH = "313px;";
        public const string REMARK_WIDTH = "172px;";
        #endregion
    }
}

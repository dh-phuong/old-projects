﻿using System;
using System.Data.Common;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Collections.Generic;

namespace DailyReport.Models
{
    /// <summary>
    /// Class UserInfo Model
    /// </summary>
    [Serializable]
    public class RouteInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string RouteCD { get; set; }
        public string RouteName { get; set; }
        public int Color { get; set; }
        //ISV-TRUC Add new 2015/02/26
        public string CssStyle { get; set; }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public RouteInfo(DbDataReader dr)
        {

            ISecurity sec = Security.Instance;

            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.RouteCD = (string)dr["RouteCD"];
            this.RouteName = (string)dr["RouteName"];
            this.Color = -1;
            this.CssStyle = string.Empty;
        }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        public RouteInfo()
        {
            this.RowNumber = 0;
            this.RouteCD = string.Empty;
            this.RouteName = string.Empty;
            this.CssStyle = string.Empty;
        }
    }

    /// <summary>
    /// RouteFormInfo
    /// ISV-TRUC
    /// 2015/05/05
    /// </summary>
    [Serializable]
    public class RouteFormInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string RouteCD { get; set; }
        public string RouteName { get; set; }
        public bool HadUsed { get; set; }

        /// <summary>
        /// Constructor class RouteFormInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public RouteFormInfo(DbDataReader dr)
        {

            ISecurity sec = Security.Instance;

            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.RouteCD = (string)dr["RouteCD"];
            this.RouteName = (string)dr["RouteName"];
            this.HadUsed = int.Parse(dr["HadUsed"].ToString()) > 0;
        }

        /// <summary>
        /// Constructor class RouteFormInfo
        /// </summary>
        public RouteFormInfo()
        {
            this.RowNumber = 0;
            this.RouteCD = string.Empty;
            this.RouteName = string.Empty;
            this.HadUsed = false;
        }
    }

    [Serializable]
    public class RouteDetailInfo
    {
        public int colSpan { get; set; }

        /// <summary>
        /// Get or set Level
        /// </summary>
        public int RouteLevel { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string RouteLevelName { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public int Color { get; set; }

        /// <summary>
        /// Get or set list detail
        /// </summary>
        public IList<RouteDetailListInfo> RouteDetailList { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public RouteDetailInfo()
        {

        }
    }

    [Serializable]
    public class RouteProxyUser
    {
        public int UserID { get; set; }
        public int ProxyUserID { get; set; }
        public string ProxyUserCD { get; set; }
        public string ProxyUserName { get; set; }

        public RouteProxyUser() { }

        public RouteProxyUser(M_StaffInfo m_user, int userID)
        {
            this.ProxyUserID = m_user.UserID;
            this.ProxyUserCD = EditDataUtil.ToFixCodeShow(m_user.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
            this.ProxyUserName = m_user.StaffName;
            this.UserID = userID;
        }
    }

    [Serializable]
    public class RouteDetailListInfo
    {
        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public short RouteMethod { get; set; }

        public string RouteMethodStr { get; set; }

        /// <summary>
        /// get or set route proxy user
        /// </summary>
        public IList<RouteProxyUser> RouteProxyUser { get; set; }

        public string UserProxyId { get; set; }       

        /// <summary>
        /// Get or set Level
        /// </summary>
        public int RouteLevel { get; set; }

        /// <summary>
        /// Get or set row number
        /// </summary>
        public int RowNumber { get; set; }

        /// <summary>
        /// Get or set Level
        /// </summary>
        public int UserID { get; set; }

       /// <summary>
        /// Get or set UserCD
        /// </summary>
        public string UserCD { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public string UserName { get; set; }


        /// <summary>
        /// Get or set StaffCD
        /// </summary>
        public string StaffCD { get; set; }

        /// <summary>
        /// StaffName
        /// </summary>
        public string StaffName { get; set; }

        /// <summary>
        /// Get or set DepartmentID
        /// </summary>
        public int DepartmentID { get; set; }

        /// <summary>
        /// Get or set department name
        /// </summary>
        public string DepartmentName { get; set; }

        /// <summary>
        /// Get or set position
        /// </summary>
        public string Position { get; set; }

        /// <summary>
        /// Require num
        /// </summary>
        public decimal? RequireNum { get; set; }

        public short ApplyFlag1 { get; set; }
        public short ApplyFlag2 { get; set; }
        public short ApplyFlag3 { get; set; }
        public short ApplyFlag4 { get; set; }

        public short RejectFlag1 { get; set; }
        public short RejectFlag2 { get; set; }
        public short RejectFlag3 { get; set; }
        public short RejectFlag4 { get; set; }
        public short RejectFlag5 { get; set; }
        public short RejectFlag6 { get; set; }
        public short RejectFlag7 { get; set; }

        public short RemandFlag1 { get; set; }
        public short RemandFlag2 { get; set; }
        public short RemandFlag3 { get; set; }
        public short RemandFlag4 { get; set; }
        public short RemandFlag5 { get; set; }
        public short RemandFlag6 { get; set; }
        public short RemandFlag7 { get; set; }

        public short ApproveFlag1 { get; set; }
        public short ApproveFlag2 { get; set; }
        public short ApproveFlag3 { get; set; }
        public short ApproveFlag4 { get; set; }
        public short ApproveFlag5 { get; set; }
        public short ApproveFlag6 { get; set; }
        public short ApproveFlag7 { get; set; }
        public short ApproveFlag8 { get; set; }
        public short ApproveFlag9 { get; set; }

        public short ReadFlag1 { get; set; }
        public short ReadFlag2 { get; set; }
        public short ReadFlag3 { get; set; }
        public short ReadFlag4 { get; set; }
        public short ReadFlag5 { get; set; }

        public void AddProxyUserId(int userId)
        {
            if (!string.IsNullOrEmpty(this.UserProxyId.Trim()))
            {
                this.UserProxyId += ',';
            }
            this.UserProxyId += userId.ToString();
        }       

        public RouteDetailListInfo()
        {
            this.RowNumber = 0;
            this.UserID = 0;
            //this.UserCD = string.Empty;
            //this.UserName = string.Empty;
            this.StaffCD = string.Empty;
            this.StaffName = string.Empty;
            this.DepartmentID = 0;
            this.DepartmentName = string.Empty;
            this.Position = string.Empty;
            this.RouteLevel = 0;
            this.RouteMethod = 0;
            this.RouteMethodStr = string.Empty;            

            this.UserProxyId = string.Empty;
            this.RequireNum = 0;
            this.UserProxyId = string.Empty;

            this.RouteProxyUser = new List<RouteProxyUser>();
        }

        public RouteDetailListInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());

            this.UserID = int.Parse(dr["UserID"].ToString());

            //if (dr["UserCD"] != DBNull.Value)
            //{
            //    this.UserCD = EditDataUtil.ToFixCodeShow(dr["UserCD"].ToString(), M_User.MAX_USER_CODE_SHOW);
            //}
            
            //this.UserName = dr["UserName"].ToString();

            if (dr["StaffCD"] != DBNull.Value)
            {
                this.StaffCD = EditDataUtil.ToFixCodeShow(dr["StaffCD"].ToString(), M_Staff.MAX_STAFF_CODE_SHOW);
            }

            this.StaffName = dr["StaffName"].ToString();
            if (dr["DepartmentID"] != DBNull.Value)
            {
                this.DepartmentID = int.Parse(dr["DepartmentID"].ToString());
            }
            
            this.DepartmentName = dr["DepartmentName"].ToString();
            this.Position = string.Format("{0}", dr["Position"]);
            this.RouteLevel = (int)dr["RouteLevel"];
            this.RouteMethod = short.Parse(dr["RouteMethod"].ToString());
            this.RouteMethodStr = this.RouteMethod == M_Config_H.METHOD_ROUTE_OR ? "OR" : "AND";
            this.UserProxyId = (string)dr["ProxyApprovalUser"];
            this.RequireNum = decimal.Parse(dr["RequireNum"].ToString());

            this.RouteProxyUser = new List<RouteProxyUser>();

            this.ApplyFlag1 = short.Parse(string.Format("{0}", dr["ApplyFlag1"]));
            this.ApplyFlag2 = short.Parse(string.Format("{0}", dr["ApplyFlag2"]));
            this.ApplyFlag3 = short.Parse(string.Format("{0}", dr["ApplyFlag3"]));
            this.ApplyFlag4 = short.Parse(string.Format("{0}", dr["ApplyFlag4"]));

            this.RejectFlag1 = short.Parse(string.Format("{0}", dr["RejectFlag1"]));
            this.RejectFlag2 = short.Parse(string.Format("{0}", dr["RejectFlag2"]));
            this.RejectFlag3 = short.Parse(string.Format("{0}", dr["RejectFlag3"]));
            this.RejectFlag4 = short.Parse(string.Format("{0}", dr["RejectFlag4"]));
            this.RejectFlag5 = short.Parse(string.Format("{0}", dr["RejectFlag5"]));
            this.RejectFlag6 = short.Parse(string.Format("{0}", dr["RejectFlag6"]));
            this.RejectFlag7 = short.Parse(string.Format("{0}", dr["RejectFlag7"]));

            this.RemandFlag1 = short.Parse(string.Format("{0}", dr["RemandFlag1"]));
            this.RemandFlag2 = short.Parse(string.Format("{0}", dr["RemandFlag2"]));
            this.RemandFlag3 = short.Parse(string.Format("{0}", dr["RemandFlag3"]));
            this.RemandFlag4 = short.Parse(string.Format("{0}", dr["RemandFlag4"]));
            this.RemandFlag5 = short.Parse(string.Format("{0}", dr["RemandFlag5"]));
            this.RemandFlag6 = short.Parse(string.Format("{0}", dr["RemandFlag6"]));
            this.RemandFlag7 = short.Parse(string.Format("{0}", dr["RemandFlag7"]));

            this.ApproveFlag1 = short.Parse(string.Format("{0}", dr["ApproveFlag1"]));
            this.ApproveFlag2 = short.Parse(string.Format("{0}", dr["ApproveFlag2"]));
            this.ApproveFlag3 = short.Parse(string.Format("{0}", dr["ApproveFlag3"]));
            this.ApproveFlag4 = short.Parse(string.Format("{0}", dr["ApproveFlag4"]));
            this.ApproveFlag5 = short.Parse(string.Format("{0}", dr["ApproveFlag5"]));
            this.ApproveFlag6 = short.Parse(string.Format("{0}", dr["ApproveFlag6"]));
            this.ApproveFlag7 = short.Parse(string.Format("{0}", dr["ApproveFlag7"]));
            this.ApproveFlag8 = short.Parse(string.Format("{0}", dr["ApproveFlag8"]));
            this.ApproveFlag9 = short.Parse(string.Format("{0}", dr["ApproveFlag9"]));

            this.ReadFlag1 = short.Parse(string.Format("{0}", dr["ReadFlag1"]));
            this.ReadFlag2 = short.Parse(string.Format("{0}", dr["ReadFlag2"]));
            this.ReadFlag3 = short.Parse(string.Format("{0}", dr["ReadFlag3"]));
            this.ReadFlag4 = short.Parse(string.Format("{0}", dr["ReadFlag4"]));
            this.ReadFlag5 = short.Parse(string.Format("{0}", dr["ReadFlag5"]));

        }
    }

    [Serializable]
    public class RouteModel
    {

        #region Variable
        public int ID { get; set; }
        public string RouteCD { get; set; }
        public string RouteName { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor RouteModel
        /// </summary>
        public RouteModel()
            : base()
        {
            this.ID = -1;
            this.RouteCD = string.Empty;
            this.RouteName = string.Empty;
        }

        /// <summary>
        /// Contructor RouteModel
        /// </summary>
        /// <param name="dr"></param>
        public RouteModel(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.RouteCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["RouteCD"], M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);
            this.RouteName = (string)dr["RouteName"];
        }
        #endregion
    }

    [Serializable]
    public class UserSelect
    {
        public bool SelectFlg { get; set; }
        public int DepartmentId { get; set; }
        public string UserCd { get; set; }

        #region Contructor
        public UserSelect()
            : base()
        {
            this.SelectFlg = false;
            this.DepartmentId = -1;
            this.UserCd = string.Empty;
        }
        #endregion
    }
}
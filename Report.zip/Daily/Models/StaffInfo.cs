﻿using System;
using System.Data.Common;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Collections.Generic;

namespace DailyReport.Models
{
    [Serializable]
    public class M_StaffInfo
    {
        public int UserID { get; set; }
        public int StaffID { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public string Position { get; set; }

        public M_StaffInfo()
        {

        }

        public M_StaffInfo(DbDataReader dr)
        {
            this.StaffID = int.Parse(dr["StaffID"].ToString());
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.StaffCD = dr["StaffCD"].ToString();
            this.StaffName = dr["StaffName"].ToString();
            this.DepartmentID = int.Parse(dr["DepartmentID"].ToString());
            this.DepartmentName = dr["DepartmentName"].ToString();
            this.Position = dr["Position"].ToString();
        }
    }

    /// <summary>
    /// Class StaffInfo Model
    /// </summary>
    [Serializable]
    public class StaffInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public decimal AnnualDays { get; set; }
        public int StatusFlag { get; set; }
        public int Color { get; set; }

        //ISV-TRUC Add new 2015/02/26
        public string CssStyle { get; set; }

        /// <summary>
        /// Constructor class StaffInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public StaffInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.StaffCD = EditDataUtil.ToFixCodeShow((string)dr["StaffCD"], M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = (string)dr["StaffName"];
            this.StatusFlag = int.Parse(dr["StatusFlag"].ToString());
            this.AnnualDays = (decimal)dr["AnnualDays"];
            this.Color = -1;
            if (this.StatusFlag == (int)DeleteFlag.Deleted)
            {
                this.Color = (int)ColorList.Danger;
            }
            this.CssStyle = string.Empty;
        }

        /// <summary>
        /// Constructor class StaffInfo
        /// </summary>
        public StaffInfo()
        {
            this.RowNumber = 0;
            this.StaffCD = string.Empty;
            this.StaffName = string.Empty;
            this.AnnualDays = 0;
            this.CssStyle = string.Empty;
        }
    }

    /// <summary>
    /// Class StaffSalaryInfo Model
    /// </summary>
    [Serializable]
    public class StaffSalaryInfo
    {
        public int ID { get; set; }
        public int salaryNo { get; set; }
        public decimal? BasicSalary { get; set; }
        public decimal? Allowance { get; set; }
        public DateTime? StartDate { get; set; }
        public bool Checked { get; set; }
        public string data { get; set; }

        public StaffSalaryInfo()
        {
            this.ID = -1;
            this.salaryNo = 1;
            this.BasicSalary = null;
            this.Allowance = null;
            this.StartDate = null;
            this.Checked = false;
        }
    }

    /// <summary>
    /// Class StaffDependentInfo Model
    /// </summary>
    [Serializable]
    public class StaffDependentInfo
    {
        public int No { get; set; }
        public DateTime? RegistDate { get; set; }
        public decimal? Dependent { get; set; }
        public decimal? Total { get; set; }
        public bool Checked { get; set; }

        public StaffDependentInfo()
        {
            this.No = 1;
            this.RegistDate = null;
            this.Dependent = null;
            this.Total = null;
            this.Checked = false;
        }
    }

    /// <summary>
    /// Class StaffContractInfo Model
    /// </summary>
    [Serializable]
    public class StaffContractInfo
    {
        public int No { get; set; }
        public string ContractNo { get; set; }
        public int ContractType { get; set; }
        public DateTime? StartDate { get; set; }
        public bool Checked { get; set; }

        public StaffContractInfo()
        {
            this.No = 1;
            this.ContractNo = string.Empty;
            this.ContractType = -1;
            this.StartDate = null;
            this.Checked = false;
        }
    }

    /// <summary>
    /// Class StaffAllowanceInfo Model
    /// </summary>
    [Serializable]
    public class StaffAllowanceInfo
    {
        public int allowanceNo { get; set; }
        public int AllowanceName { get; set; }
        public decimal? Allowance { get; set; }
        public short AccountingFlag { get; set; }
        public bool Checked { get; set; }

        public StaffAllowanceInfo()
        {
            this.allowanceNo = 1;
            this.AllowanceName = -1;
            this.Allowance = null;
            this.AccountingFlag = 0;
            this.Checked = false;
        }
    }

    /// <summary>
    /// Class Annual information
    /// </summary>
    [Serializable]
    public class AnnualDayInfo
    {
        #region Property

        /// <summary>
        /// Get or set StaffID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set StaffCD
        /// </summary>
        public string StaffCD { get; set; }

        /// <summary>
        /// Get or set StaffName
        /// </summary>
        public string StaffName { get; set; }

        /// <summary>
        /// Get or set Start work date
        /// </summary>
        public DateTime StartWorkDate { get; set; }

        /// <summary>
        /// Get or set Old annual days
        /// </summary>
        public decimal OldAnnualDays { get; set; }

        /// <summary>
        /// Get or set Old Annual Date
        /// </summary>
        public DateTime OldAnnualDate { get; set; }

        /// <summary>
        /// Get or set extra days
        /// </summary>
        public decimal ExtraDays { get; set; }

        /// <summary>
        /// Get or set bonus days
        /// </summary>
        public decimal BonusDays { get; set; }

        /// <summary>
        /// Get or set Total
        /// </summary>
        public decimal Total { get; set; }

        /// <summary>
        /// Get or set UpdateDate
        /// </summary>
        public DateTime UpdateDate { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        public AnnualDayInfo()
        { }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr">Database date reader</param>
        public AnnualDayInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.StaffCD = EditDataUtil.ToFixCodeShow(dr["StaffCD"].ToString(), M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = dr["StaffName"].ToString();
            this.StartWorkDate = (DateTime)dr["StartWorkDate"];
            this.OldAnnualDays = decimal.Parse(dr["AnnualDays"].ToString());
            this.OldAnnualDate = (DateTime)dr["AnnualDate"];
            this.UpdateDate = (DateTime)dr["UpdateDate"];
            this.ExtraDays = 0;
            this.BonusDays = 0;
            this.Total = 0;
        }

        #endregion
    }

    /// <summary>
    /// ISV-TRUC
    /// 2015/06/03
    /// </summary>
    [Serializable]
    public class StaffSearchResult
    {
        public long RowNumber { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public string DepartmentCD { get; set; }
        public string DepartmentName { get; set; }
        public string Position { get; set; }
        public string BirthDayStr { get; set; }
        public DateTime BirthDay { get; set; }

        /// <summary>
        /// Constructor class StaffSearchResult
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public StaffSearchResult(DbDataReader dr)
        {
            ISecurity sec = Security.Instance;

            this.RowNumber = (long)dr["RowNumber"];
            this.StaffCD = EditDataUtil.ToFixCodeShow((string)dr["StaffCD"], M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = (string)dr["StaffName"];
            this.DepartmentCD = EditDataUtil.ToFixCodeShow((string)dr["DeptCD"], M_Department.MAX_DEPARTRMENT_CODE_SHOW);
            this.DepartmentName = (string)dr["DeptName"];

            this.Position = (string)dr["Position"];
            this.BirthDay = (DateTime)dr["BirthDay"];
            this.BirthDayStr = this.BirthDay.ToString(Constants.FMT_DATE);
        }

        /// <summary>
        /// Constructor class StaffSearchResult
        /// </summary>
        public StaffSearchResult()
        {
            this.RowNumber = 0;
            this.StaffCD = string.Empty;
            this.StaffName = string.Empty;
            this.Position = string.Empty;
            this.DepartmentCD = string.Empty;
            this.DepartmentName = string.Empty;
            this.BirthDay = DateTime.MinValue;
            this.BirthDayStr = string.Empty;

        }
    }

}

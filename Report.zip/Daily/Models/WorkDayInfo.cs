﻿using System;
using System.Data.Common;
using DailyReport.Models;
using DailyReport.Utilities;


namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/05/29
    /// WorkingDayInfo class
    /// </summary>
    [Serializable]
    public class WorkDayInfo
    {
        /// <summary>
        /// ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// No
        /// </summary>
        public int No { get; set; }

        /// <summary>
        /// WorkingDate
        /// </summary>
        public DateTime WorkDate { get; set; }

        /// <summary>
        /// WorkingDateStr
        /// </summary>
        public string WorkDateStr { get; set; }

        /// <summary>
        /// Day
        /// </summary>
        public string Day { get; set; }

        /// <summary>
        /// ShiftCode
        /// </summary>
        public int? ShiftCode { get; set; }

        /// <summary>
        /// ShiftCodeStr
        /// </summary>
        public string ShiftCodeStr { get; set; }

        /// <summary>
        /// ShiftName
        /// </summary>
        public string ShiftName { get; set; }

        /// <summary>
        /// HolidayDate
        /// </summary>
        public DateTime? HolidayDate { get; set; }

        /// <summary>
        /// ReplaceDate
        /// </summary>
        public DateTime? ReplaceDate { get; set; }

        /// <summary>
        /// UpdateDate
        /// </summary>
        public DateTime UpdateDate { get; set; }

        /// <summary>
        /// DayOff
        /// </summary>
        public int TypeOfDay { get; set; }

        /// <summary>
        /// Constructor class WorkingDayInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public WorkDayInfo(DbDataReader dr)
        {
            ISecurity sec = Security.Instance;

            //No
            this.No = int.Parse(dr["No"].ToString());

            //ID
            this.ID = int.Parse(dr["ID"].ToString());

            //WorkingDate
            this.WorkDate = (DateTime)dr["WorkDate"];

            //HolidayDate
            if (dr["HolidayDate"] != DBNull.Value)
            {
                this.HolidayDate = (DateTime)dr["HolidayDate"];
            }
            else
            {
                this.HolidayDate = null;
            }

            //ReplaceDate
            if (dr["ReplaceDate"] != DBNull.Value)
            {
                this.ReplaceDate = (DateTime)dr["ReplaceDate"];
            }
            else
            {
                this.ReplaceDate = null;
            }

            //Set WorkingDateStr, Day
            if ((this.HolidayDate != null) || (this.WorkDate.DayOfWeek == DayOfWeek.Sunday) || (this.ReplaceDate != null && this.ReplaceDate.Value.DayOfWeek==DayOfWeek.Monday))
            {
                this.WorkDateStr = "<span class='negative-num'>" + string.Format("{0:dd/MM/yyyy}", this.WorkDate) + "</span>";
                this.Day = "<span class='negative-num'>" + this.WorkDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
            }

            else 
            {
                if (this.WorkDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    this.WorkDateStr = "<span class='text-primary'>" + string.Format("{0:dd/MM/yyyy}", this.WorkDate) + "</span>"; 
                    this.Day = "<span class='text-primary'>" + this.WorkDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
                }
                else
                {
                    this.WorkDateStr = string.Format("{0:dd/MM/yyyy}", this.WorkDate);
                this.Day =this.WorkDate.DayOfWeek.ToString().Substring(0, 3) ;
                }
            }

            //ShiftCode
            this.ShiftCode = int.Parse(dr["ShiftCode"].ToString());
            if (this.ShiftCode == 0)
            {
                this.ShiftCodeStr = string.Empty;
            }
            else
            {
                this.ShiftCodeStr = this.ShiftCode.ToString();
            }

            //ShiftName
            this.ShiftName = dr["ShiftName"].ToString();

            //UpdateDate
            this.UpdateDate = (DateTime)dr["UpdateDate"];

            //TypeOfDay
            if (dr["TypeOfDay"] != DBNull.Value)
            {
                this.TypeOfDay = int.Parse(dr["TypeOfDay"].ToString());
            }
        }

        /// <summary>
        /// Constructor class WorkingDayInfo
        /// </summary>
        public WorkDayInfo()
        {
            this.No = 0;
            this.ID = 1;
            this.WorkDate = DateTime.Now;
            this.Day = this.WorkDate.DayOfWeek.ToString().Substring(0, 3);
            this.HolidayDate = null;
            this.ReplaceDate = null;
            this.WorkDateStr = string.Empty;
            this.ShiftCode = null;
            this.ShiftCodeStr = string.Empty;
            this.ShiftName = string.Empty;
            this.UpdateDate = DateTime.Now;
            this.TypeOfDay = 0;
        }
    }
}

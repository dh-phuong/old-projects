﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    [Serializable]
    public class ApproveListInfo : M_Base<T_Approve_List>
    {
        public long RowNumber { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public int ApproveUID { get; set; }
        public string ApproveName { get; set; }
        public DateTime ApproveDate { get; set; }
        public string ApproveDateDisp { get { return ApproveDate == DateTime.MinValue ? "" : ApproveDate.ToString(); } }
        public string Remark { get; set; }
        public int ApproveLevel { get; set; }
        public int RouteMethod { get; set; }
        public short ApproveFlag { get; set; }
        public string ApproveFlagDisp
        {
            get { return ApproveFlag == (short)Approve_Ignore.Cancel ? "Cancel" : "OK"; }
        }
        public int Color { get; set; }
        /// <summary>
        /// Constructor class ApproveListInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ApproveListInfo(DbDataReader dr)
        {
            //this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ApproveID"].ToString());
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.UserName = (string)dr["UserName"];

            if (dr["ApproveUID"] == DBNull.Value)
            {
                this.ApproveUID = -1;
            }
            else
            {
                this.ApproveUID = int.Parse(dr["ApproveUID"].ToString());
            }

            if (dr["ApproveName"] == DBNull.Value)
            {
                this.ApproveName = string.Empty;
            }
            else
            {
                this.ApproveName = (string)dr["ApproveName"].ToString();
            }

            if (dr["ApproveDate"] == DBNull.Value)
            {
                this.ApproveDate = DateTime.MinValue;
            }
            else
            {
                this.ApproveDate = DateTime.Parse(dr["ApproveDate"].ToString());
            }

            this.Remark = dr["Remark"].ToString();

            if (dr["ApproveLevel"] == DBNull.Value)
            {
                this.ApproveLevel = -1;
            }
            else
            {
                this.ApproveLevel = int.Parse(dr["ApproveLevel"].ToString());
            }

            if (dr["RouteMethod"] == DBNull.Value)
            {
                this.RouteMethod = -1;
            }
            else
            {
                this.RouteMethod = int.Parse(dr["RouteMethod"].ToString());
            }

            if (dr["ApproveFlag"] == DBNull.Value)
            {
                this.ApproveFlag = -1;
            }
            else
            {
                this.ApproveFlag = short.Parse(dr["ApproveFlag"].ToString());
            }

            if (short.Parse(dr["ApproveFlag"].ToString()) == (short)Approve_Ignore.OK)
            {
                this.Color = (int)ColorList.Success;
            }
            else
            {
                this.Color = (int)ColorList.Danger;
            }
        }

        /// <summary>
        /// Constructor class ApproveListInfo
        /// </summary>
        public ApproveListInfo()
        {
            this.RowNumber = 0;
            this.ID = -1;
            this.UserID = -1;
            this.UserName = string.Empty;
            this.ApproveUID = -1;
            this.ApproveName = string.Empty;
            this.ApproveDate = DateTime.MinValue;
            this.Remark = string.Empty;
            this.ApproveLevel = -1;
            this.RouteMethod = -1;
            this.ApproveFlag = -1;
            this.Color = -1;
        }
    }



    [Serializable]
    public class ApproveListWork
    {
        public short Level { get; set; }
        public string LevelStr { get; set; }

        public IList<ApproveWork> DetailList { get; set; }
    }

    [Serializable]
    public class ApproveWork
    {
        public int ApproveID { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public int? ApproveUID { get; set; }
        public string ApproveName { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string ApproveDateStr { get; set; }
        public string Remark { get; set; }
        public short ApproveLevel { get; set; }
        public string ApproveLevelStr { get; set; }
        public short RouteMethod { get; set; }
        public string RouteMethodStr { get; set; }
        public short ApproveFlag { get; set; }
        public string ApproveFlagStr { get; set; }

        /// <summary>
        /// Contructor Empty
        /// </summary>
        public ApproveWork()
        {
            this.ApproveID = 0;
            this.UserID = 0;
            this.ApproveUID = 0;
            this.UserName = string.Empty;
            this.ApproveName = string.Empty;
            this.ApproveDate = DateTime.MinValue;
            this.ApproveDateStr = string.Empty;
            this.Remark = string.Empty;
            this.ApproveLevel = 0;
            this.ApproveLevelStr = string.Empty;
            this.ApproveFlag = 0;
            this.ApproveFlagStr = string.Empty;
            this.RouteMethod = -1;
            this.RouteMethodStr = string.Empty;
        }

        /// <summary>
        /// Constructor by data row
        /// </summary>
        /// <param name="dr"></param>
        public ApproveWork(DbDataReader dr)
        {
            if (dr["ApproveID"] != DBNull.Value)
            {
                this.ApproveID = (int)dr["ApproveID"];
            }
            if (dr["UserID"] != DBNull.Value)
            {
                this.UserID = (int)dr["UserID"];
            }

            if (dr["ApproveUID"] != DBNull.Value)
            {
                this.ApproveUID = (int)dr["ApproveUID"];
            }
            if (dr["UserName"] != DBNull.Value)
            {
                this.UserName = (string)dr["UserName"];
            }

            if (dr["ApproveName"] != DBNull.Value)
            {
                this.ApproveName = (string)dr["ApproveName"];
            }

            if (dr["Remark"] != DBNull.Value)
            {
                this.Remark = (string)dr["Remark"];
            }
            if (dr["ApproveDate"] != DBNull.Value)
            {
                this.ApproveDate = (DateTime)dr["ApproveDate"];
                this.ApproveDateStr = this.ApproveDate.Value.ToString(Constants.FMT_DATE);
            }
            if (dr["ApproveFlag"] != DBNull.Value)
            {
                this.ApproveFlag = short.Parse(dr["ApproveFlag"].ToString());
                this.ApproveFlagStr = this.ApproveFlag == 1 ? "OK" : string.Empty;
            }

            if (dr["RouteMethod"] != DBNull.Value)
            {
                this.RouteMethod = short.Parse(dr["RouteMethod"].ToString());
                this.RouteMethodStr = this.RouteMethod == (short)RouteMethods.AND ? RouteMethods.AND.ToString() : RouteMethods.OR.ToString();
            }
            if (dr["RouteLevel"] != DBNull.Value)
            {
                this.ApproveLevel = short.Parse(dr["RouteLevel"].ToString());
                this.ApproveLevelStr = "Level " + this.ApproveLevel.ToString();
            }

        }
    }

}

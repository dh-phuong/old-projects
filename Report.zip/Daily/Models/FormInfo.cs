﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class Config Information Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class FormInfo
    {
        public long RowNumber { get; set; }
        public int FormID { get; set; }
        //public string ConfigCD { get; set; }
        //public string ConfigName { get; set; }

        /// <summary>
        /// Constructor class FormInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public FormInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.FormID = int.Parse(dr["FormID"].ToString());
            //this.ConfigCD = (string)dr["ConfigCD"];
            //this.ConfigName = (string)dr["ConfigName"];
        }

        /// <summary>
        /// Constructor class FormInfo
        /// </summary>
        public FormInfo()
        {
            this.RowNumber = 0;
            this.FormID = -1;
            //this.ConfigCD = string.Empty;
            //this.ConfigName = string.Empty;
        }
    }

    [Serializable]
    public class FormListInfo
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public long RowNumber { get; set; }

        /// <summary>
        /// Contructor FormListInfo with data row
        /// </summary>
        /// <param name="dr"></param>
        public FormListInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = (int)dr["ID"];
            this.Name = (string)dr["Name"];
        }

        /// <summary>
        /// Constructor class FormListInfo with blank
        /// </summary>
        public FormListInfo()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.Name = string.Empty;
        }
    }
}

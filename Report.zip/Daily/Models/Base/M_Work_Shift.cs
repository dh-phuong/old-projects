﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_WorkingShift Model
    /// </summary>
    [Serializable]
    public class M_Work_Shift : M_Base<M_Work_Shift>
    {
        #region Contanst

        /// <summary>
        /// Max length of ShiftCode
        /// </summary>
        public const int SHIFT_CODE_MAX_LENGTH = 5;

        /// <summary>
        /// Max length of ShiftName
        /// </summary>
        public const int SHIFT_NAME_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of HourFrom
        /// </summary>
        public const int SHIFT_HOURFROM_MAX_LENGTH = 5;

        /// <summary>
        /// Max length of HourTo
        /// </summary>
        public const int SHIFT_HOURTO_MAX_LENGTH = 5;

        /// <summary>
        /// Max length of Duration
        /// </summary>
        public const int SHIFT_DURATION_MAX_LENGTH = 5;

        #endregion

        #region Variant

        /// <summary>
        /// ShiftCode
        /// </summary>
        private int shiftcode;

        /// <summary>
        /// ShiftName
        /// </summary>
        private string shiftname;

        /// <summary>
        /// HourFrom
        /// </summary>
        private int? starthour;

        /// <summary>
        /// minutefrom
        /// </summary>
        private int? startminute;

        /// <summary>
        /// hourto
        /// </summary>
        private int? endhour;

        /// <summary>
        /// minuteto
        /// </summary>
        private int? endminute;

        /// <summary>
        /// durationhour
        /// </summary>
        private int? durationhour;

        /// <summary>
        /// durationminute
        /// </summary>
        private int? durationminute;

        /// <summary>
        /// TypeOfDay
        /// </summary>
        private int typeOfDay;

        /// <summary>
        /// type
        /// </summary>
        private int type;

        #endregion

        #region Property

        /// <summary>
        /// Get or set ShiftCode
        /// </summary>
        public int ShiftCode
        {
            get { return shiftcode; }
            set
            {
                if (value != shiftcode)
                {
                    shiftcode = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ShiftName
        /// </summary>
        public string ShiftName
        {
            get { return shiftname; }
            set
            {
                if (value != shiftname)
                {
                    shiftname = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set starthour
        /// </summary>
        public int? StartHour
        {
            get { return starthour; }
            set
            {
                if (value != starthour)
                {
                    starthour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set MinuteFrom
        /// </summary>
        public int? StartMinute
        {
            get { return startminute; }
            set
            {
                if (value != startminute)
                {
                    startminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set HourTo
        /// </summary>
        public int? EndHour
        {
            get { return endhour; }
            set
            {
                if (value != endhour)
                {
                    endhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set MinuteTo
        /// </summary>
        public int? EndMinute
        {
            get { return endminute; }
            set
            {
                if (value != endminute)
                {
                    endminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set DurationHour
        /// </summary>
        public int? DurationHour
        {
            get { return durationhour; }
            set
            {
                if (value != durationhour)
                {
                    durationhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set DurationMinute
        /// </summary>
        public int? DurationMinute
        {
            get { return durationminute; }
            set
            {
                if (value != durationminute)
                {
                    durationminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set TypeOfDay
        /// </summary>
        public int TypeOfDay
        {
            get { return typeOfDay; }
            set
            {
                if (value != typeOfDay)
                {
                    typeOfDay = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Type
        /// </summary>
        public int Type
        {
            get { return type; }
            set
            {
                if (value != type)
                {
                    type = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_WorkingShift
        /// </summary>
        public M_Work_Shift()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_WorkingShift
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Work_Shift(DbDataReader dr)
            : base(dr)
        {
            this.shiftcode = (int)dr["ShiftCode"];
            this.shiftname = (string)dr["ShiftName"];

            if (dr["StartHour"] == DBNull.Value || dr["StartMinute"] == DBNull.Value ||
                dr["EndHour"] == DBNull.Value || dr["EndMinute"] == DBNull.Value)
            {
                this.starthour = null;
                this.startminute = null;
                this.endhour = null;
                this.endminute = null;
                this.durationhour = null;
                this.durationminute = null;
            }
            else
            {
                this.starthour = (int)dr["StartHour"];
                this.startminute = (int)dr["StartMinute"];
                this.endhour = (int)dr["EndHour"];
                this.endminute = (int)dr["EndMinute"];
                this.durationhour = (int)dr["DurationHour"];
                this.durationminute = (int)dr["DurationMinute"];
            }

            this.typeOfDay = (int)dr["TypeOfDay"];
            this.type = (int)dr["Type"];
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class T_Attached Model
    /// </summary>
    [Serializable]
    public class T_Attached : M_Base<T_Attached>
    {
        #region Variable
        /// <summary>
        /// no
        /// </summary>
        private string no;
        /// <summary>
        /// path
        /// </summary>
        private string path;
        #endregion

        #region Contanst

        /// <summary>
        /// Max length of No
        /// </summary>
        public const int ATTACHED_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Path
        /// </summary>
        public const int ATTACHED_PATH_MAX_LENGTH = 255;
        
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public T_Attached()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Attached(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.No = (string)dr["No"];
            this.Path = (string)dr["Path"];
            this.CreateDate = (DateTime)dr["CreateDate"];
            this.CreateUID = (int)dr["CreateUID"];
        }
        #endregion

        #region Property
        /// <summary>
        /// Get,set No
        /// </summary>
        public string No
        {
            get { return this.no; }
            set { this.no = value; }
        }
        /// <summary>
        /// Get,set Path
        /// </summary>
        public string Path
        {
            get { return this.path; }
            set { this.path = value; }
        }
        #endregion
    }
}

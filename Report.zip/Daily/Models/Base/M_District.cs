﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    public class M_District:M_Base<M_District>
    {

        #region Constant

        /// <summary>
        /// Max length of District code
        /// </summary>
        public const int DISTRICT_CODE_MAX_LEN = 4;

        /// <summary>
        /// Max length of district name
        /// </summary>
        public const int DISTRICT_NAME_MAX_LEN = 50;

        #endregion

        #region Variant

        /// <summary>
        /// Province ID
        /// </summary>
        private int _provinceID;

        /// <summary>
        /// District Code
        /// </summary>
        private string _districtCD;

        /// <summary>
        /// Dictrict name
        /// </summary>
        private string _districtName;

        #endregion

        #region Property

        /// <summary>
        /// Get or set province id
        /// </summary>
        public int ProvinceID
        {
            get { return _provinceID; }
            set 
            {
                if (value != _provinceID)
                {
                    _provinceID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set dictrict code
        /// </summary>
        public string DistrictCD
        {
            get { return _districtCD; }
            set
            {
                if (value != _districtCD)
                {
                    _districtCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set dictrict name
        /// </summary>
        public string DistrictName 
        {
            get { return _districtName; }
            set 
            {
                if (value != _districtName)
                {
                    _districtName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_District()
            : base()
        {

        }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr"></param>
        public M_District(DbDataReader dr)
            : base(dr)
        {
            this.ProvinceID = (int)dr["ProvinceID"];
            this.DistrictCD = (string)dr["DistrictCD"];
            this.DistrictName = (string)dr["DistrictName"];
        }

        #endregion
    }
}

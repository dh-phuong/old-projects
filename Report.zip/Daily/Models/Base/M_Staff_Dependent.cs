﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_User_Dependent Model
    /// </summary>
    [Serializable]
    public class M_Staff_Dependent
    {
        #region Variable

        private int staffID;
        private DateTime registDate;
        private int dependent;
        private int total;

        #endregion

        #region Property

        public int StaffID
        {
            get { return staffID; }
            set
            {
                if (value != staffID)
                {
                    staffID = value;
                }
            }
        }

        public DateTime RegistDate
        {
            get { return registDate; }
            set
            {
                if (value != registDate)
                {
                    registDate = value;
                }
            }
        }

        public int Dependent
        {
            get { return dependent; }
            set
            {
                if (value != dependent)
                {
                    dependent = value;
                }
            }
        }

        public int Total
        {
            get { return total; }
            set
            {
                if (value != total)
                {
                    total = value;
                }
            }
        }

        #endregion

        #region Contructor

        public M_Staff_Dependent()
        {
            this.StaffID = -1;
            this.RegistDate = DateTime.MinValue;
            this.Dependent = -1;
        }

        public M_Staff_Dependent(DbDataReader dr)
        {
            this.StaffID = (int)dr["StaffID"];
            this.RegistDate = (DateTime)dr["RegistDate"];
            this.Dependent = (int)dr["Dependent"];
            this.Total = (int)dr["Total"];
        }

        #endregion        
    }
}

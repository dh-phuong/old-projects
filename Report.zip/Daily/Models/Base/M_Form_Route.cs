﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Form_Route Model
    /// TRAM 2015/04/27
    /// </summary>
    [Serializable]
    public class M_Form_Route
    {
        #region Variant

        /// <summary>
        /// FormID
        /// </summary>
        public int _formID { get; set; }

        /// <summary>
        /// RouteID
        /// </summary>
        private int _routeID;
        /// <summary>
        /// Status (Is change data)
        /// </summary>
        public DataStatus Status { get; protected set; }
        #endregion

        #region Property

        /// <summary>
        /// Get or set FormID
        /// </summary>
        public int FormID
        {
            get { return _formID; }
            set
            {
                if (value != _formID)
                {
                    _formID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RouteID
        /// </summary>
        public int RouteID
        {
            get { return _routeID; }
            set
            {
                if (value != _routeID)
                {
                    _routeID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Form_Route
        /// </summary>
        public M_Form_Route()
        {

        }

        /// <summary>
        /// Contructor M_Form_Route
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Form_Route(DbDataReader dr)
        {
            this._formID = (int)dr["FormID"];
            this._routeID = (int)dr["RouteID"];
        }

        #endregion

    }
}

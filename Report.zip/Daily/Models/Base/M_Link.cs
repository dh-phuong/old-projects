﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_User Model
    /// </summary>
    [Serializable]
    public class M_Link : M_Base<M_Link>
    {
        #region Variant

        /// <summary>
        /// UserID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// loginID
        /// </summary>
        public int TypeApplyID { get; set; }

        /// <summary>
        /// RouteID
        /// </summary>
        private int _routeID;
        
        #endregion

        #region Property

        /// <summary>
        /// Get or set RouteID
        /// </summary>
        public int RouteID
        {
            get { return _routeID; }
            set
            {
                if (value != _routeID)
                {
                    _routeID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Link
        /// </summary>
        public M_Link()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Link
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Link(DbDataReader dr)
            : base(dr)
        {
            this.UserID = (int)dr["UserID"];
            this.TypeApplyID = (int)dr["TypeApplyID"];
            this._routeID = (int)dr["RouteID"];
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_GroupUser_D
    /// Create  :isv.thuy
    /// Date    :30/07/2014
    /// </summary>
    [Serializable]
    public class M_Route_D
    {
        #region Variable

        /// <summary>
        /// Header id
        /// </summary>
        public int HID { get; set; }
        
        /// <summary>
        /// Route level
        /// </summary>
        public int RouteLevel { get; set; }        
        
        /// <summary>
        /// User id
        /// </summary>
        public int UserID { get; set; }
        public short RouteMethod { get; set; }        
        public int RequireNum { get; set; }
        public string ProxyApprovalUser { get; set; }
        
        public short ApplyFlag1 { get; set; }        
        public short ApplyFlag2 { get; set; }        
        public short ApplyFlag3 { get; set; }
        public short ApplyFlag4 { get; set; }

        public short RejectFlag1 { get; set; }        
        public short RejectFlag2 { get; set; }        
        public short RejectFlag3 { get; set; }        
        public short RejectFlag4 { get; set; }        
        public short RejectFlag5 { get; set; }        
        public short RejectFlag6 { get; set; }
        public short RejectFlag7 { get; set; }

        public short RemandFlag1 { get; set; }
        public short RemandFlag2 { get; set; }
        public short RemandFlag3 { get; set; }
        public short RemandFlag4 { get; set; }
        public short RemandFlag5 { get; set; }
        public short RemandFlag6 { get; set; }
        public short RemandFlag7 { get; set; }

        public short ApproveFlag1 { get; set; }
        public short ApproveFlag2 { get; set; }
        public short ApproveFlag3 { get; set; }       
        public short ApproveFlag4 { get; set; }       
        public short ApproveFlag5 { get; set; }       
        public short ApproveFlag6 { get; set; }       
        public short ApproveFlag7 { get; set; }       
        public short ApproveFlag8 { get; set; }       
        public short ApproveFlag9 { get; set; }

        public short ReadFlag1 { get; set; }
        public short ReadFlag2 { get; set; }
        public short ReadFlag3 { get; set; }
        public short ReadFlag4 { get; set; }
        public short ReadFlag5 { get; set; }          
      
        #endregion

        #region Property
     

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_Route_D()
            : base()
        {
            this.ApplyFlag1 = 0;
            this.ApplyFlag2 = 0;
            this.ApplyFlag3 = 0;
            this.ApplyFlag4 = 0;

            this.RejectFlag1 = 0;
            this.RejectFlag2 = 0;
            this.RejectFlag3 = 0;
            this.RejectFlag4 = 0;
            this.RejectFlag5 = 0;
            this.RejectFlag6 = 0;
            this.RejectFlag7 = 0;
            
            this.RemandFlag1 = 0;
            this.RemandFlag2 = 0;
            this.RemandFlag3 = 0;
            this.RemandFlag4 = 0;
            this.RemandFlag5 = 0;
            this.RemandFlag6 = 0;
            this.RemandFlag7 = 0;

            this.ApproveFlag1 = 0;
            this.ApproveFlag2 = 0;
            this.ApproveFlag3 = 0;
            this.ApproveFlag4 = 0;
            this.ApproveFlag5 = 0;
            this.ApproveFlag6 = 0;
            this.ApproveFlag7 = 0;
            this.ApproveFlag8 = 0;
            this.ApproveFlag9 = 0;

            this.ReadFlag1 = 0;
            this.ReadFlag2 = 0;
            this.ReadFlag3 = 0;
            this.ReadFlag4 = 0;
            this.ReadFlag5 = 0;            
        }

        /// <summary>
        /// Contructor with database data reader
        /// </summary>
        /// <param name="dr"></param>
        public M_Route_D(DbDataReader dr)
        {
            this.HID = int.Parse(string.Format("{0}", dr["HID"]));
            this.RouteLevel = int.Parse(string.Format("{0}", dr["RouteLevel"]));            
            this.UserID = int.Parse(string.Format("{0}", dr["UserID"]));

            this.RouteMethod = short.Parse(string.Format("{0}", dr["RouteMethod"]));
            this.RequireNum = int.Parse(string.Format("{0}", dr["RequireNum"]));

            this.ApplyFlag1 = short.Parse(string.Format("{0}", dr["ApplyFlag1"]));
            this.ApplyFlag2 = short.Parse(string.Format("{0}", dr["ApplyFlag2"]));
            this.ApplyFlag3 = short.Parse(string.Format("{0}", dr["ApplyFlag3"]));
            this.ApplyFlag4 = short.Parse(string.Format("{0}", dr["ApplyFlag4"]));

            this.RejectFlag1 = short.Parse(string.Format("{0}", dr["RejectFlag1"]));
            this.RejectFlag2 = short.Parse(string.Format("{0}", dr["RejectFlag2"]));
            this.RejectFlag3 = short.Parse(string.Format("{0}", dr["RejectFlag3"]));
            this.RejectFlag4 = short.Parse(string.Format("{0}", dr["RejectFlag4"]));
            this.RejectFlag5 = short.Parse(string.Format("{0}", dr["RejectFlag5"]));
            this.RejectFlag6 = short.Parse(string.Format("{0}", dr["RejectFlag6"]));
            this.RejectFlag7 = short.Parse(string.Format("{0}", dr["RejectFlag7"]));

            this.RemandFlag1 = short.Parse(string.Format("{0}", dr["RemandFlag1"]));
            this.RemandFlag2 = short.Parse(string.Format("{0}", dr["RemandFlag2"]));
            this.RemandFlag3 = short.Parse(string.Format("{0}", dr["RemandFlag3"]));
            this.RemandFlag4 = short.Parse(string.Format("{0}", dr["RemandFlag4"]));
            this.RemandFlag5 = short.Parse(string.Format("{0}", dr["RemandFlag5"]));
            this.RemandFlag6 = short.Parse(string.Format("{0}", dr["RemandFlag6"]));
            this.RemandFlag7 = short.Parse(string.Format("{0}", dr["RemandFlag7"]));

            this.ApproveFlag1 = short.Parse(string.Format("{0}", dr["ApproveFlag1"]));
            this.ApproveFlag2 = short.Parse(string.Format("{0}", dr["ApproveFlag2"]));
            this.ApproveFlag3 = short.Parse(string.Format("{0}", dr["ApproveFlag3"]));
            this.ApproveFlag4 = short.Parse(string.Format("{0}", dr["ApproveFlag4"]));
            this.ApproveFlag5 = short.Parse(string.Format("{0}", dr["ApproveFlag5"]));
            this.ApproveFlag6 = short.Parse(string.Format("{0}", dr["ApproveFlag6"]));
            this.ApproveFlag7 = short.Parse(string.Format("{0}", dr["ApproveFlag7"]));
            this.ApproveFlag8 = short.Parse(string.Format("{0}", dr["ApproveFlag8"]));
            this.ApproveFlag9 = short.Parse(string.Format("{0}", dr["ApproveFlag9"]));

            this.ReadFlag1 = short.Parse(string.Format("{0}", dr["ReadFlag1"]));
            this.ReadFlag2 = short.Parse(string.Format("{0}", dr["ReadFlag2"]));
            this.ReadFlag3 = short.Parse(string.Format("{0}", dr["ReadFlag3"]));
            this.ReadFlag4 = short.Parse(string.Format("{0}", dr["ReadFlag4"]));
            this.ReadFlag5 = short.Parse(string.Format("{0}", dr["ReadFlag5"]));            

        }

        #endregion

    }
}

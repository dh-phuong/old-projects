﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class T_Work_Step
    {
        public int WorkID { get; set; }
        public string WorkName { get; set; }
        public int WorkHour { get; set; }
        public int WorkMinute { get; set; }
        public string Remark { get; set; }

        public DateTime WorkTime
        {
            get { return new DateTime(1, 1, 1).AddHours(this.WorkHour).AddMinutes(this.WorkMinute); }
            set
            {
                this.WorkHour = value.Hour;
                this.WorkMinute = value.Minute;
            }
        }

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Work_Step()
            : base()
        {

        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Work_Step(DbDataReader dr)
        {
            this.WorkID = (int)dr["WorkID"];
            this.WorkName = dr["WorkName"].ToString();
            this.WorkHour = (int)dr["WorkHour"];
            this.WorkMinute = (int)dr["WorkMinute"];
            this.Remark = dr["Remark"].ToString();
        }

        #endregion
    }
}

﻿using System;

namespace DailyReport.Models
{
    [Serializable]
    public class T_No
    {
        /// <summary>
        /// ApplyNo Key
        /// </summary>
        public const string ApplyNo = "ApplyNo";

        /// <summary>
        /// No Key
        /// </summary>
        public const string No = "VacationNo";

        /// <summary>
        /// No Key
        /// </summary>
        public const string OverTimeNo = "OverTimeNo";
    }
}

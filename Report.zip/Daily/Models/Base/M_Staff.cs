﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Staff Model
    /// </summary>
    [Serializable]
    public class M_Staff : M_Base<M_Staff>
    {
        #region Contanst

        /// <summary>
        /// Max length of StaffCD
        /// </summary>
        public const int STAFF_CODE_MAX_LENGTH = 10;

        /// <summary>
        /// Max length of staffName
        /// </summary>
        public const int STAFF_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of ID No
        /// </summary>
        public const int ID_NO_MAX_LENGTH = 9;

        /// <summary>
        /// Max length of Tell
        /// </summary>
        public const int TELL_MAX_LENGTH = 15;

        /// <summary>
        /// Max length of Email
        /// </summary>
        public const int EMAIL_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of Address
        /// </summary>
        public const int ADDRESS_MAX_LENGTH = 150;

        /// <summary>
        /// Max length of Account No
        /// </summary>
        public const int ACCOUNT_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of SocialInsur No
        /// </summary>
        public const int SOCIALINSUR_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Tax No
        /// </summary>
        public const int TAX_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Bank Name
        /// </summary>
        public const int BANK_NAME_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of StaffCD to show
        /// </summary>
        public const int MAX_STAFF_CODE_SHOW = 4;        

        #endregion

        #region Variant

        /// <summary>
        /// StaffCD
        /// </summary>
        public string StaffCD { get; set; }

        /// <summary>
        /// staffName
        /// </summary>
        private string staffName;

        private string image;
        private short typeofstaff;

        /// <summary>
        /// AnnualDays
        /// </summary>
        private decimal annualDays;

        /// <summary>
        /// TRAM - 2015/05/14
        /// AnnualToDate
        /// </summary>
        private DateTime annualToDate;

        /// <summary>
        /// DepartmentID
        /// </summary>
        private int departmentID;

        /// <summary>
        /// position
        /// </summary>
        private int position;

        /// <summary>
        /// position
        /// </summary>
        private short sex;
        private DateTime birthday;
        private int birthplace;
        private string idNo;
        private DateTime issueDate;
        private int issueplace;
        private string tel;
        private string tel2;

        /// <summary>
        /// Email
        /// </summary>
        private string email;

        private string address1;
        private int province1;
        private int district1;
        private int ward1;
        private string address2;
        private int province2;
        private int district2;
        private int ward2;
        private string accountNo;
        private string bankname;

        /// <summary>
        /// Start work date
        /// </summary>
        private DateTime startWorkDate;

        /// <summary>
        /// End work date
        /// </summary>
        private DateTime endWorkDate;

        private string socailinsurNo;
        private string taxNo;
        /// <summary>
        /// status Flag
        /// </summary>
        private short statusFlag;

        #endregion

        #region Property

        /// <summary>
        /// Get or set AnnualToDate
        /// </summary>
        public DateTime AnnualToDate
        {
            get { return this.annualToDate; }
            set
            {
                if (value != this.annualToDate)
                {
                    this.annualToDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string SocailinsurNo
        {
            get { return socailinsurNo; }
            set
            {
                if (value != socailinsurNo)
                {
                    socailinsurNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string TaxNo
        {
            get { return taxNo; }
            set
            {
                if (value != taxNo)
                {
                    taxNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Address1
        {
            get { return address1; }
            set
            {
                if (value != address1)
                {
                    address1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Province1
        {
            get { return province1; }
            set
            {
                if (value != province1)
                {
                    province1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int District1
        {
            get { return district1; }
            set
            {
                if (value != district1)
                {
                    district1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Ward1
        {
            get { return ward1; }
            set
            {
                if (value != ward1)
                {
                    ward1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Address2
        {
            get { return address2; }
            set
            {
                if (value != address2)
                {
                    address2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Province2
        {
            get { return province2; }
            set
            {
                if (value != province2)
                {
                    province2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int District2
        {
            get { return district2; }
            set
            {
                if (value != district2)
                {
                    district2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Ward2
        {
            get { return ward2; }
            set
            {
                if (value != ward2)
                {
                    ward2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string AccountNo
        {
            get { return accountNo; }
            set
            {
                if (value != accountNo)
                {
                    accountNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Bankname
        {
            get { return bankname; }
            set
            {
                if (value != bankname)
                {
                    bankname = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        public short Sex
        {
            get { return sex; }
            set
            {
                if (value != sex)
                {
                    sex = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime Birthday
        {
            get { return birthday; }
            set
            {
                if (value != birthday)
                {
                    birthday = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Birthplace
        {
            get { return birthplace; }
            set
            {
                if (value != birthplace)
                {
                    birthplace = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string IdNo
        {
            get { return idNo; }
            set
            {
                if (value != idNo)
                {
                    idNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime IssueDate
        {
            get { return issueDate; }
            set
            {
                if (value != issueDate)
                {
                    issueDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Issueplace
        {
            get { return issueplace; }
            set
            {
                if (value != issueplace)
                {
                    issueplace = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Tel
        {
            get { return tel; }
            set
            {
                if (value != tel)
                {
                    tel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Tel2
        {
            get { return tel2; }
            set
            {
                if (value != tel2)
                {
                    tel2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Image
        {
            get { return image; }
            set
            {
                if (value != image)
                {
                    image = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public short TypeOfStaff
        {
            get { return typeofstaff; }
            set
            {
                if (value != typeofstaff)
                {
                    typeofstaff = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set staffName
        /// </summary>
        public string StaffName
        {
            get { return staffName; }
            set
            {
                if (value != staffName)
                {
                    staffName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        /// <summary>
        /// Get or set Start work date
        /// </summary>
        public DateTime StartWorkDate
        {
            get { return this.startWorkDate; }
            set
            {
                if (value != this.startWorkDate)
                {
                    this.startWorkDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set End work date
        /// </summary>
        public DateTime EndWorkDate
        {
            get { return this.endWorkDate; }
            set
            {
                if (value != this.endWorkDate)
                {
                    this.endWorkDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set AnnualDays
        /// </summary>
        public decimal AnnualDays
        {
            get { return annualDays; }
            set
            {
                if (value != annualDays)
                {
                    annualDays = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Position1
        /// </summary>
        public int DepartmentID
        {
            get { return departmentID; }
            set
            {
                if (value != departmentID)
                {
                    departmentID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Position2
        /// </summary>
        public int Position
        {
            get { return position; }
            set
            {
                if (value != position)
                {
                    position = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// get or set Email
        /// </summary>
        public string Email
        {
            get { return email; }
            set
            {
                if (value != email)
                {
                    email = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }


        /// <summary>
        /// Get or set Status Flag
        /// </summary>
        public short StatusFlag
        {
            get { return statusFlag; }
            set
            {
                if (value != statusFlag)
                {
                    statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Staff
        /// </summary>
        public M_Staff()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Staff
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Staff(DbDataReader dr)
            : base(dr)
        {
            ISecurity sec = Security.Instance;

            this.StaffCD = (string)dr["StaffCD"];
            this.staffName = (string)dr["staffName"];
            this.image = (string)dr["Image"];
            this.typeofstaff = short.Parse(dr["TypeOfStaff"].ToString());
            this.sex = short.Parse(dr["Sex"].ToString());
            this.birthday = (DateTime)dr["BirthDay"];
            this.birthplace = (int)dr["BirthPlace"];
            this.idNo = (string)dr["IDNo"];
            this.issueDate = (DateTime)dr["IssueDate"];
            this.issueplace = (int)dr["IssuePlace"];
            this.tel = (string)dr["Tel"];
            this.tel2 = (string)dr["Tel2"];
            this.address1 = (string)dr["Address1"];
            this.province1 = (int)dr["Province1"];
            this.district1 = (int)dr["District1"];
            this.ward1 = (int)dr["Ward1"];
            this.address2 = (string)dr["Address2"];

            if (dr["Province2"] == DBNull.Value)
            {
                this.province2 = -1;
            }
            else
            {
                this.province2 = (int)dr["Province2"];
            }

            if (dr["District2"] == DBNull.Value)
            {
                this.district2 = -1;
            }
            else
            {
                this.district2 = (int)dr["District2"];
            }

            if (dr["Ward2"] == DBNull.Value)
            {
                this.ward2 = -1;
            }
            else
            {
                this.ward2 = (int)dr["Ward2"];
            }

            this.accountNo = (string)dr["AccountNo"];
            this.bankname = (string)dr["BankName"];
            this.socailinsurNo = (string)dr["SocialInsurNo"];
            this.taxNo = (string)dr["TaxNo"];

            this.startWorkDate = (DateTime)dr["StartWorkDate"];

            if (dr["EndWorkDate"] == DBNull.Value)
            {
                this.endWorkDate = DateTime.MinValue;
            }
            else
            {
                this.endWorkDate = (DateTime)dr["EndWorkDate"];
            }

            this.annualDays = (decimal)dr["AnnualDays"];
            if (dr["AnnualToDate"] == DBNull.Value)
            {
                this.annualToDate = DateTime.MinValue;
            }
            else
            {
                this.annualToDate = (DateTime)dr["AnnualToDate"];
            }
            this.departmentID = (int)dr["DepartmentID"];
            this.position = (int)dr["Position"];
            this.email = (string)dr["EmailAddress"];
            this.statusFlag = short.Parse(string.Format("{0}", dr["StatusFlag"]));
        }

        #endregion
    }
}
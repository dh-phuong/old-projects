﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/05/29
    /// M_WorkingDay class
    /// </summary>
    [Serializable]
    public class M_Work_Day : M_Base<M_Work_Day>
    {
       
        #region Variable

        /// <summary>
        /// ID
        /// </summary>
        private int _ID;

        /// <summary>
        /// Working Date
        /// </summary>
        private DateTime _workDate;

        /// <summary>
        /// ShiftID
        /// </summary>
        private int _shiftID;

        #endregion

        #region Property

        /// <summary>
        /// Get or set WorkingDate
        /// </summary>
        public DateTime WorkDate
        {
            get { return this._workDate; }
            set
            {
                if (this._workDate != value)
                {
                    this._workDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ShiftID
        /// </summary>
        public int ShiftID
        {
            get { return this._shiftID; }
            set
            {
                if (this._shiftID != value)
                {
                    this._shiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_WorkingDay
        /// </summary>
        public M_Work_Day()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_WorkingDay
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Work_Day(DbDataReader dr)
            : base(dr)
        {
            this._workDate = (DateTime)dr["WorkDate"];
            this._shiftID = (int)dr["ShiftID"];

        }

        #endregion

    }
}

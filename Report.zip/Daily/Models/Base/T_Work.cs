﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class T_Work : M_Base<T_Work>
    {
        #region Constant

        public const int APPLY_NO_MAX_LENGHT = 20;

        #endregion

        #region Variable
        public int UserID { get; set; }
        public DateTime WorkDate { get; set; }
        private int _workShiftID;
        private int _startWorkHour;
        private int _startWorkMinute;
        private int _endWorkHour;
        private int _endWorkMinute;
        private int _timeWorkHour;
        private int _timeWorkMinute;
        private int _timeLateHour;
        private int _timeLateMinute;
        private int _timeEarlyHour;
        private int _timeEarlyMinute;
        private int _timeOutHour;
        private int _timeOutMinute;
        private int _oTEarlyHour;
        private int _oTEarlyMinute;
        private int _oTNormal1Hour;
        private int _oTNormal1Minute;
        private int _oTNormal2Hour;
        private int _oTNormal2Minute;
        private int _oTLateHour;
        private int _oTLateMinute;
        private int _oTHoliday1Hour;
        private int _oTHoliday1Minute;
        private int _oTHoliday2Hour;
        private int _oTHoliday2Minute;
        private int _totalOTHour;
        private int _totalOTMinute;
        private int _totalWorkHour;
        private int _totalWorkMinute;
        private string _remark;

        #endregion

        #region Property

        public int WorkShiftID
        {
            get { return _workShiftID; }
            set
            {
                if (this._workShiftID != value)
                {
                    this._workShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartWorkHour
        {
            get { return _startWorkHour; }
            set
            {
                if (this._startWorkHour != value)
                {
                    this._startWorkHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartWorkMinute
        {
            get { return _startWorkMinute; }
            set
            {
                if (this._startWorkMinute != value)
                {
                    this._startWorkMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? StartWork
        {
            get 
            {
                if (this._startWorkHour == 0 && this._startWorkMinute == 0 && this._endWorkHour == 0 && this._endWorkMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._startWorkHour).AddMinutes((int)this._startWorkMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    StartWorkHour = 0;
                    StartWorkMinute = 0;
                }
                else
                {
                    StartWorkHour = value.Value.Hour;
                    StartWorkMinute = value.Value.Minute;
                }
            }
        }

        public int EndWorkHour
        {
            get { return _endWorkHour; }
            set
            {
                if (this._endWorkHour != value)
                {
                    this._endWorkHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EndWorkMinute
        {
            get { return _endWorkMinute; }
            set
            {
                if (this._endWorkMinute != value)
                {
                    this._endWorkMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? EndWork
        {
            get
            {
                if (this._startWorkHour == 0 && this._startWorkMinute == 0 && this._endWorkHour == 0 && this._endWorkMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._endWorkHour).AddMinutes((int)this._endWorkMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    EndWorkHour = 0;
                    EndWorkMinute = 0;
                }
                else
                {
                    EndWorkHour = value.Value.Hour;
                    EndWorkMinute = value.Value.Minute;
                }
            }
        }

        public int TimeWorkHour
        {
            get { return _timeWorkHour; }
            set
            {
                if (this._timeWorkHour != value)
                {
                    this._timeWorkHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TimeWorkMinute
        {
            get { return _timeWorkMinute; }
            set
            {
                if (this._timeWorkMinute != value)
                {
                    this._timeWorkMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TimeWork
        {
            get
            {
                if (this._timeWorkHour == 0 && this._timeWorkMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._timeWorkHour).AddMinutes((int)this._timeWorkMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TimeWorkHour = 0;
                    TimeWorkMinute = 0;
                }
                else
                {
                    TimeWorkHour = value.Value.Hour;
                    TimeWorkMinute = value.Value.Minute;
                }
            }
        }

        public int TimeLateHour
        {
            get { return _timeLateHour; }
            set
            {
                if (this._timeLateHour != value)
                {
                    this._timeLateHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TimeLateMinute
        {
            get { return _timeLateMinute; }
            set
            {
                if (this._timeLateMinute != value)
                {
                    this._timeLateMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TimeLate
        {
            get
            {
                if (this._timeLateHour == 0 && this._timeLateMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._timeLateHour).AddMinutes((int)this._timeLateMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TimeLateHour = 0;
                    TimeLateMinute = 0;
                }
                else
                {
                    TimeLateHour = value.Value.Hour;
                    TimeLateMinute = value.Value.Minute;
                }
            }
        }

        public int TimeEarlyHour
        {
            get { return _timeEarlyHour; }
            set
            {
                if (this._timeEarlyHour != value)
                {
                    this._timeEarlyHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TimeEarlyMinute
        {
            get { return _timeEarlyMinute; }
            set
            {
                if (this._timeEarlyMinute != value)
                {
                    this._timeEarlyMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TimeEarly
        {
            get
            {
                if (this._timeEarlyHour == 0 && this._timeEarlyMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._timeEarlyHour).AddMinutes((int)this._timeEarlyMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TimeEarlyHour = 0;
                    TimeEarlyMinute = 0;
                }
                else
                {
                    TimeEarlyHour = value.Value.Hour;
                    TimeEarlyMinute = value.Value.Minute;
                }
            }
        }

        public int TimeOutHour
        {
            get { return _timeOutHour; }
            set
            {
                if (this._timeOutHour != value)
                {
                    this._timeOutHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TimeOutMinute
        {
            get { return _timeOutMinute; }
            set
            {
                if (this._timeOutMinute != value)
                {
                    this._timeOutMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TimeOut
        {
            get
            {
                if (this._timeOutHour == 0 && this._timeOutMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._timeOutHour).AddMinutes((int)this._timeOutMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TimeOutHour = 0;
                    TimeOutMinute = 0;
                }
                else
                {
                    TimeOutHour = value.Value.Hour;
                    TimeOutMinute = value.Value.Minute;
                }
            }
        }

        public int OTEarlyHour
        {
            get { return _oTEarlyHour; }
            set
            {
                if (this._oTEarlyHour != value)
                {
                    this._oTEarlyHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTEarlyMinute
        {
            get { return _oTEarlyMinute; }
            set
            {
                if (this._oTEarlyMinute != value)
                {
                    this._oTEarlyMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTEarly
        {
            get
            {
                if (this._oTEarlyHour == 0 && this._oTEarlyMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTEarlyHour).AddMinutes((int)this._oTEarlyMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTEarlyHour = 0;
                    OTEarlyMinute = 0;
                }
                else
                {
                    OTEarlyHour = value.Value.Hour;
                    OTEarlyMinute = value.Value.Minute;
                }
            }
        }

        public int OTNormal1Hour
        {
            get { return _oTNormal1Hour; }
            set
            {
                if (this._oTNormal1Hour != value)
                {
                    this._oTNormal1Hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTNormal1Minute
        {
            get { return _oTNormal1Minute; }
            set
            {
                if (this._oTNormal1Minute != value)
                {
                    this._oTNormal1Minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTNormal1
        {
            get
            {
                if (this._oTNormal1Hour == 0 && this._oTNormal1Minute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTNormal1Hour).AddMinutes((int)this._oTNormal1Minute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTNormal1Hour = 0;
                    OTNormal1Minute = 0;
                }
                else
                {
                    OTNormal1Hour = value.Value.Hour;
                    OTNormal1Minute = value.Value.Minute;
                }
            }
        }

        public int OTNormal2Hour
        {
            get { return _oTNormal2Hour; }
            set
            {
                if (this._oTNormal2Hour != value)
                {
                    this._oTNormal2Hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTNormal2Minute
        {
            get { return _oTNormal2Minute; }
            set
            {
                if (this._oTNormal2Minute != value)
                {
                    this._oTNormal2Minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTNormal2
        {
            get
            {
                if (this._oTNormal2Hour == 0 && this._oTNormal2Minute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTNormal2Hour).AddMinutes((int)this._oTNormal2Minute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTNormal2Hour = 0;
                    OTNormal2Minute = 0;
                }
                else
                {
                    OTNormal2Hour = value.Value.Hour;
                    OTNormal2Minute = value.Value.Minute;
                }
            }
        }

        public int OTLateHour
        {
            get { return _oTLateHour; }
            set
            {
                if (this._oTLateHour != value)
                {
                    this._oTLateHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTLateMinute
        {
            get { return _oTLateMinute; }
            set
            {
                if (this._oTLateMinute != value)
                {
                    this._oTLateMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTLate
        {
            get
            {
                if (this._oTLateHour == 0 && this._oTLateMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTLateHour).AddMinutes((int)this._oTLateMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTLateHour = 0;
                    OTLateMinute = 0;
                }
                else
                {
                    OTLateHour = value.Value.Hour;
                    OTLateMinute = value.Value.Minute;
                }
            }
        }

        public int OTHoliday1Hour
        {
            get { return _oTHoliday1Hour; }
            set
            {
                if (this._oTHoliday1Hour != value)
                {
                    this._oTHoliday1Hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTHoliday1Minute
        {
            get { return _oTHoliday1Minute; }
            set
            {
                if (this._oTHoliday1Minute != value)
                {
                    this._oTHoliday1Minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTHoliday1
        {
            get
            {
                if (this._oTHoliday1Hour == 0 && this._oTHoliday1Minute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTHoliday1Hour).AddMinutes((int)this._oTHoliday1Minute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTHoliday1Hour = 0;
                    OTHoliday1Minute = 0;
                }
                else
                {
                    OTHoliday1Hour = value.Value.Hour;
                    OTHoliday1Minute = value.Value.Minute;
                }
            }
        }

        public int OTHoliday2Hour
        {
            get { return _oTHoliday2Hour; }
            set
            {
                if (this._oTHoliday2Hour != value)
                {
                    this._oTHoliday2Hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTHoliday2Minute
        {
            get { return _oTHoliday2Minute; }
            set
            {
                if (this._oTHoliday2Minute != value)
                {
                    this._oTHoliday2Minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? OTHoliday2
        {
            get
            {
                if (this._oTHoliday2Hour == 0 && this._oTHoliday2Hour == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._oTHoliday2Hour).AddMinutes((int)this._oTHoliday2Minute);
                }
            }
            set
            {
                if (value == null)
                {
                    OTHoliday2Hour = 0;
                    OTHoliday2Minute = 0;
                }
                else
                {
                    OTHoliday2Hour = value.Value.Hour;
                    OTHoliday2Minute = value.Value.Minute;
                }
            }
        }

        public int TotalOTHour
        {
            get { return _totalOTHour; }
            set
            {
                if (this._totalOTHour != value)
                {
                    this._totalOTHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TotalOTMinute
        {
            get { return _totalOTMinute; }
            set
            {
                if (this._totalOTMinute != value)
                {
                    this._totalOTMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TotalOT
        {
            get
            {
                if (this._totalOTHour == 0 && this._totalOTMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._totalOTHour).AddMinutes((int)this._totalOTMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TotalOTHour = 0;
                    TotalOTMinute = 0;
                }
                else
                {
                    TotalOTHour = value.Value.Hour;
                    TotalOTMinute = value.Value.Minute;
                }
            }
        }

        public int TotalWorkHour
        {
            get { return _totalWorkHour; }
            set
            {
                if (this._totalWorkHour != value)
                {
                    this._totalWorkHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int TotalWorkMinute
        {
            get { return _totalWorkMinute; }
            set
            {
                if (this._totalWorkMinute != value)
                {
                    this._totalWorkMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? TotalWork
        {
            get
            {
                if (this._totalWorkHour == 0 && this._totalWorkMinute == 0)
                {
                    return null;
                }
                else
                {
                    return new DateTime(1, 1, 1).AddHours((int)this._totalWorkHour).AddMinutes((int)this._totalWorkMinute);
                }
            }
            set
            {
                if (value == null)
                {
                    TotalWorkHour = 0;
                    TotalWorkMinute = 0;
                }
                else
                {
                    TotalWorkHour = value.Value.Hour;
                    TotalWorkMinute = value.Value.Minute;
                }
            }
        }

        public string Remark
        {
            get { return _remark; }
            set
            {
                if (this._remark != value)
                {
                    this._remark = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Work()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Work(DbDataReader dr)
            : base(dr)
        {
            this.UserID = (int)dr["UserID"];
            this.WorkDate = (DateTime)dr["WorkDate"];
            this._workShiftID = (int)dr["WorkShiftID"];
            this._startWorkHour = (int)dr["StartWorkHour"];
            this._startWorkMinute = (int)dr["StartWorkMinute"];
            this._endWorkHour = (int)dr["EndWorkHour"];
            this._endWorkMinute = (int)dr["EndWorkMinute"];
            this._timeWorkHour = (int)dr["TimeWorkHour"];
            this._timeWorkMinute = (int)dr["TimeWorkMinute"];
            this._timeLateHour = (int)dr["TimeLateHour"];
            this._timeLateMinute = (int)dr["TimeLateMinute"];
            this._timeEarlyHour = (int)dr["TimeEarlyHour"];
            this._timeEarlyMinute = (int)dr["TimeEarlyMinute"];
            this._timeOutHour = (int)dr["TimeOutHour"];
            this._timeOutMinute = (int)dr["TimeOutMinute"];
            this._oTEarlyHour = (int)dr["OTEarlyHour"];
            this._oTEarlyMinute = (int)dr["OTEarlyMinute"];
            this._oTNormal1Hour = (int)dr["OTNormal1Hour"];
            this._oTNormal1Minute = (int)dr["OTNormal1Minute"];
            this._oTNormal2Hour = (int)dr["OTNormal2Hour"];
            this._oTNormal2Minute = (int)dr["OTNormal2Minute"];
            this._oTLateHour = (int)dr["OTLateHour"];
            this._oTLateMinute = (int)dr["OTLateMinute"];
            this._oTHoliday1Hour = (int)dr["OTHoliday1Hour"];
            this._oTHoliday1Minute = (int)dr["OTHoliday1Minute"];
            this._oTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this._oTHoliday2Minute = (int)dr["OTHoliday2Minute"];
            this._totalOTHour = (int)dr["TotalOTHour"];
            this._totalOTMinute = (int)dr["TotalOTMinute"];
            this._totalWorkHour = (int)dr["TotalWorkHour"];
            this._totalWorkMinute = (int)dr["TotalWorkMinute"];
            this._remark = dr["Remark"].ToString();
        }

        #endregion
    }
}

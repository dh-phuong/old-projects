﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/06/04
    /// M_RestTime class
    /// </summary>
    [Serializable]
    public class M_RestTime : M_Base<M_RestTime>
    {

        #region Variable

        /// <summary>
        /// ShiftID
        /// </summary>
        private int _shiftID;

        /// <summary>
        /// RestTimeSH1
        /// </summary>
        private int? _restTimeSH1;

        /// <summary>
        /// RestTimeSM1
        /// </summary>
        private int? _restTimeSM1;

        /// <summary>
        /// RestTimeEH1
        /// </summary>
        private int? _restTimeEH1;

        /// <summary>
        /// RestTimeEM1
        /// </summary>
        private int? _restTimeEM1;

        /// <summary>
        /// RestTimeSH2
        /// </summary>
        private int? _restTimeSH2;

        /// <summary>
        /// RestTimeSM2
        /// </summary>
        private int? _restTimeSM2;

        /// <summary>
        /// RestTimeEH2
        /// </summary>
        private int? _restTimeEH2;

        /// <summary>
        /// RestTimeEM2
        /// </summary>
        private int? _restTimeEM2;

        /// <summary>
        /// RestTimeSH3
        /// </summary>
        private int? _restTimeSH3;

        /// <summary>
        /// RestTimeSM3
        /// </summary>
        private int? _restTimeSM3;

        /// <summary>
        /// RestTimeEH3
        /// </summary>
        private int? _restTimeEH3;

        /// <summary>
        /// RestTimeEM3
        /// </summary>
        private int? _restTimeEM3;

        /// <summary>
        /// RestTimeSH4
        /// </summary>
        private int? _restTimeSH4;

        /// <summary>
        /// RestTimeSM4
        /// </summary>
        private int? _restTimeSM4;

        /// <summary>
        /// RestTimeEH4
        /// </summary>
        private int? _restTimeEH4;

        /// <summary>
        /// RestTimeEM4
        /// </summary>
        private int? _restTimeEM4;

        /// <summary>
        /// RestTimeSH5
        /// </summary>
        private int? _restTimeSH5;

        /// <summary>
        /// RestTimeSM5
        /// </summary>
        private int? _restTimeSM5;

        /// <summary>
        /// RestTimeEH5
        /// </summary>
        private int? _restTimeEH5;

        /// <summary>
        /// RestTimeEM5
        /// </summary>
        private int? _restTimeEM5;

        /// <summary>
        /// RestTimeSH6
        /// </summary>
        private int? _restTimeSH6;

        /// <summary>
        /// RestTimeSM6
        /// </summary>
        private int? _restTimeSM6;

        /// <summary>
        /// RestTimeEH6
        /// </summary>
        private int? _restTimeEH6;

        /// <summary>
        /// RestTimeEM6
        /// </summary>
        private int? _restTimeEM6;

        #endregion

        #region Property

        /// <summary>
        /// Get or set ShiftID
        /// </summary>
        public int ShiftID
        {
            get { return this._shiftID; }
            set
            {
                if (this._shiftID != value)
                {
                    this._shiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH1
        /// </summary>
        public int? RestTimeSH1
        {
            get { return this._restTimeSH1; }
            set
            {
                if (this._restTimeSH1 != value)
                {
                    this._restTimeSH1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM1
        /// </summary>
        public int? RestTimeSM1
        {
            get { return this._restTimeSM1; }
            set
            {
                if (this._restTimeSM1 != value)
                {
                    this._restTimeSM1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH1
        /// </summary>
        public int? RestTimeEH1
        {
            get { return this._restTimeEH1; }
            set
            {
                if (this._restTimeEH1 != value)
                {
                    this._restTimeEH1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM1
        /// </summary>
        public int? RestTimeEM1
        {
            get { return this._restTimeEM1; }
            set
            {
                if (this._restTimeEM1 != value)
                {
                    this._restTimeEM1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH2
        /// </summary>
        public int? RestTimeSH2
        {
            get { return this._restTimeSH2; }
            set
            {
                if (this._restTimeSH2 != value)
                {
                    this._restTimeSH2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM2
        /// </summary>
        public int? RestTimeSM2
        {
            get { return this._restTimeSM2; }
            set
            {
                if (this._restTimeSM2 != value)
                {
                    this._restTimeSM2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH2
        /// </summary>
        public int? RestTimeEH2
        {
            get { return this._restTimeEH2; }
            set
            {
                if (this._restTimeEH2 != value)
                {
                    this._restTimeEH2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM2
        /// </summary>
        public int? RestTimeEM2
        {
            get { return this._restTimeEM2; }
            set
            {
                if (this._restTimeEM2 != value)
                {
                    this._restTimeEM2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH3
        /// </summary>
        public int? RestTimeSH3
        {
            get { return this._restTimeSH3; }
            set
            {
                if (this._restTimeSH3 != value)
                {
                    this._restTimeSH3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM3
        /// </summary>
        public int? RestTimeSM3
        {
            get { return this._restTimeSM3; }
            set
            {
                if (this._restTimeSM3 != value)
                {
                    this._restTimeSM3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH3
        /// </summary>
        public int? RestTimeEH3
        {
            get { return this._restTimeEH3; }
            set
            {
                if (this._restTimeEH3 != value)
                {
                    this._restTimeEH3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM3
        /// </summary>
        public int? RestTimeEM3
        {
            get { return this._restTimeEM3; }
            set
            {
                if (this._restTimeEM3 != value)
                {
                    this._restTimeEM3 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH4
        /// </summary>
        public int? RestTimeSH4
        {
            get { return this._restTimeSH4; }
            set
            {
                if (this._restTimeSH4 != value)
                {
                    this._restTimeSH4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM4
        /// </summary>
        public int? RestTimeSM4
        {
            get { return this._restTimeSM4; }
            set
            {
                if (this._restTimeSM4 != value)
                {
                    this._restTimeSM4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH4
        /// </summary>
        public int? RestTimeEH4
        {
            get { return this._restTimeEH4; }
            set
            {
                if (this._restTimeEH4 != value)
                {
                    this._restTimeEH4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM4
        /// </summary>
        public int? RestTimeEM4
        {
            get { return this._restTimeEM4; }
            set
            {
                if (this._restTimeEM4 != value)
                {
                    this._restTimeEM4 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH5
        /// </summary>
        public int? RestTimeSH5
        {
            get { return this._restTimeSH5; }
            set
            {
                if (this._restTimeSH5 != value)
                {
                    this._restTimeSH5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM5
        /// </summary>
        public int? RestTimeSM5
        {
            get { return this._restTimeSM5; }
            set
            {
                if (this._restTimeSM5 != value)
                {
                    this._restTimeSM5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH5
        /// </summary>
        public int? RestTimeEH5
        {
            get { return this._restTimeEH5; }
            set
            {
                if (this._restTimeEH5 != value)
                {
                    this._restTimeEH5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM5
        /// </summary>
        public int? RestTimeEM5
        {
            get { return this._restTimeEM5; }
            set
            {
                if (this._restTimeEM5 != value)
                {
                    this._restTimeEM5 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSH6
        /// </summary>
        public int? RestTimeSH6
        {
            get { return this._restTimeSH6; }
            set
            {
                if (this._restTimeSH6 != value)
                {
                    this._restTimeSH6 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeSM6
        /// </summary>
        public int? RestTimeSM6
        {
            get { return this._restTimeSM6; }
            set
            {
                if (this._restTimeSM6 != value)
                {
                    this._restTimeSM6 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEH6
        /// </summary>
        public int? RestTimeEH6
        {
            get { return this._restTimeEH6; }
            set
            {
                if (this._restTimeEH6 != value)
                {
                    this._restTimeEH6 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RestTimeEM6
        /// </summary>
        public int? RestTimeEM6
        {
            get { return this._restTimeEM6; }
            set
            {
                if (this._restTimeEM6 != value)
                {
                    this._restTimeEM6 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

         #region Contructor

        /// <summary>
        /// Contructor M_WorkingDate
        /// </summary>
        public M_RestTime()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_RestTime
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_RestTime(DbDataReader dr)
            : base(dr)
        {
            if (dr["ShiftID"] != DBNull.Value)
            {
                this._shiftID = (int)dr["ShiftID"];
            }

            if (dr["RestTimeSH1"] != DBNull.Value)
            {
                this._restTimeSH1 = (int)dr["RestTimeSH1"];
            }

            if (dr["RestTimeSM1"] != DBNull.Value)
            {
                this._restTimeSM1 = (int)dr["RestTimeSM1"];
            }

            if (dr["RestTimeEH1"] != DBNull.Value)
            {
                this._restTimeEH1 = (int)dr["RestTimeEH1"];
            }

            if (dr["RestTimeEM1"] != DBNull.Value)
            {
                this._restTimeEM1 = (int)dr["RestTimeEM1"];
            }

            if (dr["RestTimeSH2"] != DBNull.Value)
            {
                this._restTimeSH2 = (int)dr["RestTimeSH2"];
            }

            if (dr["RestTimeSM2"] != DBNull.Value)
            {
                this._restTimeSM2 = (int)dr["RestTimeSM2"];
            }

            if (dr["RestTimeEH2"] != DBNull.Value)
            {
                this._restTimeEH2 = (int)dr["RestTimeEH2"];
            }

            if (dr["RestTimeEM2"] != DBNull.Value)
            {
                this._restTimeEM2 = (int)dr["RestTimeEM2"];
            }

            if (dr["RestTimeSH3"] != DBNull.Value)
            {
                this._restTimeSH3 = (int)dr["RestTimeSH3"];
            }

            if (dr["RestTimeSM3"] != DBNull.Value)
            {
                this._restTimeSM3 = (int)dr["RestTimeSM3"];
            }

            if (dr["RestTimeEH3"] != DBNull.Value)
            {
                this._restTimeEH3 = (int)dr["RestTimeEH3"];
            }

            if (dr["RestTimeEM3"] != DBNull.Value)
            {
                this._restTimeEM3 = (int)dr["RestTimeEM3"];
            }

            if (dr["RestTimeSH4"] != DBNull.Value)
            {
                this._restTimeSH4 = (int)dr["RestTimeSH4"];
            }

            if (dr["RestTimeSM4"] != DBNull.Value)
            {
                this._restTimeSM4 = (int)dr["RestTimeSM4"];
            }

            if (dr["RestTimeEH4"] != DBNull.Value)
            {
                this._restTimeEH4 = (int)dr["RestTimeEH4"];
            }

            if (dr["RestTimeEM4"] != DBNull.Value)
            {
                this._restTimeEM4 = (int)dr["RestTimeEM4"];
            }

            if (dr["RestTimeSH5"] != DBNull.Value)
            {
                this._restTimeSH5 = (int)dr["RestTimeSH5"];
            }

            if (dr["RestTimeSM5"] != DBNull.Value)
            {
                this._restTimeSM5 = (int)dr["RestTimeSM5"];
            }

            if (dr["RestTimeEH5"] != DBNull.Value)
            {
                this._restTimeEH5 = (int)dr["RestTimeEH5"];
            }

            if (dr["RestTimeEM5"] != DBNull.Value)
            {
                this._restTimeEM5 = (int)dr["RestTimeEM5"];
            }

            if (dr["RestTimeSH6"] != DBNull.Value)
            {
                this._restTimeSH6 = (int)dr["RestTimeSH6"];
            }

            if (dr["RestTimeSM6"] != DBNull.Value)
            {
                this._restTimeSM6 = (int)dr["RestTimeSM6"];
            }

            if (dr["RestTimeEH6"] != DBNull.Value)
            {
                this._restTimeEH6 = (int)dr["RestTimeEH6"];
            }

            if (dr["RestTimeEM6"] != DBNull.Value)
            {
                this._restTimeEM6 = (int)dr["RestTimeEM6"];
            }

        }

        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// M_Province
    /// VN-Nho
    /// 2015/03/30
    /// </summary>
    [Serializable]
    public class M_Province: M_Base<M_Province>
    {
        #region Contanst

        /// <summary>
        /// Max length of Province code in database
        /// </summary>
        public const int PROVINCE_CODE_MAX_LEN_DB = 4;

        /// <summary>
        /// Max length of Province code in display
        /// </summary>
        public const int PROVINCE_CODE_MAX_LEN_SHOW = 2;

        /// <summary>
        /// Max length of Province name
        /// </summary>
        public const int PROVINCE_NAME_MAX_LEN = 50;

        #endregion

        #region Variable

        /// <summary>
        /// Province code
        /// </summary>
        private string _provinceCD;

        /// <summary>
        /// Province name
        /// </summary>
        private string _provinceName;

        #endregion

        #region Property

        /// <summary>
        /// Get or set Province code
        /// </summary>
        public string ProvinceCD
        {
            get { return this._provinceCD; }
            set
            {
                if (this._provinceCD != value)
                {
                    this._provinceCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set province name
        /// </summary>
        public string ProvinceName
        {
            get { return this._provinceName; }
            set
            {
                if (this._provinceName != value)
                {
                    this._provinceName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_Province()
            : base()
        { 
        
        }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr"></param>
        public M_Province(DbDataReader dr)
            : base(dr)
        {
            this._provinceCD = dr["ProvinceCD"].ToString();
            this._provinceName = dr["ProvinceName"].ToString();
        }

        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class Seting header
    /// </summary>
    [Serializable]
    public class M_Config_H : M_Base<M_Config_H>
    {
        #region Constant
        
        /// <summary>
        /// Max length of Config code
        /// </summary>
        public const int CONFIG_CODE_MAX_LENGTH = 4;

        /// <summary>
        /// Max length of config name
        /// </summary>
        public const int CONFIG_NAME_MAX_LENGTH = 50;

        #region OMS

        /// <summary>
        /// Config cd paging
        /// </summary>
        public const string CONFIG_CD_PAGING = "L001";

        /// <summary>
        /// 一覧検索 コンボボックス
        /// </summary>
        public const string CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO = "L013";

        /// <summary>
        /// ユーザー登録制限数　Max Active User No.
        /// </summary>
        public const string CONFIG_CD_MAX_ACTIVE_USER = "L015";

        /// <summary>
        /// 最大添付ファイル容量　Max upload file volume 
        /// </summary>
        public const string CONFIG_CD_UPLOAD_FILE = "L017";

        /// <summary>
        /// CONFIG_GROUP_USERCD_ADMIN
        /// </summary>
        public const string CONFIG_USER_CD_ADMIN = "L018";

        /// <summary>
        /// File Extension
        /// </summary>
        public const string CONFIG_FILE_EXTENSION_TYPE = "L020";

        /// <summary>
        /// File Extension
        /// </summary>
        public const string CONFIG_CD_TYPE_OF_DAY = "W009";

        #endregion

        #region WorkFlow

        /// <summary>
        /// Config cd Method VAT
        /// </summary>
        public const string CONFIG_CD_TYPE_OF_STAFF = "W001";

        /// <summary>
        /// Config cd Default VAT value
        /// </summary>
        public const string CONFIG_CD_TYPE_OF_SEX = "W002";

        /// <summary>
        /// 
        /// </summary>
        public const string CONFIG_CD_ANNUAL_DAY = "W003";

        /// <summary>
        /// Template of Type
        /// </summary>
        public const string CONFIG_CD_TEMPLATE_TYPE = "W004";        

        /// <summary>
        /// default Status approve value
        /// </summary>
        public const string CONFIG_CD_DEFAULT_STATUS_APPROVED = "W006";          
 
        /// <summary>
        /// logic round calculate
        /// </summary>
        public const string CONFIG_CD_ROUND_CALC = "W008";                  

        /// <summary>
        /// Type of Contract
        /// </summary>
        public const string CONFIG_CD_CONTRACT_TYPE = "W010";

        /// <summary>
        /// Possition
        /// </summary>
        public const string CONFIG_CD_POSITION = "W011";

        /// <summary>
        /// AllowanceType
        /// </summary>
        public const string CONFIG_CD_ALLOWANCE = "W012";

        /// <summary>
        /// Method Router
        /// </summary>
        public const string CONFIG_CD_METHOD_ROUTE = "W013";

        /// <summary>
        /// Config cd Method VAT
        /// </summary>
        public const string CONFIG_CD_WORKING_SHIFT_TYPE = "W014";

        /// <summary>
        /// Config cd Vacation Type
        /// </summary>
        public const string CONFIG_CD_VACATION_TYPE = "W016";

        #endregion        

        #region Value of config_cd

        /// <summary>
        /// Method Router and
        /// </summary>
        public const short METHOD_ROUTE_AND = 1;

        /// <summary>
        /// Method Router or
        /// </summary>
        public const short METHOD_ROUTE_OR = 2;  

        #endregion                          

        #endregion

        #region Variable

        /// <summary>
        /// Config Code
        /// </summary>
        public string ConfigCD { get; set; }

        /// <summary>
        /// Setting Name
        /// </summary>
        private string configName;

        #endregion

        #region Property

        /// <summary>
        /// Get or Set Config Name
        /// </summary>
        public string ConfigName
        {
            get { return configName; }
            set
            {
                if (value != this.configName)
                {
                    this.configName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Setting_H
        /// </summary>
        public M_Config_H()
            : base()
        { 
        }

        /// <summary>
        /// Contructor M_Setting_H
        /// </summary>
        /// <param name="dr"></param>
        public M_Config_H(DbDataReader dr)
            : base(dr)
        {
            this.ConfigCD = (string)dr["ConfigCD"];
            this.configName = (string)dr["ConfigName"];
        }


        #endregion

    }
}

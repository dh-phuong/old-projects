﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_User_Contract Model
    /// </summary>
    [Serializable]
    public class M_Staff_Contract
    {
        #region Variable

        private int staffID;
        private string contractNo;
        private short contractType;
        private DateTime startDate;

        #endregion

        #region Property

        public int StaffID
        {
            get { return staffID; }
            set
            {
                if (value != staffID)
                {
                    staffID = value;
                }
            }
        }

        public string ContractNo
        {
            get { return contractNo; }
            set
            {
                if (value != contractNo)
                {
                    contractNo = value;
                }
            }
        }

        public short ContractType
        {
            get { return contractType; }
            set
            {
                if (value != contractType)
                {
                    contractType = value;
                }
            }
        }

        public DateTime StartDate
        {
            get { return startDate; }
            set
            {
                if (value != startDate)
                {
                    startDate = value;
                }
            }
        }

        #endregion

        #region Constructor

        public M_Staff_Contract()
        {
            this.StaffID = -1;
            this.ContractNo = string.Empty;
            this.ContractType = -1;
            this.StartDate = DateTime.MinValue;
        }

        public M_Staff_Contract(DbDataReader dr)
        {
            this.StaffID = (int)dr["StaffID"];
            this.ContractNo = (string)dr["ContractNo"];
            this.ContractType = short.Parse(dr["ContractType"].ToString());
            this.StartDate = (DateTime)dr["StartDate"];
        }

        #endregion     
    }
}

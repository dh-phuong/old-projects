﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Form_Type Model
    /// ISV-TRUC 2015/04/27
    /// </summary>
    [Serializable]
    public class M_Form_Type
    {
        #region Variant

        /// <summary>
        /// FormID
        /// </summary>
        public int _formID;

        /// <summary>
        /// ID
        /// </summary>
        public int _id;

        /// <summary>
        /// TypeName
        /// </summary>
        private string _typeName;

        /// <summary>
        /// TimeOfRule
        /// </summary>
        private short _timeOfRule;


        /// <summary>
        /// Status
        /// </summary>
        private DataStatus _status;
        
        #endregion

        #region Property

        /// <summary>
        /// Status
        /// </summary>
        public DataStatus Status
        {
            get
            {
                return this._status;
            }
        }

        /// <summary>
        /// Get or set FormID
        /// </summary>
        public int FormID
        {
            get { return _formID; }
            set
            {
                if (value != _formID)
                {
                    _formID = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID
        {
            get { return _id; }
            set
            {
                if (value != _id)
                {
                    _id = value;
                    this._status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set TypeName
        /// </summary>
        public string TypeName
        {
            get { return _typeName; }
            set
            {
                if (value != _typeName)
                {
                    _typeName = value;
                    this._status = DataStatus.Changed;
                }
            }
        }


        /// <summary>
        /// TimeOfRule
        /// </summary>
        public short TimeOfRule
        {
            get { return _timeOfRule; }
            set
            {
                if (value != _timeOfRule)
                {
                    _timeOfRule = value;
                    this._status = DataStatus.Changed;
                }
            }
        }
        
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Form_Type
        /// </summary>
        public M_Form_Type()
        {

        }

        /// <summary>
        /// Contructor M_Form_Type
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Form_Type(DbDataReader dr)
        {
            this._formID = (int)dr["FormID"];
            this._id = (int)dr["ID"];
            this._typeName = (string)dr["TypeName"];
            this._timeOfRule = short.Parse(dr["TimeOfRule"].ToString());
        }

        #endregion

    }
}

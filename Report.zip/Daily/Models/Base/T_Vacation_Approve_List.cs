﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{ 
    /// <summary>
    /// T_Vacation_Approve_List
    /// VN-Nho
    /// 2015/03/18
    /// </summary>
    [Serializable]
    public class T_Vacation_Approve_List : M_Base<T_Vacation_Approve_List>
    {

        /// <summary>
        /// Max length of Remark
        /// </summary>
        public const int REASON_MAX_LENGTH = 1000;

        /// <summary>
        /// Get or set VacationID
        /// </summary>
        public int VacationID { get; set; }

        /// <summary>
        /// Get or set Route User ID
        /// </summary>
        public int RouteUID { get; set; }

        /// <summary>
        /// Get or Set Route Level
        /// </summary>
        public int RouteLevel { get; set; }

        /// <summary>
        /// Get or set Route Method
        /// </summary>
        public short RouteMethod { get; set; }

        /// <summary>
        /// Get or set Approve Status
        /// </summary>
        public short? ApproveStatus { get; set; }

        /// <summary>
        /// Get or set Approve User ID
        /// </summary>
        public int? ApproveUID { get; set; }

        /// <summary>
        /// Get or set Approve Date
        /// </summary>
        public DateTime? ApproveDate { get; set; }

        /// <summary>
        /// Get or set Reason
        /// </summary>
        public string ApproveReason { get; set; }
    }
}

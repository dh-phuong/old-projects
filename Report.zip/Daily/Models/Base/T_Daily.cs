﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// DailyInfo Model
    /// ISV-TRAM 2015/03/02
    /// </summary>
    [Serializable]
    public class T_Daily : M_Base<T_Daily>
    {
        #region Constant
        public const int CONTENT_MAX_LENGTH = 1000;
        public const int START_HOUR_DEFAULT = 8;
        public const int START_MINUTE_DEFAULT = 0;

        public const int END_HOUR_NOON_DEFAULT = 11;
        public const int END_MINUTE_NOON_DEFAULT = 50;

        public const int START_HOUR_AFTERNOON_DEFAULT = 12;
        public const int START_MINUTE_AFTERNOON_DEFAULT = 50;

        public const int END_HOUR_DEFAULT = 17;
        public const int END_MINUTE_DEFAULT = 30;

        #endregion

        #region Variable

        /// <summary>
        /// UserID
        /// </summary>
        public int _userID;

        /// <summary>
        /// WorkDate
        /// </summary>
        public DateTime _workDate;

        /// <summary>
        /// TypeApplyID
        /// </summary>
        public int _typeApplyID;

        /// <summary>
        /// ApplyID
        /// </summary>
        private int? _applyID;
        
        /// <summary>
        /// VacationID
        /// </summary>
        private int? _vacationID;
        
        /// <summary>
        /// ApproveID
        /// </summary>
        public int? _approveID;

        /// <summary>
        /// StartHour
        /// </summary>
        public short _startHour;

        /// <summary>
        /// StartMinute
        /// </summary>
        public short _startMinute;

        /// <summary>
        /// EndHour
        /// </summary>
        public short _endHour;

        /// <summary>
        /// EndMinute
        /// </summary>
        public short _endMinute;

        /// <summary>
        /// Content
        /// </summary>
        public string _content;

        /// <summary>
        /// DeleteFlag
        /// </summary>
        public short _deleteFlag;

        #endregion

        #region Property

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int UserID
        {
            get { return this._userID; }
            set
            {
                if (value != this._userID)
                {
                    this._userID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public DateTime WorkDate
        {
            get { return this._workDate; }
            set
            {
                if (value != this._workDate)
                {
                    this._workDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set TypeApplyID
        /// </summary>
        public int TypeApplyID
        {
            get { return this._typeApplyID; }
            set
            {
                if (value != this._typeApplyID)
                {
                    this._typeApplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ApplyID
        /// </summary>
        public int? ApplyID
        {
            get { return _applyID; }
            set
            {
                if (value != this._applyID)
                {
                    this._applyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VacationID
        /// </summary>
        public int? VacationID
        {
            get { return _vacationID; }
            set
            {
                if (value != this._vacationID)
                {
                    this._vacationID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ApproveID
        /// </summary>
        public int? ApproveID
        {
            get { return this._approveID; }
            set
            {
                if (value != this._approveID)
                {
                    this._approveID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set StartHour
        /// </summary>
        public short StartHour
        {
            get { return this._startHour; }
            set
            {
                if (value != this._startHour)
                {
                    this._startHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

         /// <summary>
        /// Get or set StartMinute
        /// </summary>
        public short StartMinute
        {
            get { return this._startMinute; }
            set
            {
                if (value != this._startMinute)
                {
                    this._startMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set EndHour
        /// </summary>
        public short EndHour
        {
            get { return this._endHour; }
            set
            {
                if (value != this._endHour)
                {
                    this._endHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set EndMinute
        /// </summary>
        public short EndMinute
        {
            get { return this._endMinute; }
            set
            {
                if (value != this._endMinute)
                {
                    this._endMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Content
        /// </summary>
        public string Content
        {
            get { return this._content; }
            set
            {
                if (value != this._content)
                {
                    this._content = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set DeleteFlag
        /// </summary>
        public short DeleteFlag
        {
            get { return this._deleteFlag; }
            set
            {
                if (value != this._deleteFlag)
                {
                    this._deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor T_Daily
        /// </summary>
        public T_Daily()
            : base()
        {

        }

        /// <summary>
        /// Contructor T_Daily
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Daily(DbDataReader dr)
            : base(dr)
        {
            this._userID =  int.Parse(dr["UserID"].ToString() );
            this._workDate = (DateTime)dr["WorkDate"];
            this._typeApplyID = short.Parse(dr["TypeApplyID"].ToString());

            if (dr["ApplyID"] != DBNull.Value)
            {
                this._applyID = int.Parse(dr["ApplyID"].ToString());
            }
            else
            {
                this._applyID = null;
            }

            if (dr["VacationID"] != DBNull.Value)
            {
                this._vacationID= int.Parse(dr["VacationID"].ToString());
            }
            else
            {
                this._vacationID = null;
            }

            if (dr["ApproveID"] != DBNull.Value)
            {
                this._approveID = int.Parse(dr["ApproveID"].ToString());
            }
            else 
            {
                this._approveID = null;
            }
            
            this._startHour = short.Parse( dr["StartHour"].ToString() );
            this._startMinute = short.Parse(  dr["StartMinute"].ToString() );
            this._endHour = short.Parse( dr["EndHour"].ToString() );
            this._endMinute = short.Parse( dr["EndMinute"].ToString() );
            this._content = (string)dr["Content"];
            this._deleteFlag = short.Parse(  dr["DeleteFlag"].ToString() );

        }
        #endregion
    }
}

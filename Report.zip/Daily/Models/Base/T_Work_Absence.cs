﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/06/12
    /// T_Work_Absence class
    /// </summary>
    [Serializable]
    public class T_Work_Absence : M_Base<T_Work_Absence>
    {
        #region Contanst

        /// <summary>
        /// Max length of Content
        /// </summary>
        public const int REASON_MAX_LENGTH = 1000;

        /// <summary>
        /// Hour for start of a day
        /// </summary>
        public const int START_OF_DAY_HOUR = 0;

        /// <summary>
        /// Minute for start of a day
        /// </summary>
        public const int START_OF_DAY_MINUTE = 0;

        /// <summary>
        /// Hour for end of a day
        /// </summary>
        public const int END_OF_DAY_HOUR = 23;

        /// <summary>
        /// Minute for end of a day
        /// </summary>
        public const int END_OF_DAY_MINUTE = 59;

        #endregion

        #region Variable

        /// <summary>
        /// ApplyNo
        /// </summary>
        private string _no;

        /// <summary>
        /// PreApplyID
        /// </summary>
        private int? _preApplyID;

        /// <summary>
        /// Apply Status
        /// 0:未申請, 1:申請済, 2:承認済, 3:差戻, 4:棄却
        /// </summary>
        private short _applyStatus;

        /// <summary>
        /// Apply Date
        /// </summary>
        private DateTime? _applyDate;

        /// <summary>
        /// User ID
        /// </summary>
        private int _userID;

        /// <summary>
        /// EffectDate
        /// </summary>
        private DateTime _effectDate;

        /// <summary>
        /// Start date
        /// </summary>
        private DateTime _startDate;

        /// <summary>
        /// End date
        /// </summary>
        private DateTime _endDate;

        /// <summary>
        /// Reason
        /// </summary>
        private string _reason;

        /// <summary>
        /// ApprovedLevel
        /// </summary>
        private int _approvedLevel;

        /// <summary>
        /// AbsenceType
        /// </summary>
        private int _absenceType;

        /// <summary>
        /// RouteID
        /// </summary>
        private int _routeID;

        /// <summary>
        /// StatusFlag
        /// </summary>
        private short _statusFlag;

        /// <summary>
        /// VacationStatus
        /// </summary>
        private decimal? _duration;

        #endregion

        #region Property

        /// <summary>
        /// Get or set ApplyNo
        /// </summary>
        public string No
        {
            get { return this._no; }
            set
            {
                if (this._no != value)
                {
                    this._no = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get { return this._preApplyID; }
            set
            {
                if (this._preApplyID != value)
                {
                    this._preApplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }

        }

        /// <summary>
        /// RouteID
        /// </summary>
        public int RouteID
        {
            get { return _routeID; }
            set { _routeID = value; }
        }

        /// <summary>
        /// ApprovedLevel
        /// </summary>
        public int ApprovedLevel
        {
            get { return _approvedLevel; }
            set
            {
                if (this._approvedLevel != value)
                {
                    this._approvedLevel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Apply Status
        /// </summary>
        public short ApplyStatus
        {
            get { return this._applyStatus; }
            set
            {
                if (this._applyStatus != value)
                {
                    this._applyStatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// AbsenceType
        /// </summary>
        public int AbsenceType
        {
            get { return _absenceType; }
            set
            {
                if (this._absenceType != value)
                {
                    this._absenceType = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Apply date
        /// </summary>
        public DateTime? ApplyDate
        {
            get { return this._applyDate; }
            set
            {
                if (this._applyDate != value)
                {
                    this._applyDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set User ID
        /// </summary>
        public int UserID
        {
            get { return this._userID; }
            set
            {
                if (this._userID != value)
                {
                    this._userID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Start Date
        /// </summary>
        public DateTime StartDate
        {
            get { return this._startDate; }
            set
            {
                if (this._startDate != value)
                {
                    this._startDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set End Date
        /// </summary>
        public DateTime EndDate
        {
            get { return this._endDate; }
            set
            {
                if (this._endDate != value)
                {
                    this._endDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Reason
        /// </summary>
        public string Reason
        {
            get { return this._reason; }
            set
            {
                if (this._reason != value)
                {
                    this._reason = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set StatusFlag
        /// </summary>
        public short StatusFlag
        {
            get { return this._statusFlag; }
            set
            {
                if (this._statusFlag != value)
                {
                    this._statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Duration
        /// </summary>
        public decimal? Duration
        {
            get { return _duration; }
            set
            {
                if (this._duration != value)
                {
                    this._duration = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of T_Work_Absence
        /// </summary>
        public T_Work_Absence()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_Work_Absence
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Work_Absence(DbDataReader dr)
            : base(dr)
        {
            this._no = dr["No"].ToString();

            if (dr["PreApplyID"] != DBNull.Value)
            {
                this._preApplyID = int.Parse(dr["PreApplyID"].ToString());
            }
            else
            {
                this._preApplyID = null;
            }
            if (dr["Duration"] != DBNull.Value)
            {
                this._duration = decimal.Parse(dr["Duration"].ToString());
            }
            this._applyStatus = short.Parse(dr["ApplyStatus"].ToString());
            this._absenceType = int.Parse(dr["AbsenceType"].ToString());
            if (dr["ApplyDate"] != DBNull.Value)
            {
                this._applyDate = (DateTime)dr["ApplyDate"];
            }
            this._userID = int.Parse(dr["UserID"].ToString());
            this._routeID = int.Parse(dr["RouteID"].ToString());
            this._approvedLevel = int.Parse(dr["ApprovedLevel"].ToString());
            this._startDate = (DateTime)dr["StartDate"];
            this._endDate = (DateTime)dr["EndDate"];
            this._reason = dr["Reason"].ToString();
            this._statusFlag = short.Parse(dr["StatusFlag"].ToString());
        }

        #endregion
    }
    
}

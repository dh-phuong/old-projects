﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class T_Work_Out
    {
        public int WorkID { get; set; }
        public int StartHour { get; set; }
        public int StartMinute { get; set; }
        public int EndHour { get; set; }
        public int EndMinute { get; set; }

        public DateTime StartTime
        {
            get 
            {
                return new DateTime(1, 1, 1).AddHours(this.StartHour).AddMinutes(this.StartMinute);
            }
            set
            {
                this.StartHour = value.Hour;
                this.StartMinute = value.Minute;
            }
        }

        public DateTime EndTime
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(this.EndHour).AddMinutes(this.EndMinute);
            }
            set
            {
                this.EndHour = value.Hour;
                this.EndMinute = value.Minute;
            }
        }

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Work_Out()
            : base()
        {

        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Work_Out(DbDataReader dr)
        {
            this.WorkID = (int)dr["WorkID"];
            this.StartHour = (int)dr["StartHour"];
            this.StartMinute = (int)dr["StartMinute"];
            this.EndHour = (int)dr["EndHour"];
            this.EndMinute = (int)dr["EndMinute"];
        }

        #endregion
    }
}

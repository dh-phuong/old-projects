﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Config_D
    /// </summary>
    [Serializable]
    public class M_Config_D
    {
        #region Constant

        /// <summary>
        /// Max length of Value2
        /// </summary>
        public const int VALUE2_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of Value3
        /// </summary>
        public const int VALUE3_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of Value4
        /// </summary>
        public const int VALUE4_MAX_LENGTH = 50;

        /// <summary>
        /// Template form apply: leave (0)
        /// </summary>
        public const int TEMPLATE_FORM_APPLY_VACTION = 0;

        /// <summary>
        /// Template form apply: time (1) 
        /// </summary>
        public const int TEMPLATE_FORM_APPLY_OT = 1;

        /// <summary>
        /// Template form apply: time (1) 
        /// </summary>
        public const int TEMPLATE_FORM_LEAVE = 2;

        /// <summary>
        /// Template form apply: Absence Vacation
        /// </summary>
        public const int TEMPLATE_FORM_ABSENCE = 3;

        #endregion

        #region VALUE_CONST

        /// <summary>
        /// DATA : WITHOUT
        /// </summary>
        public const string DATA_WITHOUT = "0";

        /// <summary>
        /// DATA : ONLY
        /// </summary>
        public const string DATA_ONLY = "1";

        /// <summary>
        /// DATA : INCLUDE
        /// </summary>
        public const string DATA_INCLUDE = "2";
        
        /// <summary>
        /// VAT TYPE : EXCLUDE
        /// </summary>
        public const string VAT_TYPE_EXCLUDE = "0";

        /// <summary>
        /// VAT_TYPE : INCLUDE
        /// </summary>
        public const string VAT_TYPE_INCLUDE = "1";

        /// <summary>
        /// VAT_TYPE : FREE
        /// </summary>
        public const string VAT_TYPE_FREE = "2";

        /// <summary>
        /// METHOD_VAT_SUM : 1
        /// </summary>
        public const string METHOD_VAT_SUM = "0";
        /// <summary>
        /// METHOD_VAT_EACH : 2
        /// </summary>
        public const string METHOD_VAT_EACH = "1";

        /// <summary>
        /// QUANTITY_NOT_DECIMAL : Not Decimal
        /// </summary>
        public const string QUANTITY_NOT_DECIMAL = "0";

        /// <summary>
        /// QUANTITY_DECIMAL : Decimal
        /// </summary>
        public const string QUANTITY_DECIMAL = "1";

        /// <summary>
        /// DEFAULT_VIEW : Hide
        /// </summary>
        public const string DEFAULT_VIEW_HIDE = "0";

        /// <summary>
        /// DEFAULT_VIEW : Show
        /// </summary>
        public const string DEFAULT_VIEW_SHOW = "1";

        /// <summary>
        /// PRODUCT_CD_SETTING : Double set
        /// </summary>
        public const string PRODUCT_CD_SETTING_DOUBLE = "0";
        /// <summary>
        /// PRODUCT_CD_SETTING : Single set
        /// </summary>
        public const string PRODUCT_CD_SETTING_SINGLE = "1";

        /// <summary>
        /// PRODUCT_CD_SETTING : Same
        /// </summary>
        public const string PRODUCT_CD_SETTING_SAME = "2";
        /// <summary>
        /// PRODUCT_CD_SETTING : Not show cost product
        /// </summary>
        public const string PRODUCT_CD_SETTING_NOT_SHOW = "3";
        
        /// <summary>
        /// EXPIRY_DAY : Quotation
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Quotation = "0";
        /// <summary>
        /// EXPIRY_DAY : Purchase
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase = "1";
        /// <summary>
        /// EXPIRY_DAY : Delivery
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Delivery = "2";
        /// <summary>
        /// EXPIRY_DAY : Bill
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Bill = "3";

        //---------------Add 2015/01/06 ISV-HUNG-----------------//
        /// <summary>
        /// Sales Scheduled Complete Date
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Complete_Date = "4";
        /// <summary>
        /// Sales Scheduled Payment Date
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Sales_Payment_Date = "5";
        /// <summary>
        /// Pirchase Scheduled Payment Date
        /// </summary>
        public const string CONFIG_CD_DEFAULT_EXPIRY_DAY_Purchase_Payment_Date = "6";
        //---------------Add 2015/01/06 ISV-HUNG-----------------//

        /// <summary>
        /// PATERN_ACCEPT_REPORT : Customer
        /// </summary>
        public const string CONFIG_CD_PATERN_ACCEPT_REPORT_Customer = "0";
        /// <summary>
        /// PATERN_ACCEPT_REPORT : Category
        /// </summary>
        public const string CONFIG_CD_PATERN_ACCEPT_REPORT_Category = "1";
        /// <summary>
        /// PATERN_ACCEPT_REPORT : Sale1
        /// </summary>
        public const string CONFIG_CD_PATERN_ACCEPT_REPORT_Sale1 = "2";
        /// <summary>
        /// PATERN_ACCEPT_REPORT : Sale2
        /// </summary>
        public const string CONFIG_CD_PATERN_ACCEPT_REPORT_Sale2 = "3";


        /// <summary>
        /// 使用する商品コード:使用
        /// </summary>
        public const string CONFIG_CD_PRODUCT_CD_USED_ON = "0";

        /// <summary>
        /// 使用する商品コード:使用しない
        /// </summary>
        public const string CONFIG_CD_PRODUCT_CD_USED_OFF = "1";

        /// <summary>
        /// Profit設定: 0
        /// </summary>
        public const string CONFIG_CD_PROFIT_SETTING_0 = "0";

        /// <summary>
        /// Profit設定: 0
        /// </summary>
        public const string CONFIG_CD_PROFIT_SETTING_1 = "1";
        #endregion

        #region Variable
        
        /// <summary>
        /// Header ID
        /// </summary>
        public int HID { get; set; }
        
        /// <summary>
        /// No
        /// </summary>
        public int No { get; set; }
        
        /// <summary>
        /// Value1
        /// </summary>
        public int Value1 { get; set; }
        
        /// <summary>
        /// Value2
        /// </summary>
        public string Value2 { get; set; }
        
        /// <summary>
        /// Value3
        /// </summary>
        public string Value3 { get; set; }
        
        /// <summary>
        /// Value4
        /// </summary>
        public string Value4 { get; set; }

        /// <summary>
        /// Delete Flag
        /// Use for delete row
        /// </summary>
        public bool DelFlag { get; set; }
        
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of M_Config_D
        /// </summary>
        public M_Config_D()
        {
        }

        /// <summary>
        /// Contructor of M_Setting_D
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public M_Config_D(DbDataReader dr)
        {
            this.HID = (int)dr["HID"];
            this.No = (int)dr["No"];
            this.Value1 = (int)dr["Value1"];
            this.Value2 = (string)dr["Value2"];
            this.Value3 = (string)dr["Value3"];
            this.Value4 = (string)dr["Value4"];
        }

        #endregion
    }
}

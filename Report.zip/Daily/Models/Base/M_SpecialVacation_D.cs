﻿using System;
using System.Data.Common;
using System.Xml.Serialization;
using System.Web.Script.Serialization;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/06/10
    /// M_SpecialVacation_D Class
    /// </summary>
    [Serializable]
    public class M_SpecialVacation_D : M_Base<M_SpecialVacation_D>
    {
        #region Constant

        /// <summary>
        /// Max value of NumOfDays
        /// </summary>
        public const decimal NUM_OF_DAYS_MAX = 999.9M;

        #endregion

        #region Variable

        /// <summary>
        /// Delete flag
        /// </summary>
        private bool _delFlg;

        /// <summary>
        /// HID
        /// </summary>
        private int _hID;

        /// <summary>
        /// EffectDate
        /// </summary>
        private DateTime? _effectDate;

        /// <summary>
        /// ExpireDate
        /// </summary>
        private DateTime? _expireDate;

        /// <summary>
        /// Num of Time
        /// </summary>
        private decimal? _numOfTime;

        /// <summary>
        /// Unit Time
        /// </summary>
        private int? _unitTime;

        /// <summary>
        /// Include holiday flag
        /// </summary>
        private short? _includeHoliday;

        #endregion

        #region Property
        /// <summary>
        /// Get,set DelFlag
        /// </summary>
        public bool DelFlag
        {
            get { return this._delFlg; }
            set { this._delFlg = value; }
        }

        /// <summary>
        /// Get,set HID
        /// </summary>
        public int HID
        {
            get { return this._hID; }
            set { this._hID = value; }
        }

        [ScriptIgnore]
        public DateTime? EffectDate
        {
            get { return this._effectDate; }
            set { this._effectDate = value; }
        }

        /// <summary>
        /// Get,set ExpireDate
        /// </summary>
        [ScriptIgnore]
        public DateTime? ExpireDate
        {
            get { return this._expireDate; }
            set { this._expireDate = value; }
        }

        /// <summary>
        /// Get,set EffectDate
        /// </summary>
        [XmlElement]
        public string ProxyEffectDate
        {
            get
            {
                if (this.EffectDate.HasValue)
                {
                    return this.EffectDate.Value.ToString("D");
                }
                return null;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.EffectDate = DateTime.Parse(value);
                }
                else
                {
                    this.EffectDate = null;
                }
            }
        }

        /// <summary>
        /// Get,set ExpireDate
        /// </summary>
        [XmlElement]
        public string ProxyExpireDate
        {
            get
            {
                if (this.ExpireDate.HasValue)
                {
                    return this.ExpireDate.Value.ToString("D");
                }
                return null;
            }
            set
            {
                if (!string.IsNullOrEmpty(value))
                {
                    this.ExpireDate = DateTime.Parse(value);
                }
                else
                {
                    this.ExpireDate = null;
                }
            }
        }

        /// <summary>
        /// Get or Set Num of Time
        /// </summary>
        public decimal? NumOfTime
        {
            get { return this._numOfTime; }
            set { this._numOfTime = value; }
        }

        /// <summary>
        /// Get or Set Unit Time
        /// </summary>
        public int? UnitTime
        {
            get { return this._unitTime; }
            set { this._unitTime = value; }
        }

        /// <summary>
        /// Get or Set Include Holiday Flag
        /// </summary>
        public short? IncludeHoliday
        {
            get { return this._includeHoliday; }
            set { this._includeHoliday = value; }
        }


        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        public M_SpecialVacation_D()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_SpecialVacation_D(DbDataReader dr)
        {
            this._hID = (int)dr["HID"];
            this._effectDate = (DateTime)dr["EffectDate"];
            this._expireDate = (DateTime)dr["ExpireDate"];
            this._numOfTime = (decimal)dr["NumOfTime"];
            this._unitTime = (int)dr["UnitTime"];
            
        }

        #endregion

        #region Method

        /// <summary>
        /// Clone
        /// </summary>
        /// <returns></returns>
        public M_SpecialVacation_D Clone()
        {
            return (M_SpecialVacation_D)base.MemberwiseClone();
        }
        #endregion
    }
}

﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class M_Message
    {
        #region Const MessageID

        /// <summary>
        /// Please input {0}.
        /// </summary>
        public const string MSG_REQUIRE = "0001";

        /// <summary>
        /// {0} has already existed.
        /// </summary>
        public const string MSG_EXIST_CODE = "0002";

        /// <summary>
        /// Inputed {0} has not existed.
        /// </summary>
        public const string MSG_NOT_EXIST_CODE = "0003";

        /// <summary>
        /// An unexpected error has occurred. {0} data is failed.
        /// </summary>
        public const string MSG_UPDATE_FAILE = "0004";

        /// <summary>
        /// This data has been already updated by another user. Please press the Back button for trying again.
        /// </summary>
        public const string MSG_DATA_CHANGED = "0005";

        /// <summary>
        /// {0} is incorrect.
        /// </summary>
        public const string MSG_INCORRECT_FORMAT = "0006";

        /// <summary>
        /// {0} has already used in system. Can't delete.
        /// </summary>
        public const string MSG_EXIST_CANT_DELETE = "0007";

        /// <summary>
        /// Data will be created. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_INSERT = "0008";

        /// <summary>
        /// Data will be updated. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_UPDATE = "0009";

        /// <summary>
        /// Data will be deleted.  Are you OK?
        /// </summary>
        public const string MSG_QUESTION_DELETE = "0010";

        /// <summary>
        /// {0} is duplicated.
        /// </summary>
        public const string MSG_DUPLICATE = "0011";

        /// <summary>
        /// Old password is invalid.
        /// </summary>
        public const string MSG_PASS_INVALID = "0012";

        /// <summary>
        /// Confirm password is incorrect.
        /// </summary>
        public const string MSG_PASS_NOT_MATCH = "0013";

        /// <summary>
        /// Password must have at least 8 characters and contain both the alpha and the number.
        /// </summary>
        public const string MSG_PASSWORD_RULE = "0014";

        /// <summary>
        /// Please select {0}.
        /// </summary>
        public const string MSG_PLEASE_SELECT = "0015";

        /// <summary>
        /// {0} must be less than or equal to {1}.
        /// </summary>
        public const string MSG_LESS_THAN_EQUAL = "0016";

        /// <summary>
        /// Please input {0}. 【Row {1}】
        /// </summary>
        public const string MSG_REQUIRE_GRID = "0017";

        /// <summary>
        /// {0} is duplicated. 【Row {1}】
        /// </summary>
        public const string MSG_DUPLICATE_GRID = "0018";

        /// <summary>
        /// {0} must be less than or equal to {1}. 【Row {2}】
        /// </summary>
        public const string MSG_LESS_THAN_EQUAL_GRID = "0019";

        /// <summary>
        /// {0} is invalid. 【Row {1}】
        /// </summary>
        public const string MSG_INVALID_GRID = "0020";

        /// <summary>
        /// {0} must be greater than or equal to {1}. 【Row {2}】 
        /// </summary>
        public const string MSG_GREATER_THAN_EQUAL_GRID = "0021";

        /// <summary>
        /// {0} doesn't exist.
        /// </summary>
        public const string MSG_VALUE_NOT_EXIST = "0022";

        /// <summary>
        /// {0} was disabled. Please check the relevant master. 
        /// </summary>
        public const string MSG_CODE_DISABLE = "0023";

        /// <summary>
        /// Login information is incorrect.
        /// </summary>
        public const string MSG_LOGIN_INFO_INCORRECT = "0024";

        /// <summary>
        /// Can't create {0}. It made up to 9,999 in a month.
        /// </summary>
        public const string MSG_SIZE_MAX_NO = "0025";

        /// <summary>
        /// {0} must be greater than or equal to {1}.
        /// </summary>
        public const string MSG_GREATER_THAN_EQUAL = "0026";

        /// <summary>
        /// Inputed {0} has not existed. 【Row {1}】
        /// </summary>
        public const string MSG_NOT_EXIST_CODE_GRID = "0027";

        /// <summary>
        /// {0} must be less than {1}.
        /// </summary>
        public const string MSG_LESS_THAN = "0028";

        /// <summary>
        /// {0} must be greater than {1}. 【Row {2}】
        /// </summary>
        public const string MSG_GREATER_THAN_GRID = "0029";

        /// <summary>
        /// {0} must be less than {1}. 【Row {2}】
        /// </summary>
        public const string MSG_LESS_THAN_GRID = "0030";

        /// <summary>
        /// Download {0}. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_OUTPUT_FILE = "0031";

        /// <summary>
        /// Selected row will be deleted. Are you OK?
        /// </summary>
        public const string MSG_QUESTION_DELETE_SELECTED_ROW = "0032";

        /// <summary>
        /// Please select row data.
        /// </summary>
        public const string MSG_SELECT_ROW_DATA = "0033";


        /// <summary>
        /// Please select file to upload
        /// </summary>
        public const string MSG_SELECT_FILE_UPLOAD = "0034";

        /// <summary>
        /// {0} disabled. 【Row {1}】
        /// </summary>
        public const string MSG_CODE_DISABLE_GRID = "0035";

        /// <summary>
        /// File extension must be in {0}.
        /// </summary>
        public const string MSG_CODE_FILE_EXTENSION = "0036";

        /// <summary>
        /// Please input an image file path.
        /// </summary>
        public const string MSG_INPUT_IMAGE = "0037";

        /// <summary>
        /// This data has been already updated by another user. Please try again.
        /// </summary>
        public const string MSG_CODE_DELETED_UPDATED = "0038";

        /// <summary>
        /// Please Select {0}. 【Row {1}】
        /// </summary>
        public const string MSG_REQUIRE_SELECT_GRID = "0039";

        /// <summary>
        /// Size of {0} must be less than or equal to {1}.
        /// </summary>
        public const string MSG_SIZE_FILE_UPLOAD_LESS_THAN_EQUAL = "0040";

        /// <summary>
        /// {0} must be different {1}.
        /// </summary>
        public const string MSG_MUST_BE_DIFFERENT = "0041";

        /// <summary>
        /// {0} must be different {1}.【Row {2}】
        /// </summary>
        public const string MSG_MUST_BE_DIFFERENT_GRID = "0042";

        /// <summary>
        /// There are {0}  requisition that need you Approve.
        /// </summary>
        public const string MSG_REQUISITION = "0043";

        /// <summary>
        /// Đơn xin sẽ được gửi đi. Bạn có đồng ý?
        /// </summary>
        public const string MSG_QUESTION_CONFIRM_WORK = "0044";

        /// <summary>
        /// This day is {0}. Please regist an application for work in this day.
        /// </summary>
        public const string MSG_HOLIDAY = "0045";

        /// <summary>
        /// Đơn xin sẽ được duyệt. Bạn có đồng ý?
        /// </summary>
        public const string MSG_QUESTION_APPROVE_ACCEPT = "0046";

        /// <summary>
        /// Đơn xin sẽ được trả về. Bạn có đồng ý?
        /// </summary>
        public const string MSG_QUESTION_APPROVE_IGNORE = "0047";

        /// <summary>
        /// Cấp bậc của bạn phải lớn hơn người được đăng ký.
        /// </summary>  
        public const string MSG_LEVEL_GREATER_USER_LEVEL = "0048";

        /// <summary>
        /// Ngày phép của người này không đủ để xin phép.
        /// </summary>  
        public const string MSG_ANNUAL_DAY_NOT_ENOUGH = "0049";

        /// <summary>
        /// This data had been approved. Can't delete.
        /// </summary>  
        public const string MSG_COMPLETE_APPROVED_CANT_DELETE = "0050";

        /// <summary>
        /// Data will be cancel. Are you OK?
        /// </summary>  
        public const string MSG_QUESTION_APPROVE_CANCEL = "0051";

        /// <summary>
        /// {0} must be greater than {1}
        /// </summary>  
        public const string MSG_GREATER_THAN = "0052";

        /// <summary>
        /// {0} must be equal to {1}
        /// </summary>  
        public const string MSG_EQUAL_TO = "0053";

        /// <summary>
        /// {0} is invalid.
        /// </summary>  
        public const string MSG_DATA_INVALID = "0054";

        /// <summary>
        /// You can't regist the day belong to weekend or holidays.
        /// </summary>
        public const string MSG_CANT_REGIST_WEEKEND_HOLIDAYS = "0055";

        /// <summary>
        /// {0} must be greater than {1} day.
        /// </summary>
        public const string MSG_GREATER_THAN_1_DAY = "0056";

        /// <summary>
        /// {0} must be between {1} and {2}.
        /// </summary>
        public const string MSG_BETWEEN_VALUE = "0057";

        /// <summary>
        /// Data has been cancelled by another user. Please try again.
        /// </summary>
        public const string MSG_DATA_HAD_CANCEL = "0058";

        /// <summary>
        /// This route is invalid
        /// </summary>
        public const string MSG_ROUTE_INVALID = "0059";

        /// <summary>
        ///  Must be has list approver. Try again.
        /// </summary>
        public const string MSG_LIST_APPROVE_NOT_EXIST = "0060";

        /// <summary>
        ///  Data has already used in the system. Please select other data.
        /// </summary>
        public const string MSG_DATA_EXISTS = "0061";

        /// <summary>
        ///  This data does not exist in the system. Please select other data.
        /// </summary>
        public const string MSG_DATA_NOT_EXISTS = "0062";

        /// <summary>
        ///  Employee has existed in the approvers list. Can't update data.
        /// </summary>
        public const string MSG_DUPLICATE_USER = "0063";

        /// <summary>
        /// This user is not allowed to apply for other users. Please select other data.
        ///  Người dùng đang đăng nhập không có quyền xin giúp người dùng khác. Vui lòng chọn dữ liệu khác.
        /// </summary>
        public const string MSG_NOT_ALLOW_APPLY_TO_OTHERS = "0064";

        /// <summary>
        /// Data not exists. Please check the relevant master.
        /// </summary>
        public const string MSG_CHECK_RELEVANT_MASTER = "0065";

        /// <summary>
        /// Invalid data. Please contact the manager.
        /// </summary>
        public const string MSG_CONTACT_MANAGER = "0066";

        /// <summary>
        /// Can't cancel {0}.
        /// </summary>
        public const string MSG_CAN_NOT_CANCEL = "0067";

        /// <summary>
        /// {0} chưa được phê duyệt.
        /// </summary>
        public const string MSG_APPROVE_NOT_FINISH = "0068";


        /// <summary>
        /// Ngày {0} đã kết sổ không thể tiếp tục.
        /// </summary>
        public const string MSG_CANT_CONTINUE = "0069";

        #endregion

        public string MessageID { get; set; }
        public string Message1 { get; set; }
        public string Message2 { get; set; }
        public string Type { get; set; }

        public M_Message(DbDataReader dr)
        {
            this.MessageID = (string)dr["MessageID"];
            this.Message1 = (string)dr["Message1"];
            this.Message2 = (string)dr["Message2"];
            this.Type = (string)dr["Type"];
        }
    }
}

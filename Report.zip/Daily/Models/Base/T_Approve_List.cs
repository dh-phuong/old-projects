﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{ 
    /// <summary>
    /// T_Approve_List
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    [Serializable]
    public class T_Approve_List : M_Base<T_Approve_List>    
    {

        /// <summary>
        /// Max length of Remark
        /// </summary>
        public const int REMARK_MAX_LENGTH = 1000;

        public int ApproveID { get; set; }
        public int UserID { get; set; }
        public int? ApproveUID { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string Remark { get; set; }
        public int ApproveLevel { get; set; }
        public short RouteMethod { get; set; }
        public short ApproveFlag { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// T_Approve
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    [Serializable]
    public class T_Approve : M_Base<T_Approve> 
    {
        #region Contanst

        /// <summary>
        /// Max length of ApproveNo
        /// </summary>
        public const int APPROVE_NO_MAX_LENGTH = 20;

        /// <summary>
        /// Max length of Content
        /// </summary>
        public const int CONTENT_MAX_LENGTH = 1000;
        
        /// <summary>
        /// Status begin when insert new Approve
        /// </summary>
        public const int C_STATUS_APP_NEW = (int)Utilities.StatusApprove.New;

        #endregion

        public string ApproveNo { get; set; }
        public int UserID { get; set; }
       
        private DateTime? confirmDate;

        public DateTime? ConfirmDate
        {
            get { return confirmDate; }
            set
            {
                if (value != confirmDate)
                {
                    confirmDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        
        public short StatusApprove { get; set; }
       
        private short typeApplyID;

        public short TypeApplyID
        {
            get { return typeApplyID; }
            set
            {
                if (value != typeApplyID)
                {
                    typeApplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private DateTime? startDate;

        public DateTime? StartDate
        {
            get { return startDate; }
            set
            {
                if (value != startDate)
                {
                    startDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short startHour;

        public short StartHour
        {
            get { return startHour; }
            set
            {
                if (value != startHour)
                {
                    startHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short startMinute;

        public short StartMinute
        {
            get { return startMinute; }
            set
            {
                if (value != startMinute)
                {
                    startMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private DateTime? endDate;

        public DateTime? EndDate
        {
            get { return endDate; }
            set
            {
                if (value != endDate)
                {
                    endDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short endHour;

        public short EndHour
        {
            get { return endHour; }
            set
            {
                if (value != endHour)
                {
                    endHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short endMinute;

        public short EndMinute
        {
            get { return endMinute; }
            set
            {
                if (value != endMinute)
                {
                    endMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private string content;

        public string Content
        {
            get { return content; }
            set
            {
                if (value != content)
                {
                    content = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short deleteFlag;

        public short DeleteFlag
        {
            get { return deleteFlag; }
            set
            {
                if (value != deleteFlag)
                {
                    deleteFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private short allUserFlag;

        public short AllUserFlag
        {
            get { return allUserFlag; }
            set
            {
                if (value != allUserFlag)
                {
                    allUserFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Approve()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Approve(DbDataReader dr)
            : base(dr)
        {
            this.ApproveNo = (string)dr["ApproveNo"];
            this.UserID = (int)dr["UserID"];           
            if (dr["ConfirmDate"] != DBNull.Value)
            {
                this.confirmDate = (DateTime)dr["ConfirmDate"];
            }
            this.StatusApprove = short.Parse(string.Format("{0}", dr["Status"]));
            this.typeApplyID = short.Parse(string.Format("{0}", dr["TypeApplyID"]));
            this.startDate = (DateTime)dr["StartDate"];
            this.startHour = short.Parse(string.Format("{0}", dr["StartHour"]));
            this.startMinute = short.Parse(string.Format("{0}", dr["StartMinute"]));

            this.endDate = (DateTime)dr["EndDate"];
            this.endHour = short.Parse(string.Format("{0}", dr["EndHour"]));
            this.endMinute = short.Parse(string.Format("{0}", dr["EndMinute"]));

            this.content = (string)dr["Content"];
            this.DeleteFlag = short.Parse(string.Format("{0}", dr["DeleteFlag"]));
            this.AllUserFlag = short.Parse(string.Format("{0}", dr["AllUserFlag"]));
           
        }

        #endregion
    }
}

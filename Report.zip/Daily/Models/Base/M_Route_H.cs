﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_GroupUser_H
    /// Create  :isv.thuy
    /// Date    :25/07/2014
    /// </summary>
    [Serializable]
    public class M_Route_H : M_Base<M_Route_H>
    {
        #region Constant

        /// <summary>
        /// Max length of UserCD
        /// </summary>
        public const int ROUTE_CODE_MAX_LENGTH = 4;
        /// <summary>
        /// Max length of UserName1
        /// </summary>
        public const int ROUTE_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// level reader
        /// </summary>
        public const int LEVEL_READER = 99;

        /// <summary>
        /// level reader name
        /// </summary>
        public const string LEVEL_READER_NAME = "Reader";

        /// <summary>
        /// level applicant
        /// </summary>
        public const int LEVEL_APPLICANT = 0;

        /// <summary>
        /// level applicant name
        /// </summary>
        public const string LEVEL_APPLICANT_NAME = "Applicant";

        #endregion

        #region Variable

        public string RouteCD { get; set; }
        private string routeName;
        private short statusFlag;
        
        #endregion

        #region Property

        public short StatusFlag
        {
            get { return statusFlag; }
            set
            {
                if (value != statusFlag)
                {
                    statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string RouteName
        {
            get { return routeName; }
            set
            {
                if (value != routeName)
                {
                    routeName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_GroupUser_H
        /// </summary>
        public M_Route_H()
            : base()
        {

        }

        public M_Route_H(DbDataReader dr)
            : base(dr)
        {
            this.RouteCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["RouteCD"], M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);
            this.RouteName = (string)dr["RouteName"];
        }
        #endregion
    }
}

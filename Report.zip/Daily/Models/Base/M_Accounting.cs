﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/06/08
    /// Accounting class
    /// </summary>
     [Serializable]
    public class M_Accounting : M_Base<M_Accounting>
    {
        #region Contanst

        /// <summary>
        /// Max length of StartMonth
        /// </summary>
        public const int START_MONTH_MAX_LENGTH = 2;

        /// <summary>
        /// Max length of Closing
        /// </summary>
        public const int CLOSING_DAY_MAX_LENGTH = 2;

        /// <summary>
        /// Max length of Closing
        /// </summary>
        public const int UNIT_OF_TIME_MAX_LENGTH = 2;

        /// <summary>
        /// Max length of NumOfDay
        /// </summary>
        public const int NUM_OF_DAY_MAX_LENGTH = 2;

        /// <summary>
        /// Max value of UnitOfTime
        /// </summary>
        public const int MAX_UNIT_OF_TIME = 60;

        public const int MIN_START_MONTH = 1;

        /// <summary>
        /// Max value of Start Month
        /// </summary>
        public const int MAX_START_MONTH = 12;

        public const int MIN_CLOSING_DAY = 1;

        public const int MAX_CLOSING_DAY = 31;

        public const int MIN_NUM_OF_DAY = 1;

        public const int MAX_NUM_OF_DAY = 31;

        #endregion

        #region Variable

        /// <summary>
        /// StartMonth
        /// </summary>
        private int _startMonth;

        /// <summary>
        /// ClosingDay
        /// </summary>
        private int _closingDay;

        /// <summary>
        /// NumOfDay
        /// </summary>
        private int _numOfDay;

        /// <summary>
        /// numOfTime_H
        /// </summary>
        private int _numOfTime_H;

        /// <summary>
        /// numOfTime_M
        /// </summary>
        private int _numOfTime_M;

        /// <summary>
        /// UnitOfTime
        /// </summary>
        private int _unitOfTime;

        /// <summary>
        /// RoundLate
        /// </summary>
        private short _roundLate;

        /// <summary>
        /// RoundLeave
        /// </summary>
        private short _roundLeave;

        /// <summary>
        /// RoundOuting
        /// </summary>
        private short _roundOuting;

        /// <summary>
        /// RoundOT
        /// </summary>
        private short _roundOT;

        /// <summary>
        /// EarlyOT_SH
        /// </summary>
        private int _earlyOT_SH;

        /// <summary>
        /// EarlyOT_SM
        /// </summary>
        private int _earlyOT_SM;

        /// <summary>
        /// EarlyOT_EH
        /// </summary>
        private int _earlyOT_EH;

        /// <summary>
        /// EarlyOT_EM
        /// </summary>
        private int _earlyOT_EM;
        
        /// <summary>
        /// LateOT_SH
        /// </summary>
        private int _lateOT_SH;

        /// <summary>
        /// LateOT_SM
        /// </summary>
        private int _lateOT_SM;

        /// <summary>
        /// LateOT_EH
        /// </summary>
        private int _lateOT_EH;

        /// <summary>
        /// LateOT_EM
        /// </summary>
        private int _lateOT_EM;

       

        #endregion

        #region Property

        /// <summary>
        /// Get or set StartMonth
        /// </summary>
        public int StartMonth
        {
            get { return _startMonth; }
            set
            {
                if (value != _startMonth)
                {
                    _startMonth = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ClosingDay
        /// </summary>
        public int ClosingDay
        {
            get { return _closingDay; }
            set
            {
                if (value != _closingDay)
                {
                    _closingDay = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set NumOfDay
        /// </summary>
        public int NumOfDay
        {
            get { return _numOfDay; }
            set
            {
                if (value != _numOfDay)
                {
                    _numOfDay = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set NumOfTime_H
        /// </summary>
        public int NumOfTime_H
        {
            get { return _numOfTime_H; }
            set
            {
                if (value != _numOfTime_H)
                {
                    _numOfTime_H = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set NumOfTime_M
        /// </summary>
        public int NumOfTime_M
        {
            get { return _numOfTime_M; }
            set
            {
                if (value != _numOfTime_M)
                {
                    _numOfTime_M = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set UnitOfTime
        /// </summary>
        public int UnitOfTime
        {
            get { return _unitOfTime; }
            set
            {
                if (value != _unitOfTime)
                {
                    _unitOfTime = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RoundLate
        /// </summary>
        public short RoundLate
        {
            get { return _roundLate; }
            set
            {
                if (value != _roundLate)
                {
                    _roundLate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RoundLeave
        /// </summary>
        public short RoundLeave
        {
            get { return _roundLeave; }
            set
            {
                if (value != _roundLeave)
                {
                    _roundLeave = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RoundOuting
        /// </summary>
        public short RoundOuting
        {
            get { return _roundOuting; }
            set
            {
                if (value != _roundOuting)
                {
                    _roundOuting = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set RoundOT
        /// </summary>
        public short RoundOT
        {
            get { return _roundOT; }
            set
            {
                if (value != _roundOT)
                {
                    _roundOT = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set EarlyOT_SH
        /// </summary>
        public int EarlyOT_SH
        {
            get { return _earlyOT_SH; }
            set
            {
                if (value != _earlyOT_SH)
                {
                    _earlyOT_SH = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set EarlyOT_SM
        /// </summary>
        public int EarlyOT_SM
        {
            get { return _earlyOT_SM; }
            set
            {
                if (value != _earlyOT_SM)
                {
                    _earlyOT_SM = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime EarlyOT_ST
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(_earlyOT_SH).AddMinutes(_earlyOT_SM);
            }
            set
            {
                EarlyOT_SH = value.Hour;
                EarlyOT_SM = value.Minute;
            }
        }

        /// <summary>
        /// Get or set EarlyOT_EH
        /// </summary>
        public int EarlyOT_EH
        {
            get { return _earlyOT_EH; }
            set
            {
                if (value != _earlyOT_EH)
                {
                    _earlyOT_EH = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set EarlyOT_EH
        /// </summary>
        public int EarlyOT_EM
        {
            get { return _earlyOT_EM; }
            set
            {
                if (value != _earlyOT_EM)
                {
                    _earlyOT_EM = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime EarlyOT_ET
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(_earlyOT_EH).AddMinutes(_earlyOT_EM);
            }
            set
            {
                EarlyOT_EH = value.Hour;
                EarlyOT_EM = value.Minute;
            }
        }

        /// <summary>
        /// Get or set LateOT_SH
        public int LateOT_SH
        {
            get { return _lateOT_SH; }
            set
            {
                if (value != _lateOT_SH)
                {
                    _lateOT_SH = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set LateOT_SM
        public int LateOT_SM
        {
            get { return _lateOT_SM; }
            set
            {
                if (value != _lateOT_SM)
                {
                    _lateOT_SM = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime LateOT_ST
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(_lateOT_SH).AddMinutes(_lateOT_SM);
            }
            set
            {
                LateOT_SH = value.Hour;
                LateOT_SM = value.Minute;
            }
        }

        /// <summary>
        /// Get or set LateOT_EH
        public int LateOT_EH
        {
            get { return _lateOT_EH; }
            set
            {
                if (value != _lateOT_EH)
                {
                    _lateOT_EH = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set LateOT_EM
        public int LateOT_EM
        {
            get { return _lateOT_EM; }
            set
            {
                if (value != _lateOT_EM)
                {
                    _lateOT_EM = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime LateOT_ET
        {
            get
            {
                return new DateTime(1, 1, 1).AddHours(_lateOT_EH).AddMinutes(_lateOT_EM);
            }
            set
            {
                LateOT_EH = value.Hour;
                LateOT_EM = value.Minute;
            }
        }

        #endregion
                 
        #region Contructor

        /// <summary>
        /// Contructor M_Accounting
        /// </summary>
        public M_Accounting()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Accounting
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Accounting(DbDataReader dr)
            : base(dr)
        {
            this._startMonth = int.Parse( dr["StartMonth"].ToString());
            this._closingDay = int.Parse(dr["ClosingDay"].ToString());
            this._numOfDay = int.Parse(dr["NumOfDay"].ToString());
            this._numOfTime_H = int.Parse(dr["NumOfTime_H"].ToString());
            this._numOfTime_M = int.Parse(dr["NumOfTime_M"].ToString());
            this._unitOfTime = int.Parse(dr["UnitOfTime"].ToString());
            this._roundLate = short.Parse(dr["RoundLate"].ToString());
            this._roundLeave = short.Parse(dr["RoundLeave"].ToString());
            this._roundOuting = short.Parse(dr["RoundOuting"].ToString());
            this._roundOT = short.Parse(dr["RoundOT"].ToString());
            this._earlyOT_SH = int.Parse(dr["EarlyOT_SH"].ToString());
            this._earlyOT_SM = int.Parse(dr["EarlyOT_SM"].ToString());
            this._earlyOT_EH = int.Parse(dr["EarlyOT_EH"].ToString());
            this._earlyOT_EM = int.Parse(dr["EarlyOT_EM"].ToString());
            this._lateOT_SH = int.Parse(dr["LateOT_SH"].ToString());
            this._lateOT_SM = int.Parse(dr["LateOT_SM"].ToString());
            this._lateOT_EH = int.Parse(dr["LateOT_EH"].ToString());
            this._lateOT_EM = int.Parse(dr["LateOT_EM"].ToString());
        }

        #endregion
    }
}

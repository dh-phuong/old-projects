﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// TRAM - 2015/06/10
    /// M_SpecialVacation_H class
    /// </summary>
    [Serializable]
    public class M_SpecialVacation_H : M_Base<M_SpecialVacation_H>
    {
        #region Constant

        /// <summary>
        /// Max length of SpVacation Code
        /// </summary>
        public const int SP_VACATION_CODE_MAX_LENGTH = 5;

        /// <summary>
        /// Max length of SpVacation Name
        /// </summary>
        public const int SP_VACATION_NAME_MAX_LENGTH = 30;
       
        #endregion

        #region Variable

        /// <summary>
        /// SpVacationCode
        /// </summary>
        private string _spVacationCD;

        /// <summary>
        /// SpVacationNameUS
        /// </summary>
        private string _spVacationNameUS;

        /// <summary>
        /// SpVacationNameVN
        /// </summary>
        private string _spVacationNameVN;
      
        #endregion

        #region Property

        /// <summary>
        /// Get,set SpVacationCD
        /// </summary>
        public string SpVacationCD
        {
            get { return this._spVacationCD; }
            set
            {
                if (value != this._spVacationCD)
                {
                    this._spVacationCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SpVacationNameUS
        /// </summary>
        public string SpVacationNameUS
        {
            get { return this._spVacationNameUS; }
            set
            {
                if (value != this._spVacationNameUS)
                {
                    this._spVacationNameUS = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get,set SpVacationNameVN
        /// </summary>
        public string SpVacationNameVN
        {
            get { return this._spVacationNameVN; }
            set
            {
                if (value != this._spVacationNameVN)
                {
                    this._spVacationNameVN = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public M_SpecialVacation_H()
            : base()
        {
        }

        /// <summary>
        /// Contructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_SpecialVacation_H(DbDataReader dr)
            : base(dr)
        {
            this._spVacationCD = (string)dr["SpVacationCD"];
            this._spVacationNameUS = (string)dr["SpVacationNameUS"];
            this._spVacationNameVN = (string)dr["SpVacationNameVN"];
        }

        #endregion
    }
}

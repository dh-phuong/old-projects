﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Holiday Model
    /// </summary>
    [Serializable]
    public class M_Holiday : M_Base<M_Holiday>
    {
        #region Contanst
        
        /// <summary>
        /// Max length of name 1
        /// </summary>
        public const int HOLIDAY_NAME1_MAX_LENGTH = 100;

        /// <summary>
        /// Max length of name 2
        /// </summary>
        public const int HOLIDAY_NAME2_MAX_LENGTH = 100;

        #endregion

        #region Variant

        /// <summary>
        /// holidayYear
        /// </summary>
        private DateTime date;

        /// <summary>
        /// holiday name 1
        /// </summary>
        private string name1;

        /// <summary>
        /// holiday name 2
        /// </summary>
        private string name2;

        /// <summary>
        /// color
        /// </summary>
        private string color;

        /// <summary>
        /// repeats flg
        /// </summary>
        private short repeats;

        /// <summary>
        /// replace
        /// </summary>
        private short replace;
        #endregion

        #region Property

        /// <summary>
        /// Get or set date
        /// </summary>
        public DateTime Date
        {
            get { return date; }
            set
            {
                if (value != date)
                {
                    date = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set name 
        /// </summary>
        public string Name1
        {
            get { return name1; }
            set
            {
                if (value != name1)
                {
                    name1 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set name 2
        /// </summary>
        public string Name2
        {
            get { return name2; }
            set
            {
                if (value != name2)
                {
                    name2 = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set color
        /// </summary>
        public string Color
        {
            get { return color; }
            set
            {
                if (value != color)
                {
                    color = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set repeats
        /// </summary>
        public short Repeats
        {
            get { return repeats; }
            set
            {
                if (value != repeats)
                {
                    repeats = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set replace
        /// </summary>
        public short Replace
        {
            get { return replace; }
            set
            {
                if (value != replace)
                {
                    replace = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        public M_Holiday()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Holiday(DbDataReader dr)
            : base(dr)
        {
            this.date = (DateTime)dr["Date"];
            this.name1 = (string)dr["Name1"];
            this.name2 = (string)dr["Name2"];
            this.color = (string)dr["Color"];

            this.repeats = short.Parse(dr["Repeats"].ToString());
            this.replace = short.Parse(dr["Replace"].ToString());
        }

        #endregion
    }
}

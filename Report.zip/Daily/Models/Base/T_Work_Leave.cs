﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class T_Work_Leave : M_Base<T_Work_Leave>
    {
        #region Contanst

        /// <summary>
        /// Max length of Content
        /// </summary>
        public const int REASON_MAX_LENGTH = 1000;

        /// <summary>
        /// Hour for start of a day
        /// </summary>
        public const int START_OF_DAY_HOUR = 0;

        /// <summary>
        /// Minute for start of a day
        /// </summary>
        public const int START_OF_DAY_MINUTE = 0;

        /// <summary>
        /// Hour for end of a day
        /// </summary>
        public const int END_OF_DAY_HOUR = 23;

        /// <summary>
        /// Minute for end of a day
        /// </summary>
        public const int END_OF_DAY_MINUTE = 59;
        #endregion

        #region Variant

        private string no;
        private int? preapplyID;
        private short applystatus;
        private DateTime? applydate;
        private int userID;
        private DateTime? effectdate;
        private int starthour;
        private int startminute;
        private int endhour;
        private int endminute;
        private int durationhour;
        private int durationminute;
        private string reason;
        private int routeID;
        private int type;
        private int? approvedlevel;
        private short statusflag;

        #endregion

        #region Property

        /// <summary>
        /// Get or set No
        /// </summary>
        public string No
        {
            get { return no; }
            set
            {
                if (value != no)
                {
                    no = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get { return preapplyID; }
            set
            {
                if (value != preapplyID)
                {
                    preapplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return applystatus; }
            set
            {
                if (value != applystatus)
                {
                    applystatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ApplyDate
        /// </summary>
        public DateTime? ApplyDate
        {
            get { return applydate; }
            set
            {
                if (value != applydate)
                {
                    applydate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int UserID
        {
            get { return userID; }
            set
            {
                if (value != userID)
                {
                    userID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime? EffectDate
        {
            get { return effectdate; }
            set
            {
                if (value != effectdate)
                {
                    effectdate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartHour
        {
            get { return starthour; }
            set
            {
                if (value != starthour)
                {
                    starthour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartMinute
        {
            get { return startminute; }
            set
            {
                if (value != startminute)
                {
                    startminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EndHour
        {
            get { return endhour; }
            set
            {
                if (value != endhour)
                {
                    endhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EndMinute
        {
            get { return endminute; }
            set
            {
                if (value != endminute)
                {
                    endminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int DurationHour
        {
            get { return durationhour; }
            set
            {
                if (value != durationhour)
                {
                    durationhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int DurationMinute
        {
            get { return durationminute; }
            set
            {
                if (value != durationminute)
                {
                    durationminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Type
        {
            get { return type; }
            set
            {
                if (value != type)
                {
                    type = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Reason
        {
            get { return reason; }
            set
            {
                if (value != reason)
                {
                    reason = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int? ApprovedLevel
        {
            get { return approvedlevel; }
            set
            {
                if (value != approvedlevel)
                {
                    approvedlevel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public short StatusFlag
        {
            get { return statusflag; }
            set
            {
                if (value != statusflag)
                {
                    statusflag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// RouteID
        /// </summary>
        public int RouteID
        {
            get { return routeID; }
            set { routeID = value; }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        public T_Work_Leave()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Work_Leave(DbDataReader dr)
            : base(dr)
        {
            this.no = (string)dr["No"];
            //---------
            if (dr["PreApplyID"] != DBNull.Value)
            {
                this.preapplyID = int.Parse(dr["PreApplyID"].ToString());
            }
            else
            {
                this.preapplyID = null;
            }
            //---------
            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.applydate = (DateTime)dr["ApplyDate"];
            }
            //---------
            this.applystatus = short.Parse(dr["ApplyStatus"].ToString());
            this.userID = (int)dr["UserID"];
            this.type = int.Parse(dr["Type"].ToString());
            this.effectdate = (DateTime)dr["EffectDate"];
            //---------
            this.starthour = (int)dr["StartHour"];
            this.startminute = (int)dr["StartMinute"];
            //---------
            this.endhour = (int)dr["EndHour"];
            this.endminute = (int)dr["EndMinute"];
            //---------
            this.durationhour = (int)dr["DurationHour"];
            this.durationminute = (int)dr["DurationMinute"];
            //---------
            this.routeID = (int)dr["RouteID"];
            this.reason = (string)dr["Reason"];
            this.approvedlevel = (int)dr["ApprovedLevel"];
            this.statusflag = short.Parse(dr["StatusFlag"].ToString());
        }

        #endregion
    }
}

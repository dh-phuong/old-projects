﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Form_Link Model
    /// TRAM 2015/04/24
    /// </summary>
    [Serializable]
    public class M_Form_Link : M_Base<M_Form_Link>
    {
        #region Variant

            /// <summary>
            /// FormID
            /// </summary>
        public int _formID;

            /// <summary>
            /// UserID
            /// </summary>
        public int _userID;

            /// <summary>
            /// RouteID
            /// </summary>
        private int _routeID;

       #endregion

       #region Property

            /// <summary>
            /// Get or set FormID
            /// </summary>
            public int FormID
            {
                get { return _formID; }
                set
                {
                    if (value != _formID)
                    {
                        _formID = value;
                        this.Status = DataStatus.Changed;
                    }
                }
            }

            /// <summary>
            /// Get or set UserID
            /// </summary>
            public int UserID
            {
                get { return _userID; }
                set
                {
                    if (value != _userID)
                    {
                        _userID = value;
                        this.Status = DataStatus.Changed;
                    }
                }
            }
        
            /// <summary>
            /// Get or set RouteID
            /// </summary>
            public int RouteID
            {
                get { return _routeID; }
                set
                {
                    if (value != _routeID)
                    {
                        _routeID = value;
                        this.Status = DataStatus.Changed;
                    }
                }
            }

       #endregion

       #region Contructor

        /// <summary>
        /// Contructor M_Form_Link
        /// </summary>
        public M_Form_Link()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Form_Link
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Form_Link(DbDataReader dr)
            : base(dr)
        {
            this._formID = (int)dr["FormID"];
            this._userID = (int)dr["UserID"];
            this._routeID = (int)dr["RouteID"];
        }

        #endregion

    }
}

﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_Form Model
    /// ISV-TRUC
    /// 2015/04/23
    /// </summary>
    [Serializable]
    public class M_Form
    {
        #region Constant
        /// <summary>
        /// Max length DB of Type Name
        /// </summary>
        public const int TYPE_NAME_MAX_LENGTH_DB = 50;
        #endregion

        #region Variant

        /// <summary>
        /// FormID
        /// </summary>
        public int FormID { get; set; }
        
        /// <summary>
        /// StatusFlag
        /// </summary>
        private short StatusFlag{ get; set; }

        /// <summary>
        /// CreateDate
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// CreateUID
        /// </summary>
        public int CreateUID { get; set; }
        /// <summary>
        /// UpdateDate
        /// </summary>
        public DateTime UpdateDate { get; set; }
        /// <summary>
        /// UpdateUID
        /// </summary>
        public int UpdateUID { get; set; }
        /// <summary>
        /// Status (Is change data)
        /// </summary>
        public DataStatus Status { get; protected set; }
        
        #endregion

        #region Property

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Form
        /// </summary>
        public M_Form()
        {

        }

        /// <summary>
        /// Contructor M_Form
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Form(DbDataReader dr)            
        {
            this.FormID = (int)dr["FormID"];
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());
            this.CreateDate = (DateTime)dr["CreateDate"];
            this.CreateUID = (int)dr["CreateUID"];
            this.UpdateDate = (DateTime)dr["UpdateDate"];
            this.UpdateUID = (int)dr["UpdateUID"];
            this.Status = DataStatus.None;
        }

        #endregion
    }
}

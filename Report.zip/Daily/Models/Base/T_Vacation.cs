﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// T_Vacation
    /// VN-Nho
    /// 2015.03.18
    /// </summary>
    [Serializable]
    public class T_Vacation : M_Base<T_Vacation> 
    {
        #region Contanst

        /// <summary>
        /// Max length of Content
        /// </summary>
        public const int REASON_MAX_LENGTH = 1000;

        /// <summary>
        /// Status begin when insert new Approve
        /// </summary>
        public const int C_STATUS_APP_NEW = (int)Utilities.StatusApply.New;
        
        #endregion

        #region Variable
        /// <summary>
        /// VacationNo
        /// </summary>
        private string _vacationNo;

        /// <summary>
        /// PreVacationID
        /// </summary>
        private int? _preVacationID;
       
        /// <summary>
        /// Apply Status
        /// 0:未申請, 1:申請済, 2:承認済, 3:差戻, 4:棄却
        /// </summary>
        private short _applyStatus;

        /// <summary>
        /// Apply Date
        /// </summary>
        private DateTime? _applyDate;

        /// <summary>
        /// User ID
        /// </summary>
        private int _userID;

        /// <summary>
        /// Type apply ID
        /// </summary>
        private int _typeApplyID;

        /// <summary>
        /// Start date
        /// </summary>
        private DateTime? _vacationDate;

        /// <summary>
        /// Start Hour
        /// </summary>
        private short _vacationStatus;

        /// <summary>
        /// Reason
        /// </summary>
        private string _reason;

        /// <summary>
        /// StatusFlag
        /// </summary>
        private short _statusFlag;
        #endregion

        #region Property

        /// <summary>
        /// PreVacationID
        /// </summary>
        public int? PreVacationID
        {
            get { return _preVacationID; }
            set
            {
                if (this._preVacationID != value)
                {
                    this._preVacationID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// VacationNo
        /// </summary>
        public string VacationNo
        {
            get { return _vacationNo; }
            set
            {
                if (this._vacationNo != value)
                {
                    this._vacationNo = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        /// <summary>
        /// StatusFlag
        /// </summary>
        public short StatusFlag
        {
            get { return _statusFlag; }
            set
            {
                if (this._statusFlag != value)
                {
                    this._statusFlag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Apply Status
        /// </summary>
        public short ApplyStatus
        {
            get { return this._applyStatus; }
            set
            {
                if (this._applyStatus != value)
                {
                    this._applyStatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Apply date
        /// </summary>
        public DateTime? ApplyDate
        {
            get { return this._applyDate; }
            set
            {
                if (this._applyDate != value)
                {
                    this._applyDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set User ID
        /// </summary>
        public int UserID
        {
            get { return this._userID; }
            set 
            {
                if (this._userID != value)
                {
                    this._userID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Type Apply Status
        /// </summary>
        public int TypeApplyID
        {
            get { return this._typeApplyID; }
            set
            {
                if (this._typeApplyID != value)
                {
                    this._typeApplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Start Date
        /// </summary>
        public DateTime? VacationDate
        {
            get { return this._vacationDate; }
            set
            {
                if (this._vacationDate != value)
                {
                    this._vacationDate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Start Hour
        /// </summary>
        public short VacationStatus
        {
            get { return this._vacationStatus; }
            set
            {
                if (this._vacationStatus != value)
                {
                    this._vacationStatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Reason
        /// </summary>
        public string Reason
        {
            get { return this._reason; }
            set
            {
                if (this._reason != value)
                {
                    this._reason = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Vacation()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Vacation(DbDataReader dr)
            : base(dr)
        {
            this._applyStatus = short.Parse(dr["ApplyStatus"].ToString());
            if (dr["ApplyDate"] != DBNull.Value)
            {
                this._applyDate = (DateTime)dr["ApplyDate"];
            }
            this._userID = int.Parse(dr["UserID"].ToString());
            this._typeApplyID = int.Parse(dr["TypeApplyID"].ToString());
            this._vacationDate = (DateTime)dr["VacationDate"];
            this._vacationStatus = short.Parse(dr["VacationStatus"].ToString());
            this._reason = dr["Reason"].ToString();

            this._vacationNo = (string)dr["VacationNo"];

            if (dr["PreVacationID"] != DBNull.Value)
            {
                this._preVacationID = int.Parse(dr["PreVacationID"].ToString());
            }
        }

        #endregion
    }
}

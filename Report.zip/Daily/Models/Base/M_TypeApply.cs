﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_TypeApply Model
    /// </summary>
    [Serializable]
    public class M_TypeApply : M_Base<M_TypeApply>
    {
        #region Constant
        /// <summary>
        /// Work normal Id = 1
        /// </summary>
        public const int DEFAULT_NORMAL_WORK_ID = -1;
        public const int TYPE_APPLY_NAME_MAX_LENGTH = 50;
        public const int TYPE_APPLY_ROUTE_CD_MAX_LENGTH = 4;
        #endregion

        #region Variant

        /// <summary>
        /// form id
        /// </summary>
        private int formID;
        
        /// <summary>
        /// Type name
        /// </summary>
        private string typename;

        /// <summary>
        /// Min start hour
        /// </summary>
        private int minStartHour = -1;
        
        /// <summary>
        /// Min start minute
        /// </summary>
        private int minStartMinute = -1;
        
        /// <summary>
        /// Max end hour
        /// </summary>
        private int maxEndHour = -1;
        
        /// <summary>
        /// Max end minute
        /// </summary>
        private int maxEndMinute = -1;

        /// <summary>
        /// SalaryStatus
        /// </summary>
        private short salaryStatus;
        
        #endregion

        #region Property

        /// <summary>
        /// Get or set Type Name
        /// </summary>
        public string TypeName
        {
            get { return typename; }
            set
            {
                if (value != typename)
                {
                    typename = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Form id
        /// </summary>
        public int FormID
        {
            get { return formID; }
            set
            {
                if (value != formID)
                {
                    formID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        
        /// <summary>
        /// SalaryStatus
        /// </summary>
        public short SalaryStatus

        {
            get { return salaryStatus; }
            set
            {
                if (value != salaryStatus)
                {
                    salaryStatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Min Start hour
        /// </summary>
        public int MinStartHour
        {
            get { return minStartHour; }
            set
            {
                if (value != minStartHour)
                {
                    minStartHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Min start minute
        /// </summary>
        public int MinStartMinute
        {
            get { return minStartMinute; }
            set
            {
                if (value != minStartMinute)
                {
                    minStartMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set Max end hour
        /// </summary>
        public int MaxEndHour
        {
            get { return maxEndHour; }
            set
            {
                if (value != maxEndHour)
                {
                    maxEndHour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set max end minute
        /// </summary>
        public int MaxEndMinute
        {
            get { return maxEndMinute; }
            set
            {
                if (value != maxEndMinute)
                {
                    maxEndMinute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_TypeApply()
            : base()
        {

        }

        /// <summary>
        /// Contructor with database data reader
        /// </summary>
        /// <param name="dr"></param>
        public M_TypeApply(DbDataReader dr)
            : base(dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.TypeName = (string)dr["TypeName"];

            if (dr["FormID"] != DBNull.Value)
            {
                this.FormID = short.Parse(dr["FormID"].ToString());
            }

            if (dr["SalaryStatus"] != DBNull.Value)
            {
                this.SalaryStatus = short.Parse(dr["SalaryStatus"].ToString());
            }

            if (dr["MinStartHour"] != DBNull.Value)
            {
                this.MinStartHour = int.Parse(dr["MinStartHour"].ToString());
            }

            if (dr["MinStartMinute"] != DBNull.Value)
            {
                this.MinStartMinute = int.Parse(dr["MinStartMinute"].ToString());
            }

            if (dr["MaxEndHour"] != DBNull.Value)
            {
                this.MaxEndHour = int.Parse(dr["MaxEndHour"].ToString());
            }

            if (dr["MaxEndMinute"] != DBNull.Value)
            {
                this.MaxEndMinute = int.Parse(dr["MaxEndMinute"].ToString());
            }
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_User_Salary Model
    /// </summary>
    [Serializable]
    public class M_Staff_Salary
    {
        #region Variable

        private int id;
        private int userID;
        private DateTime startDate;
        private decimal basicSalary;
        private decimal allowance;

        #endregion

        #region Property

        public int ID
        {
            get { return id; }
            set
            {
                if (value != id)
                {
                    id = value;
                }
            }
        }


        public int UserID
        {
            get { return userID; }
            set
            {
                if (value != userID)
                {
                    userID = value;
                }
            }
        }

        public DateTime StartDate
        {
            get { return startDate; }
            set
            {
                if (value != startDate)
                {
                    startDate = value;
                }
            }
        }

        public decimal BasicSalary
        {
            get { return basicSalary; }
            set
            {
                if (value != basicSalary)
                {
                    basicSalary = value;
                }
            }
        }

        public decimal Allowance
        {
            get { return allowance; }
            set
            {
                if (value != allowance)
                {
                    allowance = value;
                }
            }
        }

        #endregion

        #region Constructor

        public M_Staff_Salary()
        {
            this.ID = 0;
            this.UserID = 0;
            this.StartDate = DateTime.MinValue;
            this.BasicSalary = 0;
            this.Allowance = 0;
        }

        public M_Staff_Salary(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.UserID = (int)dr["UserID"];
            this.StartDate = (DateTime)dr["StartDate"];
            this.BasicSalary = (decimal)dr["BasicSalary"];
            this.Allowance = (decimal)dr["Allowance"];
        }

        #endregion

        ///// <summary>
        ///// Is empty row
        ///// </summary>
        ///// <returns></returns>
        //public bool IsEmpty()
        //{
        //    if (this.basicSalary == 0 &&
        //        this.startDate == DateTime.MinValue &&
        //        this.allowance == 0 &&
        //        this.referenceFile == 0)
        //    {
        //        return true;
        //    }

        //    return false;
        //}
    }
}

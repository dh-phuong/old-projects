﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// ISV-TRUC - 2015/06/23
    /// M_Template_WorkDay class
    /// </summary>
    [Serializable]
    public class M_Template_WorkDay 
    {

        /// <summary>
        /// Status (Is change data)
        /// </summary>
        public DataStatus Status { get; protected set; }
        #region Variable
        /// <summary>
        /// SunShiftID
        /// </summary>
        private int _sunShiftID;
        /// <summary>
        /// SunShiftID
        /// </summary>
        public int SunShiftID
        {
            get { return _sunShiftID; }
            set
            {
                if (this._sunShiftID != value)
                {
                    this._sunShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// MonShiftID
        /// </summary>
        private int _monShiftID;
        /// <summary>
        /// MonShiftID
        /// </summary>
        public int MonShiftID
        {
            get { return _monShiftID; }
            set
            {
                if (this._monShiftID != value)
                {
                    this._monShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// TueShiftID
        /// </summary>
        private int _tueShiftID;
        /// <summary>
        /// TueShiftID
        /// </summary>
        public int TueShiftID
        {
            get { return _tueShiftID; }
            set
            {
                if (this._tueShiftID != value)
                {
                    this._tueShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// WedShiftID
        /// </summary>
        private int _wedShiftID;
        /// <summary>
        /// WedShiftID
        /// </summary>
        public int WedShiftID
        {
            get { return _wedShiftID; }
            set
            {
                if (this._wedShiftID != value)
                {
                    this._wedShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// ThuShiftID
        /// </summary>
        private int _thuShiftID;

        /// <summary>
        /// ThuShiftID
        /// </summary>
        public int ThuShiftID
        {
            get { return _thuShiftID; }
            set
            {
                if (this._thuShiftID != value)
                {
                    this._thuShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// FriShiftID
        /// </summary>
        private int _friShiftID;
        /// <summary>
        /// FriShiftID
        /// </summary>
        public int FriShiftID
        {
            get { return _friShiftID; }
            set
            {
                if (this._friShiftID != value)
                {
                    this._friShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// SatShiftID
        /// </summary>
        private int _satShiftID;
        /// <summary>
        /// SatShiftID
        /// </summary>
        public int SatShiftID
        {
            get { return _satShiftID; }
            set
            {
                if (this._satShiftID != value)
                {
                    this._satShiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }
        
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Template_WorkDay
        /// </summary>
        public M_Template_WorkDay()
        {
            
        }

        /// <summary>
        /// Contructor M_Template_WorkDay
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public M_Template_WorkDay(DbDataReader dr)
        {
            this._sunShiftID = dr["SunShiftID"] != DBNull.Value ? (int)dr["SunShiftID"] : -1;
            this._monShiftID = dr["MonShiftID"] != DBNull.Value ? (int)dr["MonShiftID"] : -1;
            this._tueShiftID = dr["TueShiftID"] != DBNull.Value ? (int)dr["TueShiftID"] : -1;
            this._wedShiftID = dr["WedShiftID"] != DBNull.Value ? (int)dr["WedShiftID"] : -1;
            this._thuShiftID = dr["ThuShiftID"] != DBNull.Value ? (int)dr["ThuShiftID"] : -1;
            this._friShiftID = dr["FriShiftID"] != DBNull.Value ? (int)dr["FriShiftID"] : -1;
            this._satShiftID = dr["SatShiftID"] != DBNull.Value ? (int)dr["SatShiftID"] : -1;
        }

        #endregion

    }
}

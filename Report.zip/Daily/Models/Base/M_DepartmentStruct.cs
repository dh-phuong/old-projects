﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class M_DepartmentStruct : M_Base<M_DepartmentStruct>
    {
        private int _DepartmentStructID;

        public int DepartmentStructID
        {
            get { return _DepartmentStructID; }
            set
            {
                if (value != this._DepartmentStructID)
                {
                    this._DepartmentStructID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private int _DepartmentID;

        public int DepartmentID
        {
            get { return _DepartmentID; }
            set
            {
                if (value != this._DepartmentID)
                {
                    this._DepartmentID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private int _DepartmentIdParent;

        public int DepartmentIdParent
        {
            get { return _DepartmentIdParent; }
            set
            {
                if (value != this._DepartmentIdParent)
                {
                    this._DepartmentIdParent = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        private int _OrderItem;

        public int OrderItem
        {
            get { return _OrderItem; }
            set
            {
                if (value != this._OrderItem)
                {
                    this._OrderItem = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

         #region Contructor
        /// <summary>
        /// Contructor M_Department
        /// </summary>
        public M_DepartmentStruct()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Department
        /// </summary>
        /// <param name="dr"></param>
        public M_DepartmentStruct(DbDataReader dr)
            : base(dr)
        {
            this.DepartmentID = (int)dr["DepartmentID"];
            this.DepartmentIdParent = (int)dr["DepartmentIdParent"];
            this.DepartmentStructID = (int)dr["DepartmentStructID"];
            this.OrderItem = (int)dr["OrderItem"];
            
        }     

        #endregion
    }
}

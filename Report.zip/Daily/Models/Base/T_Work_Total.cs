﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class T_Work_Total : M_Base<T_Work_Total>
    {
        public int UserID { get; set; }
        public DateTime MonthWork { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }

        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        //public int TimeLeaveHour { get; set; }
        //public int TimeLeaveMinute { get; set; }
        public int TimeLateHour { get; set; }
        public int TimeLateMinute { get; set; }
        public int TimeEarlyHour { get; set; }
        public int TimeEarlyMinute { get; set; }
        public int TimeOutHour { get; set; }
        public int TimeOutMinute { get; set; }

        public decimal VacationLeaves { get; set; }
        public decimal AbsenceLeaves { get; set; }

        public int OTEarlyHour { get; set; }
        public int OTEarlyMinute { get; set; }
        public int OTNormal1Hour { get; set; }
        public int OTNormal1Minute { get; set; }
        public int OTNormal2Hour { get; set; }
        public int OTNormal2Minute { get; set; }
        public int OTLateHour { get; set; }
        public int OTLateMinute { get; set; }
        public int OTHoliday1Hour { get; set; }
        public int OTHoliday1Minute { get; set; }
        public int OTHoliday2Hour { get; set; }
        public int OTHoliday2Minute { get; set; }

        public int TotalOTHour { get; set; }
        public int TotalOTMinute { get; set; }
        public int TotalWorkHour { get; set; }
        public int TotalWorkMinute { get; set; }

        #region Contructor

        /// <summary>
        /// Contructor of T_Work_Total
        /// </summary>
        public T_Work_Total()
            : base()
        {

        }

        /// <summary>
        /// Contructor of T_Work_Total
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Work_Total(DbDataReader dr)
            : base(dr)
        {
            this.UserID = (int)dr["UserID"];
            this.MonthWork = (DateTime)dr["MonthWork"];
            this.DateFrom = (DateTime)dr["DateFrom"];
            this.DateTo = (DateTime)dr["DateTo"];

            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            //this.TimeLeaveHour = (int)dr["TimeLeaveHour"];
            //this.TimeLeaveMinute = (int)dr["TimeLeaveMinute"];
            this.TimeLateHour = (int)dr["TimeLateHour"];
            this.TimeLateMinute = (int)dr["TimeLateMinute"];
            this.TimeEarlyHour = (int)dr["TimeEarlyHour"];
            this.TimeEarlyMinute = (int)dr["TimeEarlyMinute"];
            this.TimeOutHour = (int)dr["TimeOutHour"];
            this.TimeOutMinute = (int)dr["TimeOutMinute"];

            this.VacationLeaves = (decimal)dr["VacationLeaves"];
            this.AbsenceLeaves = (decimal)dr["AbsenceLeaves"];

            this.OTEarlyHour = (int)dr["OTEarlyHour"];
            this.OTEarlyMinute = (int)dr["OTEarlyMinute"];
            this.OTNormal1Hour = (int)dr["OTNormal1Hour"];
            this.OTNormal1Minute = (int)dr["OTNormal1Minute"];
            this.OTNormal2Hour = (int)dr["OTNormal2Hour"];
            this.OTNormal2Minute = (int)dr["OTNormal2Minute"];
            this.OTLateHour = (int)dr["OTLateHour"];
            this.OTLateMinute = (int)dr["OTLateMinute"];
            this.OTHoliday1Hour = (int)dr["OTHoliday1Hour"];
            this.OTHoliday1Minute = (int)dr["OTHoliday1Minute"];
            this.OTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this.OTHoliday2Minute = (int)dr["OTHoliday2Minute"];

            this.TotalOTHour = (int)dr["TotalOTHour"];
            this.TotalOTMinute = (int)dr["TotalOTMinute"];
            this.TotalWorkHour = (int)dr["TotalWorkHour"];
            this.TotalWorkMinute = (int)dr["TotalWorkMinute"];
        }

        #endregion
    }
}

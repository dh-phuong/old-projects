﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using DailyReport.Utilities;

namespace DailyReport.Models
{ 
    /// <summary>
    /// T_Apply_Approve_List
    /// VN-Nho
    /// 2015/03/18
    /// </summary>
    [Serializable]
    public class T_Apply_Approve_List
    {
        #region Contanst

            /// <summary>
            /// Max length of Remark
            /// </summary>
            public const int REASON_MAX_LENGTH = 1000;

        #endregion
        
        /// <summary>
        /// Get or set Apply ID
        /// </summary>
        public int _applyID;

        /// <summary>
        /// Get or set Route User ID
        /// </summary>
        public int _routeUID;

        /// <summary>
        /// Get or set Route Level
        /// </summary>
        public int _routeLevel;

        /// <summary>
        /// Get or set Route Method
        /// </summary>
        public short _routeMethod;

        /// <summary>
        /// RequireNum
        /// </summary>
        private int _requireNum;

        /// <summary>
        /// ProxyApprovalUser
        /// </summary>
        private string _proxyApprovalUser;
        

        #region RejectFlag
        /// <summary>
        /// RejectFlag1
        /// </summary>
        private short _rejectFlag1;
        /// <summary>
        /// RejectFlag1
        /// </summary>
        public short RejectFlag1
        {
            get { return _rejectFlag1; }
            set { _rejectFlag1 = value; }
        }
        /// <summary>
        /// RejectFlag2
        /// </summary>
        private short _rejectFlag2;
        /// <summary>
        /// RejectFlag2
        /// </summary>
        public short RejectFlag2
        {
            get { return _rejectFlag2; }
            set { _rejectFlag2 = value; }
        }
        /// <summary>
        /// RejectFlag3
        /// </summary>
        private short _rejectFlag3;
        /// <summary>
        /// RejectFlag3
        /// </summary>
        public short RejectFlag3
        {
            get { return _rejectFlag3; }
            set { _rejectFlag3 = value; }
        }
        /// <summary>
        /// RejectFlag4
        /// </summary>
        private short _rejectFlag4;
        /// <summary>
        /// RejectFlag4
        /// </summary>
        public short RejectFlag4
        {
            get { return _rejectFlag4; }
            set { _rejectFlag4 = value; }
        }
        /// <summary>
        /// RejectFlag5
        /// </summary>
        private short _rejectFlag5;
        /// <summary>
        /// RejectFlag5
        /// </summary>
        public short RejectFlag5
        {
            get { return _rejectFlag5; }
            set { _rejectFlag5 = value; }
        }
        /// <summary>
        /// RejectFlag6
        /// </summary>
        private short _rejectFlag6;
        /// <summary>
        /// RejectFlag6
        /// </summary>
        public short RejectFlag6
        {
            get { return _rejectFlag6; }
            set { _rejectFlag6 = value; }
        }
        /// <summary>
        /// RejectFlag7
        /// </summary>
        private short _rejectFlag7;
        /// <summary>
        /// RejectFlag7
        /// </summary>
        public short RejectFlag7
        {
            get { return _rejectFlag7; }
            set { _rejectFlag7 = value; }
        }

        #endregion

        #region RemandFlag
        /// <summary>
        /// RemandFlag1
        /// </summary>
        private short _remandFlag1;
        /// <summary>
        /// RemandFlag1
        /// </summary>
        public short RemandFlag1
        {
            get { return _remandFlag1; }
            set { _remandFlag1 = value; }
        }
        /// <summary>
        /// RemandFlag2
        /// </summary>
        private short _remandFlag2;
        /// <summary>
        /// RemandFlag2
        /// </summary>
        public short RemandFlag2
        {
            get { return _remandFlag2; }
            set { _remandFlag2 = value; }
        }
        /// <summary>
        /// RemandFlag3
        /// </summary>
        private short _remandFlag3;
        /// <summary>
        /// RemandFlag3
        /// </summary>
        public short RemandFlag3
        {
            get { return _remandFlag3; }
            set { _remandFlag3 = value; }
        }
        /// <summary>
        /// RemandFlag4
        /// </summary>
        private short _remandFlag4;
        /// <summary>
        /// RemandFlag4
        /// </summary>
        public short RemandFlag4
        {
            get { return _remandFlag4; }
            set { _remandFlag4 = value; }
        }
        /// <summary>
        /// RemandFlag5
        /// </summary>
        private short _remandFlag5;
        /// <summary>
        /// RemandFlag5
        /// </summary>
        public short RemandFlag5
        {
            get { return _remandFlag5; }
            set { _remandFlag5 = value; }
        }
        /// <summary>
        /// RemandFlag6
        /// </summary>
        private short _remandFlag6;
        /// <summary>
        /// RemandFlag6
        /// </summary>
        public short RemandFlag6
        {
            get { return _remandFlag6; }
            set { _remandFlag6 = value; }
        }
        /// <summary>
        /// RemandFlag7
        /// </summary>
        private short _remandFlag7;
        /// <summary>
        /// RemandFlag7
        /// </summary>
        public short RemandFlag7
        {
            get { return _remandFlag7; }
            set { _remandFlag7 = value; }
        }
        
        
        #endregion

        #region ApproveFlag
        /// <summary>
        /// ApproveFlag1
        /// </summary>
        private short _approveFlag1;
        /// <summary>
        /// ApproveFlag1
        /// </summary>
        public short ApproveFlag1
        {
            get { return _approveFlag1; }
            set { _approveFlag1 = value; }
        }
        /// <summary>
        /// ApproveFlag2
        /// </summary>
        private short _approveFlag2;
        /// <summary>
        /// ApproveFlag2
        /// </summary>
        public short ApproveFlag2
        {
            get { return _approveFlag2; }
            set { _approveFlag2 = value; }
        }
        /// <summary>
        /// ApproveFlag3
        /// </summary>
        private short _approveFlag3;
        /// <summary>
        /// ApproveFlag3
        /// </summary>
        public short ApproveFlag3
        {
            get { return _approveFlag3; }
            set { _approveFlag3 = value; }
        }
        /// <summary>
        /// ApproveFlag4
        /// </summary>
        private short _approveFlag4;
        /// <summary>
        /// ApproveFlag4
        /// </summary>
        public short ApproveFlag4
        {
            get { return _approveFlag4; }
            set { _approveFlag4 = value; }
        }
        /// <summary>
        /// ApproveFlag5
        /// </summary>
        private short _approveFlag5;
        /// <summary>
        /// ApproveFlag5
        /// </summary>
        public short ApproveFlag5
        {
            get { return _approveFlag5; }
            set { _approveFlag5 = value; }
        }
        /// <summary>
        /// ApproveFlag6
        /// </summary>
        private short _approveFlag6;
        /// <summary>
        /// ApproveFlag6
        /// </summary>
        public short ApproveFlag6
        {
            get { return _approveFlag6; }
            set { _approveFlag6 = value; }
        }
        /// <summary>
        /// ApproveFlag7
        /// </summary>
        private short _approveFlag7;
        /// <summary>
        /// ApproveFlag7
        /// </summary>
        public short ApproveFlag7
        {
            get { return _approveFlag7; }
            set { _approveFlag7 = value; }
        }
        /// <summary>
        /// ApproveFlag8
        /// </summary>
        private short _approveFlag8;
        /// <summary>
        /// ApproveFlag8
        /// </summary>
        public short ApproveFlag8
        {
            get { return _approveFlag8; }
            set { _approveFlag8 = value; }
        }
        /// <summary>
        /// ApproveFlag9
        /// </summary>
        private short _approveFlag9;
        /// <summary>
        /// ApproveFlag9
        /// </summary>
        public short ApproveFlag9
        {
            get { return _approveFlag9; }
            set { _approveFlag9 = value; }
        }
        
        #endregion
        
        #region ReadFlag
        /// <summary>
        /// ReadFlag1
        /// </summary>
        private short _readFlag1;
        /// <summary>
        /// ReadFlag1
        /// </summary>
        public short ReadFlag1
        {
            get { return _readFlag1; }
            set { _readFlag1 = value; }
        }
        /// <summary>
        /// ReadFlag2
        /// </summary>
        private short _readFlag2;
        /// <summary>
        /// ReadFlag2
        /// </summary>
        public short ReadFlag2
        {
            get { return _readFlag2; }
            set { _readFlag2 = value; }
        }

        /// <summary>
        /// ReadFlag3
        /// </summary>
        private short _readFlag3;
        /// <summary>
        /// ReadFlag3
        /// </summary>
        public short ReadFlag3
        {
            get { return _readFlag3; }
            set { _readFlag3 = value; }
        }

        /// <summary>
        /// ReadFlag4
        /// </summary>
        private short _readFlag4;
        /// <summary>
        /// ReadFlag4
        /// </summary>
        public short ReadFlag4
        {
            get { return _readFlag4; }
            set { _readFlag4 = value; }
        }

        /// <summary>
        /// ReadFlag5
        /// </summary>
        private short _readFlag5;
        /// <summary>
        /// ReadFlag5
        /// </summary>
        public short ReadFlag5
        {
            get { return _readFlag5; }
            set { _readFlag5 = value; }
        }
                
        #endregion

        #region Apply Flag
        /// <summary>
        /// ApplyFlag1
        /// </summary>
        private short _applyFlag1;
        /// <summary>
        /// ApplyFlag1
        /// </summary>
        public short ApplyFlag1
        {
            get { return _applyFlag1; }
            set { _applyFlag1 = value; }
        }
        /// <summary>
        /// ApplyFlag2
        /// </summary>
        private short _applyFlag2;
        /// <summary>
        /// ApplyFlag2
        /// </summary>
        public short ApplyFlag2
        {
            get { return _applyFlag2; }
            set { _applyFlag2 = value; }
        }

        /// <summary>
        /// ApplyFlag3
        /// </summary>
        private short _applyFlag3;
        /// <summary>
        /// ApplyFlag3
        /// </summary>
        public short ApplyFlag3
        {
            get { return _applyFlag3; }
            set { _applyFlag3 = value; }
        }

        /// <summary>
        /// ApplyFlag4
        /// </summary>
        private short _applyFlag4;
        /// <summary>
        /// ApplyFlag4
        /// </summary>
        public short ApplyFlag4
        {
            get { return _applyFlag4; }
            set { _applyFlag4 = value; }
        }
        
        #endregion

        /// <summary>
        /// RouteFlag1
        /// </summary>
        private short _routeFlag1;

        /// <summary>
        /// RouteFlag2
        /// </summary>
        private short _routeFlag2;

        /// <summary>
        /// RouteFlag3
        /// </summary>
        private short _routeFlag3;

        /// <summary>
        /// RouteFlag4
        /// </summary>
        private short _routeFlag4;

        /// <summary>
        /// RouteFlag5
        /// </summary>
        private short _routeFlag5;

        /// <summary>
        /// RouteFlag6
        /// </summary>
        private short _routeFlag6;

        /// <summary>
        /// RouteFlag7
        /// </summary>
        private short _routeFlag7;

        /// <summary>
        /// RouteFlag8
        /// </summary>
        private short _routeFlag8;

        /// <summary>
        /// RouteFlag9
        /// </summary>
        private short _routeFlag9;

        /// <summary>
        /// RouteFlag10
        /// </summary>
        private short _routeFlag10;
        
        /// <summary>
        /// Get or set Approve Status
        /// </summary>
        public short? _approveStatus;

        /// <summary>
        /// Get or set Approve User ID
        /// </summary>
        public int? _approveUID;

        /// <summary>
        /// Get or set Approve Date
        /// </summary>
        public DateTime? _approveDate;

        /// <summary>
        /// Get or set Reason
        /// </summary>
        public string _approveReason;

        #region Property

        /// <summary>
        /// Get or set ApplyID
        /// </summary>
        public int ApplyID
        {
            get { return this._applyID; }
            set
            {
                if (this._applyID != value)
                {
                    this._applyID = value;
                }
            }
        }

        /// <summary>
        /// Get or set RouteUID
        /// </summary>
        public int RouteUID
        {
            get { return this._routeUID; }
            set
            {
                if (this._routeUID != value)
                {
                    this._routeUID = value;
                }
            }
        }

        /// <summary>
        /// Get or set RouteLevel
        /// </summary>
        public int RouteLevel
        {
            get { return this._routeLevel; }
            set
            {
                if (this._routeLevel != value)
                {
                    this._routeLevel = value;
                }
            }

        }

        /// <summary>
        /// Get or set RouteMethod
        /// </summary>
        public short RouteMethod
        {
            get { return this._routeMethod; }
            set
            {
                if (this._routeMethod != value)
                {
                    this._routeMethod = value;
                }
            }

        }

        /// <summary>
        /// ProxyApprovalUser
        /// </summary>
        public string ProxyApprovalUser
        {
            get { return _proxyApprovalUser; }
            set { _proxyApprovalUser = value; }
        }
        
        /// <summary>
        /// RequireNum
        /// </summary>
        public int RequireNum
        {
            get { return _requireNum; }
            set
            {
                if (this._requireNum != value)
                {
                    this._requireNum = value;
                }
            }
        }
        

        /// <summary>
        /// Get or set ApproveStatus
        /// </summary>
        public short? ApproveStatus
        {
            get { return this._approveStatus; }
            set
            {
                if (this._approveStatus != value)
                {
                    this._approveStatus = value;
                }
            }

        }

        /// <summary>
        /// Get or set ApproveUID
        /// </summary>
        public int? ApproveUID
        {
            get { return this._approveUID; }
            set
            {
                if (this._approveUID != value)
                {
                    this._approveUID = value;
                }
            }

        }

        /// <summary>
        /// Get or set ApproveDate
        /// </summary>
        public DateTime? ApproveDate
        {
            get { return this._approveDate; }
            set
            {
                if (this._approveDate != value)
                {
                    this._approveDate = value;
                }
            }

        }

        /// <summary>
        /// Get or set ApproveReason
        /// </summary>
        public string ApproveReason
        {
            get { return this._approveReason; }
            set
            {
                if (this._approveReason != value)
                {
                    this._approveReason = value;
                }
            }

        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        public T_Apply_Approve_List()
        {
        }

        /// <summary>
        /// Contructor of T_Approve
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public T_Apply_Approve_List(DbDataReader dr)
        {
            this._applyID = short.Parse(dr["ApplyID"].ToString());
         
            this._routeUID = int.Parse(dr["RouteUID"].ToString());
            this._routeLevel = int.Parse(dr["RouteLevel"].ToString());
            this._routeMethod = short.Parse( dr["RouteMethod"].ToString());
            this._approveStatus = short.Parse(dr["ApproveStatus"].ToString());
            this._requireNum = int.Parse(dr["RequireNum"].ToString());

            //Apply Flag
            this._applyFlag1 = short.Parse(dr["ApplyFlag1"].ToString());
            this._applyFlag2 = short.Parse(dr["ApplyFlag2"].ToString());
            this._applyFlag3 = short.Parse(dr["ApplyFlag3"].ToString());
            this._applyFlag4 = short.Parse(dr["ApplyFlag4"].ToString());

            //Reject Flag
            this._rejectFlag1 = short.Parse(dr["RejectFlag1"].ToString());
            this._rejectFlag2 = short.Parse(dr["RejectFlag2"].ToString());
            this._rejectFlag3 = short.Parse(dr["RejectFlag3"].ToString());
            this._rejectFlag4 = short.Parse(dr["RejectFlag4"].ToString());
            this._rejectFlag5 = short.Parse(dr["RejectFlag5"].ToString());
            this._rejectFlag6 = short.Parse(dr["RejectFlag6"].ToString());
            this._rejectFlag7 = short.Parse(dr["RejectFlag7"].ToString());

            //Remand Flag
            this._remandFlag1 = short.Parse(dr["RemandFlag1"].ToString());
            this._remandFlag2 = short.Parse(dr["RemandFlag2"].ToString());
            this._remandFlag3 = short.Parse(dr["RemandFlag3"].ToString());
            this._remandFlag4 = short.Parse(dr["RemandFlag4"].ToString());
            this._remandFlag5 = short.Parse(dr["RemandFlag5"].ToString());
            this._remandFlag6 = short.Parse(dr["RemandFlag6"].ToString());
            this._remandFlag7 = short.Parse(dr["RemandFlag7"].ToString());

            //Approve Flag
            this._approveFlag1 = short.Parse(dr["ApproveFlag1"].ToString());
            this._approveFlag2 = short.Parse(dr["ApproveFlag2"].ToString());
            this._approveFlag3 = short.Parse(dr["ApproveFlag3"].ToString());
            this._approveFlag4 = short.Parse(dr["ApproveFlag4"].ToString());
            this._approveFlag5 = short.Parse(dr["ApproveFlag5"].ToString());
            this._approveFlag6 = short.Parse(dr["ApproveFlag6"].ToString());
            this._approveFlag7 = short.Parse(dr["ApproveFlag7"].ToString());
            this._approveFlag8 = short.Parse(dr["ApproveFlag8"].ToString());
            this._approveFlag9 = short.Parse(dr["ApproveFlag9"].ToString());

            //Read Flag
            this._readFlag1 = short.Parse(dr["ReadFlag1"].ToString());
            this._readFlag2 = short.Parse(dr["ReadFlag2"].ToString());
            this._readFlag3 = short.Parse(dr["ReadFlag3"].ToString());
            this._readFlag4 = short.Parse(dr["ReadFlag4"].ToString());
            this._readFlag5 = short.Parse(dr["ReadFlag5"].ToString());
           
            if (dr["ApproveUID"] != DBNull.Value)
            {
                this._approveUID = int.Parse(dr["ApproveUID"].ToString());
            }
            if (dr["ApproveDate"] != DBNull.Value)
            {
                this._approveDate = DateTime.Parse(dr["ApproveDate"].ToString());
            }
            if (dr["ApproveReason"] != DBNull.Value)
            {
                this._approveReason = dr["ApproveReason"].ToString();
            }
        }

        #endregion

        #region method

        /// <summary>
        /// Get apply setting flag
        /// </summary>
        /// <param name="authorType"></param>
        /// <returns></returns>
        public bool GetApplySetting(ApplySetting applyType)
        {
            switch (applyType)
            {
                case ApplySetting.ProxyAll:
                    return this.ApplyFlag1 == 1;
                case ApplySetting.ProxyDept:
                    return this.ApplyFlag2 == 1;
                case ApplySetting.Mail:
                    return this.ApplyFlag3 == 1;
                case ApplySetting.MailAll:
                    return this.ApplyFlag4 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get approve setting
        /// </summary>
        /// <param name="approveType"></param>
        /// <returns></returns>
        public bool GetApproveSetting(ApproveSetting approveType)
        {
            switch (approveType)
            {
                case ApproveSetting.SeniorApprove:
                    return this.ApproveFlag1 == 1;
                case ApproveSetting.SeniorApproveAll:
                    return this.ApproveFlag2 == 1;
                case ApproveSetting.MailAppliciant:
                    return this.ApproveFlag3 == 1;
                case ApproveSetting.MailPreAll:
                    return this.ApproveFlag4 == 1;
                case ApproveSetting.MailPre:
                    return this.ApproveFlag5 == 1;
                case ApproveSetting.MailCurrentLevel:
                    return this.ApproveFlag6 == 1;
                case ApproveSetting.MailNext:
                    return this.ApproveFlag7 == 1;
                case ApproveSetting.MailNextAll:
                    return this.ApproveFlag8 == 1;
                case ApproveSetting.Reader:
                    return this.ApproveFlag9 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get Reject setting
        /// </summary>
        /// <param name="rejectType"></param>
        /// <returns></returns>
        public bool GetRejectSetting(RejectSetting rejectType)
        {
            switch (rejectType)
            {
                case RejectSetting.RejectAuthor:
                    return this.RejectFlag1 == 1;
                case RejectSetting.MailAppliciant:
                    return this.RejectFlag2 == 1;
                case RejectSetting.MailPreAll:
                    return this.RejectFlag3 == 1;
                case RejectSetting.MailPre:
                    return this.RejectFlag4 == 1;
                case RejectSetting.MailCurrentLevel:
                    return this.RejectFlag5 == 1;
                case RejectSetting.MailNext:
                    return this.RejectFlag6 == 1;
                case RejectSetting.MailNextAll:
                    return this.RejectFlag7 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get remand setting
        /// </summary>
        /// <param name="remandType"></param>
        /// <returns></returns>
        public bool GetRemandSetting(RemandSetting remandType)
        {
            switch (remandType)
            {
                case RemandSetting.RemandAuthor:
                    return this.RemandFlag1 == 1;
                case RemandSetting.MailAppliciant:
                    return this.RemandFlag2 == 1;
                case RemandSetting.MailPreAll:
                    return this.RemandFlag3 == 1;
                case RemandSetting.MailPre:
                    return this.RemandFlag4 == 1;
                case RemandSetting.MailCurrentLevel:
                    return this.RemandFlag5 == 1;
                case RemandSetting.MailNext:
                    return this.RemandFlag6 == 1;
                case RemandSetting.MailNextAll:
                    return this.RemandFlag7 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get read setting
        /// </summary>
        /// <param name="readType"></param>
        /// <returns></returns>
        public bool GetReadSetting(ReadSetting readType)
        {
            switch (readType)
            {
                case ReadSetting.ReadAuthor:
                    return this.ReadFlag1 == 1;
                case ReadSetting.MailAppliciant:
                    return this.ReadFlag2 == 1;
                case ReadSetting.MailPreAll:
                    return this.ReadFlag3 == 1;
                case ReadSetting.MailPre:
                    return this.ReadFlag4 == 1;
                case ReadSetting.MailGroup:
                    return this.ReadFlag5 == 1;
                default:
                    return false;
            }
        }

        #endregion
    }
}

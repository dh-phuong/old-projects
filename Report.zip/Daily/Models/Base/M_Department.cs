﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// M_Department
    /// ISV-TRAM
    /// 2015/03/19
    /// </summary>
    [Serializable]
    public class M_Department : M_Base<M_Department>
    {
        #region Contanst

        /// <summary>
        /// Max length of DepartmentCD
        /// </summary>
        public const int DEPARTRMENT_CODE_MAX_LENGTH = 10;

        /// <summary>
        /// Max length of DepartmentName
        /// </summary>
        public const int DEPARTRMENT_NAME_MAX_LENGTH = 50;

        /// <summary>
        /// Max length of DEPARTRMENTCD to show
        /// </summary>
        public const int MAX_DEPARTRMENT_CODE_SHOW = 4;        

        #endregion

        #region Variable

        /// <summary>
        /// DepartmentCD
        /// </summary>
        private string departmentCD { get; set; }

        /// <summary>
        /// DepartmentName
        /// </summary>
        private string departmentName;

        #endregion

        #region Property

        /// <summary>
        /// DepartmentName
        /// </summary>
        public string DepartmentCD
        {
            get { return departmentCD; }
            set
            {
                if (value != departmentCD)
                {
                    departmentCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// DepartmentName
        /// </summary>
        public string DepartmentName
        {
            get { return departmentName; }
            set
            {
                if (value != departmentName)
                {
                    departmentName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor M_Department
        /// </summary>
        public M_Department()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Department
        /// </summary>
        /// <param name="dr"></param>
        public M_Department(DbDataReader dr)
            : base(dr)
        {
            this.departmentCD = (string)dr["DepartmentCD"];
            this.departmentName = dr["DepartmentName"].ToString();

        }

        #endregion
    }
}

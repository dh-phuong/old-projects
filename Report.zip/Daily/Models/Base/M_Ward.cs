﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    public class M_Ward : M_Base<M_Ward>
    {
        #region Contanst

        /// <summary>
        /// Max length of Ward code in database
        /// </summary>
        public const int WARD_CODE_MAX_LEN_DB = 10;

        /// <summary>
        /// Max length of Ward code in display
        /// </summary>
        public const int WARD_CODE_MAX_LEN_SHOW = 5;

        /// <summary>
        /// Max length of Ward name
        /// </summary>
        public const int WARD_NAME_MAX_LEN = 50;

        #endregion

        #region Variale

        /// <summary>
        /// District ID
        /// </summary>
        private int _districtID;
        
        /// <summary>
        /// Ward code
        /// </summary>
        private string _wardCD;
        
        /// <summary>
        /// Ward name
        /// </summary>
        private string _wardName;

        #endregion

        #region Property

        /// <summary>
        /// Get or set district id
        /// </summary>
        public int DistrictID
        {
            get { return _districtID; }
            set 
            {
                if (value != _districtID)
                {
                    _districtID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ward code
        /// </summary>
        public string WardCD 
        {
            get { return _wardCD; }
            set
            {
                if (value != _wardCD)
                {
                    _wardCD = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ward name
        /// </summary>
        public string WardName
        {
            get { return _wardName; }
            set 
            {
                if (value != _wardName)
                {
                    _wardName = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Contructor
        /// </summary>
        public M_Ward()
            :base()
        { }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr"></param>
        public M_Ward(DbDataReader dr)
            : base(dr)
        {
            this.ID = (int)dr["ID"];
            this.DistrictID = (int)dr["DistrictID"];
            this.WardCD = EditDataUtil.ToFixCodeShow((string)dr["WardCD"], M_Ward.WARD_CODE_MAX_LEN_SHOW);
            this.WardName = (string)dr["WardName"];
        }

        #endregion
    }
}

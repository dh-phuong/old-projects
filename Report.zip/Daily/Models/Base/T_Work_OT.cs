﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class T_Work_OT Model
    /// </summary>
    [Serializable]
    public class T_Work_OT : M_Base<T_Work_OT>
    {
        #region Contanst

        /// <summary>
        /// Max length of Reason
        /// </summary>
        public const int REASON_MAX_LENGTH = 1000;
        #endregion

        #region Variant

        private string no;
        private int? preapplyID;
        private short applystatus;
        private DateTime? applydate;
        private int userID;
        private DateTime effectdate;
        private int shiftID;
        private string shiftname;
        private int starthour;
        private int startminute;
        private int endhour;
        private int endminute;
        private int OTstarthour;
        private int OTstartminute;
        private int OTendhour;
        private int OTendminute;
        private int earlyhour;
        private int earlyminute;
        private int normal1hour;
        private int normal1minute;
        private int normal2hour;
        private int normal2minute;
        private int latehour;
        private int lateminute;
        private int holiday1hour;
        private int holiday1minute;
        private int holiday2hour;
        private int holiday2minute;
        private string reason;
        private int routeID;
        private int approvedlevel;
        private short statusflag;

        #endregion

        #region Property

        /// <summary>
        /// Get or set No
        /// </summary>
        public string No
        {
            get { return no; }
            set
            {
                if (value != no)
                {
                    no = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get { return preapplyID; }
            set
            {
                if (value != preapplyID)
                {
                    preapplyID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return applystatus; }
            set
            {
                if (value != applystatus)
                {
                    applystatus = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        /// <summary>
        /// Get or set ApplyDate
        /// </summary>
        public DateTime? ApplyDate
        {
            get { return applydate; }
            set
            {
                if (value != applydate)
                {
                    applydate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int UserID
        {
            get { return userID; }
            set
            {
                if (value != userID)
                {
                    userID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public DateTime EffectDate
        {
            get { return effectdate; }
            set
            {
                if (value != effectdate)
                {
                    effectdate = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int ShiftID
        {
            get { return shiftID; }
            set
            {
                if (value != shiftID)
                {
                    shiftID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string ShiftName
        {
            get { return shiftname; }
            set
            {
                if (value != shiftname)
                {
                    shiftname = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartHour
        {
            get { return starthour; }
            set
            {
                if (value != starthour)
                {
                    starthour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int StartMinute
        {
            get { return startminute; }
            set
            {
                if (value != startminute)
                {
                    startminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EndHour
        {
            get { return endhour; }
            set
            {
                if (value != endhour)
                {
                    endhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EndMinute
        {
            get { return endminute; }
            set
            {
                if (value != endminute)
                {
                    endminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTStartHour
        {
            get { return OTstarthour; }
            set
            {
                if (value != OTstarthour)
                {
                    OTstarthour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTStartMinute
        {
            get { return OTstartminute; }
            set
            {
                if (value != OTstartminute)
                {
                    OTstartminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTEndHour
        {
            get { return OTendhour; }
            set
            {
                if (value != OTendhour)
                {
                    OTendhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int OTEndMinute
        {
            get { return OTendminute; }
            set
            {
                if (value != OTendminute)
                {
                    OTendminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EarlyHour
        {
            get { return earlyhour; }
            set
            {
                if (value != earlyhour)
                {
                    earlyhour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int EarlyMinute
        {
            get { return earlyminute; }
            set
            {
                if (value != earlyminute)
                {
                    earlyminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Normal1Hour
        {
            get { return normal1hour; }
            set
            {
                if (value != normal1hour)
                {
                    normal1hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Normal1Minute
        {
            get { return normal1minute; }
            set
            {
                if (value != normal1minute)
                {
                    normal1minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Normal2Hour
        {
            get { return normal2hour; }
            set
            {
                if (value != normal2hour)
                {
                    normal2hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Normal2Minute
        {
            get { return normal2minute; }
            set
            {
                if (value != normal2minute)
                {
                    normal2minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int LateHour
        {
            get { return latehour; }
            set
            {
                if (value != latehour)
                {
                    latehour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int LateMinute
        {
            get { return lateminute; }
            set
            {
                if (value != lateminute)
                {
                    lateminute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Holiday1Hour
        {
            get { return holiday1hour; }
            set
            {
                if (value != holiday1hour)
                {
                    holiday1hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Holiday1Minute
        {
            get { return holiday1minute; }
            set
            {
                if (value != holiday1minute)
                {
                    holiday1minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Holiday2Hour
        {
            get { return holiday2hour; }
            set
            {
                if (value != holiday2hour)
                {
                    holiday2hour = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int Holiday2Minute
        {
            get { return holiday2minute; }
            set
            {
                if (value != holiday2minute)
                {
                    holiday2minute = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int RouteID
        {
            get { return routeID; }
            set
            {
                if (value != routeID)
                {
                    routeID = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public string Reason
        {
            get { return reason; }
            set
            {
                if (value != reason)
                {
                    reason = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public int ApprovedLevel
        {
            get { return approvedlevel; }
            set
            {
                if (value != approvedlevel)
                {
                    approvedlevel = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        public short StatusFlag
        {
            get { return statusflag; }
            set
            {
                if (value != statusflag)
                {
                    statusflag = value;
                    this.Status = DataStatus.Changed;
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        public T_Work_OT()
            : base()
        {

        }

        /// <summary>
        /// Contructor M_Holiday
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Work_OT(DbDataReader dr)
            : base(dr)
        {
            this.no = (string)dr["No"];


            if (dr["PreApplyID"] == DBNull.Value)
            {
                this.preapplyID = null;
            }
            else
            {
                this.preapplyID = (int)dr["PreApplyID"];
            }

            this.applystatus = short.Parse(dr["ApplyStatus"].ToString());

            if (dr["ApplyDate"] == DBNull.Value)
            {
                this.applydate = null;
            }
            else
            {
                this.applydate = (DateTime)dr["ApplyDate"];
            }
            
            this.userID = int.Parse(dr["UserID"].ToString());
            this.effectdate = (DateTime)dr["EffectDate"];
            this.shiftID = (int)dr["ShiftID"];
            this.shiftname = (string)dr["ShiftName"];
            this.starthour = (int)dr["StartHour"];
            this.startminute = (int)dr["StartMinute"];
            this.endhour = (int)dr["EndHour"];
            this.endminute = (int)dr["EndMinute"];
            this.OTstarthour = (int)dr["OTStartHour"];
            this.OTstartminute = (int)dr["OTStartMinute"];
            this.OTendhour = (int)dr["OTEndHour"];
            this.OTendminute = (int)dr["OTEndMinute"];
            this.earlyhour = (int)dr["EarlyHour"];
            this.earlyminute = (int)dr["EarlyMinute"];
            this.normal1hour = (int)dr["Normal1Hour"];
            this.normal1minute = (int)dr["Normal1Minute"];
            this.normal2hour = (int)dr["Normal2Hour"];
            this.normal2minute = (int)dr["Normal2Minute"];
            this.latehour = (int)dr["LateHour"];
            this.lateminute = (int)dr["LateMinute"];
            this.holiday1hour = (int)dr["Holiday1Hour"];
            this.holiday1minute = (int)dr["Holiday1Minute"];
            this.holiday2hour = (int)dr["Holiday2Hour"];
            this.holiday2minute = (int)dr["Holiday2Minute"];
            this.reason = (string)dr["Reason"];
            this.routeID = (int)dr["RouteID"];
            this.approvedlevel = (int)dr["ApprovedLevel"];
            this.statusflag = short.Parse(dr["StatusFlag"].ToString());
        }

        #endregion
    }
}

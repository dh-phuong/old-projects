﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class Work Apply Time
    /// </summary>
    [Serializable]
    public class T_Work_ApplyTime
    {
        #region Variant

        public string ApplyNo { get; set; }
        public int UserID { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor Work Apply Time
        /// </summary>
        public T_Work_ApplyTime()           
        {

        }

        /// <summary>
        /// Contructor Work Apply Time
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public T_Work_ApplyTime(DbDataReader dr)
        {
            this.ApplyNo = (string)dr["ApplyNo"];
            this.UserID = (int)dr["UserID"];
            this.StartTime = (DateTime)dr["StartTime"];
            this.EndTime = (DateTime)dr["EndTime"];
        }

        #endregion
    }
}

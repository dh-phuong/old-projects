﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class M_User_Allowance Model
    /// </summary>
    [Serializable]
    public class M_Staff_Allowance
    {
        #region Variable

        private int salaryID;
        private int no;
        private int allowanceName;
        private decimal allowance;
        private short accountingFlag;

        #endregion

        #region Property

        public int SalaryID
        {
            get { return salaryID; }
            set
            {
                if (value != salaryID)
                {
                    salaryID = value;
                }
            }
        }

        public int No
        {
            get { return no; }
            set
            {
                if (value != no)
                {
                    no = value;
                }
            }
        }

        public int AllowanceName
        {
            get { return allowanceName; }
            set
            {
                if (value != allowanceName)
                {
                    allowanceName = value;
                }
            }
        }

        public decimal Allowance
        {
            get { return allowance; }
            set
            {
                if (value != allowance)
                {
                    allowance = value;
                }
            }
        }

        public short AccountingFlag
        {
            get { return accountingFlag; }
            set
            {
                if (value != accountingFlag)
                {
                    accountingFlag = value;
                }
            }
        }

        #endregion

        #region Contructor

        public M_Staff_Allowance()
        {
            this.salaryID = 0;
            this.no = 0;
            this.AllowanceName = 0;
            this.Allowance = 0;
            this.AccountingFlag = 0;
        }

        public M_Staff_Allowance(DbDataReader dr)
        {
            this.SalaryID = (int)dr["SalaryID"];
            this.No = (int)dr["No"];
            this.AllowanceName = (int)dr["AllowanceName"];
            this.Allowance = (decimal)dr["Allowance"];
            this.AccountingFlag = short.Parse(dr["AccountingFlag"].ToString());
        }

        #endregion

        /// <summary>
        /// Is empty row
        /// </summary>
        /// <returns></returns>
        public bool IsEmpty()
        {
            if (this.SalaryID == 0 &&
                this.No == 0 &&
                this.allowance == 0 &&
                this.AllowanceName == 0 &&
                this.AccountingFlag == 0)
            {
                return true;
            }

            return false;
        }
    }
}

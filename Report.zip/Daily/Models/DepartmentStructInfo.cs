﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class DepartmentStructInfo
    {
        public DepartmentStructInfo()
        {
        }

        public DepartmentStructInfo(DbDataReader dr)
        {
            this.DepartmentID = (int)dr["DepartmentID"];
            this.DepartmentIdParent = (int)dr["DepartmentIdParent"];
            this.DepartmentStructID = (int)dr["DepartmentStructID"];
            this.DepartmentName = dr["DepartmentName"].ToString();
            this.OrderItem = (int)dr["OrderItem"];
        }

        public int DepartmentStructID { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int DepartmentIdParent { get; set; }
        public int OrderItem { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class WorkTotalOTInfo
    {
        #region Variable

        public int EarlyHour { get; set; }
        public int EarlyMinute { get; set; }
        public int Normal1Hour { get; set; }
        public int Normal1Minute { get; set; }
        public int Normal2Hour { get; set; }
        public int Normal2Minute { get; set; }
        public int LateHour { get; set; }
        public int LateMinute { get; set; }
        public int Holiday1Hour { get; set; }
        public int Holiday1Minute { get; set; }
        public int Holiday2Hour { get; set; }
        public int Holiday2Minute { get; set; }
        public int TotalOTHour { get; set; }
        public int TotalOTMinute { get; set; }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of WorkTotalInfo
        /// </summary>
        public WorkTotalOTInfo()
            : base()
        {
            this.EarlyHour = 0;
            this.EarlyMinute = 0;
            this.Normal1Hour = 0;
            this.Normal1Minute = 0;
            this.Normal2Hour = 0;
            this.Normal2Minute = 0;
            this.LateHour = 0;
            this.LateMinute = 0;
            this.Holiday1Hour = 0;
            this.Holiday1Minute = 0;
            this.Holiday2Hour = 0;
            this.Holiday2Minute = 0;
        }
        public WorkTotalOTInfo(DbDataReader dr)
        {
            this.EarlyHour = (int)dr["EarlyHour"];
            this.EarlyMinute = (int)dr["EarlyMinute"];
            this.Normal1Hour = (int)dr["Normal1Hour"];
            this.Normal1Minute = (int)dr["Normal1Minute"];
            this.Normal2Hour = (int)dr["Normal2Hour"];
            this.Normal2Minute = (int)dr["Normal2Minute"];
            this.LateHour = (int)dr["LateHour"];
            this.LateMinute = (int)dr["LateMinute"];
            this.Holiday1Hour = (int)dr["Holiday1Hour"];
            this.Holiday1Minute = (int)dr["Holiday1Minute"];
            this.Holiday2Hour = (int)dr["Holiday2Hour"];
            this.Holiday2Minute = (int)dr["Holiday2Minute"];
            this.TotalOTHour = (int)dr["TotalOTHour"];
            this.TotalOTMinute = (int)dr["TotalOTMinute"];
        }

        #endregion
    }
}

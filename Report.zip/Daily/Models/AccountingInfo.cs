﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{

    /// <summary>
    /// Class AccountingInfo
    /// </summary>
    [Serializable]
    public class AccountingInfo
    {
        public int ID { get; set; }
        public int StartMonth { get; set; }
        public int ClosingDay { get; set; }
        public int NumOfDay { get; set; }
        public int NumOfTime_H { get; set; }
        public int NumOfTime_M { get; set; }
        public int UnitOfTime { get; set; }
        public short RoundLate { get; set; }
        public short RoundLeave { get; set; }
        public short RoundOuting { get; set; }
        public short RoundOT { get; set; }
        public int EarlyOT_SH { get; set; }
        public int EarlyOT_SM { get; set; }
        public int EarlyOT_EH { get; set; }
        public int EarlyOT_EM { get; set; }
        public int LateOT_SH { get; set; }
        public int LateOT_SM { get; set; }
        public int LateOT_EH { get; set; }
        public int LateOT_EM { get; set; }
        
        /// <summary>
        /// Constructor class AccountingInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public AccountingInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.StartMonth = int.Parse(dr["StartMonth"].ToString());
            this.ClosingDay = int.Parse(dr["ClosingDay"].ToString());
            this.NumOfDay = int.Parse(dr["NumOfDay"].ToString());
            this.NumOfTime_H = int.Parse(dr["NumOfTime_H"].ToString());
            this.NumOfTime_M = int.Parse(dr["NumOfTime_M"].ToString());
            this.UnitOfTime = int.Parse(dr["UnitOfTime"].ToString());
            this.RoundLate = short.Parse(dr["RoundLate"].ToString());
            this.RoundLeave = short.Parse(dr["RoundLeave"].ToString());
            this.RoundOuting = short.Parse(dr["RoundOuting"].ToString());
            this.RoundOT = short.Parse(dr["RoundOT"].ToString());
            this.EarlyOT_SH = int.Parse(dr["EarlyOT_SH"].ToString());
            this.EarlyOT_SM = int.Parse(dr["EarlyOT_SM"].ToString());
            this.EarlyOT_EH = int.Parse(dr["EarlyOT_EH"].ToString());
            this.EarlyOT_EM = int.Parse(dr["EarlyOT_EM"].ToString());
            this.LateOT_SH = int.Parse(dr["LateOT_SH"].ToString());
            this.LateOT_SM = int.Parse(dr["LateOT_SM"].ToString());
            this.LateOT_EH = int.Parse(dr["LateOT_EH"].ToString());
            this.LateOT_EM = int.Parse(dr["LateOT_EM"].ToString());
            
        }

        /// <summary>
        /// Constructor class AccountingInfo
        /// </summary>
        public AccountingInfo()
        {
            this.ID = 0;
            this.StartMonth = 0;
            this.ClosingDay = 0;
            this.UnitOfTime = 0;
            this.RoundLate = 0;
            this.RoundLeave = 0;
            this.RoundOuting = 0;
            this.RoundOT = 0;
            this.EarlyOT_SH = 0;
            this.EarlyOT_SM = 0;
            this.EarlyOT_EH = 0;
            this.EarlyOT_EM = 0;
            this.LateOT_SH = 0;
            this.LateOT_SM = 0;
            this.LateOT_EH = 0;
            this.LateOT_EM = 0;
            this.NumOfDay = 0;
        }
    }

    [Serializable]
    public class AccountingPeriod
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public AccountingPeriod()
            : base()
        {
        }
    }

    [Serializable]
    public class MonthInfo
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public MonthInfo()
            : base()
        {
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Vacation Info Model
    /// VN-Nho
    /// Edit: ISV-TRUC 2015/03/27
    /// </summary>
    [Serializable]
    public class VacationInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string VacationNo { get; set; }
        public int? PreVacationID { get; set; }
        public string UserCD { get; set; }
        public string Username { get; set; }
        public short ApplyStatus { get; set; }        
        public DateTime? ApplyDate { get; set; }
        public string ApplyDateStr { get; set; }
        public string TypeName { get; set; }
        public DateTime? VacationDate { get; set; }
        public string VacationDateStr { get; set; }
        public short VacationStatus { get; set; }
        public string VacationName { get; set; }
        public int Color { get; set; }
        public string Reason { get; set; }
        public short DeleteFlg { get; set; }
        public string ApplyText { get; set; }
        public string RegisterCode { get; set; }
        public string  RegisterName { get; set; }
        //public short? ApproveStatus { get; set; }


        /// <summary>
        /// Constructor class VacationInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public VacationInfo(DbDataReader dr)
        {
            this.Color = -1;
            this.RowNumber = (long)dr["RowNumber"];
            this.VacationNo = (string)dr["VacationNo"];
            if (dr["PreVacationID"] != DBNull.Value)
            {
                this.PreVacationID = (int)dr["PreVacationID"];                
            }
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserCD = EditDataUtil.ToFixCodeShow((string)dr["UserCD"], M_User.MAX_USER_CODE_SHOW);
            this.Username = (string)dr["Username"];

            this.RegisterCode = dr["RegisterCode"] != DBNull.Value ? EditDataUtil.ToFixCodeShow((string)dr["RegisterCode"], M_User.MAX_USER_CODE_SHOW) : string.Empty;
            this.RegisterName = dr["RegisterName"] != DBNull.Value ? (string)dr["RegisterName"] : string.Empty;

            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = DateTime.Parse(dr["ApplyDate"].ToString());                
            }
            this.ApplyDateStr = this.ApplyDate != null ? this.ApplyDate.Value.ToString(Constants.FMT_DATE) : string.Empty;
            this.ApplyStatus = short.Parse(dr["ApplyStatus"].ToString());

            //if (dr["ApproveStatus"] != DBNull.Value)
            //{
            //    this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());
            //}
            //this.Typename = (string)dr["TypeName"];
            
            if (dr["VacationDate"] != DBNull.Value)
            {
                this.VacationDate = DateTime.Parse(dr["VacationDate"].ToString());
            }
            this.VacationDateStr = this.VacationDate != null ? this.VacationDate.Value.ToString(Constants.FMT_DATE) : string.Empty;
            this.VacationStatus = short.Parse(dr["VacationStatus"].ToString());
            this.VacationName = dr["VacationName"] != DBNull.Value ? (string)dr["VacationName"] : string.Empty;
            this.TypeName = dr["TypeName"] != DBNull.Value ? (string)dr["TypeName"] : string.Empty;
            this.Reason = (string)dr["Reason"];
            this.DeleteFlg = short.Parse(dr["StatusFlag"].ToString());
            
            if (this.ApplyStatus == (int)StatusApply.New)
            {
                this.ApplyText = "<span class='label label-default' style='width:70px; display: inline-block'>" + "Unclaimed" + "</span>";
            }
            else if (this.ApplyStatus == (int)StatusApply.Applied || this.ApplyStatus == (int)StatusApply.Approving)
            {
                this.ApplyText = "<span class='label label-info' style='width:70px; display: inline-block'>" + "Pending" + "</span>";
            }
            else if (this.ApplyStatus == (int)StatusApply.Approved)
            {
                this.ApplyText = "<span class='label label-success' style='width:70px; display: inline-block'>" + "Approval" + "</span>";
            }
            else if (this.ApplyStatus == (int)StatusApply.Rejected)
            {
                this.ApplyText = "<span class='label label-danger' style='width:70px;  display: inline-block'>" + "Ignore" + "</span>";
            }
            else if (this.ApplyStatus == (int)StatusApply.BackPrev)
            {
                this.ApplyText = "<span class='label label-warning' style='width:70px; display: inline-block'>" + "Remand" + "</span>";
            }
            else if (this.ApplyStatus == (int)StatusApply.Cancel)
            {
                this.ApplyText = "<span class='label label-warning' style='width:70px; display: inline-block'>" + "Cancel" + "</span>";
            }

            if (this.DeleteFlg == (int)DeleteFlag.Deleted)
            {
                this.Color = (int)ColorList.Danger;
            }
            if (this.PreVacationID.HasValue)
            {
                this.Color = (int)ColorList.Warning;
            }

        }

        /// <summary>
        /// Constructor class VacationInfo
        /// </summary>
        public VacationInfo()
        {
            this.RowNumber = 0;
            this.VacationNo = string.Empty;
            this.ID = 0;
            this.UserCD = string.Empty;
            this.Username = string.Empty;
            this.ApplyDate = DateTime.MinValue;
            this.ApplyStatus = 0;
            this.ApplyText = string.Empty;
            this.VacationDate = DateTime.MinValue;
            this.VacationStatus = 0;
            this.DeleteFlg = 0;
            this.Reason = string.Empty;
            this.Color = -1;
            this.PreVacationID = null;            
        }
    }


    [Serializable]
    public class VacationInfoDetail
    {
        public int ID { get; set; }
        public int UserID { get; set; }
        public string UserCD { get; set; }
        public string UserName { get; set; }
        public string TypeName { get; set; }
        public int TypeApplyID { get; set; }
        public DateTime VacationDate { get; set; }
        public short VacationStatus { get; set; }
        public short DeleteFlg { get; set; }
       // public int Color { get; set; }

        public string VacationNo { get; set; }
        public int? PreVacationID { get; set; }

        public short ApplyStatus { get; set; }
        public DateTime? ApplyDate { get; set; }

        public string Reason { get; set; }
        public string DepartmentNm { get; set; }
        public string Position { get; set; }

        public short? ApproveStatus { get; set; }
        public string ApproveReason { get; set; }

        public DateTime? CurrentAnnualDate { get; set; }
        public decimal? CurrentAnnualDay { get; set; }

        /// <summary>
        /// CreateDate
        /// </summary>
        public DateTime CreateDate { get; set; }
        /// <summary>
        /// CreateUID
        /// </summary>
        public int CreateUID { get; set; }
        /// <summary>
        /// UpdateDate
        /// </summary>
        public DateTime UpdateDate { get; set; }
        /// <summary>
        /// UpdateUID
        /// </summary>
        public int UpdateUID { get; set; }

        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public VacationInfoDetail(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.UserCD = EditDataUtil.ToFixCodeShow(dr["UserCD"].ToString(), M_User.MAX_USER_CODE_SHOW);
            this.UserName = (string)dr["UserName"];

            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = DateTime.Parse(dr["ApplyDate"].ToString());
            }

            this.ApplyStatus = short.Parse(dr["ApplyStatus"].ToString());
            this.TypeApplyID = short.Parse(dr["TypeApplyID"].ToString());
            this.TypeName = (string)dr["TypeName"];
            if (dr["VacationDate"] != DBNull.Value)
            {
                this.VacationDate = DateTime.Parse(dr["VacationDate"].ToString());
            }
            
            this.VacationStatus = short.Parse(dr["VacationStatus"].ToString());
            this.DeleteFlg = short.Parse(dr["DeleteFlg"].ToString());
            this.Reason = dr["Reason"] != DBNull.Value ? (string)dr["Reason"] : string.Empty;
            this.DepartmentNm = dr["DepartmentName"] != DBNull.Value ? (string)dr["DepartmentName"] : string.Empty;
            this.Position = dr["Position"] != DBNull.Value ? (string)dr["Position"] : string.Empty;


            if (dr["UpdateDate"] != DBNull.Value)
            {
                this.UpdateDate = (DateTime)dr["UpdateDate"];
            }
            this.CreateDate = (DateTime)dr["CreateDate"];
            this.CreateUID = (int)dr["CreateUID"];
            this.UpdateUID = (int)dr["UpdateUID"];
                        
            if (dr["ApproveStatus"] != DBNull.Value)
            {
                this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());
            }
            this.ApproveReason = dr["ApproveReason"] != DBNull.Value ? (string)dr["ApproveReason"] : string.Empty;


            if (dr["CurrentAnnualDate"] != DBNull.Value)
            {
                this.CurrentAnnualDate = (DateTime)dr["CurrentAnnualDate"];
            }
            if (dr["CurrentAnnualDay"] != DBNull.Value)
            {
                this.CurrentAnnualDay = decimal.Parse(dr["CurrentAnnualDay"].ToString());
            }

            this.VacationNo = dr["VacationNo"] != DBNull.Value ? (string)dr["VacationNo"] : string.Empty;
            if (dr["PreVacationID"] != DBNull.Value)
            {
                this.PreVacationID = int.Parse(dr["PreVacationID"].ToString());
            }
           // this.Color = -1;
        }

        /// <summary>
        /// Constructor class ApprovedInfo
        /// </summary>
        public VacationInfoDetail()
        {
           
        }


        }


    //[Serializable]
    //public class VacationApproveList
    //{
    //    public short Level { get; set; }
    //    public string LevelStr { get; set; }

    //    public IList<VacationApprove> DetailList { get; set; }
    //}

    [Serializable]
    public class VacationApprove
    {
        public int VacationID { get; set; }
        public int UserID { get; set; }
        public string UserName { get; set; }
        public int? ApproveUID { get; set; }
        public string ApproveName { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string ApproveDateStr { get; set; }
        public string ApproveReason { get; set; }
        public short RouteMethod { get; set; }
        public string RouteMethodStr { get; set; }
        public short? ApproveFlag { get; set; }
        public string ApproveFlagStr { get; set; }

        public short RouteLevel { get; set; }
        public string RouteLevelStr { get; set; }


        /// <summary>
        /// Contructor Empty
        /// </summary>
        public VacationApprove()
        {
            this.VacationID = 0;
            this.UserID = 0;
            this.ApproveUID = 0;
            this.UserName = string.Empty;
            this.ApproveName = string.Empty;
            this.ApproveDate = DateTime.MinValue;
            this.ApproveDateStr = string.Empty;
            this.ApproveReason = string.Empty;
            this.RouteLevel = 0;
            this.RouteLevelStr = string.Empty;
            this.ApproveFlag = 0;
            this.ApproveFlagStr = string.Empty;
            this.RouteMethod = -1;
            this.RouteMethodStr = string.Empty;

            this.Department = string.Empty;
            this.Position = string.Empty;
        }

        /// <summary>
        /// Constructor by data row
        /// </summary>
        /// <param name="dr"></param>
        public VacationApprove(DbDataReader dr)
        {
            if (dr["VacationID"] != DBNull.Value)
            {
                this.VacationID = (int)dr["VacationID"];
            }
            if (dr["UserID"] != DBNull.Value)
            {
                this.UserID = (int)dr["UserID"];
            }

            if (dr["ApproveUID"] != DBNull.Value)
            {
                this.ApproveUID = (int)dr["ApproveUID"];
            }
            if (dr["UserName"] != DBNull.Value)
            {
                this.UserName = (string)dr["UserName"];
            }

            if (dr["ApproveName"] != DBNull.Value)
            {
                this.ApproveName = (string)dr["ApproveName"];
            }

            if (dr["ApproveReason"] != DBNull.Value)
            {
                this.ApproveReason = (string)dr["ApproveReason"];
            }
            if (dr["ApproveDate"] != DBNull.Value)
            {
                this.ApproveDate = (DateTime)dr["ApproveDate"];
                this.ApproveDateStr = this.ApproveDate.Value.ToString(Constants.FMT_DATE);
            }
            if (dr["ApproveFlag"] != DBNull.Value)
            {
                this.ApproveFlag = short.Parse(dr["ApproveFlag"].ToString());

                switch (this.ApproveFlag)
                {
                    case (int)StatusHasAprove.New:
                        //this.ApproveFlagStr = "<span class='label label-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>未申請</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-minus text-color-default'></span>";
                        break;
                    //case (int)StatusHasAprove.Approve:
                    //    this.ApproveFlagStr = "<span class='label label-info' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>申請済</span>";
                    //    break;
                    case (int)StatusHasAprove.Approved:
                        // this.ApproveFlagStr = "<span class='label label-success' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>承認済</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-ok text-color-success'></span>";
                        break;
                    case (int)StatusHasAprove.Ignore:
                       // this.ApproveFlagStr = "<span class='label label-danger' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>棄却</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-remove text-color-danger'></span>";
                        break;
                    case (int)StatusHasAprove.BackPrev:
                     //   this.ApproveFlagStr = "<span class='label label-warning' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>差戻</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-arrow-left text-color-warning'></span>";
                        break;
                }
            }
            else
            {
                this.ApproveFlagStr = string.Empty;//"<span class='label label-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>未申請</span>";
            }

            if (dr["RouteMethod"] != DBNull.Value)
            {
                this.RouteMethod = short.Parse(dr["RouteMethod"].ToString());
                this.RouteMethodStr = this.RouteMethod == (short)RouteMethods.AND ? RouteMethods.AND.ToString() : RouteMethods.OR.ToString();
            }
            if (dr["RouteLevel"] != DBNull.Value)
            {
                this.RouteLevel = short.Parse(dr["RouteLevel"].ToString());
                this.RouteLevelStr = "Level " + this.RouteLevel.ToString();
            }

            if (dr["Department"] != DBNull.Value)
            {
                this.Department = (string)dr["Department"];
            }

            if (dr["Position"] != DBNull.Value)
            {
                this.Position = (string)dr["Position"];
            }

        }

    }
}
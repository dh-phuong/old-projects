﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Utilities;
using System.Data.Common;

namespace DailyReport.Models
{
    
    [Serializable]
    public class WorkVacationInfo
    {
        public int RowNumber { get; set; }
        public int ID { get; set; }
        public int? PreApplyID { get; set; }
        public string ApplyNo { get; set; }
        public string UserCD { get; set; }
        public string Username { get; set; }
        public short ApplyStatus { get; set; }
        public string TemplateFormName { get; set; }
        public string TypeName { get; set; }
        public DateTime? ApplyDate { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public short StatusFlag { get; set; }
        public string Reason { get; set; }
        public int Color { get; set; }
        public string ApplyStatusText { get; set; }
        public short ApproveStatus { get; set; }
        public short ApproveLevel { get; set; }
        public DateTime UpdateDate { get; set; }
        public short VacationType { get; set; }
        /// <summary>
        /// Constructor class WorkVacationInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public WorkVacationInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.ID = int.Parse(dr["ID"].ToString());

            if (dr["PreApplyID"] != DBNull.Value)
            {
                this.PreApplyID = int.Parse(dr["PreApplyID"].ToString());
            }

            this.ApplyNo = (string)dr["ApplyNo"];
            this.UserCD = EditDataUtil.ToFixCodeShow(dr["UserCD"].ToString(), M_User.MAX_USER_CODE_SHOW);
            this.Username = (string)dr["UserName"];

            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = DateTime.Parse(dr["ApplyDate"].ToString());
            }
            else
            {
                this.ApplyDate = null;
            }

            if (dr["VacationType"] != DBNull.Value)
            {
                this.VacationType = short.Parse(dr["VacationType"].ToString());
            }

            if (dr["ApproveStatus"] != DBNull.Value)
            {
                this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());
            }
            if (dr["ApproveLevel"] != DBNull.Value)
            {
                this.ApproveLevel = short.Parse(dr["ApproveLevel"].ToString());
            }
            string statusName = string.Empty;
            string color = string.Empty;
            this.ApplyStatus = short.Parse(dr["ApplyStatus"].ToString());
            switch (this.ApplyStatus)
            {
                case (int)StatusApply.Draft:
                    color = "default";
                    statusName = "DRAFT";
                    this.Color = -1;
                    break;                
                case (int)StatusApply.Approving:
                    color = "info";
                    statusName = "APPROVING";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Approved:
                    color = "success";
                    statusName = "APPROVED";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Rejected:
                    color = "danger";
                    statusName = "REJECTED";
                    this.Color = -1;
                    break;
                case (int)StatusApply.BackPrev:
                    color = "warning";
                    statusName = "REMAND";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Cancel:
                    color = "danger";
                    statusName = "CANCEL";

                    break;

                default:
                    break;
            }

            this.ApplyStatusText = "<span class='label label-" + color + "' style='width:70px; display: inline-block'>" + statusName + "</span>";
            this.TemplateFormName = dr["TemplateFormName"].ToString();
            this.TypeName = dr["TypeName"].ToString();
            this.StartDate = DateTime.Parse(dr["StartDate"].ToString());
            this.StartHour = short.Parse(dr["StartHour"].ToString());
            this.StartMinute = short.Parse(dr["StartMinute"].ToString());
            this.EndDate = DateTime.Parse(dr["EndDate"].ToString());
            this.EndHour = short.Parse(dr["EndHour"].ToString());
            this.EndMinute = short.Parse(dr["EndMinute"].ToString());
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());
            this.Reason = dr["Reason"].ToString();

            if (dr["UpdateDate"] != DBNull.Value)
            {
                this.UpdateDate = DateTime.Parse(dr["UpdateDate"].ToString());
            }
            if (this.PreApplyID.HasValue)
            {
                this.Color = (int)ColorList.Warning;
            }
        }

        /// <summary>
        /// Constructor class ApplyInfo
        /// </summary>
        public WorkVacationInfo()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.PreApplyID = null;
            this.ApplyNo = string.Empty;
            this.UserCD = string.Empty;
            this.Username = string.Empty;
            this.ApplyDate = DateTime.MinValue;
            this.ApplyStatus = 0;
            this.TemplateFormName = string.Empty;
            this.TypeName = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartHour = 0;
            this.StartMinute = 0;
            this.EndDate = DateTime.MinValue;
            this.EndHour = 0;
            this.EndMinute = 0;
            this.StatusFlag = 0;
            this.Reason = string.Empty;
            this.ApplyStatusText = string.Empty;
            this.ApproveStatus = 0;
            this.ApproveLevel = 0;
            this.Color = -1;
            this.VacationType = 0;
            this.UpdateDate = DateTime.Now;
        }
    }


    [Serializable]
    public class VacationInfo
    {
        public int RowNumber { get; set; }
        public int ID { get; set; }
        public int? PreApplyID { get; set; }
        public string ApplyNo { get; set; }
        public string UserCD { get; set; }
        public string Username { get; set; }
        public short ApplyStatus { get; set; }
        public string TemplateFormName { get; set; }
        public string TypeName { get; set; }
        public DateTime? ApplyDate { get; set; }
        public DateTime StartDate { get; set; }
        public short StartHour { get; set; }
        public short StartMinute { get; set; }
        public DateTime EndDate { get; set; }
        public short EndHour { get; set; }
        public short EndMinute { get; set; }
        public short StatusFlag { get; set; }
        public string Reason { get; set; }
        public int Color { get; set; }
        public string ApplyStatusText { get; set; }
        public short ApproveStatus { get; set; }
        public short ApproveLevel { get; set; }
        public DateTime UpdateDate { get; set; }

        /// <summary>
        /// Constructor class ApplyInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public VacationInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.ID = int.Parse(dr["ID"].ToString());

            if (dr["PreApplyID"] != DBNull.Value)
            {
                this.PreApplyID = int.Parse(dr["PreApplyID"].ToString());
            }

            this.ApplyNo = (string)dr["ApplyNo"];
            this.UserCD = EditDataUtil.ToFixCodeShow(dr["UserCD"].ToString(), M_User.MAX_USER_CODE_SHOW);
            this.Username = (string)dr["UserName"];

            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = DateTime.Parse(dr["ApplyDate"].ToString());
            }
            else
            {
                this.ApplyDate = null;
            }
            if (dr["ApproveStatus"] != DBNull.Value)
            {
                this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());
            }
            if (dr["ApproveLevel"] != DBNull.Value)
            {
                this.ApproveLevel = short.Parse(dr["ApproveLevel"].ToString());
            }
            string statusName = string.Empty;
            string color = string.Empty;
            this.ApplyStatus = short.Parse(dr["ApplyStatus"].ToString());
            switch (this.ApplyStatus)
            {
                case (int)StatusApply.Draft:
                    color = "default";
                    statusName = "DRAFT";
                    this.Color = -1;
                    break;

                case (int)StatusApply.Approving:
                    color = "info";
                    statusName = "APPROVING";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Approved:
                    color = "success";
                    statusName = "APPROVED";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Rejected:
                    color = "danger";
                    statusName = "REJECTED";
                    this.Color = -1;
                    break;
                case (int)StatusApply.BackPrev:
                    color = "warning";
                    statusName = "REMAND";
                    this.Color = -1;
                    break;
                case (int)StatusApply.Cancel:
                    color = "danger";
                    statusName = "CANCEL";

                    break;

                default:
                    break;
            }

            this.ApplyStatusText = "<span class='label label-" + color + "' style='width:70px; display: inline-block'>" + statusName + "</span>";
            this.TemplateFormName = dr["TemplateFormName"].ToString();
            this.TypeName = dr["TypeName"].ToString();
            this.StartDate = DateTime.Parse(dr["StartDate"].ToString());
            this.EndDate = DateTime.Parse(dr["EndDate"].ToString());
            this.StatusFlag = short.Parse(dr["StatusFlag"].ToString());
            this.Reason = dr["Reason"].ToString();

            if (dr["UpdateDate"] != DBNull.Value)
            {
                this.UpdateDate = DateTime.Parse(dr["UpdateDate"].ToString());
            }
            if (this.PreApplyID.HasValue)
            {
                this.Color = (int)ColorList.Warning;
            }
        }

        /// <summary>
        /// Constructor class ApplyInfo
        /// </summary>
        public VacationInfo()
        {
            this.RowNumber = 0;
            this.ID = 0;
            this.PreApplyID = null;
            this.ApplyNo = string.Empty;
            this.UserCD = string.Empty;
            this.Username = string.Empty;
            this.ApplyDate = DateTime.MinValue;
            this.ApplyStatus = 0;
            this.TemplateFormName = string.Empty;
            this.TypeName = string.Empty;
            this.StartDate = DateTime.MinValue;
            this.StartHour = 0;
            this.StartMinute = 0;
            this.EndDate = DateTime.MinValue;
            this.EndHour = 0;
            this.EndMinute = 0;
            this.StatusFlag = 0;
            this.Reason = string.Empty;
            this.ApplyStatusText = string.Empty;
            this.ApproveStatus = 0;
            this.ApproveLevel = 0;
            this.Color = -1;
            this.UpdateDate = DateTime.Now;
        }
    }
}

﻿using System;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class FormLinkInfo Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class FormLinkInfo
    {
        public int RowNumber { get; set; }
        public int FormID { get; set; }
        public string FormName { get; set; }
        public int RouteID { get; set; }
        public string RouteName { get; set; }
        public DateTime UpdateDate { get; set; }

        /// <summary>
        /// Constructor class FormLinkInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public FormLinkInfo(DbDataReader dr)
        {
            this.RowNumber = (int)dr["RowNumber"];
            this.FormID = int.Parse(dr["FormID"].ToString());
            this.FormName = (string)dr["FormName"];
            this.RouteID = int.Parse(dr["RouteID"].ToString());
            this.RouteName = (string)dr["RouteName"];
            if (dr["UpdateDate"]!=DBNull.Value)
            {
                this.UpdateDate = DateTime.Parse(dr["UpdateDate"].ToString());
            }
            
        }

        /// <summary>
        /// Constructor class FormLinkInfo
        /// </summary>
        public FormLinkInfo()
        {
            this.RowNumber = 0;
            this.FormID =0;
            this.FormName = string.Empty;
            this.RouteID = 0;
            this.RouteName = string.Empty;
            this.UpdateDate = DateTime.Now;
        }
    }
    
    /// <summary>
    /// Class FormLinkInfo Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class UserInfoForFormLink
    {
        public int RowNumber { get; set; }
        public string DepartmentCD { get; set; }
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
        public int UserID { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public string Position { get; set; }
        public DateTime? UpdateDate { get; set; }
        public int AppliedFlag { get; set; }
        public int CountAllowMove { get; set; }

        /// <summary>
        /// Constructor class FormLinkInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public UserInfoForFormLink(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.DepartmentID = int.Parse(dr["DepartmentID"].ToString());
            this.DepartmentCD =dr["DepartmentCD"].ToString();
            this.DepartmentName = dr["DepartmentName"].ToString();
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.StaffCD = EditDataUtil.ToFixCodeShow(dr["StaffCD"].ToString(), M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = dr["StaffName"].ToString();
            this.Position = dr["Position"].ToString();
            this.AppliedFlag = int.Parse(dr["AppliedFlag"].ToString());

            if (dr["UpdateDate"] != DBNull.Value)
            {
                this.UpdateDate = DateTime.Parse(dr["UpdateDate"].ToString());
            }
           
        }

        /// <summary>
        /// Constructor class FormLinkInfo
        /// </summary>
        public UserInfoForFormLink()
        {
            this.RowNumber = 0;
            this.DepartmentID = 0;
            this.DepartmentCD = string.Empty;
            this.DepartmentName = string.Empty;
            this.UserID = 0;
            this.StaffCD = string.Empty;
            this.StaffName = string.Empty;
            this.Position = string.Empty;
            this.UpdateDate = null;
            this.AppliedFlag = 0;
        }
    }

    /// <summary>
    /// Class FormLinkMaster Model
    /// TRAM
    /// </summary>
    [Serializable]
    public class FormLinkMaster
    {
        public int FormID { get; set; }
        public int RouteID { get; set; }

        /// <summary>
        /// Constructor class FormLinkMaster
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public FormLinkMaster(DbDataReader dr)
        {
            
            this.FormID = int.Parse(dr["FormID"].ToString());
            this.RouteID = int.Parse(dr["RouteID"].ToString());
                        
        }

        /// <summary>
        /// Constructor class FormLinkMaster
        /// </summary>
        public FormLinkMaster()
        {

            this.FormID = 0;
            this.RouteID = 0;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{
    [Serializable]
    public class DayOfWeekInfo
    {
        public DateTime Day { get; set; }
        public string HolidayName { get; set; }
        public string Css { get; set; }
        public string CssContent { get; set; }
        public List<CalendarInfo> ListWork { get; set; }

        public DayOfWeekInfo()
        {
            ListWork = new List<CalendarInfo>();
        }
    }
}

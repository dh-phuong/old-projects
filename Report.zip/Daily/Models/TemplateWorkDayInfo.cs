﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{

    /// <summary>
    /// Class TemplateWorkDayInfo
    /// ISV-TRUC
    /// 2015/06/23
    /// </summary>
    [Serializable]
    public class TemplateWorkDayInfo
    {

        /// <summary>
        /// Day
        /// </summary>
        //public string SunDay { get; set; }
        //public string MonDay { get; set; }
        //public string TuesDay { get; set; }
        //public string WednesDay { get; set; }
        //public string ThursDay { get; set; }
        //public string FriDay { get; set; }
        //public string SaturDay { get; set; }

        public int SunShiftID { get; set; }
        public int SunShiftCD { get; set; }
        public string SunShiftName { get; set; }
        public int SunTypeOfDay { get; set; }
        public int MonShiftID { get; set; }
        public int MonShiftCD { get; set; }
        public string MonShiftName { get; set; }
        public int MonTypeOfDay { get; set; }
        public int TueShiftID { get; set; }
        public int TueShiftCD { get; set; }
        public string TueShiftName { get; set; }
        public int TueTypeOfDay { get; set; }
        public int WedShiftID { get; set; }
        public int WedShiftCD { get; set; }
        public string WedShiftName { get; set; }
        public int WedTypeOfDay { get; set; }
        public int ThuShiftID { get; set; }
        public int ThuShiftCD { get; set; }
        public string ThuShiftName { get; set; }
        public int ThuTypeOfDay { get; set; }
        public int FriShiftID { get; set; }
        public int FriShiftCD { get; set; }
        public string FriShiftName { get; set; }
        public int FriTypeOfDay { get; set; }
        public int SatShiftID { get; set; }
        public int SatShiftCD { get; set; }
        public string SatShiftName { get; set; }
        public int SatTypeOfDay { get; set; }
        
        /// <summary>
        /// Constructor class TemplateWorkDayInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public TemplateWorkDayInfo(DbDataReader dr)
        {            
            this.SunShiftID = dr["SunShiftID"] != DBNull.Value ? int.Parse(dr["SunShiftID"].ToString()) : -1;
            this.MonShiftID = dr["MonShiftID"] != DBNull.Value ? int.Parse(dr["MonShiftID"].ToString()) : -1;
            this.TueShiftID = dr["TueShiftID"] != DBNull.Value ? int.Parse(dr["TueShiftID"].ToString()) : -1;
            this.WedShiftID = dr["WedShiftID"] != DBNull.Value ? int.Parse(dr["WedShiftID"].ToString()) : -1;
            this.ThuShiftID = dr["ThuShiftID"] != DBNull.Value ? int.Parse(dr["ThuShiftID"].ToString()) : -1;
            this.FriShiftID = dr["FriShiftID"] != DBNull.Value ? int.Parse(dr["FriShiftID"].ToString()) : -1;
            this.SatShiftID = dr["SatShiftID"] != DBNull.Value ? int.Parse(dr["SatShiftID"].ToString()) : -1;
                        
            this.SunShiftCD = dr["SunShiftCD"] != DBNull.Value ? int.Parse(dr["SunShiftCD"].ToString()) : -1;
            this.MonShiftCD = dr["MonShiftCD"] != DBNull.Value ? int.Parse(dr["MonShiftCD"].ToString()) : -1;
            this.TueShiftCD = dr["TueShiftCD"] != DBNull.Value ? int.Parse(dr["TueShiftCD"].ToString()) : -1;
            this.WedShiftCD = dr["WedShiftCD"] != DBNull.Value ? int.Parse(dr["WedShiftCD"].ToString()) : -1;
            this.ThuShiftCD = dr["ThuShiftCD"] != DBNull.Value ? int.Parse(dr["ThuShiftCD"].ToString()) : -1;
            this.FriShiftCD = dr["FriShiftCD"] != DBNull.Value ? int.Parse(dr["FriShiftCD"].ToString()) : -1;
            this.SatShiftCD = dr["SatShiftCD"] != DBNull.Value ? int.Parse(dr["SatShiftCD"].ToString()) : -1;

            this.SunTypeOfDay = dr["SunTypeOfDay"] != DBNull.Value ? int.Parse(dr["SunTypeOfDay"].ToString()) : -1;
            this.MonTypeOfDay = dr["MonTypeOfDay"] != DBNull.Value ? int.Parse(dr["MonTypeOfDay"].ToString()) : -1;
            this.TueTypeOfDay = dr["TueTypeOfDay"] != DBNull.Value ? int.Parse(dr["TueTypeOfDay"].ToString()) : -1;
            this.WedTypeOfDay = dr["WedTypeOfDay"] != DBNull.Value ? int.Parse(dr["WedTypeOfDay"].ToString()) : -1;
            this.ThuTypeOfDay = dr["ThuTypeOfDay"] != DBNull.Value ? int.Parse(dr["ThuTypeOfDay"].ToString()) : -1;
            this.FriTypeOfDay = dr["FriTypeOfDay"] != DBNull.Value ? int.Parse(dr["FriTypeOfDay"].ToString()) : -1;
            this.SatTypeOfDay = dr["SatTypeOfDay"] != DBNull.Value ? int.Parse(dr["SatTypeOfDay"].ToString()) : -1;

            this.SunShiftName = dr["SunShiftName"] != DBNull.Value ? (string)dr["SunShiftName"] : string.Empty;
            this.MonShiftName = dr["MonShiftName"] != DBNull.Value ? (string)dr["MonShiftName"] : string.Empty;
            this.TueShiftName = dr["TueShiftName"] != DBNull.Value ? (string)dr["TueShiftName"] : string.Empty;
            this.WedShiftName = dr["WedShiftName"] != DBNull.Value ? (string)dr["WedShiftName"] : string.Empty;
            this.ThuShiftName = dr["ThuShiftName"] != DBNull.Value ? (string)dr["ThuShiftName"] : string.Empty;
            this.FriShiftName = dr["FriShiftName"] != DBNull.Value ? (string)dr["FriShiftName"] : string.Empty;
            this.SatShiftName = dr["SatShiftName"] != DBNull.Value ? (string)dr["SatShiftName"] : string.Empty;

            //this.SunDay = "<span class='negative-num'> Sun </span>";
            //this.SaturDay = "<span class='text-primary'> Sat </span>";
            //this.MonDay = "<span > Mon </span>";
            //this.TuesDay = "<span > Tue </span>";
            //this.WednesDay = "<span > Wed </span>";
            //this.ThursDay = "<span > Thu </span>";
            //this.FriDay = "<span > Fri </span>";
        }

        /// <summary>
        /// Constructor class TemplateWorkDayInfo
        /// </summary>
        public TemplateWorkDayInfo()
        {
            //this.SunDay = "Sun";
            //this.SaturDay = "Sat";
            //this.MonDay = "Mon";
            //this.TuesDay = "Tue";
            //this.WednesDay = "Wed";
            //this.ThursDay = "Thu";
            //this.FriDay = "Fri";

            this.SunShiftID = -1;
            this.MonShiftID = -1;
            this.TueShiftID = -1;
            this.WedShiftID = -1;
            this.ThuShiftID = -1;
            this.FriShiftID = -1;
            this.SatShiftID = -1;

            this.SunShiftName = string.Empty;
            this.MonShiftName = string.Empty;
            this.TueShiftName = string.Empty;
            this.WedShiftName = string.Empty;
            this.ThuShiftName = string.Empty;
            this.FriShiftName = string.Empty;
            this.SatShiftName = string.Empty;

            this.SunShiftCD = -1;
            this.MonShiftCD = -1;
            this.TueShiftCD = -1;
            this.WedShiftCD = -1;
            this.ThuShiftCD = -1;
            this.FriShiftCD = -1;
            this.SatShiftCD = -1;

            this.SunTypeOfDay = -1;
            this.MonTypeOfDay = -1;
            this.TueTypeOfDay = -1;
            this.WedTypeOfDay = -1;
            this.ThuTypeOfDay = -1;
            this.FriTypeOfDay = -1;
            this.SatTypeOfDay = -1;
        }
    }

}

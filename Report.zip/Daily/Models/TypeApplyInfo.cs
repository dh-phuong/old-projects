﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// TypeApply Info Model
    /// ISV-NHAT
    /// 2015/03/13
    /// </summary>
    [Serializable]
    public class TypeApplyInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string TypeName { get; set; }
        public int formID { get; set; }
        public string FormName { get { return formID == (int)TypeFormID.Apply ? "Apply" : "Vacation"; } }

        public TypeApplyInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.ID = int.Parse(dr["ID"].ToString());
            this.formID = int.Parse(dr["FormID"].ToString());
            this.TypeName = (string)dr["TypeName"].ToString();
        }

        public TypeApplyInfo()
        {
            this.RowNumber = 0;
            this.ID = -1;
            this.formID = -1;
            this.TypeName = string.Empty;
        }

    }
}

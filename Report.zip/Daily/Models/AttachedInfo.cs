﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// AttachedInfo
    /// </summary>
    [Serializable]
    public class AttachedInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string No { get; set; }
        public string Path { get; set; }
        public bool DelFlag { get; set; }
        public DateTime CreateDate { get; set; }
        public int CreateUID { get; set; }

        /// <summary>
        /// Constructor class AttachedInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public AttachedInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());

            this.No =(string)dr["No"];
            this.Path =  (string)dr["Path"];
            this.CreateDate = (DateTime)dr["CreateDate"];
            this.CreateUID = (int)dr["CreateUID"];
        }

        /// <summary>
        /// Constructor class AttachedInfo
        /// </summary>
        public AttachedInfo()
        {
            this.RowNumber = 0;
            this.No = string.Empty;
            this.Path = string.Empty;
        }
    }
}

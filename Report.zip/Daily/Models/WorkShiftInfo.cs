﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class WorkingShiftInfo Model
    /// </summary>
    [Serializable]
    public class WorkShiftInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public int ShiftCode { get; set; }
        public string ShiftName { get; set; }
        public string WorkingHour { get; set; }
        public int ?StartHour { get; set; }
        public int ?StartMinute { get; set; }
        public int ?EndHour { get; set; }
        public int ?EndMinute { get; set; }

        /// <summary>
        /// Constructor class WorkingShiftInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public WorkShiftInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.ShiftCode = int.Parse(dr["ShiftCode"].ToString());
            this.ShiftName = dr["ShiftName"].ToString();

            if (dr["StartHour"] != DBNull.Value && dr["EndHour"] != DBNull.Value)
            {
                this.WorkingHour = dr["StartHour"].ToString().PadLeft(2, '0') + ":"
                                + dr["StartMinute"].ToString().PadLeft(2, '0') + " ~ "
                                + dr["EndHour"].ToString().PadLeft(2, '0') + ":"
                                + dr["EndMinute"].ToString().PadLeft(2, '0');
            }
        }


        /// <summary>
        /// Constructor class WorkingShiftInfo
        /// </summary>
        public WorkShiftInfo()
        {
            this.RowNumber = 0;
            this.ID = -1;
            this.ShiftCode = -1;
            this.ShiftName = string.Empty;
            this.WorkingHour = string.Empty;
            this.StartHour = null;
            this.StartMinute = null;
            this.EndHour = null;
            this.EndMinute = null;
        }
    }
    
    /// <summary>
    /// WorkingShiftSearchInfo
    /// ISV-TRAM
    /// 2015/06/02
    /// </summary>
    [Serializable]
    public class WorkingShiftSearchInfo
    { 
        public long RowNumber { get; set; }
        public int ShiftCode { get; set; }
        public string ShiftName { get; set; }
        public string StartTime { get; set; }
        public string EndTime { get; set; }
        public int TypeOfDay { get; set; }
        public string Duration { get; set; }

        /// <summary>
        /// Constructor by datarow
        /// </summary>
        /// <param name="dr"></param>
        public WorkingShiftSearchInfo(DbDataReader dr)
        {
            ISecurity sec = Security.Instance;
            this.RowNumber = (long)dr["RowNumber"];
            this.ShiftCode = int.Parse(dr["ShiftCode"].ToString());
            this.ShiftName = (string)dr["ShiftName"];
            if (dr["StartHour"] != DBNull.Value && dr["StartMinute"] != DBNull.Value)
            {
                this.StartTime = string.Format("{0:00}", dr["StartHour"]) + ":" + string.Format("{0:00}", dr["StartMinute"]);
            }

            if (dr["EndHour"] != DBNull.Value && dr["EndMinute"] != DBNull.Value)
            {
                this.EndTime = string.Format("{0:00}", dr["EndHour"]) + ":" + string.Format("{0:00}", dr["EndMinute"]);
            }

            if (dr["TypeOfDay"] != DBNull.Value)
            {
                this.TypeOfDay = int.Parse(dr["TypeOfDay"].ToString());
            }

            if (dr["DurationHour"] != DBNull.Value && dr["DurationMinute"] != DBNull.Value)
            {
                this.Duration = string.Format("{0:00}", dr["DurationHour"]) + ":" + string.Format("{0:00}", dr["DurationMinute"]);
            }
        }

        /// <summary>
        /// Constructor empty
        /// </summary>
        public WorkingShiftSearchInfo()
        {
            this.RowNumber = 0;
            this.ShiftCode = 0;
            this.ShiftName = string.Empty;
            this.StartTime = string.Empty;
            this.EndTime = string.Empty;
            this.TypeOfDay = 0;
            this.Duration = string.Empty;
        }
    }
}

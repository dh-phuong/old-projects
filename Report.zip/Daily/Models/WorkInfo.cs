﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;
using System.Globalization;

namespace DailyReport.Models
{
    [Serializable]
    public class WorkInfo
    {
        #region Variable

        public int ID { get; set; }

        public int RowSpan
        {
            get { return ID == 0 ? 2 : 3; }
        }
        public string HiddenStepRowCss
        {
            get { return ID == 0 ? "hidden" : ""; }
        }
        public int StaffID { get; set; }
        public int UserID { get; set; }
        public DateTime WorkDate { get; set; }
        public string WorkDayOfWeek
        {
            get { return WorkDate.ToString("ddd", new CultureInfo("en-us")); }
        }
        public int TypeOfDay { get; set; }

        public string CssOfDay
        {
            get
            {
                switch (TypeOfDay)
                {
                    case 0:
                        return "workDay";
                    case 1:
                        return "halfworkDay";
                    default:
                        return "offDay";
                }
            }
        }

        /* ------ SHIFT PATTERN BASE ------ */
        public string ShiftPatternBase { get; set; }
        //-----
        private int StartWorkHourBase { get; set; }
        private int StartWorkMinuteBase { get; set; }

        public string StartWorkBase
        {
            get
            {
                if (this.StartWorkHourBase == 0 && this.StartWorkMinuteBase == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.StartWorkHourBase, this.StartWorkMinuteBase);
                }
            }
        }

        //-----
        private int EndWorkHourBase { get; set; }
        private int EndWorkMinuteBase { get; set; }
        public string EndWorkBase
        {
            get
            {
                if (this.EndWorkHourBase == 0 && this.EndWorkMinuteBase == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.EndWorkHourBase, this.EndWorkMinuteBase);
                }
            }
        }

        public int TimeWorkHourBase { get; set; }
        public int TimeWorkMinuteBase { get; set; }
        public string TimeWorkBase
        {
            get
            {
                if (this.TimeWorkHourBase == 0 && this.TimeWorkMinuteBase == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeWorkHourBase, this.TimeWorkMinuteBase);
                }
            }
        }

        public int ApprLeaveEarlyHour { get; set; }
        public int ApprLeaveEarlyMinute { get; set; }
        public string ApprLeaveEarly
        {
            get
            {
                if (this.ApprLeaveEarlyHour == 0 && this.ApprLeaveEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprLeaveEarlyHour, this.ApprLeaveEarlyMinute);
                }
            }
        }

        public int ApprOutHour { get; set; }
        public int ApprOutMinute { get; set; }
        public string ApprOut
        {
            get
            {
                if (this.ApprOutHour == 0 && this.ApprOutMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOutHour, this.ApprOutMinute);
                }
            }
        }

        public decimal VacationLeaves { get; set; }
        public string VacationLeavesStr
        {
            get
            {
                if (this.VacationLeaves == decimal.Zero)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, VacationLeaves);
                }
            }
        }

        public decimal Absence { get; set; }
        public string AbsenceStr
        {
            get
            {
                if (this.Absence == decimal.Zero)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, Absence);
                }
            }
        }

        public int ApprLateHour { get; set; }
        public int ApprLateMinute { get; set; }
        public string ApprLate
        {
            get
            {
                if (this.ApprLateHour == 0 && this.ApprLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprLateHour, this.ApprLateMinute);
                }
            }
        }

        public int ApprOTEarlyHour { get; set; }
        public int ApprOTEarlyMinute { get; set; }
        public string ApprOTEarly
        {
            get
            {
                if (this.ApprOTEarlyHour == 0 && this.ApprOTEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTEarlyHour, this.ApprOTEarlyMinute);
                }
            }
        }
        public int ApprOTNormal1Hour { get; set; }
        public int ApprOTNormal1Minute { get; set; }
        public string ApprOTNormal1
        {
            get
            {
                if (this.ApprOTNormal1Hour == 0 && this.ApprOTNormal1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTNormal1Hour, this.ApprOTNormal1Minute);
                }
            }
        }
        public int ApprOTNormal2Hour { get; set; }
        public int ApprOTNormal2Minute { get; set; }
        public string ApprOTNormal2
        {
            get
            {
                if (this.ApprOTNormal2Hour == 0 && this.ApprOTNormal2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTNormal2Hour, this.ApprOTNormal2Minute);
                }
            }
        }
        public int ApprOTLateHour { get; set; }
        public int ApprOTLateMinute { get; set; }
        public string ApprOTLate
        {
            get
            {
                if (this.ApprOTLateHour == 0 && this.ApprOTLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTLateHour, this.ApprOTLateMinute);
                }
            }
        }
        public int ApprOTHoliday1Hour { get; set; }
        public int ApprOTHoliday1Minute { get; set; }
        public string ApprOTHoliday1
        {
            get
            {
                if (this.ApprOTHoliday1Hour == 0 && this.ApprOTHoliday1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTHoliday1Hour, this.ApprOTHoliday1Minute);
                }
            }
        }
        public int ApprOTHoliday2Hour { get; set; }
        public int ApprOTHoliday2Minute { get; set; }
        public string ApprOTHoliday2
        {
            get
            {
                if (this.ApprOTHoliday2Hour == 0 && this.ApprOTHoliday2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.ApprOTHoliday2Hour, this.ApprOTHoliday2Minute);
                }
            }
        }

        /* ------ SHIFT PATTERN ------ */
        public int WorkTypeOfDay { get; set; }
        public string ShiftPattern { get; set; }
        //-----
        private int StartWorkHour { get; set; }
        private int StartWorkMinute { get; set; }
        public string StartWork
        {
            get
            {
                if (this.StartWorkHour == 0 && this.StartWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.StartWorkHour, this.StartWorkMinute);
                }
            }
        }
        //-----
        private int EndWorkHour { get; set; }
        private int EndWorkMinute { get; set; }
        public string EndWork
        {
            get
            {
                if (this.EndWorkHour == 0 && this.EndWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.EndWorkHour, this.EndWorkMinute);
                }
            }
        }

        public IList<WorkStartOutInfo> WorkStartOutInfos { get; set; }
        public IList<WorkEndOutInfo> WorkEndOutInfos { get; set; }

        /* ------ PERFORMANCE TIME ------ */
        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public string TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        //-----
        public int TimeLateHour { get; set; }
        public int TimeLateMinute { get; set; }
        public string TimeLate
        {
            get
            {
                if (this.TimeLateHour == 0 && this.TimeLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeLateHour, this.TimeLateMinute);
                }
            }
        }
        //-----
        public int TimeEarlyHour { get; set; }
        public int TimeEarlyMinute { get; set; }
        public string TimeEarly
        {
            get
            {
                if (this.TimeEarlyHour == 0 && this.TimeEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeEarlyHour, this.TimeEarlyMinute);
                }
            }
        }
        //-----
        public int TimeOutHour { get; set; }
        public int TimeOutMinute { get; set; }
        public string TimeOut
        {
            get
            {
                if (this.TimeOutHour == 0 && this.TimeOutMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeOutHour, this.TimeOutMinute);
                }
            }
        }

        /* ------ OVER TIME ------ */
        public int OTEarlyHour { get; set; }
        public int OTEarlyMinute { get; set; }
        public string OTEarly
        {
            get
            {
                if (this.OTEarlyHour == 0 && this.OTEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTEarlyHour, this.OTEarlyMinute);
                }
            }
        }
        //-----
        public int OTNormal1Hour { get; set; }
        public int OTNormal1Minute { get; set; }
        public string OTNormal1
        {
            get
            {
                if (this.OTNormal1Hour == 0 && this.OTNormal1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTNormal1Hour, this.OTNormal1Minute);
                }
            }
        }
        //-----
        public int OTNormal2Hour { get; set; }
        public int OTNormal2Minute { get; set; }
        public string OTNormal2
        {
            get
            {
                if (this.OTNormal2Hour == 0 && this.OTNormal2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTNormal2Hour, this.OTNormal2Minute);
                }
            }
        }
        //-----
        public int OTLateHour { get; set; }
        public int OTLateMinute { get; set; }
        public string OTLate
        {
            get
            {
                if (this.OTLateHour == 0 && this.OTLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTLateHour, this.OTLateMinute);
                }
            }
        }
        //-----
        public int OTHoliday1Hour { get; set; }
        public int OTHoliday1Minute { get; set; }
        public string OTHoliday1
        {
            get
            {
                if (this.OTHoliday1Hour == 0 && this.OTHoliday1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTHoliday1Hour, this.OTHoliday1Minute);
                }
            }
        }
        //-----
        public int OTHoliday2Hour { get; set; }
        public int OTHoliday2Minute { get; set; }
        public string OTHoliday2
        {
            get
            {
                if (this.OTHoliday2Hour == 0 && this.OTHoliday2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTHoliday2Hour, this.OTHoliday2Minute);
                }
            }
        }
        //-----
        public int TotalOTHour { get; set; }
        public int TotalOTMinute { get; set; }
        public string TotalOT
        {
            get
            {
                if (this.TotalOTHour == 0 && this.TotalOTMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TotalOTHour, this.TotalOTMinute);
                }
            }
        }
        //-----
        public int TotalWorkHour { get; set; }
        public int TotalWorkMinute { get; set; }
        public string TotalWork
        {
            get
            {
                if (this.TotalWorkHour == 0 && this.TotalWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TotalWorkHour, this.TotalWorkMinute);
                }
            }
        }

        public string Remark { get; set; }

        public bool IsValidData
        {
            get
            {
                if ((this.TypeOfDay == 0 || this.TypeOfDay == 1)) // Check is not holiday
                {
                    if ((((this.WorkTypeOfDay == -1 && this.VacationLeaves == 0.0m && this.Absence == 0.0m) || this.WorkTypeOfDay == 0 || this.WorkTypeOfDay == 1)) && this.StartWorkHour == 0 && this.StartWorkMinute == 0)
                    {
                        return false;
                    }
                }

                if ((this.VacationLeaves == 0.5m
                    || this.Absence == 0.5m) && this.StartWorkHour == 0 && this.StartWorkMinute == 0)
                {
                    return false;
                }
                
                return this.ApprLateHour        == this.TimeLateHour        && this.ApprLateMinute          == this.TimeLateMinute
                    && this.ApprLeaveEarlyHour  == this.TimeEarlyHour       && this.ApprLeaveEarlyMinute    == this.TimeEarlyMinute
                    && this.ApprOutHour         == this.TimeOutHour         && this.ApprOutMinute           == this.TimeOutMinute
                    && this.ApprOTEarlyHour     == this.OTEarlyHour         && this.ApprOTEarlyMinute       == this.OTEarlyMinute
                    && this.ApprOTNormal1Hour   == this.OTNormal1Hour       && this.ApprOTNormal1Minute     == this.OTNormal1Minute
                    && this.ApprOTNormal2Hour   == this.OTNormal2Hour       && this.ApprOTNormal2Minute     == this.OTNormal2Minute
                    && this.ApprOTLateHour      == this.OTLateHour          && this.ApprOTLateMinute        == this.OTLateMinute
                    && this.ApprOTHoliday1Hour  == this.OTHoliday1Hour      && this.ApprOTHoliday1Minute    == this.OTHoliday1Minute
                    && this.ApprOTHoliday2Hour  == this.OTHoliday2Hour      && this.ApprOTHoliday2Minute    == this.OTHoliday2Minute;
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of WorkInfo
        /// </summary>
        public WorkInfo()
            : base()
        {
            this.ShiftPattern = string.Empty;
            this.StartWorkHour = 0;
            this.StartWorkMinute = 0;
            this.EndWorkHour = 0;
            this.EndWorkMinute = 0;
            this.TimeWorkHour = 0;
            this.TimeWorkMinute = 0;
            this.TimeLateHour = 0;
            this.TimeLateMinute = 0;
            this.TimeEarlyHour = 0;
            this.TimeEarlyMinute = 0;
            this.TimeOutHour = 0;
            this.TimeOutMinute = 0;
            this.OTEarlyHour = 0;
            this.OTEarlyMinute = 0;
            this.OTNormal1Hour = 0;
            this.OTNormal1Minute = 0;
            this.OTNormal2Hour = 0;
            this.OTNormal2Minute = 0;
            this.OTLateHour = 0;
            this.OTLateMinute = 0;
            this.OTHoliday1Hour = 0;
            this.OTHoliday1Minute = 0;
            this.OTHoliday2Hour = 0;
            this.OTHoliday2Minute = 0;
            this.TotalOTHour = 0;
            this.TotalOTMinute = 0;
            this.TotalWorkHour = 0;
            this.TotalWorkMinute = 0;
            this.Remark = string.Empty;
            this.VacationLeaves = 0;
            this.Absence = 0;
        }

        /// <summary>
        /// Contructor of WorkInfo
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public WorkInfo(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.StaffID = (int)dr["StaffID"];
            this.UserID = (int)dr["UserID"];
            this.WorkDate = DateTime.Parse(dr["WorkDate"].ToString());
            this.TypeOfDay = (int)dr["TypeOfDay"];
            this.ShiftPatternBase = dr["ShiftPatternBase"].ToString();
            this.StartWorkHourBase = (int)dr["StartWorkHourBase"];
            this.StartWorkMinuteBase = (int)dr["StartWorkMinuteBase"];
            this.EndWorkHourBase = (int)dr["EndWorkHourBase"];
            this.EndWorkMinuteBase = (int)dr["EndWorkMinuteBase"];

            this.TimeWorkHourBase = (int)dr["TimeWorkHourBase"];
            this.TimeWorkMinuteBase = (int)dr["TimeWorkMinuteBase"];
            this.ApprLateHour = (int)dr["ApprLateHour"];
            this.ApprLateMinute = (int)dr["ApprLateMinute"];
            this.ApprLeaveEarlyHour = (int)dr["ApprLeaveEarlyHour"];
            this.ApprLeaveEarlyMinute = (int)dr["ApprLeaveEarlyMinute"];
            this.ApprOutHour = (int)dr["ApprOutHour"];
            this.ApprOutMinute = (int)dr["ApprOutMinute"];

            this.VacationLeaves = (decimal)dr["VacationLeaves"];
            this.Absence = (decimal)dr["Absence"];

            this.ApprOTEarlyHour = (int)dr["ApprOTEarlyHour"];
            this.ApprOTEarlyMinute = (int)dr["ApprOTEarlyMinute"];
            this.ApprOTNormal1Hour = (int)dr["ApprOTNormal1Hour"];
            this.ApprOTNormal1Minute = (int)dr["ApprOTNormal1Minute"];
            this.ApprOTNormal2Hour = (int)dr["ApprOTNormal2Hour"];
            this.ApprOTNormal2Minute = (int)dr["ApprOTNormal2Minute"];
            this.ApprOTLateHour = (int)dr["ApprOTLateHour"];
            this.ApprOTLateMinute = (int)dr["ApprOTLateMinute"];
            this.ApprOTHoliday1Hour = (int)dr["ApprOTHoliday1Hour"];
            this.ApprOTHoliday1Minute = (int)dr["ApprOTHoliday1Minute"];
            this.ApprOTHoliday2Hour = (int)dr["ApprOTHoliday2Hour"];
            this.ApprOTHoliday2Minute = (int)dr["ApprOTHoliday2Minute"];

            this.WorkTypeOfDay = (int)dr["WorkTypeOfDay"];
            this.ShiftPattern = dr["ShiftPattern"].ToString();
            this.StartWorkHour = (int)dr["StartWorkHour"];
            this.StartWorkMinute = (int)dr["StartWorkMinute"];
            this.EndWorkHour = (int)dr["EndWorkHour"];
            this.EndWorkMinute = (int)dr["EndWorkMinute"];
            this.WorkStartOutInfos = new List<WorkStartOutInfo>();
            this.WorkEndOutInfos = new List<WorkEndOutInfo>();

            string[] arrWOS_H = dr["WorkOutStartHour"].ToString().Split(',');
            string[] arrWOS_M = dr["WorkOutStartMinute"].ToString().Split(',');
            string[] arrWOE_H = dr["WorkOutEndHour"].ToString().Split(',');
            string[] arrWOE_M = dr["WorkOutEndMinute"].ToString().Split(',');
            for (int i = 0; i < arrWOS_H.Length; i++)
            {
                if (!string.IsNullOrEmpty(arrWOS_H[i]) && !string.IsNullOrEmpty(arrWOS_M[i]) && !string.IsNullOrEmpty(arrWOE_H[i]) && !string.IsNullOrEmpty(arrWOE_M[i]))
                {
                    WorkEndOutInfo _endOut = new WorkEndOutInfo();
                    _endOut.EndHour = int.Parse(arrWOE_H[i]);
                    _endOut.EndMinute = int.Parse(arrWOE_M[i]);
                    WorkEndOutInfos.Add(_endOut);

                    WorkStartOutInfo _startOut = new WorkStartOutInfo();
                    _startOut.StartHour = int.Parse(arrWOS_H[i]);
                    _startOut.StartMinute = int.Parse(arrWOS_M[i]);
                    WorkStartOutInfos.Add(_startOut);
                }
            }

            // ---- PERFORMANCE TIME
            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            //-----
            this.TimeLateHour = (int)dr["TimeLateHour"];
            this.TimeLateMinute = (int)dr["TimeLateMinute"];
            //-----
            this.TimeEarlyHour = (int)dr["TimeEarlyHour"];
            this.TimeEarlyMinute = (int)dr["TimeEarlyMinute"];
            //-----
            this.TimeOutHour = (int)dr["TimeOutHour"];
            this.TimeOutMinute = (int)dr["TimeOutMinute"];
            /* ------ OVER TIME ------ */
            //-----
            this.OTEarlyHour = (int)dr["OTEarlyHour"];
            this.OTEarlyMinute = (int)dr["OTEarlyMinute"];
            //-----
            this.OTNormal1Hour = (int)dr["OTNormal1Hour"];
            this.OTNormal1Minute = (int)dr["OTNormal1Minute"];
            //-----
            this.OTNormal2Hour = (int)dr["OTNormal2Hour"];
            this.OTNormal2Minute = (int)dr["OTNormal2Minute"];
            //-----
            this.OTLateHour = (int)dr["OTLateHour"];
            this.OTLateMinute = (int)dr["OTLateMinute"];
            //-----
            this.OTHoliday1Hour = (int)dr["OTHoliday1Hour"];
            this.OTHoliday1Minute = (int)dr["OTHoliday1Minute"];
            //-----
            this.OTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this.OTHoliday2Minute = (int)dr["OTHoliday2Minute"];
            //-----
            this.TotalOTHour = (int)dr["TotalOTHour"];
            this.TotalOTMinute = (int)dr["TotalOTMinute"];
            //-----
            this.TotalWorkHour = (int)dr["TotalWorkHour"];
            this.TotalWorkMinute = (int)dr["TotalWorkMinute"];

            this.Remark = dr["Remark"].ToString();
        }

        #endregion
    }

    [Serializable]
    public class WorkAppliedList
    {
        public int ApplyType { get; set; }
        public int ID { get; set; }
        public string No { get; set; }
        public string ApplyName { get; set; }
        public int ApplyStatus { get; set; }

        public string css
        {
            get
            {
                string ret = "btn btn-xs loading ";

                if (this.ApplyStatus == (int)StatusApply.Approved)
                {
                    switch (this.ApplyType)
                    {
                        case (int)Utilities.ApplyType.Vacation:
                            ret += "btn-warning";
                            break;
                        case (int)Utilities.ApplyType.OverTime:
                            ret += "btn-primary";
                            break;
                        case (int)Utilities.ApplyType.LateEarlyOuting:
                            ret += "btn-danger";
                            break;
                        case (int)Utilities.ApplyType.Absence:
                            ret += "btn-danger";
                            break;
                        default:
                            break;
                    }
                }
                else if (this.ApplyStatus == (int)StatusApply.Approving)
                {
                    switch (this.ApplyType)
                    {
                        case (int)Utilities.ApplyType.Vacation:
                        case (int)Utilities.ApplyType.OverTime:
                        case (int)Utilities.ApplyType.LateEarlyOuting:
                        case (int)Utilities.ApplyType.Absence:
                            ret += "btn-applied";
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    ret += "btn-default disabled";
                }

                return ret;
            }
        }

        public WorkAppliedList()
        {
        }

        public WorkAppliedList(DbDataReader dr)
        {
            this.ApplyType = (int)dr["ApplyType"];
            this.ID = (int)dr["ID"];
            this.No = (string)dr["No"];
            this.ApplyName = string.Format("{0}", dr["ApplyName"]);
            this.ApplyStatus = (int)dr["ApplyStatus"];
        }
    }

    [Serializable]
    public class WorkStartOutInfo
    {
        #region Variable

        public int StartHour { get; set; }
        public int StartMinute { get; set; }

        public string StartOut
        {
            get
            {
                if (this.StartHour == 0 && this.StartMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.StartHour, this.StartMinute);
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of WorkInfo
        /// </summary>
        public WorkStartOutInfo()
            : base()
        {
            this.StartHour = 0;
            this.StartMinute = 0;
        }

        #endregion
    }

    [Serializable]
    public class WorkEndOutInfo
    {
        #region Variable

        public int EndHour { get; set; }
        public int EndMinute { get; set; }

        public string EndOut
        {
            get
            {
                if (this.EndHour == 0 && this.EndMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.EndHour, this.EndMinute);
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of WorkInfo
        /// </summary>
        public WorkEndOutInfo()
            : base()
        {
            this.EndHour = 0;
            this.EndMinute = 0;
        }

        #endregion
    }

    /// <summary>
    /// WorkTotalInfo Class
    /// </summary>
    [Serializable]
    public class WorkTotalInfo
    {
        #region Variable

        /// <summary>
        /// UnitOfTime
        /// </summary>
        private int UnitOfTime { get; set; }

        /// <summary>
        /// TimeWorkBase
        /// </summary>
        public int TimeWorkHourBase { get; set; }
        public int TimeWorkMinuteBase { get; set; }
        public string TimeWorkBase
        {
            get
            {
                if (this.TimeWorkHourBase == 0 && this.TimeWorkMinuteBase == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TimeWorkHourBase, this.TimeWorkMinuteBase, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprLeaveEarly
        /// </summary>
        public int ApprLeaveEarlyHour { get; set; }
        public int ApprLeaveEarlyMinute { get; set; }
        public string ApprLeaveEarly
        {
            get
            {
                if (this.ApprLeaveEarlyHour == 0 && this.ApprLeaveEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprLeaveEarlyHour, this.ApprLeaveEarlyMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOut
        /// </summary>
        public int ApprOutHour { get; set; }
        public int ApprOutMinute { get; set; }
        public string ApprOut
        {
            get
            {
                if (this.ApprOutHour == 0 && this.ApprOutMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOutHour, this.ApprOutMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// DayOffStr
        /// </summary>
        public decimal DayOff { get; set; }
        public string DayOffStr
        {
            get
            {
                if (this.DayOff == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, this.DayOff.ToString());
                }
            }
        }

        /// <summary>
        /// AbsenceOffStr
        /// </summary>
        public decimal AbsenceOff { get; set; }
        public string AbsenceOffStr
        {
            get
            {
                if (this.AbsenceOff == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, this.AbsenceOff.ToString());
                }
            }
        }

        /// <summary>
        /// VacationLeavesStr
        /// </summary>
        public decimal VacationLeaves { get; set; }
        public string VacationLeavesStr
        {
            get
            {
                if (this.VacationLeaves == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, this.VacationLeaves.ToString());
                }
            }
        }

        /// <summary>
        /// AbsenceLeavesStr
        /// </summary>
        public decimal AbsenceLeaves { get; set; }
        public string AbsenceLeavesStr
        {
            get
            {
                if (this.AbsenceLeaves == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, this.AbsenceLeaves.ToString());
                }
            }
        }

        /// <summary>
        /// ApprLate
        /// </summary>
        public int ApprLateHour { get; set; }
        public int ApprLateMinute { get; set; }
        public string ApprLate
        {
            get
            {
                if (this.ApprLateHour == 0 && this.ApprLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprLateHour, this.ApprLateMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTEarly
        /// </summary>
        public int ApprOTEarlyHour { get; set; }
        public int ApprOTEarlyMinute { get; set; }
        public string ApprOTEarly
        {
            get
            {
                if (this.ApprOTEarlyHour == 0 && this.ApprOTEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTEarlyHour, this.ApprOTEarlyMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTNormal1
        /// </summary>
        public int ApprOTNormal1Hour { get; set; }
        public int ApprOTNormal1Minute { get; set; }
        public string ApprOTNormal1
        {
            get
            {
                if (this.ApprOTNormal1Hour == 0 && this.ApprOTNormal1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTNormal1Hour, this.ApprOTNormal1Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTNormal2
        /// </summary>
        public int ApprOTNormal2Hour { get; set; }
        public int ApprOTNormal2Minute { get; set; }
        public string ApprOTNormal2
        {
            get
            {
                if (this.ApprOTNormal2Hour == 0 && this.ApprOTNormal2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTNormal2Hour, this.ApprOTNormal2Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTLate
        /// </summary>
        public int ApprOTLateHour { get; set; }
        public int ApprOTLateMinute { get; set; }
        public string ApprOTLate
        {
            get
            {
                if (this.ApprOTLateHour == 0 && this.ApprOTLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTLateHour, this.ApprOTLateMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTHoliday1
        /// </summary>
        public int ApprOTHoliday1Hour { get; set; }
        public int ApprOTHoliday1Minute { get; set; }
        public string ApprOTHoliday1
        {
            get
            {
                if (this.ApprOTHoliday1Hour == 0 && this.ApprOTHoliday1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTHoliday1Hour, this.ApprOTHoliday1Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ApprOTHoliday2
        /// </summary>
        public int ApprOTHoliday2Hour { get; set; }
        public int ApprOTHoliday2Minute { get; set; }
        public string ApprOTHoliday2
        {
            get
            {
                if (this.ApprOTHoliday2Hour == 0 && this.ApprOTHoliday2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ApprOTHoliday2Hour, this.ApprOTHoliday2Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TimeWork
        /// </summary>
        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public string TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TimeWorkHour, this.TimeWorkMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TimeLate
        /// </summary>
        public int TimeLateHour { get; set; }
        public int TimeLateMinute { get; set; }
        public string TimeLate
        {
            get
            {
                if (this.TimeLateHour == 0 && this.TimeLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TimeLateHour, this.TimeLateMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TimeEarly
        /// </summary>
        public int TimeEarlyHour { get; set; }
        public int TimeEarlyMinute { get; set; }
        public string TimeEarly
        {
            get
            {
                if (this.TimeEarlyHour == 0 && this.TimeEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TimeEarlyHour, this.TimeEarlyMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TimeOut
        /// </summary>
        public int TimeOutHour { get; set; }
        public int TimeOutMinute { get; set; }
        public string TimeOut
        {
            get
            {
                if (this.TimeOutHour == 0 && this.TimeOutMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TimeOutHour, this.TimeOutMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// ReplaceLeave
        /// </summary>
        public int ReplaceLeaveHour { get; set; }
        public int ReplaceLeaveMinute { get; set; }
        public string ReplaceLeave
        {
            get
            {
                if (this.ReplaceLeaveHour == 0 && this.ReplaceLeaveMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.ReplaceLeaveHour, this.ReplaceLeaveMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTEarly
        /// </summary>
        public int OTEarlyHour { get; set; }
        public int OTEarlyMinute { get; set; }
        public string OTEarly
        {
            get
            {
                if (this.OTEarlyHour == 0 && this.OTEarlyMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTEarlyHour, this.OTEarlyMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTNormal1
        /// </summary>
        public int OTNormal1Hour { get; set; }
        public int OTNormal1Minute { get; set; }
        public string OTNormal1
        {
            get
            {
                if (this.OTNormal1Hour == 0 && this.OTNormal1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTNormal1Hour, this.OTNormal1Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTNormal2
        /// </summary>
        public int OTNormal2Hour { get; set; }
        public int OTNormal2Minute { get; set; }
        public string OTNormal2
        {
            get
            {
                if (this.OTNormal2Hour == 0 && this.OTNormal2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTNormal2Hour, this.OTNormal2Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTLate
        /// </summary>
        public int OTLateHour { get; set; }
        public int OTLateMinute { get; set; }
        public string OTLate
        {
            get
            {
                if (this.OTLateHour == 0 && this.OTLateMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTLateHour, this.OTLateMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTHoliday1
        /// </summary>
        public int OTHoliday1Hour { get; set; }
        public int OTHoliday1Minute { get; set; }
        public string OTHoliday1
        {
            get
            {
                if (this.OTHoliday1Hour == 0 && this.OTHoliday1Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTHoliday1Hour, this.OTHoliday1Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// OTHoliday2
        /// </summary>
        public int OTHoliday2Hour { get; set; }
        public int OTHoliday2Minute { get; set; }
        public string OTHoliday2
        {
            get
            {
                if (this.OTHoliday2Hour == 0 && this.OTHoliday2Minute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.OTHoliday2Hour, this.OTHoliday2Minute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TotalOT
        /// </summary>
        public int TotalOTHour { get; set; }
        public int TotalOTMinute { get; set; }
        public string TotalOT
        {
            get
            {
                if (this.TotalOTHour == 0 && this.TotalOTMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TotalOTHour, this.TotalOTMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        /// <summary>
        /// TotalWork
        /// </summary>
        public int TotalWorkHour { get; set; }
        public int TotalWorkMinute { get; set; }
        public string TotalWork
        {
            get
            {
                if (this.TotalWorkHour == 0 && this.TotalWorkMinute == 0)
                {
                    return "&nbsp;";
                }
                else
                {
                    return EditDataUtil.FixTimePercent(new TimeSpan(this.TotalWorkHour, this.TotalWorkMinute, 0), this.UnitOfTime, 2).ToString();
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor of WorkTotalInfo
        /// </summary>
        public WorkTotalInfo()
            : base()
        {

        }
        public WorkTotalInfo(DbDataReader dr)
        {
            this.UnitOfTime = (int)dr["UnitOfTime"];

            this.TimeWorkHourBase = (int)dr["TimeWorkHourBase"];
            this.TimeWorkMinuteBase = (int)dr["TimeWorkMinuteBase"];

            this.ApprLateHour = (int)dr["ApprLateHour"];
            this.ApprLateMinute = (int)dr["ApprLateMinute"];
            this.ApprLeaveEarlyHour = (int)dr["ApprLeaveEarlyHour"];
            this.ApprLeaveEarlyMinute = (int)dr["ApprLeaveEarlyMinute"];
            this.ApprOutHour = (int)dr["ApprOutHour"];
            this.ApprOutMinute = (int)dr["ApprOutMinute"];
            this.VacationLeaves = (decimal)dr["VacationLeaves"];
            this.AbsenceLeaves = (decimal)dr["AbsenceLeaves"];
            this.DayOff = (decimal)dr["DayOff"];
            this.AbsenceOff = (decimal)dr["AbsenceOff"];

            this.ApprOTEarlyHour = (int)dr["ApprOTEarlyHour"];
            this.ApprOTEarlyMinute = (int)dr["ApprOTEarlyMinute"];
            this.ApprOTNormal1Hour = (int)dr["ApprOTNormal1Hour"];
            this.ApprOTNormal1Minute = (int)dr["ApprOTNormal1Minute"];
            this.ApprOTNormal2Hour = (int)dr["ApprOTNormal2Hour"];
            this.ApprOTNormal2Minute = (int)dr["ApprOTNormal2Minute"];
            this.ApprOTLateHour = (int)dr["ApprOTLateHour"];
            this.ApprOTLateMinute = (int)dr["ApprOTLateMinute"];
            this.ApprOTHoliday1Hour = (int)dr["ApprOTHoliday1Hour"];
            this.ApprOTHoliday1Minute = (int)dr["ApprOTHoliday1Minute"];
            this.ApprOTHoliday2Hour = (int)dr["ApprOTHoliday2Hour"];
            this.ApprOTHoliday2Minute = (int)dr["ApprOTHoliday2Minute"];

            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            this.TimeLateHour = (int)dr["TimeLateHour"];
            this.TimeLateMinute = (int)dr["TimeLateMinute"];

            this.TimeEarlyHour = (int)dr["TimeEarlyHour"];
            this.TimeEarlyMinute = (int)dr["TimeEarlyMinute"];

            this.TimeOutHour = (int)dr["TimeOutHour"];
            this.TimeOutMinute = (int)dr["TimeOutMinute"];

            this.OTEarlyHour = (int)dr["OTEarlyHour"];
            this.OTEarlyMinute = (int)dr["OTEarlyMinute"];
            this.OTNormal1Hour = (int)dr["OTNormal1Hour"];
            this.OTNormal1Minute = (int)dr["OTNormal1Minute"];
            this.OTNormal2Hour = (int)dr["OTNormal2Hour"];
            this.OTNormal2Minute = (int)dr["OTNormal2Minute"];
            this.OTLateHour = (int)dr["OTLateHour"];
            this.OTLateMinute = (int)dr["OTLateMinute"];
            this.OTHoliday1Hour = (int)dr["OTHoliday1Hour"];
            this.OTHoliday1Minute = (int)dr["OTHoliday1Minute"];
            this.OTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this.OTHoliday2Minute = (int)dr["OTHoliday2Minute"];

            this.TotalOTHour = (int)dr["TotalOTHour"];
            this.TotalOTMinute = (int)dr["TotalOTMinute"];
            this.TotalWorkHour = (int)dr["TotalWorkHour"];
            this.TotalWorkMinute = (int)dr["TotalWorkMinute"];
        }
        #endregion

    }

    [Serializable]
    public class ApplyRegisterInfo
    {
        #region Variable

        public int RowNumber { get; set; }
        public int ID { get; set; }
        public string StatusName { get; set; }
        public string No { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public int FormID { get; set; }
        public string FormName { get; set; }
        public DateTime? ApplyDate { get; set; }
        public DateTime EffectDate { get; set; }

        public string GetUrlDetail
        {
            get
            {
                switch (FormID)
                {
                    case 0:
                        return "FrmVacationRegisterDetail.aspx";
                    case 1:
                        return "FrmOverTimeDetail.aspx";
                    case 2:
                        return "FrmWorkLeaveDetail.aspx";
                    case 3:
                        return "FrmAbsenceRegisterDetail.aspx";
                    default:
                        return string.Empty;
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor of WorkTotalInfo
        /// </summary>
        public ApplyRegisterInfo()
            : base()
        {

        }
        public ApplyRegisterInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.ID = (int)dr["ID"];
            this.StatusName = dr["StatusName"].ToString();
            this.No = dr["No"].ToString();
            this.StaffCD = Utilities.EditDataUtil.ToFixCodeShow(dr["StaffCD"].ToString(), M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = dr["StaffName"].ToString();
            this.FormID = (int)dr["FormID"];
            this.FormName = dr["FormName"].ToString();
            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = (DateTime)dr["ApplyDate"];
            }
            this.EffectDate = (DateTime)dr["EffectDate"];
        }
        #endregion
    }

    [Serializable]
    public class ApplyApproveInfo
    {
        #region Variable

        public int RowNumber { get; set; }
        public int ID { get; set; }
        public string StatusName { get; set; }
        public string No { get; set; }
        public string StaffCD { get; set; }
        public string StaffName { get; set; }
        public int FormID { get; set; }
        public string FormName { get; set; }
        public DateTime? ApplyDate { get; set; }
        public DateTime EffectDate { get; set; }
        public decimal Duration { get; set; }
        public int TypeOfForm { get; set; }
        public string DurationStr { get; set; }
        public string UnitStr { get; set; }

        public string GetUrlDetail
        {
            get
            {
                switch (FormID)
                {
                    case 0:
                        return "FrmVacationApproveDetail.aspx";
                    case 1:
                        return "FrmWorkOverTimeApproveDetail.aspx";
                    case 2:
                        return "FrmWorkLeaveApproveDetail.aspx";
                    case 3:
                        return "FrmAbsenceApproveDetail.aspx";
                    default:
                        return "";
                }
            }
        }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor of WorkTotalInfo
        /// </summary>
        public ApplyApproveInfo()
            : base()
        {

        }
        public ApplyApproveInfo(DbDataReader dr)
        {
            this.RowNumber = int.Parse(dr["RowNumber"].ToString());
            this.ID = (int)dr["ID"];
            this.StatusName = dr["StatusName"].ToString();
            this.No = dr["No"].ToString();
            this.StaffCD = Utilities.EditDataUtil.ToFixCodeShow(dr["StaffCD"].ToString(), M_Staff.MAX_STAFF_CODE_SHOW);
            this.StaffName = dr["StaffName"].ToString();
            this.FormID = (int)dr["FormID"];
            this.FormName = dr["FormName"].ToString();
            if (dr["ApplyDate"] != DBNull.Value)
            {
                this.ApplyDate = (DateTime)dr["ApplyDate"];
            }

            this.EffectDate = (DateTime)dr["EffectDate"];
            this.Duration = (decimal)dr["Duration"];
            this.TypeOfForm = (int)dr["TypeOfForm"];

            switch (this.TypeOfForm)
            {
                case 0://Vacation
                case 3://Absence
                    this.DurationStr = this.Duration.ToString("N2");
                    this.UnitStr = (this.Duration > decimal.One ? "days" : "day");
                    break;
                case 1://OT
                case 2://Leave
                    var durHour = this.Duration / 60;
                    this.DurationStr = durHour.ToString("N2");
                    this.UnitStr = (durHour > decimal.One ? "hours" : "hour");
                    break;
                
                default:
                    break;
            }
        }
        #endregion
    }

    [Serializable]
    public class ApproveNextInfo
    {

        #region Contructor

        /// <summary>
        /// Contructor of WorkTotalInfo
        /// </summary>
        public ApproveNextInfo()
            : base()
        {

        }
        public ApproveNextInfo(DbDataReader dr)
        {
            this.ApplyNo = (string)dr["No"];
            this.UserID = (int)dr["UserID"];
            this.ApproveUID = (int)dr["RouteUID"];
            this.ApproveEmail = (string)dr["Email"];
            this.ApproveName = (string)dr["StaffName"];
        }

        #endregion

        #region Variable

        public string ApplyNo { get; set; }
        public int UserID { get; set; }
        public int ApproveUID { get; set; }
        public string ApproveEmail { get; set; }
        public string ApproveName { get; set; }

        #endregion
    }

    [Serializable]
    public class EmployeeDetailInMonthList
    {
        #region Variable

        public int ID { get; set; }
        public int StaffID { get; set; }
        public int UserID { get; set; }
        
        public DateTime WorkDate { get; set; }

        public string WorkDateDsp 
        {
            get
            {
                return string.Format(Constants.FMT_DATE_DPL, WorkDate);
            }
        }

        public decimal VacationLeaves { get; set; }
        public string VacationLeavesStr
        {
            get
            {
                if (this.VacationLeaves == decimal.Zero)
                {
                    return String.Empty;
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, VacationLeaves);
                }
            }
        }

        public decimal Absence { get; set; }
        public string AbsenceStr
        {
            get
            {
                if (this.Absence == decimal.Zero)
                {
                    return String.Empty;
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, this.Absence);
                }
            }
        }

        public int TypeOfDay { get; set; }
        
        /* ------ SHIFT PATTERN ------ */
        public string ShiftPattern { get; set; }
        //-----
        private int StartWorkHour { get; set; }
        private int StartWorkMinute { get; set; }
        public string StartWork
        {
            get
            {
                if (this.StartWorkHour == 0 && this.StartWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.StartWorkHour, this.StartWorkMinute);
                }
            }
        }
        //-----
        private int EndWorkHour { get; set; }
        private int EndWorkMinute { get; set; }
        public string EndWork
        {
            get
            {
                if (this.EndWorkHour == 0 && this.EndWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.EndWorkHour, this.EndWorkMinute);
                }
            }
        }

        public IList<WorkStartOutInfo> WorkStartOutInfos { get; set; }
        public IList<WorkEndOutInfo> WorkEndOutInfos { get; set; }

        /* ------ PERFORMANCE TIME ------ */
        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public string TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        //-----
        public int TimeLateHour { get; set; }
        public int TimeLateMinute { get; set; }
        public string TimeLate
        {
            get
            {
                if (this.TimeLateHour == 0 && this.TimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeLateHour, this.TimeLateMinute);
                }
            }
        }
        //-----
        public int TimeEarlyHour { get; set; }
        public int TimeEarlyMinute { get; set; }
        public string TimeEarly
        {
            get
            {
                if (this.TimeEarlyHour == 0 && this.TimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeEarlyHour, this.TimeEarlyMinute);
                }
            }
        }
        //-----
        public int TimeOutHour { get; set; }
        public int TimeOutMinute { get; set; }
        public string TimeOut
        {
            get
            {
                if (this.TimeOutHour == 0 && this.TimeOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeOutHour, this.TimeOutMinute);
                }
            }
        }

        /* ------ OVER TIME ------ */
        public int OTEarlyHour { get; set; }
        public int OTEarlyMinute { get; set; }
        public string OTEarly
        {
            get
            {
                if (this.OTEarlyHour == 0 && this.OTEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTEarlyHour, this.OTEarlyMinute);
                }
            }
        }
        //-----
        public int OTNormal1Hour { get; set; }
        public int OTNormal1Minute { get; set; }
        public string OTNormal1
        {
            get
            {
                if (this.OTNormal1Hour == 0 && this.OTNormal1Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTNormal1Hour, this.OTNormal1Minute);
                }
            }
        }
        //-----
        public int OTNormal2Hour { get; set; }
        public int OTNormal2Minute { get; set; }
        public string OTNormal2
        {
            get
            {
                if (this.OTNormal2Hour == 0 && this.OTNormal2Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTNormal2Hour, this.OTNormal2Minute);
                }
            }
        }
        //-----
        public int OTLateHour { get; set; }
        public int OTLateMinute { get; set; }
        public string OTLate
        {
            get
            {
                if (this.OTLateHour == 0 && this.OTLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTLateHour, this.OTLateMinute);
                }
            }
        }
        //-----
        public int OTHoliday1Hour { get; set; }
        public int OTHoliday1Minute { get; set; }
        public string OTHoliday1
        {
            get
            {
                if (this.OTHoliday1Hour == 0 && this.OTHoliday1Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTHoliday1Hour, this.OTHoliday1Minute);
                }
            }
        }
        //-----
        public int OTHoliday2Hour { get; set; }
        public int OTHoliday2Minute { get; set; }
        public string OTHoliday2
        {
            get
            {
                if (this.OTHoliday2Hour == 0 && this.OTHoliday2Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTHoliday2Hour, this.OTHoliday2Minute);
                }
            }
        }
        //-----
        public int TotalOTHour { get; set; }
        public int TotalOTMinute { get; set; }
        public string TotalOT
        {
            get
            {
                if (this.TotalOTHour == 0 && this.TotalOTMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TotalOTHour, this.TotalOTMinute);
                }
            }
        }
        //-----
        public int TotalWorkHour { get; set; }
        public int TotalWorkMinute { get; set; }
        public string TotalWork
        {
            get
            {
                if (this.TotalWorkHour == 0 && this.TotalWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TotalWorkHour, this.TotalWorkMinute);
                }
            }
        }

        public string CssOfDay
        {
            get
            {
                switch (TypeOfDay)
                {
                    case 0:
                        return "workDay";
                    case 1:
                        return "halfworkDay";
                    default:
                        return "offDay";
                }
            }
        }

        public string Remark { get; set; }


        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of EmployeeDetailInMonthList
        /// </summary>
        public EmployeeDetailInMonthList()
            : base()
        {
            this.ShiftPattern = string.Empty;
            this.StartWorkHour = 0;
            this.StartWorkMinute = 0;
            this.EndWorkHour = 0;
            this.EndWorkMinute = 0;
            this.TimeWorkHour = 0;
            this.TimeWorkMinute = 0;
            this.TimeLateHour = 0;
            this.TimeLateMinute = 0;
            this.TimeEarlyHour = 0;
            this.TimeEarlyMinute = 0;
            this.TimeOutHour = 0;
            this.TimeOutMinute = 0;
            this.OTEarlyHour = 0;
            this.OTEarlyMinute = 0;
            this.OTNormal1Hour = 0;
            this.OTNormal1Minute = 0;
            this.OTNormal2Hour = 0;
            this.OTNormal2Minute = 0;
            this.OTLateHour = 0;
            this.OTLateMinute = 0;
            this.OTHoliday1Hour = 0;
            this.OTHoliday1Minute = 0;
            this.OTHoliday2Hour = 0;
            this.OTHoliday2Minute = 0;
            this.TotalOTHour = 0;
            this.TotalOTMinute = 0;
            this.TotalWorkHour = 0;
            this.TotalWorkMinute = 0;
            this.Remark = string.Empty;
            this.VacationLeaves = 0;
            this.Absence = 0;
        }

        /// <summary>
        /// Contructor of EmployeeDetailInMonthList
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public EmployeeDetailInMonthList(DbDataReader dr)
        {
            this.ID = (int)dr["ID"];
            this.StaffID = (int)dr["StaffID"];
            this.UserID = (int)dr["UserID"];
            this.WorkDate = DateTime.Parse(dr["WorkDate"].ToString());
            this.TypeOfDay = (int)dr["TypeOfDay"];

            this.ShiftPattern = dr["ShiftPattern"].ToString();
            this.StartWorkHour = (int)dr["StartWorkHour"];
            this.StartWorkMinute = (int)dr["StartWorkMinute"];
            this.EndWorkHour = (int)dr["EndWorkHour"];
            this.EndWorkMinute = (int)dr["EndWorkMinute"];
            this.WorkStartOutInfos = new List<WorkStartOutInfo>();
            this.WorkEndOutInfos = new List<WorkEndOutInfo>();

            string[] arrWOS_H = dr["WorkOutStartHour"].ToString().Split(',');
            string[] arrWOS_M = dr["WorkOutStartMinute"].ToString().Split(',');
            string[] arrWOE_H = dr["WorkOutEndHour"].ToString().Split(',');
            string[] arrWOE_M = dr["WorkOutEndMinute"].ToString().Split(',');
            for (int i = 0; i < arrWOS_H.Length; i++)
            {
                if (!string.IsNullOrEmpty(arrWOS_H[i]) && !string.IsNullOrEmpty(arrWOS_M[i]) && !string.IsNullOrEmpty(arrWOE_H[i]) && !string.IsNullOrEmpty(arrWOE_M[i]))
                {
                    WorkEndOutInfo _endOut = new WorkEndOutInfo();
                    _endOut.EndHour = int.Parse(arrWOE_H[i]);
                    _endOut.EndMinute = int.Parse(arrWOE_M[i]);
                    WorkEndOutInfos.Add(_endOut);

                    WorkStartOutInfo _startOut = new WorkStartOutInfo();
                    _startOut.StartHour = int.Parse(arrWOS_H[i]);
                    _startOut.StartMinute = int.Parse(arrWOS_M[i]);
                    WorkStartOutInfos.Add(_startOut);
                }
            }

            // ---- PERFORMANCE TIME
            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            //-----
            this.TimeLateHour = (int)dr["TimeLateHour"];
            this.TimeLateMinute = (int)dr["TimeLateMinute"];
            //-----
            this.TimeEarlyHour = (int)dr["TimeEarlyHour"];
            this.TimeEarlyMinute = (int)dr["TimeEarlyMinute"];
            //-----
            this.TimeOutHour = (int)dr["TimeOutHour"];
            this.TimeOutMinute = (int)dr["TimeOutMinute"];
            /* ------ OVER TIME ------ */
            //-----
            this.OTEarlyHour = (int)dr["OTEarlyHour"];
            this.OTEarlyMinute = (int)dr["OTEarlyMinute"];
            //-----
            this.OTNormal1Hour = (int)dr["OTNormal1Hour"];
            this.OTNormal1Minute = (int)dr["OTNormal1Minute"];
            //-----
            this.OTNormal2Hour = (int)dr["OTNormal2Hour"];
            this.OTNormal2Minute = (int)dr["OTNormal2Minute"];
            //-----
            this.OTLateHour = (int)dr["OTLateHour"];
            this.OTLateMinute = (int)dr["OTLateMinute"];
            //-----
            this.OTHoliday1Hour = (int)dr["OTHoliday1Hour"];
            this.OTHoliday1Minute = (int)dr["OTHoliday1Minute"];
            //-----
            this.OTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this.OTHoliday2Minute = (int)dr["OTHoliday2Minute"];
            //-----
            this.TotalOTHour = (int)dr["TotalOTHour"];
            this.TotalOTMinute = (int)dr["TotalOTMinute"];
            //-----
            this.TotalWorkHour = (int)dr["TotalWorkHour"];
            this.TotalWorkMinute = (int)dr["TotalWorkMinute"];
            this.VacationLeaves = (decimal)dr["VacationLeaves"];
            this.Absence = (decimal)dr["Absence"];

            this.Remark = dr["Remark"].ToString();
        }

        #endregion
    }

    [Serializable]
    public class ListEmployeeInMonthExcelList
    {
        #region Variable

        public int Month { get; set; }
        public int Year { get; set; }

        public String DisplayName { get; set; }

         public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public int CountTimeWork { get; set; }
        public String TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWork + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        public String TimeWorkHTML
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWork + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        public int TimeWorkLateHour { get; set; }
        public int TimeWorkLateMinute { get; set; }
        public int CountTimeWorkLate { get; set; }
        public String TimeWorkLate
        {
            get
            {
                if (this.TimeWorkLateHour == 0 && this.TimeWorkLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkLate + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkLateHour, this.TimeWorkLateMinute);
                }
            }
        }
        public String TimeWorkLateHTML
        {
            get
            {
                if (this.TimeWorkLateHour == 0 && this.TimeWorkLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkLate + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkLateHour, this.TimeWorkLateMinute);
                }
            }
        }

        public int TimeWorkEarlyHour { get; set; }
        public int TimeWorkEarlyMinute { get; set; }
        public int CountTimeWorkEarly { get; set; }
        public String TimeWorkEarly
        {
            get
            {
                if (this.TimeWorkEarlyHour == 0 && this.TimeWorkEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkEarly + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkEarlyHour, this.TimeWorkEarlyMinute);
                }
            }
        }
        public String TimeWorkEarlyHTML
        {
            get
            {
                if (this.TimeWorkEarlyHour == 0 && this.TimeWorkEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkEarly +"<br />" + EditDataUtil.FixTimeShow(this.TimeWorkEarlyHour, this.TimeWorkEarlyMinute);
                }
            }
        }

        public int TimeWorkOutHour { get; set; }
        public int TimeWorkOutMinute { get; set; }
        public int CountTimeWorkOut { get; set; }
        public String TimeWorkOut
        {
            get
            {
                if (this.TimeWorkOutHour == 0 && this.TimeWorkOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkOut + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkOutHour, this.TimeWorkOutMinute);
                }
            }
        }
        public String TimeWorkOutHTML
        {
            get
            {
                if (this.TimeWorkOutHour == 0 && this.TimeWorkOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkOut + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkOutHour, this.TimeWorkOutMinute);
                }
            }
        }

        public String TimeWorkDayOffDB { get; set; }
        public int CountTimeWorkDayOff { get; set; }
        public String TimeWorkDayOff
        {
            get
            {
                if (float.Parse(this.TimeWorkDayOffDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkDayOff + Environment.NewLine + TimeWorkDayOffDB;
                }
            }
        }
        public String TimeWorkDayOffHTML
        {
            get
            {
                if (float.Parse(this.TimeWorkDayOffDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkDayOff + "<br />" + TimeWorkDayOffDB;
                }
            }
        }

        public String TimeWorkAbsenceDB { get; set; }
        public int CountTimeWorkAbsence { get; set; }
        public String TimeWorkAbsence
        {

            get
            {
                if (float.Parse(this.TimeWorkAbsenceDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkAbsence + Environment.NewLine + TimeWorkAbsenceDB;
                }
            }
        }

        public String TimeWorkAbsenceHTML
        {
            get
            {
                if (float.Parse(this.TimeWorkAbsenceDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkAbsence + "<br />" + TimeWorkAbsenceDB;
                }
            }
        }

        public int OverTimeEarlyHour { get; set; }
        public int OverTimeEarlyMinute { get; set; }
        public int CountOverTimeEarly { get; set; }
        public String OverTimeEarly
        {
            get
            {
                if (this.OverTimeEarlyHour == 0 && this.OverTimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeEarly + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeEarlyHour, this.OverTimeEarlyMinute);
                }
            }
        }

        public String OverTimeEarlyHTML
        {
            get
            {
                if (this.OverTimeEarlyHour == 0 && this.OverTimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeEarly + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeEarlyHour, this.OverTimeEarlyMinute);
                }
            }
        }

        public int OverTimeNormalHour { get; set; }
        public int OverTimeNormalMinute { get; set; }
        public int CountOverTimeNormal { get; set; }
        public String OverTimeNormal
        {
            get
            {
                if (this.OverTimeNormalHour == 0 && this.OverTimeNormalMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeNormal + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeNormalHour, this.OverTimeNormalMinute);
                }
            }
        }
        public String OverTimeNormalHTML
        {
            get
            {
                if (this.OverTimeNormalHour == 0 && this.OverTimeNormalMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeNormal + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeNormalHour, this.OverTimeNormalMinute);
                }
            }
        }

        public int OverTimeSatHour { get; set; }
        public int OverTimeSatMinute { get; set; }
        public int CountOverTimeSat { get; set; }
        public String OverTimeSat
        {
            get
            {
                if (this.OverTimeSatHour == 0 && this.OverTimeSatMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSat + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeSatHour, this.OverTimeSatMinute);
                }
            }
        }
        public String OverTimeSatHTML
        {
            get
            {
                if (this.OverTimeSatHour == 0 && this.OverTimeSatMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSat + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeSatHour, this.OverTimeSatMinute);
                }
            }
        }

        public int OverTimeLateHour { get; set; }
        public int OverTimeLateMinute { get; set; }
        public int CountOverTimeLate { get; set; }
        public String OverTimeLate
        {
            get
            {
                if (this.OverTimeLateHour == 0 && this.OverTimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeLate + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeLateHour, this.OverTimeLateMinute);
                }
            }
        }
        public String OverTimeLateHTML
        {
            get
            {
                if (this.OverTimeLateHour == 0 && this.OverTimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeLate + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeLateHour, this.OverTimeLateMinute);
                }
            }
        }

        public int OverTimeSunHour { get; set; }
        public int OverTimeSunMinute { get; set; }
        public int CountOverTimeSun { get; set; }
        public String OverTimeSun
        {
            get
            {
                if (this.OverTimeSunHour == 0 && this.OverTimeSunMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSun + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeSunHour, this.OverTimeSunMinute);
                }
            }
        }
        public String OverTimeSunHTML
        {
            get
            {
                if (this.OverTimeSunHour == 0 && this.OverTimeSunMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSun + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeSunHour, this.OverTimeSunMinute);
                }
            }
        }

        public int OverTimeHolidayHour { get; set; }
        public int OverTimeHolidayMinute { get; set; }
        public int CountOverTimeHoliday { get; set; }
        public String OverTimeHoliday
        {
            get
            {
                if (this.OverTimeHolidayHour == 0 && this.OverTimeHolidayMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeHoliday + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeHolidayHour, this.OverTimeHolidayMinute);
                }
            }
        }
        public String OverTimeHolidayHTML
        {
            get
            {
                if (this.OverTimeHolidayHour == 0 && this.OverTimeHolidayMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeHoliday + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeHolidayHour, this.OverTimeHolidayMinute);
                }
            }
        }
         #endregion

        #region Contructor

        /// <summary>
        /// Contructor of ListEmployeeInMonthExcelList
        /// </summary>
        public ListEmployeeInMonthExcelList()
            : base()
        {
            this.DisplayName = string.Empty;

            this.TimeWorkHour = 0;
            this.TimeWorkMinute = 0;
            this.CountTimeWork = 0;

            this.TimeWorkLateHour = 0;
            this.TimeWorkLateMinute = 0;
            this.CountTimeWorkLate = 0;

            this.TimeWorkEarlyHour = 0;
            this.TimeWorkEarlyMinute = 0;
            this.CountTimeWorkEarly = 0;

            this.TimeWorkOutHour = 0;
            this.TimeWorkOutMinute = 0;
            this.CountTimeWorkOut = 0;

            this.TimeWorkDayOffDB = string.Empty;
            this.TimeWorkAbsenceDB = string.Empty;
            this.CountTimeWorkDayOff = 0;
            this.CountTimeWorkAbsence = 0;

            this.OverTimeEarlyHour = 0;
            this.OverTimeEarlyMinute = 0;
            this.CountOverTimeEarly = 0;

            this.OverTimeNormalHour = 0;
            this.OverTimeNormalMinute = 0;
            this.CountOverTimeNormal = 0;

            this.OverTimeSatHour = 0;
            this.OverTimeSatMinute = 0;
            this.CountOverTimeSat = 0;

            this.OverTimeLateHour = 0;
            this.OverTimeLateMinute = 0;
            this.CountOverTimeLate = 0;

            this.OverTimeSunHour = 0;
            this.OverTimeSunMinute = 0;
            this.CountOverTimeSun = 0;

            this.OverTimeHolidayHour = 0;
            this.OverTimeHolidayMinute = 0;
            this.CountOverTimeHoliday = 0;
        }

        /// <summary>
        /// Contructor of ListEmployeeInMonthExcelList
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public ListEmployeeInMonthExcelList(DbDataReader dr)
        {

            this.DisplayName = dr["DisplayName"].ToString();

            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            this.CountTimeWork = (int)dr["CountTimeWork"];

            this.TimeWorkLateHour = (int)dr["TimeWorkLateHour"];
            this.TimeWorkLateMinute = (int)dr["TimeWorkLateMinute"];
            this.CountTimeWorkLate = (int)dr["CountTimeLate"];

            this.TimeWorkEarlyHour = (int)dr["TimeWorkEarlyHour"];
            this.TimeWorkEarlyMinute = (int)dr["TimeWorkEarlyMinute"];
            this.CountTimeWorkEarly = (int)dr["CountTimeEarly"];

            this.TimeWorkOutHour = (int)dr["TimeWorkOutHour"];
            this.TimeWorkOutMinute = (int)dr["TimeWorkOutMinute"];
            this.CountTimeWorkOut = (int)dr["CountTimeOut"];

            this.TimeWorkDayOffDB = dr["TimeWorkDayOff"].ToString();
            this.TimeWorkAbsenceDB = dr["TimeWorkAbsence"].ToString();
            this.CountTimeWorkDayOff = (int)dr["CountTimeWorkDayOff"];
            this.CountTimeWorkAbsence = (int)dr["CountTimeWorkAbsence"];

            this.OverTimeEarlyHour = (int)dr["OverTimeEarlyHour"];
            this.OverTimeEarlyMinute = (int)dr["OverTimeEarlyMinute"];
            this.CountOverTimeEarly = (int)dr["CountOverTimeEarly"];

            this.OverTimeNormalHour = (int)dr["OverTimeNormalHour"];
            this.OverTimeNormalMinute = (int)dr["OverTimeNormalMinute"];
            this.CountOverTimeNormal = (int)dr["CountOTNormal1"];

            this.OverTimeSatHour = (int)dr["OverTimeSatHour"];
            this.OverTimeSatMinute = (int)dr["OverTimeSatMinute"];
            this.CountOverTimeSat = (int)dr["CountOTNormal2"];

            this.OverTimeLateHour = (int)dr["OverTimeLateHour"];
            this.OverTimeLateMinute = (int)dr["OverTimeLateMinute"];
            this.CountOverTimeLate = (int)dr["CountOTLate"];

            this.OverTimeSunHour = (int)dr["OverTimeSunHour"];
            this.OverTimeSunMinute = (int)dr["OverTimeSunMinute"];
            this.CountOverTimeSun = (int)dr["CountOTHoliday1"];

            this.OverTimeHolidayHour = (int)dr["OverTimeHolidayHour"];
            this.OverTimeHolidayMinute = (int)dr["OverTimeHolidayMinute"];
            this.CountOverTimeHoliday = (int)dr["CountOTHoliday2"];
            
        }

        #endregion
    }

    [Serializable]
    public class ListEmployeeInYearExcelList
    {
        #region Variable

        public int Year { get; set; }

        public String DisplayName { get; set; }

        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public int CountTimeWork { get; set; }
        public String TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWork + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        public String TimeWorkHTML
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWork + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }
        public int TimeWorkLateHour { get; set; }
        public int TimeWorkLateMinute { get; set; }
        public int CountTimeWorkLate { get; set; }
        public String TimeWorkLate
        {
            get
            {
                if (this.TimeWorkLateHour == 0 && this.TimeWorkLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkLate + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkLateHour, this.TimeWorkLateMinute);
                }
            }
        }
        public String TimeWorkLateHTML
        {
            get
            {
                if (this.TimeWorkLateHour == 0 && this.TimeWorkLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkLate + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkLateHour, this.TimeWorkLateMinute);
                }
            }
        }

        public int TimeWorkEarlyHour { get; set; }
        public int TimeWorkEarlyMinute { get; set; }
        public int CountTimeWorkEarly { get; set; }
        public String TimeWorkEarly
        {
            get
            {
                if (this.TimeWorkEarlyHour == 0 && this.TimeWorkEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkEarly + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkEarlyHour, this.TimeWorkEarlyMinute);
                }
            }
        }
        public String TimeWorkEarlyHTML
        {
            get
            {
                if (this.TimeWorkEarlyHour == 0 && this.TimeWorkEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkEarly + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkEarlyHour, this.TimeWorkEarlyMinute);
                }
            }
        }

        public int TimeWorkOutHour { get; set; }
        public int TimeWorkOutMinute { get; set; }
        public int CountTimeWorkOut { get; set; }
        public String TimeWorkOut
        {
            get
            {
                if (this.TimeWorkOutHour == 0 && this.TimeWorkOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkOut + Environment.NewLine + EditDataUtil.FixTimeShow(this.TimeWorkOutHour, this.TimeWorkOutMinute);
                }
            }
        }
        public String TimeWorkOutHTML
        {
            get
            {
                if (this.TimeWorkOutHour == 0 && this.TimeWorkOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountTimeWorkOut + "<br />" + EditDataUtil.FixTimeShow(this.TimeWorkOutHour, this.TimeWorkOutMinute);
                }
            }
        }

        public String TimeWorkDayOffDB { get; set; }
        public int CountTimeWorkDayOff { get; set; }
        public String TimeWorkDayOff
        {
            get
            {
                if (float.Parse(this.TimeWorkDayOffDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkDayOff + Environment.NewLine + TimeWorkDayOffDB;
                }
            }
        }
        public String TimeWorkDayOffHTML
        {
            get
            {
                if (float.Parse(this.TimeWorkDayOffDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkDayOff + "<br />" + TimeWorkDayOffDB;
                }

            }
        }

        public String TimeWorkAbsenceDB { get; set; }
        public int CountTimeWorkAbsence { get; set; }
        public String TimeWorkAbsence
        {
            get
            {
                if (float.Parse(this.TimeWorkAbsenceDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkAbsence + Environment.NewLine + TimeWorkAbsenceDB;
                }
            }
        }

        public String TimeWorkAbsenceHTML
        {
            get
            {
                if (float.Parse(this.TimeWorkAbsenceDB) == 0)
                {
                    return string.Empty;

                }
                else
                {

                    return CountTimeWorkAbsence + "<br />" + TimeWorkAbsenceDB;
                }
            }
        }

        public int OverTimeEarlyHour { get; set; }
        public int OverTimeEarlyMinute { get; set; }
        public int CountOverTimeEarly { get; set; }
        public String OverTimeEarly
        {
            get
            {
                if (this.OverTimeEarlyHour == 0 && this.OverTimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeEarly + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeEarlyHour, this.OverTimeEarlyMinute);
                }
            }
        }

        public String OverTimeEarlyHTML
        {
            get
            {
                if (this.OverTimeEarlyHour == 0 && this.OverTimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeEarly + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeEarlyHour, this.OverTimeEarlyMinute);
                }
            }
        }

        public int OverTimeNormalHour { get; set; }
        public int OverTimeNormalMinute { get; set; }
        public int CountOverTimeNormal { get; set; }
        public String OverTimeNormal
        {
            get
            {
                if (this.OverTimeNormalHour == 0 && this.OverTimeNormalMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeNormal + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeNormalHour, this.OverTimeNormalMinute);
                }
            }
        }
        public String OverTimeNormalHTML
        {
            get
            {
                if (this.OverTimeNormalHour == 0 && this.OverTimeNormalMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeNormal + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeNormalHour, this.OverTimeNormalMinute);
                }
            }
        }

        public int OverTimeSatHour { get; set; }
        public int OverTimeSatMinute { get; set; }
        public int CountOverTimeSat { get; set; }
        public String OverTimeSat
        {
            get
            {
                if (this.OverTimeSatHour == 0 && this.OverTimeSatMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSat + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeSatHour, this.OverTimeSatMinute);
                }
            }
        }
        public String OverTimeSatHTML
        {
            get
            {
                if (this.OverTimeSatHour == 0 && this.OverTimeSatMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSat + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeSatHour, this.OverTimeSatMinute);
                }
            }
        }

        public int OverTimeLateHour { get; set; }
        public int OverTimeLateMinute { get; set; }
        public int CountOverTimeLate { get; set; }
        public String OverTimeLate
        {
            get
            {
                if (this.OverTimeLateHour == 0 && this.OverTimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeLate + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeLateHour, this.OverTimeLateMinute);
                }
            }
        }
        public String OverTimeLateHTML
        {
            get
            {
                if (this.OverTimeLateHour == 0 && this.OverTimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeLate + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeLateHour, this.OverTimeLateMinute);
                }
            }
        }

        public int OverTimeSunHour { get; set; }
        public int OverTimeSunMinute { get; set; }
        public int CountOverTimeSun { get; set; }
        public String OverTimeSun
        {
            get
            {
                if (this.OverTimeSunHour == 0 && this.OverTimeSunMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSun + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeSunHour, this.OverTimeSunMinute);
                }
            }
        }
        public String OverTimeSunHTML
        {
            get
            {
                if (this.OverTimeSunHour == 0 && this.OverTimeSunMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeSun + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeSunHour, this.OverTimeSunMinute);
                }
            }
        }

        public int OverTimeHolidayHour { get; set; }
        public int OverTimeHolidayMinute { get; set; }
        public int CountOverTimeHoliday { get; set; }
        public String OverTimeHoliday
        {
            get
            {
                if (this.OverTimeHolidayHour == 0 && this.OverTimeHolidayMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeHoliday + Environment.NewLine + EditDataUtil.FixTimeShow(this.OverTimeHolidayHour, this.OverTimeHolidayMinute);
                }
            }
        }
        public String OverTimeHolidayHTML
        {
            get
            {
                if (this.OverTimeHolidayHour == 0 && this.OverTimeHolidayMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return CountOverTimeHoliday + "<br />" + EditDataUtil.FixTimeShow(this.OverTimeHolidayHour, this.OverTimeHolidayMinute);
                }
            }
        }

        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of ListEmployeeInYearExcelList
        /// </summary>
        public ListEmployeeInYearExcelList()
            : base()
        {
            this.DisplayName = string.Empty;

            this.TimeWorkHour = 0;
            this.TimeWorkMinute = 0;
            this.CountTimeWork = 0;

            this.TimeWorkLateHour = 0;
            this.TimeWorkLateMinute = 0;
            this.CountTimeWorkLate = 0;

            this.TimeWorkEarlyHour = 0;
            this.TimeWorkEarlyMinute = 0;
            this.CountTimeWorkEarly = 0;

            this.TimeWorkOutHour = 0;
            this.TimeWorkOutMinute = 0;
            this.CountTimeWorkOut = 0;

            this.TimeWorkDayOffDB = string.Empty;
            this.TimeWorkAbsenceDB = string.Empty;
            this.CountTimeWorkDayOff = 0;
            this.CountTimeWorkAbsence = 0;

            this.OverTimeEarlyHour = 0;
            this.OverTimeEarlyMinute = 0;
            this.CountOverTimeEarly = 0;

            this.OverTimeNormalHour = 0;
            this.OverTimeNormalMinute = 0;
            this.CountOverTimeNormal = 0;

            this.OverTimeSatHour = 0;
            this.OverTimeSatMinute = 0;
            this.CountOverTimeSat = 0;

            this.OverTimeLateHour = 0;
            this.OverTimeLateMinute = 0;
            this.CountOverTimeLate = 0;

            this.OverTimeSunHour = 0;
            this.OverTimeSunMinute = 0;
            this.CountOverTimeSun = 0;

            this.OverTimeHolidayHour = 0;
            this.OverTimeHolidayMinute = 0;
            this.CountOverTimeHoliday = 0;
        }

        /// <summary>
        /// Contructor of ListEmployeeInYearExcelList
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public ListEmployeeInYearExcelList(DbDataReader dr)
        {

            this.DisplayName = dr["DisplayName"].ToString();

            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            this.CountTimeWork = (int)dr["CountTimeWork"];

            this.TimeWorkLateHour = (int)dr["TimeWorkLateHour"];
            this.TimeWorkLateMinute = (int)dr["TimeWorkLateMinute"];
            this.CountTimeWorkLate = (int)dr["CountTimeLate"];

            this.TimeWorkEarlyHour = (int)dr["TimeWorkEarlyHour"];
            this.TimeWorkEarlyMinute = (int)dr["TimeWorkEarlyMinute"];
            this.CountTimeWorkEarly = (int)dr["CountTimeEarly"];

            this.TimeWorkOutHour = (int)dr["TimeWorkOutHour"];
            this.TimeWorkOutMinute = (int)dr["TimeWorkOutMinute"];
            this.CountTimeWorkOut = (int)dr["CountTimeOut"];

            this.TimeWorkDayOffDB = dr["TimeWorkDayOff"].ToString();
            this.TimeWorkAbsenceDB = dr["TimeWorkAbsence"].ToString();
            this.CountTimeWorkDayOff = (int)dr["CountTimeWorkDayOff"];
            this.CountTimeWorkAbsence = (int)dr["CountTimeWorkAbsence"];

            this.OverTimeEarlyHour = (int)dr["OverTimeEarlyHour"];
            this.OverTimeEarlyMinute = (int)dr["OverTimeEarlyMinute"];
            this.CountOverTimeEarly = (int)dr["CountOverTimeEarly"];

            this.OverTimeNormalHour = (int)dr["OverTimeNormalHour"];
            this.OverTimeNormalMinute = (int)dr["OverTimeNormalMinute"];
            this.CountOverTimeNormal = (int)dr["CountOTNormal1"];

            this.OverTimeSatHour = (int)dr["OverTimeSatHour"];
            this.OverTimeSatMinute = (int)dr["OverTimeSatMinute"];
            this.CountOverTimeSat = (int)dr["CountOTNormal2"];

            this.OverTimeLateHour = (int)dr["OverTimeLateHour"];
            this.OverTimeLateMinute = (int)dr["OverTimeLateMinute"];
            this.CountOverTimeLate = (int)dr["CountOTLate"];

            this.OverTimeSunHour = (int)dr["OverTimeSunHour"];
            this.OverTimeSunMinute = (int)dr["OverTimeSunMinute"];
            this.CountOverTimeSun = (int)dr["CountOTHoliday1"];

            this.OverTimeHolidayHour = (int)dr["OverTimeHolidayHour"];
            this.OverTimeHolidayMinute = (int)dr["OverTimeHolidayMinute"];
            this.CountOverTimeHoliday = (int)dr["CountOTHoliday2"];

        }

        #endregion
    }

    [Serializable]
    public class EmployeeDetailInYearExcelList
    {
        #region Variable

        public int WorkMonth { get; set; }
        public int WorkYear { get; set; }
        public string WorkMMYYYY
        {
            get
            {
                if (this.WorkMonth == 0 && this.WorkYear == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return  WorkMonth.ToString() + "/" + WorkYear.ToString();
                }
            }
        }

        /* ------ PERFORMANCE TIME ------ */
        public int TimeWorkHour { get; set; }
        public int TimeWorkMinute { get; set; }
        public string TimeWork
        {
            get
            {
                if (this.TimeWorkHour == 0 && this.TimeWorkMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeWorkHour, this.TimeWorkMinute);
                }
            }
        }

        public int CountTimeWork { get; set; }
        public string CountTimeWorkStr
        {
            get
            {
                if (this.CountTimeWork == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeWork.ToString();
                }
            }
        }
        //-----
        public int TimeLateHour { get; set; }
        public int TimeLateMinute { get; set; }
        public string TimeLate
        {
            get
            {
                if (this.TimeLateHour == 0 && this.TimeLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeLateHour, this.TimeLateMinute);
                }
            }
        }

        public int CountTimeLate { get; set; }
        public string CountTimeLateStr
        {
            get
            {
                if (this.CountTimeLate == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeLate.ToString();
                }
            }
        }
        //-----
        public int TimeEarlyHour { get; set; }
        public int TimeEarlyMinute { get; set; }
        public string TimeEarly
        {
            get
            {
                if (this.TimeEarlyHour == 0 && this.TimeEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeEarlyHour, this.TimeEarlyMinute);
                }
            }
        }

        public int CountTimeEarly { get; set; }
        public string CountTimeEarlyStr
        {
            get
            {
                if (this.CountTimeEarly == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeEarly.ToString();
                }
            }
        }
        //-----
        public int TimeOutHour { get; set; }
        public int TimeOutMinute { get; set; }
        public string TimeOut
        {
            get
            {
                if (this.TimeOutHour == 0 && this.TimeOutMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.TimeOutHour, this.TimeOutMinute);
                }
            }
        }

        public int CountTimeOut { get; set; }
        public string CountTimeOutStr
        {
            get
            {
                if (this.CountTimeOut == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeOut.ToString();
                }
            }
        }

        //-----
        public decimal DayOff { get; set; }
        public string DayOffStr
        {
            get
            {
                if (this.DayOff == decimal.Zero)
                {
                    return String.Empty;
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, DayOff);
                }
            }
        }

        public int CountTimeWorkDayOff { get; set; }
        public string CountTimeWorkDayOffStr
        {
            get
            {
                if (this.CountTimeWorkDayOff == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeWorkDayOff.ToString();
                }
            }
        }




        public decimal Absence { get; set; }
        public string AbsenceStr
        {
            get
            {
                if (this.Absence == decimal.Zero)
                {
                    return String.Empty;
                }
                else
                {
                    return string.Format(Constants.NUMBER_FORMAT_DEC_2, Absence);
                }
            }
        }

        public int CountTimeWorkAbsence { get; set; }
        public string CountTimeWorkAbsenceStr
        {
            get
            {
                if (this.CountTimeWorkAbsence == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountTimeWorkAbsence.ToString();
                }
            }
        }

        /* ------ OVER TIME ------ */
        public int OTEarlyHour { get; set; }
        public int OTEarlyMinute { get; set; }
        public string OTEarly
        {
            get
            {
                if (this.OTEarlyHour == 0 && this.OTEarlyMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTEarlyHour, this.OTEarlyMinute);
                }
            }
        }

        public int CountOTEarly { get; set; }
        public string CountOTEarlyStr
        {
            get
            {
                if (this.CountOTEarly == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTEarly.ToString();
                }
            }
        }
        //-----
        public int OTNormal1Hour { get; set; }
        public int OTNormal1Minute { get; set; }
        public string OTNormal1
        {
            get
            {
                if (this.OTNormal1Hour == 0 && this.OTNormal1Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTNormal1Hour, this.OTNormal1Minute);
                }
            }
        }

        public int CountOTNormal1 { get; set; }
        public string CountOTNormal1Str
        {
            get
            {
                if (this.CountOTNormal1 == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTNormal1.ToString();
                }
            }
        }
        //-----
        public int OTSatHour { get; set; }
        public int OTSatMinute { get; set; }
        public string OTSat
        {
            get
            {
                if (this.OTSatHour == 0 && this.OTSatMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTSatHour, this.OTSatMinute);
                }
            }
        }

        public int CountOTSat { get; set; }
        public string CountOTSatStr
        {
            get
            {
                if (this.CountOTSat == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTSat.ToString();
                }
            }
        }
        //-----
        public int OTLateHour { get; set; }
        public int OTLateMinute { get; set; }
        public string OTLate
        {
            get
            {
                if (this.OTLateHour == 0 && this.OTLateMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTLateHour, this.OTLateMinute);
                }
            }
        }

        public int CountOTLate { get; set; }
        public string CountOTLateStr
        {
            get
            {
                if (this.CountOTLate == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTLate.ToString();
                }
            }
        }
        //-----
        public int OTSunHour { get; set; }
        public int OTSunMinute { get; set; }
        public string OTSun
        {
            get
            {
                if (this.OTSunHour == 0 && this.OTSunMinute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTSunHour, this.OTSunMinute);
                }
            }
        }

        public int CountOTSun { get; set; }
        public string CountOTSunStr
        {
            get
            {
                if (this.CountOTSun == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTSun.ToString();
                }
            }
        }
        //-----
        public int OTHoliday2Hour { get; set; }
        public int OTHoliday2Minute { get; set; }
        public string OTHoliday2
        {
            get
            {
                if (this.OTHoliday2Hour == 0 && this.OTHoliday2Minute == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return EditDataUtil.FixTimeShow(this.OTHoliday2Hour, this.OTHoliday2Minute);
                }
            }
        }

        public int CountOTHoliday2 { get; set; }
        public string CountOTHoliday2Str
        {
            get
            {
                if (this.CountOTHoliday2 == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return this.CountOTHoliday2.ToString();
                }
            }
        }
        #endregion

        #region Contructor

        /// <summary>
        /// Contructor of EmployeeDetailInMonthList
        /// </summary>
        public EmployeeDetailInYearExcelList()
            : base()
        {

            this.WorkMonth = 0;
            this.WorkYear = 0;

            this.TimeWorkHour = 0;
            this.TimeWorkMinute = 0;
            this.CountTimeWork = 0;

            this.TimeLateHour = 0;
            this.TimeLateMinute = 0;
            this.CountTimeLate = 0;

            this.TimeEarlyHour = 0;
            this.TimeEarlyMinute = 0;
            this.CountTimeEarly = 0;

            this.TimeOutHour = 0;
            this.TimeOutMinute = 0;
            this.CountTimeOut = 0;

            this.Absence = 0;
            this.CountTimeWorkAbsence = 0;

            this.DayOff = 0;
            this.CountTimeWorkDayOff = 0;

            this.OTEarlyHour = 0;
            this.OTEarlyMinute = 0;
            this.CountOTEarly = 0;

            this.OTNormal1Hour = 0;
            this.OTNormal1Minute = 0;
            this.CountOTNormal1 = 0;

            this.OTSatHour = 0;
            this.OTSatMinute = 0;
            this.CountOTSat = 0;

            this.OTLateHour = 0;
            this.OTLateMinute = 0;
            this.CountOTLate = 0;

            this.OTSunHour = 0;
            this.OTSunMinute = 0;
            this.CountOTSun = 0;

            this.OTHoliday2Hour = 0;
            this.OTHoliday2Minute = 0;
            this.CountOTHoliday2 = 0;
  
        }

        /// <summary>
        /// Contructor of EmployeeDetailInYearList
        /// </summary>
        /// <param name="dr">Database data reader</param>
        public EmployeeDetailInYearExcelList(DbDataReader dr)
        {

            this.WorkMonth = (int)dr["WorkMonth"];
            this.WorkYear = (int)dr["WorkYear"];

            // ---- PERFORMANCE TIME
            this.TimeWorkHour = (int)dr["TimeWorkHour"];
            this.TimeWorkMinute = (int)dr["TimeWorkMinute"];
            this.CountTimeWork = (int)dr["CountTimeWork"];
            //-----
            this.TimeLateHour = (int)dr["TimeLateHour"];
            this.TimeLateMinute = (int)dr["TimeLateMinute"];
            this.CountTimeLate = (int)dr["CountTimeLate"];
            //-----
            this.TimeEarlyHour = (int)dr["TimeEarlyHour"];
            this.TimeEarlyMinute = (int)dr["TimeEarlyMinute"];
            this.CountTimeEarly = (int)dr["CountTimeEarly"];
            //-----
            this.TimeOutHour = (int)dr["TimeOutHour"];
            this.TimeOutMinute = (int)dr["TimeOutMinute"];
            this.CountTimeOut = (int)dr["CountTimeOut"];

            this.DayOff = (decimal)dr["DayOff"];
            this.CountTimeWorkDayOff = (int)dr["CountTimeWorkDayOff"];
            //-----
            this.Absence = (decimal)dr["Absence"];
            this.CountTimeWorkAbsence = (int)dr["CountTimeWorkAbsence"];
            /* ------ OVER TIME ------ */
            //-----
            this.OTEarlyHour = (int)dr["OTEarlyHour"];
            this.OTEarlyMinute = (int)dr["OTEarlyMinute"];
            this.CountOTEarly = (int)dr["CountOTEarly"];
            //-----
            this.OTNormal1Hour = (int)dr["OTNormal1Hour"];
            this.OTNormal1Minute = (int)dr["OTNormal1Minute"];
            this.CountOTNormal1 = (int)dr["CountOTNormal1"];
            //-----
            this.OTSatHour = (int)dr["OTSatHour"];
            this.OTSatMinute = (int)dr["OTSatMinute"];
            this.CountOTSat = (int)dr["CountOTSat"];
            //-----
            this.OTLateHour = (int)dr["OTLateHour"];
            this.OTLateMinute = (int)dr["OTLateMinute"];
            this.CountOTLate = (int)dr["CountOTLate"];
            //-----
            this.OTSunHour = (int)dr["OTSunHour"];
            this.OTSunMinute = (int)dr["OTSunMinute"];
            this.CountOTSun = (int)dr["CountOTSun"];
            //-----
            this.OTHoliday2Hour = (int)dr["OTHoliday2Hour"];
            this.OTHoliday2Minute = (int)dr["OTHoliday2Minute"];
            this.CountOTHoliday2 = (int)dr["CountOTHoliday2"];  

        }

        #endregion
    }
}

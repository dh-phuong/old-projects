﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// ApplyApproveListInfo Model
    /// ISV-TRAM
    /// </summary>
    [Serializable]
    public class ApplyApproveListInfo
    {
        public int RowNum { get; set; }
        public int ApplyID { get; set; }
        public int RouteUID { get; set; }
        public string UserName { get; set; }
        public int? RouteLevel { get; set; }
        public short? RouteMethod { get; set; }
        public string RouteMethodStr { get; set; }
        public short? ApproveStatus { get; set; }
        public string ApproveFlagStr { get; set; }
        public int? ApproveUID { get; set; }
        public string ApproveName { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string ApproveDateStr { get; set; }
        public string ApproveReason { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
        public int RequireNum { get; set; }

        public short RouteFlag1 { get; set; }
        public short RouteFlag2 { get; set; }
        public short RouteFlag3 { get; set; }
        public short RouteFlag4 { get; set; }
        public short RouteFlag5 { get; set; }
        public short RouteFlag6 { get; set; }
        public short RouteFlag7 { get; set; }
        public short RouteFlag8 { get; set; }
        public short RouteFlag9 { get; set; }
        public short RouteFlag10 { get; set; }
        /// <summary>
        /// Constructor class ApplyApproveListInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ApplyApproveListInfo(DbDataReader dr)
        {
            this.RowNum = int.Parse(dr["RowNum"].ToString());
            this.ApplyID = int.Parse(dr["ApplyID"].ToString());
            this.RouteUID = int.Parse(dr["RouteUID"].ToString());
            this.UserName = dr["RouteUserName"].ToString();
            if (dr["RouteLevel"] != DBNull.Value)
            {
                this.RouteLevel = int.Parse(dr["RouteLevel"].ToString());
            }
            else
            {
                this.RouteLevel = null;
            }

            this.RequireNum = int.Parse(dr["RequireNum"].ToString());
            this.RouteFlag1 = short.Parse(dr["RouteFlag1"].ToString());
            this.RouteFlag2 = short.Parse(dr["RouteFlag2"].ToString());
            this.RouteFlag3 = short.Parse(dr["RouteFlag3"].ToString());
            this.RouteFlag4 = short.Parse(dr["RouteFlag4"].ToString());
            this.RouteFlag5 = short.Parse(dr["RouteFlag5"].ToString());
            this.RouteFlag6 = short.Parse(dr["RouteFlag6"].ToString());
            this.RouteFlag7 = short.Parse(dr["RouteFlag7"].ToString());
            this.RouteFlag8 = short.Parse(dr["RouteFlag8"].ToString());
            this.RouteFlag9 = short.Parse(dr["RouteFlag9"].ToString());
            this.RouteFlag10 = short.Parse(dr["RouteFlag10"].ToString());

            if (dr["RouteMethod"] != DBNull.Value)
            {
                this.RouteMethod = short.Parse(dr["RouteMethod"].ToString());
                switch (this.RouteMethod)
                { 
                    case (short) RouteMethods.AND:
                        this.RouteMethodStr = RouteMethods.AND.ToString();
                        break;
                    case (short)RouteMethods.OR:
                        this.RouteMethodStr = RouteMethods.OR.ToString();
                        break;
                }
            }
            else
            {
                this.RouteMethod = null;
                this.RouteMethodStr = string.Empty;
            }
                       
            if (dr["ApproveStatus"] != DBNull.Value)
            {
                this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());

                switch (this.ApproveStatus)
                {
                    case (int)StatusHasAprove.New:
                        //this.ApproveFlagStr = "<span class='label label-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>New</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-minus text-color-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    //case (int)StatusHasAprove.Approve:
                    //    this.ApproveFlagStr = "<span class='label label-info' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>申請済</span>";
                    //    break;
                    case (int)StatusHasAprove.Approved:
                        //this.ApproveFlagStr = "<span class='label label-success' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>Approve</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-ok text-color-success' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    case (int)StatusHasAprove.Ignore:
                        //this.ApproveFlagStr = "<span class='label label-danger' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>Ignore</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-remove text-color-danger' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    case (int)StatusHasAprove.BackPrev:
                        //this.ApproveFlagStr = "<span class='label label-warning' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>PrevBack</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-arrow-left text-color-warning' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                }
            }
            else
            {
                this.ApproveFlagStr = string.Empty;
            }

            if ( dr["ApproveUID"] != DBNull.Value)
            {
                this.ApproveUID = int.Parse(dr["ApproveUID"].ToString());
            }
            else 
            {
                this.ApproveUID = null;
            }
            this.ApproveName = dr["ApproveUserName"].ToString();
            if (dr["ApproveDate"] != DBNull.Value)
            {
                this.ApproveDate = DateTime.Parse(dr["ApproveDate"].ToString());
                this.ApproveDateStr = this.ApproveDate.Value.ToString(Constants.FMT_DATE_TIME);
            }
            else
            {
                this.ApproveDate = null;
            }
           
            this.ApproveReason = dr["ApproveReason"].ToString();

            this.Department = dr["DepartmentName"].ToString();

            this.Position = dr["Position"].ToString();
        }

        /// <summary>
        /// Constructor class ApplyApproveListInfo
        /// </summary>
        public ApplyApproveListInfo()
        {
            this.RowNum = 0;
            this.ApplyID=0;
            this.RouteUID = 0;
            this.UserName = string.Empty;
            this.RouteLevel = 0;
            this.RouteMethod = 0;
            this.RouteMethodStr = string.Empty;
            this.ApproveStatus = null;
            this.ApproveUID = null;
            this.ApproveName = string.Empty;
            this.ApproveDate = null;
            this.ApproveDateStr = string.Empty;
            this.ApproveReason = string.Empty;
            this.Department = string.Empty;
            this.Position = string.Empty;
            this.RequireNum = 0;
        }
    }


    /// <summary>
    /// ISV-TRUC
    /// Edit for Approve List New (more flags than the old list)
    /// </summary>
    [Serializable]
    public class ApplyApproveListModel
    {
        public int RowNum { get; set; }
        public int ApplyID { get; set; }
        public int RouteUID { get; set; }
        public string UserName { get; set; }
        public int? RouteLevel { get; set; }
        public short? RouteMethod { get; set; }
        public string RouteMethodStr { get; set; }
        public short? ApproveStatus { get; set; }
        public string ApproveFlagStr { get; set; }
        public int? ApproveUID { get; set; }
        public string ApproveName { get; set; }
        public DateTime? ApproveDate { get; set; }
        public string ApproveDateStr { get; set; }
        public string ApproveReason { get; set; }
        public string Department { get; set; }
        public string Position { get; set; }
        public int RequireNum { get; set; }

        public string ProxyApprovalUser { get; set; }

        //Apply
        public short ApplyFlag1 { get; set; }
        public short ApplyFlag2 { get; set; }
        public short ApplyFlag3 { get; set; }
        public short ApplyFlag4 { get; set; }

        //Reject
        public short RejectFlag1 { get; set; }
        public short RejectFlag2 { get; set; }
        public short RejectFlag3 { get; set; }
        public short RejectFlag4 { get; set; }
        public short RejectFlag5 { get; set; }
        public short RejectFlag6 { get; set; }
        public short RejectFlag7 { get; set; }
        
        //Remand
        public short RemandFlag1 { get; set; }
        public short RemandFlag2 { get; set; }
        public short RemandFlag3 { get; set; }
        public short RemandFlag4 { get; set; }
        public short RemandFlag5 { get; set; }
        public short RemandFlag6 { get; set; }
        public short RemandFlag7 { get; set; }
        
        //Approve
        public short ApproveFlag1 { get; set; }
        public short ApproveFlag2 { get; set; }
        public short ApproveFlag3 { get; set; }
        public short ApproveFlag4 { get; set; }
        public short ApproveFlag5 { get; set; }
        public short ApproveFlag6 { get; set; }
        public short ApproveFlag7 { get; set; }
        public short ApproveFlag8 { get; set; }
        public short ApproveFlag9 { get; set; }

        //Read
        public short ReadFlag1 { get; set; }
        public short ReadFlag2 { get; set; }
        public short ReadFlag3 { get; set; }
        public short ReadFlag4 { get; set; }
        public short ReadFlag5 { get; set; }

        /// <summary>
        /// Constructor class ApplyApproveListModel
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public ApplyApproveListModel(DbDataReader dr)
        {
            this.RowNum = int.Parse(dr["RowNum"].ToString());
            this.ApplyID = int.Parse(dr["ApplyID"].ToString());
            this.RouteUID = int.Parse(dr["RouteUID"].ToString());
            this.UserName = dr["RouteUserName"].ToString();
            if (dr["RouteLevel"] != DBNull.Value)
            {
                this.RouteLevel = int.Parse(dr["RouteLevel"].ToString());
            }
            else
            {
                this.RouteLevel = null;
            }

            this.RequireNum = int.Parse(dr["RequireNum"].ToString());
            this.ProxyApprovalUser = dr["ProxyApprovalUser"].ToString();
            //Apply
            this.ApplyFlag1 = short.Parse(dr["ApplyFlag1"].ToString());
            this.ApplyFlag2 = short.Parse(dr["ApplyFlag2"].ToString());
            this.ApplyFlag3 = short.Parse(dr["ApplyFlag3"].ToString());
            this.ApplyFlag4 = short.Parse(dr["ApplyFlag4"].ToString());

            //Reject
            this.RejectFlag1 = short.Parse(dr["RejectFlag1"].ToString());
            this.RejectFlag2 = short.Parse(dr["RejectFlag2"].ToString());
            this.RejectFlag3 = short.Parse(dr["RejectFlag3"].ToString());
            this.RejectFlag4 = short.Parse(dr["RejectFlag4"].ToString());
            this.RejectFlag5 = short.Parse(dr["RejectFlag5"].ToString());
            this.RejectFlag6 = short.Parse(dr["RejectFlag6"].ToString());
            this.RejectFlag7 = short.Parse(dr["RejectFlag7"].ToString());

            //Remand
            this.RemandFlag1 = short.Parse(dr["RemandFlag1"].ToString());
            this.RemandFlag2 = short.Parse(dr["RemandFlag2"].ToString());
            this.RemandFlag3 = short.Parse(dr["RemandFlag3"].ToString());
            this.RemandFlag4 = short.Parse(dr["RemandFlag4"].ToString());
            this.RemandFlag5 = short.Parse(dr["RemandFlag5"].ToString());
            this.RemandFlag6 = short.Parse(dr["RemandFlag6"].ToString());
            this.RemandFlag7 = short.Parse(dr["RemandFlag7"].ToString());

            //Approve
            this.ApproveFlag1 = short.Parse(dr["ApproveFlag1"].ToString());
            this.ApproveFlag2 = short.Parse(dr["ApproveFlag2"].ToString());
            this.ApproveFlag3 = short.Parse(dr["ApproveFlag3"].ToString());
            this.ApproveFlag4 = short.Parse(dr["ApproveFlag4"].ToString());
            this.ApproveFlag5 = short.Parse(dr["ApproveFlag5"].ToString());
            this.ApproveFlag6 = short.Parse(dr["ApproveFlag6"].ToString());
            this.ApproveFlag7 = short.Parse(dr["ApproveFlag7"].ToString());
            this.ApproveFlag8 = short.Parse(dr["ApproveFlag8"].ToString());
            this.ApproveFlag9 = short.Parse(dr["ApproveFlag9"].ToString());

            //Read
            this.ReadFlag1 = short.Parse(dr["ReadFlag1"].ToString());
            this.ReadFlag2 = short.Parse(dr["ReadFlag2"].ToString());
            this.ReadFlag3 = short.Parse(dr["ReadFlag3"].ToString());
            this.ReadFlag4 = short.Parse(dr["ReadFlag4"].ToString());
            this.ReadFlag5 = short.Parse(dr["ReadFlag5"].ToString());
            

            if (dr["RouteMethod"] != DBNull.Value)
            {
                this.RouteMethod = short.Parse(dr["RouteMethod"].ToString());
                switch (this.RouteMethod)
                {
                    case (short)RouteMethods.AND:
                        this.RouteMethodStr = RouteMethods.AND.ToString();
                        break;
                    case (short)RouteMethods.OR:
                        this.RouteMethodStr = RouteMethods.OR.ToString();
                        break;
                }
            }
            else
            {
                this.RouteMethod = null;
                this.RouteMethodStr = string.Empty;
            }

            if (dr["ApproveStatus"] != DBNull.Value)
            {
                this.ApproveStatus = short.Parse(dr["ApproveStatus"].ToString());

                switch (this.ApproveStatus)
                {
                    case (int)StatusHasAprove.New:
                        //this.ApproveFlagStr = "<span class='label label-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>New</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-minus text-color-default' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    //case (int)StatusHasAprove.Approve:
                    //    this.ApproveFlagStr = "<span class='label label-info' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>申請済</span>";
                    //    break;
                    case (int)StatusHasAprove.Approved:
                        //this.ApproveFlagStr = "<span class='label label-success' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>Approve</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-ok text-color-success' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    case (int)StatusHasAprove.Ignore:
                        //this.ApproveFlagStr = "<span class='label label-danger' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>Ignore</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-remove text-color-danger' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                    case (int)StatusHasAprove.BackPrev:
                        //this.ApproveFlagStr = "<span class='label label-warning' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'>PrevBack</span>";
                        this.ApproveFlagStr = "<span class='glyphicon glyphicon-arrow-left text-color-warning' style='width:70px; display: inline-block; text-align:center; vertical-align:middle;'></span>";
                        break;
                }
            }
            else
            {
                this.ApproveFlagStr = string.Empty;
            }

            if (dr["ApproveUID"] != DBNull.Value)
            {
                this.ApproveUID = int.Parse(dr["ApproveUID"].ToString());
            }
            else
            {
                this.ApproveUID = null;
            }
            this.ApproveName = dr["ApproveUserName"].ToString();
            if (dr["ApproveDate"] != DBNull.Value)
            {
                this.ApproveDate = DateTime.Parse(dr["ApproveDate"].ToString());
                this.ApproveDateStr = this.ApproveDate.Value.ToString(Constants.FMT_DATE_TIME);
            }
            else
            {
                this.ApproveDate = null;
            }

            this.ApproveReason = dr["ApproveReason"].ToString();

            this.Department = dr["DepartmentName"].ToString();

            this.Position = dr["Position"].ToString();
        }
        
        #region method

        /// <summary>
        /// Get apply setting flag
        /// </summary>
        /// <param name="authorType"></param>
        /// <returns></returns>
        public bool GetApplySetting(ApplySetting applyType)
        {
            switch (applyType)
            {
                case ApplySetting.ProxyAll:
                    return this.ApplyFlag1 == 1;
                case ApplySetting.ProxyDept:
                    return this.ApplyFlag2 == 1;
                case ApplySetting.Mail:
                    return this.ApplyFlag3 == 1;
                case ApplySetting.MailAll:
                    return this.ApplyFlag4 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get approve setting
        /// </summary>
        /// <param name="approveType"></param>
        /// <returns></returns>
        public bool GetApproveSetting(ApproveSetting approveType)
        {
            switch (approveType)
            {
                case ApproveSetting.SeniorApprove:
                    return this.ApproveFlag1 == 1;
                case ApproveSetting.SeniorApproveAll:
                    return this.ApproveFlag2 == 1;
                case ApproveSetting.MailAppliciant:
                    return this.ApproveFlag3 == 1;
                case ApproveSetting.MailPreAll:
                    return this.ApproveFlag4 == 1;
                case ApproveSetting.MailPre:
                    return this.ApproveFlag5 == 1;
                case ApproveSetting.MailCurrentLevel:
                    return this.ApproveFlag6 == 1;
                case ApproveSetting.MailNext:
                    return this.ApproveFlag7 == 1;
                case ApproveSetting.MailNextAll:
                    return this.ApproveFlag8 == 1;
                case ApproveSetting.Reader:
                    return this.ApproveFlag9 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get Reject setting
        /// </summary>
        /// <param name="rejectType"></param>
        /// <returns></returns>
        public bool GetRejectSetting(RejectSetting rejectType)
        {
            switch (rejectType)
            {
                case RejectSetting.RejectAuthor:
                    return this.RejectFlag1 == 1;
                case RejectSetting.MailAppliciant:
                    return this.RejectFlag2 == 1;
                case RejectSetting.MailPreAll:
                    return this.RejectFlag3 == 1;
                case RejectSetting.MailPre:
                    return this.RejectFlag4 == 1;
                case RejectSetting.MailCurrentLevel:
                    return this.RejectFlag5 == 1;
                case RejectSetting.MailNext:
                    return this.RejectFlag6 == 1;
                case RejectSetting.MailNextAll:
                    return this.RejectFlag7 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get remand setting
        /// </summary>
        /// <param name="remandType"></param>
        /// <returns></returns>
        public bool GetRemandSetting(RemandSetting remandType)
        {
            switch (remandType)
            {
                case RemandSetting.RemandAuthor:
                    return this.RemandFlag1 == 1;
                case RemandSetting.MailAppliciant:
                    return this.RemandFlag2 == 1;
                case RemandSetting.MailPreAll:
                    return this.RemandFlag3 == 1;
                case RemandSetting.MailPre:
                    return this.RemandFlag4 == 1;
                case RemandSetting.MailCurrentLevel:
                    return this.RemandFlag5 == 1;
                case RemandSetting.MailNext:
                    return this.RemandFlag6 == 1;
                case RemandSetting.MailNextAll:
                    return this.RemandFlag7 == 1;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Get read setting
        /// </summary>
        /// <param name="readType"></param>
        /// <returns></returns>
        public bool GetReadSetting(ReadSetting readType)
        {
            switch (readType)
            {
                case ReadSetting.ReadAuthor:
                    return this.ReadFlag1 == 1;
                case ReadSetting.MailAppliciant:
                    return this.ReadFlag2 == 1;
                case ReadSetting.MailPreAll:
                    return this.ReadFlag3 == 1;
                case ReadSetting.MailPre:
                    return this.ReadFlag4 == 1;
                case ReadSetting.MailGroup:
                    return this.ReadFlag5 == 1;
                default:
                    return false;
            }
        }

        #endregion

        /// <summary>
        /// Constructor class ApplyApproveListInfo
        /// </summary>
        public ApplyApproveListModel()
        {
            this.RowNum = 0;
            this.ApplyID = 0;
            this.RouteUID = 0;
            this.UserName = string.Empty;
            this.RouteLevel = 0;
            this.RouteMethod = 0;
            this.RouteMethodStr = string.Empty;
            this.ApproveStatus = null;
            this.ApproveUID = null;
            this.ApproveName = string.Empty;
            this.ApproveDate = null;
            this.ApproveDateStr = string.Empty;
            this.ApproveReason = string.Empty;
            this.Department = string.Empty;
            this.Position = string.Empty;
            this.RequireNum = 0;
            this.ProxyApprovalUser = string.Empty;
        }
    }
}

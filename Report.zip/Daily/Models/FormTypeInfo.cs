﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class Form Type Info Model
    /// 
    /// </summary>
    [Serializable]
    public class FormTypeInfo
    {
        public int FormID { get; set; }
        public int ID { get; set; }
        public string TypeName { get; set; }
        public bool DeleteFlg { get; set; }
        public short TimeOfRule { get; set; }
        public bool HadUsed { get; set; }

        /// <summary>
        /// Constructor class FormTypeInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public FormTypeInfo(DbDataReader dr)
        {
            this.FormID = int.Parse(dr["FormID"].ToString());
            this.ID = int.Parse(dr["ID"].ToString());
            this.TypeName = (string)dr["TypeName"];
            this.TimeOfRule = short.Parse(dr["TimeOfRule"].ToString());
            this.HadUsed = int.Parse(dr["HadUsed"].ToString()) > 0;
        }

        /// <summary>
        /// Constructor class FormTypeInfo
        /// </summary>
        public FormTypeInfo()
        {
            this.ID = -1;
            this.FormID = -1;
            this.TypeName = string.Empty;
            this.DeleteFlg = false;
            this.TimeOfRule = -1;
            this.HadUsed = false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{
    public class StringModel
    {
        public string Text { get; set; }
        public int Val { get; set; }
        public int Val2 { get; set; }
        public StringModel()
        {
            this.Text = string.Empty;
            this.Val = -1;
            this.Val2 = -1;
        }

        public StringModel(int val,int val2, string text)
        {
            this.Text = text;
            this.Val = val;
            this.Val2 = val2;
        }

        //public StringModel(int val)
        //{
        //    this.Text = string.Empty;
        //    this.Val = val;
        //    this.Val2 = -1;
        //}

        //public StringModel(int val2)
        //{
        //    this.Text = string.Empty;
        //    this.Val2 = val2;
        //    this.Val = -1;
        //}

        public StringModel(string text)
        {
            this.Text = text;
            this.Val = -1;
            this.Val2 = -1;
        }
    }
}

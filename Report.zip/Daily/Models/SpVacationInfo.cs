﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    [Serializable]
    public class SpVacationInfo
    {
        public long RowNumber { get; set; }

        /// <summary>
        /// ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Special vacation code
        /// </summary>
        public string SpVacationCD { get; set; }

        /// <summary>
        /// Special Vacation Name (VN)
        /// </summary>
        public string SpVacationNameVN { get; set; }

        /// <summary>
        /// Special Vacation Name (EN)
        /// </summary>
        public string SpVacationNameUS { get; set; }

        /// <summary>
        /// Effect date
        /// </summary>
        public DateTime EffectDate { get; set; }

        /// <summary>
        /// Expire date
        /// </summary>
        public DateTime ExpireDate { get; set; }

        /// <summary>
        /// Num of time
        /// </summary>
        public decimal NumOfTime { get; set; }

        /// <summary>
        /// Unit Time
        /// </summary>
        public string UnitTime { get; set; }

         /// <summary>
        /// Constructor
        /// </summary>
        public SpVacationInfo()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public SpVacationInfo(DbDataReader dr)
        {
            this.RowNumber = long.Parse(dr["RowNumber"].ToString());

            this.ID = (int)dr["ID"];
            this.SpVacationCD = (string)dr["SpVacationCD"];
            this.SpVacationNameVN = (string)dr["SpVacationNameVN"];
            this.SpVacationNameUS = (string)dr["SpVacationNameUS"];
            this.EffectDate = (DateTime)dr["EffectDate"];
            this.ExpireDate = (DateTime)dr["ExpireDate"];
            this.NumOfTime = (decimal)dr["NumOfTime"];
            this.UnitTime = (string)dr["UnitTime"];
        }
    }
}

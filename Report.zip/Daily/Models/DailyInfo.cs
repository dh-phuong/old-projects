﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using DailyReport.Utilities;


namespace DailyReport.Models
{
    /// <summary>
    /// DailyInfo Model
    /// ISV-TRAM 2015/03/02
    /// </summary>
    [Serializable]
    public class DailyInfo
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public DailyInfo()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        public DailyInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.WorkDate = (DateTime)dr["WorkDate"];
            this.TypeApplyID = int.Parse(dr["TypeApplyID"].ToString());
            this.TypeName = (string)dr["TypeName"];
            if (dr["ApproveID"] != DBNull.Value)
            {
                this.ApproveID = int.Parse(dr["ApproveID"].ToString());
            }
            else
            {
                this.ApproveID = null;
            }

            this.StartHour = dr["StartHour"].ToString();
            this.StartMinute = dr["StartMinute"].ToString();
            this.EndHour = dr["EndHour"].ToString();
            this.EndMinute = dr["EndMinute"].ToString();
            this.Content = dr["Content"].ToString();
            this.DeleteFlag = short.Parse(dr["DeleteFlag"].ToString());
            this.Collapsed = string.Empty;
        }

        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public DateTime WorkDate { get; set; }

        /// <summary>
        /// Get or set Type
        /// </summary>
        public int TypeApplyID { get; set; }

        /// Get or set TypeName
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// Get or set ApproveID
        /// </summary>
        public int? ApproveID { get; set; }

        /// <summary>
        /// Get or set StartHour
        /// </summary>
        public string StartHour { get; set; }

        /// <summary>
        /// Get or set StartMinute
        /// </summary>
        public string StartMinute { get; set; }

        /// <summary>
        /// Get or set EndHour
        /// </summary>
        public string EndHour { get; set; }

        /// <summary>
        /// Get or set EndMinute
        /// </summary>
        public string EndMinute { get; set; }

        /// <summary>
        /// Get or set Content
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Get or set DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// Get or set Collapsed
        /// </summary>
        public string Collapsed { get; set; }
    }

    [Serializable]
    public class DailyCalendar
    {
        public string UserName { get; set; }
        public int wor { get; set; }
    }

    [Serializable]
    public class DailyDataSource
    {
        /// <summary>
        /// Get or set DayOfWeek
        /// </summary>
        public string DayOfWeek { get; set; }

        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public string WorkDate { get; set; }

        /// <summary>
        /// Color
        /// </summary>
        public int Color { get; set; }

        /// Get or set IsHoliday
        /// </summary>
        public short IsHoliday { get; set; }

        /// <summary>
        /// Get or set list detail
        /// </summary>
        public IList<DailyInfo> DailyDetailList { get; set; }
    }

    [Serializable]
    public class SummaryDailyDataSource
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public SummaryDailyDataSource()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        public SummaryDailyDataSource(DbDataReader dr)
        {
            this.TypeApplyID = int.Parse(dr["TypeApplyID"].ToString());
            this.TypeName = dr["TypeName"].ToString();
            this.HourTotal = int.Parse(dr["HourTotal"].ToString()) + int.Parse(dr["MinuteTotal"].ToString()) / 60;
            this.MinuteTotal = int.Parse(dr["MinuteTotal"].ToString()) % 60;
            this.TimeUnit = int.Parse(dr["TimeUnit"].ToString());

        }

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public String WorkDate { get; set; }

        /// <summary>
        /// Get or set TypeApplyID
        /// </summary>
        public int TypeApplyID { get; set; }

        /// <summary>
        /// Get or set TypeName
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// Get or set HourTotal
        /// </summary>
        public int HourTotal { get; set; }

        /// <summary>
        /// Get or set MinuteTotal
        /// </summary>
        public int MinuteTotal { get; set; }

        /// <summary>
        /// Get or set LeaveDayTotal
        /// </summary>
        public decimal LeaveDayTotal { get; set; }

        /// <summary>
        /// Get or set TimeUnit
        /// </summary>
        public int TimeUnit { get; set; }
    }

    [Serializable]
    public class CalendarInfo
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CalendarInfo()
        {
        }

        public CalendarInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserID = int.Parse(dr["UserID"].ToString());
            this.UserName1 = dr["UserName1"].ToString();
            this.UserName2 = dr["UserName2"].ToString();
            this.WorkDate = (DateTime)dr["WorkDate"];
            this.TypeApplyID = int.Parse(dr["TypeApplyID"].ToString());
            if (dr["ApproveID"] != DBNull.Value)
            {
                this.ApproveID = int.Parse(dr["ApproveID"].ToString());
            }
            else
            {
                this.ApproveID = null;
            }

            this.StartHour = int.Parse(dr["StartHour"].ToString());
            this.StartMinute = int.Parse(dr["StartMinute"].ToString());
            this.EndHour = int.Parse(dr["EndHour"].ToString());
            this.EndMinute = int.Parse(dr["EndMinute"].ToString());
            this.Content = dr["Content"].ToString();
        }

        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int UserID { get; set; }

        /// <summary>
        /// Get or set UserName
        /// </summary>
        public string UserName1 { get; set; }

        /// <summary>
        /// Get or set UserName
        /// </summary>
        public string UserName2 { get; set; }

        /// <summary>
        /// Get or set WorkDate
        /// </summary>
        public DateTime WorkDate { get; set; }

        /// <summary>
        /// Get or set Type
        /// </summary>
        public int TypeApplyID { get; set; }

        /// <summary>
        /// Get or set ApproveID
        /// </summary>
        public int? ApproveID { get; set; }

        /// <summary>
        /// Get or set StartHour
        /// </summary>
        public int StartHour { get; set; }

        /// <summary>
        /// Get or set StartMinute
        /// </summary>
        public int StartMinute { get; set; }

        /// <summary>
        /// Get or set EndHour
        /// </summary>
        public int EndHour { get; set; }

        /// <summary>
        /// Get or set EndMinute
        /// </summary>
        public int EndMinute { get; set; }

        /// <summary>
        /// Get or set Content
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// Get or set DeleteFlag
        /// </summary>
        public short DeleteFlag { get; set; }

        /// Get or set TypeName
        /// </summary>
        public string TypeName { get; set; }

        /// <summary>
        /// Get or set Color
        /// </summary>
        public string HColor { get; set; }
    }

    [Serializable]
    public class DailyOutingInfo
    {
        public bool Checked { get; set; }
        public int? StartHour { get; set; }
        public int? StartMinute { get; set; }
        public int? EndHour { get; set; }
        public int? EndMinute { get; set; }

        public DateTime? StartOutTime
        {
            get
            {
                if (StartHour != null)
                {
                    return new DateTime().AddHours((int)StartHour).AddMinutes((int)StartMinute);
                }
                else
                {
                    return null;
                }

            }
            set
            {
                if (value != null)
                {
                    this.StartHour = value.Value.Hour;
                    this.StartMinute = value.Value.Minute;
                }
                else
                {
                    this.StartHour = null;
                    this.StartMinute = null;
                }
            }
        }

        public DateTime? EndOutTime
        {
            get
            {
                if (EndHour != null)
                {
                    return new DateTime().AddHours((int)EndHour).AddMinutes((int)EndMinute);
                }
                else
                {
                    return null;
                }

            }
            set
            {
                if (value != null)
                {
                    this.EndHour = value.Value.Hour;
                    this.EndMinute = value.Value.Minute;
                }
                else
                {
                    this.EndHour = null;
                    this.EndMinute = null;
                }
            }
        }

        public DailyOutingInfo(){}

        public DailyOutingInfo(DbDataReader dr)
        {
            this.StartHour = (int)dr["StartHour"];
            this.StartMinute = (int)dr["StartMinute"];
            this.EndHour = (int)dr["EndHour"];
            this.EndMinute = (int)dr["EndMinute"];
        }
    }

    [Serializable]
    public class DailyWorkInfo
    {
        public bool Checked { get; set; }
        public string WorkName { get; set; }
        public int? WorkHour { get; set; }
        public int? WorkMinute { get; set; }
        public string WorkNote { get; set; }

        public DateTime? WorkTime
        {
            get
            {
                if (WorkHour != null)
                {
                    return new DateTime().AddHours((int)WorkHour).AddMinutes((int)WorkMinute);
                }
                else
                {
                    return null;
                }

            }
            set
            {
                if (value != null)
                {
                    this.WorkHour = value.Value.Hour;
                    this.WorkMinute = value.Value.Minute;
                }
                else
                {
                    this.WorkHour = null;
                    this.WorkMinute = null;
                }
            }
        }

        public DailyWorkInfo(){}

        public DailyWorkInfo(DbDataReader dr)
        {
            this.WorkName = dr["WorkName"].ToString();
            this.WorkHour = (int)dr["WorkHour"];
            this.WorkMinute = (int)dr["WorkMinute"];
            this.WorkNote = dr["Remark"].ToString();
        }
    }   
}

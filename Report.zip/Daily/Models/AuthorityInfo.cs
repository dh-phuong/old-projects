﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.Models
{
    public class AuthorityInfo
    {
        public bool IsMasterView { get; set; }
        public bool IsMasterNew { get; set; }
        public bool IsMasterEdit { get; set; }
        public bool IsMasterCopy { get; set; }
        public bool IsMasterDelete { get; set; }
        
        public bool IsDailyView { get; set; }
        public bool IsDailyEdit { get; set; }
        public bool IsDailyNew { get; set; }
        public bool IsDailyCopy { get; set; }        
        public bool IsDailyDelete { get; set; }

        public bool IsApplyRegistView { get; set; }
        public bool IsApplyRegistEdit { get; set; }
        public bool IsApplyRegistNew { get; set; }
        public bool IsApplyRegistCopy { get; set; }
        public bool IsApplyRegistConfirm { get; set; }
        public bool IsApplyRegistDelete { get; set; }
        public bool IsApplyRegistCheckAllUser { get; set; }

        public bool IsApplyApproveView { get; set; }
        public bool IsApplyApproveApprove { get; set; }
        public bool IsApplyApproveIgnore { get; set; }
        public bool IsApplyApproveReBack { get; set; }

        public bool IsVacRegistView { get; set; }
        public bool IsVacRegistEdit { get; set; }
        public bool IsVacRegistNew { get; set; }
        public bool IsVacRegistCopy { get; set; }
        public bool IsVacRegistConfirm { get; set; }
        public bool IsVacRegistDelete { get; set; }
        public bool IsVacRegistCheckAllUser { get; set; }

        public bool IsVacApproveView { get; set; }
        public bool IsVacApproveApprove { get; set; }
        public bool IsVacApproveIgnore { get; set; }
        public bool IsVacApproveReBack { get; set; }
        
    }
}

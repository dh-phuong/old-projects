﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Province information
    /// </summary>
    [Serializable]
    public class WardInfo
    {
        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set Province code
        /// </summary>
        public string ProvinceCD { get; set; }

        /// <summary>
        /// Get or set province name
        /// </summary>
        public string ProvinceName { get; set; }

        /// <summary>
        /// Get or set district code
        /// </summary>
        public string DistrictCD { get; set; }

        /// <summary>
        /// Get or set district name
        /// </summary>
        public string DistrictName { get; set; }

        /// <summary>
        /// Get or set ward code
        /// </summary>
        public string WardCD { get; set; }

        /// <summary>
        /// Get or set ward name
        /// </summary>
        public string WardName { get; set; }

        /// <summary>
        /// Contructor
        /// </summary>
        public WardInfo() { }

        /// <summary>
        /// Contructor with DbDataReader
        /// </summary>
        /// <param name="dr"></param>
        public WardInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.RowNumber = (long)dr["RowNumber"];
            this.ProvinceCD = EditDataUtil.ToFixCodeShow((string)dr["ProvinceCD"], M_Province.PROVINCE_CODE_MAX_LEN_SHOW);
            this.ProvinceName = dr["ProvinceName"].ToString();
            this.DistrictCD = dr["DistrictCD"].ToString();
            this.DistrictName = dr["DistrictName"].ToString();
            this.WardCD = EditDataUtil.ToFixCodeShow((string)dr["WardCD"], M_Ward.WARD_CODE_MAX_LEN_SHOW);
            this.WardName = dr["WardName"].ToString();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Common;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// DepartmentInfo Model
    /// ISV-TRAM 2015/03/19
    /// </summary>
    [Serializable]
    public class DepartmentInfo
    {
        /// <summary>
        /// Constructor with param
        /// </summary>
        public DepartmentInfo(DbDataReader dr)
        {
            this.ID = int.Parse(dr["ID"].ToString());
            this.RowNumber = (long)dr["RowNumber"];
            this.DepartmentCD = EditDataUtil.ToFixCodeShow((string)dr["DepartmentCD"], M_Department.MAX_DEPARTRMENT_CODE_SHOW); 
            this.DepartmentName = dr["DepartmentName"].ToString();
            this.Collapsed = string.Empty;
        }

        /// <summary>
        /// Get or set ID
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        /// Get or set RowNumber
        /// </summary>
        public long RowNumber { get; set; }

        /// <summary>
        /// Get or set DepartmentCD
        /// </summary>
        public string DepartmentCD { get; set; }

        /// <summary>
        /// Get or set DepartmentName
        /// </summary>
        public string DepartmentName { get; set; }

        /// Get or set Collapsed
        /// </summary>
        public string Collapsed { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        public DepartmentInfo()
        {
            this.ID = -1;
            this.RowNumber = -1;
            this.DepartmentCD = string.Empty;
            this.DepartmentName = string.Empty;
            
        }
    }

    /// <summary>
    /// DepartmentSearchInfo
    /// ISV-TRUC
    /// 2015/04/16
    /// </summary>
    [Serializable]
    public class DepartmentSearchInfo
    {
        public long RowNumber { get; set; }
        public string  DeptCD { get; set; }
        public string DeptNm { get; set; }

        /// <summary>
        /// Constructor by datarow
        /// </summary>
        /// <param name="dr"></param>
        public DepartmentSearchInfo(DbDataReader dr)
        {
            ISecurity sec = Security.Instance;
            this.RowNumber = (long)dr["RowNumber"];
            this.DeptCD = EditDataUtil.ToFixCodeShow((string)dr["DeptCD"], M_Department.MAX_DEPARTRMENT_CODE_SHOW);
            this.DeptNm = (string)dr["DeptNm"];
        }

        /// <summary>
        /// Constructor empty
        /// </summary>
        public DepartmentSearchInfo()
        {
            this.RowNumber = 0;
            this.DeptCD = string.Empty;
            this.DeptNm = string.Empty;
        }
    }
}
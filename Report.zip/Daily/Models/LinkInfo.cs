﻿using System;
using System.Data.Common;

namespace DailyReport.Models
{
    /// <summary>
    /// Class Config Information Model
    /// VN-Nho
    /// </summary>
    [Serializable]
    public class LinkInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public string UserCD { get; set; }
        public string UserName { get; set; }
        public string TypeName { get; set;}
        public string RouteCD { get; set; }

        /// <summary>
        /// Constructor class SettingInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public LinkInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            this.UserCD = Utilities.EditDataUtil.ToFixCodeShow((string)dr["UserCD"], M_User.MAX_USER_CODE_SHOW) ;
            this.UserName = (string)dr["UserName"];
            this.TypeName = (string)dr["TypeName"];
            this.RouteCD = (string)dr["RouteCD"];
        }

        /// <summary>
        /// Constructor class SettingInfo
        /// </summary>
        public LinkInfo()
        {
            this.RowNumber = 0;
            this.ID = -1;
            this.UserCD = string.Empty;
            this.UserName = string.Empty;
            this.TypeName = string.Empty;
            this.RouteCD = string.Empty;
        }
    }
}

﻿using System;
using System.Data.Common;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Models
{
    /// <summary>
    /// Class HolidayInfo Model
    /// </summary>
    [Serializable]
    public class HolidayInfo
    {
        public long RowNumber { get; set; }
        public int ID { get; set; }
        public DateTime? Date { get; set; }
        public string Name1 { get; set; }
        public string Name2 { get; set; }
        public string Color { get; set; }

        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        /// <param name="dr">DbDataReader</param>
        public HolidayInfo(DbDataReader dr)
        {
            this.RowNumber = (long)dr["RowNumber"];
            this.ID = int.Parse(dr["ID"].ToString());
            if (dr["Date"] != DBNull.Value)
            {
                this.Date = (DateTime)dr["Date"];
            }
            else
            {
                this.Date = null;
            }
            this.Name1 = (string)dr["Name1"];
            this.Name2 = (string)dr["Name2"];
            this.Color = (string)dr["Color"];
        }


        /// <summary>
        /// Constructor class UserInfo
        /// </summary>
        public HolidayInfo()
        {
            this.RowNumber = 0;
            this.ID = -1;
            this.Date = DateTime.Now;
            this.Name1 = string.Empty;
            this.Name2 = string.Empty;
            this.Color = string.Empty;
        }
    }

    [Serializable]
    public class DayInfo
    {
        public string DayName { get; set; }
        public string Color { get; set; }

        public DayInfo(DbDataReader dr)
        {
            this.DayName = dr["Name"].ToString();
            this.Color = dr["Color"].ToString();
        }

        public DayInfo()
        {
            this.DayName = string.Empty;
            this.Color = string.Empty;
        }
    }
}

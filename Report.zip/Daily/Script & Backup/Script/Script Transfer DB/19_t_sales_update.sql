
--Update 1:------------------------------------------------Update StatusFlag------------------------------------------------------------------------
--KDDI--------------OMS
--	0				5	Lost
--	1				0	

UPDATE [dbo].[T_Sales_H]
SET [StatusFlag] = 5
WHERE [StatusFlag] = 0

UPDATE [dbo].[T_Sales_H]
SET [StatusFlag] = 0
WHERE [StatusFlag] = 1


--Update 2:-------------------------------------------Update TOTAL, VAT, GRANDTOTAL-----------------------------------------------------------------

DECLARE @ID INT
DECLARE @SUM_Total DECIMAL
DECLARE @SUM_Vat DECIMAL
DECLARE @GRAND_Total DECIMAL

DECLARE cTotal CURSOR FOR	
SELECT 
	QD.[HID]
	, SUM(QD.[Total]) SUM_Total
	, SUM(QD.[Vat]) SUM_Vat
	, (SUM(QD.[Total]) +  SUM(QD.[Vat])) AS GRAND_Total
FROM dbo.T_Sales_D_Sell QD
GROUP BY QD.[HID]

OPEN cTotal
FETCH NEXT FROM cTotal INTO 
@ID, @SUM_Total, @SUM_Vat, @GRAND_Total

WHILE @@FETCH_STATUS = 0
BEGIN
	UPDATE dbo.T_Sales_H
		SET   [Total] = @SUM_Total
			, [Vat]   = @SUM_Vat
			, [GrandTotal]   = @GRAND_Total
	WHERE [ID] = @ID
						
	FETCH NEXT FROM cTotal INTO 
	@ID, @SUM_Total, @SUM_Vat, @GRAND_Total
END
CLOSE cTotal;
DEALLOCATE cTotal;
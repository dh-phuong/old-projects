-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
DECLARE @IN_CurrencyID_OLD TINYINT = 1 -- USD
DECLARE @IN_CurrencyID_NEW INT = 11


INSERT INTO [dbo].[T_Quote_D_Sell]
           ([HID]
           ,[No]
           ,[HeadLineFlag]
           ,[HeadLine]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])           
SELECT 
			([ID] + 10)
           ,[GridNo] + 1
           ,[HeadlineFlag]
           ,[Headline]
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END -- out of range
           , LeadTime
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID             
           , UnitPriceUSD
           , [Quantity]
           , VATUSD
           , [VATRatio]
           , VATFlag
           , SubTotalUSD
FROM [KDDI_DEV].dbo.T_Quote_M_Sell TMS
WHERE TMS.CurrencyFlag = @IN_CurrencyID_OLD 

-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
SET @IN_CurrencyID_OLD = 2 -- VND
SET @IN_CurrencyID_NEW = 1

INSERT INTO [dbo].[T_Quote_D_Sell]
           ([HID]
           ,[No]
           ,[HeadLineFlag]
           ,[HeadLine]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])           
SELECT 
			([ID] + 10)
           ,[GridNo] + 1
           ,[HeadlineFlag]
           ,[Headline]
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END -- out of range
           , LeadTime
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID             
           , UnitPriceVND
           , [Quantity]
           , VATVND
           , [VATRatio]
           , VATFlag
           , SubTotalVND
FROM [KDDI_DEV].dbo.T_Quote_M_Sell TMS
WHERE TMS.CurrencyFlag = @IN_CurrencyID_OLD 

/*
-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
SET @IN_CurrencyID_OLD = 3 -- JPY
SET @IN_CurrencyID_NEW = 13

INSERT INTO [dbo].[T_Quote_D_Sell]
           ([HID]
           ,[No]
           ,[HeadLineFlag]
           ,[HeadLine]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])           
SELECT 
			([ID] + 10)
           ,[GridNo] + 1
           ,[HeadlineFlag]
           ,[Headline]
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END -- out of range
           , LeadTime
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID             
           , UnitPriceVND
           , [Quantity]
           , VATVND
           , [VATRatio]
           , VATFlag
           , SubTotalVND
FROM [KDDI_DEV].dbo.T_Quote_M_Sell TMS
WHERE TMS.CurrencyFlag = @IN_CurrencyID_OLD 
*/
--*****************************--
--Create by: ISV-HUNG
--Create date: 2015/01/14
--*****************************--
INSERT INTO [dbo].[T_Sales_C]
           (
           [HID]
           ,[Conditions]
           )
SELECT 
	 (H.ID + 10)
	,ISNULL(C.[Conditions], '')
FROM [KDDI_DEV].dbo.T_Accept_H H
LEFT JOIN  [KDDI_DEV].dbo.T_Accept_C C ON C.ID = H.ID
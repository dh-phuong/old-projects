INSERT INTO [dbo].[T_Purchase_C]
           ([HID]
           ,[Conditions])
SELECT 
	 (H.ID + 10)
	,ISNULL(C.[Conditions], '')
FROM [KDDI_DEV].dbo.T_Purchase_H H
LEFT JOIN  [KDDI_DEV].dbo.T_Purchase_C C ON C.ID = H.ID           



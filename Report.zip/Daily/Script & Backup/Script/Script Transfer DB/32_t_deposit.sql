INSERT INTO [dbo].[T_Deposit]
           ([BillingID]
           ,[No]
           ,[DepositDate]
           ,[Amount]
           ,[PaymentMethod]
           )
SELECT  
		 (TBH.ID)
		, 1
		, (SELECT DepositDate FROM [KDDI_DEV].dbo.T_Invoice_H TIH WHERE TIH.InvoiceNo = TBH.BillingNo COLLATE Japanese_CS_AS )
		, TBH.GrandTotal
		, TBH.PaymentMethod
FROM dbo.T_Billing_H TBH
WHERE TBH.FinishFlag = 1

SET IDENTITY_INSERT [dbo].[M_Customer] ON 
INSERT INTO dbo.M_Customer
	(
		  ID
		, CustomerCD
		, CustomerName1
		, CustomerName2
		, CustomerAddress1
		, CustomerAddress2
		, CustomerAddress3
		, Tel
		, FAX
		, EmailAddress
		, ContactPerson
		, ContactTel
		, TAXCode
		, CustomerBank
		, AccountCode
		, CreateDate
		, CreateUID
		, UpdateDate
		, UpdateUID
	)
	SELECT 
	  (ID + 10)
	, CustomerCD
	, CustomerName1
	, CustomerName2
	, CustomerAddress1
	, CustomerAddress2
	, CustomerAddress3
	, Tel
	, FAX
	, EmailAddress
	, ContactPerson
	, ContactTel
	, TAXCode
	, CustomerBank
	, AccountCode
	, CreateDate	
	, CreateUID  + 10
	, UpdateDate
	, UpdateUID  + 10
	
FROM [KDDI_DEV].dbo.M_Customer
WHERE CustomerCD <> ''

SET IDENTITY_INSERT [dbo].[M_Customer] OFF

--SELECT * FROM [KDDI_DEV].dbo.M_Customer
--SELECT * FROM [OMS_WEB].[dbo].[M_Customer]
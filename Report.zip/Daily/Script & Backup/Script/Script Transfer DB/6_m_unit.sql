
SET IDENTITY_INSERT [dbo].[M_Unit] ON 
INSERT INTO dbo.M_Unit
(
	  ID
	, UnitName
	, CreateDate
	, CreateUID
	, UpdateDate
	, UpdateUID
)
SELECT  
	  (ID + 10) ID
	, UnitName
	, CreateDate	
	, CreateUID  + 10
	, UpdateDate
	, UpdateUID  + 10	
FROM [KDDI_DEV].dbo.M_Unit
WHERE UnitName <> ''
SET IDENTITY_INSERT [dbo].[M_Unit] OFF 

/*
SELECT  
	  *
FROM [KDDI_DEV].dbo.M_Unit
*/
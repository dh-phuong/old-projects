--
-- COLLATION OF DB : CS_AS
--

DECLARE @OUT_ID INT
DECLARE @OUT_GroupCD VARCHAR(10)
DECLARE @OUT_GroupName NVARCHAR(50)


DECLARE @IN_CreateDate DATETIME = GETDATE()
DECLARE @IN_UID INT = 1
DECLARE @CONST_DEFAULT_FormName NVARCHAR(100) = ' '

DECLARE cGroup CURSOR FOR  
SELECT 
	  ID
	, GroupCD
	, GroupName
	
	
FROM [KDDI_DEV].dbo.M_GroupUser
--WHERE ID > 1

SET IDENTITY_INSERT [dbo].[M_GroupUser_H] ON 
OPEN cGroup
FETCH NEXT FROM cGroup INTO 
@OUT_ID, @OUT_GroupCD, @OUT_GroupName

WHILE @@FETCH_STATUS = 0
BEGIN

	DECLARE @HID INT;
	-- INSERT HEADER
	INSERT INTO [dbo].M_GroupUser_H
	(
		  ID
		, GroupCD
		, GroupName
		, CreateDate
		, CreateUID
		, UpdateDate
		, UpdateUID
	)
	VALUES
	(
		  @OUT_ID + 10
		, @OUT_GroupCD
		, @OUT_GroupName
		, @IN_CreateDate
		, @IN_UID
		, @IN_CreateDate
		, @IN_UID
	)
	SET @HID = @OUT_ID + 10;
	-- INSERT DETAIL
	DECLARE @i INT = 1;
	WHILE @i <= 18	
	BEGIN
		INSERT INTO [dbo].M_GroupUser_D		
		(
			  GroupID
			, FormID
			, FormName
			, AuthorityFlag1
			, AuthorityFlag2
			, AuthorityFlag3
			, AuthorityFlag4
			, AuthorityFlag5
			, AuthorityFlag6
			, AuthorityFlag7
			, AuthorityFlag8
			, AuthorityFlag9
			, AuthorityFlag10
		)
		VALUES
		(
			  @HID
			, @i
			, (SELECT FormName FROM [dbo].M_GroupUser_D	WHERE GroupID = 1 AND  FormID = @i )
			, 1
			, 1
			, 1
			, 1
			, 1
			, 1
			, 1
			, 1
			, 1
			, 1
		)
		
		SET @i = @i + 1;
	END
	--MOVE NEXT RECORD
	FETCH NEXT FROM cGroup INTO 
	  @OUT_ID, @OUT_GroupCD, @OUT_GroupName
END

CLOSE cGroup;
DEALLOCATE cGroup;
SET IDENTITY_INSERT [dbo].[M_GroupUser_H] OFF

--SELECT * FROM [KDDI_DEV].dbo.M_GroupUser
--SELECT * FROM [OMS_WEB].[dbo].[M_GroupUser_H]
--SELECT * FROM [OMS_WEB].[dbo].[M_GroupUser_D]
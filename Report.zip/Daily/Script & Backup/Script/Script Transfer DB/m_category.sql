
SET IDENTITY_INSERT [dbo].[M_Category] ON 
INSERT INTO dbo.M_Category
(
	  ID
	, CategoryCD
	, CategoryName
	, CreateDate
	, CreateUID
	, UpdateDate
	, UpdateUID
)
SELECT  
	  (ID + 10) ID
	, CategoryCD
	, CategoryName
	, CreateDate	
	, CreateUID  + 10
	, UpdateDate
	, UpdateUID  + 10
FROM [KDDI_DEV].dbo.M_Category
WHERE CategoryCD <> ''
SET IDENTITY_INSERT [dbo].[M_Category] OFF 

/*

SELECT  
	  *
FROM [KDDI_DEV].dbo.M_Category


SELECT  
	  *
FROM dbo.M_Category
*/
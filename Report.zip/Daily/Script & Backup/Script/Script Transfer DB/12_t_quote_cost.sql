-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
--DECLARE @IN_CurrencyID_SELL_OLD TINYINT = 1 -- RUN WITH ALL ID M_CURRENCY_H

DECLARE @IN_CurrencyID_COST_OLD TINYINT = 1 -- USD
DECLARE @IN_CurrencyID_COST_NEW INT = 11


INSERT INTO [dbo].[T_Quote_D_Cost]
           ([HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT 
			([ID] + 10)
           ,[GridNo] + 1 			
           ,[TabNo] + 1
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[PurchaseFlag]
           ,(SELECT MV.ID FROM dbo.M_Vendor MV WHERE  MV.VendorCD = TMC.VendorCD COLLATE Japanese_CS_AS) -- COLLATE Japanese_CS_AS
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_COST_NEW
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceUSD]
           ,[Quantity]
           ,[VATUSD]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalUSD]
FROM [KDDI_DEV].dbo.T_Quote_M_Cost TMC
WHERE TMC.CurrencyFlag = @IN_CurrencyID_COST_OLD 
--AND TMC.ID IN (SELECT ID FROM [KDDI_DEV].dbo.T_Quote_M_Sell WHERE CurrencyFlag = @IN_CurrencyID_SELL_OLD)

-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
--DECLARE @IN_CurrencyID_SELL_OLD TINYINT = 1 -- RUN WITH ALL ID M_CURRENCY_H

SET @IN_CurrencyID_COST_OLD = 2 -- VND
SET @IN_CurrencyID_COST_NEW = 1

INSERT INTO [dbo].[T_Quote_D_Cost]
           ([HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT 
			([ID] + 10)
           ,[GridNo] + 1 			
           ,[TabNo] + 1
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[PurchaseFlag]
           ,(SELECT MV.ID FROM dbo.M_Vendor MV WHERE  MV.VendorCD = TMC.VendorCD COLLATE Japanese_CS_AS) -- COLLATE Japanese_CS_AS
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_COST_NEW
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].dbo.T_Quote_M_Cost TMC
WHERE TMC.CurrencyFlag = @IN_CurrencyID_COST_OLD 
--AND TMC.ID IN (SELECT ID FROM [KDDI_DEV].dbo.T_Quote_M_Sell WHERE CurrencyFlag = @IN_CurrencyID_SELL_OLD)

-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
--DECLARE @IN_CurrencyID_SELL_OLD TINYINT = 1 -- RUN WITH ALL ID M_CURRENCY_H

/*
SET @IN_CurrencyID_COST_OLD = 3 -- JPY
SET @IN_CurrencyID_COST_NEW = 13

INSERT INTO [dbo].[T_Quote_D_Cost]
           ([HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])
SELECT 
			([ID] + 10)
           ,[GridNo] + 1 			
           ,[TabNo] + 1
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[PurchaseFlag]
           ,(SELECT MV.ID FROM dbo.M_Vendor MV WHERE  MV.VendorCD = TMC.VendorCD COLLATE Japanese_CS_AS)
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_COST_NEW
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].dbo.T_Quote_M_Cost TMC
WHERE TMC.CurrencyFlag = @IN_CurrencyID_COST_OLD 
--AND TMC.ID IN (SELECT ID FROM [KDDI_DEV].dbo.T_Quote_M_Sell WHERE CurrencyFlag = @IN_CurrencyID_SELL_OLD)
*/
-----------------------------------------------------------------------------------------------------
/*
TRUNCATE TABLE dbo.T_Quote_H
TRUNCATE TABLE dbo.T_Quote_D_Sell
TRUNCATE TABLE dbo.T_Quote_D_Cost
*/

/*
select COUNT(*) from dbo.T_Quote_D_Cost
select COUNT(*) from [KDDI_DEV].dbo.T_Quote_M_Cost
*/
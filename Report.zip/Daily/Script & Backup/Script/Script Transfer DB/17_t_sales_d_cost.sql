--*****************************--
--Create by: ISV-HUNG
--Create date: 2015/01/14
--*****************************--
-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
--DECLARE @IN_CurrencyID_Sell_OLD TINYINT = 1 -- RUN ALL ID M_CURRENCY

DECLARE @IN_CurrencyID_OLD TINYINT = 1 -- USD
DECLARE @IN_CurrencyID_NEW INT = 11

SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] ON
INSERT INTO [dbo].[T_Sales_D_Cost]
           (
           [InternalID]
           ,[HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatType]
           ,[VatRatio]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[SellNo]
           ,([TabNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[PurchaseFlag]
           ,(SELECT MV.[ID] FROM dbo.M_Vendor MV WHERE  MV.[VendorCD] = TMC.[VendorCD] COLLATE Japanese_CS_AS) --???[VendorID]
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_NEW --???[CurrencyID]
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceUSD] --???[UnitPrice]
           ,[Quantity]
           ,[VATUSD] --???[Vat]
           ,[VATFlag] --???[VatType]
           ,[VATRatio] --???[VatRatio]
           ,[SubTotalUSD] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Cost TMC
	WHERE	TMC.[CurrencyFlag] = @IN_CurrencyID_OLD
			--AND TMC.[ID] IN (SELECT TMS.[ID] FROM [KDDI_DEV].dbo.T_Accept_M_Sell TMS WHERE TMS.[CurrencyFlag] = @IN_CurrencyID_Sell_OLD )
			
SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] OFF


-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
--DECLARE @IN_CurrencyID_Sell_OLD TINYINT = 1 -- RUN ALL ID M_CURRENCY

SET @IN_CurrencyID_OLD = 2 -- VND
SET @IN_CurrencyID_NEW = 1

SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] ON
INSERT INTO [dbo].[T_Sales_D_Cost]
           (
           [InternalID]
           ,[HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatType]
           ,[VatRatio]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[SellNo]
           ,([TabNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[PurchaseFlag]
           ,(SELECT MV.[ID] FROM dbo.M_Vendor MV WHERE  MV.[VendorCD] = TMC.[VendorCD] COLLATE Japanese_CS_AS) --???[VendorID]
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_NEW --???[CurrencyID]
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceVND] --???[UnitPrice]
           ,[Quantity]
           ,[VATVND] --???[Vat]
           ,[VATFlag] --???[VatType]
           ,[VATRatio] --???[VatRatio]
           ,[SubTotalVND] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Cost TMC
	WHERE 
			TMC.[CurrencyFlag] = @IN_CurrencyID_OLD
			--AND TMC.[ID] IN (SELECT TMS.[ID] FROM [KDDI_DEV].dbo.T_Accept_M_Sell TMS WHERE TMS.[CurrencyFlag] = @IN_CurrencyID_Sell_OLD )
			
SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] OFF


/*
-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
--DECLARE @IN_CurrencyID_Sell_OLD TINYINT = 1 -- RUN ALL ID M_CURRENCY

SET @IN_CurrencyID_OLD = 3 -- JPY
SET @IN_CurrencyID_NEW = 13

SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] ON
INSERT INTO [dbo].[T_Sales_D_Cost]
           (
           [InternalID]
           ,[HID]
           ,[SellNo]
           ,[No]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[PurchaseFlag]
           ,[VendorID]
           ,[VendorCD]
           ,[VendorName]
           ,[CurrencyID]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatType]
           ,[VatRatio]
           ,[Total]
           )
	SELECT
		   ([InternalID] + 10) --???[InternalID]
		   ,([ID] + 10) --???[HID]
           ,([GridNo] + 1) --???[SellNo]
           ,([TabNo] + 1) --???[No]
           ,1 --???[ProductID]
           ,'999999' --???[ProductCD]
           ,[ItemName] --???[ProductName]
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END --???[Description]
           ,[PurchaseFlag]
           ,(SELECT MV.[ID] FROM dbo.M_Vendor MV WHERE  MV.[VendorCD] = TMC.[VendorCD] COLLATE Japanese_CS_AS) --???[VendorID]
           ,[VendorCD]
           ,[VendorName1]
           ,@IN_CurrencyID_NEW --???[CurrencyID]
           , CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END --???[UnitID]
           ,[UnitPriceVND] --???[UnitPrice]
           ,[Quantity]
           ,[VATVND] --???[Vat]
           ,[VATFlag] --???[VatType]
           ,[VATRatio] --???[VatRatio]
           ,[SubTotalVND] --???[Total]
	FROM
			[KDDI_DEV].dbo.T_Accept_M_Cost TMC
	WHERE 
			TMC.[CurrencyFlag] = @IN_CurrencyID_OLD
			--AND TMC.[ID] IN (SELECT TMS.[ID] FROM [KDDI_DEV].dbo.T_Accept_M_Sell TMS WHERE TMS.[CurrencyFlag] = @IN_CurrencyID_Sell_OLD )
			
SET IDENTITY_INSERT [dbo].[T_Sales_D_Cost] OFF
*/
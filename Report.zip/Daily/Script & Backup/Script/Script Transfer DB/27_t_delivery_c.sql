INSERT INTO [dbo].[T_Delivery_C]
           ([HID]
           ,[Conditions])
SELECT 
	 (H.ID + 10)
	,ISNULL(C.[Conditions], '')
FROM [KDDI_DEV].dbo.T_Shipping_H H
LEFT JOIN  [KDDI_DEV].dbo.T_Shipping_C C ON C.ID = H.ID
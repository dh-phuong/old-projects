
	
--INSERT DATA T_Payment
INSERT INTO [dbo].[T_Payment]
           (
            [PurchaseID]
           ,[No]
           ,[PaymentDate]
           ,[Amount]
           ,[PaymentMethod]
			)
    SELECT 
			ID
			,1
			,(SELECT TIH.[PaymentDate] FROM [KDDI_DEV].dbo.T_Purchase_H TIH WHERE TIH.[PurchaseNo] = TSM.[PurchaseNo] COLLATE Japanese_CS_AS)
			,GrandTotal
			,0
	FROM 
			[dbo].T_Purchase_H TSM
	WHERE 
			TSM.FinishFlag = 1 
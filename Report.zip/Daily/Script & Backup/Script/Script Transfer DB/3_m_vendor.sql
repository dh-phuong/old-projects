SET IDENTITY_INSERT [dbo].[M_Vendor] ON 
	INSERT INTO dbo.M_Vendor
		(
			  ID
			, VendorCD
			, VendorName1
			, VendorName2
			, VendorAddress1
			, VendorAddress2
			, VendorAddress3
			, Tel
			, FAX
			, EmailAddress
			, ContactPerson
			, ContactTel
			, TAXCode
			, VendorBank
			, AccountCode
			, CreateDate
			, CreateUID
			, UpdateDate
			, UpdateUID
		)
	SELECT 
		  ID + 10
		, VendorCD
		, VendorName1
		, VendorName2
		, VendorAddress1
		, VendorAddress2
		, VendorAddress3
		, Tel
		, FAX
		, EmailAddress
		, ContactPerson
		, ContactTel
		, TAXCode
		, VendorBank
		, AccountCode
		, CreateDate	
		, CreateUID  + 10	
		, UpdateDate
		, UpdateUID  + 10
	FROM [KDDI_DEV].dbo.M_Vendor
	WHERE VendorCD <> ''	
SET IDENTITY_INSERT [dbo].[M_Vendor] OFF

--SELECT * FROM [KDDI_DEV].dbo.M_Vendor
--SELECT * FROM [dbo].[M_Vendor]


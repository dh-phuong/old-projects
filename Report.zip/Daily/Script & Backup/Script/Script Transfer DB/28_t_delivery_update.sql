
-- UPDATE VAT, TOTAL, GRANDTOTAL
 
	DECLARE @ID INT
	DECLARE @SUM_Total DECIMAL
	DECLARE @SUM_Vat DECIMAL
	DECLARE @GRAND_Total DECIMAL
	
	DECLARE cTotal CURSOR FOR	
	SELECT 
		  DD.HID
		, SUM(DD.Total) SUM_Total
		, SUM(DD.Vat) SUM_Vat
		, (SUM(DD.Total) +  SUM(DD.Vat)) AS GRAND_Total
	FROM dbo.T_Delivery_D DD
	GROUP BY DD.HID
	
	OPEN cTotal
	FETCH NEXT FROM cTotal INTO 
	@ID, @SUM_Total, @SUM_Vat, @GRAND_Total
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		UPDATE dbo.T_Delivery_H
			SET   Total = @SUM_Total
				, Vat   = @SUM_Vat
				, GrandTotal   = @GRAND_Total
		WHERE ID = @ID
							
		FETCH NEXT FROM cTotal INTO 
		@ID, @SUM_Total, @SUM_Vat, @GRAND_Total
	END
	CLOSE cTotal;
	DEALLOCATE cTotal;
	
	
--UPDATE FINISH DATA
	UPDATE dbo.T_Delivery_D
		SET   DeliveryQuantity = Quantity
			, DeliveryDate = (SELECT DeliveredDate FROM [KDDI_DEV].[dbo].T_Shipping_H
							  WHERE ShippingNo  COLLATE Japanese_CS_AS IN (SELECT DeliveryNo FROM dbo.T_Delivery_H
												  WHERE ID = HID))
			
	WHERE HID IN 
	(
		SELECT ID
		FROM
		dbo.T_Delivery_H TDH
		WHERE TDH.DeliveryNo COLLATE Japanese_CS_AS IN 
		(
			SELECT ShippingNo
			FROM [KDDI_DEV].[dbo].T_Shipping_H TSM
			WHERE TSM.FinishFlag = 1 
		)
	)
	
	
	/*SELECT * 
	FROM dbo.T_Delivery_D 
	WHERE HID IN (69, 82)*/
--UPDATE FINISH DATA

UPDATE dbo.T_Purchase_D
		SET   DeliverQuantity = Quantity
			, DeliverDate = CASE WHEN DeliverDate = '1900-01-01'
			THEN (SELECT DeliveredDate FROM [KDDI_DEV].[dbo].T_Purchase_H
							  WHERE PurchaseNo  COLLATE Japanese_CS_AS IN (SELECT PurchaseNo FROM dbo.T_Purchase_H
												  WHERE ID = HID))
							ELSE
								DeliverDate
							END
			
	WHERE HID IN 
	(
		SELECT ID
		FROM
		dbo.T_Purchase_H TDH
		WHERE TDH.PurchaseNo COLLATE Japanese_CS_AS IN 
		(
			SELECT PurchaseNo
			FROM [KDDI_DEV].[dbo].T_Purchase_H TSM
			WHERE TSM.FinishFlag = 1 
		)
	)


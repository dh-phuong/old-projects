-----------------------------------OLD CURRENCY: 1:USD-----------------------------------------------------
DECLARE @IN_CurrencyID_OLD TINYINT = 1 -- USD

SET IDENTITY_INSERT [dbo].[T_Purchase_D] ON 
INSERT INTO [dbo].[T_Purchase_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesCostID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[DeliverQuantity]           
           ,[DeliverDate]
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])

SELECT 
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo] + 1
           ,CASE WHEN [AcceptCostID] > 0 THEN
				[AcceptCostID] + 10
			ELSE
				[AcceptCostID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[LeadTime]     
           ,[DeliverQuantity]           
           ,[DeliverDate]      
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceUSD]
           ,[Quantity]
           ,[VATUSD]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalUSD]
FROM [KDDI_DEV].[dbo].[T_Purchase_M] TD
WHERE TD.ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Purchase_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)

SET IDENTITY_INSERT [dbo].[T_Purchase_D] OFF     

-----------------------------------OLD CURRENCY: 2:VND-----------------------------------------------------
SET @IN_CurrencyID_OLD = 2 -- VND

SET IDENTITY_INSERT [dbo].[T_Purchase_D] ON 
INSERT INTO [dbo].[T_Purchase_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesCostID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[DeliverQuantity]           
           ,[DeliverDate]           
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])

SELECT 
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo] + 1
           ,CASE WHEN [AcceptCostID] > 0 THEN
				[AcceptCostID] + 10
			ELSE
				[AcceptCostID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[LeadTime]
           ,[DeliverQuantity]           
           ,[DeliverDate]           
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].[dbo].[T_Purchase_M] TD
WHERE TD.ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Purchase_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)

SET IDENTITY_INSERT [dbo].[T_Purchase_D] OFF     

/*
-----------------------------------OLD CURRENCY OTHER: 3:JPY-----------------------------------------------------
SET @IN_CurrencyID_OLD = 3 -- JPY

SET IDENTITY_INSERT [dbo].[T_Purchase_D] ON 
INSERT INTO [dbo].[T_Purchase_D]
           (
            [InternalID]
           ,[HID]
           ,[No]
           ,[SalesCostID]
           ,[ProductID]
           ,[ProductCD]
           ,[ProductName]
           ,[Description]
           ,[Remark]
           ,[DeliverQuantity]           
           ,[DeliverDate]           
           ,[UnitID]
           ,[UnitPrice]
           ,[Quantity]
           ,[Vat]
           ,[VatRatio]
           ,[VatType]
           ,[Total])

SELECT 
		    [InternalID] + 10
           ,[ID] + 10
           ,[GridNo] + 1
           ,CASE WHEN [AcceptCostID] > 0 THEN
				[AcceptCostID] + 10
			ELSE
				[AcceptCostID]
			END
           ,1
           ,'999999'
           ,ItemName
           ,CASE WHEN [Maker] = '' THEN [Description]
           ELSE 
				CASE WHEN [Description] = '' THEN [Maker]
				ELSE
					SUBSTRING(([Maker] + CHAR(13) + CHAR(10) + [Description] ),0,1500) 
				END
			END
           ,[LeadTime]
           ,[DeliverQuantity]           
           ,[DeliverDate]           
           ,CASE WHEN
			 [UnitID] < 0 THEN 1
			 ELSE ([UnitID] + 10) END as UnitID  
           ,[UnitPriceVND]
           ,[Quantity]
           ,[VATVND]
           ,[VATRatio]
           ,[VATFlag]
           ,[SubTotalVND]
FROM [KDDI_DEV].[dbo].[T_Purchase_M] TD
WHERE TD.ID IN (SELECT ID FROM [KDDI_DEV].[dbo].[T_Purchase_H] WHERE CurrencyFlag = @IN_CurrencyID_OLD)

SET IDENTITY_INSERT [dbo].[T_Purchase_D] OFF     
*/
/*

SELECT * FROM [KDDI_DEV].[dbo].[T_Purchase_M] TD
WHERE TD.ID IN(
SELECT ID FROM [KDDI_DEV].[dbo].[T_Purchase_H] WHERE CurrencyFlag = 3)

*/
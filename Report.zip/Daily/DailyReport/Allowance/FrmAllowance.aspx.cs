﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using DailyReport.Controls;

namespace DailyReport.Allowance
{
    public partial class FrmAllowance : FrmBaseDetail
    {
        #region Property

        public string FocusControlId
        {
            get;
            private set;
        }

        private ActionMode Action
        {
            get { return base.GetValueViewState<ActionMode>("ActionMode"); }
            set { this.ViewState["ActionMode"] = value; }
        }

        /// <summary>
        /// ChildRowCommandArgument
        /// </summary>
        private string ChildRowCommandArgument
        {
            get { return base.GetValueViewState<string>("ChildRowCommandArgument"); }
            set { this.ViewState["ChildRowCommandArgument"] = value; }
        }

        public int salaryID
        {
            get { return (int)ViewState["salaryID"]; }
            set { ViewState["salaryID"] = value; }
        }

        public string data
        {
            get { return (string)ViewState["data"]; }
            set { ViewState["data"] = value; }
        }

        #endregion

        #region Variable
        private enum ActionMode
        {
            /// <summary>
            /// None
            /// </summary>
            None = 0,
            /// <summary>
            /// RemoveChildRow
            /// </summary>
            RemoveChildRow = 1
        }
        #endregion

        #region Event


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.InitData();

                if (this.data == string.Empty)
                {
                    StaffAllowanceService allowanceSer = new StaffAllowanceService(new DB());
                    IList<M_Staff_Allowance> allowanceList = allowanceSer.GetBySalaryID(this.salaryID);

                    if (allowanceList.Count != 0)
                    {
                        this.ShowData(allowanceList);
                    }
                    else
                    {
                        IList<StaffAllowanceInfo> data = new List<StaffAllowanceInfo>();
                        AddEmptyRow_Allowance(1, ref data);
                        this.rptAllowance.DataSource = data;
                        this.rptAllowance.DataBind();
                    }

                }
                else
                {
                    LoadData();
                }

                this.ProcessMode(this.Mode);
            }
        }

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        protected void btnProcessData(object sender, EventArgs e)
        {
            #region CheckAction

            switch (this.Action)
            {

                case ActionMode.None:
                    IList<StaffAllowanceInfo> detailAllowance = null;
                    int allowanceNo;
                    break;

                #region DeleteRow
                case ActionMode.RemoveChildRow:
                    this.Action = ActionMode.None;
                    allowanceNo = Convert.ToInt32(this.ChildRowCommandArgument);

                    //Get Data
                    detailAllowance = this.GetDetailAllowanceData();

                    StaffAllowanceInfo removedAllowance = detailAllowance.Where(a => a.allowanceNo == allowanceNo).FirstOrDefault();
                    detailAllowance.Remove(removedAllowance);

                    if (detailAllowance.Count != 0)
                    {
                        int No = 1;
                        foreach (StaffAllowanceInfo allowance in detailAllowance)
                        {
                            allowance.allowanceNo = No++;
                        }
                    }

                    if (detailAllowance.Count == 0)
                    {
                        StaffAllowanceInfo allowanceInfo = new StaffAllowanceInfo();
                        detailAllowance.Add(allowanceInfo);
                    }

                    this.RefreshDetails_Allowance(detailAllowance);

                    //var lastOfCost = removedSell.CostList.LastOrDefault();
                    //this.FocusControlId = string.Format("{0}_txtCostProductCD_{1}", removedSell.No - 1, lastOfCost.No - 1);

                    return;
                #endregion
            }

            #endregion
        }

        protected void rptAllowance_ItemCommand(object source, RepeaterCommandEventArgs e)
        {
            if (e.CommandName == "cmdDelAllowance")
            {
                this.ChildRowCommandArgument = e.CommandArgument.ToString();

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
                this.Action = ActionMode.RemoveChildRow;
            }
        }

        /// <summary>
        /// Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            IList<StaffAllowanceInfo> data = new List<StaffAllowanceInfo>();

            AddEmptyRow_Allowance(1, ref data);
            this.rptAllowance.DataSource = data;
            this.rptAllowance.DataBind();
            this.FocusControlId = "ddlAllowancename_0";
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRowAllowance_Click(object sender, EventArgs e)
        {
            IList<StaffAllowanceInfo> list = this.GetDetailAllowanceData();
            StaffAllowanceInfo allowance = new StaffAllowanceInfo();

            allowance.allowanceNo = list.Count + 1;
            list.Add(allowance);
            this.rptAllowance.DataSource = list;
            this.rptAllowance.DataBind();
            this.FocusControlId = string.Format("ddlAllowancename_{0}", allowance.allowanceNo - 1);
        }

        /// <summary>
        /// Event Detail ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptAllowance_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                StaffAllowanceInfo dataItem = (StaffAllowanceInfo)e.Item.DataItem;
                DropDownList ddlAllowancename = (DropDownList)e.Item.FindControl("ddlAllowancename");
                INumberTextBox txtAllowance = (INumberTextBox)e.Item.FindControl("txtAllowance");

                this.InitCombobox(ddlAllowancename, M_Config_H.CONFIG_CD_ALLOWANCE, true);
                ddlAllowancename.SelectedValue = dataItem.AllowanceName.ToString();
                txtAllowance.Attributes.Add("onvaluechange", "calcTotal()");
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(IList<M_Staff_Allowance> allowance)
        {
            int dataNo = 1;
            List<StaffAllowanceInfo> allowanceData = new List<StaffAllowanceInfo>();

            for (int i = 0; i < allowance.Count; i++)
            {
                StaffAllowanceInfo temp = new StaffAllowanceInfo();

                temp.allowanceNo = dataNo;
                temp.AllowanceName = allowance[i].AllowanceName;
                temp.Allowance = allowance[i].Allowance;
                temp.Checked = allowance[i].AccountingFlag == 1 ? true : false;
                allowanceData.Add(temp);
                dataNo++;
            }

            this.RefreshDetails_Allowance(allowanceData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails_Allowance(IList<StaffAllowanceInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailAllowanceData();
            }
            this.rptAllowance.DataSource = dataSource;
            this.rptAllowance.DataBind();
        }

        private List<StaffAllowanceInfo> ConvertData(string data)
        {
            List<StaffAllowanceInfo> listData = new List<StaffAllowanceInfo>();
            string[] temp = new string[data.Split('_').Length];

            temp = data.Split('_');

            for (int i = 0; i < temp.Length - 1; i += 4)
            {
                StaffAllowanceInfo tempData = new StaffAllowanceInfo();
                tempData.allowanceNo = int.Parse(temp[i]);
                tempData.AllowanceName = int.Parse(temp[i + 1]);
                tempData.Allowance = decimal.Parse(temp[i + 2]);

                if (temp[i + 3] == "true")
                {
                    tempData.AccountingFlag = 1;
                    tempData.Checked = true;
                }
                else
                {
                    tempData.AccountingFlag = 0;
                    tempData.Checked = false;
                }
                listData.Add(tempData);
            }

            return listData;
        }

        private void LoadData()
        {
            List<StaffAllowanceInfo> allowanceData = new List<StaffAllowanceInfo>();
            allowanceData = this.ConvertData(this.data);
            this.RefreshDetails_Allowance(allowanceData);
        }

        /// <summary>
        /// Get Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        /// <returns>QuotationDetailInfo List</returns>
        private IList<StaffAllowanceInfo> GetDetailAllowanceData(bool includeDelete = true)
        {
            IList<StaffAllowanceInfo> ret = new List<StaffAllowanceInfo>();
            var allowanceNo = 1;
            foreach (RepeaterItem item in this.rptAllowance.Items)
            {
                if (!includeDelete)
                {
                    continue;
                    
                }

                StaffAllowanceInfo detail = this.GetDetailAllowanceRow(item);
                detail.allowanceNo = allowanceNo;
                //Reset [No]
                ////////////////////////////////////////////////                

                ret.Add(detail);
                ////////////////////////////////////////////////
                allowanceNo++;
            }

            return ret;
        }

        /// <summary>
        /// Get Row
        /// </summary>
        /// <param name="rptI"></param>
        /// <returns></returns>
        private StaffAllowanceInfo GetDetailAllowanceRow(RepeaterItem rptI)
        {
            StaffAllowanceInfo detail = new StaffAllowanceInfo();

            CheckBox chkAccounting = (CheckBox)rptI.FindControl("chkAccounting");
            detail.Checked = chkAccounting.Checked;

            DropDownList ddlAllowancename = (DropDownList)rptI.FindControl("ddlAllowancename");
            detail.AllowanceName = int.Parse(ddlAllowancename.SelectedValue);

            INumberTextBox txtAllowance = (INumberTextBox)rptI.FindControl("txtAllowance");
            detail.Allowance = txtAllowance.Value;

            return detail;
        }

        private void InitData()
        {
            //Set SalaryID
            if (Request.QueryString["salaryID"] != null)
            {
                this.salaryID = int.Parse(Request.QueryString["salaryID"]);
            }

            if (Request.QueryString["AllowanceCtrl"] != null)
            {
                this.OutAllowanceCtrl.Value = Request.QueryString["AllowanceCtrl"];
            }

            if (Request.QueryString["data"] != null)
            {
                this.data = Request.QueryString["data"];
            }

            if (Request.QueryString["dataCtrl"] != null)
            {
                this.OutDataCtrl.Value = Request.QueryString["dataCtrl"];
            }

            if (Request.QueryString["Mode"] != null)
            {
                this.Mode = (Mode)int.Parse(Request.QueryString["Mode"]);
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable = false;
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Copy:
                case Mode.Insert:
                case Mode.Update:
                    enable = false;
                    break;

                default:

                    base.DisabledLink(this.btnAddRowAllowance, !enable);
                    base.DisabledLink(this.btnClear, !enable);
                    base.DisabledLink(this.btnSubmit, !enable);
                    enable = true;
                    break;
            }

            //Lock control
            foreach (RepeaterItem item in this.rptAllowance.Items)
            {
                DropDownList ddlAllowancename = (DropDownList)item.FindControl("ddlAllowancename");
                ddlAllowancename.Enabled = !enable;

                ITextBox txtAllowance = (ITextBox)item.FindControl("txtAllowance");
                txtAllowance.Enabled = !enable;

                CheckBox chkAccounting = (CheckBox)item.FindControl("chkAccounting");
                chkAccounting.Enabled = !enable;
            }
        }

        private void AddEmptyRow_Allowance(int size, ref IList<StaffAllowanceInfo> dataSource)
        {
            //AllowanceInfo
            if (dataSource == null)
            {
                dataSource = new List<StaffAllowanceInfo>();
            }

            for (int i = 0; i < size; i++)
            {
                StaffAllowanceInfo salary = new StaffAllowanceInfo();
                dataSource.Add(salary);
            }
        }
        #endregion

        #region Web Methods
        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                     errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Calc Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalctxtAllowanceTotal(string[] totals)
        {
            try
            {
                decimal? sumTotal = null;

                if (totals.Any(s => !string.IsNullOrEmpty(s)))
                {
                    sumTotal = totals.Sum(s => string.IsNullOrEmpty(s) ? 0 : decimal.Parse(s));
                }
                
                System.Text.StringBuilder result = new System.Text.StringBuilder();

                result.Append("{");
                result.Append(string.Format("\"txtTotal\":\"{0}\"", sumTotal.HasValue ? sumTotal.GetValueOrDefault().ToString(string.Format("N{0}", 0)) : 0.ToString()));
                result.Append("}");

                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion
    }
}
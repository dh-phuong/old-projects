﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using System.Web.UI.HtmlControls;
using DailyReport.Utilities;
using System.IO;

namespace DailyReport.AttachedFile
{
    public partial class FrmAttachedFile : FrmBaseDetail
    {
        public string lblNo = string.Empty;

        //FormType
        // 0 : All
        // 1 : Salary
        // 2 : Dependent
        // 3 : Contract


        public bool DataChanged
        {
            get
            {
                return (bool)base.ViewState["DataChanged"];
            }
            private set { ViewState["DataChanged"] = value; }
        }

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnYesProcessData);

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownload_Click);

            //Init Max Length
            this.txtNo.MaxLength = T_Attached.ATTACHED_NO_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.DataChanged = false;

                // header grid
                this.HeaderGrid.SortField = "1";
                this.HeaderGrid.SortDirec = "1";

                //Set data into control
                this.InitData();

                this.Mode = Utilities.Mode.View;

                //Load data into grid
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Process the button Upload
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpload_Click(object sender, EventArgs e)
        {
            if (!CheckInput())
            {
                this.txtPath.Text = string.Empty;
                this.LoadDataGrid();
                return;
            }
            this.DataChanged = false;
            if (this.InsertData())
            {
                this.DataChanged = true;

                //Set Success
                this.Success = true;
            }
            this.txtPath.Value = string.Empty;
            this.LoadDataGrid();

            //Show question insert
            //base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPLOAD, Models.DefaultButton.Yes, true);
        }

        /// <summary>
        /// Process the button Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            var list = this.GetDetailList();
            if (list != null && list.Count != 0 && !list.Any(x => x.DelFlag))
            {
                this.SetMessage(this.rptAttachedFileList.ClientID, M_Message.MSG_SELECT_ROW_DATA);
                this.txtPath.Value = string.Empty;
                this.LoadDataGrid();
                return;
            }
            this.txtPath.Value = string.Empty;
            this.LoadDataGrid();

            //Show question delete row
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No);

        }

        /// <summary>
        /// Process the button Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.DataChanged = true;
            this.txtPath.Text = string.Empty;
            this.LoadDataGrid(true);
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownload_Click(object sender, EventArgs e)
        {
            //CustomerID
            var attached = new T_Attached();
            var setting = new M_Setting();
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                SettingService settingSer = new SettingService(db);
                attached = attachedService.GetByID(int.Parse(this.hdnFileName.Value));
                setting = settingSer.GetData();
            }

            if (attached != null)
            {
                var filetype = Path.GetExtension(attached.Path);
                var filename = attached.Path;

                var filePath = System.IO.Path.Combine(setting.AttachPath, attached.ID.ToString() + filetype);
                if (File.Exists(filePath))
                {
                    Response.ClearContent();
                    Response.Clear();
                    Response.ContentType = "text/plain";
                    Response.AddHeader("Content-Disposition", string.Format("attachment; filename = \"{0}\"", filename));
                    Response.TransmitFile(filePath);
                    Response.Flush();
                    Response.End();
                }
                else
                {
                    base.SetMessage("", M_Message.MSG_VALUE_NOT_EXIST, "File");
                    this.txtPath.Value = string.Empty;
                    this.LoadDataGrid();
                }
            }
            else
            {
                base.SetMessage("", M_Message.MSG_VALUE_NOT_EXIST, "File");
                this.txtPath.Value = string.Empty;
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnYesProcessData(object sender, EventArgs e)
        {
            this.DataChanged = false;
            if (this.DeleteData())
            {
                this.DataChanged = true;
                this.txtPath.Value = string.Empty;
                this.LoadDataGrid();

                //Set Success
                this.Success = true;
            }

        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid();
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid();
        }

        #endregion

        #region Method

        /// <summary>
        /// Authority
        /// </summary>
        /// <param name="auth"></param>
        private void SetAuthorityByForm(bool auth)
        {
            //Set authority
            base.DisabledLink(this.btnUpload, !auth);
            base.DisabledLink(this.btnDelete, !auth);
            base.DisabledLink(this.btnClear, !auth);
            this.fupath.Enabled = auth;
            if (!this.fupath.Enabled)
            {
                this.fupath.CssClass += " disabled";
            }
        }

        /// <summary>
        /// Set Search Conditions
        /// </summary>
        private void InitData()
        {
            //Set
            if (Request.QueryString["FormType"] != null)
            {
                this.hdFormType.Value = Request.QueryString["FormType"].ToString();
            }

            //Set
            if (Request.QueryString["IDFormType"] != null)
            {
                this.hdIDFormType.Value = Request.QueryString["IDFormType"].ToString();
            }

            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                //M_Staff staff = staffSer.GetByID(int.Parse(this.hdIDFormType.Value));
                this.txtNo.Text = EditDataUtil.ToFixCodeDB(this.hdIDFormType.Value, M_User.USER_CODE_MAX_LENGTH);
                this.hdlblNo.Value = "No.";
            }

            lbTitle.Text = "Staff Infomation Attached File";
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(bool isClear = false)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);

                IList<AttachedInfo> listAttached = attachedService.GetListByCond(this.hdIDFormType.Value, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                if (listAttached != null && listAttached.Count != 0)
                {
                    // header
                    this.HeaderGrid.TotalRow = 1;
                    this.HeaderGrid.AddColumms(new string[] { "#", "", "No", "Path" });
                }
                if (!isClear)
                {
                    var lstAttached = this.GetDetailList();
                    var lstDel = lstAttached.Where(x => x.DelFlag);
                    if (lstDel != null)
                    {
                        foreach (var item in lstDel)
                        {
                            var attached = listAttached.Where(x => x.ID == item.ID).SingleOrDefault();
                            if (attached != null)
                            {
                                attached.DelFlag = true;
                            }
                        }
                    }
                }
                this.rptAttachedFileList.DataSource = listAttached;
                this.rptAttachedFileList.DataBind();
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                this.hdPath.Value = Path.GetFileName(this.fupath.FileName);
                AttachedInfo attached = new AttachedInfo();
                attached.No = this.txtNo.Value;
                attached.Path = this.hdPath.Value;
                attached.CreateUID = this.LoginInfo.User.ID;

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    AttachedService attachedSer = new AttachedService(db);
                    SettingService settingSer = new SettingService(db);
                    var setting = new M_Setting();
                    setting = settingSer.GetData();

                    //Insert customer
                    attachedSer.Insert(attached);
                    var newId = db.GetIdentityId<T_Attached>();
                    var filetype = Path.GetExtension(attached.Path);
                    this.fupath.PostedFile.SaveAs(System.IO.Path.Combine(setting.AttachPath, newId.ToString() + filetype));

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Upload");
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                //Get new list from screen
                var listAttachedInfo = this.GetDetailList();
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    if (listAttachedInfo != null)
                    {
                        AttachedService attachedService = new AttachedService(db);
                        SettingService settingSer = new SettingService(db);
                        var setting = new M_Setting();
                        setting = settingSer.GetData();

                        //Remove row
                        foreach (var item in listAttachedInfo)
                        {
                            if (item.DelFlag)
                            {
                                var filetype = Path.GetExtension(item.Path);
                                File.Delete(System.IO.Path.Combine(setting.AttachPath, item.ID.ToString() + filetype));
                                attachedService.Delete(item.ID);
                            }
                        }
                        db.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
            }

            return true;
        }

        /// <summary>
        /// Get detail list from screen
        /// </summary>
        /// <returns>list AttachedInfo</returns>
        private IList<AttachedInfo> GetDetailList()
        {
            var listAttachedInfo = new List<AttachedInfo>();
            foreach (RepeaterItem item in this.rptAttachedFileList.Items)
            {
                HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");
                HiddenField no = (HiddenField)item.FindControl("hdnNo");
                HiddenField path = (HiddenField)item.FindControl("hdnFile");
                HiddenField id = (HiddenField)item.FindControl("hdnID");

                AttachedInfo addItem = new AttachedInfo();

                //Delete flag
                if (chkDelFlg != null)
                {
                    addItem.DelFlag = (chkDelFlg.Checked) ? true : false;
                }
                addItem.ID = int.Parse(id.Value);
                addItem.No = no.Value;
                addItem.Path = path.Value;
                addItem.CreateUID = this.LoginInfo.User.ID;
                listAttachedInfo.Add(addItem);
            }

            return listAttachedInfo;
        }

        /// <summary>
        /// Check Disable Button
        /// </summary>
        /// <returns></returns>
        public bool IsDisableButton()
        {
            return this.rptAttachedFileList.Items == null || this.rptAttachedFileList.Items.Count == 0;
        }

        /// <summary>
        /// File Exists
        /// </summary>
        /// <param name="fileLenght">fileLenght</param>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (!this.fupath.HasFile)
            {
                this.SetMessage(this.fupath.ClientID, M_Message.MSG_SELECT_FILE_UPLOAD);
                return false;
            }
            else
            {
                var fileSizeConf = string.Empty;
                IList<M_Config_D> lstConf = new List<M_Config_D>();
                List<string> extens = new List<string>();
                var exten = string.Empty;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    Config_HService confSer = new Config_HService(db);
                    Config_DService confDSer = new Config_DService(db);
                    fileSizeConf = confSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_UPLOAD_FILE);
                    lstConf = confDSer.GetListByConfigCd(M_Config_H.CONFIG_FILE_EXTENSION_TYPE);
                }
                foreach (var item in lstConf)
                {
                    var enterList = item.Value3.Split(';');
                    for (int i = 0; i < enterList.Length; i++)
                    {
                        var temp = enterList[i];
                        extens.Add(temp);
                        var fileExten = string.Empty;
                        if (i == enterList.Length - 1 && lstConf.IndexOf(item) == lstConf.Count - 1)
                            fileExten = temp;
                        else
                            fileExten = temp + ",";
                        exten += fileExten;
                    }
                }
                var filetype = Path.GetExtension(this.fupath.FileName);
                if (!extens.Any(x => x.Equals(filetype)))
                {
                    this.SetMessage(this.fupath.ClientID, M_Message.MSG_CODE_FILE_EXTENSION, exten);
                    return false;
                }
                else
                {
                    var fSize = int.Parse(fileSizeConf) * 1024 * 1024;
                    if (this.fupath.PostedFile.ContentLength > fSize)
                    {
                        this.SetMessage(this.fupath.ClientID, M_Message.MSG_SIZE_FILE_UPLOAD_LESS_THAN_EQUAL, "File", fileSizeConf + " " + "MB");
                        return false;
                    }
                }
            }

            return true;
        }

        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using System.Linq;
using System.Globalization;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.Controls;
using System.Web.Services;

namespace DailyReport.Work
{
    /// <summary>
    /// FrmDailyDetail
    /// ISV-TRAM 2015/03/02
    /// </summary>
    public partial class FrmDailyMain : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Daily/FrmDailyMainList.aspx";
        #endregion

        #region Property
        /// <summary>
        /// Get or Set work id
        /// </summary>
        private int WorkID
        {
            get { return (int)ViewState["WorkID"]; }
            set { ViewState["WorkID"] = value; }
        }

        /// <summary>
        /// Get or set DailyID
        /// </summary>
        private int UserID
        {
            get { return (int)ViewState["UserID"]; }
            set { ViewState["UserID"] = value; }
        }

        /// <summary>
        /// Get or set DailyID
        /// </summary>
        private int StaffID
        {
            get { return (int)ViewState["_StaffID"]; }
            set { ViewState["_StaffID"] = value; }
        }

        /// <summary>
        /// Get or set DailyID
        /// </summary>
        private DateTime WorkDate
        {
            get { return (DateTime)ViewState["_WorkDate"]; }
            set { ViewState["_WorkDate"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        private DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Outing row count
        /// </summary>
        public int OutingRowCount
        {
            get { return (int)ViewState["OutingRowCount"]; }
            set { ViewState["OutingRowCount"] = value; }
        }

        /// <summary>
        /// Outing row count
        /// </summary>
        public bool PreCalWorkTime
        {
            get { return (bool)ViewState["PreCalWorkTime"]; }
            set { ViewState["PreCalWorkTime"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Daily";
            base.FormSubTitle = "Main";


            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Daily);
            if (!this._authority.IsDailyView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            this.PreCalWorkTime = false;
            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];
                    this.StaffID = int.Parse(PreviousPageViewState["_StaffID"].ToString());
                    this.WorkDate = (DateTime)PreviousPageViewState["_WorkDate"];
                    this.InitData();

                    T_Work data = this.GetDataByKey(this.UserID, this.WorkDate);

                    if (data != null)
                    {
                        this.ShowData(data);
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        this.ProcessMode(Mode.Insert);
                        this.PreCalWorkTime = true;
                    }
                }
                else
                {
                    //Set mode
                    base.RedirectUrl(URL_LIST);
                }
            }
            else
            {
                ReLoadDataForGrid();
            }
        }

        /// <summary>
        /// Performance shift changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmdPerformShift_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            this.ShiftPerformDataChanged();
            this.PreCalWorkTime = true;
        }

        /// <summary>
        /// Add row outing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOutAddRow_Click(object sender, EventArgs e)
        {
            IList<DailyOutingInfo> lstOuting = this.GetOutingData();
            lstOuting.Add(new DailyOutingInfo());
            this.rptOuting.DataSource = lstOuting;
            this.rptOuting.DataBind();
            this.OutingRowCount = lstOuting.Count + 1;
            this.PreCalWorkTime = true;
        }

        /// <summary>
        /// Del row outing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnOutDelRow_Click(object sender, EventArgs e)
        {
            IList<DailyOutingInfo> lstOuting = this.GetOutingData(true);
            if (lstOuting.Count == 0)
            {
                lstOuting.Add(new DailyOutingInfo());
            }
            this.rptOuting.DataSource = lstOuting;
            this.rptOuting.DataBind();
            this.OutingRowCount = lstOuting.Count + 1;
            this.PreCalWorkTime = true;
        }

        /// <summary>
        /// Copy from prev date
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopyFromDate_Click(object sender, EventArgs e)
        {
            //Check input
            if (this.dtCopyDate.Value == null)
            {
                this.SetMessage(this.dtCopyDate.ID, M_Message.MSG_REQUIRE, "Date");
                return;
            }

            T_Work work = this.GetDataByKey(this.UserID, this.dtCopyDate.Value.Value);
            if (work != null)
            {
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                IList<DailyWorkInfo> lstWorkInfo;
                using (DB db = new DB())
                {
                    WorkStepService workStepSer = new WorkStepService(db);
                    lstWorkInfo = workStepSer.GetListWorkByWorkID(work.ID);
                }

                this.rptDailyWorkList.DataSource = lstWorkInfo;
                this.rptDailyWorkList.DataBind();

            }
            else
            {
                IList<DailyWorkInfo> lstWorkInfo = new List<DailyWorkInfo>();
                lstWorkInfo.Add(new DailyWorkInfo());
                this.rptDailyWorkList.DataSource = lstWorkInfo;
                this.rptDailyWorkList.DataBind();
            }
        }

        /// <summary>
        /// Add row outing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWorkAddRow_Click(object sender, EventArgs e)
        {
            IList<DailyWorkInfo> lstWork = this.GetWorkData();
            lstWork.Add(new DailyWorkInfo());
            this.rptDailyWorkList.DataSource = lstWork;
            this.rptDailyWorkList.DataBind();
        }

        /// <summary>
        /// Del row outing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnWorkDelRow_Click(object sender, EventArgs e)
        {
            IList<DailyWorkInfo> lstWork = this.GetWorkData(true);
            if (lstWork.Count == 0)
            {
                lstWork.Add(new DailyWorkInfo());
            }
            this.rptDailyWorkList.DataSource = lstWork;
            this.rptDailyWorkList.DataBind();
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Work data = this.GetDataByKey(this.UserID, this.WorkDate);

            //Check data
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work data = this.GetDataByKey(this.UserID, this.WorkDate);

            if (!this.Mode.Equals(Mode.View) && !this.Mode.Equals(Mode.Insert))
            {
                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Work data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetDataByKey(this.UserID, this.WorkDate);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete vendor
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;
                case Utilities.Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetDataByKey(this.UserID, this.WorkDate);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get vendor
            T_Work data = this.GetDataByKey(this.UserID, this.WorkDate);
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// GetOutingData
        /// </summary>
        /// <param name="delRow"></param>
        /// <returns>IList<DailyOutingInfo></returns>
        private IList<DailyOutingInfo> GetOutingData(bool delRow = false)
        {
            IList<DailyOutingInfo> ret = new List<DailyOutingInfo>();

            foreach (RepeaterItem item in this.rptOuting.Items)
            {
                CheckBox chkOutDel = (CheckBox)item.FindControl("chkOutDel");
                IDateTextBox dtStartOutTime = (IDateTextBox)item.FindControl("dtStartOutTime");
                IDateTextBox dtEndOutTime = (IDateTextBox)item.FindControl("dtEndOutTime");

                if (delRow && chkOutDel.Checked)
                {
                    continue;
                }
                DailyOutingInfo itemData = new DailyOutingInfo();
                itemData.Checked = chkOutDel.Checked;
                itemData.StartOutTime = dtStartOutTime.Value;
                itemData.EndOutTime = dtEndOutTime.Value;
                ret.Add(itemData);
            }

            return ret;
        }

        /// <summary>
        /// GetWorkData
        /// </summary>
        /// <param name="delRow"></param>
        /// <returns>IList<DailyWorkInfo></returns>
        private IList<DailyWorkInfo> GetWorkData(bool delRow = false)
        {
            IList<DailyWorkInfo> ret = new List<DailyWorkInfo>();

            foreach (RepeaterItem item in this.rptDailyWorkList.Items)
            {
                CheckBox chkWorkDel = (CheckBox)item.FindControl("chkWorkDel");
                ITextBox txtWorkName = (ITextBox)item.FindControl("txtWorkName");
                IDateTextBox dtWorkTime = (IDateTextBox)item.FindControl("dtWorkTime");
                ITextBox txtWorkNote = (ITextBox)item.FindControl("txtWorkNote");

                if (delRow && chkWorkDel.Checked)
                {
                    continue;
                }
                DailyWorkInfo itemData = new DailyWorkInfo();
                itemData.Checked = chkWorkDel.Checked;
                itemData.WorkName = txtWorkName.Value;
                itemData.WorkTime = dtWorkTime.Value;
                itemData.WorkNote = txtWorkNote.Value;
                ret.Add(itemData);
            }

            return ret;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            M_StaffInfo staff = new M_StaffInfo();
            WorkTotalOTInfo totalOT = new WorkTotalOTInfo();
            M_Work_Shift wsModel = new M_Work_Shift();
            IList<DropDownModel> lstShiftData = new List<DropDownModel>();

            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                staff = staffSer.GetStaffInfoByStaffID(this.StaffID);

                WorkOTService otSer = new WorkOTService(db);
                totalOT = otSer.GetTotalOverTime(this.WorkDate, this.WorkDate, staff.UserID);

                WorkShiftService wsSer = new WorkShiftService(db);
                wsModel = wsSer.GetByDate(this.WorkDate);

                lstShiftData = wsSer.GetDataForDropDown((int)ShiftType.Attendance);
            }

            this.UserID = staff.UserID;
            this.txtStaffName.Value = staff.StaffName;
            this.dtDate.Value = this.WorkDate;
            this.dtCopyDate.Value = this.WorkDate.AddDays(-1);

            this.txtApprEarly.Value = EditDataUtil.FixTimeShow(totalOT.EarlyHour, totalOT.EarlyMinute, true);
            this.txtApprNormal1.Value = EditDataUtil.FixTimeShow(totalOT.Normal1Hour, totalOT.Normal1Minute, true);
            this.txtApprNormal2.Value = EditDataUtil.FixTimeShow(totalOT.Normal2Hour, totalOT.Normal2Minute, true);
            this.txtApprLateNight.Value = EditDataUtil.FixTimeShow(totalOT.LateHour, totalOT.LateMinute, true);
            this.txtApprHoliday1.Value = EditDataUtil.FixTimeShow(totalOT.Holiday1Hour, totalOT.Holiday1Minute, true);
            this.txtApprHoliday2.Value = EditDataUtil.FixTimeShow(totalOT.Holiday2Hour, totalOT.Holiday2Minute, true);

            this.txtPlanShiftName.Value = "";
            this.txtPlanStartTime.Value = "";
            this.txtPlanEndTime.Value = "";

            if (wsModel != null)
            {
                this.txtPlanShiftName.Value = wsModel.ShiftName;

                if (wsModel.StartHour != null)
                {
                    this.txtPlanStartTime.Value = string.Format("{0:00}:{1:00}", wsModel.StartHour, wsModel.StartMinute);
                    this.txtPlanEndTime.Value = string.Format("{0:00}:{1:00}", wsModel.EndHour, wsModel.EndMinute);
                }
            }

            this.cmdPerformShift.DataSource = lstShiftData;
            this.cmdPerformShift.DataValueField = "Value";
            this.cmdPerformShift.DataTextField = "DisplayName";
            this.cmdPerformShift.DataBind();
            this.cmdPerformShift.SelectedValue = wsModel.ID.ToString();

            this.ShiftPerformDataChanged();

            IList<DailyOutingInfo> lstOuting = new List<DailyOutingInfo>();
            lstOuting.Add(new DailyOutingInfo());
            this.rptOuting.DataSource = lstOuting;
            this.rptOuting.DataBind();
            this.OutingRowCount = lstOuting.Count + 1;

            IList<DailyWorkInfo> lstWork = new List<DailyWorkInfo>();
            lstWork.Add(new DailyWorkInfo());
            this.rptDailyWorkList.DataSource = lstWork;
            this.rptDailyWorkList.DataBind();
        }

        /// <summary>
        /// Shift performance data changed process
        /// </summary>
        private void ShiftPerformDataChanged()
        {
            M_Work_Shift wsModel = new M_Work_Shift();
            using (DB db = new DB())
            {
                WorkShiftService wsSer = new WorkShiftService(db);
                wsModel = wsSer.GetByID(int.Parse(this.cmdPerformShift.SelectedValue));
            }

            if (wsModel.StartHour != null)
            {
                this.dtStartWorkTime.Value = new DateTime(1, 1, 1).AddHours((int)wsModel.StartHour).AddMinutes((int)wsModel.StartMinute);
                this.dtEndWorkTime.Value = new DateTime(1, 1, 1).AddHours((int)wsModel.EndHour).AddMinutes((int)wsModel.EndMinute);
            }
            else
            {
                this.dtStartWorkTime.Value = null;
                this.dtEndWorkTime.Value = null;
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            if (this.LoginInfo.User.ID != this.UserID)
            {
                mode = Mode.View;
            }
            //Set Model
            this.Mode = mode;

            bool enable = false;

            //Check model
            switch (mode)
            {

                case Mode.Insert:
                case Mode.Update:
                    enable = true;
                    break;

                default:

                    enable = false;
                    break;
            }

            this.cmdPerformShift.Enabled = enable;
            this.dtStartWorkTime.SetReadOnly(!enable);
            this.dtEndWorkTime.SetReadOnly(!enable);

            this.btnOutAddRow.Enabled = enable;
            this.btnOutDelRow.Enabled = enable;

            foreach (RepeaterItem item in this.rptOuting.Items)
            {
                CheckBox chkOutDel = (CheckBox)item.FindControl("chkOutDel");
                IDateTextBox dtStartOutTime = (IDateTextBox)item.FindControl("dtStartOutTime");
                IDateTextBox dtEndOutTime = (IDateTextBox)item.FindControl("dtEndOutTime");

                chkOutDel.Enabled = enable;
                dtStartOutTime.SetReadOnly(!enable);
                dtEndOutTime.SetReadOnly(!enable);
            }

            this.dtCopyDate.SetReadOnly(!enable);
            this.btnCopyFromDate.Enabled = enable;
            this.btnWorkAddRow.Enabled = enable;
            this.btnOutDelRow.Enabled = enable;

            foreach (RepeaterItem item in this.rptDailyWorkList.Items)
            {
                CheckBox chkWorkDel = (CheckBox)item.FindControl("chkWorkDel");
                ITextBox txtWorkName = (ITextBox)item.FindControl("txtWorkName");
                IDateTextBox dtWorkTime = (IDateTextBox)item.FindControl("dtWorkTime");
                ITextBox txtWorkNote = (ITextBox)item.FindControl("txtWorkNote");

                chkWorkDel.Enabled = enable;
                txtWorkName.SetReadOnly(!enable);
                dtWorkTime.SetReadOnly(!enable);
                txtWorkNote.SetReadOnly(!enable);
            }

            this.txtNote.SetReadOnly(!enable);

            this.dtDate.SetReadOnly(true);
            this.txtStaffName.SetReadOnly(true);

            //Plan work
            this.txtPlanShiftName.SetReadOnly(true);
            this.txtPlanStartTime.SetReadOnly(true);
            this.txtPlanEndTime.SetReadOnly(true);

            //Working hour
            this.dtAtWork.SetReadOnly(true);
            this.dtLate.SetReadOnly(true);
            this.dtLeaveEarly.SetReadOnly(true);
            this.dtOuting.SetReadOnly(true);

            //Approve OT
            this.txtApprEarly.SetReadOnly(true);
            this.txtApprNormal1.SetReadOnly(true);
            this.txtApprNormal2.SetReadOnly(true);
            this.txtApprLateNight.SetReadOnly(true);
            this.txtApprHoliday1.SetReadOnly(true);
            this.txtApprHoliday2.SetReadOnly(true);

            //Performance OT
            this.dtPerformEarly.SetReadOnly(true);
            this.dtPerformNormal1.SetReadOnly(true);
            this.dtPerformNormal2.SetReadOnly(true);
            this.dtPerformLateNight.SetReadOnly(true);
            this.dtPerformHoliday1.SetReadOnly(true);
            this.dtPerformHoliday2.SetReadOnly(true);

            //Total
            this.dtTotalOT.SetReadOnly(true);
            this.dtTotalWork.SetReadOnly(true);
            this.dtTotalWorkHour.SetReadOnly(true);

            base.DisabledLink(this.btnEdit, this.LoginInfo.User.ID != this.UserID);
            base.DisabledLink(this.btnDelete, this.LoginInfo.User.ID != this.UserID);
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="data">T_Work</param>
        private void ShowData(T_Work data)
        {
            //Show data
            if (data != null)
            {
                this.cmdPerformShift.SelectedValue = data.WorkShiftID.ToString();
                this.dtStartWorkTime.Value = data.StartWork;
                this.dtEndWorkTime.Value = data.EndWork;

                this.dtAtWork.Value = data.TimeWork;
                this.dtLate.Value = data.TimeLate;
                this.dtLeaveEarly.Value = data.TimeEarly;
                this.dtOuting.Value = data.TimeOut;
                this.dtPerformEarly.Value = data.OTEarly;
                this.dtPerformNormal1.Value = data.OTNormal1;
                this.dtPerformNormal2.Value = data.OTNormal2;
                this.dtPerformLateNight.Value = data.OTLate;
                this.dtPerformHoliday1.Value = data.OTHoliday1;
                this.dtPerformHoliday2.Value = data.OTHoliday2;
                this.dtTotalOT.Value = data.TotalOT;
                this.dtTotalWork.Value = data.TotalWork;

                IList<DailyWorkInfo> lstWorkInfo;
                IList<DailyOutingInfo> lstOuting;
                using (DB db = new DB())
                {
                    WorkOutService workOutSer = new WorkOutService(db);
                    lstOuting = workOutSer.GetListOutingByWorkID(data.ID);
                    if (lstOuting.Count == 0)
                    {
                        lstOuting.Add(new DailyOutingInfo());
                    }

                    WorkStepService workStepSer = new WorkStepService(db);
                    lstWorkInfo = workStepSer.GetListWorkByWorkID(data.ID);
                    if (lstWorkInfo.Count == 0)
                    {
                        lstWorkInfo.Add(new DailyWorkInfo());
                    }
                }

                this.rptOuting.DataSource = lstOuting;
                this.rptOuting.DataBind();
                this.OutingRowCount = lstOuting.Count + 1;

                this.rptDailyWorkList.DataSource = lstWorkInfo;
                this.rptDailyWorkList.DataBind();
                this.txtNote.Value = data.Remark;

                this.OldUpdateDate = data.UpdateDate;
                this.WorkID = data.ID;
            }
        }

        /// <summary>
        /// Get Data By Key
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="workDate"></param>
        /// <returns>T_Work</returns>
        private T_Work GetDataByKey(int userID, DateTime workDate)
        {
            using (DB db = new DB())
            {
                WorkService service = new WorkService(db);

                //Get User
                return service.GetByKey(userID, workDate);
            }
        }

        /// <summary>
        /// Get work data
        /// </summary>
        /// <returns>T_Work</returns>
        private T_Work GetMainData()
        {
            T_Work ret = new T_Work();

            ret.UserID = this.UserID;
            ret.WorkDate = this.WorkDate;
            ret.WorkShiftID = int.Parse(this.cmdPerformShift.SelectedValue);
            ret.StartWork = this.dtStartWorkTime.Value;
            ret.EndWork = this.dtEndWorkTime.Value;
            ret.TimeWork = this.dtAtWork.Value;
            ret.TimeLate = this.dtLate.Value;
            ret.TimeEarly = this.dtLeaveEarly.Value;
            ret.TimeOut = this.dtOuting.Value;
            ret.OTEarly = this.dtPerformEarly.Value;
            ret.OTNormal1 = this.dtPerformNormal1.Value;
            ret.OTNormal2 = this.dtPerformNormal2.Value;
            ret.OTLate = this.dtPerformLateNight.Value;
            ret.OTHoliday1 = this.dtPerformHoliday1.Value;
            ret.OTHoliday2 = this.dtPerformHoliday2.Value;
            ret.TotalOT = this.dtTotalOT.Value;
            ret.TotalWork = this.dtTotalWork.Value;
            ret.Remark = this.txtNote.Value;
            ret.CreateUID = this.LoginInfo.User.ID;
            ret.UpdateUID = this.LoginInfo.User.ID;
            return ret;
        }

        /// <summary>
        /// Get Outing List
        /// </summary>
        /// <param name="workID"></param>
        /// <returns>IList<T_Work_Out></returns>
        private IList<T_Work_Out> GetOutingList(int workID)
        {
            IList<T_Work_Out> lstOuting = new List<T_Work_Out>();

            foreach (RepeaterItem item in this.rptOuting.Items)
            {
                CheckBox chkOutDel = (CheckBox)item.FindControl("chkOutDel");
                IDateTextBox dtStartOutTime = (IDateTextBox)item.FindControl("dtStartOutTime");
                IDateTextBox dtEndOutTime = (IDateTextBox)item.FindControl("dtEndOutTime");

                if (dtStartOutTime.Value != null)
                {
                    T_Work_Out itemData = new T_Work_Out();
                    itemData.WorkID = workID;
                    itemData.StartTime = dtStartOutTime.Value.Value;
                    itemData.EndTime = dtEndOutTime.Value.Value;
                    lstOuting.Add(itemData);
                }
            }

            return lstOuting;
        }

        /// <summary>
        /// Get Work Step List
        /// </summary>
        /// <param name="workID"></param>
        /// <returns>IList<T_Work_Step></returns>
        private IList<T_Work_Step> GetWorkStepList(int workID)
        {
            IList<T_Work_Step> lstWorkStep = new List<T_Work_Step>();

            foreach (RepeaterItem item in this.rptDailyWorkList.Items)
            {
                ITextBox txtWorkName = (ITextBox)item.FindControl("txtWorkName");
                IDateTextBox dtWorkTime = (IDateTextBox)item.FindControl("dtWorkTime");
                ITextBox txtWorkNote = (ITextBox)item.FindControl("txtWorkNote");

                if (!string.IsNullOrEmpty(txtWorkName.Value))
                {
                    T_Work_Step itemData = new T_Work_Step();
                    itemData.WorkID = workID;
                    itemData.WorkName = txtWorkName.Value;
                    itemData.WorkTime = dtWorkTime.Value.Value;
                    itemData.Remark = txtWorkNote.Value;
                    lstWorkStep.Add(itemData);
                }
            }

            return lstWorkStep;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                T_Work work = this.GetMainData();
                using (DB db = new DB(IsolationLevel.Serializable))
                {
                    WorkService workSer = new WorkService(db);
                    WorkOutService workOutSer = new WorkOutService(db);
                    WorkStepService workStepSer = new WorkStepService(db);

                    //Insert work data
                    int workID = workSer.Insert(work);

                    if (workID != 0)
                    {
                        IList<T_Work_Out> lstOuting = this.GetOutingList(workID);
                        IList<T_Work_Step> lstWorkStep = this.GetWorkStepList(workID);

                        //Insert work outing
                        foreach (var item in lstOuting)
                        {
                            workOutSer.Insert(item);
                        }

                        //Insert work step
                        foreach (var item in lstWorkStep)
                        {
                            workStepSer.Insert(item);
                        }

                        db.Commit();
                    }
                    else
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                        return false;
                    }
                }

            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_WORK_UN))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "Date");
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Work work = this.GetMainData();
                work.ID = this.WorkID;
                work.UpdateDate = this.OldUpdateDate;

                using (DB db = new DB(IsolationLevel.Serializable))
                {
                    WorkService workSer = new WorkService(db);
                    WorkOutService workOutSer = new WorkOutService(db);
                    WorkStepService workStepSer = new WorkStepService(db);

                    ret = workSer.Update(work);

                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    workOutSer.Delete(work.ID);
                    workStepSer.Delete(work.ID);

                    IList<T_Work_Out> lstOuting = this.GetOutingList(work.ID);
                    IList<T_Work_Step> lstWorkStep = this.GetWorkStepList(work.ID);

                    //Insert work outing
                    foreach (var item in lstOuting)
                    {
                        workOutSer.Insert(item);
                    }

                    //Insert work step
                    foreach (var item in lstWorkStep)
                    {
                        workStepSer.Insert(item);
                    }
                    db.Commit();

                }
            }
            catch (Exception ex)
            {

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkService workSer = new WorkService(db);
                    WorkOutService workOutSer = new WorkOutService(db);
                    WorkStepService workStepSer = new WorkStepService(db);

                    ret = workSer.Delete(this.WorkID, this.OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    workOutSer.Delete(this.WorkID);
                    workStepSer.Delete(this.WorkID);
                    db.Commit();
                }

            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            if (this.dtStartWorkTime.IsEmpty != this.dtEndWorkTime.IsEmpty)
            {
                if (this.dtStartWorkTime.IsEmpty)
                {
                    this.SetMessage(this.dtStartWorkTime.ID, M_Message.MSG_REQUIRE, "Start Work Time");
                }

                if (this.dtEndWorkTime.IsEmpty)
                {
                    this.SetMessage(this.dtEndWorkTime.ID, M_Message.MSG_REQUIRE, "End Work Time");
                }
            }
            else if (!this.dtStartWorkTime.IsEmpty && this.dtStartWorkTime.Value.Value >= this.dtEndWorkTime.Value.Value)
            {
                this.SetMessage(this.dtStartWorkTime.ID, M_Message.MSG_GREATER_THAN, "End Work Time", "Start Work Time");
            }

            IList<T_Work_Out> lstOuting = new List<T_Work_Out>();
            foreach (RepeaterItem item in this.rptOuting.Items)
            {
                IDateTextBox dtStartOutTime = (IDateTextBox)item.FindControl("dtStartOutTime");
                IDateTextBox dtEndOutTime = (IDateTextBox)item.FindControl("dtEndOutTime");

                if (dtStartOutTime.IsEmpty != dtEndOutTime.IsEmpty)
                {
                    if (dtStartOutTime.IsEmpty)
                    {
                        this.SetMessage(dtStartOutTime.ClientID, M_Message.MSG_REQUIRE_GRID, "Start Out Time", item.ItemIndex + 1);
                    }

                    if (dtEndOutTime.IsEmpty)
                    {
                        this.SetMessage(dtEndOutTime.ClientID, M_Message.MSG_REQUIRE_GRID, "End Out Time", item.ItemIndex + 1);
                    }
                }
                else if (!dtStartOutTime.IsEmpty && dtEndOutTime.Value.Value <= dtStartOutTime.Value.Value)
                {
                    this.SetMessage(dtEndOutTime.ClientID, M_Message.MSG_GREATER_THAN_GRID, "End Out Time", "End Out Time", item.ItemIndex + 1);
                }
                else if (!dtStartOutTime.IsEmpty)
                {
                    T_Work_Out outItem = new T_Work_Out();
                    outItem.StartTime = dtStartOutTime.Value.Value;
                    outItem.EndTime = dtEndOutTime.Value.Value;

                    foreach (var temp in lstOuting)
                    {
                        if ((temp.StartTime <= outItem.StartTime && outItem.StartTime <= temp.EndTime)
                           || (temp.StartTime <= outItem.EndTime && outItem.EndTime <= temp.EndTime)
                           || (temp.StartTime >= outItem.EndTime && outItem.EndTime >= temp.EndTime))
                        {
                            this.SetMessage(dtStartOutTime.ClientID, M_Message.MSG_DUPLICATE_GRID, "Out Time", item.ItemIndex + 1);
                            this.CtrlIDErrors.Add(dtEndOutTime.ClientID);
                        }
                    }
                    lstOuting.Add(outItem);
                }
            }
            bool hasWork = false;
            foreach (RepeaterItem item in this.rptDailyWorkList.Items)
            {
                ITextBox txtWorkName = (ITextBox)item.FindControl("txtWorkName");
                IDateTextBox dtWorkTime = (IDateTextBox)item.FindControl("dtWorkTime");
                ITextBox txtWorkNote = (ITextBox)item.FindControl("txtWorkNote");
                //-----------------------------------
                if (txtWorkName.IsEmpty && dtWorkTime.IsEmpty && txtWorkNote.IsEmpty)
                {
                    continue;
                }
                //-----------------------------------
                if (txtWorkName.IsEmpty)
                {
                    this.SetMessage(txtWorkName.ClientID, M_Message.MSG_REQUIRE_GRID, "Project/Work name", item.ItemIndex + 1);
                }
                //-----------------------------------
                if (dtWorkTime.IsEmpty)
                {
                    this.SetMessage(dtWorkTime.ClientID, M_Message.MSG_REQUIRE_GRID, "Work hour", item.ItemIndex + 1);
                }
                //-----------------------------------                
                if (this.dtTotalWorkHour.Value != null && this.dtTotalWork.Value != null && item.ItemIndex == this.rptDailyWorkList.Items.Count - 1)
                {
                    if (this.dtTotalWorkHour.Value.Value > this.dtTotalWork.Value.Value)
                    {
                        this.SetMessage(dtWorkTime.ClientID, M_Message.MSG_INVALID_GRID, "Work Time", item.ItemIndex + 1);
                    }
                }

                hasWork = true;
            }

            if (!hasWork && !this.dtStartWorkTime.IsEmpty && !this.dtEndWorkTime.IsEmpty)
            {
                ITextBox txtWorkName = (ITextBox)this.rptDailyWorkList.Items[0].FindControl("txtWorkName");
                IDateTextBox dtWorkTime = (IDateTextBox)this.rptDailyWorkList.Items[0].FindControl("dtWorkTime");
                this.SetMessage(txtWorkName.ClientID, M_Message.MSG_REQUIRE_GRID, "Project/Work name", 1);
                this.SetMessage(dtWorkTime.ClientID, M_Message.MSG_REQUIRE_GRID, "Work hour", 1);
            }

            if (base.HaveError)
            {
                ReLoadDataForGrid();
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// ReLoadDataForGrid
        /// </summary>
        private void ReLoadDataForGrid()
        {
            IList<DailyOutingInfo> lstOuting = this.GetOutingData();
            this.rptOuting.DataSource = lstOuting;
            this.rptOuting.DataBind();
            this.OutingRowCount = lstOuting.Count + 1;

            IList<DailyWorkInfo> lstWork = this.GetWorkData();
            this.rptDailyWorkList.DataSource = lstWork;
            this.rptDailyWorkList.DataBind();
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Format time result
        /// </summary>
        /// <param name="inVal"></param>
        /// <returns></returns>
        private static string FormatTimeResult(TimeSpan inVal)
        {
            if (inVal.TotalMinutes > 0)
            {
                return string.Format("{0:00}:{1:00}", inVal.Hours, inVal.Minutes);
            }
            else
            {
                return string.Empty;
            }
        }
        #endregion

        #region Web method
        /// <summary>
        /// Cal Total Work Time
        /// </summary>
        /// <param name="in1">Start Date</param>
        /// <returns></returns>
        [WebMethod]
        public static string CalTotalWorkTime(string arrVal)
        {
            try
            {
                if (string.IsNullOrEmpty(arrVal))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(string.Empty);
                }

                var lstVal = arrVal.Split(',');
                int hour = 0;
                int minute = 0;
                foreach (string item in lstVal)
                {
                    if (item != "")
                    {
                        var arrItem = item.Split(':');
                        hour = hour + int.Parse(arrItem[0]);
                        minute = minute + int.Parse(arrItem[1]);
                        if (minute >= 60)
                        {
                            minute = minute - 60;
                            hour++;
                        }
                    }
                }
                if (hour != 0 || minute != 0)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(string.Format("{0:00}:{1:00}", hour, minute));
                }
                else
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(string.Empty);
                }

            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Cal Work Time
        /// </summary>
        /// <param name="processDate"></param>
        /// <param name="shiftId"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        /// <param name="outTimeArr"></param>
        /// <returns></returns>
        [WebMethod]
        public static string CalWorkTime(string processDate, int shiftId, string startTime, string endTime, string outTimeArr)
        {
            try
            {
                if (string.IsNullOrEmpty(startTime) || string.IsNullOrEmpty(endTime) || endTime.CompareTo(startTime) <= 0)
                {
                    var result = new
                    {
                        atWork = "",
                        beLate = "",
                        leaveEarly = "",
                        outTime = "",

                        earlyOT = "",
                        normal1OT = "",
                        normal2OT = "",
                        lateNightOT = "",
                        holiday1OT = "",
                        holiday2OT = "",
                        totalOT = "",
                        totalWork = "",
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }

                var arrST = startTime.Split(':');
                var arrET = endTime.Split(':');
                var arrOutTime = outTimeArr.Split(',');

                TimeSpan atWork = new TimeSpan();
                TimeSpan beLate = new TimeSpan();
                TimeSpan leaveEarly = new TimeSpan();

                TimeSpan outTimeEarly = new TimeSpan();
                TimeSpan outTimeWork = new TimeSpan();
                TimeSpan outTimeOT = new TimeSpan();
                TimeSpan outTimeOTNight = new TimeSpan();

                TimeSpan earlyOT = new TimeSpan();
                TimeSpan normal1OT = new TimeSpan();
                TimeSpan normal2OT = new TimeSpan();
                TimeSpan lateNightOT = new TimeSpan();
                TimeSpan holiday1OT = new TimeSpan();
                TimeSpan holiday2OT = new TimeSpan();

                TimeSpan totalOT = new TimeSpan();
                TimeSpan totalWork = new TimeSpan();

                DateTime workST = new DateTime(1, 1, 1).AddHours(int.Parse(arrST[0])).AddMinutes(int.Parse(arrST[1]));
                DateTime workET = new DateTime(1, 1, 1).AddHours(int.Parse(arrET[0])).AddMinutes(int.Parse(arrET[1]));

                DateTime startWorkTime = workST;
                DateTime endWorkTime = workET;

                DateTime workOTBeforeST = new DateTime(1, 1, 1);
                DateTime workOTBeforeET = new DateTime(1, 1, 1);
                DateTime workSTWork = new DateTime(1, 1, 1);
                DateTime workETWork = new DateTime(1, 1, 1);
                DateTime workOTAfterST = new DateTime(1, 1, 1);
                DateTime workOTAfterET = new DateTime(1, 1, 1);

                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    HolidayService holidaySer = new HolidayService(db);
                    RestTimeService restTSer = new RestTimeService(db);
                    AccountingService accSer = new AccountingService(db);

                    M_Work_Shift shift = shiftSer.GetByID(shiftId);
                    IList<RestTime> lstRestTime = restTSer.GetListByShiftID(shiftId);
                    M_Accounting accouting = accSer.GetData();

                    DateTime shiftST = new DateTime(1, 1, 1);
                    DateTime shiftET = new DateTime(1, 1, 1);
                    if (shift.StartHour != null)
                    {
                        shiftST = new DateTime(1, 1, 1).AddHours((int)shift.StartHour).AddMinutes((int)shift.StartMinute);
                        shiftET = new DateTime(1, 1, 1).AddHours((int)shift.EndHour).AddMinutes((int)shift.EndMinute);
                    }

                    //work time
                    workSTWork = startWorkTime >= shiftST ? startWorkTime : shiftST;
                    workETWork = endWorkTime <= shiftET ? endWorkTime : shiftET;

                    //over time morning
                    if (startWorkTime < shiftST)
                    {
                        workOTBeforeST = startWorkTime;
                        workOTBeforeET = endWorkTime < shiftST ? endWorkTime : shiftST;
                    }

                    //over time everning
                    if (endWorkTime > shiftET)
                    {
                        workOTAfterST = startWorkTime > shiftET ? startWorkTime : shiftET;
                        workOTAfterET = endWorkTime;
                    }

                    for (int i = 0; i < arrOutTime.Length; i = i + 2)
                    {
                        if (!string.IsNullOrEmpty(arrOutTime[i]) && !string.IsNullOrEmpty(arrOutTime[i + 1]))
                        {
                            var arrOST = arrOutTime[i].Split(':');
                            var arrOET = arrOutTime[i + 1].Split(':');
                            DateTime outST = new DateTime(1, 1, 1).AddHours(int.Parse(arrOST[0])).AddMinutes(int.Parse(arrOST[1]));
                            DateTime outET = new DateTime(1, 1, 1).AddHours(int.Parse(arrOET[0])).AddMinutes(int.Parse(arrOET[1]));

                            if (outET <= outST)
                            {
                                continue;
                            }

                            DateTime outOTBeforeST = new DateTime(1, 1, 1);
                            DateTime outOTBeforeET = new DateTime(1, 1, 1);
                            DateTime outSTWork = new DateTime(1, 1, 1);
                            DateTime outETWork = new DateTime(1, 1, 1);
                            DateTime outOTAfterST = new DateTime(1, 1, 1);
                            DateTime outOTAfterET = new DateTime(1, 1, 1);

                            outST = outST < workST ? workST : outST;
                            outET = outET > workET ? workET : outET;

                            //Out work time
                            outSTWork = outST >= shiftST ? outST : shiftST;
                            outETWork = outET <= shiftET ? outET : shiftET;
                            outTimeWork = outTimeWork.Add(CommonService.CalDurationWorkTime(outSTWork, outETWork, lstRestTime));

                            //Out time morning
                            if (outST < shiftST)
                            {
                                outOTBeforeST = outST;
                                outOTBeforeET = outET < shiftST ? outET : shiftST;
                                CommonService.ClassifyOTTime(outOTBeforeST, outOTBeforeET, lstRestTime, accouting, ref outTimeEarly, ref outTimeOT, ref outTimeOTNight);
                            }

                            //Out time everning
                            if (outET > shiftET)
                            {
                                outOTAfterST = outST > shiftET ? outST : shiftET;
                                outOTAfterET = outET;
                                CommonService.ClassifyOTTime(outOTAfterST, outOTAfterET, lstRestTime, accouting, ref outTimeEarly, ref outTimeOT, ref outTimeOTNight);
                            }
                        }
                    }

                    //Late and leave early
                    if (shiftST < shiftET)
                    {
                        beLate = CommonService.CalDurationWorkTime(shiftST, workSTWork, lstRestTime);
                        leaveEarly = CommonService.CalDurationWorkTime(workETWork, shiftET, lstRestTime);

                        //round
                        beLate = EditDataUtil.RoundTime(beLate, accouting.UnitOfTime, accouting.RoundLate);
                        leaveEarly = EditDataUtil.RoundTime(leaveEarly, accouting.UnitOfTime, accouting.RoundLeave);
                        outTimeWork = EditDataUtil.RoundTime(outTimeWork, accouting.UnitOfTime, accouting.RoundOuting);

                        //Working time
                        atWork = CommonService.CalDurationWorkTime(shiftST, shiftET, lstRestTime).Subtract(outTimeWork).Subtract(beLate).Subtract(leaveEarly);
                    }

                    //overtime calculate
                    TimeSpan normalOT = new TimeSpan();
                    if (workOTBeforeST != new DateTime(1, 1, 1) || workOTBeforeET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTBeforeST, workOTBeforeET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }
                    if (workOTAfterST != new DateTime(1, 1, 1) || workOTAfterET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTAfterST, workOTAfterET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }

                    earlyOT = earlyOT.Subtract(outTimeEarly);
                    normalOT = normalOT.Subtract(outTimeOT);

                    //round overtime
                    earlyOT = EditDataUtil.RoundTime(earlyOT, accouting.UnitOfTime, accouting.RoundOT);
                    normalOT = EditDataUtil.RoundTime(normalOT, accouting.UnitOfTime, accouting.RoundOT);

                    DateTime pDate = DateTime.ParseExact(processDate, Constants.FMT_DATE, CultureInfo.InvariantCulture);
                    if (holidaySer.GetByDay(pDate) != null)
                    {
                        holiday2OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        holiday1OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Saturday)
                    {
                        normal2OT = normalOT;
                    }
                    else
                    {
                        normal1OT = normalOT;
                    }

                    lateNightOT = lateNightOT.Subtract(outTimeOTNight);

                    //Round
                    lateNightOT = EditDataUtil.RoundTime(lateNightOT, accouting.UnitOfTime, accouting.RoundOT);
                }

                totalOT = earlyOT.Add(normal1OT).Add(normal2OT).Add(lateNightOT).Add(holiday1OT).Add(holiday2OT);
                totalWork = totalOT;
                if (atWork.TotalMinutes > 0)
                {
                    totalWork = atWork.Add(totalOT);
                }
                var ret = new
                {
                    atWork = FormatTimeResult(atWork),
                    beLate = FormatTimeResult(beLate),
                    leaveEarly = FormatTimeResult(leaveEarly),
                    outTime = FormatTimeResult(outTimeWork),

                    earlyOT = FormatTimeResult(earlyOT),
                    normal1OT = FormatTimeResult(normal1OT),
                    normal2OT = FormatTimeResult(normal2OT),
                    lateNightOT = FormatTimeResult(lateNightOT),
                    holiday1OT = FormatTimeResult(holiday1OT),
                    holiday2OT = FormatTimeResult(holiday2OT),
                    totalOT = FormatTimeResult(totalOT),
                    totalWork = FormatTimeResult(totalWork),

                };
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(ret);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
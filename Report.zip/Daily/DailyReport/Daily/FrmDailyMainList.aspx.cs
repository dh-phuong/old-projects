﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Collections;
using System.Data.SqlClient;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Daily
{
    /// <summary>
    /// Form Daily main list
    /// </summary>
    public partial class FrmDailyMainList : FrmBaseDetail
    {
        #region Property
        /// <summary>
        /// List work date error
        /// </summary>
        private List<DateTime> ListWorkDateErr
        {
            get { return (List<DateTime>)ViewState["ListWorkDateErr"]; }
            set { ViewState["ListWorkDateErr"] = value; }
        }

        /// <summary>
        /// List work date error
        /// </summary>
        private List<DateTime> ListWorkDateSubmitErr
        {
            get { return (List<DateTime>)ViewState["ListWorkDateSubmitErr"]; }
            set { ViewState["ListWorkDateSubmitErr"] = value; }
        }

        /// <summary>
        /// DataSubmit
        /// </summary>
        private bool DataSubmit
        {
            get { return base.GetValueViewState<bool>("DataSubmit"); }
            set
            {
                base.ViewState["DataSubmit"] = value;
            }
        }

        /// <summary>
        /// DataCancel
        /// </summary>
        private bool DataCancel
        {
            get { return base.GetValueViewState<bool>("DataCancel"); }
            set
            {
                base.ViewState["DataCancel"] = value;
            }
        }
        #endregion

        #region Page Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Daily Report";
            base.FormSubTitle = "Report";

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);
        }

        /// <summary>
        /// Page load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.SetDataDepartmentCbo();
                this.dtDate.Value = this.GetMonthAccount();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                    else
                    {
                        this.cmbDept.SelectedValue = this.LoginInfo.Department.ID.ToString();

                        this.SetDataStaffCbo();
                        this.cmbStaff.SelectedValue = this.LoginInfo.User.StaffID.ToString();
                    }
                }

                this.GetData();
            }

            this.IsHiddenModeLabel = true;
        }

        /// <summary>
        /// Change month view
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void dtDate_TextChanged(object sender, EventArgs e)
        {
            string itemSelected = this.cmbStaff.SelectedValue;
            this.SetDataStaffCbo();

            List<DropDownModel> list = (List<DropDownModel>)this.cmbStaff.DataSource;
            if (list.Exists(x => x.Value.Equals(itemSelected)))
            {
                this.cmbStaff.SelectedValue = itemSelected;
            }
        }

        /// <summary>
        /// Change dept
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetDataStaffCbo();
            this.ClearDataRouter();
            this.rptData.DataSource = null;
            this.rptData.DataBind();

            if (this.dtDate.Value.HasValue)
            {
                this.lblMonth.Text = string.Format(Constants.FMT_MMYYYY, this.dtDate.Value.Value);
            }
            else
            {
                this.lblMonth.Text = string.Empty;
            }
            base.HiddenLink(this.btnSubmit, true);
            base.HiddenLink(this.btnCancel, true);
        }

        /// <summary>
        /// Change Staff
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbStaff_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetData();
        }

        /// <summary>
        /// Submit button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.LoadData(this.dtDate.Value.Value, int.Parse(this.cmbStaff.SelectedValue));

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            this.DataSubmit = true;
            this.DataCancel = false;

            //Show question insert
            this.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Cancel button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.DataSubmit = false;
            this.DataCancel = true;

            //Show question insert
            this.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No);
        }

        /// <summary>
        /// Search button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.GetData();
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            this.LoadData(this.dtDate.Value.Value, int.Parse(this.cmbStaff.SelectedValue));

            #region Submit
            if (this.DataSubmit)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }

                ////Insert Data
                if (this.InsertData())
                {
                    //Set Success
                    this.Success = true;

                    this.btnSearch_Click(null, null);
                }
            }
            #endregion

            #region Cancel
            if (this.DataCancel)
            {
                if (this.CancelData())
                {
                    //Set Success
                    this.Success = true;

                    this.btnSearch_Click(null, null);
                }
            }
            #endregion
        }

        /// <summary>
        /// No Process data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
            #region Submit
            if (this.DataSubmit)
            {
                this.DataSubmit = false;
            }
            #endregion

            #region Cancel
            if (this.DataCancel)
            {
                this.DataCancel = false;
            }
            #endregion

            this.btnSearch_Click(null, null);
        }

        /// <summary>
        /// Detail input button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDailyInput_Click(object sender, CommandEventArgs e)
        {
            var tmp = e.CommandArgument.ToString().Split(',');

            this.ViewState["_WorkDate"] = DateTime.ParseExact(tmp[0], Constants.FMT_DATE, CultureInfo.InvariantCulture);
            this.ViewState["_StaffID"] = tmp[1];

            this.SaveCondition();
        }

        /// <summary>
        /// Data bound list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptData_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            WorkInfo dataItem = (WorkInfo)e.Item.DataItem;
            if (dataItem != null)
            {
                Repeater rptOutS = (Repeater)e.Item.FindControl("rptOutS");
                //----------------Set data daily detail----------------------//
                rptOutS.DataSource = dataItem.WorkStartOutInfos;
                rptOutS.DataBind();

                Repeater rptOutE = (Repeater)e.Item.FindControl("rptOutE");
                //----------------Set data daily detail----------------------//
                rptOutE.DataSource = dataItem.WorkEndOutInfos;
                rptOutE.DataBind();

                using (DB db = new DB())
                {
                    //----------------Set data daily detail----------------------//
                    Repeater rptWorkStep = (Repeater)e.Item.FindControl("rptWorkStep");
                    WorkStepService stepSer = new WorkStepService(db);
                    rptWorkStep.DataSource = stepSer.GetListByWorkID(dataItem.ID);
                    rptWorkStep.DataBind();

                    //----------------Set data daily detail----------------------//
                    Repeater rptApplied = (Repeater)e.Item.FindControl("rptApplied");
                    WorkService workSer = new WorkService(db);
                    IList<WorkAppliedList> listApplied = workSer.GetAppliedList(dataItem.UserID, dataItem.WorkDate);
                    rptApplied.DataSource = listApplied;

                    this.CheckWorkDateSubmit(listApplied, dataItem);
                    rptApplied.DataBind();
                }
            }
        }
        #endregion

        #region Method
        /// <summary>
        /// Check required input
        /// </summary>
        /// <returns></returns>
        private bool CheckRequire()
        {
            if (!this.dtDate.Value.HasValue)
            {
                this.SetMessage(this.dtDate.ID, M_Message.MSG_REQUIRE, "Month");
            }

            if (this.cmbDept.SelectedIndex == 0)
            {
                this.SetMessage(this.cmbDept.ID, M_Message.MSG_REQUIRE, "Department");
            }
            else
            {
                if (this.cmbStaff.SelectedIndex == 0)
                {
                    this.SetMessage(this.cmbStaff.ID, M_Message.MSG_REQUIRE, "Employee");
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Check Input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            this.CheckRequire();
            if (!base.HaveError)
            {
                if (this.dtDate.Value.Value.Month > DateTime.Now.Month)
                {
                    this.SetMessage(this.dtDate.ID, M_Message.MSG_LESS_THAN, "Month", "Current Month");
                }
            }
            if (!base.HaveError)
            {
                List<ApproveNextInfo> items = this.GetListApproveNext();
                if (items.Count > 0)
                {
                    List<string> tmps = new List<string>();
                    foreach (var item in items)
                    {
                        if (!tmps.Contains(item.ApplyNo))
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_APPROVE_NOT_FINISH, item.ApplyNo);
                            tmps.Add(item.ApplyNo);
                        }
                    }
                }
                else
                {
                    List<DateTime> lstErrDate = new List<DateTime>();
                    lstErrDate.AddRange(ListWorkDateErr);
                    lstErrDate.AddRange(ListWorkDateSubmitErr);
                    lstErrDate.Sort();
                    if (lstErrDate.Count > 0)
                    {
                        foreach (var item in lstErrDate)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_INVALID, item.ToString(Constants.FMT_DATE));
                        }
                    }
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.dtDate.ID, this.dtDate.Value);
            hash.Add(this.cmbDept.ID, this.cmbDept.SelectedValue);
            hash.Add(this.cmbStaff.ID, this.cmbStaff.SelectedValue);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        /// <param name="data"></param>
        private void ShowCondition(Hashtable data)
        {
            this.dtDate.Value = DateTime.Parse(data[this.dtDate.ID].ToString());
            this.cmbDept.SelectedValue = data[this.cmbDept.ID].ToString();

            this.SetDataStaffCbo();
            this.cmbStaff.SelectedValue = data[this.cmbStaff.ID].ToString();
        }

        /// <summary>
        /// Get T_Work_Total insert data
        /// </summary>
        /// <returns>T_Work_Total</returns>
        private T_Work_Total GetWorkTotalInsert()
        {
            AccountingPeriod accountingPeriod = new AccountingPeriod();
            WorkTotalInfo workTotalInfo = new WorkTotalInfo();
            M_StaffInfo mStaffInfo = new M_StaffInfo();

            using (DB db = new DB())
            {
                AccountingService accountingService = new AccountingService(db);
                accountingPeriod = accountingService.GetAccountingMonth(this.dtDate.Value.Value);

                WorkService workService = new WorkService(db);
                workTotalInfo = workService.GetTotalByCond(int.Parse(this.cmbStaff.SelectedValue), accountingPeriod.StartDate, accountingPeriod.EndDate);

                StaffService staffService = new StaffService(db);
                mStaffInfo = staffService.GetStaffInfoByStaffID(int.Parse(this.cmbStaff.SelectedValue));
            }

            T_Work_Total workTotal = new T_Work_Total();
            if (workTotalInfo != null)
            {
                workTotal.UserID = mStaffInfo.UserID;
                workTotal.MonthWork = this.dtDate.Value.Value;
                workTotal.DateFrom = accountingPeriod.StartDate;
                workTotal.DateTo = accountingPeriod.EndDate;

                workTotal.TimeWorkHour = workTotalInfo.TimeWorkHour;
                workTotal.TimeWorkMinute = workTotalInfo.TimeWorkMinute;
                workTotal.TimeLateHour = workTotalInfo.TimeLateHour;
                workTotal.TimeLateMinute = workTotalInfo.TimeLateMinute;
                workTotal.TimeEarlyHour = workTotalInfo.TimeEarlyHour;
                workTotal.TimeEarlyMinute = workTotalInfo.TimeEarlyMinute;
                workTotal.TimeOutHour = workTotalInfo.TimeOutHour;
                workTotal.TimeOutMinute = workTotalInfo.TimeOutMinute;

                workTotal.VacationLeaves = workTotalInfo.VacationLeaves;
                workTotal.AbsenceLeaves = workTotalInfo.AbsenceLeaves;

                workTotal.OTEarlyHour = workTotalInfo.OTEarlyHour;
                workTotal.OTEarlyMinute = workTotalInfo.OTEarlyMinute;
                workTotal.OTNormal1Hour = workTotalInfo.OTNormal1Hour;
                workTotal.OTNormal1Minute = workTotalInfo.OTNormal1Minute;
                workTotal.OTNormal2Hour = workTotalInfo.OTNormal2Hour;
                workTotal.OTNormal2Minute = workTotalInfo.OTNormal2Minute;
                workTotal.OTLateHour = workTotalInfo.OTLateHour;
                workTotal.OTLateMinute = workTotalInfo.OTLateMinute;
                workTotal.OTHoliday1Hour = workTotalInfo.OTHoliday1Hour;
                workTotal.OTHoliday1Minute = workTotalInfo.OTHoliday1Minute;
                workTotal.OTHoliday2Hour = workTotalInfo.OTHoliday2Hour;
                workTotal.OTHoliday2Minute = workTotalInfo.OTHoliday2Minute;

                workTotal.TotalOTHour = workTotalInfo.TotalOTHour;
                workTotal.TotalOTMinute = workTotalInfo.TotalOTMinute;
                workTotal.TotalWorkHour = workTotalInfo.TotalWorkHour;
                workTotal.TotalWorkMinute = workTotalInfo.TotalWorkMinute;

                workTotal.CreateUID = this.LoginInfo.User.ID;
            }

            return workTotal;
        }

        /// <summary>
        /// Get list approve next
        /// </summary>
        /// <returns>List<ApproveNextInfo></returns>
        private List<ApproveNextInfo> GetListApproveNext()
        {
            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                WorkApproveService _workService = new WorkApproveService(db);

                AccountingPeriod _period = _ser.GetAccountingMonth(this.dtDate.Value.Value);

                return _workService.GetListNextApprove(int.Parse(this.cmbStaff.SelectedValue), _period.StartDate, _period.EndDate).ToList();
            }
        }

        /// <summary>
        /// Cancel data
        /// </summary>
        /// <returns></returns>
        private bool CancelData()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    M_StaffInfo mStaffInfo = new M_StaffInfo();
                    WorkTotalService service = new WorkTotalService(db);
                    StaffService staffService = new StaffService(db);
                    mStaffInfo = staffService.GetStaffInfoByStaffID(int.Parse(this.cmbStaff.SelectedValue));

                    service.Delete(mStaffInfo.UserID, this.dtDate.Value.Value);

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage("", M_Message.MSG_UPDATE_FAILE, "Cancel");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <returns></returns>
        private bool InsertData()
        {
            try
            {
                T_Work_Total item = this.GetWorkTotalInsert();

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkTotalService _service = new WorkTotalService(db);

                    int ret = _service.Insert(item);
                    if (ret == 0)
                    {
                        AccountingService accountingService = new AccountingService(db);
                        AccountingPeriod accountingPeriod = accountingService.GetAccountingMonth(this.dtDate.Value.Value);

                        for (DateTime day = accountingPeriod.StartDate; day < accountingPeriod.EndDate;)
                        {

                            StaffService staffService = new StaffService(db);
                            M_StaffInfo mStaffInfo = staffService.GetStaffInfoByStaffID(int.Parse(this.cmbStaff.SelectedValue));

                            WorkService workService = new WorkService(db);
                            T_Work work = workService.GetByKey(mStaffInfo.UserID, day);
                            if (work == null)
                            {
                                IList<WorkAppliedList> listApplied = workService.GetAppliedList(mStaffInfo.UserID, day);
                                if (listApplied.Count > 0 && listApplied.Any(m => (m.ApplyType == (int)ApplyType.Vacation || m.ApplyType == (int)ApplyType.Absence) && m.ApplyStatus == (int)StatusApply.Approved))
                                {
                                    WorkVacationService workVacationService = new WorkVacationService(db);
                                    T_Work_Vacation workVacation = workVacationService.GetByApplyNo(listApplied.FirstOrDefault().No);

                                    WorkAbsenceService workAbsenceService = new WorkAbsenceService(db);
                                    T_Work_Absence workAbsence = workAbsenceService.GetByApplyNo(listApplied.FirstOrDefault().No);

                                    if ((workVacation != null && workVacation.VacationType == (int)VacationType.DayOff))
                                    {
                                        work = new T_Work();
                                        //Insert T_Work
                                        work.UserID = mStaffInfo.UserID;
                                        work.WorkDate = day;
                                        work.WorkShiftID = 16;
                                        work.StartWork = null;
                                        work.EndWork = null;
                                        work.TimeWork = null;
                                        work.TimeLate = null;
                                        work.TimeEarly = null;
                                        work.TimeOut = null;
                                        work.OTEarly = null;
                                        work.OTNormal1 = null;
                                        work.OTNormal2 = null;
                                        work.OTLate = null;
                                        work.OTHoliday1 = null;
                                        work.OTHoliday2 = null;
                                        work.TotalOT = null;
                                        work.TotalWork = null;
                                        work.Remark = string.Empty;
                                        work.CreateUID = this.LoginInfo.User.ID;
                                        work.UpdateUID = this.LoginInfo.User.ID;
                                        workService.Insert(work);
                                    }
                                    if ((workAbsence != null && workAbsence.AbsenceType == (int)VacationType.DayOff))
                                    {
                                        work = new T_Work();
                                        //Insert T_Work
                                        work.UserID = mStaffInfo.UserID;
                                        work.WorkDate = day;
                                        work.WorkShiftID = 19;
                                        work.StartWork = null;
                                        work.EndWork = null;
                                        work.TimeWork = null;
                                        work.TimeLate = null;
                                        work.TimeEarly = null;
                                        work.TimeOut = null;
                                        work.OTEarly = null;
                                        work.OTNormal1 = null;
                                        work.OTNormal2 = null;
                                        work.OTLate = null;
                                        work.OTHoliday1 = null;
                                        work.OTHoliday2 = null;
                                        work.TotalOT = null;
                                        work.TotalWork = null;
                                        work.Remark = string.Empty;
                                        work.CreateUID = this.LoginInfo.User.ID;
                                        work.UpdateUID = this.LoginInfo.User.ID;
                                        workService.Insert(work);
                                    }
                                }
                            }
                            day = day.AddDays(1);
                        }
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Work_Total_UN))
                {
                    this.SetMessage("", M_Message.MSG_EXIST_CODE, "Month");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage("", M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Get month account
        /// </summary>
        /// <returns>DateTime</returns>
        private DateTime GetMonthAccount()
        {
            DateTime nowDate = DateTime.Now.Date;
            M_Accounting m_accounting;
            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                m_accounting = _ser.GetData();
            }

            if (nowDate.Day > m_accounting.ClosingDay)
            {
                return nowDate.AddMonths(1);
            }

            return nowDate;

        }

        /// <summary>
        /// Get end period
        /// </summary>
        /// <param name="workDate"></param>
        /// <returns>DateTime</returns>
        private DateTime GetEndPeriod(DateTime workDate)
        {
            M_Accounting m_accounting = new M_Accounting();
            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                m_accounting = _ser.GetData();
            }

            int daysInMonth = DateTime.DaysInMonth(workDate.Year, workDate.Month);
            if (m_accounting.ClosingDay > daysInMonth)
            {
                return new DateTime(workDate.Year, workDate.Month, daysInMonth);
            }
            else
            {
                return new DateTime(workDate.Year, workDate.Month, m_accounting.ClosingDay);
            }
        }

        /// <summary>
        /// Get Data
        /// </summary>
        private void GetData()
        {
            if (CheckRequire())
            {
                DateTime _date = this.dtDate.Value.Value;
                if (this.cmbStaff.SelectedItem == null)
                {
                    this.lblMonth.Text = string.Format(Constants.FMT_MMYYYY, _date);
                }
                else
                {
                    this.lblMonth.Text = string.Format(Constants.FMT_MMYYYY, _date) + ' ' + this.cmbStaff.SelectedItem.Text;
                }

                this.LoadData(_date, int.Parse(this.cmbStaff.SelectedValue));
            }
            else
            {
                this.rptData.DataSource = null;
                this.rptData.DataBind();

                base.HiddenLink(this.btnSubmit, true);
                base.HiddenLink(this.btnCancel, true);
                if (this.dtDate.Value.HasValue)
                {
                    this.lblMonth.Text = string.Format(Constants.FMT_MMYYYY, this.dtDate.Value.Value);
                }
                else
                {
                    this.lblMonth.Text = string.Empty;
                }
            }
        }

        /// <summary>
        /// Load data
        /// </summary>
        /// <param name="date"></param>
        /// <param name="staffID"></param>
        private void LoadData(DateTime date, int staffID)
        {
            AccountingPeriod _period = new AccountingPeriod();
            List<WorkInfo> items = new List<WorkInfo>();
            WorkTotalInfo work_total = new WorkTotalInfo();
            WorkTotalInfo totals = new WorkTotalInfo();

            this.ListWorkDateSubmitErr = new List<DateTime>();

            using (DB db = new DB())
            {
                //------------------------
                AccountingService _ser = new AccountingService(db);
                _period = _ser.GetAccountingMonth(date);

                WorkService _workService = new WorkService(db);
                items = _workService.GetListByCond(staffID, _period.StartDate, _period.EndDate).OrderBy(m => m.WorkDate).ToList();

                WorkTotalService _workTotalService = new WorkTotalService(db);
                work_total = _workTotalService.GetByKey(staffID, date);
                totals = _workService.GetTotalByCond(int.Parse(this.cmbStaff.SelectedValue), _period.StartDate, _period.EndDate);
            }

            this.rptData.DataSource = items.Count == 0 ? null : items;
            this.rptData.DataBind();

            //------------------------
            this.StoredWorkDateError(items);

            //------------------------

            if (work_total != null)
            {
                this.lblTimeWorkBase.Text = work_total.TimeWorkBase;

                this.lblApprLate.Text = work_total.ApprLate;
                this.lblApprLeaveEarly.Text = work_total.ApprLeaveEarly;
                this.lblApprOut.Text = work_total.ApprOut;

                this.lblVacationLeaves.Text = work_total.VacationLeavesStr;
                this.lblAbsenceLeaves.Text = work_total.AbsenceLeavesStr;
                this.lblDayOff.Text = work_total.DayOffStr;
                this.lblAbsenceOff.Text = work_total.AbsenceOffStr;

                this.lblApprOTEarly.Text = work_total.ApprOTEarly;
                this.lblApprOTNormal1.Text = work_total.ApprOTNormal1;
                this.lblApprOTNormal2.Text = work_total.ApprOTNormal2;
                this.lblApprOTLate.Text = work_total.ApprOTLate;
                this.lblApprOTHoliday1.Text = work_total.ApprOTHoliday1;
                this.lblApprOTHoliday2.Text = work_total.ApprOTHoliday2;

                this.lblTimeWork.Text = work_total.TimeWork;
                this.lblTimeLate.Text = work_total.TimeLate;
                this.lblTimeEarly.Text = work_total.TimeEarly;
                this.lblTimeOut.Text = work_total.TimeOut;

                this.lblOTEarly.Text = work_total.OTEarly;
                this.lblOTNormal1.Text = work_total.OTNormal1;
                this.lblOTNormal2.Text = work_total.OTNormal2;
                this.lblOTLate.Text = work_total.OTLate;
                this.lblOTHoliday1.Text = work_total.OTHoliday1;
                this.lblOTHoliday2.Text = work_total.OTHoliday2;

                this.lblTotalOT.Text = work_total.TotalOT;
                this.lblTotalWork.Text = work_total.TotalWork;

                base.HiddenLink(this.btnSubmit, true);
                if (this.IsAdmin())
                {
                    base.HiddenLink(this.btnCancel, false);
                }
            }
            else
            {
                if (totals != null)
                {
                    this.lblTimeWorkBase.Text = totals.TimeWorkBase;
                    this.lblApprLate.Text = totals.ApprLate;
                    this.lblApprLeaveEarly.Text = totals.ApprLeaveEarly;
                    this.lblApprOut.Text = totals.ApprOut;

                    this.lblVacationLeaves.Text = totals.VacationLeavesStr;
                    this.lblAbsenceLeaves.Text = totals.AbsenceLeavesStr;
                    this.lblDayOff.Text = totals.DayOffStr;
                    this.lblAbsenceOff.Text = totals.AbsenceOffStr;

                    this.lblApprOTEarly.Text = totals.ApprOTEarly;
                    this.lblApprOTNormal1.Text = totals.ApprOTNormal1;
                    this.lblApprOTNormal2.Text = totals.ApprOTNormal2;
                    this.lblApprOTLate.Text = totals.ApprOTLate;
                    this.lblApprOTHoliday1.Text = totals.ApprOTHoliday1;
                    this.lblApprOTHoliday2.Text = totals.ApprOTHoliday2;

                    this.lblTimeWork.Text = totals.TimeWork;
                    this.lblTimeLate.Text = totals.TimeLate;
                    this.lblTimeEarly.Text = totals.TimeEarly;
                    this.lblTimeOut.Text = totals.TimeOut;

                    this.lblOTEarly.Text = totals.OTEarly;
                    this.lblOTNormal1.Text = totals.OTNormal1;
                    this.lblOTNormal2.Text = totals.OTNormal2;
                    this.lblOTLate.Text = totals.OTLate;
                    this.lblOTHoliday1.Text = totals.OTHoliday1;
                    this.lblOTHoliday2.Text = totals.OTHoliday2;

                    this.lblTotalOT.Text = totals.TotalOT;
                    this.lblTotalWork.Text = totals.TotalWork;
                }
                else
                {
                    this.ClearDataRouter();
                }

                if (this.IsAdmin() || this.LoginInfo.User.StaffID != int.Parse(this.cmbStaff.SelectedValue))
                {
                    base.HiddenLink(this.btnSubmit, true);
                }
                else
                {
                    base.HiddenLink(this.btnSubmit, false);
                }
                base.HiddenLink(this.btnCancel, true);
            }
        }

        /// <summary>
        /// ClearDataRouter
        /// </summary>
        private void ClearDataRouter()
        {
            this.lblTimeWorkBase.Text = "&nbsp;";
            this.lblApprLate.Text = "&nbsp;";
            this.lblApprLeaveEarly.Text = "&nbsp;";
            this.lblApprOut.Text = "&nbsp;";
            this.lblVacationLeaves.Text = "&nbsp;";
            this.lblAbsenceLeaves.Text = "&nbsp;";

            this.lblApprOTEarly.Text = "&nbsp;";
            this.lblApprOTNormal1.Text = "&nbsp;";
            this.lblApprOTNormal2.Text = "&nbsp;";
            this.lblApprOTLate.Text = "&nbsp;";
            this.lblApprOTHoliday1.Text = "&nbsp;";
            this.lblApprOTHoliday2.Text = "&nbsp;";

            this.lblTimeWork.Text = "&nbsp;";
            this.lblTimeLate.Text = "&nbsp;";
            this.lblTimeEarly.Text = "&nbsp;";
            this.lblTimeOut.Text = "&nbsp;";

            this.lblOTEarly.Text = "&nbsp;";
            this.lblOTNormal1.Text = "&nbsp;";
            this.lblOTNormal2.Text = "&nbsp;";
            this.lblOTLate.Text = "&nbsp;";
            this.lblOTHoliday1.Text = "&nbsp;";
            this.lblOTHoliday2.Text = "&nbsp;";

            this.lblTotalOT.Text = "&nbsp;";
            this.lblTotalWork.Text = "&nbsp;";
        }

        /// <summary>
        /// Stored work date error
        /// </summary>
        /// <param name="items">List<WorkInfo></param>
        private void StoredWorkDateError(List<WorkInfo> items)
        {
            List<DateTime> lst = new List<DateTime>();
            foreach (var item in items)
            {
                if (!item.IsValidData)
                {
                    lst.Add(item.WorkDate);
                }
            }
            this.ListWorkDateErr = lst;
        }

        /// <summary>
        /// Check work date submit
        /// </summary>
        /// <param name="applyStatus"></param>
        /// <param name="dataItem"></param>
        private void CheckWorkDateSubmit(IList<WorkAppliedList> applyStatus, WorkInfo dataItem)
        {
            if (dataItem.WorkTypeOfDay == (int)TypeOfDay.DayOff || dataItem.WorkTypeOfDay == (int)TypeOfDay.HalfDayOff)
            {
                if (applyStatus.Count > 0 && applyStatus.Any(m=>m.ApplyStatus == -1))
                {
                    this.ListWorkDateSubmitErr.Add(dataItem.WorkDate);
                }
            }
        }

        /// <summary>
        /// Init combox user
        /// </summary>
        private void SetDataStaffCbo()
        {
            IList<DropDownModel> list;
            using (DB db = new DB())
            {
                StaffService _staffService = new StaffService(db);
                list = _staffService.GetDataForDropdown(int.Parse(this.cmbDept.SelectedValue), this.dtDate.Value, true);
            }

            this.cmbStaff.DataSource = list;
            this.cmbStaff.DataValueField = "Value";
            this.cmbStaff.DataTextField = "DisplayName";
            this.cmbStaff.DataBind();
        }

        /// <summary>
        /// Init combox department
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            IList<DropDownModel> list;
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                list = deptSer.GetDataForDropdown(true);
            }

            this.cmbDept.DataSource = list;
            this.cmbDept.DataValueField = "Value";
            this.cmbDept.DataTextField = "DisplayName";
            this.cmbDept.DataBind();
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using System.Collections;
using DailyReport.Models;
using DailyReport.DAC;

namespace DailyReport.Work
{
    public partial class FrmWorkList : FrmBaseList
    {
        private const string CONST_DANGER_TEXT = "Deleted";

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Work";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = CONST_DANGER_TEXT;
            
            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtApproveNo.MaxLength = T_Approve.APPROVE_NO_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Work);
            if (!this._authority.IsWorkView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["ID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.dtConfirmDateFrom.ID, this.dtConfirmDateFrom.Value);
            hash.Add(this.dtConfirmDateTo.ID, this.dtConfirmDateTo.Value);
            hash.Add(this.cmbStatus.ID, this.cmbStatus.SelectedValue);
            hash.Add(this.cmbType.ID, this.cmbType.SelectedValue);
            hash.Add(this.cmbInvalidData.ID, this.cmbInvalidData.SelectedValue);
            
            
            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            if (data[this.dtConfirmDateFrom.ID] != null)
            {
                this.dtConfirmDateFrom.Value = DateTime.Parse(data[this.dtConfirmDateFrom.ID].ToString());
            }
            if (data[this.dtConfirmDateTo.ID] != null)
            {
                this.dtConfirmDateTo.Value = DateTime.Parse(data[this.dtConfirmDateTo.ID].ToString());
            }
            this.cmbStatus.SelectedValue = data[this.cmbStatus.ID].ToString();
            this.cmbType.SelectedValue = data[this.cmbType.ID].ToString();
            this.cmbInvalidData.SelectedValue = data[this.cmbInvalidData.ID].ToString();    

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //this.dtConfirmDateFrom.Value = DateTime.Now.AddMonths(-3);
            //this.dtConfirmDateTo.Value = DateTime.Now;

            // Default Type Day off
            //this.hdTypeDefault.Value = "-1";//this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_TYPE_DAYOFF);
            // Default Status Approve
            this.hdStatusDefault.Value = "-1";//this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
            // Default Invalid Data
            this.hdInValidDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Type
            this.InitComboboxType();

            //Status
            this.InitCombobox(this.cmbStatus, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);

            //Invalid
            this.InitCombobox(this.cmbInvalidData, M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Set Default Select index
            this.cmbInvalidData.SelectedValue = this.hdInValidDefault.Value;
            this.cmbStatus.SelectedValue = this.hdStatusDefault.Value;
           // this.cmbType.SelectedValue = this.hdTypeDefault.Value;

            // header grid
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            base.DisabledLink(this.btnNew, !base._authority.IsWorkNew);
        }


        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void InitComboboxType()
        {
            // init combox 
            //IList<DropDownModel> lstDB = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_TYPE_DAYOFF, true);
            //this.cmbType.DataSource = (from l in lstDB
            //                           where !l.Value.Equals(M_Config_H.CONFIG_CD_DEFAULT_TYPE_NORMAL_WORK)
            //                           select new DropDownModel
            //                           {
            //                               DataboundItem = l.DataboundItem,
            //                               DisplayName = l.DisplayName,
            //                               Value = l.Value
            //                           }).ToList();
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                IList<DropDownModel> lstDB = typeSer.GetDataForDropDownList(true);
                this.cmbType.DataSource = lstDB;
            }
            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Get Model For Search
        /// </summary>
        /// <returns></returns>
        private WorkConditionSearch GetModelCondition()
        {
            WorkConditionSearch model = new WorkConditionSearch();
            model.Type = short.Parse(this.cmbType.SelectedValue);
            model.Status = short.Parse(this.cmbStatus.SelectedValue);
            model.ConfirmDateFrm = this.dtConfirmDateFrom.Value;
            model.ConfirmDateTo = this.dtConfirmDateTo.Value;
            model.UserID = LoginInfo.User.ID;
            model.ApproveNo = this.txtApproveNo.Text;
            model.Invalid =  short.Parse(this.cmbInvalidData.SelectedValue);
            return model;
        }

        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int totalRow = 0;
            this.GetColorClass(1);
            IList<WorkResultSearch> lstResult = null;

            //Get data
            using (DB db = new DB())
            {
                ApproveService appSer = new ApproveService(db);
                totalRow = appSer.GetTotalRow(this.GetModelCondition());

                lstResult = appSer.GetListByCond(this.GetModelCondition(),
                                                         pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (lstResult == null || lstResult.Count == 0)
            {
                this.rptWorkList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstResult[lstResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Approve No.", "Status", "Type", "Confirm Date", "Start Date", "End Date", "Content" });

                // detail
                this.rptWorkList.DataSource = lstResult;
            }

            this.rptWorkList.DataBind();
        }


        #endregion        

    }
}
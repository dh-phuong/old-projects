﻿using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Linq;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Globalization;

namespace DailyReport.Work
{
    /// <summary>
    /// FrmDailyDetail
    /// ISV-TRAM 2015/03/02
    /// </summary>
    public partial class FrmDailyDetail : FrmBaseDetail
    {

        #region Property

        public const int DEFAULT_NORMAL_WORK_ID = -1;

        private string URL_LIST
        {
            get { return ViewState["_urlTransfer"].ToString(); }
            set { ViewState["_urlTransfer"] = value; }
        }

        /// <summary>
        /// Get or set DailyID
        /// </summary>
        private int DailyID
        {
            get { return ViewState["_dailyID"] == null ? -1 : (int)ViewState["_dailyID"]; }
            set { ViewState["_dailyID"] = value; }
        }

        /// <summary>
        /// Get or set TypeApplyID
        /// </summary>
        public int TypeApplyID
        {
            get { return ViewState["TypeApplyID"] == null ? -1 : (int)ViewState["TypeApplyID"]; }
            set { ViewState["TypeApplyID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        private DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        private M_UserInfo ApplyUser
        {
            get { return (M_UserInfo)ViewState["ApplyUser"]; }
            set { ViewState["ApplyUser"] = value; }
        }

        #endregion

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Daily);
            if (!this._authority.IsDailyView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {
                    URL_LIST = this.PreviousPageViewState["_urlTransfer"].ToString();

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["_dailyID"] == null)
                    {
                        //Init data
                        this.InitData();

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DailyID = int.Parse(PreviousPageViewState["_dailyID"].ToString());
                        T_Daily data = this.GetDailyByID(this.DailyID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                //else
                //{
                //    //Set mode
                //    this.ProcessMode(Mode.Insert);
                //}
            }
        }

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Daily";
            base.FormSubTitle = "Detail";

            //Init Max Length                        
            this.txtContent.MaxLength = T_Daily.CONTENT_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);

        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Init data
            this.InitData();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get data
            T_Daily data = this.GetDailyByID(this.DailyID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Daily data = this.GetDailyByID(this.DailyID);

            //Check data
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        // <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Daily data = this.GetDailyByID(this.DailyID);

            if (!this.Mode.Equals(Mode.View) && !this.Mode.Equals(Mode.Insert))
            {
                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Daily data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetDailyByID(this.DailyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete vendor
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;
                case Utilities.Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetDailyByID(this.DailyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }

        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get vendor
            T_Daily data = this.GetDailyByID(this.DailyID);
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            var temp = this.PreviousPageViewState["_dateNew"];
            var _date = temp == null ? DateTime.Now : DateTime.Parse(temp.ToString());
            var _userCd = this.PreviousPageViewState["_userNew"].ToString();

            UserService _ser = new UserService();
            //this.ApplyUser = _ser.GetByUserCD(_userCd);

            this.dtWorkDate.Value = _date;
            this.txtUser.Value = this.ApplyUser.UserName1;

            this.txtStartHour.Text = T_Daily.START_HOUR_DEFAULT.ToString().PadLeft(2, '0');
            this.txtStartMin.Text = T_Daily.START_MINUTE_DEFAULT.ToString().PadLeft(2, '0');
            this.txtEndHour.Text = T_Daily.END_HOUR_DEFAULT.ToString().PadLeft(2, '0');
            this.txtEndMin.Text = T_Daily.END_MINUTE_DEFAULT.ToString().PadLeft(2, '0');
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.txtContent.Value = string.Empty;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {

                case Mode.Insert:
                case Mode.Copy:
                    this.dtWorkDate.ReadOnly = true;
                    this.txtStartHour.SetReadOnly(false);
                    this.txtStartMin.SetReadOnly(false);
                    this.txtEndHour.SetReadOnly(false);
                    this.txtEndMin.SetReadOnly(false);

                    this.txtContent.ReadOnly = false;
                    this.txtType.ReadOnly = false;
                    break;

                case Mode.Update:
                    this.dtWorkDate.ReadOnly = true;
                    this.txtStartHour.SetReadOnly(false);
                    this.txtStartMin.SetReadOnly(false);
                    this.txtEndHour.SetReadOnly(false);
                    this.txtEndMin.SetReadOnly(false);
                    this.txtContent.ReadOnly = false;
                    this.txtType.ReadOnly = false;
                    break;

                default:
                    this.dtWorkDate.ReadOnly = true;
                    this.txtStartHour.SetReadOnly(true);
                    this.txtStartMin.SetReadOnly(true);
                    this.txtEndHour.SetReadOnly(true);
                    this.txtEndMin.SetReadOnly(true);
                    this.txtContent.ReadOnly = true;
                    this.txtType.ReadOnly = true;

                    if (this.TypeApplyID.Equals(DEFAULT_NORMAL_WORK_ID) && LoginInfo.Department.ID.Equals(this.ApplyUser.DepartmentID))
                    {
                        base.DisabledLink(this.btnDelete, !base._authority.IsDailyDelete);
                        base.DisabledLink(this.btnEdit, !base._authority.IsDailyEdit);
                        base.DisabledLink(this.btnCopy, !base._authority.IsDailyCopy);
                        base.DisabledLink(this.btnNew, !base._authority.IsDailyNew);
                    }
                    else
                    {
                        base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnCopy, true);
                        base.DisabledLink(this.btnNew, true);
                    }


                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Daily daily)
        {
            //Show data
            if (daily != null)
            {
                M_User user = new M_User();
                UserService userSer = new UserService();

                user = userSer.GetByID(daily.UserID);
                if (user != null)
                {
                    this.txtUser.Value = user.UserName1;
                }

                //this.ApplyUser = user;
                this.dtWorkDate.Value = daily.WorkDate;

                this.txtStartHour.Text = daily.StartHour.ToString().PadLeft(2, '0');
                this.txtStartMin.Text = daily.StartMinute.ToString().PadLeft(2, '0');
                this.txtEndHour.Text = daily.EndHour.ToString().PadLeft(2, '0');
                this.txtEndMin.Text = daily.EndMinute.ToString().PadLeft(2, '0');
                this.TypeApplyID = daily.TypeApplyID;

                FormTypeService FSer = new FormTypeService();
                M_Form_Type m_type = FSer.GetByID(daily.TypeApplyID);

                if (m_type != null)
                {
                    this.txtType.Text = m_type.TypeName;
                }
                this.txtContent.Value = daily.Content;


                if (!user.GroupID.Equals(this.LoginInfo.GroupUser.ID) && this.TypeApplyID.Equals(DEFAULT_NORMAL_WORK_ID))
                {
                    base.DisabledLink(this.btnDelete, true);
                }
                else
                {
                    base.DisabledLink(this.btnDelete, false);
                }

                this.DailyID = daily.ID;
                this.OldUpdateDate = daily.UpdateDate;
            }
        }

        /// <summary>
        /// Get Daily by DailyID
        /// </summary>
        /// <param name="dailyID">Daily id</param>
        /// <returns>Daily data</returns>
        private T_Daily GetDailyByID(int dailyID)
        {
            using (DB db = new DB())
            {
                DailyService service = new DailyService(db);

                //Get User
                return service.GetByID(dailyID);
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                T_Daily data = new T_Daily();
                data.UserID = this.ApplyUser.ID;
                string date = string.Format("{0:00}", this.dtWorkDate.Value.Value.Day) + "/" + string.Format("{0:00}", this.dtWorkDate.Value.Value.Month) + "/" + string.Format("{0:0000}", this.dtWorkDate.Value.Value.Year);
                data.WorkDate = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                data.TypeApplyID = DEFAULT_NORMAL_WORK_ID;
                data.ApproveID = null;
                data.StartHour = short.Parse(this.txtStartHour.Value.Value.ToString());
                data.StartMinute = short.Parse(this.txtStartMin.Value.Value.ToString());
                data.EndHour = short.Parse(this.txtEndHour.Value.Value.ToString());
                data.EndMinute = short.Parse(this.txtEndMin.Value.Value.ToString());

                data.Content = this.txtContent.Text;
                data.CreateUID = base.LoginInfo.User.ID;
                data.UpdateUID = base.LoginInfo.User.ID;

                //Insert Category
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {

                    DailyService serive = new DailyService(db);

                    //Insert Daily
                    serive.Insert(data);
                    this.DailyID = db.GetIdentityId<T_Daily>();

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_DAILY_UN))
                {
                    this.SetMessage(this.txtStartHour.ID, M_Message.MSG_EXIST_CODE, "Start Hour");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Daily data = this.GetDailyByID(this.DailyID);
                if (data != null)
                {
                    data.StartHour = short.Parse(this.txtStartHour.Value.Value.ToString());
                    data.StartMinute = short.Parse(this.txtStartMin.Value.Value.ToString());
                    data.EndHour = short.Parse(this.txtEndHour.Value.Value.ToString());
                    data.EndMinute = short.Parse(this.txtEndMin.Value.Value.ToString());

                    data.ApproveID = null;
                    data.Content = this.txtContent.Text;
                    data.UpdateDate = this.OldUpdateDate;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Update category
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        DailyService service = new DailyService(db);

                        //Update category
                        if (data.Status == DataStatus.Changed)
                        {
                            ret = service.Update(data);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    DailyService service = new DailyService(db);

                    //Delete Vendor
                    ret = service.Delete(this.DailyID, this.OldUpdateDate);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Work Date
            if (this.dtWorkDate.IsEmpty)
            {
                this.SetMessage("dtWorkDate", M_Message.MSG_REQUIRE, "Work Date");
            }

            //Start Hour
            if (string.IsNullOrEmpty(this.txtStartHour.Value.ToString()))
            {
                this.SetMessage("txtStartHour", M_Message.MSG_REQUIRE, "Start Hour");
            }

            //Start Minute
            if (string.IsNullOrEmpty(this.txtStartMin.Value.ToString()))
            {
                this.SetMessage("txtStartMin", M_Message.MSG_REQUIRE, "Start Minute");
            }

            //End Hour
            if (string.IsNullOrEmpty(this.txtEndHour.Value.ToString()))
            {
                this.SetMessage("txtEndHour", M_Message.MSG_REQUIRE, "End Hour");
            }

            //End Minute
            if (string.IsNullOrEmpty(this.txtEndMin.Value.ToString()))
            {
                this.SetMessage("txtEndMin", M_Message.MSG_REQUIRE, "End Minute");
            }

            //Content
            if (this.txtContent.IsEmpty)
            {
                this.SetMessage("txtContent", M_Message.MSG_REQUIRE, "Content");
            }

            if (!base.HaveError)
            {
                int startHour = int.Parse(this.txtStartHour.Value.ToString());
                int startMinute = int.Parse(this.txtStartMin.Value.ToString());
                int endHour = int.Parse(this.txtEndHour.Value.ToString());
                int endMinute = int.Parse(this.txtEndMin.Value.ToString());

                DateTime startTime = new DateTime(this.dtWorkDate.Value.Value.Year, this.dtWorkDate.Value.Value.Month, this.dtWorkDate.Value.Value.Day, startHour, startMinute, 0);
                DateTime endTime = new DateTime(this.dtWorkDate.Value.Value.Year, this.dtWorkDate.Value.Value.Month, this.dtWorkDate.Value.Value.Day, endHour, endMinute, 0);

                //Work Time          
                if (startTime != null && endTime != null)
                {

                    if (startHour > endHour)
                    {
                        this.SetMessage(this.txtStartHour.ID, M_Message.MSG_LESS_THAN_EQUAL, "Start Hour", "End Hour");
                    }

                    if (startHour.Equals(endHour) && startMinute >= endMinute)
                    {
                        this.SetMessage(this.txtStartMin.ID, M_Message.MSG_LESS_THAN_EQUAL, "Start Minute", "End Minute");
                    }

                }
            }

            //Check error
            return !base.HaveError;
        }
    }
}
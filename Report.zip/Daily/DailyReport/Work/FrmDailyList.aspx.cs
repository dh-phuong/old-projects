﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Web.UI.HtmlControls;
using System.Linq;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.Work
{
    /// <summary>
    /// FrmDailyList
    /// ISV-TRAM 2015/03/02
    /// </summary>
     public partial class FrmDailyList: FrmBaseList
    {
        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// User
        /// </summary>
        public string User;
      
        /// <summary>
        /// WorkDate
        /// </summary>
        public string WorkDate;

        public IList<M_TypeApply> TypeNameList;
        public IList<SummaryDailyDataSource> SummaryDataSource;
        public IList<string> DetailInfo;
        private int startHourDefault;
        private int startMinuteDefault;
        private int endHourDefault;
        private int endMinuteDefault;
                         
        #endregion
         
        /// <summary>
        /// On Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Daily";
            base.FormSubTitle = "List";
            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
        }

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Daily );
            if (!this._authority.IsDailyView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                ////Show data on grid
                this.LoadDataGrid();
                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.SaveCondSearch();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //DailyID
            this.ViewState["DataID"] = e.CommandArgument;
           
            //Save condition
            this.SaveCondSearch();
        }

        /// <summary>
        /// Event Daily ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptDaily_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            DailyDataSource dailyDetail = (DailyDataSource)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptDailyChild");

            //----------------Set data daily detail----------------------//

            rptDetail.DataSource = dailyDetail.DailyDetailList;
            rptDetail.DataBind();
            //----------------End Set data daily detail-----------------//
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                this.Collapse = "in";
                return;
            }
            this.WorkDate = string.Format("{0:MM/yyyy}", this.dtMonthYear.Value);

            M_User user=new M_User() ;
            UserService userSer= new UserService();
            user = userSer.GetByID(int.Parse ( cmbUser.SelectedValue.ToString() ));
            if (user != null)
            {
                this.User = user.UserName1;   
            }

            // Refresh load grid
            this.LoadDataGrid();

            this.Collapse = "in";
        }

        #endregion

        #region Method
        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.dtMonthYear.Value = DateTime.Now;

            // Default data valid

            //Set MonthYear default
            this.hdMonthYearDefault.Value = string.Format("{0:00}", DateTime.Now.Month) + "/" + string.Format("{0:0000}", DateTime.Now.Year);

            //Set User default
            IList<int> adminList = this.GetListAdminIDFromConfig();
            if(adminList != null && adminList.Count >0 )
            {
                //If User id 'admin'
                if (adminList.Contains(this.LoginInfo.User.ID))
                {
                    IList<DropDownModel> listUser= this.GetDataForDropdownList();
                    if (listUser != null && listUser.Count >0 )
                    {
                        //Get the first value of dropdown
                        this.hdUserDefault.Value = listUser[0].Value;
                    }
                }
                else
                {
                    //Get the login user
                    this.hdUserDefault.Value = this.LoginInfo.User.ID.ToString();    
                }
            
            }
            else
            {
                this.hdUserDefault.Value = this.LoginInfo.User.ID.ToString();    
            }
            
            //Set data for combobox
            this.SetDataCombobox(this.cmbUser, this.LoginInfo.User.ID.ToString()  );
            this.cmbUser.SelectedValue = this.LoginInfo.User.ID.ToString() ;

            this.WorkDate = string.Format("{0:MM/yyyy}", this.dtMonthYear.Value);

            M_User user = new M_User();
            UserService userSer = new UserService();
            user = userSer.GetByID(int.Parse(cmbUser.SelectedValue.ToString()));
            if (user != null)
            {
                this.User = user.UserName1;
            }

            M_TypeApply typeApply = new M_TypeApply();
            typeApply = this.GetTypeApplyByID(M_TypeApply.DEFAULT_NORMAL_WORK_ID);
            if (typeApply != null)
            {
                startHourDefault = typeApply.MinStartHour;
                startMinuteDefault = typeApply.MinStartMinute;
                endHourDefault = typeApply.MaxEndHour;
                endMinuteDefault = typeApply.MaxEndMinute;
            }
            
            //Disable button
            base.DisabledLink(this.btnNew, !base._authority.IsDailyNew);
            
        }

        /// <summary>
        /// GetTypeApplyByID
        /// </summary>
        /// <returns></returns>
        private M_TypeApply GetTypeApplyByID(int id)
        {
            M_TypeApply typeApp = new M_TypeApply();
            TypeApplyService typeAppSer = new TypeApplyService();
            typeApp = typeAppSer.GetByID(id);
            return typeApp;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList()
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                IList<DropDownModel> listUser = userSer.GetAll();
                return listUser;
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataCombobox(DropDownList ddl, string defaultVal)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList();
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
            ddl.SelectedValue = defaultVal;
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondSearch()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.dtMonthYear.ID, this.dtMonthYear.Value);
            hash.Add(this.cmbUser.ID, this.cmbUser.SelectedValue);

            hash.Add("hdMonthYearDefault", this.hdMonthYearDefault.Value);
            hash.Add("hdUserDefault", this.hdUserDefault.Value);
            this.ViewState["Condition"] = hash;
            
            this.WorkDate = string.Format("{0:MM/yyyy}", this.dtMonthYear.Value);
            M_User user = new M_User();
            UserService userSer = new UserService();
            user = userSer.GetByID(int.Parse(cmbUser.SelectedValue.ToString()));
            if (user != null)
            {
                this.User = user.UserName1;
            }
        }

        /// <summary>
        /// Get condition Save
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.dtMonthYear.Value = null;
            if (data.ContainsKey(this.dtMonthYear.ID))
            {
                if (data[this.dtMonthYear.ID] != null)
                {
                    this.dtMonthYear.Value = (DateTime)data[this.dtMonthYear.ID];
                    this.hdMonthYearDefault.Value = (string)data["hdMonthYearDefault"];
                }
            }
            this.cmbUser.SelectedValue = data[this.cmbUser.ID].ToString();
            this.hdUserDefault.Value = (string)data["hdUserDefault"];
            this.WorkDate = string.Format("{0:MM/yyyy}", this.dtMonthYear.Value);
            M_User user = new M_User();
            UserService userSer = new UserService();
            user = userSer.GetByID(int.Parse(cmbUser.SelectedValue.ToString()));
            if (user != null)
            {
                
                this.User = user.UserName1;
            }

        }

        /// <summary>
        /// load data gird
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid()
        {
        
            IList<DailyInfo> listDaily = new List<DailyInfo>();

            IList<DailyDataSource> listDataSource = new List<DailyDataSource>();
            SummaryDailyDataSource summaryDataSource = new SummaryDailyDataSource();
            IList<SummaryDailyDataSource> listSummaryDataSource = new List<SummaryDailyDataSource>();
                        
            IList<string> detailInfoList= new List<string>();
            IList<string> typeNameList= new List<string>();
            
            string offDayDetail = string.Empty;
 
            try
                {
                    using (DB db = new DB())
                    {
                        DailyService dailyService = new DailyService(db);
                        int userID = int.Parse(this.cmbUser.SelectedValue.ToString());
                        listDaily = dailyService.GetByCondition(this.dtMonthYear.Value.Value, userID);
                    }

                    int dayOfMonth = DateTime.DaysInMonth(this.dtMonthYear.Value.Value.Year, this.dtMonthYear.Value.Value.Month);
                    for (int day = 1; day <= dayOfMonth; day++)
                    {
                        DailyDataSource item = new DailyDataSource();
                        DateTime date = new DateTime(this.dtMonthYear.Value.Value.Year, this.dtMonthYear.Value.Value.Month, day);
                        DayOfWeek dayOfWeek= date.DayOfWeek;
                        M_Holiday holiday=new M_Holiday() ;
                        HolidayService holidaySer = new HolidayService();
                        holiday = holidaySer.GetByDay(date.Year, date.Month, date.Day);
                         
                        item.WorkDate = string.Format("{0:MM月dd日}", date);
                        if (dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday  )
                        {
                            item.Color = (int)ColorList.Danger;
                            item.IsHoliday = 1;
                        }
                        else if (holiday != null)
                        {
                            item.Color = (int)ColorList.Danger;
                            item.WorkDate = item.WorkDate + " " + holiday.HolidayName ;
                            item.IsHoliday = 1;
                        }
                        else
                        {
                            item.Color = -1;
                            item.IsHoliday = 0;
                        }

                        item.DailyDetailList = (from dayInfo in listDaily
                                                where dayInfo.WorkDate.Day.Equals(day)
                                                select dayInfo).ToList();

                        if (item.DailyDetailList != null)
                        {
                            this.LoadDetailData(date, item.DailyDetailList);
                            listDataSource.Add(item);
                        }
                              
                    }

                    //Set title summary info
                    IList<M_TypeApply> typeApplyList = new List<M_TypeApply>();
                    TypeApplyService typeApplySer = new TypeApplyService();
                    typeApplyList = typeApplySer.GetDisplayList();
                    TypeNameList = typeApplyList;
                    int index = 0;
                    for (int i = 0; i < typeApplyList.Count; i++)
                    {
                        
                        if (typeApplyList[i].TimeUnit.Equals(TimeUnitType.Day))
                        {

                            index = i;
                            break;
                        }
                    }

                    //Set Detail Info
                    IList<DailyInfo> detailList = new List<DailyInfo>();
                    string sTab = "<br/><hr/>";
                    for (int i = 0; i < typeApplyList.Count; i++)
                    {
                        string strDetailInfo = string.Empty;
                        foreach (DailyDataSource daily in listDataSource)
                        {
                            detailList = (from detailInfo in daily.DailyDetailList
                                          where detailInfo.TypeApplyID.Equals(typeApplyList[i].ID)
                                          select detailInfo).ToList();
                            foreach (DailyInfo row in detailList)
                            {
                                strDetailInfo = strDetailInfo + string.Format("{0:dd/MM/yyyy}", row.WorkDate) + " " + row.StartHour + ":" + row.StartMinute + "～" + row.EndHour + ":" + row.EndMinute + sTab;
                            }
                        }

                        if (string.IsNullOrEmpty(strDetailInfo))
                        {
                            detailInfoList.Add(strDetailInfo);
                        }
                        else
                        {
                            detailInfoList.Add(strDetailInfo.Substring(0, strDetailInfo.Length - sTab.Length));
                        }

                    }

                    DetailInfo = detailInfoList;
                

                    //Set summary info
                    summaryDataSource.WorkDate = string.Format("{0:MM/yyyy}", this.dtMonthYear.Value);
                    summaryDataSource.UserID = int.Parse(cmbUser.SelectedValue);
                    
                    using (DB db = new DB())
                    {
                        DailyService dailyService = new DailyService(db);
                        int userID = int.Parse(this.cmbUser.SelectedValue.ToString());
                        listSummaryDataSource = dailyService.GetTotalTimeOfTypeApply(this.dtMonthYear.Value.Value, userID);
                        SummaryDataSource = listSummaryDataSource;
                        decimal leaveDatyTotal=dailyService.GetTotalLeaveDay(this.dtMonthYear.Value.Value
                                                        , userID
                                                        , typeApplyList[index].ID
                                                        , T_Daily.END_HOUR_NOON_DEFAULT
                                                        , T_Daily.END_MINUTE_NOON_DEFAULT
                                                        , T_Daily.START_HOUR_AFTERNOON_DEFAULT
                                                        , T_Daily.START_MINUTE_AFTERNOON_DEFAULT
                                                        , (int) TimeUnitType.Day);

                    
                        if (summaryDataSource != null)
                        {

                            listSummaryDataSource[index].LeaveDayTotal = leaveDatyTotal;
                            listSummaryDataSource[index].TimeUnit =(int) TimeUnitType.Day;
                        }
                        
                    }
                    

                   
                    //Set datasource for daily info
                    this.rptDaily.DataSource = listDataSource;
                    this.rptDaily.DataBind();
   
                }
                catch (Exception)
                {

                }

        }

        /// <summary>
        /// LoadDetailData
        /// </summary>
        /// <param name="date"></param>
        /// <param name="listDailyInfo"></param>
        private void LoadDetailData(DateTime date,IList<DailyInfo> listDailyInfo)
        {
            foreach (DailyInfo model in listDailyInfo)
            {
                string workDate = string.Format("{0:MM月dd日}", date);
                model.WorkDate = DateTime.ParseExact(workDate, "MM月dd日", new System.Globalization.CultureInfo("ja-JP"));

                model.StartHour = string.Format("{0:00}", int.Parse(model.StartHour));
                model.StartMinute = string.Format("{0:00}", int.Parse(model.StartMinute));
                model.EndHour = string.Format("{0:00}", int.Parse(model.EndHour));
                model.EndMinute = string.Format("{0:00}", int.Parse(model.EndMinute));
                model.Collapsed = "in";
            }
        }
         
        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Month Year
            if (this.dtMonthYear.IsEmpty)
            {
                this.SetMessage("dtMonthYear", M_Message.MSG_REQUIRE, "Year Month");
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Get list AdminID from config
        /// </summary>
        /// <returns>List of UserID</returns>
        private IList<int> GetListAdminIDFromConfig()
        {
             IList<M_Config_D> config_DList = new List<M_Config_D>();
             IList<int> adminIDList = new List<int>();
             using (DB db = new DB())
             {
                 Config_DService config_DSer = new Config_DService(db);
                 config_DList = config_DSer.GetListByConfigCd(M_Config_H.CONFIG_GROUP_USERCD_ADMIN);
             }

             foreach (M_Config_D row in config_DList)
             {
                 
                 M_User user = new M_User();
                 UserService userSer = new UserService();
                 user = userSer.GetByUserCD(row.Value3);
                 adminIDList.Add(user.ID);
             }
             return adminIDList;
        }
        #endregion
    }
}
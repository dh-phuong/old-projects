﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;
using System.Data.SqlClient;

namespace DailyReport.Work
{
    public partial class FrmWorkDetail : FrmBaseDetail
    {
        #region Constant

        private const string URL_LIST = "~/Work/FrmWorkList.aspx";

        #endregion

        #region Variant

        /// <summary>
        /// Default Status
        /// </summary>
        private string _defaultStatus;
                
        /// <summary>
        /// Has Approve User
        /// </summary>
        public bool _hasApproveUser;

        public short _approveStatus;

        public bool _isDeleted;

        private int _defaultUnitMinute;
        
        /// <summary>
        /// StatusList
        /// </summary>
        private IList<DropDownModel> _statusList;
        
        /// <summary>
        /// VatTypeList
        /// </summary>
        private IList<DropDownModel> _typeList;

        #endregion

        #region Property

        /// <summary>
        /// Get or set WorkID
        /// </summary>
        public int WorkID
        {
            get { return (int)ViewState["WorkID"]; }
            set { ViewState["WorkID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Init Event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Work";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtMemo.MaxLength = T_Approve.CONTENT_MAX_LENGTH;

            //this.cmbType.SelectedIndexChanged += new EventHandler(cmbType_SelectedIndexChanged);

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);                        
        }

        /// <summary>
        /// Page load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Work);
            if (!this._authority.IsWorkView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            //Get Default Data
            this.GetDefaultData();

            if (!this.IsPostBack)
            {
                this.InitData();
                
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                       // this.ClearValue();
                        //Set Mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get customer data by id
                        this.WorkID = int.Parse(PreviousPageViewState["ID"].ToString());
                        T_Approve app = this.GetWork(this.WorkID);

                        //Check customer
                        if (app != null)
                        {
                            //Show data
                            this.ShowData(app);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    this.ClearValue();
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Process data Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
             switch (this.Mode)
             {
                 case DailyReport.Utilities.Mode.Insert:
                 case DailyReport.Utilities.Mode.Copy:

                     //Insert Data
                     if (this.InsertData())
                     {
                         //Get Approve data by code
                         T_Approve app = this.GetWork(this.WorkID);

                         //Show data
                         this.ShowData(app);

                         //Set Mode
                         this.ProcessMode(Mode.View);

                         //Set Success
                         this.Success = true;
                     }
                     break;

                 case DailyReport.Utilities.Mode.Delete:

                     //Delete Data
                     if (this.DeleteData())
                     {
                         Server.Transfer(URL_LIST);
                     }
                     else
                     {                         
                         //Set Mode
                         this.ProcessMode(Mode.View);
                     }
                     break;

                 case DailyReport.Utilities.Mode.Confirm:
                     //Confirm Data
                     if (this.ConfirmData())
                     {
                         T_Approve app = this.GetWork(this.WorkID);

                         //Show data
                         this.ShowData(app);

                         //Set Mode
                         this.ProcessMode(Mode.View);

                         //Set Success
                         this.Success = true;
                     }
                     
                     break;

                 default:

                     //Update Data
                     if (this.UpdateData())
                     {
                         T_Approve app = this.GetWork(this.WorkID);

                         //Show data
                         this.ShowData(app);

                         //Set Mode
                         this.ProcessMode(Mode.View);

                         //Set Success
                         this.Success = true;
                     }
                    
                     break;
             }
        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get Approve
            T_Approve app = this.GetWork(this.WorkID);

            //Check Approve
            if (app != null)
            {                
                //Show data
                this.ShowData(app);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Back Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Approve app = this.GetWork(this.WorkID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(app);

                 //Set Mode
                 this.ProcessMode(Mode.View);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Copy click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Approve app = this.GetWork(this.WorkID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(app);

                 //Set Mode
                 this.ProcessMode(Mode.Copy);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Confirm Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {           
            //Get Approve
            T_Approve app = this.GetWork(this.WorkID);

            //Check Approve
            if (app != null)
            {
                //Set Model
                this.Mode = Mode.Confirm;

                //Fill List Approve
                this.FillDataApproveList(this.WorkID);

                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        
        /// <summary>
        /// Delete Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;
            //Fill List Approve
            this.FillDataApproveList(this.WorkID);

            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Edit Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Approve
             T_Approve app = this.GetWork(this.WorkID);

             //Check Approve
             if (app != null)
             {
                 //Show data
                 this.ShowData(app);

                 //Set Mode
                 this.ProcessMode(Mode.Update);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Insert Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Fill List Approve
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue));

            //Check input
              if (!this.CheckInput())
              {
                  return;
              }

              //Show question insert
              base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// New Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Update Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Fill List Approve
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()));

            //Check input
            if (!this.CheckInput())
             {
                 return;
             }

             //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// ItemDataBound Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptApproveList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            ApproveListWork Detail = (ApproveListWork)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptApproveChild");

            //----------------Set data detail----------------------//

            rptDetail.DataSource = Detail.DetailList;
            rptDetail.DataBind();
            //----------------End Set data detail-----------------//
        }

        /// <summary>
        /// cmbType SelectedIndexChanged Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetDisableDateByType(int.Parse(this.cmbType.SelectedValue.ToString()));
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue));
        }

        /// <summary>
        /// Start Date Text Changed Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void dtStartDate_TextChanged(object sender, EventArgs e)
        {           
            if (!this.dtEndDate.Enabled)
            {
                this.dtEndDate.Value = this.dtStartDate.Value;
            }
        }
        
        #endregion

        #region Methods

        /// <summary>
        /// Init Data
        /// </summary>
        public void InitData()
        {
            this.dtStartDate.Value = DateTime.Now;
            this.dtEndDate.Value = DateTime.Now;

            this._isDeleted = false;
            this._approveStatus = (short)StatusApprove.None;
            this._hasApproveUser = false;
            this.chkDeletedData.Checked = false;
            this.InitCombobox(this.cmbStatus, this._statusList, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
            this.InitComboboxType();
            this.txtUserName.Text = this.LoginInfo.User.UserName1;
            this.cmbStatus.SelectedValue = "1";
           
            //Set disable Control Date
            this.SetDisableDateByType(int.Parse(this.cmbType.SelectedValue.ToString()));
        }

        /// <summary>
        /// Set Disable Control Date By Type
        /// </summary>
        private void SetDisableDateByType(int typeID)
        {            
            M_TypeApply type = this.GetTypeApplyByID(typeID);
            if (type != null)
            {
                this.InitComboHour(this.cmbHourStart,type.MinStartHour, type.MaxEndHour);
                this.InitComboMinute(this.cmbMinuteStart);
                this.InitComboHour(this.cmbHourEnd, type.MinStartHour, type.MaxEndHour);
                this.InitComboMinute(this.cmbMinuteEnd);

                this.dtEndDate.Enabled = true;
                this.cmbHourStart.Enabled = true;
                this.cmbHourEnd.Enabled = true;
                this.cmbMinuteEnd.Enabled = true;
                this.cmbMinuteStart.Enabled = true;
            }
        }

        /// <summary>
        /// Init combobox Hour
        /// </summary>
        /// <param name="ddlHour"></param>
        private void InitComboHour(DropDownList ddlHour, int minHour, int maxHour)
        {
            IList<DropDownModel> lstDay = new List<DropDownModel>();
            for (int i = minHour; i <= maxHour; i++)
            {
                DropDownModel item = new DropDownModel();
                item.DisplayName = i.ToString().PadLeft(2, '0');
                item.Value = i.ToString();
                lstDay.Add(item);
            }
            ddlHour.DataSource = lstDay;
            ddlHour.DataValueField = "Value";
            ddlHour.DataTextField = "DisplayName";
            ddlHour.DataBind();
        }

        /// <summary>
        /// Init combobox Minute
        /// </summary>
        /// <param name="ddlMinute"></param>
        private void InitComboMinute(DropDownList ddlMinute)
        {
            IList<DropDownModel> lstDay = new List<DropDownModel>();

            int maxMinuteCal = 0;
            DropDownModel item0 = new DropDownModel();
            item0.DisplayName = maxMinuteCal.ToString().PadLeft(2, '0');
            item0.Value = maxMinuteCal.ToString();
            lstDay.Add(item0);
            while (maxMinuteCal < 60)
            {
                DropDownModel item = new DropDownModel();
                maxMinuteCal = maxMinuteCal + this._defaultUnitMinute;
                if (maxMinuteCal < 60)
                {
                    item.DisplayName = maxMinuteCal.ToString().PadLeft(2, '0');
                    item.Value = maxMinuteCal.ToString();
                    lstDay.Add(item);
                }
            }
            ddlMinute.DataSource = lstDay;
            ddlMinute.DataValueField = "Value";
            ddlMinute.DataTextField = "DisplayName";
            ddlMinute.DataBind();
        }

        
        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode"></param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Copy)
                    {
                        this.txtApproveNo.Text = string.Empty;
                        this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
                        this.dtConfirmDate.Value = null;
                        this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()));
                    }

                    if (this.Mode == Mode.Insert)
                    {
                        this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()));
                    }
                   
                    this.txtApproveNo.ReadOnly = true;
                    this.cmbStatus.Enabled = false;
                    this.txtUserName.ReadOnly = true;
                    this.dtConfirmDate.Enabled = false;
                    
                    enable = false;

                    break;

                default:

                    this.txtApproveNo.ReadOnly = true;
                    this.cmbStatus.Enabled = false;
                    this.txtUserName.ReadOnly = true;
                    this.dtConfirmDate.Enabled = false;

                    base.DisabledLink(this.btnEdit, !base._authority.IsWorkEdit || this._isDeleted || (this._approveStatus != (short)StatusApprove.New && this._approveStatus != (short)StatusApprove.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);

                    base.DisabledLink(this.btnDelete, !base._authority.IsWorkDelete || this._isDeleted || this._approveStatus == (short)StatusApprove.Complete || this._approveStatus == (short)StatusApprove.Approve || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    base.DisabledLink(this.btnCopy, !base._authority.IsWorkCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsWorkNew );
                    base.DisabledLink(this.btnConfirm, !base._authority.IsWorkConfirm || this._isDeleted || (this._approveStatus != (short)StatusApprove.New && this._approveStatus != (short)StatusApprove.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    enable = true;
                    break;
            }

            //Lock control
            this.txtMemo.ReadOnly = enable;
            this.cmbType.Enabled = !enable;
            this.dtStartDate.Enabled = !enable;
            

            if (this.Mode == Mode.View || this.Mode == Mode.Confirm)
            {
                this.dtEndDate.Enabled = !enable;
                this.cmbHourStart.Enabled = !enable;
                this.cmbMinuteStart.Enabled = !enable;
                this.cmbHourEnd.Enabled = !enable;
                this.cmbMinuteEnd.Enabled = !enable;
            }           
        }

        /// <summary>
        /// FillDataApproveList From Approve List Table
        /// </summary>
        private void FillDataApproveList(int WorkID)
        {
            IList<ApproveWork> appLstWork = this.GetListApproveByWorkID(WorkID);
            IList<ApproveListWork> lstApprove = this.GetListApproveUser(appLstWork);
            if (lstApprove == null || lstApprove.Count == 0)
            {
                this._hasApproveUser = false;
                this.rptApproveList.DataSource = null;
            }
            else
            {               
                this._hasApproveUser = true;
                this.rptApproveList.DataSource = lstApprove;
            }
            this.rptApproveList.DataBind();
        }

        /// <summary>
        /// Get List Approve User (Has List Child)
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        private IList<ApproveListWork> GetListApproveUser(IList<ApproveWork> lstDB)
        {
            IList<ApproveListWork> lstRet = null;
            IList<ApproveWork> lstTemp = null;   
            if (lstDB != null)
            {
                lstRet = new List<ApproveListWork>();
                
                //Get Level of Current User
                var appWorkModel = (from u in lstDB
                              where u.UserID.Equals(this.LoginInfo.User.ID)
                              select new ApproveWork {
                                  ApproveLevel=u.ApproveLevel,
                                  ApproveLevelStr=u.ApproveLevelStr,
                                  RouteMethod=u.RouteMethod,
                                  RouteMethodStr=u.RouteMethodStr,
                                  UserID=u.UserID,
                                  UserName=u.UserName
                              }
                             ).SingleOrDefault();
                 
                if (appWorkModel != null)
                {
                    short userLv = appWorkModel.ApproveLevel;
                    lstTemp = (from l in lstDB
                                       where l.ApproveLevel > userLv | (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) & l.ApproveLevel.Equals(userLv))
                                             & !l.UserID.Equals(this.LoginInfo.User.ID)
                                       select new ApproveWork
                                       {
                                           ApproveDate = l.ApproveDate,
                                           ApproveDateStr = l.ApproveDateStr,
                                           ApproveFlag = l.ApproveFlag,
                                           ApproveFlagStr = l.ApproveFlagStr,
                                           ApproveID = l.ApproveID,
                                           ApproveLevel = l.ApproveLevel,
                                           ApproveLevelStr = l.ApproveLevelStr,
                                           ApproveName = l.ApproveName,
                                           ApproveUID = l.ApproveUID,
                                           Remark = l.Remark,
                                           RouteMethod = l.RouteMethod,
                                           RouteMethodStr = l.RouteMethodStr,
                                           UserID = l.UserID,
                                           UserName = l.UserName
                                       }).ToList();

                    //Current User has Level Max. Get current user
                    if (lstTemp.Count == 0)
                    {
                        lstTemp = (from k in lstDB
                                   where k.UserID.Equals(this.LoginInfo.User.ID)
                                   select new ApproveWork
                                   {
                                       ApproveDate = k.ApproveDate,
                                       ApproveDateStr = k.ApproveDateStr,
                                       ApproveFlag = k.ApproveFlag,
                                       ApproveFlagStr = k.ApproveFlagStr,
                                       ApproveID = k.ApproveID,
                                       ApproveLevel = k.ApproveLevel,
                                       ApproveLevelStr = k.ApproveLevelStr,
                                       ApproveName = k.ApproveName,
                                       ApproveUID = k.ApproveUID,
                                       Remark = k.Remark,
                                       RouteMethod = k.RouteMethod,
                                       RouteMethodStr = k.RouteMethodStr,
                                       UserID = k.UserID,
                                       UserName = k.UserName
                                   }).ToList();
                    }
                }
                if (lstTemp == null || lstTemp.Count==0)
                {
                    lstTemp = new List<ApproveWork>();
                    ((List<ApproveWork>)lstTemp).AddRange(lstDB);
                }
                bool onlyUser = lstTemp.Count == 1;
                var lstLevel = (from lstI in lstTemp
                                group lstI by lstI.ApproveLevel into newGroup
                                select newGroup
                               );
                foreach (var item in lstLevel)
                {
                    ApproveListWork w = new ApproveListWork();
                    w.Level = item.Key;
                    w.LevelStr = onlyUser ? string.Empty : string.Format("Level {0}", w.Level);
                    w.DetailList = new List<ApproveWork>();
                    w.DetailList = (from i in lstTemp
                                    where i.ApproveLevel.Equals(w.Level)
                                    select i
                                    ).ToList();
                    if (w.DetailList.Count == 1)
                    {
                        w.DetailList[0].RouteMethodStr = string.Empty;
                    }
                    lstRet.Add(w);
                }
            }

            return lstRet;
        }

        /// <summary>
        /// GetListApproveWork From Route
        /// </summary>
        /// <returns></returns>
        private IList<ApproveWork> GetListApproveWorkFromRoute(int TypeID)
        {            
            using (DB db = new DB())
            {
                Route_DService rSer = new Route_DService(db);

                //Get Approve List
                return rSer.GetListApproveByTypeID(TypeID);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl,IList<DropDownModel> data, string configCD)
        {
            // init combox 
            ddl.DataSource = data;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void InitComboboxType()
        {
            // init combox 
            //////IList<DropDownModel> lstDB = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_TYPE_DAYOFF, true);
            //this.cmbType.DataSource = (from l in this._typeList
            //                           where !l.Value.Equals(M_Config_H.CONFIG_CD_DEFAULT_TYPE_NORMAL_WORK)
            //                           select new DropDownModel
            //                           {
            //                               DataboundItem = l.DataboundItem,
            //                               DisplayName = l.DisplayName,
            //                               Value = l.Value
            //                           }).ToList();
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                IList<DropDownModel> lstDB = typeSer.GetDataForDropDownList();
                this.cmbType.DataSource = lstDB;
            }
            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();
        }


        /// <summary>
        /// Show data
        /// </summary>
        /// <param name="app"></param>
        private void ShowData(T_Approve app)
        {
            if (app != null)
            {
                this.SetDisableDateByType(app.TypeApplyID);

                this.txtApproveNo.Text = app.ApproveNo;
                this.dtConfirmDate.Value = app.ConfirmDate;
                this.cmbStatus.SelectedValue = app.StatusApprove.ToString();
                this.cmbType.SelectedValue = app.TypeApplyID.ToString();
                this.txtUserName.Text = LoginInfo.User.UserName1;
                this.dtEndDate.Value = app.EndDate;
                this.cmbHourStart.SelectedValue = app.StartHour.ToString();
                this.cmbMinuteStart.SelectedValue = app.StartMinute.ToString();
                this.dtStartDate.Value = app.StartDate;
                this.cmbHourEnd.SelectedValue = app.EndHour.ToString();
                this.cmbMinuteEnd.SelectedValue = app.EndMinute.ToString();

                this.txtMemo.Text = app.Content;
                this.chkDeletedData.Checked = app.DeleteFlag == (int)DeleteFlag.Deleted;
                
                //Get List Approve
                this.FillDataApproveList(this.WorkID);
                
                this._approveStatus = app.StatusApprove;
                //Save ID and UpdateDate
                this.WorkID = app.ID;
                this.OldUpdateDate = app.UpdateDate;
                this._isDeleted = app.DeleteFlag == (short)DeleteFlag.Deleted;
            }
        }

        /// <summary>
        /// Clear value on screen
        /// </summary>
        private void ClearValue()
        {            
            this.txtApproveNo.Text = string.Empty;
            this.dtConfirmDate.Value = null;
            this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
            this.InitComboboxType();
            this.txtUserName.Text = LoginInfo.User.UserName1;
            this.dtEndDate.Value = DateTime.Now;
            
            this.SetDisableDateByType(int.Parse(this.cmbType.SelectedValue.ToString()));
            this.dtStartDate.Value = DateTime.Now;
            this.txtMemo.Text = string.Empty;
            //Reload List Approve user
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue));
        }

        /// <summary>
        /// Fill Data Approve List From Route
        /// </summary>
        private void FillDataApproveList_FromRoute(int TypeHID)
        {
            IList<ApproveListWork> lst = this.GetListApproveUser(this.GetListApproveWorkFromRoute(TypeHID));

            if (lst != null && lst.Count != 0)
            {
                this._hasApproveUser = true;
                this.rptApproveList.DataSource = lst;
            }
            else
            {
                this._hasApproveUser = false;
                this.rptApproveList.DataSource = null;
            }
            this.rptApproveList.DataBind();
        }

        /// <summary>
        /// Get work by ID
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private T_Approve GetWork(int wID)
        {
            using (DB db = new DB())
            {
                ApproveService appSer = new ApproveService(db);

                //Get Approve
                return appSer.GetByID(wID);
            }
        }

        /// <summary>
        /// GetListApprove(From Approve_List)
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private IList<ApproveWork> GetListApproveByWorkID(int wID)
        {
            using (DB db = new DB())
            {
                ApproveListService appListSer = new ApproveListService(db);

                //Get Approve
                return appListSer.GetListForWork(wID);
               
            }
        }

        /// <summary>
        /// GetTotalRowApprove
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        //private int GetTotalRowApprove(int wID)
        //{
        //    using (DB db = new DB())
        //    {
        //        ApproveListService appListSer = new ApproveListService(db);

        //        //Get Approve
        //        return appListSer.GetTotalRowForWork(wID);

        //    }
        //}

        /// <summary>
        /// Get work by approve no
        /// </summary>
        /// <param name="approveNo"></param>
        /// <returns></returns>
        private T_Approve GetWorkByApproveNo(string approveNo)
        {
            using (DB db = new DB())
            {
                ApproveService appSer = new ApproveService(db);

                //Get Approve
                return appSer.GetByApproveNo(approveNo);
            }
        }

        /// <summary>
        /// Get default data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                TypeApplyService typeSer = new TypeApplyService(db);
                
                this._defaultStatus = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
                
                //Status List
                this._statusList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);
                //Type List
                this._typeList = typeSer.GetDataForDropDownList(true);

                //Unit Minute
                this._defaultUnitMinute = int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_UNIT_MINUTE));
            }

        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //if (this.cmbType.SelectedValue.ToString().Equals("-1"))
            //{
            //    this.SetMessage(this.cmbType.ID, M_Message.MSG_PLEASE_SELECT, "Type");
            //}

            if (!this.dtStartDate.Value.HasValue)
            {
                this.SetMessage(this.dtStartDate.ID, M_Message.MSG_REQUIRE, "Start Date");
            }

            /*---if (!this.dtStartTime.Value.HasValue)
            {
                this.SetMessage(this.dtStartTime.ID, M_Message.MSG_REQUIRE, "Start Time");
            }*/

            if (!this.dtEndDate.Value.HasValue)
            {
                this.SetMessage(this.dtEndDate.ID, M_Message.MSG_REQUIRE, "End Date");
            }

           /*--- if (!this.dtEndTime.Value.HasValue)
            {
                this.SetMessage(this.dtEndTime.ID, M_Message.MSG_REQUIRE, "End Time");
            }*/
            if (string.IsNullOrEmpty(this.txtMemo.Text))
            {
                this.SetMessage(this.txtMemo.ID, M_Message.MSG_REQUIRE, "Content");
            }

           /* if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue)
            {
                if (this.dtStartDate.Value.Value > this.dtEndDate.Value.Value)
                {
                    this.SetMessage(this.dtEndDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Date","Start Date");
                }
            }*/

            //Check Valid Date
             this.CheckValidDateType();

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// GetTypeApplyByID
        /// </summary>
        /// <param name="typeApplyID">ID</param>
        /// <returns></returns>
        private M_TypeApply GetTypeApplyByID(int typeApplyID)
        {
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                return typeSer.GetByID(typeApplyID);
            }
        }

        /// <summary>
        /// CheckValidDateType
        /// </summary>
        private void CheckValidDateType()
        {
            int typeApplyID = int.Parse(this.cmbType.SelectedValue.ToString());
            bool isErrorRange = false;
            M_TypeApply type = this.GetTypeApplyByID(typeApplyID);
            if (type != null)
            {
                //Nghi phep
                if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue && this.dtStartDate.Value.Value == this.dtEndDate.Value.Value)
                {
                    int startHour = int.Parse(this.cmbHourStart.SelectedValue);
                    int startMinute = int.Parse(this.cmbMinuteStart.SelectedValue);
                    int endHour = int.Parse(this.cmbHourEnd.SelectedValue);
                    int endMinute = int.Parse(this.cmbMinuteEnd.SelectedValue);
                    
                    //Thoi gian bat dau < thoi gian bat dau quy dinh
                    if (startHour == type.MinStartHour && startMinute < type.MinStartMinute)
                    {
                        this.SetMessage(this.cmbMinuteStart.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Start Time", string.Format("{0} : {1}", type.MinStartHour.ToString().PadLeft(2, '0'), type.MinStartMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    //Thoi gian bat dau = thoi gian ket thuc quy dinh
                    if (startHour == type.MaxEndHour && startMinute >= type.MaxEndMinute)
                    {
                        this.SetMessage(this.cmbMinuteStart.ID, M_Message.MSG_LESS_THAN_EQUAL, "Start Time", string.Format("{0} : {1}", type.MaxEndHour.ToString().PadLeft(2, '0'), type.MaxEndMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }                   
                    
                    //Thoi gian ket thuc = thoi gian bat dau quy dinh
                    if (endHour == type.MinStartHour && endMinute <= type.MinStartMinute)
                    {
                        this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Time", string.Format("{0} : {1}", type.MinStartHour.ToString().PadLeft(2, '0'), type.MinStartMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    //Thoi gian ket thuc > thoi gian ket thuc quy dinh
                    if (endHour == type.MaxEndHour && endMinute > type.MaxEndMinute)
                    {
                        this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Time", string.Format("{0} : {1}", type.MaxEndHour.ToString().PadLeft(2, '0'), type.MaxEndMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    if (!isErrorRange)
                    {
                        //Thoi gian ket thuc > thoi gian bat dau
                        if (endHour < startHour)//Hour
                        {
                            this.SetMessage(this.cmbHourEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Hour", "Start Hour");
                        }
                        else if (endHour == startHour)//Gio bang nhau
                        {
                            if (endMinute <= startMinute)//Minute
                            {
                                this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Minute", "Start Minute");
                            }
                        }
                    }                   
                }
                else
                {
                    //Nghi phep
                    if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue)
                    {
                        if (this.dtStartDate.Value.Value > this.dtEndDate.Value.Value)
                        {
                            this.SetMessage(this.dtEndDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Date", "Start Date");
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Get data for insert
        /// </summary>
        /// <returns></returns>
        private T_Approve GetDataForInsert()
        {
            T_Approve app = new T_Approve();            
            app.StartDate = this.dtStartDate.Value;
            //---if (this.dtStartTime.Value.HasValue)
            //{
            //    app.StartHour = (short)this.dtStartTime.Value.Value.Hour;
            //    app.StartMinute = (short)this.dtStartTime.Value.Value.Minute;
            //}
            app.StartHour = short.Parse(this.cmbHourStart.SelectedValue.ToString());
            app.StartMinute = short.Parse(this.cmbMinuteStart.SelectedValue.ToString());

            app.EndDate = this.dtEndDate.Value;
            app.EndHour = short.Parse(this.cmbHourEnd.SelectedValue.ToString());
            app.EndMinute = short.Parse(this.cmbMinuteEnd.SelectedValue.ToString());
            //---if (this.dtEndTime.Value.HasValue)
            //{
            //    app.EndHour = (short)this.dtEndTime.Value.Value.Hour;
            //    app.EndMinute = (short)this.dtEndTime.Value.Value.Minute;
            //}
            app.Content = this.txtMemo.Text;
            app.UserID = this.LoginInfo.User.ID;
            app.CreateUID = this.LoginInfo.User.ID;
            app.UpdateUID = this.LoginInfo.User.ID;
            app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
            app.StatusApprove = (short)T_Approve.C_STATUS_APP_NEW;
            return app;
        }

        /// <summary>
        /// Get List Approve User For Insert
        /// </summary>
        /// <param name="lstInput"></param>
        /// <returns></returns>
        private IList<T_Approve_List> GetListApproveForInsert(int TypeID)
        {
            IList<ApproveWork> lstDB = this.GetListApproveWorkFromRoute(TypeID);
            IList<ApproveWork> lstTemp = null;
            IList<T_Approve_List> lstRet = null;
            if (lstDB != null && lstDB.Count != 0)
            {
                var appWorkModel = (from u in lstDB
                                    where u.UserID.Equals(this.LoginInfo.User.ID)
                                    select new ApproveWork
                                    {
                                        ApproveLevel = u.ApproveLevel,
                                        ApproveLevelStr = u.ApproveLevelStr,
                                        RouteMethod = u.RouteMethod,
                                        RouteMethodStr = u.RouteMethodStr,
                                        UserID = u.UserID,
                                        UserName = u.UserName
                                    }
                             ).SingleOrDefault();

                if (appWorkModel != null)
                {
                    short userLv = appWorkModel.ApproveLevel;
                    lstTemp = (from l in lstDB
                               where l.ApproveLevel > userLv | (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) & l.ApproveLevel.Equals(userLv))
                                     & !l.UserID.Equals(this.LoginInfo.User.ID)
                               select new ApproveWork
                               {
                                   ApproveDate = l.ApproveDate,
                                   ApproveDateStr = l.ApproveDateStr,
                                   ApproveFlag = l.ApproveFlag,
                                   ApproveFlagStr = l.ApproveFlagStr,
                                   ApproveID = l.ApproveID,
                                   ApproveLevel = l.ApproveLevel,
                                   ApproveLevelStr = l.ApproveLevelStr,
                                   ApproveName = l.ApproveName,
                                   ApproveUID = l.ApproveUID,
                                   Remark = l.Remark,
                                   RouteMethod = l.RouteMethod,
                                   RouteMethodStr = l.RouteMethodStr,
                                   UserID = l.UserID,
                                   UserName = l.UserName
                               }).ToList();

                    //Current User has Level Max. Get current user
                    if (lstTemp.Count == 0)
                    {
                        lstTemp = (from k in lstDB
                                   where k.UserID.Equals(this.LoginInfo.User.ID)
                                   select new ApproveWork
                                   {
                                       ApproveDate = k.ApproveDate,
                                       ApproveDateStr = k.ApproveDateStr,
                                       ApproveFlag = k.ApproveFlag,
                                       ApproveFlagStr = k.ApproveFlagStr,
                                       ApproveID = k.ApproveID,
                                       ApproveLevel = k.ApproveLevel,
                                       ApproveLevelStr = k.ApproveLevelStr,
                                       ApproveName = k.ApproveName,
                                       ApproveUID = k.ApproveUID,
                                       Remark = k.Remark,
                                       RouteMethod = k.RouteMethod,
                                       RouteMethodStr = k.RouteMethodStr,
                                       UserID = k.UserID,
                                       UserName = k.UserName
                                   }).ToList();
                    }


                }
                //Current User not exist in List Approve in DB
                if (lstTemp == null || lstTemp.Count == 0)
                {
                    lstTemp = new List<ApproveWork>();
                    ((List<ApproveWork>)lstTemp).AddRange(lstDB);
                }

                lstRet = new List<T_Approve_List>();
                foreach (ApproveWork item in lstTemp)
                {
                    T_Approve_List app = new T_Approve_List();
                    app.UserID = item.UserID;
                    app.ApproveUID = item.ApproveUID;
                    app.ApproveDate = item.ApproveDate;
                    app.Remark = item.Remark;
                    app.ApproveLevel = item.ApproveLevel;
                    app.RouteMethod = item.RouteMethod;
                    app.ApproveFlag = item.ApproveFlag;
                    lstRet.Add(app);
                }

            }
            return lstRet;
        }
                
        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns></returns>
        private bool InsertData()
        {
            try
            {
                //Create model Approve
                T_Approve app = this.GetDataForInsert();
                //Create model Approve List
                IList<T_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID);

                //Get Approve
                app.ApproveNo = (new TNoService()).CreateNo(T_No.VacationNo);

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApproveService appSer = new ApproveService(db);
                    ApproveListService appLstSer = new ApproveListService(db);
                    //Insert Approve
                    this.WorkID = appSer.Insert(app);
                    if (this.WorkID != 0 && lstApp != null)
                    {
                        foreach (var appItem in lstApp)
                        {
                            appItem.ApproveID = this.WorkID;
                            appLstSer.Insert(appItem);
                        }
                    }
                    db.Commit();                    
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                //{
                //    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                //    return false;
                //}

                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Approve app = this.GetWorkByApproveNo(this.txtApproveNo.Value);
                if (app != null)
                {
                    //Create model
                    app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
                    app.StartDate = this.dtStartDate.Value;
                    app.StartHour = short.Parse(this.cmbHourStart.SelectedValue.ToString());
                    app.StartMinute = short.Parse(this.cmbMinuteStart.SelectedValue.ToString());
                    //---app.StartHour = (short)this.dtStartTime.Value.Value.Hour;
                    //app.StartMinute = (short)this.dtStartTime.Value.Value.Minute;
                    app.EndDate = this.dtEndDate.Value;
                    app.EndHour = short.Parse(this.cmbHourEnd.SelectedValue.ToString());
                    app.EndMinute = short.Parse(this.cmbMinuteEnd.SelectedValue.ToString());
                    //---app.EndHour = (short)this.dtEndTime.Value.Value.Hour;
                    //app.EndMinute = (short)this.dtEndTime.Value.Value.Minute;
                    app.Content = this.txtMemo.Text;
                   
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    IList<T_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID);

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ApproveService appSer = new ApproveService(db);
                        ApproveListService appListSer = new ApproveListService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Update(app);
                           
                            //Delete Old List
                            appListSer.DeleteByApproveID(app.ID);
                            //Insert New List
                            foreach (var item in lstApp)
                            {
                                item.ApproveID = app.ID;
                                appListSer.Insert(item);
                            }
                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Approve app = this.GetWorkByApproveNo(this.txtApproveNo.Value);
                
                if (app != null)
                {
                    if (app.UpdateDate != this.OldUpdateDate)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    if (app.StatusApprove == (short)StatusApprove.Approve || app.StatusApprove == (short)StatusApprove.Complete)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    //Create model
                    app.DeleteFlag = (short)DeleteFlag.Deleted;
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update customer                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ApproveService appSer = new ApproveService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Delete(app);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        private bool ConfirmData()
        {
            try
            {
                int ret = 0;
                T_Approve app = this.GetWorkByApproveNo(this.txtApproveNo.Value);
                if (app != null)
                {
                    //Create model
                    app.StatusApprove = (int)StatusApprove.Confirm;                    
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ApproveService appSer = new ApproveService(db);

                        //Update Approve                       
                        ret = appSer.UpdateStatusFlag(app);
                        db.Commit();                        
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }


        #endregion
        
    }
}
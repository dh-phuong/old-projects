﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Utilities;

namespace DailyReport.Menu
{
    public partial class FrmCompanyConstructor : FrmBase
    {
        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Company Contructor";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";  

            base.SetAuthority(FormId.Department);
            this.btnFrmDepartmentList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.User);
            this.btnFrmUserList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.Staff);
            this.btnFrmStaffList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.GroupUser);
            this.btnFrmGroupUserList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.CompanyInfo);
            this.btnFrmCompanyInfo.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
        }
    }
}
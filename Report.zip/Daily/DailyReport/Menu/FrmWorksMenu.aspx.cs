﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Utilities;

namespace DailyReport.Menu
{
    public partial class FrmWorksMenu : FrmBase
    {
        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Work System Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";
            
            base.SetAuthority(FormId.Holiday);
            this.btnFrmHolidayList.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.Route);
            this.btnFrmRoute.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);            

            base.SetAuthority(FormId.Link);
            this.btnFrmLink.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);            

            base.SetAuthority(FormId.Template);
            this.btnFrmTemplate.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.RestTime);
            this.btnFrmRestTime.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.Accounting);
            this.btnFrmAccounting.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.BaseWorkDay);
            this.btnFrmBaseWorkDay.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.WorkingShift);
            this.btnFrmWorkingShift.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.WorkingDay);
            this.btnFrmWorkDay.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);
        }
    }
}
﻿using System;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.DAC;
using System.Collections.Generic;

namespace DailyReport.Menu
{
    public partial class FrmMasterMenu : FrmBase
    {
        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Main Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";                                

            base.SetAuthority(FormId.Setting);
            this.btnFrmSetting.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            base.SetAuthority(FormId.Information);
            this.btnFrmInformation.Attributes.Add("class", base._authority.IsMasterView ? enableClass : disableClass);

            this.btnFrmConfigList.Attributes.Add("class", base.IsAdmin() ? enableClass : disableClass);                       
        }

        #endregion
    }
}
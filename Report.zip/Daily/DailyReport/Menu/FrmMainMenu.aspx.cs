﻿using System;
using System.Collections.Generic;

using DailyReport.Models;
using DailyReport.DAC;
using System.Collections;
using DailyReport.Utilities;
using System.Web.UI.WebControls;

namespace DailyReport.Menu
{
    public partial class FrmMainMenu : FrmBase
    {

        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Main Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            IList<M_Information> data;
            //Get data
            int totalRow;
            using (DB db = new DB())
            {
                InformationService service = new InformationService(db);
                data = service.GetAll();
                DateTime nowDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);

                WorkService _appService = new WorkService(db);
                totalRow = _appService.GetCountApplyApproveList(this.LoginInfo.User.ID, string.Empty, string.Empty, new DateTime(1900, 1, 1), new DateTime(9999, 12, 31), null, null, -1, 0);                
            }

            if (totalRow > 0)
            {
                M_Message mess = (M_Message)this.Messages[M_Message.MSG_REQUISITION];
                M_Information requisitionInfo = new M_Information();
                requisitionInfo.InformationName = "Has Apply Requisition";
                requisitionInfo.InformationContent = string.Format(mess.Message1, totalRow, "apply") + Environment.NewLine + string.Format(mess.Message2, totalRow, "phép");
                data.Insert(0, requisitionInfo);
            }

            this.rptData.DataSource = data;
            this.rptData.DataBind();


            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";

            base.SetAuthority(FormId.ApplyRegist);
            this.btnApplyRegist.Attributes.Add("class", base._authority.IsApplyRegistView ? enableClass : disableClass);

            base.SetAuthority(FormId.ApplyApprove);
            this.btnApplyApprove.Attributes.Add("class", base._authority.IsApplyApproveView ? enableClass : disableClass);
        }

        #endregion
    }
}
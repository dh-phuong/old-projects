﻿using System;

namespace DailyReport.Menu
{
    public partial class FrmMenu : FrmBaseList
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }
    }
}
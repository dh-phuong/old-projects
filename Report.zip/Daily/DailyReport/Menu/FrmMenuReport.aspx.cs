﻿using System;
using DailyReport.Utilities;
using DailyReport;

namespace DailyReport.Menu
{
    public partial class FrmMenuReport : FrmBase
    {
        #region Event

        /// <summary>
        /// Init page
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Report Menu";
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            string enableClass = "btn btn-default btn-lg btn-block";
            string disableClass = "btn btn-default btn-lg btn-block disabled";

            //base.SetAuthority(FormId.BuySell);
            //this.btnBuySell.Attributes.Add("class", base._authority.IsBuySellView ? enableClass : disableClass);

            //base.SetAuthority(FormId.BalanceSales);
            //this.btnBalanceSales.Attributes.Add("class", base._authority.IsBalanceSalesView ? enableClass : disableClass);

            //base.SetAuthority(FormId.BalancePurchase);
            //this.btnBalancePurchase.Attributes.Add("class", base._authority.IsBalancePurchaseView ? enableClass : disableClass);
        }
        #endregion
    }
}
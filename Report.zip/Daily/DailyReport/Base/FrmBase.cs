﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Reflection;
using System.Collections;
using System.IO;

using Microsoft.Reporting.WebForms;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

using NPOI.SS.UserModel;
using NPOI.HSSF.UserModel;
using NPOI.SS.Util;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Windows.Forms;
using System.Globalization;

namespace DailyReport
{
    /// <summary>
    /// Class Form Base
    /// </summary>
    public abstract class FrmBase : System.Web.UI.Page
    {
        #region Variable
        protected AuthorityInfo _authority;
        #endregion

        #region Property
        /// <summary>
        /// Message List
        /// </summary>
        protected IDictionary<string, M_Message> Messages { get; private set; }

        protected IList<string> CtrlIDErrors
        {
            get
            {
                return (IList<string>)base.ViewState["CTRL_ERROR_ID"];
            }
            private set
            {
                base.ViewState["CTRL_ERROR_ID"] = value;
            }
        }
        protected IList<string> MsgErrors
        {
            get
            {
                return (IList<string>)base.ViewState["MSG_ERROR"];
            }
            private set
            {
                base.ViewState["MSG_ERROR"] = value;
            }
        }

        protected IList<string> CtrlIDInfos
        {
            get
            {
                return (IList<string>)base.ViewState["CTRL_INFO"];
            }
            set
            {
                base.ViewState["CTRL_INFO"] = value;
            }
        }
        protected IList<string> MsgInfos
        {
            get
            {
                return (IList<string>)base.ViewState["MSG_INFO"];
            }
            set
            {
                base.ViewState["MSG_INFO"] = value;
            }
        }

        /// <summary>
        /// Get LoginInfo
        /// </summary>
        protected LoginInfo LoginInfo
        {
            get { return (LoginInfo)Session["LoginInfo"]; }
        }

        /// <summary>
        /// Get PreviousPageViewState
        /// </summary>
        protected StateBag PreviousPageViewState
        {
            get
            {
                StateBag returnValue = null;
                if (PreviousPage != null)
                {
                    Object objPreviousPage = (Object)PreviousPage;
                    MethodInfo objMethod = objPreviousPage.GetType().GetMethod("ReturnViewState");
                    return (StateBag)objMethod.Invoke(objPreviousPage, null);
                }
                return returnValue;
            }
        }

        /// <summary>
        /// Get HaveError
        /// </summary>
        protected bool HaveError
        {
            get
            {
                if (this.MsgErrors.Count == 0 && this.MsgInfos.Count == 0)
                {
                    return false;
                }

                return true;
            }
        }

        /// <summary>
        /// Get or set FormTitle
        /// </summary>
        public string FormTitle
        {
            get
            {
                SiteMaster master = (SiteMaster)this.Master;
                return master.FormTitle;
            }
            set
            {
                SiteMaster master = (SiteMaster)this.Master;
                master.FormTitle = value;
            }
        }

        /// <summary>
        /// Get or set FormSubTitle
        /// </summary>
        public string FormSubTitle
        {
            get
            {
                SiteMaster master = (SiteMaster)this.Master;
                return master.FormSubTitle;
            }
            set
            {
                SiteMaster master = (SiteMaster)this.Master;
                master.FormSubTitle = value;
            }
        }

        /// <summary>
        /// Get IsOutFile
        /// </summary>
        protected bool IsOutFile
        {
            get
            {
                if (ViewState["OUTFILE"] != null)
                {
                    if (File.Exists(ViewState["OUTFILE"].ToString()))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        #endregion

        #region Event

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Get list message

            using (DB db = new DB())
            {
                MessageService msgSer = new MessageService(db);
                this.Messages = msgSer.GetAll().ToDictionary(key => key.MessageID, value => value);
            }

            this.CtrlIDErrors = new List<string>();
            this.MsgErrors = new List<string>();

            this.CtrlIDInfos = new List<string>();
            this.MsgInfos = new List<string>();
        }

        #endregion

        #region Method

        /// <summary>
        /// Get ReturnViewState
        /// </summary>
        public StateBag ReturnViewState()
        {
            return ViewState;
        }

        /// <summary>
        /// Set error messsage
        /// </summary>
        /// <param name="ctrlID">Error ControlID</param>
        /// <param name="msgID">Message Id</param>
        /// <param name="args">List argument of messsage</param>
        protected void SetMessage(string ctrlID, string msgID, params object[] args)
        {
            //Get Message
            M_Message mess = (M_Message)this.Messages[msgID];
            //Check Message Type
            switch (mess.Type)
            {
                case "E":
                    this.MsgErrors.Add(string.Format("<h5>{0}</h5>", string.Format(mess.Message1, args)));
                    this.MsgErrors.Add(string.Format("<h5>{0}</h5>", string.Format(mess.Message2, args)));
                    this.CtrlIDErrors.Add(ctrlID);

                    break;
                case "I":
                    this.MsgInfos.Add(string.Format("<h5>{0}</h5>", string.Format(mess.Message1, args)));
                    this.MsgInfos.Add(string.Format("<h5>{0}</h5>", string.Format(mess.Message2, args)));
                    this.CtrlIDInfos.Add(ctrlID);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected virtual string GetClassError(string ctrlID)
        {
            if (this.CtrlIDErrors.Contains(ctrlID))
            {
                return "has-error";
            }
            if (this.CtrlIDInfos.Contains(ctrlID))
            {
                return " has-warning";
            }
            return string.Empty;
        }

        /// <summary>
        /// Get display message
        /// </summary>
        /// <returns>HTML of error message</returns>
        public string GetMessage()
        {
            string ret = string.Empty;
            if (this.MsgErrors.Count > 0)
            {
                ret += "<div id='panelError' class='alert alert-danger alert-dismissible' role='alert'>";
                ret += "<button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span><span class='sr-only'></span></button>";
                ret += "<span class='glyphicon glyphicon-remove-sign'></span><strong> Warning!</strong>";

                int i = 0;
                string msg1 = string.Empty;
                string msg2 = string.Empty;
                foreach (var msg in this.MsgErrors)
                {
                    if (i % 2 == 0)
                    {
                        msg1 += msg;
                    }
                    else
                    {
                        msg2 += msg;
                    }
                    i++;
                }

                ret += msg1;
                ret += "<span class='glyphicon glyphicon-remove-sign'></span><strong> Cảnh báo!</strong>";
                ret += msg2;
                ret += "</div>";

            }

            if (this.MsgInfos.Count > 0)
            {
                ret += "<div id='panelError' class='alert alert-info alert-dismissible' role='alert' runat='server'>";
                ret += "<button type='button' class='close' data-dismiss='alert'><span aria-hidden='true'>&times;</span><span class='sr-only'></span></button>";
                ret += "<span class='glyphicon glyphicon-info-sign'></span><strong> Information!</strong>";

                int i = 0;
                string msg1 = string.Empty;
                string msg2 = string.Empty;
                foreach (var msg in this.MsgInfos)
                {
                    if (i % 2 == 0)
                    {
                        msg1 += msg;
                    }
                    else
                    {
                        msg2 += msg;
                    }
                    i++;
                }

                ret += msg1;
                ret += "<span class='glyphicon glyphicon-info-sign'></span><strong> Thông tin!</strong>";
                ret += msg2;

                ret += "</div>";
            }

            return ret;
        }

        /// <summary>
        /// Get Color For Grid Data
        /// ISV-TRUC
        /// </summary>
        /// <param name="color">color</param>
        /// <returns></returns>
        public string GetColorClass(int color)
        {
            string ret = string.Empty;

            if (color == (int)ColorList.Danger)
            {
                ret = "danger";
            }
            else if (color == (int)ColorList.Warning)
            {
                ret = "warning";
            }
            else if (color == (int)ColorList.Info)
            {
                ret = "info";
            }
            else if (color == (int)ColorList.Success)
            {
                ret = "success";
            }
            else if (color == (int)ColorList.Finish)
            {
                ret = "finish";
            }

            return ret;
        }

        /// <summary>
        /// Get Color Class By Level
        /// </summary>
        /// <param name="level"></param>
        /// <returns></returns>
        public string GetColorLevel(int level)
        {
            string ret = string.Empty;

            if (level == (int)ColorOfLevel.Danger)
            {
                ret = "danger";
            }
            else if (level == (int)ColorOfLevel.Warning)
            {
                ret = "warning";
            }
            else if (level == (int)ColorOfLevel.Info)
            {
                ret = "info";
            }
            else if (level == (int)ColorOfLevel.Success)
            {
                ret = "success";
            }
            else if (level == (int)ColorOfLevel.Finish)
            {
                ret = "finish";
            }


            return ret;
        }

        /// <summary>
        /// Get Authority
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        protected void SetAuthority(Utilities.FormId formId)
        {
            this._authority = new AuthorityInfo();
            M_GroupUser_D grpUser = this.LoginInfo.ListGroupDetail.Where(m => m.FormID == (int)formId).FirstOrDefault();

            if (grpUser != null)
            {
                #region Daily
                if (formId == FormId.Daily)
                {
                    if (grpUser.AuthorityFlag1 == 1)
                    {
                        this._authority.IsDailyView = true;
                    }

                    if (grpUser.AuthorityFlag2 == 1)
                    {
                        this._authority.IsDailyNew = true;
                    }

                    if (grpUser.AuthorityFlag3 == 1)
                    {
                        this._authority.IsDailyEdit = true;
                    }

                    if (grpUser.AuthorityFlag4 == 1)
                    {
                        this._authority.IsDailyCopy = true;
                    }

                    if (grpUser.AuthorityFlag5 == 1)
                    {
                        this._authority.IsDailyDelete = true;
                    }

                    return;
                }
                #endregion

                #region ApplyRegist
                if (formId == FormId.ApplyRegist)
                {
                    if (grpUser.AuthorityFlag1 == 1)
                    {
                        this._authority.IsApplyRegistView = true;
                    }

                    if (grpUser.AuthorityFlag2 == 1)
                    {
                        this._authority.IsApplyRegistNew = true;
                    }

                    if (grpUser.AuthorityFlag3 == 1)
                    {
                        this._authority.IsApplyRegistEdit = true;
                    }

                    if (grpUser.AuthorityFlag4 == 1)
                    {
                        this._authority.IsApplyRegistCopy = true;
                    }

                    if (grpUser.AuthorityFlag5 == 1)
                    {
                        this._authority.IsApplyRegistDelete = true;
                    }

                    if (grpUser.AuthorityFlag6 == 1)
                    {
                        this._authority.IsApplyRegistConfirm = true;
                    }

                    return;
                }
                #endregion

                #region Approve
                if (formId == FormId.ApplyApprove)
                {
                    if (grpUser.AuthorityFlag1 == 1)
                    {
                        this._authority.IsApplyApproveView = true;
                    }

                    if (grpUser.AuthorityFlag2 == 1)
                    {
                        this._authority.IsApplyApproveApprove = true;
                    }

                    if (grpUser.AuthorityFlag3 == 1)
                    {
                        this._authority.IsApplyApproveIgnore = true;
                    }
                    if (grpUser.AuthorityFlag4 == 1)
                    {
                        this._authority.IsApplyApproveReBack = true;
                    }

                    return;
                }
                #endregion

                //Master
                #region Master
                if (grpUser.AuthorityFlag1 == 1)
                {
                    this._authority.IsMasterView = true;
                }

                if (grpUser.AuthorityFlag2 == 1)
                {
                    this._authority.IsMasterNew = true;
                }

                if (grpUser.AuthorityFlag3 == 1)
                {
                    this._authority.IsMasterEdit = true;
                }

                if (grpUser.AuthorityFlag4 == 1)
                {
                    this._authority.IsMasterCopy = true;
                }

                if (grpUser.AuthorityFlag5 == 1)
                {
                    this._authority.IsMasterDelete = true;
                }

                #endregion

            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="button"></param>
        /// <param name="disabled"></param>
        protected void DisabledLink(LinkButton button, bool disabled)
        {
            if (disabled)
            {
                button.Enabled = false;
                button.CssClass += " disabled";
            }
            else
            {
                button.Enabled = true;
                button.CssClass = button.CssClass.Replace("disabled", "");
            }
            button.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="button"></param>
        /// <param name="disabled"></param>
        protected void HiddenLink(LinkButton button, bool disabled)
        {
            if (disabled)
            {
                button.Enabled = false;
                button.CssClass = button.CssClass.Trim() + " hidden";
            }
            else
            {
                button.Enabled = true;                
                button.CssClass = button.CssClass.Replace("hidden", "");
            }
            button.DataBind();
        }

        /// <summary>
        /// Get Value
        /// </summary>
        /// <typeparam name="T">Type of value</typeparam>
        /// <param name="property">property</param>
        /// <returns></returns>
        protected T GetValueViewState<T>(string property)
        {
            var val = base.ViewState[property];
            if (val == null)
            {
                return default(T);
            }
            return (T)val;
        }

        /// <summary>
        /// Get Status Color Label
        /// ISV-TRUC
        /// </summary>
        /// <param name="status"></param>
        /// <returns></returns>
        public string GetStatusColorLabel(int status)
        {
            string statusName = string.Empty;
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                Config_DService configSer = new Config_DService(db);
                statusName = configSer.GetValue2(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, status);
            }

            string color = string.Empty;
            switch (status)
            {
                case (int)StatusApply.Draft:
                    color = "color-default";
                    break;

                case (int)StatusApply.Approving:
                    color = "color-info";
                    break;

                case (int)StatusApply.Approved:
                    color = "color-success";
                    break;

                case (int)StatusApply.Rejected:
                    color = "color-danger";
                    break;

                case (int)StatusApply.BackPrev:
                    color = "color-warning";
                    break;

                case (int)StatusApply.Cancel:
                    color = "color-danger";
                    break;

                default:
                    break;
            }
            return "<div class='row'><div class='col-md-2'><div class='form-group'><div class='testPanel " + color + "'><span class='testText label' id='lblStatus'>" + statusName.ToUpper() + "</span></div></div></div></div>";
        }

        /// <summary>
        /// GetListMonthByStartMonth
        /// ISV-TRUC
        /// 2015/06/11
        /// </summary>
        /// <param name="startMonth"></param>
        /// <returns></returns>
        public IList<StringModel> GetListMonthByStartMonth(int startMonth, int curMonth, int curYear)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            int valAdd = 1;
            if (curMonth < startMonth)
            {
                curYear--;
            }

            DateTime dt = new DateTime(curYear, startMonth, 1);
            lstMonth.Add(new StringModel(dt.Month, dt.Year, dt.ToString("MMM", CultureInfo.InvariantCulture)));
            for (int i = 0; i < 11; i++)
            {
                dt = dt.AddMonths(valAdd);
                lstMonth.Add(new StringModel(dt.Month, dt.Year, dt.ToString("MMM", CultureInfo.InvariantCulture)));
            }
            /*int i = startMonth;
            while (i <= 12)
            {
                lstMonth.Add(new StringModel(i, this.GetNameOfMonthEN(i)));
                i++;
            }
            if (startMonth > 1)
            {
                i = 1;
                while (i < startMonth)
                {
                    lstMonth.Add(new StringModel(i, this.GetNameOfMonthEN(i)));
                    i++;
                }
            }*/
            return lstMonth;
        }

        #endregion

        #region Report

        /// <summary>
        /// 
        /// </summary>
        /// <param name="report"></param>
        /// <param name="fileName"></param>
        /// <param name="isPortrait"></param>
        public void ExportPDF(LocalReport report, string fileName, bool isPortrait)
        {
            try
            {
                string REPORT_TYPE = "OUTFILE";
                string MimeType;
                string Encoding;
                string FilenameExtension;

                //Page size
                double pageWidth = isPortrait ? 21 : 29.7;
                double pageHeight = isPortrait ? 29.7 : 21;

                //Margin
                double maginTop = 0.5;
                double maginRight = 0.75;
                double maginBottom = 0.5;
                double maginLeft = 1;

                string DEVICE_INFO = "<DeviceInfo>";
                DEVICE_INFO += "  <OutputFormat>PDF</OutputFormat>";
                DEVICE_INFO += "  <PageWidth>" + pageWidth + "cm</PageWidth>";
                DEVICE_INFO += "  <PageHeight>" + pageHeight + "cm</PageHeight>";
                DEVICE_INFO += "  <MarginTop>" + maginTop + "cm</MarginTop>";
                DEVICE_INFO += "  <MarginRight>" + maginRight + "cm</MarginRight>";
                DEVICE_INFO += "  <MarginBottom>" + maginBottom + "cm</MarginBottom>";
                DEVICE_INFO += "  <MarginLeft>" + maginLeft + "cm</MarginLeft>";
                DEVICE_INFO += "  </DeviceInfo>";

                Warning[] warnings;
                string[] streams;
                byte[] renderedBytes;

                //Render the report
                renderedBytes = report.Render("PDF",
                                                DEVICE_INFO,
                                                out MimeType,
                                                out Encoding,
                                                out FilenameExtension,
                                                out streams,
                                                out warnings);

                var filePath = Server.MapPath("~") + "/TempDownload/" + Guid.NewGuid().ToString() + ".pdf";
                File.WriteAllBytes(filePath, renderedBytes);
                ViewState[REPORT_TYPE] = filePath;
            }
            catch (Exception)
            {
                throw;
            }
        }

        #endregion

        #region Excel

        /// <summary>
        /// Save File
        /// </summary>
        /// <param name="workBook"></param>
        protected void SaveFile(IWorkbook workBook)
        {
            ViewState["OUTFILE"] = Server.MapPath("~") + "/TempDownload/" + Guid.NewGuid().ToString() + ".xls";
            using (FileStream temp = new FileStream(ViewState["OUTFILE"].ToString(), FileMode.CreateNew, FileAccess.Write))
            {
                workBook.Write(temp);
            }
        }

        /// <summary>
        /// Get Data Excel
        /// </summary>
        /// <returns>MemoryStream</returns>
        protected MemoryStream GetFileStream(string fileType)
        {
            var filePath = ViewState[fileType].ToString();
            MemoryStream ret = new MemoryStream();
            using (FileStream temp = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                temp.CopyTo(ret);
            }
            File.Delete(filePath);
            ViewState[fileType] = null;
            return ret;
        }

        protected bool IsAdmin()
        {
            using (DB db = new DB())
            {
                Config_DService ser = new Config_DService(db);
                return ser.GetListByConfigCd(M_Config_H.CONFIG_USER_CD_ADMIN).Any(c => c.Value3.Equals(EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH)));
            }
        }

        #endregion

        #region URL
        #endregion

        #region REF

        /// <summary>
        /// Redirect
        /// </summary>
        /// <param name="url"></param>
        protected void RedirectUrl(string url)
        {
            ViewState.Clear();
            Response.Redirect(url);
        }

        /// <summary>
        /// Transfer
        /// </summary>
        /// <param name="url"></param>
        protected void TransferUrl(string url)
        {
            this.BackPage();
            Server.Transfer(url);
        }

        /// <summary>
        /// Next Page
        /// </summary>
        /// <param name="currentPage">Current Page</param>
        /// <param name="nextPage">Next Page</param>
        /// <param name="backCurentURL">Back Curent URL</param>
        /// <param name="currentUrl">Current Url</param>
        protected void NextPage(Hashtable currentPage, Hashtable nextPage, string backCurentURL, string currentUrl)
        {
            Stack<Hashtable> temp = new Stack<Hashtable>();
            if (this.ViewState["REF"] != null)
            {
                temp = (Stack<Hashtable>)this.ViewState["REF"];
            }

            //Current Page
            currentPage.Add("BACK_URL", backCurentURL);
            temp.Push(currentPage);
            this.ViewState["REF"] = temp;

            //Next Page
            nextPage.Add("BACK_URL", currentUrl);
            this.ViewState["PARAMATER"] = nextPage;
        }

        /// <summary>
        /// Back Page
        /// </summary>
        protected void BackPage()
        {
            if (this.ViewState["REF"] != null)
            {
                Stack<Hashtable> temp = (Stack<Hashtable>)this.ViewState["REF"];
                this.ViewState["PARAMATER"] = temp.Pop();
                this.ViewState["REF"] = temp;
            }
        }

        /// <summary>
        /// Get Paramater
        /// </summary>
        /// <returns>Paramater</returns>
        protected Hashtable GetParamater()
        {
            if (this.ViewState["PARAMATER"] != null)
            {
                return (Hashtable)this.ViewState["PARAMATER"];
            }
            return null;
        }

        /// <summary>
        /// Save Back Page
        /// </summary>
        protected void SaveBackPage()
        {
            if (this.PreviousPageViewState["REF"] != null)
            {
                this.ViewState["REF"] = this.PreviousPageViewState["REF"];
            }

            if (this.PreviousPageViewState["PARAMATER"] != null)
            {
                this.ViewState["PARAMATER"] = this.PreviousPageViewState["PARAMATER"];
            }
        }

        #endregion
    }
}
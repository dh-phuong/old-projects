﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;

namespace DailyReport.Apply
{
    /// <summary>
    /// FrmVacationRegisterDetail
    /// ISV-TRUC 2015/06/02
    /// </summary>

    public partial class FrmVacationRegisterDetail : FrmBaseDetail
    {

        #region Constants
        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const decimal ZERO_DEC = 0m;
        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_APPLY_VACTION;
        public const int DEFAULT_VALUE = -1;

        public const string PER_HALF_DAY_STR = "0.5";
        public const string A_DAY_STR = "1.0";

        #endregion

        #region Variable

        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;

        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;

        public bool isExistCancel;

        #endregion

        #region Property

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set VacationType
        /// </summary>
        public int VacationTypeForm
        {
            get { return (int)ViewState["VacationTypeForm"]; }
            set { ViewState["VacationTypeForm"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }

        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vacation";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtReason.MaxLength = T_Work_Vacation.REASON_MAX_LENGTH;
            this.txtReasonCancel.MaxLength = T_Work_Vacation.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// Load form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        this.ApplyStatus = (int)StatusApply.Draft;

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_Vacation data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data, false);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Checked change chkisAgent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkIsAgent.Checked)
            {
                this.CheckAuthor(string.Empty);
                this.txtEmployeeCD.SetReadOnly(false);
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.hdnDepartmentID.Value = LoginInfo.Department.ID.ToString();
                this.hdnUserID.Value = string.Empty;
                this.lblTotalDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblUsedDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblPlanDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblRemainDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblExpriedDays.InnerText = ZERO_DEC.ToString("N1");
                this.GetTimesHeader(DEFAULT_VALUE);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);

                this.InitUserInfo(this.LoginInfo.User.ID);
                this.GetTimesHeader(this.LoginInfo.User.ID);
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            }
        }

        /// <summary>
        /// Click btnSeachUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUser_Click(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            string userDa = this.txtUseDays.Text;
            this.RestoreListApprove();

            if (!this.PreApplyID.HasValue)
            {
                ////Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Check CheckValidAnnual
                if (!this.CheckValidAnnual())
                {
                    return;
                }
            }
            else
            {
                //Check input mode cancel
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// btnCopy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCoppy_Click(object sender, EventArgs e)
        {
            //Get data
            T_Work_Vacation data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data, false);
                this.ApplyStatus = (int)StatusApply.Draft;
                this.PreApplyID = null;
                this.btnViewPreVacation.Text = string.Empty;
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Work_Vacation data = this.GetApplyByID(this.DataID);

            //Check data
            if (data != null)
            {
                this.RestoreListApprove();

                //Show data
                this.ShowData(data, true);
                //Set Mode
                this.ProcessMode(Mode.Update);

            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Update;
            this.RestoreListApprove();
            if (this.PreApplyID.HasValue)
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            else
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Check CheckValidAnnual
                if (!this.CheckValidAnnual())
                {
                    return;
                }
                //M_Work_Shift shift = new M_Work_Shift();
                //using (DB db = new DB())
                //{
                //    WorkShiftService shiftSer = new WorkShiftService(db);
                //    shift = shiftSer.GetByID(int.Parse(this.cmbTypeVacation.SelectedValue));
                //}
                //if (shift != null)
                //{
                //    //Check duplicate time apply
                //    if (this.IsDuplicateApplyTime(this.DataNo,shift.TypeOfDay))
                //    {
                //        return;
                //    }
                //}

            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.RestoreListApprove();
                this.ProcessMode(Mode.Delete);
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Confirm;

            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.RestoreListApprove();
                if (!this.PreApplyID.HasValue)
                {
                    //Employee Code
                    if (!this.CheckInput(true))
                    {
                        return;
                    }
                }
                else
                {
                    //Check ngay thang co nam trong thang da ket so ko
                    if (this.CheckExistingDateInWorkTotal())
                    {
                        this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_CANT_CONTINUE, this.txtVactionDtFrm.Value.Value.ToString(Constants.FMT_DATE));
                        return;
                    }
                }
                //Set Mode
                this.ProcessMode(Mode.Confirm);

                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnCancel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
                this.txtReasonCancel.Text = string.Empty;
                this.btnViewPreVacation.Text = apply.No;
                this.PreApplyID = apply.ID;

                this.ApplyStatus = (int)StatusApply.Cancel;
                this.hdnApplyID.Value = this.PreApplyID.ToString();
                this.ProcessMode(Mode.Cancel);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnCancelApply Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelApply_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Cancel;
            this.RestoreListApprove();
            if (IsExistCancel())
            {
                base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
            }
            else
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work_Vacation data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data, false);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }


        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Work_Vacation data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                case Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get 
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        if (this.cmbRoute.Items.Count > 0)
                        {
                            this.LoadDataForApproveListFromRoute(int.Parse(this.cmbRoute.SelectedValue));
                        }
                    }
                    break;

                case Mode.Delete:

                    //Delete 
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                    }

                    break;
                case Mode.Confirm:
                    //Update Data
                    ret = this.Confirm(); // this.UpdateApplyStatus(this.ApplyStatus);
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Cancel:
                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);//?????????????

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Vacation data = this.GetApplyByID(this.DataID);
            if (data != null)
            {
                //Show data
                this.ShowData(data, false);
                this.ProcessMode(Mode.View);
            }

            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// cmbRoute OnSelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbRoute_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int routeID = int.Parse(this.cmbRoute.SelectedValue);
            this.SetValueForHiddenProxy(routeID);
            this.LoadDataForApproveListFromRoute(routeID);
        }

        #endregion

        #region Methods
        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// GetUserInfoByID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_UserInfo GetUserInfoByID(int userID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetUserInfoByID(userID);
            }
        }

        /// <summary>
        /// ResetValueForHeaderDays
        /// </summary>
        /// <param name="dataID"></param>
        /// <param name="userID"></param>
        private void ResetValueForHeaderDays(int dataID, int userID)
        {
            decimal curRemainDay = 0;
            decimal usedDay = 0;
            decimal planDay = 0;
            using (DB db = new DB())
            {
                WorkVacationService applySer = new WorkVacationService(db);
                curRemainDay = applySer.GetRemainDays(dataID, userID);
                usedDay = applySer.GetUsedDays(userID, DateTime.MinValue, DateTime.MinValue);
                planDay = applySer.GetPlanDays(dataID, userID);
            }
            decimal totalDay = planDay + usedDay + curRemainDay;
            this.lblTotalDays.InnerText = totalDay.ToString("N1");
            this.lblUsedDays.InnerText = usedDay.ToString("N1");
            this.lblPlanDays.InnerText = planDay.ToString("N1");
            decimal expDays = totalDay - 12;
            this.lblExpriedDays.InnerText = (expDays < 0 ? 0 : expDays).ToString("N1");
            this.lblRemainDays.InnerText = curRemainDay.ToString("N1");
        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/27
        /// </summary>
        private void InitUserInfo(int userID)
        {

            M_UserInfo u = this.GetUserInfoByID(userID);
            if (u != null)
            {
                M_Route_H item = this.GetRouteByUserID(u.ID);
                if (item != null)
                {
                    this.hdnRouteID.Value = item.ID.ToString();
                }
                this.hdnUserID.Value = u.ID.ToString();
                M_Staff s;
                string position = string.Empty;
                string deptNm = string.Empty;
                using (DB db = new DB())
                {
                    WorkVacationService applySer = new WorkVacationService(db);
                    StaffService staffSer = new StaffService(db);
                    s = staffSer.GetByID(u.StaffID);
                    if (s != null)
                    {
                        Config_DService conDSer = new Config_DService(db);
                        position = conDSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                    }
                    deptNm = u.DepartmentName;
                    this.hdnDepartmentID.Value = u.DepartmentID.ToString();
                }

                if (s != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = s.StaffName;
                    this.txtDepartment.Value = deptNm;
                    this.txtPosition.Value = position;
                    this.ResetValueForHeaderDays(DEFAULT_VALUE, u.ID);
                }
            }
            else
            {
                this.lblUsedDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblPlanDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblExpriedDays.InnerText = ZERO_DEC.ToString("N1");
                this.lblRemainDays.InnerText = ZERO_DEC.ToString("N1");
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;

                this.lblTotalDays.InnerText = ZERO_DEC.ToString("N1");
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.InitUserInfo(this.LoginInfo.User.ID);
            this.txtVactionDtFrm.Value = DateTime.Now;
            this.txtVactionDtTo.Value = DateTime.Now;

            this.txtUseDays.Value = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value).ToString("N1");
            this.hdnFormIDDefault.Value = LEAVE_TEMPLATE.ToString();
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();
            this.GetTimesHeader(this.LoginInfo.User.ID);

            this.InitDataDropdownType(this.cmbTypeVacation);

            this.DataID = DEFAULT_VALUE;
            this.PreApplyID = null;
            this.btnViewPreVacation.Text = string.Empty;
        }

        /// <summary>
        /// InitTimesHeader
        /// </summary>
        private void GetTimesHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            M_Accounting acc;
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                acc = accSer.GetData();
                
            }

            if (acc != null)
            {
                lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
            }
            this.rptTimesHeader.DataSource = lstMonth;
            this.rptTimesHeader.DataBind();

            this.GetTimesValue(lstMonth, userID);
        }

        /// <summary>
        /// Init Times Value
        /// </summary>
        private void GetTimesValue(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();
                using (DB db = new DB())
                {
                    AccountingService accSer = new AccountingService(db);
                    M_Accounting data = accSer.GetData();
                    if (data != null)
                    {
                        foreach (var item in lstMonth)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkVacationService vacSer = new WorkVacationService(db);
                            decimal usedDay = vacSer.GetUsedDaysInMonth(userID, period);
                            if (usedDay != 0m)
                            {
                                lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                            }
                            else
                            {
                                lstMonthVal.Add(new StringModel(string.Empty));
                            }
                        }
                            
                    }
                }         

                this.rptTimes.DataSource = lstMonthVal;
                this.rptTimes.DataBind();
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            this.InitDropdownRoute(ddl, list);
        }

        /// <summary>
        /// InitDataDropdownRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        private void InitDropdownRoute(DropDownList ddl, IList<M_Route_H> list)
        {
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            this.LoadDataForApproveListFromRoute((list != null && list.Count > 0) ? int.Parse(this.cmbRoute.SelectedValue) : DEFAULT_VALUE);

        }

        /// <summary>
        /// InitDataDropdownType
        /// </summary>
        /// <param name="ddl"></param>
        private void InitDataDropdownType(DropDownList ddl)
        {
            /*
             //TRUC 2015-07-06 Doi logic , lay type tu config len
             using (DB db = new DB())
            {
                WorkShiftService wrkSer = new WorkShiftService(db);
                ddl.DataSource = wrkSer.GetDataForDropDown((int)ShiftType.PaidVacation);
            }            
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind(); */
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                ddl.DataSource = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.InitData();

            this.chkIsAgent.Checked = false;
            this.txtReason.Value = string.Empty;
        }

        #region Insert data

        /// <summary>
        /// GetTimeByVacationType
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private AccountingPeriod GetTimeByVacationType(int type, DateTime startDt, DateTime endDt)
        {
            AccountingPeriod ret = new AccountingPeriod();
            string value3 = string.Empty;
            using (DB db = new DB())
            {
                Config_DService ser = new Config_DService(db);
                value3 = ser.GetValue3(M_Config_H.CONFIG_CD_VACATION_TYPE, type);
            }
            var lstVal = new List<string>(value3.Split('-'));
            if (lstVal.Count == 2)
            {
                string startDateStr = lstVal[0].Trim();
                string endDateStr = lstVal[1].Trim();
                var lstStart = new List<string>(startDateStr.Split(':'));
                int startHour = 0;
                int startMin = 0;
                if (lstStart.Count == 2 && int.TryParse(lstStart[0], out startHour) && int.TryParse(lstStart[1], out startMin))
                {
                    ret.StartDate = new DateTime(startDt.Year, startDt.Month, startDt.Day, startHour, startMin, 0);
                }

                var lstEnd = new List<string>(endDateStr.Split(':'));
                int endHour = 0;
                int endMin = 0;
                if (lstEnd.Count == 2 && int.TryParse(lstEnd[0], out endHour) && int.TryParse(lstEnd[1], out endMin))
                {
                    ret.EndDate = new DateTime(endDt.Year, endDt.Month, endDt.Day, endHour, endMin, 0);
                }
            }
            if (type == (int)VacationType.DayOff && startDt == endDt)
            {
                M_Work_Shift wrkShift = null;
                using (DB db = new DB())
                {
                    WorkShiftService wkSer = new WorkShiftService(db);
                    wrkShift = wkSer.GetByDate(startDt);
                }
                if (wrkShift != null)
                {
                    if (wrkShift.TypeOfDay == (int)TypeOfDay.HalfWorkDay)//Lam viec nua ngay
                    {
                        ret.EndDate = new DateTime(endDt.Year, endDt.Month, endDt.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                if (this.IsExistCancel())
                {
                    this.RestoreListApprove();
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);
                    return false;
                }
                //M_Work_Shift shift = new M_Work_Shift();
                //using (DB db = new DB())
                //{
                //    WorkShiftService shiftSer = new WorkShiftService(db);
                //    shift = shiftSer.GetByID(int.Parse(this.cmbTypeVacation.SelectedValue));
                //}

                //if (shift != null)
                //{
                //    int dayOffType = shift.TypeOfDay;
                //    if (this.IsDuplicateApplyTime(this.DataNo, dayOffType))
                //    {
                //        this.RestoreListApprove();
                //        this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                //        return false;
                //    }
                //}

                if (this.IsDuplicateApplyTime(this.DataNo, int.Parse(this.cmbTypeVacation.SelectedValue)))
                {
                    this.RestoreListApprove();
                    this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    return false;
                }

                //Create model
                T_Work_Vacation data = new T_Work_Vacation();

                //Neu dang lam ma co nguoi khac cancel truoc thi phieu nay co phat hien ra ko????
                using (DB db = new DB())
                {
                    TNoService noService = new TNoService(db);
                    data = this.CreateApplyData(noService.CreateNo(T_No.No), PreApplyID.HasValue);
                }

                T_Work_ApplyTime wrkATime = this.GetApplyTime(data);
                //Insert
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkVacationService service = new WorkVacationService(db);
                    this.DataID = service.Insert(data);
                    this.ApplyStatus = data.ApplyStatus;
                    if (!this.PreApplyID.HasValue)
                    {
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        wrkAppSer.Insert(wrkATime);
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Work_Vacation_PK))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "Vacation");
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// GetApplyTimeForInsert
        /// </summary>
        /// <returns></returns>
        private T_Work_ApplyTime GetApplyTime(T_Work_Vacation vac)
        {
            T_Work_ApplyTime ret = new T_Work_ApplyTime();
            ret.ApplyNo = vac.No;
            ret.UserID = vac.UserID;
            DateTime start = DateTime.MinValue;
            DateTime end = DateTime.MinValue;

            //M_Work_Shift wrkShift = null;
            //using (DB db = new DB())
            //{
            //    WorkShiftService wShiftSer = new WorkShiftService(db);
            //    wrkShift = wShiftSer.GetByID(vac.VacationType);
            //}
            //if (wrkShift != null)
            //{
            //    if (wrkShift.TypeOfDay == (int)TypeOfDay.HalfDayOff)//half day
            //    {
            //        start = new DateTime(vac.StartDate.Year, vac.StartDate.Month, vac.StartDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
            //        end = new DateTime(vac.EndDate.Year, vac.EndDate.Month, vac.EndDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);
            //    }
            //    else if (wrkShift.TypeOfDay == (int)TypeOfDay.DayOff)//a day
            //    {
            //        start = new DateTime(vac.StartDate.Year, vac.StartDate.Month, vac.StartDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
            //        end = new DateTime(vac.EndDate.Year, vac.EndDate.Month, vac.EndDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);
            //    }
            //}

            AccountingPeriod acc = this.GetTimeByVacationType(vac.VacationType, vac.StartDate, vac.EndDate);
            if (acc != null)
            {
                start = new DateTime(vac.StartDate.Year, vac.StartDate.Month, vac.StartDate.Day, acc.StartDate.Hour, acc.StartDate.Minute, 0);
                end = new DateTime(vac.EndDate.Year, vac.EndDate.Month, vac.EndDate.Day, acc.EndDate.Hour, acc.EndDate.Minute, 0);
            }
            ret.StartTime = start;
            ret.EndTime = end;
            return ret;
        }

        #endregion

        #region Update data

        private T_Work_Vacation GetDataForUpdate(int appID)
        {
            T_Work_Vacation data;
            data = this.GetApplyByID(appID);

            data.VacationType = int.Parse(this.cmbTypeVacation.SelectedValue);
            M_Work_Shift wShift = null;
            using (DB db = new DB())
            {
                WorkShiftService wsSer = new WorkShiftService(db);
                wShift = wsSer.GetByID(data.VacationType);
            }
            if (wShift != null)
            {
                switch (wShift.TypeOfDay)
                {
                    case (int)TypeOfDay.DayOff:
                        data.StartDate = this.txtVactionDtFrm.Value.Value;
                        data.EndDate = this.txtVactionDtTo.Value.Value;
                        data.Duration = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
                        break;

                    case (int)TypeOfDay.HalfDayOff:
                        data.StartDate = this.txtVactionDtFrm.Value.Value;
                        data.EndDate = data.StartDate;
                        decimal days = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
                        if (days > decimal.Zero)
                        {
                            data.Duration = 0.5m;
                        }
                        break;
                }
            }

            if (this.cmbRoute.Items.Count > 0)
            {
                data.RouteID = int.Parse(this.cmbRoute.SelectedValue);
            }

            if (data.PreApplyID.HasValue)
            {
                data.Reason = this.txtReasonCancel.Text;
            }
            else
            {
                data.Reason = this.txtReason.Text;
            }

            data.UpdateDate = this.OldUpdateDate;
            data.UpdateUID = this.LoginInfo.User.ID;

            return data;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {

                if (this.IsDuplicateApplyTime(this.DataNo, int.Parse(this.cmbTypeVacation.SelectedValue)))
                {
                    this.RestoreListApprove();
                    this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    return false;
                }

                int ret = 0;
                T_Work_Vacation data = this.CreateApplyData(this.DataNo, this.PreApplyID.HasValue);//this.GetDataForUpdate(this.DataID);
                if (data != null)
                {
                    //M_Work_Shift shift = new M_Work_Shift();
                    //using (DB db = new DB())
                    //{
                    //    WorkShiftService shiftSer = new WorkShiftService(db);
                    //    shift = shiftSer.GetByID(int.Parse(this.cmbTypeVacation.SelectedValue));
                    //}
                    //if (shift != null)
                    //{
                    //    if (this.IsDuplicateApplyTime(this.DataNo, shift.TypeOfDay))
                    //    {
                    //        this.RestoreListApprove();
                    //        this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    //        return false;
                    //    }
                    //}

                    T_Work_ApplyTime wrkATime = this.GetApplyTime(data);
                    //Update data
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkVacationService service = new WorkVacationService(db);

                        //Update
                        if (data.Status == DataStatus.Changed)
                        {
                            //Update T_Work_Vacation
                            data.UpdateDate = this.OldUpdateDate;

                            ret = service.Update(data);
                            if (ret > 0)
                            {
                                if (!this.PreApplyID.HasValue)
                                {
                                    WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                                    ret = wrkAppSer.Update(wrkATime);
                                }

                                if (ret > 0)
                                {
                                    db.Commit();
                                }
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Confirm

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool Confirm()
        {
            ApplyFucntion appFunc = new ApplyFucntion(this.DataID, this.LoginInfo.User, ApplyType.Vacation, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));
            bool ret = false;
            ProcessResult proc = appFunc.Confirm();
            switch (proc)
            {
                case ProcessResult.Success:
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;

            #region OLD
            /* bool success = false;
            try
            {
                int ret = 0;
                T_Work_Vacation data = this.GetApplyByID(this.DataID);
                if (data != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkVacationService service = new WorkVacationService(db);

                        //Update StatusFlag
                        ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (int)StatusApply.Approving, 0, this.OldUpdateDate);
                        if (ret == 1)
                        {
                            //Insert into T_Work_Approve tabable
                           // IList<WorkApproveModel> approveUserlist = this.GetListApprovePerson(db, data.RouteID, true);
                           // IList<T_Work_Approve> applyApproveLst = this.CreateApplyApproveListData(service.GetByID(this.DataID), approveUserlist);
                           // WorkApproveService applyApproveSer = new WorkApproveService(db);

                           // if (applyApproveLst.Count == 0)
                           // {
                           //     this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
                           //     return false;
                           // }

                           // //foreach (T_Work_Approve item in applyApproveLst)
                           // //{
                           // //    applyApproveSer.Insert(item);
                           // //}
                            WorkApproveService applyApproveSer = new WorkApproveService(db);
                            ret = applyApproveSer.Insert(data.RouteID, this.DataNo, -1, (short)StatusHasAprove.New);

                        }
                        //Check result update
                        if (ret == 0)
                        {
                            //Data is changed
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        db.Commit();
                        success = true;
                    }
                }
            }
            catch (Exception ex)
            {
                //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            //TRAM - 2015/05/28 - Send Email for Confirm
            
            try
            {
                //Send mail
                if (success)
                {
                    IList<string> lstEmail = this.GetListEmail();
                    StringBuilder mailBody = new StringBuilder();
                    if (lstEmail != null && lstEmail.Count > 0)
                    {
                        mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                        mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                        string type = this.cmbTypeVacation.SelectedItem.Text;
                        mailBody.AppendLine("Type: " + type);
                        mailBody.AppendLine("Reason: " + this.txtReason.Text);
                        string sSubject = string.Empty;
                        if (lstEmail.Count == 1)
                        {
                            sSubject = "There is " + lstEmail.Count + " requirement for approving";
                        }
                        else
                        {
                            sSubject = "There are " + lstEmail.Count + " requirements for approving";
                        }

                        CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);

                    }
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            //TRAM - 2015/05/28 - Send Email for Confirm - END

            return true;*/
            #endregion
        }

        #endregion

        #region  Delete Data

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Work_Vacation apply = this.GetApplyByID(this.DataID);
                if (apply != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkVacationService service = new WorkVacationService(db);

                        apply.StatusFlag = (int)DeleteFlag.Deleted;
                        apply.ID = this.DataID;
                        apply.UpdateUID = LoginInfo.User.ID;
                        apply.UpdateDate = this.OldUpdateDate;

                        //Update StatusFlag
                        ret = service.UpdateStatusFlag(apply);
                        if (ret != 0 && !this.PreApplyID.HasValue)
                        {
                            WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                            ret = wrkAppSer.Delete(apply.No);
                        }
                        if (ret != 0)
                        {
                            db.Commit();
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Get data

        /// <summary>
        /// GetByApplyNo
        /// </summary>
        /// <returns></returns>
        private T_Work_Vacation GetByApplyNo(string AppNo)
        {
            using (DB db = new DB())
            {
                T_Work_Vacation apply = new T_Work_Vacation();
                WorkVacationService appSer = new WorkVacationService(db);
                apply = appSer.GetByApplyNo(AppNo);
                return apply;
            }
        }

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns></returns>
        private T_Work_Vacation GetApplyByID(int AppID)
        {
            using (DB db = new DB())
            {
                T_Work_Vacation apply = new T_Work_Vacation();
                WorkVacationService appSer = new WorkVacationService(db);
                apply = appSer.GetByID(AppID);
                return apply;
            }
        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(vacNo, isIncludeView, includeZeroLV);
            }
        }

        /// <summary>
        /// Load Data Approve List From Route
        /// </summary>
        private void LoadDataForApproveListFromRoute(int routeID)
        {
            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
            using (DB db = new DB())
            {
                Route_DService service = new Route_DService(db);
                //Get Approve List           
                approverList = service.GetApproverListByRouteIDForWork(routeID, true, EnumGetLevelZero.Exclude);
            }
            this.rptApproverList.DataSource = approverList;
            this.ApproverList = new List<WorkApproveModel>(approverList);
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// isHasData
        /// </summary>
        /// <returns></returns>
        public bool isHasData()
        {
            return (this.ApproverList != null && this.ApproverList.Count > 0);
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadDataForApproveListFromApproveList(string vacNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);

            if (applyList != null && applyList.Count != 0)
            {
                this.ApproverList = new List<WorkApproveModel>(applyList);
                this.rptApproverList.DataSource = applyList;
                this.ApproverList = new List<WorkApproveModel>();
                ((List<WorkApproveModel>)this.ApproverList).AddRange(applyList);
            }
            else
            {
                this.ApproverList = new List<WorkApproveModel>();
                this.rptApproverList.DataSource = null;
                this.ApproverList = null;
            }
            this.rptApproverList.DataBind();
        }

        #endregion

        #region Set data

        /// <summary>
        /// SetValueForHiddenProxy
        /// </summary>
        private void SetValueForHiddenProxy(int routeID)
        {
            bool applyFlag1 = false;
            bool applyFlag2 = false;

            M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
            if (routeD != null)
            {
                applyFlag1 = routeD.ApplyFlag1 == 1;
                applyFlag2 = routeD.ApplyFlag2 == 1;
            }
            if (applyFlag1)//Proxy All in a route
            {
                // this.chkIsAgent.Enabled = true;
                this.hdnProxyAll.Value = "1";
            }
            else if (applyFlag2)//Proxy Dept.
            {
                //this.chkIsAgent.Enabled = true;
                this.hdnProxyDept.Value = "1";
            }
            else
            {
                // this.chkIsAgent.Enabled = false;
            }

        }

        /// <summary>
        /// GetRouteLevelZeroByRouteID
        /// </summary>
        /// <param name="RouteID"></param>
        /// <returns></returns>
        private M_Route_D GetRouteLevelZeroByRouteID(int RouteID)
        {
            using (DB db = new DB())
            {
                Route_DService routeSer = new Route_DService(db);
                var lstItem = routeSer.GetByRouteIDForWork(RouteID, isGetLVZero: EnumGetLevelZero.Only);
                if (lstItem != null && lstItem.Count > 0)
                {
                    return lstItem[0];
                }
            }
            return null;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.ClearUpdateInfo();
                    this.ApplyStatus = (int)StatusApply.Draft;

                    this.chkIsAgent.Checked = false;
                    this.chkIsAgent.Enabled = true;
                    this.txtReason.SetReadOnly(false);
                    this.cmbTypeVacation.Enabled = true;
                    this.txtVactionDtFrm.SetReadOnly(false);
                    this.txtVactionDtTo.SetReadOnly(false);
                    this.cmbRoute.Enabled = true;
                    if (this.cmbRoute.DataSource != null && this.cmbRoute.Items.Count > 0)
                    {
                        this.SetValueForHiddenProxy(int.Parse(this.cmbRoute.SelectedValue));
                    }
                    else
                    {
                        // this.chkIsAgent.Enabled = false;
                    }
                    break;
                case Mode.Copy:
                    ClearUpdateInfo();
                    this.ApplyStatus = (int)StatusApply.Draft;
                    this.txtApplyNo.Value = string.Empty;

                    this.chkIsAgent.Enabled = true;
                    this.txtVactionDtFrm.SetReadOnly(false);
                    this.txtVactionDtTo.SetReadOnly(false);
                    this.cmbRoute.Enabled = true;
                    this.cmbTypeVacation.Enabled = true;
                    this.txtReason.SetReadOnly(false);

                    break;

                case Mode.Update:
                    if (!this.PreApplyID.HasValue)
                    {
                        this.txtReason.SetReadOnly(false);
                        this.cmbTypeVacation.Enabled = true;
                        this.txtVactionDtFrm.SetReadOnly(false);
                        this.txtVactionDtTo.SetReadOnly(false);
                        this.cmbRoute.Enabled = true;
                        this.chkIsAgent.Enabled = true;
                        if (this.cmbRoute.DataSource != null && this.cmbRoute.Items.Count > 0)
                        {
                            this.SetValueForHiddenProxy(int.Parse(this.cmbRoute.SelectedValue));
                        }
                        else
                        {
                            //  this.chkIsAgent.Enabled = false;
                        }

                        if (this.ApplyStatus != (int)StatusApply.Draft)
                        {
                            base.DisabledLink(this.btnEdit, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                        }
                    }
                    else
                    {
                        this.txtReason.SetReadOnly(true);
                        this.txtReasonCancel.SetReadOnly(false);
                    }

                    break;


                case Mode.Delete:

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.SetReadOnly(true);
                    this.chkIsAgent.Enabled = false;
                    this.txtVactionDtFrm.SetReadOnly(true);
                    this.txtVactionDtTo.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.cmbTypeVacation.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;

                case Mode.Confirm:
                    this.ApplyStatus = (int)StatusApply.Draft;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;
                case Mode.Cancel:
                    this.txtApplyNo.Value = string.Empty;
                    this.ApplyStatus = (int)StatusApply.Cancel;
                    this.dtApplyDate.Value = null;
                    this.cmbRoute.Enabled = true;

                    break;
                default:

                    this.chkIsAgent.Enabled = false;
                    this.txtVactionDtFrm.SetReadOnly(true);
                    this.txtVactionDtTo.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.cmbTypeVacation.Enabled = false;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.Draft:
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                            base.DisabledLink(this.btnDelete, !base._authority.IsApplyRegistDelete);
                            base.DisabledLink(this.btnConfirm, !base._authority.IsApplyRegistConfirm);
                            break;

                        case (int)StatusApply.Approving:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;
                        case (int)StatusApply.Approved:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Rejected:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Cancel:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, false);
                            break;
                    }

                    T_Work_Vacation app = new T_Work_Vacation();
                    using (DB db = new DB())
                    {
                        WorkVacationService appSer = new WorkVacationService(db);
                        app = appSer.GetByID(this.DataID);
                    }

                    if (app == null)
                    {
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnConfirm, true);
                    }

                    break;
            }
            base.DisabledLink(this.btnSearchList, true);
            this.txtUseDays.SetReadOnly(true);
            if (this.chkIsAgent.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Update || this.Mode == Mode.Copy))
            {
                this.txtEmployeeCD.SetReadOnly(false);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="isWithoutVacID">is Get Days by VacID</param>
        private void ShowData(T_Work_Vacation apply, bool isWithoutVacID = false)
        {
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();
            //Show data
            if (apply != null)
            {
                //Re-Init value for combobox Route
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, apply.UserID);

                int vactionID = DEFAULT_VALUE;
                if (isWithoutVacID)
                {
                    vactionID = apply.ID;
                }
                M_UserInfo user = new M_UserInfo();
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    user = userSer.GetUserInfoByID(apply.UserID);
                }
                this.txtApplyNo.Value = apply.No;
                this.dtApplyDate.Value = apply.ApplyDate;
                if (apply.UserID.Equals(apply.CreateUID) || apply.UserID.Equals(this.LoginInfo.User.ID))
                {
                    this.chkIsAgent.Checked = false;
                }
                else
                {
                    this.chkIsAgent.Checked = true;
                }


                if (user != null)
                {
                    using (DB db = new DB())
                    {
                        StaffService staffSer = new StaffService(db);
                        M_Staff s = staffSer.GetByID(user.StaffID);
                        if (s != null)
                        {
                            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                            this.txtEmployeeNm.Value = s.StaffName;

                            this.txtPosition.Value = (new Config_DService(db)).GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                        }
                    }
                    this.txtDepartment.Value = user.DepartmentName;
                    this.hdnDepartmentID.Value = user.DepartmentID.ToString();
                    this.hdnUserID.Value = user.ID.ToString();
                    this.ResetValueForHeaderDays(vactionID, user.ID);
                    this.GetTimesHeader(user.ID);
                }

                this.hdnRouteID.Value = apply.RouteID.ToString();
                this.cmbRoute.SelectedValue = apply.RouteID.ToString();
                this.txtUseDays.Value = apply.Duration.HasValue ? apply.Duration.Value.ToString("N1") : string.Empty;
                this.DataID = apply.ID;
                this.DataNo = apply.No;
                this.txtVactionDtFrm.Value = apply.StartDate;
                this.txtVactionDtTo.Value = apply.EndDate;
                this.ApplyStatus = apply.ApplyStatus;
                this.PreApplyID = apply.PreApplyID;
                this.VacationTypeForm = apply.VacationType;
                this.cmbTypeVacation.SelectedValue = apply.VacationType.ToString();

                if (this.PreApplyID.HasValue)
                {
                    T_Work_Vacation preApp = new T_Work_Vacation();
                    using (DB db = new DB())
                    {
                        WorkVacationService ser = new WorkVacationService(db);
                        preApp = ser.GetByID(this.PreApplyID.Value);
                    }
                    if (preApp != null)
                    {
                        this.btnViewPreVacation.Text = preApp.No;
                        this.txtReason.Value = preApp.Reason;
                        this.txtReasonCancel.Value = apply.Reason;
                        this.hdnApplyID.Value = preApp.ID.ToString();
                    }
                }
                else
                {
                    this.txtReason.Value = apply.Reason;
                }
                M_User createUser = new M_User();
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    createUser = userSer.GetByID(apply.CreateUID);
                }
                if (createUser != null)
                {
                    var createDate = (apply.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }

                M_User updateUser = new M_User();
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    updateUser = userSer.GetByID(apply.UpdateUID);
                }
                if (updateUser != null)
                {
                    var updateDate = (apply.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }

                this.isExistCancel = this.IsExistCancel();
                this.OldUpdateDate = apply.UpdateDate;
                if (apply.ApplyStatus == (int)StatusApply.Draft || apply.ApplyStatus == (int)StatusApply.Cancel)//chua confirm
                {
                    this.LoadDataForApproveListFromRoute(apply.RouteID);
                }
                else
                {
                    this.LoadDataForApproveListFromApproveList(apply.No, true);
                }
            }
        }

        /// <summary>
        /// GetRouteByUserID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_Route_H GetRouteByUserID(int userID)
        {
            using (DB db = new DB())
            {
                Route_HService service = new Route_HService(db);
                return service.GetByTypeAndUserIDForWork(LEAVE_TEMPLATE, userID);
            }
        }

        /// <summary>
        /// Create Apply data
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private T_Work_Vacation CreateApplyData(string appNo, bool isCancel = false)
        {
            T_Work_Vacation data;
            data = this.GetByApplyNo(appNo);
            if (data == null)
            {
                data = new T_Work_Vacation();
            }
            data.ApplyDate = null;
            data.No = appNo;
            data.ApplyStatus = (int)StatusApply.Draft;

            if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
            {
                data.PreApplyID = null;
            }
            else if (this.Mode == Mode.Cancel)
            {
                data.PreApplyID = this.PreApplyID;
            }

            if (this.chkIsAgent.Checked)
            {
                M_StaffInfo staff = this.GetStaffInfoByCD(this.txtEmployeeCD.Value.Trim());
                if (staff != null)
                {
                    data.UserID = staff.UserID;
                }
            }
            else
            {
                data.UserID = LoginInfo.User.ID;
            }

            if (this.cmbRoute.Items.Count > 0)
            {
                data.RouteID = int.Parse(this.cmbRoute.SelectedValue);
            }

            data.VacationType = int.Parse(this.cmbTypeVacation.SelectedValue);
            /******** M_Work_Shift wShift = null;
             using (DB db = new DB())
             {
                 WorkShiftService wsSer = new WorkShiftService(db);
                 wShift = wsSer.GetByID(data.VacationType);
             }
             if (wShift != null)
             {
                 switch (wShift.TypeOfDay)
                 {
                     case (int)TypeOfDay.DayOff:
                         data.StartDate = this.txtVactionDtFrm.Value.Value;
                         data.EndDate = this.txtVactionDtTo.Value.Value;
                         data.Duration = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
                         break;

                     case (int)TypeOfDay.HalfDayOff:
                         data.StartDate = this.txtVactionDtFrm.Value.Value;
                         data.EndDate = data.StartDate;
                         decimal days = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtFrm.Value.Value);
                         if (days > decimal.Zero)
                         {
                             data.Duration = 0.5m;
                         }
                         break;
                 }
             }*************/

            
            if (data.VacationType == (int)VacationType.DayOff)
            {
                data.StartDate = this.txtVactionDtFrm.Value.Value;
                data.EndDate = this.txtVactionDtTo.Value.Value;
                data.Duration = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
            }
            else
            {
                data.StartDate = this.txtVactionDtFrm.Value.Value;
                data.EndDate = data.StartDate;
                decimal days = this.GetUsesDays(data.StartDate, data.EndDate);
                if (days > decimal.Zero)
                {
                    data.Duration = 0.5m;
                }
            }
            if (isCancel)
            {
                data.Reason = this.txtReasonCancel.Text;
            }
            else
            {
                data.Reason = this.txtReason.Text;
            }
            data.CreateUID = base.LoginInfo.User.ID;
            data.UpdateUID = base.LoginInfo.User.ID;
            return data;
        }

        /// <summary>
        /// Create data for ApplyApproveList 
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="lstApproveUser"></param>
        private IList<T_Work_Approve> CreateApplyApproveListData(T_Work_Vacation apply, IList<WorkApproveModel> lstApproveUser)
        {
            IList<T_Work_Approve> applyApproveList = new List<T_Work_Approve>();
            foreach (WorkApproveModel item in lstApproveUser)
            {
                T_Work_Approve model = new T_Work_Approve();
                Hashtable htbUserID = new Hashtable();
                model.ApplyNo = apply.No;
                if (item.RouteLevel == M_Route_H.LEVEL_APPLICANT)
                {
                    model.RouteUID = apply.UserID;
                }
                else
                {
                    model.RouteUID = item.RouteUID;
                }
                model.RouteLevel = item.RouteLevel.Value;
                model.RouteMethod = item.RouteMethod.Value;
                model.ApproveUID = item.ApproveUID;
                model.ApproveDate = item.ApproveDate;
                model.ApproveReason = item.ApproveReason;
                model.RequireNum = item.RequireNum;
                model.ApproveStatus = (int)StatusHasAprove.New;

                model.ProxyApprovalUser = item.ProxyApprovalUser;
                //Apply Flag
                model.ApplyFlag1 = item.ApplyFlag1;
                model.ApplyFlag2 = item.ApplyFlag2;
                model.ApplyFlag3 = item.ApplyFlag3;
                model.ApplyFlag4 = item.ApplyFlag4;

                //Reject Flag
                model.RejectFlag1 = item.RejectFlag1;
                model.RejectFlag2 = item.RejectFlag2;
                model.RejectFlag3 = item.RejectFlag3;
                model.RejectFlag4 = item.RejectFlag4;
                model.RejectFlag5 = item.RejectFlag5;
                model.RejectFlag6 = item.RejectFlag6;
                model.RejectFlag7 = item.RejectFlag7;

                //Remand Flag
                model.RemandFlag1 = item.RemandFlag1;
                model.RemandFlag2 = item.RemandFlag2;
                model.RemandFlag3 = item.RemandFlag3;
                model.RemandFlag4 = item.RemandFlag4;
                model.RemandFlag5 = item.RemandFlag5;
                model.RemandFlag6 = item.RemandFlag6;
                model.RemandFlag7 = item.RemandFlag7;

                //Approve Flag
                model.ApproveFlag1 = item.ApproveFlag1;
                model.ApproveFlag2 = item.ApproveFlag2;
                model.ApproveFlag3 = item.ApproveFlag3;
                model.ApproveFlag4 = item.ApproveFlag4;
                model.ApproveFlag5 = item.ApproveFlag5;
                model.ApproveFlag6 = item.ApproveFlag6;
                model.ApproveFlag7 = item.ApproveFlag7;
                model.ApproveFlag8 = item.ApproveFlag8;
                model.ApproveFlag9 = item.ApproveFlag9;

                //Read Flag
                model.ReadFlag1 = item.ReadFlag1;
                model.ReadFlag2 = item.ReadFlag2;
                model.ReadFlag3 = item.ReadFlag3;
                model.ReadFlag4 = item.ReadFlag4;
                model.ReadFlag5 = item.ReadFlag5;

                applyApproveList.Add(model);
            }

            return applyApproveList;
        }

        /// <summary>
        /// Change Employee Textbox
        /// </summary>
        private void EmployeeTextChange()
        {
            int loginRouteID = int.Parse(this.hdnRouteID.Value);

            M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
            if (s != null)
            {
                M_User u = this.GetUserByStaffID(s.ID);
                if (u != null)
                {
                    string loginUserCD = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                    string userCD = EditDataUtil.ToFixCodeShow(u.UserCD, M_User.MAX_USER_CODE_SHOW);
                    if (userCD.Equals(loginUserCD))//Is login user
                    {
                        this.chkIsAgent.Checked = false;
                        this.GetTimesHeader(u.ID);
                        this.InitUserInfo(u.ID);
                        this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, u.ID);
                    }
                    else//user other
                    {
                        if (this.IsSameRoute(u.ID, this.LoginInfo.User.ID))
                        {
                            this.GetTimesHeader(u.ID);
                            this.InitUserInfo(u.ID);
                            this.InitDropdownRoute(this.cmbRoute, this.GetListRouteByUserID(u.ID, this.LoginInfo.User.ID));
                        }
                        else
                        {
                            this.GetTimesHeader(DEFAULT_VALUE);
                            this.InitUserInfo(DEFAULT_VALUE);
                            this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
                        }
                    }
                }
                else
                {
                    this.GetTimesHeader(DEFAULT_VALUE);
                    this.InitUserInfo(DEFAULT_VALUE);
                    this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
                }
            }
            else
            {
                this.GetTimesHeader(DEFAULT_VALUE);
                this.InitUserInfo(DEFAULT_VALUE);
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
            }

        }

        #region Check data

        /// <summary>
        /// IsExistCancel
        /// </summary>
        /// <returns></returns>
        private bool IsExistCancel()
        {

            if (ViewState["DataID"] != null)
            {
                T_Work_Vacation app = new T_Work_Vacation();
                using (DB db = new DB())
                {
                    WorkVacationService appSer = new WorkVacationService(db);
                    app = appSer.GetByPreApplyID(this.DataID);
                }
                if (app != null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check Author intermediary(check co quyen xin gium ngkhac ko)
        /// </summary>
        /// <returns></returns>
        private bool CheckAuthor(string focusID)
        {
            if (this.chkIsAgent.Checked)//dang xin gium ngkhac
            {
                int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
                if (routeD != null)
                {
                    // proxy all
                    if (routeD.ApplyFlag1 != 1 && routeD.ApplyFlag2 != 1)//ko co quyen xin cho ngkhac
                    {
                        this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                    }

                    // proxy dept
                    if (routeD.ApplyFlag2 == 1)
                    {
                        using (DB db = new DB())
                        {
                            StaffService staffSer = new StaffService(db);
                            M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                            if (s != null)
                            {
                                if (s.DepartmentID != this.LoginInfo.Department.ID)
                                {
                                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                                }
                            }
                        }
                    }
                }
                else//ko co quyen xin gium ngkhac
                {
                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Get Shift By ID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_Work_Shift GetShiftByID(int ID)
        {
            using (DB db = new DB())
            {
                WorkShiftService wsSer = new WorkShiftService(db);
                return wsSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Check Employee(Check du lieu cua nguoi dc xin gium hop le)
        /// </summary>
        /// <returns></returns>
        private bool CheckEmployee(M_Route_D routeD, string focusID)
        {
            if (routeD != null)
            {
                //Check employee's department is the same department with login user
                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                    if (s != null)
                    {
                        //luon luon check trong cung 1 route(ko can ApplyFlag1)
                        //if (this.IsSameRoute(this.LoginInfo.User.UserCD, this.GetUserInfoByID(s.UserID).UserCD))//cung route
                        if (this.IsSameRoute(this.LoginInfo.User.ID, s.UserID))//cung route
                        {
                            //Gioi han trong pham vi dept.
                            if (routeD.ApplyFlag2 == 1)
                            {
                                if (!s.DepartmentID.Equals(this.LoginInfo.Department.ID))//khac dept. --> loi
                                {
                                    this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                                }
                            }
                        }
                        else//ko cung route --> loi
                        {
                            this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                        }

                    }
                    else
                    {
                        this.SetMessage(focusID, M_Message.MSG_VALUE_NOT_EXIST, "Applicant");
                    }
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check inputing
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(bool isConfirm = false)
        {
            string focusID = this.Mode == Mode.Update ? this.txtVactionDtFrm.ID : this.txtEmployeeCD.ID;

            int UserID = this.LoginInfo.User.ID;
            //Neu xin ca ngay thi check them ngay ket thuc
            int typeOfDay = int.Parse(this.cmbTypeVacation.SelectedValue);
            //M_Work_Shift wShift = this.GetShiftByID(type);
            //TypeOfDay typeOfDay = TypeOfDay.DayOff;
            //if (wShift != null)
            //{                
            //    typeOfDay = (wShift.TypeOfDay == (int)TypeOfDay.DayOff) ? TypeOfDay.DayOff : TypeOfDay.HalfDayOff;
            //}

            #region Check require field

            if (!isConfirm)
            {
                //Employee
                if (this.chkIsAgent.Checked)//dang xin gium ngkhac
                {
                    if (this.txtEmployeeCD.IsEmpty)
                    {
                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_REQUIRE, "Applicant");
                    }
                    else
                    {
                        M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
                        if (s==null)
                        {
                            this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Applicant");
                        }
                    }
                }

                //Vacation Date From
                if (!this.txtVactionDtFrm.Value.HasValue)
                {
                    this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_REQUIRE, "Effect Date From");
                }

                if (typeOfDay == (int)VacationType.DayOff)
                {
                    //Vacation Date To
                    if (!this.txtVactionDtTo.Value.HasValue)
                    {
                        this.SetMessage(this.txtVactionDtTo.ID, M_Message.MSG_REQUIRE, "Effect Date To");
                    }

                    //compare 2 date
                    if (this.txtVactionDtFrm.Value.HasValue && this.txtVactionDtTo.Value.HasValue)
                    {
                        if (this.txtVactionDtTo.Value.Value < this.txtVactionDtFrm.Value.Value)
                        {
                            this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_LESS_THAN_EQUAL, "Effect Date From", "Effect Date To");
                        }
                    }
                }

                //Reason
                if (this.txtReason.IsEmpty)
                {
                    this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Apply Reason");
                }

                //Reason cancel
                if (this.PreApplyID.HasValue)
                {
                    if (this.txtReasonCancel.IsEmpty)
                    {
                        this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Cancel Reason");
                    }
                }

            }
            //route
            if (this.cmbRoute.Items.Count == 0)
            {
                this.SetMessage(isConfirm ? string.Empty : this.cmbRoute.ID, M_Message.MSG_PLEASE_SELECT, "Approval Route");
            }

            #endregion

            #region Check Date is valid

            //ko co loi require, check du lieu hop le
            if (!base.HaveError)
            {
                //Check data of workday
                bool isError = false;

                //Check co quyen xin gium ngkhac ko
                if (!this.CheckAuthor(isConfirm ? string.Empty : this.txtEmployeeCD.ID))//ko co quyen
                {
                    isError = true;
                }

                //check employee hop le
                if (this.chkIsAgent.Checked)
                {
                    int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                    M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
                    if (!this.CheckEmployee(routeD, isConfirm ? string.Empty : this.txtEmployeeCD.ID))
                    {
                        isError = true;
                    }
                }
                //Check data had set in workday
                if (!this.IsHaveDataDefault(this.txtVactionDtFrm.Value.Value))
                {
                    isError = true;
                    this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_CONTACT_MANAGER);
                }

                if (typeOfDay == (int)VacationType.DayOff)
                {
                    if (!this.IsHaveDataDefault(this.txtVactionDtTo.Value.Value))
                    {
                        isError = true;
                        this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtTo.ID, M_Message.MSG_CONTACT_MANAGER);
                    }
                }

                if (!isError)//ko co loi o tren
                {
                    isError = false;

                    //Check vacation in holidays date from
                    decimal useDay = this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtFrm.Value.Value);
                    if (useDay == decimal.Zero)//xin vao ngay ko lam viec
                    {
                        isError = true;
                        this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                    }
                    else
                    {
                        if (typeOfDay == (int)VacationType.MorningOff || typeOfDay == (int)VacationType.AfternoonOff)//xin nghi 1/2 ngay
                        {
                            AccountingPeriod accTime = this.GetTimeByVacationType(typeOfDay, this.txtVactionDtFrm.Value.Value, this.txtVactionDtFrm.Value.Value);
                            //Check lam nua ngay nhung nua sang hay nua chieu
                            using (DB db = new DB())
                            {
                                WorkShiftService wrkSSer = new WorkShiftService(db);
                                M_Work_Shift wkShf = wrkSSer.GetByDate(this.txtVactionDtFrm.Value.Value);
                                if (wkShf != null && accTime != null)
                                {
                                    if (wkShf.TypeOfDay == (int)TypeOfDay.HalfWorkDay)
                                    {
                                        //xin nghi phep vao ngay lam nua ngay va xin vao buoi ko lam viec
                                        // if (wShift.StartHour > wkShf.StartHour || wShift.EndHour < wkShf.EndHour)
                                        if (accTime.StartDate.Hour != wkShf.StartHour && accTime.EndDate.Hour != wkShf.EndHour)
                                        {
                                            isError = true;
                                            this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (typeOfDay == (int)VacationType.DayOff)
                    {
                        ////Check vacation in holidays date To
                        if (this.GetUsesDays(this.txtVactionDtTo.Value.Value, this.txtVactionDtTo.Value.Value) == decimal.Zero)
                        {
                            isError = true;
                            this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtTo.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                        }
                        if (!isError)//ngay bat dau, ngay ket thuc ko trung ngay nghi
                        {
                            //Check vacation in holidays date from -> to
                            if (this.GetUsesDays(this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value) == decimal.Zero)
                            {
                                this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                            }
                        }
                    }
                }
            }

            //Check existing of Effect Date in T_Work_Total
            if (!base.HaveError)
            {
                if (this.CheckExistingDateInWorkTotal())
                {
                    // this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_DATA_INVALID, "Effect Date");
                    this.SetMessage(this.txtVactionDtFrm.ID, M_Message.MSG_CANT_CONTINUE, this.txtVactionDtFrm.Value.Value.ToString(Constants.FMT_DATE));
                }
            }

            #endregion

            if (this.ApproverList != null && this.ApproverList.Count == 0)
            {
                this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
            }

            //Not error. Check Duplicate
            if (!base.HaveError && this.IsDuplicateApplyTime(this.DataNo, typeOfDay))
            {
                this.SetMessage(isConfirm ? string.Empty : this.txtVactionDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check existing of date in T_Work_Total
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="effectDateFrm"></param>
        /// <param name="effectDateTo"></param>
        /// <returns></returns>
        private bool IsExistingDateInWorkTotal(int userID, DateTime effectDateFrm, DateTime effectDateTo)
        {
            using (DB db = new DB())
            {
                WorkTotalService totalSer = new WorkTotalService(db);
                IList<T_Work_Total> totalList = totalSer.GetByCond(userID, effectDateFrm, effectDateTo);
                return totalList != null && totalList.Count > 0;
            }
        }

        /// <summary>
        /// Check existing of date in T_Work_Total
        /// </summary>
        /// <returns></returns>
        public bool CheckExistingDateInWorkTotal()
        {
            bool isExist = false;
            int typeOfDay = int.Parse(this.cmbTypeVacation.SelectedValue);
            if (typeOfDay == (int)VacationType.MorningOff || typeOfDay == (int)VacationType.AfternoonOff)
            {
                isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.txtVactionDtFrm.Value.Value, this.txtVactionDtFrm.Value.Value);
            }
            else if (typeOfDay == (int)VacationType.DayOff)
            {
                isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
            }
            //M_Work_Shift shift = new M_Work_Shift();
            //using (DB db = new DB())
            //{
            //    WorkShiftService shiftSer = new WorkShiftService(db);
            //    shift=shiftSer.GetByID(int.Parse(this.cmbTypeVacation.SelectedValue.ToString()));
            //}
            //if(shift!=null)
            //{
            // TypeOfDay dayOffType =(TypeOfDay) shift.TypeOfDay;
            //if (dayOffType == TypeOfDay.HalfDayOff)
            //{
            //    isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.txtVactionDtFrm.Value.Value, this.txtVactionDtFrm.Value.Value);
            //}
            //else if (dayOffType == TypeOfDay.DayOff)
            //{
            //    isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.txtVactionDtFrm.Value.Value, this.txtVactionDtTo.Value.Value);
            //}
            //}

            return isExist;
        }

        /// <summary>
        /// IsHaveDataDefault
        /// </summary>
        /// <param name="dateVal"></param>
        /// <returns></returns>
        private bool IsHaveDataDefault(DateTime dateVal)
        {
            using (DB db = new DB())
            {
                WorkDayService ser = new WorkDayService(db);
                if (ser.GetByWorkDate(dateVal) != null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// check SameRoute of 2 userCD
        /// </summary>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        //private bool IsSameRoute(string userCD1, string userCD2)
        //{
        //    IList<M_Route_H> lstRet = this.GetListRouteByUserCD(userCD1, userCD2);
        //    if (lstRet != null && lstRet.Count > 0)
        //    {
        //        return true;
        //    }
        //    return false;
        //}
        private bool IsSameRoute(int userID1, int userID2)
        {
            IList<M_Route_H> lstRet = this.GetListRouteByUserID(userID1, userID2);
            if (lstRet != null && lstRet.Count > 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// GetListRouteByUserCD
        /// </summary>
        /// <param name="userID1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        //private IList<M_Route_H> GetListRouteByUserCD(string userCD1, string userCD2)
        //{
        //    using (DB db = new DB())
        //    {
        //        Route_HService routeSer = new Route_HService(db);
        //        return routeSer.GetListRouteBy2UserCD(LEAVE_TEMPLATE, userCD1, userCD2);
        //    }
        //}

        private IList<M_Route_H> GetListRouteByUserID(int userID1, int userID2)
        {
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                return routeSer.GetListRouteBy2UserID(LEAVE_TEMPLATE, userID1, userID2);
            }
        }
        /// <summary>
        /// Check inputing for cancel mode
        /// </summary>
        /// <returns></returns>
        private bool CheckInputForCancel()
        {
            //Reason cancel

            if (this.txtReasonCancel.IsEmpty)
            {
                this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Reason Cancel");
            }

            if (this.cmbRoute.Items.Count == 0)
            {
                this.SetMessage(this.cmbRoute.ID, M_Message.MSG_PLEASE_SELECT, "Approval Route");
            }

            if (this.CheckExistingDateInWorkTotal())
            {
                this.SetMessage(string.Empty, M_Message.MSG_CANT_CONTINUE, this.txtVactionDtFrm.Value.Value.ToString(Constants.FMT_DATE));
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check Valid Annual
        /// </summary>
        /// <returns></returns>
        private bool CheckValidAnnual()
        {
            //So Ngay nghi du kien
            decimal annualDay = decimal.Parse(this.txtUseDays.Value);
            M_StaffInfo s = this.GetStaffInfoByCD(this.txtEmployeeCD.Text.Trim());
            if (s != null)
            {
                using (DB db = new DB())
                {
                    WorkVacationService applySer = new WorkVacationService(db);
                    //So ngay nghi con lai
                    decimal remain = applySer.GetRemainDays(this.DataID, s.UserID);
                    if (remain < annualDay)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    }
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Check duplicate time apply
        /// </summary>
        /// <param name="applyId"></param>
        /// <returns></returns>
        private bool IsDuplicateApplyTime(string appNo, int typeOfDay)
        {
            int userID = int.Parse(this.hdnUserID.Value);
            if (!string.IsNullOrEmpty(this.cmbTypeVacation.SelectedValue))
            {
                // M_Work_Shift wShift = null;
                DateTime fromDtSc = this.txtVactionDtFrm.Value.Value;
                DateTime fromDtDB = this.txtVactionDtFrm.Value.Value;
                DateTime toDtSc = fromDtSc;
                DateTime toDtDB = fromDtDB;

                if (typeOfDay == (int)VacationType.DayOff)
                {
                    toDtSc = this.txtVactionDtTo.Value.Value;
                }

                AccountingPeriod accTime = this.GetTimeByVacationType(typeOfDay, fromDtSc, toDtSc);
                if (accTime != null)
                {
                    fromDtDB = new DateTime(fromDtSc.Year, fromDtSc.Month, fromDtSc.Day, accTime.StartDate.Hour, accTime.StartDate.Minute, 0);
                    toDtDB = new DateTime(toDtSc.Year, toDtSc.Month, toDtSc.Day, accTime.EndDate.Hour, accTime.EndDate.Minute, 0);
                }

                //using (DB db = new DB())
                //{
                //    WorkShiftService wsSer = new WorkShiftService(db);
                //    wShift = wsSer.GetByID(int.Parse(this.cmbTypeVacation.SelectedValue));
                //}

                //if (wShift != null)
                //{
                //if (wShift.TypeOfDay == (int)TypeOfDay.HalfDayOff)
                //{
                //    fromDtDB = new DateTime(fromDtSc.Year, fromDtSc.Month, fromDtSc.Day, wShift.StartHour.Value, wShift.StartMinute.Value, 0);
                //    toDtDB = new DateTime(fromDtSc.Year, fromDtSc.Month, fromDtSc.Day, wShift.EndHour.Value, wShift.EndMinute.Value, 0);
                //}
                //else if (wShift.TypeOfDay == (int)TypeOfDay.DayOff)
                //{
                //    fromDtDB = new DateTime(fromDtSc.Year, fromDtSc.Month, fromDtSc.Day, wShift.StartHour.Value, wShift.StartMinute.Value, 0);
                //    toDtDB = new DateTime(toDtSc.Year, toDtSc.Month, toDtSc.Day, wShift.EndHour.Value, wShift.EndMinute.Value, 0);
                //}
                //}

                using (DB db = new DB())
                {
                    WorkApplyTimeService wrkSer = new WorkApplyTimeService(db);
                    return wrkSer.IsDuplicateTimeApply(appNo, userID, fromDtDB, toDtDB);
                }
            }
            return false;
        }

        /// <summary>
        /// IsHolidays
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        private bool IsHolidays(DateTime date)
        {
            using (DB db = new DB())
            {
                HolidayService holidaySer = new HolidayService(db);
                return holidaySer.GetByDay(date) != null;
            }
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }
        }

        /// <summary>
        /// GetUserByStaffID
        /// </summary>
        /// <param name="staffID"></param>
        /// <returns></returns>
        private M_User GetUserByStaffID(int staffID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByStaffID(staffID);
            }
        }

        /// <summary>
        /// ISV-TRUC
        /// GetStaffByCD
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_Staff GetStaffByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService service = new StaffService(db);
                return service.GetByStaffCD(staffCD);
            }
        }
        
        /// <summary>
        /// ISV-TRUC
        /// GetStaffInfoByCD
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService service = new StaffService(db);
                return service.GetStaffInfoByStaffCD(staffCD);
            }
        }

        /// <summary>
        /// RestoreListApprove
        /// </summary>
        private void RestoreListApprove()
        {
            this.rptApproverList.DataSource = this.ApproverList;
            this.GetTimesHeader(!string.IsNullOrEmpty(this.hdnUserID.Value) ? int.Parse(this.hdnUserID.Value) : DEFAULT_VALUE);
        }

        /// <summary>
        /// GetUsesDays
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        private decimal GetUsesDays(DateTime startDate, DateTime endDate)
        {
            using (DB db = new DB())
            {
                WorkVacationService ser = new WorkVacationService(db);
                return ser.GetNumberOfDaysByRangeDate(startDate, endDate);
            }
        }

        #endregion

        #endregion

        #endregion

        #region Web method
        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string employeeCD, int loginUserID)
        {
            var employeeCd = employeeCD;
            var employeeCdShow = employeeCD;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    StaffService serv = new StaffService(db);
                    M_Staff model = serv.GetByStaffCD(employeeCd);
                    if (model != null)
                    {
                        UserService userSer = new UserService(db);
                        M_UserInfo u = userSer.GetUserInfoByStaffID(model.ID);
                        if (u != null)
                        {
                            Route_HService routeSer = new Route_HService(db);
                            //IList<M_Route_H> lstRet = routeSer.GetListRouteBy2UserCD(LEAVE_TEMPLATE, u.UserCD, loginUserCD);
                            IList<M_Route_H> lstRet = routeSer.GetListRouteBy2UserID(LEAVE_TEMPLATE, u.ID, loginUserID);
                            if (lstRet != null && lstRet.Count > 0)
                            {
                                DepartmentService deptSer = new DepartmentService(db);
                                M_Department dept = deptSer.GetByID(model.DepartmentID);
                                Config_DService confSer = new Config_DService(db);
                                string pos = confSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, model.Position);
                                var result = new
                                {
                                    employeeCD = employeeCdShow,
                                    employeeNm = model.StaffName,
                                    department = dept != null ? dept.DepartmentName : string.Empty,
                                    position = pos

                                };
                                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                            }
                        }
                    }
                }

                var employee = new
                {
                    employeeCD = employeeCdShow,
                    employeeNm = string.Empty,
                    department = string.Empty,
                    position = string.Empty
                };

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
            }
            catch (Exception)
            {
                return null;
            }

        }

        /// <summary>
        /// GetUseDays
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUseDays(DateTime startDate, DateTime endDate)
        {
            try
            {
                if (endDate < startDate)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                using (DB db = new DB())
                {
                    WorkVacationService ser = new WorkVacationService(db);
                    decimal days = ser.GetNumberOfDaysByRangeDate(startDate, endDate);

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(days);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// GetTypeVacation
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetTypeVacation(string type)
        {
            try
            {
                if (string.IsNullOrEmpty(type))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                int typeID = int.Parse(type);
                using (DB db = new DB())
                {
                    Config_DService ser = new Config_DService(db);
                    string value = ser.GetValue4(M_Config_H.CONFIG_CD_VACATION_TYPE, typeID);
                    if (!string.IsNullOrEmpty(value))
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(value);
                    }
                    else
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                    }
                    //Doi logic, lay type tu Config
                    /* WorkShiftService wrkSer = new WorkShiftService(db);
                     M_Work_Shift wk = wrkSer.GetByID(typeID);
                     if (wk != null)
                     {
                         return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(wk.TypeOfDay);
                     }
                     else
                     {
                         return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                     }*/
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using System.Collections;


namespace DailyReport.Apply
{
    /// <summary>
    /// FrmApplyApproveList
    /// ISV-TRAM 2015/04/01
    /// </summary>
    public partial class FrmApplyApproveList : FrmBaseList
    {
        #region Constant

        /// <summary>
        /// Danger text
        /// </summary>
        private const string CONST_DANGER_TEXT = "Deleted";

        #endregion Constant

        #region Variant
        
        #endregion

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }
        /// <summary>
        /// Get or set ListData
        /// </summary>
        public IList<ApplyInfo> ListData
        {
            get { return (IList<ApplyInfo>)ViewState["ListData"]; }
            set { ViewState["ListData"] = value; }
        }
        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Apply Approve";
            base.FormSubTitle = "Approve List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtUserCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtUserName.MaxLength = M_User.USER_NAME_1_MAX_LENGTH;
        }


        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ApplyApprove);
            if (!this._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["DataID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();

        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }
        
        protected void cmbTemplateForm_SelectIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.cmbTemplateForm.SelectedValue))
            {
                this.SetDataApplyTypeCbo(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
            }

            if (this.ListData != null && this.ListData.Count > 0)
            {
                // this.LoadGridPaging(this.ApplyInfoList, this.ApplyInfoList.Count, this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, true);
            }

            this.Collapse = "in";
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtUserCD.ID, this.txtUserCD.Value);
            hash.Add(this.txtUserName.ID, this.txtUserName.Value);
            hash.Add(this.cmbStatus.ID, this.cmbStatus.SelectedValue);
            hash.Add(this.cmbType.ID, this.cmbType.SelectedValue);
            hash.Add(this.cmbTemplateForm.ID, this.cmbTemplateForm.SelectedValue);
            hash.Add(this.cmbIsApproved.ID, this.cmbIsApproved.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtUserCD.Value = data[this.txtUserCD.ID].ToString();
            this.txtUserName.Value = data[this.txtUserName.ID].ToString();
            this.cmbStatus.SelectedValue = data[this.cmbStatus.ID].ToString();
            this.cmbType.SelectedValue = data[this.cmbType.ID].ToString();
            this.cmbTemplateForm.SelectedValue = data[this.cmbTemplateForm.ID].ToString();            
            this.cmbIsApproved.SelectedValue = data[this.cmbIsApproved.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();

            this.SetDataApplyTypeCbo(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.dtMonthYear.Value = DateTime.Now;           

            //Status
            this.InitCombobox(this.cmbStatus, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);
            //Set datatsource for TemplateForm combobox
            this.SetDataForCmbTemplateForm();
            this.SetDataApplyTypeCbo(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
            //InitComboboxApproved
            this.InitComboboxApproved(this.cmbIsApproved);

            // header grid
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

        }


        /// <summary>
        /// Get datasource for dropdownlist template form
        /// </summary>
        private void SetDataForCmbTemplateForm()
        {
            using (DB db = new DB())
            {
                FormService frmSer = new FormService(db);
                IList<DropDownModel> lstData = frmSer.GetDataForDropdown();
                IList<DropDownModel> allowList = new List<DropDownModel>();
                allowList = lstData;
                if (lstData != null && lstData.Count > 0)
                {
                    allowList = (from row in lstData
                                 where row.Value == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE.ToString() || row.Value == M_Config_D.TEMPLATE_FORM_APPLY_TIME.ToString() || row.Value == "-1"
                                 select row).ToList<DropDownModel>();

                }
                allowList.Insert(0, (new DropDownModel("-1", "---")));
                this.cmbTemplateForm.DataSource = allowList;
                this.cmbTemplateForm.DataValueField = "Value";
                this.cmbTemplateForm.DataTextField = "DisplayName";
                this.cmbTemplateForm.DataBind();
            }
        }
        
        /// <summary>
        /// Set data for ApplyType combobox
        /// </summary>
        private void SetDataApplyTypeCbo(int formID)
        {
            IList<DropDownModel> typeApplyList = new List<DropDownModel>();
            using (DB db = new DB())
            {
                FormTypeService frmTypeSer = new FormTypeService(db);
                typeApplyList = frmTypeSer.GetDataForDropdownList(formID);
            }
            //typeApplyList = this.GetListTypeOfRuleByForm(formID);
            typeApplyList.Insert(0, new DropDownModel("-1", "---"));
            this.cmbType.DataSource = typeApplyList;

            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();

        }


        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            IList<DropDownModel> dataList = this.GetDataForDropdownList(configCD, withBlank);
            IList<DropDownModel> allowList = (from data in dataList
                                              where int.Parse(data.Value) != (int)StatusApply.Draft
                                                && int.Parse(data.Value) != (int)StatusApply.Cancel 
                                              select data).ToList();
            ddl.DataSource = allowList;

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// InitComboboxApproved
        /// </summary>
        /// <param name="ddl"></param>
        private void InitComboboxApproved(DropDownList ddl)
        {
            // init combox 
            IList<DropDownModel> dataList = new List<DropDownModel>();            
            dataList.Add(new DropDownModel("0", "Include All"));
            dataList.Add(new DropDownModel("1", "Only View"));
            dataList.Add(new DropDownModel("2", "Only Approved"));
            dataList.Add(new DropDownModel("3", "Only Not Approved"));

            ddl.DataSource = dataList;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        ///// <summary>
        ///// Init Combovbox Type
        ///// </summary>
        //private void InitComboboxType()
        //{
        //    using (DB db = new DB())
        //    {
        //        IList<DropDownModel> typeApplyList = new List<DropDownModel>();
        //        TypeApplyService serTypeApp = new TypeApplyService();
        //        typeApplyList = serTypeApp.GetDataForDropDownList(-1 , true);
        //        this.cmbType.DataSource = typeApplyList;
        //    }
        //    this.cmbType.DataValueField = "Value";
        //    this.cmbType.DataTextField = "DisplayName";
        //    this.cmbType.DataBind();

        //}

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage, bool isProcess=false)
        {
            int totalRow = 0;
            this.GetColorClass(1);
            IList<ApplyInfo> lstResult = null;

            if (isProcess)
            {
                lstResult = new List<ApplyInfo>(this.ListData);
                totalRow = lstResult.Count;
            }
            else
            {
                //Get data
                using (DB db = new DB())
                {
                    ApplyService appSer = new ApplyService(db);
                    DateTime? monthYear = null;
                    if (this.dtMonthYear.Value != null)
                    {
                        monthYear = this.dtMonthYear.Value.Value;
                    }

                    totalRow = appSer.GetTotalRowForApproveList2(LoginInfo.User.ID, monthYear, this.txtUserCD.Value, this.txtUserName.Value, short.Parse(this.cmbStatus.SelectedValue), int.Parse(this.cmbTemplateForm.SelectedValue), int.Parse(this.cmbType.SelectedValue), int.Parse(this.cmbIsApproved.SelectedValue));

                    lstResult = appSer.GetListByCondForApproveList2(LoginInfo.User.ID, monthYear, this.txtUserCD.Value, this.txtUserName.Value, short.Parse(this.cmbStatus.SelectedValue), int.Parse(this.cmbTemplateForm.SelectedValue),int.Parse(this.cmbType.SelectedValue), int.Parse(this.cmbIsApproved.SelectedValue),
                                                             pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                }
            }
            //Show data
            if (lstResult == null || lstResult.Count == 0)
            {
                this.ListData = new List<ApplyInfo>();
                this.rptResult.DataSource = null;
            }
            else
            {
                this.ListData = new List<ApplyInfo>(lstResult);
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstResult[lstResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "ApplyNo", "User", "Template", "Type", "Apply Date", "Start Date", "End Date", "Reason", "Status", "" });

                // detail
                this.rptResult.DataSource = lstResult;
            }

            this.rptResult.DataBind();
        }

        #endregion Method

        #region Web Method

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string FormatUserCode(string in1)
        {
            var employeeCd = in1;
            var employeeCdShow = in1;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(employeeCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            employeeCD = employeeCdShow,
                            employeeNm = model.UserName1
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var employee = new
                    {
                        employeeCD = employeeCdShow
                    };

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;

namespace DailyReport.Apply
{
    /// <summary>
    /// FrmApplyApproveDetail
    /// ISV-TRAM 2015/04/01
    /// </summary>
    public partial class FrmApplyApproveDetail : FrmBaseDetail
    {
        #region enum

        /// <summary>
        /// Shift value
        /// </summary>
        enum ShiftValue
        {
            Morning = 0,
            Afternoon
        }

        /// <summary>
        /// Perform value
        /// </summary>
        enum PerformValue
        {
            Morning = 0,
            Afternoon,
            FullDay,
            MultiDays
        }

        #endregion

        #region Constants
        private const string URL_LIST = "~/Apply/FrmApplyApproveList.aspx";
        private const string APPLY_INFO = "This apply is cancellation of";
        #endregion

        #region Variable
        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;

        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;

        /// <summary>
        /// isApproveUser
        /// </summary>
        public bool isApproveUser;

        /// <summary>
        /// isApproved
        /// </summary>
        public bool isApproved;

        /// <summary>
        /// isDisablePrevBack
        /// </summary>
        public bool isDisablePrevBack;

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData;

        /// <summary>
        /// 
        /// </summary>
        public string lblApplyInfo = APPLY_INFO;

        /// <summary>
        /// TypePerformList
        /// </summary>
        private IList<DropDownModel> _typePerformList;
        private string _defaultTypePerform;

        /// <summary>
        /// 2015/04/20 ISV-TRUC
        /// </summary>
        public bool isDispApproveButton;
        public bool isDispViewButton;
        public bool isDispIgnoreButton;
        public bool isShowPrevBackButton;
        #endregion

        #region Property
        
        /// <summary>
        /// Type Apply Form Current
        /// </summary>
        public int CurrenType
        {
            get { return (int)ViewState["CurrenType"]; }
            set { ViewState["CurrenType"] = value; }
        }
        
        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyNo
        /// </summary>
        public string PreApplyNo
        {
            get { return (string)ViewState["PreApplyNo"]; }
            set { ViewState["PreApplyNo"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }


        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<ApplyApproveListModel>  ApproverList
        {     
            get{return (IList<ApplyApproveListModel>)ViewState["ApproverList"];}
            set { ViewState["ApproverList"] = value; }
        }


        /// <summary>
        /// Is Inspected : đã xem xét (approve, remaind)
        /// </summary>
        public bool IsInspected
        {
            get { return (bool)ViewState["IsInspected"]; }
            set { ViewState["IsInspected"] = value; }
        }

        /// <summary>
        /// Is penalized(Bi tru phep nam)
        /// </summary>
        public bool IsPenalized
        {
            get { return (bool)ViewState["IsPenalized"]; }
            set { ViewState["IsPenalized"] = value; }
        }
        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Apply Approve";
            base.FormSubTitle = "Detail";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtReason.MaxLength = T_Apply.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyApprove);
            if (!this._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init Data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["DataID"] == null)
                    {
                        base.RedirectUrl(URL_LIST);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["DataID"].ToString());
                        T_Apply data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    base.RedirectUrl(URL_LIST);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
              ////  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
              //  var isOk = true;
              //  if (apply.UpdateDate != this.OldUpdateDate)
              //  {
              //      base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
              //      isOk = false;
              //      if (apply.StatusFlag == 1)
              //      {
              //        //  this.LoadDataForApproveListFromApproveList();
              //          base.RedirectUrl(URL_LIST);
              //          return;
              //      }
              //  }

              //  //Set Mode
              //  this.ShowData(apply);
              //  if (isOk)
              //  {
              //      //Set Mode
              //      this.ProcessMode(this.Mode);
              //  }

             //   this.ShowData(apply);
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Apply app;
            using (DB db = new DB())
            {
                ApplyService appSer = new ApplyService(db);
                app = appSer.GetByID(this.DataID);
            }
            if (app != null)
            {
                if (this.OldUpdateDate != app.UpdateDate)
                {
                    this.LoadDataForChangedData();
                }
                else
                {
                    this.LoadDataForApproveList(this.DataID,true);
                }
            }

            if (this.Mode == Mode.Approve)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.Yes);
            }
            else if (this.Mode == Mode.Ignore)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No);
            }
            else if (this.Mode == Mode.BackPre)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.No);
            }
               
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Ignore);
              ////  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
              //  var isOk = true;
              //  if (apply.UpdateDate != this.OldUpdateDate)
              //  {
              //      base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
              //      isOk = false;
              //      if (apply.StatusFlag == 1)
              //      {
              //          this.LoadDataForApproveList(this.DataID);
              //          base.RedirectUrl(URL_LIST);
              //          return;
              //      }
              //  }

              //  this.ShowData(apply);

              //  if (isOk)
              //  {
              //      //Set Mode
              //      this.ProcessMode(Mode.Ignore);
              //  }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// btnView Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                //View Data
                if (this.ViewData(apply))
                {
                    Server.Transfer(URL_LIST);
                }
                else
                {
                    this.LoadDataForChangedData();
                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        
        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.BackPre);
               //// this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
               // var isOk = true;
               // if (apply.UpdateDate != this.OldUpdateDate)
               // {
               //     base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
               //     isOk = false;
               //     if (apply.StatusFlag == 1)
               //     {
               //         this.LoadDataForApproveList(this.DataID);
               //         base.RedirectUrl(URL_LIST);
               //         return;
               //     }
               // }

               // this.ShowData(apply);

               // if (isOk)
               // {
               //     //Set Mode
               //     this.ProcessMode(Mode.BackPre);
               // }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Apply data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Approve:
                    //Update Data
                    
                    if (this.Approve())
                    {

                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    
                    //data = this.GetApplyByID(this.DataID);
                    //if (data != null)
                    //{
                    //    data.Reason = this.txtApproveReason.Text;
                    //    this.ApplyStatus = (short)StatusApply.Approving;
                    //    ret = this.Approve(data);
                    //    if (ret)
                    //    {
                    //        //Show data
                    //        data = this.GetApplyByID(this.DataID);

                    //        this.ShowData(data);

                    //        //Set Mode
                    //        this.ProcessMode(Mode.View);

                    //        //Set Success
                    //        this.Success = true;
                    //    }
                    //    else
                    //    {
                    //       // this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //        this.LoadDataForChangedData();
                    //        //du lieu da thay doi
                    //       // this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //        return;

                    //    }
                    //}
                    
                    break;

                case Utilities.Mode.Ignore:
                    //Update Data
                    if (this.Reject((short)StatusApply.Rejected))
                    {

                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    //ret = this.Ignore((short)StatusApply.Rejected);
                    //if (ret)
                    //{
                    //    //Get User
                    //    data = this.GetApplyByID(this.DataID);

                    //    //Show data
                    //    this.ShowData(data);

                    //    //Set Mode
                    //    this.ProcessMode(Mode.View);

                    //    //Set Success
                    //    this.Success = true;
                    //}
                    //else
                    //{
                    //  //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //    this.LoadDataForChangedData();
                    //    //du lieu da thay doi
                    // //   this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //    return;

                    //}
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    if (this.Remand((short)StatusApply.Approving))
                    {

                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    //ret = this.Remand((short)StatusApply.Approving);
                    //if (ret)
                    //{
                    //    //Get User
                    //    data = this.GetApplyByID(this.DataID);

                    //    //Show data
                    //    this.ShowData(data);

                    //    //Set Mode
                    //    this.ProcessMode(Mode.View);

                    //    //Set Success
                    //    this.Success = true;
                    //}
                    //else
                    //{
                    //  //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //    this.LoadDataForChangedData();
                    //    //du lieu da thay doi
                    //  //  this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //    return;
                    //}
                    break;
            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
         //   this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Apply data = this.GetApplyByID(this.DataID);
            if (this.Mode == Utilities.Mode.View)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                this.LoadDataForApproveList(this.DataID,true);
            }

        }

        #endregion

        #region Methods
        
        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.IsInspected = false;
            this.InitComboboxPerform();
            this.InitComboboxShift(this.cmbShiftFrom);
            this.InitComboboxShift(this.cmbShiftTo);
            this.IsPenalized = false;
        }
        
        /// <summary>
        /// Get datasource for dropdownlist template form
        /// </summary>
        private void GetDataSourceForCmbTemplateForm(int userID)
        {
            using (DB db = new DB())
            {
                Config_HService conSer = new Config_HService(db);
                IList<DropDownModel> lstData = conSer.GetFormatTypeWithForm(M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);

                FormLinkService frmLinkSer = new FormLinkService(db);

                this.cmbTemplateForm.DataSource = lstData;
                this.cmbTemplateForm.DataValueField = "Value";
                this.cmbTemplateForm.DataTextField = "DisplayName";
                this.cmbTemplateForm.DataBind();
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitComboboxTypeConfirm(DropDownList ddl, string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                this._typePerformList = configSer.GetDataForDropDownList(configCD);
                this._defaultTypePerform = configSer.GetDefaultValueDrop(configCD);
            }

            // init combox 
            ddl.DataSource = this._typePerformList;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        #region check data

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApproved(IList<ApplyApproveListModel> applyList)
        {
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            IList<ApplyApproveListModel> approveList = new List<ApplyApproveListModel>();
            approveList = (from app in applyList
                           where ((app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.BackPrev) || app.ApproveStatus == (short)StatusHasAprove.Ignore)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Checking approve status for previous level of loginuser level
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsNotApprovedInPreLevel(IList<ApplyApproveListModel> applyList)
        {
            //Get level of user login 
            int? loginUserLevel = 0;
            ApplyApproveListModel loginUserInfo = new ApplyApproveListModel();
            loginUserInfo = (from app in applyList
                             where app.RouteUID == LoginInfo.User.ID
                             select app).SingleOrDefault();

            if (loginUserInfo != null)
            {
                loginUserLevel = loginUserInfo.RouteLevel;
            }

            IList<ApplyApproveListModel> notApproveList1 = new List<ApplyApproveListModel>();
            notApproveList1 = (from app in applyList
                               where ((app.RouteLevel == loginUserLevel && app.RouteMethod == (int)RouteMethods.AND)) && (app.ApproveStatus != (short)StatusHasAprove.Approved)
                               select app).ToList();


            if (notApproveList1 != null && notApproveList1.Count > 0)
            {
                IList<ApplyApproveListModel> notApproveList2 = new List<ApplyApproveListModel>();
                notApproveList2 = (from app in applyList
                                   where (app.RouteLevel == loginUserLevel - 1) && (app.ApproveStatus != (short)StatusHasAprove.Approved)
                                   select app).ToList();
                if (notApproveList2 != null && notApproveList2.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        ///// <summary>
        ///// Check showing PrevBack button
        ///// </summary>
        ///// <param name="applyApproveListInfo"></param>
        ///// <returns></returns>
        //private bool IsShowPrevBackButton(IList<ApplyApproveListInfo> applyApproveListInfo)
        //{
        //    //Get level of user login 
        //    int? loginUserLevel = 0;
        //    ApplyApproveListInfo approveUserInfo = new ApplyApproveListInfo();
        //    approveUserInfo = (from app in applyApproveListInfo
        //                       where app.RouteUID == LoginInfo.User.ID
        //                       select app).SingleOrDefault();

        //    if (approveUserInfo != null)
        //    {
        //        loginUserLevel = approveUserInfo.RouteLevel;
        //    }

        //    ApplyApproveListService approveSer = new ApplyApproveListService();
        //    int minLevel = approveSer.GetMinRouteLevelByID(this.DataID);

        //    //Get list of Approve User whose level is less than level of login user 
        //    if (loginUserLevel > minLevel)
        //    {
        //        IList<ApplyApproveListInfo> approveUserList = new List<ApplyApproveListInfo>();
        //        approveUserList = (from appUser in applyApproveListInfo
        //                           where appUser.ApproveStatus == (short)StatusHasAprove.Approved && loginUserLevel >= appUser.RouteLevel
        //                           select appUser).ToList();
        //        if (approveUserList != null && approveUserList.Count > 0)
        //        {
        //            return true;
        //        }
        //        else
        //        {
        //            return false;
        //        }
        //    }
        //    else
        //    {
        //        return false;
        //    }
        //}

        /// <summary>
        /// Set complete status for the ApplyStatus
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private void SetCompleteStatus(IList<ApplyApproveListModel> applyList)
        {
            IList<ApplyApproveListModel> completedList = new List<ApplyApproveListModel>();
            completedList = (from app in applyList
                             where app.ApproveStatus == (short)StatusHasAprove.Approved
                             select app).ToList();

            if (completedList != null && completedList.Count == applyList.Count)
            {
                this.ApplyStatus = (short)StatusApply.Approved;
            }
        }

        #endregion

        #region Confirm

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Approve()
        {
            bool success = false;
            bool isFinishApp = false;
            //User has been registed in list approve
            int userApproveID = this.LoginInfo.User.ID;
            try
            {               
                var ret = 0;
                int nextLevel = 0;
                ApplyService appSer;
                ApplyApproveListService approveListSer;
                
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    appSer = new ApplyService(db);
                    T_Apply app = appSer.GetByID(this.DataID);
                    if (app != null)
                    {
                        approveListSer = new ApplyApproveListService(db);
                        T_Apply_Approve_List apLt = approveListSer.GetApproveRow(this.DataID, this.LoginInfo.User.ID);
                        if (apLt != null)
                        {
                            userApproveID = apLt.RouteUID;
                            approveListSer.Approve2_2(this.DataID, userApproveID, this.LoginInfo.User.ID, (short)StatusHasAprove.Approved, this.txtApproveReason.Text.Trim());
                            //Check finish
                            isFinishApp = approveListSer.CheckApproveIsFinish2(this.DataID, userApproveID);

                            if (isFinishApp)//approve lastest
                            {
                                T_Apply_Approve_List appr = approveListSer.GetByKey2(this.DataID, userApproveID);
                                //update status header
                                ret = appSer.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (short)StatusApply.Approved, appr.RouteLevel, this.OldUpdateDate);
                                nextLevel = 99;

                                //Get time of rule
                                FormTypeService frmTypeSer = new FormTypeService(db);
                                M_Form_Type frmType = frmTypeSer.GetByID(app.TypeApplyID);
                                if (frmType != null)
                                {
                                    if (frmType.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE && frmType.TimeOfRule == (int)TimeOfRuleLeave.TruPhep)
                                    {
                                        StaffService staffSer = new StaffService(db);
                                        //get Staff 
                                        M_Staff staff = null;

                                        staff = this.GetStaffForUpdateAnnual(app.UserID, app.Duration.Value, staffSer, this.PreApplyID.HasValue);

                                        //update ngay phep trong user--if is vacation
                                        if (staff != null)
                                        {
                                            if (ret != 0)
                                            {
                                                //AnnualDate chua gan trong user
                                                ret = staffSer.UpdateAnnualDay(staff);
                                            }
                                        }
                                        else
                                        {
                                            this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                                            return false;
                                        }
                                    }
                                }

                                //if (this.CurrenType == (int)TypeFormID.Vacation)
                                //{

                                //}

                                //-----------T_Daily---------------
                                DailyService dailySer = new DailyService(db);
                                if (this.PreApplyID.HasValue)
                                {

                                    T_Apply preApp = appSer.GetByID(this.PreApplyID.Value);
                                    appSer.UpdateApplyStatus(this.PreApplyID.Value, this.LoginInfo.User.ID, (short)StatusApply.Cancel, preApp.ApprovedLevel, preApp.UpdateDate);

                                    //Delete Daily
                                    if (ret != 0)
                                    {
                                        //28/05/2015 ret = dailySer.DeleteByApplyID(this.PreApplyID.Value);
                                    }
                                }
                                else
                                {
                                    //get daily
                                    /* 28/05/2015 IList<T_Daily> lstDaily = new List<T_Daily>();
                                      lstDaily = this.CreateDailyData(app, this.CurrenType);
                                      //insert each item into T_Daily
                                      if (ret != 0)
                                      {
                                          foreach (var item in lstDaily)
                                          {
                                              ret = dailySer.Insert(item);
                                          }
                                      }28/05/2015*/
                                }
                                //************END APPROVE NORMAL****************

                            }
                            else//approve normal
                            {
                                bool finishLevel = false;
                                //Send mail
                                T_Apply_Approve_List appr = approveListSer.GetByKey2(this.DataID, userApproveID);
                                if (approveListSer.CheckApproveIsFinishLevel2(this.DataID, appr.RouteLevel))
                                {
                                    nextLevel = appr.RouteLevel + 1;
                                    finishLevel = true;
                                }

                                //update status approve for header
                                ret = appSer.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (short)StatusApply.Approving, finishLevel ? appr.RouteLevel : app.ApprovedLevel, this.OldUpdateDate);
                                //back next level to new if is remand
                                if (ret != 0)
                                {
                                    //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
                                    approveListSer.UpdateStatusForPrevBack2(this.DataID, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
                                }
                            }
                            //Check result update
                            if (ret == 0)
                            {
                                //data changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                          /*  else
                            {
                                IList<string> lstEmail = approveListSer.GetListEmailByLevelAprove2(this.DataID, nextLevel);
                                StringBuilder mailBody = new StringBuilder();
                                if (lstEmail.Count > 0)
                                {
                                    mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                                    mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                                    mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
                                    mailBody.AppendLine("Reason: " + this.txtReason.Text);

                                    if (nextLevel < 99)
                                    {
                                        CommonUtil.Sending_Email(lstEmail.ToArray(), "Has request approve", mailBody);
                                    }
                                    else
                                    {
                                        CommonUtil.Sending_Email(lstEmail.ToArray(), "Has complete apply", mailBody);
                                    }
                                }

                                lstEmail = approveListSer.GetListEmailApproveByOthers2(this.DataID, this.LoginInfo.User.ID);
                                if (lstEmail.Count > 0)
                                {
                                    mailBody = new StringBuilder();
                                    mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                                    mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                                    mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
                                    mailBody.AppendLine("Reason: " + this.txtReason.Text);
                                    mailBody.AppendLine("Approved By: " + this.LoginInfo.User.UserName2);
                                    CommonUtil.Sending_Email(lstEmail.ToArray(), "Apply is approved by other user", mailBody);
                                }
                            }*/
                            db.Commit();
                            success = true;
                            this.IsInspected = true;
                        }
                    }                    
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                //LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return false;
            }
             
            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have approved.";
                    this.SendMail(this.DataID, userApproveID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, this.cmbApplyType.SelectedItem.Text, this.txtReason.Text, mess, TypeSettingMail.Approve, isFinishApp);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            return true;
        }

        /// <summary>
        /// Get value of annual day in config
        /// </summary>
        /// <param name="configCD"></param>
        /// <param name="value1"></param>
        /// <returns></returns>
        private string GetValue4(string configCD, int value1)
        {
            using (DB db = new DB())
            {
                Config_DService conSer = new Config_DService(db);
                return conSer.GetValue4(configCD, value1);
            }
        }

        /// <summary>
        /// GetStaffForUpdateAnnual
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="typeApply"></param>
        /// <param name="staffSer"></param>
        /// <param name="isCancel"></param>
        /// <returns></returns>
        private M_Staff GetStaffForUpdateAnnual(int userID, decimal annualDay, StaffService staffSer, bool isCancel = false)
        {
            M_Staff staff = staffSer.GetByUserID(userID);
            if (staff != null)
            {
                if (isCancel)//cancel -> + dayoff
                {
                    staff.AnnualDays = staff.AnnualDays + annualDay;
                }
                else//not cancel -> - dayoff
                {
                    if ((staff.AnnualDays >= annualDay) && (staff.AnnualDays - annualDay >= 0))
                    {
                        staff.AnnualDays = staff.AnnualDays - annualDay;
                    }
                    else
                    {
                        return null;
                    }
                }
                
                staff.UpdateUID = this.LoginInfo.User.ID;
            }
            return staff;
        }

        /// <summary>
        /// Ignore
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Reject(short applyStatus)
        {
            bool success = false;
            int approveUserID = this.LoginInfo.User.ID;
            try
            {   
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    ApplyApproveListService approveSer = new ApplyApproveListService(db);
                    T_Apply_Approve_List apLt = approveSer.GetApproveRow(this.DataID, this.LoginInfo.User.ID);
                    if (apLt != null)
                    {
                        approveUserID = apLt.RouteUID;
                        ret = approveSer.Reject2(this.DataID, apLt.RouteUID, this.LoginInfo.User.ID, (int)StatusHasAprove.Ignore, this.txtApproveReason.Value);
                        ApplyService service = new ApplyService(db);
                        //Update StatusFlag
                        //Chua co level nao duoc duyet nen approve level = 0
                        ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, 0, this.OldUpdateDate);
                        
                        //Check result update
                        if (ret == 0)
                        {
                            //du lieu da thay doi
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        db.Commit();
                        success = true;
                        this.IsInspected = true;
                    }
                }

                
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }

            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have rejected.";
                    this.SendMail(this.DataID, approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, this.cmbApplyType.SelectedItem.Text, this.txtReason.Text, mess, TypeSettingMail.Reject);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            
            return true;
        }

        /// <summary>
        /// SendMail
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="empName"></param>
        /// <param name="appType"></param>
        /// <param name="reason"></param>
        /// <param name="mess"></param>
        /// <param name="type"></param>
        private void SendMail(int applyID, int routeUID, string applyNo, string empName, string appType, string reason, string mess, TypeSettingMail type, bool isFinishApprove = false)
        {
           // IList<string> lstEmail = this.GetListEmail(type, applyID, routeUID, isFinishApprove);
            if (isFinishApprove)
            {
                this.SendMail(applyID, routeUID, applyNo, empName, appType, reason, mess, type);
            }
            IList<M_User> lstEmail = this.GetListEmail(type, applyID, routeUID, isFinishApprove);

            StringBuilder mailBody = new StringBuilder();

            #region Test
            IList<string> lstEmailStr = new List<string>();
            IList<string> lstUserStr = new List<string>();
            foreach (var item in lstEmail)
            {
                lstEmailStr.Add(item.Email);
                lstUserStr.Add(string.Format("{0} {1}", EditDataUtil.ToFixCodeShow(item.UserCD, M_User.MAX_USER_CODE_SHOW), item.UserName2)); 
            }
            #endregion


            if (lstEmail != null && lstEmail.Count > 0)
            {
                mailBody.AppendLine("All mail: " + lstEmail.Count);
                mailBody.AppendLine("ApplyNo: " + applyNo);
                mailBody.AppendLine("User: " + empName);
                mailBody.AppendLine("Type: " + appType);
                mailBody.AppendLine("Reason: " + reason);
                mailBody.AppendLine("All user received: ");
                foreach (var it in lstUserStr)
                {
                    mailBody.AppendLine(string.Format("● {0},", it));
                }
                switch (type)
                {                    
                    case TypeSettingMail.Reject:
                        mailBody.AppendLine("Rejected By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Remand:
                        mailBody.AppendLine("Remanded By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Approve:
                        mailBody.AppendLine("Approved By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Read:
                        mailBody.AppendLine("Viewer By: " + this.LoginInfo.User.UserName2);
                        break;
                    default:
                        break;
                }
                
                string sSubject = string.Empty;
                if (isFinishApprove)
                {
                    sSubject = "This application form has been completed.";
                }
                else
                {
                    //if (lstEmail.Count == 1)
                    //{
                    //    sSubject = string.Format(mess, "is", lstEmail.Count);
                    //}
                    //else
                    //{
                    //    sSubject = string.Format(mess, "are", lstEmail.Count);
                    //}
                    sSubject = mess;
                }

                
                //CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);
                CommonUtil.Sending_Email(lstEmailStr.ToArray(), sSubject, mailBody);
            }
        }

        /// <summary>
        /// GetListEmail
        /// </summary>
        /// <param name="type"></param>
        /// <param name="isFinishApprove"></param>
        /// <returns></returns>
        //private IList<string> GetListEmail(TypeSettingMail type, int applyID, int routeUID, bool isFinishApprove = false)
        private IList<M_User> GetListEmail(TypeSettingMail type, int applyID, int routeUID, bool isFinishApprove = false)
        {
            //IList<string> lstEmail = new List<string>();
            IList<M_User> lstEmail = new List<M_User>();
            ApplyApproveListService approveSer = new ApplyApproveListService();
            T_Apply_Approve_List applicantInfoList = approveSer.GetByKey2(applyID, routeUID);

            if (applicantInfoList != null)
            {
                #region Comment <-> Right
                //switch (type)
                //{
                //    case TypeSettingMail.Reject:
                //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                //        }
                //        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                //        }
                        
                //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                        
                //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                        
                //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        break;

                //    case TypeSettingMail.Remand:
                //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                //        }
                //        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                //        }
                        
                //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                        
                //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                        
                //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        break;

                //    case TypeSettingMail.Approve:
                //        if (isFinishApprove)
                //        {
                //            return approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
                //        }
                //        //Next
                //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                //        }
                //        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                //        }
                //        //Previous
                //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        //sender
                //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        //current
                //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        break;

                //    case TypeSettingMail.Read:
                //        if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                //            return lstEmail;
                //        }
                //        else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
                //        {
                //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                //        }
                        
                //        if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                        
                //        if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
                //        {
                //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                //            ((List<string>)lstEmail).AddRange(lstTemp);
                //        }
                //        break;
                //}
                #endregion

                #region Test
                switch (type)
                {
                    case TypeSettingMail.Reject:
                        if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                        }
                        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                        }

                        if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }

                        if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }

                        if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        break;

                    case TypeSettingMail.Remand:
                        if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                        }
                        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                        }

                        if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }

                        if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }

                        if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        break;

                    case TypeSettingMail.Approve:
                        if (isFinishApprove)
                        {
                            return approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
                        }
                        //Next
                        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                        }
                        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                        }
                        //Previous
                        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        //sender
                        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        //current
                        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        break;

                    case TypeSettingMail.Read:
                        if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);                           
                        }
                        else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
                        {
                            lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                        }

                        if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }

                        if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
                        {
                            var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                            ((List<M_User>)lstEmail).AddRange(lstTemp);
                        }
                        break;
                }
                #endregion
            }
            return lstEmail;
        }

        /// <summary>
        /// ViewData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private bool ViewData(T_Apply apply)
        {
            bool success = false;
            try
            {
                int ret = 0;
                using (DB db = new DB())
                {
                    ApplyService service = new ApplyService(db);

                    //Update StatusFlag
                    ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, apply.ApplyStatus, apply.ApprovedLevel, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        ApplyApproveListService approveSer = new ApplyApproveListService(db);
                        approveSer.UpdateApproveStatus2(apply.ID, (int)StatusHasAprove.Approved, this.LoginInfo.User.ID, string.Empty);
                    }
                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                    success = true;
                }
            }
            catch (Exception ex)
            {
                //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have viewed.";
                    this.SendMail(this.DataID, this.LoginInfo.User.ID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, this.cmbApplyType.SelectedItem.Text, this.txtReason.Text, mess, TypeSettingMail.Read);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            return true;
        }
        

        /// <summary>
        /// Back previous level
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Remand(short applyStatus)
        {
            int approveUserID = this.LoginInfo.User.ID;
            bool success = false;
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    ApplyService service = new ApplyService(db);
                    T_Apply app = service.GetByID(this.DataID);
                    if (app != null)
                    {
                        ApplyApproveListService approveSer = new ApplyApproveListService(db);
                        T_Apply_Approve_List apLt = approveSer.GetApproveRow(this.DataID, this.LoginInfo.User.ID);
                        if (apLt != null)
                        {
                            //1:Update ApproveStatus for the login user 
                            //2:Update New status of the approved users have level = the login user's level or level= the login user's level-1

                            ret = approveSer.Remand2(this.DataID, apLt.RouteUID, this.LoginInfo.User.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New, this.txtApproveReason.Value);
                            ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, app.ApprovedLevel > 1 ? (app.ApprovedLevel - 1) : 0, this.OldUpdateDate);
                            
                            //Check result update
                            if (ret == 0)
                            {
                                //data changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                           /* else
                            {
                                ApplyApproveListService approveListSer = new ApplyApproveListService(db);
                                T_Apply_Approve_List appr = approveListSer.GetByKey2(this.DataID, this.LoginInfo.User.ID);
                                IList<string> lstEmail = approveListSer.GetListEmailByLevelRemand2(this.DataID, appr.RouteLevel - 1);
                                StringBuilder mailBody = new StringBuilder();
                                if (lstEmail.Count > 0)
                                {
                                    mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                                    mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                                    mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
                                    mailBody.AppendLine("Reason: " + this.txtReason.Text);
                                    mailBody.AppendLine("Remain By: " + this.LoginInfo.User.UserName2);

                                    CommonUtil.Sending_Email(lstEmail.ToArray(), "Has remain apply", mailBody);
                                }
                            }*/
                            db.Commit();
                            success = true;
                            this.IsInspected = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }
            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have remanded.";
                    this.SendMail(this.DataID, approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, this.cmbApplyType.SelectedItem.Text, this.txtReason.Text, mess, TypeSettingMail.Remand);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            
            return true;
        }

        #endregion

        #region Get data        

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Apply GetApplyByID(int id)
        {
            T_Apply apply = new T_Apply();
            using (DB db = new DB())
            {
                ApplyService appSer = new ApplyService(db);
                apply = appSer.GetByID(id);
            }            
            return apply;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<ApplyApproveListModel> GetListApproveUserFromApply()
        {
            using (DB db = new DB())
            {
                ApplyApproveListService applyApproveSer = new ApplyApproveListService(db);
                return applyApproveSer.GetByID2(this.DataID);
            }
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        private void LoadDataForApproveList(int appID, bool isIncludeView = false)
        {
            this.colorStatus = base.GetStatusColorLabel((this.GetApplyByID(DataID)).ApplyStatus, ref this.statusNameLbl);
            IList<ApplyApproveListModel> approverList = new List<ApplyApproveListModel>();
            approverList = this.GetListApproveUserFromApply();

            if (approverList != null && approverList.Count != 0)
            {
                IList<ApplyApproveListModel> allowList = new List<ApplyApproveListModel>();
                if (!isIncludeView)
                {
                    var lstTemp = from i in approverList
                                  where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                                  select new ApplyApproveListModel
                                  {
                                      RowNum = i.RowNum,
                                      ApplyID = i.ApplyID,
                                      UserName = i.UserName,
                                      RouteLevel = i.RouteLevel,
                                      RouteMethod = i.RouteMethod,
                                      Department = i.Department,
                                      Position = i.Position,
                                      ApproveDate = i.ApproveDate,
                                      ApproveDateStr = i.ApproveDateStr,
                                      ApproveUID = i.ApproveUID,
                                      ApproveName = i.ApproveName,
                                      ApproveReason = i.ApproveReason,
                                      ApproveFlagStr = i.ApproveFlagStr,
                                      RouteUID = i.RouteUID,
                                      ApproveStatus = i.ApproveStatus,
                                      RouteMethodStr = i.RouteMethodStr
                                  };
                    if (lstTemp != null)
                    {
                        //((List<ApplyApproveListModel>)allowList).AddRange(lstTemp);
                        allowList = new List<ApplyApproveListModel>(lstTemp);
                    }
                           
                }
                else
                {
                    ((List<ApplyApproveListModel>)allowList).AddRange(approverList);
                    allowList = new List<ApplyApproveListModel>(approverList);
                }
                this.isHasData = true;
                this.ApproverList = new List<ApplyApproveListModel>(allowList);
               // ((List<ApplyApproveListModel>)this.ApproverList).AddRange(allowList);             
                this.SetRowNumForGrid(ref allowList);
                this.rptApproverList.DataSource = allowList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();
            this.isApproved = false;
        }

        /// <summary>
        /// SetRowNumForGrid
        /// </summary>
        /// <param name="listData"></param>
        private void SetRowNumForGrid(ref IList<ApplyApproveListModel> listData)
        {

            if (listData != null && listData.Count > 0)
            {
                var rowNum0 = 0;

                listData[0].RowNum = 1;
                var item0 = listData[0];
                rowNum0 = listData[0].RowNum;
                var level0 = listData[0].RouteLevel;
                foreach (ApplyApproveListModel item in listData)
                {

                    if (level0 != item.RouteLevel)
                    {
                        item.RowNum = rowNum0 + 1;
                        rowNum0++;

                    }
                    else
                    {
                        item.RowNum = rowNum0;
                    }
                    level0 = item.RouteLevel;

                }

            }

            listData = (from data in listData
                        orderby data.RouteLevel ascending
                        select data).ToList();

        }

        /// <summary>
        /// 
        /// </summary>
        private void LoadDataForChangedData()
        {
            this.colorStatus = base.GetStatusColorLabel(this.ApplyStatus, ref this.statusNameLbl);
            IList<ApplyApproveListModel> applyLst = new List<ApplyApproveListModel>(this.ApproverList);
            //((List<ApplyApproveListModel>)applyLst).AddRange(this.ApproverList);
            if (applyLst != null)
            {
                this.SetRowNumForGrid(ref applyLst);
                this.rptApproverList.DataSource = applyLst;
                this.isHasData = true;
            }
            else
            {
                this.rptApproverList.DataSource = null;
                this.isHasData = false;
            }
            
            this.rptApproverList.DataBind();
            
        }

        #endregion

        #region Set data

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;          

            //Check model
            switch (mode)
            {
                case Mode.Approve:
                    this.txtApproveReason.SetReadOnly(false);
                    break;

                case Mode.Confirm:
                    this.LoadDataForApproveList(this.DataID,true);
                    //this.ApplyStatus = (int)StatusApply.Draft;
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtApproveReason.ReadOnly = this.isApproveUser == false ? true : false;

                    break;
                case Mode.Ignore:
                    this.txtEmployeeCD.SetReadOnly(true);
                   // this.ApplyStatus = (int)StatusApply.Rejected;
                    this.txtApproveReason.SetReadOnly(false);

                    break;

                case Mode.BackPre:
                    this.txtEmployeeCD.SetReadOnly(true);
                   // this.ApplyStatus = (int)StatusApply.BackPrev;
                    this.txtApproveReason.SetReadOnly(false);

                    break;
             
                default:

                    //this.chkIsAgent.Enabled = false;
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.cmbTemplateForm.Enabled = false;
                    this.cmbApplyType.Enabled = false;
                    this.cmbPerform.Enabled = false;
                    this.cmbShiftFrom.Enabled = false;
                    this.cmbShiftTo.Enabled = false;
                    this.dtPerformDateFrm.SetReadOnly(true);
                    this.txtStartHour.SetReadOnly(true);
                    this.txtStartMinute.SetReadOnly(true);
                    this.dtPerformDateTo.SetReadOnly(true);
                    this.txtEndHour.SetReadOnly(true);
                    this.txtEndMinute.SetReadOnly(true);
                    this.txtDuration.SetReadOnly(true);
                    this.txtReason.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    if (this.isApproved)
                    {
                        base.DisabledLink(this.btnApprove, true);
                        base.DisabledLink(this.btnIgnore, true);
                        base.DisabledLink(this.btnPrevBack, true);
                    }
                    else
                    {
                        base.DisabledLink(this.btnApprove, !base._authority.IsApplyApproveApprove);
                        base.DisabledLink(this.btnIgnore, !base._authority.IsApplyApproveIgnore);

                        if (this.isDisablePrevBack)
                        {
                            base.DisabledLink(this.btnPrevBack, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnPrevBack, !base._authority.IsApplyApproveReBack);
                        }

                    }

                    break;
            }

        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Apply apply)
        {
            //Show data
            if (apply != null)
            {
                using (DB db = new DB())
                {
                    ApplyApproveListService appSer = new ApplyApproveListService(db);
                    T_Apply_Approve_List appLst = appSer.GetByKey2(apply.ID, this.LoginInfo.User.ID);
                    if (appLst != null)
                    {
                        this.IsInspected = appLst.ApproveStatus != (int)StatusHasAprove.New;
                    }
                    M_UserInfo user = new M_UserInfo();
                    UserService userSer = new UserService(db);
                    this.txtApplyNo.Value = apply.ApplyNo;
                    this.dtApplyDate.Value = apply.ApplyDate;

                    this.GetDataSourceForCmbTemplateForm(apply.UserID);

                    FormTypeService typeSer = new FormTypeService(db);
                    M_Form_Type typeApp = typeSer.GetByID(apply.TypeApplyID);
                    if (typeApp != null)
                    {
                        this.cmbTemplateForm.SelectedValue = typeApp.FormID.ToString();
                        if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                        {
                            this.IsPenalized = typeApp.TimeOfRule == (int)TimeOfRuleLeave.TruPhep;
                        }
                    }

                    this.CurrenType = int.Parse(this.cmbTemplateForm.SelectedValue);
                    this.lblDuration.InnerHtml = this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE ? "day" : "hour";
                    this.SetDataApplyTypeCbo(this.CurrenType);

                    this.cmbApplyType.SelectedValue = apply.TypeApplyID.ToString();

                    user = userSer.GetUserInfoByID(apply.UserID);
                    if (user != null)
                    {
                        this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(user.UserCD, M_User.MAX_USER_CODE_SHOW);
                        this.txtEmployeeNm.Value = user.UserName1;

                        ApplyService applySer = new ApplyService(db);
                        this.txtDepartment.Value = user.DepartmentName;
                        if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                        {
                            this.txtCurrentAnnual.Value = applySer.GetRemainDays(apply.ID, user.ID);
                        }

                        this.txtPosition.Value = user.Position2;
                    }

                    this.dtPerformDateFrm.Value = apply.StartDate;
                    this.txtStartHour.Text = apply.StartHour.ToString("00");
                    this.txtStartMinute.Text = apply.StartMinute.ToString("00");
                    this.dtPerformDateTo.Value = apply.EndDate;
                    this.txtEndHour.Text = apply.EndHour.ToString("00");
                    this.txtEndMinute.Text = apply.EndMinute.ToString("00");

                    if (this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        if (apply.StartHour == 8)
                        {
                            this.cmbShiftFrom.SelectedValue = ((int)ShiftValue.Morning).ToString();
                        }
                        else
                        {
                            this.cmbShiftFrom.SelectedValue = ((int)ShiftValue.Afternoon).ToString();
                        }
                        if (apply.EndHour == 11)
                        {
                            this.cmbShiftTo.SelectedValue = ((int)ShiftValue.Morning).ToString();
                        }
                        else
                        {
                            this.cmbShiftTo.SelectedValue = ((int)ShiftValue.Afternoon).ToString();
                        }

                        if (apply.StartDate != apply.EndDate)
                        {
                            this.cmbPerform.SelectedValue = ((int)PerformValue.MultiDays).ToString();
                        }
                        else if (this.cmbShiftFrom.SelectedValue != this.cmbShiftTo.SelectedValue)
                        {
                            this.cmbPerform.SelectedValue = ((int)PerformValue.FullDay).ToString();
                        }
                        else
                        {
                            this.cmbPerform.SelectedValue = this.cmbShiftFrom.SelectedValue;
                        }
                    }

                    this.txtDuration.Value = apply.Duration;

                    this.txtApproveReason.Value = string.Empty;

                    // this.chkDeletedData.Checked = apply.StatusFlag==1?true:false;

                    this.DataID = apply.ID;
                    this.ApplyStatus = apply.ApplyStatus;
                    this.PreApplyID = apply.PreApplyID;
                    ApplyService ser = new ApplyService(db);
                    if (this.PreApplyID.HasValue)
                    {
                        T_Apply preApp = ser.GetByID(this.PreApplyID.Value);
                        if (preApp != null)
                        {
                            this.PreApplyNo = preApp.ApplyNo;
                            this.txtReason.Value = preApp.Reason;
                            this.txtReasonCancel.Value = apply.Reason;
                        }
                    }
                    else
                    {
                        this.txtReason.Value = apply.Reason;
                    }

                    M_User createUser = userSer.GetByID(apply.CreateUID);
                    if (createUser != null)
                    {
                        this.CreateUserCD = createUser.UserCD;
                    }
                }
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveList(this.DataID, true);
                this.isDispApproveButton = this.IsDisplayApproveButton(this.DataID, this.LoginInfo.User.ID);
                this.isDispIgnoreButton = this.IsDisplayIgnoreButton(this.DataID, this.LoginInfo.User.ID);
                this.isShowPrevBackButton = this.IsDisplayPreBackButton(this.DataID, this.LoginInfo.User.ID);
                this.isDispViewButton = this.IsDisplayViewButton(this.DataID, this.LoginInfo.User.ID);

            }
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayApproveButton(int appID, int loginID)
        {
            using (DB db=new DB())
            {
                ApplyApproveListService appLstSer = new ApplyApproveListService(db);
                T_Apply_Approve_List apprLst = appLstSer.GetApproveRow(appID, loginID);
                if (apprLst != null)
                {
                    if (apprLst.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (short)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                   
                    return true;
                }
                return false;
            }            
        }

        /// <summary>
        /// IsDisplayViewButton
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayViewButton(int appID, int loginID)
        {
            using (DB db = new DB())
            {
                ApplyApproveListService appLstSer = new ApplyApproveListService(db);
                T_Apply_Approve_List apprLst = appLstSer.GetApproveRow(appID, loginID);
                if (apprLst != null)
                {
                    if (apprLst.RouteLevel != 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (short)StatusApply.Approved)
                    {
                        return true;
                    }
                }
                return false;
            }
        }
        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayIgnoreButton(int appID, int loginID)
        {
            using (DB db = new DB())
            {
                ApplyApproveListService appLstSer = new ApplyApproveListService(db);
                T_Apply_Approve_List apprLst = appLstSer.GetApproveRow(appID, loginID);
                if (apprLst != null)
                {
                    if (apprLst.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                    if (apprLst.GetRejectSetting(RejectSetting.RejectAuthor))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayPreBackButton(int appID, int loginID)
        {
            using (DB db = new DB())
            {
                ApplyApproveListService appLstSer = new ApplyApproveListService(db);
                T_Apply_Approve_List apprLst = appLstSer.GetByKey2(appID, loginID);
                if (apprLst != null)
                {
                    if (apprLst.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                    if (apprLst.GetRemandSetting(RemandSetting.RemandAuthor) && appLstSer.CheckApproveIsFinishLevel2(appID, apprLst.RouteLevel - 1))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// CreateDailyData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private IList<T_Daily> CreateDailyData(T_Apply apply, int typeOfForm = (int)TypeFormID.Apply)
        {
            IList<T_Daily> dailyList = new List<T_Daily>();
            M_Holiday hld;
            DateTime sDate = apply.StartDate;
            DateTime eDate = apply.EndDate;

            using (DB db = new DB())
            {
                HolidayService hSer = new HolidayService(db);
                hld = hSer.GetByDay(sDate);
            }
            
            while (sDate <= eDate)
            {
                if (int.Parse(this.cmbTemplateForm.SelectedValue) == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                { 
                    if (sDate.DayOfWeek == DayOfWeek.Saturday || sDate.DayOfWeek == DayOfWeek.Sunday || hld != null)
                    {
                        sDate = sDate.AddDays(1);
                        continue;
                    }
                }
                T_Daily daily = new T_Daily();
                daily.WorkDate = sDate;
                daily.UserID = apply.UserID;
                daily.TypeApplyID = apply.TypeApplyID;
                daily.ApplyID = apply.ID;
                daily.VacationID = null;
                daily.ApproveID = null;
                daily.Content = apply.Reason;

                if (sDate == apply.StartDate)
                {
                    daily.StartHour = (short)apply.StartHour;
                    daily.StartMinute = (short)apply.StartMinute;
                }
                else if (int.Parse(this.cmbTemplateForm.SelectedValue) == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                {
                    daily.StartHour = T_Daily.START_HOUR_DEFAULT;
                    daily.StartMinute = T_Daily.START_MINUTE_DEFAULT;
                }
                else
                {
                    daily.StartHour = T_Apply.START_OF_DAY_HOUR;
                    daily.StartMinute = T_Apply.START_OF_DAY_MINUTE;
                }

                if (sDate == apply.EndDate)
                {
                    daily.EndHour = (short)apply.EndHour;
                    daily.EndMinute = (short)apply.EndMinute;
                }
                else if (int.Parse(this.cmbTemplateForm.SelectedValue) == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                {
                    daily.EndHour = T_Daily.END_HOUR_DEFAULT;
                    daily.EndMinute = T_Daily.END_MINUTE_DEFAULT;
                }
                else
                {
                    daily.EndHour = T_Apply.END_OF_DAY_HOUR;
                    daily.EndMinute = T_Apply.END_OF_DAY_MINUTE;
                }

                daily.DeleteFlag = 0;
                daily.CreateUID = apply.CreateUID;
                daily.UpdateUID = apply.CreateUID;
                dailyList.Add(daily);
                sDate = sDate.AddDays(1);
            }
                
            return dailyList;
        }

        /// <summary>
        /// Set data for ApplyType combobox
        /// </summary>
        private void SetDataApplyTypeCbo(int formID)
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> typeApplyList = new List<DropDownModel>();
                FormTypeService frmTypeSer = new FormTypeService(db);

                typeApplyList = frmTypeSer.GetDataForDropdownList(formID);
                this.cmbApplyType.DataSource = typeApplyList;
            }
            this.cmbApplyType.DataValueField = "Value";
            this.cmbApplyType.DataTextField = "DisplayName";
            this.cmbApplyType.DataBind();

        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitComboboxPerform()
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.Morning).ToString(), DisplayName = "Morning" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.Afternoon).ToString(), DisplayName = "Afternoon" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.FullDay).ToString(), DisplayName = "Full day" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.MultiDays).ToString(), DisplayName = "Multi days" });

            // init combox 
            this.cmbPerform.DataSource = lstData;
            this.cmbPerform.DataValueField = "Value";
            this.cmbPerform.DataTextField = "DisplayName";
            this.cmbPerform.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitComboboxShift(DropDownList ddl)
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            lstData.Add(new DropDownModel() { Value = ((int)ShiftValue.Morning).ToString(), DisplayName = ShiftValue.Morning.ToString() });
            lstData.Add(new DropDownModel() { Value = ((int)ShiftValue.Afternoon).ToString(), DisplayName = ShiftValue.Afternoon.ToString() });

            // init combox 
            ddl.DataSource = lstData;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }     

        #endregion

        #endregion

        #region Web Method

        ///// <summary>
        ///// Get Employee Name By Employee Code
        ///// </summary>
        ///// <param name="in1"></param>
        ///// <returns></returns>
        //[System.Web.Services.WebMethod]
        //public static string GetEmployeeName(string in1)
        //{
        //    var employeeCd = in1;
        //    var employeeCdShow = in1;
        //    employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
        //    employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

        //    try
        //    {
        //        using (DB db = new DB())
        //        {
        //            UserService userSer = new UserService(db);
        //            M_User model = userSer.GetByUserCD(employeeCd);
        //            if (model != null)
        //            {
        //                DepartmentService deptSer = new DepartmentService(db);
        //                M_Department dept = deptSer.GetByID(model.DepartmentID);
        //                var result = new
        //                {
        //                    employeeCD = employeeCdShow,
        //                    employeeNm = model.UserName1,
        //                    department = dept.DepartmentName,
        //                    position = model.Position

        //                };
        //                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
        //            }
        //            var employee = new
        //            {
        //                employeeCD = employeeCdShow
        //            };

        //            return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return null;
        //    }
        //}

        #endregion
    }
}
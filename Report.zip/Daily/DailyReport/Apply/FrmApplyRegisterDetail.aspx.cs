﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;

namespace DailyReport.Apply
{
    /// <summary>
    /// FrmApplyRegisterDetail
    /// ISV-TRAM 2015/04/01
    /// </summary>

    public partial class FrmApplyRegisterDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Apply/FrmApplyRegisterList.aspx";
        private const string APPLY_INFO = "This apply is cancellation of";
        #endregion

        #region enum

        /// <summary>
        /// Shift value
        /// </summary>
        enum ShiftValue
        {
            Morning = 0,
            Afternoon
        }

        /// <summary>
        /// Perform value
        /// </summary>
        enum PerformValue
        {
            Morning = 0,
            Afternoon,
            FullDay,
            MultiDays
        }

        #endregion

        #region Variable

        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;

        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;

        /// <summary>
        /// lblApplyInfo
        /// </summary>
        public string lblApplyInfo = APPLY_INFO;

        /// <summary>
        /// isHasData
        /// </summary>
       // public bool isHasData;

        public bool isExistCancel;

        #endregion

        #region Property

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Type Apply Current
        /// </summary>
        public int CurrenType
        {
            get { return (int)ViewState["CurrenType"]; }
            set { ViewState["CurrenType"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyNo
        /// </summary>
        public string PreApplyNo
        {
            get { return (string)ViewState["PreApplyNo"]; }
            set { ViewState["PreApplyNo"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }

        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<ApplyApproveListModel> ApproverList
        {
            get { return (IList<ApplyApproveListModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }

        /// <summary>
        /// ApproveStatus
        /// </summary>
        public short ApproveStatus
        {
            get { return (short)ViewState["ApproveStatus"]; }
            set { ViewState["ApproveStatus"] = value; }
        }
        //public int countListApprover
        //{
        //    get { return (int)ViewState["countListApprover"]; }
        //    set { ViewState["countListApprover"] = value; }
        //}

        /// <summary>
        /// Is penalized(Bi tru phep nam)
        /// </summary>
        public bool IsPenalized
        {
            get { return (bool)ViewState["IsPenalized"]; }
            set { ViewState["IsPenalized"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Apply Register";
            base.FormSubTitle = "Detail";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtReason.MaxLength = T_Apply.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// Load form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["DataID"] == null)
                    {
                        this.ApplyStatus = (int)StatusApply.Draft;

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["DataID"].ToString());
                        T_Apply data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Checked change chkisAgent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {

            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            if (this.chkIsAgent.Checked)
            {
                this.txtEmployeeCD.ReadOnly = false;
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.hdnDepartmentID.Value = LoginInfo.Department.ID.ToString();
                this.txtCurrentAnnual.Value = 0;
                this.txtCurrentAnnual.Text = string.Empty;
                this.txtDuration.Value = 0;
                this.txtDuration.Text = string.Empty;
            }
            else
            {
                this.txtEmployeeCD.ReadOnly = true;
                this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtEmployeeNm.Value = LoginInfo.User.UserName1;
                using (DB db = new DB())
                {
                    ApplyService applySer = new ApplyService(db);
                    DepartmentService deptSer = new DepartmentService(db);
                    M_Department dept = deptSer.GetByID(LoginInfo.Department.ID);
                    this.txtDepartment.Value = dept.DepartmentName;
                    this.txtCurrentAnnual.Value = applySer.GetRemainDays(-1, LoginInfo.User.ID); ;
                }
                this.txtPosition.Value = LoginInfo.User.Position2;
                
                this.GetDataSourceForCmbTemplateForm(this.LoginInfo.User.ID);
                this.TemplateFormChanged();
            }

            this.LoadDataForApproveListFromRoute(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
        }

        /// <summary>
        /// Selected change cmbApplyType
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbTemplateForm_OnSelectedIndexChanged(object sender, EventArgs e)
        {            
            this.ChangeTemplateFormOnChanged();
            this.SetValueForHiddenProxy(this.Mode != Mode.Update);
        }

        /// <summary>
        /// ChangeTemplateFormOnChanged
        /// </summary>
        private void ChangeTemplateFormOnChanged()
        {
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            this.TemplateFormChanged();
            this.LoadDataForApproveListFromRoute(this.CurrenType);

            this.txtStartHour.Text = T_Daily.START_HOUR_DEFAULT.ToString("00");
            this.txtStartMinute.Text = T_Daily.START_MINUTE_DEFAULT.ToString("00");
            this.txtEndHour.Text = T_Daily.END_HOUR_DEFAULT.ToString("00");
            this.txtEndMinute.Text = T_Daily.END_MINUTE_DEFAULT.ToString("00");
            if (CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
            {
                this.cmbPerform.SelectedValue = ((int)PerformValue.Morning).ToString();
                this.txtEndHour.Text = T_Daily.END_HOUR_NOON_DEFAULT.ToString("00");
                this.txtEndMinute.Text = T_Daily.END_MINUTE_NOON_DEFAULT.ToString("00");
            }
        }

        /// <summary>
        /// Template form changed
        /// </summary>
        private void TemplateFormChanged()
        {
            this.CurrenType = int.Parse(this.cmbTemplateForm.SelectedValue);
            this.hdnCurrentType.Value = this.CurrenType.ToString();
            this.lblDuration.InnerHtml = this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE ? "day" : "hour";
            this.SetDataApplyTypeCbo(this.CurrenType);
        }

        /// <summary>
        /// Click btnSeachUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUser_Click(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.LoadDataForApproveListFromRoute(this.CurrenType);
            this.colorStatus = base.GetStatusColorLabel((int)StatusApply.Draft, ref this.statusNameLbl);
            this.SetApplyTypePenalized(int.Parse(this.cmbApplyType.SelectedValue));
            if (!this.PreApplyID.HasValue)
            {
                ////Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Check CheckValidAnnual
                if (!this.CheckValidAnnual())
                {
                    return;
                }
                //Check duplicate time apply
                if (this.IsDuplicateApplyTime(-1))
                {
                    return;
                }
            }
            else
            {
                //Check input mode cancel
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// btnCopy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCoppy_Click(object sender, EventArgs e)
        {
            //Get data
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ApplyStatus = (int)StatusApply.Draft;
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                this.PreApplyID = null;
                this.PreApplyNo = null;
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check data
            if (data != null)
            {
                var isOk = true;
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);

                if (data.UpdateDate != this.OldUpdateDate)
                {
                    this.LoadDataForApproveListFromApproveList(this.DataID,true);

                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (data.StatusFlag == 1)
                    {
                        base.RedirectUrl(URL_LIST);
                        return;
                    }
                }

                //Show data
                this.ShowData(data);
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Update;
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            this.SetApplyTypePenalized(int.Parse(this.cmbApplyType.SelectedValue));
            this.RestoreListApprove();
            if (this.PreApplyID.HasValue)
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            else
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Check CheckValidAnnual
                if (!this.CheckValidAnnual())
                {
                    return;
                }
                //Check duplicate time apply
                if (this.IsDuplicateApplyTime(this.DataID))
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.RestoreListApprove();
                //this.SetApplyTypePenalized(int.Parse(this.cmbApplyType.SelectedValue));
                this.ProcessMode(Mode.Delete);
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Confirm;

            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                var isOk = true;
                if (apply.UpdateDate != this.OldUpdateDate)
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (apply.StatusFlag == 1)
                    {
                        this.LoadDataForApproveListFromApproveList(this.DataID,true);
                        base.RedirectUrl(URL_LIST);
                        return;
                    }

                }

                this.RestoreListApprove();
                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Confirm);

                    //Show question confirm
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
                }

            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.ShowData(apply);
                this.PreApplyNo = apply.ApplyNo;
                this.PreApplyID = apply.ID;
                this.ApplyStatus = (int)StatusApply.Cancel;
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);

                this.ProcessMode(Mode.Cancel);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelApply_Click(object sender, EventArgs e)
        {
            this.ApproveStatus = (int)StatusApply.Cancel;
            this.RestoreListApprove();
            if (IsExistCancel())
            {
                base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
            }
            else
            {
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Apply data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                case Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get 
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.colorStatus = base.GetStatusColorLabel((int)StatusApply.Draft, ref this.statusNameLbl);
                        this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
                    }
                    break;

                case Mode.Delete:

                    //Delete 
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                    }

                    break;
                case Mode.Confirm:
                    //Update Data
                    //this.ApplyStatus = (short)StatusApply.Confirm;
                    ret = this.Confirm(); // this.UpdateApplyStatus(this.ApplyStatus);
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Cancel:
                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Apply data = this.GetApplyByID(this.DataID);
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }

            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }
       
        #endregion

        #region Methods

        /// <summary>
        /// Get datasource for dropdownlist template form
        /// </summary>
        private void GetDataSourceForCmbTemplateForm(int userID)
        {
            using (DB db = new DB())
            {
                Config_HService conSer = new Config_HService(db);
                IList<DropDownModel> lstData = conSer.GetFormatTypeWithForm(M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);


                this.cmbTemplateForm.DataSource = lstData.Where(m => m.Value == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE.ToString()
                                                                    || m.Value == M_Config_D.TEMPLATE_FORM_APPLY_TIME.ToString());
                this.cmbTemplateForm.DataValueField = "Value";
                this.cmbTemplateForm.DataTextField = "DisplayName";
                this.cmbTemplateForm.DataBind();
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitComboboxPerform()
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.Morning).ToString(), DisplayName = "Morning" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.Afternoon).ToString(), DisplayName = "Afternoon" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.FullDay).ToString(), DisplayName = "Full day" });
            lstData.Add(new DropDownModel() { Value = ((int)PerformValue.MultiDays).ToString(), DisplayName = "Multi days" });

            // init combox 
            this.cmbPerform.DataSource = lstData;
            this.cmbPerform.DataValueField = "Value";
            this.cmbPerform.DataTextField = "DisplayName";
            this.cmbPerform.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitComboboxShift(DropDownList ddl)
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            lstData.Add(new DropDownModel() { Value = ((int)ShiftValue.Morning).ToString(), DisplayName = ShiftValue.Morning.ToString() });
            lstData.Add(new DropDownModel() { Value = ((int)ShiftValue.Afternoon).ToString(), DisplayName = ShiftValue.Afternoon.ToString() });

            // init combox 
            ddl.DataSource = lstData;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/27
        /// </summary>
        private void InitUserInfo()
        {
            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            this.txtEmployeeNm.Value = LoginInfo.User.UserName1;
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                ApplyService applySer = new ApplyService(db);
                M_Department dept = deptSer.GetByID(LoginInfo.Department.ID);

                this.txtDepartment.Value = dept.DepartmentName;
                this.hdnDepartmentID.Value = dept.ID.ToString();
                this.hdnDepartmentName.Value = dept.DepartmentName;
                this.txtCurrentAnnual.Value = applySer.GetRemainDays(-1, LoginInfo.User.ID);                
            }
            this.txtPosition.Value = LoginInfo.User.Position2;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
          //  this.countListApprover = 0;
            this.IsPenalized = false;
            this.GetDataSourceForCmbTemplateForm(this.LoginInfo.User.ID);
            this.TemplateFormChanged();            
            this.InitComboboxPerform();
            this.InitComboboxShift(this.cmbShiftFrom);
            this.InitComboboxShift(this.cmbShiftTo);
            this.cmbShiftTo.SelectedValue = "1";

            this.dtApplyDate.Value = null;
            this.InitUserInfo();

            this.dtPerformDateFrm.Value = DateTime.Now;
            this.dtPerformDateTo.Value = DateTime.Now;
            this.txtStartHour.Text = T_Daily.START_HOUR_DEFAULT.ToString("00");
            this.txtStartMinute.Text = T_Daily.START_MINUTE_DEFAULT.ToString("00");
            this.txtEndHour.Text = T_Daily.END_HOUR_DEFAULT.ToString("00");
            this.txtEndMinute.Text = T_Daily.END_MINUTE_DEFAULT.ToString("00");
            if (CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
            {
                this.txtEndHour.Text = T_Daily.END_HOUR_NOON_DEFAULT.ToString("00");
                this.txtEndMinute.Text = T_Daily.END_MINUTE_NOON_DEFAULT.ToString("00");
            }
            this.DataID = -1;
            this.PreApplyID = null;
            this.PreApplyNo = null;
        }

        /// <summary>
        /// Init combobox Hour
        /// </summary>
        /// <param name="ddlHour"></param>
        private void InitComboHour(DropDownList ddlHour)
        {

            IList<DropDownModel> lstHour = new List<DropDownModel>();
            for (int i = 0; i <= 24; i++)
            {
                DropDownModel item = new DropDownModel();
                item.DisplayName = i.ToString().PadLeft(2, '0');
                item.Value = i.ToString();
                lstHour.Add(item);
            }
            ddlHour.DataSource = lstHour;
            ddlHour.DataValueField = "Value";
            ddlHour.DataTextField = "DisplayName";
            ddlHour.DataBind();

        }        

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.InitData();
            this.txtApplyNo.Value = string.Empty;
            this.chkIsAgent.Checked = false;
            this.txtReason.Value = string.Empty;
        }

        #region Insert data

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                if (this.IsExistCancel())
                {
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    LoadDataForApproveListFromApproveList(this.DataID,true);
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);

                    return false;
                }

                if (!this.PreApplyID.HasValue && this.IsDuplicateApplyTime(-1))
                {
                    return false;
                }

                //Create model
                T_Apply data = new T_Apply();

                //Neu dang lam ma co nguoi khac cancel truoc thi phieu nay co phat hien ra ko????
                data = this.CreateApplyData(PreApplyID.HasValue);

                //Insert
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);

                    //Insert Daily
                    this.DataID = service.Insert(data);
                    this.ApplyStatus = data.ApplyStatus;
                    data.ID = this.DataID;

                    //Insert into T_Apply_Approve_List tabable
                    IList<ApplyApproveListModel> approveUserlist = this.GetListApprovePerson(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()), true);
                    IList<T_Apply_Approve_List> applyApproveLst = this.CreateApplyApproveListData(data, approveUserlist);
                    ApplyApproveListService applyApproveSer = new ApplyApproveListService(db);

                    if (applyApproveLst.Count == 0)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
                        return false;
                    }

                    foreach (T_Apply_Approve_List item in applyApproveLst)
                    {
                        applyApproveSer.Insert2(item);
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Apply_UK))
                {
                    // this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //  LoadDataForApproveListFromApproveList(this.DataID);
                    this.SetMessage(this.cmbApplyType.ID, M_Message.MSG_EXIST_CODE, "Apply Type");
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                // LoadDataForApproveListFromApproveList(this.DataID);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }


        #endregion

        #region Update data

        private T_Apply GetDataForUpdate(int appID)
        {
            T_Apply data;
            data = this.GetApplyByID(appID);

            data.TypeApplyID = int.Parse(this.cmbApplyType.SelectedValue.ToString());

            data.StartDate = this.dtPerformDateFrm.Value.Value;

            data.EndDate = this.dtPerformDateTo.Value.Value;

            data.StartHour = (int)this.txtStartHour.Value;
            data.StartMinute = (int)this.txtStartMinute.Value;
            data.EndHour = (int)this.txtEndHour.Value;
            data.EndMinute = (int)this.txtEndMinute.Value;
            data.Duration = (decimal)this.txtDuration.Value;

            if (data.PreApplyID.HasValue)
            {
                data.Reason = this.txtReasonCancel.Text;
            }
            else
            {
                data.Reason = this.txtReason.Text;
            }
            //data.StatusFlag = 0;//short.Parse( this.chkDeletedData.Checked==true?"1":"0") ;

            data.UpdateDate = this.OldUpdateDate;
            data.UpdateUID = this.LoginInfo.User.ID;

            return data;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Apply data = this.GetDataForUpdate(this.DataID);
                if (data != null)
                {
                    if (!this.PreApplyID.HasValue && this.IsDuplicateApplyTime(this.DataID))
                    {
                        return false;
                    }

                    //Update data
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ApplyService service = new ApplyService(db);

                        //Update
                        if (data.Status == DataStatus.Changed)
                        {
                            //Update T_Apply
                            ret = service.Update(data);
                            if (ret > 0)
                            {
                                //Insert into T_Apply_Approve_List tabable
                                IList<ApplyApproveListModel> approveUserlist = this.GetListApprovePerson(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()), true);
                                IList<T_Apply_Approve_List> applyApproveLst = this.CreateApplyApproveListData(data, approveUserlist);
                                ApplyApproveListService applyApproveSer = new ApplyApproveListService(db);

                                if (applyApproveLst.Count == 0)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
                                    return false;
                                }

                                //Delete T_ApplyApproveList
                                applyApproveSer.Delete2(data.ID);

                                //Insert T_ApplyApproveList
                                foreach (T_Apply_Approve_List item in applyApproveLst)
                                {
                                    applyApproveSer.Insert2(item);
                                }

                                db.Commit();
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                // LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Confirm

        ///// <summary>
        ///// ApproveData
        ///// </summary>
        ///// <param name="applyStatus"></param>
        ///// <returns></returns>
        //private bool ApproveData(int applyID)
        //{
        //    try
        //    {
        //        int ret = 0;
        //        using (DB db = new DB(System.Data.IsolationLevel.Serializable))
        //        {

        //            ApplyApproveListService approveSer = new ApplyApproveListService(db);
        //            T_Apply_Approve_List applyList = new T_Apply_Approve_List();
        //            applyList.ApplyID = applyID;
        //            applyList.ApproveStatus = (short)StatusHasAprove.Approved;
        //            applyList.ApproveUID = LoginInfo.User.ID;
        //            ret = approveSer.Approve(applyList, (short)StatusHasAprove.New, (short)StatusHasAprove.BackPrev);

        //            //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
        //            approveSer.UpdateStatusForPrevBack(applyList.ApplyID, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
        //            db.Commit();
        //        }

        //        //Check result update
        //        if (ret == 0)
        //        {
        //            //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
        //            //  LoadDataForApproveListFromApproveList();
        //            //Data is changed
        //            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
        //            return false;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        // this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
        //        // LoadDataForApproveListFromApproveList();
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

        //        Log.Instance.WriteLog(ex);
        //        return false;
        //    }

        //    return true;
        //}

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool Confirm()
        {
            bool success = false;
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);

                    //Update StatusFlag
                    ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (int)StatusApply.Approving, 0, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        ApplyApproveListService approveSer = new ApplyApproveListService(db);
                        T_Apply_Approve_List applyList = new T_Apply_Approve_List();
                        applyList.ApplyID = this.DataID;
                        applyList.ApproveStatus = (short)StatusHasAprove.New;
                        applyList.ApproveUID = null;
                        applyList.ApproveDate = null;
                        applyList.ApproveReason = null;
                        approveSer.Update2(applyList);
                    }
                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                    success = true;
                }               
                
            }
            catch (Exception ex)
            {
                //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            //TRAM - 2015/05/28 - Send Email for Confirm
            
            try
            {
                //Send mail
                if (success)
                {
                    IList<string> lstEmail = this.GetListEmail();
                    StringBuilder mailBody = new StringBuilder();
                    if (lstEmail != null && lstEmail.Count > 0)
                    {
                        mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                        mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                        mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
                        mailBody.AppendLine("Reason: " + this.txtReason.Text);
                        string sSubject = string.Empty;
                        if (lstEmail.Count == 1)
                        {
                            sSubject = "There is " + lstEmail.Count + " requirement for approving";
                        }
                        else
                        {
                            sSubject = "There are " + lstEmail.Count + " requirements for approving";
                        }

                        CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);

                    }
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            //TRAM - 2015/05/28 - Send Email for Confirm - END

            return true;
        }


        #endregion

        #region  Delete Data

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);
                    T_Apply apply = new T_Apply();
                    apply.StatusFlag = 1;
                    apply.ID = this.DataID;
                    apply.UpdateUID = LoginInfo.User.ID;
                    apply.UpdateDate = this.OldUpdateDate;

                    //Update StatusFlag
                    ret = service.UpdateStatusFlag(apply);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //   LoadDataForApproveListFromApproveList();
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                // this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                // LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Apply GetApplyByID(int id)
        {
            T_Apply apply = new T_Apply();
            ApplyService appSer = new ApplyService();
            apply = appSer.GetByID(id);
            return apply;
        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <returns></returns>
        private IList<ApplyApproveListModel> GetListApproveUserFromApply(int DataID)
        {
            IList<ApplyApproveListModel> approveUserList = new List<ApplyApproveListModel>();
            ApplyApproveListService applyApproveSer = new ApplyApproveListService();
            approveUserList = applyApproveSer.GetByID2(DataID);
            return approveUserList;
        }

        /// <summary>
        /// Get list of approver
        /// </summary>
        /// <param name="TypeID"></param>
        /// <param name="isIncludeView">true: include level 99, false:exclude level 99</param>
        /// <returns></returns>
        private IList<ApplyApproveListModel> GetListApprovePerson(int formID, bool isIncludeView = false, bool includeZeroLV = true)
        {
            //Custom again
            IList<ApplyApproveListModel> approveUserList = new List<ApplyApproveListModel>();
            IList<ApplyApproveListModel> allowList = new List<ApplyApproveListModel>();

            //Get level of leaver 
            //  int? userLevel = 0;
            UserService userSer = new UserService();
            int employeeID = 0;
            M_User user = userSer.GetByUserCD(this.txtEmployeeCD.Value);
            if (user != null)
            {
                employeeID = user.ID;
            }
            else
            {
                return allowList;
            }


            using (DB db = new DB())
            {
                ApplyApproveListService appApproveListSer = new ApplyApproveListService();
                //Get Approve List
                //approveUserList = appApproveListSer.GetApproverListByApplyTypeID(TypeID);
                approveUserList = appApproveListSer.GetApproverListByTypeAndUserID2(formID, employeeID, isGetLVZero: includeZeroLV ? EnumGetLevelZero.Include : EnumGetLevelZero.Exclude);
                if (approveUserList != null && approveUserList.Count != 0)
                {
                    if (isIncludeView || includeZeroLV)//Giu nguyen all level hien len
                    {
                        ((List<ApplyApproveListModel>)allowList).AddRange(approveUserList);
                    }
                    else
                    {
                        if (!includeZeroLV)//bo level 0
                        {
                            var lstTemp = (from i in approveUserList
                                           where !i.RouteLevel.Equals(M_Route_H.LEVEL_APPLICANT)
                                           select i).ToList<ApplyApproveListModel>();
                                          //select new ApplyApproveListModel
                                          //{
                                          //    RowNum = i.RowNum,
                                          //    ApplyID = i.ApplyID,
                                          //    UserName = i.UserName,
                                          //    RouteLevel = i.RouteLevel,
                                          //    RouteMethod = i.RouteMethod,
                                          //    Department = i.Department,
                                          //    Position = i.Position,
                                          //    ApproveDate = i.ApproveDate,
                                          //    ApproveDateStr = i.ApproveDateStr,
                                          //    ApproveUID = i.ApproveUID,
                                          //    ApproveName = i.ApproveName,
                                          //    ApproveReason = i.ApproveReason,
                                          //    ApproveFlagStr = i.ApproveFlagStr,
                                          //    RouteUID = i.RouteUID,
                                          //    ApproveStatus = i.ApproveStatus,
                                          //    //cac flag moi them vao

                                          //    RouteMethodStr = i.RouteMethodStr

                                          //};
                            if (lstTemp != null)
                            {
                               // ((List<ApplyApproveListModel>)approveUserList).AddRange(lstTemp);
                                approveUserList = new List<ApplyApproveListModel>(lstTemp);
                            }
                        }

                        if (!isIncludeView)//bo level view (99)
                        {
                            var lstTemp = (from i in approveUserList
                                           where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                                           select i).ToList<ApplyApproveListModel>();
                                          //select new ApplyApproveListModel
                                          //{
                                          //    RowNum = i.RowNum,
                                          //    ApplyID = i.ApplyID,
                                          //    UserName = i.UserName,
                                          //    RouteLevel = i.RouteLevel,
                                          //    RouteMethod = i.RouteMethod,
                                          //    Department = i.Department,
                                          //    Position = i.Position,
                                          //    ApproveDate = i.ApproveDate,
                                          //    ApproveDateStr = i.ApproveDateStr,
                                          //    ApproveUID = i.ApproveUID,
                                          //    ApproveName = i.ApproveName,
                                          //    ApproveReason = i.ApproveReason,
                                          //    ApproveFlagStr = i.ApproveFlagStr,
                                          //    RouteUID = i.RouteUID,
                                          //    ApproveStatus = i.ApproveStatus,
                                          //    //cac flag moi them vao

                                          //    RouteMethodStr = i.RouteMethodStr

                                          //};
                            if (lstTemp != null)
                            {
                               // ((List<ApplyApproveListModel>)approveUserList).AddRange(lstTemp);
                                approveUserList = new List<ApplyApproveListModel>(lstTemp);
                            }
                        }

                        allowList = new List<ApplyApproveListModel>(approveUserList);
                    }
                }
                return allowList;
            }
        }

        /// <summary>
        /// Load Data Approve List From Route
        /// </summary>
        private void LoadDataForApproveListFromRoute(int formID)
        {
            //IList<VacationApprove> approverList = new List<VacationApprove>();
            IList<ApplyApproveListModel> approverList = new List<ApplyApproveListModel>();
            approverList = this.GetListApprovePerson(formID, true, false);

            if (approverList != null && approverList.Count != 0)
            {
               // this.countListApprover = approverList.Count;                
              //  this.isHasData = true;
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
               // this.countListApprover = 0;
                
               // this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.ApproverList = new List<ApplyApproveListModel>(approverList);
            this.rptApproverList.DataBind();

            //this.isApproved = false;
            if (this.ApproverList == null || (this.ApproverList != null && this.ApproverList.Count == 0))
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    base.DisabledLink(this.btnInsert, true);
                }
                else if (this.Mode == Mode.Update)
                {
                    base.DisabledLink(this.btnUpdate, true);
                }
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    base.DisabledLink(this.btnInsert, false);
                }
                else if (this.Mode == Mode.Update)
                {
                    base.DisabledLink(this.btnUpdate, false);
                }
            }

        }

        public bool isHasData()
        {
            return (this.ApproverList != null && this.ApproverList.Count > 0);
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadDataForApproveListFromApproveList(int DataID, bool isIncludeView = false)
        {
            this.colorStatus = base.GetStatusColorLabel((this.GetApplyByID(DataID)).ApplyStatus, ref this.statusNameLbl);
            IList<ApplyApproveListModel> applyList = new List<ApplyApproveListModel>();
            applyList = this.GetListApproveUserFromApply(DataID);
           
            if (applyList != null && applyList.Count != 0)
            {
                IList<ApplyApproveListModel> allowList = new List<ApplyApproveListModel>();
                if (!isIncludeView)
                {
                    var lstTemp = from i in applyList
                                  where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                                  select new ApplyApproveListModel
                                  {
                                      RowNum = i.RowNum,
                                      ApplyID = i.ApplyID,
                                      UserName = i.UserName,
                                      RouteLevel = i.RouteLevel,
                                      RouteMethod = i.RouteMethod,
                                      Department = i.Department,
                                      Position = i.Position,
                                      ApproveDate = i.ApproveDate,
                                      ApproveDateStr = i.ApproveDateStr,
                                      ApproveUID = i.ApproveUID,
                                      ApproveName = i.ApproveName,
                                      ApproveReason = i.ApproveReason,
                                      ApproveFlagStr = i.ApproveFlagStr,
                                      RouteUID = i.RouteUID,
                                      ApproveStatus = i.ApproveStatus,
                                      RouteMethodStr = i.RouteMethodStr
                                  };
                    if (lstTemp != null)
                    {
                        ((List<ApplyApproveListModel>)allowList).AddRange(lstTemp);
                    }
                }
                else
                {
                    ((List<ApplyApproveListModel>)allowList).AddRange(applyList);
                }
              //  this.countListApprover = allowList.Count;
                this.ApproverList = new List<ApplyApproveListModel>(allowList);
               // this.isHasData = true;
                this.rptApproverList.DataSource = allowList;
                this.ApproverList = new List<ApplyApproveListModel>();
                ((List<ApplyApproveListModel>)this.ApproverList).AddRange(allowList);
               

            }
            else
            {
             //   this.countListApprover = 0;
                this.ApproverList = new List<ApplyApproveListModel>();
              //  this.isHasData = false;
                this.rptApproverList.DataSource = null;
                this.ApproverList = null;
            }            
            this.rptApproverList.DataBind();

            //Set complete status for ApplyStatus
          //  this.SetCompleteStatus(applyList);

        }

        /// <summary>
        /// TRAM - 2015/05/28
        /// Get list Email
        /// </summary>
        /// <returns>List of email</returns>
        private IList<string> GetListEmail()
        {
            IList<string> lstEmail = new List<string>();
            ApplyApproveListService approveSer = new ApplyApproveListService();
            IList<ApplyApproveListModel> applicantInfoList = approveSer.GetListByIDOptionLevel2(this.DataID, false, EnumGetLevelZero.Only);
            if (applicantInfoList != null && applicantInfoList.Count>0)
            {
                if (applicantInfoList[0].GetApplySetting(ApplySetting.MailAll))
                {
                    lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.GreaterLevel);
                    return lstEmail;
                }
                else if (applicantInfoList[0].GetApplySetting(ApplySetting.Mail))
                {
                    lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.NextLevel);
                }
            }
            return lstEmail;
        }

        #endregion

        #region Set data
        
        /// <summary>
        /// SetValueForHiddenProxy
        /// </summary>
        private void SetValueForHiddenProxy(bool isNewMode = true)
        {
            IList<ApplyApproveListModel> lst = new List<ApplyApproveListModel>();
            using (DB db = new DB())
            {
                UserService uSer = new UserService(db);
                M_User u = uSer.GetByUserCD(this.txtEmployeeCD.Text.Trim());
                if (u != null)
                {
                    if (u.ID != this.LoginInfo.User.ID)
                    {
                        return;
                    }
                }

                //UserService uSer = new UserService(db);
                //M_User u = uSer.GetByUserCD(this.txtEmployeeCD.Text.Trim());
                //if (u != null)
                //{
                //    ApplyApproveListService approveSer = new ApplyApproveListService(db);
                //    lst = approveSer.GetApproverListByTypeAndUserID2(int.Parse(this.cmbTemplateForm.SelectedValue), u.ID, isOnlyLVZero: true);
                //}
                ApplyApproveListService approveSer = new ApplyApproveListService(db);
                if (isNewMode)
                {
                    lst = approveSer.GetApproverListByTypeAndUserID2(int.Parse(this.cmbTemplateForm.SelectedValue), this.LoginInfo.User.ID, isGetLVZero: EnumGetLevelZero.Only);
                }
                else
                {
                    lst = approveSer.GetListByIDOptionLevel2(this.DataID, isGetLVZero: EnumGetLevelZero.Only);
                }
            }

            if (lst != null && lst.Count == 1)
            {
                if (lst[0].ApplyFlag1 == 1)//Proxy All
                {
                    this.chkIsAgent.Enabled = true;
                    this.hdnProxyAll.Value = "1";
                }
                else if (lst[0].ApplyFlag2 == 1)//Proxy Dept.
                {
                    this.chkIsAgent.Enabled = true;
                    this.hdnProxyDept.Value = "1";
                }
                else
                {
                    this.chkIsAgent.Enabled = false;
                }
            }
            else
            {
                this.chkIsAgent.Enabled = false;
                this.chkIsAgent.Checked = false;
                //  this.InitUserInfo();
                //  this.ChangeTemplateFormOnChanged();
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;            

            //Check model
            switch (mode)
            {

                case Mode.Insert:

                    this.ApplyStatus = (int)StatusApply.Draft;
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    if (!string.IsNullOrEmpty(this.cmbTemplateForm.SelectedValue))
                    {
                        this.LoadDataForApproveListFromRoute(int.Parse(this.cmbTemplateForm.SelectedValue));
                    }

                    this.chkIsAgent.Checked = false;
                    this.chkIsAgent.Enabled = true;
                    this.cmbTemplateForm.Enabled = true;
                    this.cmbApplyType.Enabled = true;
                    this.cmbPerform.Enabled = true;
                    this.cmbShiftFrom.Enabled = true;
                    this.cmbShiftTo.Enabled = true;
                    this.dtPerformDateFrm.SetReadOnly(false);
                    this.txtStartHour.SetReadOnly(false);
                    this.txtStartMinute.SetReadOnly(false);
                    this.dtPerformDateTo.SetReadOnly(false);
                    this.txtEndHour.SetReadOnly(false);
                    this.txtEndMinute.SetReadOnly(false);
                    this.txtReason.SetReadOnly(false);
                    
                    this.SetValueForHiddenProxy();
                                        
                    //this.isApproved = false;
                    break;
                case Mode.Copy:

                    this.ApplyStatus = (int)StatusApply.Draft;
                    this.txtApplyNo.Value = string.Empty;
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    if (!string.IsNullOrEmpty(this.cmbApplyType.SelectedValue))
                    {
                        this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue));
                    }

                    this.chkIsAgent.Enabled = true;
                    this.cmbTemplateForm.Enabled = true;
                    this.cmbApplyType.Enabled = true;
                    this.cmbPerform.Enabled = true;
                    this.cmbShiftFrom.Enabled = true;
                    this.cmbShiftTo.Enabled = true;
                    this.dtPerformDateFrm.SetReadOnly(false);
                    this.txtStartHour.SetReadOnly(false);
                    this.txtStartMinute.SetReadOnly(false);
                    this.dtPerformDateTo.SetReadOnly(false);
                    this.txtEndHour.SetReadOnly(false);
                    this.txtEndMinute.SetReadOnly(false);
                    this.txtReason.SetReadOnly(false);
                    //this.isApproved = false;

                    break;

                case Mode.Update:
                    if (!this.PreApplyID.HasValue)
                    {
                        this.txtEmployeeCD.SetReadOnly(false);
                        //this.txtEmployeeNm.ReadOnly = true;
                        this.chkIsAgent.Enabled = false;
                        this.cmbTemplateForm.Enabled = true;
                        this.cmbApplyType.Enabled = true;
                        this.cmbPerform.Enabled = true;
                        this.cmbShiftFrom.Enabled = true;
                        this.cmbShiftTo.Enabled = true;
                        this.dtPerformDateFrm.SetReadOnly(false);
                        this.txtStartHour.SetReadOnly(false);
                        this.txtStartMinute.SetReadOnly(false);
                        this.dtPerformDateTo.SetReadOnly(false);
                        this.txtEndHour.SetReadOnly(false);
                        this.txtEndMinute.SetReadOnly(false);                        
                       // this.txtReasonCancel.SetReadOnly(true);
                        if (this.ApplyStatus != (int)StatusApply.Draft)
                        {
                            base.DisabledLink(this.btnEdit, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                        }
                        this.txtReason.SetReadOnly(false);//can edit
                    }
                    else
                    {
                        this.txtReason.SetReadOnly(true);
                        this.txtReasonCancel.SetReadOnly(false);
                    }
                    
                    break;


                case Mode.Delete:

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.SetReadOnly(true);
                    //this.chkIsAgent.Disabled = true;
                    this.cmbTemplateForm.Enabled = false;
                    this.chkIsAgent.Enabled = false;
                    this.cmbApplyType.Enabled = false;
                    this.cmbPerform.Enabled = false;
                    this.cmbShiftFrom.Enabled = false;
                    this.cmbShiftTo.Enabled = false;
                    this.dtPerformDateFrm.SetReadOnly(true);
                    this.txtStartHour.SetReadOnly(true);
                    this.txtStartMinute.SetReadOnly(true);
                    this.dtPerformDateTo.SetReadOnly(true);
                    this.txtEndHour.SetReadOnly(true);
                    this.txtEndMinute.SetReadOnly(true);
                    this.txtReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;

                case Mode.Confirm:
                    //   this.LoadDataForApproveListFromApproveList();
                    this.ApplyStatus = (int)StatusApply.Draft;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;
                case Mode.Cancel:
                    this.txtApplyNo.Value = string.Empty;
                    this.ApplyStatus = (int)StatusApply.Cancel;
                    this.dtApplyDate.Value = null;
                    break;
                default:
                    this.chkIsAgent.Enabled = false;
                    this.cmbTemplateForm.Enabled = false;
                    this.cmbApplyType.Enabled = false;
                    this.cmbPerform.Enabled = false;
                    this.cmbShiftFrom.Enabled = false;
                    this.cmbShiftTo.Enabled = false;
                    this.dtPerformDateFrm.SetReadOnly(true);
                    this.txtStartHour.SetReadOnly(true);
                    this.txtStartMinute.SetReadOnly(true);
                    this.dtPerformDateTo.SetReadOnly(true);
                    this.txtEndHour.SetReadOnly(true);
                    this.txtEndMinute.SetReadOnly(true);
                    this.txtReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.Draft:
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                            base.DisabledLink(this.btnDelete, !base._authority.IsApplyRegistDelete);
                            base.DisabledLink(this.btnConfirm, !base._authority.IsApplyRegistConfirm);
                            break;
                                                    
                        case (int)StatusApply.Approving:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;
                        case (int)StatusApply.Approved:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Rejected:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        //case (int)StatusApply.BackPrev:
                        //    base.DisabledLink(this.btnEdit, true);
                        //    base.DisabledLink(this.btnConfirm, true);
                        //    break;
                        case (int)StatusApply.Cancel:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, false);
                            break;
                    }

                    ApplyService appSer = new ApplyService();
                    T_Apply app = appSer.GetByID(this.DataID);
                    if (app == null)
                    {
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnConfirm, true);
                    }

                    break;
            }

            this.txtCurrentAnnual.SetReadOnly(true);
            this.txtDuration.SetReadOnly(true);

            if (this.chkIsAgent.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Update || this.Mode == Mode.Copy))
            {
                this.txtEmployeeCD.SetReadOnly(false);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Apply apply)
        {
            //Show data
            if (apply != null)
            {
                
                M_UserInfo user = new M_UserInfo();
                UserService userSer = new UserService();
                // this.colorStatus = base.GetStatusColorLabel(apply.ApplyStatus, ref this.statusNameLbl);
                this.txtApplyNo.Value = apply.ApplyNo;
                this.dtApplyDate.Value = apply.ApplyDate;

                if (apply.UserID.Equals(apply.CreateUID))
                {
                    this.chkIsAgent.Checked = false;
                }
                else
                {
                    this.chkIsAgent.Checked = true;
                }
                this.GetDataSourceForCmbTemplateForm(apply.UserID);
                ApplyService applySer = new ApplyService();
                FormTypeService typeSer = new FormTypeService();
                M_Form_Type typeApp = typeSer.GetByID(apply.TypeApplyID);
                if (typeApp != null)
                {
                    this.cmbTemplateForm.SelectedValue = typeApp.FormID.ToString();
                    this.TemplateFormChanged();
                    if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        this.IsPenalized = typeApp.TimeOfRule == (int)TimeOfRuleLeave.TruPhep;
                    }
                }
                
                this.cmbApplyType.SelectedValue = apply.TypeApplyID.ToString();

                user = userSer.GetUserInfoByID(apply.UserID);
                if (user != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(user.UserCD, M_User.MAX_USER_CODE_SHOW);
                    this.txtEmployeeNm.Value = user.UserName1;

                    this.txtDepartment.Value = user.DepartmentName;
                    this.txtPosition.Value = user.Position2;

                    if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        this.txtCurrentAnnual.Value = applySer.GetRemainDays(apply.ID, user.ID);
                    }
                }
                this.dtPerformDateFrm.Value = apply.StartDate;
                this.txtStartHour.Text = apply.StartHour.ToString("00");
                this.txtStartMinute.Text = apply.StartMinute.ToString("00");

                this.dtPerformDateTo.Value = apply.EndDate;
                this.txtEndHour.Text = apply.EndHour.ToString("00");
                this.txtEndMinute.Text = apply.EndMinute.ToString("00");
                
                if (this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                {
                    if (apply.StartHour == 8)
                    {
                        this.cmbShiftFrom.SelectedValue = ((int)ShiftValue.Morning).ToString();
                    }
                    else
                    {
                        this.cmbShiftFrom.SelectedValue = ((int)ShiftValue.Afternoon).ToString();
                    }
                    if (apply.EndHour == 11)
                    {
                        this.cmbShiftTo.SelectedValue = ((int)ShiftValue.Morning).ToString();
                    }
                    else
                    {
                        this.cmbShiftTo.SelectedValue = ((int)ShiftValue.Afternoon).ToString();
                    }

                    if (apply.StartDate != apply.EndDate)
                    {
                        this.cmbPerform.SelectedValue = ((int)PerformValue.MultiDays).ToString();
                    }
                    else if (this.cmbShiftFrom.SelectedValue != this.cmbShiftTo.SelectedValue)
                    {
                        this.cmbPerform.SelectedValue = ((int)PerformValue.FullDay).ToString();
                    }
                    else
                    {
                        this.cmbPerform.SelectedValue = this.cmbShiftFrom.SelectedValue;
                    }
                }

                this.txtDuration.Value = apply.Duration;

                this.DataID = apply.ID;
                this.ApplyStatus = apply.ApplyStatus;
                this.PreApplyID = apply.PreApplyID;
                ApplyService ser = new ApplyService();
                if (this.PreApplyID.HasValue)
                {
                    T_Apply preApp = ser.GetByID(this.PreApplyID.Value);
                    if (preApp != null)
                    {
                        this.PreApplyNo = preApp.ApplyNo;
                        this.txtReason.Value = preApp.Reason;
                        this.txtReasonCancel.Value = apply.Reason;
                    }
                }
                else
                {
                    this.txtReason.Value = apply.Reason;
                }
                M_User createUser = userSer.GetByID(apply.CreateUID);
                if (createUser != null)
                {
                    this.CreateUserCD = createUser.UserCD;
                }
                
                this.isExistCancel = this.IsExistCancel();
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveListFromApproveList(apply.ID, true);
                this.ApproveStatus = apply.ApplyStatus;

            }
        }

        /// <summary>
        /// Create Apply data
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private T_Apply CreateApplyData(bool isCancel=false)
        {
            T_Apply data = new T_Apply();


            data.ApplyDate = null;
            TNoService noService = new TNoService();
            data.ApplyNo = noService.CreateNo(T_No.ApplyNo);
            data.ApplyStatus = (int)StatusApply.Draft;

            if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
            {
                data.PreApplyID = null;
            }
            else if (this.Mode == Mode.Cancel)
            {
                data.PreApplyID = this.PreApplyID;
            }

            if (this.chkIsAgent.Checked)
            {
                UserService userSer = new UserService();
                M_User user = userSer.GetByUserCD(this.txtEmployeeCD.Value);
                if (user != null)
                {
                    data.UserID = user.ID;
                }
            }
            else
            {
                data.UserID = LoginInfo.User.ID;
            }

            data.TypeApplyID = int.Parse(this.cmbApplyType.SelectedValue.ToString());
            data.StartDate = this.dtPerformDateFrm.Value.Value;
            data.StartHour = int.Parse(this.txtStartHour.Value.ToString());
            data.StartMinute = int.Parse(this.txtStartMinute.Value.ToString());

            data.EndDate = this.dtPerformDateTo.Value.Value;
            data.EndHour = int.Parse(this.txtEndHour.Value.ToString());
            data.EndMinute = int.Parse(this.txtEndMinute.Value.ToString());

            data.Duration = this.txtDuration.Value.Value;
            if (isCancel)
            {
                data.Reason = this.txtReasonCancel.Text;
            }
            else
            {
                data.Reason = this.txtReason.Text;
            }
            data.CreateUID = base.LoginInfo.User.ID;
            data.UpdateUID = base.LoginInfo.User.ID;
            return data;
        }

        /// <summary>
        /// Get value of annual day in config
        /// </summary>
        /// <param name="configCD"></param>
        /// <param name="value1"></param>
        /// <returns></returns>
        private string GetValue4(string configCD, int value1)
        {
            using (DB db = new DB())
            {
                Config_DService conSer = new Config_DService(db);
                return conSer.GetValue4(configCD, value1);
            }
        }

        /// <summary>
        /// GetTypeApplyByID
        /// </summary>
        /// <param name="typeApplyID">ID</param>
        /// <returns></returns>
        //private M_TypeApply GetTypeApplyByID(int typeApplyID)
        //{
        //    using (DB db = new DB())
        //    {
        //        TypeApplyService typeSer = new TypeApplyService(db);
        //        return typeSer.GetByID(typeApplyID);
        //    }
        //}

        /// <summary>
        /// Create data for ApplyApproveList 
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="lstApproveUser"></param>
        private IList<T_Apply_Approve_List> CreateApplyApproveListData(T_Apply apply, IList<ApplyApproveListModel> lstApproveUser)
        {
            IList<T_Apply_Approve_List> applyApproveList = new List<T_Apply_Approve_List>();
            foreach (ApplyApproveListModel item in lstApproveUser)
            {
                T_Apply_Approve_List model = new T_Apply_Approve_List();
                Hashtable htbUserID = new Hashtable();
                model.ApplyID = apply.ID;
                if (item.RouteLevel == M_Route_H.LEVEL_APPLICANT)
                {
                    model.RouteUID = apply.UserID;
                }
                else
                {
                    model.RouteUID = item.RouteUID;
                }
                model.RouteLevel = item.RouteLevel.Value;
                model.RouteMethod = item.RouteMethod.Value;
                model.ApproveStatus = item.ApproveStatus;
                model.ApproveUID = item.ApproveUID;
                model.ApproveDate = item.ApproveDate;
                model.ApproveReason = item.ApproveReason;
                model.RequireNum = item.RequireNum;
                var lstUserProxy = item.ProxyApprovalUser;
                var lstUser = lstUserProxy.Split(',');
               /* foreach (var it in lstUser)
                {
                    if (!string.IsNullOrEmpty(it) && !htbUserID.ContainsKey(it))
                    {
                        htbUserID.Add(it, it);
                    }
                }

                if (item.RouteLevel != M_Route_H.LEVEL_READER)
                {
                    if (item.ApproveFlag2 == 1)//Duoc Duyet gium boi all user co level lon hon
                    {
                        var lstTemp = (from l in lstApproveUser
                                       where l.RouteLevel > model.RouteLevel && l.RouteLevel != M_Route_H.LEVEL_READER
                                       select l).ToList<ApplyApproveListModel>();
                        foreach (var im in lstTemp)
                        {
                            if (!htbUserID.ContainsKey(im.RouteUID.ToString()))
                            {
                                htbUserID.Add(im.RouteUID.ToString(), im.RouteUID.ToString());
                            }
                        }
                    }
                    else if (item.ApproveFlag1 == 1)//Duoc duyet gium boi user of level + 1
                    {
                        var lstTemp = (from l in lstApproveUser
                                       where l.RouteLevel.Value.Equals((model.RouteLevel + 1))
                                       select l).ToList<ApplyApproveListModel>();
                        foreach (var im in lstTemp)
                        {
                            if (!htbUserID.ContainsKey(im.RouteUID.ToString()))
                            {
                                htbUserID.Add(im.RouteUID.ToString(), im.RouteUID.ToString());
                            }
                        }
                    }
                    List<string> keys = htbUserID.Keys.Cast<string>().ToList();
                    model.ProxyApprovalUser = string.Join(",", keys.ToArray());
                }
                */
                model.ProxyApprovalUser = item.ProxyApprovalUser;
                //Apply Flag
                model.ApplyFlag1 = item.ApplyFlag1;
                model.ApplyFlag2 = item.ApplyFlag2;
                model.ApplyFlag3 = item.ApplyFlag3;
                model.ApplyFlag4 = item.ApplyFlag4;

                //Reject Flag
                model.RejectFlag1 = item.RejectFlag1;
                model.RejectFlag2 = item.RejectFlag2;
                model.RejectFlag3 = item.RejectFlag3;
                model.RejectFlag4 = item.RejectFlag4;
                model.RejectFlag5 = item.RejectFlag5;
                model.RejectFlag6 = item.RejectFlag6;
                model.RejectFlag7 = item.RejectFlag7;

                //Remand Flag
                model.RemandFlag1 = item.RemandFlag1;
                model.RemandFlag2 = item.RemandFlag2;
                model.RemandFlag3 = item.RemandFlag3;
                model.RemandFlag4 = item.RemandFlag4;
                model.RemandFlag5 = item.RemandFlag5;
                model.RemandFlag6 = item.RemandFlag6;
                model.RemandFlag7 = item.RemandFlag7;

                //Approve Flag
                model.ApproveFlag1 = item.ApproveFlag1;
                model.ApproveFlag2 = item.ApproveFlag2;
                model.ApproveFlag3 = item.ApproveFlag3;
                model.ApproveFlag4 = item.ApproveFlag4;
                model.ApproveFlag5 = item.ApproveFlag5;
                model.ApproveFlag6 = item.ApproveFlag6;
                model.ApproveFlag7 = item.ApproveFlag7;
                model.ApproveFlag8 = item.ApproveFlag8;
                model.ApproveFlag9 = item.ApproveFlag9;

                //Read Flag
                model.ReadFlag1 = item.ReadFlag1;
                model.ReadFlag2 = item.ReadFlag2;
                model.ReadFlag3 = item.ReadFlag3;
                model.ReadFlag4 = item.ReadFlag4;
                model.ReadFlag5 = item.ReadFlag5;
               
                applyApproveList.Add(model);
            }

            return applyApproveList;
        }

        /// <summary>
        /// Set data for ApplyType combobox
        /// </summary>
        private void SetDataApplyTypeCbo(int formID)
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> typeApplyList = new List<DropDownModel>();
                FormTypeService frmTypeSer = new FormTypeService(db);

                typeApplyList = frmTypeSer.GetDataForDropdownList(formID);
                this.cmbApplyType.DataSource = typeApplyList;
                if (typeApplyList.Count > 0)
                {
                    var item = frmTypeSer.GetByID(int.Parse(typeApplyList[0].Value));
                    if (item != null && item.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        this.IsPenalized = item.TimeOfRule == (int)TimeOfRuleLeave.TruPhep;
                    }                    
                }
            }
            this.cmbApplyType.DataValueField = "Value";
            this.cmbApplyType.DataTextField = "DisplayName";
            this.cmbApplyType.DataBind();

        }

        ///// <summary>
        ///// Set PerformDateTo
        ///// </summary>
        //private void SetPerformDateTo()
        //{
        //    if (!string.IsNullOrEmpty(this.cmbApplyType.SelectedValue.ToString()))
        //    {
        //        M_TypeApply typeApp = this.GetTypeApplyByID(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
        //        if (typeApp != null && typeApp.FormID == (int)TypeFormID.Apply)
        //        {
        //            if (typeApp.MinStartHour != -1 && typeApp.MaxEndHour != -1)
        //            {
        //                if (typeApp.MaxEndHour < typeApp.MinStartHour)
        //                {
        //                    DateTime currentDate = this.dtPerformDateFrm.Value.Value;
        //                    DateTime nextDate = currentDate.AddDays(1);
        //                    this.dtPerformDateTo.Value = nextDate;
        //                    this.hdnPerformDateTo.Value = nextDate.ToShortDateString();
        //                }
        //                else
        //                {
        //                    this.dtPerformDateTo.Value = this.dtPerformDateFrm.Value;
        //                    this.hdnPerformDateTo.Value = this.dtPerformDateFrm.Value.Value.ToShortDateString();
        //                }
        //            }
        //        }
        //    }

        //}

        /// <summary>
        /// Change Employee Textbox
        /// </summary>
        private void EmployeeTextChange()
        {
            this.colorStatus = this.GetStatusColorLabel((int)StatusApply.Draft, ref this.statusNameLbl);
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            M_UserInfo user = new M_UserInfo();
            UserService userSer = new UserService();
            user = userSer.GetUserInfo(this.txtEmployeeCD.Value);
            
            if (this.chkIsAgent.Checked)
            {
            }
            if (user != null)
            {
                this.TemplateFormChanged();

                if (this.txtEmployeeCD.Value == loginUserCD)
                {
                    this.chkIsAgent.Checked = false;
                }
                this.txtDepartment.Value = user.DepartmentName;
                this.txtEmployeeNm.Value = user.UserName1;
                using (DB db = new DB())
                {
                    ApplyService applySer = new ApplyService(db);
                    
                    this.txtCurrentAnnual.Value = applySer.GetRemainDays(-1, user.ID);
                }

                this.txtPosition.Value = user.Position2;
            }
            else
            {
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.txtCurrentAnnual.Value = 0;
            }

            if (!string.IsNullOrEmpty(this.cmbTemplateForm.SelectedValue.ToString()))
            {
                this.LoadDataForApproveListFromRoute(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
            }           
        }

        #region Check data
        /// <summary>
        /// Checking LoginUser is the approver
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApprover(IList<ApplyApproveListModel> applyList)
        {
            ApplyApproveListModel approveInfo = new ApplyApproveListModel();
            approveInfo = (from app in applyList
                           where LoginInfo.User.ID.Equals(app.RouteUID)
                           select app).FirstOrDefault();

            return approveInfo != null ? true : false;

        }

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApproved(IList<ApplyApproveListModel> applyList)
        {
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            IList<ApplyApproveListModel> approveList = new List<ApplyApproveListModel>();
            approveList = (from app in applyList
                           where (app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.Ignore || app.ApproveStatus == (short)StatusHasAprove.BackPrev)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Checking approve status for previous level of loginuser level
        /// </summary>
        /// <param name="ApplyApproveListModel"></param>
        /// <returns></returns>
        private bool IsNotApprovedInPreLevel(IList<ApplyApproveListModel> applyList)
        {
            //Get level of user login 
            int? loginUserLevel = 0;
            ApplyApproveListModel loginUserInfo = new ApplyApproveListModel();
            loginUserInfo = (from app in applyList
                             where app.RouteUID == LoginInfo.User.ID
                             select app).SingleOrDefault();

            if (loginUserInfo != null)
            {
                loginUserLevel = loginUserInfo.RouteLevel;
            }

            IList<ApplyApproveListModel> notApproveList1 = new List<ApplyApproveListModel>();
            notApproveList1 = (from app in applyList
                               where ((app.RouteLevel == loginUserLevel && app.RouteMethod == (int)RouteMethods.AND)) && (app.ApproveStatus != (short)StatusHasAprove.Approved)
                               select app).ToList();


            if (notApproveList1 != null && notApproveList1.Count > 0)
            {
                IList<ApplyApproveListModel> notApproveList2 = new List<ApplyApproveListModel>();
                notApproveList2 = (from app in applyList
                                   where (app.RouteLevel == loginUserLevel - 1) && (app.ApproveStatus != (short)StatusHasAprove.Approved)
                                   select app).ToList();
                if (notApproveList2 != null && notApproveList2.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool IsExistCancel()
        {
            ApplyService appSer = new ApplyService();

            if (ViewState["DataID"] != null)
            {
                T_Apply app = appSer.GetByPreApplyID(this.DataID);
                if (app != null)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Check showing PrevBack button
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsShowPrevBackButton(IList<ApplyApproveListModel> applyList)
        {
            //Get level of user login 
            int? loginUserLevel = 0;
            ApplyApproveListModel approveUserInfo = new ApplyApproveListModel();
            approveUserInfo = (from app in applyList
                               where app.RouteUID == LoginInfo.User.ID
                               select app).SingleOrDefault();

            if (approveUserInfo != null)
            {
                loginUserLevel = approveUserInfo.RouteLevel;
            }

            ApplyApproveListService approveSer = new ApplyApproveListService();
            int minLevel = approveSer.GetMinRouteLevelByID2(this.DataID);

            //Get list of Approveer whose level is less than level of login user 
            if (loginUserLevel > minLevel)
            {
                IList<ApplyApproveListModel> approveUserList = new List<ApplyApproveListModel>();
                approveUserList = (from appUser in applyList
                                   where appUser.ApproveStatus == (short)StatusHasAprove.Approved && loginUserLevel >= appUser.RouteLevel
                                   select appUser).ToList();
                if (approveUserList != null && approveUserList.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Set complete status for the ApplyStatus
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        //private void SetCompleteStatus(IList<ApplyApproveListModel> applyList)
        //{
        //    IList<ApplyApproveListModel> completedList = new List<ApplyApproveListModel>();
        //    completedList = (from app in applyList
        //                     where app.ApproveStatus == (short)StatusHasAprove.Approved
        //                     select app).ToList();

        //    if (completedList != null && completedList.Count == applyList.Count)
        //    {
        //        this.ApplyStatus = (short)StatusApply.Approved;
        //    }
        //}

        /// <summary>
        /// Check inputing
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            string focusID = this.Mode == Mode.Update ? this.cmbTemplateForm.ID : this.txtEmployeeCD.ID;
            //Employee Code
            if (this.chkIsAgent.Checked)//dang xin gium ngkhac
            {
                IList<ApplyApproveListModel> lst = new List<ApplyApproveListModel>();
                using (DB db = new DB())
                {
                    ApplyApproveListService approveSer = new ApplyApproveListService(db);                   
                    lst = approveSer.GetApproverListByTypeAndUserID2(int.Parse(this.cmbTemplateForm.SelectedValue), this.LoginInfo.User.ID, isGetLVZero: EnumGetLevelZero.Only);                    
                }
                if (lst.Count == 1)//co level 0
                {
                    if (lst[0].ApplyFlag1 != 1 && lst[0].ApplyFlag2 != 1)//login user ko co quyen xin cho ngkhac
                    {
                        this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                    }
                    else//co quyen xin gium ngkhac
                    {
                        if (this.txtEmployeeCD.IsEmpty)
                        {
                            this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_REQUIRE, "Employee Code");
                        }
                        else
                        {
                            //Check employee's department is the same department with login user                            
                            UserService userSer = new UserService();
                            M_UserInfo mUser = userSer.GetUserInfo(this.txtEmployeeCD.Value);
                            if (mUser != null)
                            {
                                if (this.hdnProxyDept.Value == "1")//Gioi han trong pham vi dept.
                                {
                                     if (!mUser.DepartmentID.Equals(LoginInfo.Department.ID))
                                    {
                                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_VALUE_NOT_EXIST, "Employee Code");
                                        this.txtEmployeeCD.Value = string.Empty;
                                        this.txtEmployeeNm.Value = string.Empty;
                                        this.txtDepartment.Value = string.Empty;
                                        this.txtPosition.Value = string.Empty;
                                   }
                                }
                            }
                            else
                            {
                                this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_VALUE_NOT_EXIST, "Employee Code");
                            }
                        }
                    }
                }
                else
                {
                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                    return !base.HaveError;
                }
            }
            
            if (this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_TIME || (this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE && this.cmbPerform.SelectedValue == ((int)PerformValue.MultiDays).ToString()))
            {
                if (this.dtPerformDateFrm.Value == null)
                {
                    this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_REQUIRE, "Perform Date From");
                }

                if (this.txtStartHour.IsEmpty)
                {
                    this.SetMessage(this.txtStartHour.ID, M_Message.MSG_REQUIRE, "Perform Hour From");
                }

                if (this.txtStartMinute.IsEmpty)
                {
                    this.SetMessage(this.txtStartMinute.ID, M_Message.MSG_REQUIRE, "Perform Minute From");
                }

                if (this.dtPerformDateTo.Value == null)
                {
                    this.SetMessage(this.dtPerformDateTo.ID, M_Message.MSG_REQUIRE, "Perform Date To");
                }

                if (this.txtEndHour.IsEmpty)
                {
                    this.SetMessage(this.txtEndHour.ID, M_Message.MSG_REQUIRE, "Perform Hour To");
                }

                if (this.txtEndMinute.IsEmpty)
                {
                    this.SetMessage(this.txtEndMinute.ID, M_Message.MSG_REQUIRE, "Perform Minute To");
                }
            }
            else
            {
                if (this.dtPerformDateFrm.Value == null)
                {
                    this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_REQUIRE, "Perform Date");
                }
            }
            if (this.dtPerformDateFrm.Value != null && !this.txtStartHour.IsEmpty && !this.txtStartMinute.IsEmpty
                && this.dtPerformDateTo.Value != null && !this.txtEndHour.IsEmpty && !this.txtEndMinute.IsEmpty)
            {
                DateTime startDate = this.dtPerformDateFrm.Value.Value.Date.AddHours((int)this.txtStartHour.Value).AddMinutes((int)txtStartMinute.Value);
                DateTime endDate = this.dtPerformDateTo.Value.Value.Date.AddHours((int)this.txtEndHour.Value).AddMinutes((int)txtEndMinute.Value);
                if (endDate < startDate)
                {
                    this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_LESS_THAN, "Perform Date Form", "Perform Date To");
                    this.CtrlIDInfos.Add(this.txtStartHour.ID);
                    this.CtrlIDInfos.Add(this.txtStartMinute.ID);
                }
                else if (this.txtDuration.Value == 0)
                {
                    if(this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                    }
                    else
                    {
                        this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_GREATER_THAN, "Duration", "0");
                    }
                }
            }

            //Reason
            if (this.txtReason.IsEmpty)
            {
                this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Reason");
            }

            //Reason cancel
            if (this.PreApplyID.HasValue)
            {
                if (this.txtReasonCancel.IsEmpty)
                {
                    this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Reason Cancel");
                }
            }

            if (!base.HaveError && this.ApproverList!=null && this.ApproverList.Count == 0)
            {
                this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
            }

            return !base.HaveError;
        }


        /// <summary>
        /// Check inputing for cancel mode
        /// </summary>
        /// <returns></returns>
        private bool CheckInputForCancel()
        {
            //Reason cancel

            if (this.txtReasonCancel.IsEmpty)
            {
                this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Reason Cancel");
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check Valid Annual
        /// </summary>
        /// <returns></returns>
        private bool CheckValidAnnual()
        {
            FormTypeService frmTypeSer = new FormTypeService();
            M_Form_Type frmType = frmTypeSer.GetByID(int.Parse(this.cmbApplyType.SelectedValue));
            if (this.CurrenType == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE && frmType.TimeOfRule == (int)TimeOfRuleLeave.TruPhep)
            {
                decimal annualDay = this.txtDuration.Value.Value;
                M_User user = this.GetUserByCD(this.txtEmployeeCD.Text.Trim());
                if (user != null)
                {
                    ApplyService applySer = new ApplyService();
                    this.txtCurrentAnnual.Value = applySer.GetRemainDays(this.DataID, user.ID);
                    if (this.txtCurrentAnnual.Value.Value < annualDay)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    }
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Check duplicate time apply
        /// </summary>
        /// <param name="applyId"></param>
        /// <returns></returns>
        private bool IsDuplicateApplyTime(int applyId)
        {
            DateTime startDate = this.dtPerformDateFrm.Value.Value.Date.AddHours((int)this.txtStartHour.Value).AddMinutes((int)txtStartMinute.Value);
            DateTime endDate = this.dtPerformDateTo.Value.Value.Date.AddHours((int)this.txtEndHour.Value).AddMinutes((int)txtEndMinute.Value);
            ApplyService applySer = new ApplyService();
            UserService userSer = new UserService();
            M_User mUser = userSer.GetByUserCD(this.txtEmployeeCD.Value);
            if (mUser != null)
            {
                if (applySer.IsDuplicateTimeApply(applyId, mUser.ID, startDate, endDate))
                {
                    this.SetMessage(this.dtPerformDateFrm.ID, M_Message.MSG_DUPLICATE, "Regist Time");
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }
        }

        /// <summary>
        /// RestoreListApprove
        /// </summary>
        private void RestoreListApprove()
        {
            this.colorStatus = base.GetStatusColorLabel(this.ApproveStatus, ref this.statusNameLbl);
            this.rptApproverList.DataSource = this.ApproverList;
          //  this.isHasData = this.rptApproverList.DataSource != null;
        }

        #endregion

        /// <summary>
        /// Set ApplyType Is Penalized
        /// </summary>
        /// <param name="typeID"></param>
        private void SetApplyTypePenalized(int typeID)
        {
            using (DB db = new DB())
            {
                FormTypeService typeSer = new FormTypeService();
                M_Form_Type typeApp = typeSer.GetByID(typeID);
                if (typeApp != null)
                {
                    if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                    {
                        this.IsPenalized = typeApp.TimeOfRule == (int)TimeOfRuleLeave.TruPhep;
                    }
                }
            }
        }
        #endregion
                
        #endregion
  
        #region Web method
        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string in1)
        {
            var employeeCd = in1;
            var employeeCdShow = in1;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    FormLinkService frmLinkSer = new FormLinkService(db);
                    M_UserInfo model = userSer.GetUserInfo(employeeCd);

                    if (model != null)
                    {                      
                        var result = new
                        {
                            employeeCD = employeeCdShow,
                            employeeNm = model.UserName1,
                            department = model.DepartmentName,
                            position = model.Position2

                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var employee = new
                    {
                        employeeCD = employeeCdShow
                    };

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// GetApplyType penalized(Tru phep)
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetApplyTypePenalized(string typeID)
        {
            try
            {
                using (DB db = new DB())
                {
                    FormTypeService typeSer = new FormTypeService();
                    M_Form_Type typeApp = typeSer.GetByID(int.Parse(typeID));
                    if (typeApp != null)
                    {
                        if (typeApp.FormID == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                        {
                            return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(typeApp.TimeOfRule == (int)TimeOfRuleLeave.TruPhep ? "1" : "0");
                        }
                        else
                        {
                            return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>("0");
                        }
                    }
                }
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1">Start Date</param>
        /// <param name="in2">Start Hour</param>
        /// <param name="in3">Start Minute</param>
        /// <param name="in4">End Date</param>
        /// <param name="in5">End Hour</param>
        /// <param name="in6">End Minute</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalDuration(string startDate, string startHour, string startMinute, string endDate, string endHour, string endMinute, int templateForm)
        {
            try
            {
                if (string.IsNullOrEmpty(startDate) || string.IsNullOrEmpty(startHour) || string.IsNullOrEmpty(startMinute)
                    || string.IsNullOrEmpty(endDate) || string.IsNullOrEmpty(endHour) || string.IsNullOrEmpty(endMinute))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>("0");
                }

                DateTime sDate = DateTime.ParseExact(startDate, Constants.FMT_DATE, CultureInfo.InvariantCulture);
                DateTime eDate = DateTime.ParseExact(endDate, Constants.FMT_DATE, CultureInfo.InvariantCulture);
                decimal ret = 0;
                var format = string.Empty;
                if (templateForm == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE)
                {
                    format = string.Format("N{0}", 1);
                    HolidayService hSer = new HolidayService();
                    int loop = 0;
                    while (sDate <= eDate)
                    {
                        DateTime frmDate = sDate;
                        DateTime toDate = sDate;
                        if (frmDate.DayOfWeek == DayOfWeek.Saturday || frmDate.DayOfWeek == DayOfWeek.Sunday || hSer.GetByDay(sDate) != null)
                        {
                            sDate = sDate.AddDays(1);
                            loop++;
                            continue;
                        }
                        if (loop == 0)
                        {
                            frmDate = sDate.AddHours(int.Parse(startHour)).AddMinutes(int.Parse(startMinute));
                        }
                        else
                        {
                            frmDate = sDate.AddHours(8);
                        }

                        if (sDate == eDate)
                        {
                            toDate = eDate.AddHours(int.Parse(endHour)).AddMinutes(int.Parse(endMinute));
                        }
                        else
                        {
                            toDate = eDate.AddHours(17).AddMinutes(30);
                        }
                        if (frmDate < toDate)
                        {
                            TimeSpan temp = toDate.Subtract(frmDate);
                            if (temp.Hours >= 9 && temp.Minutes >= 30)
                            {
                                ret += 1;
                            }
                            else
                            {
                                ret += (decimal)0.5;
                            }
                        }

                        sDate = sDate.AddDays(1);
                        loop++;
                    }
                }
                else
                {
                    format = string.Format("N{0}", 2);
                    sDate = sDate.AddHours(int.Parse(startHour)).AddMinutes(int.Parse(startMinute));
                    eDate = eDate.AddHours(int.Parse(endHour)).AddMinutes(int.Parse(endMinute));
                    if (sDate < eDate)
                    {
                        TimeSpan temp = eDate.Subtract(sDate);
                        ret = temp.Hours + temp.Days * 24;
                        ret += (decimal)((temp.Minutes / 15) * 0.25 + (temp.Minutes % 15 > 0 ? 0.25 : 0));
                    }
                }

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(ret.ToString(format));

            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;
using DailyReport.Apply;
using DailyReport.Controls;

namespace DailyReport.Work
{
    public partial class FrmWorkLeaveDetail : FrmBaseDetail
    {
        #region Constants

        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";
        public const int DEFAULT_VALUE = -1;

        #endregion

        #region Property

        /// <summary>
        /// Get or set ApplyID
        /// </summary>
        public int ApplyID
        {
            get { return (int)ViewState["ApplyID"]; }
            set { ViewState["ApplyID"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Late Work / Early Leave";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtReason.MaxLength = T_Work_Leave.REASON_MAX_LENGTH;
            this.txtReasonCancel.MaxLength = T_Work_Leave.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);
        }

        /// <summary>
        /// Load form
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        this.ApplyStatus = (int)StatusApply.Draft;

                        //Set mode
                        this.ProcessMode(Mode.Insert);

                        this.LoadRouteFromRoute(int.Parse(this.cmbRoute.SelectedValue));
                    }
                    else
                    {
                        //Get User ID
                        this.ApplyID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_Leave data = this.GetApplyByID(this.ApplyID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);

                    this.LoadRouteFromRoute(int.Parse(this.cmbRoute.SelectedValue));
                }

                this.InitTimesDetail();
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Checked change chkisAgent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {
            if (!this.IsAgent())
            {
                this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
            }

            this.txtEmployeeCD.SetReadOnly(!this.chkIsAgent.Checked);
            if (this.chkIsAgent.Checked)
            {
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
            }
            else
            {
                this.LoadStaff(this.LoginInfo.User.ID);
            }

            this.InitTimesDetail();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.LoadRouteFromRoute(int.Parse(this.cmbRoute.SelectedValue));
            if (!this.PreApplyID.HasValue)
            {
                ////Check input
                if (!this.CheckInput())
                {
                    return;
                }
            }
            else
            {
                //Check input mode cancel
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// btnCopy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCoppy_Click(object sender, EventArgs e)
        {
            //Get data
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ApplyStatus = (int)StatusApply.Draft;
                this.PreApplyID = null;
                this.btnViewPreVacation.Text = string.Empty;
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);
            if (data != null)
            {
                this.ShowData(data);
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (this.PreApplyID.HasValue)
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            else
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            this.ProcessMode(Mode.Delete);
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                if (!this.PreApplyID.HasValue)
                {
                    if (!this.CheckInput(true))
                    {
                        return;
                    }
                }
                //Set Mode
                this.ProcessMode(Mode.Confirm);

                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                this.ShowData(apply);
                this.btnViewPreVacation.Text = apply.No;
                this.PreApplyID = apply.ID;
                this.ApplyStatus = (int)StatusApply.Cancel;

                this.ProcessMode(Mode.Cancel);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelApply_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                if (!CheckInputForCancel())
                {
                    return;
                }

                if (IsExistCancel())
                {
                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                }
                else
                {
                    //Show question insert
                    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, Models.DefaultButton.Yes);
                }
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Work_Leave data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                case Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get 
                        data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadRouteFromRoute(int.Parse(this.cmbRoute.SelectedValue));
                    }
                    break;

                case Mode.Delete:

                    //Delete 
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
                case Mode.Confirm:
                    //Update Data
                    ret = this.Confirm();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Cancel:
                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ProcessMode(Mode.View);
                    }
                    break;
            }
        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }

            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// cmbRoute OnSelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbRoute_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int routeID = int.Parse(this.cmbRoute.SelectedValue);
            this.LoadRouteFromRoute(routeID);
            this.SetProxyAuth();
        }

        #endregion

        #region Methods

        /// <summary>
        /// load route from table route
        /// </summary>
        /// <param name="RouteID"></param>
        private void LoadRouteFromRoute(int RouteID)
        {
            IList<WorkApproveModel> lstData = new List<WorkApproveModel>();
            using (DB db = new DB())
            {
                Route_DService routeDSer = new Route_DService(db);
                lstData = routeDSer.GetApproverListByRouteIDForWork(RouteID, true, EnumGetLevelZero.Exclude);
            }

            this.rptApproverList.DataSource = lstData;
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// GetUserInfoByID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_UserInfo GetUserInfoByID(int userID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetUserInfoByID(userID);
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.LoadRoute(this.LoginInfo.User.ID);
            this.LoadStaff(this.LoginInfo.User.ID);
            this.dtDateFrom.Value = null;
            this.dtDateTo.Value = null;
            this.dtEffect.Value = DateTime.Now;

            this.ApplyID = DEFAULT_VALUE;
            this.PreApplyID = null;
            this.btnViewPreVacation.Text = string.Empty;

            using (DB db = new DB())
            {
                DateTime effectDate = this.dtEffect.Value.Value;
                WorkShiftService wrkShiftSer = new WorkShiftService(db);
                M_Work_Shift wrkShift = wrkShiftSer.GetByDate(this.dtEffect.Value.Value);
                this.hdStartTime.Value = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0).ToString();
                this.hdEndTime.Value = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0).ToString();

                this.InitTimesHeader(db);
            }
        }

        /// <summary>
        /// Set Proxy Auth
        /// </summary>
        private void SetProxyAuth()
        {
            M_Route_D routeD = this.GetRouteLevelZeroByRouteID(int.Parse(this.cmbRoute.SelectedValue));
            if (routeD != null)
            {
                string onclick = "callSearchEmployee(" + routeD.ApplyFlag2 + "," + this.LoginInfo.Department.ID + "," + M_Config_D.TEMPLATE_FORM_LEAVE + "," + this.LoginInfo.User.ID + ")";
                this.btnSearchEmployee.Attributes.Add("onclick", onclick);
            }

            this.txtEmployeeCD.SetReadOnly(!this.chkIsAgent.Checked);
        }

        /// <summary>
        /// set data for header repeater
        /// </summary>
        private void InitTimesHeader(DB db)
        {
            AccountingService accSer = new AccountingService(db);
            this.rptLateH.DataSource = accSer.GetListMonthName();
            this.rptLateH.DataBind();
            //--------------
            this.rptEarlyH.DataSource = accSer.GetListMonthName();
            this.rptEarlyH.DataBind();
            //--------------
            this.rptOutH.DataSource = accSer.GetListMonthName();
            this.rptOutH.DataBind();
        }

        /// <summary>
        /// set data for detail repeater
        /// </summary>
        private void InitTimesDetail()
        {
            using (DB db = new DB())
            {
                //DateTime dateNow = DateTime.Now.Date;
                AccountingService accSer = new AccountingService(db);

                AccountingPeriod _acc = accSer.GetAccountingYear(DateTime.Now.Date);

                WorkLeaveService leaveSr = new WorkLeaveService(db);
                IList<WorkLeaveDay> lst = leaveSr.GetListMonthAccounting(this.txtEmployeeCD.Value, _acc.StartDate, _acc.EndDate);

                this.rptLateD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Late, lst, _acc);
                this.rptLateD.DataBind();
                //--------------
                this.rptEarlyD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Early, lst, _acc);
                this.rptEarlyD.DataBind();
                //--------------
                this.rptOutD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Out, lst, _acc);
                this.rptOutD.DataBind();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="type"></param>
        /// <param name="lstDay"></param>
        /// <param name="period"></param>
        /// <returns></returns>
        private List<string> GetListMonthValue(int type, IList<WorkLeaveDay> lstDay, AccountingPeriod period)
        {
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting m_acc = accSer.GetData();

                List<string> lstTmp = new List<string>();
                DateTime dtTmp = lstDay[0].WorkDate;
                TimeSpan timeTmp = TimeSpan.Zero;

                for (int i = 0; i < 12; i++)
                {
                    AccountingPeriod periodM = accSer.GetAccountingMonth(period.StartDate.AddMonths(i), m_acc.ClosingDay);
                    foreach (var item in lstDay.Where(m => m.WorkDate >= periodM.StartDate && m.WorkDate <= periodM.EndDate && m.Type == type))
                    {
                        timeTmp = timeTmp.Add(item.Duration);
                    }

                    if (timeTmp == TimeSpan.Zero)
                    {
                        lstTmp.Add("&nbsp;");
                    }
                    else
                    {
                        lstTmp.Add(EditDataUtil.FixTimeShow(timeTmp.Hours, timeTmp.Minutes));
                    }


                    timeTmp = TimeSpan.Zero;
                }

                return lstTmp;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        private void LoadStaff(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo m_staff = staffSer.GetStaffInfoByStaffCD(staffCD);
                if (m_staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(m_staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = m_staff.StaffName;
                    this.txtDepartment.Value = m_staff.DepartmentName;
                    this.txtPosition.Value = m_staff.Position;
                }
                else
                {
                    this.txtEmployeeCD.Value = string.Empty;
                    this.txtEmployeeNm.Value = string.Empty;
                    this.txtDepartment.Value = string.Empty;
                    this.txtPosition.Value = string.Empty;
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        private void LoadStaff(int userID)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo m_staff = staffSer.GetStaffInfoByUserID(userID);
                if (m_staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(m_staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = m_staff.StaffName;
                    this.txtDepartment.Value = m_staff.DepartmentName;
                    this.txtPosition.Value = m_staff.Position;
                }
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void LoadRoute(int userID = DEFAULT_VALUE)
        {
            using (DB db = new DB())
            {

                Route_HService routeService = new Route_HService(db);
                List<DropDownModel> rets = routeService.GetDataForDropdown(M_Config_D.TEMPLATE_FORM_LEAVE, userID).ToList();
                if (rets == null)
                {
                    rets.Insert(0, new DropDownModel("-1", "---"));
                }

                this.cmbRoute.DataSource = rets;
                this.cmbRoute.DataValueField = "Value";
                this.cmbRoute.DataTextField = "DisplayName";
                this.cmbRoute.DataBind();

                this.cmbRoute.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        private void LoadRoute(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService _StaffService = new StaffService(db);
                M_StaffInfo _staff = _StaffService.GetStaffInfoByStaffCD(staffCD);
                if (_staff != null)
                {
                    this.LoadRoute(_staff.UserID);
                }
            }
        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.InitData();

            this.chkIsAgent.Checked = false;
            this.txtReason.Value = string.Empty;
        }

        #endregion

        #region Insert data

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                if (this.IsExistCancel())
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);
                    return false;
                }

                if (this.IsDuplicateApplyTime())
                {
                    this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    return false;
                }

                //Create model
                T_Work_Leave data = this.GetDataForInsert(PreApplyID.HasValue);
                T_Work_ApplyTime wrkATime = this.GetApplyTime(data);
                //Insert
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkLeaveService service = new WorkLeaveService(db);

                    //Insert Daily
                    this.ApplyID = service.Insert(data);
                    this.ApplyStatus = data.ApplyStatus;
                    if (!this.PreApplyID.HasValue)
                    {
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        wrkAppSer.Insert(wrkATime);
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Work_Leave_PK))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "Leave");
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }


        #endregion

        #region Update data

        private T_Work_Leave GetDataForUpdate(int appID)
        {
            using (DB db = new DB())
            {
                DateTime effectDate = this.dtEffect.Value.Value;
                //--------------------
                WorkShiftService wrkShiftSer = new WorkShiftService(db);
                M_Work_Shift wrkShift = wrkShiftSer.GetByDate(this.dtEffect.Value.Value);
                DateTime startTime_S = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
                DateTime endTime_S = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);

                //-----------------
                RestTimeService restTSer = new RestTimeService(db);
                IList<RestTime> lstRestTime = restTSer.GetListByShiftID(wrkShift.ID);

                //-----------------
                AccountingService accSer = new AccountingService(db);
                M_Accounting m_acc = accSer.GetData();

                //-----------------
                T_Work_Leave item = new T_Work_Leave();
                item.ID = appID;
                item.No = this.txtApplyNo.Value;

                if (this.chkIsAgent.Checked)
                {
                    M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
                    if (s != null)
                    {
                        M_User u = this.GetUserByStaffID(s.ID);
                        if (u != null)
                        {
                            item.UserID = u.ID;
                        }
                    }
                }
                else
                {
                    item.UserID = LoginInfo.User.ID;
                }

                //-------------------
                item.EffectDate = this.dtEffect.Value.Value;

                //-------------------
                //-------------------
                TimeSpan tmp = TimeSpan.Zero;
                if (this.optEarly.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Early;
                    //-------------------
                    item.StartHour = this.GetTime(this.dtDateFrom).Hour;
                    item.StartMinute = this.GetTime(this.dtDateFrom).Minute;
                    //-------------------
                    item.EndHour = endTime_S.Hour;
                    item.EndMinute = endTime_S.Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(this.GetTime(this.dtDateFrom), endTime_S, lstRestTime), m_acc.UnitOfTime, m_acc.RoundLeave);
                }
                else if (this.optLate.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Late;
                    //-------------------
                    item.StartHour = startTime_S.Hour;
                    item.StartMinute = startTime_S.Minute;
                    //-------------------
                    item.EndHour = this.GetTime(this.dtDateTo).Hour;
                    item.EndMinute = this.GetTime(this.dtDateTo).Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(startTime_S, this.GetTime(this.dtDateTo), lstRestTime), m_acc.UnitOfTime, m_acc.RoundLate);
                }
                else if (this.optOut.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Out;
                    //-------------------
                    item.StartHour = this.GetTime(this.dtDateFrom).Hour;
                    item.StartMinute = this.GetTime(this.dtDateFrom).Minute;
                    //-------------------
                    item.EndHour = this.GetTime(this.dtDateTo).Hour;
                    item.EndMinute = this.GetTime(this.dtDateTo).Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(this.GetTime(this.dtDateFrom), this.GetTime(this.dtDateTo), lstRestTime), m_acc.UnitOfTime, m_acc.RoundOuting);
                }

                //-------------------
                item.DurationHour = tmp.Hours;
                item.DurationMinute = tmp.Minutes;

                //-------------------
                item.RouteID = int.Parse(this.cmbRoute.SelectedValue);

                //-------------------
                if (item.PreApplyID.HasValue)
                {
                    item.Reason = this.txtReasonCancel.Text;
                }
                else
                {
                    item.Reason = this.txtReason.Text;
                }

                //-------------------
                item.UpdateDate = this.OldUpdateDate;
                item.UpdateUID = this.LoginInfo.User.ID;

                return item;
            }
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Work_Leave data = this.GetDataForUpdate(this.ApplyID);
                if (data != null)
                {
                    if (this.IsDuplicateApplyTime())
                    {
                        this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                        return false;
                    }

                    T_Work_ApplyTime wrkATime = this.GetApplyTime(data);

                    //Update data
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkLeaveService service = new WorkLeaveService(db);

                        //Update
                        if (data.Status == DataStatus.Changed)
                        {
                            data.UpdateDate = this.OldUpdateDate;
                            ret = service.Update(data);
                            if (ret > 0)
                            {
                                if (!this.PreApplyID.HasValue)
                                {
                                    WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                                    ret = wrkAppSer.Update(wrkATime);
                                }

                                if (ret > 0)
                                {
                                    db.Commit();
                                }
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Confirm

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool Confirm()
        {
            bool ret = true;
            ApplyFucntion act = new ApplyFucntion(this.ApplyID, this.LoginInfo.User, ApplyType.LateEarlyOuting, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));
            switch (act.Confirm())
            {
                case ProcessResult.Success:
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Confirm");
                    ret = false;
                    break;
                case ProcessResult.MailFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    ret = false;
                    break;
                default:
                    ret = false;
                    break;
            }

            return ret;
        }


        #endregion

        #region  Delete Data

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkLeaveService service = new WorkLeaveService(db);
                    T_Work_Leave apply = new T_Work_Leave();
                    apply.StatusFlag = (int)DeleteFlag.Deleted;
                    apply.ID = this.ApplyID;
                    apply.UpdateUID = LoginInfo.User.ID;
                    apply.UpdateDate = this.OldUpdateDate;

                    //Update StatusFlag
                    ret = service.UpdateStatusFlag(apply);
                    if (ret != 0 && !this.PreApplyID.HasValue)
                    {
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        ret = wrkAppSer.Delete(this.txtApplyNo.Value);
                    }
                    if (ret != 0)
                    {
                        db.Commit();
                    }                    
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vac"></param>
        /// <returns></returns>
        private T_Work_ApplyTime GetApplyTime(T_Work_Leave vac)
        {
            using (DB db = new DB())
            {
                T_Work_ApplyTime ret = new T_Work_ApplyTime();
                ret.ApplyNo = vac.No;
                ret.UserID = vac.UserID;

                DateTime effectDate = this.dtEffect.Value.Value;
                WorkShiftService wrkShiftSer = new WorkShiftService(db);
                M_Work_Shift wrkShift = wrkShiftSer.GetByDate(effectDate);
                DateTime startTime_B = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
                DateTime endTime_B = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);

                if (this.optLate.Checked)
                {
                    ret.StartTime = startTime_B;
                    ret.EndTime = this.GetTime(this.dtDateTo);
                }
                if (this.optEarly.Checked)
                {
                    ret.StartTime = this.GetTime(this.dtDateFrom);
                    ret.EndTime = endTime_B;
                }
                if (this.optOut.Checked)
                {
                    ret.StartTime = this.GetTime(this.dtDateFrom);
                    ret.EndTime = this.GetTime(this.dtDateTo);
                }

                return ret;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appNo"></param>
        /// <returns></returns>
        private bool IsDuplicateApplyTime()
        {
            if (this.PreApplyID != null)
            {
                return false;
            }

            using (DB db = new DB())
            {
                string appNo = this.txtApplyNo.Value;
                DateTime effectDate = this.dtEffect.Value.Value;
                WorkShiftService wrkShiftSer = new WorkShiftService(db);
                M_Work_Shift wrkShift = wrkShiftSer.GetByDate(effectDate);
                DateTime startTime_B = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
                DateTime endTime_B = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);

                StaffService _staffService = new StaffService(db);
                M_StaffInfo m_staff = _staffService.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value);

                WorkApplyTimeService wrkSer = new WorkApplyTimeService(db);
                if (this.optLate.Checked)
                {
                    return wrkSer.IsDuplicateTimeApply(appNo, m_staff.UserID, startTime_B, this.GetTime(this.dtDateTo));
                }
                if (this.optEarly.Checked)
                {
                    return wrkSer.IsDuplicateTimeApply(appNo, m_staff.UserID, this.GetTime(this.dtDateFrom), endTime_B);
                }
                if (this.optOut.Checked)
                {
                    return wrkSer.IsDuplicateTimeApply(appNo, m_staff.UserID, this.GetTime(this.dtDateTo), this.GetTime(this.dtDateFrom));
                }
            }

            return false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Work_Leave GetApplyByID(int id)
        {
            using (DB db = new DB())
            {
                T_Work_Leave apply = new T_Work_Leave();
                WorkLeaveService appSer = new WorkLeaveService(db);
                apply = appSer.GetByID(id);
                return apply;
            }
        }

        /// <summary>
        /// Get list of approver
        /// </summary>
        /// <param name="TypeID"></param>
        /// <param name="isIncludeView">true: include level 99, false:exclude level 99</param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprovePerson(DB db, int routeID, bool isIncludeView = false, bool includeZeroLV = true)
        {
            //Custom again
            Route_DService service = new Route_DService(db);
            return service.GetApproverListByRouteIDForWork(routeID, isGetLVZero: includeZeroLV ? EnumGetLevelZero.Include : EnumGetLevelZero.Exclude);
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadRouteFromApprove(string vacNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);
            if (!isIncludeView)
            {
                this.rptApproverList.DataSource = applyList;
                this.rptApproverList.DataBind();
            }
            else
            {
                this.rptApproverList.DataSource = applyList;
                this.rptApproverList.DataBind();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.txtApplyNo.Value, isIncludeView, includeZeroLV);
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            this.dtDuration.SetReadOnly(true);
            this.txtPosition.SetReadOnly(true);
            this.txtEmployeeNm.SetReadOnly(true);
            this.txtCreateDate.SetReadOnly(true);
            this.txtUpdateDate.SetReadOnly(true);
            this.txtDepartment.SetReadOnly(true);
            this.txtApplyNo.SetReadOnly(true);
            this.dtApplyDate.SetReadOnly(true);

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:
                    this.ApplyStatus = (int)StatusApply.Draft;
                    this.cmbRoute.Enabled = true;
                    this.optLate.Disabled = false;
                    this.optEarly.Disabled = false;
                    this.optOut.Disabled = false;
                    this.cmbRoute.Enabled = true;
                    this.txtReason.SetReadOnly(false);
                    this.dtDateFrom.SetReadOnly(false);
                    this.dtDateTo.SetReadOnly(false);
                    this.dtEffect.SetReadOnly(false);
                    this.chkIsAgent.Enabled = true;
                    this.SetProxyAuth();
                    break;

                case Mode.Cancel:
                    this.txtApplyNo.Value = string.Empty;
                    this.dtApplyDate.Value = null;
                    this.ApplyStatus = (int)StatusApply.Cancel;

                    string onclick = "gotoApprovedForm(" + M_Config_D.TEMPLATE_FORM_LEAVE + "," + this.PreApplyID + ") ; return false;";
                    this.btnViewPreVacation.Attributes.Add("onclick", onclick);

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.chkIsAgent.Enabled = false;
                    this.dtEffect.SetReadOnly(true);
                    this.optLate.Disabled = true;
                    this.optEarly.Disabled = true;
                    this.optOut.Disabled = true;
                    this.dtDateFrom.SetReadOnly(true);
                    this.dtDateTo.SetReadOnly(true);
                    this.txtReason.SetReadOnly(true);
                    this.cmbRoute.Enabled = true;
                    break;

                case Mode.Confirm:
                case Mode.Delete:
                default:
                    this.chkIsAgent.Enabled = false;
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtReason.SetReadOnly(true);
                    this.dtDateFrom.SetReadOnly(true);
                    this.dtDateTo.SetReadOnly(true);
                    this.dtEffect.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.optLate.Disabled = true;
                    this.optEarly.Disabled = true;
                    this.optOut.Disabled = true;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);

                        onclick = "gotoApprovedForm(" + M_Config_D.TEMPLATE_FORM_LEAVE + "," + this.PreApplyID + ") ; return false;";
                        this.btnViewPreVacation.Attributes.Add("onclick", onclick);
                    }

                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.Draft:
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                            base.DisabledLink(this.btnDelete, !base._authority.IsApplyRegistDelete);
                            base.DisabledLink(this.btnConfirm, !base._authority.IsApplyRegistConfirm);
                            break;

                        case (int)StatusApply.Approving:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Approved:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Rejected:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Cancel:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, false);
                            break;
                    }

                    T_Work_Leave app = this.GetApplyByID(this.ApplyID);
                    if (app == null)
                    {
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnConfirm, true);
                    }

                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Work_Leave apply)
        {
            using (DB db = new DB())
            {
                //Show data
                if (apply != null)
                {
                    //------------------------------
                    this.ApplyID = apply.ID;
                    this.PreApplyID = apply.PreApplyID;
                    this.ApplyStatus = apply.ApplyStatus;
                    this.OldUpdateDate = apply.UpdateDate;
                    this.dtEffect.Value = apply.EffectDate;
                    //------------------------------
                    this.txtApplyNo.Value = apply.No;
                    //------------------------------
                    this.dtApplyDate.Value = apply.ApplyDate;
                    //------------------------------

                    StaffService _staffService = new StaffService(db);
                    M_StaffInfo m_staff = _staffService.GetStaffInfoByUserID(apply.UserID);
                    if (m_staff != null)
                    {
                        this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(m_staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                        this.txtEmployeeNm.Value = m_staff.StaffName;

                        this.txtDepartment.Value = m_staff.DepartmentName;
                        this.txtPosition.Value = m_staff.Position;
                    }

                    //------------------------------      
                    if (apply.UserID.Equals(this.LoginInfo.User.ID))
                    {
                        this.chkIsAgent.Checked = false;
                    }
                    else
                    {
                        this.chkIsAgent.Checked = !apply.UserID.Equals(apply.CreateUID);
                    }
                    //------------------------------              
                    this.dtDateFrom.SetTimeValue(apply.StartHour, apply.StartMinute);
                    this.dtDateTo.SetTimeValue(apply.EndHour, apply.EndMinute);
                    //------------------------------
                    if (apply.Type == (int)TypeWorkLeave.Late)
                    {
                        this.optLate.Checked = true;
                    }
                    //-------------------
                    if (apply.Type == (int)TypeWorkLeave.Early)
                    {
                        this.optEarly.Checked = true;
                    }
                    //-------------------
                    if (apply.Type == (int)TypeWorkLeave.Out)
                    {
                        this.optOut.Checked = true;
                    }
                    //------------------------------
                    this.dtDuration.Text = EditDataUtil.FixTimeShow(apply.DurationHour, apply.DurationMinute, true);
                    //------------------------------
                    WorkLeaveService ser = new WorkLeaveService(db);
                    if (this.PreApplyID.HasValue)
                    {
                        T_Work_Leave preApp = ser.GetByID(this.PreApplyID.Value);
                        if (preApp != null)
                        {
                            this.txtReason.Value = preApp.Reason;
                            this.txtReasonCancel.Value = apply.Reason;
                            this.btnViewPreVacation.Text = preApp.No;
                            this.PreApplyID = preApp.ID;
                        }
                    }
                    else
                    {
                        this.txtReason.Value = apply.Reason;
                    }
                    //------------------------------
                    this.cmbRoute.SelectedValue = apply.RouteID.ToString();

                    //------------------------------
                    UserService userSer = new UserService(db);
                    M_User createUser = userSer.GetByID(apply.CreateUID);
                    M_User updateUser = userSer.GetByID(apply.UpdateUID);
                    if (createUser != null)
                    {
                        var createDate = apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        var updateDate = apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                        this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                    }

                    //------------------------------
                    if (apply.ApplyStatus == (int)StatusApply.Draft || apply.ApplyStatus == (int)StatusApply.Cancel)//chua confirm
                    {
                        this.LoadRouteFromRoute(apply.RouteID);
                    }
                    else
                    {
                        this.LoadRouteFromApprove(this.txtApplyNo.Value, true);
                    }
                }
            }
        }

        /// <summary>
        /// Create Apply data
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private T_Work_Leave GetDataForInsert(bool isCancel = false)
        {
            using (DB db = new DB())
            {
                DateTime effectDate = this.dtEffect.Value.Value;
                //--------------------
                WorkShiftService wrkShiftSer = new WorkShiftService(db);
                M_Work_Shift wrkShift = wrkShiftSer.GetByDate(this.dtEffect.Value.Value);
                DateTime startTime_S = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0);
                DateTime endTime_S = new DateTime(effectDate.Year, effectDate.Month, effectDate.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);

                //-----------------
                RestTimeService restTSer = new RestTimeService(db);
                IList<RestTime> lstRestTime = restTSer.GetListByShiftID(wrkShift.ID);

                //-----------------
                AccountingService accSer = new AccountingService(db);
                M_Accounting m_acc = accSer.GetData();

                //-----------------
                T_Work_Leave item = new T_Work_Leave();

                item.ApplyDate = null;

                TNoService noService = new TNoService(db);
                item.No = noService.CreateNo(T_No.No);
                item.ApplyStatus = (int)StatusApply.Draft;

                //-----------------
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    item.PreApplyID = null;
                }
                else if (this.Mode == Mode.Cancel)
                {
                    item.PreApplyID = this.PreApplyID;
                }

                //-----------------
                if (this.chkIsAgent.Checked)
                {
                    M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
                    if (s != null)
                    {
                        M_User u = this.GetUserByStaffID(s.ID);
                        if (u != null)
                        {
                            item.UserID = u.ID;
                        }
                    }
                }
                else
                {
                    item.UserID = LoginInfo.User.ID;
                }
                //-------------------
                item.EffectDate = this.dtEffect.Value.Value;
                //-------------------
                TimeSpan tmp = TimeSpan.Zero;
                if (this.optEarly.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Early;
                    //-------------------
                    item.StartHour = this.GetTime(this.dtDateFrom).Hour;
                    item.StartMinute = this.GetTime(this.dtDateFrom).Minute;
                    //-------------------
                    item.EndHour = endTime_S.Hour;
                    item.EndMinute = endTime_S.Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(this.GetTime(this.dtDateFrom), endTime_S, lstRestTime), m_acc.UnitOfTime, m_acc.RoundLeave);
                }
                else if (this.optLate.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Late;
                    //-------------------
                    item.StartHour = startTime_S.Hour;
                    item.StartMinute = startTime_S.Minute;
                    //-------------------
                    item.EndHour = this.GetTime(this.dtDateTo).Hour;
                    item.EndMinute = this.GetTime(this.dtDateTo).Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(startTime_S, this.GetTime(this.dtDateTo), lstRestTime), m_acc.UnitOfTime, m_acc.RoundLate);
                }
                else if (this.optOut.Checked)
                {
                    item.Type = (int)TypeWorkLeave.Out;
                    //-------------------
                    item.StartHour = this.GetTime(this.dtDateFrom).Hour;
                    item.StartMinute = this.GetTime(this.dtDateFrom).Minute;
                    //-------------------
                    item.EndHour = this.GetTime(this.dtDateTo).Hour;
                    item.EndMinute = this.GetTime(this.dtDateTo).Minute;
                    //-------------------
                    tmp = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(this.GetTime(this.dtDateFrom), this.GetTime(this.dtDateTo), lstRestTime), m_acc.UnitOfTime, m_acc.RoundOuting);
                }

                //-------------------
                item.DurationHour = tmp.Hours;
                item.DurationMinute = tmp.Minutes;

                //-------------------
                item.RouteID = int.Parse(this.cmbRoute.SelectedValue);

                //-------------------
                if (isCancel)
                {
                    item.Reason = this.txtReasonCancel.Text;
                }
                else
                {
                    item.Reason = this.txtReason.Text;
                }

                //-------------------
                item.CreateUID = base.LoginInfo.User.ID;
                item.UpdateUID = base.LoginInfo.User.ID;
                return item;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_Route_H GetRouteByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo staff = staffSer.GetStaffInfoByStaffCD(staffCD);
                if (staff != null)
                {
                    Route_HService service = new Route_HService(db);
                    return service.GetByTypeAndUserIDForWork(M_Config_D.TEMPLATE_FORM_LEAVE, staff.UserID);
                }

                return null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="iDateTextBox"></param>
        /// <returns></returns>
        private DateTime GetTime(IDateTextBox iDateTextBox)
        {
            return new DateTime(this.dtEffect.Value.Value.Year, this.dtEffect.Value.Value.Month, this.dtEffect.Value.Value.Day, iDateTextBox.Value.Value.Hour, iDateTextBox.Value.Value.Minute, iDateTextBox.Value.Value.Second);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool IsExistCancel()
        {
            using (DB db = new DB())
            {
                WorkLeaveService appSer = new WorkLeaveService(db);

                if (ViewState["ApplyID"] != null)
                {
                    T_Work_Leave app = appSer.GetByPreApplyID(this.ApplyID);
                    if (app != null)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// check exists total work
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="effectDateFrm"></param>
        /// <param name="effectDateTo"></param>
        /// <returns></returns>
        public bool IsExistsTotalWork()
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());

                WorkTotalService totalSer = new WorkTotalService(db);
                IList<T_Work_Total> totalList = totalSer.GetByCond(s.UserID, this.dtEffect.Value.Value, this.dtEffect.Value.Value);
                return totalList != null && totalList.Count > 0;
            }
        }

        /// <summary>
        /// check proxy route
        /// </summary>
        /// <returns></returns>
        public bool IsAgent()
        {
            if (this.chkIsAgent.Checked)//dang xin gium ngkhac
            {
                int routeID = int.Parse(this.cmbRoute.SelectedValue);
                M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
                if (routeD != null)
                {
                    // proxy all
                    if (routeD.ApplyFlag1 != 1 && routeD.ApplyFlag2 != 1)
                    {
                        return false;
                    }

                    // proxy dept
                    if (routeD.ApplyFlag2 == 1)
                    {
                        using (DB db = new DB())
                        {
                            StaffService staffSer = new StaffService(db);
                            M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                            if (s != null)
                            {
                                if (s.DepartmentID != this.LoginInfo.Department.ID)
                                {
                                    return false;
                                }
                            }
                        }
                    }
                }
                else//ko co quyen xin gium ngkhac
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Check inputing
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(bool isConfirm = false)
        {
            #region Check Require

            if (!isConfirm)
            {
                //Employee Code
                if (this.chkIsAgent.Checked)
                {
                    if (this.txtEmployeeCD.IsEmpty)
                    {
                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_REQUIRE, "Applicant");
                    }
                    else
                    {
                        M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
                        if (s == null)
                        {
                            this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Applicant");
                        }
                    }
                }

                if (!this.dtEffect.Value.HasValue)
                {
                    this.SetMessage(this.dtEffect.ID, M_Message.MSG_REQUIRE, "Effect Date");
                }

                // Late
                if (this.optLate.Checked)
                {
                    if (!this.dtDateTo.Value.HasValue)
                    {
                        this.SetMessage(this.dtDateTo.ID, M_Message.MSG_REQUIRE, "Time To");
                    }
                    else
                    {
                        if (TimeSpan.Compare(DateTime.Parse(this.hdStartTime.Value).TimeOfDay, this.dtDateTo.Value.Value.TimeOfDay) >= 0)
                        {
                            this.SetMessage(this.dtDateTo.ID, M_Message.MSG_LESS_THAN, "Time From", "Time To");
                        }
                        else
                        {
                            if (TimeSpan.Compare(this.dtDateTo.Value.Value.TimeOfDay, DateTime.Parse(this.hdEndTime.Value).TimeOfDay) >= 0)
                            {
                                this.SetMessage(this.dtDateTo.ID, M_Message.MSG_DATA_INVALID, "Time");
                            }
                        }
                    }
                }

                // Early
                if (this.optEarly.Checked)
                {
                    if (!this.dtDateFrom.Value.HasValue)
                    {
                        this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_REQUIRE, "Time From");
                    }
                    else
                    {
                        if (TimeSpan.Compare(this.dtDateFrom.Value.Value.TimeOfDay, DateTime.Parse(this.hdEndTime.Value).TimeOfDay) >= 0)
                        {
                            this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_LESS_THAN, "Time From", "Time To");
                        }
                        else
                        {
                            if (TimeSpan.Compare(this.dtDateFrom.Value.Value.TimeOfDay, DateTime.Parse(this.hdStartTime.Value).TimeOfDay) <= 0)
                            {
                                this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_DATA_INVALID, "Time");
                            }

                        }
                    }
                }

                // Out
                if (this.optOut.Checked)
                {
                    if (!this.dtDateFrom.Value.HasValue)
                    {
                        this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_REQUIRE, "Time From");
                    }

                    if (!this.dtDateTo.Value.HasValue)
                    {
                        this.SetMessage(this.dtDateTo.ID, M_Message.MSG_REQUIRE, "Time To");
                    }

                    if (this.dtDateFrom.Value.HasValue && this.dtDateTo.Value.HasValue)
                    {
                        if (TimeSpan.Compare(this.dtDateFrom.Value.Value.TimeOfDay, this.dtDateTo.Value.Value.TimeOfDay) >= 0)
                        {
                            this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_LESS_THAN, "Time From", "Time To");
                        }
                    }
                }

                //Reason
                if (this.txtReason.IsEmpty)
                {
                    this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Apply Reason");
                }

                //Reason cancel
                if (this.PreApplyID.HasValue)
                {
                    if (this.txtReasonCancel.IsEmpty)
                    {
                        this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Cancel Reason");
                    }
                }
            }

            #endregion

            #region Check Data

            if (!base.HaveError)
            {
                //-------------------------------------
                if (!this.IsAgent())
                {
                    this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                }
                else
                {
                    //-------------------------------------
                    M_Route_H route_staff = this.GetRouteByStaffCD(this.txtEmployeeCD.Value);
                    if (route_staff != null)
                    {
                        M_Route_H route_login = new M_Route_H();

                        using (DB db = new DB())
                        {
                            Route_HService service = new Route_HService(db);
                            route_login = service.GetByTypeAndUserIDForWork(M_Config_D.TEMPLATE_FORM_LEAVE, this.LoginInfo.User.ID);
                        }

                        if (route_staff.ID != route_login.ID)
                        {
                            this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_DATA_INVALID, "Applicant");
                        }
                    }
                    else
                    {
                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_DATA_INVALID, "Applicant");
                    }

                    //-------------------------------------
                    decimal days = this.GetUsesDays(this.dtEffect.Value.Value, this.dtEffect.Value.Value);
                    if (days == decimal.Zero)
                    {
                        this.SetMessage(this.dtEffect.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS, "");
                    }

                    //-------------------------------------
                    if (string.IsNullOrEmpty(this.dtDuration.Text))
                    {
                        if (this.optLate.Checked)
                        {
                            this.SetMessage(this.dtDateTo.ID, M_Message.MSG_DATA_INVALID, "Time");
                        }
                        if (this.optEarly.Checked || this.optOut.Checked)
                        {
                            this.SetMessage(this.dtDateFrom.ID, M_Message.MSG_DATA_INVALID, "Time");
                        }
                    }
                    //-------------------------------------
                    if (this.IsExistsTotalWork())
                    {
                        //this.SetMessage(isConfirm ? string.Empty : this.dtEffect.ID, M_Message.MSG_DATA_INVALID, "Effect Date");
                        this.SetMessage(this.dtEffect.ID, M_Message.MSG_CANT_CONTINUE, this.dtEffect.Value.Value.ToString(Constants.FMT_DATE));
                    }
                    //-------------------------------------
                    if (this.IsDuplicateApplyTime())
                    {
                        this.SetMessage(this.dtEffect.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    }
                }
            }

            #endregion

            return !base.HaveError;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        private decimal GetUsesDays(DateTime startDate, DateTime endDate)
        {
            using (DB db = new DB())
            {
                WorkVacationService ser = new WorkVacationService(db);
                return ser.GetNumberOfDaysByRangeDate(startDate, endDate);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="RouteID"></param>
        /// <returns></returns>
        private M_Route_D GetRouteLevelZeroByRouteID(int RouteID)
        {
            using (DB db = new DB())
            {
                Route_DService routeSer = new Route_DService(db);
                var lstItem = routeSer.GetByRouteIDForWork(RouteID, isGetLVZero: EnumGetLevelZero.Only);
                if (lstItem != null && lstItem.Count > 0)
                {
                    return lstItem[0];
                }
            }
            return null;
        }

        /// <summary>
        /// Check inputing for cancel mode
        /// </summary>
        /// <returns></returns>
        private bool CheckInputForCancel()
        {
            //Reason cancel

            if (this.txtReasonCancel.IsEmpty)
            {
                this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Cancel Reason");
            }

            if (this.IsExistsTotalWork())
            {
                this.SetMessage(this.dtEffect.ID, M_Message.MSG_CANT_CONTINUE, this.dtEffect.Value.Value.ToString(Constants.FMT_DATE));
            }

            return !base.HaveError;
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }
        }

        /// <summary>
        /// GetUserByStaffID
        /// </summary>
        /// <param name="staffID"></param>
        /// <returns></returns>
        private M_User GetUserByStaffID(int staffID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByStaffID(staffID);
            }
        }

        /// <summary>
        /// ISV-TRUC
        /// GetStaffByCD
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_Staff GetStaffByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService service = new StaffService(db);
                return service.GetByStaffCD(staffCD);
            }
        }


        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        #endregion

        #region Web method

        [System.Web.Services.WebMethod]
        public static string GetDurationTime(string effectDate, string startTime, string endTime)
        {
            try
            {
                DateTime tmp = DateTime.ParseExact(effectDate, "dd/MM/yyyy", new CultureInfo("en-US"), DateTimeStyles.None);
                M_Work_Shift wrkShift = new M_Work_Shift();
                IList<RestTime> lstRestTime = new List<RestTime>();
                M_Accounting m_acc = new M_Accounting();
                using (DB db = new DB())
                {
                    WorkShiftService wrkShiftSer = new WorkShiftService(db);
                    RestTimeService restTSer = new RestTimeService(db);
                    AccountingService accSer = new AccountingService(db);
                    wrkShift = wrkShiftSer.GetByDate(tmp);
                    lstRestTime = restTSer.GetListByShiftID(wrkShift.ID);
                    m_acc = accSer.GetData();
                }

                DateTime _startTime = DateTime.Parse(startTime);
                DateTime _endTime = DateTime.Parse(endTime);
                //-----------------

                TimeSpan _time = EditDataUtil.RoundTime(CommonService.CalDurationWorkTime(_startTime, _endTime, lstRestTime), m_acc.UnitOfTime, m_acc.RoundLeave);

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(EditDataUtil.FixTimeShow(_time.Hours, _time.Minutes, true));

            }
            catch (Exception)
            {
                return null;
            }
        }

        [System.Web.Services.WebMethod]
        public static string GetShiftTime(string effectDate)
        {
            try
            {
                DateTime tmp = DateTime.ParseExact(effectDate, "dd/MM/yyyy", new CultureInfo("en-US"), DateTimeStyles.None);
                M_Work_Shift wrkShift = new M_Work_Shift();
                using (DB db = new DB())
                {
                    WorkShiftService wrkShiftSer = new WorkShiftService(db);
                    wrkShift = wrkShiftSer.GetByDate(tmp);
                }

                if (wrkShift.StartHour == null || wrkShift.StartMinute == null)
                {
                    return null;
                }
                else
                {
                    var result = new
                    {
                        startTime = new DateTime(tmp.Year, tmp.Month, tmp.Day, wrkShift.StartHour.Value, wrkShift.StartMinute.Value, 0).ToString(),
                        endTime = new DateTime(tmp.Year, tmp.Month, tmp.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0).ToString()
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception)
            {

                return null;
            }
        }

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string employeeCD, string loginUserCD)
        {
            var employeeCd = employeeCD;
            var employeeCdShow = employeeCD;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    StaffService serv = new StaffService(db);
                    M_Staff model = serv.GetByStaffCD(employeeCd);
                    if (model != null)
                    {
                        UserService userSer = new UserService(db);
                        M_UserInfo u = userSer.GetUserInfoByStaffID(model.ID);
                        if (u != null)
                        {
                            Route_HService routeSer = new Route_HService(db);
                            IList<M_Route_H> lstRet = routeSer.GetListRouteBy2UserCD(M_Config_D.TEMPLATE_FORM_LEAVE, u.UserCD, loginUserCD);
                            if (lstRet != null && lstRet.Count > 0)
                            {
                                DepartmentService deptSer = new DepartmentService(db);
                                M_Department dept = deptSer.GetByID(model.DepartmentID);
                                Config_DService confSer = new Config_DService(db);
                                string pos = confSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, model.Position);
                                var result = new
                                {
                                    employeeCD = employeeCdShow,
                                    employeeNm = model.StaffName,
                                    department = dept != null ? dept.DepartmentName : string.Empty,
                                    position = pos

                                };
                                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                            }
                        }
                    }
                }

                var employee = new
                {
                    employeeCD = employeeCdShow,
                    employeeNm = string.Empty,
                    department = string.Empty,
                    position = string.Empty
                };

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
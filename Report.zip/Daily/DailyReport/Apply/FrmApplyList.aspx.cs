﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.ApplyRegister
{
    /// <summary>
    /// FrmApplyRegisterList
    /// VN-Nho 2015.06.10
    /// </summary>
    public partial class FrmApplyList : FrmBaseList
    {
        #region Constant

        /// <summary>
        /// Danger text
        /// </summary>
        private const string CONST_WARNING_TEXT = "Cancellation";
        private const string DEFAULT_SORT_FIELD = "7"/*"8"*/;
        private const string DEFAULT_SORT_DIREC = "2";
        #endregion Constant

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        public Hashtable TypeApplication
        {
            get { return (Hashtable)ViewState["TypeApplication"]; }
            set { ViewState["TypeApplication"] = value; }
        }

        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Application List";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;

            this.txtApplyNo.MaxLength = T_Work.APPLY_NO_MAX_LENGHT;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];
                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = DEFAULT_SORT_DIREC;
            this.HeaderGrid.SortField = DEFAULT_SORT_FIELD;

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["ApplyID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event Select
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSelect_Click(object sender, CommandEventArgs e)
        {
            this.SaveCondition();            
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtApplyNo.ID, this.txtApplyNo.Value);
            hash.Add(this.dtApplyDateFrom.ID, this.dtApplyDateFrom.Value);
            hash.Add(this.dtApplyDateTo.ID, this.dtApplyDateTo.Value);
            hash.Add(this.dtEffectDateFrom.ID, this.dtEffectDateFrom.Value);
            hash.Add(this.dtEffectDateTo.ID, this.dtEffectDateTo.Value);
            hash.Add(this.cmbApplyType.ID, this.cmbApplyType.SelectedValue);
            hash.Add(this.cmbApplyStatus.ID, this.cmbApplyStatus.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtApplyNo.Value = data[this.txtApplyNo.ID].ToString();


            this.dtApplyDateFrom.Value = null;
            if (data[this.dtApplyDateFrom.ID] != null)
            {
               this.dtApplyDateFrom.Value = (DateTime)data[this.dtApplyDateFrom.ID];
            }

            this.dtApplyDateTo.Value = null;
            if (data[this.dtApplyDateTo.ID] != null)
            {
                this.dtApplyDateTo.Value = (DateTime)data[this.dtApplyDateTo.ID];
            }

            this.dtEffectDateFrom.Value = null;
            if (data[this.dtEffectDateFrom.ID] != null)
            {
                this.dtEffectDateFrom.Value = (DateTime)data[this.dtEffectDateFrom.ID];
            }

            this.dtEffectDateTo.Value = null;
            if (data[this.dtEffectDateTo.ID] != null)
            {
                this.dtEffectDateTo.Value = (DateTime)data[this.dtEffectDateTo.ID];
            }

            this.cmbApplyType.SelectedValue = data[this.cmbApplyType.ID].ToString();
            this.cmbApplyStatus.SelectedValue = data[this.cmbApplyStatus.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// GetDataForMenuFromConfig
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private Hashtable GetDataForMenuFromConfig(string configCD)
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            Hashtable hash = new Hashtable();
            using (DB db = new DB())
            {
                Config_HService conDSer = new Config_HService(db);
                lstData = conDSer.GetDataForDropDownList(configCD);
            }

            if (lstData != null && lstData.Count != 0)
            {
                foreach (var item in lstData)
                {
                    if (!hash.ContainsKey(item.Value))
                    {
                        hash.Add(item.Value, item.DisplayName);
                    }
                }
            }
            return hash;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init data for Type of application
            this.TypeApplication = this.GetDataForMenuFromConfig(M_Config_H.CONFIG_CD_TEMPLATE_TYPE);
            
            //Init default value of Apply Date
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            AccountingPeriod accPeriod = new AccountingPeriod();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                accPeriod = accSer.GetAccountingMonth(DateTime.Now);
            }

            this.dtApplyDateFrom.Value = null;
            this.dtApplyDateTo.Value = null;

            this.dtEffectDateFrom.Value = accPeriod.StartDate;
            this.dtEffectDateTo.Value = null;

            this.hdEffectDateFrmDefault.Value = accPeriod.StartDate.ToString(Constants.FMT_DATE);
            this.hdEffectDateToDefault.Value = null;

            //Status
            this.InitApplyTypeCmb(this.cmbApplyType, M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
            this.InitApplyStatusCmb(this.cmbApplyStatus, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);

            // header grid
            this.HeaderGrid.SortDirec = DEFAULT_SORT_DIREC;
            this.HeaderGrid.SortField = DEFAULT_SORT_FIELD;

            base.DisabledLink(this.btnVacationSelect, !this.EnableNewBtn(M_Config_D.TEMPLATE_FORM_APPLY_VACTION));
            base.DisabledLink(this.btnOverTimeSelect, !this.EnableNewBtn( M_Config_D.TEMPLATE_FORM_APPLY_OT));
            base.DisabledLink(this.btnLeaveSelect, !this.EnableNewBtn( M_Config_D.TEMPLATE_FORM_LEAVE));
            base.DisabledLink(this.btnAbsenceSelect, !this.EnableNewBtn( M_Config_D.TEMPLATE_FORM_ABSENCE));
        }

        /// <summary>
        /// Enable new button by form id
        /// </summary>
        /// <param name="formId"></param>
        /// <returns></returns>
        private bool EnableNewBtn(int formId)
        {
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                FormLinkService linkSer = new FormLinkService(db);
                M_Form_Link link = linkSer.GetByKey(formId, this.LoginInfo.User.ID);

                return link != null;
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitApplyTypeCmb(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitApplyStatusCmb(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }


        /// <summary>
        /// Get data for DropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }

            int totalRow = 0;
            DateTime? applyDateFrom = this.dtApplyDateFrom.Value;
            DateTime? applyDateTo = this.dtApplyDateTo.Value;
            DateTime effectDateFrom = this.dtEffectDateFrom.IsEmpty? new DateTime(1900, 1, 1):this.dtEffectDateFrom.Value.Value;
            DateTime effectDateTo = this.dtEffectDateTo.IsEmpty? new DateTime(9999, 12, 31): this.dtEffectDateTo.Value.Value;

            IList<ApplyRegisterInfo> lstData;

            //Get data
            using (DB db = new DB())
            {
                WorkService workSer = new WorkService(db);
                totalRow = workSer.GetCountApplyRegisterList(this.LoginInfo.User.ID, this.txtApplyNo.Value, applyDateFrom, applyDateTo, effectDateFrom, effectDateTo, int.Parse(this.cmbApplyType.SelectedValue), int.Parse(this.cmbApplyStatus.SelectedValue));

                lstData = workSer.GetApplyRegisterListByCond(this.LoginInfo.User.ID, this.txtApplyNo.Value, applyDateFrom, applyDateTo, effectDateFrom, effectDateTo, int.Parse(this.cmbApplyType.SelectedValue), int.Parse(this.cmbApplyStatus.SelectedValue),
                                                         pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (lstData.Count == 0)
            {
                this.rptResult.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstData[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstData[lstData.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Status", "App. No.", "Employee", "App. Type", "Effect Date", "Apply Date" });

                // detail
                this.rptResult.DataSource = lstData;
            }

            this.rptResult.DataBind();
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Apply Date
            if (this.dtApplyDateFrom.Value != null && this.dtApplyDateTo.Value != null)
            {
                if (this.dtApplyDateFrom.Value.Value.Date > this.dtApplyDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtApplyDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Apply Date From", "Apply Date To");
                }
            }
            //Effect Date
            if (this.dtEffectDateFrom.Value != null && this.dtEffectDateTo.Value != null)
            {
                if (this.dtEffectDateFrom.Value.Value.Date > this.dtEffectDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtEffectDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Effect Date From", "Effect Date To");
                }
            }
            //Has errors
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptResult.DataSource = null;
                this.rptResult.DataBind();
                return true;
            }
            return false;
        }
        
        #endregion Method

        #region Web Method

        #endregion
    }
}
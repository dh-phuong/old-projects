﻿using System;
using System.Collections;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Apply
{
    /// <summary>
    /// FrmApplyDetail
    /// ISV-TRAM 2015/03/20
    /// </summary>
    public partial class FrmApplyDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";
        #endregion

        #region Variable
            /// <summary>
            /// 2015/03/19
            /// color Status
            /// </summary>
            public string colorStatus;

            /// <summary>
            /// 2015/03/19
            /// name of Status
            /// </summary>
            public string statusNameLbl;
            
            public bool isApproveUser;
            
            /// <summary>
            /// isApproved
            /// </summary>
            public bool isApproved;

            public bool isDisablePrevBack;
            public bool isShowPrevBack;
            
            public bool isHasData;

        #endregion

        #region Property

        /// <summary>
        /// Get or set DailyID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }
        
        #endregion
        
        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Apply Detail";
            base.FormSubTitle = "Detail";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtReason.MaxLength = T_Apply.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!this.IsPostBack)
            {
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["DataID"] == null)
                    {
                        this.ApplyStatus = (int)StatusApply.New;

                        //Init data
                        this.InitData();

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["DataID"].ToString());
                        T_Apply data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    //this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {
            
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            if (this.chkIsAgent.Checked)
            {
                this.txtEmployeeCD.ReadOnly = false;
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.hdnDepartmentID.Value = LoginInfo.User.DepartmentID.ToString();
               
            }
            else
            {
                this.txtEmployeeCD.ReadOnly = true;
                this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                this.txtEmployeeNm.Value = LoginInfo.User.UserName1;
                using (DB db = new DB())
                {
                    DepartmentService deptSer = new DepartmentService(db);
                    M_Department dept = deptSer.GetByID(LoginInfo.User.DepartmentID);
                    this.txtDepartment.Value = dept.DepartmentName;
                }
                this.txtPosition.Value = LoginInfo.User.Position;
            }

            this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbApplyType_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            this.GetDefaultDataForCbo(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
            this.SetPerformDateTo();
            this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue.ToString()));

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txtEmployeeCD_OnTextChanged(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
        }

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //protected void dtPerformDateFrm_OnTextChanged(object sender, EventArgs e)
        //{
        //    this.SetPerformDateTo();
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUser_Click(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            ////Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Init data
            this.InitData();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Checking LoginUser is the approver
        /// </summary>
        /// <param name="applyApproveListInfo"></param>
        /// <returns></returns>
        private bool IsApprover(IList<ApplyApproveListInfo> applyApproveListInfo)
        {
            ApplyApproveListInfo approveInfo = new ApplyApproveListInfo();
            approveInfo = (from app in applyApproveListInfo
                           where LoginInfo.User.ID.Equals(app.RouteUID)
                           select app).FirstOrDefault();

            return approveInfo != null ? true : false;

            //if (this.ApplyStatus == (int)StatusApply.Confirm || this.ApplyStatus == (int)StatusApply.Approve || this.ApplyStatus == (int)StatusApply.Ignore || this.ApplyStatus == (int)StatusApply.BackPrev)
            //{
            //    return approveInfo != null ? true : false;
            //}
            //else
            //{
            //    return false;
            //}
        }

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyApproveListInfo"></param>
        /// <returns></returns>
        private bool IsApproved(IList<ApplyApproveListInfo> applyApproveListInfo)
        {
            string loginUserCD =Utilities.EditDataUtil.ToFixCodeShow( LoginInfo.User.UserCD,M_User.MAX_USER_CODE_SHOW);
            IList<ApplyApproveListInfo> approveList = new List<ApplyApproveListInfo>();
            approveList = (from app in applyApproveListInfo
                           where (app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.Ignore || app.ApproveStatus == (short)StatusHasAprove.BackPrev)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return  true;

            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Checking approve status for previous level of loginuser level
        /// </summary>
        /// <param name="applyApproveListInfo"></param>
        /// <returns></returns>
        private bool IsNotApprovedInPreLevel(IList<ApplyApproveListInfo> applyApproveListInfo)
        {
            //Get level of user login 
            int? loginUserLevel = 0;
            ApplyApproveListInfo loginUserInfo = new ApplyApproveListInfo();
            loginUserInfo = (from app in applyApproveListInfo
                               where app.RouteUID == LoginInfo.User.ID
                               select app).SingleOrDefault();

            if (loginUserInfo != null)
            {
                loginUserLevel = loginUserInfo.RouteLevel;
            }
            
            IList<ApplyApproveListInfo> notApproveList1 = new List<ApplyApproveListInfo>();
            notApproveList1 = (from app in applyApproveListInfo
                              where ((app.RouteLevel == loginUserLevel && app.RouteMethod==(int)RouteMethods.AND) ) && (app.ApproveStatus != (short)StatusHasAprove.Approved )
                               select app).ToList();


            if (notApproveList1 != null && notApproveList1.Count > 0)
            {
                IList<ApplyApproveListInfo> notApproveList2= new List<ApplyApproveListInfo>();
                notApproveList2 = (from app in applyApproveListInfo
                                   where (app.RouteLevel == loginUserLevel - 1) && (app.ApproveStatus != (short)StatusHasAprove.Approved)
                                   select app).ToList();
                if (notApproveList2 != null && notApproveList2.Count > 0)
                {
                    return true;
                }
                else 
                {
                    return false;
                }
                
            }
            else
            {
                return false;
            }
        }

       
        /// <summary>
        /// Check showing PrevBack button
        /// </summary>
        /// <param name="applyApproveListInfo"></param>
        /// <returns></returns>
        private bool IsShowPrevBackButton(IList<ApplyApproveListInfo> applyApproveListInfo)
        {
            //Get level of user login 
            int? loginUserLevel = 0;
            ApplyApproveListInfo approveUserInfo = new ApplyApproveListInfo();
            approveUserInfo = (from app in applyApproveListInfo
                               where app.RouteUID == LoginInfo.User.ID
                               select app).SingleOrDefault();

            if (approveUserInfo != null)
            {
                loginUserLevel = approveUserInfo.RouteLevel;
            }

            ApplyApproveListService approveSer = new ApplyApproveListService();
            int minLevel = approveSer.GetMinRouteLevelByID(this.DataID);

            //Get list of Approve User whose level is less than level of login user 
            if (loginUserLevel > minLevel)
            {
                IList<ApplyApproveListInfo> approveUserList = new List<ApplyApproveListInfo>();
                approveUserList = (from appUser in applyApproveListInfo
                                   where appUser.ApproveStatus == (short)StatusHasAprove.Approved && loginUserLevel>=appUser.RouteLevel 
                                   select appUser).ToList();
                if (approveUserList != null && approveUserList.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }  
        }

        /// <summary>
        /// Set complete status for the ApplyStatus
        /// </summary>
        /// <param name="applyApproveListInfo"></param>
        /// <returns></returns>
        private void SetCompleteStatus(IList<ApplyApproveListInfo> applyApproveListInfo)
        {
            IList<ApplyApproveListInfo> completedList = new List<ApplyApproveListInfo>();
            completedList = (from app in applyApproveListInfo
                             where app.ApproveStatus == (short)StatusHasAprove.Approved
                             select app).ToList();

            if (completedList != null && completedList.Count == applyApproveListInfo.Count)
            {
                this.ApplyStatus= (short)StatusApply.Complete;
            }
        }

        /// <summary>
        /// Check inputing
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
            {
                this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
            }
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            //Employee Code
            if (this.chkIsAgent.Checked)
            {
                if (this.txtEmployeeCD.IsEmpty)
                {
                    this.SetMessage("txtEmployeeCD", M_Message.MSG_REQUIRE, "Employee Code");
                }
            }

            //Perform Date From
            if (!this.dtPerformDateFrm.Value.HasValue)
            {
                this.SetMessage("dtPerformDateFrm", M_Message.MSG_REQUIRE, "Perform Date From");
            }


            //Start Hour
            if (this.dtPerformDateFrm.Value== this.dtPerformDateTo.Value && int.Parse( this.cmbStartHour.SelectedValue.ToString()) > int.Parse( this.cmbEndHour.SelectedValue.ToString()))
            {
                this.SetMessage("cmbStartHour", M_Message.MSG_LESS_THAN_EQUAL, "Start Hour", "End Hour");
            }

            //StartHour
            if (this.dtPerformDateFrm.Value.HasValue)
            {
                if (int.Parse(this.cmbStartHour.SelectedValue.ToString()) < int.Parse(this.hdnMinHour.Value))
                {
                    this.SetMessage("cmbStartHour", M_Message.MSG_GREATER_THAN_EQUAL, "Start Hour", int.Parse(this.hdnMinHour.Value));
                }

                if (int.Parse(this.cmbStartHour.SelectedValue.ToString()) == int.Parse(this.hdnMinHour.Value) && int.Parse(this.cmbStartMinute.SelectedValue.ToString()) < int.Parse(this.hdnMinMinute.Value))
                {
                    this.SetMessage("cmbStartMinute", M_Message.MSG_GREATER_THAN_EQUAL, "Start Minute", int.Parse(this.hdnMinMinute.Value));
                }

            }

            //EndHour
            if (this.dtPerformDateTo.Value.HasValue)
            {
                if (int.Parse(this.cmbEndHour.SelectedValue.ToString()) > int.Parse(this.hdnMaxHour.Value))
                {
                    this.SetMessage("cmbEndHour", M_Message.MSG_LESS_THAN_EQUAL, "End Hour", int.Parse(this.hdnMaxHour.Value));
                }

                if (int.Parse(this.cmbEndHour.SelectedValue.ToString()) == int.Parse(this.hdnMaxHour.Value) && int.Parse(this.cmbEndMinute.SelectedValue.ToString()) > int.Parse(this.hdnMaxMinute.Value))
                {
                    this.SetMessage("cmbEndMinute", M_Message.MSG_LESS_THAN_EQUAL, "End Minute", int.Parse(this.hdnMaxMinute.Value));
                }

            }

            //Start Minute
            if (int.Parse(this.cmbStartHour.SelectedValue.ToString()) == int.Parse(this.cmbEndHour.SelectedValue.ToString()) && int.Parse(this.cmbStartMinute.SelectedValue.ToString()) >= int.Parse(this.cmbEndMinute.SelectedValue.ToString()))
            {
                this.SetMessage("cmbStartMinute", M_Message.MSG_LESS_THAN, "Start Minute", "End Minute");
            }


            return !base.HaveError;
        }


        /// <summary>
        /// btCopy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCoppy_Click(object sender, EventArgs e)
        {
            
            //Get data
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ApplyStatus = (int)StatusApply.New;
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check data
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Update;
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            this.LoadDataForApproveListFromApproveList();

            ////Check input
            if (!this.CheckInput())
            {
                
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            ////Set Mode
            this.ProcessMode(Mode.Delete);
            this.LoadDataForApproveListFromApproveList();
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {

            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                //Set Mode
                this.ShowData(apply);
                this.ProcessMode(Mode.Confirm);
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                //Set Mode
                this.ShowData(apply);
                this.ProcessMode(this.Mode);
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            this.LoadDataForApproveListFromApproveList();
            if (this.Mode == Mode.Approve)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.Yes, true);
            }
            else if (this.Mode == Mode.Ignore)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No, true);
            }
            else if (this.Mode == Mode.BackPre)
            {
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No, true);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.ShowData(apply);
                //Set Mode
                this.ProcessMode(Mode.Ignore);
            }
           
        }
        
        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Apply apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.ShowData(apply);
                //Set Mode
                this.ProcessMode(Mode.BackPre);
            }
            
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Apply data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Apply data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);
                       
                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete vendor
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                case Utilities.Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
                case Utilities.Mode.Confirm:
                    //Update Data
                    this.ApplyStatus = (short)StatusApply.Confirm;
                    ret = this.UpdateApplyStatus(this.ApplyStatus);
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Approve:
                    //Update Data
                    data = this.GetApplyByID(this.DataID);
                    ApplyService service = new ApplyService();
                    ret =this.ApproveData(data.ID);
                    if (ret)
                    {
                        this.ApplyStatus = (short)StatusApply.Approve;
                        IList<ApplyApproveListInfo> applyApproveListInfo = new List<ApplyApproveListInfo>();
                        applyApproveListInfo = this.GetListApproveUserFromApply();
                        this.SetCompleteStatus(applyApproveListInfo);
                       
                        data.ApplyStatus = this.ApplyStatus;
                        data.UpdateUID = LoginInfo.User.ID;
                        service.UpdateApplyStatus(data);

                        //Show data
                        this.ShowData(data);
                        
                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.Ignore:
                    //Update Data
                    ret = this.UpdateApplyStatus((short)StatusApply.Ignore);
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    ret = this.UpdateApplyStatus((short)StatusApply.BackPrev);
                    if (ret)
                    {
                        //Get User
                        data = this.GetApplyByID(this.DataID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Apply data = this.GetApplyByID(this.DataID);
            if (this.Mode == Utilities.Mode.View)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else 
            {
                this.LoadDataForApproveListFromApproveList();
            }
           
        }

        #endregion

        #region Methods

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.SetDataApplyTypeCbo();
            
            this.dtApplyDate.Value = null;
            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW); 
            this.txtEmployeeNm.Value = LoginInfo.User.UserName1;
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                M_Department dept = deptSer.GetByID(LoginInfo.User.DepartmentID);
                this.txtDepartment.Value = dept.DepartmentName;
            }
            this.txtPosition.Value = LoginInfo.User.Position;
            this.GetDefaultDataForCbo(int.Parse(this.cmbApplyType.SelectedValue.ToString()));

            this.dtPerformDateFrm.Value = DateTime.Now;
            this.dtPerformDateTo.Value = DateTime.Now;

            this.InitComboHour(this.cmbStartHour);
            this.InitComboMinute(this.cmbStartMinute);
            this.InitComboHour(this.cmbEndHour);
            this.InitComboMinute(this.cmbEndMinute);
            
        }

        /// <summary>
        /// Init combobox Hour
        /// </summary>
        /// <param name="ddlHour"></param>
        private void InitComboHour(DropDownList ddlHour)
        {
           
            IList<DropDownModel> lstHour = new List<DropDownModel>();
            for (int i = 0; i < 24; i++)
            {
                DropDownModel item = new DropDownModel();
                item.DisplayName = i.ToString().PadLeft(2, '0');
                item.Value = i.ToString();
                lstHour.Add(item);
            }
            ddlHour.DataSource = lstHour;
            ddlHour.DataValueField = "Value";
            ddlHour.DataTextField = "DisplayName";
            ddlHour.DataBind();

        }

        /// <summary>
        /// Init combobox Minute
        /// </summary>
        /// <param name="ddlMinute"></param>
        private void InitComboMinute(DropDownList ddlMinute)
        {
            IList<DropDownModel> lstMinute = new List<DropDownModel>();
            for (int i = 0; i < 60; i++)
            {
                DropDownModel item = new DropDownModel();
                item.DisplayName = i.ToString().PadLeft(2, '0');
                item.Value = i.ToString();
                lstMinute.Add(item);
            }
            ddlMinute.DataSource = lstMinute;
            ddlMinute.DataValueField = "Value";
            ddlMinute.DataTextField = "DisplayName";
            ddlMinute.DataBind();

        }

        /// <summary>
        /// Clear value screen
        /// </summary>
        private void ClearValue()
        {
            this.chkIsAgent.Checked = false;
            this.txtReason.Value = string.Empty;
            this.txtApproveReason.Value = string.Empty;
        }

        #region Insert data
        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                T_Apply data = new T_Apply();

                data=this.CreateApplyData();

                //Insert
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);

                    //Insert Daily
                    service.Insert(data);
                    this.ApplyStatus = data.ApplyStatus;

                    this.DataID = db.GetIdentityId<T_Apply>();
                    data.ID = this.DataID;

                    //Insert into T_Apply_Approve_List tabable
                    IList<VacationApprove> approveUserlist = this.GetListApprovePerson(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
                    IList<T_Apply_Approve_List> applyApproveLst=this.CreateApplyApproveListData(data, approveUserlist);
                    ApplyApproveListService applyApproveSer = new ApplyApproveListService(db);

                    foreach (T_Apply_Approve_List item in applyApproveLst)
                    {
                        applyApproveSer.Insert(item);
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Apply_UK))
                {
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    LoadDataForApproveListFromApproveList();
                    this.SetMessage(this.cmbApplyType.ID, M_Message.MSG_EXIST_CODE, "Apply Type");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }
               

        #endregion

        #region Update data
        

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                T_Apply data = this.GetApplyByID(this.DataID);
                if (data != null)
                {

                    //Create model

                    data.ApplyDate = this.dtApplyDate.Value.Value;

                    if (this.chkIsAgent.Checked)
                    {
                        UserService userSer = new UserService();
                        M_User user = userSer.GetByUserCD(this.txtEmployeeCD.Value);
                        if (user != null)
                        {
                            data.UserID = user.ID;
                        }
                    }
                    else 
                    {
                        data.UserID = LoginInfo.User.ID;
                    }
                    data.ApplyStatus = this.ApplyStatus; //(short)StatusApply.New;
                    data.TypeApplyID =int.Parse( this.cmbApplyType.SelectedValue.ToString());
                    data.StartDate = this.dtPerformDateFrm.Value.Value;
                    data.StartHour = short.Parse(this.cmbStartHour.SelectedValue.ToString());
                    data.StartMinute = short.Parse(this.cmbStartMinute.SelectedValue.ToString());

                    data.EndDate = this.dtPerformDateTo.Value.Value;
                    data.EndHour = short.Parse(this.cmbEndHour.SelectedValue.ToString());
                    data.EndMinute = short.Parse(this.cmbEndMinute.SelectedValue.ToString());

                    data.Reason = this.txtReason.Text;
                    data.StatusFlag = 0;//short.Parse( this.chkDeletedData.Checked==true?"1":"0") ;

                    data.UpdateDate = this.OldUpdateDate;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Update data
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ApplyService service = new ApplyService(db);

                        //Update
                        if (data.Status == DataStatus.Changed)
                        {
                            //Update T_Apply
                            ret = service.Update(data);

                            //Insert into T_Apply_Approve_List tabable
                            IList<VacationApprove> approveUserlist = this.GetListApprovePerson(int.Parse(this.cmbApplyType.SelectedValue.ToString()));

                            IList<T_Apply_Approve_List> applyApproveLst = this.CreateApplyApproveListData(data, approveUserlist);
                            ApplyApproveListService applyApproveSer = new ApplyApproveListService(db);

                            //Delete T_ApplyApproveList
                            applyApproveSer.Delete(data.ID);

                            //Insert T_ApplyApproveList
                            foreach (T_Apply_Approve_List item in applyApproveLst)
                            {
                                applyApproveSer.Insert(item);
                            }

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    LoadDataForApproveListFromApproveList();
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Confirm

        /// <summary>
        /// ApproveData
        /// </summary>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool ApproveData(int applyID)
        { 
            try
            {
               int ret = 0;
               using (DB db = new DB(System.Data.IsolationLevel.Serializable))
               {
                   
                   ApplyApproveListService approveSer = new ApplyApproveListService(db);
                   T_Apply_Approve_List applyList = new T_Apply_Approve_List();
                   applyList.ApplyID = applyID;
                   applyList.ApproveStatus = (short)StatusHasAprove.Approved;
                   applyList.ApproveUID = LoginInfo.User.ID;
                   applyList.ApproveReason = this.txtApproveReason.Value;
                   ret=approveSer.Approve(applyList, (short)StatusHasAprove.New, (short)StatusHasAprove.BackPrev);

                   //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
                   approveSer.UpdateStatusForPrevBack(applyList.ApplyID, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
                   db.Commit();
               }

               //Check result update
               if (ret == 0)
               {
                   this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                   LoadDataForApproveListFromApproveList();
                   //Data is changed
                   this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                   return false;
               }
            }
            catch (Exception ex)
            {
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Confirm applying
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool UpdateApplyStatus(short applyStatus)
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);
                    T_Apply apply = new T_Apply();
                    apply.ID = this.DataID;
                    apply.ApplyStatus = applyStatus;
                    apply.UpdateUID = LoginInfo.User.ID;
                    apply.UpdateDate = this.OldUpdateDate;

                    //Update StatusFlag
                    ret = service.UpdateApplyStatus(apply);

                    ApplyApproveListService approveSer = new ApplyApproveListService(db);
                    T_Apply_Approve_List applyList = new T_Apply_Approve_List();

                    switch (applyStatus)
                    {
                        case (short)StatusApply.Confirm:
                            applyList.ApplyID = this.DataID;
                            applyList.ApproveStatus = (short)StatusHasAprove.New;
                            applyList.ApproveUID = null;
                            applyList.ApproveDate = null;
                            applyList.ApproveReason = null;
                            approveSer.Update(applyList);

                            break;
                        //case (short)StatusApply.Approve:
                        //    //Update ApplyStatus
                            
                        //    applyList.ApplyID = this.DataID;
                        //    applyList.ApproveStatus = (short)StatusHasAprove.Approved;
                        //    applyList.ApproveUID = LoginInfo.User.ID;
                        //    applyList.ApproveReason = this.txtApproveReason.Value;
                        //    approveSer.Approve(applyList, (short)StatusHasAprove.New, (short)StatusHasAprove.BackPrev);

                        //    //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
                        //    approveSer.UpdateStatusForPrevBack(applyList.ApplyID, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
                        //    break;
                        case (short)StatusApply.Ignore:

                            //Update ApproveStatus
                            applyList.ApplyID = this.DataID;
                            applyList.ApproveStatus = (short)StatusHasAprove.Ignore;
                            applyList.ApproveReason = this.txtApproveReason.Value;
                            approveSer.UpdateApproveStatus(applyList,LoginInfo.User.ID);
                            break;

                        case (short)StatusApply.BackPrev:

                            //1:Update ApproveStatus for the login user 
                            applyList.ApplyID = this.DataID;
                            applyList.ApproveStatus = (short)StatusHasAprove.BackPrev;
                            applyList.ApproveReason = this.txtApproveReason.Value;
                            approveSer.UpdateApproveStatus(applyList, LoginInfo.User.ID);

                            //2:Update New status of the approved users have level = the login user's level or level= the login user's level-1
                            applyList.ApproveStatus = (short)StatusHasAprove.New;
                            approveSer.UpdateForPrevBack(applyList, LoginInfo.User.ID, (short)StatusHasAprove.Approved);
                            break;

                    }
                    
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    LoadDataForApproveListFromApproveList();
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region  Delete Data

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ApplyService service = new ApplyService(db);
                    T_Apply apply = new T_Apply();
                    apply.StatusFlag = 1;
                    apply.ID = this.DataID;
                    apply.UpdateUID = LoginInfo.User.ID;
                    apply.UpdateDate = this.OldUpdateDate;

                    //Update StatusFlag
                    ret = service.UpdateStatusFlag(apply);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    LoadDataForApproveListFromApproveList();
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Get data

        /// <summary>
        /// Get default data for Combo box
        /// </summary>
        /// <param name="applyTypeID"></param>
        private void GetDefaultDataForCbo(int applyTypeID)
        {
            M_TypeApply typeApply = new M_TypeApply();
            typeApply = this.GetTypeApplyByID(applyTypeID);
            if (typeApply != null)
            {
                this.cmbStartHour.SelectedValue = typeApply.MinStartHour.ToString();
                this.cmbStartMinute.SelectedValue = typeApply.MinStartMinute.ToString();
                this.cmbEndHour.SelectedValue = typeApply.MaxEndHour.ToString();
                this.cmbEndMinute.SelectedValue = typeApply.MaxEndMinute.ToString();
                this.hdnMinHour.Value = typeApply.MinStartHour.ToString();
                this.hdnMinMinute.Value = typeApply.MinStartMinute.ToString();
                this.hdnMaxHour.Value = typeApply.MaxEndHour.ToString();
                this.hdnMaxMinute.Value = typeApply.MaxEndMinute.ToString();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private M_TypeApply GetTypeApplyByID(int id)
        {
            M_TypeApply typeApp = new M_TypeApply();
            TypeApplyService typeAppSer = new TypeApplyService();
            typeApp = typeAppSer.GetByID(id);
            return typeApp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Apply GetApplyByID(int id)
        {
            T_Apply apply = new T_Apply();
            ApplyService appSer = new ApplyService();
            apply = appSer.GetByID(id);
            return apply;
        }

        /// <summary>
        /// Get  approver List from Apply
        /// </summary>
        /// <returns></returns>
        private IList<ApplyApproveListInfo> GetListApproveUserFromApply()
        {
            IList<ApplyApproveListInfo> approveUserList = new List<ApplyApproveListInfo>();
            ApplyApproveListService applyApproveSer = new ApplyApproveListService();
            approveUserList = applyApproveSer.GetByID(this.DataID);
            return approveUserList;
        }

        /// <summary>
        /// GetListApproveWork From Route
        /// </summary>
        /// <returns></returns>
        private IList<VacationApprove> GetListApprovePerson(int TypeID)
        {

            IList<VacationApprove> approveUserList = new List<VacationApprove>();
            IList<VacationApprove> allowList = new List<VacationApprove>();

            //Get level of leaver 
            int? userLevel = 0;
            UserService userSer =new UserService();
            int employeeID=0 ;
            M_User user =userSer.GetByUserCD(this.txtEmployeeCD.Value);
            if(user !=null)
            {
                employeeID=user.ID;
            }


            using (DB db = new DB())
            {
                Route_DService rSer = new Route_DService(db);
                //Get Approve List
                approveUserList = rSer.GetListApproveVacationByTypeID(TypeID);
                if (approveUserList != null && approveUserList.Count != 0)
                {

                    VacationApprove userInfo = new VacationApprove();
                    userInfo = (from app in approveUserList
                                where app.UserID == employeeID
                                select app).SingleOrDefault();

                    if (userInfo != null)
                    {
                        userLevel = userInfo.RouteLevel;
                    }

                    allowList = (from approveUser in approveUserList
                                 where approveUser.RouteLevel > userLevel || (approveUser.RouteLevel==userLevel && approveUser.RouteMethod==(int)RouteMethods.AND)
                                        && approveUser.UserID!=employeeID
                                     select approveUser).ToList();
                    
                    if (allowList == null || allowList.Count == 0)
                    {
                        allowList = (from approveUser in approveUserList
                                     where approveUser.UserID == employeeID || (approveUser.RouteLevel == userLevel && approveUser.RouteMethod==1)
                                     select approveUser).ToList();
                    }

                }
                return allowList;
            }
        }

        /// <summary>
        /// Fill Data Approve List From Route
        /// </summary>
        private void LoadDataForApproveListFromRoute(int typeID)
        {

            IList<VacationApprove> approverList =new List<VacationApprove>() ;
            approverList = this.GetListApprovePerson(typeID);
            foreach (VacationApprove approve in approverList)
            {
                if (approve.ApproveFlag == null)
                {
                    approve.ApproveFlagStr = string.Empty;
                }
            }

            if (approverList != null && approverList.Count != 0)
            {
                this.isHasData = true;
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                 this.isHasData = false;
                 this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();
            this.isApproved = false;
            
        }

        /// <summary>
        /// Load data for rptApproveChild from ApproveList
        /// </summary>
        private void LoadDataForApproveListFromApproveList()
        {
            IList<ApplyApproveListInfo> applyApproveListInfo = new List<ApplyApproveListInfo>();
            applyApproveListInfo = this.GetListApproveUserFromApply();
            if (applyApproveListInfo != null && applyApproveListInfo.Count != 0)
            {
                this.isHasData = true;
                this.rptApproverList.DataSource = applyApproveListInfo;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();

            //Check LoginUser is approver
            this.isApproveUser = this.IsApprover(applyApproveListInfo);
          

           //Check LoginUser has approved or not yet.
            this.isApproved = this.IsApproved(applyApproveListInfo);
        
           //Set complete status for ApplyStatus
            this.SetCompleteStatus(applyApproveListInfo);

            //Check showing PrevBack button
            this.isShowPrevBack = this.IsShowPrevBackButton(applyApproveListInfo);

            //Checking approve status for previous level of loginuser level
            this.isDisablePrevBack = this.IsNotApprovedInPreLevel(applyApproveListInfo);
        }

        #endregion

        #region Set data

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;
            this.SetPerformDateTo();
            
            //Check model
            switch (mode)
            {

                case Mode.Insert:
                    this.LoadDataForApproveListFromRoute(int.Parse( this.cmbApplyType.SelectedValue));
                    this.ApplyStatus = (int)StatusApply.New;
                    this.chkIsAgent.Checked = false;
                    //this.chkIsAgent.Disabled = false;
                    this.chkIsAgent.Enabled = true;
                    this.cmbApplyType.Enabled = true;
                    this.dtPerformDateFrm.ReadOnly = false;
                    this.cmbStartHour.Enabled = true;
                    this.cmbStartMinute.Enabled = true;
                    this.dtPerformDateTo.ReadOnly = true;
                    this.cmbEndHour.Enabled = true;
                    this.cmbEndMinute.Enabled = true;
                    //this.chkDeletedData.Disabled = true;
                    this.txtReason.ReadOnly = false;
                    this.txtApproveReason.ReadOnly = true;
                    this.isApproved = false;
                    break;
                case Mode.Copy:
                    this.LoadDataForApproveListFromApproveList();
                    this.ApplyStatus = (int)StatusApply.New;
                    //this.chkIsAgent.Disabled = false;
                    this.chkIsAgent.Enabled = true;
                    this.cmbApplyType.Enabled = true;
                    this.dtPerformDateFrm.ReadOnly = false;
                    this.cmbStartHour.Enabled = true;
                    this.cmbStartMinute.Enabled = true;
                    this.dtPerformDateTo.ReadOnly = true;
                    this.cmbEndHour.Enabled = true;
                    this.cmbEndMinute.Enabled = true;
                   // this.chkDeletedData.Disabled = true;
                    this.txtReason.ReadOnly = false;
                    this.txtApproveReason.ReadOnly = true;
                    this.isApproved = false;
                    
                    break;

                case Mode.Update:
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.ReadOnly = true;
                    //this.chkIsAgent.Disabled = true;
                    this.chkIsAgent.Enabled = true;
                    this.cmbApplyType.Enabled = true;
                    this.dtPerformDateFrm.ReadOnly = false;
                    this.cmbStartHour.Enabled = true;
                    this.cmbStartMinute.Enabled = true;
                    this.dtPerformDateTo.ReadOnly = false;
                    this.cmbEndHour.Enabled = true;
                    this.cmbEndMinute.Enabled = true;
                    this.txtReason.ReadOnly = false;
                    //this.chkDeletedData.Disabled = false;
                    if (!this.ApplyStatus.Equals(StatusApply.New))
                    {
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnDelete, true);
                    }
                    else
                    {
                        base.DisabledLink(this.btnEdit, false);
                        base.DisabledLink(this.btnDelete, false);
                    }
                    this.txtApproveReason.ReadOnly = true;
                    break;
                case Mode.Approve:
                    this.txtApproveReason.ReadOnly = false;
                    break;

                case Mode.Confirm:
                    this.LoadDataForApproveListFromApproveList();
                    this.ApplyStatus = (int)StatusApply.New;
                    this.txtApproveReason.ReadOnly = this.isApproveUser==false?true:false;
                    
                    break;
                case Mode.Ignore:
                    
                    this.ApplyStatus = (int)StatusApply.Ignore;
                    this.txtApproveReason.ReadOnly = false;

                    break;

                case Mode.BackPre:
                    
                    this.ApplyStatus = (int)StatusApply.BackPrev;
                    this.txtApproveReason.ReadOnly = false;

                    break;

                case Mode.Delete:
                    
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.ReadOnly = true;
                    //this.chkIsAgent.Disabled = true;
                    this.chkIsAgent.Enabled = false;
                    this.cmbApplyType.Enabled = false;
                    this.dtPerformDateFrm.ReadOnly = true;
                    this.cmbStartHour.Enabled = false;
                    this.cmbStartMinute.Enabled = false;
                    this.dtPerformDateTo.ReadOnly = true;
                    this.cmbEndHour.Enabled = false;
                    this.cmbEndMinute.Enabled = false;
                    this.txtReason.ReadOnly = true;
                   // this.chkDeletedData.Disabled = true;
                    this.txtApproveReason.ReadOnly = true;
                    break;
                default:

                    //this.chkIsAgent.Disabled = true;
                    this.chkIsAgent.Enabled = false;
                    this.cmbApplyType.Enabled = false;
                    this.dtPerformDateFrm.ReadOnly = true;
                    this.cmbStartHour.Enabled = false;
                    this.cmbStartMinute.Enabled = false;
                    this.dtPerformDateTo.ReadOnly = true;
                    this.cmbEndHour.Enabled = false;
                    this.cmbEndMinute.Enabled = false;
                    //this.chkDeletedData.Disabled = true;
                    this.txtReason.ReadOnly = true;
                    this.txtApproveReason.ReadOnly = true;

                    //if (this.chkDeletedData.Checked)
                    //{
                    //    base.DisabledLink(this.btnEdit, false);
                    //    base.DisabledLink(this.btnDelete, true);
                    //    base.DisabledLink(this.btnConfirm, true);
                    //}
                    //else
                    //{
                    //    base.DisabledLink(this.btnEdit, false);
                    //    base.DisabledLink(this.btnDelete, false);
                    //    base.DisabledLink(this.btnConfirm, false);
                    //}

                    string loginUserCD=Utilities.EditDataUtil.ToFixCodeShow( LoginInfo.User.UserCD,M_User.MAX_USER_CODE_SHOW);
                    if ((!this.txtEmployeeCD.IsEmpty && loginUserCD != this.txtEmployeeCD.Value) )
                    {
                        base.DisabledLink(this.btnEdit, true);
                        //base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnConfirm, true);
                    }

                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.New:
                            base.DisabledLink(this.btnEdit, false);
                            base.DisabledLink(this.btnDelete, false);
                            base.DisabledLink(this.btnConfirm, false);
                            break;

                        case (int) StatusApply.Confirm:
                            base.DisabledLink(this.btnEdit, true);
                            //base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                           
                            break;
                        case (int)StatusApply.Approve:
                            base.DisabledLink(this.btnEdit, true);
                            //base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;
                        case (int)StatusApply.Complete:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Ignore:
                            base.DisabledLink(this.btnEdit, false);
                            base.DisabledLink(this.btnConfirm, false);
                            break;
                    }

                    if (this.isApproved)
                    {
                        //base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnApprove, true);
                        base.DisabledLink(this.btnIgnore, true);
                        base.DisabledLink(this.btnPrevBack, true);
                    }
                    else 
                    {
                        //base.DisabledLink(this.btnDelete, false);
                        base.DisabledLink(this.btnApprove, false);
                        base.DisabledLink(this.btnIgnore, false);

                        if (this.isDisablePrevBack)
                        {
                            base.DisabledLink(this.btnPrevBack, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnPrevBack, false);
                        }
                        
                    }

                  
                    break;
            }

            if (this.chkIsAgent.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Update || this.Mode == Mode.Copy))
            {
                this.txtEmployeeCD.SetReadOnly(false);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Apply apply)
        {
            this.SetDataApplyTypeCbo();
            this.InitComboHour(this.cmbStartHour);
            this.InitComboMinute(this.cmbStartMinute);
            this.InitComboHour(this.cmbEndHour);
            this.InitComboMinute(this.cmbEndMinute);

            //Show data
            if (apply != null)
            {
                M_User user = new M_User();
                UserService userSer = new UserService();
                this.colorStatus = base.GetStatusColorLabel(apply.ApplyStatus, ref this.statusNameLbl);
                this.dtApplyDate.Value = apply.ApplyDate;
                
                if(apply.UserID.Equals(apply.CreateUID))
                {
                    this.chkIsAgent.Checked = false;
                    
                }else
                {
                    this.chkIsAgent.Checked = true;
                }

                user = userSer.GetByID(apply.UserID);
                if(user !=null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(user.UserCD, M_User.MAX_USER_CODE_SHOW);
                    this.txtEmployeeNm.Value = user.UserName1;
                    this.txtEmployeeNm.Value = user.UserName1;
                    using (DB db = new DB())
                    {
                        DepartmentService deptSer = new DepartmentService(db);
                        M_Department dept = deptSer.GetByID(user.DepartmentID);
                        if (dept != null)
                        {
                            this.txtDepartment.Value = dept.DepartmentName;
                        }

                    }
                    this.txtPosition.Value = user.Position;
                    
                }
                
                this.cmbApplyType.SelectedValue = apply.TypeApplyID.ToString();
                TypeApplyService typeSer = new TypeApplyService();
                M_TypeApply typeApp = typeSer.GetByID(apply.TypeApplyID);
                if (typeApp != null)
                {
                    this.hdnMinHour.Value = typeApp.MinStartHour.ToString();
                    this.hdnMinMinute.Value = typeApp.MinStartMinute.ToString();
                    this.hdnMaxHour.Value = typeApp.MaxEndHour.ToString();
                    this.hdnMaxMinute.Value = typeApp.MaxEndMinute.ToString();
                }

                this.dtPerformDateFrm.Value = apply.StartDate;
                this.cmbStartHour.SelectedValue = apply.StartHour.ToString();
                this.cmbStartMinute.SelectedValue = apply.StartMinute.ToString();
                this.dtPerformDateTo.Value = apply.EndDate;
                this.cmbEndHour.SelectedValue = apply.EndHour.ToString();
                this.cmbEndMinute.SelectedValue = apply.EndMinute.ToString();
                this.txtReason.Value = apply.Reason;
                this.txtApproveReason.Value = string.Empty;

               // this.chkDeletedData.Checked = apply.StatusFlag==1?true:false;

                this.DataID = apply.ID;
                this.ApplyStatus = apply.ApplyStatus;

                M_User createUser = userSer.GetByID(apply.CreateUID);
                if(createUser!=null)
                {
                    this.CreateUserCD = createUser.UserCD;
                }
                
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveListFromApproveList();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private T_Apply CreateApplyData()
        {
            T_Apply data = new T_Apply();
            data.ApplyStatus = (int)StatusApply.New;
            data.ApplyDate = null;

            if (this.chkIsAgent.Checked)
            {
                UserService userSer = new UserService();
                M_User user = userSer.GetByUserCD(this.txtEmployeeCD.Value);
                if (user != null)
                {
                    data.UserID = user.ID;
                }

            }
            else
            {

                data.UserID = LoginInfo.User.ID;
            }

            data.TypeApplyID = int.Parse(this.cmbApplyType.SelectedValue.ToString());
            data.StartDate = this.dtPerformDateFrm.Value.Value;
            data.StartHour = short.Parse(this.cmbStartHour.SelectedValue.ToString());
            data.StartMinute = short.Parse(this.cmbStartMinute.SelectedValue.ToString());

            data.EndDate = this.dtPerformDateTo.Value.Value;
            data.EndHour = short.Parse(this.cmbEndHour.SelectedValue.ToString());
            data.EndMinute = short.Parse(this.cmbEndMinute.SelectedValue.ToString());

            data.Reason = this.txtReason.Text;

            //if (this.chkDeletedData.Checked)
            //{
            //    data.StatusFlag = 1;
            //}
            //else
            //{
            //    data.StatusFlag = 0;
            //}

            data.CreateUID = base.LoginInfo.User.ID;
            data.UpdateUID = base.LoginInfo.User.ID;
            return data;
        }

        /// <summary>
        /// Create data for ApplyApproveList 
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="lstApproveUser"></param>
        private IList<T_Apply_Approve_List> CreateApplyApproveListData(T_Apply apply, IList<VacationApprove> lstApproveUser)
        {
            IList<T_Apply_Approve_List> applyApproveList = new List<T_Apply_Approve_List>(); 
            foreach (VacationApprove approveUser in lstApproveUser)
            {
                T_Apply_Approve_List model = new T_Apply_Approve_List();
                model.ApplyID = apply.ID;
                model.RouteUID = approveUser.UserID;
                model.RouteLevel = approveUser.RouteLevel;
                model.RouteMethod = approveUser.RouteMethod;
                model.ApproveStatus =approveUser.ApproveFlag;
                model.ApproveUID = approveUser.ApproveUID;
                model.ApproveDate = approveUser.ApproveDate;
                model.ApproveReason = approveUser.ApproveReason;
                applyApproveList.Add(model);
            }

            return applyApproveList;
        }

        /// <summary>
        /// Set data for ApplyType combobox
        /// </summary>
        private void SetDataApplyTypeCbo()
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> typeApplyList = new List<DropDownModel>();
                TypeApplyService serTypeApp = new TypeApplyService();
                typeApplyList = serTypeApp.GetDataForDropDownList((int)TypeFormID.Apply);
                this.cmbApplyType.DataSource = typeApplyList;
            }
            this.cmbApplyType.DataValueField = "Value";
            this.cmbApplyType.DataTextField = "DisplayName";
            this.cmbApplyType.DataBind();
           
        }

        /// <summary>
        /// Set PerformDateTo
        /// </summary>
        private void SetPerformDateTo()
        {
            M_TypeApply typeApp = this.GetTypeApplyByID(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
            if (typeApp != null)
            {
               if (typeApp.MaxEndHour < typeApp.MinStartHour)
                {
                    DateTime currentDate = this.dtPerformDateFrm.Value.Value;
                    DateTime nextDate= currentDate.AddDays(1);
                    this.dtPerformDateTo.Value = nextDate;
                }
                else 
                {
                    this.dtPerformDateTo.Value = this.dtPerformDateFrm.Value;
                }
            }
        }

        /// <summary>
        /// Change Employee Textbox
        /// </summary>
        private void EmployeeTextChange()
        {
            string loginUserCD =Utilities.EditDataUtil.ToFixCodeShow( LoginInfo.User.UserCD,M_User.MAX_USER_CODE_SHOW);
            M_User user = new M_User();
            UserService userSer = new UserService();
            user = userSer.GetByUserCD(this.txtEmployeeCD.Value);
            if (user != null)
            {
                if (this.txtEmployeeCD.Value == loginUserCD)
                {
                    this.chkIsAgent.Checked = false;
                }
                
                this.txtEmployeeNm.Value = user.UserName1;
                using (DB db = new DB())
                {
                    M_Department dept = new M_Department();
                    DepartmentService deptSer = new DepartmentService(db);
                    dept = deptSer.GetByID(user.DepartmentID);
                    if (dept != null)
                    {
                        this.txtDepartment.Value = dept.DepartmentName;
                    }
                }

                this.txtPosition.Value = user.Position;
            }
            else 
            {
                this.txtEmployeeNm.Value =string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
            }

            if (!string.IsNullOrEmpty(this.cmbApplyType.SelectedValue.ToString()))
            {
                this.LoadDataForApproveListFromRoute(int.Parse(this.cmbApplyType.SelectedValue.ToString()));
            }
            
        }

        #endregion

        /// <summary>
        /// Get Employee Name By Employee Code
       /// </summary>
       /// <param name="in1"></param>
       /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string in1)
        {
            var employeeCd = in1;
            var employeeCdShow = in1;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(employeeCd);
                    if (model != null)
                    {
                        DepartmentService deptSer = new DepartmentService(db);
                        M_Department dept = deptSer.GetByID(model.DepartmentID);
                        var result = new
                        {
                            employeeCD = employeeCdShow,
                            employeeNm = model.UserName1,
                            department = dept.DepartmentName,
                            position=model.Position

                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var employee = new
                    {
                        employeeCD = employeeCdShow
                    };

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        [System.Web.Services.WebMethod]
        public static Array GetDataRepeater(int applyTypeID, string employeeCD)
        {
            IList<VacationApprove> approveUserList = new List<VacationApprove>();
            IList<VacationApprove> allowList = new List<VacationApprove>();

            //Get level of leaver 
            int? userLevel = 0;
            UserService userSer = new UserService();
            int employeeID = 0;
            M_User user = userSer.GetByUserCD(employeeCD);
            if (user != null)
            {
                employeeID = user.ID;
            }


            using (DB db = new DB())
            {
                ArrayList dataList = new ArrayList();
                Route_DService rSer = new Route_DService(db);
                //Get Approve List
                approveUserList = rSer.GetListApproveVacationByTypeID(applyTypeID);
                if (approveUserList != null && approveUserList.Count != 0)
                {

                    VacationApprove userInfo = new VacationApprove();
                    userInfo = (from app in approveUserList
                                where app.UserID == employeeID
                                select app).SingleOrDefault();

                    if (userInfo != null)
                    {
                        userLevel = userInfo.RouteLevel;
                    }


                    allowList = (from approveUser in approveUserList
                                 where approveUser.RouteLevel > userLevel || (approveUser.RouteLevel == userLevel && approveUser.RouteMethod == (int)RouteMethods.AND)
                                        && approveUser.UserID != employeeID
                                 select approveUser).ToList();

                    if (allowList == null || allowList.Count == 0)
                    {
                        allowList = (from approveUser in approveUserList
                                     where approveUser.UserID == employeeID || (approveUser.RouteLevel == userLevel && approveUser.RouteMethod == 1)
                                     select approveUser).ToList();
                    }

                }

                System.Collections.ICollection collect = (System.Collections.ICollection)allowList;
                dataList.AddRange(collect);

                return dataList.ToArray();
            }
           
        }

        #endregion
    }
}

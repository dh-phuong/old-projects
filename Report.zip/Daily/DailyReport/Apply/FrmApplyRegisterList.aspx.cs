﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Apply
{
    /// <summary>
    /// FrmApplyRegisterList
    /// ISV-TRAM - 2015/04/01
    /// 
    /// </summary>
    public partial class FrmApplyRegisterList : FrmBaseList
    {
        #region Constant

        /// <summary>
        /// Danger text
        /// </summary>
        private const string CONST_WARNING_TEXT = "Cancellation";

        #endregion Constant

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set ApplyInfoList property
        /// </summary>
        public IList<ApplyInfo> ApplyInfoList
        {
            get { return (IList<ApplyInfo>)ViewState["ApplyInfoList"]; }
            set { ViewState["ApplyInfoList"] = value; }
        }

        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Apply Regist";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtUserCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtUserName.MaxLength = M_User.USER_NAME_1_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];
                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["DataID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Selected change cmbApplyType
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbTemplateForm_SelectIndexChanged(object sender, EventArgs e)
        {
            if(!string.IsNullOrEmpty(this.cmbTemplateForm.SelectedValue))
            {
                this.SetDataApplyTypeCbo(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
            }

            if (this.ApplyInfoList != null && this.ApplyInfoList.Count > 0)
            {
               // this.LoadGridPaging(this.ApplyInfoList, this.ApplyInfoList.Count, this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, true);
            }

            this.Collapse = "in";
        }

        /// <summary>
        /// Selected change cmbApplyType
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbStatus_SelectIndexChanged(object sender, EventArgs e)
        {
            if (this.cmbStatus.SelectedValue.Equals("1"))
            {
                this.dtApplyDateFrom.Value = null;
                this.dtApplyDateTo.Value = null;
            }
            if (this.ApplyInfoList != null && this.ApplyInfoList.Count > 0)
            {
               // this.LoadGridPaging(this.ApplyInfoList, this.ApplyInfoList.Count, this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, true);
            }
            this.Collapse = "in";
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtUserCD.ID, this.txtUserCD.Value);
            hash.Add(this.txtUserName.ID, this.txtUserName.Value);
            hash.Add(this.dtApplyDateFrom.ID, this.dtApplyDateFrom.Value);
            hash.Add(this.dtApplyDateTo.ID, this.dtApplyDateTo.Value);
            hash.Add(this.cmbStatus.ID, this.cmbStatus.SelectedValue);
            hash.Add(this.cmbTemplateForm.ID, this.cmbTemplateForm.SelectedValue);
            hash.Add(this.cmbType.ID, this.cmbType.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtUserCD.Value = data[this.txtUserCD.ID].ToString();
            this.txtUserName.Value = data[this.txtUserName.ID].ToString();


            this.dtApplyDateFrom.Value = null;
            if (data.ContainsKey(this.dtApplyDateFrom.ID))
            {
                if (data[this.dtApplyDateFrom.ID] != null)
                {
                    this.dtApplyDateFrom.Value = (DateTime)data[this.dtApplyDateFrom.ID];
                }
            }

            this.dtApplyDateTo.Value = null;
            if (data.ContainsKey(this.dtApplyDateTo.ID))
            {
                if (data[this.dtApplyDateTo.ID] != null)
                {
                    this.dtApplyDateTo.Value = (DateTime)data[this.dtApplyDateTo.ID];
                }
            }

            this.cmbStatus.SelectedValue = data[this.cmbStatus.ID].ToString();
            this.cmbTemplateForm.SelectedValue = data[this.cmbTemplateForm.ID].ToString();
            this.cmbType.SelectedValue = data[this.cmbType.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Init default value of Apply Date
            this.dtApplyDateFrom.Value = null;//DateTime.Now.AddMonths(-1);
            this.dtApplyDateTo.Value = null;//DateTime.Now;

            //Status
            this.InitCombobox(this.cmbStatus, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);

            //Set datatsource for TemplateForm combobox
            this.SetDataForCmbTemplateForm(this.LoginInfo.User.ID);
            this.SetDataApplyTypeCbo(int.Parse(this.cmbTemplateForm.SelectedValue.ToString()));
            // header grid
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            base.DisabledLink(this.btnNew, !base._authority.IsApplyRegistView || this.IsAdmin());
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Get datasource for dropdownlist template form
        /// </summary>
        private void SetDataForCmbTemplateForm(int userID)
        {
            using (DB db = new DB())
            {
                Config_HService conSer = new Config_HService(db);
                IList<DropDownModel> lstData = conSer.GetFormatTypeWithForm(M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
                IList<DropDownModel> allowList = new List<DropDownModel>();
                allowList = lstData;
                if (lstData != null && lstData.Count > 0)
                {
                    allowList = (from row in lstData
                                 where row.Value == M_Config_D.TEMPLATE_FORM_APPLY_LEAVE.ToString() || row.Value == M_Config_D.TEMPLATE_FORM_APPLY_TIME.ToString() || row.Value=="-1"
                                 select row).ToList<DropDownModel>();
                        
                }
                allowList.Insert(0, (new DropDownModel("-1", "---")));
                this.cmbTemplateForm.DataSource = allowList;
                this.cmbTemplateForm.DataValueField = "Value";
                this.cmbTemplateForm.DataTextField = "DisplayName";
                this.cmbTemplateForm.DataBind();
            }
        }

        /// <summary>
        /// Set data for ApplyType combobox
        /// </summary>
        private void SetDataApplyTypeCbo(int formID)
        {
            IList<DropDownModel> typeApplyList = new List<DropDownModel>();
            using (DB db = new DB())
            {
                FormTypeService frmTypeSer = new FormTypeService(db);
                typeApplyList = frmTypeSer.GetDataForDropdownList(formID);
            }

            typeApplyList.Insert(0, new DropDownModel("-1", "---"));
            this.cmbType.DataSource = typeApplyList;

            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();

        }

        /// <summary>
        /// Get data for DropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage, bool isProcess=false)
        {
            int totalRow = 0;
            this.GetColorClass(1);
            IList<ApplyInfo> lstResult = null;
            if (isProcess)
            {
                lstResult = new List<ApplyInfo>(this.ApplyInfoList);
                totalRow = lstResult.Count;
            }
            else
            {
                //Get conditions of search
                short status = -1;
                int templateFormID = -1;
                int typeApply = -1;
                DateTime? applyDateFrm;
                DateTime? applyDateTo;

                if (this.dtApplyDateFrom.Value != null)
                {
                    applyDateFrm = this.dtApplyDateFrom.Value;
                }
                else
                {
                    applyDateFrm = null;
                }

                if (this.dtApplyDateTo.Value != null)
                {
                    applyDateTo = this.dtApplyDateTo.Value;
                }
                else
                {
                    applyDateTo = null;

                }
                if (!string.IsNullOrEmpty(this.cmbStatus.SelectedValue))
                {
                    status = short.Parse(this.cmbStatus.SelectedValue.ToString());
                }

                if (!string.IsNullOrEmpty(this.cmbTemplateForm.SelectedValue))
                {
                    templateFormID = short.Parse(this.cmbTemplateForm.SelectedValue.ToString());
                }
                if (!string.IsNullOrEmpty(this.cmbType.SelectedValue))
                {
                    typeApply = int.Parse(this.cmbType.SelectedValue.ToString());
                }

                //Get data for grid
                using (DB db = new DB())
                {
                    ApplyService appSer = new ApplyService(db);
                    totalRow = appSer.GetTotalRow(this.LoginInfo.User.ID, this.txtUserCD.Value, this.txtUserName.Value, applyDateFrm, applyDateTo, status, templateFormID, typeApply);
                    lstResult = appSer.GetListByCond(this.LoginInfo.User.ID, this.txtUserCD.Value, this.txtUserName.Value, applyDateFrm, applyDateTo, status, templateFormID, typeApply, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                    //if (lstResult != null && lstResult.Count > 0)
                    //{
                    //    for (int i=0; i<lstResult.Count;i++)
                    //    {

                    //        lstResult[i].RowNumber = i + 1;
                    //    }
                    //}
                }
            }
            //totalRow = lstResult.Count;
            //this.SortGrid(ref lstResult);
            
            // Set color for rows
            //----this.SetColorForRows(lstResult, applyDateFrm, applyDateTo, status, templateFormID, typeApply);

            //if (lstResult == null || lstResult.Count == 0)
            //{
            //    this.rptResult.DataSource = null;
            //}
            //else
            //{
            //    if (lstResult.Count > numOnPage)
            //    {
            //        //Get data depend on page index and row number on one page
            //        lstResult = lstResult.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            //    }

            //    //Load paging of grid
            //    this.LoadGridPaging(lstResult, totalRow, pageIndex, numOnPage);

            //    // detail
            //    this.rptResult.DataSource = lstResult;
            //}
            //Show data
            if (lstResult == null || lstResult.Count == 0)
            {
                this.ApplyInfoList = new List<ApplyInfo>();
                // if (this.PagingFooter.CurrentPage > 1)
                if (pageIndex > 1)
                {
                    var curPage = (totalRow % numOnPage) == 0 ? (totalRow / numOnPage) : ((totalRow / numOnPage) + 1);
                    this.LoadDataGrid(curPage, numOnPage);
                }
                else
                {
                    this.rptResult.DataSource = null;
                }
            }
            else
            {
                this.ApplyInfoList = new List<ApplyInfo>(lstResult);
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstResult[lstResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "ApplyNo", "User", "Template Form", "Type", "Apply Date", "Start Date", "End Date", "Reason", "Status" });

                // detail
                this.rptResult.DataSource = lstResult;
            }
            this.rptResult.DataBind();
        }
        
        ///// <summary>
        ///// Load paging for grid
        ///// </summary>
        ///// <param name="listFormLink">List of FormLinkInfo model</param>
        ///// <param name="totalRow">Total row</param>
        ///// <param name="pageIndex">Page index</param>
        ///// <param name="numOnPage">Row number on one page</param>
        //private void LoadGridPaging(IList<ApplyInfo> applyInfoList, int totalRow, int pageIndex, int numOnPage)
        //{
        //    this.PagingHeader.RowNumFrom = int.Parse(applyInfoList[0].RowNumber.ToString());
        //    this.PagingHeader.RowNumTo = int.Parse(applyInfoList[applyInfoList.Count - 1].RowNumber.ToString());
        //    this.PagingHeader.TotalRow = totalRow;
        //    this.PagingHeader.CurrentPage = pageIndex;

        //    // paging footer
        //    this.PagingFooter.CurrentPage = pageIndex;
        //    this.PagingFooter.NumberOnPage = numOnPage;
        //    this.PagingFooter.TotalRow = totalRow;

        //    // header
        //    this.HeaderGrid.TotalRow = totalRow;
        //    this.HeaderGrid.AddColumms(new string[] { "#", "", "ApplyNo", "User", "Template Form", "Type", "Apply Date", "Start Date", "End Date", "Reason", "Status" });
            
        //}

        ///// <summary>
        ///// Set color for rows
        ///// </summary>
        ///// <param name="lstResult"></param>
        //private void SetColorForRows(IList<ApplyInfo> lstResult, DateTime? applyDateFrm, DateTime?  applyDateTo, short status, int templateFormID, int typeApply)
        //{
        //    //Get data
        //    using (DB db = new DB())
        //    {
        //        ApplyService appSer = new ApplyService(db);
        //        IList<T_Apply> lstCancelData = appSer.GetListByPreApplyID(LoginInfo.User.ID, this.txtUserCD.Value, this.txtUserName.Value, applyDateFrm, applyDateTo, status, templateFormID, typeApply);
        //        if (lstResult != null && lstResult.Count > 0)
        //        {
        //            foreach (ApplyInfo apply in lstResult)
        //            {
        //                IList<T_Apply> applyCancel = new List<T_Apply>();
        //                applyCancel = (from cancelData in lstCancelData
        //                               where apply.PreApplyID != null //&& apply.ApplyStatus == (int)StatusApply.New
        //                               select cancelData).ToList();

        //                if (applyCancel != null && applyCancel.Count > 0)
        //                {
        //                    apply.Color = (int)ColorList.Warning;
        //                }
        //                else
        //                {
        //                    apply.Color = -1;
        //                }
        //            }
        //        }
        //    }
        //}

        ///// <summary>
        ///// Sort grid
        ///// </summary>
        ///// <param name="linkList"></param>
        //private void SortGrid(ref IList<ApplyInfo> applyInfoList)
        //{
        //    int sortField = 1;
        //    int sortDirect = 1;

        //    if (!string.IsNullOrEmpty(HeaderGrid.SortField))
        //    {
        //        sortField = int.Parse(HeaderGrid.SortField);
        //    }

        //    if (!string.IsNullOrEmpty(HeaderGrid.SortDirec))
        //    {
        //        sortDirect = int.Parse(HeaderGrid.SortDirec);
        //    }

        //    switch (sortField)
        //    {
        //        case 1:
        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.UpdateDate descending
        //                                 select row).ToList();
        //            }

        //            break;

        //        case 3:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyNo ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyNo descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 4:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.UserCD ascending, row.Username ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.UserCD descending, row.Username descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 5:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.TemplateFormName ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.TemplateFormName descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 6:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.TypeName ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.TypeName descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 7:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyDate ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyDate descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 8:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.StartDate ascending, row.StartHour ascending, row.StartMinute ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.StartDate descending, row.StartHour descending, row.StartMinute descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 9:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.EndDate ascending, row.EndHour ascending, row.EndMinute ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.EndDate descending, row.EndHour descending, row.EndMinute descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 10:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.Reason ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.Reason descending
        //                                 select row).ToList();
        //            }
        //            break;

        //        case 11:

        //            if (sortDirect == 1)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyStatusText ascending
        //                                 select row).ToList();
        //            }

        //            if (sortDirect == 2)
        //            {
        //                applyInfoList = (from row in applyInfoList
        //                                 orderby row.ApplyStatusText descending
        //                                 select row).ToList();
        //            }
        //            break;
        //    }

        //    for (int i = 0; i < applyInfoList.Count; i++)
        //    {
        //        applyInfoList[i].RowNumber = i+1;
        //    }
        //}

        #endregion Method

        #region Web Method

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string FormatUserCode(string in1)
        {
            var employeeCd = in1;
            var employeeCdShow = in1;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(employeeCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            employeeCD = employeeCdShow,
                            employeeNm = model.UserName1


                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var employee = new
                    {
                        employeeCD = employeeCdShow
                    };

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
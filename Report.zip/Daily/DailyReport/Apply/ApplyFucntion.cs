﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DailyReport.DAC;
using DailyReport.Utilities;
using DailyReport.Models;
using System.Text;

namespace DailyReport.Apply
{
    public class ApplyFucntion
    {

        #region Property
        private int ApplyID { get; set; }
        private M_User LoginUser { get; set; }
        private ApplyType ApplyType { get; set; }
        private DateTime OldUpdateDate { get; set; }
        private M_StaffInfo Staff { get; set; }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor
        /// </summary>
        private ApplyFucntion()
        {
        }
        /// <summary>
        /// Contructor
        /// </summary>
        public ApplyFucntion(int applyID, M_User loginUser, ApplyType applyType, DateTime oldUpdateDate, M_StaffInfo staff)
        {
            this.ApplyID = applyID;
            this.LoginUser = loginUser;
            this.ApplyType = applyType;
            this.OldUpdateDate = oldUpdateDate;
            this.Staff = staff;
        }
        #endregion

        #region Confirm
        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        public ProcessResult Confirm()
        {
            bool success = false;
            string applyNo = string.Empty;
            string applyReason = string.Empty;
            string effectTime = string.Empty;
            string type = string.Empty;
            int routeID = 0;
            try
            {
                int ret = 0;
                switch (this.ApplyType)
                {
                    case ApplyType.Vacation:
                        using (DB db = new DB())
                        {
                            WorkVacationService vacationSer = new WorkVacationService(db);
                            T_Work_Vacation app = vacationSer.GetByID(this.ApplyID);
                            applyNo = app.No;
                            applyReason = app.Reason;
                            routeID = app.RouteID;

                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, app.VacationType);

                            if (app.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, app.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString());
                            }
                        }
                        break;

                    case ApplyType.OverTime:
                        using (DB db = new DB())
                        {
                            WorkOTService otSer = new WorkOTService(db);
                            T_Work_OT appOT = otSer.GetByID(this.ApplyID);
                            applyNo = appOT.No;
                            applyReason = appOT.Reason;
                            routeID = appOT.RouteID;
                            effectTime = EditDataUtil.FixTimeShow(appOT.OTStartHour, appOT.OTStartMinute) + " ～ " + EditDataUtil.FixTimeShow(appOT.OTEndHour, appOT.OTEndMinute);
                        }
                        break;

                    case ApplyType.LateEarlyOuting:
                        using (DB db = new DB())
                        {
                            WorkLeaveService leaveSer = new WorkLeaveService(db);
                            T_Work_Leave appLeave = leaveSer.GetByID(this.ApplyID);

                            applyNo = appLeave.No;
                            applyReason = appLeave.Reason;
                            routeID = appLeave.RouteID;
                            effectTime = EditDataUtil.FixTimeShow(appLeave.StartHour, appLeave.StartMinute) + " ～ " + EditDataUtil.FixTimeShow(appLeave.EndHour, appLeave.EndMinute);
                        }
                        break;

                    case ApplyType.Absence:
                        using (DB db = new DB())
                        {
                            WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                            T_Work_Absence appAbsence = absenceSer.GetByID(this.ApplyID);

                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, appAbsence.AbsenceType);

                            applyNo = appAbsence.No;
                            applyReason = appAbsence.Reason;
                            routeID = appAbsence.RouteID;

                            if (appAbsence.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, appAbsence.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString());
                            }
                        }
                        break;

                    default:
                        return ProcessResult.ProcessFail;
                }

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkApproveService apprSer = new WorkApproveService(db);
                    //Update StatusFlag
                    ret = apprSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, (int)StatusApply.Approving, 0, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        ret = apprSer.Insert(routeID, applyNo, -1, (short)StatusHasAprove.New);

                    }
                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        return ProcessResult.DataChanged;
                    }
                    db.Commit();
                    success = true;
                }
            }

            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return ProcessResult.ProcessFail;
            }

            try
            {
                //Send mail
                if (success)
                {
                    IList<string> lstEmail = this.GetListEmail(applyNo);
                    StringBuilder mailBody = new StringBuilder();
                    if (lstEmail != null && lstEmail.Count > 0)
                    {
                        mailBody.AppendLine(this.ApplyType.ToString() + " Application");
                        mailBody.AppendLine("------------ooo------------");
                        mailBody.AppendLine("ApplyNo       : " + applyNo);
                        mailBody.AppendLine("");
                        mailBody.AppendLine("Applicant     : " + this.Staff.DepartmentName);
                        mailBody.AppendLine("                " + this.Staff.StaffName);
                        mailBody.AppendLine("");
                        mailBody.AppendLine("Effect Time   : " + effectTime);
                        mailBody.AppendLine("");
                        mailBody.AppendLine("Reason        : " + applyReason);
                        mailBody.AppendLine("---------------------------");

                        string subject = "[WORKFLOW] : " + this.ApplyType.ToString() + " Application";

                        CommonUtil.Sending_Email(lstEmail.ToArray(), subject, mailBody);
                    }
                }
            }
            catch (Exception)
            {
                return ProcessResult.MailFail;
            }
            //TRAM - 2015/05/28 - Send Email for Confirm - END

            return ProcessResult.Success;
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService _service = new StaffService(db);
                return _service.GetStaffInfoByStaffCD(staffCD);
            }
        }

        #endregion

        #region mail

        /// <summary>
        /// TRAM - 2015/05/28
        /// Get list Email
        /// </summary>
        /// <returns>List of email</returns>
        private IList<string> GetListEmail(string applyNo)
        {
            IList<string> lstEmail = new List<string>();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                IList<WorkApproveModel> applicantInfoList = approveSer.GetListByIDOptionLevel(applyNo, false, EnumGetLevelZero.Only);
                if (applicantInfoList != null && applicantInfoList.Count > 0)
                {
                    if (applicantInfoList[0].GetApplySetting(ApplySetting.MailAll))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(applyNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.GreaterLevel);
                        return lstEmail;
                    }
                    else if (applicantInfoList[0].GetApplySetting(ApplySetting.Mail))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(applyNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.NextLevel);
                    }
                }
                return lstEmail;
            }
        }

        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Apply
{
    /// <summary>
    /// TRAM - 2015/06/16
    /// FrmAbsenceRegisterDetail form
    /// </summary>
    public partial class FrmAbsenceRegisterDetail : FrmBaseDetail
    {
        #region Constants

        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_ABSENCE;
        public const int DEFAULT_VALUE = -1;

        #endregion

        #region Variable

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isExistCancel;

        #endregion

        #region Property

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }
             
        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set VacationType
        /// </summary>
        public int AbsenceType
        {
            get { return (int)ViewState["AbsenceType"]; }
            set { ViewState["AbsenceType"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }

        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Absence";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtEmployeeCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtReason.MaxLength = T_Work_Absence.REASON_MAX_LENGTH;
            this.txtReasonCancel.MaxLength = T_Work_Absence.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        this.ApplyStatus = (int)StatusApply.Draft;

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_Absence data = this.GetAbsenceByID(this.DataID);

                        ////Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data, false);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }

                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Checked change chkisAgent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {
            if (this.chkIsAgent.Checked)
            {
                this.CheckAuthority(string.Empty);
                this.txtEmployeeCD.SetReadOnly(false);
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.hdnDepartmentID.Value = LoginInfo.Department.ID.ToString();
                this.hdnUserID.Value = string.Empty;
                this.SetRestTimeTableHeader(this.LoginInfo.User.ID);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
                this.SetEmployeeInfo(this.LoginInfo.User.ID);
                this.SetRestTimeTableHeader(this.LoginInfo.User.ID);
                this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            }
          
        }

        /// <summary>
        /// Click btnSeachUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUser_Click(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.RestoreListApprove();
            if (!this.PreApplyID.HasValue)
            {
                ////Check input
                if (!this.CheckInput())
                {
                    return;
                }
            }
            else
            {
                //Check input mode cancel
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Data
            T_Work_Absence data = this.GetAbsenceByID(this.DataID);

            //Check data
            if (data != null)
            {
                this.RestoreListApprove();
              
                //Show data
                this.ShowData(data, true);

                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Update;
            this.RestoreListApprove();
            if (this.PreApplyID.HasValue)
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }
            }
            else
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Delete;
            T_Work_Absence apply = this.GetAbsenceByID(this.DataID);
            if (apply != null)
            {
                this.RestoreListApprove();
                this.ProcessMode(Mode.Delete);
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Confirm;

            T_Work_Absence abs = this.GetAbsenceByID(this.DataID);
            if (abs != null)
            {
                this.RestoreListApprove();

                if (!this.PreApplyID.HasValue)
                {
                    //Employee Code
                    if (!this.CheckInput(true))
                    {
                        return;
                    }
                }
                else
                {
                    //Check ngay thang co nam trong thang da ket so ko
                    if (this.CheckExistingDateInWorkTotal())
                    {
                        this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_CONTINUE, this.datAbsenceDtFrm.Value.Value.ToString(Constants.FMT_DATE));
                        return;
                    }
                }
                //Set Mode
                this.ProcessMode(Mode.Confirm);

                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Cancel;
            T_Work_Absence abs = this.GetAbsenceByID(this.DataID);
            if (abs != null)
            {
                this.txtReasonCancel.Value = string.Empty;
                this.ApplyStatus = (int)StatusApply.Cancel;
                this.ShowData(abs, false);
                this.PreApplyID = abs.ID;
                this.hdnPreApplyID.Value = this.PreApplyID.ToString();
                this.btnViewPreAbsence.Text = abs.No;
                this.ProcessMode(Mode.Cancel);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelApply_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Cancel;
            this.RestoreListApprove();
            //Check input mode cancel
            if (!this.CheckInputForCancel())
            {
                return;
            }

            if (this.IsExistCancel())
            {   
                base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
            }
            else
            {
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.View;
            //Get User
            T_Work_Absence data = this.GetAbsenceByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data, false);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// cmbRoute OnSelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbRoute_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int routeID = int.Parse(this.cmbRoute.SelectedValue);
            this.SetValueForHiddenProxy(routeID);
            this.LoadDataForApproveListFromRoute(routeID);
           // this.FillDataApproverByRouteID(routeID);
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            T_Work_Absence data = null;

            //Check Mode
            switch (this.Mode)
            {
                case Mode.Insert:
                case Mode.Copy:

                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get 
                        data = this.GetAbsenceByID(this.DataID);

                        //Show data
                        this.ShowData(data, false);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        if (this.cmbRoute.Items.Count > 0)
                        {
                            this.LoadDataForApproveListFromRoute(int.Parse(this.cmbRoute.SelectedValue));
                        }
                    }
                    break;

                case Mode.Delete:

                    //Delete 
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Update:

                    //Update Data
                    ret = this.UpdateData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetAbsenceByID(this.DataID);

                        //Show data
                        this.ShowData(data, false);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                    }

                    break;
                case Mode.Confirm:
                    //Update Data

                    ret = this.Confirm();
                    if (ret)
                    {
                        //Get User
                        data = this.GetAbsenceByID(this.DataID);

                        //Show data
                        this.ShowData(data, true);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Mode.Cancel:
                    //Insert Data
                    ret = this.InsertData();
                    if (ret)
                    {
                        //Get User
                        data = this.GetAbsenceByID(this.DataID);

                        //Show data
                        this.ShowData(data, false);//?????????????

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Absence abs = this.GetAbsenceByID(this.DataID);
            if (abs != null)
            {
                //Show data
                this.ShowData(abs, false);
                this.ProcessMode(Mode.View);
            }

            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }
        
        #endregion

        #region Method

        #region Init data

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.hdnFormIDDefault.Value = LEAVE_TEMPLATE.ToString();
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();
            this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.SetDataForDayOffTypeCbo((int)ShiftType.PaidVacation);
            this.SetEmployeeInfo(this.LoginInfo.User.ID);
            this.datAbsenceDtFrm.Value = DateTime.Now;
            this.datAbsenceDtTo.Value = DateTime.Now;
            this.SetRestTimeTableHeader(this.LoginInfo.User.ID);
            this.DataID = DEFAULT_VALUE;
            this.PreApplyID = null;
            this.btnViewPreAbsence.Text = string.Empty;
        }

        #endregion

        #region Check data

        /// <summary>
        /// IsExistCancel
        /// </summary>
        /// <returns></returns>
        private bool IsExistCancel()
        {
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkAbsenceService appSer = new WorkAbsenceService(db);

                if (ViewState["DataID"] != null)
                {
                    T_Work_Absence abs = appSer.GetByPreApplyID(this.DataID);
                    if (abs != null)
                    {
                        return true;
                    }
                }
                return false;
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="focusID"></param>
        /// <returns></returns>
        private bool CheckAuthority(string focusID)
        {
            if (this.chkIsAgent.Checked)//dang xin gium ngkhac
            {
                int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
                if (routeD != null)
                {
                    // proxy all
                    if (routeD.ApplyFlag1 != 1 && routeD.ApplyFlag2 != 1)//ko co quyen xin cho ngkhac
                    {
                        this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                    }

                    // proxy dept
                    if (routeD.ApplyFlag2 == 1)
                    {
                        using (DB db = new DB())
                        {
                            StaffService staffSer = new StaffService(db);
                            M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                            if (s != null)
                            {
                                if (s.DepartmentID != this.LoginInfo.Department.ID)
                                {
                                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                                }
                            }
                        }
                    }
                }
                else//ko co quyen xin gium ngkhac
                {
                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check inputing
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(bool isConfirm=false)
        {
            string focusID = this.Mode == Mode.Update ? this.datAbsenceDtFrm.ID : this.txtEmployeeCD.ID;
            int UserID = this.LoginInfo.User.ID;
            int dayOffType = int.Parse(this.hdnDayOffType.Value.ToString());

            #region Check requirement

            if (!isConfirm)
            {
                if (this.chkIsAgent.Checked)
                {
                    if (this.txtEmployeeCD.IsEmpty)
                    {
                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_REQUIRE, "Applicant");
                    }
                    else
                    {
                        M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
                        if (s == null)
                        {
                            this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Applicant");
                        }
                    }
                }

                //Absence Date From
                if (!this.datAbsenceDtFrm.Value.HasValue)
                {
                    this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_REQUIRE, "Effect Date From");
                }
                               
                if (dayOffType == (int)VacationType.DayOff)
                {
                    //Absence Date To
                    if (!this.datAbsenceDtTo.Value.HasValue)
                    {
                        this.SetMessage(this.datAbsenceDtTo.ID, M_Message.MSG_REQUIRE, "Effect Date To");
                    }

                    //compare 2 date
                    if (this.datAbsenceDtFrm.Value.HasValue && this.datAbsenceDtTo.Value.HasValue)
                    {
                        if (this.datAbsenceDtTo.Value.Value < this.datAbsenceDtFrm.Value.Value)
                        {
                            this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_LESS_THAN_EQUAL, "Effect Date From", "Effect Date To");
                        }
                    }
                }

                //Reason
                if (this.txtReason.IsEmpty)
                {
                    this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Apply Reason");
                }

                //Reason cancel
                if (this.PreApplyID.HasValue)
                {
                    if (this.txtReasonCancel.IsEmpty)
                    {
                        this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Cancel Reason");
                    }
                }
            }

            //route
            if (this.cmbRoute.Items.Count == 0)
            {
                this.SetMessage(isConfirm ? string.Empty : this.cmbRoute.ID, M_Message.MSG_PLEASE_SELECT, "Approval Route");
            }

            #endregion

            #region Check Invalid

            //ko co loi require, check du lieu hop le
            if (!base.HaveError)
            {
                //Check data of workday
                bool isError = false;
                //Check co quyen xin gium ngkhac ko
                if (!this.CheckAuthority(isConfirm ? string.Empty : this.txtEmployeeCD.ID))//ko co quyen
                {
                    isError = true;
                }

                //check employee hop le
                if (this.chkIsAgent.Checked)
                {
                    int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                    M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
                    if (!this.CheckEmployee(routeD, isConfirm ? string.Empty : this.txtEmployeeCD.ID))
                    {
                        isError = true;
                    }
                }

                //Check existing of day off in WorkDay

                if (!this.IsExistDateInWorkDay(this.datAbsenceDtFrm))
                {
                    isError = true;
                    this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtFrm.ID, M_Message.MSG_CONTACT_MANAGER);
                }

                //Check existing of day off in WorkDay
                if (dayOffType == (int)VacationType.DayOff)
                {
                    if (!this.IsExistDateInWorkDay(this.datAbsenceDtTo))
                    {
                        isError = true;
                        this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtTo.ID, M_Message.MSG_CONTACT_MANAGER);
                    }
                }

                if (!isError)//ko co loi o tren
                {
                    isError = false;

                    //Check absence days in holidays   
                    decimal days = 0;
                    if (this.datAbsenceDtFrm.Value.HasValue)
                    {
                        days = this.GetUsingNumberDays(this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtFrm.Value.Value);
                    }
                    if (days == decimal.Zero)
                    {
                        this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                    }
                    else
                    {
                        if (dayOffType == (int)VacationType.DayOff)
                        {

                            decimal numberOfDayOff = this.GetUsingNumberDays(this.datAbsenceDtTo.Value.Value, this.datAbsenceDtTo.Value.Value);
                            if (numberOfDayOff == decimal.Zero)
                            {
                                this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtTo.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                            }
                            if (!isError)//ngay bat dau, ngay ket thuc ko trung ngay nghi
                            {
                                //Check vacation in holidays date from -> to
                                if (this.GetUsingNumberDays(this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtTo.Value.Value) == decimal.Zero)
                                {
                                    this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                                }
                            }
                        }
                        else if (dayOffType == (int)VacationType.MorningOff || dayOffType == (int)VacationType.AfternoonOff)
                        {
                            AccountingPeriod accTime = this.GetTimeByVacationType(dayOffType, this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtFrm.Value.Value);
                            using (DB db = new DB())
                            {
                                WorkShiftService wrkSSer = new WorkShiftService(db);
                                M_Work_Shift wkShf = wrkSSer.GetByDate(this.datAbsenceDtFrm.Value.Value);
                                if (wkShf != null && accTime != null)
                                {
                                    if (wkShf.TypeOfDay == (int)TypeOfDay.HalfWorkDay)
                                    {
                                        //xin nghi phep vao ngay lam nua ngay va xin vao buoi ko lam viec
                                        // if (wShift.StartHour > wkShf.StartHour || wShift.EndHour < wkShf.EndHour)
                                        if (accTime.StartDate.Hour != wkShf.StartHour && accTime.EndDate.Hour != wkShf.EndHour)
                                        {
                                            isError = true;
                                            this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            //Check existing of Effect Date in T_Work_Total
            if (!base.HaveError)
            {
                if (this.CheckExistingDateInWorkTotal())
                {
                    this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_CONTINUE, this.datAbsenceDtFrm.Value.Value.ToString(Constants.FMT_DATE));
                }
            }

            #endregion
          
            if (this.ApproverList != null && this.ApproverList.Count == 0)
            {
                this.SetMessage(string.Empty, M_Message.MSG_LIST_APPROVE_NOT_EXIST);
            }

            //Check duplication of leaving times
            if (!base.HaveError && this.CheckDuplicationOfTimes(this.DataNo ,dayOffType))
            {
                this.SetMessage(isConfirm ? string.Empty : this.datAbsenceDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
            }

            return !base.HaveError;
        }

        /// <summary>
        /// GetTimeByVacationType
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private AccountingPeriod GetTimeByVacationType(int type, DateTime startDt, DateTime endDt)
        {
            AccountingPeriod ret = new AccountingPeriod();
            string value3 = string.Empty;
            using (DB db = new DB())
            {
                Config_DService ser = new Config_DService(db);
                value3 = ser.GetValue3(M_Config_H.CONFIG_CD_VACATION_TYPE, type);
            }
            var lstVal = new List<string>(value3.Split('-'));
            if (lstVal.Count == 2)
            {
                string startDateStr = lstVal[0].Trim();
                string endDateStr = lstVal[1].Trim();
                var lstStart = new List<string>(startDateStr.Split(':'));
                int startHour = 0;
                int startMin = 0;
                if (lstStart.Count == 2 && int.TryParse(lstStart[0], out startHour) && int.TryParse(lstStart[1], out startMin))
                {
                    ret.StartDate = new DateTime(startDt.Year, startDt.Month, startDt.Day, startHour, startMin, 0);
                }

                var lstEnd = new List<string>(endDateStr.Split(':'));
                int endHour = 0;
                int endMin = 0;
                if (lstEnd.Count == 2 && int.TryParse(lstEnd[0], out endHour) && int.TryParse(lstEnd[1], out endMin))
                {
                    ret.EndDate = new DateTime(endDt.Year, endDt.Month, endDt.Day, endHour, endMin, 0);
                }
            }
            if (type == (int)VacationType.DayOff && startDt == endDt)
            {
                M_Work_Shift wrkShift = null;
                using (DB db = new DB())
                {
                    WorkShiftService wkSer = new WorkShiftService(db);
                    wrkShift = wkSer.GetByDate(startDt);
                }
                if (wrkShift != null)
                {
                    if (wrkShift.TypeOfDay == (int)TypeOfDay.HalfWorkDay)//Lam viec nua ngay
                    {
                        ret.EndDate = new DateTime(endDt.Year, endDt.Month, endDt.Day, wrkShift.EndHour.Value, wrkShift.EndMinute.Value, 0);
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Check existing of date in T_Work_Total
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="effectDateFrm"></param>
        /// <param name="effectDateTo"></param>
        /// <returns></returns>
        private bool IsExistingDateInWorkTotal(int userID,DateTime effectDateFrm, DateTime effectDateTo)
        {
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkTotalService totalSer = new WorkTotalService(db);
                IList<T_Work_Total> totalList = totalSer.GetByCond(userID, effectDateFrm, effectDateTo);
                return totalList != null && totalList.Count > 0;
            }
           
        }

        /// <summary>
        /// Check existing date in T_Work_Total
        /// </summary>
        /// <returns></returns>
        public bool CheckExistingDateInWorkTotal()
        {
            bool isExist = false;
            int dayOffType = int.Parse(this.hdnDayOffType.Value.ToString());
            if (dayOffType == (int)TypeOfDay.HalfDayOff)
            {
                isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtFrm.Value.Value);
            }
            else if (dayOffType == (int)TypeOfDay.DayOff)
            {
                isExist = this.IsExistingDateInWorkTotal(int.Parse(this.hdnUserID.Value), this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtTo.Value.Value);
            }
            return isExist;
        }
        
        /// <summary>
        /// Check Employee(Check du lieu cua nguoi dc xin gium hop le)
        /// </summary>
        /// <returns></returns>
        private bool CheckEmployee(M_Route_D routeD, string focusID)
        {
            if (routeD != null)
            {
                //Check employee's department is the same department with login user
                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                    if (s != null)
                    {
                        //luon luon check trong cung 1 route(ko can ApplyFlag1)
                        if (this.IsSameRoute(this.LoginInfo.User.UserCD, this.GetUserInfoByID(s.UserID).UserCD))//cung route
                        {
                            //Gioi han trong pham vi dept.
                            if (routeD.ApplyFlag2 == 1)
                            {
                                if (!s.DepartmentID.Equals(this.LoginInfo.Department.ID))//khac dept. --> loi
                                {
                                    this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                                }
                            }
                        }
                        else//ko cung route --> loi
                        {
                            this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                        }

                    }
                    else
                    {
                        this.SetMessage(focusID, M_Message.MSG_VALUE_NOT_EXIST, "Applicant");
                    }
                }
            }
            return !base.HaveError;
        }


        /// <summary>
        /// Check duplication of times
        /// </summary>
        /// <returns></returns>
        private bool CheckDuplicationOfTimes(string appNo, int dayOffType)
        {
            //using (DB db = new DB())
            //{
            //    WorkApplyTimeService appTimeSer = new WorkApplyTimeService(db);

            bool isDuplicate = false;

            if (!string.IsNullOrEmpty(this.hdnUserID.Value) && this.cmbDayOffType.SelectedValue != null)
            {
                /*DateTime startDate = this.datAbsenceDtFrm.Value.Value;
                DateTime endDate = startDate;
                DateTime startTime = this.datAbsenceDtFrm.Value.Value;
                DateTime endTime = startTime;
                int userID = int.Parse(this.hdnUserID.Value);

                endDate = startDate;
                endTime = startTime;
                if (dayOffType == (int)VacationType.DayOff)
                {
                    endDate = this.datAbsenceDtTo.Value.Value;
                }

                int shiftID = int.Parse(this.cmbDayOffType.SelectedValue.ToString());
                this.GetTimeByShiftID(db, shiftID, startDate, endDate, ref startTime, ref endTime);
                isDuplicate = appTimeSer.IsDuplicateTimeApply(this.DataNo, userID, startTime, endTime);
                */
                
                int userID = int.Parse(this.hdnUserID.Value);
                DateTime fromDtSc = this.datAbsenceDtFrm.Value.Value;
                DateTime fromDtDB = this.datAbsenceDtFrm.Value.Value;
                DateTime toDtSc = fromDtSc;
                DateTime toDtDB = fromDtDB;

                if (dayOffType == (int)VacationType.DayOff)
                {
                    toDtSc = this.datAbsenceDtTo.Value.Value;
                }

                AccountingPeriod accTime = this.GetTimeByVacationType(dayOffType, fromDtSc, toDtSc);
                if (accTime != null)
                {
                    fromDtDB = new DateTime(fromDtSc.Year, fromDtSc.Month, fromDtSc.Day, accTime.StartDate.Hour, accTime.StartDate.Minute, 0);
                    toDtDB = new DateTime(toDtSc.Year, toDtSc.Month, toDtSc.Day, accTime.EndDate.Hour, accTime.EndDate.Minute, 0);
                }
                using (DB db = new DB())
                {
                    WorkApplyTimeService wrkSer = new WorkApplyTimeService(db);
                    isDuplicate = wrkSer.IsDuplicateTimeApply(appNo, userID, fromDtDB, toDtDB);
                }
            }
            return isDuplicate;
        }

        /// <summary>
        /// Check inputing for cancel mode
        /// </summary>
        /// <returns></returns>
        private bool CheckInputForCancel()
        {
            //Reason cancel

            if (this.txtReasonCancel.IsEmpty)
            {
                this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Cancel Reason");
            }

            //Check existing of Effect Date in T_Work_Total
            if (!base.HaveError)
            {
                if (this.CheckExistingDateInWorkTotal())
                {
                    this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_CANT_CONTINUE, this.datAbsenceDtFrm.Value.Value.ToString(Constants.FMT_DATE));
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public bool IsHasData()
        {
            return (this.ApproverList != null && this.ApproverList.Count > 0);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        private bool IsHolidays(DateTime date)
        {
            using (DB db = new DB())
            {
                HolidayService holidaySer = new HolidayService(db);
                return holidaySer.GetByDay(date) != null;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="absenceDate"></param>
        private bool IsExistDateInWorkDay(IDateTextBox txtAbsenceDt)
        {
            bool ret = true;
            if (txtAbsenceDt.Value.HasValue)
            {
                using (DB db = new DB())
                {
                    WorkDayService workDaySer = new WorkDayService(db);
                    M_Work_Day workDay = workDaySer.GetByWorkDate(txtAbsenceDt.Value.Value);
                    if (workDay == null)
                    {
                        ret = false;
                    }
                }

            }

            return ret;
        }

        /// <summary>
        /// check SameRoute of 2 userCD
        /// </summary>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        private bool IsSameRoute(string userCD1, string userCD2)
        {
            IList<M_Route_H> lstRet = this.GetListRouteByUserCD(userCD1, userCD2);
            if (lstRet != null && lstRet.Count > 0)
            {
                return true;
            }
            return false;
        }


        #endregion

    
        #endregion
        
        #region Get

        /// <summary>
        /// GetByApplyNo
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="appNo">Apply No</param>
        /// <returns></returns>
        private T_Work_Absence GetByApplyNo(string appNo)
        {
            using (DB db = new DB())
            {
                T_Work_Absence abs = new T_Work_Absence();
                WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                abs = absenceSer.GetByApplyNo(appNo);
                return abs;
            }
        }

        /// <summary>
        /// GetListRouteByUserCD
        /// </summary>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        private IList<M_Route_H> GetListRouteByUserCD(string userCD1, string userCD2)
        {
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                return routeSer.GetListRouteBy2UserCD(LEAVE_TEMPLATE, userCD1, userCD2);
            }
        }

        /// <summary>
        /// GetTimeByShiftID
        /// </summary>
        /// <param name="db"></param>
        /// <param name="shiftID"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="startTime"></param>
        /// <param name="endTime"></param>
        private void GetTimeByShiftID(DB db, int shiftID, DateTime startDate, DateTime endDate, ref DateTime startTime, ref DateTime endTime)
        {//--------------ISV-HUNG 2015/07/02 Add param DB to method----------//
            WorkShiftService shiftSer = new WorkShiftService(db);
            M_Work_Shift shift = shiftSer.GetByID(shiftID);
            startTime = startDate;
            endTime = endDate;

            if (shift != null)
            { 
                if(shift.StartHour!=null && shift.StartMinute!=null)
                {
                    startTime = startTime.AddHours(shift.StartHour.Value).AddMinutes(shift.StartMinute.Value);    
                }

                if (shift.EndHour != null && shift.EndMinute != null)
                {
                    endTime = endTime.AddHours(shift.EndHour.Value).AddMinutes(shift.EndMinute.Value);
                }
            }
        }

        /// <summary>
        /// GetDurationDays By date range
        /// </summary>
        /// <param name="start"></param>
        /// <param name="end"></param>
        /// <returns></returns>
        private decimal GetUsingNumberDays(DateTime start, DateTime end)
        {
            using (DB db = new DB())
            {
                WorkVacationService ser = new WorkVacationService(db);
                return ser.GetNumberOfDaysByRangeDate(start, end);
            }
        }

        /// <summary>
        /// GetUserInfoByID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_UserInfo GetUserInfoByID(int userID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetUserInfoByID(userID);
            }
        }

        /// <summary>
        /// GetUserByStaffID
        /// </summary>
        /// <param name="staffID"></param>
        /// <returns></returns>
        private M_User GetUserByStaffID(int staffID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByStaffID(staffID);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_Staff GetStaffByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetByStaffCD(staffCD);
            }
        }

        /// <summary>
        /// GetRouteByUserID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_Route_H GetRouteByUserID(int userID)
        {
            using (DB db = new DB())
            {
                Route_HService service = new Route_HService(db);
                return service.GetByTypeAndUserIDForWork(LEAVE_TEMPLATE, userID);
            }
        }

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="absenceID"></param>
        /// <returns></returns>
        private T_Work_Absence GetAbsenceByID(int absenceID)
        {
            T_Work_Absence abs = new T_Work_Absence();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                abs = absenceSer.GetByID(absenceID);
                return abs;
            }
        }

        /// <summary>
        /// GetStaffInfoByStaffCD
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// GetRouteLevelZeroByRouteID
        /// </summary>
        /// <param name="RouteID"></param>
        /// <returns></returns>
        private M_Route_D GetRouteLevelZeroByRouteID(int RouteID)
        {
            using (DB db = new DB())
            {
                Route_DService routeSer = new Route_DService(db);
                var lstItem = routeSer.GetByRouteIDForWork(RouteID, isGetLVZero: EnumGetLevelZero.Only);
                if (lstItem != null && lstItem.Count > 0)
                {
                    return lstItem[0];
                }
            }
            return null;
        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproverFromApply(string absNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.DataNo, isIncludeView, includeZeroLV);
            }
        }

        /// <summary>
        /// TRAM - 2015/05/28
        /// Get list Email
        /// </summary>
        /// <returns>List of email</returns>
        private IList<string> GetListEmail()
        {
            IList<string> lstEmail = new List<string>();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                IList<WorkApproveModel> applicantInfoList = approveSer.GetListByIDOptionLevel(this.DataNo, false, EnumGetLevelZero.Only);
                if (applicantInfoList != null && applicantInfoList.Count > 0)
                {
                    if (applicantInfoList[0].GetApplySetting(ApplySetting.MailAll))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(this.DataNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.GreaterLevel);
                        return lstEmail;
                    }
                    else if (applicantInfoList[0].GetApplySetting(ApplySetting.Mail))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(this.DataNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.NextLevel);
                    }
                }
                return lstEmail;
            }
        }
        
        /// <summary>
        /// Get list of approver
        /// </summary>
        /// <param name="TypeID"></param>
        /// <param name="isIncludeView">true: include level 99, false:exclude level 99</param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprover(DB db, int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            //Custom again
            IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
            Route_DService service = new Route_DService(db);
            approveUserList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
            return approveUserList;
           
        }

        #endregion

        #region Set data

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="isConfirmed">true: Load List Approver from approve list, false: from route</param>
        /// <param name="isGetDaysVacID">is Get Days by VacID</param>
        private void ShowData(T_Work_Absence abs, bool isGetDaysAbsID = false)
        {
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();

            //Show data
            if (abs != null)
            {
                //Re-Init value for combobox Route
                this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, abs.UserID);

                int absenceID = DEFAULT_VALUE;
                if (isGetDaysAbsID)
                {
                    absenceID = abs.ID;
                }

                this.txtApplyNo.Value = abs.No;
                this.dtApplyDate.Value = abs.ApplyDate;
                this.hdnPreApplyID.Value = abs.PreApplyID.ToString();
                if (abs.UserID.Equals(abs.CreateUID) || abs.UserID == this.LoginInfo.User.ID)
                {
                    this.chkIsAgent.Checked = false;
                }
                else
                {
                    this.chkIsAgent.Checked = true;
                }
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                M_StaffInfo staff = new M_StaffInfo();
               // M_Work_Shift workShift = new M_Work_Shift();
                T_Work_Absence preAbs = new T_Work_Absence();
                M_User createUser = new M_User();
                M_User updateUser = new M_User();

                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    staff = staffSer.GetStaffInfoByUserID(abs.UserID);
                    //ISV-TRUC Start 2015/07/16
                    //WorkShiftService shiftSer = new WorkShiftService(db);
                    //workShift = shiftSer.GetByID(int.Parse(this.cmbDayOffType.SelectedValue));
                    //ISV-TRUC END 2015/07/16
                    
                    UserService userSer = new UserService(db);
                    createUser = userSer.GetByID(abs.CreateUID);
                    updateUser = userSer.GetByID(abs.UpdateUID);

                }

                if (staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = staff.StaffName;
                    this.txtPosition.Value = staff.Position;
                    this.hdnDepartmentID.Value = staff.DepartmentID.ToString();
                    this.hdnUserID.Value = staff.UserID.ToString();
                    this.txtDepartment.Value = staff.DepartmentName;
                    this.SetRestTimeTableHeader(abs.UserID);
                }
                //ISV-TRUC Start 2015/07/16
                //if (workShift != null)
                //{
                //    this.hdnDayOffType.Value = workShift.TypeOfDay.ToString();
                //}
                this.hdnDayOffType.Value = abs.AbsenceType.ToString();
                //ISV-TRUC END 2015/07/16
                this.hdnRouteID.Value = abs.RouteID.ToString();
                this.cmbRoute.SelectedValue = abs.RouteID.ToString();
                this.cmbDayOffType.SelectedValue = abs.AbsenceType.ToString();
                this.txtTotalDays.Value = abs.Duration.Value.ToString("N1");
                this.DataID = abs.ID;
                this.DataNo = abs.No;
                this.datAbsenceDtFrm.Value = abs.StartDate;
                this.datAbsenceDtTo.Value = abs.EndDate;
                this.ApplyStatus = abs.ApplyStatus;
                this.PreApplyID = abs.PreApplyID;
                this.AbsenceType = abs.AbsenceType;

                if (this.PreApplyID.HasValue)
                {
                    using (DB db = new DB())
                    {
                        WorkAbsenceService ser = new WorkAbsenceService(db);
                        preAbs = ser.GetByID(this.PreApplyID.Value);

                        if (preAbs != null)
                        {
                            this.btnViewPreAbsence.Text = preAbs.No;
                            this.txtReason.Value = preAbs.Reason;
                            this.txtReasonCancel.Value = abs.Reason;
                        }
                    }
                }
                else
                {
                    this.txtReason.Value = abs.Reason;
                }

                if (createUser != null)
                {
                    var createDate = (abs.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }

                if (updateUser != null)
                {
                    var updateDate = (abs.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }

                this.isExistCancel = this.IsExistCancel();
                this.OldUpdateDate = abs.UpdateDate;
                if (this.ApplyStatus == (int)StatusApply.Draft || this.Mode==Mode.Cancel)//this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    this.LoadDataForApproveListFromRoute(abs.RouteID);
                }
                else
                {
                    this.LoadDataForApproveListFromApproveList(abs.No, true);
                }

                if (this.cmbRoute.SelectedValue != null)
                {
                    this.SetValueForHiddenProxy(int.Parse(this.cmbRoute.SelectedValue));
                }
            }
        }

        /// <summary>
        /// Set rest time table
        /// </summary>
        private void SetRestTimeTableHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting acc = accSer.GetData();
                if (acc != null)
                {
                    lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
                }
            }
            this.rptRestTimeHeader.DataSource = lstMonth;
            this.rptRestTimeHeader.DataBind();
            this.SetDataForRestTimeTable(lstMonth, userID);
        }

        /// <summary>
        /// Init Times Value
        /// </summary>
        private void SetDataForRestTimeTable(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();
                foreach (var item in lstMonth)
                {
                    using (DB db = new DB())
                    {
                        AccountingService accSer = new AccountingService(db);
                        M_Accounting data = accSer.GetData();
                        if (data != null)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkAbsenceService absSer = new WorkAbsenceService(db);
                            decimal usedDay = absSer.GetUsedDaysInMonth(userID, period);
                            lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                        }
                    }
                }

                this.rptRestTimeContent.DataSource = lstMonthVal;
                this.rptRestTimeContent.DataBind();
            }
        }

        /// <summary>
        /// Set employee info
        /// </summary>
        /// <param name="userID"></param>
        private void SetEmployeeInfo(int userID)
        {

            M_UserInfo u = this.GetUserInfoByID(userID);
            if (u != null)
            {
                M_Route_H item = this.GetRouteByUserID(u.ID);
                if (item != null)
                {
                    this.hdnRouteID.Value = item.ID.ToString();
                }
                this.hdnUserID.Value = u.ID.ToString();
                M_Staff s;
                string position = string.Empty;
                string deptNm = string.Empty;
                using (DB db = new DB())
                {
                    WorkAbsenceService applySer = new WorkAbsenceService(db);
                    StaffService staffSer = new StaffService(db);
                    s = staffSer.GetByID(u.StaffID);
                    if (s != null)
                    {
                        Config_DService conDSer = new Config_DService(db);
                        position = conDSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                    }
                    deptNm = u.DepartmentName;
                    this.hdnDepartmentID.Value = u.DepartmentID.ToString();
                }

                if (s != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = s.StaffName;
                    this.txtDepartment.Value = deptNm;
                    this.txtPosition.Value = position;
                }
            }
            else
            {
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
            }
        }

        /// <summary>
        /// Disable buttons when data is empty
        /// </summary>
        private void DisableButtonDataEmpty()
        {
            if (this.cmbRoute.Items.Count == 0 || this.ApproverList == null || (this.ApproverList != null && this.ApproverList.Count == 0))
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    base.DisabledLink(this.btnInsert, true);
                }
                else if (this.Mode == Mode.Update)
                {
                    base.DisabledLink(this.btnUpdate, true);
                }
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    base.DisabledLink(this.btnInsert, false);
                }
                else if (this.Mode == Mode.Update)
                {
                    base.DisabledLink(this.btnUpdate, false);
                }
            }
        }

        /// <summary>
        /// Clear update info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        /// <summary>
        /// Create data for ApplyApproveList 
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="lstApproveUser"></param>
        private IList<T_Work_Approve> CreateApplyApproveListData(T_Work_Absence apply, IList<WorkApproveModel> approverList)
        {
            IList<T_Work_Approve> approveList = new List<T_Work_Approve>();
            foreach (WorkApproveModel item in approverList)
            {
                T_Work_Approve model = new T_Work_Approve();
                Hashtable htbUserID = new Hashtable();
                model.ApplyNo = apply.No;
                if (item.RouteLevel == M_Route_H.LEVEL_APPLICANT)
                {
                    model.RouteUID = apply.UserID;
                }
                else
                {
                    model.RouteUID = item.RouteUID;
                }
                model.RouteLevel = item.RouteLevel.Value;
                model.RouteMethod = item.RouteMethod.Value;
                // model.ApproveStatus = item.ApproveStatus;
                model.ApproveUID = item.ApproveUID;
                model.ApproveDate = item.ApproveDate;
                model.ApproveReason = item.ApproveReason;
                model.RequireNum = item.RequireNum;
                model.ApproveStatus = (int)StatusHasAprove.New;

                model.ProxyApprovalUser = item.ProxyApprovalUser;
                //Apply Flag
                model.ApplyFlag1 = item.ApplyFlag1;
                model.ApplyFlag2 = item.ApplyFlag2;
                model.ApplyFlag3 = item.ApplyFlag3;
                model.ApplyFlag4 = item.ApplyFlag4;

                //Reject Flag
                model.RejectFlag1 = item.RejectFlag1;
                model.RejectFlag2 = item.RejectFlag2;
                model.RejectFlag3 = item.RejectFlag3;
                model.RejectFlag4 = item.RejectFlag4;
                model.RejectFlag5 = item.RejectFlag5;
                model.RejectFlag6 = item.RejectFlag6;
                model.RejectFlag7 = item.RejectFlag7;

                //Remand Flag
                model.RemandFlag1 = item.RemandFlag1;
                model.RemandFlag2 = item.RemandFlag2;
                model.RemandFlag3 = item.RemandFlag3;
                model.RemandFlag4 = item.RemandFlag4;
                model.RemandFlag5 = item.RemandFlag5;
                model.RemandFlag6 = item.RemandFlag6;
                model.RemandFlag7 = item.RemandFlag7;

                //Approve Flag
                model.ApproveFlag1 = item.ApproveFlag1;
                model.ApproveFlag2 = item.ApproveFlag2;
                model.ApproveFlag3 = item.ApproveFlag3;
                model.ApproveFlag4 = item.ApproveFlag4;
                model.ApproveFlag5 = item.ApproveFlag5;
                model.ApproveFlag6 = item.ApproveFlag6;
                model.ApproveFlag7 = item.ApproveFlag7;
                model.ApproveFlag8 = item.ApproveFlag8;
                model.ApproveFlag9 = item.ApproveFlag9;

                //Read Flag
                model.ReadFlag1 = item.ReadFlag1;
                model.ReadFlag2 = item.ReadFlag2;
                model.ReadFlag3 = item.ReadFlag3;
                model.ReadFlag4 = item.ReadFlag4;
                model.ReadFlag5 = item.ReadFlag5;

                approveList.Add(model);
            }

            return approveList;

        }

        /// <summary>
        /// Create ApplyTime model
        /// </summary>
        /// <param name="workAbsence">T_Work_Absence</param>
        /// <returns></returns>
        private T_Work_ApplyTime CreateApplyTimeModel(T_Work_Absence workAbsence)
        {
            T_Work_ApplyTime appTime = new T_Work_ApplyTime();
            appTime.ApplyNo = workAbsence.No;
            appTime.UserID = workAbsence.UserID;
            DateTime start = DateTime.MinValue;
            DateTime end = DateTime.MinValue;
            AccountingPeriod acc = this.GetTimeByVacationType(workAbsence.AbsenceType, workAbsence.StartDate, workAbsence.EndDate);
            if (acc != null)
            {
                start = new DateTime(workAbsence.StartDate.Year, workAbsence.StartDate.Month, workAbsence.StartDate.Day, acc.StartDate.Hour, acc.StartDate.Minute, 0);
                end = new DateTime(workAbsence.EndDate.Year, workAbsence.EndDate.Month, workAbsence.EndDate.Day, acc.EndDate.Hour, acc.EndDate.Minute, 0);
            }
            appTime.StartTime = start;
            appTime.EndTime = end;
            return appTime;
        }

        /// <summary>
        /// Create Absence data
        /// </summary>
        /// <param name="db">DB</param>
        /// <param name="appNo">Apply No</param>
        /// <param name="isCancel">Is Cancel</param>
        /// <returns></returns>
        private T_Work_Absence CreateAbsenceData(string appNo, bool isCancel = false)
        {
            T_Work_Absence abs = this.GetByApplyNo(appNo);
            if (abs == null)
            {
                abs = new T_Work_Absence();
            }
            abs.ApplyDate = null;
            abs.No = appNo;
            abs.ApplyStatus = (int)StatusApply.Draft;

            if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
            {
                abs.PreApplyID = null;
            }
            else if (this.Mode == Mode.Cancel)
            {
                abs.PreApplyID = this.PreApplyID;
            }

            if (this.chkIsAgent.Checked)
            {
                M_StaffInfo staff = this.GetStaffInfoByCD(this.txtEmployeeCD.Value.Trim());
                if (staff != null)
                {
                    abs.UserID = staff.UserID;
                }
            }
            else
            {
                abs.UserID = LoginInfo.User.ID;
            }

            if (this.cmbRoute.Items.Count > 0)
            {
                abs.RouteID = int.Parse(this.cmbRoute.SelectedValue);
            }
            abs.AbsenceType = int.Parse(this.cmbDayOffType.SelectedValue.ToString());

            switch (abs.AbsenceType)
            {
                case (int)VacationType.DayOff:
                    abs.StartDate = this.datAbsenceDtFrm.Value.Value;
                    abs.EndDate = this.datAbsenceDtTo.Value.Value;
                    abs.Duration = this.GetUsingNumberDays(this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtTo.Value.Value);
                    break;
                case (int)VacationType.MorningOff:
                case (int)VacationType.AfternoonOff:
                    abs.StartDate = this.datAbsenceDtFrm.Value.Value;
                    abs.EndDate = abs.StartDate;
                    decimal days = this.GetUsingNumberDays(this.datAbsenceDtFrm.Value.Value, this.datAbsenceDtFrm.Value.Value);
                    if (days > decimal.Zero)
                    {
                        abs.Duration = 0.5m;
                    }
                    break;
            }

            if (isCancel)
            {
                abs.Reason = this.txtReasonCancel.Text;
            }
            else
            {
                abs.Reason = this.txtReason.Text;
            }
            abs.CreateUID = base.LoginInfo.User.ID;
            abs.UpdateUID = base.LoginInfo.User.ID;
            return abs;
        }

        /// <summary>
        /// ISV-TRUC
        /// GetStaffInfoByCD
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService service = new StaffService(db);
                return service.GetStaffInfoByStaffCD(staffCD);
            }
        }

        /// <summary>
        /// Set data for DayOffType combobox
        /// </summary>
        /// <param name="dayOffType"></param>
        private void SetDataForDayOffTypeCbo(int dayOffType)
        {

            /*
             //ISV-TRUC 2015-07-16 Doi Logic, Lay type from Config
             IList<DropDownModel> list = new List<DropDownModel>();
            using (DB db = new DB())
            {
                WorkShiftService ser = new WorkShiftService(db);
                list = ser.GetDataForDropDown(dayOffType, false);
            }

            cmbDayOffType.DataSource = list;
            cmbDayOffType.DataValueField = "Value";
            cmbDayOffType.DataTextField = "DisplayName";
            cmbDayOffType.DataBind();*/
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                this.cmbDayOffType.DataSource = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }
            this.cmbDayOffType.DataValueField = "Value";
            this.cmbDayOffType.DataTextField = "DisplayName";
            this.cmbDayOffType.DataBind();
        }

        /// <summary>
        /// Set data dor Route combobox
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        /// <param name="hasUser"></param>
        private void SetDataForRouteCbo(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {
            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            this.LoadDataForApproveListFromRoute((list != null && list.Count > 0) ? int.Parse(this.cmbRoute.SelectedValue) : DEFAULT_VALUE);
        }

        /// <summary>
        /// Set value for hidden proxy
        /// </summary>
        private void SetValueForHiddenProxy(int routeID)
        {
            bool applyFlag1 = false;
            bool applyFlag2 = false;

            M_Route_D routeD = this.GetRouteLevelZeroByRouteID(routeID);
            if (routeD != null)
            {
                applyFlag1 = routeD.ApplyFlag1 == 1;
                applyFlag2 = routeD.ApplyFlag2 == 1;
            }
            if (applyFlag1)//Proxy All in a route
            {
                //this.chkIsAgent.Enabled = true;
                this.hdnProxyAll.Value = "1";
            }
            else if (applyFlag2)//Proxy Dept.
            {
                //this.chkIsAgent.Enabled = true;
                this.hdnProxyDept.Value = "1";
            }
            else
            {
                //this.chkIsAgent.Enabled = false;
            }
        }

        /// <summary>
        /// FillDataApproverByRouteID
        /// </summary>
        /// <param name="RouteID"></param>
        private void FillDataApproverByRouteID(int RouteID)
        {
            IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            using (DB db = new DB())
            {
                Route_DService routeDSer = new Route_DService(db);
                var lstTemp = routeDSer.GetListDetailInfo(RouteID, DEFAULT_VALUE);

                if (lstTemp != null && lstTemp.Count != 0)
                {
                    var lstTemp1 = (from l in lstTemp
                                    where l.RouteLevel != M_Route_H.LEVEL_APPLICANT
                                    select l).ToList<RouteDetailListInfo>();

                    lstItem = new List<RouteDetailListInfo>(lstTemp1);
                }
            }

            var lstTempCopy = from i in lstItem
                              select new WorkApproveModel
                              {
                                  Department = i.DepartmentName,
                                  Position = i.Position,
                                  UserName = i.UserName,
                                  RouteLevel = i.RouteLevel,
                                  RowNum = i.RowNumber,
                                  RouteMethod = i.RouteMethod,
                                  RouteMethodStr = i.RouteMethodStr
                              };
            IList<WorkApproveModel> lstData = new List<WorkApproveModel>(lstTempCopy);

            this.ApproverList = new List<WorkApproveModel>(lstData);
            this.rptApproverList.DataSource = lstData;
            this.rptApproverList.DataBind();
            //this.DisableButtonDataEmpty();
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadDataForApproveListFromApproveList(string absNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = this.GetListApproverFromApply(absNo, isIncludeView);

            if (approveList != null && approveList.Count != 0)
            {
                this.ApproverList = new List<WorkApproveModel>(approveList);
                this.rptApproverList.DataSource = approveList;
                this.ApproverList = new List<WorkApproveModel>();
                ((List<WorkApproveModel>)this.ApproverList).AddRange(approveList);
            }
            else
            {
                this.ApproverList = new List<WorkApproveModel>();
                this.rptApproverList.DataSource = null;
                this.ApproverList = null;
            }
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// Load Data Approve List From Route
        /// </summary>
        private void LoadDataForApproveListFromRoute(int routeID)
        {

            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
            using (DB db = new DB())
            {
                approverList = this.GetListApprover(db, routeID, true, EnumGetLevelZero.Exclude);
            }            

            if (approverList != null && approverList.Count != 0)
            {
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                this.rptApproverList.DataSource = null;
            }
            this.ApproverList = new List<WorkApproveModel>(approverList);
            this.rptApproverList.DataBind();

            this.DisableButtonDataEmpty();

        }

        /// <summary>
        /// RestoreListApprove
        /// </summary>
        private void RestoreListApprove()
        {
            this.rptApproverList.DataSource = this.ApproverList;
            this.SetRestTimeTableHeader(!string.IsNullOrEmpty(this.hdnUserID.Value) ? int.Parse(this.hdnUserID.Value) : DEFAULT_VALUE);
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.ClearUpdateInfo();
                    this.ApplyStatus = (int)StatusApply.Draft;
                    this.chkIsAgent.Checked = false;
                    this.chkIsAgent.Enabled = true;
                    this.txtReason.SetReadOnly(false);
                    this.cmbDayOffType.Enabled = true;
                    this.datAbsenceDtFrm.SetReadOnly(false);
                    this.datAbsenceDtTo.SetReadOnly(false);
                    this.cmbRoute.Enabled = true;
                    if (this.cmbRoute.DataSource != null && this.cmbRoute.Items.Count > 0)
                    {
                        this.SetValueForHiddenProxy(int.Parse(this.cmbRoute.SelectedValue));
                    }
                 
                    break;

                case Mode.Update:
                    if (!this.PreApplyID.HasValue)
                    {
                        this.txtReason.SetReadOnly(false);
                        this.cmbDayOffType.Enabled = true;
                        this.datAbsenceDtFrm.SetReadOnly(false);
                        this.datAbsenceDtTo.SetReadOnly(false);
                        this.chkIsAgent.Enabled = true;
                        this.cmbRoute.Enabled = true;
                        if (this.cmbRoute.DataSource != null && this.cmbRoute.Items.Count > 0)
                        {
                            this.SetValueForHiddenProxy(int.Parse(this.cmbRoute.SelectedValue));
                        }
                        else
                        {
                          //  this.chkIsAgent.Enabled = false;
                        }

                        if (this.ApplyStatus != (int)StatusApply.Draft)
                        {
                            base.DisabledLink(this.btnEdit, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnEdit, false);
                            //base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                        }                       
                    }
                    else
                    {
                        this.txtReason.SetReadOnly(true);
                        this.txtReasonCancel.SetReadOnly(false);
                    }

                    break;
                    
                case Mode.Delete:

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.SetReadOnly(true);
                    this.chkIsAgent.Enabled = false;
                    this.datAbsenceDtFrm.SetReadOnly(true);
                    this.datAbsenceDtTo.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.cmbDayOffType.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;

                case Mode.Confirm:

                    this.ApplyStatus = (int)StatusApply.Draft;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;
                case Mode.Cancel:
                    this.txtApplyNo.Value = string.Empty;
                    this.ApplyStatus = (int)StatusApply.Cancel;
                    this.dtApplyDate.Value = null;
                    this.chkIsAgent.Enabled = false;
                    break;
                default:

                    this.chkIsAgent.Enabled = false;
                    this.datAbsenceDtFrm.SetReadOnly(true);
                    this.datAbsenceDtTo.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.cmbDayOffType.Enabled = false;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.Draft:
                            base.DisabledLink(this.btnEdit, false);
                            base.DisabledLink(this.btnDelete, false);
                            base.DisabledLink(this.btnConfirm, false);
                            //base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                            //base.DisabledLink(this.btnDelete, !base._authority.IsApplyRegistDelete);
                            //base.DisabledLink(this.btnConfirm, !base._authority.IsApplyRegistConfirm);
                            break;

                        case (int)StatusApply.Approving:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;
                        case (int)StatusApply.Approved:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Rejected:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        //case (int)StatusApply.BackPrev:
                        //    base.DisabledLink(this.btnEdit, true);
                        //    base.DisabledLink(this.btnConfirm, true);
                        //    break;
                        case (int)StatusApply.Cancel:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, false);
                            break;
                    }

                    //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                    T_Work_Absence app = new T_Work_Absence();
                    using (DB db = new DB())
                    {
                        WorkAbsenceService appSer = new WorkAbsenceService(db);
                        app = appSer.GetByID(this.DataID);
                    }
                    
                    if (app == null)
                    {
                        base.DisabledLink(this.btnEdit, true);
                        base.DisabledLink(this.btnDelete, true);
                        base.DisabledLink(this.btnConfirm, true);
                    }
                    break;
            }

            this.DisableButtonDataEmpty();
            this.txtTotalDays.SetReadOnly(true);
            if (this.chkIsAgent.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Update || this.Mode == Mode.Copy))
            {
                this.txtEmployeeCD.SetReadOnly(false);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
            }
        }

        /// <summary>
        /// Change Employee Textbox
        /// </summary>
        private void EmployeeTextChange()
        {
            int loginRouteID = int.Parse(this.hdnRouteID.Value);
            M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
            if (s != null)
            {
                M_User u = this.GetUserByStaffID(s.ID);
                if (u != null)
                {
                    string loginUserCD = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                    string userCD = EditDataUtil.ToFixCodeShow(u.UserCD, M_User.MAX_USER_CODE_SHOW);
                    if (userCD.Equals(loginUserCD))//Is login user
                    {
                        this.chkIsAgent.Checked = false;
                        this.SetRestTimeTableHeader(u.ID);
                        this.SetEmployeeInfo(u.ID);
                        this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, u.ID);
                    }
                    else//user other
                    {
                        if (this.IsSameRoute(u.UserCD, this.LoginInfo.User.UserCD))
                        {
                            this.SetRestTimeTableHeader(u.ID);
                            this.SetEmployeeInfo(u.ID);
                            this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, u.ID);
                        }
                        else
                        {
                            this.SetRestTimeTableHeader(DEFAULT_VALUE);
                            this.SetEmployeeInfo(DEFAULT_VALUE);
                            this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
                        }
                    }
                }
                else
                {
                    this.SetRestTimeTableHeader(DEFAULT_VALUE);
                    this.SetEmployeeInfo(DEFAULT_VALUE);
                    this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
                }
            }
            else
            {
                this.SetRestTimeTableHeader(DEFAULT_VALUE);
                this.SetEmployeeInfo(DEFAULT_VALUE);
                this.SetDataForRouteCbo(this.cmbRoute, LEAVE_TEMPLATE, DEFAULT_VALUE, false);
            }

        }

        #endregion
       

        #region Insert data

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                if (this.IsExistCancel())
                {
                    this.RestoreListApprove();
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);
                    return false;
                }

                int dayOffType = int.Parse(this.cmbDayOffType.SelectedValue.ToString());
                if (this.CheckDuplicationOfTimes(this.DataNo, dayOffType))
                {
                    this.RestoreListApprove();
                    this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    return false;
                }
              
                //Neu dang lam ma co nguoi khac cancel truoc thi phieu nay co phat hien ra ko????
                string no = string.Empty;
                using (DB db = new DB())
                {
                    TNoService noService = new TNoService(db);
                    no = noService.CreateNo(T_No.No);

                }
                //Create model
                T_Work_Absence abs = new T_Work_Absence();
                abs = this.CreateAbsenceData(no, PreApplyID.HasValue);
                T_Work_ApplyTime applyTime = this.CreateApplyTimeModel(abs);
                //Insert
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    
                    //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                    

                    WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                    this.DataID = absenceSer.Insert(abs);
                    this.ApplyStatus = abs.ApplyStatus;
                    if (!this.PreApplyID.HasValue)
                    {
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        wrkAppSer.Insert(applyTime);
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Work_Absence_PK))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "Absence");
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Update data

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int dayOffType = int.Parse(this.cmbDayOffType.SelectedValue.ToString());
                if (this.CheckDuplicationOfTimes(this.DataNo, dayOffType))
                {
                    this.RestoreListApprove();
                    this.SetMessage(this.datAbsenceDtFrm.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                    return false;
                }
                int ret = 0;
                
                T_Work_Absence abs = new T_Work_Absence();
                abs = this.CreateAbsenceData(this.DataNo, this.PreApplyID.HasValue);

                if (abs != null)
                {
                    T_Work_ApplyTime wrkATime = this.CreateApplyTimeModel(abs);
                    //Update data
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        
                        WorkAbsenceService service = new WorkAbsenceService(db);

                        //Update
                        if (abs.Status == DataStatus.Changed)
                        {
                            //Update T_Work_Absence
                            abs.UpdateDate = this.OldUpdateDate;

                            ret = service.Update(abs);
                            if (ret > 0)
                            {
                                if (!this.PreApplyID.HasValue)
                                {
                                    WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                                    ret = wrkAppSer.Update(wrkATime);
                                }

                                if (ret > 0)
                                {
                                    db.Commit();
                                }
                            }
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region  Confirm
        
        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool Confirm()
        {
            ApplyFucntion appFunc = new ApplyFucntion(this.DataID, this.LoginInfo.User, ApplyType.Absence, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));
            bool ret = false;
            ProcessResult proc = appFunc.Confirm();
            switch (proc)
            {
                case ProcessResult.Success:
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
            #region OLD
            /*bool success = false;
            try
            {
                int ret = 0;
                T_Work_Absence data = this.GetAbsenceByID(this.DataID);
                if (data != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkAbsenceService absenceSer = new WorkAbsenceService(db);

                        //Update StatusFlag
                        ret = absenceSer.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (int)StatusApply.Approving, 0, this.OldUpdateDate);
                        if (ret == 1)
                        {
                            WorkApproveService applyApproveSer = new WorkApproveService(db);
                            ret = applyApproveSer.Insert(data.RouteID, this.DataNo, -1, (short)StatusHasAprove.New);

                        }
                        //Check result update
                        if (ret == 0)
                        {
                            //Data is changed
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        db.Commit();
                        success = true;
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            try
            {
                //Send mail
                if (success)
                {
                    IList<string> lstEmail = this.GetListEmail();
                    StringBuilder mailBody = new StringBuilder();
                    if (lstEmail != null && lstEmail.Count > 0)
                    {
                        mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                        mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                        string type = string.Empty;
                        if (this.cmbDayOffType.SelectedValue != null)
                        {
                            if (int.Parse(this.cmbDayOffType.SelectedValue) ==(int) TypeOfDay.DayOff)
                            {
                                type = TypeOfDay.DayOff.ToString();
                            }
                            else if (int.Parse(this.cmbDayOffType.SelectedValue) == (int)TypeOfDay.HalfDayOff)
                            {
                                type = TypeOfDay.HalfDayOff.ToString();
                            }
                        }
                        mailBody.AppendLine("Type: " + type);
                        mailBody.AppendLine("Reason: " + this.txtReason.Text);
                        string sSubject = string.Empty;
                        if (lstEmail.Count == 1)
                        {
                            sSubject = "There is " + lstEmail.Count + " requirement for approving";
                        }
                        else
                        {
                            sSubject = "There are " + lstEmail.Count + " requirements for approving";
                        }

                        CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);
                    }
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            */
            #endregion
        }

        #endregion

        #region  Delete Data

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Work_Absence apply = this.GetAbsenceByID(this.DataID);
                if (apply != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkAbsenceService service = new WorkAbsenceService(db);

                        apply.StatusFlag = (int)DeleteFlag.Deleted;
                        apply.ID = this.DataID;
                        apply.UpdateUID = LoginInfo.User.ID;
                        apply.UpdateDate = this.OldUpdateDate;

                        //Update StatusFlag
                        ret = service.UpdateStatusFlag(apply);
                        if (ret != 0 && !this.PreApplyID.HasValue)
                        {
                            WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                            ret = wrkAppSer.Delete(apply.No);
                        }
                        if (ret != 0)
                        {
                            db.Commit();
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Web method

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string employeeCD, string loginUserCD)
        {
            var employeeCd = employeeCD;
            var employeeCdShow = employeeCD;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    StaffService serv = new StaffService(db);
                    M_Staff model = serv.GetByStaffCD(employeeCd);
                    if (model != null)
                    {
                        UserService userSer = new UserService(db);
                        M_UserInfo u = userSer.GetUserInfoByStaffID(model.ID);
                        if (u != null)
                        {
                            Route_HService routeSer = new Route_HService(db);
                            IList<M_Route_H> lstRet = routeSer.GetListRouteBy2UserCD(LEAVE_TEMPLATE, u.UserCD, loginUserCD);
                            if (lstRet != null && lstRet.Count > 0)
                            {
                                DepartmentService deptSer = new DepartmentService(db);
                                M_Department dept = deptSer.GetByID(model.DepartmentID);
                                Config_DService confSer = new Config_DService(db);
                                string pos = confSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, model.Position);
                                var result = new
                                {
                                    employeeCD = employeeCdShow,
                                    employeeNm = model.StaffName,
                                    department = dept != null ? dept.DepartmentName : string.Empty,
                                    position = pos

                                };
                                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                            }
                        }
                    }
                }

                var employee = new
                {
                    employeeCD = employeeCdShow,
                    employeeNm = string.Empty,
                    department = string.Empty,
                    position = string.Empty
                };

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
            }
            catch (Exception)
            {
                return null;
            }

        }
        
        /// <summary>
        /// GetUseDays
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUseDays(DateTime startDate, DateTime endDate)
        {
            try
            {
                if (endDate < startDate)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                using (DB db = new DB())
                {
                    WorkVacationService ser = new WorkVacationService(db);
                    decimal days = ser.GetNumberOfDaysByRangeDate(startDate, endDate);

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(days);
                }

            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// GetUseDays
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetDayOffType(string shiftID)
        {
            try
            {
                if (string.IsNullOrEmpty(shiftID))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                int typeID = int.Parse(shiftID);
                /*var dayOffType = -1;
                if (shiftID==null)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }*/
                using (DB db = new DB())
                {
                   /* WorkShiftService shiftSer =new WorkShiftService(db);
                    M_Work_Shift shift = shiftSer.GetByID(int.Parse(shiftID));
                    if (shift != null)
                    {
                        dayOffType = shift.TypeOfDay;
                    }

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(dayOffType);
                     */
                    Config_DService ser = new Config_DService(db);
                    string value = ser.GetValue4(M_Config_H.CONFIG_CD_VACATION_TYPE, typeID);
                    if (!string.IsNullOrEmpty(value))
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(value);
                    }
                    else
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                    }
                }

            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
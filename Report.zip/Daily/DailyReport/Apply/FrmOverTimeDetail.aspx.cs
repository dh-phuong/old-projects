﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using System.Globalization;
using System.Text;
using System.Collections;
using DailyReport.Apply;

namespace DailyReport
{
    public partial class FrmOverTimeDetail : FrmBaseDetail
    {

        #region Constants

        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const int DEFAULT_VALUE = -1;
        public bool isExistCancel;
        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";

        #endregion

        #region Variable

        public string statusNameLbl;
        public string colorStatus;
        public string NowDate;

        #endregion

        #region Property

        /// <summary>
        /// Outing row count
        /// </summary>
        public bool PreCalWorkTime
        {
            get { return (bool)ViewState["PreCalWorkTime"]; }
            set { ViewState["PreCalWorkTime"] = value; }
        }

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int ApplyID
        {
            get { return (int)ViewState["ApplyID"]; }
            set { ViewState["ApplyID"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }
            set { ViewState["PreApplyID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyNo
        /// </summary>
        public string PreApplyNo
        {
            get { return (string)ViewState["PreApplyNo"]; }
            set { ViewState["PreApplyNo"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Overtime";
            base.FormSubTitle = "Detail";

            //Set max lengh
            this.txtReason.MaxLength = T_Work_OT.REASON_MAX_LENGTH;
            this.txtReasonCancel.MaxLength = T_Work_OT.REASON_MAX_LENGTH;
            this.txtEmployeeCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

            //Dropdownlist select index change event            
            this.ddlApprovalRoute.SelectedIndexChanged += ddlApprovalRoute_OnSelectedIndexChanged;
            this.dtEffectDate.TextChanged += dtEffectDate_OnTextChanged;
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case DailyReport.Utilities.Mode.Insert:
                case DailyReport.Utilities.Mode.Copy:
                    if (this.InsertData())
                    {
                        T_Work_OT w;
                        using (DB db = new DB())
                        {
                            WorkOTService wSer = new WorkOTService(db);
                            w = wSer.GetByID(this.ApplyID);

                        }

                        //Show data
                        this.ShowData(w);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        //this.colorStatus = base.GetStatusColorLabel((int)StatusApply.Draft, ref this.statusNameLbl);
                    }
                    break;

                case DailyReport.Utilities.Mode.Delete:
                    //Delete
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                case Mode.Confirm:
                    //Update Data
                    //this.ApplyStatus = (short)StatusApply.Confirm;
                    if (this.Confirm())
                    {
                        //Get User
                        T_Work_OT data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;
                case Mode.Cancel:
                    //Insert Data
                    if (this.InsertData(true))
                    {
                        //Get User
                        T_Work_OT data = this.GetApplyByID(this.ApplyID);

                        //Show data
                        this.ShowData(data);//?????????????

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.RestoreListApprove();
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;
                case Mode.Update:
                    if (this.UpdateData())
                    {
                        T_Work_OT data = this.GetApplyByID(this.ApplyID);
                        this.ShowData(data);
                        //M_Holiday holiday = this.GetHoliday(this.HolidayID);

                        //Show data
                        //this.ShowData(holiday);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        protected void dtEffectDate_OnTextChanged(object sender, EventArgs e)
        {
            M_Work_Shift ws = new M_Work_Shift();

            if (this.dtEffectDate.IsEmpty)
            {
                this.SetDataForShift(ws);
                using (DB db = new DB())
                {
                    this.GetTotalOverTime(db);
                }

                return;
            }

            using (DB db = new DB())
            {
                WorkOTService wOT = new WorkOTService(db);
                ws = wOT.GetWorkingShiftByDate(this.dtEffectDate.Value.Value.Date);
            }

            if (ws == null)
            {
                this.SetDataForShift(ws);
            }
            else
            {
                this.SetDataForShift(ws, true);
            }

            this.PreCalWorkTime = true;
            using (DB db = new DB())
            {
                this.GetTotalOverTime(db);
            }

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            this.PreCalWorkTime = false;
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {

                        this.ApplyID = 0;
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.ApplyID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_OT data = this.GetWorkOTByID(this.ApplyID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// btEdit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            T_Work_OT data = new T_Work_OT();

            using (DB db = new DB())
            {
                //Get Data
                WorkOTService wSer = new WorkOTService(db);
                data = wSer.GetByID(this.ApplyID);
            }

            //Check data
            if (data != null)
            {
                var isOk = true;
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);

                if (data.UpdateDate != this.OldUpdateDate)
                {
                    this.LoadDataForApproveListFromApproveList(this.DataNo, true);

                    base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                    isOk = false;
                    if (data.StatusFlag == 1)
                    {
                        base.RedirectUrl(URL_LIST);
                        return;
                    }
                }

                if (isOk)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
                this.PreCalWorkTime = true;
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Confirm;

            T_Work_OT apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                this.RestoreListApprove();
                if (!this.PreApplyID.HasValue)
                {
                    //Employee Code
                    if (!this.CheckInput(true))
                    {
                        return;
                    }
                }
                else
                {
                    //Check ngay thang co nam trong thang da ket so ko
                    if (this.CheckExistingDateInWorkTotal())
                    {
                        this.SetMessage(this.dtEffectDate.ID, M_Message.MSG_CANT_CONTINUE, this.dtEffectDate.Value.Value.ToString(Constants.FMT_DATE));
                        return;
                    }
                }

                this.PreCalWorkTime = true;

                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, Models.DefaultButton.Yes, true);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnDelete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            T_Work_OT w = this.GetWorkOTByID(this.ApplyID);
            if (w != null)
            {
                this.RestoreListApprove();
                this.ProcessMode(Mode.Delete);
                this.PreCalWorkTime = true;
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
            }
            //T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            //if (apply != null)
            //{
            //    this.RestoreListApprove();
            //    //this.SetApplyTypePenalized(int.Parse(this.cmbApplyType.SelectedValue));
            //    this.ProcessMode(Mode.Delete);
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
            //}
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            T_Work_OT w = this.GetApplyByID(this.ApplyID);
            if (w != null)
            {
                this.btnViewPreVacation.Text = w.No;
                this.ShowData(w);
                this.PreApplyNo = w.No;
                this.PreApplyID = w.ID;
                this.hdnApplyID.Value = this.PreApplyID.ToString();
                this.ApplyStatus = (int)StatusApply.Cancel;
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                this.ProcessMode(Mode.Cancel);
                this.PreCalWorkTime = true;
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.PreCalWorkTime = true;
            if (!this.PreApplyID.HasValue)
            {
                ////Check input
                if (!this.CheckInput())
                {
                    return;
                }
            }
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Update;
            this.PreCalWorkTime = true;

            //    //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelApply_Click(object sender, EventArgs e)
        {
            //this.ApproveStatus = (int)StatusApply.Cancel;
            this.RestoreListApprove();
            this.PreCalWorkTime = true;

            bool check;
            using (DB db = new DB())
            {
                check = IsExistCancel(db);
            }
            if (check)
            {
                base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
            }
            else
            {
                if (!this.CheckInputForCancel())
                {
                    return;
                }

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            T_Work_OT data = new T_Work_OT();
            using (DB db = new DB())
            {
                //Get User
                WorkOTService wOT = new WorkOTService(db);
                data = wOT.GetByID(this.ApplyID);
            }

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Click btnSeachUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnChangeDate_Click(object sender, EventArgs e)
        {
            this.PreCalWorkTime = true;
        }

        /// <summary>
        /// Checked change chkisAgent
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void chkIsAgent_CheckedChanged(object sender, EventArgs e)
        {
            //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            if (this.chkIsAgent.Checked)
            {
                this.CheckAuthor(string.Empty);
                this.txtEmployeeCD.SetReadOnly(false);
                this.txtEmployeeCD.Value = string.Empty;
                this.txtEmployeeNm.Value = string.Empty;
                this.hdnUserID.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
                this.hdnDepartmentID.Value = LoginInfo.Department.ID.ToString();
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
                this.InitUserInfo(this.LoginInfo.User.ID);
                this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, this.LoginInfo.User.ID);
            }

            this.PreCalWorkTime = true;
        }

        /// <summary>
        /// ddlApprovalRoute OnSelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void ddlApprovalRoute_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            int routeID = int.Parse(this.ddlApprovalRoute.SelectedValue);
            this.PreCalWorkTime = true;
            using (DB db = new DB())
            {
                this.SetValueForHiddenProxy(db, routeID);
            }
            this.FillDataApproverByRouteID(routeID);
        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Work_OT data = this.GetApplyByID(this.ApplyID);
            if (data != null)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Click btnSeachUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUser_Click(object sender, EventArgs e)
        {
            this.EmployeeTextChange();
            this.PreCalWorkTime = true;
        }

        #endregion

        #region Mehod

        private void FillDataApproverByRouteID(int RouteID)
        {
            // IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            IList<WorkApproveModel> lstData = new List<WorkApproveModel>();
            using (DB db = new DB())
            {
                Route_DService routeDSer = new Route_DService(db);
                lstData = routeDSer.GetApproverListByRouteIDForWork(RouteID, true, EnumGetLevelZero.Exclude);
            }

            this.ApproverList = new List<WorkApproveModel>(lstData);
            this.rptApproverList.DataSource = lstData;
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// Change Employee Textbox
        /// </summary>
        private void EmployeeTextChange()
        {
            //this.colorStatus = this.GetStatusColorLabel((int)StatusApply.Draft, ref this.statusNameLbl);
            int loginRouteID = -1;

            if (this.hdnRouteID.Value != string.Empty)
            {
                loginRouteID = int.Parse(this.hdnRouteID.Value);
            }

            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_Staff s = staffSer.GetByStaffCD(this.txtEmployeeCD.Value.Trim());
                if (s != null)
                {
                    UserService userSer = new UserService(db);
                    M_User u = userSer.GetByStaffID(s.ID);
                    if (u != null)
                    {
                        string loginUserCD = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
                        string userCD = EditDataUtil.ToFixCodeShow(u.UserCD, M_User.MAX_USER_CODE_SHOW);
                        if (userCD.Equals(loginUserCD))//Is login user
                        {
                            this.chkIsAgent.Checked = false;
                            this.InitUserInfo(u.ID);
                            this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, u.ID);
                        }
                        else//user other
                        {
                            if (this.IsSameRoute(u.UserCD, this.LoginInfo.User.UserCD))
                            {
                                this.InitUserInfo(u.ID);
                                this.InitDropdownRoute(this.ddlApprovalRoute, this.GetListRouteByUserCD(u.UserCD, this.LoginInfo.User.UserCD));
                            }
                            else
                            {
                                this.InitUserInfo(DEFAULT_VALUE);
                                this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, DEFAULT_VALUE, false);
                            }
                        }
                    }
                    else
                    {
                        this.InitUserInfo(DEFAULT_VALUE);
                        this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, DEFAULT_VALUE, false);
                    }
                }
                else
                {
                    this.InitUserInfo(DEFAULT_VALUE);
                    this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, DEFAULT_VALUE, false);
                }
            }
        }

        /// <summary>
        /// InitDataDropdownRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        private void InitDropdownRoute(DropDownList ddl, IList<M_Route_H> list)
        {
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            if (list != null && list.Count > 0)
            {
                this.FillDataApproverByRouteID(int.Parse(this.ddlApprovalRoute.SelectedValue));
            }
            else
            {
                this.FillDataApproverByRouteID(DEFAULT_VALUE);
            }
        }

        /// <summary>
        /// check SameRoute of 2 userCD
        /// </summary>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        private bool IsSameRoute(string userCD1, string userCD2)
        {
            IList<M_Route_H> lstRet = this.GetListRouteByUserCD(userCD1, userCD2);
            if (lstRet != null && lstRet.Count > 0)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// GetListRouteByUserCD
        /// </summary>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        private IList<M_Route_H> GetListRouteByUserCD(string userCD1, string userCD2)
        {
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                return routeSer.GetListRouteBy2UserCD(M_Config_D.TEMPLATE_FORM_APPLY_OT, userCD1, userCD2);
            }
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkOTService service = new WorkOTService(db);
                    T_Work_OT w = new T_Work_OT();
                    w.StatusFlag = (int)DeleteFlag.Deleted;
                    w.ID = this.ApplyID;
                    w.UpdateUID = LoginInfo.User.ID;
                    w.UpdateDate = this.OldUpdateDate;

                    //Update StatusFlag
                    ret = service.UpdateStatusFlag(w);

                    if (ret != 0 && !this.PreApplyID.HasValue)
                    {
                        WorkApplyTimeService wSer = new WorkApplyTimeService(db);
                        wSer.Delete(this.txtApplyNo.Value);
                    }

                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB())
                {
                    WorkOTService wSer = new WorkOTService(db);
                    T_Work_OT w = wSer.GetByID(this.ApplyID);

                    if (w != null)
                    {
                        StaffService staffSer = new StaffService(db);
                        UserService userSer = new UserService(db);

                        //Create model
                        M_Staff staff = staffSer.GetByStaffCD(this.txtEmployeeCD.Value);
                        M_User user = userSer.GetByStaffID(staff.ID);

                        w.UserID = user.ID;
                        w.EffectDate = (DateTime)this.dtEffectDate.Value;
                        w.ShiftID = int.Parse(this.hdShiftID.Value);
                        w.ShiftName = this.hdShiftName.Value;

                        if (this.hdStartTime.Value != string.Empty)
                        {
                            string[] temp = new string[2];

                            temp = this.hdStartTime.Value.Split(':');
                            w.StartHour = int.Parse(temp[0]);
                            w.StartMinute = int.Parse(temp[1]);
                            temp = this.hdEndTime.Value.Split(':');
                            w.EndHour = int.Parse(temp[0]);
                            w.EndMinute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.StartHour = 0;
                            w.StartMinute = 0;
                            w.EndHour = 0;
                            w.EndMinute = 0;
                        }

                        w.OTStartHour = this.dtStartTime.Value.Value.Hour;
                        w.OTStartMinute = this.dtStartTime.Value.Value.Minute;
                        w.OTEndHour = this.dtEndTime.Value.Value.Hour;
                        w.OTEndMinute = this.dtEndTime.Value.Value.Minute;

                        //Early
                        if (this.hdEarly.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdEarly.Value.Split(':');
                            w.EarlyHour = int.Parse(temp[0]);
                            w.EarlyMinute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.EarlyHour = 0;
                            w.EarlyMinute = 0;
                        }

                        //Normal
                        if (this.hdNormal.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdNormal.Value.Split(':');
                            w.Normal1Hour = int.Parse(temp[0]);
                            w.Normal1Minute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.Normal1Hour = 0;
                            w.Normal1Minute = 0;
                        }

                        //Normal2
                        if (this.hdNormal2.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdNormal2.Value.Split(':');
                            w.Normal2Hour = int.Parse(temp[0]);
                            w.Normal2Minute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.Normal2Hour = 0;
                            w.Normal2Minute = 0;
                        }

                        //Late
                        if (this.hdLateNight.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdLateNight.Value.Split(':');
                            w.LateHour = int.Parse(temp[0]);
                            w.LateMinute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.LateHour = 0;
                            w.LateMinute = 0;
                        }

                        //Holiday1
                        if (this.hdHoliday1.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdHoliday1.Value.Split(':');
                            w.Holiday1Hour = int.Parse(temp[0]);
                            w.Holiday1Minute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.Holiday1Hour = 0;
                            w.Holiday1Minute = 0;
                        }

                        //Holiday2
                        if (this.hdHoliday2.Value != string.Empty)
                        {
                            string[] temp = new string[2];
                            temp = this.hdHoliday2.Value.Split(':');
                            w.Holiday2Hour = int.Parse(temp[0]);
                            w.Holiday2Minute = int.Parse(temp[1]);
                        }
                        else
                        {
                            w.Holiday2Hour = 0;
                            w.Holiday2Minute = 0;
                        }

                        if (this.PreApplyID.HasValue)
                        {
                            w.Reason = this.txtReasonCancel.Value;
                        }
                        else
                        {
                            w.Reason = this.txtReason.Value;
                        }

                        w.RouteID = int.Parse(this.ddlApprovalRoute.SelectedValue);

                        w.UpdateDate = this.OldUpdateDate;
                        w.UpdateUID = this.LoginInfo.User.ID;

                        //Update Holiday  
                        wSer = new WorkOTService(db);

                        //Update User
                        if (w.Status == DataStatus.Changed)
                        {
                            ret = wSer.Update(w);

                            T_Work_ApplyTime wt = new T_Work_ApplyTime();
                            WorkApplyTimeService wtSer = new WorkApplyTimeService(db);
                            DateTime starttime = this.dtEffectDate.Value.Value;
                            DateTime endtime = this.dtEffectDate.Value.Value;

                            wt.ApplyNo = this.txtApplyNo.Value;
                            wt.UserID = user.ID;
                            wt.StartTime = starttime.AddHours(this.dtStartTime.Value.Value.Hour).AddMinutes(this.dtStartTime.Value.Value.Minute);
                            wt.EndTime = endtime.AddHours(this.dtEndTime.Value.Value.Hour).AddMinutes(this.dtEndTime.Value.Value.Minute);
                            wtSer.Update(wt);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        private bool InsertData(bool isCancel = false)
        {
            try
            {
                bool check;
                using (DB db = new DB())
                {
                    check = this.IsExistCancel(db);
                }
                if (check)
                {
                    //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    this.RestoreListApprove();
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);

                    return false;
                }

                //Create model
                T_Work_OT w = new T_Work_OT();
                M_Staff staff = new M_Staff();
                M_User user = new M_User();

                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    UserService userSer = new UserService(db);
                    TNoService noService = new TNoService(db);

                    staff = staffSer.GetByStaffCD(this.txtEmployeeCD.Value);
                    user = userSer.GetByStaffID(staff.ID);
                    w.No = noService.CreateNo(T_No.No);
                }

                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    w.PreApplyID = null;
                }
                else if (this.Mode == Mode.Cancel)
                {
                    w.PreApplyID = this.PreApplyID;
                }

                w.ApplyStatus = (short)StatusApply.Draft;
                w.ApplyDate = null;

                w.UserID = user.ID;
                w.EffectDate = (DateTime)this.dtEffectDate.Value;
                w.ShiftID = int.Parse(this.hdShiftID.Value.ToString());
                w.ShiftName = this.hdShiftName.Value;

                if (this.hdStartTime.Value != string.Empty)
                {
                    string[] temp = new string[2];

                    temp = this.hdStartTime.Value.Split(':');
                    w.StartHour = int.Parse(temp[0]);
                    w.StartMinute = int.Parse(temp[1]);
                    temp = this.hdEndTime.Value.Split(':');
                    w.EndHour = int.Parse(temp[0]);
                    w.EndMinute = int.Parse(temp[1]);
                }
                else
                {
                    w.StartHour = 0;
                    w.StartMinute = 0;
                    w.EndHour = 0;
                    w.EndMinute = 0;
                }

                w.EarlyHour = 0;
                w.EarlyMinute = 0;
                w.Normal1Hour = 0;
                w.Normal1Minute = 0;
                w.Normal2Hour = 0;
                w.Normal2Minute = 0;
                w.LateHour = 0;
                w.LateMinute = 0;
                w.Holiday1Hour = 0;
                w.Holiday1Minute = 0;
                w.Holiday2Hour = 0;
                w.Holiday2Minute = 0;

                w.OTStartHour = this.dtStartTime.Value.Value.Hour;
                w.OTStartMinute = this.dtStartTime.Value.Value.Minute;
                w.OTEndHour = this.dtEndTime.Value.Value.Hour;
                w.OTEndMinute = this.dtEndTime.Value.Value.Minute;

                //Early
                if (this.hdEarly.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdEarly.Value.Split(':');
                    w.EarlyHour = int.Parse(temp[0]);
                    w.EarlyMinute = int.Parse(temp[1]);
                }

                //Normal
                if (this.hdNormal.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdNormal.Value.Split(':');
                    w.Normal1Hour = int.Parse(temp[0]);
                    w.Normal1Minute = int.Parse(temp[1]);
                }

                //Normal2
                if (this.hdNormal2.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdNormal2.Value.Split(':');
                    w.Normal2Hour = int.Parse(temp[0]);
                    w.Normal2Minute = int.Parse(temp[1]);
                }

                //Late
                if (this.hdLateNight.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdLateNight.Value.Split(':');
                    w.LateHour = int.Parse(temp[0]);
                    w.LateMinute = int.Parse(temp[1]);
                }

                //Holiday1
                if (this.hdHoliday1.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdHoliday1.Value.Split(':');
                    w.Holiday1Hour = int.Parse(temp[0]);
                    w.Holiday1Minute = int.Parse(temp[1]);
                }

                //Holiday2
                if (this.hdHoliday2.Value != string.Empty)
                {
                    string[] temp = new string[2];
                    temp = this.hdHoliday2.Value.Split(':');
                    w.Holiday2Hour = int.Parse(temp[0]);
                    w.Holiday2Minute = int.Parse(temp[1]);
                }

                if (isCancel)
                {
                    w.Reason = this.txtReasonCancel.Text;
                }
                else
                {
                    w.Reason = this.txtReason.Text;
                }

                w.RouteID = int.Parse(this.ddlApprovalRoute.SelectedValue);
                w.ApprovedLevel = 0;
                w.StatusFlag = 0;

                w.CreateUID = this.LoginInfo.User.ID;
                w.UpdateUID = this.LoginInfo.User.ID;

                //Insert Holiday
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkOTService wSer = new WorkOTService(db);
                    //Insert Work
                    wSer.Insert(w);
                    this.ApplyID = db.GetIdentityId<T_Work_OT>();

                    T_Work_ApplyTime wt = new T_Work_ApplyTime();
                    WorkApplyTimeService wtSer = new WorkApplyTimeService(db);
                    DateTime starttime = this.dtEffectDate.Value.Value;
                    DateTime endtime = this.dtEffectDate.Value.Value;

                    wt.ApplyNo = w.No;
                    wt.UserID = user.ID;
                    wt.StartTime = starttime.AddHours(this.dtStartTime.Value.Value.Hour).AddMinutes(this.dtStartTime.Value.Value.Minute);
                    wt.EndTime = endtime.AddHours(this.dtEndTime.Value.Value.Hour).AddMinutes(this.dtEndTime.Value.Value.Minute);
                    wtSer.Insert(wt);

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool IsExistCancel(DB db)
        {
            WorkOTService appSer = new WorkOTService(db);

            if (ViewState["ApplyID"] != null)
            {
                T_Work_OT app = appSer.GetByPreApplyID(this.ApplyID);
                if (app != null)
                {
                    return true;
                }
            }
            return false;

        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                    this.ClearUpdateInfo();
                    this.ApplyStatus = (int)StatusApply.Draft;
                    //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    this.chkIsAgent.Checked = false;
                    this.chkIsAgent.Enabled = true;
                    this.txtReason.SetReadOnly(false);
                    this.ddlApprovalRoute.Enabled = true;

                    if (this.ddlApprovalRoute.DataSource != null && this.ddlApprovalRoute.Items.Count > 0)
                    {
                        using (DB db = new DB())
                        {
                            this.SetValueForHiddenProxy(db, int.Parse(this.ddlApprovalRoute.SelectedValue));
                        }
                    }
                    else
                    {
                        this.chkIsAgent.Enabled = false;
                    }

                    this.dtEffectDate.Enabled = true;
                    this.dtStartTime.Enabled = true;
                    this.dtEndTime.Enabled = true;
                    break;

                case Mode.Update:
                    if (!this.PreApplyID.HasValue)
                    {
                        this.txtEmployeeCD.SetReadOnly(false);
                        //this.txtEmployeeNm.ReadOnly = true;
                        this.chkIsAgent.Enabled = true;
                        this.dtEffectDate.Enabled = true;
                        this.dtStartTime.Enabled = true;
                        this.dtEndTime.Enabled = true;
                        this.txtReason.SetReadOnly(false);//can edit
                        this.ddlApprovalRoute.Enabled = true;

                        if (this.ddlApprovalRoute.DataSource != null && this.ddlApprovalRoute.Items.Count > 0)
                        {
                            using (DB db = new DB())
                            {
                                this.SetValueForHiddenProxy(db, int.Parse(this.ddlApprovalRoute.SelectedValue));
                            }

                        }
                        else
                        {
                            this.chkIsAgent.Enabled = false;
                        }

                        if (this.ApplyStatus != (int)StatusApply.Draft)
                        {
                            base.DisabledLink(this.btnEdit, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                        }
                    }
                    else
                    {
                        this.txtReason.SetReadOnly(true);
                        this.txtReasonCancel.SetReadOnly(false);
                    }

                    break;

                case Mode.Delete:

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtEmployeeNm.SetReadOnly(true);
                    this.chkIsAgent.Enabled = false;
                    this.ddlApprovalRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);

                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;

                case Mode.Confirm:

                    this.ApplyStatus = (int)StatusApply.Draft;
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;

                case Mode.Cancel:
                    this.txtApplyNo.Value = string.Empty;
                    this.ApplyStatus = (int)StatusApply.Cancel;
                    this.dtApplyDate.Value = null;
                    this.ddlApprovalRoute.Enabled = true;
                    break;
                default:

                    this.chkIsAgent.Enabled = false;
                    this.ddlApprovalRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.dtEffectDate.Enabled = false;
                    this.dtStartTime.Enabled = false;
                    this.dtEndTime.Enabled = false;

                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    switch (this.ApplyStatus)
                    {
                        case (int)StatusApply.Draft:
                            base.DisabledLink(this.btnEdit, !base._authority.IsApplyRegistEdit);
                            base.DisabledLink(this.btnDelete, !base._authority.IsApplyRegistDelete);
                            base.DisabledLink(this.btnConfirm, !base._authority.IsApplyRegistConfirm);
                            break;

                        case (int)StatusApply.Approving:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Approved:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Rejected:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnConfirm, true);
                            break;

                        case (int)StatusApply.Cancel:
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, false);
                            break;
                    }

                    using (DB db = new DB())
                    {
                        WorkOTService appSer = new WorkOTService(db);
                        T_Work_OT app = appSer.GetByID(this.ApplyID);

                        if (app == null)
                        {
                            base.DisabledLink(this.btnEdit, true);
                            base.DisabledLink(this.btnDelete, true);
                            base.DisabledLink(this.btnConfirm, true);
                        }
                    }
                    break;
            }

            if (this.chkIsAgent.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Update || this.Mode == Mode.Copy))
            {
                this.txtEmployeeCD.SetReadOnly(false);
            }
            else
            {
                this.txtEmployeeCD.SetReadOnly(true);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Work_OT</param>
        private void ShowData(T_Work_OT w)
        {
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();

            if (w != null)
            {
                using (DB db = new DB())
                {
                    //Show data                    
                    M_UserInfo user = new M_UserInfo();
                    UserService userSer = new UserService(db);
                    WorkOTService wOT = new WorkOTService(db);
                    M_Work_Shift ws = new M_Work_Shift();

                    ws = wOT.GetWorkingShiftByDate(w.EffectDate);
                    this.txtApplyNo.Value = w.No;
                    this.dtApplyDate.Value = w.ApplyDate;
                    this.dtEffectDate.Value = w.EffectDate;
                    this.dtStartTime.SetTimeValue(w.OTStartHour, w.OTStartMinute);
                    this.dtEndTime.SetTimeValue(w.OTEndHour, w.OTEndMinute);
                    this.lbEarly.Text = EditDataUtil.FixTimeShow(w.EarlyHour, w.EarlyMinute, true);
                    this.lbNormal.Text = EditDataUtil.FixTimeShow(w.Normal1Hour, w.Normal1Minute, true);
                    this.lbNormal2.Text = EditDataUtil.FixTimeShow(w.Normal2Hour, w.Normal2Minute, true);
                    this.lbLateNight.Text = EditDataUtil.FixTimeShow(w.LateHour, w.LateMinute, true);
                    this.lbHoliday1.Text = EditDataUtil.FixTimeShow(w.Holiday1Hour, w.Holiday1Minute, true);
                    this.lbHoliday2.Text = EditDataUtil.FixTimeShow(w.Holiday2Hour, w.Holiday2Minute, true);
                    this.SetDataForShift(ws, true);
                    this.GetTotalOverTime(db);

                    if (w.UserID.Equals(w.CreateUID) || w.UserID.Equals(this.LoginInfo.User.ID))
                    {
                        this.chkIsAgent.Checked = false;
                    }
                    else
                    {
                        this.chkIsAgent.Checked = true;
                    }

                    user = userSer.GetUserInfoByID((int)w.UserID);

                    if (user != null)
                    {
                        StaffService staffSer = new StaffService(db);
                        M_Staff s = staffSer.GetByID(user.StaffID);
                        if (s != null)
                        {
                            DepartmentService deptSer = new DepartmentService(db);
                            M_Department dept = deptSer.GetByID(s.DepartmentID);
                            string deptNm = string.Empty;
                            if (dept != null)
                            {
                                deptNm = dept.DepartmentName;
                                this.hdnDepartmentID.Value = dept.ID.ToString();
                            }

                            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                            this.txtEmployeeNm.Value = s.StaffName;

                            this.txtDepartment.Value = deptNm;
                            this.txtPosition.Value = (new Config_DService(db)).GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                        }

                        this.hdnUserID.Value = user.ID.ToString();
                    }

                    this.ddlApprovalRoute.SelectedValue = w.RouteID.ToString();
                    this.hdnRouteID.Value = w.RouteID.ToString();

                    if (this.ddlApprovalRoute.DataSource != null && this.ddlApprovalRoute.Items.Count > 0)
                    {
                        this.SetValueForHiddenProxy(db, w.RouteID);
                    }

                    this.ApplyStatus = w.ApplyStatus;
                    this.PreApplyID = w.PreApplyID;
                    this.DataNo = w.No;
                    this.ApplyID = w.ID;

                    WorkOTService workOTSer = new WorkOTService(db);

                    if (this.PreApplyID.HasValue)
                    {
                        T_Work_OT preApp = workOTSer.GetByID(this.PreApplyID.Value);
                        if (preApp != null)
                        {
                            this.hdnApplyID.Value = preApp.ID.ToString();
                            this.txtReason.Value = preApp.Reason;
                            this.txtReasonCancel.Value = w.Reason;
                            this.btnViewPreVacation.Text = preApp.No;
                        }
                    }
                    else
                    {
                        this.txtReason.Value = w.Reason;
                    }

                    this.isExistCancel = this.IsExistCancel(db);
                    this.OldUpdateDate = w.UpdateDate;

                    M_User createUser = userSer.GetByID(w.CreateUID);
                    if (createUser != null)
                    {
                        var createDate = (w.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : w.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                    }

                    M_User updateUser = userSer.GetByID(w.UpdateUID);
                    if (updateUser != null)
                    {
                        var updateDate = (w.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : w.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                    }

                    if (w.ApplyStatus == (int)StatusApply.Draft || w.ApplyStatus == (int)StatusApply.Cancel)//chua confirm
                    {
                        this.LoadDataForApproveListFromRoute(w.RouteID);
                    }
                    else
                    {
                        this.LoadDataForApproveListFromApproveList(w.No, true);
                    }

                }
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            this.InitDropdownRoute(ddl, list);
        }


        /// <summary>
        /// Load Data Approve List From Route
        /// </summary>
        private void LoadDataForApproveListFromRoute(int routeID)
        {
            if (this.Mode != Mode.Insert && this.Mode != Mode.Copy)
            {
                //this.colorStatus = base.GetStatusColorLabel((this.GetApplyByID(this.DataID)).ApplyStatus, ref this.statusNameLbl);
            }
            else
            {
                //this.colorStatus = base.GetStatusColorLabel(this.ApplyStatus, ref this.statusNameLbl);
            }
            //IList<VacationApprove> approverList = new List<VacationApprove>();
            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();

            using (DB db = new DB())
            {
                approverList = this.GetListApprovePerson(db, routeID, true, EnumGetLevelZero.Exclude);
            }

            if (approverList != null && approverList.Count != 0)
            {
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                this.rptApproverList.DataSource = null;
            }
            this.ApproverList = new List<WorkApproveModel>(approverList);
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(bool withBlank = false)
        {
            using (DB db = new DB())
            {
                WorkShiftService otSer = new WorkShiftService(db);
                return otSer.GetDataForDropDown((int)ShiftType.Attendance, withBlank);
            }
        }

        /// <summary>
        /// ISV-NHAT
        /// 2015/06/10
        /// </summary>
        private void InitUserInfo(int userID)
        {

            M_UserInfo u = this.GetUserInfoByID(userID);
            if (u != null)
            {
                M_Route_H item = this.GetRouteByUserID(u.ID);
                if (item != null)
                {
                    this.hdnRouteID.Value = item.ID.ToString();
                }
                this.hdnUserID.Value = u.ID.ToString();
                M_Staff s;
                string position = string.Empty;
                string deptNm = string.Empty;
                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    s = staffSer.GetByID(u.StaffID);
                    if (s != null)
                    {
                        Config_DService conDSer = new Config_DService(db);
                        position = conDSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                    }
                    deptNm = u.DepartmentName;
                    this.hdnDepartmentID.Value = u.DepartmentID.ToString();
                }

                if (s != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = s.StaffName;
                    this.txtDepartment.Value = deptNm;
                    this.txtPosition.Value = position;
                }
            }
            else
            {
                this.txtEmployeeNm.Value = string.Empty;
                this.txtDepartment.Value = string.Empty;
                this.txtPosition.Value = string.Empty;
            }
        }

        /// <summary>
        /// GetUserInfoByID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_UserInfo GetUserInfoByID(int userID)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetUserInfoByID(userID);
            }
        }

        private void InitData()
        {
            this.ApplyStatus = (short)StatusApply.Draft;
            this.hdnFormIDDefault.Value = M_Config_D.TEMPLATE_FORM_APPLY_OT.ToString();
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();
            this.ApplyID = DEFAULT_VALUE;
            this.PreApplyID = null;
            this.btnViewPreVacation.Text = string.Empty;
            this.InitUserInfo(this.LoginInfo.User.ID);
            this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, this.LoginInfo.User.ID);
            this.dtEffectDate.Value = DateTime.Now;
            dtEffectDate_OnTextChanged(null, null);
        }

        /// <summary>
        /// </summary>
        /// <returns></returns>
        private T_Work_OT GetWorkOTByID(int id)
        {
            using (DB db = new DB())
            {
                T_Work_OT wOT = new T_Work_OT();
                WorkOTService wSer = new WorkOTService(db);
                wOT = wSer.GetByID(id);
                return wOT;
            }
        }

        private void SetTime(WorkTotalOTInfo lastmonth, WorkTotalOTInfo thismonth)
        {
            this.lbLastEarly.Text = EditDataUtil.FixTimeShow(lastmonth.EarlyHour, lastmonth.EarlyMinute, true);
            this.lbLastNormal.Text = EditDataUtil.FixTimeShow(lastmonth.Normal1Hour, lastmonth.Normal1Minute, true);
            this.lbLastNormal2.Text = EditDataUtil.FixTimeShow(lastmonth.Normal2Hour, lastmonth.Normal2Minute, true);
            this.lbLastLate.Text = EditDataUtil.FixTimeShow(lastmonth.LateHour, lastmonth.LateMinute, true);
            this.lbLastHoliday1.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday1Hour, lastmonth.Holiday1Minute, true);
            this.lbLastHoliday2.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday2Hour, lastmonth.Holiday2Minute, true);
            this.lbLastTotal.Text = EditDataUtil.FixTimeShow(lastmonth.TotalOTHour, lastmonth.TotalOTMinute, true);

            this.lbThisEarly.Text = EditDataUtil.FixTimeShow(thismonth.EarlyHour, thismonth.EarlyMinute, true);
            this.lbThisNormal.Text = EditDataUtil.FixTimeShow(thismonth.Normal1Hour, thismonth.Normal1Minute, true);
            this.lbThisNormal2.Text = EditDataUtil.FixTimeShow(thismonth.Normal2Hour, thismonth.Normal2Minute, true);
            this.lbThisLate.Text = EditDataUtil.FixTimeShow(thismonth.LateHour, thismonth.LateMinute, true);
            this.lbThisHoliday1.Text = EditDataUtil.FixTimeShow(thismonth.Holiday1Hour, thismonth.Holiday1Minute, true);
            this.lbThisHoliday2.Text = EditDataUtil.FixTimeShow(thismonth.Holiday2Hour, thismonth.Holiday2Minute, true);
            this.lbThisTotal.Text = EditDataUtil.FixTimeShow(thismonth.TotalOTHour, thismonth.TotalOTMinute, true);
        }

        private void GetTotalOverTime(DB db)
        {
            if (this.txtEmployeeCD.IsEmpty)
            {
                return;
            }

            WorkOTService wSer = new WorkOTService(db);
            AccountingService accSer = new AccountingService(db);
            M_Accounting acc = new M_Accounting();
            WorkTotalOTInfo thismonth = new WorkTotalOTInfo();
            WorkTotalOTInfo lastmonth = new WorkTotalOTInfo();
            StaffService staffSer = new StaffService(db);
            M_Staff staff = staffSer.GetByStaffCD(this.txtEmployeeCD.Value);
            UserService userSer = new UserService(db);
            M_User user = userSer.GetByStaffID(staff.ID);

            acc = accSer.GetData();

            if (this.dtEffectDate.IsEmpty)
            {
                this.SetTime(lastmonth, thismonth);
                return;
            }

            AccountingPeriod periodC = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value);
            thismonth = wSer.GetTotalOverTime(periodC.StartDate, periodC.EndDate, user.ID);

            AccountingPeriod period = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value.AddMonths(-1));
            lastmonth = wSer.GetTotalOverTime(period.StartDate, period.EndDate, user.ID);

            this.SetTime(lastmonth, thismonth);
        }

        /// <summary>
        /// Check Employee(Check du lieu cua nguoi dc xin gium hop le)
        /// </summary>
        /// <returns></returns>
        private bool CheckEmployee(M_Route_D routeD, string focusID)
        {
            if (routeD != null)
            {
                //Check employee's department is the same department with login user
                using (DB db = new DB())
                {
                    StaffService staffSer = new StaffService(db);
                    M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                    if (s != null)
                    {
                        //luon luon check trong cung 1 route(ko can ApplyFlag1)
                        if (this.IsSameRoute(this.LoginInfo.User.UserCD, this.GetUserInfoByID(s.UserID).UserCD))//cung route
                        {
                            //Gioi han trong pham vi dept.
                            if (routeD.ApplyFlag2 == 1)
                            {
                                if (!s.DepartmentID.Equals(this.LoginInfo.Department.ID))//khac dept. --> loi
                                {
                                    this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                                }
                            }
                        }
                        else//ko cung route --> loi
                        {
                            this.SetMessage(focusID, M_Message.MSG_DATA_INVALID, "Applicant");
                        }

                    }
                    else
                    {
                        this.SetMessage(focusID, M_Message.MSG_VALUE_NOT_EXIST, "Applicant");
                    }
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// Check Author intermediary(check co quyen xin gium ngkhac ko)
        /// </summary>
        /// <returns></returns>
        private bool CheckAuthor(string focusID)
        {
            if (this.chkIsAgent.Checked)//dang xin gium ngkhac
            {
                using (DB db = new DB())
                {
                    int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                    M_Route_D routeD;

                    routeD = this.GetRouteLevelZeroByRouteID(db, routeID);


                    if (routeD != null)
                    {
                        // proxy all
                        if (routeD.ApplyFlag1 != 1 && routeD.ApplyFlag2 != 1)//ko co quyen xin cho ngkhac
                        {
                            this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                        }

                        // proxy dept
                        if (routeD.ApplyFlag2 == 1)
                        {
                            StaffService staffSer = new StaffService(db);
                            M_StaffInfo s = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value.Trim());
                            if (s != null)
                            {
                                if (s.DepartmentID != this.LoginInfo.Department.ID)
                                {
                                    this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                                }
                            }
                        }
                    }
                    else//ko co quyen xin gium ngkhac
                    {
                        this.SetMessage(focusID, M_Message.MSG_NOT_ALLOW_APPLY_TO_OTHERS);
                    }
                }
            }
            return !base.HaveError;
        }

        /// <summary>
        /// IsHaveDataDefault
        /// </summary>
        /// <param name="dateVal"></param>
        /// <returns></returns>
        private bool IsHaveDataDefault(DateTime dateVal)
        {
            using (DB db = new DB())
            {
                WorkDayService ser = new WorkDayService(db);
                if (ser.GetByWorkDate(dateVal) != null)
                {
                    return true;
                }
            }
            return false;
        }

        public bool CheckExistingDateInWorkTotal()
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo staff = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value);

                WorkTotalService wSer = new WorkTotalService(db);
                IList<T_Work_Total> list = wSer.GetByCond(staff.UserID, this.dtEffectDate.Value.Value, this.dtEffectDate.Value.Value);
                return list.Count != 0 ? true : false;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="appNo"></param>
        /// <returns></returns>
        private bool IsDuplicateApplyTime()
        {
            M_StaffInfo staff = new M_StaffInfo();
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                staff = staffSer.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value);
            }

            DateTime starttime = this.dtEffectDate.Value.Value;
            DateTime endtime = this.dtEffectDate.Value.Value;

            starttime = starttime.AddHours(this.dtStartTime.Value.Value.Hour).AddMinutes(this.dtStartTime.Value.Value.Minute);
            endtime = endtime.AddHours(this.dtEndTime.Value.Value.Hour).AddMinutes(this.dtEndTime.Value.Value.Minute);

            if (this.Mode == Mode.Insert)
            {
                return this.IsDuplicateTimeApply("", staff.UserID, starttime, endtime);
            }

            if (this.Mode == Mode.Update)
            {
                return this.IsDuplicateTimeApply(this.txtApplyNo.Value, staff.UserID, starttime, endtime);
            }

            return false;
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput(bool isConfirm = false)
        {
            string focusID = this.Mode == Mode.Update ? this.dtEffectDate.ID : this.txtEmployeeCD.ID;
            int UserID = this.LoginInfo.User.ID;

            #region Check require field

            if (!isConfirm)
            {
                if (this.chkIsAgent.Checked)
                {
                    if (this.txtEmployeeCD.IsEmpty)
                    {
                        this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_REQUIRE, "Applicant");
                    }
                    else
                    {
                        using (DB db = new DB())
                        {
                            StaffService staffSer = new StaffService(db);
                            M_Staff s = staffSer.GetByStaffCD(this.txtEmployeeCD.Value.Trim());
                            if (s == null)
                            {
                                this.SetMessage(this.txtEmployeeCD.ID, M_Message.MSG_NOT_EXIST_CODE, "Applicant");
                            }
                        }
                    }
                }

                //Check Effect Date
                if (this.dtEffectDate.IsEmpty)
                {
                    this.SetMessage(this.dtEffectDate.ID, M_Message.MSG_REQUIRE, "Effect Date");
                }

                //Check StartTime
                if (this.dtStartTime.IsEmpty)
                {
                    this.SetMessage(this.dtStartTime.ID, M_Message.MSG_REQUIRE, "Start overtime");
                }

                //Check EndTime
                if (this.dtEndTime.IsEmpty)
                {
                    this.SetMessage(this.dtEndTime.ID, M_Message.MSG_REQUIRE, "End overtime");
                }

                //Check Working Time
                if (this.dtStartTime.Value != null && this.dtEndTime.Value != null)
                {
                    DateTime timeFrom = new DateTime(2014, 10, 1, this.dtStartTime.Value.Value.Hour, this.dtStartTime.Value.Value.Minute, 0);
                    DateTime timeTo = new DateTime(2014, 10, 1, this.dtEndTime.Value.Value.Hour, this.dtEndTime.Value.Value.Minute, 0);
                    TimeSpan Result = timeTo.Subtract(timeFrom);

                    if (Result.TotalMinutes <= 0)
                    {
                        this.SetMessage(this.dtStartTime.ID, M_Message.MSG_LESS_THAN, "Start Time", "End Time", "Working Hour");
                    }
                    else
                    {
                        //Check Overtime Valid
                        if (this.hdEarly.Value == string.Empty && this.hdNormal.Value == string.Empty && this.hdNormal2.Value == string.Empty)
                        {
                            if (this.hdLateNight.Value == string.Empty && this.hdHoliday1.Value == string.Empty && this.hdHoliday2.Value == string.Empty)
                            {
                                if (!this.dtStartTime.IsEmpty && !this.dtEndTime.IsEmpty)
                                {
                                    this.SetMessage(this.dtStartTime.ID, M_Message.MSG_DATA_INVALID, "Overtime");
                                }
                            }
                        }
                    }
                }

                //Check Reason
                if (this.txtReason.IsEmpty)
                {
                    this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Reason");
                }

                //Reason cancel
                if (this.PreApplyID.HasValue)
                {
                    if (this.txtReasonCancel.IsEmpty)
                    {
                        this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Reason Cancel");
                    }
                }

                //Check Route
                if (this.ddlApprovalRoute.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlApprovalRoute.ID, M_Message.MSG_REQUIRE, "Approval Route");
                }

                //Check Route
                if (this.ddlApprovalRoute.SelectedValue == "")
                {
                    this.SetMessage(this.ddlApprovalRoute.ID, M_Message.MSG_LIST_APPROVE_NOT_EXIST, "Approval Route");
                }
            }

            #endregion

            #region Check valid

            if (!base.HaveError)
            {
                //Check quyen
                this.CheckAuthor(isConfirm ? string.Empty : this.txtEmployeeCD.ID);//ko co quyen

                //check employee hop le
                int routeID = int.Parse(!string.IsNullOrEmpty(this.hdnRouteID.Value) ? this.hdnRouteID.Value : DEFAULT_VALUE.ToString());
                M_Route_D routeD;
                using (DB db = new DB())
                {
                    routeD = this.GetRouteLevelZeroByRouteID(db, routeID);
                }

                bool isEmloyeeValid = this.CheckEmployee(routeD, isConfirm ? string.Empty : this.txtEmployeeCD.ID);

                //Check data had set in workday
                if (!this.IsHaveDataDefault(this.dtEffectDate.Value.Value))
                {
                    this.SetMessage(this.dtEffectDate.ID, M_Message.MSG_CONTACT_MANAGER);
                }

                //Check Total is contains
                if (isEmloyeeValid)
                {
                    if (this.CheckExistingDateInWorkTotal())
                    {
                        this.SetMessage(this.dtEffectDate.ID, M_Message.MSG_CANT_CONTINUE, this.dtEffectDate.Value.Value.ToString(Constants.FMT_DATE));
                    }

                    //Check Duplicate Time
                    if (!this.dtStartTime.IsEmpty && !this.dtEndTime.IsEmpty && !this.dtEffectDate.IsEmpty && !this.txtEmployeeCD.IsEmpty && this.PreApplyID == null)
                    {
                        if (this.IsDuplicateApplyTime())
                        {
                            this.SetMessage(this.dtEffectDate.ID, M_Message.MSG_DUPLICATE, "Effect Date");
                        }
                    }
                }
            }

            #endregion

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check inputing for cancel mode
        /// </summary>
        /// <returns></returns>
        private bool CheckInputForCancel()
        {
            //Reason cancel

            if (this.txtReasonCancel.IsEmpty)
            {
                this.SetMessage(this.txtReasonCancel.ID, M_Message.MSG_REQUIRE, "Reason Cancel");
            }

            if (this.ddlApprovalRoute.Items.Count == 0)
            {
                this.SetMessage(this.ddlApprovalRoute.ID, M_Message.MSG_PLEASE_SELECT, "Approval Route");
            }

            if (this.CheckExistingDateInWorkTotal())
            {
                this.SetMessage(string.Empty, M_Message.MSG_CAN_NOT_CANCEL, "Apply No. " + this.btnViewPreVacation.Text);
            }
            return !base.HaveError;
        }

        /// <summary>
        /// RestoreListApprove
        /// </summary>
        private void RestoreListApprove()
        {
            //this.colorStatus = base.GetStatusColorLabel(this.ApplyStatus, ref this.statusNameLbl);
            this.rptApproverList.DataSource = this.ApproverList;
        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                //approveUserList = applyApproveSer.GetByApplyNo(vacNo);
                return applyApproveSer.GetListByIDOptionLevel(this.DataNo, isIncludeView, includeZeroLV);
            }
        }

        ///// <summary>
        ///// GetListApproveUserFromApply
        ///// </summary>
        ///// <returns></returns>
        //private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo)
        //{
        //    IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
        //    WorkApproveService applyApproveSer = new WorkApproveService();
        //    approveUserList = applyApproveSer.GetByApplyNo(vacNo);
        //    return approveUserList;
        //}

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns></returns>
        private T_Work_OT GetApplyByID(int AppID)
        {
            using (DB db = new DB())
            {
                T_Work_OT apply = new T_Work_OT();
                WorkOTService appSer = new WorkOTService(db);
                apply = appSer.GetByID(AppID);
                return apply;
            }
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadDataForApproveListFromApproveList(string vacNo, bool isIncludeView = false)
        {
            //this.colorStatus = base.GetStatusColorLabel((this.GetApplyByID(this.ApplyID)).ApplyStatus, ref this.statusNameLbl);
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);

            if (applyList != null && applyList.Count != 0)
            {
                IList<WorkApproveModel> allowList = new List<WorkApproveModel>();
                if (!isIncludeView)
                {
                    var lstTemp = (from i in applyList
                                   where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                                   select i).ToList<WorkApproveModel>();
                    if (lstTemp != null)
                    {
                        ((List<WorkApproveModel>)allowList).AddRange(lstTemp);
                    }
                }
                else
                {
                    ((List<WorkApproveModel>)allowList).AddRange(applyList);
                }
                //  this.countListApprover = allowList.Count;
                this.ApproverList = new List<WorkApproveModel>(allowList);
                // this.isHasData = true;
                this.rptApproverList.DataSource = allowList;
                this.ApproverList = new List<WorkApproveModel>();
                ((List<WorkApproveModel>)this.ApproverList).AddRange(allowList);


            }
            else
            {
                //   this.countListApprover = 0;
                this.ApproverList = new List<WorkApproveModel>();
                //  this.isHasData = false;
                this.rptApproverList.DataSource = null;
                this.ApproverList = null;
            }
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool Confirm()
        {
            ApplyFucntion appFunc = new ApplyFucntion(this.ApplyID, this.LoginInfo.User, ApplyType.OverTime, this.OldUpdateDate, GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));
            bool ret = false;
            ProcessResult proc = appFunc.Confirm();
            switch (proc)
            {
                case ProcessResult.Success:
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }

        /// <summary>
        /// Get list of approver
        /// </summary>
        /// <param name="TypeID"></param>
        /// <param name="isIncludeView">true: include level 99, false:exclude level 99</param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprovePerson(DB db, int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            //Custom again
            IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
            //IList<WorkApproveModel> allowList = new List<WorkApproveModel>();

            //Get level of leaver 
            //  int? userLevel = 0;
            //UserService userSer = new UserService(db);
            //int employeeID = 0;
            //M_Staff s = this.GetStaffByCD(this.txtEmployeeCD.Value.Trim());
            //if (s != null)
            //{
            //    M_User u = this.GetUserByStaffID(s.ID);
            //    if (u != null)
            //    {
            //        employeeID = u.ID;
            //    }
            //    else
            //    {
            //        return allowList;
            //    }
            //}

            Route_DService service = new Route_DService(db);
            //Get Approve List
            //approveUserList = appApproveListSer.GetApproverListByApplyTypeID(TypeID);
            // approveUserList = service.GetApproverListByTypeAndUserIDForWork(employeeID, isGetLVZero: includeZeroLV ? EnumGetLevelZero.Include : EnumGetLevelZero.Exclude);
            approveUserList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
            #region Comment
            /* if (approveUserList != null && approveUserList.Count != 0)
            {
                if (isIncludeView || includeZeroLV)//Giu nguyen all level hien len
                {
                    ((List<WorkApproveModel>)allowList).AddRange(approveUserList);
                }
                else
                {
                    if (!includeZeroLV)//bo level 0
                    {
                        var lstTemp = (from i in approveUserList
                                       where !i.RouteLevel.Equals(M_Route_H.LEVEL_APPLICANT)
                                       select i).ToList<WorkApproveModel>();
                        //select new ApplyApproveListModel
                        //{
                        //    RowNum = i.RowNum,
                        //    ApplyID = i.ApplyID,
                        //    UserName = i.UserName,
                        //    RouteLevel = i.RouteLevel,
                        //    RouteMethod = i.RouteMethod,
                        //    Department = i.Department,
                        //    Position = i.Position,
                        //    ApproveDate = i.ApproveDate,
                        //    ApproveDateStr = i.ApproveDateStr,
                        //    ApproveUID = i.ApproveUID,
                        //    ApproveName = i.ApproveName,
                        //    ApproveReason = i.ApproveReason,
                        //    ApproveFlagStr = i.ApproveFlagStr,
                        //    RouteUID = i.RouteUID,
                        //    ApproveStatus = i.ApproveStatus,
                        //    //cac flag moi them vao

                        //    RouteMethodStr = i.RouteMethodStr

                        //};
                        if (lstTemp != null)
                        {
                            // ((List<ApplyApproveListModel>)approveUserList).AddRange(lstTemp);
                            approveUserList = new List<WorkApproveModel>(lstTemp);
                        }
                    }

                    if (!isIncludeView)//bo level view (99)
                    {
                        var lstTemp = (from i in approveUserList
                                       where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                                       select i).ToList<WorkApproveModel>();
                        //select new ApplyApproveListModel
                        //{
                        //    RowNum = i.RowNum,
                        //    ApplyID = i.ApplyID,
                        //    UserName = i.UserName,
                        //    RouteLevel = i.RouteLevel,
                        //    RouteMethod = i.RouteMethod,
                        //    Department = i.Department,
                        //    Position = i.Position,
                        //    ApproveDate = i.ApproveDate,
                        //    ApproveDateStr = i.ApproveDateStr,
                        //    ApproveUID = i.ApproveUID,
                        //    ApproveName = i.ApproveName,
                        //    ApproveReason = i.ApproveReason,
                        //    ApproveFlagStr = i.ApproveFlagStr,
                        //    RouteUID = i.RouteUID,
                        //    ApproveStatus = i.ApproveStatus,
                        //    //cac flag moi them vao

                        //    RouteMethodStr = i.RouteMethodStr

                        //};
                        if (lstTemp != null)
                        {
                            // ((List<ApplyApproveListModel>)approveUserList).AddRange(lstTemp);
                            approveUserList = new List<WorkApproveModel>(lstTemp);
                        }
                    }

                    allowList = new List<WorkApproveModel>(approveUserList);
                }
            }
            return allowList;*/
            #endregion
            return approveUserList;
        }

        /// <summary>
        /// Create data for ApplyApproveList 
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="lstApproveUser"></param>
        private IList<T_Work_Approve> CreateApplyApproveListData(T_Work_OT w, IList<WorkApproveModel> lstApproveUser)
        {
            IList<T_Work_Approve> applyApproveList = new List<T_Work_Approve>();
            foreach (WorkApproveModel item in lstApproveUser)
            {
                T_Work_Approve model = new T_Work_Approve();
                Hashtable htbUserID = new Hashtable();
                model.ApplyNo = w.No;
                if (item.RouteLevel == M_Route_H.LEVEL_APPLICANT)
                {
                    model.RouteUID = w.UserID;
                }
                else
                {
                    model.RouteUID = item.RouteUID;
                }
                model.RouteLevel = item.RouteLevel.Value;
                model.RouteMethod = item.RouteMethod.Value;
                // model.ApproveStatus = item.ApproveStatus;
                model.ApproveUID = item.ApproveUID;
                model.ApproveDate = item.ApproveDate;
                model.ApproveReason = item.ApproveReason;
                model.RequireNum = item.RequireNum;
                model.ApproveStatus = (int)StatusHasAprove.New;

                model.ProxyApprovalUser = item.ProxyApprovalUser;
                //Apply Flag
                model.ApplyFlag1 = item.ApplyFlag1;
                model.ApplyFlag2 = item.ApplyFlag2;
                model.ApplyFlag3 = item.ApplyFlag3;
                model.ApplyFlag4 = item.ApplyFlag4;

                //Reject Flag
                model.RejectFlag1 = item.RejectFlag1;
                model.RejectFlag2 = item.RejectFlag2;
                model.RejectFlag3 = item.RejectFlag3;
                model.RejectFlag4 = item.RejectFlag4;
                model.RejectFlag5 = item.RejectFlag5;
                model.RejectFlag6 = item.RejectFlag6;
                model.RejectFlag7 = item.RejectFlag7;

                //Remand Flag
                model.RemandFlag1 = item.RemandFlag1;
                model.RemandFlag2 = item.RemandFlag2;
                model.RemandFlag3 = item.RemandFlag3;
                model.RemandFlag4 = item.RemandFlag4;
                model.RemandFlag5 = item.RemandFlag5;
                model.RemandFlag6 = item.RemandFlag6;
                model.RemandFlag7 = item.RemandFlag7;

                //Approve Flag
                model.ApproveFlag1 = item.ApproveFlag1;
                model.ApproveFlag2 = item.ApproveFlag2;
                model.ApproveFlag3 = item.ApproveFlag3;
                model.ApproveFlag4 = item.ApproveFlag4;
                model.ApproveFlag5 = item.ApproveFlag5;
                model.ApproveFlag6 = item.ApproveFlag6;
                model.ApproveFlag7 = item.ApproveFlag7;
                model.ApproveFlag8 = item.ApproveFlag8;
                model.ApproveFlag9 = item.ApproveFlag9;

                //Read Flag
                model.ReadFlag1 = item.ReadFlag1;
                model.ReadFlag2 = item.ReadFlag2;
                model.ReadFlag3 = item.ReadFlag3;
                model.ReadFlag4 = item.ReadFlag4;
                model.ReadFlag5 = item.ReadFlag5;

                applyApproveList.Add(model);
            }

            return applyApproveList;
        }

        /// <summary>
        /// Get list Email
        /// </summary>
        /// <returns>List of email</returns>
        private IList<string> GetListEmail()
        {
            using (DB db = new DB())
            {
                IList<string> lstEmail = new List<string>();
                WorkApproveService approveSer = new WorkApproveService(db);

                IList<WorkApproveModel> applicantInfoList = approveSer.GetListByIDOptionLevel(this.DataNo, false, EnumGetLevelZero.Only);
                if (applicantInfoList != null && applicantInfoList.Count > 0)
                {
                    if (applicantInfoList[0].GetApplySetting(ApplySetting.MailAll))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(this.DataNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.GreaterLevel);
                        return lstEmail;
                    }
                    else if (applicantInfoList[0].GetApplySetting(ApplySetting.Mail))
                    {
                        lstEmail = approveSer.GetListEmailByLevelAprove(this.DataNo, applicantInfoList[0].RouteLevel.Value, (short)SendMailMode.NextLevel);
                    }
                }
                return lstEmail;
            }
        }

        private bool IsDuplicateTimeApply(string applyNo, int userId, DateTime startTime, DateTime endTime)
        {
            using (DB db = new DB())
            {
                WorkApplyTimeService wSer = new WorkApplyTimeService(db);
                bool isDuplicate = wSer.IsDuplicateTimeApply(applyNo, userId, startTime, endTime);
                return isDuplicate;
            }
        }

        private void InsertTimeApply(string applyNo, int userId, DateTime startTime, DateTime endTime)
        {
            using (DB db = new DB())
            {
                T_Work_ApplyTime w = new T_Work_ApplyTime();
                WorkApplyTimeService wSer = new WorkApplyTimeService(db);

                w.ApplyNo = applyNo;
                w.UserID = userId;
                w.StartTime = startTime;
                w.EndTime = endTime;
                wSer.Insert(w);
            }
        }

        private void UpdateTimeApply(string applyNo, int userId, DateTime startTime, DateTime endTime)
        {
            using (DB db = new DB())
            {
                T_Work_ApplyTime w = new T_Work_ApplyTime();
                WorkApplyTimeService wSer = new WorkApplyTimeService(db);

                w.ApplyNo = applyNo;
                w.UserID = userId;
                w.StartTime = startTime;
                w.EndTime = endTime;
                wSer.Update(w);
            }
        }

        private void DeleteTimeApply(string applyNo)
        {
            using (DB db = new DB())
            {
                WorkApplyTimeService wSer = new WorkApplyTimeService(db);
                wSer.Delete(applyNo);
            }
        }

        /// <summary>
        /// SetValueForHiddenProxy
        /// </summary>
        private void SetValueForHiddenProxy(DB db, int routeID)
        {
            bool applyFlag1 = false;
            bool applyFlag2 = false;

            M_Route_D routeD = this.GetRouteLevelZeroByRouteID(db, routeID);
            if (routeD != null)
            {
                applyFlag1 = routeD.ApplyFlag1 == 1;
                applyFlag2 = routeD.ApplyFlag2 == 1;
            }
            if (applyFlag1)//Proxy All in a route
            {
                this.hdnProxyAll.Value = "1";
            }
            else if (applyFlag2)//Proxy Dept.
            {
                this.hdnProxyDept.Value = "1";
            }
        }

        /// <summary>
        /// GetRouteLevelZeroByRouteID
        /// </summary>
        /// <param name="RouteID"></param>
        /// <returns></returns>
        private M_Route_D GetRouteLevelZeroByRouteID(DB db, int RouteID)
        {

            Route_DService routeSer = new Route_DService(db);
            var lstItem = routeSer.GetByRouteIDForWork(RouteID, isGetLVZero: EnumGetLevelZero.Only);
            if (lstItem != null && lstItem.Count > 0)
            {
                return lstItem[0];
            }

            return null;
        }

        /// <summary>
        /// GetRouteByUserID
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_Route_H GetRouteByUserID(int userID)
        {
            using (DB db = new DB())
            {
                Route_HService service = new Route_HService(db);
                return service.GetByTypeAndUserIDForWork(M_Config_D.TEMPLATE_FORM_APPLY_OT, userID);
            }
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// isHasData
        /// </summary>
        /// <returns></returns>
        public bool isHasData()
        {
            return (this.ApproverList != null && this.ApproverList.Count > 0);
        }

        private void SetDataForShift(M_Work_Shift ws, bool isEmpty = false)
        {
            if (!isEmpty)
            {
                this.lbShiftName.Text = string.Empty;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = "-1";
                this.hdShiftName.Value = string.Empty;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;
            }
            else
            {
                this.lbShiftName.Text = ws.ShiftName;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = ws.ID.ToString();
                this.hdShiftName.Value = ws.ShiftName;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;

                if (ws.StartHour != null)
                {
                    this.lbStartTime.Text = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.lbEndTime.Text = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                    this.hdStartTime.Value = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.hdEndTime.Value = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                }
            }
        }


        #endregion

        #region WebMethod

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetEmployeeName(string employeeCD, string loginUserCD)
        {
            var employeeCd = employeeCD;
            var employeeCdShow = employeeCD;
            employeeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(employeeCd, M_User.USER_CODE_MAX_LENGTH);
            employeeCdShow = EditDataUtil.ToFixCodeShow(employeeCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    StaffService serv = new StaffService(db);
                    M_Staff model = serv.GetByStaffCD(employeeCd);
                    if (model != null)
                    {
                        UserService userSer = new UserService(db);
                        M_UserInfo u = userSer.GetUserInfoByStaffID(model.ID);
                        if (u != null)
                        {
                            Route_HService routeSer = new Route_HService(db);
                            IList<M_Route_H> lstRet = routeSer.GetListRouteBy2UserCD(M_Config_D.TEMPLATE_FORM_APPLY_OT, u.UserCD, loginUserCD);
                            if (lstRet != null && lstRet.Count > 0)
                            {
                                DepartmentService deptSer = new DepartmentService(db);
                                M_Department dept = deptSer.GetByID(model.DepartmentID);
                                Config_DService confSer = new Config_DService(db);
                                string pos = confSer.GetValue2(M_Config_H.CONFIG_CD_POSITION, model.Position);
                                var result = new
                                {
                                    employeeCD = employeeCdShow,
                                    employeeNm = model.StaffName,
                                    department = dept != null ? dept.DepartmentName : string.Empty,
                                    position = pos

                                };
                                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                            }
                        }
                    }
                }

                var employee = new
                {
                    employeeCD = employeeCdShow
                };

                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(employee);
            }
            catch (Exception)
            {
                return null;
            }

        }

        /// <summary>
        /// Calc Dependent Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string GetTimeByDate(string Date)
        {
            try
            {
                using (DB db = new DB())
                {
                    WorkOTService wOT = new WorkOTService(db);
                    M_Work_Shift ws = new M_Work_Shift();
                    ws = wOT.GetWorkingShiftByDate(DateTime.ParseExact(Date, Constants.FMT_DATE, CultureInfo.InvariantCulture));
                    System.Text.StringBuilder result = new System.Text.StringBuilder();

                    result.Append("{");
                    result.Append(string.Format("\"ddlShiftPattern\":\"{0}\"", ws == null ? -1 : ws.ID));
                    result.Append("}");

                    return result.ToString();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1">Start Date</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalWorkTime(string processDate, int shiftId, string startTime, string endTime)
        {
            try
            {
                if (string.IsNullOrEmpty(startTime) || string.IsNullOrEmpty(endTime) || endTime.CompareTo(startTime) <= 0)
                {
                    var result = new
                    {
                        earlyOT = "",
                        normal1OT = "",
                        normal2OT = "",
                        lateNightOT = "",
                        holiday1OT = "",
                        holiday2OT = ""
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }

                var arrST = startTime.Split(':');
                var arrET = endTime.Split(':');

                TimeSpan earlyOT = new TimeSpan();
                TimeSpan normal1OT = new TimeSpan();
                TimeSpan normal2OT = new TimeSpan();
                TimeSpan lateNightOT = new TimeSpan();
                TimeSpan holiday1OT = new TimeSpan();
                TimeSpan holiday2OT = new TimeSpan();

                DateTime workST = new DateTime(1, 1, 1).AddHours(int.Parse(arrST[0])).AddMinutes(int.Parse(arrST[1]));
                DateTime workET = new DateTime(1, 1, 1).AddHours(int.Parse(arrET[0])).AddMinutes(int.Parse(arrET[1]));

                DateTime startWorkTime = workST;
                DateTime endWorkTime = workET;

                DateTime workOTBeforeST = new DateTime(1, 1, 1);
                DateTime workOTBeforeET = new DateTime(1, 1, 1);
                DateTime workOTAfterST = new DateTime(1, 1, 1);
                DateTime workOTAfterET = new DateTime(1, 1, 1);

                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    HolidayService holidaySer = new HolidayService(db);
                    RestTimeService restTSer = new RestTimeService(db);
                    AccountingService accSer = new AccountingService(db);

                    M_Work_Shift shift = shiftSer.GetByID(shiftId);
                    IList<RestTime> lstRestTime = restTSer.GetListByShiftID(shiftId);
                    M_Accounting accouting = accSer.GetData();

                    DateTime shiftST = new DateTime(1, 1, 1);
                    DateTime shiftET = new DateTime(1, 1, 1);
                    if (shift.StartHour != null)
                    {
                        shiftST = new DateTime(1, 1, 1).AddHours((int)shift.StartHour).AddMinutes((int)shift.StartMinute);
                        shiftET = new DateTime(1, 1, 1).AddHours((int)shift.EndHour).AddMinutes((int)shift.EndMinute);
                    }

                    //over time morning
                    if (startWorkTime < shiftST)
                    {
                        workOTBeforeST = startWorkTime;
                        workOTBeforeET = endWorkTime < shiftST ? endWorkTime : shiftST;
                    }

                    //over time everning
                    if (endWorkTime > shiftET)
                    {
                        workOTAfterST = startWorkTime > shiftET ? startWorkTime : shiftET;
                        workOTAfterET = endWorkTime;
                    }

                    //overtime calculate
                    TimeSpan normalOT = new TimeSpan();
                    if (workOTBeforeST != new DateTime(1, 1, 1) && workOTBeforeET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTBeforeST, workOTBeforeET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }
                    if (workOTAfterST != new DateTime(1, 1, 1) && workOTAfterET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTAfterST, workOTAfterET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }

                    //round overtime
                    earlyOT = EditDataUtil.RoundTime(earlyOT, accouting.UnitOfTime, accouting.RoundOT);
                    normalOT = EditDataUtil.RoundTime(normalOT, accouting.UnitOfTime, accouting.RoundOT);

                    DateTime pDate = DateTime.ParseExact(processDate, Constants.FMT_DATE, CultureInfo.InvariantCulture);
                    if (holidaySer.GetByDay(pDate) != null)
                    {
                        holiday2OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        holiday1OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Saturday)
                    {
                        normal2OT = normalOT;
                    }
                    else
                    {
                        normal1OT = normalOT;
                    }

                    //Round
                    lateNightOT = EditDataUtil.RoundTime(lateNightOT, accouting.UnitOfTime, accouting.RoundOT);
                }

                var ret = new
                {
                    earlyOT = FormatTimeResult(earlyOT),
                    normal1OT = FormatTimeResult(normal1OT),
                    normal2OT = FormatTimeResult(normal2OT),
                    lateNightOT = FormatTimeResult(lateNightOT),
                    holiday1OT = FormatTimeResult(holiday1OT),
                    holiday2OT = FormatTimeResult(holiday2OT)
                };
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(ret);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Format time result
        /// </summary>
        /// <param name="inVal"></param>
        /// <returns></returns>
        private static string FormatTimeResult(TimeSpan inVal)
        {
            if (inVal.TotalMinutes > 0)
            {
                return string.Format("{0:00}:{1:00}", inVal.Hours, inVal.Minutes);
            }
            else
            {
                return string.Empty;
            }
        }
        #endregion
    }
}
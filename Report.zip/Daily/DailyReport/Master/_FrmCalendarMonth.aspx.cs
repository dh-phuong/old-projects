﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;

namespace DailyReport.Master
{
    public partial class _FrmCalendarMonth : System.Web.UI.Page
    {
        public readonly string[] DayNames = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };

        public DateTime nowDate { get; set; }

        public DateTime currentDate
        {
            get { return (DateTime)ViewState["currentDate"]; }
            set { ViewState["currentDate"] = value; }
        }

        protected override void OnInit(EventArgs e)
        {
            this.btnPre.ServerClick += new EventHandler(btnPre_Click);
            this.btnNext.ServerClick += new EventHandler(btnNext_Click);
            this.btnPicker.ServerClick += new EventHandler(btnPicker_Click);
            this.btnToday.ServerClick += new EventHandler(btnToday_Click);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            this.nowDate = DateTime.Now.Date;
            if (!IsPostBack)
            {
                this.currentDate = DateTime.Now.Date;
                this.txtDate.Value = DateTime.Now.Date;

                this.LoadCalendar(this.currentDate);
            }
        }

        protected void btnToday_Click(object sender, EventArgs e)
        {
            this.LoadCalendar(this.nowDate);
        }

        protected void btnPicker_Click(object sender, EventArgs e)
        {
            this.LoadCalendar((DateTime)this.txtDate.Value);
        }

        protected void btnPre_Click(object sender, EventArgs e)
        {
            this.LoadCalendar(this.currentDate.AddMonths(-1));
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            this.LoadCalendar(this.currentDate.AddMonths(1));
        }

        public List<M_Holiday> GetHoliday(DateTime dateFrom, DateTime dateTo)
        {
            try
            {
                HolidayService holidaySer = new HolidayService();
                return holidaySer.GetHolidayInfo(dateFrom, dateTo).ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void LoadCalendar(DateTime date)
        {
            this.currentDate = date;

            List<WeekInfo> lstData = new List<WeekInfo>();

            int dayInMonth = DateTime.DaysInMonth(date.Year, date.Month);
            var firstDayInMonth = new DateTime(date.Year, date.Month, 1);
            var lastDayInMonth = new DateTime(date.Year, date.Month, dayInMonth);

            //firts day display
            var firstDayInView = DateTime.Now;
            if (firstDayInMonth.DayOfWeek == DayOfWeek.Sunday)
            {
                firstDayInView = firstDayInMonth.AddDays(-7);
            }
            else
            {
                firstDayInView = firstDayInMonth.AddDays(-1 * (int)firstDayInMonth.DayOfWeek);
            }

            // last day display
            var lastDayInView = lastDayInMonth.AddDays((int)(6 - lastDayInMonth.DayOfWeek));

            List<M_Holiday> lstHoliday = GetHoliday(firstDayInView, lastDayInView);

            // add data month
            DateTime iDay = firstDayInView;
            for (int week = 1; week <= 6; week++)
            {
                WeekInfo weekData = new WeekInfo();
                for (int i = 0; i < 7; i++)
                {
                    DayOfWeekInfo dayInfo = new DayOfWeekInfo();
                    dayInfo.Day = iDay;

                    if (iDay == this.nowDate)
                    {
                        dayInfo.Css += "fc-today ";
                    }

                    if (lstHoliday.Count > 0)
                    {
                        dayInfo.HolidayName = (from holiday in lstHoliday
                                               where holiday.HolidayDay == iDay.Day && holiday.HolidayMonth == iDay.Month && holiday.HolidayYear == iDay.Year
                                               select holiday.HolidayName).FirstOrDefault();
                        if (!string.IsNullOrEmpty(dayInfo.HolidayName))
                        {
                            dayInfo.Css += "day-cell-weekend ";
                        }
                    }

                    if (iDay.Month != date.Month)
                    {
                        dayInfo.Css += "fc-other-month ";
                    }

                    iDay = iDay.AddDays(1);
                    weekData.AddDayInfo(dayInfo);
                }
                lstData.Add(weekData);
            }

            this.rptDay.DataSource = lstData;
            this.rptDay.DataBind();

            /*Header*/
            this.rptDayName.DataSource = DayNames;
            this.rptDayName.DataBind();
        }

        //public DateTime[] GetMonthDisplayLimits(int year, int month)
        //{
        //    int lastDay = DateTime.DaysInMonth(year, month);
        //    var firstDayInMonth = new DateTime(year, month, 1);
        //    var lastDayInMonth = new DateTime(year, month, lastDay);

        //    var firstDayInView = firstDayInMonth.AddDays(-1 * (int)firstDayInMonth.DayOfWeek);
        //    if (firstDayInView.DayOfWeek == DayOfWeek.Sunday)
        //    {
        //        firstDayInView = firstDayInMonth.AddDays(-7);
        //    }
        //    var lastDayInView = lastDayInMonth.AddDays((int)(6 - lastDayInMonth.DayOfWeek));


        //    /*-----------*/
        //    DateTime StartDate = firstDayInView;
        //    DateTime EndDate = lastDayInView;
        //    int DayInterval = 3;

        //    List<DateTime> dateList = new List<DateTime>();
        //    while (StartDate.AddDays(DayInterval) <= EndDate)
        //    {
        //        StartDate = StartDate.AddDays(DayInterval);
        //        dateList.Add(StartDate);
        //    }
        //}
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// Class Config Detail
    /// Create Date: 2014/07/31
    /// Create Author: VN-Nho
    /// Updated by      : TRAM - 2015/05/14
    /// Update Content  : Moving getting and updating data from M_User to M_Staff
    /// </summary>
    public partial class FrmAddAnnualDays : FrmBaseDetail
    {
        #region Variable

        /// <summary>
        /// URL form list
        /// </summary>
        private const string URL_LIST = "~/Master/FrmStaffList.aspx";

        #endregion

        #region Property

        /// <summary>
        /// Repeater data source information
        /// </summary>
        private Hashtable RptDataInfo
        {
            get { return (Hashtable)ViewState["RptDataInfo"]; }
            set { ViewState["RptDataInfo"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Add Annual Days";
            base.FormSubTitle = "";

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (base.LoginInfo == null)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                this.SetDataDepartmentCbo();
                this.SetDataAnnualDaysCbo();

                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.ViewState["Condition"] = base.PreviousPageViewState["Condition"];
                }

                this.LoadRptData();
                this.Mode = Utilities.Mode.Update;
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadRptData();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmdAnnualDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            IList<AnnualDayInfo> lstData = this.GetRptData();
            this.CalAnnualDays(lstData);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lstData"></param>
        private void CalAnnualDays(IList<AnnualDayInfo> lstData)
        {

            Hashtable dataInfo = new Hashtable();
            foreach (var item in lstData)
            {
                DateTime tempDate = new DateTime(item.OldAnnualDate.AddDays(1).Year, item.StartWorkDate.Month, item.StartWorkDate.Day);

                if (tempDate >= item.OldAnnualDate && tempDate <= item.OldAnnualDate.AddMonths(int.Parse(this.cmbAnnualDays.SelectedValue)))
                {
                    item.ExtraDays = (item.OldAnnualDate.AddMonths(int.Parse(this.cmbAnnualDays.SelectedValue)).Year - item.StartWorkDate.Year) / 5;
                }
                else
                {
                    item.ExtraDays = 0;
                }

                item.Total = int.Parse(this.cmbAnnualDays.SelectedValue) + item.ExtraDays + item.BonusDays + item.OldAnnualDays;
                dataInfo.Add(item.ID, item);
            }

            this.RptDataInfo = dataInfo;

            this.rptList.DataSource = lstData;
            this.rptList.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<AnnualDayInfo> GetRptData()
        {
            IList<AnnualDayInfo> retLst = new List<AnnualDayInfo>();

            foreach (RepeaterItem item in this.rptList.Items)
            {
                HiddenField hidID = (HiddenField)item.FindControl("hidID");
                INumberTextBox txtExtraDays = (INumberTextBox)item.FindControl("txtExtraDays");
                INumberTextBox txtBonusDays = (INumberTextBox)item.FindControl("txtBonusDays");
                INumberTextBox txtTotal = (INumberTextBox)item.FindControl("txtTotal");

                AnnualDayInfo addItem = (AnnualDayInfo)this.RptDataInfo[int.Parse(hidID.Value)];
                addItem.ExtraDays = (decimal)txtExtraDays.Value;
                if (txtBonusDays.Value == null)
                {
                    addItem.BonusDays = 0;
                }
                else
                {
                    addItem.BonusDays = (decimal)txtBonusDays.Value;
                }
                addItem.Total = (decimal)txtTotal.Value;
                retLst.Add(addItem);
            }

            return retLst;
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(false);
                this.cmbDepartment.DataSource = lstDB;
            }
            this.cmbDepartment.DataValueField = "Value";
            this.cmbDepartment.DataTextField = "DisplayName";
            this.cmbDepartment.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataAnnualDaysCbo()
        {
            // init combox 
            this.cmbAnnualDays.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_ANNUAL_DAY);
            this.cmbAnnualDays.DataValueField = "Value";
            this.cmbAnnualDays.DataTextField = "DisplayName";
            this.cmbAnnualDays.DataBind();
            this.cmbAnnualDays.SelectedValue = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_ANNUAL_DAY);
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);
            }
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Event Button Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }
               
        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            //Update Data

            ret = this.UpdateData();
            if (ret)
            {
                this.LoadRptData();

                //Set Success
                this.Success = true;
            }
        }
    
        #endregion

        #region Method

        /// <summary>
        /// Load repeater data
        /// </summary>
        private void LoadRptData()
        {
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            IList<AnnualDayInfo> lstData = new List<AnnualDayInfo>();
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                lstData = staffSer.GetListAnnualByDeptID(int.Parse(cmbDepartment.SelectedValue));
            }
            
            this.CalAnnualDays(lstData);

            base.DisabledLink(this.btnSubmit, !(lstData.Count > 0));
           
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set mode
            this.Mode = mode;

        }

        /// <summary>
        /// Add display error for control
        /// </summary>
        /// <param name="divCtrl">div error control</param>
        /// <param name="errorKey">Error Control ID</param>
        private void AddErrorForListItem(HtmlGenericControl divCtrl, string errorKey)
        {
            divCtrl.Attributes.Add("class", "form-group " + base.GetClassError(errorKey));
        }
                
        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                //Update                     
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Update detail
                    StaffService staffSer = new StaffService(db);
                    IList<AnnualDayInfo> gridList = this.GetRptData();
                    IList<AnnualDayInfo> databaseList = staffSer.GetListAnnualByDeptID(int.Parse(cmbDepartment.SelectedValue));
                    if (gridList.Count != databaseList.Count)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    foreach (var item in gridList)
                    {
                        AnnualDayInfo databaseItem = (from info in databaseList
                                                      where info.StaffCD == item.StaffCD
                                                      select info).SingleOrDefault();
                        if (item.UpdateDate != databaseItem.UpdateDate)
                        {
                            //Data is changed
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        M_Staff updateItem = new M_Staff();
                        updateItem.ID = item.ID;
                        updateItem.AnnualDays = item.Total;
                        updateItem.AnnualToDate = item.OldAnnualDate.AddMonths(int.Parse(cmbAnnualDays.SelectedValue));
                        updateItem.UpdateUID = this.LoginInfo.User.ID;
                        updateItem.UpdateDate = item.UpdateDate;
                        staffSer.UpdateAnnualDay(updateItem); ;
                    }
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        #endregion
    }
}
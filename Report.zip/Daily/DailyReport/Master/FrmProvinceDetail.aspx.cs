﻿using System;
using System.Data.SqlClient;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Web.UI.WebControls;


namespace DailyReport.Master
{
    /// <summary>
    /// Form:   FrmProvinceDetail
    /// Author: VN-Nho
    /// </summary>
    public partial class FrmProvinceDetail : FrmBaseDetail
    {
        #region Constants
            private const string URL_LIST = "~/Master/FrmProvinceList.aspx";
        #endregion
   
        #region Property

        /// <summary>
        /// Get or set ProvinceID
        /// </summary>
        public int ProvinceID
        {
            get { return (int)ViewState["ProvinceID"]; }
            set { ViewState["ProvinceID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

            /// <summary>
            /// Event Init
            /// </summary>
            /// <param name="e"></param>
            protected override void OnInit(EventArgs e)
            {
                base.OnInit(e);

                //Set Title
                base.FormTitle = "Province Master";
                base.FormSubTitle = "Detail";

                //Init Max Length                        
                this.txtProvinceCD.MaxLength = M_Province.PROVINCE_CODE_MAX_LEN_SHOW;
                this.txtProvinceName.MaxLength = M_Province.PROVINCE_NAME_MAX_LEN;

                //Init Event
                LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
                btnYes.Click += new EventHandler(btnProcessData);
                LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
                btnNo.Click += new EventHandler(btnShowData);
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void Page_Load(object sender, EventArgs e)
            {
                //Check authority of login user
                base.SetAuthority(FormId.Province);
                if (!this._authority.IsMasterView)
                {
                    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
                }

                if (!this.IsPostBack)
                {
                    if (this.PreviousPage != null)
                    {
                        //Save condition of previous page
                        this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                        //Check mode
                        if (this.PreviousPageViewState["ID"] == null)
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                        else
                        {
                            //Get User ID
                            this.ProvinceID = int.Parse(this.PreviousPageViewState["ID"].ToString());
                            M_Province data = this.GetProvince(this.ProvinceID);

                            //Check user
                            if (data != null)
                            {
                                //Show data
                                this.ShowData(data);

                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                Server.Transfer(URL_LIST);
                            }
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }

                //Set init
                this.Success = false;
            }

            /// <summary>
            /// Copy Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnCopy_Click(object sender, EventArgs e)
            {
                //Get data
                M_Province data = this.GetProvince(this.ProvinceID);

                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Copy);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// New Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnNew_Click(object sender, EventArgs e)
            {
                this.ClearValue();

                //Set Mode
                this.ProcessMode(Mode.Insert);
            }

            /// <summary>
            /// Edit Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnEdit_Click(object sender, EventArgs e)
            {
                //Get Data
                M_Province data = this.GetProvince(this.ProvinceID);

                //Check data
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Event Insert Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnInsert_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Update Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnUpdate_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Delete
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnDelete_Click(object sender, EventArgs e)
            {
                //Set Model
                this.Mode = Mode.Delete;

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
            }


            /// <summary>
            /// Event Back
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnBack_Click(object sender, EventArgs e)
            {
                //Get Department
                M_Province data = this.GetProvince(this.ProvinceID);

                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

           
            /// <summary>
            /// Process Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnProcessData(object sender, EventArgs e)
            {
                bool ret;
                M_Province data = null;

                //Check Mode
                switch (this.Mode)
                {
                    case Utilities.Mode.Insert:
                    case Utilities.Mode.Copy:

                        //Insert Data
                        ret = this.InsertData();
                        if (ret)
                        {
                            //Get User
                            data = this.GetProvince(this.txtProvinceCD.Value);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                        break;

                    case Utilities.Mode.Delete:

                        //Delete Department
                        if (!this.DeleteData())
                        {
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                        break;
                    case Utilities.Mode.Update:

                        //Update Data
                        ret = this.UpdateData();
                        if (ret)
                        {
                            //Get Department
                            data = this.GetProvince(this.ProvinceID);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }

                        break;
                }

            }


            /// <summary>
            /// Show Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnShowData(object sender, EventArgs e)
            {
                //Get Province
                M_Province data = this.GetProvince(this.ProvinceID);
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Clear value screen
            /// </summary>
            private void ClearValue()
            {
                this.txtProvinceCD.Value = string.Empty;
                this.txtProvinceName.Value = string.Empty;
            }
        #endregion

        #region Methods

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                    this.txtProvinceCD.ReadOnly = false;
                    this.txtProvinceName.ReadOnly = false;
                    break;

                case Mode.Update:
                    this.txtProvinceCD.ReadOnly = true;
                    this.txtProvinceName.ReadOnly = false;
                    break;

                default:
                    this.txtProvinceCD.ReadOnly = true;
                    this.txtProvinceName.ReadOnly = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                        
                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="province">M_Province</param>
        private void ShowData(M_Province province)
        {
            //Show data
            if (province != null)
            {
                this.txtProvinceCD.Value = Utilities.EditDataUtil.ToFixCodeShow(province.ProvinceCD, M_Province.PROVINCE_CODE_MAX_LEN_SHOW); 
                this.txtProvinceName.Value = province.ProvinceName;

                //Save UserID and UpdateDate
                this.ProvinceID = province.ID;
                this.OldUpdateDate = province.UpdateDate;
            }
        }

        /// <summary>
        /// Get Province by id
        /// </summary>
        /// <param name="provinceID">province id</param>
        /// <returns>province model</returns>
        private M_Province GetProvince(int provinceID)
        {
            using (DB db = new DB())
            {
                ProvinceService service = new ProvinceService(db);

                //Get Department
                return service.GetByID(provinceID);
            }
        }

        /// <summary>
        /// Get province by code
        /// </summary>
        /// <param name="provinceCD">province code</param>
        /// <returns>province model</returns>
        private M_Province GetProvince(string provinceCD)
        {
            using (DB db = new DB())
            {
                ProvinceService service = new ProvinceService(db);

                //Get User
                return service.GetByCD(provinceCD);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //ProvinceCD
            if (this.txtProvinceCD.IsEmpty)
            {
                this.SetMessage("txtProvinceCD", M_Message.MSG_REQUIRE, "Province Code");
            }
            else
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    // Check Province
                    if (this.GetProvince(this.txtProvinceCD.Value) != null)
                    {
                        this.SetMessage("txtProvinceCD", M_Message.MSG_EXIST_CODE, "Province Code");
                    }
                    

                }
            }

            //ProvinceName
            if (this.txtProvinceName.IsEmpty)
            {
                this.SetMessage("txtProvinceName", M_Message.MSG_REQUIRE, "Province Name");
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Province data = new M_Province();
                data.ProvinceCD = this.txtProvinceCD.Value;
                data.ProvinceName = this.txtProvinceName.Value;

                data.CreateUID = base.LoginInfo.User.ID;

                //Insert Category
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ProvinceService serive = new ProvinceService(db);

                    //Insert Category
                    serive.Insert(data);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_PROVINCE_UN))
                {
                    this.SetMessage(this.txtProvinceCD.ID, M_Message.MSG_EXIST_CODE, "Province Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Province data = this.GetProvince(this.txtProvinceCD.Value);
                if (data != null)
                {
                    //Create model
                    data.ProvinceName = this.txtProvinceName.Value;

                    data.UpdateDate = this.OldUpdateDate;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Update category
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        ProvinceService service = new ProvinceService(db);

                        //Update department
                        if (data.Status == DataStatus.Changed)
                        {
                            ret = service.Update(data);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ProvinceService deptService = new ProvinceService(db);

                    //Delete Vendor
                    ret = deptService.Delete(this.ProvinceID, this.OldUpdateDate);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Constant.M_USER_FK_PROVINCE_ID))
                       
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Province Code " + this.txtProvinceCD.Value);
                }

                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

    }
}
﻿using System;
using System.Data.SqlClient;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Web.UI.WebControls;


namespace DailyReport.Master
{
    /// <summary>
    /// Form:   FrmDepartmentDetail
    /// Author: ISV-TRAM
    /// </summary>
    public partial class FrmDepartmentDetail : FrmBaseDetail
    {
        #region Constants
            private const string URL_LIST = "~/Master/FrmDepartmentList.aspx";
        #endregion
   
        #region Property

        /// <summary>
        /// Get or set DepartmentID
        /// </summary>
        public int DepartmentID
        {
            get { return (int)ViewState["DepartmentID"]; }
            set { ViewState["DepartmentID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

            /// <summary>
            /// Event Init
            /// </summary>
            /// <param name="e"></param>
            protected override void OnInit(EventArgs e)
            {
                base.OnInit(e);

                //Set Title
                base.FormTitle = "Department Master";
                base.FormSubTitle = "Detail";

                //Init Max Length                        
                this.txtDepartmentCode.MaxLength = M_Department.MAX_DEPARTRMENT_CODE_SHOW;
                this.txtDepartmentName.MaxLength = M_Department.DEPARTRMENT_NAME_MAX_LENGTH;

                //Init Event
                LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
                btnYes.Click += new EventHandler(btnProcessData);
                LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
                btnNo.Click += new EventHandler(btnShowData);
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void Page_Load(object sender, EventArgs e)
            {
                //Check authority of login user
                base.SetAuthority(FormId.Department);
                if (!this._authority.IsMasterView)
                {
                    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
                }

                if (!this.IsPostBack)
                {
                    if (this.PreviousPage != null)
                    {
                        //Save condition of previous page
                        this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                        //Check mode
                        if (this.PreviousPageViewState["ID"] == null)
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                        else
                        {
                            //Get User ID
                            this.DepartmentID = int.Parse(this.PreviousPageViewState["ID"].ToString());
                            M_Department data = this.GetDepartment(this.DepartmentID);

                            //Check user
                            if (data != null)
                            {
                                //Show data
                                this.ShowData(data);

                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                Server.Transfer(URL_LIST);
                            }
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }

                //Set init
                this.Success = false;
            }

            /// <summary>
            /// Copy Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnCopy_Click(object sender, EventArgs e)
            {
                //Get data
                M_Department data = this.GetDepartment(this.DepartmentID);

                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Copy);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// New Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnNew_Click(object sender, EventArgs e)
            {
                this.ClearValue();

                //Set Mode
                this.ProcessMode(Mode.Insert);
            }

            /// <summary>
            /// Edit Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnEdit_Click(object sender, EventArgs e)
            {
                //Get Data
                M_Department data = this.GetDepartment(this.DepartmentID);

                //Check data
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Event Insert Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnInsert_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Update Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnUpdate_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Delete
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnDelete_Click(object sender, EventArgs e)
            {
                //Set Model
                this.Mode = Mode.Delete;

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
            }


            /// <summary>
            /// Event Back
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnBack_Click(object sender, EventArgs e)
            {
                //Get Department
                M_Department data = this.GetDepartment(this.DepartmentID);

                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

           
            /// <summary>
            /// Process Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnProcessData(object sender, EventArgs e)
            {
                bool ret;
                M_Department data = null;

                //Check Mode
                switch (this.Mode)
                {
                    case Utilities.Mode.Insert:
                    case Utilities.Mode.Copy:

                        //Insert Data
                        ret = this.InsertData();
                        if (ret)
                        {
                            //Get User
                            data = this.GetDepartment(this.txtDepartmentCode.Value);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                        break;

                    case Utilities.Mode.Delete:

                        //Delete Department
                        if (!this.DeleteData())
                        {
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                        break;
                    case Utilities.Mode.Update:

                        //Update Data
                        ret = this.UpdateData();
                        if (ret)
                        {
                            //Get Department
                            data = this.GetDepartment(this.DepartmentID);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }

                        break;
                }

            }


            /// <summary>
            /// Show Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnShowData(object sender, EventArgs e)
            {
                //Get Department
                M_Department data = this.GetDepartment(this.DepartmentID);
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Clear value screen
            /// </summary>
            private void ClearValue()
            {
                this.txtDepartmentCode.Value = string.Empty;
                this.txtDepartmentName.Value = string.Empty;
            }
        #endregion

        #region Methods

            /// <summary>
            /// Process Mode
            /// </summary>
            /// <param name="mode">Mode</param>
            private void ProcessMode(Mode mode)
            {
                //Set Model
                this.Mode = mode;

                //Check model
                switch (mode)
                {
                    case Mode.Insert:
                    case Mode.Copy:
                        this.txtDepartmentCode.ReadOnly = false;
                        this.txtDepartmentName.ReadOnly = false;
                        break;

                    case Mode.Update:
                        this.txtDepartmentCode.ReadOnly = true;
                        this.txtDepartmentName.ReadOnly = false;
                        break;

                    default:
                        this.txtDepartmentCode.ReadOnly = true;
                        this.txtDepartmentName.ReadOnly = true;

                        base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                        base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                        base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                        base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                        
                        break;
                }
            }

            /// <summary>
            /// Show data on form
            /// </summary>
            /// <param name="category">M_Department</param>
            private void ShowData(M_Department department)
            {
                //Show data
                if (department != null)
                {
                    this.txtDepartmentCode.Value = Utilities.EditDataUtil.ToFixCodeShow(department.DepartmentCD, M_Department.MAX_DEPARTRMENT_CODE_SHOW); 
                    this.txtDepartmentName.Value = department.DepartmentName;

                    //Save UserID and UpdateDate
                    this.DepartmentID = department.ID;
                    this.OldUpdateDate = department.UpdateDate;
                }
            }

            /// <summary>
            /// Get Department by Department id
            /// </summary>
            /// <param name="departmentId">Department id</param>
            /// <returns>M_Department model</returns>
            private M_Department GetDepartment(int departmentId)
            {
                using (DB db = new DB())
                {
                    DepartmentService service = new DepartmentService(db);

                    //Get Department
                    return service.GetByID(departmentId);
                }
            }

            /// <summary>
            /// Get Department by Department code
            /// </summary>
            /// <param name="departmentCd">DepartmentCd</param>
            /// <returns>M_Department model</returns>
            private M_Department GetDepartment(string departmentCd)
            {
                using (DB db = new DB())
                {
                    DepartmentService service = new DepartmentService(db);

                    //Get User
                    return service.GetByCD(departmentCd);
                }
            }

            /// <summary>
            /// Check input
            /// </summary>
            /// <returns>Valid:true, Invalid:false</returns>
            private bool CheckInput()
            {
                //DepartmentCD
                if (this.txtDepartmentCode.IsEmpty)
                {
                    this.SetMessage(this.txtDepartmentCode.ID, M_Message.MSG_REQUIRE, "Department Code");
                }
                else
                {
                    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                    {
                        if (this.txtDepartmentCode.Value == Constant.M_DEPARTMENT_DEFAULT_CODE)
                        {
                            //Diff '0000'
                            this.SetMessage(this.txtDepartmentCode.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Department Code", Constant.M_DEPARTMENT_DEFAULT_CODE);
                        }
                        else
                        {
                            // Check Department
                            if (this.GetDepartment(this.txtDepartmentCode.Value) != null)
                            {
                                this.SetMessage(this.txtDepartmentCode.ID, M_Message.MSG_EXIST_CODE, "Department Code");
                            }
                        }

                    }
                }

                //DepartmentName
                if (this.txtDepartmentName.IsEmpty)
                {
                    this.SetMessage(this.txtDepartmentName.ID, M_Message.MSG_REQUIRE, "Department Name");
                }

                //Check error
                return !base.HaveError;
            }

            /// <summary>
            /// Insert Data
            /// </summary>
            /// <returns>Success:true, Faile:false</returns>
            private bool InsertData()
            {
                try
                {
                    //Create model
                    M_Department data = new M_Department();
                    data.DepartmentCD = this.txtDepartmentCode.Value;
                    data.DepartmentName = this.txtDepartmentName.Value;

                    data.CreateUID = base.LoginInfo.User.ID;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Insert Category
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        DepartmentService serive = new DepartmentService(db);

                        //Insert Category
                        serive.Insert(data);

                        db.Commit();
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Message.Contains(Models.Constant.M_DEPARTMENT_UN))
                    {
                        this.SetMessage(this.txtDepartmentCode.ID, M_Message.MSG_EXIST_CODE, "Department Code");
                    }

                    Log.Instance.WriteLog(ex);

                    return false;
                }
                catch (Exception ex)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                    Log.Instance.WriteLog(ex);
                    return false;
                }

                return true;
            }

            /// <summary>
            /// Update Data
            /// </summary>
            /// <returns>Success:true, Faile:false</returns>
            private bool UpdateData()
            {
                try
                {
                    int ret = 0;
                    M_Department data = this.GetDepartment(this.txtDepartmentCode.Value);
                    if (data != null)
                    {
                        //Create model
                        data.DepartmentName = this.txtDepartmentName.Value;

                        data.UpdateDate = this.OldUpdateDate;
                        data.UpdateUID = base.LoginInfo.User.ID;

                        //Update category
                        using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                        {
                            DepartmentService service = new DepartmentService(db);

                            //Update department
                            if (data.Status == DataStatus.Changed)
                            {
                                ret = service.Update(data);

                                db.Commit();
                            }
                            else
                            {
                                return true;
                            }
                        }
                    }

                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                    Log.Instance.WriteLog(ex);
                    return false;
                }

                return true;
            }

            /// <summary>
            /// Delete Data
            /// </summary>
            /// <returns>True: delete success/False: delete fail</returns>
            private bool DeleteData()
            {
                try
                {
                    int ret = 0;
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        DepartmentService deptService = new DepartmentService(db);

                        //Delete Vendor
                        ret = deptService.Delete(this.DepartmentID, this.OldUpdateDate);
                        db.Commit();
                    }

                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                }
                catch (SqlException ex)
                {
                    if (ex.Message.Contains(Constant.M_STAFF_FK_DEPARTMENTID))
                       
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Department Code " + this.txtDepartmentCode.Value);
                    }

                    Log.Instance.WriteLog(ex);
                    return false;
                }
                catch (Exception ex)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                    Log.Instance.WriteLog(ex);
                    return false;
                }

                return true;
            }

            /// <summary>
            /// Format Department Code
            /// </summary>
            /// <param name="in1">Department Code</param>
            /// <returns>Department Name</returns>
            [System.Web.Services.WebMethod]
            public static string FormatDepartmentCode(string in1)
            {
                try
                {
                    var departmentCD = in1;
                    var departmentCDShow = in1;
                    departmentCD = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(departmentCD, M_Department.MAX_DEPARTRMENT_CODE_SHOW);
                    departmentCDShow = EditDataUtil.ToFixCodeShow(departmentCD, M_Department.MAX_DEPARTRMENT_CODE_SHOW);

                    var onlyCd = new
                    {
                        txtDepartmentCode = departmentCDShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
                catch (Exception)
                {
                    return null;
                }
            }

            #endregion

    }
}
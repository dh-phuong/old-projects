﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;

using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{   
    /// <summary>
    /// ISV-TRUC - 2015/06/23
    /// Template WorkingDay Form
    /// </summary>
    public partial class FrmBaseWorkday : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Apply/FrmApplyList.aspx";
        private const int DEFAULT_VALUE = -1;
        private const int DEFAULT_ZERO = 0;
        #endregion

        #region Variable

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData=false;

        #endregion

        #region Property

        /// <summary>
        /// Get or set WorkingDateList
        /// </summary>
        public IList<WorkDayInfo> WorkingDateList
        {
            get { return (IList<WorkDayInfo>)ViewState["WorkingDateList"]; }
            set { ViewState["WorkingDateList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Base Workday";
            base.FormSubTitle = "";

            // Header grid sort

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);
        }    
            
        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.BaseWorkDay);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmWorksMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                TemplateWorkDayInfo model = this.GetModel();
                if (model != null)
                {
                    this.ShowData(model);
                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    this.ShowData(new TemplateWorkDayInfo());
                    //Set Mode
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// View Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, CommandEventArgs e)
        {

            if (!this.CheckInput())
            {
                return;
            }
            
            //Get data
            //this.ShowData();
        }

        /// <summary>
        /// btnEdit_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            TemplateWorkDayInfo data = this.GetModel();
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnInsert_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnUpdate_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }


        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            TemplateWorkDayInfo data = this.GetModel();
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        
        #endregion

        #region Method


        /// <summary>
        /// ProcessMode
        /// </summary>
        /// <param name="mode"></param>
        private void ProcessMode(Mode mode)
        {
            bool readOnly = false;
            //Set Model
            this.Mode = mode;

            switch (mode)
            {
                case Mode.Insert:
                    readOnly = false;
                    break;
                case Mode.Update:
                    readOnly = false;
                    break;
                default:
                    readOnly = true;
                    break;
            }
            
            this.txtShiftCodeSun.SetReadOnly(readOnly);
            this.txtShiftCodeMon.SetReadOnly(readOnly);
            this.txtShiftCodeTue.SetReadOnly(readOnly);
            this.txtShiftCodeWed.SetReadOnly(readOnly);
            this.txtShiftCodeThu.SetReadOnly(readOnly);
            this.txtShiftCodeFri.SetReadOnly(readOnly);
            this.txtShiftCodeSat.SetReadOnly(readOnly);

            this.txtShiftNameSun.SetReadOnly(true);
            this.txtShiftNameMon.SetReadOnly(true);
            this.txtShiftNameTue.SetReadOnly(true);
            this.txtShiftNameWed.SetReadOnly(true);
            this.txtShiftNameThu.SetReadOnly(true);
            this.txtShiftNameFri.SetReadOnly(true);
            this.txtShiftNameSat.SetReadOnly(true);
            ////Set disable button
            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
        }
        
        /// <summary>
        /// ShowData
        /// </summary>
        private void ShowData(TemplateWorkDayInfo model)
        {
            if (model != null)
            {
               // this.lblSunday.InnerText = model.SunDay;
                this.hdnSunShiftID.Value = model.SunShiftID.ToString();
                this.txtShiftCodeSun.Value = model.SunShiftCD != DEFAULT_VALUE ? model.SunShiftCD.ToString() : string.Empty;
                this.txtShiftNameSun.Value = model.SunShiftName;
                this.hdnTypeOfDaySun.Value = model.SunTypeOfDay != DEFAULT_VALUE ?model.SunTypeOfDay.ToString() : string.Empty;

                //this.lblMonday.InnerText = model.MonDay;
                this.hdnMonShiftID.Value = model.MonShiftID.ToString();
                this.txtShiftCodeMon.Value = model.MonShiftCD != DEFAULT_VALUE ? model.MonShiftCD.ToString() : string.Empty;
                this.txtShiftNameMon.Value = model.MonShiftName;
                this.hdnTypeOfDayMon.Value = model.MonTypeOfDay != DEFAULT_VALUE ?model.MonTypeOfDay.ToString() : string.Empty;

                //this.lblTuesDay.InnerText = model.TuesDay;
                this.hdnTueShiftID.Value = model.TueShiftID.ToString();
                this.txtShiftCodeTue.Value = model.TueShiftCD != DEFAULT_VALUE ? model.TueShiftCD.ToString() : string.Empty;
                this.txtShiftNameTue.Value = model.TueShiftName;
                this.hdnTypeOfDayTue.Value = model.TueTypeOfDay != DEFAULT_VALUE ?model.TueTypeOfDay.ToString() : string.Empty;

              //  this.lblWednesday.InnerText = model.WednesDay;
                this.hdnWedShiftID.Value = model.WedShiftID.ToString();
                this.txtShiftCodeWed.Value = model.WedShiftCD != DEFAULT_VALUE ? model.WedShiftCD.ToString() : string.Empty;
                this.txtShiftNameWed.Value = model.WedShiftName;
                this.hdnTypeOfDayWed.Value = model.WedTypeOfDay != DEFAULT_VALUE ?model.WedTypeOfDay.ToString() : string.Empty;

               // this.lblThursday.InnerText = model.ThursDay;
                this.hdnThuShiftID.Value = model.ThuShiftID.ToString();
                this.txtShiftCodeThu.Value = model.ThuShiftCD != DEFAULT_VALUE ? model.ThuShiftCD.ToString() : string.Empty;
                this.txtShiftNameThu.Value = model.ThuShiftName;
                this.hdnTypeOfDayThu.Value = model.ThuTypeOfDay != DEFAULT_VALUE ?model.ThuTypeOfDay.ToString() : string.Empty;

               // this.lblFriday.InnerText = model.FriDay;
                this.hdnFriShiftID.Value = model.FriShiftID.ToString();
                this.txtShiftCodeFri.Value = model.FriShiftCD != DEFAULT_VALUE ? model.FriShiftCD.ToString() : string.Empty;
                this.txtShiftNameFri.Value = model.FriShiftName;
                this.hdnTypeOfDayFri.Value = model.FriTypeOfDay != DEFAULT_VALUE ?model.FriTypeOfDay.ToString() : string.Empty;

              //  this.lblSaturday.InnerText = model.SaturDay;
                this.hdnSatShiftID.Value = model.SatShiftID.ToString();
                this.txtShiftCodeSat.Value = model.SatShiftCD != DEFAULT_VALUE ? model.SatShiftCD.ToString() : string.Empty;
                this.txtShiftNameSat.Value = model.SatShiftName;
                this.hdnTypeOfDaySat.Value = model.SatTypeOfDay != DEFAULT_VALUE ?model.SatTypeOfDay.ToString() : string.Empty;

            }
        }

        /// <summary>
        /// GetModel
        /// </summary>
        /// <returns></returns>
        private TemplateWorkDayInfo GetModel()
        {
            using (DB db = new DB())
            {
                TemplateWorkDayService ser = new TemplateWorkDayService(db);
                return ser.GetDataModel();
            }
        }

        /// <summary>
        /// Get data
        /// </summary>
        /// <returns></returns>
        private M_Template_WorkDay GetData()
        {
            using (DB db = new DB())
            {
                TemplateWorkDayService ser = new TemplateWorkDayService(db);
                return ser.GetData();
            }
        }

        /// <summary>
        /// btnProcessData
        /// </summary>
        private void btnProcessData(object sender, EventArgs e)
        {
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                    if (this.Insert())
                    {
                        //Show data
                         this.ShowData(this.GetModel());
                         //Set Mode
                         this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }

                    break;

                case Utilities.Mode.Update:
                    if (this.Update())
                    {
                        //Show data
                        this.ShowData(this.GetModel());
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }
                    break;
            }
        }

        /// btnNoProcessData
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
           // this.ReLoadDataForGrid();
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <returns></returns>
        private bool Insert()
        {
            try
            {
                int ret = 0;
                M_Template_WorkDay data = this.GetDataFromScreen();
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {                    
                    if (data != null)
                    {
                        TemplateWorkDayService ser = new TemplateWorkDayService(db);
                        ret = ser.Insert(data);
                        if (ret == 0)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        db.Commit();
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_SUN))
                {
                    this.SetMessage(this.txtShiftCodeSun.ID, M_Message.MSG_DATA_INVALID, "Shift Code Sunday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_MON))
                {
                    this.SetMessage(this.txtShiftCodeMon.ID, M_Message.MSG_DATA_INVALID, "Shift Code Monday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_TUE))
                {
                    this.SetMessage(this.txtShiftCodeTue.ID, M_Message.MSG_DATA_INVALID, "Shift Code Tuesday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_WED))
                {
                    this.SetMessage(this.txtShiftCodeWed.ID, M_Message.MSG_DATA_INVALID, "Shift Code Wednesday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_THU))
                {
                    this.SetMessage(this.txtShiftCodeThu.ID, M_Message.MSG_DATA_INVALID, "Shift Code Thursday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_FRI))
                {
                    this.SetMessage(this.txtShiftCodeFri.ID, M_Message.MSG_DATA_INVALID, "Shift Code Friday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_SAT))
                {
                    this.SetMessage(this.txtShiftCodeSat.ID, M_Message.MSG_DATA_INVALID, "Shift Code Saturday");
                }
                
                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return true;
            
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <returns></returns>
        private bool Update()
        {
            try
            {
                int ret = 0;
                M_Template_WorkDay data = this.GetDataFromScreen(this.GetData());
                if (data != null && data.Status == DataStatus.Changed)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {

                        TemplateWorkDayService ser = new TemplateWorkDayService(db);
                        ret = ser.Update(data);
                        if (ret == 0)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        db.Commit();
                    }
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_SUN))
                {
                    this.SetMessage(this.txtShiftCodeSun.ID, M_Message.MSG_DATA_INVALID, "Shift Code Sunday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_MON))
                {
                    this.SetMessage(this.txtShiftCodeMon.ID, M_Message.MSG_DATA_INVALID, "Shift Code Monday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_TUE))
                {
                    this.SetMessage(this.txtShiftCodeTue.ID, M_Message.MSG_DATA_INVALID, "Shift Code Tuesday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_WED))
                {
                    this.SetMessage(this.txtShiftCodeWed.ID, M_Message.MSG_DATA_INVALID, "Shift Code Wednesday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_THU))
                {
                    this.SetMessage(this.txtShiftCodeThu.ID, M_Message.MSG_DATA_INVALID, "Shift Code Thursday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_FRI))
                {
                    this.SetMessage(this.txtShiftCodeFri.ID, M_Message.MSG_DATA_INVALID, "Shift Code Friday");
                }

                if (ex.Message.Contains(Models.Constant.M_Template_WorkDay_FK_Work_Shift_SAT))
                {
                    this.SetMessage(this.txtShiftCodeSat.ID, M_Message.MSG_DATA_INVALID, "Shift Code Saturday");
                }
                
                Log.Instance.WriteLog(ex);
            }
            catch (Exception ex)
            {
                // this.ReLoadDataForGrid();
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Check Inputting
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            //Check require
            if (this.txtShiftCodeSun.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeSun.ID, M_Message.MSG_REQUIRE, "Shift code Sunday");
            }
            if (this.txtShiftCodeMon.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeMon.ID, M_Message.MSG_REQUIRE, "Shift code Monday");
            }
            if (this.txtShiftCodeTue.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeTue.ID, M_Message.MSG_REQUIRE, "Shift code Tuesday");
            }
            if (this.txtShiftCodeWed.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeWed.ID, M_Message.MSG_REQUIRE, "Shift code Wednesday");
            }
            if (this.txtShiftCodeThu.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeThu.ID, M_Message.MSG_REQUIRE, "Shift code Thursday");
            }
            if (this.txtShiftCodeFri.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeFri.ID, M_Message.MSG_REQUIRE, "Shift code Friday");
            }
            if (this.txtShiftCodeSat.IsEmpty)
            {
                this.SetMessage(this.txtShiftCodeSat.ID, M_Message.MSG_REQUIRE, "Shift code Saturday");
            }

            //check exist
            if (!base.HaveError)//ko co loi require
            {
                if (!this.txtShiftCodeSun.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeSun.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeSun.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Sunday");
                    }
                }
                if (!this.txtShiftCodeMon.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeMon.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeMon.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Monday");
                    }
                }
                if (!this.txtShiftCodeTue.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeTue.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeTue.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Tuesday");
                    }
                }
                if (!this.txtShiftCodeWed.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeWed.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeWed.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Wednesday");
                    }
                }
                if (!this.txtShiftCodeThu.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeThu.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeThu.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Thursday");
                    }
                }
                if (!this.txtShiftCodeFri.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeFri.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeFri.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Friday");
                    }
                }
                if (!this.txtShiftCodeSat.IsEmpty)
                {
                    if (this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeSat.Value)) == null)
                    {
                        this.SetMessage(this.txtShiftCodeSat.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift code Saturday");
                    }
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// GetWorkShiftByCD
        /// </summary>
        /// <param name="shiftCD"></param>
        /// <returns></returns>
        private M_Work_Shift GetWorkShiftByCD(int shiftCD)
        {
            using (DB db = new DB())
            {
                WorkShiftService Ser = new WorkShiftService(db);
                return Ser.GetByCode(shiftCD);
            }
        }

        /// <summary>
        /// GetDataFromScreen
        /// </summary>
        private M_Template_WorkDay GetDataFromScreen(M_Template_WorkDay inputData = null)
        {
            if (inputData == null)
            {
                inputData = new M_Template_WorkDay();
            }
            if (!string.IsNullOrEmpty(this.txtShiftCodeSun.Value))
            {
                M_Work_Shift dataSun = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeSun.Value.Trim()));
                if (dataSun != null)
                {
                    inputData.SunShiftID = dataSun.ID;
                }
                else
                {
                    inputData.SunShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.SunShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeMon.Value))
            {
                M_Work_Shift dataMon = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeMon.Value.Trim()));
                if (dataMon != null)
                {
                    inputData.MonShiftID = dataMon.ID;
                }
                else
                {
                    inputData.MonShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.MonShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeTue.Value))
            {
                M_Work_Shift dataTue = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeTue.Value.Trim()));
                if (dataTue != null)
                {
                    inputData.TueShiftID = dataTue.ID;
                }
                else
                {
                    inputData.TueShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.TueShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeWed.Value))
            {
                M_Work_Shift dataWed = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeWed.Value.Trim()));
                if (dataWed != null)
                {
                    inputData.WedShiftID = dataWed.ID;
                }
                else
                {
                    inputData.WedShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.WedShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeThu.Value))
            {
                M_Work_Shift dataThu = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeThu.Value.Trim()));
                if (dataThu != null)
                {
                    inputData.ThuShiftID = dataThu.ID;
                }
                else
                {
                    inputData.ThuShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.ThuShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeFri.Value))
            {
                M_Work_Shift dataFri = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeFri.Value.Trim()));
                if (dataFri != null)
                {
                    inputData.FriShiftID = dataFri.ID;
                }
                else
                {
                    inputData.FriShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.FriShiftID = DEFAULT_ZERO;
            }

            if (!string.IsNullOrEmpty(this.txtShiftCodeSat.Value))
            {
                M_Work_Shift dataSat = this.GetWorkShiftByCD(int.Parse(this.txtShiftCodeSat.Value.Trim()));
                if (dataSat != null)
                {
                    inputData.SatShiftID = dataSat.ID;
                }
                else
                {
                    inputData.SatShiftID = DEFAULT_ZERO;
                }
            }
            else
            {
                inputData.SatShiftID = DEFAULT_ZERO;
            }

            return inputData;
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        #endregion


        #region Web Methods

        /// <summary>
        /// Get Shift Name By Shift Code
        /// </summary>
        /// <param name="in1">Shift Code</param>
        /// <returns>Shift Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetShiftName(int shiftCode)
        {
            var shiftCd = shiftCode;
         
            try
            {
                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    M_Work_Shift model = shiftSer.GetByShiftCode(shiftCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            Code = model.ShiftCode,
                            Name = model.ShiftName,
                            TypeOfDay = model.TypeOfDay
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    else
                    {
                        var result = new
                        {
                            Code = shiftCd
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
               
        #endregion
    }
}
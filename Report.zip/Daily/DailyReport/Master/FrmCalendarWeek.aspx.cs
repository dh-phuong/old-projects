﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using System.Collections;

namespace DailyReport.Master
{
    public partial class FrmCalendarWeek : FrmBaseDetail
    {
        #region prop

        private const string URL_TRANSFER = "~/Master/FrmCalendarWeek.aspx";

        private readonly string[] DayNames = { "SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT" };

        public List<string> HDate { get; set; }

        public DateTime nowDate { get; set; }

        public DateTime currentDate
        {
            get { return (DateTime)ViewState["currentDate"]; }
            set { ViewState["currentDate"] = value; }
        }

        #endregion

        #region Override Method

        protected override void OnInit(EventArgs e)
        {
            this.btnPre.ServerClick += new EventHandler(btnPre_Click);
            this.btnNext.ServerClick += new EventHandler(btnNext_Click);
            this.btnStop.ServerClick += new EventHandler(btnStop_Click);

            base.FormTitle = "Calendar";
        }

        #endregion

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Daily);
            if (!this._authority.IsDailyView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            this.nowDate = DateTime.Now.Date;
            HDate = new List<string>();

            if (!IsPostBack)
            {
                this.SetDataDepartmentCbo();
                this.currentDate = DateTime.Now.Date;
                this.cmbDepartment.SelectedValue = LoginInfo.Department.ID.ToString();
                this.dtDateSelect.Value = DateTime.Now.Date;

                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                this.LoadCalendar(this.currentDate, this.cmbDepartment.SelectedValue);
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.dtDateSelect.Value.Value, this.cmbDepartment.SelectedValue);
        }

        protected void btnPre_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.currentDate.AddDays(-7), this.cmbDepartment.SelectedValue);
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.currentDate.AddDays(7), this.cmbDepartment.SelectedValue);
        }

        protected void btnStop_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.nowDate, this.cmbDepartment.SelectedValue);
        }

        protected void btnMonth_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void btnWeek_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void btnDay_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void rptDay_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            WeekInfo dailyDetail = (WeekInfo)e.Item.DataItem;

            //Find control
            Repeater _rptSun = (Repeater)e.Item.FindControl("rptSun");
            _rptSun.DataSource = dailyDetail.SunDay.ListWork;
            _rptSun.DataBind();

            Repeater _rptMon = (Repeater)e.Item.FindControl("rptMon");
            _rptMon.DataSource = dailyDetail.MonDay.ListWork;
            _rptMon.DataBind();

            Repeater _rptTue = (Repeater)e.Item.FindControl("rptTue");
            _rptTue.DataSource = dailyDetail.TueDay.ListWork;
            _rptTue.DataBind();

            Repeater _rptWed = (Repeater)e.Item.FindControl("rptWed");
            _rptWed.DataSource = dailyDetail.WedDay.ListWork;
            _rptWed.DataBind();

            Repeater _rptThu = (Repeater)e.Item.FindControl("rptThu");
            _rptThu.DataSource = dailyDetail.ThuDay.ListWork;
            _rptThu.DataBind();

            Repeater _rptFri = (Repeater)e.Item.FindControl("rptFri");
            _rptFri.DataSource = dailyDetail.FriDay.ListWork;
            _rptFri.DataBind();

            Repeater _rptSat = (Repeater)e.Item.FindControl("rptSat");
            _rptSat.DataSource = dailyDetail.SatDay.ListWork;
            _rptSat.DataBind();

        }

        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            var tmp = e.CommandArgument.ToString().Split(',');

            this.ViewState["_dailyID"] = tmp[0];
            this.ViewState["_urlTransfer"] = URL_TRANSFER;

            SaveCondSearch();
        }

        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            var tmp = e.CommandArgument.ToString().Split(',');

            this.ViewState["_dateNew"] = tmp[0];
            this.ViewState["_userNew"] = tmp[1];
            this.ViewState["_urlTransfer"] = URL_TRANSFER;

            SaveCondSearch();
        }

        protected void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadCalendar(this.currentDate, this.cmbDepartment.SelectedValue);
        }

        #endregion

        #region Method

        /// <summary>
        /// Get Group Name By Group Code
        /// </summary>
        /// <param name="groupCd">Group Code</param>
        /// <returns>Group Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetGroupName(string groupCD)
        {
            var groupCd = groupCD;
            var groupCdShow = groupCD;
            groupCd = EditDataUtil.ToFixCodeDB(groupCd, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH);
            groupCdShow = EditDataUtil.ToFixCodeShow(groupCd, M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);

            try
            {
                using (DB db = new DB())
                {
                    GroupUserService grpSer = new GroupUserService(db);
                    M_GroupUser_H model = grpSer.GetByGroupCD(groupCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            groupCD = groupCdShow,
                            groupNm = model.GroupName
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCD = new
                    {
                        groupCD = groupCdShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(onlyCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void LoadCalendar(DateTime date, string departmentID = "")
        {
            this.currentDate = date;
            var firstDayInView = date.AddDays(-1 * (int)date.DayOfWeek);
            var lastDayInView = date.AddDays((int)(6 - date.DayOfWeek));

            List<M_Holiday> lstHoliday = GetHoliday(firstDayInView, lastDayInView);
            List<M_UserInfo> lstUser = GetUser(this.cmbDepartment.SelectedValue);
            List<WeekInfo> lstData = new List<WeekInfo>();

            List<CalendarInfo> listDaily = new List<CalendarInfo>();

            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            List<M_Holiday> itemH = new List<M_Holiday>();
            using (DB db = new DB())
            {
                DailyService grpSer = new DailyService(db);
                listDaily = grpSer.GetCalendarByDept(firstDayInView, lastDayInView, this.cmbDepartment.SelectedValue).ToList();

                HolidayService holSer = new HolidayService(db);
                itemH = holSer.GetHolidayInfo(firstDayInView, lastDayInView).ToList();
            }

            for (int week = 1; week <= lstUser.Count(); week++)
            {
                DateTime iDay = firstDayInView;
                WeekInfo weekData = new WeekInfo();
                weekData.info = lstUser[week - 1];
                for (int i = 0; i < 7; i++)
                {
                    DayOfWeekInfo dayInfo = new DayOfWeekInfo();
                    dayInfo.Day = iDay;

                    HDate.Add(string.Format("{0:dd/MM} ({1})", iDay, DayNames[i]));

                    // set color today
                    if (iDay == this.nowDate)
                    {
                        dayInfo.Css += "fc-today ";
                    }

                    if (!LoginInfo.Department.ID.Equals(lstUser[week - 1].DepartmentID) || !this._authority.IsDailyView)
                    {
                        dayInfo.Css += "fc-disabled ";
                    }

                    // add holiday                    
                    if (itemH.Where(m => m.Date.Equals(iDay)).Count() > 0)
                    {
                        CalendarInfo calInfo = new CalendarInfo();
                        calInfo.TypeApplyID = -1;
                        calInfo.Content = "<span class='glyphicon glyphicon-flag' aria-hidden='true'></span>" + itemH.Where(m => m.Date.Equals(iDay)).Single().Name1;
                        calInfo.HColor = itemH.Where(m => m.Date.Equals(iDay)).Single().Color;
                        dayInfo.ListWork.Add(calInfo);
                    }

                    dayInfo.ListWork.AddRange(from _info in listDaily where _info.WorkDate.Day.Equals(iDay.Day) && _info.UserID.Equals(lstUser[week - 1].ID) select _info);

                    iDay = iDay.AddDays(1);
                    weekData.AddDayInfo(dayInfo);
                }

                lstData.Add(weekData);
            }

            this.rptDay.DataSource = lstData;
            this.rptDay.DataBind();
        }

        public List<M_UserInfo> GetUser(string deparmentID)
        {
            try
            {
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                using (DB db = new DB())
                {
                    UserService ser = new UserService(db);
                    return ser.GetUserInfoByDeptID(int.Parse(deparmentID)).ToList();
                }
                
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<M_Holiday> GetHoliday(DateTime dateFrom, DateTime dateTo)
        {
            try
            {
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                using (DB db = new DB())
                {
                    HolidayService holidaySer = new HolidayService(db);
                    return holidaySer.GetHolidayInfo(dateFrom, dateTo).ToList();
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void SaveCondSearch()
        {
            Hashtable hash = new Hashtable();
            hash.Add("date", this.currentDate);
            hash.Add(this.cmbDepartment.ID, this.cmbDepartment.SelectedValue);

            this.ViewState["Condition"] = hash;
        }

        private void ShowCondition(Hashtable data)
        {
            this.currentDate = DateTime.Parse(data["date"].ToString());
            this.cmbDepartment.SelectedValue = data[this.cmbDepartment.ID].ToString();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(true);
                this.cmbDepartment.DataSource = lstDB;
            }
            this.cmbDepartment.DataValueField = "Value";
            this.cmbDepartment.DataTextField = "DisplayName";
            this.cmbDepartment.DataBind();
        }

        #endregion

    }
}
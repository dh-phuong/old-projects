﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DailyReport.Master
{
    /// <summary>
    /// FrmAccountingSystem
    /// TRAM-2015/04/16
    /// </summary>
    public partial class FrmAccountingSystem : FrmBaseDetail
    {
       
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Accounting System";
            base.FormSubTitle = "";

            //Init Max Length
           
            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            //btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            //btnNo.Click += new EventHandler(btnShowData);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

       
    }
}
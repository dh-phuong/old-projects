﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Controls;
using System.Web.UI.HtmlControls;
using System.Collections;

namespace DailyReport.Master
{
    /// <summary>
    /// Class Config Detail
    /// Create Date: 2014/07/31
    /// Create Author: VN-Nho
    /// </summary>
    public partial class FrmAddAnuualDays : FrmBaseDetail
    {
        #region Variable

        /// <summary>
        /// URL form list
        /// </summary>
        private const string URL_LIST = "~/Master/FrmStaffList.aspx";

        #endregion

        #region Property

        /// <summary>
        /// Repeater data source information
        /// </summary>
        private Hashtable RptDataInfo
        {
            get { return (Hashtable)ViewState["RptDataInfo"]; }
            set { ViewState["RptDataInfo"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "User Master";
            base.FormSubTitle = "Add Annual Days";

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (base.LoginInfo == null)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                this.SetDataDepartmentCbo();
                this.SetDataAnnualDaysCbo();

                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.ViewState["Condition"] = base.PreviousPageViewState["Condition"];
                }

                this.LoadRptData();
                this.Mode = Utilities.Mode.Update;
            }

            //Set init
            this.Success = false;
        }

        protected void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadRptData();
        }

        protected void cmdAnnualDays_SelectedIndexChanged(object sender, EventArgs e)
        {
            IList<AnnualDayInfo> lstData = this.GetRptData();
            this.CalAnnualDays(lstData);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="lstData"></param>
        private void CalAnnualDays(IList<AnnualDayInfo> lstData)
        {

            Hashtable dataInfo = new Hashtable();
            foreach (var item in lstData)
            {
                DateTime tempDate = new DateTime(item.OldAnnualDate.AddDays(1).Year, item.StartWorkDate.Month, item.StartWorkDate.Day);

                if (tempDate >= item.OldAnnualDate && tempDate <= item.OldAnnualDate.AddMonths(int.Parse(this.cmbAnnualDays.SelectedValue)))
                {
                    item.ExtraDays = (item.OldAnnualDate.AddMonths(int.Parse(this.cmbAnnualDays.SelectedValue)).Year - item.StartWorkDate.Year) / 5;
                }
                else
                {
                    item.ExtraDays = 0;
                }

                item.Total = int.Parse(this.cmbAnnualDays.SelectedValue) + item.ExtraDays + item.BonusDays + item.OldAnnualDays;
                dataInfo.Add(item.ID, item);
            }

            this.RptDataInfo = dataInfo;

            this.rptList.DataSource = lstData;
            this.rptList.DataBind();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<AnnualDayInfo> GetRptData()
        {
            IList<AnnualDayInfo> retLst = new List<AnnualDayInfo>();

            foreach (RepeaterItem item in this.rptList.Items)
            {
                HiddenField hidID = (HiddenField)item.FindControl("hidID");
                INumberTextBox txtExtraDays = (INumberTextBox)item.FindControl("txtExtraDays");
                INumberTextBox txtBonusDays = (INumberTextBox)item.FindControl("txtBonusDays");
                INumberTextBox txtTotal = (INumberTextBox)item.FindControl("txtTotal");

                AnnualDayInfo addItem = (AnnualDayInfo)this.RptDataInfo[int.Parse(hidID.Value)];
                addItem.ExtraDays = (decimal)txtExtraDays.Value;
                addItem.BonusDays = (decimal)txtBonusDays.Value;
                addItem.Total = (decimal)txtTotal.Value;

                retLst.Add(addItem);
            }

            return retLst;
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(false);
                this.cmbDepartment.DataSource = lstDB;
            }
            this.cmbDepartment.DataValueField = "Value";
            this.cmbDepartment.DataTextField = "DisplayName";
            this.cmbDepartment.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void SetDataAnnualDaysCbo()
        {
            // init combox 
            this.cmbAnnualDays.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_ANNUAL_DAY);
            this.cmbAnnualDays.DataValueField = "Value";
            this.cmbAnnualDays.DataTextField = "DisplayName";
            this.cmbAnnualDays.DataBind();
            this.cmbAnnualDays.SelectedValue = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_ANNUAL_DAY);
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD);

            }
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Event Button Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Button Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            Server.Transfer(URL_LIST);
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            bool ret;
            //Update Data
            ret = this.UpdateData();
            if (ret)
            {
                this.LoadRptData();

                //Set Success
                this.Success = true;
            }
        }
    
        #endregion

        #region Method

        /// <summary>
        /// Load repeater data
        /// </summary>
        private void LoadRptData()
        {
            StaffService staffSer = new StaffService();
            IList<AnnualDayInfo> lstData = staffSer.GetListAnnualByDeptID(int.Parse(cmbDepartment.SelectedValue));

            this.CalAnnualDays(lstData);

            base.DisabledLink(this.btnSubmit, !(lstData.Count > 0));
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set mode
            this.Mode = mode;

        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Config Code
            //if (this.txtConfigCD.IsEmpty)
            //{
            //    base.SetMessage(this.txtConfigCD.ID, M_Message.MSG_REQUIRE, "Config Code");
            //}
            //else
            //{
            //    //Check exist by Config code
            //    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
            //    {
            //        if (this.IsExistConfigCode(this.txtConfigCD.Value))
            //        {
            //            base.SetMessage(this.txtConfigCD.ID, M_Message.MSG_EXIST_CODE, "Config Code");
            //        }
            //    }
            //}

            ////Config Name
            //if (this.txtConfigName.IsEmpty)
            //{
            //    base.SetMessage(this.txtConfigName.ID, M_Message.MSG_REQUIRE, "Config Name");
            //}

            //List<int> lstDup = new List<int>();

            //bool hasData = false;

            //foreach (RepeaterItem item in this.rptList.Items)
            //{
            //    if (this.IsEmptyRow(item))
            //    {
            //        continue;
            //    }

            //    hasData = true;
            //    int rowIndex = item.ItemIndex + 1;

            //    //Value1
            //    ICodeTextBox txtValue1 = (ICodeTextBox)item.FindControl("txtValue1");
            //    if (txtValue1 != null)
            //    {
            //        HtmlGenericControl divValue = (HtmlGenericControl)item.FindControl("divValue1");
            //        divValue.Attributes.Remove("class");
            //        string errorId = txtValue1.ID + "_" + item.ItemIndex.ToString();
            //        if (string.IsNullOrEmpty(txtValue1.Value))
            //        {
            //            base.SetMessage(errorId, M_Message.MSG_REQUIRE_GRID, "Value 1", rowIndex);
            //            this.AddErrorForListItem(divValue, errorId);
            //        }
            //        else
            //        {
            //            if (lstDup.Contains(int.Parse(txtValue1.Value)))
            //            {
            //                base.SetMessage(errorId, M_Message.MSG_DUPLICATE_GRID, "Value 1", rowIndex);
            //                this.AddErrorForListItem(divValue, errorId);
            //            }
            //            else
            //            {
            //                lstDup.Add(int.Parse(txtValue1.Value));
            //            }
            //            txtValue1.Value = int.Parse(txtValue1.Value).ToString();
            //        }
            //    }
            //}

            //if (!hasData)
            //{
            //    ICodeTextBox txtValue1 = (ICodeTextBox)this.rptList.Items[0].FindControl("txtValue1");
            //    HtmlGenericControl divValue = (HtmlGenericControl)this.rptList.Items[0].FindControl("divValue1");
            //    string errorId = txtValue1.ID + "_" + this.rptList.Items[0].ItemIndex.ToString();
            //    base.SetMessage(errorId, M_Message.MSG_REQUIRE_GRID, "Value 1", 1);
            //    this.AddErrorForListItem(divValue, errorId);
            //}

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Add display error for control
        /// </summary>
        /// <param name="divCtrl">div error control</param>
        /// <param name="errorKey">Error Control ID</param>
        private void AddErrorForListItem(HtmlGenericControl divCtrl, string errorKey)
        {
            divCtrl.Attributes.Add("class", "form-group " + base.GetClassError(errorKey));
        }

        

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                //Update                     
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Update detail
                    StaffService staffService = new StaffService(db);
                    IList<AnnualDayInfo> detail = this.GetRptData();
                    
                    foreach (var item in detail)
                    {
                        M_Staff updateItem = new M_Staff();
                        updateItem.ID = item.ID;
                        updateItem.AnnualDays = item.Total;
                        updateItem.AnnualToDate = item.OldAnnualDate.AddMonths(int.Parse(cmbAnnualDays.SelectedValue));
                        updateItem.UpdateUID = this.LoginInfo.User.ID;
                        updateItem.UpdateDate = item.UpdateDate;
                        staffService.UpdateAnnualDay(updateItem); ;
                    }
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }
        #endregion
    }
}
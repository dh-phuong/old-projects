﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using System.Collections;

namespace DailyReport.Master
{
    public partial class FrmCalendarDay : FrmBaseDetail
    {
        #region prop
        private const string URL_TRANSFER = "~/Master/FrmCalendarDay.aspx";

        public DateTime nowDate { get; set; }

        public DateTime currentDate
        {
            get { return (DateTime)ViewState["currentDate"]; }
            set { ViewState["currentDate"] = value; }
        }

        #endregion

        #region Override Method

        protected override void OnInit(EventArgs e)
        {
            this.btnPre.ServerClick += new EventHandler(btnPre_Click);
            this.btnNext.ServerClick += new EventHandler(btnNext_Click);
            this.btnStop.ServerClick += new EventHandler(btnStop_Click);

            base.FormTitle = "Calendar";
        }

        #endregion

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Daily);
            if (!this._authority.IsDailyView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            this.nowDate = DateTime.Now.Date;

            if (!IsPostBack)
            {
                this.dtDateSelect.Value = DateTime.Now.Date;
                this.SetDataDepartmentCbo();
                this.currentDate = DateTime.Now.Date;
                this.cmbDepartment.SelectedValue = LoginInfo.Department.ID.ToString();

                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                this.LoadCalendar(this.currentDate, this.cmbDepartment.SelectedValue);
            }
        }

        protected void btnPre_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.currentDate.AddDays(-1), this.cmbDepartment.SelectedValue);
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.currentDate.AddDays(1), this.cmbDepartment.SelectedValue);
        }

        protected void btnStop_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.nowDate, this.cmbDepartment.SelectedValue);
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            LoadCalendar(this.dtDateSelect.Value.Value, this.cmbDepartment.SelectedValue);
        }

        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            var tmp = e.CommandArgument.ToString().Split(',');

            this.ViewState["_dailyID"] = tmp[0];
            this.ViewState["_urlTransfer"] = URL_TRANSFER;

            SaveCondSearch();
        }

        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            var tmp = e.CommandArgument.ToString().Split(',');

            this.ViewState["_dateNew"] = tmp[0];
            this.ViewState["_userNew"] = tmp[1];
            this.ViewState["_urlTransfer"] = URL_TRANSFER;

            SaveCondSearch();
        }

        protected void btnMonth_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void btnWeek_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void btnDay_Click(object sender, EventArgs e)
        {
            SaveCondSearch();
        }

        protected void cmbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadCalendar(this.currentDate, this.cmbDepartment.SelectedValue);
        }

        protected void rptDay_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            WeekInfo dailyDetail = (WeekInfo)e.Item.DataItem;

            //Find control
            Repeater _rptWorkDay = (Repeater)e.Item.FindControl("rptWorkDay");
            _rptWorkDay.DataSource = dailyDetail.SunDay.ListWork;
            _rptWorkDay.DataBind();
        }

        #endregion

        #region Method

        /// <summary>
        /// Get Group Name By Group Code
        /// </summary>
        /// <param name="groupCd">Group Code</param>
        /// <returns>Group Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetGroupName(string groupCD)
        {
            var groupCd = groupCD;
            var groupCdShow = groupCD;
            groupCd = EditDataUtil.ToFixCodeDB(groupCd, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH);
            groupCdShow = EditDataUtil.ToFixCodeShow(groupCd, M_GroupUser_H.GROUP_CODE_SHOW_MAX_LENGTH);

            try
            {
                using (DB db = new DB())
                {
                    GroupUserService grpSer = new GroupUserService(db);
                    M_GroupUser_H model = grpSer.GetByGroupCD(groupCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            groupCD = groupCdShow,
                            groupNm = model.GroupName
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCD = new
                    {
                        groupCD = groupCdShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(onlyCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void LoadCalendar(DateTime date, string departmentID = "")
        {
            this.currentDate = date;
            var firstDayInView = date;

            List<M_UserInfo> lstUser = GetUser(this.cmbDepartment.SelectedValue);
            List<WeekInfo> lstData = new List<WeekInfo>();

            List<CalendarInfo> listDaily = new List<CalendarInfo>();
            List<M_Holiday> itemH = new List<M_Holiday>();

            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                DailyService grpSer = new DailyService(db);
                listDaily = grpSer.GetCalendarByDept(firstDayInView, firstDayInView, this.cmbDepartment.SelectedValue).ToList();

                HolidayService holSer = new HolidayService(db);
                itemH = holSer.GetHolidayInfo(firstDayInView, firstDayInView).ToList();
            }

            for (int week = 1; week <= lstUser.Count(); week++)
            {
                DateTime iDay = firstDayInView;
                WeekInfo weekData = new WeekInfo();
                weekData.info = lstUser[week - 1];

                DayOfWeekInfo dayInfo = new DayOfWeekInfo();
                dayInfo.Day = iDay;

                if (iDay.DayOfWeek == DayOfWeek.Sunday)
                {
                    dayInfo.Css += "fc-sun ";
                }

                if (iDay.DayOfWeek == DayOfWeek.Saturday)
                {
                    dayInfo.Css += "fc-sat ";
                }

                // set color today
                if (iDay == this.nowDate)
                {
                    dayInfo.Css += "fc-today ";
                }

                if (!LoginInfo.Department.ID.Equals(lstUser[week - 1].DepartmentID) || !this._authority.IsDailyView)
                {
                    dayInfo.Css += "fc-disabled ";
                }

                // add holiday                    
                if (itemH.Where(m => m.Date.Equals(iDay)).Count() > 0)
                {
                    CalendarInfo calInfo = new CalendarInfo();
                    calInfo.TypeApplyID = -1;
                    calInfo.Content = "<span class='glyphicon glyphicon-flag' aria-hidden='true'></span>" + itemH.Where(m => m.Date.Equals(iDay)).Single().Name1;
                    calInfo.HColor = itemH.Where(m => m.Date.Equals(iDay)).Single().Color;
                    dayInfo.ListWork.Add(calInfo);
                }

                dayInfo.ListWork.AddRange(from _info in listDaily where _info.WorkDate.Day.Equals(iDay.Day) && _info.UserID.Equals(lstUser[week - 1].ID) select _info);

                iDay = iDay.AddDays(1);
                weekData.AddDayInfo(dayInfo, false);

                lstData.Add(weekData);
            }

            this.rptDay.DataSource = lstData;
            this.rptDay.DataBind();
        }

        public List<M_UserInfo> GetUser(string deparmentID)
        {
            try
            {
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                using (DB db = new DB())
                {
                    UserService ser = new UserService(db);
                    return ser.GetUserInfoByDeptID(int.Parse(deparmentID)).ToList();
                }
               
            }
            catch (Exception)
            {

                throw;
            }
        }

        public List<M_Holiday> GetHoliday(DateTime dateFrom, DateTime dateTo)
        {
            try
            {
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                using (DB db = new DB())
                {
                    HolidayService holidaySer = new HolidayService(db);
                    return holidaySer.GetHolidayInfo(dateFrom, dateTo).ToList();
                }
                
            }
            catch (Exception)
            {
                return null;
            }
        }

        private void SaveCondSearch()
        {
            Hashtable hash = new Hashtable();
            hash.Add("date", this.currentDate);
            hash.Add(this.cmbDepartment.ID, this.cmbDepartment.SelectedValue);            

            this.ViewState["Condition"] = hash;
        }

        private void ShowCondition(Hashtable data)
        {
            this.currentDate = DateTime.Parse(data["date"].ToString());
            this.cmbDepartment.SelectedValue = data[this.cmbDepartment.ID].ToString();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(true);
                this.cmbDepartment.DataSource = lstDB;
            }
            this.cmbDepartment.DataValueField = "Value";
            this.cmbDepartment.DataTextField = "DisplayName";
            this.cmbDepartment.DataBind();
        }

        public string getDayOfWeek(DateTime _date)
        {
            string ret = string.Empty;
            switch (_date.DayOfWeek)
            {
                case DayOfWeek.Friday:
                    ret = "FRI";
                    break;
                case DayOfWeek.Monday:
                    ret = "MON";
                    break;
                case DayOfWeek.Saturday:
                    ret = "SAT";
                    break;
                case DayOfWeek.Sunday:
                    ret = "SUN";
                    break;
                case DayOfWeek.Thursday:
                    ret = "THU";
                    break;
                case DayOfWeek.Tuesday:
                    ret = "TUE";
                    break;
                case DayOfWeek.Wednesday:
                    ret = "WED";
                    break;
                default:
                    break;
            }

            return ret;
        }

        #endregion


    }
}
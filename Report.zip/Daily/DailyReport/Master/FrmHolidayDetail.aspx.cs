﻿using System;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text.RegularExpressions;
using DailyReport.Controls;
using DailyReport;
using System.Collections.Generic;

namespace DailyReport.Master
{
    public partial class FrmHolidayDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmHolidayList.aspx";
        #endregion

        #region Property

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int HolidayID
        {
            get { return (int)ViewState["HolidayID"]; }
            set { ViewState["HolidayID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Method

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Holiday Detail";
            base.FormSubTitle = "Detail";

            //Init Max Length            
            this.txtName1.MaxLength = M_Holiday.HOLIDAY_NAME1_MAX_LENGTH;
            this.txtName2.MaxLength = M_Holiday.HOLIDAY_NAME2_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        private void ProcessMode(Mode mode)
        {
            bool enable = false;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                    this.txtDate.ReadOnly = false;
                    enable = false;
                    break;

                case Mode.Update:
                    this.txtDate.ReadOnly = true;
                    enable = false;
                    break;

                default:
                    this.txtDate.ReadOnly = true;
                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    enable = true;
                    break;
            }

            //Lock control
            this.txtName1.ReadOnly = enable;
            this.txtName2.ReadOnly = enable;
            this.txtColor.SetReadOnly(enable);
            this.chkRepeats.Disabled = enable;
            this.chkReplace.Disabled = enable;
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(M_Holiday holiday)
        {
            ////Show data
            if (holiday != null)
            {
                this.txtDate.Value = holiday.Date;
                this.txtName1.Value = holiday.Name1;
                this.txtName2.Value = holiday.Name2;
                this.txtColor.Value = holiday.Color;
                this.chkRepeats.Checked = holiday.Repeats == 1;
                this.chkReplace.Checked = holiday.Replace == 1;

                //Save UserID and UpdateDate
                this.HolidayID = holiday.ID;
                this.OldUpdateDate = holiday.UpdateDate;
            }
        }

        /// <summary>
        /// Get Holiday BY HolidayID
        /// </summary>
        /// <param name="holidayID">HolidayID</param>
        /// <returns>User</returns>
        private M_Holiday GetHoliday(int holidayID)
        {
            using (DB db = new DB())
            {
                HolidayService holidaySer = new HolidayService(db);
                //Get Holiday
                return holidaySer.GetByID(holidayID);
            }
        }

        /// <summary>
        /// Get Holiday BY HolidayName
        /// </summary>
        /// <param name="holidayID">HolidayName</param>
        /// <returns>holidayName</returns>
        private M_Holiday GetHoliday(DateTime date)
        {
            using (DB db = new DB())
            {
                HolidayService holidaySer = new HolidayService(db);
                //Get Holiday
                return holidaySer.GetByDay(date);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Holiday Date
            if (this.txtDate.IsEmpty)
            {
                this.SetMessage(this.txtDate.ID, M_Message.MSG_REQUIRE, "Date");
            }

            if (this.txtName1.IsEmpty)
            {
                this.SetMessage(this.txtName1.ID, M_Message.MSG_REQUIRE, "Name (VN)");
            }            

            if (!base.HaveError && (this.Mode == Mode.Insert || this.Mode == Mode.Copy || this.Mode == Mode.Update))
            {
                // Check Holiday by holidayDay  
                DateTime _day = this.txtDate.Value.Value;
                M_Holiday holiday = this.GetHoliday(_day);

                if (holiday != null)
                {
                    if (holiday.Date == _day)
                    {
                        if (this.Mode == Mode.Update)
                        {
                            if (holiday.ID != HolidayID)
                            {
                                this.SetMessage(this.txtDate.ID, M_Message.MSG_EXIST_CODE, "Holiday Date");
                            }
                        }
                        else
                        {
                            this.SetMessage(this.txtDate.ID, M_Message.MSG_EXIST_CODE, "Holiday Date");
                        }
                    }
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Holiday holiday = new M_Holiday();
                holiday.Date = this.txtDate.Value.Value;
                holiday.Name1 = this.txtName1.Value;
                holiday.Name2 = this.txtName2.Value;
                holiday.Color = string.IsNullOrEmpty(this.txtColor.Value) ? "#FFFFFF" : this.txtColor.Value;
                holiday.Replace = (short)(this.chkReplace.Checked ? 1 : 0);
                holiday.Repeats = (short)(this.chkRepeats.Checked ? 1 : 0);

                holiday.CreateUID = this.LoginInfo.User.ID;
                holiday.UpdateUID = this.LoginInfo.User.ID;

                //Insert Holiday
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    HolidayService holidaySer = new HolidayService(db);

                    //Insert User
                    holidaySer.Insert(holiday);

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Holiday holiday = this.GetHoliday(this.HolidayID);
                if (holiday != null)
                {
                    //Create model
                    holiday.ID = this.HolidayID;
                    holiday.Date = this.txtDate.Value.Value;
                    holiday.Name1 = this.txtName1.Value;
                    holiday.Name2 = this.txtName2.Value;
                    holiday.Color = this.txtColor.Value;

                    holiday.Replace = (short)(this.chkReplace.Checked ? 1 : 0);
                    holiday.Repeats = (short)(this.chkRepeats.Checked ? 1 : 0);

                    holiday.UpdateDate = this.OldUpdateDate;
                    holiday.UpdateUID = this.LoginInfo.User.ID;

                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        //Update Holiday  
                        HolidayService holidaySer = new HolidayService(db);

                        //Update User
                        if (holiday.Status == DataStatus.Changed)
                        {
                            ret = holidaySer.Update(holiday);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    HolidayService holidaySer = new HolidayService(db);
                    ret = holidaySer.Delete(this.HolidayID, this.OldUpdateDate);

                    if (ret > 0)
                    {
                        db.Commit();
                    }
                }

                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
            }
            return true;
        }

        #endregion

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Holiday);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                this.txtColor.Text = "#FFFFFF";
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["HolidayID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.HolidayID = int.Parse(PreviousPageViewState["HolidayID"].ToString());
                        M_Holiday holiday = this.GetHoliday(this.HolidayID);

                        //Check user
                        if (holiday != null)
                        {
                            //Show data
                            this.ShowData(holiday);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case DailyReport.Utilities.Mode.Insert:
                case DailyReport.Utilities.Mode.Copy:
                    //Insert Data
                    if (!this.CheckInput())
                    {
                        return;
                    }

                    if (this.InsertData())
                    {
                        int year = this.txtDate.Value.Value.Year;
                        int month = this.txtDate.Value.Value.Month;
                        int day = this.txtDate.Value.Value.Day;

                        M_Holiday holiday = this.GetHoliday(this.txtDate.Value.Value);

                        //Show data
                        this.ShowData(holiday);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case DailyReport.Utilities.Mode.Delete:
                    //Delete
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:
                    //Update Data
                    if (!this.CheckInput())
                    {
                        return;
                    }

                    if (this.UpdateData())
                    {
                        M_Holiday holiday = this.GetHoliday(this.HolidayID);

                        //Show data
                        this.ShowData(holiday);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;

            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            M_Holiday holiday = this.GetHoliday(this.HolidayID);

            if (holiday != null)
            {

                //Show data
                this.ShowData(holiday);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.txtDate.Value = null;
            this.txtName1.Value = string.Empty;
            this.txtName2.Value = string.Empty;
            //Set mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Holiday
            M_Holiday holiday = this.GetHoliday(this.HolidayID);

            //Check Holiday
            if (holiday != null)
            {
                //Show data
                this.ShowData(holiday);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }


        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Holiday
            M_Holiday holiday = this.GetHoliday(this.HolidayID);

            //Check user
            if (holiday != null)
            {
                //Show data
                this.ShowData(holiday);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Insert Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Update Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Holiday
            M_Holiday holiday = this.GetHoliday(this.HolidayID);

            //Check Holiday
            if (holiday != null)
            {
                //Show data
                this.ShowData(holiday);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        #endregion
    }
}
﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Controls;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Data.SqlClient;

namespace DailyReport.Master
{
    /// <summary>
    /// Class Form Detail
    /// Create Date: 2015/04/23
    /// Create Author: ISV-TRUC
    /// </summary>
    public partial class FrmFormDetail : FrmBaseDetail
    {
        private const string URL_LIST = "~/Master/FrmFormList.aspx";
        /// <summary>
        /// View State key: IS_DATA_CHANGE
        /// </summary>
        // private const string IS_DATA_CHANGED = "IS_DATA_CHANGED";

        #region Property

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set Approver list
        /// </summary>
        private IList<RouteDetailListInfo> ApproverList
        {
            get
            {
                return (IList<RouteDetailListInfo>)base.ViewState["ApproverList"];
            }
            set
            {
                base.ViewState["ApproverList"] = value;
            }
        }

        /// <summary>
        /// Get or set route list
        /// </summary>
        private IList<RouteFormInfo> RouteList
        {
            get
            {
                return (IList<RouteFormInfo>)base.ViewState["RouteList"];
            }
            set
            {
                base.ViewState["RouteList"] = value;
            }
        }

        /// <summary>
        /// RouteOtherList
        /// </summary>
        private IList<RouteModel> RouteOtherList
        {
            get
            {
                return (IList<RouteModel>)base.ViewState["RouteOtherList"];
            }
            set
            {
                base.ViewState["RouteOtherList"] = value;
            }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "App-Route Master";
            base.FormSubTitle = "Detail";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            this.PagingHeader.NumRowOnPage = this.GetDefaultValuePaging();
            this.PagingHeader.CurrentPage = 1;

            // Paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;

            this.HeaderGrid.AddColumms(new string[] { "", "", "Route CD", "Route Name" });
            this.HeaderGrid.IsShowEmpty = true;
            this.PagingHeader.IsShowEmpty = true;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            int sortField = 3;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
            ////Refresh rptList
            //this.rptList.DataSource = this.GetFormTypeForDisp(false);
            //this.rptList.DataBind();
            this.ProcessMode(this.Mode);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                int sortField = 3;
                int sortDirec = 1;
                this.PagingHeader.CurrentPage = curPage;
                this.PagingFooter.CurrentPage = curPage;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                ////Refresh rptList
                //this.rptList.DataSource = this.GetFormTypeForDisp(false);
                //this.rptList.DataBind();
                this.SaveCondition();
                this.ProcessMode(this.Mode);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int sortField = 3;
                int sortDirec = 1;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                ////Refresh rptList
                //this.rptList.DataSource = this.GetFormTypeForDisp(false);
                //this.rptList.DataBind();
                this.SaveCondition();
                this.ProcessMode(this.Mode);
            }
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Template);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {   //Init data
                this.InitData(true);

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);

                        //Init detail list
                        // this.InitTypeConfigList();
                    }
                    else
                    {
                        this.InitData();
                        //Get route ID
                        this.DataID = int.Parse(PreviousPageViewState["ID"].ToString());
                        // this.ShowApproveData(this.DataID);
                        M_Form hModel = this.GetHeaderData(this.DataID);
                        if (hModel != null)
                        {
                            //Show data
                            this.ShowData(hModel);

                            //Check route
                            if (this.RouteList.Count > 0)
                            {
                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                Server.Transfer(URL_LIST);
                            }
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }

                //--- this.ShowRouteListData();
            }
            //else
            //{
            //    // this.GetData();
            //}
            this.Success = false;

        }

        /// <summary>
        /// Edit Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get  data by ID
            M_Form hModel = this.GetHeaderData(this.DataID);

            //Check  exists
            if (hModel != null)
            {
                //Show data
                this.ShowData(hModel);

                //Set Mode
                this.ProcessMode(Mode.Update);
                // this.SetFocusWithUsed();
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Copy Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //protected void btnCopy_Click(object sender, EventArgs e)
        //{
        //    //Get config data by ID
        //    M_Form hModel = this.GetHeaderData(this.DataID);

        //    //Check Config exists
        //    if (hModel != null)
        //    {
        //        //Show data
        //        this.ShowData(hModel);

        //        //Set Mode
        //        this.ProcessMode(Mode.Copy);
        //    }
        //    else
        //    {
        //        Server.Transfer(URL_LIST);
        //    }
        //}

        /// <summary>
        /// Delete Button Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            //check exist in another table
            if (CheckIsExist())
            {
                return;
            }

            //Set Model
            this.Mode = Mode.Delete;
            this.FocusControlId = this.btnDelete.ClientID;
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Event Button Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Button Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            this.FocusControlId = this.btnUpdate.ClientID;
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Button Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (this.Mode == Mode.View || this.Mode == Mode.Insert)
            {
                Server.Transfer(URL_LIST);
            }
            else if (this.Mode == Mode.Update || this.Mode == Mode.Copy)
            {
                //Get Form by ID
                M_Form hModel = this.GetHeaderData(this.DataID);

                //Check Config exists
                if (hModel != null)
                {
                    //Show data
                    this.ShowData(hModel);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }
        }

        /// <summary>
        /// cmbRouteChoose OnSelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbRouteChoose_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            int routeID = int.Parse(this.cmbRouteChoose.SelectedValue);
            this.FillDataApproverByRouteID(routeID);
            //using (DB db = new DB())
            //{
            //    Route_DService routeDSer = new Route_DService(db);
            //    var lstTemp = routeDSer.GetListDetailInfo(routeID, -1);

            //    if (lstTemp != null && lstTemp.Count != 0)
            //    {
            //        /*var lstTemp1 = from l in lstTemp
            //                       where l.RouteLevel != Constants.LEVEL_VIEW
            //                       select new RouteDetailListInfo()
            //                       {
            //                           DepartmentID = l.DepartmentID,
            //                           DepartmentName = l.DepartmentName,
            //                           Position = l.Position,
            //                           RequireNum = l.RequireNum,
            //                           RouteFlag1 = l.RouteFlag1,
            //                           RouteFlag2 = l.RouteFlag2,
            //                           RouteFlag3 = l.RouteFlag3,
            //                           RouteFlag4 = l.RouteFlag4,
            //                           RouteFlag5 = l.RouteFlag5,
            //                           RouteFlag6 = l.RouteFlag6,
            //                           RouteLevel = l.RouteLevel,
            //                           RouteMethod = l.RouteMethod,
            //                           RowNumber = l.RowNumber,
            //                           UserCD = l.UserCD,
            //                           UserID = l.UserID,
            //                           UserName = l.UserName
            //                       };
            //        lstItem = new List<RouteDetailListInfo>(lstTemp1);*/
            //        lstItem = new List<RouteDetailListInfo>(lstTemp);
            //    }
            //}

            //if (lstItem.Count != 0)
            //{
            //    this.rptApprover.DataSource = lstItem;
            //    this.rptApprover.DataBind();
            //    this.ApproverList = new List<RouteDetailListInfo>(lstItem);
            //    //((List<RouteDetailListInfo>)this.ApproverList).AddRange(lstItem);
            //}
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            ////Refresh rptList
            //this.rptList.DataSource = this.GetFormTypeForDisp(false);
            //this.rptList.DataBind();
            this.ProcessMode(this.Mode);
            this.FocusControlId = this.btnAddRoute.ClientID;
        }

        /// <summary>
        /// Event Button AddRow
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        //protected void btnAddRow_Click(object sender, EventArgs e)
        //{
        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {
        //        //Find control
        //        DropDownList ddl = (DropDownList)item.FindControl("cmbTimeType");
        //        if (ddl != null)
        //        {

        //            using (DB db = new DB())
        //            {

        //                Config_HService configHSer = new Config_HService(db);
        //                var lst = configHSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_ANNUAL_DAY);
        //                string val = configHSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_ANNUAL_DAY);
        //                // init combox 
        //                ddl.DataSource = lst;
        //                ddl.DataValueField = "Value";
        //                ddl.DataTextField = "DisplayName";
        //                ddl.DataBind();
        //            }
        //        }
        //    }
        //    //Get new list from screen
        //    var listDetail = this.GetFormTypeForDisp(false);
        //    if (listDetail != null)
        //    {
        //        listDetail.Add(new FormTypeInfo());
        //    }

        //    //Process list view
        //    this.rptList.DataSource = listDetail;
        //    this.rptList.DataBind();
        //    this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
        //    this.ProcessMode(this.Mode);
        //    this.FocusControlId = string.Format("txtTypeName_{0}", listDetail.Count - 1);
        //}

        ///// <summary>
        ///// Event Button RemoveRow
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //protected void btnRemoveRow_Click(object sender, EventArgs e)
        //{
        //    //Get new list from screen
        //    var listDetail = this.GetFormTypeForDisp(false);

        //    //Get list index remove item
        //    List<int> listDel = new List<int>();
        //    for (int i = listDetail.Count - 1; i >= 0; i--)
        //    {
        //        if (listDetail[i].DeleteFlg)
        //        {
        //            listDel.Add(i);                   
        //        }

        //        listDetail[i].DeleteFlg = false;
        //    }

        //    //Remove row
        //    foreach (var item in listDel)
        //    {
        //        listDetail.RemoveAt(item);                
        //    }

        //    if (listDetail.Count == 0)
        //    {
        //        listDetail.Add(new FormTypeInfo());
        //    }

        //    ////Process list view
        //    //this.rptList.DataSource = listDetail;
        //    //this.rptList.DataBind();
        //    this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
        //    this.ProcessMode(this.Mode);
        //    //this.SetFocusWithUsed();

        //}

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:
                    //Insert Data
                    if (this.InsertData())
                    {
                        //ShowData
                        this.ShowData(this.GetHeaderData(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                    }
                    break;

                case Utilities.Mode.Delete:

                    //Delete data
                    if (!this.DeleteData())
                    {
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //ShowData
                        this.ShowData(this.GetHeaderData(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                    }
                    break;
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            //Get Config Header
            M_Form hModel = this.GetHeaderData(this.DataID);
            if (hModel != null)
            {
                //Show data
                this.ShowData(hModel);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnRemoveRoute Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveRoute_Click(object sender, EventArgs e)
        {
            var keyID = (sender as LinkButton).CommandArgument;

            if (!string.IsNullOrEmpty(keyID))//has value
            {
                M_Route_H routeItem = new M_Route_H();

                using (DB db = new DB())
                {
                    Route_HService routeHSer = new Route_HService(db);
                    routeItem = routeHSer.GetByID(int.Parse(keyID));
                }
                if (routeItem != null)
                {
                    //remove out list route
                    var lstTemp = from l in this.RouteList
                                  where l.ID != routeItem.ID
                                  select new RouteFormInfo
                                  {
                                      ID = l.ID,
                                      HadUsed = l.HadUsed,
                                      RouteCD = l.RouteCD,
                                      RouteName = l.RouteName
                                  };
                    if (lstTemp.Count() != 0)
                    {
                        this.RouteList = new List<RouteFormInfo>(lstTemp);
                        //((List<RouteFormInfo>)this.RouteList).AddRange();
                    }
                    else
                    {
                        this.RouteList = new List<RouteFormInfo>();
                    }
                    //add to list route
                    var itemNew = new RouteModel();
                    itemNew.ID = routeItem.ID;
                    itemNew.RouteCD = routeItem.RouteCD;
                    itemNew.RouteName = routeItem.RouteName;
                    this.RouteOtherList.Add(itemNew);
                    var lst = from k in this.RouteOtherList
                              orderby k.RouteCD
                              select new RouteModel
                              {
                                  ID = k.ID,
                                  RouteCD = k.RouteCD,
                                  RouteName = k.RouteName
                              };
                    this.RouteOtherList = new List<RouteModel>(lst);
                    // ((List<RouteModel>)this.RouteOtherList).AddRange(lst);
                    //Refresh data
                    this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                    ////Refresh rptList
                    //this.rptList.DataSource = this.GetFormTypeForDisp(false);
                    //this.rptList.DataBind();

                    // combox 
                    this.cmbRouteChoose.DataSource = this.RouteOtherList;
                    this.cmbRouteChoose.DataValueField = "ID";
                    this.cmbRouteChoose.DataTextField = "RouteName";
                    this.cmbRouteChoose.DataBind();
                    //List Approver
                    this.FillDataApproverByRouteID(this.RouteOtherList[0].ID);
                    this.cmbRouteChoose.Enabled = true;
                    base.DisabledLink(this.btnAddRoute, false);
                    this.ProcessMode(this.Mode);
                    this.FocusControlId = this.btnAddRoute.ClientID;
                }
            }

            /*int indexL = 0;
             if (this.RouteList.Count == 0)
             {
                 //Add new level if route list is empty
                 this.RouteList.Add(new RouteDetailInfo
                 {
                     RouteLevel = 1,
                     NumberRow = 1,
                     RouteDetailList = new List<RouteDetailListInfo>()
                 });
                 indexL = 1;
                 this.hdnRadLevelId.Value = this.RouteList[0].RouteLevel.ToString();
             }
             else
             {
                 //Get current level
                 indexL = int.Parse(this.hdnRadLevelId.Value);
             }

             int level = indexL;
             if (indexL.Equals(Constants.LEVEL_VIEW))
             {
                 indexL = this.RouteList.Count();
             }

             var key = (sender as LinkButton).CommandArgument;
             //Get user
             var u = this.UserList.Where(s => s.UserID == int.Parse(key)).SingleOrDefault();
             u.RouteLevel = level;
             u.RouteMethod = 0;
             //Add user to route detail list
             this.RouteList[indexL - 1].RouteDetailList.Add(u);
             this.RouteList[indexL - 1].NumberRow += 1;

             //Order route detail list by department id
             this.RouteList[indexL - 1].RouteDetailList = this.RouteList[indexL - 1].RouteDetailList.OrderBy(m => m.DepartmentName).ToList();

             //Set route data source
             this.rptRoute.DataSource = this.RouteList;
             this.rptRoute.DataBind();

             //Show user list
             this.ShowUserListData();*/
        }

        /// <summary>
        /// btnAddRoute Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRoute_Click(object sender, EventArgs e)
        {
            int routeID = int.Parse(this.cmbRouteChoose.SelectedValue);
            if (routeID > 0)//has value
            {
                M_Route_H routeItem = new M_Route_H();

                using (DB db = new DB())
                {
                    Route_HService routeHSer = new Route_HService(db);
                    routeItem = routeHSer.GetByID(routeID);
                }
                if (routeItem != null)
                {

                    //remove out list route choose other
                    var lstTemp = from l in this.RouteOtherList
                                  where l.ID != routeItem.ID
                                  orderby l.RouteCD
                                  select new RouteModel
                                  {
                                      ID = l.ID,
                                      RouteCD = l.RouteCD,
                                      RouteName = l.RouteName
                                  };
                    if (lstTemp.Count() != 0)
                    {
                        this.RouteOtherList = new List<RouteModel>(lstTemp);
                        //((List<RouteModel>)this.RouteOtherList).AddRange(lstTemp);
                    }
                    else
                    {
                        this.RouteOtherList = new List<RouteModel>();
                        this.ApproverList = new List<RouteDetailListInfo>();
                        this.rptApprover.DataSource = this.ApproverList;
                        this.rptApprover.DataBind();
                    }
                    //add to list route
                    var itemNew = new RouteFormInfo();
                    itemNew.ID = routeItem.ID;
                    itemNew.RouteCD = routeItem.RouteCD;
                    itemNew.RouteName = routeItem.RouteName;
                    itemNew.RowNumber = this.RouteList.Count + 1;
                    this.RouteList.Add(itemNew);
                    int rowNum = 1;
                    var lst = from k in this.RouteList
                              orderby k.RouteCD
                              select new RouteFormInfo
                               {
                                   ID = k.ID,
                                   HadUsed = k.HadUsed,
                                   RouteCD = k.RouteCD,
                                   RouteName = k.RouteName,
                                   RowNumber = rowNum++
                               };
                    this.RouteList = new List<RouteFormInfo>(lst);
                    // ((List<RouteFormInfo>)this.RouteList).AddRange(lst);
                    //Refresh data
                    this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                    ////Refresh rptList
                    //this.rptList.DataSource = this.GetFormTypeForDisp(false);
                    //this.rptList.DataBind();

                    // combox 
                    this.cmbRouteChoose.DataSource = this.RouteOtherList;
                    this.cmbRouteChoose.DataValueField = "ID";
                    this.cmbRouteChoose.DataTextField = "RouteName";
                    this.cmbRouteChoose.DataBind();
                    //List Approver
                    if (this.RouteOtherList.Count > 0)
                    {
                        this.FillDataApproverByRouteID(this.RouteOtherList[0].ID);
                    }
                    else
                    {
                        base.DisabledLink(this.btnAddRoute, true);
                        this.cmbRouteChoose.Enabled = false;
                    }
                }
                this.ProcessMode(this.Mode, true);
                this.FocusControlId = this.btnAddRoute.ClientID;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                FormTypeInfo dataItem = (FormTypeInfo)e.Item.DataItem;
                ITextBox txtTypeName = (ITextBox)e.Item.FindControl("txtTypeName");
                txtTypeName.MaxLength = M_Form.TYPE_NAME_MAX_LENGTH_DB;

                //Find control                
                DropDownList ddl = (DropDownList)e.Item.FindControl("cmbTimeType");

                this.InitDropDownListData(ddl, this.GetListTypeOfRuleByForm(this.cmbTypeFormat.Items.Count > 0 ? int.Parse(this.cmbTypeFormat.SelectedValue) : -1));
                ddl.SelectedValue = dataItem.TimeOfRule.ToString();

            }

        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.InitData(true);

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// cmbTypeFormat SelectedIndexChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbTypeFormat_SelectedIndexChanged(object sender, EventArgs e)
        {
            // int typeForm = int.Parse(this.cmbTypeFormat.SelectedValue);
            //this.InitTypeConfigList();
        }

        #endregion

        #region Method

        ///// <summary>
        ///// SetFocusWhenUpdate
        ///// </summary>
        //private void SetFocusWithUsed()
        //{
        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {
        //        if (this.IsEmptyRowType(item))
        //        {
        //            this.FocusControlId = "txtTypeName_" + item.ItemIndex;
        //            return;
        //        }

        //        HiddenField hdnHadUsed = (HiddenField)item.FindControl("hdnHadUsed");
        //        if (hdnHadUsed != null)
        //        {
        //            if (!bool.Parse(hdnHadUsed.Value))
        //            {
        //                this.FocusControlId = "txtTypeName_" + item.ItemIndex;
        //                return;
        //            }
        //        }
        //    }

        //    //Set focus on button Add row
        //    this.FocusControlId = this.btnAddRow.ClientID;
        //}

        /// <summary>
        /// GetTypeFormatFormWithoutData
        /// </summary>
        /// <param name="ddl"></param>
        private void GetTypeFormatFormWithoutData(DropDownList ddl)
        {
            ddl.Items.Clear();
            IList<DropDownModel> lst = new List<DropDownModel>();
            using (DB db = new DB())
            {
                Config_HService conSer = new Config_HService(db);
                //do not get data exist in M_Form
                lst = conSer.GetFormatTypeWithForm(M_Config_H.CONFIG_CD_TEMPLATE_TYPE, false);
            }

            // init combox 
            ddl.DataSource = lst;

            if (lst.Count > 0)
            {
                ddl.SelectedValue = lst[0].Value;
            }

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode, bool isProcess = false)
        {
            bool disable;

            //Set mode
            this.Mode = mode;
            bool disableRoute = false;
            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:

                    if (this.cmbTypeFormat.Items.Count == 0)
                    {
                        //this.DisableRepeaterList();
                        base.DisabledLink(this.btnInsert, true);
                        disableRoute = true;
                        // base.DisabledLink(this.btnAddRow, true);
                        // base.DisabledLink(this.btnDeleteRow, true);
                        this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "All Type Format Form");
                        disable = true;
                    }
                    else
                        disable = false;

                    break;
                case Mode.Update:
                    //this.DisableRepeaterList(true);
                    disable = false;
                    break;

                default://view

                    disable = true;
                    // this.DisableRepeaterList();
                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    break;
            }

            //Lock control
            this.cmbTypeFormat.Enabled = !disable;
            if (this.ApproverList != null && this.ApproverList.Count > 0)
            {
                base.DisabledLink(this.btnAddRoute, disable);
            }
            else
            {
                base.DisabledLink(this.btnAddRoute, true);
            }
            if ((this.RouteOtherList != null && this.RouteOtherList.Count > 0) && !disableRoute)
            {
                this.cmbRouteChoose.Enabled = true;
            }
            else
            {
                this.cmbRouteChoose.Enabled = false;
            }
            if (mode == Mode.Update)
            {
                this.cmbTypeFormat.Enabled = false;
            }


        }

        ///// <summary>
        ///// Disable repeater List Type
        ///// </summary>
        ///// <param name="rpt"></param>
        //private void DisableRepeaterList(bool isUpdate = false)
        //{

        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {                
        //        if (isUpdate)
        //        {
        //            bool isUsed = false;
        //            HiddenField hdnHadUsed = (HiddenField)item.FindControl("hdnHadUsed");
        //            if (hdnHadUsed != null)
        //            {
        //                isUsed = bool.Parse(hdnHadUsed.Value);
        //            }
        //            //Delete flag
        //            HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");                    
        //            if (chkDelFlg != null)
        //            {
        //                chkDelFlg.Disabled = isUsed;
        //            }

        //            //Type Name 
        //            ITextBox txtTypeNm = (ITextBox)item.FindControl("txtTypeName");
        //            if (txtTypeNm != null)
        //                txtTypeNm.ReadOnly = isUsed;

        //            //Time Of Rule
        //            DropDownList ddlTypeTime = (DropDownList)item.FindControl("cmbTimeType");
        //            if (ddlTypeTime != null)
        //                ddlTypeTime.Enabled = !isUsed;
        //        }
        //        else
        //        {
        //            //Delete flag
        //            HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");
        //            if (chkDelFlg != null)
        //            {
        //                chkDelFlg.Disabled = true;
        //            }
        //            ITextBox txtTypeNm = (ITextBox)item.FindControl("txtTypeName");
        //            if (txtTypeNm != null)
        //                txtTypeNm.ReadOnly = true;
        //            DropDownList ddlTypeTime = (DropDownList)item.FindControl("cmbTimeType");
        //            if (ddlTypeTime != null)
        //                ddlTypeTime.Enabled = false;
        //        }
        //    }
        //}

        /// <summary>
        /// Init Combobox TypeForm
        /// </summary>
        private void InitComboboxTypeForm(DropDownList ddl, string configCD)
        {
            ddl.Items.Clear();
            IList<DropDownModel> list = new List<DropDownModel>();
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                list = configSer.GetDataForDropDownList(configCD);
                string value = configSer.GetDefaultValueDrop(configCD);
                if (list.Count > 0)
                {
                    if (string.IsNullOrEmpty(value))
                    {
                        ddl.SelectedValue = list[0].Value;
                    }
                    else
                    {
                        ddl.SelectedValue = value;
                    }
                }
            }
            ddl.DataSource = list;
            // init combox 
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combobox Route
        /// </summary>
        private void InitComboboxRoute()
        {
            int valueInit = -1;
            IList<RouteModel> lst = new List<RouteModel>();
            IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                lst = routeSer.GetList();
                //Add Blank
                lst.Insert(0, new RouteModel());
                ////if (lst.Count != 0)
                ////{                    
                ////    // ((List<RouteModel>)this.RouteOtherList).AddRange(lst);
                ////    valueInit = lst[0].ID;
                ////    Route_DService routeDSer = new Route_DService(db);
                ////    var lstTemp = routeDSer.GetListDetailInfo(valueInit, -1);
                ////    if (lstTemp != null && lstTemp.Count != 0)
                ////    {
                ////        var lstTemp1 = (from l in lstTemp
                ////                        where l.RouteLevel != M_Route_H.LEVEL_APPLICANT
                ////                        select l).ToList<RouteDetailListInfo>();

                ////         lstItem = new List<RouteDetailListInfo>(lstTemp1);
                ////       // lstItem = new List<RouteDetailListInfo>(lstTemp);
                ////    }
                ////}
            }

            // init combox 
            this.cmbRouteChoose.DataSource = lst;
            this.cmbRouteChoose.DataValueField = "ID";
            this.cmbRouteChoose.DataTextField = "RouteName";
            this.cmbRouteChoose.DataBind();
            this.RouteOtherList = new List<RouteModel>(lst);
            this.ApproverList = new List<RouteDetailListInfo>();
            this.rptApprover.DataSource = this.ApproverList;
            this.rptApprover.DataBind();
            ////if (lstItem.Count != 0)
            ////{
            ////    this.rptApprover.DataSource = lstItem;
            ////    this.rptApprover.DataBind();
            ////    this.ApproverList = new List<RouteDetailListInfo>(lstItem);
            ////    // ((List<RouteDetailListInfo>)this.ApproverList).AddRange(lstItem);
            ////}
            ////else
            ////    this.ApproverList = new List<RouteDetailListInfo>();
        }

        /// <summary>
        /// GetListRoute for Choose
        /// ISV-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="formID"></param>
        private void GetListRouteChoose(int formID)
        {
            int valueInit = -1;
            IList<RouteModel> lst = new List<RouteModel>();
            IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                lst = routeSer.GetListOtherByFormID(formID);
                //Add Blank
                lst.Insert(0, new RouteModel());
                ////if (lst.Count != 0)
                ////{

                ////    this.RouteOtherList = new List<RouteModel>(lst);
                ////    //((List<RouteModel>)this.RouteOtherList).AddRange(lst);
                ////    valueInit = lst[0].ID;
                ////    Route_DService routeDSer = new Route_DService(db);
                ////    var lstTemp = routeDSer.GetListDetailInfo(valueInit, -1);
                ////    if (lstTemp != null && lstTemp.Count != 0)
                ////    {
                ////        var lstTemp1 = (from l in lstTemp
                ////                        where l.RouteLevel != M_Route_H.LEVEL_APPLICANT
                ////                        select l).ToList<RouteDetailListInfo>();

                ////        lstItem = new List<RouteDetailListInfo>(lstTemp1);
                ////       // lstItem = new List<RouteDetailListInfo>(lstTemp);
                ////    }

                ////}
                ////else
                ////{
                ////    this.RouteOtherList = new List<RouteModel>();
                ////    this.ApproverList = new List<RouteDetailListInfo>();
                ////}
                this.RouteOtherList = new List<RouteModel>(lst);
            }

            // init combox 
            this.cmbRouteChoose.DataSource = lst;
            this.cmbRouteChoose.DataValueField = "ID";
            this.cmbRouteChoose.DataTextField = "RouteName";
            this.cmbRouteChoose.DataBind();

            this.ApproverList = new List<RouteDetailListInfo>();
            this.rptApprover.DataSource = this.ApproverList;
            this.rptApprover.DataBind();
            // ((List<RouteDetailListInfo>)this.ApproverList).AddRange(lstItem);
            if (this.RouteOtherList.Count > 0)
            {
                this.cmbRouteChoose.Enabled = true;
                base.DisabledLink(this.btnAddRoute, false);
            }
            else
            {
                base.DisabledLink(this.btnAddRoute, true);
                this.cmbRouteChoose.Enabled = false;
            }

        }

        /// <summary>
        /// FillDataApproverByRouteID
        /// </summary>
        /// <param name="RouteID"></param>
        private void FillDataApproverByRouteID(int RouteID)
        {
            IList<RouteDetailListInfo> lstItem = new List<RouteDetailListInfo>();
            using (DB db = new DB())
            {
                Route_DService routeDSer = new Route_DService(db);
                var lstTemp = routeDSer.GetListDetailInfo(RouteID, -1);

                if (lstTemp != null && lstTemp.Count != 0)
                {
                    var lstTemp1 = (from l in lstTemp
                                    where l.RouteLevel != M_Route_H.LEVEL_APPLICANT
                                    select l).ToList<RouteDetailListInfo>();

                    lstItem = new List<RouteDetailListInfo>(lstTemp1);
                    //lstItem = new List<RouteDetailListInfo>(lstTemp);
                }
            }

            this.ApproverList = new List<RouteDetailListInfo>(lstItem);
            // ((List<RouteDetailListInfo>)this.ApproverList).AddRange(lstItem);

            this.rptApprover.DataSource = lstItem;
            this.rptApprover.DataBind();
        }

        ///// <summary>
        ///// Init Detail List
        ///// </summary>
        //private void InitTypeConfigList()
        //{
        //    //Add data
        //    IList<FormTypeInfo> listDetail = new List<FormTypeInfo>();
        //    listDetail.Add(new FormTypeInfo());

        //    //Process list view
        //    this.rptList.DataSource = listDetail;
        //    this.rptList.DataBind();           
        //}        

        /// <summary>
        /// GetListTypeOfRule By Form Type
        /// </summary>
        private IList<DropDownModel> GetListTypeOfRuleByForm(int formType)
        {
            IList<DropDownModel> lstRet = new List<DropDownModel>();
            List<int> lstVal = new List<int>();
            switch (formType)
            {
                case 0://Leave
                    lstVal = Enum.GetValues(typeof(TimeOfRuleLeave)).Cast<int>().ToList();
                    break;

                case 1://Time&Attendance
                    lstVal = Enum.GetValues(typeof(TimeOfRuleTimeAttendance)).Cast<int>().ToList();
                    break;
                default:
                    //Get enum : None
                    lstVal = Enum.GetValues(typeof(TimeOfRuleLeave)).Cast<int>().ToList();
                    lstVal.RemoveRange(1, lstVal.Count - 1);
                    break;
            }

            for (int i = 0; i < lstVal.Count; i++)
            {
                var val = lstVal[i];
                DropDownModel item = new DropDownModel();
                switch (formType)
                {
                    case 0://Leave
                        item.DisplayName = this.GetTimeOfRuleLeaveName(val);
                        break;

                    case 1://Time&Attendance
                        item.DisplayName = this.GetTimeOfRuleTimeName(val);
                        break;
                    default:
                        //Get enum : None
                        item.DisplayName = GetTimeOfRuleLeaveName(val);
                        break;
                }

                item.Value = val.ToString();
                lstRet.Add(item);
            }

            return lstRet;
        }

        /// <summary>
        /// InitDropDownListData
        /// </summary>
        /// <param name="dropDownList"></param>
        /// <param name="data"></param>
        private void InitDropDownListData(DropDownList dropDownList, IList<DropDownModel> data)
        {
            dropDownList.DataSource = data;
            dropDownList.DataTextField = "DisplayName";
            dropDownList.DataValueField = "Value";
            dropDownList.DataBind();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData(bool inProcess = false)
        {
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";
            // this.ViewState[IS_DATA_CHANGED] = false;
            //Get type of rule data
            //this.GetListAllTypeOfRule();

            //Init combo Type Form (header)
            if (!inProcess)
                this.InitComboboxTypeForm(this.cmbTypeFormat, M_Config_H.CONFIG_CD_TEMPLATE_TYPE);
            else
            {
                this.GetTypeFormatFormWithoutData(this.cmbTypeFormat);
            }
            ////Init List config
            //this.InitTypeConfigList();

            //Init Combo Route (Choose)
            this.InitComboboxRoute();

            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec), true, true);

            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        private void ShowRouteListData()
        {

            int sortField = 3;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }

            //Show condition
            if (this.ViewState["ConditionDetail"] != null)
            {
                Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];

                this.ShowCondition(data);
            }

            //Show data on grid
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

        }

        /// <summary>
        /// Get Header Data
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        private M_Form GetHeaderData(int id)
        {
            using (DB db = new DB())
            {
                FormService dbSer = new FormService(db);

                //Get Config header
                return dbSer.GetByID(id);
            }
        }

        /// <summary>
        /// Show header data on form
        /// </summary>
        /// <param name="model">M_Config_H</param>
        private void ShowData(M_Form model)
        {
            if (model != null)
            {
                //Display header
                this.DataID = model.FormID;
                // this.txtConfigCD.Value = model.ConfigCD;
                //  this.txtConfigName.Value = model.ConfigName;
                this.cmbTypeFormat.SelectedValue = model.FormID.ToString();
                this.OldUpdateDate = model.UpdateDate;
                ////Show list form type(config)
                //this.ShowTypeNameData(this.DataID);
                //Show list route
                this.ShowListRouteData(this.DataID);

                //Show list approver by route(choose)
                this.GetListRouteChoose(this.DataID);

                this.ShowRouteListData();
            }
        }

        ///// <summary>
        ///// Show detail data on form
        ///// </summary>
        ///// <param name="headerID">Header ID</param>
        //private void ShowTypeNameData(int formID)
        //{
        //    using (DB db = new DB())
        //    {
        //        FormTypeService dbSer = new FormTypeService(db);

        //        //Get list detail
        //        IList<FormTypeInfo> listDetail = dbSer.GetListByFormID(formID);
        //        if (listDetail != null && listDetail.Count != 0)
        //        {
        //            //this.TypeNameList = new List<FormTypeInfo>();
        //            //((List<FormTypeInfo>)this.TypeNameList).AddRange(listDetail);
        //            this.rptList.DataSource = listDetail;
        //        }
        //        else
        //        {
        //            this.rptList.DataSource = null;
        //        }

        //        this.rptList.DataBind();
        //    }
        //}

        /// <summary>
        /// Show data of list route
        /// </summary>
        /// <param name="formID"></param>
        private void ShowListRouteData(int formID)
        {
            using (DB db = new DB())
            {
                Route_HService dbSer = new Route_HService(db);

                //Get list detail
                IList<RouteFormInfo> listDetail = dbSer.GetListByFormIDHasSort(formID, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                if (listDetail != null && listDetail.Count != 0)
                {
                    this.RouteList = new List<RouteFormInfo>(listDetail);
                    // ((List<RouteFormInfo>)this.RouteList).AddRange(listDetail);
                    this.rptRouteList.DataSource = listDetail;
                }
                else
                {
                    this.rptRouteList.DataSource = null;
                }

                this.rptRouteList.DataBind();
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {

            List<int> lstDup = new List<int>();

            bool hasData = false;

            //foreach (RepeaterItem item in this.rptList.Items)
            //{
            //    if (this.IsEmptyRowType(item))
            //    {
            //        continue;
            //    }

            //    hasData = true;
            //    int rowIndex = item.ItemIndex + 1;

            //    //TypeName
            //    ITextBox txtTypeName = (ITextBox)item.FindControl("txtTypeName");
            //    if (txtTypeName != null)
            //    {
            //        HtmlGenericControl divValue = (HtmlGenericControl)item.FindControl("divTypeName");
            //        divValue.Attributes.Remove("class");
            //        string errorId = txtTypeName.ID + "_" + item.ItemIndex.ToString();
            //        if (string.IsNullOrEmpty(txtTypeName.Value))
            //        {
            //            base.SetMessage(errorId, M_Message.MSG_REQUIRE_GRID, "Type Name", rowIndex);
            //            this.AddErrorForListItem(divValue, errorId);
            //        }
            //        else
            //        {
            //            txtTypeName.Value = txtTypeName.Value;
            //        }
            //    }

            //}

            //if (!hasData)
            //{
            //    ITextBox txtTypeName = (ITextBox)this.rptList.Items[0].FindControl("txtTypeName");
            //    HtmlGenericControl divValue = (HtmlGenericControl)this.rptList.Items[0].FindControl("divTypeName");
            //    string errorId = txtTypeName.ID + "_" + this.rptList.Items[0].ItemIndex.ToString();
            //    base.SetMessage(errorId, M_Message.MSG_REQUIRE_GRID, "Type Name", 1);
            //    this.AddErrorForListItem(divValue, errorId);
            //}

            if (this.RouteList.Count == 0)
            {
                this.SetMessage(string.Empty, M_Message.MSG_REQUIRE, "Route List");
            }

            if (this.Mode != Mode.Update && !base.HaveError)
            {
                //Check exist form in DB
                using (DB db = new DB())
                {
                    FormService frmSer = new FormService(db);
                    var form = frmSer.GetByID(int.Parse(this.cmbTypeFormat.SelectedValue));
                    if (form != null)
                    {
                        this.SetMessage(this.cmbTypeFormat.ID, M_Message.MSG_EXIST_CODE, "Type Format Form");
                    }
                }

            }
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Add display error for control
        /// </summary>
        /// <param name="divCtrl">div error control</param>
        /// <param name="errorKey">Error Control ID</param>
        private void AddErrorForListItem(HtmlGenericControl divCtrl, string errorKey)
        {
            divCtrl.Attributes.Add("class", base.GetClassError(errorKey));
            //Control ctrError = ParseControl(base.GetSpanError(errorKey));
            //divCtrl.Controls.Add(ctrError);
        }

        /// <summary>
        /// Check empty row
        /// </summary>
        /// <returns></returns>
        private bool IsEmptyRowType(RepeaterItem item)
        {
            bool ret = true;

            //TypeName
            ITextBox txtValue1 = (ITextBox)item.FindControl("txtTypeName");
            //TimeType
            DropDownList ddl = (DropDownList)item.FindControl("cmbTimeType");
            if (txtValue1 != null)
            {
                if (!string.IsNullOrEmpty(txtValue1.Value.Trim()))
                {
                    ret = false;
                }
            }
            if (ddl != null)
                if (!string.IsNullOrEmpty(ddl.SelectedValue) && int.Parse(ddl.SelectedValue) != 1)
                {
                    ret = false;
                }
            return ret;
        }

        /// <summary>
        /// Check exist Config by Config Code
        /// </summary>
        /// <param name="ConfigCD">Config Code</param>
        /// <returns></returns>
        private bool IsExistConfigCode(string ConfigCD)
        {
            using (DB db = new DB())
            {
                Config_HService dbSer = new Config_HService(db);

                //Check Exist
                return dbSer.IsExistConfigCode(ConfigCD);
            }
        }

        ///// <summary>
        ///// Get detail list from screen
        ///// </summary>
        ///// <returns></returns>
        //private List<FormTypeInfo> GetFormTypeForDisp(bool isProcess)
        //{
        //    List<FormTypeInfo> results = new List<FormTypeInfo>();

        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {
        //        if (isProcess && this.IsEmptyRowType(item))
        //        {
        //            continue;
        //        }

        //        HtmlInputCheckBox chkDelFlg = (HtmlInputCheckBox)item.FindControl("deleteFlag");
        //        ITextBox txtTypeName = (ITextBox)item.FindControl("txtTypeName");
        //        DropDownList ddlType = (DropDownList)item.FindControl("cmbTimeType");
        //        HiddenField hdnHadUsed = (HiddenField)item.FindControl("hdnHadUsed");
        //        HiddenField hdnID = (HiddenField)item.FindControl("hdnID");
        //        FormTypeInfo addItem = new FormTypeInfo();
        //        if (hdnHadUsed != null)
        //        {
        //            addItem.HadUsed = bool.Parse(hdnHadUsed.Value);
        //        }
        //        //Delete flag
        //        if (chkDelFlg != null)
        //        {
        //            addItem.DeleteFlg = (chkDelFlg.Checked) ? true : false;
        //        }
        //        addItem.TimeOfRule = short.Parse(ddlType.SelectedValue);
        //        addItem.TypeName = txtTypeName.Text;
        //        addItem.ID = int.Parse(hdnID.Value);
        //        results.Add(addItem);
        //    }
        //    //if (results.Count != 0)
        //    //{
        //    //    this.TypeNameList = new List<FormTypeInfo>();
        //    //    ((List<FormTypeInfo>)this.TypeNameList).AddRange(results);
        //    //}
        //    return results;
        //}

        ///// <summary>
        ///// GetFormTypeForInsert
        ///// </summary>
        ///// <param name="isProcess"></param>
        ///// <returns></returns>
        //private List<M_Form_Type> GetFormTypeForInsert(int formID)
        //{
        //    List<M_Form_Type> results = new List<M_Form_Type>();

        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {
        //        if (this.IsEmptyRowType(item))
        //        {
        //            continue;
        //        }

        //        ITextBox txtTypeName = (ITextBox)item.FindControl("txtTypeName");
        //        DropDownList ddlTypeOfRule = (DropDownList)item.FindControl("cmbTimeType");
        //        M_Form_Type addItem = new M_Form_Type();
        //        addItem.TypeName = txtTypeName.Text;
        //        addItem.TimeOfRule = short.Parse(ddlTypeOfRule.SelectedValue);
        //        addItem.FormID = formID;
        //        results.Add(addItem);
        //    }

        //    return results;
        //}

        ///// <summary>
        ///// GetFormTypeForUpdate
        ///// </summary>
        ///// <param name="formID"></param>
        ///// <returns></returns>
        //private List<M_Form_Type> GetFormTypeForUpdate(int formID, ref Hashtable htb)
        //{
        //    List<M_Form_Type> results = new List<M_Form_Type>();

        //    foreach (RepeaterItem item in this.rptList.Items)
        //    {
        //        if (this.IsEmptyRowType(item))
        //        {
        //            continue;
        //        }

        //        HiddenField hdnHadUsed = (HiddenField)item.FindControl("hdnHadUsed");
        //        if (hdnHadUsed != null && bool.Parse(hdnHadUsed.Value))
        //        {
        //            continue;
        //        }
        //        HiddenField hdnID = (HiddenField)item.FindControl("hdnID");
        //        ITextBox txtTypeName = (ITextBox)item.FindControl("txtTypeName");
        //        DropDownList ddlTypeOfRule = (DropDownList)item.FindControl("cmbTimeType");
        //        M_Form_Type addItem = new M_Form_Type();
        //        addItem.TypeName = txtTypeName.Text;
        //        addItem.ID = string.IsNullOrEmpty(hdnID.Value) ? 0 : int.Parse(hdnID.Value);
        //        addItem.TimeOfRule = short.Parse(ddlTypeOfRule.SelectedValue);
        //        addItem.FormID = formID;
        //        if (addItem.ID > 0)
        //        {
        //            htb.Add(addItem.ID, addItem.ID);
        //        }
        //        results.Add(addItem);
        //    }

        //    return results;
        //}

        /// <summary>
        /// GetListRouteForInsert
        /// 2015/04/27
        /// ISV-TRUC
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        private IList<M_Form_Route> GetListRouteForInsert(int formID)
        {
            IList<M_Form_Route> lst = new List<M_Form_Route>();
            if (this.RouteList.Count != 0)
            {
                foreach (var item in this.RouteList)
                {
                    M_Form_Route fr = new M_Form_Route();
                    fr.FormID = formID;
                    fr.RouteID = item.ID;
                    lst.Add(fr);
                }
            }
            return lst;
        }

        /// <summary>
        /// GetListRouteForUpdate
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        private IList<M_Form_Route> GetListRouteForUpdate(DB db, int formID, ref bool isError)
        {
            IList<M_Form_Route> lst = new List<M_Form_Route>();
            IList<M_Form_Route> lstDB = new List<M_Form_Route>();
            Dictionary<int, int> dicLstScreen = new Dictionary<int, int>();

            FormRouteService frmRouteSer = new FormRouteService(db);
            lstDB = frmRouteSer.GetListByFormID(formID);
            dicLstScreen = this.RouteList.ToDictionary(s => s.ID, s => s.ID);

            if (this.RouteList.Count != 0)
            {
                foreach (var rDB in lstDB)
                {
                    if (!dicLstScreen.ContainsKey(rDB.RouteID))//not exist in Screen--> has been deleted
                    {
                        //Check exist in other table
                        FormLinkService frmLinkSer = new FormLinkService(db);
                        FormLinkMaster linkObj = frmLinkSer.GetByFormIDAndRouteID(formID, rDB.RouteID);
                        if (linkObj != null)
                        {
                            isError = true;
                            return lst;
                        }
                    }
                }

                foreach (var item in this.RouteList)
                {
                    M_Form_Route fr = new M_Form_Route();
                    fr.FormID = formID;
                    fr.RouteID = item.ID;
                    lst.Add(fr);
                }
            }
            return lst;
        }

        /// <summary>
        /// GetHeaderInsert
        /// </summary>
        /// <returns></returns>
        private M_Form GetHeaderInsert()
        {
            M_Form header = new M_Form();
            header.FormID = int.Parse(this.cmbTypeFormat.SelectedValue);
            header.CreateUID = this.LoginInfo.User.ID;
            header.UpdateUID = this.LoginInfo.User.ID;
            return header;
        }

        ///// <summary>
        ///// Check List Type Changed
        ///// </summary>
        ///// <param name="db"></param>
        ///// <param name="formID"></param>
        ///// <returns></returns>
        //private bool IsListTypeChanged(DB db, int formID)
        //{
        //    FormTypeService frmTypeSer = new FormTypeService(db);
        //    IList<FormTypeInfo> lstFrmTypeDB = frmTypeSer.GetListByFormID(formID);
        //    var listDetail = this.GetFormTypeForDisp(false);
        //    if (lstFrmTypeDB.Count != listDetail.Count)
        //    {
        //        return true;
        //    }
        //    else
        //    {
        //        for (int i = 0; i < lstFrmTypeDB.Count; i++)
        //        {
        //            if (!lstFrmTypeDB[i].TypeName.Equals(listDetail[i].TypeName))
        //            {
        //                return true;
        //            }
        //            if (lstFrmTypeDB[i].TimeOfRule != listDetail[i].TimeOfRule)
        //            {
        //                return true;
        //            }
        //        }
        //        //foreach (RepeaterItem item in this.rptList.Items)
        //        //{                    
        //        //    ITextBox txtTypeNm = (ITextBox)item.FindControl("txtTypeName");
        //        //    if (txtTypeNm != null)
        //        //        if (txtTypeNm.Text.Equals(lstFrmTypeDB[item.ItemIndex].TypeName))
        //        //        {
        //        //            return true;
        //        //        }
        //        //    //Chua xu ly cmbTimeType
        //        //    //DropDownList ddlTypeTime = (DropDownList)item.FindControl("cmbTimeType");
        //        //    //if (ddlTypeTime != null)
        //        //    //{
        //        //    //}
        //        //}
        //    }
        //    return false;
        //}

        /// <summary>
        /// Check List Route Changed
        /// </summary>
        /// <param name="db"></param>
        /// <param name="formID"></param>
        /// <returns></returns>
        private bool IsListRouteChanged(DB db, int formID)
        {
            FormRouteService frmRouteSer = new FormRouteService(db);
            IList<M_Form_Route> lstFrmRouteDB = frmRouteSer.GetListByFormID(formID);

            if (lstFrmRouteDB.Count != this.RouteList.Count)
            {
                return true;
            }
            else
            {
                //sort again, because 2 list, sort field diffirent --> alway diffirent
                var lstTemp1 = (from t in this.RouteList
                                orderby t.ID ascending
                                select new RouteInfo
                                {
                                    ID = t.ID
                                }).ToList<RouteInfo>();
                var lstTemp2 = (from d in lstFrmRouteDB
                                orderby d.RouteID ascending
                                select new RouteInfo
                                {
                                    ID = d.RouteID
                                }).ToList<RouteInfo>();
                for (int i = 0; i < this.RouteList.Count; i++)
                {
                    if (lstTemp1[i].ID != lstTemp2[i].ID)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        private bool InsertData()
        {
            M_Form header = this.GetHeaderInsert();
            //  IList<M_Form_Type> lstFormType = new List<M_Form_Type>();
            // lstFormType = this.GetFormTypeForInsert(header.FormID);
            IList<M_Form_Route> lstRoute = this.GetListRouteForInsert(header.FormID);
            var ret = 0;
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Insert M_Form
                    FormService headerService = new FormService(db);
                    ret = headerService.Insert(header);
                    if (ret != 0)
                    {
                        this.DataID = header.FormID;
                        //insert M_Form_Type
                        // int detailID = 1;//hinh nhu la tu tang moi dung?????
                        //FormTypeService formTypeSer = new FormTypeService(db);
                        //foreach (var item in lstFormType)
                        //{
                        //    //item.ID = detailID++;
                        //    ret = formTypeSer.Insert(item);
                        //}

                        //insert M_Form_Route
                        FormRouteService formRouteSer = new FormRouteService(db);
                        foreach (var item in lstRoute)
                        {
                            ret = formRouteSer.Insert(item);
                        }
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_FORM_PK))
                {
                    this.SetMessage(this.cmbTypeFormat.ID, M_Message.MSG_EXIST_CODE, "Type Format Form");
                    Log.Instance.WriteLog(ex);
                    return false;
                }
                if (ex.Message.Contains(Models.Constant.M_FORM_ROUTE_FK))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_NOT_EXISTS);
                    Log.Instance.WriteLog(ex);
                    return false;
                }
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                var ret = 0;
                M_Form header = this.GetHeaderData(this.DataID);
                if (header != null)
                {
                    Hashtable htbLstUpdate = new Hashtable();

                    bool isRouteError = false;
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        bool lstRouteChanged = this.IsListRouteChanged(db, header.FormID);
                        if (lstRouteChanged)
                        {
                            //Update M_Form
                            FormService headerService = new FormService(db);
                            header.UpdateDate = this.OldUpdateDate;
                            header.UpdateUID = this.LoginInfo.User.ID;
                            ret = headerService.Update(header);
                            if (ret > 0)
                            {
                                if (lstRouteChanged)
                                {
                                    IList<M_Form_Route> lstRoute = this.GetListRouteForUpdate(db, header.FormID, ref isRouteError);
                                    if (!isRouteError)
                                    {
                                        FormRouteService formRouteSer = new FormRouteService(db);
                                        formRouteSer.Delete(header.FormID);
                                        //insert M_Form_Route
                                        foreach (var item in lstRoute)
                                        {
                                            formRouteSer.Insert(item);
                                        }
                                    }
                                    else
                                    {
                                        //data has already used by another table
                                        this.SetMessage(string.Empty, M_Message.MSG_DATA_EXISTS);
                                        return false;
                                    }
                                }
                                db.Commit();
                            }
                        }
                        else
                            return true;
                    }

                }
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                if (this.CheckIsExist())
                {
                    return false;
                }
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    ////Delete Type
                    //FormTypeService frmTypeSer = new FormTypeService(db);
                    //frmTypeSer.Delete(this.DataID);

                    //Delete Route
                    FormRouteService frmRouteSer = new FormRouteService(db);
                    frmRouteSer.Delete(this.DataID);

                    //Delete header
                    FormService headerService = new FormService(db);
                    ret = headerService.Delete(this.DataID, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        db.Commit();
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// LoadDataGrid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage, int sortField, int sortDirec, bool isInit = false, bool isNew = false)
        {
            int totalRow = 0;
            //this.HeaderGrid.AddColumms(new string[] { "", "", "Route CD", "Route Name" });
            //this.HeaderGrid.IsShowEmpty = true;
            //this.PagingHeader.IsShowEmpty = true;

            IList<RouteFormInfo> dataSource = new List<RouteFormInfo>();
            if (isInit)
            {
                if (isNew)
                {
                    this.RouteList = new List<RouteFormInfo>();
                    //RouteInfo item = new RouteInfo();
                    //item.RowNumber = 0;
                    //item.RouteCD = string.Empty;
                    //item.RouteName = string.Empty;
                    //this.RouteList.Add(item);
                    //dataSource = this.RouteList;
                }
                else
                {
                    //Get data
                    using (DB db = new DB())
                    {
                        //---CategoryService service = new CategoryService(db);
                        // UserService service = new UserService(db);
                        // var lstUser = service.GetListSortBy(sortField, sortDirec);
                        Route_HService routeHSer = new Route_HService(db);
                        dataSource = routeHSer.GetListByFormIDHasSort(this.DataID, sortField, sortDirec);
                    }
                    #region Route List

                    //int rowNumber = 1;
                    //foreach (var item in lstTemp)
                    //{
                    //   // if (!this.ExistsInRouteList(user.UserID))
                    //  //  {
                    //        item.RowNumber = rowNumber;
                    //        dataSource.Add(item);
                    //        rowNumber += 1;
                    //  //  }
                    //}

                    this.RouteList = new List<RouteFormInfo>(dataSource);
                    //((List<RouteFormInfo>)this.RouteList).AddRange(dataSource);

                    #endregion
                }
            }
            else
            {
                IList<RouteFormInfo> lstTemp = new List<RouteFormInfo>();
                //sort ...?
                int rowNum = 1;
                if (sortField == 3)
                {
                    if (sortDirec == 1)
                    {
                        lstTemp = (from t in this.RouteList
                                   orderby t.RouteCD ascending
                                   select new RouteFormInfo
                                   {
                                       ID = t.ID,
                                       HadUsed = t.HadUsed,
                                       RouteCD = t.RouteCD,
                                       RouteName = t.RouteName,
                                       RowNumber = rowNum++
                                   }).ToList<RouteFormInfo>();
                    }
                    else
                    {
                        lstTemp = (from t in this.RouteList
                                   orderby t.RouteCD descending
                                   select new RouteFormInfo
                                   {
                                       ID = t.ID,
                                       HadUsed = t.HadUsed,
                                       RouteCD = t.RouteCD,
                                       RouteName = t.RouteName,
                                       RowNumber = rowNum++
                                   }).ToList<RouteFormInfo>();
                    }
                }
                else if (sortField == 4)
                {
                    if (sortDirec == 1)
                    {
                        lstTemp = (from t in this.RouteList
                                   orderby t.RouteName ascending
                                   select new RouteFormInfo
                                   {
                                       ID = t.ID,
                                       HadUsed = t.HadUsed,
                                       RouteCD = t.RouteCD,
                                       RouteName = t.RouteName,
                                       RowNumber = rowNum++
                                   }).ToList<RouteFormInfo>();
                    }
                    else
                    {
                        lstTemp = (from t in this.RouteList
                                   orderby t.RouteName descending
                                   select new RouteFormInfo
                                   {
                                       ID = t.ID,
                                       HadUsed = t.HadUsed,
                                       RouteCD = t.RouteCD,
                                       RouteName = t.RouteName,
                                       RowNumber = rowNum++
                                   }).ToList<RouteFormInfo>();
                    }
                }
                this.RouteList = new List<RouteFormInfo>(lstTemp);
                // ((List<RouteFormInfo>)this.RouteList).AddRange(lstTemp);
                dataSource = new List<RouteFormInfo>(this.RouteList);
            }
            totalRow = dataSource.Count;
            //Paging
            dataSource = dataSource.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();

            #region Set paging info
            //Show data
            if (dataSource.Count == 0)
            {
                if (this.ViewState["ConditionDetail"] != null)
                {
                    Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];
                    int curPage = int.Parse(data["CurrentPage"].ToString());
                    if (curPage != 1)
                    {
                        curPage -= 1;

                        this.PagingHeader.CurrentPage = curPage;
                        this.PagingFooter.CurrentPage = curPage;

                        int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                        this.PagingHeader.NumRowOnPage = rowOfPage;

                        this.SaveCondition();

                        //Show data on grid
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

                        return;
                    }
                }

                this.rptRouteList.DataSource = null;
                this.RouteList = new List<RouteFormInfo>();

            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(dataSource[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(dataSource[dataSource.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                this.SaveCondition();

                // header
                this.HeaderGrid.TotalRow = totalRow;
                //this.HeaderGrid.AddColumms(new string[] { "", "", "Route CD", "Route Name" });

                // detail
                this.rptRouteList.DataSource = dataSource;
            }
            #endregion
            this.rptRouteList.DataBind();
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            this.ViewState["ConditionDetail"] = hash;
        }

        /// <summary>
        /// Get Default Value
        /// </summary>
        /// <returns></returns>
        private int GetDefaultValuePaging()
        {
            using (DB db = new DB())
            {
                Config_HService service = new Config_HService(db);
                string ret = service.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAGING);
                return string.IsNullOrEmpty(ret) ? 0 : int.Parse(ret);
            }
        }

        /// <summary>
        /// Check list has record
        /// </summary>
        /// <returns></returns>
        //public bool GetHasRecord()
        //{
        //    /* var lstUser = (IList<RouteDetailListInfo>)this.UserList;
        //     int sortField = 2;
        //     int sortDirec = 1;
        //     //Show condition
        //     if (this.ViewState["ConditionDetail"] != null)
        //     {
        //         Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];

        //         this.ShowCondition(data);

        //         if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
        //         {
        //             sortField = int.Parse(this.HeaderGrid.SortField);
        //         }
        //         if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
        //         {
        //             sortDirec = int.Parse(this.HeaderGrid.SortDirec);
        //         }
        //     }
        //     if (lstUser.Count == 0)
        //     {
        //         this.PagingFooter.CurrentPage = this.PagingHeader.CurrentPage = 1;
        //         this.LoadDataGrid(this.PagingFooter.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
        //         lstUser = (IList<RouteDetailListInfo>)this.UserList;
        //         this.SaveCondition();
        //         if (lstUser.Count == 0)
        //         {
        //             return false;
        //         }
        //     }*/

        //   /*---- var lstRoute = (IList<RouteFormInfo>)this.RouteList;
        //    int sortField = 3;
        //    int sortDirec = 1;
        //    //Show condition
        //    if (this.ViewState["ConditionDetail"] != null)
        //    {
        //        Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];

        //        this.ShowCondition(data);

        //        if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
        //        {
        //            sortField = int.Parse(this.HeaderGrid.SortField);
        //        }
        //        if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
        //        {
        //            sortDirec = int.Parse(this.HeaderGrid.SortDirec);
        //        }
        //    }
        //    if (lstRoute.Count == 0)
        //    {
        //        this.PagingFooter.CurrentPage = this.PagingHeader.CurrentPage = 1;
        //        this.LoadDataGrid(this.PagingFooter.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
        //        this.SaveCondition();
        //        if (lstRoute.Count == 0)
        //        {
        //            return false;
        //        }
        //    }*/
        //    return true;
        //}

        /// <summary>
        /// Check is has data for approver
        /// </summary>
        /// <returns></returns>
        public bool IsHasApprover()
        {
            return (this.ApproverList != null && this.ApproverList.Count != 0);
        }

        /// <summary>
        /// Check data is exist in another place
        /// </summary>
        /// <returns></returns>
        private bool CheckIsExist()
        {
            bool typeExist = false;
            bool routeExist = false;
            //IList<FormTypeInfo> lstTypeSc = this.GetFormTypeForDisp(false);
            //using (DB db = new DB())
            //{
            //    //Check Type in Apply
            //    ApplyService appSer = new ApplyService(db);
            //    for (int i = 0; i < lstTypeSc.Count; i++)
            //    {
            //        var item = lstTypeSc[i];
            //        typeExist = appSer.IsExistFormType(item.ID);
            //        if (typeExist)
            //            break;
            //    }

            //    FormLinkService frmLinkSer = new FormLinkService(db);
            //    //Check Route in M_Form_Link
            //    for (int j = 0; j < this.RouteList.Count; j++)
            //    {
            //        var itRoute=this.RouteList[j];
            //        routeExist = frmLinkSer.IsExistFormRoute(this.DataID, itRoute.ID);
            //        if (routeExist)
            //            break;
            //    }
            //}
            if (routeExist || typeExist)
            {
                this.SetMessage(string.Empty, M_Message.MSG_DATA_EXISTS);
                return true;
            }
            return false;
        }

        /// <summary>
        /// GetTimeOfRuleLeaveName
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string GetTimeOfRuleLeaveName(int value)
        {
            string ret = string.Empty;
            switch (value)
            {
                case (int)TimeOfRuleLeave.None:
                    ret = " ";
                    break;
                case (int)TimeOfRuleLeave.TruLuong:
                    ret = "Trừ lương";
                    break;
                //case (int)TimeOfRuleLeave.LamBu:
                //    ret = "Làm bù";
                //    break;
                //case (int)TimeOfRuleLeave.NghiBu:
                //    ret = "Nghỉ bù";
                //    break;
                case (int)TimeOfRuleLeave.TruPhep:
                    ret = "Trừ phép";
                    break;
            }
            return ret;
        }

        /// <summary>
        /// GetTimeOfRuleTimeName
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string GetTimeOfRuleTimeName(int value)
        {
            string ret = string.Empty;
            switch (value)
            {
                case (int)TimeOfRuleTimeAttendance.None:
                    ret = " ";
                    break;
                case (int)TimeOfRuleTimeAttendance.TruLuong:
                    ret = "Trừ lương";
                    break;
                case (int)TimeOfRuleTimeAttendance.LamBu:
                    ret = "Làm bù";
                    break;
                case (int)TimeOfRuleTimeAttendance.NghiBu:
                    ret = "Nghỉ bù";
                    break;
                case (int)TimeOfRuleTimeAttendance.CongLuong:
                    ret = "Cộng lương";
                    break;
            }
            return ret;
        }

        #endregion

    }
}
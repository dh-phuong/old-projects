﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using System.Collections;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;

namespace DailyReport.Master
{
    public partial class FrmHolidayList : FrmBaseList
    {

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Holiday);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmWorksMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        protected void btnNew_Click(object sender, CommandEventArgs e)
        {

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //HolidayID
            this.ViewState["HolidayID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        #endregion

        #region Method

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            //this.txtName.Value = data[this.txtName.ID].ToString();

            if (data[this.txtDateFrom.ID] == null)
            {
                this.txtDateFrom.Value = null;
            }
            else
            {
                this.txtDateFrom.Value = DateTime.Parse(data[this.txtDateFrom.ID].ToString());
            }

            if (data[this.txtDateTo.ID] == null)
            {
                this.txtDateTo.Value = null;
            }
            else
            {
                this.txtDateTo.Value = DateTime.Parse(data[this.txtDateTo.ID].ToString());
            }

            this.txtName.Value = data[this.txtName.ID].ToString();
            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtDateFrom.ID, this.txtDateFrom.Value);
            hash.Add(this.txtDateTo.ID, this.txtDateTo.Value);
            hash.Add(this.txtName.ID, this.txtName.Value);
            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        private bool CheckInput()
        {
            if (this.txtDateFrom.Value.HasValue && this.txtDateTo.Value.HasValue && this.txtDateTo.Value.Value < this.txtDateFrom.Value.Value)
            {
                this.SetMessage(this.txtDateTo.ID, M_Message.MSG_LESS_THAN_EQUAL, "Date From ", "Date To");
            }

            //Has errors
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptHolidayList.DataSource = null;
                this.rptHolidayList.DataBind();
                return false;
            }

            return true;
        }


        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            // Default data valide

            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
        }


        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            if (!this.CheckInput())
            {
                return;
            }

            int totalRow = 0;

            IList<HolidayInfo> listHolidayInfo;

            //Get data
            using (DB db = new DB())
            {
                HolidayService holidayService = new HolidayService(db);
                totalRow = holidayService.getTotalRow(txtDateFrom.Value, txtDateTo.Value, txtName.Value);
                listHolidayInfo = holidayService.GetListByCond(txtDateFrom.Value, txtDateTo.Value, txtName.Value,
                                                     pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            }

            //Show data
            if (listHolidayInfo.Count == 0)
            {
                this.rptHolidayList.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(listHolidayInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listHolidayInfo[listHolidayInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Date", "Name (VN)", "Name (EN)" });

                // detail
                this.rptHolidayList.DataSource = listHolidayInfo;
            }

            this.rptHolidayList.DataBind();
        }

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Holiday Master";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;


            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
        }

        #endregion

    }
}
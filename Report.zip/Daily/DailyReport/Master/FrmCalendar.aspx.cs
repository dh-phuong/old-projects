﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.Master
{    
    public partial class FrmCalendar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack){
                this.txtDate.Value = DateTime.Now;
            }
        }

        [System.Web.Services.WebMethod]
        public static DayInfo GetHoliday(DateTime date)
        {
            try
            {
                HolidayService holidaySer = new HolidayService();
                DayInfo holiday = holidaySer.GetDayInfo(date);
                if (holiday == null)
                {
                    return null;
                }
                return holiday;
            }
            catch (Exception)
            {
                return null;
            }
        }

        [System.Web.Services.WebMethod]
        public static Array GetInfo(DateTime start)
        {
            try
            {
                List<CalendarInfo> items = null;
                using (DB db = new DB())
                {
                    DailyService grpSer = new DailyService(db);
                    //items = grpSer.GetByCalendar(start.Month).ToList();
                }

                ArrayList eventList = new ArrayList();
                foreach (var item in items)
                {
                    CalendarItem calI = new CalendarItem();
                    calI.title = item.UserName2 + " " + item.TypeName;
                    calI.startDate = item.WorkDate.ToString("yyyy-MM-dd");
                    calI.user = item.UserName1;
                    calI.detail = string.Format("{0:00}", item.StartHour) + ":" + string.Format("{0:00}", item.StartMinute) + " ～ " + string.Format("{0:00}", item.EndHour) + ":" + string.Format("{0:00}", item.EndMinute);
                    calI.detailContent = item.Content;
                    eventList.Add(calI);
                }

                return eventList.ToArray();
            }
            catch (Exception)
            {
                return null;
            }
        }


    }
}
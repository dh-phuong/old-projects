﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// Staff Detail
    /// ISV-NHAT
    /// </summary>
    public partial class FrmStaffDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmStaffList.aspx";
        private const string CONST_IMAGES_PATH = "~/Logo/";
        private const string CONST_STAFF_IMAGES_PATH = "~/StaffImage/";
        private const string CONST_NO_IMAGE_AVAILABLE = "no-image.png";
        #endregion

        #region Variable

        private enum ActionMode
        {
            /// <summary>
            /// None
            /// </summary>
            None = 0,

            /// <summary>
            /// DeleteRow_Salary
            /// </summary>
            DeleteRow_Salary = 3,

            /// <summary>
            /// DeleteRow_Dependent
            /// </summary>
            DeleteRow_Dependent = 4,

            /// <summary>
            /// DeleteRow_Contract
            /// </summary>
            DeleteRow_Contract = 5
        }
        #endregion

        #region Property

        /// <summary>
        /// Focus control id
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }

        private ActionMode Action
        {
            get { return base.GetValueViewState<ActionMode>("ActionMode"); }
            set { this.ViewState["ActionMode"] = value; }
        }

        /// <summary>
        /// Get or set StaffID
        /// </summary>
        public int StaffID
        {
            get { return (int)ViewState["StaffID"]; }
            set { ViewState["StaffID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// File count
        /// </summary>
        public int FileCount
        {
            get { return base.GetValueViewState<int>("FileCount"); }
            private set { this.ViewState["FileCount"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Staff Information";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtStaffcode.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtStaffname.MaxLength = M_Staff.STAFF_NAME_MAX_LENGTH;
            this.txtEmail.MaxLength = M_Staff.EMAIL_MAX_LENGTH;
            this.txtIDNo.MaxLength = M_Staff.ID_NO_MAX_LENGTH;
            this.txtTel.MaxLength = M_Staff.TELL_MAX_LENGTH;
            this.txtTel2.MaxLength = M_Staff.TELL_MAX_LENGTH;
            this.txtAddress1.MaxLength = M_Staff.ADDRESS_MAX_LENGTH;
            this.txtAddress2.MaxLength = M_Staff.ADDRESS_MAX_LENGTH;
            this.txtAccountNo.MaxLength = M_Staff.ACCOUNT_NO_MAX_LENGTH;
            this.txtBankName.MaxLength = M_Staff.BANK_NAME_MAX_LENGTH;
            this.txtSocialInsur.MaxLength = M_Staff.SOCIALINSUR_NO_MAX_LENGTH;
            this.txtTaxNo.MaxLength = M_Staff.TAX_NO_MAX_LENGTH;

            //Dropdownlist select index change event            
            this.ddlProvince.SelectedIndexChanged += ddlProvince_SelectedIndexChanged;
            this.ddlDistrict.SelectedIndexChanged += ddlDistrict_SelectedIndexChanged;
            this.ddlProvince2.SelectedIndexChanged += ddlProvince2_SelectedIndexChanged;
            this.ddlDistrict2.SelectedIndexChanged += ddlDistrict2_SelectedIndexChanged;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        //DropDownList Province - Event DropDownlist Selected Index Changed
        protected void ddlProvince_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = int.Parse(ddlProvince.SelectedValue.ToString());

            if (index != -1)
            {
                using (DB db = new DB())
                {
                    this.InitDropDownDistrict(db, index);
                    this.InitDropDownWard(db, -1);
                }
                
            }
            else
            {
                using (DB db = new DB())
                {
                    this.InitDropDownDistrict(db, -1);
                    this.InitDropDownWard(db, -1);
                }                
            }

            this.FocusControlId = "ddlDistrict";
        }

        //DropDownList District - Event DropDownlist Selected Index Changed
        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = int.Parse(ddlDistrict.SelectedValue.ToString());

            if (index != -1)
            {
                using (DB db = new DB())
                {
                    this.InitDropDownWard(db, index);
                }                
            }
            else
            {
                using (DB db = new DB())
                {
                    this.InitDropDownWard(db, -1);
                }                
            }

            this.FocusControlId = "ddlWard1";
        }

        //DropDownList Province2 - Event DropDownlist Selected Index Changed
        protected void ddlProvince2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = int.Parse(ddlProvince2.SelectedValue.ToString());

            if (index != -1)
            {
                using (DB db = new DB())
                {
                    this.InitDropDownDistrict2(db, index);
                    this.InitDropDownWard2(db, -1);
                }                
            }
            else
            {
                using (DB db = new DB())
                {
                    this.InitDropDownDistrict2(db, -1);
                    this.InitDropDownWard2(db, -1);
                }                
            }

            this.FocusControlId = "ddlDistrict2";
        }

        //DropDownList District2 - Event DropDownlist Selected Index Changed
        protected void ddlDistrict2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = int.Parse(ddlDistrict2.SelectedValue.ToString());

            if (index != -1)
            {
                using (DB db = new DB())
                {
                    this.InitDropDownWard2(db, index);
                }                
            }
            else
            {
                using (DB db = new DB())
                {
                    this.InitDropDownWard2(db, -1);
                }                
            }

            this.FocusControlId = "ddlWard2";
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Staff);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                this.InitRepeaterData();
                this.InitDDL();
                this.imgLogo1.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
                this.imgLogo1.Attributes.Add("style", "width:115px;height:115px");
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.hidMode.Value = ((int)Mode.Insert).ToString();
                        this.StaffID = 0;
                        //this.Mode = Mode.Insert;
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get Staff ID
                        this.StaffID = int.Parse(PreviousPageViewState["ID"].ToString());

                        M_Staff staff;
                        using(DB db=new DB())
                        {
                            staff = this.GetStaff(this.StaffID, db);
                        }                        

                        //Check staff
                        if (staff != null)
                        {
                            //Set Mode
                            this.hidMode.Value = ((int)Mode.View).ToString();

                            using (DB db = new DB())
                            {
                                //Count File
                                AttachedService attachedService = new AttachedService(db);
                                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeDB(staff.StaffCD, M_Staff.STAFF_CODE_MAX_LENGTH));
                            }

                            //Show data
                            this.ShowData(staff);
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.StaffID = 0;
                    this.hidMode.Value = ((int)Mode.Insert).ToString();
                    this.ProcessMode(Mode.Insert);
                }
            }
            else
            {
                //Set Image
                this.SaveTempImage(this.fileLogo1, this.hidImg.Value, this.imgLogo1);
                this.ShowImage(this.hidImg.Value, this.imgLogo1);
            }
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get User
            M_Staff staff;
            using (DB db = new DB())
            {
                staff = this.GetStaff(this.StaffID, db);
            }            

            //Check user
            if (staff != null)
            {
                this.hidMode.Value = ((int)Mode.Copy).ToString();
                //Show data
                this.ShowData(staff);
                //Clear loginID and password
                this.FileCount = 0;
                this.txtStaffcode.Value = string.Empty;
                this.imgLogo1.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
                this.imgLogo1.Alt = string.Empty;
                this.imgLogo1.Attributes.Add("style", "width:115px;height:115px");
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get User
            M_Staff staff;
            using (DB db = new DB())
            {
                staff = this.GetStaff(this.StaffID, db);
            }

            //Check user
            if (staff != null)
            {
                this.hidMode.Value = ((int)Mode.Update).ToString();
                //Show data
                this.ShowData(staff);
                this.hidImg.Value = staff.Image;
                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(this.txtStaffcode.Value);
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }

                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.txtStaffcode.Value = string.Empty;
            this.ddlTypeofStaff.SelectedValue = "-1";
            this.txtAnnualDays.Value = null;
            this.txtStaffname.Value = string.Empty;
            this.ddlDepartment.SelectedValue = "-1";
            this.txtEmail.Value = string.Empty;
            this.ddlPosition2.SelectedValue = "-1";
            this.ddlSex.SelectedValue = "-1";
            this.txtBirthDay.Value = null;
            this.ddlBirthPlace.SelectedValue = "-1";
            this.txtIDNo.Value = string.Empty;
            this.txtIssueDate.Value = null;
            this.ddlIssuePlace.SelectedValue = "-1";
            this.txtTel.Value = string.Empty;
            this.txtAddress1.Value = string.Empty;
            this.ddlProvince.SelectedValue = "-1";

            using (DB db = new DB())
            {
                this.InitDropDownDistrict(db, -1);
                this.InitDropDownWard(db, -1);
                this.InitDropDownDistrict2(db, -1);
                this.InitDropDownWard2(db, -1);
            }            

            this.txtAddress2.Value = string.Empty;
            this.ddlProvince2.SelectedValue = "-1";
            
            this.txtAccountNo.Value = string.Empty;
            this.txtBankName.Value = string.Empty;
            this.txtStartWordDate.Value = null;
            this.txtEndWordDate.Value = null;
            this.txtSocialInsur.Value = string.Empty;
            this.txtTaxNo.Value = string.Empty;
            this.imgLogo1.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
            this.imgLogo1.Alt = string.Empty;
            this.imgLogo1.Attributes.Add("style", "width:115px;height:115px");
            this.chkStatusFlag.Checked = true;
            this.FileCount = 0;
            this.InitRepeaterData();

            //Set mode
            this.hidMode.Value = ((int)Mode.Insert).ToString();
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            string tmpDirectory = CONST_STAFF_IMAGES_PATH + "/" + this.hidImg.Value;

            if (File.Exists(MapPath(tmpDirectory)))
            {
                File.Delete(MapPath(tmpDirectory));
            }

            //Get User
            M_Staff staff;
            using (DB db = new DB())
            {
                staff = this.GetStaff(this.StaffID, db);
            }            

            //Check user
            if (staff != null)
            {
                this.hidMode.Value = ((int)Mode.View).ToString();

                //Show data
                this.ShowData(staff);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            #region CheckAction

            switch (this.Action)
            {

                case ActionMode.None:

                    IList<StaffSalaryInfo> detailSalary = null;
                    IList<StaffDependentInfo> detailDependent = null;
                    IList<StaffContractInfo> detailContract = null;
                    break;

                #region DeleteRow
                case ActionMode.DeleteRow_Salary:
                    this.Action = ActionMode.None;

                    //Get Data
                    detailSalary = this.GetDetailSalaryData(false);
                    if (detailSalary.Count == 0)
                    {
                        this.AddEmptyRow_Salary(1, ref detailSalary);
                    }
                    this.RefreshDetails_Salary(detailSalary);
                    return;

                case ActionMode.DeleteRow_Dependent:
                    this.Action = ActionMode.None;

                    //Get Data
                    detailDependent = this.GetDetailDependentData(false);
                    if (detailDependent.Count == 0)
                    {
                        this.AddEmptyRow_Dependent(1, ref detailDependent);
                    }
                    this.RefreshDetails_Dependent(detailDependent);
                    return;
                case ActionMode.DeleteRow_Contract:
                    this.Action = ActionMode.None;

                    //Get Data
                    detailContract = this.GetDetailContractData(false);
                    if (detailContract.Count == 0)
                    {
                        this.AddEmptyRow_Contract(1, ref detailContract);
                    }
                    this.RefreshDetails_Contract(detailContract);
                    return;
                #endregion
            }

            #endregion

            #region Check Mode

            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        M_Staff staff;
                        using (DB db = new DB())
                        {
                            staff = this.GetStaff(this.txtStaffcode.Value, db);
                        }                        
                        this.hidMode.Value = ((int)Mode.View).ToString();
                        //this.Mode = Mode.View;
                        //Show data
                        this.ShowData(staff);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_Staff staff;
                        using (DB db = new DB())
                        {
                            staff = this.GetStaff(this.StaffID, db);
                        }                        
                        this.hidMode.Value = ((int)Mode.View).ToString();
                        //this.Mode = Mode.View;
                        //Show data
                        this.ShowData(staff);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        //Set Success
                        this.Success = true;
                    }

                    break;

            }

            #endregion
        }

        // <summary>
        // Create Contract Detail
        // </summary>
        // <param name="contractList"></param>
        // <param name="staffID"></param>
        private void CreateContractDetail(ref IList<M_Staff_Contract> contractList, int staffID)
        {
            if (contractList == null)
            {
                contractList = new List<M_Staff_Contract>();
            }

            #region Create Detail
            foreach (RepeaterItem repeaterItem in this.rptContract.Items)
            {
                ITextBox txtContractNo = (ITextBox)repeaterItem.FindControl("txtContractNo");
                DropDownList ddlTypeofContract = (DropDownList)repeaterItem.FindControl("ddlTypeofContract");
                IDateTextBox txtStartDate = (IDateTextBox)repeaterItem.FindControl("txtStartDate");

                if (txtContractNo.Value == string.Empty && ddlTypeofContract.SelectedValue == "-1")
                {
                    if (txtStartDate.Value == null)
                    {
                        continue;
                    }
                }

                M_Staff_Contract contract = new M_Staff_Contract();

                contract.StaffID = staffID;
                contract.ContractNo = txtContractNo.Value;
                contract.ContractType = short.Parse(ddlTypeofContract.SelectedValue.ToString());
                contract.StartDate = (DateTime)txtStartDate.Value;
                contractList.Add(contract);
            }
            #endregion
        }

        // <summary>
        // Create Dependent Detail
        // </summary>
        // <param name="dependentList"></param>
        // <param name="userID"></param>
        private void CreateDependentDetail(ref IList<M_Staff_Dependent> dependentList, int staffID)
        {
            if (dependentList == null)
            {
                dependentList = new List<M_Staff_Dependent>();
            }

            #region Create Detail
            foreach (RepeaterItem repeaterItem in this.rptDependent.Items)
            {
                INumberTextBox txtDependent = (INumberTextBox)repeaterItem.FindControl("txtDependent");
                IDateTextBox txtRegistDate = (IDateTextBox)repeaterItem.FindControl("txtRegistDate");
                INumberTextBox txtTotal = (INumberTextBox)repeaterItem.FindControl("txtTotal");

                if (txtDependent.Value == null && txtRegistDate.Value == null)
                {
                    continue;
                }

                M_Staff_Dependent dependent = new M_Staff_Dependent();

                dependent.StaffID = staffID;
                dependent.RegistDate = (DateTime)txtRegistDate.Value;
                dependent.Dependent = (int)txtDependent.Value;
                dependent.Total = (int)txtTotal.Value;
                dependentList.Add(dependent);
            }
            #endregion
        }

        // <summary>
        // Create Salary Detail
        // </summary>
        // <param name="salaryData"></param>
        // <param name="allowanceData"></param>
        // <param name="userID"></param>
        private void CreateSalaryDetail(ref Hashtable salaryData, ref Hashtable allowanceData, int userID)
        {
            #region Create Detail

            int i = 0;
            foreach (RepeaterItem repeaterItem in this.rptSalary.Items)
            {
                HiddenField hidData = (HiddenField)repeaterItem.FindControl("hidData");
                INumberTextBox txtBasicSalary = (INumberTextBox)repeaterItem.FindControl("txtBasicSalary");
                INumberTextBox txtAllowance = (INumberTextBox)repeaterItem.FindControl("txtAllowance");
                IDateTextBox txtStartDate = (IDateTextBox)repeaterItem.FindControl("txtStartDate1");
                M_Staff_Salary salary = new M_Staff_Salary();

                if (txtBasicSalary.Value == null && txtAllowance.Value == null)
                {
                    if (txtStartDate.Value == null)
                    {
                        continue;
                    }
                }

                salary.ID = i;
                salary.UserID = userID;
                salary.BasicSalary = (decimal)txtBasicSalary.Value;
                salary.Allowance = (decimal)txtAllowance.Value;
                salary.StartDate = (DateTime)txtStartDate.Value;

                if (hidData.Value != string.Empty)
                {
                    List<M_Staff_Allowance> allowanceDataTemp = new List<M_Staff_Allowance>();
                    allowanceDataTemp = CreateAllowanceDetail(hidData.Value);
                    allowanceData.Add(i, allowanceDataTemp);
                }

                salaryData.Add(i, salary);
                i++;
            }
            #endregion
        }

        // <summary>
        // Create Salary Detail
        // </summary>
        // <param name="data"></param>
        private List<M_Staff_Allowance> CreateAllowanceDetail(string data)
        {
            List<M_Staff_Allowance> allowanceList = new List<M_Staff_Allowance>();
            string[] dataAllowance = new string[data.Split('_').Length];
            dataAllowance = data.Split('_');
            
            #region Create Detail

            for (int i = 0; i < dataAllowance.Length - 1; i += 4)
            {
                M_Staff_Allowance allowance = new M_Staff_Allowance();

                if (dataAllowance[i + 1] == "-1" && dataAllowance[i + 2] == "")
                {
                    continue;
                }
                allowance.No = int.Parse(dataAllowance[i]);
                allowance.AllowanceName = int.Parse(dataAllowance[i + 1]);
                allowance.Allowance = decimal.Parse(dataAllowance[i + 2]);

                if (dataAllowance[i + 3] == "true")
                {
                    allowance.AccountingFlag = 1;
                }
                else
                {
                    allowance.AccountingFlag = 0;
                }

                allowanceList.Add(allowance);
            }

            return allowanceList;

            #endregion
        }

        /// <summary>
        /// Event Add Row Salary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRowSalary_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                IList<StaffSalaryInfo> list = this.GetDetailSalaryData();
                StaffSalaryInfo salary = new StaffSalaryInfo();

                salary.salaryNo = list.Count + 1;
                list.Add(salary);

                this.rptSalary.DataSource = list;
                this.rptSalary.DataBind();

                this.FocusControlId = string.Format("txtBasicSalary_{0}", salary.salaryNo - 1);
            }
        }

        /// <summary>
        /// Event Delete Row Salary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRowSalary_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);

                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                this.Action = ActionMode.DeleteRow_Salary;
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
            }
        }

        // <summary>
        // Add Empty Salary Row
        // </summary>
        // <param name="size"></param>
        // <param name="dataSource"></param>
        private void AddEmptyRow_Salary(int size, ref IList<StaffSalaryInfo> dataSource)
        {
            //SalaryInfo
            if (dataSource == null)
            {
                dataSource = new List<StaffSalaryInfo>();
            }

            for (int i = 0; i < size; i++)
            {
                StaffSalaryInfo salary = new StaffSalaryInfo();
                dataSource.Add(salary);
            }
        }

        // <summary>
        // Add Empty Dependent Row
        // </summary>
        // <param name="size"></param>
        // <param name="dataSource"></param>
        private void AddEmptyRow_Dependent(int size, ref IList<StaffDependentInfo> dataSource)
        {
            //DependentInfo
            if (dataSource == null)
            {
                dataSource = new List<StaffDependentInfo>();
            }

            for (int i = 0; i < size; i++)
            {
                StaffDependentInfo dependent = new StaffDependentInfo();

                dataSource.Add(dependent);

            }
        }

        // <summary>
        // Add Empty Contract Row
        // </summary>
        // <param name="size"></param>
        // <param name="dataSource"></param>
        private void AddEmptyRow_Contract(int size, ref IList<StaffContractInfo> dataSource)
        {
            //DependentInfo
            if (dataSource == null)
            {
                dataSource = new List<StaffContractInfo>();
            }

            for (int i = 0; i < size; i++)
            {
                StaffContractInfo contract = new StaffContractInfo();

                dataSource.Add(contract);

            }
        }

        /// <summary>
        /// Event Add Dependent Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRowDependent_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                IList<StaffDependentInfo> list = this.GetDetailDependentData();
                StaffDependentInfo dependent = new StaffDependentInfo();

                dependent.No = list.Count + 1;
                list.Add(dependent);

                this.rptDependent.DataSource = list;
                this.rptDependent.DataBind();

                this.FocusControlId = string.Format("txtDependent_{0}", dependent.No - 1);
            }
        }

        /// <summary>
        /// Event Delete Dependent Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRowDependent_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
                this.Action = ActionMode.DeleteRow_Dependent;
            }
        }

        /// <summary>
        /// Event Add Contract Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddRowContract_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                IList<StaffContractInfo> list = this.GetDetailContractData();
                StaffContractInfo contract = new StaffContractInfo();

                contract.No = list.Count + 1;
                list.Add(contract);

                this.rptContract.DataSource = list;
                this.rptContract.DataBind();

                this.FocusControlId = string.Format("txtContractNo_{0}", contract.No - 1);
            }
        }

        /// <summary>
        /// Event Delete Contract Row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDeleteRowContract_Click(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                AttachedService attachedService = new AttachedService(db);
                this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
                this.Action = ActionMode.DeleteRow_Contract;
            }
        }

        /// <summary>
        /// Event Contract ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptContract_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                StaffContractInfo dataItem = (StaffContractInfo)e.Item.DataItem;
                DropDownList ddlTypeofContract = (DropDownList)e.Item.FindControl("ddlTypeofContract");

                using (DB db = new DB())
                {
                    this.InitCombobox(db, ddlTypeofContract, M_Config_H.CONFIG_CD_CONTRACT_TYPE, true);
                }
                
                ddlTypeofContract.SelectedValue = dataItem.ContractType.ToString();
            }
        }

        /// <summary>
        /// Event Salary ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptSalary_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                HiddenField hidID = (HiddenField)e.Item.FindControl("hidID");
                HiddenField hidData = (HiddenField)e.Item.FindControl("hidData");
                INumberTextBox txtAllowance = (INumberTextBox)e.Item.FindControl("txtAllowance");
                txtAllowance.SetReadOnly(true);
                HtmlButton btnAllowance = (HtmlButton)e.Item.FindControl("btnAllowance");
                int allowanceID = -1;

                if (hidID.Value.Trim() != string.Empty)
                {
                    allowanceID = int.Parse(hidID.Value);
                }

                string onclick = "callAllowance('" + allowanceID + "','" + txtAllowance.ClientID
                                                    + "','" + hidData.ClientID + "')";
                btnAllowance.Attributes.Add("onclick", onclick);
            }
        }

        /// <summary>
        /// Event Dependent ItemDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptDependent_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                INumberTextBox txtDependent = (INumberTextBox)e.Item.FindControl("txtDependent");
                INumberTextBox txtTotal = (INumberTextBox)e.Item.FindControl("txtTotal");

                txtTotal.SetReadOnly(true);
                txtDependent.Attributes.Add("onvaluechange", "calcTotal()");
            }
        }

        #endregion

        #region Methods

        /// <summary>
        /// Get Detail Contract Row
        /// </summary>
        /// <param name="rptI"></param>
        /// <returns></returns>
        private StaffContractInfo GetDetailContractRow(RepeaterItem rptI)
        {
            HiddenField hidType = (HiddenField)rptI.FindControl("hidType");

            StaffContractInfo detail = new StaffContractInfo();

            //Check
            CheckBox chkContractDel = (CheckBox)rptI.FindControl("chkContract");
            detail.Checked = chkContractDel.Checked;

            //ContractNo
            ITextBox txtContractNo = (ITextBox)rptI.FindControl("txtContractNo");
            detail.ContractNo = txtContractNo.Value;

            //ContractType
            DropDownList ddlTypeofContract = (DropDownList)rptI.FindControl("ddlTypeofContract");
            detail.ContractType = int.Parse(ddlTypeofContract.SelectedValue);

            //StartDate
            IDateTextBox txtStartDate = (IDateTextBox)rptI.FindControl("txtStartDate");
            detail.StartDate = txtStartDate.Value;

            return detail;
        }

        /// <summary>
        /// Get Detail Contract Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        private IList<StaffContractInfo> GetDetailContractData(bool includeDelete = true)
        {
            IList<StaffContractInfo> ret = new List<StaffContractInfo>();
            var sellNo = 1;
            foreach (RepeaterItem item in this.rptContract.Items)
            {
                CheckBox chkContractDel = (CheckBox)item.FindControl("chkContract");
                var deleted = chkContractDel.Checked;

                if (!includeDelete && deleted)
                {
                    continue;
                }

                StaffContractInfo detail = this.GetDetailContractRow(item);

                detail.No = sellNo;
                ret.Add(detail);
                sellNo++;
            }

            return ret;
        }

        /// <summary>
        /// Get Detail Salary Row
        /// </summary>
        /// <param name="rptI"></param>
        /// <returns></returns>
        private StaffSalaryInfo GetDetailSalaryRow(RepeaterItem rptI)
        {
            HiddenField hidType = (HiddenField)rptI.FindControl("hidType");

            StaffSalaryInfo detail = new StaffSalaryInfo();

            //hidID
            HiddenField hidID = (HiddenField)rptI.FindControl("hidID");
            detail.ID = int.Parse(hidID.Value);

            HiddenField hidData = (HiddenField)rptI.FindControl("hidData");
            detail.data = hidData.Value;

            //Check
            CheckBox chkSalaryDel = (CheckBox)rptI.FindControl("chkSalaryDel");
            detail.Checked = chkSalaryDel.Checked;

            //BasicSalary
            INumberTextBox txtBasicSalary = (INumberTextBox)rptI.FindControl("txtBasicSalary");
            detail.BasicSalary = txtBasicSalary.Value;

            //Allowance
            INumberTextBox txtAllowance = (INumberTextBox)rptI.FindControl("txtAllowance");
            detail.Allowance = txtAllowance.Value;

            //StartDate
            IDateTextBox txtStartDate = (IDateTextBox)rptI.FindControl("txtStartDate1");
            detail.StartDate = txtStartDate.Value;

            return detail;
        }

        /// <summary>
        /// Get Detail Salary Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        private IList<StaffSalaryInfo> GetDetailSalaryData(bool includeDelete = true)
        {
            IList<StaffSalaryInfo> ret = new List<StaffSalaryInfo>();
            int salaryNo = 1;
            foreach (RepeaterItem item in this.rptSalary.Items)
            {
                CheckBox chkSalaryDel = (CheckBox)item.FindControl("chkSalaryDel");
                var deleted = chkSalaryDel.Checked;

                if (!includeDelete && deleted)
                {
                    continue;
                }

                StaffSalaryInfo detail = this.GetDetailSalaryRow(item);
                detail.salaryNo = salaryNo;

                salaryNo++;
                ret.Add(detail);
            }

            return ret;
        }

        /// <summary>
        /// Get Detail Row Dependent Row
        /// </summary>
        /// <param name="rptI"></param>
        /// <returns></returns>
        private StaffDependentInfo GetDetailDependentRow(RepeaterItem rptI)
        {
            HiddenField hidType = (HiddenField)rptI.FindControl("hidType");

            StaffDependentInfo detail = new StaffDependentInfo();

            //Check
            CheckBox chkDependentDel = (CheckBox)rptI.FindControl("chkDependentDel");
            detail.Checked = chkDependentDel.Checked;

            //Dependent
            INumberTextBox txtDependent = (INumberTextBox)rptI.FindControl("txtDependent");
            if (txtDependent.IsEmpty)
            {
                detail.Dependent = null;
            }
            else
            {
                detail.Dependent = (int)txtDependent.Value;
            }

            //StartDate
            IDateTextBox txtRegistDate = (IDateTextBox)rptI.FindControl("txtRegistDate");
            detail.RegistDate = txtRegistDate.Value;

            //Total
            INumberTextBox txtTotal = (INumberTextBox)rptI.FindControl("txtTotal");
            if (txtTotal.IsEmpty)
            {
                detail.Total = null;
            }
            else
            {
                detail.Total = (int)txtTotal.Value;
            }

            return detail;
        }

        /// <summary>
        /// Get Detail Dependent Data
        /// </summary>
        /// <param name="includeDelete">Include Delete</param>
        private IList<StaffDependentInfo> GetDetailDependentData(bool includeDelete = true)
        {
            IList<StaffDependentInfo> ret = new List<StaffDependentInfo>();
            var depNo = 1;
            foreach (RepeaterItem item in this.rptDependent.Items)
            {
                CheckBox chkDependentDel = (CheckBox)item.FindControl("chkDependentDel");
                var deleted = chkDependentDel.Checked;

                if (!includeDelete && deleted)
                {
                    continue;
                }

                StaffDependentInfo detail = this.GetDetailDependentRow(item);
                detail.No = depNo;

                ret.Add(detail);
                depNo++;
            }

            return ret;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitRepeaterData()
        {
            IList<StaffSalaryInfo> listSa = new List<StaffSalaryInfo>();
            IList<StaffDependentInfo> listDe = new List<StaffDependentInfo>();
            IList<StaffContractInfo> listCon = new List<StaffContractInfo>();

            this.AddEmptyRow_Salary(1, ref listSa);
            this.AddEmptyRow_Dependent(1, ref listDe);
            this.AddEmptyRow_Contract(1, ref listCon);

            this.rptContract.DataSource = listCon;
            this.rptContract.DataBind();

            this.rptSalary.DataSource = listSa;
            this.rptSalary.DataBind();

            this.rptDependent.DataSource = listDe;
            this.rptDependent.DataBind();
        }

        /// <summary>
        /// Init DropDownList Department
        /// </summary>
        private void InitDropDownListDepartment(DB db)
        {
            DepartmentService deptSer = new DepartmentService(db);
            IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(true);
            this.ddlDepartment.DataSource = lstDB;

            this.ddlDepartment.DataValueField = "Value";
            this.ddlDepartment.DataTextField = "DisplayName";
            this.ddlDepartment.DataBind();
        }

        /// <summary>
        /// Init DropDownList Province
        /// </summary>
        private void InitDropDownProvince_BirthPlace_IssuePlace(DB db)
        {

            ProvinceService proSer = new ProvinceService(db);
            IList<DropDownModel> lstPro = proSer.GetDataForDropDownList(true);
            this.ddlProvince.DataSource = lstPro;
            this.ddlProvince2.DataSource = lstPro;
            this.ddlBirthPlace.DataSource = lstPro;
            this.ddlIssuePlace.DataSource = lstPro;


            this.ddlProvince.DataTextField = "DisplayName";
            this.ddlProvince.DataValueField = "Value";
            this.ddlProvince.DataBind();

            this.ddlProvince2.DataTextField = "DisplayName";
            this.ddlProvince2.DataValueField = "Value";
            this.ddlProvince2.DataBind();

            this.ddlBirthPlace.DataTextField = "DisplayName";
            this.ddlBirthPlace.DataValueField = "Value";
            this.ddlBirthPlace.DataBind();

            this.ddlIssuePlace.DataTextField = "DisplayName";
            this.ddlIssuePlace.DataValueField = "Value";
            this.ddlIssuePlace.DataBind();
        }

        /// <summary>
        /// Init DropDownList District
        /// </summary>
        private void InitDropDownDistrict(DB db, int index)
        {
            DistrictService disSer = new DistrictService(db);
            IList<DropDownModel> lstDis = disSer.GetDataForDropDownList(index, true);
            this.ddlDistrict.DataSource = lstDis;

            this.ddlDistrict.DataTextField = "DisplayName";
            this.ddlDistrict.DataValueField = "Value";
            this.ddlDistrict.DataBind();
        }

        /// <summary>
        /// Init DropDownList District2
        /// </summary>
        private void InitDropDownDistrict2(DB db, int index)
        {
   
            DistrictService disSer = new DistrictService(db);
            IList<DropDownModel> lstDis = disSer.GetDataForDropDownList(index, true);
            this.ddlDistrict2.DataSource = lstDis;
   
            this.ddlDistrict2.DataTextField = "DisplayName";
            this.ddlDistrict2.DataValueField = "Value";
            this.ddlDistrict2.DataBind();
        }

        /// <summary>
        /// Init DropDownList Ward
        /// </summary>
        private void InitDropDownWard(DB db, int index)
        {

            WardService wardSer = new WardService(db);
            IList<DropDownModel> lstWard = wardSer.GetDataForDropDownList(index, true);
            this.ddlWard1.DataSource = lstWard;

            this.ddlWard1.DataTextField = "DisplayName";
            this.ddlWard1.DataValueField = "Value";
            this.ddlWard1.DataBind();
        }

        /// <summary>
        /// Init DropDownList Ward2
        /// </summary>
        private void InitDropDownWard2(DB db, int index)
        {

            WardService wardSer = new WardService(db);
            IList<DropDownModel> lstWard = wardSer.GetDataForDropDownList(index, true);
            this.ddlWard2.DataSource = lstWard;

            this.ddlWard2.DataTextField = "DisplayName";
            this.ddlWard2.DataValueField = "Value";
            this.ddlWard2.DataBind();
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(DB db, string configCD, bool withBlank = false)
        {

            Config_HService configSer = new Config_HService(db);
            return configSer.GetDataForDropDownList(configCD, withBlank);

        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DB db, DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(db, configCD, withBlank);
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init All DropDownList
        /// </summary>
        private void InitDDL()
        {
            using (DB db = new DB())
            {
                this.InitDropDownListDepartment(db);
                this.InitDropDownProvince_BirthPlace_IssuePlace(db);
                this.InitDropDownDistrict(db, -1);
                this.InitDropDownWard(db, -1);
                this.InitDropDownDistrict2(db, -1);
                this.InitDropDownWard2(db, -1);
                
                this.InitCombobox(db, this.ddlTypeofStaff, M_Config_H.CONFIG_CD_TYPE_OF_STAFF, true);
                this.InitCombobox(db, this.ddlSex, M_Config_H.CONFIG_CD_TYPE_OF_SEX, true);
                this.InitCombobox(db, this.ddlPosition2, M_Config_H.CONFIG_CD_POSITION, true);
            }            

            
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;
            this.Action = ActionMode.None;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtStaffcode.ReadOnly = true;
                        this.chkStatusFlag.Disabled = false;
                    }
                    else
                    {
                        this.txtStaffcode.ReadOnly = false;
                        this.chkStatusFlag.Disabled = true;
                        this.chkStatusFlag.Checked = true;
                    }

                    enable = false;

                    break;

                default:
                    this.txtStaffcode.ReadOnly = true;
                    this.chkStatusFlag.Disabled = true;
                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    enable = true;
                    break;
            }

            //Lock control
            this.ddlTypeofStaff.Enabled = !enable;
            this.txtAnnualDays.ReadOnly = enable;
            this.txtStaffname.ReadOnly = enable;     //
            this.ddlDepartment.Enabled = !enable;     //
            this.ddlPosition2.Enabled = !enable;
            this.ddlSex.Enabled = !enable;
            this.txtBirthDay.ReadOnly = enable;
            this.ddlBirthPlace.Enabled = !enable;
            this.txtIDNo.ReadOnly = enable;
            this.txtIssueDate.ReadOnly = enable;
            this.ddlIssuePlace.Enabled = !enable;
            this.txtTel.ReadOnly = enable;
            this.txtTel2.ReadOnly = enable;
            this.txtEmail.ReadOnly = enable;
            this.txtAddress1.ReadOnly = enable;
            this.ddlProvince.Enabled = !enable;
            this.ddlDistrict.Enabled = !enable;
            this.ddlWard1.Enabled = !enable;
            this.txtAddress2.ReadOnly = enable;
            this.ddlProvince2.Enabled = !enable;
            this.ddlDistrict2.Enabled = !enable;
            this.ddlWard2.Enabled = !enable;
            this.txtAccountNo.ReadOnly = enable;
            this.txtBankName.ReadOnly = enable;
            this.txtStartWordDate.ReadOnly = enable;
            this.txtEndWordDate.ReadOnly = enable;
            this.txtSocialInsur.ReadOnly = enable;
            this.txtTaxNo.ReadOnly = enable;

            foreach (RepeaterItem item in this.rptSalary.Items)
            {
                CheckBox chkSalaryDel = (CheckBox)item.FindControl("chkSalaryDel");
                chkSalaryDel.Enabled = !enable;

                //BasicSalary
                INumberTextBox txtAllowance = (INumberTextBox)item.FindControl("txtAllowance");
                txtAllowance.SetReadOnly(true);

                //BasicSalary
                INumberTextBox txtBasicSalary = (INumberTextBox)item.FindControl("txtBasicSalary");
                txtBasicSalary.Enabled = !enable;

                //StartDate
                IDateTextBox txtStartDate = (IDateTextBox)item.FindControl("txtStartDate1");
                txtStartDate.Enabled = !enable;
            }

            foreach (RepeaterItem item in this.rptDependent.Items)
            {
                //Check
                CheckBox chkDependentDel = (CheckBox)item.FindControl("chkDependentDel");
                chkDependentDel.Enabled = !enable;

                //Dependent
                INumberTextBox txtDependent = (INumberTextBox)item.FindControl("txtDependent");
                txtDependent.Enabled = !enable;

                //StartDate
                IDateTextBox txtRegistDate = (IDateTextBox)item.FindControl("txtRegistDate");
                txtRegistDate.Enabled = !enable;
            }

            foreach (RepeaterItem item in this.rptContract.Items)
            {
                //Check
                CheckBox chkContractDel = (CheckBox)item.FindControl("chkContract");
                chkContractDel.Enabled = !enable;

                //ContractNo
                ITextBox txtContractNo = (ITextBox)item.FindControl("txtContractNo");
                txtContractNo.Enabled = !enable;

                //ContractType
                DropDownList ddlTypeofContract = (DropDownList)item.FindControl("ddlTypeofContract");
                ddlTypeofContract.Enabled = !enable;

                //StartDate
                IDateTextBox txtStartDate = (IDateTextBox)item.FindControl("txtStartDate");
                txtStartDate.Enabled = !enable;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(M_Staff staff)
        {
            if (staff != null)
            {
                using (DB db = new DB())
                {
                    //UserService userSer = new UserService(db);
                    StaffSalaryService salarySer = new StaffSalaryService(db);
                    StaffAllowanceService allowanceSer = new StaffAllowanceService(db);
                    AttachedService attachedService = new AttachedService(db);
                    StaffDependentService dependentSer = new StaffDependentService(db);
                    StaffContractService contractSer = new StaffContractService(db);

                    //Show data
                    this.txtStaffcode.Value = Utilities.EditDataUtil.ToFixCodeShow(staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.ddlTypeofStaff.SelectedValue = staff.TypeOfStaff.ToString();
                    this.txtAnnualDays.Value = staff.AnnualDays;
                    this.txtStaffname.Value = staff.StaffName;

                    string pathLogo1 = CONST_STAFF_IMAGES_PATH + EditDataUtil.ToFixCodeDB(txtStaffcode.Value, M_Staff.STAFF_CODE_MAX_LENGTH) + "/" + staff.Image;
                    if (File.Exists(MapPath(pathLogo1)))
                    {
                        this.imgLogo1.Src = pathLogo1;
                        this.imgLogo1.Alt = staff.Image;
                    }
                    else
                    {
                        this.imgLogo1.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
                    }

                    this.ddlDepartment.SelectedValue = staff.DepartmentID.ToString();
                    this.ddlPosition2.SelectedValue = staff.Position.ToString();
                    this.ddlSex.SelectedValue = staff.Sex.ToString();
                    this.txtBirthDay.Value = staff.Birthday;
                    this.ddlBirthPlace.SelectedValue = staff.Birthplace.ToString();
                    this.txtIDNo.Value = staff.IdNo;
                    this.txtIssueDate.Value = staff.IssueDate;
                    this.ddlIssuePlace.SelectedValue = staff.Issueplace.ToString();
                    this.txtTel.Value = staff.Tel;
                    this.txtEmail.Value = staff.Email;
                    this.txtAddress1.Value = staff.Address1;
                    this.ddlProvince.SelectedValue = staff.Province1.ToString();
                    this.InitDropDownDistrict(db, staff.Province1);
                    this.ddlDistrict.SelectedValue = staff.District1.ToString();
                    this.InitDropDownWard(db, staff.District1);
                    this.ddlWard1.SelectedValue = staff.Ward1.ToString();
                    this.ddlProvince2.SelectedValue = staff.Province2.ToString();
                    this.InitDropDownDistrict2(db, staff.Province2);
                    this.ddlDistrict2.SelectedValue = staff.District2.ToString();
                    this.InitDropDownWard2(db, staff.District2);
                    this.ddlWard2.SelectedValue = staff.Ward2.ToString();
                    this.txtAccountNo.Value = staff.AccountNo;
                    this.txtBankName.Value = staff.Bankname;
                    this.txtStartWordDate.Value = staff.StartWorkDate;
                    this.chkStatusFlag.Checked = staff.StatusFlag == 0 ? true : false;
                        
                    //M_User user = new M_User();

                    if (staff.EndWorkDate == DateTime.MinValue)
                    {
                        this.txtEndWordDate.Value = null;
                    }
                    else
                    {
                        this.txtEndWordDate.Value = staff.EndWorkDate;
                    }

                    this.txtSocialInsur.Value = staff.SocailinsurNo;
                    this.txtTaxNo.Value = staff.TaxNo;

                    //Save UserID and UpdateDate
                    this.StaffID = staff.ID;
                    this.OldUpdateDate = staff.UpdateDate;

                    //Get UserSalary Data
                        
                    int dataNo = 1;

                    IList<M_Staff_Salary> salary = salarySer.GetByStaffID(staff.ID);
                        
                    List<StaffSalaryInfo> salaryData = new List<StaffSalaryInfo>();
                        

                    for (int i = 0; i < salary.Count; i++)
                    {
                        StaffSalaryInfo temp = new StaffSalaryInfo();

                        temp.salaryNo = dataNo;
                        temp.ID = salary[i].ID;
                        temp.BasicSalary = salary[i].BasicSalary;
                        temp.Allowance = salary[i].Allowance;
                        temp.StartDate = salary[i].StartDate;

                        IList<M_Staff_Allowance> allowanceList = allowanceSer.GetBySalaryID(salary[i].ID);
                        string data = "";

                        for (int j = 0; j < allowanceList.Count; j++)
                        {
                            data = data + allowanceList[j].No
                                        + "_" + allowanceList[j].AllowanceName
                                        + "_" + allowanceList[j].Allowance
                                        + "_" + allowanceList[j].AccountingFlag
                                        + "_";
                        }

                        temp.data = data;
                        dataNo++;
                        salaryData.Add(temp);
                    }

                    if (salary.Count == 0)
                    {
                        IList<StaffSalaryInfo> listSa = new List<StaffSalaryInfo>();
                        this.AddEmptyRow_Salary(1, ref listSa);
                        this.rptSalary.DataSource = listSa;
                        this.rptSalary.DataBind();
                    }
                    else
                    {
                        this.RefreshDetails_Salary(salaryData);
                    }

                    //Get UserDependent Data

                        
                    IList<M_Staff_Dependent> dependent = dependentSer.GetByStaffID(staff.ID);

                    dataNo = 1;

                    var dependentData = new List<StaffDependentInfo>(dependent.Select(s => new StaffDependentInfo
                    {
                        No = dataNo++,
                        RegistDate = s.RegistDate,
                        Dependent = s.Dependent,
                        Total = s.Total,
                    }));

                    if (dependent.Count == 0)
                    {
                        IList<StaffDependentInfo> listDe = new List<StaffDependentInfo>();
                        this.AddEmptyRow_Dependent(1, ref listDe);
                        this.rptDependent.DataSource = listDe;
                        this.rptDependent.DataBind();
                    }
                    else
                    {
                        this.RefreshDetails_Dependent(dependentData);
                    }

                    //Get UserContract Data                        
                    IList<M_Staff_Contract> contract = contractSer.GetByStaffID(staff.ID);

                    dataNo = 1;
                    var contractData = new List<StaffContractInfo>(contract.Select(s => new StaffContractInfo
                    {
                        No = dataNo++,
                        ContractNo = s.ContractNo,
                        ContractType = s.ContractType,
                        StartDate = s.StartDate,
                    }));

                    if (contractData.Count == 0)
                    {
                        IList<StaffContractInfo> listCo = new List<StaffContractInfo>();
                        this.AddEmptyRow_Contract(1, ref listCo);
                        this.rptContract.DataSource = listCo;
                        this.rptContract.DataBind();
                    }
                    else
                    {
                        this.RefreshDetails_Contract(contractData);
                    }

                    this.FileCount = attachedService.CountFile(EditDataUtil.ToFixCodeShow(this.txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW));
                    
                }
            }            
        }

        /// <summary>
        /// Get Staff BY staffID
        /// </summary>
        /// <param name="userID">staffID</param>
        /// <returns>Staff</returns>
        private M_Staff GetStaff(int staffID, DB db)
        {
            StaffService staffSer = new StaffService(db);

            //Get User
            return staffSer.GetByID(staffID);
        }

        /// <summary>
        /// Get Staff By staffCode
        /// </summary>
        /// <param name="StaffCD">StaffCD</param>
        /// <returns>User</returns>
        private M_Staff GetStaff(string StaffCD, DB db, bool includeDelete = true)
        {
            StaffService userSer = new StaffService(db);

            //Get User
            return userSer.GetByStaffCD(EditDataUtil.ToFixCodeDB(StaffCD, M_Staff.STAFF_CODE_MAX_LENGTH), includeDelete);

        }

        private void CheckSalary(StaffSalaryInfo data, int index)
        {
            //Check BasicSalary                
            if (data.BasicSalary == null)
            {
                this.SetMessage(string.Format("txtBasicSalary_{0}", index), M_Message.MSG_REQUIRE, string.Format("Salary : Basic Salary [{0}]", index + 1));
            }

            //Check Allowance
            if (data.Allowance == null)
            {
                this.SetMessage(string.Format("txtAllowance_{0}", index), M_Message.MSG_REQUIRE, string.Format("Salary : Allowance [{0}]", index + 1));
            }

            //Check StartDate                
            if (data.StartDate == null)
            {
                this.SetMessage(string.Format("txtStartDate1_{0}", index), M_Message.MSG_REQUIRE, string.Format("Salary : Start Date [{0}]", index + 1));
            }
        }

        private void CheckDependent(StaffDependentInfo data, int index)
        {
            //Check BasicSalary                
            if (data.Dependent == null)
            {
                this.SetMessage(string.Format("txtDependent_{0}", index), M_Message.MSG_REQUIRE, string.Format("Dependent : Dependent [{0}]", index + 1));
            }

            //Check StartDate                
            if (data.RegistDate == null)
            {
                this.SetMessage(string.Format("txtRegistDate_{0}", index), M_Message.MSG_REQUIRE, string.Format("Dependent : Regist Date [{0}]", index + 1));
            }

        }

        private void CheckContract(StaffContractInfo data, int index)
        {
            //Check BasicSalary                
            if (data.ContractNo.Trim() == string.Empty)
            {
                this.SetMessage(string.Format("txtContractNo_{0}", index), M_Message.MSG_REQUIRE, string.Format("Contract : Contract No [{0}]", index + 1));
            }

            //Check StartDate                
            if (data.ContractType == -1)
            {
                this.SetMessage(string.Format("ddlTypeofContract_{0}", index), M_Message.MSG_REQUIRE, string.Format("Contract : Type of Contract [{0}]", index + 1));
            }

            //Check Reference File
            if (data.StartDate == null)
            {
                this.SetMessage(string.Format("txtStartDate_{0}", index), M_Message.MSG_REQUIRE, string.Format("Contract : Start Date [{0}]", index + 1));
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                #region Check Main Information

                //Check the Image
                if (this.hidImg.Value != string.Empty)
                {
                    IList<M_Config_D> lstConf = new List<M_Config_D>();
                    List<string> extens = new List<string>();
                    string exten = string.Empty;
                    Config_DService confDSer = new Config_DService(db);

                    lstConf = confDSer.GetListByConfigCd(M_Config_H.CONFIG_FILE_EXTENSION_TYPE);

                    foreach (var item in lstConf)
                    {
                        if (item.Value1 != 2)
                        {
                            continue;
                        }
                        var enterList = item.Value3.Split(';');
                        for (int i = 0; i < enterList.Length; i++)
                        {
                            var temp = enterList[i];
                            extens.Add(temp);
                            var fileExten = string.Empty;
                            if (i == enterList.Length - 1 && lstConf.IndexOf(item) == lstConf.Count - 1)
                                fileExten = temp;
                            else
                                fileExten = temp + ",";
                            exten += fileExten;
                        }
                    }

                    var filetype = Path.GetExtension(this.hidImg.Value);
                    if (!extens.Any(x => x.Equals(filetype)))
                    {
                        this.SetMessage("", M_Message.MSG_CODE_FILE_EXTENSION, exten);
                        this.imgLogo1.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
                        this.imgLogo1.Attributes.Add("style", "width:115px;height:115px");
                        return false;
                    }
                }

                //StaffCD
                if (this.txtStaffcode.IsEmpty)
                {
                    this.SetMessage(this.txtStaffcode.ID, M_Message.MSG_REQUIRE, "Staff Code");
                }
                else
                {
                    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                    {
                        // Check user by StaffCD 
                        if (this.GetStaff(this.txtStaffcode.Value, db) != null)
                        {
                            this.SetMessage(this.txtStaffcode.ID, M_Message.MSG_EXIST_CODE, "Staff Code");
                        }
                    }
                }

                //Type of Staff
                if (this.ddlTypeofStaff.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlTypeofStaff.ID, M_Message.MSG_REQUIRE, "Type of Staff");
                }

                //Annual Days
                if (this.txtAnnualDays.IsEmpty)
                {
                    this.SetMessage(this.txtAnnualDays.ID, M_Message.MSG_REQUIRE, "Annual Days");
                }

                //StaffName
                if (this.txtStaffname.IsEmpty)
                {
                    this.SetMessage(this.txtStaffname.ID, M_Message.MSG_REQUIRE, "Staff Name");
                }

                //Department
                if (this.ddlDepartment.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlDepartment.ID, M_Message.MSG_REQUIRE, "Department");
                }

                //Position
                if (this.ddlPosition2.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlPosition2.ID, M_Message.MSG_REQUIRE, "Position");
                }

                //Sex
                if (this.ddlSex.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlSex.ID, M_Message.MSG_REQUIRE, "Sex");
                }

                //Birthday
                if (this.txtBirthDay.IsEmpty)
                {
                    this.SetMessage(this.txtBirthDay.ID, M_Message.MSG_REQUIRE, "Birthday");
                }

                //BirthPlace
                if (this.ddlBirthPlace.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlBirthPlace.ID, M_Message.MSG_REQUIRE, "Birth Place");
                }

                //ID No
                if (this.txtIDNo.IsEmpty)
                {
                    this.SetMessage(this.txtIDNo.ID, M_Message.MSG_REQUIRE, "ID No");
                }

                //Issue Date
                if (this.txtIssueDate.IsEmpty)
                {
                    this.SetMessage(this.txtIssueDate.ID, M_Message.MSG_REQUIRE, "Issue Date");
                }

                //Issue Place
                if (this.ddlIssuePlace.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlIssuePlace.ID, M_Message.MSG_REQUIRE, "Issue Place");
                }

                if (!this.txtEmail.IsEmpty)
                {
                    //EmailAddress
                    if (!CheckDataUtil.IsEmail(this.txtEmail.Text))
                    {
                        this.SetMessage(this.txtEmail.ID, M_Message.MSG_INCORRECT_FORMAT, "Email");
                    }
                }

                //Address1
                if (this.txtAddress1.IsEmpty)
                {
                    this.SetMessage(this.txtAddress1.ID, M_Message.MSG_REQUIRE, "Address 1");
                }

                //Province 1
                if (this.ddlProvince.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlProvince.ID, M_Message.MSG_REQUIRE, "Province 1");
                }

                //District 1
                if (this.ddlDistrict.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlDistrict.ID, M_Message.MSG_REQUIRE, "District 1");
                }

                //Ward 1
                if (this.ddlWard1.SelectedValue == "-1")
                {
                    this.SetMessage(this.ddlWard1.ID, M_Message.MSG_REQUIRE, "Ward 1");
                }


                //AccountNo
                if (this.txtAccountNo.IsEmpty)
                {
                    this.SetMessage(this.txtAccountNo.ID, M_Message.MSG_REQUIRE, "AccountNo");
                }

                //BankName
                if (this.txtBankName.IsEmpty)
                {
                    this.SetMessage(this.txtBankName.ID, M_Message.MSG_REQUIRE, "Bank Name");
                }

                //StartWorkDate
                if (this.txtStartWordDate.IsEmpty)
                {
                    this.SetMessage(this.txtStartWordDate.ID, M_Message.MSG_REQUIRE, "Start Work Date");
                }

                #endregion

                #region CheckSalary
                IList<StaffSalaryInfo> dataSalary = this.GetDetailSalaryData();
                StaffSalaryInfo salary = dataSalary[0];
                this.CheckSalary(salary, 0);

                for (int i = 1; i < dataSalary.Count; i++)
                {
                    salary = dataSalary[i];
                    if (salary.BasicSalary != null || salary.Allowance != null || salary.StartDate != null)
                    {
                        if (salary.BasicSalary == null || salary.Allowance == null || salary.StartDate == null)
                        {
                            CheckSalary(salary, i);
                        }
                    }
                }
                #endregion

                #region CheckDependent

                IList<StaffDependentInfo> dataDependent = this.GetDetailDependentData();
                StaffDependentInfo dependent;

                for (int i = 0; i < dataDependent.Count; i++)
                {
                    dependent = dataDependent[i];

                    if (dependent.Dependent != null || dependent.RegistDate != null)
                    {
                        if (dependent.Dependent == null || dependent.RegistDate == null)
                        {
                            CheckDependent(dependent, i);
                        }
                    }

                    int count = 0;

                    foreach (StaffDependentInfo item in dataDependent)
                    {
                        if (item.RegistDate == dependent.RegistDate && item.RegistDate != null && dependent.RegistDate != null)
                        {
                            count++;
                        }
                    }

                    if (count > 1)
                    {
                        //Check StartDate
                        this.SetMessage(string.Format("txtRegistDate_{0}", i), M_Message.MSG_EXIST_CODE, string.Format("Dependent : Regist Date {0}", i + 1));
                    }

                }

                #endregion

                #region Contract

                IList<StaffContractInfo> dataContract = this.GetDetailContractData();
                StaffContractInfo contract;

                for (int i = 0; i < dataContract.Count; i++)
                {
                    contract = new StaffContractInfo();
                    contract = dataContract[i];

                    if (contract.ContractNo.Trim() != string.Empty || contract.ContractType != -1 || contract.StartDate != null)
                    {
                        if (contract.ContractNo.Trim() == string.Empty || contract.ContractType == -1 || contract.StartDate == null)
                        {
                            CheckContract(contract, i);
                        }
                    }

                    int count = 0;

                    foreach (StaffContractInfo item in dataContract)
                    {
                        if (item.ContractNo == contract.ContractNo && item.ContractNo != string.Empty && contract.ContractNo != string.Empty)
                        {
                            count++;
                        }
                    }

                    if (count > 1)
                    {
                        //Check StartDate
                        this.SetMessage(string.Format("txtContractNo_{0}", i), M_Message.MSG_EXIST_CODE, string.Format("Contract : Contract No {0}", i + 1));
                    }

                }

                #endregion

                this.RefreshDetails_Salary(dataSalary);
                this.RefreshDetails_Dependent(dataDependent);
                this.RefreshDetails_Contract(dataContract);
            }
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Refresh Salary Detail
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails_Salary(IList<StaffSalaryInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailSalaryData();
            }
            this.rptSalary.DataSource = dataSource;
            this.rptSalary.DataBind();
        }

        /// <summary>
        /// Refresh Dependent Detail
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails_Dependent(IList<StaffDependentInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailDependentData();
            }
            this.rptDependent.DataSource = dataSource;
            this.rptDependent.DataBind();
        }

        /// <summary>
        /// Refresh Contract Detail
        /// </summary>
        /// <param name="dataSource"></param>
        private void RefreshDetails_Contract(IList<StaffContractInfo> dataSource = null)
        {
            if (dataSource == null)
            {
                dataSource = this.GetDetailContractData();
            }
            this.rptContract.DataSource = dataSource;
            this.rptContract.DataBind();
        }

        /// <summary>
        /// Show Image
        /// </summary>
        /// <param name="filename"></param>
        /// <param name="img"></param>
        private void ShowImage(string filename, HtmlImage img)
        {
            string tmpDirectory = CONST_STAFF_IMAGES_PATH + EditDataUtil.ToFixCodeDB(txtStaffcode.Value, M_Staff.STAFF_CODE_MAX_LENGTH);

            if (!Directory.Exists(MapPath(tmpDirectory)))
            {
                tmpDirectory = CONST_STAFF_IMAGES_PATH;
            }

            string tmpPathLogo = tmpDirectory + "/" + filename;

            if (!File.Exists(MapPath(tmpPathLogo)))
            {
                tmpPathLogo = CONST_STAFF_IMAGES_PATH + filename;
            }

            if (filename == string.Empty)
            {
                img.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;
            }
            else
            {
                img.Src = tmpPathLogo + "?time=" + DateTime.Now.ToString();
            }
        }

        /// <summary>
        /// Save Image To Temp Path
        /// </summary>
        /// <param name="fileUpload"></param>
        /// <param name="filename"></param>
        /// <param name="img"></param>
        private void SaveTempImage(FileUpload fileUpload, string filename, HtmlImage img)
        {
            //Create the LogoTemp directory
            string tmpDirectory = CONST_STAFF_IMAGES_PATH + EditDataUtil.ToFixCodeDB(txtStaffcode.Value, M_Staff.MAX_STAFF_CODE_SHOW);

            if (!Directory.Exists(MapPath(tmpDirectory)))
            {
                tmpDirectory = CONST_STAFF_IMAGES_PATH;
            }

            //Get file name, file size and save the Logo into the Logo directory
            string tmpPathLogo;

            //
            img.Src = CONST_IMAGES_PATH + CONST_NO_IMAGE_AVAILABLE;

            if ((fileUpload.PostedFile != null && fileUpload.PostedFile.ContentLength > 0) && filename != string.Empty)
            {
                if (fileUpload.PostedFile != null && fileUpload.PostedFile.ContentLength > 0)
                {
                    fileUpload.SaveAs(MapPath(tmpDirectory + "/" + filename));
                    tmpPathLogo = tmpDirectory + "/" + filename;
                }
            }
        }

        /// <summary>
        /// Save Image
        /// </summary>
        /// <param name="fileUpload"></param>
        /// <param name="filename"></param>
        private void SaveImage(FileUpload fileUpload, string filename)
        {
            string tmpDirectory = CONST_STAFF_IMAGES_PATH + EditDataUtil.ToFixCodeDB(txtStaffcode.Value, M_Staff.STAFF_CODE_MAX_LENGTH);

            if (!Directory.Exists(MapPath(tmpDirectory)) && filename != string.Empty)
            {
                Directory.CreateDirectory(MapPath(tmpDirectory));
            }

            string pathLogo = MapPath(CONST_STAFF_IMAGES_PATH);

            if ((fileUpload.PostedFile != null && fileUpload.PostedFile.ContentLength > 0) || (filename != string.Empty))
            {
                if (!(fileUpload.PostedFile != null && fileUpload.PostedFile.ContentLength > 0))
                {
                    string tmpPathLogo = tmpDirectory + "/" + filename;
                    if (File.Exists(pathLogo + filename) && !File.Exists(MapPath(tmpPathLogo)))
                    {
                        File.Copy(pathLogo + filename, MapPath(tmpPathLogo));
                    }
                }
            }

            if (File.Exists(pathLogo + filename))
            {
                File.Delete(pathLogo + filename);
            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Staff staff = new M_Staff();
                staff.StaffCD = this.txtStaffcode.Value;
                staff.StaffName = this.txtStaffname.Value;
                staff.Image = this.hidImg.Value;
                staff.TypeOfStaff = short.Parse(this.ddlTypeofStaff.SelectedValue.ToString());
                staff.AnnualDays = decimal.Parse(this.txtAnnualDays.Value.ToString());
                staff.DepartmentID = int.Parse(this.ddlDepartment.SelectedValue.ToString());
                staff.Position = int.Parse(this.ddlPosition2.SelectedValue.ToString());
                staff.Sex = short.Parse(this.ddlSex.SelectedValue.ToString());
                staff.Birthday = DateTime.Parse(txtBirthDay.Value.ToString());
                staff.Birthplace = int.Parse(this.ddlBirthPlace.SelectedValue.ToString());
                staff.IdNo = this.txtIDNo.Value;
                staff.IssueDate = DateTime.Parse(this.txtIssueDate.Value.ToString());
                staff.Issueplace = int.Parse(this.ddlIssuePlace.SelectedValue.ToString());
                staff.Tel = this.txtTel.Value;
                staff.Tel2 = this.txtTel2.Value;
                staff.Email = this.txtEmail.Value;
                staff.Address1 = this.txtAddress1.Value;
                staff.Province1 = int.Parse(this.ddlProvince.SelectedValue.ToString());
                staff.District1 = int.Parse(this.ddlDistrict.SelectedValue.ToString());
                staff.Ward1 = int.Parse(this.ddlWard1.SelectedValue.ToString());
                staff.Address2 = this.txtAddress2.Value;
                staff.Province2 = int.Parse(this.ddlProvince2.SelectedValue.ToString());
                staff.District2 = int.Parse(this.ddlDistrict2.SelectedValue.ToString());
                staff.Ward2 = int.Parse(this.ddlWard2.SelectedValue.ToString());
                staff.AccountNo = this.txtAccountNo.Value;
                staff.Bankname = this.txtBankName.Value;
                staff.StartWorkDate = this.txtStartWordDate.Value.Value;
                staff.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                if (this.txtEndWordDate.Value.ToString() == string.Empty)
                {
                    staff.EndWorkDate = DateTime.MinValue;
                }
                else
                {
                    staff.EndWorkDate = this.txtEndWordDate.Value.Value;
                }

                staff.SocailinsurNo = this.txtSocialInsur.Value;
                staff.TaxNo = this.txtTaxNo.Value;

                staff.CreateUID = staff.UpdateUID = this.LoginInfo.User.ID;
                //staff.UpdateUID = this.LoginInfo.User.ID;

                Hashtable salaryData = new Hashtable();
                Hashtable allowanceData = new Hashtable();

                this.CreateSalaryDetail(ref salaryData, ref allowanceData, staff.ID);

                IList<M_Staff_Dependent> dependentList = null;
                this.CreateDependentDetail(ref dependentList, staff.ID);

                IList<M_Staff_Contract> contractList = null;
                this.CreateContractDetail(ref contractList, staff.ID);

                //Insert User
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    UserService userSer = new UserService(db);
                    StaffService staffSer = new StaffService(db);

                    //Insert User
                    staffSer.Insert(staff);
                    this.StaffID = db.GetIdentityId<M_Staff>();

                    //Insert Salary
                    StaffSalaryService salarySer = new StaffSalaryService(db);
                    StaffAllowanceService allowanceSer = new StaffAllowanceService(db);
                    StaffDependentService dependentSer = new StaffDependentService(db);
                    StaffContractService contractSer = new StaffContractService(db);

                    for (int i = 0; i < salaryData.Count; i++)
                    {
                        M_Staff_Salary salary = (M_Staff_Salary)salaryData[i];
                        salary.UserID = this.StaffID;
                        salarySer.Insert(salary);

                        int salaryID = db.GetIdentityId<M_Staff_Salary>();
                        List<M_Staff_Allowance> listAllowance = (List<M_Staff_Allowance>)allowanceData[i];

                        if (listAllowance != null)
                        {
                            foreach (M_Staff_Allowance item in listAllowance)
                            {
                                if (item.IsEmpty())
                                {
                                    continue;
                                }

                                item.SalaryID = salaryID;
                                allowanceSer.Insert(item);
                            }
                        }
                    }

                    foreach (M_Staff_Dependent item in dependentList)
                    {
                        item.StaffID = this.StaffID;
                        dependentSer.Insert(item);
                    }

                    foreach (M_Staff_Contract item in contractList)
                    {
                        item.StaffID = this.StaffID;
                        contractSer.Insert(item);
                    }

                    db.Commit();
                    
                }
                this.SaveImage(this.fileLogo1, this.hidImg.Value);
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                string newImage = "";
                string oldImage = "";
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    M_Staff staff = this.GetStaff(this.txtStaffcode.Value, db);
                    UserService userSer = new UserService(db);
                    StaffService staffSer = new StaffService(db);
                    StaffSalaryService salarySer = new StaffSalaryService(db);
                    StaffAllowanceService allowanceSer = new StaffAllowanceService(db);
                    StaffDependentService dependentSer = new StaffDependentService(db);
                    StaffContractService contractSer = new StaffContractService(db);

                    if (staff != null)
                    {
                        //Save Old Image
                        oldImage = staff.Image;

                        //Create model
                        staff.ID = this.StaffID;
                        staff.StaffCD = this.txtStaffcode.Value;
                        staff.StaffName = this.txtStaffname.Value;
                        staff.Image = this.hidImg.Value;
                        newImage = staff.Image;
                        staff.TypeOfStaff = short.Parse(this.ddlTypeofStaff.SelectedValue.ToString());
                        staff.AnnualDays = decimal.Parse(this.txtAnnualDays.Value.ToString());
                        staff.DepartmentID = int.Parse(this.ddlDepartment.SelectedValue.ToString());
                        staff.Position = int.Parse(this.ddlPosition2.SelectedValue.ToString());
                        staff.Sex = short.Parse(this.ddlSex.SelectedValue.ToString());
                        staff.Birthday = DateTime.Parse(txtBirthDay.Value.ToString());
                        staff.Birthplace = int.Parse(this.ddlBirthPlace.SelectedValue.ToString());
                        staff.IdNo = this.txtIDNo.Value;
                        staff.IssueDate = DateTime.Parse(this.txtIssueDate.Value.ToString());
                        staff.Issueplace = int.Parse(this.ddlIssuePlace.SelectedValue.ToString());
                        staff.Tel = this.txtTel.Value;
                        staff.Tel2 = this.txtTel2.Value;
                        staff.Email = this.txtEmail.Value;
                        staff.Address1 = this.txtAddress1.Value;
                        staff.Province1 = int.Parse(this.ddlProvince.SelectedValue.ToString());
                        staff.District1 = int.Parse(this.ddlDistrict.SelectedValue.ToString());
                        staff.Ward1 = int.Parse(this.ddlWard1.SelectedValue.ToString());
                        staff.Address2 = this.txtAddress2.Value;
                        staff.Province2 = int.Parse(this.ddlProvince2.SelectedValue.ToString());
                        staff.District2 = int.Parse(this.ddlDistrict2.SelectedValue.ToString());
                        staff.Ward2 = int.Parse(this.ddlWard2.SelectedValue.ToString());
                        staff.AccountNo = this.txtAccountNo.Value;
                        staff.Bankname = this.txtBankName.Value;
                        staff.StartWorkDate = this.txtStartWordDate.Value.Value;
                        staff.StatusFlag = Convert.ToInt16(this.chkStatusFlag.Checked == true ? 0 : 1);

                        if (this.txtEndWordDate.Value.ToString() == string.Empty)
                        {
                            staff.EndWorkDate = DateTime.MinValue;
                        }
                        else
                        {
                            staff.EndWorkDate = this.txtEndWordDate.Value.Value;
                        }

                        staff.SocailinsurNo = this.txtSocialInsur.Value;
                        staff.TaxNo = this.txtTaxNo.Value;

                        staff.UpdateDate = this.OldUpdateDate;
                        staff.UpdateUID = this.LoginInfo.User.ID;

                        //Update staff                    

                        

                        //Update User
                        //if (staff.Status == DataStatus.Changed)
                        //{
                        ret = staffSer.Update(staff);

                        //Check result update
                        if (ret == 0)
                        {
                            //du lieu da thay doi
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        //Get Data from UI
                        Hashtable salaryUIList = new Hashtable();
                        Hashtable allowanceUIList = new Hashtable();
                        IList<M_Staff_Dependent> dependentUIList = null;
                        IList<M_Staff_Contract> contractUIList = null;

                        this.CreateSalaryDetail(ref salaryUIList, ref allowanceUIList, staff.ID);
                        this.CreateDependentDetail(ref dependentUIList, staff.ID);
                        this.CreateContractDetail(ref contractUIList, staff.ID);

                        //Get Data From Database
                        
                        IList<M_Staff_Salary> salaryDBList = salarySer.GetByStaffID(staff.ID);

                        
                        IList<M_Staff_Allowance> allowanceDBList = allowanceSer.GetByStaffID(staff.ID);

                        
                        IList<M_Staff_Dependent> dependentDBList = dependentSer.GetByStaffID(staff.ID);

                        
                        IList<M_Staff_Contract> contractDBList = contractSer.GetByStaffID(staff.ID);

                        //Check DataChanged------------------------------------------------------
                        bool detailChanged = false;

                        if (salaryUIList.Count != salaryDBList.Count ||
                            allowanceUIList.Count != allowanceDBList.Count ||
                            dependentUIList.Count != dependentDBList.Count ||
                            contractUIList.Count != contractDBList.Count)
                        {
                            detailChanged = true;
                        }

                        //------------------------------------------------------

                        if (!detailChanged)
                        {
                            foreach (M_Staff_Salary item in salaryDBList)
                            {
                                if (!salaryUIList.Contains(item))
                                {
                                    detailChanged = true;
                                    break;
                                }
                            }

                            foreach (M_Staff_Allowance item in allowanceDBList)
                            {
                                if (!allowanceUIList.Contains(item))
                                {
                                    detailChanged = true;
                                    break;
                                }
                            }

                            foreach (M_Staff_Dependent item in dependentDBList)
                            {
                                if (!dependentUIList.Contains(item))
                                {
                                    detailChanged = true;
                                    break;
                                }
                            }

                            foreach (M_Staff_Contract item in contractDBList)
                            {
                                if (!contractUIList.Contains(item))
                                {
                                    detailChanged = true;
                                    break;
                                }
                            }
                        }

                        if (detailChanged)
                        {
                            //Update Salary
                            salarySer.Delete(staff.ID);

                            for (int i = 0; i < salaryUIList.Count; i++)
                            {
                                M_Staff_Salary salary = (M_Staff_Salary)salaryUIList[i];

                                salarySer.Insert(salary);

                                int salaryID = db.GetIdentityId<M_Staff_Salary>();
                                List<M_Staff_Allowance> listAllowance = (List<M_Staff_Allowance>)allowanceUIList[i];

                                if (listAllowance != null)
                                {
                                    foreach (M_Staff_Allowance item in listAllowance)
                                    {
                                        item.SalaryID = salaryID;
                                        allowanceSer.Insert(item);
                                    }
                                }
                            }

                            //Update Dependent
                            dependentSer.Delete(staff.ID);
                            foreach (M_Staff_Dependent item in dependentUIList)
                            {
                                dependentSer.Insert(item);
                            }

                            //Update Contract
                            contractSer.Delete(staff.ID);
                            foreach (M_Staff_Contract item in contractUIList)
                            {
                                contractSer.Insert(item);
                            }
                        }
                        else
                        {
                            //du lieu da thay doi
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        db.Commit();
                        //}
                        //else
                        //{
                        //    return true;
                        //}
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }

                this.SaveImage(this.fileLogo1, this.hidImg.Value);

                //Delete old Image
                if (newImage != oldImage)
                {
                    string path = MapPath(CONST_STAFF_IMAGES_PATH + EditDataUtil.ToFixCodeDB(txtStaffcode.Value, M_Staff.STAFF_CODE_MAX_LENGTH) + "/" + oldImage);
                    if (File.Exists(path))
                    {
                        File.Delete(path);
                    }
                }
            }
            catch (Exception ex)
            {

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                     errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        /// <summary>
        /// Calc Dependent Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalcDependentTotal(string dep, string tot, int index)
        {
            try
            {
                decimal sumTotal = decimal.Parse(dep) + decimal.Parse(tot);
                string sumResult = string.Empty;

                if (sumTotal != 0)
                {
                    sumResult = sumTotal.ToString("N0");
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();

                result.Append("{");
                result.Append(string.Format("\"txtTotal_" + index + "\":\"{0}\"", sumResult));
                result.Append("}");

                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        /// <summary>
        /// Count Attached File
        /// </summary>
        /// <param name="dataId">dataId</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CountFile(string dataId)
        {
            try
            {
                using (DB db = new DB())
                {
                    AttachedService attachedService = new AttachedService(db);
                    var count = attachedService.CountFile(dataId);
                    var result = new
                    {
                        count = count
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }

        [System.Web.Services.WebMethod]
        public static string FillStaffCD(string in1)
        {
            try
            {
                string staffCd = in1;
                if (CheckDataUtil.IsInteger(in1))
                {
                    staffCd = EditDataUtil.ToFixCodeShow(EditDataUtil.ToFixCodeDB(in1, M_Staff.STAFF_CODE_MAX_LENGTH), M_Staff.MAX_STAFF_CODE_SHOW);
                }

                var result = new
                {
                    staffcode = staffCd
                };
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);

            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        

        #endregion
    }
}
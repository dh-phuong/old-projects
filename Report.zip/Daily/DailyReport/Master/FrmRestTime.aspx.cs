﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;

using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// TRAM - 2015/06/03
    /// RestTime Form
    /// </summary>
    public partial class FrmRestTime : FrmBaseDetail
    {
        #region Vriable
            public bool isHasData=false;
        #endregion

        #region Property

        /// <summary>
        /// Get or set ShiftID
        /// </summary>
        public int ShiftID 
        {
            get { return (int)ViewState["ShiftID"]; }
            set { ViewState["ShiftID"] = value; }
        }

        /// <summary>
        /// Get or set OldRestTime
        /// </summary>
        public M_RestTime OldRestTime
        {
            get { return (M_RestTime)ViewState["OldRestTime"]; }
            set { ViewState["OldRestTime"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDateOfShift
        /// </summary>
        public DateTime OldUpdateDateOfShift
        {
            get { return (DateTime)ViewState["OldUpdateDateOfShift"]; }
            set { ViewState["OldUpdateDateOfShift"] = value; }
        }

        /// <summary>
        /// Get or set DurationList
        /// </summary>
        public IList<RestTime> RestTimeList
        {
            get { return (IList<RestTime>)ViewState["RestTimeList"]; }
            set { ViewState["RestTimeList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Rest Time";
            base.FormSubTitle = "";
            base.IsHiddenModeLabel = true;

            // Header grid sort

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);

            //Init Max Length
            this.txtShiftCode.MaxLength = M_Work_Shift.SHIFT_CODE_MAX_LENGTH;

        }    

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Holiday);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmWorksMenu.aspx");
            }

            this.SetReadOnlyControl();
            base.DisabledLink(this.btnSubmit, true);
            if (!this.IsPostBack)
            {
                this.ShowData();
            }
        }

        /// <summary>
        /// View Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, CommandEventArgs e)
        {
            //Check inputting
            if (!this.CheckInput(true,false))
            {
                return;
            }
            
            //Show data
            this.ShowData();
            base.DisabledLink(this.btnSubmit,false);
        }

        /// <summary>
        /// Submit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!this.txtShiftCode.IsEmpty)
            {
                if (!this.hdnOldShiftCode.Value.Equals(this.txtShiftCode.Value))
                {
                    this.txtShiftCode.Value = this.hdnOldShiftCode.Value;
                    using (DB db = new DB())
                    {
                        WorkShiftService shiftSer = new WorkShiftService(db);
                        M_Work_Shift shift = shiftSer.GetByShiftCode(int.Parse(this.txtShiftCode.Value));
                        if (shift != null)
                        {
                            this.txtShiftName.Value= shift.ShiftName;
                        }
                    }
                }
            }
           
            if (!CheckInput(false,true))
            {
                return;
            }
            this.isHasData = true;
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes,true);
        }

        #endregion

        #region "Method"

        /// <summary>
        /// Check inputting
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(bool isView=true, bool isRegist=false )
        {
            if (isView || isRegist)
            {
                if (this.txtShiftCode.IsEmpty)
                {
                    this.SetMessage(this.txtShiftCode.ID, M_Message.MSG_REQUIRE, "Shift Code");
                  
                }
                else if (!this.txtShiftCode.IsEmpty)
                {
                    using (DB db = new DB())
                    {
                        WorkShiftService workingShiftSer = new WorkShiftService(db);
                        M_Work_Shift workingShift = workingShiftSer.GetByShiftCode(int.Parse(this.txtShiftCode.Value));
                        if (workingShift == null)
                        {
                            //this.txtShiftName.Value = string.Empty;
                            this.SetMessage(this.txtShiftCode.ID, M_Message.MSG_NOT_EXIST_CODE, "Shift Code");
                        }
                    }
                   
                }
                base.DisabledLink(this.btnSubmit, true);
                this.isHasData = false;
            }

            if (isRegist)
            {
                if (!this.txtShiftCode.IsEmpty)
                {
                    //RestTime1
                    this.CheckInputForControl(this.datStartTime1, this.datEndTime1, 1);

                    //RestTime2
                    this.CheckInputForControl(this.datStartTime2, this.datEndTime2, 2);

                    //RestTime3
                    this.CheckInputForControl(this.datStartTime3, this.datEndTime3, 3);

                    //RestTime4
                    this.CheckInputForControl(this.datStartTime4, this.datEndTime4, 4);

                    //RestTime5
                    this.CheckInputForControl(this.datStartTime5, this.datEndTime5, 5);

                    //RestTime6
                    this.CheckInputForControl(this.datStartTime6, this.datEndTime6, 6);
                    this.SetRestTimeList();
                    this.CheckDuplicate(this.datStartTime1, this.datEndTime1,1);
                    this.CheckDuplicate(this.datStartTime2, this.datEndTime2,2);
                    this.CheckDuplicate(this.datStartTime3, this.datEndTime3,3);
                    this.CheckDuplicate(this.datStartTime4, this.datEndTime4,4);
                    this.CheckDuplicate(this.datStartTime5, this.datEndTime5,5);
                    this.CheckDuplicate(this.datStartTime6, this.datEndTime6,6);
                }
                this.isHasData = true;
                base.DisabledLink(this.btnSubmit, false);
            }

            
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Check inputting for controls
        /// </summary>
        /// <param name="startTime">StartTime</param>
        /// <param name="endTime">EndTime</param>
        /// <param name="index">index</param>
        private void CheckInputForControl(IDateTextBox startTime,IDateTextBox endTime, int index)
        {
            //RestTime
            if (startTime.IsEmpty && !endTime.IsEmpty)
            {
                this.SetMessage(startTime.ID, M_Message.MSG_REQUIRE, "Start Rest Time " + index);
            }

            if (!startTime.IsEmpty && endTime.IsEmpty)
            {
                this.SetMessage(endTime.ID, M_Message.MSG_REQUIRE, "End Rest Time " + index);
            }

            if (!startTime.IsEmpty && !endTime.IsEmpty && startTime.Value >= endTime.Value)
            {
                this.SetMessage(startTime.ID, M_Message.MSG_LESS_THAN, "Start Rest Time " + index, "End Rest Time " + index);
            }

        }

        /// <summary>
        /// Check duplication of Rest Time rows
        /// </summary>
        /// <param name="datStartTime"></param>
        /// <param name="datEndTime"></param>
        /// <param name="index"></param>
        private void CheckDuplicate(IDateTextBox datStartTime, IDateTextBox datEndTime, int index)
        {
            DateTime startRestTime=DateTime.Now;
            DateTime endRestTime = DateTime.Now;

            if (datStartTime.Value != null && datEndTime.Value != null)
            {
                startRestTime = new DateTime(1, 1, 1).AddHours(datStartTime.Value.Value.Hour).AddMinutes(datStartTime.Value.Value.Minute);
                endRestTime = new DateTime(1, 1, 1).AddHours(datEndTime.Value.Value.Hour).AddMinutes(datEndTime.Value.Value.Minute);
            }

            int rowNum = 0;
            foreach(RestTime row in this.RestTimeList)
            {
                DateTime startTime=new  DateTime(1, 1, 1).AddHours(row.RestTimeSH).AddMinutes(row.RestTimeSM);
                DateTime endTime = new DateTime(1, 1, 1).AddHours(row.RestTimeEH).AddMinutes(row.RestTimeEM);

                if (datStartTime.Value != null && datEndTime.Value != null)
                {
                    rowNum++;
                    if ((startRestTime == startTime && endRestTime == endTime) || (startRestTime > startTime && startRestTime > endTime))
                    {
                        continue;
                    }

                    if ((startRestTime>=startTime  && endRestTime<=endTime )
                       || (startRestTime >= startTime && endRestTime >= endTime) )
                    {
                        this.SetMessage(datStartTime.ClientID, M_Message.MSG_DUPLICATE_GRID, "Rest Time ", index);
                        this.CtrlIDErrors.Add(datStartTime.ClientID);
                        break;
                    }
                }
                
            }
            
        }

        /// <summary>
        /// Show data
        /// </summary>
        private void ShowData()
        {
            using (DB db = new DB())
            {
                if (!this.txtShiftCode.IsEmpty)
                {
                    int? shiftCode = int.Parse(this.txtShiftCode.Value);
                    this.hdnOldShiftCode.Value = shiftCode.Value.ToString();
                    WorkShiftService workShiftSer = new WorkShiftService(db);

                    M_Work_Shift workShift = workShiftSer.GetByShiftCode(shiftCode.Value);
                    if (workShift != null)
                    {
                        int shiftID = workShift.ID;
                        this.txtShiftName.Value = workShift.ShiftName;
                        this.ShiftID = shiftID;
                        this.OldUpdateDateOfShift = workShift.UpdateDate;

                        RestTimeService restTimeSer = new RestTimeService(db);
                        M_RestTime restTime = restTimeSer.GetByShiftID(shiftID);
                        if (restTime != null)
                        {

                            //RestTime1
                            if (restTime.RestTimeSH1 != null && restTime.RestTimeSM1 != null && restTime.RestTimeEH1 != null && restTime.RestTimeEM1 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH1.Value, restTime.RestTimeSM1.Value, restTime.RestTimeEH1.Value, restTime.RestTimeEM1.Value, ref this.datStartTime1, ref this.datEndTime1, ref this.txtDuration1);
                            }
                            else
                            {
                                this.datStartTime1.Value = null;
                                this.datEndTime1.Value = null;
                                this.txtDuration1.Value = null;
                            }

                            //RestTime2
                            if (restTime.RestTimeSH2 != null && restTime.RestTimeSM2 != null && restTime.RestTimeEH2 != null && restTime.RestTimeEM2 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH2.Value, restTime.RestTimeSM2.Value, restTime.RestTimeEH2.Value, restTime.RestTimeEM2.Value, ref this.datStartTime2, ref this.datEndTime2, ref this.txtDuration2);
                            }
                            else
                            {
                                this.datStartTime2.Value = null;
                                this.datEndTime2.Value = null;
                                this.txtDuration2.Value = null;
                            }

                            //RestTime3
                            if (restTime.RestTimeSH3 != null && restTime.RestTimeSM3 != null && restTime.RestTimeEH3 != null && restTime.RestTimeEM3 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH3.Value, restTime.RestTimeSM3.Value, restTime.RestTimeEH3.Value, restTime.RestTimeEM3.Value, ref this.datStartTime3, ref this.datEndTime3, ref this.txtDuration3);
                            }
                            else
                            {
                                this.datStartTime3.Value = null;
                                this.datEndTime3.Value = null;
                                this.txtDuration3.Value = null;
                            }

                            //RestTime4
                            if (restTime.RestTimeSH4 != null && restTime.RestTimeSM4 != null && restTime.RestTimeEH4 != null && restTime.RestTimeEM4 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH4.Value, restTime.RestTimeSM4.Value, restTime.RestTimeEH4.Value, restTime.RestTimeEM4.Value, ref this.datStartTime4, ref this.datEndTime4, ref this.txtDuration4);
                            }
                            else
                            {
                                this.datStartTime4.Value = null;
                                this.datEndTime4.Value = null;
                                this.txtDuration4.Value = null;
                            }

                            //RestTime5
                            if (restTime.RestTimeSH5 != null && restTime.RestTimeSM5 != null && restTime.RestTimeEH5 != null && restTime.RestTimeEM5 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH5.Value, restTime.RestTimeSM5.Value, restTime.RestTimeEH5.Value, restTime.RestTimeEM5.Value, ref this.datStartTime5, ref this.datEndTime5, ref this.txtDuration5);
                            }
                            else
                            {
                                this.datStartTime5.Value = null;
                                this.datEndTime5.Value = null;
                                this.txtDuration5.Value = null;
                            }
                            //RestTime6
                            if (restTime.RestTimeSH6 != null && restTime.RestTimeSM6 != null && restTime.RestTimeEH6 != null && restTime.RestTimeEM6 != null)
                            {
                                this.SetControlValue(restTime.RestTimeSH6.Value, restTime.RestTimeSM6.Value, restTime.RestTimeEH6.Value, restTime.RestTimeEM6.Value, ref this.datStartTime6, ref this.datEndTime6, ref this.txtDuration6);
                            }
                            else
                            {
                                this.datStartTime6.Value = null;
                                this.datEndTime6.Value = null;
                                this.txtDuration6.Value = null;
                            }
                            this.OldRestTime = restTime;
                        }
                        else
                        {
                            this.ClearData();

                        }
                    }
                    this.isHasData = true;
                }
            }
        }

        /// <summary>
        /// btnProcessData
        /// </summary>
        private void btnProcessData(object sender, EventArgs e)
        {
            if (!this.IsExistedData())
            {
                if (this.Insert())
                {
                   
                   // Show data
                    this.ShowData();
                    //Set Success
                    this.Success = true;
                }
            }
            else
            {
                if (this.Update())
                {
                    //Show data
                    this.ShowData();

                    //Set Success
                    this.Success = true;
                }
            }
            base.DisabledLink(this.btnSubmit, false);
        }

        /// btnNoProcessData
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
            this.isHasData = true;
            base.DisabledLink(this.btnSubmit, false);
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool IsExistedData()
        {
            using (DB db = new DB())
            {
                M_RestTime restTime = new M_RestTime();
                int? shiftCode = int.Parse(this.txtShiftCode.Value);
                WorkShiftService workShiftSer = new WorkShiftService(db);

                M_Work_Shift workShift = workShiftSer.GetByShiftCode(shiftCode.Value);
                if (workShift != null)
                {
                    int shiftID = workShift.ID;
                    RestTimeService restTimeSer = new RestTimeService(db);
                    restTime = restTimeSer.GetByShiftID(shiftID);
                }
                return restTime != null;
            }
        }

        /// <summary>
        /// Update
        /// </summary>
        /// <returns></returns>
        private bool Update()
        {
            try
            {
                int ret = 0;
                int retShift = 0;
                this.isHasData = true;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    M_Work_Shift workShift = new M_Work_Shift();

                    RestTimeService restTimeSer = new RestTimeService(db);
                    M_RestTime restTimeNew = new M_RestTime();
                    M_RestTime dataInDatabase = new M_RestTime();
                    
                    dataInDatabase = restTimeSer.GetByShiftID(this.ShiftID);
                    if (dataInDatabase != null)
                    {
                        if ((DateTime)dataInDatabase.UpdateDate != (DateTime)this.OldRestTime.UpdateDate)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                            
                        //Set data to update
                        restTimeNew.ShiftID = this.ShiftID;

                        //Create RestTime Model
                        this.CreateRestTimeModel(ref restTimeNew);

                        restTimeNew.UpdateDate = (DateTime)this.OldRestTime.UpdateDate;
                        ret = restTimeSer.Update(restTimeNew);

                        if (ret == 0)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        M_Work_Shift shift = shiftSer.GetByID(this.ShiftID);
                        if (shift != null)
                        {
                            workShift = this.CreateWorkShiftModel(db, ref shift);
                            retShift = shiftSer.Update(workShift);

                            if (retShift == 0)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                        
                    }

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <returns></returns>
        private bool Insert()
        {
            try
            {
                int ret = 0;
                int retShift = 0;
                this.isHasData = true;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    
                    RestTimeService restTimeSer = new RestTimeService(db);
                    M_RestTime restTime = new M_RestTime();
                    int? shiftCode = int.Parse(this.txtShiftCode.Value);
                    WorkShiftService workShiftSer=new WorkShiftService(db);
                    
                    M_Work_Shift workShift = workShiftSer.GetByShiftCode(shiftCode.Value);
                    

                    if (workShift != null)
                    {
                        //Create RestTime Model
                        this.CreateRestTimeModel(ref restTime);
                        this.SetRestTimeList();

                        //CreateUID
                        restTime.CreateUID = this.LoginInfo.User.ID;

                        //UpdateUID
                        restTime.UpdateUID = this.LoginInfo.User.ID;

                        //ShiftID
                        restTime.ShiftID = workShift.ID;
                        this.ShiftID = workShift.ID;

                        //Insert
                        ret = restTimeSer.Insert(restTime);
                        if (ret == 0)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }

                        M_Work_Shift shift = new M_Work_Shift();
                        shift = workShiftSer.GetByID(this.ShiftID);
                        if (shift!=null)
                        {
                            shift = this.CreateWorkShiftModel(db, ref shift);

                            retShift = workShiftSer.Update(shift);

                            if (retShift == 0)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Clear data
        /// </summary>
        private void ClearData()
        {
            this.datStartTime1.Value = null;
            this.datEndTime1.Value = null;
            this.txtDuration1.Value = null;
            this.datStartTime2.Value = null;
            this.datEndTime2.Value = null;
            this.txtDuration2.Value = null;
            this.datStartTime3.Value = null;
            this.datEndTime3.Value = null;
            this.txtDuration3.Value = null;
            this.datStartTime4.Value = null;
            this.datEndTime4.Value = null;
            this.txtDuration4.Value = null;
            this.datStartTime5.Value = null;
            this.datEndTime5.Value = null;
            this.txtDuration5.Value = null;
            this.datStartTime6.Value = null;
            this.datEndTime6.Value = null;
            this.txtDuration6.Value = null;
        }
               

       /// <summary>
        /// Set value for controls
       /// </summary>
        /// <param name="startHour">StartHour</param>
        /// <param name="startMinute">StartMinute</param>
        /// <param name="endHour">EndHour</param>
        /// <param name="endMinute">EndMinute</param>
        /// <param name="datStartTime">datStartTime</param>
        /// <param name="datEndTime">datEndTime</param>
        /// <param name="txtDuration">txtDuration</param>
        private void SetControlValue(int? startHour, int? startMinute, int? endHour, int? endMinute, ref IDateTextBox datStartTime, ref IDateTextBox datEndTime, ref ITextBox txtDuration)
        {
            if (startHour != null && startMinute != null)
            {
                datStartTime.SetTimeValue(startHour.Value, startMinute.Value);
            }

            if (endHour != null && endMinute != null)
            {
                datEndTime.SetTimeValue(endHour.Value, endMinute.Value);
            }

            txtDuration.Value = this.CalculateDuration(datStartTime.Value.Value, datEndTime.Value.Value);
       
        }

        /// <summary>
        /// 
        /// </summary>
        private void SetReadOnlyControl()
        {
            this.txtShiftName.SetReadOnly(true);
            this.txtDuration1.SetReadOnly(true);
            this.txtDuration2.SetReadOnly(true);
            this.txtDuration3.SetReadOnly(true);
            this.txtDuration4.SetReadOnly(true);
            this.txtDuration5.SetReadOnly(true);
            this.txtDuration6.SetReadOnly(true);
        }

        /// <summary>
        /// 
        /// </summary>
        private void SetRestTimeList()
        {
            this.RestTimeList = new List<RestTime>();
            if (this.datStartTime1.Value != null && this.datEndTime1.Value != null)
            {
                RestTime row1 = new RestTime();
                row1.RestTimeSH = this.datStartTime1.Value.Value.Hour;
                row1.RestTimeSM = this.datStartTime1.Value.Value.Minute;
                row1.RestTimeEH = this.datEndTime1.Value.Value.Hour;
                row1.RestTimeEM = this.datEndTime1.Value.Value.Minute;
                RestTimeList.Add(row1);
            }

            if (this.datStartTime2.Value != null && this.datEndTime2.Value != null)
            {
                RestTime row2 = new RestTime();
                row2.RestTimeSH = this.datStartTime2.Value.Value.Hour;
                row2.RestTimeSM = this.datStartTime2.Value.Value.Minute;
                row2.RestTimeEH = this.datEndTime2.Value.Value.Hour;
                row2.RestTimeEM = this.datEndTime2.Value.Value.Minute;
                RestTimeList.Add(row2);
            }

            if (this.datStartTime3.Value != null && this.datEndTime3.Value != null)
            {
                RestTime row3 = new RestTime();
                row3.RestTimeSH = this.datStartTime3.Value.Value.Hour;
                row3.RestTimeSM = this.datStartTime3.Value.Value.Minute;
                row3.RestTimeEH = this.datEndTime3.Value.Value.Hour;
                row3.RestTimeEM = this.datEndTime3.Value.Value.Minute;
                RestTimeList.Add(row3);
            }

            if (this.datStartTime4.Value != null && this.datEndTime4.Value != null)
            {
                RestTime row4 = new RestTime();
                row4.RestTimeSH = this.datStartTime4.Value.Value.Hour;
                row4.RestTimeSM = this.datStartTime4.Value.Value.Minute;
                row4.RestTimeEH = this.datEndTime4.Value.Value.Hour;
                row4.RestTimeEM = this.datEndTime4.Value.Value.Minute;
                RestTimeList.Add(row4);
            }

            if (this.datStartTime5.Value != null && this.datEndTime5.Value != null)
            {
                RestTime row5 = new RestTime();
                row5.RestTimeSH = this.datStartTime5.Value.Value.Hour;
                row5.RestTimeSM = this.datStartTime5.Value.Value.Minute;
                row5.RestTimeEH = this.datEndTime5.Value.Value.Hour;
                row5.RestTimeEM = this.datEndTime5.Value.Value.Minute;
                RestTimeList.Add(row5);
            }

            if (this.datStartTime6.Value != null && this.datEndTime6.Value != null)
            {
                RestTime row6 = new RestTime();
                row6.RestTimeSH = this.datStartTime6.Value.Value.Hour;
                row6.RestTimeSM = this.datStartTime6.Value.Value.Minute;
                row6.RestTimeEH = this.datEndTime6.Value.Value.Hour;
                row6.RestTimeEM = this.datEndTime6.Value.Value.Minute;
                RestTimeList.Add(row6);
            }

           
        }

        /// <summary>
        /// Create RestTime Model
        /// </summary>
        /// <param name="restTime">RestTime model</param>
        /// <returns></returns>
        private void CreateRestTimeModel(ref M_RestTime restTime)
        {
            //RestTime 1
            if (this.datStartTime1.Value != null)
            {
                restTime.RestTimeSH1 = this.datStartTime1.Value.Value.Hour;
                restTime.RestTimeSM1 = this.datStartTime1.Value.Value.Minute;
            }

            if (this.datEndTime1.Value != null)
            {
                restTime.RestTimeEH1 = this.datEndTime1.Value.Value.Hour;
                restTime.RestTimeEM1 = this.datEndTime1.Value.Value.Minute;
            }

            //RestTime 2
            if (this.datStartTime2.Value != null)
            {
                restTime.RestTimeSH2 = this.datStartTime2.Value.Value.Hour;
                restTime.RestTimeSM2 = this.datStartTime2.Value.Value.Minute;
            }

            if (this.datEndTime2.Value != null)
            {
                restTime.RestTimeEH2 = this.datEndTime2.Value.Value.Hour;
                restTime.RestTimeEM2 = this.datEndTime2.Value.Value.Minute;
            }

            //RestTime 3
            if (this.datStartTime3.Value != null)
            {
                restTime.RestTimeSH3 = this.datStartTime3.Value.Value.Hour;
                restTime.RestTimeSM3 = this.datStartTime3.Value.Value.Minute;
            }

            if (this.datEndTime3.Value != null)
            {
                restTime.RestTimeEH3 = this.datEndTime3.Value.Value.Hour;
                restTime.RestTimeEM3 = this.datEndTime3.Value.Value.Minute;
            }

            //RestTime 4
            if (this.datStartTime4.Value != null)
            {
                restTime.RestTimeSH4 = this.datStartTime4.Value.Value.Hour;
                restTime.RestTimeSM4 = this.datStartTime4.Value.Value.Minute;
            }

            if (this.datEndTime4.Value != null)
            {
                restTime.RestTimeEH4 = this.datEndTime4.Value.Value.Hour;
                restTime.RestTimeEM4 = this.datEndTime4.Value.Value.Minute;
            }

            //RestTime 5
            if (this.datStartTime5.Value != null)
            {
                restTime.RestTimeSH5 = this.datStartTime5.Value.Value.Hour;
                restTime.RestTimeSM5 = this.datStartTime5.Value.Value.Minute;
            }

            if (this.datEndTime5.Value != null)
            {
                restTime.RestTimeEH5 = this.datEndTime5.Value.Value.Hour;
                restTime.RestTimeEM5 = this.datEndTime5.Value.Value.Minute;
            }

            //RestTime 6
            if (this.datStartTime6.Value != null)
            {
                restTime.RestTimeSH6 = this.datStartTime6.Value.Value.Hour;
                restTime.RestTimeSM6 = this.datStartTime6.Value.Value.Minute;
            }

            if (this.datEndTime6.Value != null)
            {
                restTime.RestTimeEH6 = this.datEndTime6.Value.Value.Hour;
                restTime.RestTimeEM6 = this.datEndTime6.Value.Value.Minute;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="db"></param>
        /// <returns></returns>
        private M_Work_Shift CreateWorkShiftModel(DB db, ref M_Work_Shift shift)
        {
            if (shift != null)
            {

                TimeSpan calDurationResult;
                this.SetRestTimeList();
                if (this.RestTimeList != null && this.RestTimeList.Count > 0)
                {
                    IList<RestTime> list = this.RestTimeList.OrderBy(item => item.RestTimeSH).ThenBy(item1 => item1.RestTimeSM).ThenBy(item2 => item2.RestTimeEH).ThenBy(item3 => item3.RestTimeEM).ToList();
                    this.RestTimeList = list;
                }
                if (shift.StartHour != null && shift.StartMinute != null && shift.EndHour != null && shift.EndMinute != null)
                {
                    DateTime startTime = new DateTime(1, 1, 1, shift.StartHour.Value, shift.StartMinute.Value, 1);
                    DateTime endTime = new DateTime(1, 1, 1, shift.EndHour.Value, shift.EndMinute.Value, 1);
                    if (this.RestTimeList != null)
                    {
                        calDurationResult = CommonService.CalDurationWorkTime(startTime, endTime, this.RestTimeList);
                        shift.DurationHour = calDurationResult.Hours;
                        shift.DurationMinute = calDurationResult.Minutes;
                    }
                    
                }
                else 
                {
                    shift.DurationHour = null;
                    shift.DurationHour = null;
                }
            }
            shift.UpdateDate = (DateTime)this.OldUpdateDateOfShift;
            shift.UpdateUID = this.LoginInfo.User.ID;

            return shift;          
        }

       /// <summary>
        /// Calculate Duration
       /// </summary>
        /// <param name="startTime">StartTime</param>
        /// <param name="endTime">EndTime</param>
       /// <returns></returns>
        private string CalculateDuration(DateTime startTime,DateTime endTime)
        {
            if (startTime != null && endTime != null)
            {
                string start = string.Format("{0:00}:{1:00}", startTime.Hour, startTime.Minute);
                string end = string.Format("{0:00}:{1:00}", endTime.Hour, endTime.Minute);

                DateTime sTime = DateTime.ParseExact(start, Constants.FMT_HOUR, CultureInfo.InvariantCulture);
                DateTime eTime = DateTime.ParseExact(end, Constants.FMT_HOUR, CultureInfo.InvariantCulture);
                TimeSpan duration = eTime.Subtract(sTime);

                if (duration.TotalMinutes > 0)
                {
                    return string.Format("{0:00}:{1:00}", duration.Hours, duration.Minutes);
                }else
                {
                    return null;
                }
            }
            else
            {
                return null;
            }
            
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Get Shift Name By Shift Code
        /// </summary>
        /// <param name="in1">in1</param>
        /// <returns>Shift Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetShiftName(int in1)
        {
            var shiftCd = in1;
            try
            {
                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    M_Work_Shift model = shiftSer.GetByShiftCode(shiftCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            shiftCode = shiftCd,
                            shiftName = model.ShiftName
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var shift = new
                    {
                        shiftCode = shiftCd
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(shift);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Calculate Duration
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalDuration(string startTime, string endTime)
        {
            try
            {
                if (string.IsNullOrEmpty(startTime) || string.IsNullOrEmpty(startTime))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>("");
                }

                DateTime sTime = DateTime.ParseExact(startTime, Constants.FMT_HOUR, CultureInfo.InvariantCulture);
                DateTime eTime = DateTime.ParseExact(endTime, Constants.FMT_HOUR, CultureInfo.InvariantCulture);
                if (sTime > eTime)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>("");
                }

                TimeSpan duration = eTime.Subtract(sTime);
                if (duration.TotalMinutes > 0)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(string.Format("{0:00}:{1:00}", duration.Hours, duration.Minutes));
                }else
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>("");
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
          
        }

        #endregion
       
    }
}
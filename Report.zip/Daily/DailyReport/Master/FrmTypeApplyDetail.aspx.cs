﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;
using System.Data.SqlClient;

namespace DailyReport.Master
{
    public partial class FrmTypeApplyDetail : FrmBaseDetail
    {

        #region Constants
        private const string URL_LIST = "~/Master/FrmTypeApplyList.aspx";
        private int _defaultUnitMinute = 0;//Saving default of Unit Minute.
        #endregion

        #region Property

        /// <summary>
        /// Get or set UserID
        /// </summary>
        public int ID
        {
            get { return (int)ViewState["ID"]; }
            set { ViewState["ID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Method

        /// <summary>
        /// Get Minute Range
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void GetMinuteRange()
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                //Unit Minute
                this._defaultUnitMinute = int.Parse(configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_UNIT_MINUTE));
            }
        }

        /// <summary>
        /// Init DropDownList Minute
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void InitDropDownListMinute()
        {
            int init = 0;

            this.cmbMinStartMinute.Items.Clear();
            this.cmbMinStartMinute.Items.Insert(0, new ListItem("------", "-1"));

            this.cmbMaxEndMinute.Items.Clear();
            this.cmbMaxEndMinute.Items.Insert(0, new ListItem("------", "-1"));

            for (int i = 1; init < 60; i++)
            {
                this.cmbMinStartMinute.Items.Insert(i, new ListItem(init.ToString("00"), init.ToString()));
                this.cmbMaxEndMinute.Items.Insert(i, new ListItem(init.ToString("00"), init.ToString()));
                init += _defaultUnitMinute;
            }
        }

        /// <summary>
        /// Init DropDownList Hour
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void InitDropDownListHour()
        {
            this.cmbMinStartHour.Items.Clear();
            this.cmbMinStartHour.Items.Insert(0, new ListItem("------", "-1"));

            this.cmbMaxEndHour.Items.Clear();
            this.cmbMaxEndHour.Items.Insert(0, new ListItem("------", "-1"));

            for (int i = 1; i <= 24; i++)
            {
                this.cmbMinStartHour.Items.Insert(i, new ListItem((i - 1).ToString("00"), (i - 1).ToString()));
                this.cmbMaxEndHour.Items.Insert(i, new ListItem((i - 1).ToString("00"), (i - 1).ToString()));
            }
        }


        /// <summary>
        /// Init all DropDownList
        /// </summary>
        /// <param name="headerID">Header ID</param>
        private void InitDropDownList()
        {
            //Init DropDownList FormID
            this.cmbFormID.Items.Clear();
            this.cmbFormID.Items.Insert(0, new ListItem("Apply", ((int)TypeFormID.Apply).ToString()));
            this.cmbFormID.Items.Insert(1, new ListItem("Vacation", ((int)TypeFormID.Vacation).ToString()));

            //Init DropDownList Vacation
            this.cmbVacation.Items.Clear();
            this.cmbVacation.Items.Insert(0, new ListItem("None", ((int)SubVacation.None).ToString()));
            this.cmbVacation.Items.Insert(1, new ListItem("Deducting Salary", ((int)SubVacation.DeductingSalary).ToString()));
            this.cmbVacation.Items.Insert(2, new ListItem("Deducting Day Off", ((int)SubVacation.DeductingDayOff).ToString()));

            //Init DropDownList about Hour
            InitDropDownListHour();

            //Init DropDownList about Minute
            InitDropDownListMinute();
        }

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            this.GetMinuteRange();

            ////Set Title
            base.FormTitle = "Type Apply Detail";
            base.FormSubTitle = "Detail";

            ////Init Max Length
            this.txtName.MaxLength = M_TypeApply.TYPE_APPLY_NAME_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        private void ProcessMode(Mode mode)
        {
            bool enable;
            bool cmbenable;
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtName.ReadOnly = true;
                        this.cmbFormID.Enabled = true;
                        this.cmbVacation.Enabled = true;
                        this.cmbMinStartHour.Enabled = true;
                        this.cmbMinStartHour.Enabled = true;
                        this.cmbMaxEndHour.Enabled = true;
                        this.cmbMaxEndMinute.Enabled = true;
                    }
                    else
                    {
                        this.txtName.ReadOnly = false;
                        this.cmbFormID.Enabled = false;
                        this.cmbVacation.Enabled = false;
                        this.cmbMinStartHour.Enabled = false;
                        this.cmbMinStartHour.Enabled = false;
                        this.cmbMaxEndHour.Enabled = false;
                        this.cmbMaxEndMinute.Enabled = false;
                    }

                    enable = false;
                    cmbenable = true;
                    break;

                default:

                    this.txtName.ReadOnly = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                    enable = true;
                    cmbenable = false;
                    break;
            }

            //Lock control
            this.txtName.ReadOnly = enable;     //
            this.cmbFormID.Enabled = cmbenable;
            this.cmbVacation.Enabled = cmbenable;
            this.cmbMinStartHour.Enabled = cmbenable;
            this.cmbMinStartMinute.Enabled = cmbenable;
            this.cmbMaxEndHour.Enabled = cmbenable;
            this.cmbMaxEndMinute.Enabled = cmbenable;
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(M_TypeApply typeapply)
        {
            ////Show data
            if (typeapply != null)
            {
                //M_Route_H routeH = new M_Route_H();

                //using (DB db = new DB())
                //{
                //    Route_HService routeSer = new Route_HService(db);
                //    routeH = routeSer.GetByID(typeapply.RouteID);
                //}

                this.txtName.Value = typeapply.TypeName;
                this.cmbFormID.SelectedValue = typeapply.FormID.ToString();

                this.cmbMinStartHour.SelectedValue = typeapply.MinStartHour.ToString();
                this.cmbMinStartMinute.SelectedValue = typeapply.MinStartMinute.ToString();
                this.cmbMaxEndHour.SelectedValue = typeapply.MaxEndHour.ToString();
                this.cmbMaxEndMinute.SelectedValue = typeapply.MaxEndMinute.ToString();

                //Save UserID and UpdateDate
                this.ID = typeapply.ID;
                this.OldUpdateDate = typeapply.UpdateDate;
            }
        }

        /// <summary>
        /// Get route by routeID
        /// </summary>
        /// <param name="groupCD"></param>
        /// <returns></returns>
        private M_Route_H GetRoute(string routeCD)
        {
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);

                //Get Group User
                return routeSer.GetByRouteCD(routeCD);
            }
        }

        /// <summary>
        /// Get TypeApply BY ID
        /// </summary>
        /// <param name="holidayID">HolidayID</param>
        /// <returns>User</returns>
        private M_TypeApply GetTypeApply(int ID)
        {
            using (DB db =new DB())
            {
                TypeApplyService typeApplySer = new TypeApplyService(db);

                //Get TypeApply
                return typeApplySer.GetByID(ID);    
            }            
        }

        /// <summary>
        /// Check DropDownList
        /// </summary>
        private void CheckDropDownList(DropDownList a, string name1, DropDownList b, string name2)
        {
            if (a.SelectedValue == "-1" && b.SelectedValue != "-1")
            {
                this.SetMessage(a.ID, M_Message.MSG_REQUIRE, name1);
            }

            if (b.SelectedValue == "-1" && a.SelectedValue != "-1")
            {
                this.SetMessage(b.ID, M_Message.MSG_REQUIRE, name2);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            using (DB db = new DB())
            {
                //Name
                if (this.txtName.IsEmpty)
                {
                    this.SetMessage(this.txtName.ID, M_Message.MSG_REQUIRE, "Type Apply Name");
                }

                //Check DropDownList
                CheckDropDownList(this.cmbMinStartHour, "Min Start Hour", this.cmbMinStartMinute, "Min Start Minute");
                CheckDropDownList(this.cmbMaxEndHour, "Max End Hour", this.cmbMaxEndMinute, "Max End Minute");

            }
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_TypeApply typeapply = new M_TypeApply();
                typeapply.TypeName = this.txtName.Value;
                typeapply.FormID = int.Parse(cmbFormID.SelectedValue.ToString());
                typeapply.MinStartHour = int.Parse(cmbMinStartHour.SelectedValue.ToString());
                typeapply.MinStartMinute = int.Parse(cmbMinStartMinute.SelectedValue.ToString());
                typeapply.MaxEndHour = int.Parse(cmbMaxEndHour.SelectedValue.ToString());
                typeapply.MaxEndMinute = int.Parse(cmbMaxEndMinute.SelectedValue.ToString());
                typeapply.CreateUID = this.LoginInfo.User.ID;
                typeapply.UpdateUID = this.LoginInfo.User.ID;

                //Insert Type Apply
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    TypeApplyService typeapplySer = new TypeApplyService(db);
                    Route_HService routeSer = new Route_HService(db);

                    //Insert User
                    typeapplySer.Insert(typeapply);
                    this.ID = db.GetIdentityId<M_TypeApply>();
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_TypeApply typeapply = this.GetTypeApply(this.ID);
                if (typeapply != null)
                {
                    //Create model
                    typeapply.ID = this.ID;
                    typeapply.TypeName = this.txtName.Value;

                    typeapply.FormID = int.Parse(cmbFormID.SelectedValue.ToString());

                    typeapply.MinStartHour = int.Parse(cmbMinStartHour.SelectedValue.ToString());
                    typeapply.MinStartMinute = int.Parse(cmbMinStartMinute.SelectedValue.ToString());
                    typeapply.MaxEndHour = int.Parse(cmbMaxEndHour.SelectedValue.ToString());
                    typeapply.MaxEndMinute = int.Parse(cmbMaxEndMinute.SelectedValue.ToString());

                    typeapply.UpdateDate = this.OldUpdateDate;
                    typeapply.UpdateUID = this.LoginInfo.User.ID;
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        //Update Type Apply

                        TypeApplyService typeapplySer = new TypeApplyService(db);

                        //Update Type Apply
                        if (typeapply.Status == DataStatus.Changed)
                        {
                            ret = typeapplySer.Update(typeapply);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns></returns>
        private bool Delete()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    TypeApplyService typeApplySer = new TypeApplyService(db);
                    ret = typeApplySer.Delete(this.ID, this.OldUpdateDate);

                    if (ret > 0)
                    {
                        db.Commit();
                    }
                }

                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.T_Approve_FK_TypeApplyID))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Type Apply " + this.txtName.Value);
                }

                if (ex.Message.Contains(Models.Constant.T_Daily_FK_TypeApplyID))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "Type Apply " + this.txtName.Value);
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }
            return true;
        }

        #endregion

        #region Event
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.TypeApply);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            if (!this.IsPostBack)
            {                
                this.InitDropDownList();
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get User ID
                        this.ID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_TypeApply typeapply = this.GetTypeApply(this.ID);

                        //Check user
                        if (typeapply != null)
                        {
                            //Show data
                            this.ShowData(typeapply);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            M_TypeApply typeapply = this.GetTypeApply(this.ID);

            if (typeapply != null)
            {

                //Show data
                this.ShowData(typeapply);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Delete:
                    //Delete type apply
                    if (!this.Delete())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {

                        M_TypeApply typeapply = this.GetTypeApply(this.ID);

                        //Show data
                        this.ShowData(typeapply);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        M_TypeApply typeapply = this.GetTypeApply(this.ID);

                        //Show data
                        this.ShowData(typeapply);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;

            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.txtName.Value = string.Empty;
            this.cmbFormID.SelectedIndex = 0;
            this.cmbVacation.SelectedIndex = 0;
            this.cmbMinStartHour.SelectedIndex = 0;
            this.cmbMinStartMinute.SelectedIndex = 0;
            this.cmbMaxEndHour.SelectedIndex = 0;
            this.cmbMaxEndMinute.SelectedIndex = 0;

            //Set mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get User
            M_TypeApply typeapply = this.GetTypeApply(this.ID);

            //Check typeapply
            if (typeapply != null)
            {
                //Show data
                this.ShowData(typeapply);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }


        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get User
            M_TypeApply typeapply = this.GetTypeApply(this.ID);

            //Check user
            if (typeapply != null)
            {
                //Show data
                this.ShowData(typeapply);

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Insert Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Update Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Holiday
            M_TypeApply typeApp = this.GetTypeApply(this.ID);

            //Check Holiday
            if (typeApp != null)
            {
                //Show data
                this.ShowData(typeApp);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        #endregion

        #region Web Methods

        /// <summary>
        /// Get Group Name By Group Code
        /// </summary>
        /// <param name="routeCd">Group Code</param>
        /// <returns>Group Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetRouteName(string in1)
        {
            var routeCd = in1;
            var routeCdShow = in1;
            routeCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(routeCd, M_Route_H.ROUTE_CODE_MAX_LENGTH);
            routeCdShow = EditDataUtil.ToFixCodeShow(routeCd, M_Route_H.ROUTE_CODE_MAX_LENGTH);

            try
            {
                using (DB db = new DB())
                {
                    Route_HService routeSer = new Route_HService(db);
                    M_Route_H model = routeSer.GetByRouteCD(routeCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            routeCD = routeCdShow,
                            routeNm = model.RouteName
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var routeCD = new
                    {
                        routeCD = routeCdShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(routeCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

    }
}
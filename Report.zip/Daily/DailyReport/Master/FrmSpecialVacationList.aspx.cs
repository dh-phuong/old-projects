﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Xml;
using System.Data;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// TRAM - 2015/06/10
    /// FrmSpecialVacationList Form
    /// </summary>
    public partial class FrmSpecialVacationList : FrmBaseList
    {
        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Special Vacation Master";
            base.FormSubTitle = "List";

            // Header grid sort
            this.HeaderGrid.OnSortClick += this.Sort_Click;

            //// Paging footer
            this.PagingFooter.OnClick += this.PagingFooter_Click;

            //// Paging header
            this.PagingHeader.OnClick += this.PagingHeader_Click;
            this.PagingHeader.OnPagingClick += this.PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtSpVacationCD.MaxLength = M_SpecialVacation_H.SP_VACATION_CODE_MAX_LENGTH;
            this.txtSpVacationNameUS.MaxLength = M_SpecialVacation_H.SP_VACATION_NAME_MAX_LENGTH;
            this.txtSpVacationNameVN.MaxLength = M_SpecialVacation_H.SP_VACATION_NAME_MAX_LENGTH;
        }

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!base.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (base.PreviousPage != null)
                {
                    if (base.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)base.PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Event Search
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Click New button
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">CommandEventArgs</param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click Detail button
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">CommandEventArgs</param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //ID
            base.ViewState["ID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Change page in footer
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Change page in header
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click to sort list
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtSpVacationCD.ID, this.txtSpVacationCD.Value);
            hash.Add(this.txtSpVacationNameUS.ID, this.txtSpVacationNameUS.Value);
            hash.Add(this.txtSpVacationNameVN.ID, this.txtSpVacationNameVN.Value);
            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);
            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);
            ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Get condition Save
        /// </summary>
        /// <param name="data">Data</param>
        private void ShowCondition(Hashtable data)
        {
            this.txtSpVacationCD.Value = data[this.txtSpVacationCD.ID].ToString();
            this.txtSpVacationNameUS.Value = data[this.txtSpVacationNameUS.ID].ToString();
            this.txtSpVacationNameVN.Value = data[this.txtSpVacationNameVN.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;
            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        /// <summary>
        /// Init control
        /// </summary>
        private void InitData()
        {
            // Header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            //base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
        }

        /// <summary>
        /// Load data gird
        /// </summary>
        /// <param name="pageIndex">Page Index</param>
        /// <param name="numOnPage">Number On Page</param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int totalRow = 0;
            IList<SpVacationInfo> listSpVacationInfo;

            //Get data
            using (DB db = new DB())
            {
                SpVacation_HService spVacation_HService = new SpVacation_HService(db);

                //Get total row
                totalRow = spVacation_HService.GetTotalRow(this.txtSpVacationCD.Value, this.txtSpVacationNameUS.Value, this.txtSpVacationNameVN.Value);

                //Get list
                listSpVacationInfo = spVacation_HService.GetList(this.txtSpVacationCD.Value, this.txtSpVacationNameUS.Value, this.txtSpVacationNameVN.Value,
                                        pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (listSpVacationInfo.Count == 0)
            {
                this.rptVacationList.DataSource = null;
            }
            else
            {
                // Paging header
                this.PagingHeader.RowNumFrom = int.Parse(listSpVacationInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listSpVacationInfo[listSpVacationInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // Paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // Header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Code", "Special Vacation Name (VN)", "Special Vacation Name (EN)", "Effect Date", "Expire Date", "N#Num of Days" });

                // Detail
                this.rptVacationList.DataSource = listSpVacationInfo;
            }

            this.rptVacationList.DataBind();
        }

        #endregion
    }
}
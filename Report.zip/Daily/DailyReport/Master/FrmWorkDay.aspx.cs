﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;

using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// TRAM - 2015/05/29
    /// WorkingDay Form
    /// </summary>
    public partial class FrmWorkDay : FrmBaseDetail
    {
        #region Variable

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData = false;

        #endregion

        #region Property

        /// <summary>
        /// Get or set WorkingDateList
        /// </summary>
        public IList<WorkDayInfo> WorkingDateList
        {
            get { return (IList<WorkDayInfo>)ViewState["WorkingDateList"]; }
            set { ViewState["WorkingDateList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Work Day";
            base.FormSubTitle = "";
            base.IsHiddenModeLabel = true;

            // Header grid sort

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnNoProcessData);
        }

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.WorkingDay);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmWorksMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                this.InitData();
                this.LoadDataForGrid();
            }
        }

        /// <summary>
        /// View Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, CommandEventArgs e)
        {
            if (!this.dtWorkingMonth.IsEmpty)
            {
                base.DisabledLink(this.btnSubmit, false);
                this.hdnOldWorkingMonth.Value = this.dtWorkingMonth.Value.ToString();
            }

            if (!this.CheckInput(true, false))
            {
                base.DisabledLink(this.btnSubmit, true);
                return;
            }

            //Get data
            this.LoadDataForGrid();
        }

        /// <summary>
        /// btnLoadDefault_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnLoadDefault_Click(object sender, CommandEventArgs e)
        {
            if (!this.dtWorkingMonth.IsEmpty)
            {
                this.hdnOldWorkingMonth.Value = this.dtWorkingMonth.Value.ToString();
            }

            if (!this.CheckInput(true, false))
            {
                return;
            }

            TemplateWorkDayInfo workTemplate;
            using (DB db = new DB())
            {
                TemplateWorkDayService TempSer = new TemplateWorkDayService(db);
                workTemplate = TempSer.GetDataModel();
            }

            if (workTemplate != null)
            {
                this.LoadNewDataForGrid(workTemplate);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            if (!this.dtWorkingMonth.IsEmpty)
            {
                if (string.Format("{0:MM/yyyy}", this.hdnOldWorkingMonth.Value) != string.Format("{0:MM/yyyy}", this.dtWorkingMonth.Value))
                {
                    this.dtWorkingMonth.Value = DateTime.Parse(this.hdnOldWorkingMonth.Value);

                }
            }

            if (!CheckInput(false, true))
            {
                base.DisabledLink(this.btnSubmit, true);
                this.ReLoadDataForGrid();
                return;
            }
            this.ReLoadDataForGrid();
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptWorkingDayList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                ICodeTextBox txtShiftCode = (ICodeTextBox)e.Item.FindControl("txtShiftCode");
                ITextBox txtShiftName = (ITextBox)e.Item.FindControl("txtShiftName");

                HiddenField hdnWorkingDate = (HiddenField)e.Item.FindControl("hdnWorkingDate");
                DateTime workingDate = DateTime.Parse(hdnWorkingDate.Value);



                int? shiftCode = null;
                if (!txtShiftCode.IsEmpty)
                {
                    shiftCode = int.Parse(txtShiftCode.Value);
                    M_Work_Shift workShift = new M_Work_Shift();
                    using (DB db = new DB())
                    {
                        WorkShiftService workShiftSer = new WorkShiftService(db);
                        workShift = workShiftSer.GetByShiftCode(shiftCode.Value);
                    }

                    if (workShift != null)
                    {
                        if (workShift.TypeOfDay.Equals((int)TypeOfDay.DayOff))
                        {
                            txtShiftName.Attributes.Add("class", "text-color-danger form-control input-sm");
                        }
                        else
                        {
                            txtShiftName.Attributes.Add("class", "form-control input-sm");
                        }
                    }
                    else
                    {
                        txtShiftName.Attributes.Add("class", "form-control input-sm");
                    }
                }
                else
                {
                    txtShiftName.Attributes.Add("class", "form-control input-sm");
                }

                txtShiftName.SetReadOnly(true);
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {

            DateTime startDate = DateTime.Now;
            DateTime endDate = DateTime.Now;
            using (DB db = new DB())
            {
                this.GetDateToView(db, true, ref startDate, ref endDate);
            }
            if (DateTime.Now.Date > endDate.Date)
            {
                this.dtWorkingMonth.Value = endDate.AddMonths(1);
            }
            else if (DateTime.Now.Date < startDate.Date)
            {
                this.dtWorkingMonth.Value = endDate.AddMonths(-1);
            }
            else if (startDate.Date <= DateTime.Now.Date && DateTime.Now.Date <= endDate.Date)
            {
                this.dtWorkingMonth.Value = endDate;
            }

            if (!this.dtWorkingMonth.IsEmpty)
            {
                this.hdnOldWorkingMonth.Value = this.dtWorkingMonth.Value.ToString();
            }
        }

        private WorkDayInfo SetDataRow(ref DateTime startDate, ref DateTime? holidayDate, ref M_Holiday holiday, TemplateWorkDayInfo info = null)
        {
            WorkDayInfo item = new WorkDayInfo();
            DateTime currDate = startDate;

            item.WorkDate = currDate;
            if (holidayDate == null)
            {
                holiday = this.GetHoliday(currDate);
            }

            if (holiday != null && currDate.DayOfWeek == DayOfWeek.Sunday && holiday.Replace == 1)
            {
                //holidayDate = holiday.Date;
                holidayDate = holiday.Date.AddDays(1);
            }

            if ((holiday != null) || (currDate.DayOfWeek == DayOfWeek.Sunday) || (holidayDate != null && currDate == holidayDate))
            {
                item.WorkDateStr = "<span class='negative-num'>" + string.Format("{0:dd/MM/yyyy}", currDate) + "</span>";
                item.Day = "<span class='negative-num'>" + currDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
                if (holidayDate != null && currDate == holidayDate)
                {
                    holidayDate = null;
                }

            }
            else
            {
                if (currDate.DayOfWeek == DayOfWeek.Saturday)
                {
                    item.WorkDateStr = "<span class='text-primary'>" + string.Format("{0:dd/MM/yyyy}", currDate) + "</span>";
                    item.Day = "<span class='text-primary'>" + currDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
                }
                else
                {
                    item.WorkDateStr = string.Format("{0:dd/MM/yyyy}", currDate);
                    item.Day = currDate.DayOfWeek.ToString().Substring(0, 3);
                }
            }

            if (info != null)
            {
                switch (item.WorkDate.DayOfWeek)
                {
                    case DayOfWeek.Friday:
                        if (info.FriShiftCD != -1)
                        {
                            item.ShiftCode = info.FriShiftCD;
                        }
                        item.ShiftCodeStr = info.FriShiftCD.ToString();
                        item.ShiftName = info.FriShiftName;
                        break;
                    case DayOfWeek.Monday:
                        if (info.MonShiftCD != -1)
                        {
                            item.ShiftCode = info.MonShiftCD;
                        }
                        item.ShiftCodeStr = info.MonShiftCD.ToString();
                        item.ShiftName = info.MonShiftName;
                        break;
                    case DayOfWeek.Saturday:
                        if (info.SatShiftCD != -1)
                        {
                            item.ShiftCode = info.SatShiftCD;
                        }
                        item.ShiftCodeStr = info.SatShiftCD.ToString();
                        item.ShiftName = info.SatShiftName;
                        break;
                    case DayOfWeek.Sunday:
                        if (info.SunShiftCD != -1)
                        {
                            item.ShiftCode = info.SunShiftCD;
                        }
                        item.ShiftCodeStr = info.SunShiftCD.ToString();
                        item.ShiftName = info.SunShiftName;
                        break;
                    case DayOfWeek.Thursday:
                        if (info.ThuShiftCD != -1)
                        {
                            item.ShiftCode = info.ThuShiftCD;
                        }
                        item.ShiftCodeStr = info.ThuShiftCD.ToString();
                        item.ShiftName = info.ThuShiftName;
                        break;
                    case DayOfWeek.Tuesday:
                        if (info.TueShiftCD != -1)
                        {
                            item.ShiftCode = info.TueShiftCD;
                        }
                        item.ShiftCodeStr = info.TueShiftCD.ToString();
                        item.ShiftName = info.TueShiftName;
                        break;
                    case DayOfWeek.Wednesday:
                        if (info.WedShiftCD != -1)
                        {
                            item.ShiftCode = info.WedShiftCD;
                        }
                        item.ShiftCodeStr = info.WedShiftCD.ToString();
                        item.ShiftName = info.WedShiftName;
                        break;
                }
            }
            else
            {
                item.ShiftCode = null;
                item.ShiftCodeStr = string.Empty;
                item.ShiftName = string.Empty;
            }
            return item;

        }

        /// <summary>
        /// 
        /// </summary>
        private void ReLoadDataForGrid()
        {

            IList<WorkDayInfo> listData = this.GetDataGrid();
            if (listData != null && listData.Count > 0)
            {
                this.rptWorkingDayList.DataSource = listData;
                this.rptWorkingDayList.DataBind();
                this.isHasData = true;
            }
        }

        /// <summary>
        /// LoadDataForFrid
        /// </summary>
        private void LoadDataForGrid()
        {

            IList<WorkDayInfo> workingDateList = new List<WorkDayInfo>();
            DateTime startDate = DateTime.Now;
            DateTime endDate = DateTime.Now;
            workingDateList = this.GetListByWorkingDate(ref startDate, ref endDate);
            DateTime? holidayDate = null;
            DateTime prevDate = startDate.AddDays(-1);
            M_Holiday holiday = new M_Holiday();

            IList<WorkDayInfo> lstInfo = new List<WorkDayInfo>();

            holiday = this.GetHoliday(prevDate);
            if (holiday != null && holiday.Replace == 1 && holiday.Date.DayOfWeek == DayOfWeek.Sunday)
            {
                holidayDate = startDate;
            }

            while (startDate <= endDate)
            {
                WorkDayInfo workDayInfo = (from row in workingDateList
                                           where row.WorkDate == startDate
                                           select row).SingleOrDefault();

                if (workDayInfo == null)
                {
                    WorkDayInfo item = new WorkDayInfo();
                    DateTime currDate = startDate;
                    item = this.SetDataRow(ref currDate, ref holidayDate, ref holiday);
                    lstInfo.Add(item);
                }
                else
                {
                    lstInfo.Add(workDayInfo);
                    holidayDate = null;
                }
                startDate = startDate.AddDays(1);
                //holidayDate = null;
            }
            this.WorkingDateList = workingDateList;
            if (workingDateList != null && workingDateList.Count > 0)
            {
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    lstInfo[i].No = i + 1;
                }
                this.rptWorkingDayList.DataSource = lstInfo;
                this.rptWorkingDayList.DataBind();
                this.isHasData = true;
            }
            else
            {
                this.LoadNewDataForGrid();
            }
        }

        /// <summary>
        /// LoadNewDataForGrid
        /// </summary>
        private void LoadNewDataForGrid(TemplateWorkDayInfo info = null)
        {
            DateTime workingDate = this.dtWorkingMonth.Value.Value;
            DateTime endDate;
            DateTime? holidayDate = null;
            int closingDay = 0;
            M_Accounting account = new M_Accounting();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                account = accSer.GetData();
            }

            if (account != null)
            {
                closingDay = account.ClosingDay;
            }

            int daysInMonth = DateTime.DaysInMonth(workingDate.Year, workingDate.Month);

            if (daysInMonth < closingDay)
            {
                endDate = new DateTime(workingDate.Year, workingDate.Month, daysInMonth);
            }
            else
            {
                endDate = new DateTime(workingDate.Year, workingDate.Month, closingDay);
            }

            DateTime startDate = endDate.AddMonths(-1).AddDays(1);

            DateTime prevDate = startDate.AddDays(-1);
            M_Holiday holiday = new M_Holiday();
            holiday = this.GetHoliday(prevDate);
            if (holiday != null && holiday.Replace == 1 && holiday.Date.DayOfWeek == DayOfWeek.Sunday)
            {
                holidayDate = startDate;
            }

            while (startDate.Day <= closingDay && startDate.Month != endDate.Month)
            {
                startDate = startDate.AddDays(1);
            }

            IList<WorkDayInfo> lstInfo = new List<WorkDayInfo>();
            while (startDate <= endDate)
            {

                WorkDayInfo item = new WorkDayInfo();
                DateTime currDate = startDate;
                item = this.SetDataRow(ref currDate, ref holidayDate, ref holiday, info);

                lstInfo.Add(item);
                startDate = startDate.AddDays(1);
            }

            if (lstInfo != null && lstInfo.Count > 0)
            {
                for (int i = 0; i < lstInfo.Count; i++)
                {
                    lstInfo[i].No = i + 1;
                }
                this.isHasData = true;
            }
            else
            {
                this.isHasData = false;
            }

            this.rptWorkingDayList.DataSource = lstInfo;
            this.rptWorkingDayList.DataBind();
        }

        /// <summary>
        /// btnProcessData
        /// </summary>
        private void btnProcessData(object sender, EventArgs e)
        {
            if (!this.IsExistedData())
            {
                if (this.Insert())
                {
                    //Show data
                    this.LoadDataForGrid();
                    //Set Success
                    this.Success = true;
                }
                else
                {
                    this.ReLoadDataForGrid();
                }
            }
            else
            {
                if (this.Update())
                {
                    //Show data
                    this.LoadDataForGrid();

                    //Set Success
                    this.Success = true;
                }
                else
                {
                    this.ReLoadDataForGrid();
                }
            }
        }

        /// btnNoProcessData
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNoProcessData(object sender, EventArgs e)
        {
            this.ReLoadDataForGrid();
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <returns></returns>
        private bool Insert()
        {
            try
            {
                int ret = 0;
                var listDetail = this.GetDataGrid();
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    for (int i = 0; i < listDetail.Count; i++)
                    {
                        WorkDayService workingDateSer = new WorkDayService(db);
                        M_Work_Day workingD = new M_Work_Day();

                        WorkDayInfo item = listDetail[i];
                        workingD.WorkDate = item.WorkDate;
                        WorkShiftService workingSSer = new WorkShiftService(db);
                        M_Work_Shift workingS = workingSSer.GetByShiftCode(item.ShiftCode);
                        if (workingS != null)
                        {
                            workingD.ShiftID = workingS.ID;
                        }
                        workingD.CreateUID = this.LoginInfo.User.ID;
                        workingD.UpdateUID = this.LoginInfo.User.ID;
                        ret = workingDateSer.Insert(workingD);
                        Log.Instance.WriteLog("bool Insert():" + ret.ToString(), LogType.Debug);
                    }
                    if (ret == 0)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            return true;

        }

        /// <summary>
        /// Update
        /// </summary>
        /// <returns></returns>
        private bool Update()
        {
            try
            {
                int ret = 0;
                var listDetail = this.GetDataGrid();
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    for (int i = 0; i < listDetail.Count; i++)
                    {
                        WorkDayService workingDateSer = new WorkDayService(db);
                        M_Work_Day workingDNew = new M_Work_Day();
                        M_Work_Day dataInDatabase = new M_Work_Day();

                        WorkDayInfo item = listDetail[i];
                        dataInDatabase = workingDateSer.GetByWorkDate(item.WorkDate);

                        //Existed=> Update data
                        if (dataInDatabase != null)
                        {
                            if (this.WorkingDateList != null && this.WorkingDateList.Count > 0)
                            {
                                WorkDayInfo workingDBeforeUpdate = (from row in this.WorkingDateList
                                                                    where row.ID == dataInDatabase.ID
                                                                    select row).FirstOrDefault();

                                if (workingDBeforeUpdate != null)
                                {
                                    if ((DateTime)dataInDatabase.UpdateDate != (DateTime)workingDBeforeUpdate.UpdateDate)
                                    {
                                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                        return false;
                                    }

                                    WorkShiftService workingSSer = new WorkShiftService(db);
                                    M_Work_Shift workingS = workingSSer.GetByShiftCode(item.ShiftCode);
                                    if (workingS != null)
                                    {
                                        if (workingS.ID != dataInDatabase.ShiftID)
                                        {
                                            workingDNew.ID = dataInDatabase.ID;
                                            workingDNew.ShiftID = workingS.ID;
                                            workingDNew.UpdateDate = (DateTime)workingDBeforeUpdate.UpdateDate;
                                            workingDNew.UpdateUID = this.LoginInfo.User.ID;
                                            ret = workingDateSer.Update(workingDNew);

                                            if (ret == 0)
                                            {
                                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                                return false;
                                            }

                                        }
                                    }
                                }

                            }
                            Log.Instance.WriteLog("bool Insert():" + ret.ToString(), LogType.Debug);
                        }
                        else // Not Existed= Insert into data
                        {

                            M_Work_Day workingD = new M_Work_Day();

                            workingD.WorkDate = item.WorkDate;
                            WorkShiftService workingSSer = new WorkShiftService(db);
                            M_Work_Shift workingS = workingSSer.GetByShiftCode(item.ShiftCode);
                            if (workingS != null)
                            {
                                workingD.ShiftID = workingS.ID;
                            }
                            workingD.CreateUID = this.LoginInfo.User.ID;
                            workingD.UpdateUID = this.LoginInfo.User.ID;
                            ret = workingDateSer.Insert(workingD);
                            if (ret == 0)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                            Log.Instance.WriteLog("bool Insert():" + ret.ToString(), LogType.Debug);
                        }

                    }
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.ReLoadDataForGrid();
                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            return true;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workingDate"></param>
        /// <returns></returns>
        private M_Holiday GetHoliday(DateTime workingDate)
        {
            M_Holiday holiday;
            using (DB db = new DB())
            {
                HolidayService holidaySer = new HolidayService(db);
                holiday = holidaySer.GetByDay(workingDate);
            }

            return holiday;
        }

        /// <summary>
        /// IsExistedData
        /// </summary>
        /// <returns></returns>
        private bool IsExistedData()
        {
            int count = 0;
            if (this.dtWorkingMonth.Value != null)
            {
                using (DB db = new DB())
                {
                    WorkDayService workingSer = new WorkDayService(db);
                    DateTime workingDate = this.dtWorkingMonth.Value.Value;
                    DateTime endDate = DateTime.Now;
                    DateTime startDate = DateTime.Now;

                    this.GetDateToView(db, false, ref startDate, ref endDate);
                    count = workingSer.GetCountByWorkDate(startDate, endDate);
                }
            }
            return count > 0;
        }

        /// <summary>
        /// Check Inputting
        /// </summary>
        /// <returns></returns>
        private bool CheckInput(bool isView = true, bool isRegist = false)
        {
            if (isView || isRegist)
            {
                if (this.dtWorkingMonth.Value == null)
                {

                    this.SetMessage(this.dtWorkingMonth.ID, M_Message.MSG_REQUIRE, "Work Month");
                }
            }

            if (isRegist)
            {
                var listDetail = this.GetDataGrid();
                for (int i = 0; i < listDetail.Count; i++)
                {
                    int rowIndex = i + 1;
                    var item = listDetail[i];
                    if (item.ShiftCode == null)
                    {
                        base.SetMessage(string.Format("txtShiftCode_{0}", i), M_Message.MSG_REQUIRE_GRID, "Shift Code", rowIndex);
                    }
                    else
                    {
                        using (DB db = new DB())
                        {
                            WorkShiftService workingSSer = new WorkShiftService(db);

                            M_Work_Shift workingShift = workingSSer.GetByShiftCode(item.ShiftCode);
                            if (workingShift == null)
                            {
                                base.SetMessage(string.Format("txtShiftCode_{0}", i), M_Message.MSG_NOT_EXIST_CODE_GRID, "Shift Code", rowIndex);
                            }
                        }

                    }

                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<WorkDayInfo> GetListByWorkingDate(ref DateTime startDate, ref DateTime endDate)
        {
            IList<WorkDayInfo> workingDateList = new List<WorkDayInfo>();
            if (this.dtWorkingMonth.Value != null)
            {
                using (DB db = new DB())
                {
                    WorkDayService workingSer = new WorkDayService(db);
                    this.GetDateToView(db, false, ref startDate, ref endDate);
                    workingDateList = workingSer.GetListByWorkDate(startDate, endDate);
                }

            }
            return workingDateList;
        }

        /// <summary>
        /// Get date to view
        /// </summary>
        private void GetDateToView(DB db, bool isFirst, ref DateTime startDate, ref DateTime endDate)
        {
            WorkDayService workingSer = new WorkDayService(db);
            DateTime workingDate;
            if (isFirst)
            {
                workingDate = DateTime.Now;
            }
            else
            {
                workingDate = this.dtWorkingMonth.Value.Value;
            }

            int closingDay = 0;
            AccountingService accSer = new AccountingService(db);
            M_Accounting account = accSer.GetData();
            if (account != null)
            {
                closingDay = account.ClosingDay;
            }

            int daysInMonth = DateTime.DaysInMonth(workingDate.Year, workingDate.Month);

            if (daysInMonth < closingDay)
            {
                endDate = new DateTime(workingDate.Year, workingDate.Month, daysInMonth);
            }
            else
            {
                endDate = new DateTime(workingDate.Year, workingDate.Month, closingDay);
            }

            //DateTime startDate 
            startDate = endDate.AddMonths(-1).AddDays(1);
            while (startDate.Day <= closingDay && startDate.Month != endDate.Month)
            {
                startDate = startDate.AddDays(1);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private IList<WorkDayInfo> GetDataGrid()
        {
            DateTime? holidayDate = null;
            IList<WorkDayInfo> ret = new List<WorkDayInfo>();
            if (this.dtWorkingMonth.Value != null)
            {
                int count = 0;
                M_Holiday holiday = new M_Holiday();

                if (this.rptWorkingDayList.Items.Count > 0)
                {
                    RepeaterItem item0 = this.rptWorkingDayList.Items[0];
                    HiddenField hdnWorkingDate0 = (HiddenField)item0.FindControl("hdnWorkingDate");
                    DateTime prevDate = DateTime.Parse(hdnWorkingDate0.Value).AddDays(-1);

                    holiday = this.GetHoliday(prevDate);
                    if (holiday != null && holiday.Replace == 1 && holiday.Date.DayOfWeek == DayOfWeek.Sunday)
                    {
                        // holiday = prevHoliday;
                        holidayDate = DateTime.Parse(hdnWorkingDate0.Value);
                    }
                }

                foreach (RepeaterItem item in this.rptWorkingDayList.Items)
                {
                    count++;
                    HiddenField hdnWorkingDate = (HiddenField)item.FindControl("hdnWorkingDate");
                    HiddenField hdnDay = (HiddenField)item.FindControl("hdnDay");
                    ICodeTextBox txtShiftCode = (ICodeTextBox)item.FindControl("txtShiftCode");
                    ITextBox txtShiftName = (ITextBox)item.FindControl("txtShiftName");
                    WorkDayInfo detail = new WorkDayInfo();

                    detail.No = count;
                    detail.WorkDate = DateTime.Parse(hdnWorkingDate.Value);
                    detail.Day = hdnDay.Value;

                    if (!string.IsNullOrEmpty(txtShiftCode.Value))
                    {
                        detail.ShiftCode = int.Parse(txtShiftCode.Value);
                    }
                    else
                    {
                        detail.ShiftCode = null;
                    }

                    detail.ShiftCodeStr = txtShiftCode.Value;

                    if (holidayDate == null)
                    {
                        holiday = this.GetHoliday(detail.WorkDate);
                    }

                    if (holiday != null && detail.WorkDate.DayOfWeek == DayOfWeek.Sunday && holiday.Replace == 1)
                    {
                        //holidayDate = holiday.Date;
                        holidayDate = holiday.Date.AddDays(1);
                    }

                    if ((holiday != null) || (detail.WorkDate.DayOfWeek == DayOfWeek.Sunday) || (holidayDate != null && detail.WorkDate == holidayDate))
                    {
                        detail.WorkDateStr = "<span class='negative-num'>" + string.Format("{0:dd/MM/yyyy}", detail.WorkDate) + "</span>";
                        detail.Day = "<span class='negative-num'>" + detail.WorkDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
                        if (holidayDate != null && detail.WorkDate == holidayDate)
                        {
                            holidayDate = null;
                        }
                    }
                    else
                    {
                        if (detail.WorkDate.DayOfWeek == DayOfWeek.Saturday)
                        {
                            detail.WorkDateStr = "<span class='text-primary'>" + string.Format("{0:dd/MM/yyyy}", detail.WorkDate) + "</span>";
                            detail.Day = "<span class='text-primary'>" + detail.WorkDate.DayOfWeek.ToString().Substring(0, 3) + "</span>";
                        }
                        else
                        {
                            detail.WorkDateStr = string.Format("{0:dd/MM/yyyy}", detail.WorkDate);
                            detail.Day = detail.WorkDate.DayOfWeek.ToString().Substring(0, 3);

                        }
                    }

                    detail.ShiftName = txtShiftName.Text;

                    ret.Add(detail);
                    //holidayDate=null;
                }
            }

            return ret;
        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Get Shift Name By Shift Code
        /// </summary>
        /// <param name="in1">Shift Code</param>
        /// <returns>Shift Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetShiftName(int shiftCode)
        {
            var shiftCd = shiftCode;

            try
            {
                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    M_Work_Shift model = shiftSer.GetByShiftCode(shiftCd);
                    if (model != null)
                    {
                        var result = new
                        {
                            ShiftCode = shiftCd,
                            ShiftName = model.ShiftName,
                            TypeOfDay = model.TypeOfDay
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(shiftCode);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Text;

using DailyReport.Controls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// TRAM -2015/06/08
    /// Accouting Form
    /// </summary>
    public partial class FrmAccounting : FrmBaseDetail
    {
        #region Constant

        private const string URL = "~/Master/FrmWorksMenu.aspx";

        #endregion

        #region Property

        /// <summary>
        /// Get or set AccountingID
        /// </summary>
        public int AccountingID
        {
            get { return (int)ViewState["AccountingID"]; }
            set { ViewState["AccountingID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Accounting";
            base.FormSubTitle = "";


            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            // LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            //btnNo.Click += new EventHandler(btnNoProcessData);

            //Init Max Length
            this.txtStartMonth.MaxLength = M_Accounting.START_MONTH_MAX_LENGTH;
            this.txtClosingDate.MaxLength = M_Accounting.CLOSING_DAY_MAX_LENGTH;
            this.txtUnitOfTime.MaxLength = M_Accounting.UNIT_OF_TIME_MAX_LENGTH;
            this.txtNumOfDay.MaxLength = M_Accounting.NUM_OF_DAY_MAX_LENGTH;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Accounting);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmWorksMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                this.InitData();
                M_Accounting accounting = this.GetAccounting();
                if (accounting == null)
                {
                    //Set Mode
                    this.ProcessMode(Mode.Insert);
                }
                else
                {
                    this.AccountingID = accounting.ID;

                    //Show data
                    this.ShowData(accounting);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }

        }

        /// <summary>
        /// Event Edit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Accounting
            M_Accounting accounting = this.GetAccounting();

            //Check accounting
            if (accounting != null)
            {
                //Show data
                this.ShowData(accounting);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL);
            }
        }

        /// <summary>
        /// Event Insert Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);

        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Accounting
            M_Accounting accounting = this.GetAccounting();

            //Check company
            if (accounting != null)
            {
                //Show data
                this.ShowData(accounting);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL);
            }

        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                    //Insert Data
                    if (this.InsertData())
                    {
                        //Get data
                        M_Accounting accounting = this.GetAccounting();

                        //Show data
                        this.ShowData(accounting);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //get data
                        M_Accounting accounting = this.GetAccounting();

                        //Show data
                        this.ShowData(accounting);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;
            }
        }

        #endregion

        #region Methods

        #region Init data

        /// <summary>
        /// Initial Data
        /// </summary>
        private void InitData()
        {
            this.InitComboboxRound(cmbLateWork, M_Config_H.CONFIG_CD_ROUND_CALC);
            this.InitComboboxRound(cmbEarlyLeave, M_Config_H.CONFIG_CD_ROUND_CALC);
            this.InitComboboxRound(cmbOuting, M_Config_H.CONFIG_CD_ROUND_CALC);
            this.InitComboboxRound(cmbOverTime, M_Config_H.CONFIG_CD_ROUND_CALC);
        }

        /// <summary>
        /// Init Combobox Round
        /// </summary>
        private void InitComboboxRound(DropDownList ddl, string configCD)
        {
            ddl.Items.Clear();
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                ddl.DataSource = configSer.GetDataForDropDownList(configCD);
            }

            // init combox 
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        #endregion

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Update:
                    enable = false;
                    break;

                default:
                    enable = true;
                    //base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnEdit, false);
                    break;
            }

            //Lock control
            this.txtStartMonth.ReadOnly = enable;
            this.txtClosingDate.ReadOnly = enable;
            this.txtUnitOfTime.ReadOnly = enable;
            this.cmbLateWork.Enabled = !enable;
            this.cmbEarlyLeave.Enabled = !enable;
            this.cmbOuting.Enabled = !enable;
            this.cmbOverTime.Enabled = !enable;
            this.datEarlyOverTimeFrm.ReadOnly = enable;
            this.datEarlyOverTimeTo.ReadOnly = enable;
            this.datLateOverTimeFrm.ReadOnly = enable;
            this.datLateOverTimeTo.ReadOnly = enable;
            this.txtNumOfDay.ReadOnly = enable;
            this.datNumOfTime.ReadOnly = enable;
        }

        #region Check input

        /// <summary>
        /// Check Inputting
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {

            //UnitOfTime
            if (this.txtUnitOfTime.IsEmpty)
            {
                this.SetMessage(this.txtUnitOfTime.ID, M_Message.MSG_REQUIRE, "Unit of Time");
            }
            else
            {
                if (int.Parse(this.txtUnitOfTime.Value) > M_Accounting.MAX_UNIT_OF_TIME)
                {
                    this.SetMessage(this.txtUnitOfTime.ID, M_Message.MSG_DATA_INVALID, "Unit of Time");
                }
            }

            //StartMonth
            if (this.txtStartMonth.IsEmpty)
            {
                this.SetMessage(this.txtStartMonth.ID, M_Message.MSG_REQUIRE, "Start Month");
            }

            if (!this.txtStartMonth.IsEmpty)
            {
                if (int.Parse(this.txtStartMonth.Value) <= 0 || int.Parse(this.txtStartMonth.Value) > M_Accounting.MAX_START_MONTH)
                {
                    this.SetMessage(this.txtStartMonth.ID, M_Message.MSG_DATA_INVALID, "Start Month");
                }
            }

            //ClosingDate
            if (this.txtClosingDate.IsEmpty)
            {
                this.SetMessage(this.txtClosingDate.ID, M_Message.MSG_REQUIRE, "Closing Date");
            }

            if (!this.txtClosingDate.IsEmpty)
            {
                if (int.Parse(this.txtClosingDate.Value) <= 0 || int.Parse(this.txtClosingDate.Value) > M_Accounting.MAX_CLOSING_DAY)
                {
                    this.SetMessage(this.txtClosingDate.ID, M_Message.MSG_DATA_INVALID, "Closing Date");
                }
            }

            //Late Work
            if (string.IsNullOrEmpty(this.cmbLateWork.SelectedValue.ToString()))
            {
                this.SetMessage(this.cmbLateWork.ID, M_Message.MSG_REQUIRE, "Late Work");
            }

            if (string.IsNullOrEmpty(this.cmbEarlyLeave.SelectedValue.ToString()))
            {
                this.SetMessage(this.cmbEarlyLeave.ID, M_Message.MSG_REQUIRE, "Early Leave");
            }

            if (string.IsNullOrEmpty(this.cmbOuting.SelectedValue.ToString()))
            {
                this.SetMessage(this.cmbOuting.ID, M_Message.MSG_REQUIRE, "Out");
            }

            if (string.IsNullOrEmpty(this.cmbOverTime.SelectedValue.ToString()))
            {
                this.SetMessage(this.cmbOverTime.ID, M_Message.MSG_REQUIRE, "Overtime");
            }

            if (this.datEarlyOverTimeFrm.Value == null)
            {
                this.SetMessage(this.datEarlyOverTimeFrm.ID, M_Message.MSG_REQUIRE, "Early Overtime From");
            }

            if (this.datEarlyOverTimeTo.Value == null)
            {
                this.SetMessage(this.datEarlyOverTimeTo.ID, M_Message.MSG_REQUIRE, "Early Overtime To");
            }

            if (this.datEarlyOverTimeFrm.Value != null && this.datEarlyOverTimeTo.Value != null)
            {
                if (this.datEarlyOverTimeFrm.Value >= this.datEarlyOverTimeTo.Value)
                {
                    this.SetMessage(this.datEarlyOverTimeFrm.ID, M_Message.MSG_LESS_THAN, "Early Overtime From", "Early Overtime To");
                }
            }

            if (this.datLateOverTimeFrm.Value == null)
            {
                this.SetMessage(this.datLateOverTimeFrm.ID, M_Message.MSG_REQUIRE, "Late Overtime From");
            }

            if (this.datLateOverTimeTo.Value == null)
            {
                this.SetMessage(this.datLateOverTimeTo.ID, M_Message.MSG_REQUIRE, "Late Overtime To");
            }

            if (this.datLateOverTimeFrm.Value != null && this.datLateOverTimeTo.Value != null)
            {
                if (this.datLateOverTimeFrm.Value == this.datLateOverTimeTo.Value)
                {
                    this.SetMessage(this.datLateOverTimeFrm.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Late Overtime From", "Late Overtime To");
                }
            }

            //EarlyOverTime
            if (this.datEarlyOverTimeFrm.Value != null && this.datEarlyOverTimeTo.Value != null && this.datLateOverTimeFrm.Value != null && this.datLateOverTimeTo.Value != null)
            {
                if (this.datEarlyOverTimeFrm.Value == this.datLateOverTimeFrm.Value && this.datEarlyOverTimeTo.Value == this.datLateOverTimeTo.Value)
                {
                    this.SetMessage(this.datEarlyOverTimeFrm.ID, M_Message.MSG_MUST_BE_DIFFERENT, "Early Overtime", "Late Overtime");
                }
            }

            //NumOfDay
            if (this.txtNumOfDay.IsEmpty)
            {
                this.SetMessage(this.txtNumOfDay.ID, M_Message.MSG_REQUIRE, "Num of Days");
            }
            else
            {
                if (int.Parse(this.txtNumOfDay.Value) < M_Accounting.MIN_NUM_OF_DAY || int.Parse(this.txtNumOfDay.Value) > M_Accounting.MAX_NUM_OF_DAY)
                {
                    this.SetMessage(this.txtNumOfDay.ID, M_Message.MSG_DATA_INVALID, "Num of Days");
                }
            }

            //NumOfTime
            if (this.datNumOfTime.IsEmpty)
            {
                this.SetMessage(this.datNumOfTime.ID, M_Message.MSG_REQUIRE, "Num of Time");
            }
            else
            {
                DateTime time = this.datNumOfTime.Value.Value;
                if (time.Hour == 0 && time.Minute == 0)
                {
                    this.SetMessage(this.datNumOfTime.ID, M_Message.MSG_GREATER_THAN, "Num of Time", "0");
                }
            }

            //Check error
            return !base.HaveError;
        }

        #endregion

        #region Get

        /// Get Accounting
        /// </summary>
        /// <returns>Accounting</returns>
        private M_Accounting GetAccounting()
        {
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);

                //Get Company
                return accSer.GetData();
            }
        }

        #endregion

        #region Show data

        /// <summary>
        /// Show data on form
        /// <param name="accounting">M_Accounting</param>
        /// </summary>
        private void ShowData(M_Accounting accounting)
        {
            if (accounting != null)
            {
                this.txtStartMonth.Value = accounting.StartMonth.ToString();
                this.txtClosingDate.Value = accounting.ClosingDay.ToString();
                this.txtNumOfDay.Value = accounting.NumOfDay.ToString();
                this.datNumOfTime.SetTimeValue(accounting.NumOfTime_H, accounting.NumOfTime_M);
                this.txtUnitOfTime.Value = accounting.UnitOfTime.ToString();
                this.cmbLateWork.SelectedValue = accounting.RoundLate.ToString();
                this.cmbEarlyLeave.SelectedValue = accounting.RoundLeave.ToString();
                this.cmbOuting.SelectedValue = accounting.RoundOuting.ToString();
                this.cmbOverTime.SelectedValue = accounting.RoundOT.ToString();

                this.datEarlyOverTimeFrm.SetTimeValue(accounting.EarlyOT_SH, accounting.EarlyOT_SM);
                this.datEarlyOverTimeTo.SetTimeValue(accounting.EarlyOT_EH, accounting.EarlyOT_EM);

                this.datLateOverTimeFrm.SetTimeValue(accounting.LateOT_SH, accounting.LateOT_SM);
                this.datLateOverTimeTo.SetTimeValue(accounting.LateOT_EH, accounting.LateOT_EM);

                //Save AccountingID and UpdateDate
                this.AccountingID = accounting.ID;
                this.OldUpdateDate = accounting.UpdateDate;
            }
        }

        #endregion

        #region Insert data

        /// <summary>
        /// Insert
        /// </summary>
        private bool InsertData()
        {
            try
            {
                M_Accounting accounting = new M_Accounting();

                //Create model
                accounting = this.CreateData();

                accounting.CreateUID = this.LoginInfo.User.ID;
                accounting.UpdateUID = this.LoginInfo.User.ID;

                //Insert Data
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    AccountingService accSer = new AccountingService(db);
                    accSer.Insert(accounting);
                    db.Commit();
                }
            }

            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }


        #endregion

        #region Update data

        /// <summary>
        /// Update Data
        /// </summary>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Accounting accounting = new M_Accounting();

                //Create model
                accounting = this.CreateData();
                accounting.UpdateDate = this.OldUpdateDate;
                accounting.UpdateUID = this.LoginInfo.User.ID;

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    AccountingService accSer = new AccountingService(db);


                    if (accounting.Status == DataStatus.Changed)
                    {
                        //Update data
                        ret = accSer.Update(accounting);
                        db.Commit();
                    }
                }

                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Create data

        /// <summary>
        /// Get data to insert
        /// </summary>
        /// <returns></returns>
        private M_Accounting CreateData()
        {
            M_Accounting accounting = new M_Accounting();
            accounting.StartMonth = int.Parse(this.txtStartMonth.Value);
            accounting.NumOfDay = int.Parse(this.txtNumOfDay.Value);
            accounting.NumOfTime_H = this.datNumOfTime.Value.Value.Hour;
            accounting.NumOfTime_M = this.datNumOfTime.Value.Value.Minute;
            accounting.ClosingDay = int.Parse(this.txtClosingDate.Value);
            accounting.UnitOfTime = int.Parse(this.txtUnitOfTime.Value);
            accounting.RoundLate = short.Parse(this.cmbLateWork.SelectedValue);
            accounting.RoundLeave = short.Parse(this.cmbEarlyLeave.SelectedValue);
            accounting.RoundOuting = short.Parse(this.cmbOuting.SelectedValue);
            accounting.RoundOT = short.Parse(this.cmbOverTime.SelectedValue);
            accounting.EarlyOT_SH = this.datEarlyOverTimeFrm.Value.Value.Hour;
            accounting.EarlyOT_SM = this.datEarlyOverTimeFrm.Value.Value.Minute;
            accounting.EarlyOT_EH = this.datEarlyOverTimeTo.Value.Value.Hour;
            accounting.EarlyOT_EM = this.datEarlyOverTimeTo.Value.Value.Minute;

            accounting.LateOT_SH = this.datLateOverTimeFrm.Value.Value.Hour;
            accounting.LateOT_SM = this.datLateOverTimeFrm.Value.Value.Minute;
            accounting.LateOT_EH = this.datLateOverTimeTo.Value.Value.Hour;
            accounting.LateOT_EM = this.datLateOverTimeTo.Value.Value.Minute;


            return accounting;
        }

        #endregion

        #endregion
    }
}
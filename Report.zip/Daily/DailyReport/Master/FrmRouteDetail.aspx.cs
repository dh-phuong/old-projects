﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;
using System.Collections;
using System.Data.SqlClient;
using System.Web.UI.HtmlControls;
using DailyReport.Controls;

namespace DailyReport.Master
{
    /// <summary>
    /// Page:   Route Detail
    /// Author: ISV-Thuy
    /// </summary>
    public partial class FrmRouteDetail : FrmBaseDetail
    {

        #region Constants
        private const string URL_LIST = "~/Master/FrmRouteList.aspx";
        #endregion

        /// <summary>
        /// View State key: IS_DATA_CHANGE
        /// </summary>
        private const string IS_DATA_CHANGED = "IS_DATA_CHANGED";

        /// <summary>
        /// Get or set route id
        /// </summary>
        private int ID
        {
            get
            {
                return (int)base.ViewState["ID"];
            }
            set
            {
                base.ViewState["ID"] = value;
            }
        }

        /// <summary>
        /// Get or set old update date
        /// </summary>
        private DateTime OldUpdateDate
        {
            get
            {
                return (DateTime)base.ViewState["OldUpdateDate"];
            }
            set
            {
                base.ViewState["OldUpdateDate"] = value;
            }
        }

        /// <summary>
        /// Get or set User list
        /// </summary>
        private IList<RouteDetailListInfo> UserList
        {
            get
            {
                return (IList<RouteDetailListInfo>)base.ViewState["UserList"];
            }
            set
            {
                base.ViewState["UserList"] = value;
            }
        }

        /// <summary>
        /// Get or set route list
        /// </summary>
        private IList<RouteDetailInfo> RouteList
        {
            get
            {
                return (IList<RouteDetailInfo>)base.ViewState["RouteList"];
            }
            set
            {
                base.ViewState["RouteList"] = value;
            }
        }

        #region event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Route Struct Master";
            base.FormSubTitle = "Detail";

            this.txtRouteCD.MaxLength = M_Route_H.ROUTE_CODE_MAX_LENGTH;
            this.txtRouteName.MaxLength = M_Route_H.ROUTE_NAME_MAX_LENGTH;

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // Paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            this.PagingHeader.NumRowOnPage = this.GetDefaultValuePaging();
            this.PagingHeader.CurrentPage = 1;

            // Paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.Route);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {   //Init data
                this.InitData();

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get route ID
                        this.ID = int.Parse(PreviousPageViewState["ID"].ToString());

                        //Check route
                        if (this.ShowRouteData(this.ID))
                        {
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }

                this.ShowUserListData();
            }
            else
            {
                this.GetData();
            }
            this.Success = false;

        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                int sortField = 2;
                int sortDirec = 1;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                this.SaveCondition();
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int sortField = 2;
                int sortDirec = 1;
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                this.SaveCondition();
            }
        }

        protected void rptRouteDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            RouteDetailListInfo dataItem = (RouteDetailListInfo)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptProxy");

            //----------------Set data daily detail----------------------//
            rptDetail.DataSource = dataItem.RouteProxyUser;
            rptDetail.DataBind();
        }

        /// <summary>
        /// Event Daily ItemDataBound
        /// </summary>
        /// <param name="sender">RepeaterItemEventArgs</param>
        /// <param name="e">EventArgs</param>
        protected void rptRoute_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            RouteDetailInfo dataItem = (RouteDetailInfo)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptRouteDetail");

            //----------------Set data daily detail----------------------//
            rptDetail.DataSource = dataItem.RouteDetailList;
            rptDetail.DataBind();
            //----------------End Set data daily detail-----------------//
            foreach (RepeaterItem item in rptDetail.Items)
            {
                RouteDetailListInfo RouteDetailListInfo = this.RouteList[e.Item.ItemIndex].RouteDetailList[item.ItemIndex];

                DropDownList cmbMethod = (DropDownList)item.FindControl("cmbMethod");
                SetDataCmbMethod(cmbMethod);
                cmbMethod.SelectedValue = RouteDetailListInfo.RouteMethod.ToString();

                INumberTextBox no = (INumberTextBox)item.FindControl("txtRequireNum");
                if (RouteDetailListInfo.RouteMethod == M_Config_H.METHOD_ROUTE_AND)
                {
                    no.Value = rptDetail.Items.Count;
                }

                string onchange = "cmbMethodChange('" + cmbMethod.ClientID + "','" + no.ClientID + "');";
                cmbMethod.Attributes.Add("onchange", onchange);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            int sortField = 2;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
        }

        /// <summary>
        /// Add department click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddDept_Click(object sender, EventArgs e)
        {
            string[] arr = this.hdLevel.Value.ToString().Split(',');
            int level = 0;
            int userId = 0;

            level = int.Parse(arr[0]);

            //Get list user to add
            var key = (sender as LinkButton).CommandArgument;
            var u = this.UserList.Where(s => s.DepartmentID == int.Parse(key));

            RouteDetailInfo _RouteDetailInfo = this.RouteList.Where(m => m.RouteLevel == level).SingleOrDefault();
            if (arr.Length == 1)
            {
                //Add user to route list
                foreach (var item in u)
                {
                    if (ExistsInRouteList(item.UserID))
                    {
                        this.SetMessage("", M_Message.MSG_EXIST_CODE, item.StaffCD + ' ' + item.StaffName);
                        continue;
                    }

                    item.RouteLevel = level;
                    item.RouteMethod = M_Config_H.METHOD_ROUTE_AND;
                    item.RequireNum = u.Count();
                    _RouteDetailInfo.RouteDetailList.Add(item);
                    _RouteDetailInfo.colSpan = _RouteDetailInfo.RouteDetailList.Where(m => m.DepartmentID != 0).Count() + 1;
                }
            }
            else
            {
                userId = int.Parse(arr[1]);
                RouteDetailListInfo _RouteDetailListInfo = _RouteDetailInfo.RouteDetailList.Where(m => m.UserID == userId).SingleOrDefault();
                foreach (var item in u)
                {
                    RouteProxyUser proxy = new RouteProxyUser();
                    proxy.ProxyUserCD = item.StaffCD;
                    proxy.ProxyUserID = item.UserID;
                    proxy.ProxyUserName = item.StaffName;
                    proxy.UserID = userId;

                    if (userId == item.UserID || _RouteDetailListInfo.RouteProxyUser.Any(m => m.ProxyUserID == item.UserID))
                    {
                        this.SetMessage("", M_Message.MSG_EXIST_CODE, item.StaffCD + ' ' + item.StaffName);
                    }
                    else
                    {
                        _RouteDetailListInfo.RouteProxyUser.Add(proxy);
                    }
                }
            }

            //Order route detail list by department id
            _RouteDetailInfo.RouteDetailList = _RouteDetailInfo.RouteDetailList.Where(m => m.DepartmentID != 0).OrderBy(m => m.DepartmentName).ToList();

            //Set route data source
            this.rptRoute.DataSource = this.RouteList.OrderBy(m => m.RouteLevel);
            this.rptRoute.DataBind();

            //Show user data
            this.ShowUserListData();
        }

        /// <summary>
        /// Remove department click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveDept_Click(object sender, EventArgs e)
        {
            //Get key:Department id and route level
            var key = (sender as LinkButton).CommandArgument.ToString().Split(',');

            //get route level
            int level = int.Parse(key[1]);
            int deptID = int.Parse(key[0]);
            RouteDetailInfo RouteDetailInfo = this.RouteList.Where(m => m.RouteLevel == level).SingleOrDefault();

            //Remove department on route level
            List<RouteDetailListInfo> lstTmp = RouteDetailInfo.RouteDetailList.Where(r => r.DepartmentID != deptID).ToList();
            if (lstTmp.Count == 0)
            {
                RouteDetailInfo.RouteDetailList = this.AddBlankUser(RouteDetailInfo.RouteLevel);
            }
            else
            {
                RouteDetailInfo.RouteDetailList = RouteDetailInfo.RouteDetailList.Where(r => r.DepartmentID != deptID).ToList();
            }

            RouteDetailInfo.colSpan = RouteDetailInfo.RouteDetailList.Count() + 1;

            //Set route data source
            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user list
            this.ShowUserListData();

            this.hdLevel.Value = this.RouteList[1].RouteLevel.ToString();
        }

        /// <summary>
        /// Add user click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            string[] arr = this.hdLevel.Value.ToString().Split(',');
            int level = 0;
            int userId = 0;

            level = int.Parse(arr[0]);
            var key = (sender as LinkButton).CommandArgument;

            //Get user
            var u = this.UserList.Where(s => s.UserID == int.Parse(key)).SingleOrDefault();
            u.RouteLevel = level;
            u.RouteMethod = M_Config_H.METHOD_ROUTE_AND;
            u.RequireNum = 1;

            RouteDetailInfo _RouteDetailInfo = this.RouteList.Where(m => m.RouteLevel == level).SingleOrDefault();
            if (arr.Length == 1)
            {
                if (ExistsInRouteList(u.UserID))
                {
                    this.SetMessage("", M_Message.MSG_EXIST_CODE, u.StaffCD + ' ' + u.StaffName);
                }
                else
                {
                    //Add user to route detail list
                    _RouteDetailInfo.RouteDetailList.Add(u);

                    //Order route detail list by department id
                    _RouteDetailInfo.RouteDetailList = _RouteDetailInfo.RouteDetailList.Where(m => m.DepartmentID != 0).OrderBy(m => m.DepartmentName).ToList();

                    _RouteDetailInfo.colSpan = _RouteDetailInfo.RouteDetailList.Where(m => m.DepartmentID != 0).Count() + 1;
                }
            }
            else
            {
                userId = int.Parse(arr[1]);
                RouteProxyUser proxy = new RouteProxyUser();
                proxy.ProxyUserCD = u.StaffCD;
                proxy.ProxyUserID = u.UserID;
                proxy.ProxyUserName = u.StaffName;
                proxy.UserID = userId;

                if (userId == u.UserID)
                {
                    this.SetMessage("", M_Message.MSG_EXIST_CODE, u.StaffCD + ' ' + u.StaffName);
                }
                else
                {
                    RouteDetailListInfo _RouteDetailListInfo = _RouteDetailInfo.RouteDetailList.Where(m => m.UserID == userId).SingleOrDefault();
                    if (!_RouteDetailListInfo.RouteProxyUser.Any(m => m.ProxyUserID == u.UserID))
                    {
                        _RouteDetailListInfo.RouteProxyUser.Add(proxy);
                    }
                    else
                    {
                        this.SetMessage("", M_Message.MSG_EXIST_CODE, u.StaffCD + ' ' + u.StaffName);
                    }
                }
            }

            //Set route data source
            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user list
            this.ShowUserListData();
        }

        protected void btnRemoveProxy_Click(object sender, EventArgs e)
        {
            var key = (sender as LinkButton).CommandArgument.ToString().Split('_');
            int userID = int.Parse(key[0]);
            int userProxy = int.Parse(key[1]);

            foreach (var itemx in this.RouteList)
            {
                foreach (var itemy in itemx.RouteDetailList)
                {
                    itemy.RouteProxyUser = itemy.RouteProxyUser.Where(m => m.UserID != userID || m.ProxyUserID != userProxy).ToList();
                }
            }

            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user list
            this.ShowUserListData();

            this.hdLevel.Value = this.RouteList[1].RouteLevel.ToString();
        }

        /// <summary>
        /// Remove user list
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemove_Click(object sender, EventArgs e)
        {
            //Get user id
            var key = int.Parse((sender as LinkButton).CommandArgument);
            foreach (var itemLevel in this.RouteList)
            {
                //Remove user id from list
                List<RouteDetailListInfo> lstTmp = itemLevel.RouteDetailList.Where(r => r.UserID != key).ToList();
                if (lstTmp.Count == 0)
                {
                    itemLevel.RouteDetailList = this.AddBlankUser(itemLevel.RouteLevel);
                }
                else
                {
                    itemLevel.RouteDetailList = lstTmp;
                }

                itemLevel.colSpan = itemLevel.RouteDetailList.Count() + 1;
            }

            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            this.hdLevel.Value = this.RouteList[1].RouteLevel.ToString();

            //Show user list
            this.ShowUserListData();
        }

        /// <summary>
        /// Add Level click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddLevel_Click(object sender, CommandEventArgs e)
        {
            //Add new level to route list
            int level = this.RouteList.Where(m => !m.RouteLevel.Equals(M_Route_H.LEVEL_READER) && !m.RouteLevel.Equals(M_Route_H.LEVEL_APPLICANT)).ToList().Count() + 1;
            this.AddBlankLevel(level);

            this.hdLevel.Value = level.ToString();

            //Order route list by level
            this.RouteList = this.RouteList.OrderBy(m => m.RouteLevel).ToList();

            //Set route data source
            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user data
            this.ShowUserListData();
        }

        /// <summary>
        /// Remove level click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveLevel_Click(object sender, EventArgs e)
        {
            //Get current level
            int level = int.Parse((sender as LinkButton).CommandArgument.ToString());

            //Remove level to route list
            this.RouteList = this.RouteList.Where(r => r.RouteLevel != level).ToList();

            //reset level
            level = 1;
            foreach (var item in this.RouteList.Where(m => !m.RouteLevel.Equals(M_Route_H.LEVEL_READER) && !m.RouteLevel.Equals(M_Route_H.LEVEL_APPLICANT)))
            {
                item.RouteLevel = level;
                item.RouteLevelName = level.ToString();
                level++;
            }

            //Order by route list by route level
            this.RouteList = this.RouteList.OrderBy(m => m.RouteLevel).ToList();

            //Set route data source
            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user list
            this.ShowUserListData();

            this.hdLevel.Value = this.RouteList[1].RouteLevel.ToString();
        }

        /// <summary>
        /// Edit click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Show route data
            this.ShowRouteData(this.ID);

            //Check route
            if (this.RouteList.Count > 0)
            {
                //Show user data
                this.ShowUserListData();

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Update click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Show user click
            this.ShowUserListData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Copy click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Show route data
            this.ShowRouteData(this.ID);

            //Check route
            if (this.RouteList.Count > 0)
            {
                //Show user data
                this.ShowUserListData();

                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            //Clear route data
            this.txtRouteCD.Value = string.Empty;
            this.txtRouteName.Value = string.Empty;

            this.RouteList = new List<RouteDetailInfo>();

            this.AddBlankLevel(M_Route_H.LEVEL_APPLICANT);
            this.AddBlankLevel(1);
            this.AddBlankLevel(M_Route_H.LEVEL_READER);

            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            //Show user list
            this.ShowUserListData();

            //Set mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Insert click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Show user list
            this.ShowUserListData();

            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Event Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;
            this.ShowUserListData();
            this.ShowRouteData(this.ID);

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Back click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            if (this.Mode == Mode.View || this.Mode == Mode.Insert)
            {
                Server.Transfer(URL_LIST);
            }
            else if (this.Mode == Mode.Update || this.Mode == Mode.Copy)
            {
                //Get route data
                this.ShowRouteData(this.ID);

                //Check route
                if (this.RouteList.Count > 0)
                {
                    //Set Mode
                    this.ProcessMode(Mode.View);

                    //Show user data
                    this.ShowUserListData();
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }
        }

        #endregion

        #region method

        /// <summary>
        /// Get Default Value
        /// </summary>
        /// <returns></returns>
        private int GetDefaultValuePaging()
        {
            using (DB db = new DB())
            {
                Config_HService service = new Config_HService(db);
                string ret = service.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAGING);
                return string.IsNullOrEmpty(ret) ? 0 : int.Parse(ret);
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.ID = -1;
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "2";
            this.ViewState[IS_DATA_CHANGED] = false;

            this.RouteList = new List<RouteDetailInfo>();

            this.AddBlankLevel(M_Route_H.LEVEL_APPLICANT);
            this.AddBlankLevel(1);
            this.AddBlankLevel(M_Route_H.LEVEL_READER);

            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Insert:
                case Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertProccess())
                    {
                        //Show route data
                        this.ShowRouteData(this.ID);

                        //Show user data
                        this.ShowUserListData();

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ShowUserListData();
                    }
                    break;
                case Utilities.Mode.Update:
                    if (this.UpdateData())
                    {
                        //Show route data
                        this.ShowRouteData(this.ID);

                        //Show user data
                        this.ShowUserListData();

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.ShowUserListData();
                    }
                    break;
                case Utilities.Mode.Delete:

                    if (!this.DeleteData())
                    {
                        this.ShowUserListData();

                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;
                default:

                    break;

            }
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertProccess()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    this.InsertData(db);
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_ROUTE_H_UN))
                {
                    this.SetMessage(this.txtRouteCD.ID, M_Message.MSG_EXIST_CODE, "Route Code");
                }

                if (ex.Message.Contains(Models.Constant.M_ROUTE_D_FK_USERID))
                {
                    this.SetMessage(this.txtRouteCD.ID, M_Message.MSG_EXIST_CODE, "User Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        private string getUserInLevelBefore(int level)
        {
            string lst = string.Empty;

            var RouteList = this.RouteList.Where(m => m.RouteLevel < level);
            foreach (var item in RouteList)
            {
                foreach (var itemu in item.RouteDetailList)
                {
                    if (!string.IsNullOrEmpty(lst))
                    {
                        lst += ',';
                    }
                    lst += itemu.UserID;
                }
            }

            return lst;
        }

        /// <summary>
        /// Get detail data
        /// </summary>
        private void GetData()
        {
            foreach (RepeaterItem itemx in this.rptRoute.Items)
            {
                if (itemx.ItemType == ListItemType.AlternatingItem || itemx.ItemType == ListItemType.Item)
                {
                    string userLevelB = this.getUserInLevelBefore(itemx.ItemIndex);
                    Repeater rptDetail = (Repeater)itemx.FindControl("rptRouteDetail");

                    short _RouteMethod = 0;
                    decimal? _RequireNum = rptDetail.Items.Count;

                    foreach (RepeaterItem itemy in rptDetail.Items)
                    {
                        if (itemy.ItemType == ListItemType.AlternatingItem || itemy.ItemType == ListItemType.Item)
                        {
                            RouteDetailListInfo _RouteDetailListInfo = this.RouteList[itemx.ItemIndex].RouteDetailList[itemy.ItemIndex];

                            if (itemy.ItemIndex == 0)
                            {
                                DropDownList cmbMethod = (DropDownList)itemy.FindControl("cmbMethod");
                                _RouteMethod = short.Parse(cmbMethod.SelectedValue.ToString());

                                INumberTextBox rNum = (INumberTextBox)itemy.FindControl("txtRequireNum");
                                if (_RouteMethod == M_Config_H.METHOD_ROUTE_OR)
                                {
                                    _RequireNum = rNum.Value;
                                }
                                else
                                {
                                    _RequireNum = rptDetail.Items.Count;
                                }
                            }

                            _RouteDetailListInfo.RouteLevel = this.RouteList[itemx.ItemIndex].RouteLevel;
                            _RouteDetailListInfo.RequireNum = _RequireNum;
                            _RouteDetailListInfo.RouteMethod = _RouteMethod;

                            //------------- Apply
                            HtmlInputCheckBox chkApplyFlag1 = (HtmlInputCheckBox)itemy.FindControl("chkApplyFlag1");
                            _RouteDetailListInfo.ApplyFlag1 = Convert.ToInt16(chkApplyFlag1.Checked);

                            HtmlInputCheckBox chkApplyFlag2 = (HtmlInputCheckBox)itemy.FindControl("chkApplyFlag2");
                            _RouteDetailListInfo.ApplyFlag2 = Convert.ToInt16(chkApplyFlag2.Checked);

                            HtmlInputCheckBox chkApplyFlag3 = (HtmlInputCheckBox)itemy.FindControl("chkApplyFlag3");
                            _RouteDetailListInfo.ApplyFlag3 = Convert.ToInt16(chkApplyFlag3.Checked);

                            HtmlInputCheckBox chkApplyFlag4 = (HtmlInputCheckBox)itemy.FindControl("chkApplyFlag4");
                            _RouteDetailListInfo.ApplyFlag4 = Convert.ToInt16(chkApplyFlag4.Checked);

                            //------------- Reject
                            HtmlInputCheckBox chkRejectFlag1 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag1");
                            _RouteDetailListInfo.RejectFlag1 = Convert.ToInt16(chkRejectFlag1.Checked);

                            HtmlInputCheckBox chkRejectFlag2 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag2");
                            _RouteDetailListInfo.RejectFlag2 = Convert.ToInt16(chkRejectFlag2.Checked);

                            HtmlInputCheckBox chkRejectFlag3 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag3");
                            _RouteDetailListInfo.RejectFlag3 = Convert.ToInt16(chkRejectFlag3.Checked);

                            HtmlInputCheckBox chkRejectFlag4 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag4");
                            _RouteDetailListInfo.RejectFlag4 = Convert.ToInt16(chkRejectFlag4.Checked);

                            HtmlInputCheckBox chkRejectFlag5 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag5");
                            _RouteDetailListInfo.RejectFlag5 = Convert.ToInt16(chkRejectFlag5.Checked);

                            HtmlInputCheckBox chkRejectFlag6 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag6");
                            _RouteDetailListInfo.RejectFlag6 = Convert.ToInt16(chkRejectFlag6.Checked);

                            HtmlInputCheckBox chkRejectFlag7 = (HtmlInputCheckBox)itemy.FindControl("chkRejectFlag7");
                            _RouteDetailListInfo.RejectFlag7 = Convert.ToInt16(chkRejectFlag7.Checked);

                            //------------- Remand
                            HtmlInputCheckBox chkRemandFlag1 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag1");
                            _RouteDetailListInfo.RemandFlag1 = Convert.ToInt16(chkRemandFlag1.Checked);

                            HtmlInputCheckBox chkRemandFlag2 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag2");
                            _RouteDetailListInfo.RemandFlag2 = Convert.ToInt16(chkRemandFlag2.Checked);

                            HtmlInputCheckBox chkRemandFlag3 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag3");
                            _RouteDetailListInfo.RemandFlag3 = Convert.ToInt16(chkRemandFlag3.Checked);

                            HtmlInputCheckBox chkRemandFlag4 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag4");
                            _RouteDetailListInfo.RemandFlag4 = Convert.ToInt16(chkRemandFlag4.Checked);

                            HtmlInputCheckBox chkRemandFlag5 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag5");
                            _RouteDetailListInfo.RemandFlag5 = Convert.ToInt16(chkRemandFlag5.Checked);

                            HtmlInputCheckBox chkRemandFlag6 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag6");
                            _RouteDetailListInfo.RemandFlag6 = Convert.ToInt16(chkRemandFlag6.Checked);

                            HtmlInputCheckBox chkRemandFlag7 = (HtmlInputCheckBox)itemy.FindControl("chkRemandFlag7");
                            _RouteDetailListInfo.RemandFlag7 = Convert.ToInt16(chkRemandFlag7.Checked);

                            //------------- ApproveFlag1
                            HtmlInputCheckBox chkApproveFlag1 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag1");
                            _RouteDetailListInfo.ApproveFlag1 = Convert.ToInt16(chkApproveFlag1.Checked);

                            HtmlInputCheckBox chkApproveFlag2 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag2");
                            _RouteDetailListInfo.ApproveFlag2 = Convert.ToInt16(chkApproveFlag2.Checked);

                            HtmlInputCheckBox chkApproveFlag3 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag3");
                            _RouteDetailListInfo.ApproveFlag3 = Convert.ToInt16(chkApproveFlag3.Checked);

                            HtmlInputCheckBox chkApproveFlag4 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag4");
                            _RouteDetailListInfo.ApproveFlag4 = Convert.ToInt16(chkApproveFlag4.Checked);

                            HtmlInputCheckBox chkApproveFlag5 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag5");
                            _RouteDetailListInfo.ApproveFlag5 = Convert.ToInt16(chkApproveFlag5.Checked);

                            HtmlInputCheckBox chkApproveFlag6 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag6");
                            _RouteDetailListInfo.ApproveFlag6 = Convert.ToInt16(chkApproveFlag6.Checked);

                            HtmlInputCheckBox chkApproveFlag7 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag7");
                            _RouteDetailListInfo.ApproveFlag7 = Convert.ToInt16(chkApproveFlag7.Checked);

                            HtmlInputCheckBox chkApproveFlag8 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag8");
                            _RouteDetailListInfo.ApproveFlag8 = Convert.ToInt16(chkApproveFlag8.Checked);

                            HtmlInputCheckBox chkApproveFlag9 = (HtmlInputCheckBox)itemy.FindControl("chkApproveFlag9");
                            _RouteDetailListInfo.ApproveFlag9 = Convert.ToInt16(chkApproveFlag9.Checked);

                            //------------- ReadFlag1
                            HtmlInputCheckBox chkReadFlag1 = (HtmlInputCheckBox)itemy.FindControl("chkReadFlag1");
                            _RouteDetailListInfo.ReadFlag1 = Convert.ToInt16(chkReadFlag1.Checked);

                            HtmlInputCheckBox chkReadFlag2 = (HtmlInputCheckBox)itemy.FindControl("chkReadFlag2");
                            _RouteDetailListInfo.ReadFlag2 = Convert.ToInt16(chkReadFlag2.Checked);

                            HtmlInputCheckBox chkReadFlag3 = (HtmlInputCheckBox)itemy.FindControl("chkReadFlag3");
                            _RouteDetailListInfo.ReadFlag3 = Convert.ToInt16(chkReadFlag3.Checked);

                            HtmlInputCheckBox chkReadFlag4 = (HtmlInputCheckBox)itemy.FindControl("chkReadFlag4");
                            _RouteDetailListInfo.ReadFlag4 = Convert.ToInt16(chkReadFlag4.Checked);

                            HtmlInputCheckBox chkReadFlag5 = (HtmlInputCheckBox)itemy.FindControl("chkReadFlag5");
                            _RouteDetailListInfo.ReadFlag5 = Convert.ToInt16(chkReadFlag5.Checked);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Update route
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Check data change
                    if (this.CheckDataChange(db))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    int ret = 0;
                    Route_HService ser = new Route_HService(db);
                    Route_DService serD = new Route_DService(db);

                    //Get route header
                    M_Route_H header = new M_Route_H
                    {
                        ID = this.ID,
                        RouteCD = this.txtRouteCD.Value,
                        RouteName = this.txtRouteName.Value,
                        UpdateDate = this.OldUpdateDate,
                        UpdateUID = LoginInfo.User.ID
                    };

                    //Update header
                    ret = ser.Update(header);
                    if (ret == 0)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    //Delete detail
                    serD.Delete(this.ID);

                    //Insert detail
                    insertD(serD);

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert route
        /// </summary>
        /// <param name="db">Database</param>
        private void InsertData(DB db)
        {
            Route_HService serH = new Route_HService(db);
            Route_DService serD = new Route_DService(db);

            //Get header model
            M_Route_H header = new M_Route_H();
            header.RouteCD = this.txtRouteCD.Value;
            header.RouteName = this.txtRouteName.Value;
            header.CreateUID = LoginInfo.User.ID;

            //Inset route header
            serH.Insert(header);

            //Get route id
            this.ID = db.GetIdentityId<M_Route_H>();

            //Insert detail
            insertD(serD);
        }

        /// <summary>
        /// Insert route detail
        /// </summary>
        /// <param name="serD"></param>
        private void insertD(Route_DService serD)
        {
            using (DB db = new DB())
            {
                int level = 0;
                for (int i = 0; i < this.RouteList.Count; i++)
                {
                    List<RouteDetailListInfo> RouteDetailListInfos = this.RouteList[i].RouteDetailList.ToList();
                    if (RouteDetailListInfos.Count > 0)
                    {
                        for (int j = 0; j < RouteDetailListInfos.Count; j++)
                        {
                            M_Route_D detail = new M_Route_D();
                            RouteDetailListInfo item = RouteDetailListInfos[j];
                            detail.HID = this.ID;
                            detail.RouteLevel = item.RouteLevel;

                            if (detail.RouteLevel != M_Route_H.LEVEL_APPLICANT && item.DepartmentID == 0)
                            {
                                continue;
                            }

                            //Get detail model
                            UserService _UserService = new UserService(db);
                            List<M_User> admins = _UserService.GetListAdmin().ToList();

                            detail.UserID = detail.RouteLevel == M_Route_H.LEVEL_APPLICANT ? admins[0].ID : item.UserID;
                            detail.RouteMethod = item.RouteMethod;
                            detail.RequireNum = item.RequireNum == null ? RouteDetailListInfos.Count : int.Parse(item.RequireNum.Value.ToString());

                            detail.ProxyApprovalUser = String.Join(",", item.RouteProxyUser.Select(p => p.ProxyUserID.ToString()).ToArray());

                            detail.ApplyFlag1 = item.ApplyFlag1;
                            detail.ApplyFlag2 = item.ApplyFlag2;
                            detail.ApplyFlag3 = item.ApplyFlag3;
                            detail.ApplyFlag4 = item.ApplyFlag4;

                            detail.RejectFlag1 = item.RejectFlag1;
                            detail.RejectFlag2 = item.RejectFlag2;
                            detail.RejectFlag3 = item.RejectFlag3;
                            detail.RejectFlag4 = item.RejectFlag4;
                            detail.RejectFlag5 = item.RejectFlag5;
                            detail.RejectFlag6 = item.RejectFlag6;
                            detail.RejectFlag7 = item.RejectFlag7;

                            detail.RemandFlag1 = item.RemandFlag1;
                            detail.RemandFlag2 = item.RemandFlag2;
                            detail.RemandFlag3 = item.RemandFlag3;
                            detail.RemandFlag4 = item.RemandFlag4;
                            detail.RemandFlag5 = item.RemandFlag5;
                            detail.RemandFlag6 = item.RemandFlag6;
                            detail.RemandFlag7 = item.RemandFlag7;

                            detail.ApproveFlag1 = item.ApproveFlag1;
                            detail.ApproveFlag2 = item.ApproveFlag2;
                            detail.ApproveFlag3 = item.ApproveFlag3;
                            detail.ApproveFlag4 = item.ApproveFlag4;
                            detail.ApproveFlag5 = item.ApproveFlag5;
                            detail.ApproveFlag6 = item.ApproveFlag6;
                            detail.ApproveFlag7 = item.ApproveFlag7;
                            detail.ApproveFlag8 = item.ApproveFlag8;
                            detail.ApproveFlag9 = item.ApproveFlag9;

                            detail.ReadFlag1 = item.ReadFlag1;
                            detail.ReadFlag2 = item.ReadFlag2;
                            detail.ReadFlag3 = item.ReadFlag3;
                            detail.ReadFlag4 = item.ReadFlag4;
                            detail.ReadFlag5 = item.ReadFlag5;

                            //Isert route detail
                            serD.Insert(detail);
                        }

                        level++;
                    }
                }
            }
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns></returns>
        private bool DeleteData()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Check data change
                    if (this.CheckDataChange(db))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    int ret = 0;
                    Route_HService ser = new Route_HService(db);

                    M_Route_H header = new M_Route_H
                    {
                        ID = this.ID,
                        StatusFlag = 1,
                        UpdateDate = this.OldUpdateDate,
                        UpdateUID = LoginInfo.User.ID
                    };

                    ret = ser.UpdateStatusFlag(header);
                    if (ret == 0)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_FORM_ROUTE_FK) || ex.Message.Contains(Models.Constant.M_FORM_LINK_FK))
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_EXISTS);
                    Log.Instance.WriteLog(ex);
                    return false;
                }

                Log.Instance.WriteLog(ex);
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;
            switch (this.Mode)
            {
                case Mode.Copy:
                    this.txtRouteCD.ReadOnly = false;
                    this.txtRouteName.ReadOnly = false;
                    break;
                case Mode.Insert:
                    this.txtRouteCD.ReadOnly = false;
                    this.txtRouteName.ReadOnly = false;
                    break;
                case Mode.Update:
                    this.txtRouteCD.ReadOnly = true;
                    this.txtRouteName.ReadOnly = false;
                    break;
                case Mode.Delete:
                    this.txtRouteCD.ReadOnly = true;
                    this.txtRouteName.ReadOnly = true;
                    break;
                default:
                    this.HeaderGrid.SortField = string.Empty;
                    this.HeaderGrid.SortDirec = string.Empty;
                    this.PagingHeader.CurrentPage = 1;
                    this.ViewState["ConditionDetail"] = null;

                    this.txtRouteCD.ReadOnly = true;
                    this.txtRouteName.ReadOnly = true;
                    break;
            }

            //Set disable button
            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
            base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
            base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
        }


        /// <summary>
        /// Show data on form
        /// </summary>
        private bool ShowRouteData(int id)
        {
            using (DB db = new DB())
            {
                this.RouteList = new List<RouteDetailInfo>();
                Route_HService serH = new Route_HService(db);
                Route_DService serD = new Route_DService(db);
                //UserService userS = new UserService(db);
                StaffService staffSer = new StaffService(db);
                M_Route_H header = serH.GetByID(id);
                IList<M_Route_D> lstD = serD.GetByListByHeaderID(id);

                if (header == null) return false;

                this.txtRouteCD.Value = header.RouteCD;
                this.txtRouteName.Value = header.RouteName;
                this.OldUpdateDate = header.UpdateDate;
                foreach (int level in lstD.Select(m => m.RouteLevel).Distinct())
                {
                    IList<M_Route_D> listLevelItem = lstD.Where(m => m.RouteLevel == level).ToList();
                    RouteDetailInfo headInfo = new RouteDetailInfo();

                    headInfo.colSpan = listLevelItem.Count() + 1;
                    headInfo.RouteLevel = level;
                    headInfo.RouteDetailList = serD.GetListDetailInfo(id, level);

                    string userLevelB = this.getUserInLevelBefore(level);

                    foreach (var item in headInfo.RouteDetailList)
                    {
                        if (!string.IsNullOrEmpty(item.UserProxyId))
                        {
                            string[] arr = item.UserProxyId.Split(',');
                            for (int i = 0; i < arr.Length; i++)
                            {
                                M_StaffInfo m_staffInfo = staffSer.GetStaffInfoByUserID(int.Parse(arr[i]));
                                RouteProxyUser _RouteProxyUser = new RouteProxyUser(m_staffInfo, item.UserID);
                                item.RouteProxyUser.Add(_RouteProxyUser);
                            }
                        }
                    }

                    switch (level)
                    {
                        case M_Route_H.LEVEL_APPLICANT:
                            headInfo.RouteLevelName = M_Route_H.LEVEL_APPLICANT_NAME;
                            break;

                        case M_Route_H.LEVEL_READER:
                            headInfo.RouteLevelName = M_Route_H.LEVEL_READER_NAME;
                            break;

                        default:
                            headInfo.RouteLevelName = level.ToString();
                            break;
                    }
                    this.RouteList.Add(headInfo);
                }


                if (!this.RouteList.Any(m => m.RouteLevel.Equals(M_Route_H.LEVEL_READER)))
                {
                    AddBlankLevel(M_Route_H.LEVEL_READER);
                }

                this.RouteList = this.RouteList.OrderBy(m => m.RouteLevel).ToList();

                this.rptRoute.DataSource = this.RouteList;
                this.rptRoute.DataBind();

                return true;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        private void ShowUserListData()
        {
            int sortField = 2;
            int sortDirec = 1;
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
            {
                sortField = int.Parse(this.HeaderGrid.SortField);
            }
            if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
            {
                sortDirec = int.Parse(this.HeaderGrid.SortDirec);
            }

            //Show condition
            if (this.ViewState["ConditionDetail"] != null)
            {
                Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];

                this.ShowCondition(data);
            }

            //Show data on grid
            this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

        }

        /// <summary>
        /// Check data change
        /// </summary>
        /// <param name="db"></param>
        /// <returns></returns>
        private bool CheckDataChange(DB db)
        {
            Route_HService serH = new Route_HService(db);
            M_Route_H header = serH.GetByID(this.ID);
            if (header != null)
            {
                if (this.OldUpdateDate != header.UpdateDate)
                {
                    return true;
                }

            }
            else
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Check Input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            this.GetData();

            using (DB db = new DB())
            {
                //Route CD
                if (this.txtRouteCD.IsEmpty)
                {
                    this.SetMessage(this.txtRouteCD.ID, M_Message.MSG_REQUIRE, "Route Code");
                }
                else
                {
                    if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                    {

                        Route_HService ser = new Route_HService(db);

                        // Check user by userCD 
                        if (ser.IsExist(this.txtRouteCD.Value))
                        {
                            this.SetMessage(this.txtRouteCD.ID, M_Message.MSG_EXIST_CODE, "Route Code");
                        }
                    }
                }

                //Route name
                if (this.txtRouteName.IsEmpty)
                {
                    this.SetMessage(this.txtRouteName.ID, M_Message.MSG_REQUIRE, "Route Name");
                }

                List<RouteDetailInfo> lst = this.RouteList.Where(m => !m.RouteLevel.Equals(M_Route_H.LEVEL_READER) && !m.RouteLevel.Equals(M_Route_H.LEVEL_APPLICANT)).ToList();

                if (lst.Count == 0)
                {
                    this.SetMessage("", M_Message.MSG_REQUIRE, "Level");
                }

                if (lst.Exists(m => m.RouteDetailList.Where(n => n.DepartmentID != 0).ToList().Count == 0))
                {
                    this.SetMessage("", M_Message.MSG_PLEASE_SELECT, "User");
                }

                for (int i = 0; i < this.RouteList.Count; i++)
                {
                    RouteDetailInfo RouteDetailInfo = this.RouteList[i];
                    for (int j = 0; j < RouteDetailInfo.RouteDetailList.Count; j++)
                    {
                        RouteDetailListInfo RouteDetailListInfo = RouteDetailInfo.RouteDetailList[j];

                        if (j == 0 && RouteDetailListInfo.RouteMethod == M_Config_H.METHOD_ROUTE_OR)
                        {
                            if (RouteDetailListInfo.RequireNum == null)
                            {
                                base.SetMessage(string.Format("{0}_txtRequireNum_{1}", i, j), M_Message.MSG_REQUIRE_GRID, "Require Number", j + 1);
                            }

                            if (RouteDetailListInfo.RequireNum == 0)
                            {
                                base.SetMessage(string.Format("{0}_txtRequireNum_{1}", i, j), M_Message.MSG_GREATER_THAN_GRID, "Require Number", 0, j + 1);
                            }

                            if (RouteDetailListInfo.RequireNum > RouteDetailInfo.RouteDetailList.Count)
                            {
                                base.SetMessage(string.Format("{0}_txtRequireNum_{1}", i, j), M_Message.MSG_LESS_THAN_EQUAL_GRID, "Require Number", RouteDetailInfo.RouteDetailList.Count, j + 1);
                            }
                        }
                    }
                }

                this.rptRoute.DataSource = this.RouteList;
                this.rptRoute.DataBind();
            }
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            this.ShowRouteData(this.ID);
            if (this.RouteList.Count > 0)
            {

                this.ShowUserListData();

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                    errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        protected void btnOnSubmit_Click(object sender, EventArgs e)
        {
            this.GetData();

            this.rptRoute.DataSource = this.RouteList;
            this.rptRoute.DataBind();

            this.ShowUserListData();
        }

        #endregion

        public List<RouteDetailListInfo> AddBlankUser(int level)
        {
            List<RouteDetailListInfo> RouteDetailListInfos = new List<RouteDetailListInfo>();
            RouteDetailListInfo RouteDetailListInfo = new RouteDetailListInfo();
            RouteDetailListInfo.RouteLevel = level;
            RouteDetailListInfo.RequireNum = 0;

            RouteDetailListInfos.Add(RouteDetailListInfo);
            return RouteDetailListInfos;
        }

        public void AddBlankLevel(int level, int colSpan = 2)
        {
            List<RouteDetailListInfo> RouteDetailListInfos = AddBlankUser(level);
            RouteDetailInfo _RouteDetailInfo1 = new RouteDetailInfo();
            _RouteDetailInfo1.RouteLevel = level;
            switch (level)
            {
                case M_Route_H.LEVEL_APPLICANT:
                    _RouteDetailInfo1.RouteLevelName = M_Route_H.LEVEL_APPLICANT_NAME;
                    break;

                case M_Route_H.LEVEL_READER:
                    _RouteDetailInfo1.RouteLevelName = M_Route_H.LEVEL_READER_NAME;
                    break;

                default:
                    _RouteDetailInfo1.RouteLevelName = level.ToString();
                    break;
            }

            _RouteDetailInfo1.colSpan = colSpan;
            _RouteDetailInfo1.RouteDetailList = RouteDetailListInfos;
            this.RouteList.Add(_RouteDetailInfo1);
        }

        public void SetDataCmbMethod(DropDownList ddl)
        {

            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                ddl.DataSource = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_METHOD_ROUTE);
            }

            //cmbMethod            
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Check list has record
        /// </summary>
        /// <returns></returns>
        public bool GetHasRecord()
        {
            var lstUser = (IList<RouteDetailListInfo>)this.UserList;
            int sortField = 2;
            int sortDirec = 1;
            //Show condition
            if (this.ViewState["ConditionDetail"] != null)
            {
                Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];

                this.ShowCondition(data);

                if (!string.IsNullOrEmpty(this.HeaderGrid.SortField))
                {
                    sortField = int.Parse(this.HeaderGrid.SortField);
                }
                if (!string.IsNullOrEmpty(this.HeaderGrid.SortDirec))
                {
                    sortDirec = int.Parse(this.HeaderGrid.SortDirec);
                }
            }
            if (lstUser.Count == 0)
            {
                this.PagingFooter.CurrentPage = this.PagingHeader.CurrentPage = 1;
                this.LoadDataGrid(this.PagingFooter.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);
                lstUser = (IList<RouteDetailListInfo>)this.UserList;
                this.SaveCondition();
                if (lstUser.Count == 0)
                {
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            this.ViewState["ConditionDetail"] = hash;
        }

        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex">Index of page</param>
        /// <param name="numOnPage">The number of lines on a page</param>
        /// <param name="sortField">Sort field</param>
        /// <param name="sortDirec">Sort direction</param>
        private void LoadDataGrid(int pageIndex, int numOnPage, int sortField, int sortDirec)
        {
            int totalRow = 0;

            IList<RouteDetailListInfo> dataSource = new List<RouteDetailListInfo>();

            //Get data
            using (DB db = new DB())
            {
                //---CategoryService service = new CategoryService(db);
                //////UserService service = new UserService(db);
                //////dataSource = service.GetListSortBy(this.ID, sortField, sortDirec);

                StaffService staffSer = new StaffService(db);
                dataSource = staffSer.GetListSortBy(this.ID, sortField, sortDirec);
                totalRow = dataSource.Count;
                this.UserList = dataSource;

                //Paging
                dataSource = dataSource.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            }

            #region Set paging info
            //Show data
            if (dataSource.Count == 0)
            {
                if (this.ViewState["ConditionDetail"] != null)
                {
                    Hashtable data = (Hashtable)this.ViewState["ConditionDetail"];
                    int curPage = int.Parse(data["CurrentPage"].ToString());
                    if (curPage != 1)
                    {
                        curPage -= 1;

                        this.PagingHeader.CurrentPage = curPage;
                        this.PagingFooter.CurrentPage = curPage;

                        int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
                        this.PagingHeader.NumRowOnPage = rowOfPage;

                        this.SaveCondition();

                        //Show data on grid
                        this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage, sortField, sortDirec);

                        return;
                    }
                }

                this.rptUser.DataSource = null;
                this.UserList = new List<RouteDetailListInfo>();

            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(dataSource[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(dataSource[dataSource.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                this.SaveCondition();

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "", "Department", "", "Employee", "Position" });

                // detail
                this.rptUser.DataSource = dataSource.OrderBy(x => x.DepartmentName).ThenBy(n => n.UserCD);
            }
            #endregion
            this.rptUser.DataBind();
        }

        /// <summary>
        /// Check user was exists in route list
        /// </summary>
        /// <param name="uid"></param>
        /// <returns></returns>
        private bool ExistsInRouteList(int uid)
        {
            foreach (var levelItem in this.RouteList)
            {
                if (levelItem.RouteDetailList != null)
                {
                    foreach (var item in levelItem.RouteDetailList)
                    {
                        if (item.UserID.Equals(uid))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
    }
}


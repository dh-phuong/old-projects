﻿using System;
using System.Data.SqlClient;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Web.UI.WebControls;


namespace DailyReport.Master
{
    /// <summary>
    /// Form:   FrmDistrictDetail
    /// Author: VN-Nho
    /// </summary>
    public partial class FrmDistrictDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmDistrictList.aspx";
        #endregion
   
        #region Property

        /// <summary>
        /// Get or set DistrictID
        /// </summary>
        public int DistrictID
        {
            get { return (int)ViewState["DistrictID"]; }
            set { ViewState["DistrictID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        #endregion

        #region Event

            /// <summary>
            /// Event Init
            /// </summary>
            /// <param name="e"></param>
            protected override void OnInit(EventArgs e)
            {
                base.OnInit(e);

                //Set Title
                base.FormTitle = "District Master";
                base.FormSubTitle = "Detail";

                //Init Max Length                        
                this.txtDistrictCD.MaxLength = M_District.DISTRICT_CODE_MAX_LEN;
                this.txtDistrictName.MaxLength = M_District.DISTRICT_NAME_MAX_LEN;

                //Init Event
                LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
                btnYes.Click += new EventHandler(btnProcessData);
                LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
                btnNo.Click += new EventHandler(btnShowData);
            }

            /// <summary>
            /// 
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void Page_Load(object sender, EventArgs e)
            {
                //Check authority of login user
                base.SetAuthority(FormId.Province);
                if (!this._authority.IsMasterView)
                {
                    Response.Redirect("~/Menu/FrmMasterMenu.aspx");
                }

                if (!this.IsPostBack)
                {
                    //Invalid
                    this.InitCombobox(this.cmbProvince);

                    if (this.PreviousPage != null)
                    {
                        //Save condition of previous page
                        this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                        //Check mode
                        if (this.PreviousPageViewState["ID"] == null)
                        {
                            //Set mode
                            this.ProcessMode(Mode.Insert);
                        }
                        else
                        {
                            //Get District ID
                            this.DistrictID = int.Parse(this.PreviousPageViewState["ID"].ToString());
                            M_District data = this.GetDistrict(this.DistrictID);

                            //Check District
                            if (data != null)
                            {
                                //Show data
                                this.ShowData(data);

                                //Set Mode
                                this.ProcessMode(Mode.View);
                            }
                            else
                            {
                                Server.Transfer(URL_LIST);
                            }
                        }
                    }
                    else
                    {
                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                }

                //Set init
                this.Success = false;
            }

            /// <summary>
            /// Copy Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnCopy_Click(object sender, EventArgs e)
            {
                //Get data
                M_District data = this.GetDistrict(this.DistrictID);

                //Check District
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Copy);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// New Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnNew_Click(object sender, EventArgs e)
            {
                this.ClearValue();

                //Set Mode
                this.ProcessMode(Mode.Insert);
            }

            /// <summary>
            /// Edit Click
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnEdit_Click(object sender, EventArgs e)
            {
                //Get Data
                M_District data = this.GetDistrict(this.DistrictID);

                //Check data
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.Update);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Event Insert Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnInsert_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Update Submit
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnUpdate_Click(object sender, EventArgs e)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
            }

            /// <summary>
            /// Event Delete
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnDelete_Click(object sender, EventArgs e)
            {
                //Set Model
                this.Mode = Mode.Delete;

                //Show question insert
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
            }


            /// <summary>
            /// Event Back
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnBack_Click(object sender, EventArgs e)
            {
                //Get District
                M_District data = this.GetDistrict(this.DistrictID);

                //Check user
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

           
            /// <summary>
            /// Process Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnProcessData(object sender, EventArgs e)
            {
                bool ret;
                M_District data = null;

                //Check Mode
                switch (this.Mode)
                {
                    case Utilities.Mode.Insert:
                    case Utilities.Mode.Copy:

                        //Insert Data
                        ret = this.InsertData();
                        if (ret)
                        {
                            //Get District
                            data = this.GetDistrict(int.Parse(this.cmbProvince.SelectedValue), this.txtDistrictCD.Value);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                        break;

                    case Utilities.Mode.Delete:

                        //Delete District
                        if (!this.DeleteData())
                        {
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                        break;
                    case Utilities.Mode.Update:

                        //Update Data
                        ret = this.UpdateData();
                        if (ret)
                        {
                            //Get District
                            data = this.GetDistrict(this.DistrictID);

                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }

                        break;
                }

            }


            /// <summary>
            /// Show Data
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            protected void btnShowData(object sender, EventArgs e)
            {
                //Get District
                M_District data = this.GetDistrict(this.DistrictID);
                if (data != null)
                {
                    //Show data
                    this.ShowData(data);

                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
                else
                {
                    Server.Transfer(URL_LIST);
                }
            }

            /// <summary>
            /// Clear value screen
            /// </summary>
            private void ClearValue()
            {
                this.cmbProvince.SelectedIndex = 0;
                this.txtDistrictCD.Value = string.Empty;
                this.txtDistrictName.Value = string.Empty;
            }
        #endregion

        #region Methods

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl)
        {
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                ProvinceService ser = new ProvinceService(db);
                // init combox 
                ddl.DataSource = ser.GetDataForDropDownList(true);
                ddl.DataValueField = "Value";
                ddl.DataTextField = "DisplayName";
                ddl.DataBind();
            }
            
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                    this.cmbProvince.Enabled = true;
                    this.txtDistrictCD.ReadOnly = false;
                    this.txtDistrictName.ReadOnly = false;
                    break;

                case Mode.Update:
                    this.cmbProvince.Enabled = false;
                    this.txtDistrictCD.ReadOnly = true;
                    this.txtDistrictName.ReadOnly = false;
                    break;

                default:
                    this.cmbProvince.Enabled = false;
                    this.txtDistrictCD.ReadOnly = true;
                    this.txtDistrictName.ReadOnly = true;

                    base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
                    base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
                    base.DisabledLink(this.btnCopy, !base._authority.IsMasterCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
                        
                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="district">M_District</param>
        private void ShowData(M_District district)
        {
            //Show data
            if (district != null)
            {
                this.cmbProvince.SelectedValue = district.ProvinceID.ToString();
                this.txtDistrictCD.Value = district.DistrictCD;
                this.txtDistrictName.Value = district.DistrictName;

                //Save UserID and UpdateDate
                this.DistrictID = district.ID;
                this.OldUpdateDate = district.UpdateDate;
            }
        }

        /// <summary>
        /// Get District by id
        /// </summary>
        /// <param name="districtID">District id</param>
        /// <returns>District model</returns>
        private M_District GetDistrict(int districtID)
        {
            using (DB db = new DB())
            {
                DistrictService service = new DistrictService(db);

                //Get Department
                return service.GetByID(districtID);
            }
        }

        /// <summary>
        /// Get District by key
        /// </summary>
        /// <param name="pistrictCD">District code</param>
        /// <returns>District model</returns>
        private M_District GetDistrict(int provinceID, string districtCD)
        {
            using (DB db = new DB())
            {
                DistrictService service = new DistrictService(db);

                //Get User
                return service.GetByKey(provinceID, districtCD);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            if (this.cmbProvince.SelectedIndex == 0)
            {
                this.SetMessage("cmbProvince", M_Message.MSG_REQUIRE, "Province");                
            }

            //ProvinceCD
            if (this.txtDistrictCD.IsEmpty)
            {
                this.SetMessage("txtDistrictCD", M_Message.MSG_REQUIRE, "District Code");
            }
            else if (this.cmbProvince.SelectedIndex != 0 && !this.txtDistrictCD.IsEmpty)
            {
                if (this.Mode == Mode.Insert || this.Mode == Mode.Copy)
                {
                    // Check Province
                    if (this.GetDistrict(int.Parse(this.cmbProvince.SelectedValue), this.txtDistrictCD.Value) != null)
                    {
                        this.SetMessage("txtDistrictCD", M_Message.MSG_EXIST_CODE, "District Code");
                    }
                    

                }
            }

            //ProvinceName
            if (this.txtDistrictName.IsEmpty)
            {
                this.SetMessage("txtDistrictName", M_Message.MSG_REQUIRE, "District Name");
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_District data = new M_District();
                data.ProvinceID = int.Parse(this.cmbProvince.SelectedValue);
                data.DistrictCD = this.txtDistrictCD.Value;
                data.DistrictName = this.txtDistrictName.Value;

                data.CreateUID = base.LoginInfo.User.ID;

                //Insert Category
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    DistrictService serive = new DistrictService(db);

                    //Insert Category
                    serive.Insert(data);

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_PROVINCE_UN))
                {
                    this.SetMessage(this.txtDistrictCD.ID, M_Message.MSG_EXIST_CODE, "District Code");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_District data = this.GetDistrict(this.DistrictID);
                if (data != null)
                {
                    //Create model
                    data.DistrictName = this.txtDistrictName.Value;

                    data.UpdateDate = this.OldUpdateDate;
                    data.UpdateUID = base.LoginInfo.User.ID;

                    //Update category
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        DistrictService service = new DistrictService(db);

                        //Update department
                        if (data.Status == DataStatus.Changed)
                        {
                            ret = service.Update(data);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    DistrictService ser = new DistrictService(db);

                    //Delete Vendor
                    ret = ser.Delete(this.DistrictID, this.OldUpdateDate);
                    db.Commit();
                }

                //Check result update
                if (ret == 0)
                {
                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Constant.M_USER_FK_PROVINCE_ID))
                       
                {
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CANT_DELETE, "District Code " + this.txtDistrictCD.Value);
                }

                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

    }
}
﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using System.Collections;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.Master
{

    /// <summary>
    /// ISV-TRAM 2015/04/24
    /// FrmLinkMaster
    /// </summary>
    public partial class FrmLinkList : FrmBaseList
    {
        #region Property

        /// <summary>
        /// Get or set collapse property
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        /// <summary>
        /// Get or set FormLinkList property
        /// </summary>
        public IList<FormLinkInfo> FormLinkList
        {
            get { return (IList<FormLinkInfo>)ViewState["FormLinkList"]; }
            set { ViewState["FormLinkList"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Link Master";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
        }

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Link);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)this.PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }
                }
                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Click to create the new row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click to view info detail of the current row
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            string[] commandArgs = e.CommandArgument.ToString().Split(',');
            //FormID
            this.ViewState["FormID"] = commandArgs[0];
            //RouteID
            this.ViewState["RouteID"] = commandArgs[1];

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click footer of page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click header of page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click sorting grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        /// <summary>
        /// Change TypeForm combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbTypeForm_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            this.InitComboboxRoute(int.Parse(this.cmbTypeForm.SelectedValue));
            if (this.FormLinkList != null && this.FormLinkList.Count > 0)
            {
                this.LoadGridPaging(this.FormLinkList, this.FormLinkList.Count, this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);
            }
            this.Collapse = "in";
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Combobox Type
        /// </summary>
        private void InitComboboxFormType()
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> formLinkList = new List<DropDownModel>();
                FormService formLinkSer = new FormService(db);
                formLinkList = formLinkSer.GetDataForDropdown(true);
                this.cmbTypeForm.DataSource = formLinkList;
            }
            this.cmbTypeForm.DataValueField = "Value";
            this.cmbTypeForm.DataTextField = "DisplayName";
            this.cmbTypeForm.DataBind();

        }

        /// <summary>
        /// Init Combobox Type
        /// </summary>
        private void InitComboboxRoute(int formTypeID)
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> routeList = new List<DropDownModel>();
                FormRouteService formRouteSer = new FormRouteService(db);

                if (formTypeID != -1)
                {
                    routeList = formRouteSer.GetDataForDropdown(formTypeID, true);
                }
                else
                {
                    routeList.Insert(0, new DropDownModel("-1", "---"));
                }
                
                this.cmbRoute.DataSource = routeList;
            }
            this.cmbRoute.DataValueField = "Value";
            this.cmbRoute.DataTextField = "DisplayName";
            this.cmbRoute.DataBind();

        }

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.cmbTypeForm.ID, this.cmbTypeForm.SelectedValue);
            hash.Add(this.cmbRoute.ID, this.cmbRoute.SelectedValue);
            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);
            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);
            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.cmbTypeForm.SelectedValue = data[this.cmbTypeForm.ID].ToString();
            this.InitComboboxFormType();
            this.InitComboboxRoute(int.Parse(this.cmbTypeForm.SelectedValue));
            this.cmbRoute.SelectedValue = data[this.cmbRoute.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.InitComboboxFormType();
            this.InitComboboxRoute(int.Parse(this.cmbTypeForm.SelectedValue));
            
            // header grid
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex">Page index</param>
        /// <param name="numOnPage">Row number on one page</param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int totalRow = 0;

            IList<FormLinkInfo> listFormLink;
            int typeForm;
            int route;

            //Searching Conditions
            if (!this.cmbTypeForm.SelectedValue.Equals("-1") )
            {
                typeForm = int.Parse(this.cmbTypeForm.SelectedValue);
            }
            else
            {
                typeForm = -1;
            }

            if (!this.cmbRoute.SelectedValue.Equals("-1") )
            {
                route = int.Parse(this.cmbRoute.SelectedValue);
            }
            else
            {
                route = -1;
            }

            //Get data
            using (DB db = new DB())
            {
                FormLinkService dbSer = new FormLinkService(db);
                listFormLink = dbSer.GetListByCond(typeForm, route);
                if (listFormLink != null && listFormLink.Count > 0)
                {
                    int rowNumber = 1;
                    listFormLink = (from row in listFormLink
                                    orderby row.RowNumber ascending
                                    select new FormLinkInfo
                                    {
                                        RowNumber = rowNumber++,
                                        FormID = row.FormID,
                                        FormName = row.FormName,
                                        RouteID = row.RouteID,
                                        RouteName = row.RouteName,
                                        UpdateDate = row.UpdateDate

                                    }).ToList();
                }
            }

            totalRow = listFormLink.Count;

            //Sort data on grid
            this.SortGrid(ref listFormLink);
            this.FormLinkList = listFormLink;
            //Show data
            if (listFormLink == null || listFormLink.Count == 0)
            {
                this.rptLinkList.DataSource = null;
            }
            else
            {
                if (listFormLink.Count > numOnPage)
                {
                    //Get data depend on page index and row number on one page
                    listFormLink = listFormLink.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                }

                //Load paging of grid
                this.LoadGridPaging(listFormLink, totalRow, pageIndex, numOnPage);

                // detail
                this.rptLinkList.DataSource = listFormLink;
            }

            this.rptLinkList.DataBind();
        }

        /// <summary>
        /// Load paging for grid
        /// </summary>
        /// <param name="listFormLink">List of FormLinkInfo model</param>
        /// <param name="totalRow">Total row</param>
        /// <param name="pageIndex">Page index</param>
        /// <param name="numOnPage">Row number on one page</param>
        private void LoadGridPaging(IList<FormLinkInfo> listFormLink, int totalRow, int pageIndex, int numOnPage)
        {
            this.PagingHeader.RowNumFrom = int.Parse(listFormLink[0].RowNumber.ToString());
            this.PagingHeader.RowNumTo = int.Parse(listFormLink[listFormLink.Count - 1].RowNumber.ToString());
            this.PagingHeader.TotalRow = totalRow;
            this.PagingHeader.CurrentPage = pageIndex;

            // paging footer
            this.PagingFooter.CurrentPage = pageIndex;
            this.PagingFooter.NumberOnPage = numOnPage;
            this.PagingFooter.TotalRow = totalRow;

            // header
            this.HeaderGrid.TotalRow = totalRow;
            this.HeaderGrid.AddColumms(new string[] { "#", "", "Application Name", "Route Name" });

        }

        /// <summary>
        /// SortGrid
        /// </summary>
        /// <param name="linkList"></param>
        private void SortGrid(ref IList<FormLinkInfo> linkList)
        {
            int sortField = 3;
            int sortDirect = 1;

            if (!string.IsNullOrEmpty(HeaderGrid.SortField))
            {
                sortField = int.Parse(HeaderGrid.SortField);
            }

            if (!string.IsNullOrEmpty(HeaderGrid.SortDirec))
            {
                sortDirect = int.Parse(HeaderGrid.SortDirec);
            }

            int rowNumber = 1;
            switch (sortField)
            {
                case 3:
                    if (sortDirect == 1)
                    {
                        linkList = (from row in linkList
                                    orderby row.FormName ascending
                                    select new FormLinkInfo
                                    {
                                        RowNumber = rowNumber++,
                                        FormID = row.FormID,
                                        FormName = row.FormName,
                                        RouteID = row.RouteID,
                                        RouteName = row.RouteName,
                                        UpdateDate = row.UpdateDate

                                    }).ToList();
                    }

                    if (sortDirect == 2)
                    {
                        linkList = (from row in linkList
                                    orderby row.FormName descending
                                    select new FormLinkInfo
                                    {
                                        RowNumber = rowNumber++,
                                        FormID = row.FormID,
                                        FormName = row.FormName,
                                        RouteID = row.RouteID,
                                        RouteName = row.RouteName,
                                        UpdateDate = row.UpdateDate

                                    }).ToList();
                    }

                    break;
                case 4:

                    if (sortDirect == 1)
                    {
                        linkList = (from row in linkList
                                    orderby row.RouteName ascending
                                    select new FormLinkInfo
                                    {
                                        RowNumber = rowNumber++,
                                        FormID = row.FormID,
                                        FormName = row.FormName,
                                        RouteID = row.RouteID,
                                        RouteName = row.RouteName,
                                        UpdateDate = row.UpdateDate

                                    }).ToList();
                    }

                    if (sortDirect == 2)
                    {
                        linkList = (from row in linkList
                                    orderby row.RouteName descending
                                    select new FormLinkInfo
                                    {
                                        RowNumber = rowNumber++,
                                        FormID = row.FormID,
                                        FormName = row.FormName,
                                        RouteID = row.RouteID,
                                        RouteName = row.RouteName,
                                        UpdateDate = row.UpdateDate

                                    }).ToList();
                    }
                    break;
            }
        }

        #endregion
    }
}
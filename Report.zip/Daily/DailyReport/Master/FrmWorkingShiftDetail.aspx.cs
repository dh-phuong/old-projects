﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Utilities;
using DailyReport.Models;
using DailyReport.DAC;
using System.Data.SqlClient;

namespace DailyReport.Master
{
    public partial class FrmWorkingShiftDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Master/FrmWorkingShiftList.aspx";
        #endregion

        #region Variable

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set WorkingShiftID
        /// </summary>
        public int WorkingShiftID
        {
            get { return (int)ViewState["WorkingShiftID"]; }
            set { ViewState["WorkingShiftID"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Work Shift Master";
            base.FormSubTitle = "Detail";

            ////Init Max Length
            this.txtShiftcode.MaxLength = M_Work_Shift.SHIFT_CODE_MAX_LENGTH;
            this.txtShiftname.MaxLength = M_Work_Shift.SHIFT_NAME_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Update)
                    {
                        this.txtShiftcode.ReadOnly = true;
                        this.txtShiftname.ReadOnly = true;
                        this.txtTimefrom.ReadOnly = true;
                        this.txtTimeto.ReadOnly = true;
                        this.ddlTypeOfDay.Enabled = false;
                        this.ddlType.Enabled = false;
                        this.txtDuration.SetReadOnly(true);
                    }
                    else
                    {
                        this.txtShiftcode.ReadOnly = false;
                        this.txtShiftname.ReadOnly = false;
                        this.txtTimefrom.ReadOnly = false;
                        this.txtTimeto.ReadOnly = false;
                        this.ddlTypeOfDay.Enabled = true;
                        this.ddlType.Enabled = true;
                        this.txtDuration.SetReadOnly(true);
                    }

                    enable = false;
                    break;

                default:
                    this.txtShiftcode.ReadOnly = true;
                    this.txtShiftname.ReadOnly = true;
                    this.txtTimefrom.ReadOnly = true;
                    this.txtTimeto.ReadOnly = true;
                    this.ddlTypeOfDay.Enabled = true;
                    this.ddlType.Enabled = false;
                    this.txtDuration.SetReadOnly(true);
                    enable = true;
                    break;
            }

            //Lock control
            this.txtShiftname.ReadOnly = enable;
            this.txtTimefrom.ReadOnly = enable;
            this.txtTimeto.ReadOnly = enable;
            this.ddlTypeOfDay.Enabled = !enable;
            this.ddlType.Enabled = !enable;
            this.txtDuration.SetReadOnly(true);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.WorkingShift);
            if (!base._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                //Init Combobox
                this.InitCombobox();

                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                        //Set mode
                        this.WorkingShiftID = 0;
                        //this.Mode = Mode.Insert;
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get Staff ID
                        this.WorkingShiftID = int.Parse(PreviousPageViewState["ID"].ToString());
                        M_Work_Shift workingshift;

                        using (DB db = new DB())
                        {
                            WorkShiftService workingshiftSer = new WorkShiftService(db);
                            workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
                        }                        

                        //Check M_WorkingShift
                        if (workingshift != null)
                        {
                            //Show data
                            this.ShowData(workingshift);
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.WorkingShiftID = 0;
                    this.ProcessMode(Mode.Insert);
                }
            }
        }

        /// <summary>
        /// Edit Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get WorkingShift
            M_Work_Shift workingshift;
            using(DB db=new DB())
            {
                WorkShiftService workingshiftSer = new WorkShiftService(db);
                workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
            }            

            //Check user
            if (workingshift != null)
            {
                //Show data
                this.ShowData(workingshift);
                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Copy Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get WorkingShift
            M_Work_Shift workingshift;
            using (DB db = new DB())
            {
                WorkShiftService workingshiftSer = new WorkShiftService(db);
                workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
            }            

            //Check user
            if (workingshift != null)
            {
                //Show data
                this.ShowData(workingshift);
                this.txtShiftcode.Value = "";
                //Set Mode
                this.ProcessMode(Mode.Copy);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Delete Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Show question
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Insert Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Update Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Back Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get WorkingShift
            M_Work_Shift workingshift;

            using (DB db = new DB())
            {
                WorkShiftService workingshiftSer = new WorkShiftService(db);
                workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
            }            

            //Check user
            if (workingshift != null)
            {
                //Show data
                this.ShowData(workingshift);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// New Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {

            this.txtShiftcode.Value = "";
            this.txtShiftname.Value = "";
            this.txtTimefrom.Value = null;
            this.txtTimeto.Value = null;
            this.txtDuration.Value = null;
            this.InitCombobox();
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            M_Work_Shift workingshift;
            using (DB db = new DB())
            {
                WorkShiftService workingshiftSer = new WorkShiftService(db);
                workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
            }            

            if (workingshift != null)
            {
                //Show data
                this.ShowData(workingshift);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case DailyReport.Utilities.Mode.Insert:
                case DailyReport.Utilities.Mode.Copy:
                    //Insert Data
                    if (!this.CheckInput())
                    {
                        return;
                    }

                    if (this.InsertData())
                    {
                        using (DB db = new DB())
                        {
                            WorkShiftService workingshiftSer = new WorkShiftService(db);
                            //this.WorkingShiftID = db.GetIdentityId<M_Work_Shift>();
                            //M_Work_Shift workingshift = workingshiftSer.GetByID(this.WorkingShiftID);

                            M_Work_Shift workingshift = workingshiftSer.GetByCode(int.Parse(this.txtShiftcode.Value));

                            //Show data
                            this.ShowData(workingshift);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                    }
                    break;

                case DailyReport.Utilities.Mode.Delete:
                    //Delete
                    if (!this.DeleteData())
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        Server.Transfer(URL_LIST);
                    }
                    break;

                default:
                    //Update Data
                    if (!this.CheckInput())
                    {
                        return;
                    }

                    if (this.UpdateData())
                    {
                        M_Work_Shift workingshift;
                        using (DB db = new DB())
                        {
                            WorkShiftService workingshiftSer = new WorkShiftService(db);
                            workingshift = workingshiftSer.GetByID(this.WorkingShiftID);
                        }                        

                        //Show data
                        this.ShowData(workingshift);

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;
            }
        }

        #endregion

        #region Mehod

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox()
        {
            // init combox 
            ddlType.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_WORKING_SHIFT_TYPE);
            ddlType.DataValueField = "Value";
            ddlType.DataTextField = "DisplayName";
            ddlType.DataBind();

            // init combox 
            ddlTypeOfDay.DataSource = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_TYPE_OF_DAY);
            ddlTypeOfDay.DataValueField = "Value";
            ddlTypeOfDay.DataTextField = "DisplayName";
            ddlTypeOfDay.DataBind();
        }

        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool InsertData()
        {
            try
            {
                //Create model
                M_Work_Shift workingshift = new M_Work_Shift();
                workingshift.ShiftCode = int.Parse(this.txtShiftcode.Value);
                workingshift.ShiftName = this.txtShiftname.Value;

                int? starthour = null;
                int? startminute = null;
                int? endhour = null;
                int? endminute = null;
                int? durationhour = null;
                int? durationminute = null;

                if (txtTimefrom.Text.Trim() != string.Empty && txtTimeto.Text.Trim() != string.Empty)
                {
                    starthour = txtTimefrom.Value.Value.Hour;
                    startminute = txtTimefrom.Value.Value.Minute;
                    endhour = txtTimeto.Value.Value.Hour;
                    endminute = txtTimeto.Value.Value.Minute;
                    string[] temp = new string[2];
                    temp = this.txtDuration.Value.Split(':');
                    durationhour = int.Parse(temp[0]);
                    durationminute = int.Parse(temp[1]);
                }

                workingshift.StartHour = starthour;
                workingshift.StartMinute = startminute;
                workingshift.EndHour = endhour;
                workingshift.EndMinute = endminute;
                workingshift.DurationHour = durationhour;
                workingshift.DurationMinute = durationminute;
                workingshift.TypeOfDay = int.Parse(this.ddlTypeOfDay.SelectedValue);
                workingshift.Type = int.Parse(this.ddlType.SelectedValue.ToString());

                workingshift.CreateUID = this.LoginInfo.User.ID;
                workingshift.UpdateUID = this.LoginInfo.User.ID;

                //Insert Holiday
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkShiftService workingshiftSer = new WorkShiftService(db);

                    //Insert User
                    workingshiftSer.Insert(workingshift);

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool UpdateData()
        {
            try
            {
                int ret = 0;
                M_Work_Shift WorkingShift;
                using (DB db = new DB())
                {
                    WorkShiftService workingshiftService = new WorkShiftService(db);
                    WorkingShift = workingshiftService.GetByID(this.WorkingShiftID);
                }
                
                if (WorkingShift != null)
                {
                    //Create model
                    WorkingShift.ID = this.WorkingShiftID;
                    WorkingShift.ShiftName = this.txtShiftname.Value;

                    int? starthour = null;
                    int? startminute = null;
                    int? endhour = null;
                    int? endminute = null;
                    int? durationhour = null;
                    int? durationminute = null;

                    if (txtTimefrom.Text.Trim() != string.Empty && txtTimeto.Text.Trim() != string.Empty)
                    {
                        starthour = txtTimefrom.Value.Value.Hour;
                        startminute = txtTimefrom.Value.Value.Minute;
                        endhour = txtTimeto.Value.Value.Hour;
                        endminute = txtTimeto.Value.Value.Minute;
                        string[] temp = new string[2];
                        temp = this.txtDuration.Value.Split(':');
                        durationhour = int.Parse(temp[0]);
                        durationminute = int.Parse(temp[1]);
                    }

                    WorkingShift.StartHour = starthour;
                    WorkingShift.StartMinute = startminute;
                    WorkingShift.EndHour = endhour;
                    WorkingShift.EndMinute = endminute;
                    WorkingShift.DurationHour = durationhour;
                    WorkingShift.DurationMinute = durationminute;
                    WorkingShift.TypeOfDay = int.Parse(this.ddlTypeOfDay.SelectedValue);
                    WorkingShift.Type = int.Parse(this.ddlType.SelectedValue.ToString());

                    WorkingShift.UpdateDate = this.OldUpdateDate;
                    WorkingShift.UpdateUID = this.LoginInfo.User.ID;

                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        //Update Holiday  
                        WorkShiftService workingshiftSer = new WorkShiftService(db);

                        //Update User
                        if (WorkingShift.Status == DataStatus.Changed)
                        {
                            ret = workingshiftSer.Update(WorkingShift);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    //du lieu da thay doi
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }


        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkShiftService workingshiftService = new WorkShiftService(db);
                    ret = workingshiftService.Delete(this.WorkingShiftID, this.OldUpdateDate);

                    if (ret > 0)
                    {
                        db.Commit();
                    }
                }

                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_WorkingDate_FK_ShiftID))
                {
                    this.SetMessage("", M_Message.MSG_EXIST_CANT_DELETE, "Shift Code");
                }

                if (ex.Message.Contains(Models.Constant.T_WORK_FK_WORKSHIFTID))
                {
                    this.SetMessage("", M_Message.MSG_EXIST_CANT_DELETE, "Shift Code");
                }

                Log.Instance.WriteLog(ex);
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");
                Log.Instance.WriteLog(ex);
            }
            return true;
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns>Valid:true, Invalid:false</returns>
        private bool CheckInput()
        {
            //Shift Code
            if (this.txtShiftcode.IsEmpty)
            {
                this.SetMessage(this.txtShiftcode.ID, M_Message.MSG_REQUIRE, "Shift Code");
            }

            //Shift Name
            if (this.txtShiftname.IsEmpty)
            {
                this.SetMessage(this.txtShiftname.ID, M_Message.MSG_REQUIRE, "Shift Name");
            }

            //Shift Name
            if (this.ddlType.SelectedValue == "-1")
            {
                this.SetMessage(this.ddlType.ID, M_Message.MSG_REQUIRE, "Type");
            }

            if (this.txtTimefrom.Value == null && this.txtTimeto.Value != null)
            {
                this.SetMessage(this.txtTimefrom.ID, M_Message.MSG_REQUIRE, "Start Working Time");
            }

            if (this.txtTimefrom.Value != null && this.txtTimeto.Value == null)
            {
                this.SetMessage(this.txtTimeto.ID, M_Message.MSG_REQUIRE, "End Working Time");
            }

            //Check Working Time
            if (this.txtTimefrom.Value != null && this.txtTimeto.Value != null)
            {
                DateTime timeFrom = new DateTime(2014, 10, 1, this.txtTimefrom.Value.Value.Hour, this.txtTimefrom.Value.Value.Minute, 0);
                DateTime timeTo = new DateTime(2014, 10, 1, this.txtTimeto.Value.Value.Hour, this.txtTimeto.Value.Value.Minute, 0);
                TimeSpan Result = timeTo.Subtract(timeFrom);

                if (Result.TotalMinutes <= 0)
                {
                    this.SetMessage(this.txtTimefrom.ID, M_Message.MSG_LESS_THAN, "Start Time", "End Time", "Working Hour");
                }
            }

            if (this.ddlTypeOfDay.SelectedValue == "-1")
            {
                this.SetMessage(this.ddlTypeOfDay.ID, M_Message.MSG_REQUIRE, "Type Of Day");
            }

            if (!base.HaveError && (this.Mode == Mode.Insert || this.Mode == Mode.Copy))
            {
                // Check WorkingShift by workingshift
                M_Work_Shift workingshift;
                using (DB db = new DB())
                {
                    WorkShiftService workingshiftSer = new WorkShiftService(db);
                    workingshift = workingshiftSer.GetByCode(int.Parse(this.txtShiftcode.Value));
                }                

                if (workingshift != null)
                {
                    this.SetMessage(this.txtShiftcode.ID, M_Message.MSG_EXIST_CODE, "Shift Code");
                }
            }

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="workingshift">workingshift</param>
        private void ShowData(M_Work_Shift workingshift)
        {
            //Show data
            if (workingshift != null)
            {
                this.txtShiftcode.Value = workingshift.ShiftCode.ToString();
                this.txtShiftname.Value = workingshift.ShiftName;

                if (workingshift.StartHour == null)
                {
                    this.txtTimefrom.Value = null;
                    this.txtTimeto.Value = null;
                    this.txtDuration.Value = null;
                }
                else
                {
                    this.txtTimefrom.SetTimeValue((int)workingshift.StartHour, (int)workingshift.StartMinute);
                    this.txtTimeto.SetTimeValue((int)workingshift.EndHour, (int)workingshift.EndMinute);
                    this.txtDuration.Value = workingshift.DurationHour.ToString().PadLeft(2, '0') + ":" + workingshift.DurationMinute.ToString().PadLeft(2, '0');
                }

                this.ddlTypeOfDay.SelectedValue = workingshift.TypeOfDay.ToString();
                this.ddlType.SelectedValue = workingshift.Type.ToString();

                //Save UserID and UpdateDate
                this.WorkingShiftID = workingshift.ID;
                this.OldUpdateDate = workingshift.UpdateDate;
            }
        }
        #endregion

        #region WebMethod
        /// <summary>
        /// Calc Dependent Total
        /// </summary>
        [System.Web.Services.WebMethod]
        public static string CalDuration(string id, string timefrom, string timeto)
        {
            try
            {
                int workingshiftID = int.Parse(id);
                string[] temp = new string[2];
                temp = timefrom.Split(':');
                DateTime timeFrom = new DateTime(2014, 10, 1, int.Parse(temp[0]), int.Parse(temp[1]), 0);
                temp = new string[2];
                temp = timeto.Split(':');
                DateTime timeTo = new DateTime(2014, 10, 1, int.Parse(temp[0]), int.Parse(temp[1]), 0);
                TimeSpan Result = timeTo.Subtract(timeFrom);

                if (workingshiftID != 0)
                {
                    
                    IList<RestTime> listRest = new List<RestTime>();
                    using (DB db = new DB())
                    {
                        RestTimeService timeSer = new RestTimeService(db);
                        listRest = timeSer.GetListByShiftID(workingshiftID);
                    }
                    
                    Result = CommonService.CalDurationWorkTime(timeFrom, timeTo, listRest);
                    listRest = null;
                }

                if (timeto == "23:59")
                {
                    TimeSpan timetemp = new TimeSpan(0, 1, 0);
                    Result = Result.Add(timetemp);
                }

                System.Text.StringBuilder result = new System.Text.StringBuilder();

                result.Append("{");
                result.Append(string.Format("\"txtDuration\":\"{0}\"", Result.TotalMinutes < 0 ? "" : (Result.Days * 24 + Result.Hours).ToString("00") + ":" + Result.Minutes.ToString("00")));
                result.Append("}");

                return result.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return null;
            }
        }
        #endregion
    }
}
﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Master
{
    /// <summary>
    /// TRAM
    /// FrmLinkDetail
    /// </summary>
    public partial class FrmLinkDetail : FrmBaseDetail
    {
        #region Constant
        private const string URL_LIST = "~/Master/FrmLinkList.aspx";
        #endregion

        #region Variable

        /// <summary>
        /// 
        /// </summary>
        public bool isHasData;

        /// <summary>
        /// 
        /// </summary>
        public bool isHasDataUserLeft;

        /// <summary>
        /// 
        /// </summary>
        public bool isHasDataUserRight;

        #endregion

        #region View state

        /// <summary>
        /// Get or set UserListInDatabase
        /// </summary>
        private IList<M_Form_Link> UserListInDatabase
        {
            get
            {
                return (IList<M_Form_Link>)base.ViewState["UserListInDatabase"];
            }
            set
            {
                base.ViewState["UserListInDatabase"] = value;
            }
        }

        /// <summary>
        /// Get or set CurrentUserListInDatabase
        /// </summary>
        private IList<M_Form_Link> CurrentUserListInDatabase
        {
            get
            {
                return (IList<M_Form_Link>)base.ViewState["CurrentUserListInDatabase"];
            }
            set
            {
                base.ViewState["CurrentUserListInDatabase"] = value;
            }
        }

        /// <summary>
        /// Get or set UserUnApproveList
        /// </summary>
        private IList<UserInfoForFormLink> UserListUnApprove
        {
            get
            {
                return (IList<UserInfoForFormLink>)base.ViewState["UserListUnApprove"];
            }
            set
            {
                base.ViewState["UserListUnApprove"] = value;
            }
        }

        /// <summary>
        /// Get or set ApproverList
        /// </summary>
        private IList<RouteDetailListInfo> ApproverList
        {
            get
            {
                return (IList<RouteDetailListInfo>)base.ViewState["ApproverList"];
            }
            set
            {
                base.ViewState["ApproverList"] = value;
            }
        }

        /// <summary>
        /// Get or set UserUnApproveList
        /// </summary>
        private IList<UserInfoForFormLink> UserListInFormLink
        {
            get
            {
                return (IList<UserInfoForFormLink>)base.ViewState["UserListInFormLink"];
            }
            set
            {
                base.ViewState["UserListInFormLink"] = value;
            }
        }

        /// <summary>
        /// Get or set FormID
        /// </summary>
        private int FormID
        {
            get
            {
                return int.Parse(base.ViewState["FormID"].ToString());
            }
            set
            {
                base.ViewState["FormID"] = value;
            }
        }

        /// <summary>
        /// Get or set RouteID
        /// </summary>
        private int RouteID
        {
            get
            {
                return int.Parse(base.ViewState["RouteID"].ToString());
            }
            set
            {
                base.ViewState["RouteID"] = value;
            }
        }

        /// <summary>
        /// Get or set OldUpdateOfRoute
        /// </summary>
        private DateTime OldUpdateOfRoute
        {
            get
            {
                return (DateTime)base.ViewState["OldUpdateOfRoute"];
            }
            set
            {
                base.ViewState["OldUpdateOfRoute"] = value;
            }
        }


        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Link Master";
            base.FormSubTitle = "Detail";

            // //header grid sort
            this.HeaderGridLeft.OnSortClick += SortLeft_Click;

            //// paging footer
            this.PagingFooterLeft.OnClick += PagingFooterLeft_Click;

            // //header grid sort
            this.HeaderGridRight.OnSortClick += SortRight_Click;

            //// paging footer
            this.PagingFooterRight.OnClick += PagingFooterRight_Click;

            //// paging header
            this.PagingHeaderLeft.OnClick += PagingHeaderLeft_Click;
            this.PagingHeaderLeft.OnPagingClick += PagingFooterLeft_Click;
            this.PagingHeaderLeft.NumRowOnPage = this.GetDefaultValuePaging();
            this.PagingHeaderLeft.CurrentPage = 1;

            this.PagingHeaderRight.OnClick += PagingHeaderRight_Click;
            this.PagingHeaderRight.OnPagingClick += PagingFooterRight_Click;
            this.PagingHeaderRight.NumRowOnPage = this.GetDefaultValuePaging();
            this.PagingHeaderRight.CurrentPage = 1;

            this.HeaderGridLeft.IsShowEmpty = true;
            this.HeaderGridLeft.AddColumms(new string[] { "", "Department", "", "Applicant", "Position" });
            this.HeaderGridRight.IsShowEmpty = true;
            this.HeaderGridRight.AddColumms(new string[] { "", "Department", "", "Employee", "Position" });
            this.PagingHeaderLeft.IsShowEmpty = true;
            this.PagingHeaderRight.IsShowEmpty = true;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnShowData);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Link);
            if (!this._authority.IsMasterView)
            {
                Response.Redirect("~/Menu/FrmMasterMenu.aspx");
            }
            if (!this.IsPostBack)
            {
                this.InitData();
                if (base.PreviousPage != null)
                {
                    //Save condition of previous page
                    base.ViewState["Condition"] = base.PreviousPageViewState["Condition"];

                    //Check mode
                    if (base.PreviousPageViewState["FormID"] == null && base.PreviousPageViewState["RouteID"] == null)
                    {

                        //Set mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get config data by ID
                        this.FormID = int.Parse(base.PreviousPageViewState["FormID"].ToString());
                        this.RouteID = int.Parse(base.PreviousPageViewState["RouteID"].ToString());
                        this.InitComboboxRoute(this.FormID);
                        FormLinkMaster formLink = this.GetDataByFormIDAndRouteID(this.FormID, this.RouteID);

                        if (formLink != null)
                        {
                            //Show data
                            this.ShowMasterData(formLink);
                            this.FillDataForApproverList();
                            this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                            this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooterLeft_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.ProcessPagingFooterClick(sender, this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft);
            }
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooterRight_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.ProcessPagingFooterClick(sender, this.PagingHeaderRight, this.PagingFooterRight, this.HeaderGridRight);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeaderLeft_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.ProcessPagingHeaderClick(this.HeaderGridLeft);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeaderRight_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.ProcessPagingHeaderClick(this.HeaderGridLeft);
            }
        }

        #region Sort data on the grid

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SortLeft_Click(object sender, EventArgs e)
        {
            this.ProcessSortPageClick(this.PagingHeaderLeft);
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void SortRight_Click(object sender, EventArgs e)
        {
            this.ProcessSortPageClick(this.PagingHeaderRight);
        }

        #endregion

        #region Process Add button

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddDept_Click(object sender, CommandEventArgs e)
        {
            if (this.UserListUnApprove != null && this.UserListUnApprove.Count > 0)
            {
                var key = e.CommandArgument;

                IList<UserInfoForFormLink> staffListUnApprove = new List<UserInfoForFormLink>();
                IList<UserInfoForFormLink> staffList = new List<UserInfoForFormLink>();

                if (this.UserListInFormLink != null && this.UserListInFormLink.Count > 0)
                {
                    foreach (UserInfoForFormLink user in this.UserListInFormLink)
                    {
                        if (!this.IsEmptyRow(user))
                        {
                            staffList.Add(user);
                        }
                    }
                }

                staffListUnApprove = (from user in this.UserListUnApprove
                                      where user.DepartmentID == int.Parse(key.ToString())
                                      select user).ToList();

                if (staffListUnApprove != null && staffListUnApprove.Count > 0)
                {

                    foreach (UserInfoForFormLink userUnApprove in staffListUnApprove)
                    {

                        UserInfoForFormLink user = new UserInfoForFormLink();
                        user.DepartmentID = userUnApprove.DepartmentID;
                        user.DepartmentCD = userUnApprove.DepartmentCD;
                        user.DepartmentName = userUnApprove.DepartmentName;
                        user.UserID = userUnApprove.UserID;
                        user.StaffCD = userUnApprove.StaffCD;
                        user.StaffName = userUnApprove.StaffName;
                        user.Position = userUnApprove.Position;
                        user.AppliedFlag = userUnApprove.AppliedFlag;
                        staffList.Add(user);

                        this.isHasDataUserLeft = true;

                    }

                    staffList = (from item in staffList
                                 orderby item.DepartmentName, item.StaffCD ascending
                                 select item).ToList();

                    for (int i = 0; i < staffList.Count; i++)
                    {
                        staffList[i].RowNumber = i + 1;

                    }

                    //Check disable move button
                    UserInfoForFormLink itemPrev = new UserInfoForFormLink();
                    if (staffList != null && staffList.Count > 0)
                    {
                        itemPrev = staffList[0];
                    }

                    foreach (UserInfoForFormLink item in staffList)
                    {
                        int count = (from row in staffList
                                     where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                                     select row).Count();

                        if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                        {
                            item.CountAllowMove = count;
                        }
                        else
                        {
                            itemPrev = item;
                            item.CountAllowMove = count;
                        }
                    }

                    this.UserListInFormLink = staffList;

                    int totalRow = this.UserListInFormLink.Count;
                    //Show data

                    //Get data list depend on pageIndex and pageSize
                    int numOnPage = this.PagingHeaderLeft.NumRowOnPage;
                    int pageIndex = this.PagingHeaderLeft.CurrentPage;

                    if (staffList.Count > numOnPage)
                    {
                        staffList = staffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                    }

                    this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, staffList, totalRow, pageIndex, numOnPage);

                    this.rptUserListLeft.DataSource = staffList;
                    this.rptUserListLeft.DataBind();

                    ////Reload 
                    this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                    this.FillDataForApproverList();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAddUser_Click(object sender, CommandEventArgs e)
        {
            var key = e.CommandArgument;

            UserInfoForFormLink userUnApprove = new UserInfoForFormLink();

            IList<UserInfoForFormLink> staffList = new List<UserInfoForFormLink>();
            if (this.UserListInFormLink != null && this.UserListInFormLink.Count > 0)
            {
                foreach (UserInfoForFormLink user in this.UserListInFormLink)
                {
                    if (!this.IsEmptyRow(user))
                    {
                        staffList.Add(user);
                    }
                }
            }
            userUnApprove = (from user in this.UserListUnApprove
                             where user.StaffCD == (key.ToString())
                             select user).FirstOrDefault();

            if (userUnApprove != null)
            {
                UserInfoForFormLink user = new UserInfoForFormLink();
                user.DepartmentID = userUnApprove.DepartmentID;
                user.DepartmentCD = userUnApprove.DepartmentCD;
                user.DepartmentName = userUnApprove.DepartmentName;
                user.UserID = userUnApprove.UserID;
                user.StaffCD = userUnApprove.StaffCD;
                user.StaffName = userUnApprove.StaffName;
                user.Position = userUnApprove.Position;
                user.AppliedFlag = userUnApprove.AppliedFlag;

                if (this.UserListInFormLink != null)
                {
                    IList<UserInfoForFormLink> existedList = new List<UserInfoForFormLink>();
                    existedList = (from user1 in this.UserListInFormLink
                                   where user1.DepartmentID == userUnApprove.DepartmentID
                                   select user1).ToList();
                    if (existedList != null && existedList.Count > 0)
                    {
                        int index = this.UserListInFormLink.IndexOf(existedList[existedList.Count - 1]);

                        user.RowNumber = existedList.Count + 1;
                        staffList.Insert(index, user);
                    }
                    else
                    {
                        user.RowNumber = this.UserListUnApprove.Count + 1;
                        staffList.Add(user);
                    }
                }
                else
                {
                    user.RowNumber += 1;
                    staffList.Add(user);
                }

                this.isHasDataUserLeft = true;

                staffList = (from item in staffList
                             orderby item.DepartmentName, item.StaffCD, item.StaffName ascending
                             select item).ToList();
                for (int i = 0; i < staffList.Count; i++)
                {
                    staffList[i].RowNumber = i + 1;
                }

                //Check disable move button
                UserInfoForFormLink itemPrev = new UserInfoForFormLink();
                if (staffList != null && staffList.Count > 0)
                {
                    itemPrev = staffList[0];
                }

                foreach (UserInfoForFormLink item in staffList)
                {
                    int count = (from row in staffList
                                 where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                                 select row).Count();

                    if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                    {
                        item.CountAllowMove = count;
                    }
                    else
                    {
                        itemPrev = item;
                        item.CountAllowMove = count;
                    }
                }

                this.UserListInFormLink = staffList;

                int totalRow = this.UserListInFormLink.Count;
                //Show data

                //Get data list depend on pageIndex and pageSize
                int numOnPage = this.PagingHeaderLeft.NumRowOnPage;
                int pageIndex = this.PagingHeaderLeft.CurrentPage;

                if (staffList.Count > numOnPage)
                {
                    staffList = staffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                }

                this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, staffList, totalRow, pageIndex, numOnPage);

                this.rptUserListLeft.DataSource = staffList;
                this.rptUserListLeft.DataBind();

                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                this.FillDataForApproverList();
            }
        }

        #endregion

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Information
            FormLinkMaster data = this.GetDataByFormIDAndRouteID(this.FormID, this.RouteID);

            //Check Information
            if (data != null)
            {
                //Show data
                this.ShowMasterData(data);
                this.FillDataForApproverList();
                this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            this.Mode = Mode.Insert;
            if (!this.cmbTypeFormatForm.SelectedValue.Equals("-1"))
            {
                this.InitComboboxRoute(int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString()));
            }

            this.cmbRoute.SelectedValue = "-1";
            this.UserListInFormLink = null;
            this.UserListUnApprove = null;

            //Set Mode
            this.ProcessMode(this.Mode);
        }

        #region Process Remove button

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveUser_Click(object sender, CommandEventArgs e)
        {
            var key = e.CommandArgument;
            IList<UserInfoForFormLink> staffList = new List<UserInfoForFormLink>();
            staffList = (from staff in this.UserListInFormLink
                         where staff.StaffCD != key.ToString()
                         select staff).ToList();
            if (staffList != null && staffList.Count > 0)
            {
                this.isHasDataUserLeft = true;
            }
            else
            {
                this.isHasDataUserLeft = false;
            }

            int totalRow = staffList.Count;

            int countUserInDept = 0;
            IList<int> deptList = new List<int>();
            foreach (UserInfoForFormLink row in staffList)
            {
                if (!deptList.Contains(row.DepartmentID))
                {
                    countUserInDept = (from item in staffList
                                       where item.DepartmentID == row.DepartmentID
                                       select item
                                      ).Count();
                    deptList.Add(row.DepartmentID);

                }

                row.CountAllowMove = 0;

            }

            for (int i = 0; i < staffList.Count; i++)
            {
                staffList[i].RowNumber = i + 1;

            }

            //Check disable move button
            UserInfoForFormLink itemPrev = new UserInfoForFormLink();
            if (staffList != null && staffList.Count > 0)
            {
                itemPrev = staffList[0];
            }

            foreach (UserInfoForFormLink item in staffList)
            {
                int count = (from row in staffList
                             where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                             select row).Count();

                if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                {
                    item.CountAllowMove = count;
                }
                else
                {
                    itemPrev = item;
                    item.CountAllowMove = count;
                }
            }

            this.UserListInFormLink = staffList;

            //Get data list depend on pageIndex and pageSize
            int numOnPage = this.PagingHeaderLeft.NumRowOnPage;
            int pageIndex = this.PagingHeaderLeft.CurrentPage;

            if (staffList.Count > numOnPage)
            {
                staffList = staffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            }

            this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, staffList, totalRow, pageIndex, numOnPage);
            this.rptUserListLeft.DataSource = staffList;
            this.rptUserListLeft.DataBind();

            //Reload right grid
            UserInfoForFormLink staffUnApp = new UserInfoForFormLink();
            staffUnApp.StaffCD = key.ToString();
            IList<UserInfoForFormLink> existedList = new List<UserInfoForFormLink>();

            //UserService userSer = new UserService();
            //M_UserInfo userInfo = userSer.GetUserInfo(key.ToString(),false);

            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo staffInfo = staffSer.GetStaffInfoByStaffCD(key.ToString());
                if (staffInfo != null)
                {
                    //userUnApp.StaffName = userInfo.UserName2;
                    //userUnApp.DepartmentID = userInfo.DepartmentID;
                    //userUnApp.DepartmentName = userInfo.DepartmentName;
                    //userUnApp.Position = userInfo.Position2;
                    //userUnApp.UserID = userInfo.ID;

                    staffUnApp.StaffName = staffInfo.StaffName;
                    staffUnApp.DepartmentID = staffInfo.DepartmentID;
                    staffUnApp.DepartmentName = staffInfo.DepartmentName;
                    staffUnApp.Position = staffInfo.Position;
                    staffUnApp.UserID = staffInfo.UserID;
                    existedList = (from staff1 in this.UserListUnApprove
                                   where staff1.DepartmentID == staffInfo.DepartmentID
                                   select staff1).ToList();
                }
            }

            if (existedList != null && existedList.Count > 0)
            {
                int index = this.UserListUnApprove.IndexOf(existedList[existedList.Count - 1]);
                this.UserListUnApprove.Insert(index + 1, staffUnApp);
            }
            else
            {
                this.UserListUnApprove.Add(staffUnApp);
            }

            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
            this.FillDataForApproverList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnRemoveDept_Click(object sender, CommandEventArgs e)
        {
            var key = e.CommandArgument;
            IList<UserInfoForFormLink> removeList = new List<UserInfoForFormLink>();

            //Get the removed list
            removeList = (from removeInfo in this.UserListInFormLink
                          where removeInfo.DepartmentID == int.Parse(key.ToString()) && removeInfo.AppliedFlag == 0
                          select removeInfo).ToList();

            //Add removed list into the right grid
            if (removeList != null && removeList.Count > 0)
            {
                foreach (UserInfoForFormLink removeInfo in removeList)
                {
                    UserInfoForFormLink staffInfo = new UserInfoForFormLink();
                    staffInfo.DepartmentID = removeInfo.DepartmentID;
                    staffInfo.DepartmentName = removeInfo.DepartmentName;
                    staffInfo.UserID = removeInfo.UserID;
                    staffInfo.StaffCD = removeInfo.StaffCD;
                    staffInfo.StaffName = removeInfo.StaffName;
                    staffInfo.Position = removeInfo.Position;
                    staffInfo.AppliedFlag = removeInfo.AppliedFlag;

                    //Get data list existed on the right grid with the removed Department
                    IList<UserInfoForFormLink> existedList = new List<UserInfoForFormLink>();
                    existedList = (from staffUnApp in this.UserListUnApprove
                                   where staffUnApp.DepartmentID == int.Parse(key.ToString())
                                   select staffUnApp).ToList();

                    //If existed
                    if (existedList != null && existedList.Count > 0)
                    {
                        int index = this.UserListUnApprove.IndexOf(existedList[existedList.Count - 1]);

                        //Insert data into the next position of find data
                        this.UserListUnApprove.Insert(index + 1, staffInfo);
                    }
                    else
                    {
                        //Remove empty row on the right grid
                        if (this.UserListUnApprove.Count == 1 && this.UserListUnApprove[0].DepartmentID == 0)
                        {
                            this.UserListUnApprove.Remove(this.UserListUnApprove[0]);
                        }

                        //add data into data list on the right grid
                        this.UserListUnApprove.Add(staffInfo);
                    }
                }
            }

            //Get data list which remain in the left grid
            IList<UserInfoForFormLink> staffList = new List<UserInfoForFormLink>();
            staffList = (from user in this.UserListInFormLink
                         where user.DepartmentID != int.Parse(key.ToString()) || user.AppliedFlag == 1
                         select user).ToList();
            if (staffList != null && staffList.Count > 0)
            {
                this.isHasDataUserLeft = true;
            }
            else
            {
                this.isHasDataUserLeft = false;
            }

            //if the left grid is empty
            if (staffList == null || staffList.Count == 0)
            {
                //Add empty row into the left grid
                UserInfoForFormLink user = new UserInfoForFormLink();
                user.RowNumber = 0;
                staffList.Add(user);
                this.isHasDataUserLeft = false;
            }

            int totalRow = staffList.Count;

            int countUserInDept = 0;
            IList<int> deptList = new List<int>();
            foreach (UserInfoForFormLink row in staffList)
            {
                if (!deptList.Contains(row.DepartmentID))
                {
                    countUserInDept = (from item in staffList
                                       where item.DepartmentID == row.DepartmentID
                                       select item
                                      ).Count();
                    deptList.Add(row.DepartmentID);

                }
                row.CountAllowMove = 0;

            }

            //Set RowNumber
            for (int i = 0; i < staffList.Count; i++)
            {
                staffList[i].RowNumber = i + 1;
            }

            //Check disable move button
            UserInfoForFormLink itemPrev = new UserInfoForFormLink();
            if (staffList != null && staffList.Count > 0)
            {
                itemPrev = staffList[0];
            }

            foreach (UserInfoForFormLink item in staffList)
            {
                int count = (from row in staffList
                             where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                             select row).Count();

                if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                {
                    item.CountAllowMove = count;
                }
                else
                {
                    itemPrev = item;
                    item.CountAllowMove = count;
                }
            }

            //Keep data list on the left grid
            this.UserListInFormLink = staffList;

            //Get data list depend on pageIndex and pageSize
            int numOnPage = this.PagingHeaderLeft.NumRowOnPage;
            int pageIndex = this.PagingHeaderLeft.CurrentPage;
            if (staffList.Count > numOnPage)
            {
                staffList = staffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            }

            //Load paging for gird
            this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, staffList, totalRow, pageIndex, numOnPage);

            //Set datasource for the left grid
            this.rptUserListLeft.DataSource = staffList;
            this.rptUserListLeft.DataBind();

            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

            //Fill data for approver list
            this.FillDataForApproverList();
        }

        #endregion

        /// <summary>
        /// Change Route combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbRoute_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.cmbRoute.SelectedValue) && this.cmbRoute.SelectedValue != "-1")
            {
                M_Route_H oldRouteH = this.GetRouteHInfoByID(int.Parse(this.cmbRoute.SelectedValue.ToString()));
                if (oldRouteH != null)
                {
                    this.OldUpdateOfRoute = oldRouteH.UpdateDate;
                }

                this.FillDataForApproverList();
                if (this.Mode != Mode.Update)
                {
                    this.UserListInFormLink = null;
                    this.FillDataForRouteListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                    this.FillDataForRouteListLeft(this.PagingHeaderLeft.CurrentPage, this.PagingHeaderLeft.NumRowOnPage);
                }
                else
                {
                    using (DB db = new DB())
                    {
                        FormLinkService formLinkSer = new FormLinkService(db);
                        this.CurrentUserListInDatabase = formLinkSer.GetListByFormIDAndRouteID(this.FormID, int.Parse(cmbRoute.SelectedValue.ToString()));
                        this.ReLoadUserGridLeft(this.HeaderGridLeft);
                        this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                        //this.FillDataForRouteListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                    }
                }

            }
        }

        /// <summary>
        /// Change TypeFormatForm combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbTypeFormatForm_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(this.cmbTypeFormatForm.SelectedValue))
            {
                this.InitComboboxRoute(int.Parse(this.cmbTypeFormatForm.SelectedValue));
            }
        }

        /// <summary>
        /// Insert click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                this.FillDataForApproverList();
                return;
            }

            this.ReLoadUserGridLeft(this.HeaderGridLeft);
            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// Edit click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            this.InitComboboxRoute(this.FormID);

            //Show route data
            FormLinkMaster formLink = this.GetDataByFormIDAndRouteID(this.FormID, this.RouteID);

            //Check route
            if (formLink != null)
            {
                //Show user data
                this.ShowMasterData(formLink);
                this.FillDataForApproverList();
                this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);

                //Set Mode
                this.ProcessMode(Mode.Update);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// Update click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Show user click
            //this.FillDataForApproverList();
            //this.ReLoadUserGridLeft(this.HeaderGridLeft);
            //this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, Models.DefaultButton.Yes);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;
            this.FillDataForApproverList();
            this.ReLoadUserGridLeft(this.HeaderGridLeft);
            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, Models.DefaultButton.No, true);
        }

        #endregion

        #region Method

        #region Initiate data
        /// <summary>
        /// Initiate data
        /// </summary>
        private void InitData()
        {
            //Init Combovbox Type
            this.InitComboboxFormType();
            if (!string.IsNullOrEmpty(this.cmbTypeFormatForm.SelectedValue))
            {
                this.InitComboboxRoute(int.Parse(this.cmbTypeFormatForm.SelectedValue));
            }

            if (!string.IsNullOrEmpty(this.cmbRoute.SelectedValue))
            {
                this.FillDataForApproverList();
            }

            // header grid
            this.HeaderGridLeft.SortDirec = "1";
            this.HeaderGridLeft.SortField = "2";

            this.HeaderGridRight.SortDirec = "1";
            this.HeaderGridRight.SortField = "2";
        }

        /// <summary>
        /// Init FormType combobox
        /// </summary>
        private void InitComboboxFormType()
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> formTypeList = new List<DropDownModel>();
                FormService formService = new FormService(db);
                formTypeList = formService.GetDataForDropdown(false);
                this.cmbTypeFormatForm.DataSource = formTypeList;
            }
            this.cmbTypeFormatForm.DataValueField = "Value";
            this.cmbTypeFormatForm.DataTextField = "DisplayName";
            this.cmbTypeFormatForm.DataBind();
        }

        /// <summary>
        /// Init Route combobox
        /// </summary>
        private void InitComboboxRoute(int formTypeID)
        {
            using (DB db = new DB())
            {
                IList<DropDownModel> routeList = new List<DropDownModel>();
                FormRouteService formRouteSer = new FormRouteService(db);
                routeList = formRouteSer.GetDataForDropdown(formTypeID, true);
                IList<DropDownModel> allowList = new List<DropDownModel>();
                allowList = routeList;
                FormLinkService formLinkSer = new FormLinkService(db);

                //Remove data existed in database
                if (this.Mode == Mode.Insert || (base.PreviousPageViewState != null && base.PreviousPageViewState["FormID"] == null && base.PreviousPageViewState["RouteID"] == null))
                {
                    if (!this.cmbTypeFormatForm.SelectedValue.Equals("-1") && routeList != null && routeList.Count > 0)
                    {

                        IList<int> routeIDList = formLinkSer.GetRouteIDByFormID(int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString()));

                        if (routeIDList != null && routeIDList.Count > 0)
                        {
                            allowList = (from route in routeList
                                         where !routeIDList.Contains(int.Parse(route.Value))
                                         select route).ToList();
                        }

                    }

                }

                this.cmbRoute.DataSource = allowList;
            }
            this.cmbRoute.DataValueField = "Value";
            this.cmbRoute.DataTextField = "DisplayName";
            this.cmbRoute.DataBind();
        }

        #endregion

        #region Get data

        /// <summary>
        /// Get Default Value
        /// </summary>
        /// <returns></returns>
        private int GetDefaultValuePaging()
        {
            using (DB db = new DB())
            {
                Config_HService service = new Config_HService(db);
                string ret = service.GetDefaultValueDrop(M_Config_H.CONFIG_CD_PAGING);
                return string.IsNullOrEmpty(ret) ? 0 : int.Parse(ret);
            }
        }

        /// <summary>
        /// Get Default Value
        /// </summary>
        /// <returns></returns>
        private FormLinkMaster GetDataByFormIDAndRouteID(int formID, int routeID)
        {
            using (DB db = new DB())
            {
                FormLinkService formLinkSer = new FormLinkService(db);
                FormLinkMaster formLink = formLinkSer.GetByFormIDAndRouteID(formID, routeID);
                return formLink;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private M_Form_Link GetDataByKey(int formID, int userID)
        {
            using (DB db = new DB())
            {
                FormLinkService formLinkSer = new FormLinkService(db);
                M_Form_Link formLink = formLinkSer.GetByKey(formID, userID);
                return formLink;
            }
        }

        /// <summary>
        /// Get M_Route_H info by ID
        /// </summary>
        /// <param name="routeID"></param>
        /// <returns></returns>
        private M_Route_H GetRouteHInfoByID(int routeID)
        {
            using (DB db = new DB())
            {
                Route_HService routeH_Ser = new Route_HService(db);
                M_Route_H routeH = routeH_Ser.GetByID(routeID);
                return routeH;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private int GetUserIDbByStaffCode(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                M_StaffInfo staff = staffSer.GetStaffInfoByStaffCD(staffCD);
                if (staff != null)
                {
                    return staff.UserID;
                }
                return 0;
            }
        }

        #endregion

        #region Process mode

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;
            switch (this.Mode)
            {
                case Mode.Insert:
                    this.cmbTypeFormatForm.Enabled = true;
                    this.cmbRoute.Enabled = true;
                    break;
                case Mode.Update:
                    this.HeaderGridLeft.SortField = "2";
                    this.HeaderGridLeft.SortDirec = "1";
                    this.cmbTypeFormatForm.Enabled = false;
                    bool disableRoute = false;
                    foreach (UserInfoForFormLink item in this.UserListInFormLink)
                    {
                        if (this.checkUserExistedInApply(item.UserID, this.FormID))
                        {
                            this.cmbRoute.Enabled = false;
                            disableRoute = true;
                            break;
                        }

                    }

                    if (!disableRoute)
                    {
                        this.cmbRoute.Enabled = true;
                    }

                    break;
                default:

                    this.PagingHeaderLeft.CurrentPage = 1;

                    this.cmbTypeFormatForm.Enabled = false;
                    this.cmbRoute.Enabled = false;


                    break;
            }

            //Set disable button
            base.DisabledLink(this.btnNew, !base._authority.IsMasterNew);
            base.DisabledLink(this.btnEdit, !base._authority.IsMasterEdit);
            base.DisabledLink(this.btnDelete, !base._authority.IsMasterDelete);
        }

        #endregion

        #region CheckData

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private bool IsExistData()
        {
            using (DB db = new DB())
            {
                FormLinkService formLinkSer = new FormLinkService(db);
                FormLinkMaster info = formLinkSer.GetByFormIDAndRouteID(this.FormID, this.RouteID);
                return info != null;
            }
        }

        /// <summary>
        /// Check existing of UserID and FormID in T_Apply table
        /// </summary>
        /// <param name="userID">UserID</param>
        /// <param name="formID">FormID</param>
        /// <returns></returns>
        private bool checkUserExistedInApply(int userID, int formID)
        {

            //Check existing of UserID and FormID in T_Apply table
            //FormTypeService formTypeSer = new FormTypeService();
            //IList<FormTypeInfo> formTypeList = formTypeSer.GetListByFormID(formID);
            //foreach (FormTypeInfo formTypeInfo in formTypeList)
            //{
            //    ApplyService applySer = new ApplyService();
            //    T_Apply apply = applySer.GetByUserIDAndTypeAppy(userID, formTypeInfo.ID);
            //    if (apply != null)
            //    {
            //        if (apply.ApplyStatus ==(int) StatusApply.Draft)
            //        {
            //            return true;
            //        }

            //    }
            //}

            return false;
        }

        /// <summary>
        /// Check the empty row
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private bool IsEmptyRow(UserInfoForFormLink row)
        {
            return (row.DepartmentID == 0 && row.DepartmentName == string.Empty && row.UserID == 0 && row.StaffCD == string.Empty && row.StaffName == string.Empty && row.Position == string.Empty);
        }

        /// <summary>
        /// Check inputting data
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {

            if (!this.cmbTypeFormatForm.SelectedValue.Equals("-1") && !this.cmbRoute.SelectedValue.Equals("-1"))
            {
                this.FillDataForApproverList();
                if (this.UserListInFormLink != null && this.UserListInFormLink.Count > 0)
                {
                    this.ReLoadUserGridLeft(this.HeaderGridLeft);
                    this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                }
                else
                {
                    this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);
                }
            }

            //TypeFormatForm
            if (this.cmbTypeFormatForm.SelectedValue.Equals("-1"))
            {
                this.SetMessage(this.cmbTypeFormatForm.ID, M_Message.MSG_REQUIRE, "Type Format Form");
            }

            //Route
            if (this.cmbRoute.SelectedValue.Equals("-1"))
            {
                this.SetMessage(this.cmbRoute.ID, M_Message.MSG_REQUIRE, "Route");
            }
            else
            {
                //Remove check required applicant
                //if (this.UserListInFormLink == null || this.UserListInFormLink.Count == 0 || (this.UserListInFormLink.Count == 1 && this.IsEmptyRow(this.UserListInFormLink[0])))
                //{
                //    this.SetMessage("", M_Message.MSG_PLEASE_SELECT, "Applicant");
                //}

                if (this.Mode == Mode.Update)
                {
                    if (this.UserListInFormLink != null && this.UserListInFormLink.Count > 0)
                    {
                        foreach (RouteDetailListInfo approver in this.ApproverList)
                        {
                            UserInfoForFormLink staffLink = (from item in this.UserListInFormLink
                                                             where item.StaffCD == approver.StaffCD
                                                             select item
                                                            ).SingleOrDefault();

                            if (staffLink != null)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DUPLICATE_USER);
                                break;
                            }
                        }
                    }
                }

                //Check applicant user not exists or invalid
                if (this.UserListInFormLink != null && this.UserListInFormLink.Count >0)
                {
                    foreach (var item in this.UserListInFormLink)
                    {
                        using (DB db = new DB())
                        {
                            UserService service = new UserService(db);
                            var user = service.GetByID(item.UserID);

                            if (user != null && user.StatusFlag == 1)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_NOT_EXIST_CODE_GRID,string.Format("Applicant [{0}] {1}",item.DepartmentName,item.StaffName),item.RowNumber);
                                break;
                            }
                        }
                    }
                }
            }

            //Check error
            return !base.HaveError;
        }

        #endregion

        #region Register data

        /// <summary>
        /// Process Insert, Update, Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            using (DB db = new DB())
            {
                //Check Mode
                switch (this.Mode)
                {
                    case Utilities.Mode.Insert:

                        //Insert Data
                        if (this.InsertProcess())
                        {
                            //Show route data

                            this.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString());
                            this.RouteID = int.Parse(this.cmbRoute.SelectedValue.ToString());
                            FormLinkService formLinkSer = new FormLinkService(db);
                            FormLinkMaster formLink = formLinkSer.GetByFormIDAndRouteID(this.FormID, this.RouteID);

                            //Show master data
                            this.ShowMasterData(formLink);

                            this.FillDataForApproverList();
                            this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                            this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                        else
                        {
                            this.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString());
                            this.RouteID = int.Parse(this.cmbRoute.SelectedValue.ToString());
                            FormLinkService formLinkSer = new FormLinkService(db);
                            FormLinkMaster formLink = formLinkSer.GetByFormIDAndRouteID(this.FormID, this.RouteID);

                            //Show master data
                            this.ShowMasterData(formLink);

                            this.FillDataForApproverList();
                            this.ReLoadUserGridLeft(this.HeaderGridLeft);
                            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                        }
                        break;

                    case Utilities.Mode.Update:
                        if (this.UpdateData())
                        {
                            this.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue);
                            this.RouteID = int.Parse(this.cmbRoute.SelectedValue);

                            FormLinkService formLinkSer = new FormLinkService(db);
                            FormLinkMaster formLink = formLinkSer.GetByFormIDAndRouteID(this.FormID, this.RouteID);
                            this.UserListInDatabase = formLinkSer.GetListByFormIDAndRouteID(this.FormID, this.RouteID);

                            //Show master data
                            this.ShowMasterData(formLink);
                            this.FillDataForApproverList();
                            this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                            this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);

                            //Set Mode
                            this.ProcessMode(Mode.View);

                            //Set Success
                            this.Success = true;
                        }
                        else
                        {
                            this.FillDataForApproverList();
                            this.ReLoadUserGridLeft(this.HeaderGridLeft);
                            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                        }

                        break;

                    case Utilities.Mode.Delete:

                        //Delete Department
                        if (!this.DeleteData())
                        {
                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                        break;

                }
            }
        }

        /// <summary>
        /// Show Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnShowData(object sender, EventArgs e)
        {
            FormLinkMaster master = this.GetDataByFormIDAndRouteID(int.Parse(this.cmbTypeFormatForm.SelectedValue), int.Parse(this.cmbRoute.SelectedValue));
            if (master != null)
            {
                this.FillDataForApproverList();
                this.ReLoadUserGridLeft(this.HeaderGridLeft);
                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        #endregion

        #region Insert data

        /// <summary>
        /// Process insert
        /// </summary>
        private bool InsertProcess()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    //Check FormID exist in M_Form table
                    FormService formSer = new FormService(db);
                    M_Form form = formSer.GetByID(int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString()));
                    if (form == null)
                    {
                        this.SetMessage(this.cmbTypeFormatForm.ID, M_Message.MSG_DATA_NOT_EXISTS);
                        return false;
                    }
                    else
                    {
                        //Check RouteID exist in M_Form_Route table
                        FormRouteService formRouteSer = new FormRouteService(db);
                        M_Form_Route formRoute = formRouteSer.GetByKey(int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString()), int.Parse(this.cmbRoute.SelectedValue.ToString()));
                        if (formRoute == null)
                        {
                            this.SetMessage(this.cmbRoute.ID, M_Message.MSG_DATA_NOT_EXISTS);
                            return false;
                        }
                        else
                        {
                            //Check changing data of M_Route_H
                            M_Route_H routeH = this.GetRouteHInfoByID(int.Parse(this.cmbRoute.SelectedValue.ToString()));
                            if (routeH != null)
                            {
                                if (routeH.UpdateDate != this.OldUpdateOfRoute)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }

                            this.InsertData(db);
                        }
                    }

                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                if (ex.Message.Contains(Models.Constant.M_FORM_LINK_PK))
                {
                    this.FillDataForApproverList();
                    this.ReLoadUserGridLeft(this.HeaderGridLeft);
                    this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                    this.SetMessage(string.Empty, M_Message.MSG_EXIST_CODE, "FormID, UserID");
                }

                Log.Instance.WriteLog(ex);

                return false;
            }
            catch (Exception ex)
            {
                this.FillDataForApproverList();
                this.ReLoadUserGridLeft(this.HeaderGridLeft);
                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="db">Database</param>
        private void InsertData(DB db)
        {
            IList<M_Form_Link> formLinkList = new List<M_Form_Link>();
            FormLinkService formLinkSer = new FormLinkService(db);

            foreach (UserInfoForFormLink row in this.UserListInFormLink)
            {
                M_Form_Link formLink = new M_Form_Link();
                formLink.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString());
                formLink.RouteID = int.Parse(this.cmbRoute.SelectedValue.ToString());
                formLink.UserID = this.GetUserIDbByStaffCode(row.StaffCD);
                formLink.CreateUID = LoginInfo.User.ID;
                formLink.UpdateUID = formLink.CreateUID;

                //Inset form link
                formLinkSer.Insert(formLink);
            }
        }

        #endregion

        #region Update data

        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="db">Database</param>
        private bool UpdateData()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    StaffService staffSer = new StaffService(db);
                    //Check data change
                    if (!this.IsExistData())
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    //Check changing data of M_Route_H
                    M_Route_H routeH = this.GetRouteHInfoByID(int.Parse(this.cmbRoute.SelectedValue.ToString()));
                    if (routeH != null)
                    {
                        if (routeH.UpdateDate != this.OldUpdateOfRoute)
                        {
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                    }

                    int retIns = 0;
                    int retDel = 0;

                    FormLinkService formLinkSer = new FormLinkService(db);


                    //Get user list existed in database
                    IList<string> staffList = formLinkSer.GetUserListByFormIDAndRouteID(this.FormID, this.RouteID);
                    IList<int> userIDlist = (from row1 in this.UserListInDatabase
                                             select row1.UserID).ToList();

                    if (int.Parse(this.cmbRoute.SelectedValue.ToString()) != this.RouteID)
                    {
                        //delete old route in database
                        foreach (string oldStaffCD in staffList)
                        {
                            int oldUserID = this.GetUserIDbByStaffCode(oldStaffCD);

                            if (oldUserID != 0)
                            {
                                if (staffList.Count != this.UserListInDatabase.Count)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }

                                M_Form_Link formLink = formLinkSer.GetByKey(this.FormID, oldUserID);

                                //Get info from database before update
                                M_Form_Link oldInfo = (from row in this.UserListInDatabase
                                                       where row.UserID == oldUserID
                                                       select row).SingleOrDefault();

                                if (formLink.UpdateDate != oldInfo.UpdateDate)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }

                                retDel = formLinkSer.Delete(this.FormID, oldUserID);
                                if (retDel == 0)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }
                        }

                        //Check existing of current route in database
                        //Get user list existed in database
                        IList<string> staffCDList = formLinkSer.GetUserListByFormIDAndRouteID(this.FormID, int.Parse(this.cmbRoute.SelectedValue.ToString()));
                        if (staffCDList != null && staffCDList.Count > 0)
                        {
                            //delete old users of current route
                            foreach (string staffCD in staffCDList)
                            {
                                int userID = this.GetUserIDbByStaffCode(staffCD);

                                if (userID != 0)
                                {
                                    if (staffCDList.Count != this.CurrentUserListInDatabase.Count)
                                    {
                                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                        return false;
                                    }

                                    M_Form_Link currentItem = formLinkSer.GetByKey(this.FormID, userID);

                                    //Get info from database before delete
                                    M_Form_Link oldInfo = (from row in this.CurrentUserListInDatabase
                                                           where row.UserID == userID
                                                           select row).SingleOrDefault();

                                    if (currentItem != null)
                                    {
                                        //Check data has been changed
                                        if (currentItem.UpdateDate != oldInfo.UpdateDate)
                                        {
                                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                            return false;
                                        }

                                    }
                                    retDel = formLinkSer.Delete(this.FormID, userID);
                                    if (retDel == 0)
                                    {
                                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                        return false;
                                    }

                                }
                            }
                        }
                        //insert current users

                        foreach (UserInfoForFormLink row in this.UserListInFormLink)
                        {
                            M_Form_Link data = formLinkSer.GetByKey(this.FormID, row.UserID);
                            if (data != null)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }

                            M_Form_Link item = new M_Form_Link();
                            item.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString());
                            item.UserID = this.GetUserIDbByStaffCode(row.StaffCD);
                            item.RouteID = int.Parse(this.cmbRoute.SelectedValue.ToString());
                            item.CreateUID = LoginInfo.User.ID;
                            item.UpdateUID = LoginInfo.User.ID;
                            retIns = formLinkSer.Insert(item);
                            if (retIns == 0)
                            {
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                        }
                    }

                    else
                    {
                        //New data => Insert into database
                        IList<UserInfoForFormLink> newList = new List<UserInfoForFormLink>();

                        newList = (from info in this.UserListInFormLink
                                   where !userIDlist.Contains(info.UserID)
                                   select info).ToList();
                        if (newList != null && newList.Count > 0)
                        {
                            foreach (UserInfoForFormLink row in newList)
                            {
                                M_Form_Link data = formLinkSer.GetByKey(this.FormID, row.UserID);
                                if (data != null)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }

                                M_Form_Link item = new M_Form_Link();
                                item.FormID = int.Parse(this.cmbTypeFormatForm.SelectedValue.ToString());
                                item.UserID = this.GetUserIDbByStaffCode(row.StaffCD);
                                item.RouteID = int.Parse(this.cmbRoute.SelectedValue.ToString());
                                item.CreateUID = LoginInfo.User.ID;
                                item.UpdateUID = LoginInfo.User.ID;
                                retIns = formLinkSer.Insert(item);
                                if (retIns == 0)
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                    return false;
                                }
                            }
                        }

                        //Deleted data in database
                        foreach (string staffCD in staffList)
                        {

                            UserInfoForFormLink item = (from info in this.UserListInFormLink
                                                        where info.StaffCD.Equals(EditDataUtil.ToFixCodeShow(staffCD, M_Staff.MAX_STAFF_CODE_SHOW))
                                                        select info).SingleOrDefault();

                            //If removed=> delete from database
                            if (item == null)
                            {
                                int userID = this.GetUserIDbByStaffCode(staffCD);
                                if (userID != 0)
                                {
                                    M_Form_Link formLink = formLinkSer.GetByKey(this.FormID, userID);

                                    if (formLink != null)
                                    {
                                        //Get info from database before update
                                        M_Form_Link oldInfo = (from row in this.UserListInDatabase
                                                               where row.UserID == userID
                                                               select row).SingleOrDefault();
                                        if (oldInfo != null)
                                        {
                                            //Check data changed
                                            if (formLink.UpdateDate != oldInfo.UpdateDate)
                                            {
                                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                                return false;
                                            }
                                            else
                                            {
                                                ////Check existing of UserID and FormID in T_Apply table
                                                //if (this.IsExistedDataInAppy(user.ID, this.FormID))
                                                //{
                                                //    this.SetMessage(string.Empty, M_Message.MSG_DATA_EXISTS);
                                                //    return false;
                                                //}

                                                retDel = formLinkSer.Delete(this.FormID, userID);
                                                if (retDel == 0)
                                                {
                                                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                                    return false;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        base.RedirectUrl(URL_LIST);
                                    }
                                }

                            }
                        }
                    }

                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.FillDataForApproverList();
                this.ReLoadUserGridLeft(this.HeaderGridLeft);
                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);                

                return false;
            }

            return true;
        }

        #endregion

        #region Detele Data

        /// <summary>
        /// Delete data
        /// </summary>
        /// <returns>True: delete success/False: delete fail</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    FormLinkService formLinkService = new FormLinkService(db);
                    IList<M_Form_Link> formLinkList = formLinkService.GetListByFormIDAndRouteID(this.FormID, this.RouteID);
                    if (formLinkList != null && formLinkList.Count != this.UserListInFormLink.Count)
                    {
                        //Data is changed
                        this.FillDataForApproverList();
                        this.ReLoadUserGridLeft(this.HeaderGridLeft);
                        this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    else
                    {
                        foreach (UserInfoForFormLink row in this.UserListInFormLink)
                        {
                            //Check existing of UserID and FormID in T_Apply table
                            //if(this.IsExistedDataInAppy(row.UserID,this.FormID))
                            //{
                            //    this.FillDataForApproverList();
                            //    this.ReLoadUserGrid(this.HeaderGridLeft);
                            //    this.SetMessage(string.Empty, M_Message.MSG_DATA_EXISTS);
                            //    return false;
                            //}

                            //Delete FormLink
                            ret = formLinkService.Delete(this.FormID, row.UserID);
                            if (ret == 0)
                            {
                                break;
                            }
                        }

                    }
                    if (ret != 0)
                    {
                        db.Commit();
                    }

                }

                //Check result update
                if (ret == 0)
                {
                    this.FillDataForApproverList();
                    this.ReLoadUserGridLeft(this.HeaderGridLeft);
                    this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

                    //Data is changed
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (Exception ex)
            {
                this.FillDataForApproverList();
                this.ReLoadUserGridLeft(this.HeaderGridLeft);
                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);
                return false;
            }

            return true;
        }

        #endregion

        #region Show Data

        /// <summary>
        /// Show data for master
        /// </summary>
        private void ShowMasterData(FormLinkMaster formLink)
        {
            if (formLink != null)
            {
                this.cmbTypeFormatForm.SelectedValue = formLink.FormID.ToString();
                this.cmbRoute.SelectedValue = formLink.RouteID.ToString();

                M_Route_H oldRouteH = this.GetRouteHInfoByID(formLink.RouteID);
                if (oldRouteH != null)
                {
                    this.OldUpdateOfRoute = oldRouteH.UpdateDate;
                }

                using (DB db = new DB())
                {
                    //Get data from database
                    FormLinkService formLinkSer = new FormLinkService(db);
                    this.UserListInDatabase = formLinkSer.GetListByFormIDAndRouteID(this.FormID, this.RouteID);
                }
            }
        }

        /// <summary>
        /// Fill data for approver list
        /// </summary>
        private void FillDataForApproverList()
        {
            IList<RouteDetailListInfo> approverList = new List<RouteDetailListInfo>();
            int routeID = 0;
            if (!string.IsNullOrEmpty(this.cmbRoute.SelectedValue))
            {
                routeID = int.Parse(this.cmbRoute.SelectedValue);
                approverList = this.CreateApproverList(routeID);

                if (approverList != null && approverList.Count > 0)
                {
                    this.isHasData = true;
                    this.rptApproverList.DataSource = approverList;
                }
                else
                {
                    this.isHasData = false;
                    this.rptApproverList.DataSource = null;
                }

            }
            this.ApproverList = approverList;
            this.rptApproverList.DataBind();

        }

        /// <summary>
        /// Load data the left grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void FillDataForRouteListLeft(int pageIndex, int numOnPage)
        {
            using (DB db = new DB())
            {
                int totalRow = 0;

                FormLinkService formLinkSer = new FormLinkService(db);

                IList<UserInfoForFormLink> userList = new List<UserInfoForFormLink>();

                if (!string.IsNullOrEmpty(this.cmbRoute.SelectedValue) && !(this.cmbRoute.SelectedValue).Equals(" -1"))
                {
                    int rowNumber = 1;
                    userList = formLinkSer.GetUserByCond(int.Parse(this.cmbTypeFormatForm.SelectedValue), int.Parse(this.cmbRoute.SelectedValue));

                    if (userList != null && userList.Count > 0)
                    {
                        userList = (from row in userList
                                    orderby row.DepartmentName ascending, row.StaffCD ascending
                                    select new UserInfoForFormLink
                                    {
                                        RowNumber = rowNumber++,
                                        DepartmentID = row.DepartmentID,
                                        DepartmentCD = row.DepartmentCD,
                                        DepartmentName = row.DepartmentName,
                                        UserID = row.UserID,
                                        StaffCD = row.StaffCD,
                                        StaffName = row.StaffName,
                                        Position = row.Position,
                                        UpdateDate = row.UpdateDate,
                                        AppliedFlag = row.AppliedFlag

                                    }).ToList();

                    }

                    if (userList.Count == 0)
                    {
                        this.isHasDataUserLeft = false;
                    }
                    else
                    {
                        this.isHasDataUserLeft = true;
                        totalRow = userList.Count;
                    }

                    this.SortGrid(this.HeaderGridLeft, ref userList);

                    //Check disable move button
                    UserInfoForFormLink itemPrev = new UserInfoForFormLink();
                    if (userList != null && userList.Count > 0)
                    {
                        itemPrev = userList[0];
                    }

                    foreach (UserInfoForFormLink item in userList)
                    {
                        int count = (from row in userList
                                     where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                                     select row).Count();

                        if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                        {
                            item.CountAllowMove = count;
                        }
                        else
                        {
                            itemPrev = item;
                            item.CountAllowMove = count;
                        }
                    }

                    this.UserListInFormLink = userList;

                    if (userList.Count > numOnPage)
                    {
                        //Paging
                        userList = userList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                    }
                }

                this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, userList, totalRow, pageIndex, numOnPage);

                // detail
                this.rptUserListLeft.DataSource = userList;

                this.rptUserListLeft.DataBind();
            }
        }

        /// <summary>
        /// Load data the right grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void FillDataForRouteListRight(int pageIndex, int numOnPage)
        {
            using (DB db = new DB())
            {
                int totalRow = 0;

                UserService userSer = new UserService(db);
                IList<UserInfoForFormLink> userList = new List<UserInfoForFormLink>();
                if (!string.IsNullOrEmpty(this.cmbTypeFormatForm.SelectedValue) && !string.IsNullOrEmpty(this.cmbRoute.SelectedValue))
                {
                    int rowNumber = 1;
                    totalRow = userSer.GetTotalRowForNotApprove(int.Parse(this.cmbTypeFormatForm.SelectedValue), int.Parse(this.cmbRoute.SelectedValue));
                    userList = userSer.GetListUserNotApprove(int.Parse(this.cmbTypeFormatForm.SelectedValue), int.Parse(this.cmbRoute.SelectedValue));
                    if (userList != null && userList.Count > 0)
                    {
                        userList = (from row in userList
                                    orderby row.DepartmentName ascending, row.StaffCD ascending
                                    select new UserInfoForFormLink
                                    {
                                        RowNumber = rowNumber++,
                                        DepartmentID = row.DepartmentID,
                                        DepartmentCD = row.DepartmentCD,
                                        DepartmentName = row.DepartmentName,
                                        UserID = row.UserID,
                                        StaffCD = row.StaffCD,
                                        StaffName = row.StaffName,
                                        Position = row.Position,
                                        UpdateDate = row.UpdateDate,
                                        AppliedFlag = row.AppliedFlag

                                    }).ToList();
                    }

                    this.UserListUnApprove = userList;

                    if (userList.Count > numOnPage)
                    {
                        //Paging
                        userList = userList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
                    }

                }
                this.SortGrid(HeaderGridRight, ref userList);

                //Show data
                if (userList.Count == 0)
                {
                    this.rptUserListRight.DataSource = null;
                    this.isHasDataUserRight = false;
                }
                else
                {
                    this.isHasDataUserRight = true;
                }
                this.LoadPagingForGrid(this.PagingHeaderRight, this.PagingFooterRight, this.HeaderGridRight, userList, totalRow, pageIndex, numOnPage);
                // header
                this.HeaderGridRight.TotalRow = totalRow;

                // detail
                this.rptUserListRight.DataSource = userList;
                this.rptUserListRight.DataBind();
            }
        }

        /// <summary>
        /// Reload data for user grid (include left grid and right grid)
        /// </summary>
        private void ReLoadUserGridLeft(UserControls.HeaderGridControl HeaderGrid)
        {

            int totalRow = 0;
            if (this.UserListInFormLink != null)
            {
                totalRow = this.UserListInFormLink.Count;
            }

            IList<UserInfoForFormLink> staffList = new List<UserInfoForFormLink>();
            staffList = this.UserListInFormLink;


            this.SortGrid(HeaderGrid, ref staffList);

            //Check disable move button
            UserInfoForFormLink itemPrev = new UserInfoForFormLink();
            if (staffList != null && staffList.Count > 0)
            {
                itemPrev = staffList[0];
            }

            foreach (UserInfoForFormLink item in staffList)
            {
                int count = (from row in staffList
                             where row.DepartmentID == item.DepartmentID && row.AppliedFlag == 0
                             select row).Count();

                if (item.DepartmentID.Equals(itemPrev.DepartmentID))
                {
                    item.CountAllowMove = count;
                }
                else
                {
                    itemPrev = item;
                    item.CountAllowMove = count;
                }
            }

            //Show data

            if (staffList.Count > 0)
            {
                if (staffList.Count == 1 && this.IsEmptyRow(staffList[0]))
                {
                    this.isHasDataUserLeft = false;
                }
                else
                {
                    this.isHasDataUserLeft = true;
                }

            }
            else
            {
                this.isHasDataUserLeft = false;
            }

            //Get data list depend on pageIndex and pageSize
            int numOnPage = this.PagingHeaderLeft.NumRowOnPage;
            int pageIndex = this.PagingHeaderLeft.CurrentPage;

            if (staffList.Count > numOnPage)
            {
                staffList = staffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            }

            this.LoadPagingForGrid(this.PagingHeaderLeft, this.PagingFooterLeft, this.HeaderGridLeft, staffList, totalRow, pageIndex, numOnPage);
            this.rptUserListLeft.DataSource = staffList;
            this.rptUserListLeft.DataBind();

        }

        /// <summary>
        /// Reload right grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void ReloadUserListRight(int pageIndex, int numOnPage)
        {
            IList<string> staffCDList = new List<string>();

            foreach (UserInfoForFormLink staff in this.UserListInFormLink)
            {
                staffCDList.Add(staff.StaffCD);
            }

            IList<string> approverCDList = (from approver in this.ApproverList
                                            select approver.StaffCD).ToList();

            IList<UserInfoForFormLink> remainStaffList = new List<UserInfoForFormLink>();

            remainStaffList = (from staff in this.UserListUnApprove
                               where !staffCDList.Contains(staff.StaffCD) && staff.DepartmentID != 0
                               select staff).ToList();

            int rowNumber = 1;
            if (remainStaffList != null && remainStaffList.Count > 0)
            {
                remainStaffList = (from row in remainStaffList
                                   orderby row.DepartmentName ascending, row.StaffCD ascending
                                   select new UserInfoForFormLink
                                   {
                                       RowNumber = rowNumber++,
                                       DepartmentID = row.DepartmentID,
                                       DepartmentCD = row.DepartmentCD,
                                       DepartmentName = row.DepartmentName,
                                       UserID = row.UserID,
                                       StaffCD = row.StaffCD,
                                       StaffName = row.StaffName,
                                       Position = row.Position,
                                       UpdateDate = row.UpdateDate,
                                       AppliedFlag = row.AppliedFlag

                                   }).ToList();

            }

            if (remainStaffList != null && remainStaffList.Count > 0)
            {
                if (remainStaffList.Count == 1 && remainStaffList[0].DepartmentID == 0)
                {
                    this.isHasDataUserRight = false;
                }
                else
                {
                    this.isHasDataUserRight = true;
                }

            }
            else
            {
                this.isHasDataUserRight = false;
            }

            int totalRow = remainStaffList.Count;
            remainStaffList = (from staff in remainStaffList
                               orderby staff.DepartmentName, staff.StaffCD ascending
                               select staff).ToList();

            this.SortGrid(HeaderGridRight, ref remainStaffList);

            //Keep data list
            this.UserListUnApprove = remainStaffList;

            //Get data list depend on pageIndex and pageSize
            if (remainStaffList.Count > numOnPage)
            {
                remainStaffList = remainStaffList.Skip(numOnPage * (pageIndex - 1)).Take(numOnPage).ToList();
            }

            //Load header
            this.LoadPagingForGrid(this.PagingHeaderRight, this.PagingFooterRight, this.HeaderGridRight, remainStaffList, totalRow, pageIndex, numOnPage);

            // detail
            this.rptUserListRight.DataSource = remainStaffList;
            this.rptUserListRight.DataBind();
        }

        /// <summary>
        /// Create approver list
        /// </summary>
        /// <param name="routeID">RouteID</param>
        private IList<RouteDetailListInfo> CreateApproverList(int routeID)
        {
            IList<RouteDetailListInfo> listDetail = new List<RouteDetailListInfo>();
            using (DB db = new DB())
            {
                Route_DService dbSer = new Route_DService(db);

                //Get list detail
                listDetail = dbSer.GetListDetailInfo(routeID, -1);
                listDetail = (from row in listDetail
                              where !row.RouteLevel.Equals(0)
                              select row
                            ).ToList();

                this.rptApproverList.DataSource = listDetail;
                this.rptApproverList.DataBind();
                this.isHasData = (listDetail.Count > 0) ? true : false;
            }
            return listDetail;

        }

        /// <summary>
        /// Load page info for grid
        /// </summary>
        /// <param name="userList"></param>
        /// <param name="totalRow"></param>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadPagingForGrid(UserControls.PagingHeaderControl pagingHeader, UserControls.PagingFooterControl pagingFooter, UserControls.HeaderGridControl headerGrid, IList<UserInfoForFormLink> staffList, int totalRow, int pageIndex, int numOnPage)
        {
            if (staffList.Count > 1 || (staffList.Count == 1 && !this.IsEmptyRow(staffList[0])))
            {
                // paging header
                pagingHeader.RowNumFrom = int.Parse(staffList[0].RowNumber.ToString());
                pagingHeader.RowNumTo = int.Parse(staffList[staffList.Count - 1].RowNumber.ToString());
                pagingHeader.TotalRow = totalRow;
                pagingHeader.CurrentPage = pageIndex;
            }

            // paging footer
            pagingFooter.CurrentPage = pageIndex;
            pagingFooter.NumberOnPage = numOnPage;
            pagingFooter.TotalRow = totalRow;

            // header
            headerGrid.TotalRow = totalRow;

        }

        #endregion

        #region Sort Data

        /// <summary>
        /// Process sorting grid
        /// </summary>
        /// <param name="HeaderGrid"></param>
        /// <param name="userList"></param>
        private void SortGrid(UserControls.HeaderGridControl HeaderGrid, ref IList<UserInfoForFormLink> staffList)
        {
            if (staffList != null && staffList.Count == 1)
            {
                if (this.IsEmptyRow(staffList[0]))
                {
                    return;
                }

            }

            int sortField = 2;
            int sortDirect = 1;

            if (!string.IsNullOrEmpty(HeaderGrid.SortField))
            {
                sortField = int.Parse(HeaderGrid.SortField);
            }

            if (!string.IsNullOrEmpty(HeaderGrid.SortDirec))
            {
                sortDirect = int.Parse(HeaderGrid.SortDirec);
            }

            int rowNumber = 1;
            switch (sortField)
            {
                case 2:
                    if (sortDirect == 1)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag

                                     }).ToList();

                    }

                    if (sortDirect == 2)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName descending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }

                    break;
                case 4:

                    if (sortDirect == 1)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.StaffCD ascending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }

                    if (sortDirect == 2)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.StaffCD descending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }
                    break;
                case 5:
                    if (sortDirect == 1)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.StaffName ascending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }

                    if (sortDirect == 2)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.StaffName descending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }
                    break;
                case 6:
                    if (sortDirect == 1)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.Position ascending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }

                    if (sortDirect == 2)
                    {
                        staffList = (from row in staffList
                                     orderby row.DepartmentName ascending, row.Position descending
                                     select new UserInfoForFormLink
                                     {
                                         RowNumber = rowNumber++,
                                         DepartmentID = row.DepartmentID,
                                         DepartmentCD = row.DepartmentCD,
                                         DepartmentName = row.DepartmentName,
                                         UserID = row.UserID,
                                         StaffCD = row.StaffCD,
                                         StaffName = row.StaffName,
                                         Position = row.Position,
                                         UpdateDate = row.UpdateDate,
                                         AppliedFlag = row.AppliedFlag
                                     }).ToList();
                    }
                    break;
            }
        }

        /// <summary>
        /// Process click for sorting page
        /// </summary>
        /// <param name="pagingHeader"></param>
        private void ProcessSortPageClick(UserControls.PagingHeaderControl pagingHeader)
        {
            if (this.UserListInFormLink != null && this.UserListInFormLink.Count > 0)
            {
                pagingHeader.CurrentPage = 1;
                this.FillDataForApproverList();
                this.ReLoadUserGridLeft(this.HeaderGridLeft);
                this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
            }
            else
            {
                this.FillDataForApproverList();
                this.FillDataForRouteListLeft(1, this.PagingHeaderLeft.NumRowOnPage);
                this.FillDataForRouteListRight(1, this.PagingHeaderRight.NumRowOnPage);
            }
        }

        #endregion

        #region Paging Header
        /// <summary>
        /// Process click page on header
        /// </summary>
        /// <param name="headerGrid"></param>
        private void ProcessPagingHeaderClick(UserControls.HeaderGridControl headerGrid)
        {
            this.FillDataForApproverList();
            this.ReLoadUserGridLeft(headerGrid);
            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
        }

        #endregion

        #region Paging Footer

        /// <summary>
        /// Process click page on footer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="pagingHeader"></param>
        /// <param name="pagingFooter"></param>
        /// <param name="headerGrid"></param>
        private void ProcessPagingFooterClick(object sender, UserControls.PagingHeaderControl pagingHeader, UserControls.PagingFooterControl pagingFooter, UserControls.HeaderGridControl headerGrid)
        {
            int curPage = int.Parse((sender as LinkButton).CommandArgument);
            pagingFooter.CurrentPage = curPage;
            pagingHeader.CurrentPage = curPage;
            this.FillDataForApproverList();
            this.ReLoadUserGridLeft(headerGrid);
            this.ReloadUserListRight(this.PagingHeaderRight.CurrentPage, this.PagingHeaderRight.NumRowOnPage);
        }

        #endregion

        #endregion
    }
}
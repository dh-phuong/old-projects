﻿/*
* Script on page load
*/
$(function () {

    var sessionId = '#stay';
    var history_api = typeof history.pushState != 'undefined';

    if (history_api) {
        history.pushState(null, '', sessionId);
    } else {
        location.hash = sessionId;
    }
    window.onhashchange = function () {
        // User tried to go back; warn user, rinse and repeat
        if (history_api) {
            history.pushState(null, '', sessionId);
        } else {
            location.hash = sessionId;
        }
    }

    if (typeof OnPageLoad != 'undefined') {
        OnPageLoad();
    }

    setPickColor();
    disableIme();
    dateInputSetting();
    numberInputSetting();
    codeInputSetting();
    inputDisplay();
    registLoading();
    hideLoading();
    if (window.addEventListener) {
        // IE9, Chrome, Safari, Opera
        window.addEventListener("mousewheel", scrollHorizontally, false);
        // Firefox
        window.addEventListener("DOMMouseScroll", scrollHorizontally, false);
    } else {
        // IE 6/7/8
        window.attachEvent("onmousewheel", scrollHorizontally);
    }
    asyncScrollBar();
});

///////////////////////////////////////////
//  Asynchronouses the scroll bar.
//  Create  : dh-phuong
///////////////////////////////////////////
function asyncScrollBar() {
    $scrollTop = $(".scrollTop");
    $scrollBottom = $(".scrollBottom");
    if ($scrollTop.length != 0 && $scrollBottom.length != 0) {
        $.each($scrollTop, function (i, scrollTop) {
            $(scrollTop).children("table")[0].style.width = $scrollBottom.children("table")[0].scrollWidth + "px";
        });
        $scrollTop.scroll(function () {
            $scrollBottom.scrollLeft($scrollTop.scrollLeft());
        });
        $scrollBottom.scroll(function () {
            $scrollTop.scrollLeft($scrollBottom.scrollLeft());
        });
    }
}
///////////////////////////////////////////
//  Process on mouse wheel
//  Create  : dh-phuong
///////////////////////////////////////////
function scrollHorizontally(e) {
    e = window.event || e;

    var scroll = function () {
        return function a(target) {
            var delta = Math.max(-1, Math.min(1, (e.wheelDelta || -e.detail)));
            target.scrollLeft -= (delta * 20); // Multiplied by 40
            target.scrollLeft -= (delta * 20); // Multiplied by 40
            e.preventDefault();
        }
    } ();

    var $container = $(e.target);
    if ($container.hasAttr("direction")) {
        var direction = $container.attr("direction");
        if (direction === "horizontally") {
            scroll(e.target);
        }
    } else {
        // Check if body height is higher than window height :) 
        if ($(document).height() <= $(window).height()) {
            var target = $("*[direction]:first");
            if (target.length > 0) {
                scroll(target[0]);
            }
        }
    }
};


///////////////////////////////////////////
//  GET CONTROL BY ID
//  Create  : isv.thuy
//  Date    : 16/07/2014  
///////////////////////////////////////////
function getCtrlById(id, index) {

    /// <summary locid='1'>Get element by id start with</summary>
    /// <param name='id' locid='2'>element id</param>
    /// <param name='index' locid='3'>index (use for data grid)</param>
    if ($.trim(id) === "") {
        return null;
    }
    if (index == undefined) {
        return $("[id$=" + id + "]");
    } else {
        return $("[id$=" + id + "_" + index + "]");
    }
}

///////////////////////////////////////////
//  FOCUS CONTROL ERROR
//  Create  : isv.thuy
//  Date    : 16/07/2014  
///////////////////////////////////////////
function focusErrors() {
    /// <summary locid='1'>Focus to error element</summary>

    var $divs = $(".has-error, .has-warning");
    if ($divs.length > 0) {
        $divs.first().find("input, select, textarea").focus().select();
    }
}

function showLoading() {
    /// <summary locid='1'>Show loading panel</summary>
    $('#loading').modal('show');
}
function hideLoading() {
    /// <summary locid='1'>Hide loading panel</summary>
    $('#loading').modal('hide');
}

function showSuccess() {
    /// <summary locid='1'>Show success panel</summary>
    $("#success").removeClass("hidden");
    $("#success").fadeIn();
}
function hideSuccess() {
    /// <summary locid='1'>Hide success panel</summary>
    $("#success").hide();
}

//
//Get Value of Querry String
//
function getParameter(key) {
    key = key.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + key + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
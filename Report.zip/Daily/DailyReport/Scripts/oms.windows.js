﻿
/****************************************
* Call User Search form
*****************************************/
function showSearchUser(in1, in2, in3, in4, in5, out1, out2, out3, out4, out5, out6) {

    /// <summary locid='1'>show User Search Popup</summary>
    /// <param name='in1' locid='2'>User Cd</param>
    /// <param name='in2' locid='3'>User Name1</param>
    /// <param name='in3' locid='4'>User Name2</param>
    /// <param name='in4' locid='5'>Group Cd</param>
    /// <param name='in5' locid='6'>Department ID</param>

    /// <param name='out1' locid='7'>User Cd</param>
    /// <param name='out2' locid='8'>User Name1</param>
    /// <param name='out3' locid='9'>User Name2</param>
    /// <param name='out4' locid='10'>CustomerAddress1</param>
    /// <param name='out5' locid='11'>Department Name</param>
    /// <param name='out6' locid='12'>Position</param>

    var url = "../Search/FrmUserSearch.aspx?in1=" + in1 + "&in2=" + in2 + "&in3=" + in3 + "&in4=" + in4 + "&in5=" + in5;
    //var url = "../Search/FrmUserSearch.aspx?in1=" + in1;//  + "&out1=" + out1 + "&out2=" + out2;
    var length = arguments.length;
    for (var i = 5; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 4) + "=" + arguments[i];
        }
    }
    openWindow(url, "FrmUserSearch", 1100, 600);
}

/****************************************
* Call Group User Select form
*****************************************/
function showSelectUser(in1, in2, in3, out1, out2) {
    var url = "../Search/FrmUserSelect.aspx?in1=" + in1 + "&in2=" + in2 + "&in3=" + in3;
       
    var length = arguments.length;
    for (var i = 3; i < length; i++) {

        if ('undefined' != typeof arguments[i]) {
            url += "&out" + (i - 2) + "=" + arguments[i];
        }
    }

    openWindow(url, "FrmUserSelect", 1100, 600);
}

/****************************************
* Call Group User Search form
*****************************************/
function showSearchGroupUser(groupCd, groupNm, groupCdCtrlId, groupNmCtrlId) {
    var url = "../Search/FrmGroupSearch.aspx?GroupCD=" + groupCd + "&GroupCDCtrl=" + groupCdCtrlId + "&GroupNmCtrl=" + groupNmCtrlId;
    openWindow(url, "FrmGroupSearch", 800, 600);
}

/****************************************
* Call Route Search form
*****************************************/
function showSearchRoute(routeCd, routeNm, routeCdCtrlId, routeNmCtrlId) {
    var url = "../Search/FrmRouteSearch.aspx?RouteCD=" + routeCd + "&RouteCDCtrl=" + routeCdCtrlId + "&RouteNmCtrl=" + routeNmCtrlId;
    openWindow(url, "FrmRouteSearch", 800, 600);
}

/****************************************
* Call Department Search form
* ISV-TRUC 2015/04/16
*****************************************/
function showSearchDept(deptCd, deptNm, deptCdCtrlId, deptNmCtrlId) {
    var url = "../Search/FrmDepartmentSearch.aspx?in1=" + deptCd + "&in2=" + deptNm + "&out1=" + deptCdCtrlId + "&out2=" + deptNmCtrlId;
    openWindow(url, "FrmDepartmentSearch", 800, 600);
}

/****************************************
* Call Staff Search form
* ISV-TRUC 2015/06/03
*****************************************/
function showSearchStaff(staffCD, staffNm, deptID, routeID, formID, loginUserID, staffCdCtrlId, staffNmCtrlId, deptCDCtrlId, deptNmCtrlId, positionCtrlId) {
    var url = "../Search/FrmStaffSearch.aspx?in1=" + staffCD + "&in2=" + staffNm + "&in3=" + deptID + "&in4=" + routeID + "&in5=" + formID + "&in6=" + loginUserID + "&out1=" + staffCdCtrlId + "&out2=" + staffNmCtrlId + "&out3=" + deptCDCtrlId + "&out4=" + deptNmCtrlId + "&out5=" + positionCtrlId;
    openWindow(url, "FrmStaffSearch", 800, 600);
}

/****************************************
* Call WorkingShift Search form
* ISV-TRAM 2015/06/02
*****************************************/
function showSearchWorkingShift(shiftCode, shiftName, shiftCodeCtrlId, shiftNameCtrlId, dayOffCtrlId) {
    var url = "../Search/FrmWorkingShiftSearch.aspx?in1=" + shiftCode + "&in2=" + shiftName + "&out1=" + shiftCodeCtrlId + "&out2=" + shiftNameCtrlId + "&out3=" + dayOffCtrlId;
    openWindow(url, "FrmWorkingShiftSearch", 800, 600);
}

function gotoApprovedForm(applyType, applyId) {
    var apprForm = "";
    switch (applyType) {
        case 0:
            apprForm = "FrmVacationView";
            break;
        case 1:
            apprForm = "FrmOverTimeView";
            break;
        case 2:
            apprForm = "FrmWorkLeaveView";
            break;
        case 3:
            apprForm = "FrmAbsenceView";
            break;
    }
   
    var url = "../ApprovedView/" + apprForm + ".aspx?ApplyId=" + applyId;
    openWindow(url, apprForm, 1200, 800);
}

var $opener;
var $iopn = false;


/**
* windowのポップアップ
*/
function openWindow(url, name, width, height) {

    /// <summary locid='1'>windowのポップアップ</summary>
    /// <param name='url' locid='2'>URL</param>
    /// <param name='name' locid='3'>Window Name</param>
    /// <param name='width' locid='4'>Width</param>
    /// <param name='height' locid='5'>Height</param>

    var windowFeatures = "";
    //windowFeatures = "menubar=no,location=no,resizable=yes,scrollbars=yes,status=no";
    windowFeatures = "menubar=no, titlebar=no, toolbar=no,scrollbars=yes, resizable=no, left=" + (screen.availWidth - width) / 2 + ",top=" + (screen.availHeight - height) / 2 + ", width=" + width + ", height=" + height + ", directories=no,location=no";
    if (!$iopn) {
        $iopn = true;

        $opener = window.open(url, name, windowFeatures);
        isOpenerClosed();
    }
}

var timeOutStack = [0, 0];
/**
* Check Window.opener is closing
*/
function isOpenerClosed() {
    if ($opener.closed) {
        $iopn = false;
        $.each(timeOutStack, function (i, id) {
            clearTimeout(id);
        });
        hideLoading();
    } else {
        var id = window.setTimeout("isOpenerClosed()", 500);
        if (id % 2 == 0) {
            timeOutStack[1] = id;
        } else {
            timeOutStack[0] = id;
        }
    }
    //console.log(new Date());
}

/****************************************
* Call Allowance form
*****************************************/
function showAllowance(id, allowanceCtrlId, data, dataCtrlID, mode) {
    var a = "FrmAllowance.aspx?salaryID=" + id
                        + "&AllowanceCtrl=" + allowanceCtrlId
                        + "&data=" + data
                        + "&dataCtrl=" + dataCtrlID
                        + "&Mode=" + mode;
    openWindow(a, "FrmAllowance", 800, 600);
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
namespace DailyReport.Search
{
    /// <summary>
    /// TRAM 2015/06/02
    /// Form WorkingShift Search
    /// </summary>
    public partial class FrmWorkingShiftSearch :  FrmBaseList
    {
        public IList<WorkingShiftSearchInfo> workingShiftList;

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txShiftCode.MaxLength = M_Work_Shift.SHIFT_CODE_MAX_LENGTH;
            this.txtShiftName.MaxLength = M_Work_Shift.SHIFT_NAME_MAX_LENGTH;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortDirec = "1";
                this.HeaderGrid.SortField = "3";
                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                
                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "3";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            #region IN
            //Set Shift code
            if (Request.QueryString["in1"] != null)
            {
                this.txShiftCode.Value = Request.QueryString["in1"];
            }

            //Set Shift Name
            if (Request.QueryString["in2"] != null)
            {
                this.txtShiftName.Value = Request.QueryString["in2"];
            }

            #endregion

            #region OUT

            ////Set ShiftCodeCtrl
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set ShiftNameCtrl
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            //Set DayOffCtrl
            if (Request.QueryString["out3"] != null)
            {
                this.Out3.Value = Request.QueryString["out3"];
            }

            #endregion
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int? shiftCode = null;
            string shiftName = null;
            int totalRow = 0;

            if (!this.txShiftCode.IsEmpty)
            {
                shiftCode =int.Parse(this.txShiftCode.Value);
            }

            if (!this.txtShiftName.IsEmpty)
            {
                shiftName = this.txtShiftName.Value;
            }

            using (DB db = new DB())
            {
                WorkShiftService workingShiftSer = new WorkShiftService(db);
                totalRow = workingShiftSer.GetCountByConditionForSearch(shiftCode, shiftName);
                this.workingShiftList = workingShiftSer.GetListByConditionForSearch(shiftCode, shiftName, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            }

            if (this.workingShiftList != null && this.workingShiftList.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.workingShiftList[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.workingShiftList[workingShiftList.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Shift Code", "Shift Name", "Start Time", "End Time", "Duration" });
            }

            this.Collapse = this.workingShiftList.Count > 0 ? string.Empty : "in";
            this.rptUserList.DataSource = this.workingShiftList;
            this.rptUserList.DataBind();
        }

        
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using System.Linq;

namespace DailyReport.Search
{
    public partial class FrmUserSelect : FrmBaseDetail
    {
        public string UsersBefore
        {
            get { return (string)ViewState["UsersBefore"]; }
            set { ViewState["UsersBefore"] = value; }
        }

        /// <summary>
        /// Get or set route list
        /// </summary>
        private IList<UserSelect> UserSelectList
        {
            get
            {
                return (IList<UserSelect>)base.ViewState["UserSelectList"];
            }
            set
            {
                base.ViewState["UserSelectList"] = value;
            }
        }

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);
        }

        protected void btnProcessData(object sender, EventArgs e)
        {
            this.UserSelectList = this.UserSelectList.Where(m => !m.SelectFlg).ToList();
            this.rptUser.DataSource = this.UserSelectList;
            this.rptUser.DataBind();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.InitData();
            }
        }

        protected void rptUser_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                UserSelect _user = this.UserSelectList[e.Item.ItemIndex];

                DropDownList cmbDept = (DropDownList)e.Item.FindControl("cmbDept");
                this.SetDataDepartmentCbo(cmbDept);
                cmbDept.SelectedValue = _user.DepartmentId.ToString();

                DropDownList cmbUser = (DropDownList)e.Item.FindControl("cmbUser");
                this.SetDataUserCbo(cmbUser, cmbDept.SelectedValue);
                cmbUser.SelectedValue = _user.UserCd.ToString();

                CheckBox selectFlg = (CheckBox)e.Item.FindControl("selectFlg");
                selectFlg.Checked = _user.SelectFlg; ;
            }
        }

        protected void btnAddRow_Click(object sender, EventArgs e)
        {
            this.GetData();
            this.AddEmptyRow();

            this.rptUser.DataSource = this.UserSelectList;
            this.rptUser.DataBind();
        }

        protected void btnRemoveRow_Click(object sender, EventArgs e)
        {
            this.GetData();
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE_SELECTED_ROW, Models.DefaultButton.No, true);
        }

        protected void cmbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddl = sender as DropDownList;
            RepeaterItem rpt = ddl.NamingContainer as RepeaterItem;
            if (rpt != null)
            {
                DropDownList cmbUser = rpt.FindControl("cmbUser") as DropDownList;
                if (cmbUser != null)
                {
                    this.SetDataUserCbo(cmbUser, ddl.SelectedValue);
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.GetData();
            CheckInput();

            this.rptUser.DataSource = this.UserSelectList;
            this.rptUser.DataBind();
        }

        #endregion


        #region Method

        /// <summary>
        /// Get error class name for div of control input
        /// </summary>
        /// <param name="ctrlID">ControlID</param>
        /// <returns>error class name</returns>
        protected override string GetClassError(string ctrlID)
        {
            if (base.CtrlIDErrors.Count > 0)
            {
                var haveError = base.CtrlIDErrors.Any(errorId =>
                     errorId.Length > 0 && ctrlID.Length >= errorId.Length ?
                    ctrlID.Substring(ctrlID.Length - errorId.Length, errorId.Length).Equals(errorId) : false
                );
                if (haveError)
                {
                    return "has-error";
                }
            }
            if (base.CtrlIDInfos.Count > 0)
            {
                var haveInfo = base.CtrlIDInfos.Any(infoId =>
                    infoId.Length > 0 && ctrlID.Length >= infoId.Length ?
                    ctrlID.Substring(ctrlID.Length - infoId.Length, infoId.Length).Equals(infoId) : false
                );
                if (haveInfo)
                {
                    return "has-warning";
                }
            }
            return string.Empty;
        }

        private bool CheckInput()
        {
            List<string> lstUser = new List<string>();
            this.isValid.Value = "-1";
            for (int i = 0; i < this.UserSelectList.Count; i++)
            {
                UserSelect item = this.UserSelectList[i];
                if (!string.IsNullOrEmpty(item.UserCd))
                {
                    if (lstUser.Contains(item.UserCd))
                    {
                        base.SetMessage(string.Format("cmbUser_{0}", i), M_Message.MSG_DUPLICATE_GRID, "User", i + 1);
                        this.isValid.Value = "1";
                    }
                    else
                    {
                        lstUser.Add(item.UserCd);
                    }
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            string qUser = string.Empty;
            string qDepartments = string.Empty;

            #region IN
            //Set UserCD
            if (Request.QueryString["in1"] != null)
            {
                qUser = Request.QueryString["in1"];
            }

            if (Request.QueryString["in2"] != null)
            {
                qDepartments = Request.QueryString["in2"];
            }

            if (Request.QueryString["in3"] != null)
            {
                UsersBefore = Request.QueryString["in3"];
            }

            #endregion

            #region OUT

            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            #endregion

            string[] arrDept = qDepartments.Split(',');
            string[] arrUser = qUser.Split(',');

            if (this.UserSelectList == null)
            {
                this.UserSelectList = new List<UserSelect>();
            }

            if (!string.IsNullOrEmpty(qDepartments.Trim()))
            {
                for (int i = 0; i < arrDept.Length; i++)
                {
                    UserSelect item = new UserSelect();
                    item.DepartmentId = int.Parse(arrDept[i]);
                    item.UserCd = arrUser[i];
                    this.UserSelectList.Add(item);
                }
            }
            else
            {
                this.AddEmptyRow();
            }

            this.rptUser.DataSource = this.UserSelectList;
            this.rptUser.DataBind();
        }

        /// <summary>
        /// init combox department
        /// </summary>
        private void SetDataDepartmentCbo(DropDownList ddl)
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                IList<DropDownModel> lstDB = deptSer.GetDataForDropdown(true);
                ddl.DataSource = lstDB;
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// init combox user
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="deptID"></param>
        private void SetDataUserCbo(DropDownList ddl, string deptID)
        {
            using (DB db = new DB())
            {
                UserService _UserService = new UserService(db);
                IList<DropDownModel> lstDB = _UserService.GetDataForDropdown(int.Parse(deptID), true);
                string[] arr = this.UsersBefore.Split(',');
                lstDB = lstDB.Where(m => !arr.Contains(m.Value)).ToList();
                ddl.DataSource = lstDB;
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        private void GetData()
        {
            this.UserSelectList.Clear();
            foreach (RepeaterItem item in this.rptUser.Items)
            {
                CheckBox selectFlg = (CheckBox)item.FindControl("selectFlg");
                DropDownList cmbDept = (DropDownList)item.FindControl("cmbDept");
                DropDownList cmbUser = (DropDownList)item.FindControl("cmbUser");

                UserSelect user = new UserSelect();
                user.SelectFlg = selectFlg.Checked;
                user.DepartmentId = int.Parse(cmbDept.SelectedValue.ToString());
                user.UserCd = cmbUser.SelectedValue.ToString();

                this.UserSelectList.Add(user);
            }
        }

        private void AddEmptyRow()
        {
            UserSelect item = new UserSelect();
            this.UserSelectList.Add(item);
        }

        #endregion




    }
}
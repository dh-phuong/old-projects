﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;

namespace DailyReport.Search
{
    public partial class FrmDepartmentSearch : FrmBaseList
    {
        public IList<DepartmentSearchInfo> listDeptInfo;
        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion
        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            #region IN
            //Set Dept code
            if (Request.QueryString["in1"] != null)
            {
                this.txtDeptCD.Value = Request.QueryString["in1"];
            }

            //Set Dept Name
            if (Request.QueryString["in2"] != null)
            {
                this.txtDeptName.Value = Request.QueryString["in2"];
            }

            #endregion

            #region OUT

            ////Set DeptCdCtrl
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set DeptNameCtrl
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            #endregion
        }
        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            string deptCD = null;
            string deptNm = null;
            int totalRow = 0;
            if (!this.txtDeptCD.IsEmpty)
            {
                deptCD = Utilities.EditDataUtil.ToFixCodeDB(this.txtDeptCD.Value, M_Department.DEPARTRMENT_CODE_MAX_LENGTH);
            }

            if (!this.txtDeptName.IsEmpty)
            {
                deptNm = this.txtDeptName.Value;
            }

            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                totalRow = deptSer.GetCountByConditionForSearch(deptCD, deptNm);
                this.listDeptInfo = deptSer.GetListByConditionForSearch(deptCD, deptNm, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            }

            if (this.listDeptInfo != null && this.listDeptInfo.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.listDeptInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.listDeptInfo[listDeptInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Name" });
            }

            this.Collapse = this.listDeptInfo.Count > 0 ? string.Empty : "in";
            this.rptUserList.DataSource = this.listDeptInfo;
            this.rptUserList.DataBind();
        }

        #endregion

        #region Events
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtDeptCD.MaxLength = M_Department.MAX_DEPARTRMENT_CODE_SHOW;
            this.txtDeptName.MaxLength = M_Department.DEPARTRMENT_NAME_MAX_LENGTH;
           
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortDirec = "1";
                this.HeaderGrid.SortField = "1";
                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }
        #endregion
    }
}
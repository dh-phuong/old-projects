﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Search
{
    /// <summary>
    /// FrmGroupSearch
    /// Create  : ISV-TRUC
    /// Date    : 2015/03/13
    /// </summary>
    public partial class FrmRouteSearch : FrmBaseList
    {
        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtRouteCD.MaxLength = M_Route_H.ROUTE_CODE_MAX_LENGTH;
            this.txtRouteName.MaxLength = M_Route_H.ROUTE_NAME_MAX_LENGTH;
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortDirec = "1";
                this.HeaderGrid.SortField = "1";
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Search Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";

        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Method

        /// <summary>
        /// Set search conditions
        /// </summary>
        private void InitData()
        {
            //Set RouteCD
            if (Request.QueryString["RouteCD"] != null)
            {
                this.txtRouteCD.Value = Request.QueryString["RouteCD"];
            }

            //Set RouteName
            //if (Request.QueryString["RouteNm"] != null)
            //{
            //    this.txtRouteName.Value = Request.QueryString["RouteNm"];
            //}

            ////Set RouteCode Control
            if (Request.QueryString["RouteCDCtrl"] != null)
            {
                this.Out1.Value = Request.QueryString["RouteCDCtrl"];
            }

            //Set Route Name conntrol
            if (Request.QueryString["RouteNmCtrl"] != null)
            {
                this.Out2.Value = Request.QueryString["RouteNmCtrl"];
            }
        }

        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            string groupCd = null;
            string groupNm = null;

            //Route Code
            if (!this.txtRouteCD.IsEmpty)
            {
                groupCd = this.txtRouteCD.Value;
            }

            //Route Name
            if (!this.txtRouteName.IsEmpty)
            {
                groupNm = this.txtRouteName.Value;
            }

            //Get data
            IList<RouteInfo> listInfo = null;
            int totalRow = 0;
            using (DB db = new DB())
            {
                Route_HService routeSer = new Route_HService(db);
                totalRow = routeSer.GetCountByConditionForSearch(groupCd, groupNm);

                listInfo = routeSer.GetListByConditionForSearch(groupCd, groupNm, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show Data
            if (totalRow != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(listInfo[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(listInfo[listInfo.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Route Name" });
            }

            this.Collapse = listInfo.Count > 0 ? string.Empty : "in";
            this.rptRouteList.DataSource = listInfo;
            this.rptRouteList.DataBind();
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Format Route Code
        /// </summary>
        /// <param name="in1">GroupCD</param>
        /// <returns>GroupCD</returns>
        [System.Web.Services.WebMethod]
        public static string FormatRouteCD(string in1)
        {
            try
            {
                var routeCd = in1;
                var routeCdShow = in1;
                routeCdShow = DailyReport.Utilities.EditDataUtil.ToFixCodeShow(routeCd, M_Route_H.ROUTE_CODE_MAX_LENGTH);
                var onlyCd = new
                {
                    txtRouteCD = routeCdShow
                };
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
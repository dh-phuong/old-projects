﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.Search
{
    /// <summary>
    /// FrmStaffSearch
    /// ISV-TRUC
    /// </summary>
    public partial class FrmStaffSearch : FrmBaseList
    {
        #region variable
        private string departmentID = null;
        #endregion

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion
        public IList<StaffSearchResult> lstResult;

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += Paging_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;

            // Paging footer
            this.PagingFooter.OnClick += Paging_Click;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtStaffCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtStaffName.MaxLength = M_Staff.STAFF_NAME_MAX_LENGTH;
            this.txtDeptCD.MaxLength = M_Department.MAX_DEPARTRMENT_CODE_SHOW;
           
        }

        /// <summary>
        /// Load Page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                // header grid
                this.HeaderGrid.SortDirec = "1";
                this.HeaderGrid.SortField = "1";
                // set default paging header
                this.PagingHeader.IsCloseForm = true;
                //this.PagingHeader.AddClass = "btn-success";

                //Set data into control
                this.InitData();

                //Load data into grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

            }
        }

        /// <summary>
        /// Process the button Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "1";
            this.HeaderGrid.SortField = "1";

            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            this.Collapse = "in";
        }

        /// <summary>
        /// Paging Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Paging_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(int.Parse((sender as LinkButton).CommandArgument), this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click on the paging header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Sorting on the repeater header
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            #region IN
            //Set StaffCD
            if (Request.QueryString["in1"] != null)
            {
                this.txtStaffCD.Value = Request.QueryString["in1"];
            }

            //Set StaffName
            if (Request.QueryString["in2"] != null)
            {
                this.txtStaffName.Value = Request.QueryString["in2"];
            }
            
            //Set Dept ID
            if (Request.QueryString["in3"] != null)
            {
                //Get txtDeptCD
                if (!string.IsNullOrEmpty(Request.QueryString["in3"].ToString()))
                {
                    int deptID = 0;
                    if (int.TryParse(Request.QueryString["in3"].ToString(), out deptID))
                    {
                        M_Department dept;
                        DepartmentService deptSer;
                        using (DB db = new DB())
                        {
                            deptSer = new DepartmentService(db);
                            dept = deptSer.GetByID(deptID);
                            if (dept != null)
                            {
                                this.txtDeptCD.Value = EditDataUtil.ToFixCodeShow(dept.DepartmentCD, M_Department.MAX_DEPARTRMENT_CODE_SHOW);
                                this.txtDeptName.Value = dept.DepartmentName;
                                this.hdnDeptID.Value = dept.ID.ToString();
                                this.txtDeptCD.SetReadOnly(true);
                            }
                        }
                    }
                    else
                    {
                        this.txtDeptCD.Value = string.Empty;
                        this.txtDeptName.Value = string.Empty;
                    }                     
                }
                else
                {
                    this.txtDeptCD.Value = string.Empty;
                    this.txtDeptName.Value = string.Empty;
                }
            }

            if (Request.QueryString["in4"] != null)
            {
                this.hdnRouteID.Value = Request.QueryString["in4"].ToString();
            }

            if (Request.QueryString["in5"] != null)
            {
                this.hdnFormID.Value = Request.QueryString["in5"].ToString();
            }

            if (Request.QueryString["in6"] != null)
            {
                this.hdnLoginUserID.Value = Request.QueryString["in6"].ToString();
            }

            #endregion

            #region OUT

            ////Set Staff CD Ctrl
            if (Request.QueryString["out1"] != null)
            {
                this.Out1.Value = Request.QueryString["out1"];
            }

            //Set Staff Name Ctrl
            if (Request.QueryString["out2"] != null)
            {
                this.Out2.Value = Request.QueryString["out2"];
            }

            //Set Dept CD ctrl
            if (Request.QueryString["out3"] != null)
            {
                this.Out3.Value = Request.QueryString["out3"];
            }

            //Set Dept Name Ctrl
            if (Request.QueryString["out4"] != null)
            {
                this.Out4.Value = Request.QueryString["out4"];
            }

            //Set Position Ctrl
            if (Request.QueryString["out5"] != null)
            {
                this.Out5.Value = Request.QueryString["out5"];
            }
            this.txtDeptName.SetReadOnly(true);
            #endregion
        }
        /// <summary>
        /// Load data into grid
        /// </summary>
        /// <param name="pageIndex"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            string staffCD = null;
            string staffNm = null;
            string deptCD = null;
            int routeID = -1;
            int formID = -1;
            int deptID = -1;
            int loginUID = -1;
            int totalRow = 0;
            if (!this.txtStaffCD.IsEmpty)
            {
                staffCD = this.txtStaffCD.Value;//Utilities.EditDataUtil.ToFixCodeDB(, M_Staff.STAFF_CODE_MAX_LENGTH);
            }

            if (!this.txtStaffName.IsEmpty)
            {
                staffNm = this.txtStaffName.Value;
            }

            if (!this.txtDeptCD.IsEmpty)
            {
                deptCD = txtDeptCD.Text.Trim();
            }

            if (!string.IsNullOrEmpty(this.hdnRouteID.Value))
            {
                routeID = int.Parse(this.hdnRouteID.Value.ToString());
            }

            if (!string.IsNullOrEmpty(this.hdnDeptID.Value))
            {
                deptID = int.Parse(this.hdnDeptID.Value.ToString());
            }

            if (!string.IsNullOrEmpty(this.hdnFormID.Value))
            {
                formID = int.Parse(this.hdnFormID.Value.ToString());
            }

            if (!string.IsNullOrEmpty(this.hdnLoginUserID.Value))
            {
                loginUID = int.Parse(this.hdnLoginUserID.Value.ToString());
            }

            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);

                totalRow = staffSer.GetCountByConditionForSearch(staffCD, staffNm, deptCD, deptID, routeID, formID, loginUID);
                this.lstResult = staffSer.GetListByConditionForSearch(staffCD, staffNm, deptCD, deptID, routeID, formID, loginUID, pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));

            }

            if (this.lstResult != null && this.lstResult.Count != 0)
            {
                this.PagingHeader.RowNumFrom = int.Parse(this.lstResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(this.lstResult[lstResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "CD", "Name", "Department", "Birthday", "Position" });
            }

            this.Collapse = this.lstResult.Count > 0 ? string.Empty : "in";
            this.rptStaffList.DataSource = this.lstResult;
            this.rptStaffList.DataBind();
        }

        #endregion

        #region Web Methods

        /// <summary>
        /// Show Dept Name
        /// </summary>
        /// <param name="in1">deptCD</param>
        /// <returns>GroupCD</returns>
        [System.Web.Services.WebMethod]
        public static string ShowDeptName(string in1)
        {
            try
            {
                var dbDeptCD = in1;
                dbDeptCD = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(dbDeptCD, M_Department.DEPARTRMENT_CODE_MAX_LENGTH);
                in1 = DailyReport.Utilities.EditDataUtil.ToFixCodeShow(dbDeptCD, M_Department.MAX_DEPARTRMENT_CODE_SHOW);
                using (DB db = new DB())
                {
                    DepartmentService service = new DepartmentService(db);

                    var dept = service.GetByCD(dbDeptCD);
                    if (dept != null)
                    {
                        var result = new
                        {
                            deptCD = in1,
                            deptName = dept.DepartmentName
                        };
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var onlyCd = new
                    {
                        deptCD = in1
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(onlyCd);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion

    }
 }
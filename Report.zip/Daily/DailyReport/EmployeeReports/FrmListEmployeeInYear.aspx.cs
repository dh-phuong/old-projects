﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Collections;

using NPOI.SS.UserModel;

using DailyReport.Reports.EXCEL;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.EmployeeReports
{
    /// <summary>
    /// Class FrmListEmployeeInYear
    /// </summary>
    public partial class FrmListEmployeeInYear : FrmBaseList
    {
        #region Constant Excel
        private const string EXCEL_EMPLOYEE_DETAIL_IN_MONTH_DOWNLOAD = "ListEmployeeInYear_{0}." + Constants.EXCEL_EXTEND;
        #endregion

        #region Property
        /// <summary>
        /// Get or set OutputFileName
        /// </summary>
        public string OutputFileName
        {
            get { return (string)ViewState["OutputFileName"]; }
            set { ViewState["OutputFileName"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "List Employee In Year";
            base.FormSubTitle = "Report";

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
              //  this.//SetDataDepartmentCbo();
                this.dtDate.Value = this.GetYearAccount();

                this.GetData();
            }
        }

        /// <summary>
        /// Button Search Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.GetData();
        }

        /// <summary>
        /// Button Excel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            if (CheckRequire())
            {
                AccountingPeriod _period = new AccountingPeriod();

                using (DB db = new DB())
                {
                    //------------------------
                    AccountingService _ser = new AccountingService(db);
                    _period = _ser.GetAccountingYear(this.dtDate.Value.Value);
                }

                this.OutputFileName = "List Employee In Year";
                ListEmployeeInYearExcel excel = new ListEmployeeInYearExcel();
                excel.Year = this.dtDate.Value.Value.Year;
                IWorkbook wb = excel.OutputExcel();

                if (wb != null)
                {
                    this.SaveFile(wb);
                }

                this.btnSearch_Click(null, null);
            }
        }

        /// <summary>
        /// Download Excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var fileTempName = EXCEL_EMPLOYEE_DETAIL_IN_MONTH_DOWNLOAD;
                if (!string.IsNullOrEmpty(this.OutputFileName))
                {
                    fileTempName = this.OutputFileName + "_{0}." + Constants.EXCEL_EXTEND;
                }
                var filename = string.Format(fileTempName, DateTime.Now.ToString(Constants.FMT_YMDHMM));

                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = Constants.EXCEL_CONTENT_TYPE;
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename=\"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Data Bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptData_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            ListEmployeeInYearExcelList dataItem = (ListEmployeeInYearExcelList)e.Item.DataItem;
        }
        #endregion

        #region Method
        /// <summary>
        /// Check Required
        /// </summary>
        /// <returns></returns>
        private bool CheckRequire()
        {
            if (!this.dtDate.Value.HasValue)
            {
                this.SetMessage(this.dtDate.ID, M_Message.MSG_REQUIRE, "Year");
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Get Year Account
        /// </summary>
        /// <returns>DateTime</returns>
        private DateTime GetYearAccount()
        {
            DateTime nowDate = DateTime.Now.Date;
            M_Accounting m_accounting;
            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                m_accounting = _ser.GetData();
            }

            if (nowDate.Day > m_accounting.ClosingDay)
            {
                return nowDate.AddYears(1);
            }

            return nowDate;
        }

        /// <summary>
        /// Get Data
        /// </summary>
        private void GetData()
        {
            if (CheckRequire())
            {
                DateTime _date = this.dtDate.Value.Value;

                this.lblMonth.Text = _date.Year.ToString();
         
                this.LoadData(_date);
            }
            else
            {
                this.rptData.DataSource = null;
                this.rptData.DataBind();

                if (this.dtDate.Value.HasValue)
                {
                    this.lblMonth.Text = dtDate.Value.Value.Year.ToString();
                }
                else
                {
                    this.lblMonth.Text = string.Empty;
                }
            }
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="date"></param>
        /// <param name="staffID"></param>
        private void LoadData(DateTime date)
        {
            AccountingPeriod _period = new AccountingPeriod();
            IList<ListEmployeeInYearExcelList> items = new List<ListEmployeeInYearExcelList>();

            using (DB db = new DB())
            {
                WorkService _workService = new WorkService(db);
                items = _workService.GetListByCondForListEmployeeInYearExcel(date.Year);
            }

            this.rptData.DataSource = items.Count == 0 ? null : items;
            this.rptData.DataBind();
        }
        #endregion
    }
}
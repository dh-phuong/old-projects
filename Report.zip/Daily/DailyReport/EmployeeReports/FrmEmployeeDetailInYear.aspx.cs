﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Collections;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.Reports.EXCEL;

using NPOI.SS.UserModel;

namespace DailyReport.EmployeeReports
{
    /// <summary>
    /// Class FrmEmployeeDetailInYear
    /// </summary>
    public partial class FrmEmployeeDetailInYear : FrmBaseList
    {
        #region Constant Excel
        private const string EXCEL_EMPLOYEE_DETAIL_IN_YEAR_DOWNLOAD = "EmployeeDetailInYear_{0}." + Constants.EXCEL_EXTEND;
        #endregion

        #region Property
        /// <summary>
        /// Get or set OutputFileName
        /// </summary>
        public string OutputFileName
        {
            get { return (string)ViewState["OutputFileName"]; }
            set { ViewState["OutputFileName"] = value; }
        }
        #endregion

        #region Event
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Employee Detail In Year";
            base.FormSubTitle = "Report";

            //Download Excel Click
            this.btnDownload.ServerClick += new EventHandler(btnDownloadExcel_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.SetDataDepartmentCbo();
                this.dtDate.Value = this.GetMonthAccount();

                //Show condition
                if (this.PreviousPage != null)
                {
                    this.cmbDept.SelectedValue = this.LoginInfo.Department.ID.ToString();

                    this.SetDataStaffCbo();
                    this.cmbStaff.SelectedValue = this.LoginInfo.User.StaffID.ToString();
                } 

                this.GetData();
            }
        }

        /// <summary>
        /// Date Change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void dtDate_TextChanged(object sender, EventArgs e)
        {
            string itemSelected = this.cmbStaff.SelectedValue;
            this.SetDataStaffCbo();

            List<DropDownModel> list = (List<DropDownModel>)this.cmbStaff.DataSource;
            if (list.Exists(x => x.Value.Equals(itemSelected)))
            {
                this.cmbStaff.SelectedValue = itemSelected;
            }
        }

        /// <summary>
        /// Dept Change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbDept_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SetDataStaffCbo();
            this.rptData.DataSource = null;
            this.rptData.DataBind();

            if (this.dtDate.Value.HasValue)
            {
                this.lblYear.Text = string.Format(Constants.FMT_YYYY, this.dtDate.Value.Value);
            }
            else
            {
                this.lblYear.Text = string.Empty;
            }
        }

        /// <summary>
        /// Staff Change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbStaff_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.GetData();
        }

        /// <summary>
        /// Button Search Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            this.GetData();
        }

        /// <summary>
        /// Button Excel Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnExcel_Click(object sender, CommandEventArgs e)
        {
            if (CheckRequire())
            {
                AccountingPeriod _period = new AccountingPeriod();

                using (DB db = new DB())
                {
                    AccountingService _ser = new AccountingService(db);
                    _period = _ser.GetAccountingMonth(this.dtDate.Value.Value);
                }

                this.OutputFileName = "Employee Detail In Year";
                EmployeeDetailInYearExcel excel = new EmployeeDetailInYearExcel();
                excel.StaffID = int.Parse(this.cmbStaff.SelectedValue);
                excel.StaffNm = this.cmbStaff.SelectedItem.Text;
                excel.Year = this.dtDate.Value.Value.Year;
                IWorkbook wb = excel.OutputExcel();

                if (wb != null)
                {
                    this.SaveFile(wb);
                }

                this.btnSearch_Click(null, null);
            }
        }

        /// <summary>
        /// Download Excel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDownloadExcel_Click(object sender, EventArgs e)
        {
            if (this.IsOutFile)
            {
                var fileTempName = EXCEL_EMPLOYEE_DETAIL_IN_YEAR_DOWNLOAD;
                if (!string.IsNullOrEmpty(this.OutputFileName))
                {
                    fileTempName = this.OutputFileName + "_{0}." + Constants.EXCEL_EXTEND;
                }
                var filename = string.Format(fileTempName, DateTime.Now.ToString(Constants.FMT_YMDHMM));

                var filePath = this.ViewState["OUTFILE"].ToString();
                using (var exportData = base.GetFileStream("OUTFILE"))
                {
                    Response.ContentType = Constants.EXCEL_CONTENT_TYPE;
                    Response.AddHeader("Content-Disposition", string.Format("attachment;filename=\"{0}\"", filename));
                    Response.Clear();
                    Response.BinaryWrite(exportData.GetBuffer());
                    Response.End();
                }
            }
        }

        /// <summary>
        /// Data Bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptData_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            EmployeeDetailInYearExcelList dataItem = (EmployeeDetailInYearExcelList)e.Item.DataItem;
        }
        #endregion

        #region Method
        /// <summary>
        /// Check Required
        /// </summary>
        /// <returns></returns>
        private bool CheckRequire()
        {
            if (!this.dtDate.Value.HasValue)
            {
                this.SetMessage(this.dtDate.ID, M_Message.MSG_REQUIRE, "Year");
            }

            if (this.cmbDept.SelectedIndex == 0)
            {
                this.SetMessage(this.cmbDept.ID, M_Message.MSG_REQUIRE, "Department");
            }
            else
            {
                if (this.cmbStaff.SelectedIndex == 0)
                {
                    this.SetMessage(this.cmbStaff.ID, M_Message.MSG_REQUIRE, "Employee");
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Get Month Account
        /// </summary>
        /// <returns>DateTime</returns>
        private DateTime GetMonthAccount()
        {
            DateTime nowDate = DateTime.Now.Date;
            M_Accounting m_accounting;
            using (DB db = new DB())
            {
                AccountingService _ser = new AccountingService(db);
                m_accounting = _ser.GetData();
            }

            if (nowDate.Day > m_accounting.ClosingDay)
            {
                return nowDate.AddMonths(1);
            }

            return nowDate;

        }

        /// <summary>
        /// Get Data
        /// </summary>
        private void GetData()
        {
            if (CheckRequire())
            {
                DateTime _date = this.dtDate.Value.Value;
                if (this.cmbStaff.SelectedItem == null)
                {
                    this.lblYear.Text = string.Format(Constants.FMT_YYYY, _date);
                }
                else
                {
                    this.lblYear.Text = string.Format(Constants.FMT_YYYY, _date) + ' ' + this.cmbStaff.SelectedItem.Text;
                }

                this.LoadData(_date, int.Parse(this.cmbStaff.SelectedValue));
            }
            else
            {
                this.rptData.DataSource = null;
                this.rptData.DataBind();

                if (this.dtDate.Value.HasValue)
                {
                    this.lblYear.Text = string.Format(Constants.FMT_YYYY, this.dtDate.Value.Value.Year);
                }
                else
                {
                    this.lblYear.Text = string.Empty;
                }
            }
        }

        /// <summary>
        /// Set Full Data
        /// </summary>
        /// <param name="lstData">IList<EmployeeDetailInYearExcelList></param>
        /// <returns>List<EmployeeDetailInYearExcelList></returns>
        private List<EmployeeDetailInYearExcelList> SetFullData(IList<EmployeeDetailInYearExcelList> lstData)
        {
            bool ok = false;
            List<EmployeeDetailInYearExcelList> lstDataNew = new List<EmployeeDetailInYearExcelList>();
            EmployeeDetailInYearExcelList rowNull = new EmployeeDetailInYearExcelList();
            for (int i = 1; i <= 12; i++)
            {
                for (int j = 0; j < lstData.Count; j++)
                {
                    if (i == lstData[j].WorkMonth)
                    {
                        rowNull = lstData[j];
                        ok = true;
                        break;
                    }
                }
                if (ok)
                {
                    lstDataNew.Add(rowNull);
                    rowNull = new EmployeeDetailInYearExcelList();
                    ok = false;
                }
                else
                {
                    rowNull = new EmployeeDetailInYearExcelList();
                    rowNull.WorkMonth = i;
                    rowNull.WorkYear = this.dtDate.Value.Value.Year;
                    lstDataNew.Add(rowNull);
                }
            }
            return lstDataNew;
        }

        /// <summary>
        /// Load Data
        /// </summary>
        /// <param name="date"></param>
        /// <param name="staffID"></param>
        private void LoadData(DateTime date, int staffID)
        {
            AccountingPeriod _period = new AccountingPeriod();
            List<EmployeeDetailInYearExcelList> items = new List<EmployeeDetailInYearExcelList>();

            using (DB db = new DB())
            {
                //------------------------
                AccountingService _ser = new AccountingService(db);
                _period = _ser.GetAccountingMonth(date);

                WorkService _workService = new WorkService(db);
                items = _workService.GetListByCondForEmployeeDetailInYearExcel(staffID, date.Year).OrderBy(m => m.WorkMonth).ToList();
            }
            items = SetFullData(items);
            this.rptData.DataSource = items.Count == 0 ? null : items;
            this.rptData.DataBind();
        }

        /// <summary>
        /// Init combox user
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="deptID"></param>
        private void SetDataStaffCbo()
        {
            IList<DropDownModel> list;
            using (DB db = new DB())
            {
                StaffService _staffService = new StaffService(db);
                list = _staffService.GetDataForDropdown(int.Parse(this.cmbDept.SelectedValue), this.dtDate.Value, true);
            }

            this.cmbStaff.DataSource = list;
            this.cmbStaff.DataValueField = "Value";
            this.cmbStaff.DataTextField = "DisplayName";
            this.cmbStaff.DataBind();
        }

        /// <summary>
        /// Init combox department
        /// </summary>
        private void SetDataDepartmentCbo()
        {
            IList<DropDownModel> list;
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                list = deptSer.GetDataForDropdown(true);
            }

            this.cmbDept.DataSource = list;
            this.cmbDept.DataValueField = "Value";
            this.cmbDept.DataTextField = "DisplayName";
            this.cmbDept.DataBind();
        }
        #endregion
    }
}
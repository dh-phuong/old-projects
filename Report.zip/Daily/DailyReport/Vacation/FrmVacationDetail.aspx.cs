﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;
using System.Data.SqlClient;

namespace DailyReport.Vacation
{
    public partial class FrmVacationDetail : FrmBaseDetail
    {
        #region Constant

        private const string URL_LIST = "~/Vacation/FrmVacationList.aspx";
        private const short BEGIN_MORNING_HOUR = 8;
        private const short BEGIN_MORNING_MIN = 0;
        private const short END_MORNING_HOUR = 11;
        private const short END_MORNING_MIN = 50;
        private const short BEGIN_AFTERNOON_HOUR = 12;
        private const short BEGIN_AFTERNOON_MIN = 50;
        private const short END_AFTERNOON_HOUR = 17;
        private const short END_AFTERNOON_MIN = 50;
        #endregion

        #region Variant

        public bool _isPrevButtonDisp;

        /// <summary>
        /// Default Status
        /// </summary>
       // private string _defaultStatus;

        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;
        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;
                        
        /// <summary>
        /// Has Approve User list(exist user for approve)
        /// </summary>
        public bool _hasApproveUser;

        public short _approveStatus;

       // public bool _isDeleted;

        /// <summary>
        /// 2015/03/23
        /// Check login user is exist in approve user
        /// </summary>
        public bool _isApproveUser;

        /// <summary>
        /// Check login user is create user
        /// 2015/03/26
        /// </summary>
        public bool _isCreateUser;

        /// <summary>
        /// 2015/03/23
        /// Show user code in view
        /// </summary>
        public bool IsShowUser { get; set; }

       // private int _defaultUnitMinute;
        private string _defaultTypePerform;
        
        /// <summary>
        /// StatusList
        /// </summary>
       // private IList<DropDownModel> _statusList;
        
        /// <summary>
        /// TypeList
        /// </summary>
        private IList<DropDownModel> _typeList;

        /// <summary>
        /// TypePerformList
        /// </summary>
        private IList<DropDownModel> _typePerformList;

        #endregion

        #region Property

        /// <summary>
        /// Get or set VacationID
        /// </summary>
        public int VacID
        {
            get { return (int)ViewState["VacationID"]; }
            set { ViewState["VacationID"] = value; }
        }

        /// <summary>
        /// Get or set UserID of user registry
        /// </summary>
        public int UserRegisterID
        {
            get { return (int)ViewState["UserRegisterID"]; }
            set { ViewState["UserRegisterID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// This user has Approved
        /// </summary>
        public bool HasCheckApprove
        {
            get { return (bool)ViewState["HasCheckApprove"]; }
            set { ViewState["HasCheckApprove"] = value; }
        }

        /// <summary>
        /// UserRegister
        /// </summary>
        //public M_User UserRegister
        //{
        //    get { return (M_User)ViewState["UserRegister"]; }
        //    set { ViewState["UserRegister"] = value; }
        //}
        #endregion

        #region Event

        /// <summary>
        /// Init Event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vacation";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtReason.MaxLength = T_Approve.CONTENT_MAX_LENGTH;

            //this.cmbType.SelectedIndexChanged += new EventHandler(cmbType_SelectedIndexChanged);

            this.txtUserCD.TextChanged += new EventHandler(txtUserCD_TextChanged);

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);                        
        }

        /// <summary>
        /// Page load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.Work);
            if (!this._authority.IsWorkView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            //Get Default Data
            this.GetDefaultData();

            if (!this.IsPostBack)
            {
                this.InitData();
                
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                       // this.ClearValue();
                        //Set Mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get Vacation data by id
                        this.VacID = int.Parse(PreviousPageViewState["ID"].ToString());
                        T_Vacation app = this.GetVacation(this.VacID);

                        //Check Vacation
                        if (app != null )
                        {
                            //if (app.ApplyStatus == (int)StatusApply.New || app.ApplyStatus == (int)StatusApply.Ignore || app.ApplyStatus == (int)StatusApply.Complete)//Dong nay moi tao, chua confirm/ or bi tra ve--Them truong hop da duyet xong
                            //{
                            //Neu login user la nguoi xin gium(CreateUID) hoac nguoi dung ten xin(UserID)--> duoc quyen vao sua
                            /*+++++++++++++++++++++++++++++++++++++++2015/03/30 ++++++++++++++++++++++++++++++++++++++++*/
                            /* Cho User dung ten xem all cac dong cua minh(ko care status), minh tao cho nguoi khac va minh duoc quyen duyet */
                            if (app.UserID == this.LoginInfo.User.ID || app.CreateUID == this.LoginInfo.User.ID || this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID))
                                {
                                    //Show data
                                    this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                                    //Set Mode
                                    this.ProcessMode(Mode.View);
                                }
                                else
                                {
                                    Server.Transfer(URL_LIST);
                                }
                            //}
                            //else//Dong nay da confirm roi
                            //{
                            //    if (app.UserID == this.LoginInfo.User.ID || !this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID))
                            //        //Nguoi dung ten hoac nguoi ko co quyen duyet--> ko dc vao
                            //    {
                            //        Server.Transfer(URL_LIST);
                            //    }
                            //    else
                            //    {
                            //        //Show data
                            //        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                            //        //Set Mode
                            //        this.ProcessMode(Mode.View);
                            //    }
                            //}
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    this.ClearValue();
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            //Set init
            this.Success = false;
        }

        /// <summary>
        /// txtUserCD TextChanged Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txtUserCD_TextChanged(object sender, EventArgs e)
        {            
            this.UserChanged();
        }

        /// <summary>
        /// btnSearchUserHdn Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUserHdn_Click(object sender, EventArgs e)
        {
            this.UserChanged();
        }

        /// <summary>
        /// Process data Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case DailyReport.Utilities.Mode.Insert:
                case DailyReport.Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.UserRegisterID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;

                case DailyReport.Utilities.Mode.Delete:

                    //Delete Data
                    if (this.DeleteData())
                    {
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case DailyReport.Utilities.Mode.Confirm:
                    //Confirm Data
                    if (this.ConfirmData())
                    {

                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }

                    break;

                case Utilities.Mode.Approve:
                    if (this.Approve())
                    {
                        //Cuurent User approved
                        // this._isUserApproved = true;
                        //Get data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));
                        //Set Mode
                        this.ProcessMode(Mode.View);

                        this.Success = true;
                    }
                    else
                    {
                        this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        //Set Mode
                       // this.ProcessMode(Mode.View);
                        
                    }
                    break;

                case Utilities.Mode.Ignore:
                    //Ignore Data
                    if (this.Ignore())
                    {
                        //this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                        ////Set Mode
                        //this.ProcessMode(Mode.View);

                        //this.Success = true;
                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        //Set Mode
                      //  this.ProcessMode(Mode.View);
                       
                    }
                    break;

                case Utilities.Mode.BackPre:
                    //Back Previous
                    if (this.Previous())
                    {

                        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        this.Success = true;
                    }
                    else
                    {
                        this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        //Set Mode
                       // this.ProcessMode(Mode.View);
                    }
                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.UserRegisterID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    break;
            }
        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {                
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }

        /// <summary>
        /// Back Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                 //Set Mode
                 this.ProcessMode(Mode.View);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Copy click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID), true);

                 //Set Mode
                 this.ProcessMode(Mode.Copy);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Confirm Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {           
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Set Model
                this.Mode = Mode.Confirm;

                //Fill List Approve
                this.FillDataApproveList(this.VacID, app.UserID);
                //+++++++++++++++++
                this.UserRegisterID = this.GetUserByCD(this.txtUserCD.Text.Trim()).ID;
                this.colorStatus = base.GetStatusColorLabel(app.ApplyStatus, ref this.statusNameLbl);
                this.HasCheckApprove = false;
                //+++++++++++++++++
                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        
        /// <summary>
        /// Delete Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Fill List Approve
            string userCode = string.IsNullOrEmpty(this.txtUserCD.Text) ? this.LoginInfo.User.UserCD : this.txtUserCD.Text.Trim();
            this.FillDataApproveList(this.VacID, this.GetUserByCD(userCode).ID);
            this.colorStatus = base.GetStatusColorLabel(this.GetVacation(this.VacID).ApplyStatus, ref this.statusNameLbl);
            this.HasCheckApprove = false;
            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }

        /// <summary>
        /// Edit Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Approve
             T_Vacation app = this.GetVacation(this.VacID);

             //Check Approve
             if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                 //Set Mode
                 this.ProcessMode(Mode.Update);
             }
             else
             {
                 Server.Transfer(URL_LIST);
             }
        }

        /// <summary>
        /// Insert Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {            
            
              //Fill List Approve
              string userCD = this.LoginInfo.User.UserCD;
              if (!string.IsNullOrEmpty(this.txtUserCD.Text))
              {
                  userCD = this.txtUserCD.Text.Trim();
              }
              this.colorStatus = base.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
              this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
              //Check input
              if (!this.CheckInput())
              {
                  return;
              }
              this.HasCheckApprove = false;
              this.UserRegisterID = this.GetUserByCD(userCD).ID;
              //Show question insert
              base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, DailyReport.Models.DefaultButton.Yes);
        }
        
        /// <summary>
        /// New Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }

        /// <summary>
        /// Update Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Fill List Approve
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            this.colorStatus = base.GetStatusColorLabel(this.GetVacation(this.VacID).ApplyStatus, ref this.statusNameLbl);
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(userCD).ID);
                    
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            this.HasCheckApprove = false;
            this.UserRegisterID = this.GetUserByCD(userCD).ID;
             //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, DailyReport.Models.DefaultButton.Yes);
        }
        //****************************************************************
        /// <summary>
        /// btnApprove Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                //Set Mode
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnIgnore Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                //Set Mode
                this.ProcessMode(Mode.Ignore);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }

        /// <summary>
        /// btnPrevious Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                //Set Mode
                this.ProcessMode(Mode.BackPre);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        /// <summary>
        /// Ignore Submit Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnoreSub_Click(object sender, EventArgs e)
        {
            T_Vacation vacation = this.GetVacation(this.VacID);

            //Check approve
            if (vacation != null)
            {
                this.colorStatus = base.GetStatusColorLabel(vacation.ApplyStatus, ref this.statusNameLbl);
                this.SetIsApproveUser(vacation.ID, this.LoginInfo.User.ID);
                //Fill Data
                this.FillDataApproveList(this.VacID, vacation.UserID);

                //Show question Ignore
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, DailyReport.Models.DefaultButton.No, true);
            }
        }

        /// <summary>
        /// Approve Submit Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApproveSub_Click(object sender, EventArgs e)
        {            
            T_Vacation vacation = this.GetVacation(this.VacID);

            //Check approve
            if (vacation != null)
            {
                this.colorStatus = base.GetStatusColorLabel(vacation.ApplyStatus, ref this.statusNameLbl);
                this.SetIsApproveUser(vacation.ID, this.LoginInfo.User.ID);

                //Fill Data
                this.FillDataApproveList(this.VacID, vacation.UserID);

                //Show question Approve
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, DailyReport.Models.DefaultButton.No);
            }
        }

        /// <summary>
        /// btnBackPre Submit Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPreviousSub_Click(object sender, EventArgs e)
        {
            T_Vacation vacation = this.GetVacation(this.VacID);

            //Check approve
            if (vacation != null)
            {
                this.colorStatus = base.GetStatusColorLabel(vacation.ApplyStatus, ref this.statusNameLbl);
                this.SetIsApproveUser(vacation.ID, this.LoginInfo.User.ID);
                
                //Fill Data
                this.FillDataApproveList(this.VacID, vacation.UserID);

                //Show question Back previous
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, DailyReport.Models.DefaultButton.No, true);
            }
        }

        //****************************************************************

        /// <summary>
        /// ItemDataBound Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptApproveList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            VacationApproveList Detail = (VacationApproveList)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptApproveChild");

            //----------------Set data detail----------------------//

            rptDetail.DataSource = Detail.DetailList;
            rptDetail.DataBind();
            //----------------End Set data detail-----------------//
        }

        /// <summary>
        /// cmbType SelectedIndexChanged Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {           
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
        }

        
        #endregion

        #region Methods

        /// <summary>
        /// Init Data
        /// </summary>
        public void InitData()
        {
            this._isPrevButtonDisp = false;
            this.HasCheckApprove = false;
            //this.UserRegister = this.LoginInfo.User;
            //--- this.dtStartDate.Value = DateTime.Now;
            //--- this.dtEndDate.Value = DateTime.Now;
            this.dtPerformDate.Value = DateTime.Now;
            
           // this._isDeleted = false;
            this._approveStatus = (short)StatusApply.None;
            this._hasApproveUser = false;
            
            //this.chkDeletedData.Checked = false;
            //this.InitCombobox(this.cmbStatus, this._statusList, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
            this.InitCombobox(this.cmbTypePerform, this._typePerformList, M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            this.InitComboboxType();
            this.txtUserName.Value = this.LoginInfo.User.UserName1;
            this.txtUserCD.Value = EditDataUtil.ToFixCodeShow(this.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            this.hdnDepartmentID.Value = this.LoginInfo.User.DepartmentID.ToString();
            //this.cmbStatus.SelectedValue = "1";
            M_User u = this.GetUserByCD(this.LoginInfo.User.UserCD);
            if (u != null)
            {
                this.txtPositionNm.Text = u.Position;
                M_Department d = this.GetDepartmentByID(u.DepartmentID);
                if (d != null)
                {
                    this.txtDepartmentNm.Text = d.DepartmentName;
                }
            }
            
        }

        /// <summary>
        /// GetDepartmentByID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_Department GetDepartmentByID(int ID)
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                return deptSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode"></param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:

                    if (this.Mode == Mode.Copy)
                    {
                        this.colorStatus = this.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
                      //  this.txtApproveNo.Text = string.Empty;
                      ////  this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
                      //  this.dtConfirmDate.Value = null;
                      //  this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()));
                    }

                    if (this.Mode == Mode.Insert)
                    {
                        this.colorStatus = this.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
                        string userCD = string.IsNullOrEmpty(this.txtUserCD.Text) ? this.LoginInfo.User.UserCD : this.txtUserCD.Text.Trim();
                        this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(userCD).ID);
                    }
                   
                    enable = false;

                    break;

                case Mode.Approve:
                case Mode.Ignore:
                case Mode.BackPre:
                    enable = true;
                    this.txtReasonApprove.ReadOnly = false;
                    break;
                default:
                    this.txtReasonApprove.ReadOnly = true;
                   /*24/03/2015 base.DisabledLink(this.btnEdit, !base._authority.IsWorkEdit || this._isDeleted || (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);

                    base.DisabledLink(this.btnDelete, !base._authority.IsWorkDelete || this._isDeleted || this._approveStatus == (short)StatusApply.Complete || this._approveStatus == (short)StatusApply.Approve || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    base.DisabledLink(this.btnCopy, !base._authority.IsWorkCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsWorkNew );
                    base.DisabledLink(this.btnConfirm, !base._authority.IsWorkConfirm || this._isDeleted || (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);*/
                    base.DisabledLink(this.btnEdit, !base._authority.IsWorkEdit ||  (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);

                    base.DisabledLink(this.btnDelete, !base._authority.IsWorkDelete || this._approveStatus == (short)StatusApply.Complete || this._approveStatus == (short)StatusApply.Approve || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    base.DisabledLink(this.btnCopy, !base._authority.IsWorkCopy);
                    base.DisabledLink(this.btnNew, !base._authority.IsWorkNew );
                    base.DisabledLink(this.btnConfirm, !base._authority.IsWorkConfirm || (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);

                    base.DisabledLink(this.btnApprove, !base._authority.IsWorkView || this.HasCheckApprove);
                    base.DisabledLink(this.btnIgnore, !base._authority.IsWorkView || this.HasCheckApprove);
                    base.DisabledLink(this.btnPrevious, !base._authority.IsWorkView || this.HasCheckApprove);
                    enable = true;
                    break;
            }

            //Lock control
            this.txtUserName.SetReadOnly(true);
            if (this.chkRepresentation.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Copy || this.Mode == Mode.Update))
            {
                this.txtUserCD.SetReadOnly(false);
            }
            else
            {
                this.txtUserCD.SetReadOnly(true);
            }
            this.txtReason.ReadOnly = enable;
            this.cmbType.Enabled = !enable;
            this.cmbTypePerform.Enabled = !enable;
            this.dtApplyDate.Enabled = false;
            this.dtPerformDate.Enabled = !enable;
            this.chkRepresentation.Disabled = enable;            
            this.txtPositionNm.ReadOnly = true;
            this.txtDepartmentNm.ReadOnly = true;    
        }

        /// <summary>
        /// FillDataApproveList From Approve List Table
        /// </summary>
        private void FillDataApproveList(int VacID, int UserID)
        {
            IList<VacationApprove> appLstWork = this.GetListApproveByVacationID(VacID);
            IList<VacationApprove> lstApprove = this.GetListApproveUser(appLstWork, UserID, false);
            if (lstApprove == null || lstApprove.Count == 0)
            {
                this._hasApproveUser = false;
                this.rptApproveChild.DataSource = null;
            }
            else
            {               
                this._hasApproveUser = true;
                this.rptApproveChild.DataSource = lstApprove;
            }
            this.rptApproveChild.DataBind();
        }

        /// <summary>
        /// Get List Approve User (Has List Child)
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveUser(IList<VacationApprove> lstDB, int currentUserID, bool isFrmRoute = true)
        {
            IList<VacationApprove> lstRet = null;
            IList<VacationApprove> lstTemp = null;
            if (lstDB != null)
            {
                lstRet = new List<VacationApprove>();
                if (isFrmRoute && currentUserID !=-1)
                {
                    //Get Level of Current User registry
                    var appWorkModel = (from u in lstDB
                                        where u.UserID.Equals(currentUserID) || currentUserID.Equals(-1)
                                        select new VacationApprove
                                        {
                                            RouteLevel = u.RouteLevel,
                                            RouteLevelStr = u.RouteLevelStr,
                                            RouteMethod = u.RouteMethod,
                                            RouteMethodStr = u.RouteMethodStr,
                                            UserID = u.UserID,
                                            UserName = u.UserName,
                                            Position = u.Position,
                                            Department = u.Department
                                        }
                                 ).SingleOrDefault();

                    if (appWorkModel != null)
                    {
                        short userLv = appWorkModel.RouteLevel;
                        lstTemp = (from l in lstDB
                                   where (l.RouteLevel > userLv || (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) && l.RouteLevel.Equals(userLv)))
                                                 && !l.UserID.Equals(appWorkModel.UserID)
                                   select new VacationApprove
                                           {
                                               ApproveDate = l.ApproveDate,
                                               ApproveDateStr = l.ApproveDateStr,
                                               ApproveFlag = l.ApproveFlag,
                                               ApproveFlagStr = l.ApproveFlagStr,
                                               VacationID = l.VacationID,
                                               RouteLevel = l.RouteLevel,
                                               RouteLevelStr = l.RouteLevelStr,
                                               ApproveName = l.ApproveName,
                                               ApproveUID = l.ApproveUID,
                                               ApproveReason = l.ApproveReason,
                                               RouteMethod = l.RouteMethod,
                                               RouteMethodStr = l.RouteMethodStr,
                                               UserID = l.UserID,
                                               UserName = l.UserName,
                                               Position = l.Position,
                                               Department = l.Department
                                           }).ToList();

                        //Current User has Level Max. Get current user
                        if (lstTemp.Count == 0)
                        {
                            lstTemp = (from k in lstDB
                                       where k.RouteLevel.Equals(userLv)
                                       select new VacationApprove
                                       {
                                           ApproveDate = k.ApproveDate,
                                           ApproveDateStr = k.ApproveDateStr,
                                           ApproveFlag = k.ApproveFlag,
                                           ApproveFlagStr = k.ApproveFlagStr,
                                           VacationID = k.VacationID,
                                           RouteLevel = k.RouteLevel,
                                           RouteLevelStr = k.RouteLevelStr,
                                           ApproveName = k.ApproveName,
                                           ApproveUID = k.ApproveUID,
                                           ApproveReason = k.ApproveReason,
                                           RouteMethod = k.RouteMethod,
                                           RouteMethodStr = k.RouteMethodStr,
                                           UserID = k.UserID,
                                           UserName = k.UserName,
                                           Position = k.Position,
                                           Department = k.Department
                                       }).ToList();
                        }
                    }
                    
                    // lstRet = new List<VacationApprove>();
                    if (lstTemp == null || lstTemp.Count == 0)
                    {
                        ((List<VacationApprove>)lstRet).AddRange(lstDB);
                    }
                    else
                    {
                        ((List<VacationApprove>)lstRet).AddRange(lstTemp);
                    }
                }
                else//From List Approve
                {
                    ((List<VacationApprove>)lstRet).AddRange(lstDB);
                }
            }
            return lstRet;
        }

        /// <summary>
        /// GetListApproveWork From Route
        /// </summary>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveWorkFromRoute(int TypeID)
        {            
            using (DB db = new DB())
            {
                Route_DService rSer = new Route_DService(db);
                //Get Approve List
                return rSer.GetListApproveVacationByTypeID(TypeID);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl,IList<DropDownModel> data, string configCD)
        {
            // init combox 
            ddl.DataSource = data;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void InitComboboxType()
        {
            // init combox 
            //////IList<DropDownModel> lstDB = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_TYPE_DAYOFF, true);
            //this.cmbType.DataSource = (from l in this._typeList
            //                           where !l.Value.Equals(M_Config_H.CONFIG_CD_DEFAULT_TYPE_NORMAL_WORK)
            //                           select new DropDownModel
            //                           {
            //                               DataboundItem = l.DataboundItem,
            //                               DisplayName = l.DisplayName,
            //                               Value = l.Value
            //                           }).ToList();
            ////using (DB db = new DB())
            ////{
            ////    TypeApplyService typeSer = new TypeApplyService(db);
            ////    IList<DropDownModel> lstDB = typeSer.GetDataForDropDownList();
            ////    this.cmbType.DataSource = lstDB;
            ////}
            this.cmbType.DataSource = this._typeList;
            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();
        }

        /// <summary>
        /// SetIsApproveUser
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="UserID"></param>
        private void SetIsApproveUser(int ID, int UserID)
        {
            this._isApproveUser = this.CheckLoginUserIsApproveUser(ID, this.LoginInfo.User.ID);
        }


        /// <summary>
        /// Show data
        /// </summary>
        /// <param name="app"></param>
        private void ShowData(VacationInfoDetail app, bool isFromRoute = false)
        {
            if (app != null)
            {                
                this._isCreateUser = app.CreateUID == this.LoginInfo.User.ID ? true : false;
                //+++++this._isApproveUser = this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID);
                this.SetIsApproveUser(app.ID, this.LoginInfo.User.ID);

                this.dtApplyDate.Value = app.ApplyDate;
                this.colorStatus = base.GetStatusColorLabel(app.ApplyStatus, ref this.statusNameLbl);

                this.cmbType.SelectedValue = app.TypeApplyID.ToString();
                this.txtUserName.Text = app.UserName;
                this.txtUserCD.Text = app.UserCD;
                this.txtReason.Text = app.Reason;

                //Get List Approve
                string userCD = this.LoginInfo.User.UserCD;
                if (!string.IsNullOrEmpty(this.txtUserCD.Text))
                {
                    userCD = this.txtUserCD.Text.Trim();
                }
                if (isFromRoute)
                {
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
                }
                else
                {
                    this.FillDataApproveList(this.VacID, this.GetUserByCD(userCD).ID);
                }
                this.dtPerformDate.Value = app.VacationDate;
                this.cmbTypePerform.SelectedValue = app.VacationStatus.ToString();
                this._approveStatus = app.ApplyStatus;
                //Save ID and UpdateDate
                this.VacID = app.ID;
                this.UserRegisterID = app.UserID;
                this.OldUpdateDate = app.UpdateDate;
                this.hdnVacationID.Value = this.VacID.ToString();
                //--- this._isDeleted = app.DeleteFlag == (short)DeleteFlag.Deleted;
                int status = app.ApproveStatus == null ? 0 : app.ApproveStatus.Value;
                this.txtReasonApprove.Text = this._isApproveUser ? app.ApproveReason : string.Empty;
                
                //this.HasCheckApprove = this.HasCheckApprove ? this.HasCheckApprove : (this.GetApproveStatusByUserID(this.VacID, this.LoginInfo.User.ID) != (int)StatusHasAprove.New);
                this.HasCheckApprove = this.HasCheckApprove ? this.HasCheckApprove : (status != (int)StatusHasAprove.New);
                this._isPrevButtonDisp = this.CheckPreviousLevelFinish(app.ID, this.LoginInfo.User.ID);
            }
        }

        /// <summary>
        /// Check Login User Is Approve User
        /// </summary>
        /// <param name="VacID"></param>
        /// <param name="LoginUserID"></param>
        /// <returns></returns>
        private bool CheckLoginUserIsApproveUser(int VacID, int LoginUserID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService vacSer = new VacationApproveListService(db);
                return vacSer.CheckLoginUserIsApproveUser(VacID, LoginUserID);
            }             
        }

        /// <summary>
        /// GetApproveStatusByUserID
        /// </summary>
        /// <param name="VacID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        //private int GetApproveStatusByUserID(int VacID, int UserID)
        //{
        //    using (DB db = new DB())
        //    {
        //        VacationApproveListService vacSer = new VacationApproveListService(db);
        //        return vacSer.GetStatusByHID(VacID, UserID);
        //    }
        //}

        /// <summary>
        /// Clear value on screen
        /// </summary>
        private void ClearValue()
        {   
           // this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
            this.InitComboboxType();
            this.InitCombobox(this.cmbTypePerform, this._typePerformList, M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            
            this.txtUserName.Text = LoginInfo.User.UserName1;
            this.txtUserCD.Text = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            this.chkRepresentation.Checked = false;
            this.txtReason.Text = string.Empty;
            this.dtApplyDate.Value = null;
            this.dtPerformDate.Value = DateTime.Now;
            this.txtReason.Text = string.Empty;
            this.txtReasonApprove.Text = string.Empty;
            
            //Reload List Approve user
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
        }

        /// <summary>
        /// Fill Data Approve List From Route
        /// </summary>
        private void FillDataApproveList_FromRoute(int TypeHID, int userID)
        {
            IList<VacationApprove> lst = this.GetListApproveUser(this.GetListApproveWorkFromRoute(TypeHID), userID);

            if (lst != null && lst.Count != 0)
            {
                this._hasApproveUser = true;
                this.rptApproveChild.DataSource = lst;
            }
            else
            {
                this._hasApproveUser = false;
                this.rptApproveChild.DataSource = null;
            }
            this.rptApproveChild.DataBind();
        }

        /// <summary>
        /// Get Vacation by ID
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private T_Vacation GetVacation(int wID)
        {
            using (DB db = new DB())
            {
                VacationService appSer = new VacationService(db);

                //Get Approve
                return appSer.GetByID(wID);
            }
        }

        /// <summary>
        /// GetVacationInfo
        /// </summary>
        /// <param name="vID"></param>
        /// <returns></returns>
        private VacationInfoDetail GetVacationInfo(int vID, int userID)
        {
            using (DB db = new DB())
            {
                VacationService appSer = new VacationService(db);

                //Get Vacation
                return appSer.GetVacationInfoByID(vID, userID);
            }
        }

        /// <summary>
        /// CheckPreviousLevelFinish
        /// </summary>
        /// <param name="vacID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private bool CheckPreviousLevelFinish(int vacID, int userID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService vacSer = new VacationApproveListService(db);
                return vacSer.CheckPreviousLevelFinish(vacID, userID);
            }
        }

        /// <summary>
        /// GetListApproveVacation(From Vacation_List)
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveByVacationID(int wID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService appListSer = new VacationApproveListService(db);

                //Get Approve
                return appListSer.GetListForVacation(wID);
               
            }
        }

        /// <summary>
        /// GetTotalRowApprove
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        //private int GetTotalRowApprove(int wID)
        //{
        //    using (DB db = new DB())
        //    {
        //        ApproveListService appListSer = new ApproveListService(db);

        //        //Get Approve
        //        return appListSer.GetTotalRowForWork(wID);

        //    }
        //}

        /// <summary>
        /// Get work by approve no
        /// </summary>
        /// <param name="approveNo"></param>
        /// <returns></returns>
        private T_Approve GetWorkByApproveNo(string approveNo)
        {
            using (DB db = new DB())
            {
                ApproveService appSer = new ApproveService(db);

                //Get Approve
                return appSer.GetByApproveNo(approveNo);
            }
        }

        /// <summary>
        /// Get default data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                TypeApplyService typeSer = new TypeApplyService(db);
                
                //this._defaultStatus = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
                
                //Status List
                //this._statusList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);
                //Type List
                this._typeList = typeSer.GetDataForDropDownList((int)TypeFormID.Vacation);

                this._typePerformList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
                this._defaultTypePerform = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            }

        }

        /// <summary>
        /// Get Info List
        /// </summary>
        /// <param name="vacID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private int GetInfoList(int typeID, int userID)
        {
            using (DB db = new DB())
            {
                Route_DService routeSer = new Route_DService(db);
                return routeSer.GetLevelByVacationUserID(typeID, userID);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (this.chkRepresentation.Checked)
            {
                if (string.IsNullOrEmpty(this.txtUserCD.Text.Trim()))
                {
                    this.IsShowUser = true;
                    this.SetMessage(this.txtUserCD.ID, M_Message.MSG_REQUIRE, "User Code");
                }
                else
                {

                    //Check level cua nguoi duoc tao thay the co <= Level cua nguoi tao giup ko
                    var loginLevel = this.GetInfoList(int.Parse(this.cmbType.SelectedValue.ToString()), this.LoginInfo.User.ID);
                    var userLevel = this.GetInfoList(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(this.txtUserCD.Text).ID);
                    if (loginLevel < userLevel)
                    {
                        this.SetMessage(this.txtUserCD.ID, M_Message.MSG_LEVEL_GREATER_USER_LEVEL);
                    }
                }
            }
            if (this.cmbType.SelectedValue.ToString().Equals("-1"))
            {
                this.SetMessage(this.cmbType.ID, M_Message.MSG_PLEASE_SELECT, "Type");
            }

            //if (!this.dtStartDate.Value.HasValue)
            //{
            //    this.SetMessage(this.dtStartDate.ID, M_Message.MSG_REQUIRE, "Start Date");
            //}

            /*---if (!this.dtStartTime.Value.HasValue)
            {
                this.SetMessage(this.dtStartTime.ID, M_Message.MSG_REQUIRE, "Start Time");
            }*/

            //if (!this.dtEndDate.Value.HasValue)
            //{
            //    this.SetMessage(this.dtEndDate.ID, M_Message.MSG_REQUIRE, "End Date");
            //}
            //PerformDate
            if (!this.dtPerformDate.Value.HasValue)
            {
                this.SetMessage(this.dtPerformDate.ID, M_Message.MSG_REQUIRE, "Perform Date");
            }
            //Reason
            if (string.IsNullOrEmpty(this.txtReason.Text))
            {
                this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Reason");
            }
                        
           /* if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue)
            {
                if (this.dtStartDate.Value.Value > this.dtEndDate.Value.Value)
                {
                    this.SetMessage(this.dtEndDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Date","Start Date");
                }
            }*/

            //Check Valid Date
            // this.CheckValidDateType();

           

            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// GetTypeApplyByID
        /// </summary>
        /// <param name="typeApplyID">ID</param>
        /// <returns></returns>
        private M_TypeApply GetTypeApplyByID(int typeApplyID)
        {
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                return typeSer.GetByID(typeApplyID);
            }
        }

        /// <summary>
        /// CheckValidDateType
        /// </summary>
        private void CheckValidDateType()
        {
            int typeApplyID = int.Parse(this.cmbType.SelectedValue.ToString());
            bool isErrorRange = false;
            M_TypeApply type = this.GetTypeApplyByID(typeApplyID);
            if (type != null)
            {
                //khac Nghi phep -> cung 1 ngay
                /*19/03if (type.DuringDayFlag == (int)DuringDayFlag.DuringDay)
                {
                    int startHour = int.Parse(this.cmbHourStart.SelectedValue);
                    int startMinute = int.Parse(this.cmbMinuteStart.SelectedValue);
                    int endHour = int.Parse(this.cmbHourEnd.SelectedValue);
                    int endMinute = int.Parse(this.cmbMinuteEnd.SelectedValue);
                    
                    //Thoi gian bat dau < thoi gian bat dau quy dinh
                    if (startHour == type.MinStartHour && startMinute < type.MinStartMinute)
                    {
                        this.SetMessage(this.cmbMinuteStart.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Start Time", string.Format("{0} : {1}", type.MinStartHour.ToString().PadLeft(2, '0'), type.MinStartMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    //Thoi gian bat dau = thoi gian ket thuc quy dinh
                    if (startHour == type.MaxEndHour && startMinute >= type.MaxEndMinute)
                    {
                        this.SetMessage(this.cmbMinuteStart.ID, M_Message.MSG_LESS_THAN_EQUAL, "Start Time", string.Format("{0} : {1}", type.MaxEndHour.ToString().PadLeft(2, '0'), type.MaxEndMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }                   
                    
                    //Thoi gian ket thuc = thoi gian bat dau quy dinh
                    if (endHour == type.MinStartHour && endMinute <= type.MinStartMinute)
                    {
                        this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Time", string.Format("{0} : {1}", type.MinStartHour.ToString().PadLeft(2, '0'), type.MinStartMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    //Thoi gian ket thuc > thoi gian ket thuc quy dinh
                    if (endHour == type.MaxEndHour && endMinute > type.MaxEndMinute)
                    {
                        this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Time", string.Format("{0} : {1}", type.MaxEndHour.ToString().PadLeft(2, '0'), type.MaxEndMinute.ToString().PadLeft(2, '0')));
                        isErrorRange = true;
                    }

                    if (!isErrorRange)
                    {
                        //Thoi gian ket thuc > thoi gian bat dau
                        if (endHour < startHour)//Hour
                        {
                            this.SetMessage(this.cmbHourEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Hour", "Start Hour");
                        }
                        else if (endHour == startHour)//Gio bang nhau
                        {
                            if (endMinute <= startMinute)//Minute
                            {
                                this.SetMessage(this.cmbMinuteEnd.ID, M_Message.MSG_LESS_THAN_EQUAL, "End Minute", "Start Minute");
                            }
                        }
                    }                   
                }
                else
                {
                    //Nghi phep
                    if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue)
                    {
                        if (this.dtStartDate.Value.Value > this.dtEndDate.Value.Value)
                        {
                            this.SetMessage(this.dtEndDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Date", "Start Date");
                        }
                    }
                }*/
            }
        }

        /// <summary>
        /// Get data for insert
        /// </summary>
        /// <returns></returns>
        private T_Vacation GetDataForInsert()
        {
            T_Vacation app = new T_Vacation();

            app.ApplyStatus = (short)T_Vacation.C_STATUS_APP_NEW;
            int userID = this.LoginInfo.User.ID;
            if (this.chkRepresentation.Checked)
            {
                M_User u = this.GetUserByCD(this.txtUserCD.Text);
                if (u != null)
                {
                    userID = u.ID;
                }                
            }
            app.UserID = userID;
            app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
            app.VacationDate = this.dtPerformDate.Value;
            app.VacationStatus = short.Parse(this.cmbTypePerform.SelectedValue.ToString());
            app.Reason = this.txtReason.Text;
            
            app.CreateUID = this.LoginInfo.User.ID;
            app.UpdateUID = this.LoginInfo.User.ID;
            
            return app;
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }            
        }

        /// <summary>
        /// Get List Vacation Approve User For Insert
        /// </summary>
        /// <param name="lstInput"></param>
        /// <returns></returns>
        private IList<T_Vacation_Approve_List> GetListApproveForInsert(int TypeID, int userID)
        {
            IList<T_Vacation_Approve_List> lstRet = null;
            /*IList<VacationApprove> lstDB = this.GetListApproveWorkFromRoute(TypeID);
            IList<VacationApprove> lstTemp = null;
           
            if (lstDB != null && lstDB.Count != 0)
            {
                var appWorkModel = (from u in lstDB
                                    where u.UserID.Equals(this.LoginInfo.User.ID)
                                    select new VacationApprove
                                    {
                                        RouteLevel = u.RouteLevel,
                                        RouteLevelStr = u.RouteLevelStr,
                                        RouteMethod = u.RouteMethod,
                                        RouteMethodStr = u.RouteMethodStr,
                                        UserID = u.UserID,
                                        UserName = u.UserName,
                                        Department = u.Department,
                                        Position = u.Position
                                    }
                             ).SingleOrDefault();

                if (appWorkModel != null)
                {
                    short userLv = appWorkModel.RouteLevel;
                    lstTemp = (from l in lstDB
                               where l.RouteLevel > userLv | (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) & l.RouteLevel.Equals(userLv))
                                     & !l.UserID.Equals(this.LoginInfo.User.ID)
                               select new VacationApprove
                               {
                                   ApproveDate = l.ApproveDate,
                                   ApproveDateStr = l.ApproveDateStr,
                                   ApproveFlag = l.ApproveFlag,
                                   ApproveFlagStr = l.ApproveFlagStr,
                                   VacationID = l.VacationID,
                                   RouteLevel = l.RouteLevel,
                                   RouteLevelStr = l.RouteLevelStr,
                                   ApproveName = l.ApproveName,
                                   ApproveUID = l.ApproveUID,
                                   ApproveReason = l.ApproveReason,
                                   RouteMethod = l.RouteMethod,
                                   RouteMethodStr = l.RouteMethodStr,
                                   UserID = l.UserID,
                                   UserName = l.UserName
                               }).ToList();

                    //Current User has Level Max. Get current user
                    if (lstTemp.Count == 0)
                    {
                        lstTemp = (from k in lstDB
                                   where k.UserID.Equals(this.LoginInfo.User.ID)
                                   select new VacationApprove
                                   {
                                       ApproveDate = k.ApproveDate,
                                       ApproveDateStr = k.ApproveDateStr,
                                       ApproveFlag = k.ApproveFlag,
                                       ApproveFlagStr = k.ApproveFlagStr,
                                       VacationID = k.VacationID,
                                       RouteLevel = k.RouteLevel,
                                       RouteLevelStr = k.RouteLevelStr,
                                       ApproveName = k.ApproveName,
                                       ApproveUID = k.ApproveUID,
                                       ApproveReason = k.ApproveReason,
                                       RouteMethod = k.RouteMethod,
                                       RouteMethodStr = k.RouteMethodStr,
                                       UserID = k.UserID,
                                       UserName = k.UserName
                                   }).ToList();
                    }


                }
                //Current User not exist in List Approve in DB
                if (lstTemp == null || lstTemp.Count == 0)
                {
                    lstTemp = new List<VacationApprove>();
                    ((List<VacationApprove>)lstTemp).AddRange(lstDB);
                }
            */
            IList<VacationApprove> lstTemp = this.GetListApproveUser(this.GetListApproveWorkFromRoute(TypeID), userID);

            lstRet = new List<T_Vacation_Approve_List>();
            foreach (VacationApprove item in lstTemp)
            {
                T_Vacation_Approve_List app = new T_Vacation_Approve_List();
                app.RouteUID = item.UserID;
                app.RouteLevel = item.RouteLevel;
                app.RouteMethod = item.RouteMethod;                
                app.ApproveUID = item.ApproveUID;
                app.ApproveDate = item.ApproveDate;
                app.ApproveReason = item.ApproveReason;
                lstRet.Add(app);
            }

            //}
            return lstRet;
        }
                
        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns></returns>
        private bool InsertData()
        {
            try
            {
                //Create model Vacation
                T_Vacation app = this.GetDataForInsert();
                //Create model Vacation Approve List
                IList<T_Vacation_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID, app.UserID);

                //Get Vacation
               // app.va = (new TNoService()).CreateNo(T_No.ApproveNo);

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    VacationService appSer = new VacationService(db);
                    VacationApproveListService appLstSer = new VacationApproveListService(db);
                    //Insert Approve
                    this.VacID = appSer.Insert(app);
                    if (this.VacID != 0 && lstApp != null)
                    {
                        foreach (var appItem in lstApp)
                        {
                            appItem.VacationID = this.VacID;
                            appLstSer.Insert(appItem);
                        }
                    }
                    db.Commit();                    
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                //{
                //    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                //    return false;
                //}

                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            try
            {                
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));
                if (app != null)
                {
                    //Create model
                    app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
                    if (this.chkRepresentation.Checked && !string.IsNullOrEmpty(this.txtUserCD.Text))
                    {
                        app.UserID = this.GetUserByCD(this.txtUserCD.Text).ID;
                    }
                    else
                    {
                        app.UserID = this.LoginInfo.User.ID;
                    }
                    app.Reason = this.txtReason.Text;
                    app.VacationDate = this.dtPerformDate.Value;
                    app.VacationStatus = short.Parse(this.cmbTypePerform.SelectedValue.ToString());
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    IList<T_Vacation_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID, app.UserID);

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);
                        VacationApproveListService appListSer = new VacationApproveListService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Update(app);

                            //Delete Old List
                            appListSer.DeleteByVacationID(app.ID);
                            //Insert New List
                            foreach (var item in lstApp)
                            {
                                item.VacationID = app.ID;
                                appListSer.Insert(item);
                            }
                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));

                if (app != null)
                {
                    if (app.UpdateDate != this.OldUpdateDate)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    if (app.ApplyStatus == (short)StatusApply.Approve || app.ApplyStatus == (short)StatusApply.Complete)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    //Create model
                    app.StatusFlag = (short)DeleteFlag.Deleted;
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update customer                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Delete(app);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool ConfirmData()
        {
            try
            {
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));
                if (app != null)
                {
                    //Create model
                    app.ApplyStatus = (int)StatusApply.Confirm;
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);

                        //Update Vacation                       
                        ret = appSer.Confirm(app);
                        //Update Approve status in List
                        VacationApproveListService approveListSer = new VacationApproveListService(db);
                        approveListSer.Confirm(this.VacID, Constants.DEFAULT_USER_ID, (short)StatusHasAprove.New);
                        db.Commit();
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Approve
        /// </summary>
        /// <returns></returns>
        private bool Approve()
        {
            try
            {
                int ret = 0;
                //int countUserApprove = 0;
                VacationService vacSer;
                VacationApproveListService approveListSer;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    vacSer = new VacationService(db);
                    ret = vacSer.UpdateStatus(this.VacID, this.LoginInfo.User.ID, (short)StatusApply.Approve, this.OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    this._approveStatus = (short)StatusApply.Approve;
                    approveListSer = new VacationApproveListService(db);
                    approveListSer.Approve(this.VacID, this.LoginInfo.User.ID, (short)StatusHasAprove.Approved, this.txtReasonApprove.Text);
                    this.HasCheckApprove = true;
                    db.Commit();
                }

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    if (this.checkFinished(this.VacID))//finish
                    {
                        T_Vacation vac = this.GetVacation(this.VacID);
                        this.OldUpdateDate = vac.UpdateDate;
                        //Update Vacation Header, Apply Status = Complete

                        vacSer = new VacationService(db);
                        T_Daily daily = this.GetDailyForInsert(this.VacID);
                        if (daily != null)
                        {
                            DailyService dailySer = new DailyService(db);
                            dailySer.Insert(daily);
                           var ret1= vacSer.UpdateStatus(this.VacID, this.LoginInfo.User.ID, (short)StatusApply.Complete, this.OldUpdateDate);
                            this._approveStatus = (short)StatusApply.Complete;
                        }
                    }
                    else//chua finish
                    {
                        approveListSer = new VacationApproveListService(db);
                        approveListSer.BackPreviousToNew(this.VacID, this.LoginInfo.User.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New);
                    }
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                //LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return false;
            }
            return true;
        }
        
        /// <summary>
        /// Ignore
        /// </summary>
        /// <returns></returns>
        private bool Ignore()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    VacationService vacation = new VacationService(db);
                    ret = vacation.UpdateStatus(this.VacID, this.LoginInfo.User.ID, (short)StatusApply.Ignore, this.OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    VacationApproveListService approveListSer = new VacationApproveListService(db);
                    approveListSer.Ignore(this.VacID, this.LoginInfo.User.ID, (short)StatusHasAprove.Ignore, this.txtReasonApprove.Text);
                    this.HasCheckApprove = true;
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }
            return true;
        }

        /// <summary>
        /// Previous
        /// </summary>
        /// <returns></returns>
        private bool Previous()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    VacationService vacation = new VacationService(db);
                    ret = vacation.UpdateStatus(this.VacID, this.LoginInfo.User.ID, (short)StatusApply.BackPrev, this.OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    VacationApproveListService approveListSer = new VacationApproveListService(db);
                    approveListSer.Previous(this.VacID, this.LoginInfo.User.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New, this.txtReasonApprove.Text);
                    this.HasCheckApprove = true;
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }
            return true;
        }

        /// <summary>
        /// check is approve Finished
        /// </summary>
        /// <param name="VacID"></param>
        /// <returns></returns>
        private bool checkFinished(int VacID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService lstSer = new VacationApproveListService(db);
                return lstSer.CheckApproveIsFinish(VacID);
            }
        }

        /// <summary>
        /// Get Data Daily For Insert
        /// </summary>
        /// <returns></returns>
        private T_Daily GetDailyForInsert(int vacID)
        {
            T_Daily daily = null;

            VacationInfoDetail detail = this.GetVacationInfo(vacID, this.LoginInfo.User.ID);
            if (detail != null)
            {
                daily = new T_Daily();
                daily.UserID = detail.UserID;
                daily.WorkDate = detail.VacationDate;
                daily.TypeApplyID = detail.TypeApplyID;
                daily.Content = detail.Reason;
                daily.VacationID = detail.ID;
                short startHour = 0;
                short startMin = 0;
                short endHour = 0;
                short endMin = 0;
                switch (detail.VacationStatus)
                {
                    case (int)TypePerform.Morning:
                        startHour = BEGIN_MORNING_HOUR;
                        startMin = BEGIN_MORNING_MIN;
                        endHour = END_MORNING_HOUR;
                        endMin = END_MORNING_MIN;
                        break;
                    case (int)TypePerform.Afternoon:
                        startHour = BEGIN_AFTERNOON_HOUR;
                        startMin = BEGIN_AFTERNOON_MIN;
                        endHour = END_AFTERNOON_HOUR;
                        endMin = END_AFTERNOON_MIN;
                        break;
                    case (int)TypePerform.FullDay:
                        startHour = BEGIN_MORNING_HOUR;
                        startMin = BEGIN_MORNING_MIN;
                        endHour = END_AFTERNOON_HOUR;
                        endMin = END_AFTERNOON_MIN;
                        break;
                }
                daily.StartHour = startHour;
                daily.StartMinute = startMin;
                daily.EndHour = endHour;
                daily.EndMinute = endMin;
                daily.CreateUID = detail.UserID;
                daily.UpdateUID = detail.UserID;
            }

            return daily;
        }

        /// <summary>
        /// User Changed
        /// </summary>
        private void UserChanged()
        {
            if (!string.IsNullOrEmpty(this.txtUserCD.Text.Trim()))
            {
                M_User u = this.GetUserByCD(this.txtUserCD.Text.Trim());
                if (u != null)
                {
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), u.ID);
                }
                else
                {
                    //this._hasApproveUser = false;
                    //this.rptApproveChild.DataSource = null;
                    //this.rptApproveChild.DataBind();
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), -1);
                }
            }
            else
            {
                this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), -1);
            }
        }
        
        #endregion
                
        #region Web Methods

        /// <summary>
        /// Get User Name By User Code
        /// </summary>        
        /// <returns>User Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetUserName(string in1)
        {
            var userCd = in1;
            var userCdShow = in1;
            userCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(userCd, M_User.USER_NAME_1_MAX_LENGTH);
            userCdShow = EditDataUtil.ToFixCodeShow(userCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(userCd);
                    if (model != null && model.ID != Constant.DEFAULT_ID
                                     && model.StatusFlag == 0)
                    {
                        DepartmentService deptSer = new DepartmentService(db);
                        M_Department dept = deptSer.GetByID(model.DepartmentID);
                        string deptNm = dept != null ? dept.DepartmentName : string.Empty;

                        var result = new
                        {
                            userCD = userCdShow,
                            userNm = model.UserName1,
                            departmentNm = deptNm,
                            positionNm = model.Position
                        };
                        
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var userCD = new
                    {
                        userCD = userCdShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(userCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
                
        #endregion

        
    }
}
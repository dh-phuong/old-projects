﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;
using System.Data.SqlClient;

namespace DailyReport.Vacation
{
    public partial class FrmVacationRegistDetail : FrmBaseDetail
    {
        #region Constant

        private const string URL_LIST = "~/Vacation/FrmVacationRegistList.aspx";
        private const short BEGIN_MORNING_HOUR = 8;
        private const short BEGIN_MORNING_MIN = 0;
        private const short END_MORNING_HOUR = 11;
        private const short END_MORNING_MIN = 50;
        private const short BEGIN_AFTERNOON_HOUR = 12;
        private const short BEGIN_AFTERNOON_MIN = 50;
        private const short END_AFTERNOON_HOUR = 17;
        private const short END_AFTERNOON_MIN = 50;
        #endregion

        #region Variant

        //public bool _isPrevButtonDisp;

        public bool _isCancelButtonDisp;        

        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;
        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;
                        
        /// <summary>
        /// Has Approve User list(exist user for approve)
        /// </summary>
        public bool _hasApproveUser;

        
        public bool _isShowCancel;

        public bool _isDeleted;

        ///// <summary>
        ///// 2015/03/23
        ///// Check login user is exist in approve user
        ///// </summary>
        //public bool _isApproveUser;

        ///// <summary>
        ///// Check login user is create user
        ///// 2015/03/26
        ///// </summary>
        //public bool _isCreateUser;

       // private int _defaultUnitMinute;
        private string _defaultTypePerform;
        
        /// <summary>
        /// StatusList
        /// </summary>
       // private IList<DropDownModel> _statusList;
        
        /// <summary>
        /// TypeList
        /// </summary>
        private IList<DropDownModel> _typeList;

        /// <summary>
        /// TypePerformList
        /// </summary>
        private IList<DropDownModel> _typePerformList;

        #endregion

        #region Property

        /// <summary>
        /// Get or set VacationID
        /// </summary>
        public int VacID
        {
            get { return (int)ViewState["VacationID"]; }
            set { ViewState["VacationID"] = value; }
        }

        /// <summary>
        /// Get or set UserID of user registry
        /// </summary>
        public int UserRegisterID
        {
            get { return (int)ViewState["UserRegisterID"]; }
            set { ViewState["UserRegisterID"] = value; }
        }

        /// <summary>
        /// Create user of this vacation
        /// </summary>
        public int CreateUID
        {
            get { return (int)ViewState["CreateUID"]; }
            set { ViewState["CreateUID"] = value; }
        }

        /// <summary>
        /// Previous Vacation ID
        /// </summary>
        public int? PreVacID
        {
            get { return (int?)ViewState["PreVacID"]; }
            set { ViewState["PreVacID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// This user has Approved
        /// </summary>
        public bool HasCheckApprove
        {
            get { return (bool)ViewState["HasCheckApprove"]; }
            set { ViewState["HasCheckApprove"] = value; }
        }

        /// <summary>
        /// ApproveStatus
        /// </summary>
        public short ApproveStatus
        {
            get { return (short)ViewState["ApproveStatus"]; }
            set { ViewState["ApproveStatus"] = value; }
        }

        /// <summary>
        /// ApproveUserList
        /// </summary>
        public IList<VacationApprove> ApproveUserList
        {
            get { return (IList<VacationApprove>)ViewState["ApproveUserList"]; }
            set { ViewState["ApproveUserList"] = value; }
        }


        /// <summary>
        /// FocusControlId
        /// </summary>
        public string FocusControlId
        {
            get;
            private set;
        }
        /// <summary>
        /// UserRegister
        /// </summary>
        //public M_User UserRegister
        //{
        //    get { return (M_User)ViewState["UserRegister"]; }
        //    set { ViewState["UserRegister"] = value; }
        //}
        #endregion

        #region Event

        /// <summary>
        /// Init Event
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vacation";
            base.FormSubTitle = "Detail";

            //Init Max Length
            this.txtReason.MaxLength = T_Approve.CONTENT_MAX_LENGTH;

            //this.cmbType.SelectedIndexChanged += new EventHandler(cmbType_SelectedIndexChanged);

            this.txtUserCD.TextChanged += new EventHandler(txtUserCD_TextChanged);

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);                        
        }

        /// <summary>
        /// Page load Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.VacationRegist);
            if (!this._authority.IsVacRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }
            //Get Default Data
            this.GetDefaultData();

            if (!this.IsPostBack)
            {
                this.InitData();
                
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Check mode
                    if (this.PreviousPageViewState["ID"] == null)
                    {
                       // this.ClearValue();
                        //Set Mode
                        this.ProcessMode(Mode.Insert);
                    }
                    else
                    {
                        //Get Vacation data by id
                        this.VacID = int.Parse(PreviousPageViewState["ID"].ToString());
                        T_Vacation app = this.GetVacation(this.VacID);

                        //Check Vacation
                        if (app != null )
                        {
                            //if (app.ApplyStatus == (int)StatusApply.New || app.ApplyStatus == (int)StatusApply.Ignore || app.ApplyStatus == (int)StatusApply.Complete)//Dong nay moi tao, chua confirm/ or bi tra ve--Them truong hop da duyet xong
                            //{
                            //Neu login user la nguoi xin gium(CreateUID) hoac nguoi dung ten xin(UserID)--> duoc quyen vao sua
                            /*+++++++++++++++++++++++++++++++++++++++2015/03/30 ++++++++++++++++++++++++++++++++++++++++*/
                            /* Cho User dung ten xem all cac dong cua minh(ko care status), minh tao cho nguoi khac va minh duoc quyen duyet */
                            if (app.UserID == this.LoginInfo.User.ID || app.CreateUID == this.LoginInfo.User.ID || this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID))
                                {
                                    //Show data
                                    this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                                    //Set Mode
                                    this.ProcessMode(Mode.View);
                                }
                                else
                                {
                                     
                                    //Server.Transfer(URL_LIST);
                                    base.RedirectUrl(URL_LIST);
                                }
                            //}
                            //else//Dong nay da confirm roi
                            //{
                            //    if (app.UserID == this.LoginInfo.User.ID || !this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID))
                            //        //Nguoi dung ten hoac nguoi ko co quyen duyet--> ko dc vao
                            //    {
                            //        Server.Transfer(URL_LIST);
                            //    }
                            //    else
                            //    {
                            //        //Show data
                            //        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                            //        //Set Mode
                            //        this.ProcessMode(Mode.View);
                            //    }
                            //}
                        }
                        else
                        {
                             
                            //Server.Transfer(URL_LIST);
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    this.ClearValue();
                    //Set mode
                    this.ProcessMode(Mode.Insert);
                }
            }
            //Set init
            this.Success = false;
        }

        /// <summary>
        /// txtUserCD TextChanged Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void txtUserCD_TextChanged(object sender, EventArgs e)
        {            
            this.UserChanged();
        }

        /// <summary>
        /// btnSearchUserHdn Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearchUserHdn_Click(object sender, EventArgs e)
        {
            this.UserChanged();
        }

        /// <summary>
        /// Process data Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case DailyReport.Utilities.Mode.Insert:
                case DailyReport.Utilities.Mode.Copy:

                    //Insert Data
                    if (this.InsertData())
                    {
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.UserRegisterID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                        
                    }
                    else
                    {
                        this.FocusControlId = this.txtReason.ClientID;
                        //this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        this.RestoreListApprove(this.VacID);
                    }
                    break;

                case DailyReport.Utilities.Mode.Delete:

                    //Delete Data
                    if (this.DeleteData())
                    {

                        Server.Transfer(URL_LIST);
                        //base.RedirectUrl(URL_LIST);
                        //base.TransferUrl(URL_LIST);
                       //2222 base.RedirectUrl(URL_LIST);
                        /////this.BackPage();
                        /////Response.Redirect(URL_LIST);
                    }
                    else
                    {
                        this.FocusControlId = this.btnDelete.ClientID;
                        //Show data
                        //this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        this.RestoreListApprove(this.VacID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case DailyReport.Utilities.Mode.Confirm:
                    //Confirm Data
                    if (this.ConfirmData())
                    {                        
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.FocusControlId = this.btnConfirm.ClientID;
                        //Show data
                       // this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        this.RestoreListApprove(this.VacID);
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }

                    break;

                case DailyReport.Utilities.Mode.Cancel:
                    //Cancel Data
                    if (this.CancelData())
                    {
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.FocusControlId = this.btnConfirm.ClientID;
                        //Show data
                        //this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        this.RestoreListApprove(this.VacID);
                        //Set Mode
                        this.ProcessMode(Mode.View);

                    }

                    break;

                default:

                    //Update Data
                    if (this.UpdateData())
                    {
                        //Show data
                        this.ShowData(this.GetVacationInfo(this.VacID, this.UserRegisterID));

                        //Set Mode
                        this.ProcessMode(Mode.View);

                        //Set Success
                        this.Success = true;
                    }
                    else
                    {
                        this.FocusControlId = this.btnUpdate.ClientID;
                       // this.FillDataApproveList(this.VacID, this.LoginInfo.User.ID);
                        this.RestoreListApprove(this.VacID);
                    }
                    break;
            }
        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {                
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                 
                //Server.Transfer(URL_LIST);
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// Back Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                 //Set Mode
                 this.ProcessMode(Mode.View);
             }
             else
            {
                 
                // Server.Transfer(URL_LIST);
                base.RedirectUrl(URL_LIST);
             }
        } 
        
        //btnBackList_Click
        protected void btnBackList_Click(object sender, EventArgs e)
        {
                   
        }

        /// <summary>
        /// Copy click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCopy_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID), true);

                 //Set Mode
                 this.ProcessMode(Mode.Copy);
             }
             else
            {
                 
                // Server.Transfer(URL_LIST);
                base.RedirectUrl(URL_LIST);
             }
        }

        /// <summary>
        /// Confirm Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnConfirm_Click(object sender, EventArgs e)
        {           
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Set Model
                this.Mode = Mode.Confirm;
                this.SetGroupLabelCancel(this.PreVacID);
                //Fill List Approve
               // this.FillDataApproveList(this.VacID, app.UserID);
                this.RestoreListApprove(this.VacID);
                //+++++++++++++++++
                this.UserRegisterID = this.GetUserByCD(this.txtUserCD.Text.Trim()).ID;
               // this.colorStatus = base.GetStatusColorLabel(app.ApplyStatus, ref this.statusNameLbl);
                this.HasCheckApprove = false;
                         
                //+++++++++++++++++
                //Show question confirm
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_CONFIRM_WORK, DailyReport.Models.DefaultButton.No, true);
            }
            else
            {
                 
               // Server.Transfer(URL_LIST);
                base.RedirectUrl(URL_LIST);
            }
        }
        
        /// <summary>
        /// Delete Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDelete_Click(object sender, EventArgs e)
        {
            //Set Model
            this.Mode = Mode.Delete;

            //Fill List Approve
            string userCode = string.IsNullOrEmpty(this.txtUserCD.Text) ? this.LoginInfo.User.UserCD : this.txtUserCD.Text.Trim();
            this.SetGroupLabelCancel(this.PreVacID);
           // this.FillDataApproveList(this.VacID, this.GetUserByCD(userCode).ID);
            this.RestoreListApprove(this.VacID);
           // this.colorStatus = base.GetStatusColorLabel(this.GetVacation(this.VacID).ApplyStatus, ref this.statusNameLbl);
            this.HasCheckApprove = false;
            //Show question delete
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_DELETE, DailyReport.Models.DefaultButton.No, true);
        }


        /// <summary>
        /// New Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, EventArgs e)
        {
            this.ClearValue();

            //Set Mode
            this.ProcessMode(Mode.Insert);
        }


        /// <summary>
        /// Edit Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnEdit_Click(object sender, EventArgs e)
        {
            //Get Approve
             T_Vacation app = this.GetVacation(this.VacID);

             //Check Approve
             if (app != null)
             {
                 //Show data
                 this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));

                 //Set Mode
                 this.ProcessMode(Mode.Update);
             }
             else
             {
                  
                 //Server.Transfer(URL_LIST);
                 base.RedirectUrl(URL_LIST);
             }
        }


        /// <summary>
        /// btnCancel Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //Get Approve
            T_Vacation app = this.GetVacation(this.VacID);

            //Check Approve
            if (app != null)
            {
                //Set Previous Vacation ID
                this.PreVacID = this.VacID;
                
                //Show data
                this.ShowData(this.GetVacationInfo(this.VacID, this.LoginInfo.User.ID));
                this.ApproveStatus = (int)StatusApply.Cancel;
                this.colorStatus = base.GetStatusColorLabel(this.ApproveStatus, ref this.statusNameLbl);
                //Set Mode
                this.ProcessMode(Mode.Cancel);
            }
            else
            {
                // Server.Transfer(URL_LIST);
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Insert Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnInsert_Click(object sender, EventArgs e)
        {
            //Fill List Approve
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
          
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
            this.colorStatus = base.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
            if (!this.PreVacID.HasValue)
            {
                //Check input
                if (!this.CheckInput())
                {
                    return;
                }
                //Check CheckValidAnnual
                if (!this.CheckValidAnnual())
                {
                    return;
                }
            }
            this.HasCheckApprove = false;
            this.UserRegisterID = this.GetUserByCD(userCD).ID;
            //Show question insert
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_INSERT, DailyReport.Models.DefaultButton.Yes);
        }
        
        /// <summary>
        /// Update Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //Fill List Approve
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            //this.colorStatus = base.GetStatusColorLabel(this.GetVacation(this.VacID).ApplyStatus, ref this.statusNameLbl);
            //this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(userCD).ID);
            this.RestoreListApprove(this.VacID);
            //Check input
            if (!this.CheckInput())
            {
                return;
            }
            //Check CheckValidAnnual
            if (!this.CheckValidAnnual())
            {
                return;
            }
            this.HasCheckApprove = false;
            this.UserRegisterID = this.GetUserByCD(userCD).ID;
            //Show question update
            base.ShowQuestionMessage(M_Message.MSG_QUESTION_UPDATE, DailyReport.Models.DefaultButton.Yes);
        }

        /// <summary>
        /// btnCancelSub Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnCancelSub_Click(object sender, EventArgs e)
        {
           /********** T_Vacation vacation = this.GetVacation(this.VacID);

            //Check approve
            if (vacation != null)
            {*/
                // this.colorStatus = base.GetStatusColorLabel(vacation.ApplyStatus, ref this.statusNameLbl);
                //this.SetIsApproveUser(vacation.ID, this.LoginInfo.User.ID);
               // this.SetGroupLabelCancel(this.PreVacID);
                //Fill Data
               // this.FillDataApproveList(this.VacID, vacation.UserID);
                this.ApproveStatus = (int)StatusApply.Cancel;
                //this.colorStatus = base.GetStatusColorLabel(this.ApproveStatus, ref this.statusNameLbl);
                this.RestoreListApprove(this.VacID);
                //Show question Back previous
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_CANCEL, DailyReport.Models.DefaultButton.No, true);
           /************ }
            else
            {
                base.RedirectUrl(URL_LIST);
            }*/
        }

        /// <summary>
        /// cmbType SelectedIndexChanged Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cmbType_SelectedIndexChanged(object sender, EventArgs e)
        {           
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
        }

        
        #endregion

        #region Methods


        /// <summary>
        /// RestoreListApprove
        /// </summary>
        private void RestoreListApprove(int VacID)
        {
            this.colorStatus = base.GetStatusColorLabel(this.ApproveStatus, ref this.statusNameLbl);
            this.rptApproveChild.DataSource = this.ApproveUserList;
            this._hasApproveUser = this.rptApproveChild.DataSource != null;
        }
        
        /// <summary>
        /// Init Data
        /// </summary>
        public void InitData()
        {
            this.statusNameLbl = string.Empty;
           // this._isPrevButtonDisp = false;
            this._isCancelButtonDisp = false;
            this.HasCheckApprove = false;
            //this.UserRegister = this.LoginInfo.User;
            //--- this.dtStartDate.Value = DateTime.Now;
            //--- this.dtEndDate.Value = DateTime.Now;
            this.dtPerformDate.Value = DateTime.Now;
            
            this._isDeleted = false;
            this.ApproveStatus = (short)StatusApply.None;
            this._hasApproveUser = false;
            
            //this.chkDeletedData.Checked = false;
            //this.InitCombobox(this.cmbStatus, this._statusList, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
            this.InitCombobox(this.cmbTypePerform, this._typePerformList, M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            this.InitComboboxType();
            this.txtUserName.Value = this.LoginInfo.User.UserName1;
            this.txtUserCD.Value = EditDataUtil.ToFixCodeShow(this.LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            this.txtPositionNm.Text = this.LoginInfo.User.Position;
            this.txtDepartmentNm.Text = this.LoginInfo.Department.DepartmentName;
            this.txtCurrentAnnual.Text = this.LoginInfo.User.AnnualDays.ToString();
            this.txtCurrentAnnualDate.Text = this.LoginInfo.User.AnnualDate.HasValue ? this.LoginInfo.User.AnnualDate.Value.ToString(Constants.FMT_DATE) : string.Empty;
            this.hdnDepartmentID.Value = this.LoginInfo.User.DepartmentID.ToString();
            this.CreateUID = this.LoginInfo.User.ID;
        }

        /// <summary>
        /// GetDepartmentByID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_Department GetDepartmentByID(int ID)
        {
            using (DB db = new DB())
            {
                DepartmentService deptSer = new DepartmentService(db);
                return deptSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode"></param>
        private void ProcessMode(Mode mode)
        {
            bool enable;

            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Insert:
                case Mode.Copy:
                case Mode.Update:
                    enable = false;
                    if (this.Mode == Mode.Copy)
                    {
                        this.PreVacID = null;
                        this.colorStatus = this.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
                        this.txtVacationNo.Text = string.Empty;
                        this.dtApplyDate.Text = string.Empty;
                        this.lblVacCancelText.InnerText = string.Empty;
                        this.lblVacCancelText.Visible = false;
                        this.divVacLabel.Visible = false;
                        
                        ////  this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
                        //  this.dtConfirmDate.Value = null;
                        //  this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()));
                    }

                    if (this.Mode == Mode.Insert)
                    {
                        
                        this.colorStatus = this.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
                        string userCD = string.IsNullOrEmpty(this.txtUserCD.Text) ? this.LoginInfo.User.UserCD : this.txtUserCD.Text.Trim();
                        this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(userCD).ID);
                    }

                    break;
                case Utilities.Mode.Cancel:
                    enable = true;
                    this.divVacLabel.Visible = false;
                    break;

                default:
                    this.divVacLabel.Visible = true;
                    this.ApproveStatus = this.GetVacation(this.VacID).ApplyStatus;
                    /*24/03/2015 base.DisabledLink(this.btnEdit, !base._authority.IsWorkEdit || this._isDeleted || (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);

                     base.DisabledLink(this.btnDelete, !base._authority.IsWorkDelete || this._isDeleted || this._approveStatus == (short)StatusApply.Complete || this._approveStatus == (short)StatusApply.Approve || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                     base.DisabledLink(this.btnCopy, !base._authority.IsWorkCopy);
                     base.DisabledLink(this.btnNew, !base._authority.IsWorkNew );
                     base.DisabledLink(this.btnConfirm, !base._authority.IsWorkConfirm || this._isDeleted || (this._approveStatus != (short)StatusApply.New && this._approveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);*/
                    if (this.PreVacID.HasValue)
                    {
                       //@ base.DisabledLink(this.btnEdit, true);
                        //this.btnEdit.Visible = false;
                        this.dvBtnEdit.Visible = false;
                    }
                    else
                    {
                        //base.DisabledLink(this.btnEdit, !base._authority.IsVacRegistEdit || this._isDeleted || (this.ApproveStatus != (short)StatusApply.New && this.ApproveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                        bool enEd = !base._authority.IsVacRegistEdit || this._isDeleted || (this.ApproveStatus != (short)StatusApply.New && this.ApproveStatus != (short)StatusApply.Ignore);
                        //this.btnEdit.Visible = !enEd;
                        this.dvBtnEdit.Visible = !enEd;
                    }

                   //@  base.DisabledLink(this.btnDelete, !base._authority.IsVacRegistDelete || this._isDeleted || this.ApproveStatus == (short)StatusApply.Complete || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    bool enDe = !base._authority.IsVacRegistDelete || this._isDeleted || this.ApproveStatus == (short)StatusApply.Complete;
                    //this.btnEdit.Visible = !enDe;
                    this.dvBtnDelete.Visible = !enDe;
                   // base.DisabledLink(this.btnCopy, !base._authority.IsVacRegistCopy);
                   // base.DisabledLink(this.btnNew, !base._authority.IsVacRegistNew);

                   //@  base.DisabledLink(this.btnConfirm, !base._authority.IsVacRegistConfirm || this._isDeleted || (this.ApproveStatus != (short)StatusApply.New && this.ApproveStatus != (short)StatusApply.Ignore) || EditDataUtil.ToFixCodeDB(this.LoginInfo.User.UserCD, M_User.USER_CODE_MAX_LENGTH) == M_User.ISV_ADMIN_CODE);
                    bool enCo = !base._authority.IsVacRegistConfirm || this._isDeleted || (this.ApproveStatus != (short)StatusApply.New && this.ApproveStatus != (short)StatusApply.Ignore);
                    this.dvBtnConfirm.Visible = !enCo;
                   // this.btnEdit.Visible = !enCo;
                    enable = true;
                    break;
            }

            //Lock control
            this.txtUserName.SetReadOnly(true);
            if (this.chkRepresentation.Checked && (this.Mode == Mode.Insert || this.Mode == Mode.Copy))
            {
                this.txtUserCD.SetReadOnly(false);
            }
            else
            {
                this.txtUserCD.SetReadOnly(true);
            }
            this.txtVacationNo.SetReadOnly(true);
            this.txtReason.ReadOnly = enable;
            this.cmbType.Enabled = !enable;
            this.cmbTypePerform.Enabled = !enable;
            this.dtApplyDate.Enabled = false;
            this.dtPerformDate.Enabled = !enable;
            if (this.Mode == Mode.Update)
            {
                this.chkRepresentation.Disabled = true;
            }
            else
            {
                this.chkRepresentation.Disabled = enable;
            }
                        
            this.txtPositionNm.ReadOnly = true;
            this.txtDepartmentNm.ReadOnly = true;   
        }

        /// <summary>
        /// SetGroupLabelCancel
        /// </summary>
        /// <param name="PreVacID"></param>
        private void SetGroupLabelCancel(int? PreVacID)
        {
            if (PreVacID.HasValue)
            {
                this.PreVacID = PreVacID;
                this._isShowCancel = true;
                this.lblVacCancelText.InnerText = "Cancel for vacation " + this.GetVacation(PreVacID.Value).VacationNo;
            }
        }

        /// <summary>
        /// FillDataApproveList From Approve List Table
        /// </summary>
        private void FillDataApproveList(int VacID, int UserID)
        {
            this.colorStatus = base.GetStatusColorLabel((this.GetVacation(VacID)).ApplyStatus, ref this.statusNameLbl);
            IList<VacationApprove> appLstWork = this.GetListApproveByVacationID(VacID);
            IList<VacationApprove> lstApprove = this.GetListApproveUser(appLstWork, UserID, false);
            if (lstApprove == null || lstApprove.Count == 0)
            {
                this.ApproveUserList = null;
                this._hasApproveUser = false;
                this.rptApproveChild.DataSource = null;
            }
            else
            {
                this.ApproveUserList = new List<VacationApprove>();
                ((List<VacationApprove>)this.ApproveUserList).AddRange(lstApprove);
                this._hasApproveUser = true;
                this.rptApproveChild.DataSource = lstApprove;
            }
            this.rptApproveChild.DataBind();
        }

        /// <summary>
        /// Get List Approve User (Has List Child)
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveUser(IList<VacationApprove> lstDB, int currentUserID, bool isFrmRoute = true)
        {
            IList<VacationApprove> lstRet = null;
            IList<VacationApprove> lstTemp = null;
            if (lstDB != null)
            {
                lstRet = new List<VacationApprove>();
                if (isFrmRoute && currentUserID !=-1)
                {
                    //Get Level of Current User registry
                    var appWorkModel = (from u in lstDB
                                        where u.UserID.Equals(currentUserID) || currentUserID.Equals(-1)
                                        select new VacationApprove
                                        {
                                            RouteLevel = u.RouteLevel,
                                            RouteLevelStr = u.RouteLevelStr,
                                            RouteMethod = u.RouteMethod,
                                            RouteMethodStr = u.RouteMethodStr,
                                            UserID = u.UserID,
                                            UserName = u.UserName,
                                            Position = u.Position,
                                            Department = u.Department
                                        }
                                 ).SingleOrDefault();

                    if (appWorkModel != null)
                    {
                        short userLv = appWorkModel.RouteLevel;
                        lstTemp = (from l in lstDB
                                   where (l.RouteLevel > userLv || (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) && l.RouteLevel.Equals(userLv)))
                                                 && !l.UserID.Equals(appWorkModel.UserID)
                                   select new VacationApprove
                                           {
                                               ApproveDate = l.ApproveDate,
                                               ApproveDateStr = l.ApproveDateStr,
                                               ApproveFlag = l.ApproveFlag,
                                               ApproveFlagStr = l.ApproveFlagStr,
                                               VacationID = l.VacationID,
                                               RouteLevel = l.RouteLevel,
                                               RouteLevelStr = l.RouteLevelStr,
                                               ApproveName = l.ApproveName,
                                               ApproveUID = l.ApproveUID,
                                               ApproveReason = l.ApproveReason,
                                               RouteMethod = l.RouteMethod,
                                               RouteMethodStr = l.RouteMethodStr,
                                               UserID = l.UserID,
                                               UserName = l.UserName,
                                               Position = l.Position,
                                               Department = l.Department
                                           }).ToList();

                        //Current User has Level Max. Get current user
                        if (lstTemp.Count == 0)
                        {
                            lstTemp = (from k in lstDB
                                       where k.RouteLevel.Equals(userLv)
                                       select new VacationApprove
                                       {
                                           ApproveDate = k.ApproveDate,
                                           ApproveDateStr = k.ApproveDateStr,
                                           ApproveFlag = k.ApproveFlag,
                                           ApproveFlagStr = k.ApproveFlagStr,
                                           VacationID = k.VacationID,
                                           RouteLevel = k.RouteLevel,
                                           RouteLevelStr = k.RouteLevelStr,
                                           ApproveName = k.ApproveName,
                                           ApproveUID = k.ApproveUID,
                                           ApproveReason = k.ApproveReason,
                                           RouteMethod = k.RouteMethod,
                                           RouteMethodStr = k.RouteMethodStr,
                                           UserID = k.UserID,
                                           UserName = k.UserName,
                                           Position = k.Position,
                                           Department = k.Department
                                       }).ToList();
                        }
                    }
                    
                    // lstRet = new List<VacationApprove>();
                    if (lstTemp == null || lstTemp.Count == 0)
                    {
                        ((List<VacationApprove>)lstRet).AddRange(lstDB);
                    }
                    else
                    {
                        ((List<VacationApprove>)lstRet).AddRange(lstTemp);
                    }
                }
                else//From List Approve
                {
                    ((List<VacationApprove>)lstRet).AddRange(lstDB);
                }
            }
            return lstRet;
        }

        /// <summary>
        /// GetListApproveWork From Route
        /// </summary>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveWorkFromRoute(int TypeID)
        {            
            using (DB db = new DB())
            {
                Route_DService rSer = new Route_DService(db);
                //Get Approve List
                return rSer.GetListApproveVacationByTypeID(TypeID);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl,IList<DropDownModel> data, string configCD)
        {
            // init combox 
            ddl.DataSource = data;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void InitComboboxType()
        {
            // init combox 
            //////IList<DropDownModel> lstDB = this.GetDataForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_TYPE_DAYOFF, true);
            //this.cmbType.DataSource = (from l in this._typeList
            //                           where !l.Value.Equals(M_Config_H.CONFIG_CD_DEFAULT_TYPE_NORMAL_WORK)
            //                           select new DropDownModel
            //                           {
            //                               DataboundItem = l.DataboundItem,
            //                               DisplayName = l.DisplayName,
            //                               Value = l.Value
            //                           }).ToList();
            ////using (DB db = new DB())
            ////{
            ////    TypeApplyService typeSer = new TypeApplyService(db);
            ////    IList<DropDownModel> lstDB = typeSer.GetDataForDropDownList();
            ////    this.cmbType.DataSource = lstDB;
            ////}
            this.cmbType.DataSource = this._typeList;
            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();
        }

        /// <summary>
        /// SetIsApproveUser
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="UserID"></param>
        //private void SetIsApproveUser(int ID, int UserID)
        //{
        //    this._isApproveUser = this.CheckLoginUserIsApproveUser(ID, this.LoginInfo.User.ID);
        //}
        
        /// <summary>
        /// Show data
        /// </summary>
        /// <param name="app"></param>
        private void ShowData(VacationInfoDetail app, bool isFromRoute = false)
        {
            if (app != null)
            {                
              //  this._isCreateUser = app.CreateUID == this.LoginInfo.User.ID ? true : false;
                //+++++this._isApproveUser = this.CheckLoginUserIsApproveUser(app.ID, this.LoginInfo.User.ID);
               // this.SetIsApproveUser(app.ID, this.LoginInfo.User.ID);

                this.dtApplyDate.Value = app.ApplyDate;
               // this.colorStatus = base.GetStatusColorLabel(app.ApplyStatus, ref this.statusNameLbl);
                
                this.SetGroupLabelCancel(app.PreVacationID);
                this.cmbType.SelectedValue = app.TypeApplyID.ToString();
                this.txtUserName.Text = app.UserName;
                this.txtUserCD.Text = app.UserCD;
                this.txtReason.Text = app.Reason;
                this.txtVacationNo.Text = app.VacationNo;
                this.txtDepartmentNm.Text = app.DepartmentNm;
                this.txtPositionNm.Text = app.Position;
                //Get List Approve
                string userCD = this.LoginInfo.User.UserCD;
                if (!string.IsNullOrEmpty(this.txtUserCD.Text))
                {
                    userCD = this.txtUserCD.Text.Trim();
                }
                if (isFromRoute)
                {
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
                }
                else
                {
                    this.FillDataApproveList(this.VacID, this.GetUserByCD(userCD).ID);
                }
                this.txtCurrentAnnual.Text = app.CurrentAnnualDay.HasValue ? app.CurrentAnnualDay.Value.ToString() : string.Empty;
                this.txtCurrentAnnualDate.Text = app.CurrentAnnualDate.HasValue ? app.CurrentAnnualDate.Value.ToString(Constants.FMT_DATE) : string.Empty;

                this.dtPerformDate.Value = app.VacationDate;
                this.cmbTypePerform.SelectedValue = app.VacationStatus.ToString();
                this.ApproveStatus = app.ApplyStatus;
                //Save ID and UpdateDate
                this.VacID = app.ID;
                this.CreateUID = app.CreateUID;
                this.UserRegisterID = app.UserID;
                this.OldUpdateDate = app.UpdateDate;
                this.hdnVacationID.Value = this.VacID.ToString();
                this._isDeleted = app.DeleteFlg == (short)DeleteFlag.Deleted;
                int status = app.ApproveStatus == null ? 0 : app.ApproveStatus.Value;
                
                //this.HasCheckApprove = this.HasCheckApprove ? this.HasCheckApprove : (this.GetApproveStatusByUserID(this.VacID, this.LoginInfo.User.ID) != (int)StatusHasAprove.New);
                this.HasCheckApprove = this.HasCheckApprove ? this.HasCheckApprove : (status != (int)StatusHasAprove.New);
                //this._isPrevButtonDisp = this.CheckPreviousLevelFinish(app.ID, this.LoginInfo.User.ID);
                this._isCancelButtonDisp = app.ApplyStatus == (int)StatusApply.Complete && app.PreVacationID == null && !this.CheckVacationHasCancel(this.VacID);
            }
        }

        /// <summary>
        /// Check Login User Is Approve User
        /// </summary>
        /// <param name="VacID"></param>
        /// <param name="LoginUserID"></param>
        /// <returns></returns>
        private bool CheckLoginUserIsApproveUser(int VacID, int LoginUserID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService vacSer = new VacationApproveListService(db);
                return vacSer.CheckLoginUserIsApproveUser(VacID, LoginUserID);
            }             
        }

        /// <summary>
        /// CheckVacationHasCancel
        /// </summary>
        /// <param name="VacID"></param>
        /// <returns>true: exist cancel, false: not exist </returns>
        private bool CheckVacationHasCancel(int VacID)
        {
            using (DB db = new DB())
            {
                VacationService vacSer = new VacationService(db);
                return vacSer.CheckVacationHasCancel(VacID);
            }
        }

        /// <summary>
        /// GetApproveStatusByUserID
        /// </summary>
        /// <param name="VacID"></param>
        /// <param name="UserID"></param>
        /// <returns></returns>
        //private int GetApproveStatusByUserID(int VacID, int UserID)
        //{
        //    using (DB db = new DB())
        //    {
        //        VacationApproveListService vacSer = new VacationApproveListService(db);
        //        return vacSer.GetStatusByHID(VacID, UserID);
        //    }
        //}

        /// <summary>
        /// Clear value on screen
        /// </summary>
        private void ClearValue()
        {
            this.PreVacID = null;
           // this.cmbStatus.SelectedValue = ((int)StatusApprove.New).ToString();
            this.InitComboboxType();
            this.InitCombobox(this.cmbTypePerform, this._typePerformList, M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            this.txtVacationNo.Text = string.Empty;
            this.txtUserName.Text = LoginInfo.User.UserName1;
            this.txtUserCD.Text = EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            this.chkRepresentation.Checked = false;
            this.txtReason.Text = string.Empty;
            this.dtApplyDate.Value = null;
            this.dtPerformDate.Value = DateTime.Now;
            this.txtReason.Text = string.Empty;
            this.divVacLabel.Visible = false;
            //Reload List Approve user
            string userCD = this.LoginInfo.User.UserCD;
            if (!string.IsNullOrEmpty(this.txtUserCD.Text))
            {
                userCD = this.txtUserCD.Text.Trim();
            }
            this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), this.GetUserByCD(userCD).ID);
        }

        /// <summary>
        /// Fill Data Approve List From Route
        /// </summary>
        private void FillDataApproveList_FromRoute(int TypeHID, int userID)
        {
            IList<VacationApprove> lst = this.GetListApproveUser(this.GetListApproveWorkFromRoute(TypeHID), userID);

            if (lst != null && lst.Count != 0)
            {
                this.ApproveUserList = new List<VacationApprove>();
                ((List<VacationApprove>)this.ApproveUserList).AddRange(lst);
                this._hasApproveUser = true;
                this.rptApproveChild.DataSource = lst;
            }
            else
            {
                this.ApproveUserList = null;
                this._hasApproveUser = false;
                this.rptApproveChild.DataSource = null;
            }
            this.rptApproveChild.DataBind();
        }

        /// <summary>
        /// Get Vacation by ID
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private T_Vacation GetVacation(int wID)
        {
            using (DB db = new DB())
            {
                VacationService appSer = new VacationService(db);

                //Get Approve
                return appSer.GetByID(wID);
            }
        }

        /// <summary>
        /// GetVacationInfo
        /// </summary>
        /// <param name="vID"></param>
        /// <returns></returns>
        private VacationInfoDetail GetVacationInfo(int vID, int userID)
        {
            using (DB db = new DB())
            {
                VacationService appSer = new VacationService(db);

                //Get Vacation
                return appSer.GetVacationInfoByID(vID, userID);
            }
        }

        /// <summary>
        /// CheckPreviousLevelFinish
        /// </summary>
        /// <param name="vacID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private bool CheckPreviousLevelFinish(int vacID, int userID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService vacSer = new VacationApproveListService(db);
                return vacSer.CheckPreviousLevelFinish(vacID, userID);
            }
        }

        /// <summary>
        /// GetListApproveVacation(From Vacation_List)
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private IList<VacationApprove> GetListApproveByVacationID(int wID)
        {
            using (DB db = new DB())
            {
                VacationApproveListService appListSer = new VacationApproveListService(db);

                //Get Approve
                return appListSer.GetListForVacation(wID);
               
            }
        }

        /// <summary>
        /// GetTotalRowApprove
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        //private int GetTotalRowApprove(int wID)
        //{
        //    using (DB db = new DB())
        //    {
        //        ApproveListService appListSer = new ApproveListService(db);

        //        //Get Approve
        //        return appListSer.GetTotalRowForWork(wID);

        //    }
        //}

        /// <summary>
        /// Get work by approve no
        /// </summary>
        /// <param name="approveNo"></param>
        /// <returns></returns>
        private T_Approve GetWorkByApproveNo(string approveNo)
        {
            using (DB db = new DB())
            {
                ApproveService appSer = new ApproveService(db);

                //Get Approve
                return appSer.GetByApproveNo(approveNo);
            }
        }

        /// <summary>
        /// Get default data
        /// </summary>
        private void GetDefaultData()
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                TypeApplyService typeSer = new TypeApplyService(db);
                
                //this._defaultStatus = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);
                
                //Status List
                //this._statusList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);
                //Type List
                this._typeList = typeSer.GetDataForDropDownList((int)TypeFormID.Vacation);

                this._typePerformList = configSer.GetDataForDropDownList(M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
                this._defaultTypePerform = configSer.GetDefaultValueDrop(M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM);
            }

        }

        /// <summary>
        /// Get Info List
        /// </summary>
        /// <param name="vacID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        private int GetInfoList(int typeID, int userID)
        {
            using (DB db = new DB())
            {
                Route_DService routeSer = new Route_DService(db);
                return routeSer.GetLevelByVacationUserID(typeID, userID);
            }
        }

        /// <summary>
        /// Check input
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            if (this.chkRepresentation.Checked)
            {
                if (string.IsNullOrEmpty(this.txtUserCD.Text.Trim()))
                {
                    this.SetMessage(this.txtUserCD.ID, M_Message.MSG_REQUIRE, "User Code");
                }
                else
                {

                    //Check level cua nguoi duoc tao thay the co <= Level cua nguoi tao giup ko
                    var loginLevel = this.GetInfoList(int.Parse(this.cmbType.SelectedValue.ToString()), this.LoginInfo.User.ID);
                    var userLevel = this.GetInfoList(int.Parse(this.cmbType.SelectedValue.ToString()), this.GetUserByCD(this.txtUserCD.Text).ID);
                    if (loginLevel < userLevel)
                    {
                        this.SetMessage(this.txtUserCD.ID, M_Message.MSG_LEVEL_GREATER_USER_LEVEL);
                    }
                }
            }
            //if (this.cmbType.SelectedValue.ToString().Equals("-1"))
            //{
            //    this.SetMessage(this.cmbType.ID, M_Message.MSG_PLEASE_SELECT, "Type");
            //}

            //if (!this.dtStartDate.Value.HasValue)
            //{
            //    this.SetMessage(this.dtStartDate.ID, M_Message.MSG_REQUIRE, "Start Date");
            //}

            /*---if (!this.dtStartTime.Value.HasValue)
            {
                this.SetMessage(this.dtStartTime.ID, M_Message.MSG_REQUIRE, "Start Time");
            }*/

            //if (!this.dtEndDate.Value.HasValue)
            //{
            //    this.SetMessage(this.dtEndDate.ID, M_Message.MSG_REQUIRE, "End Date");
            //}
            //PerformDate
            if (!this.dtPerformDate.Value.HasValue)
            {
                this.SetMessage(this.dtPerformDate.ID, M_Message.MSG_REQUIRE, "Perform Date");
            }
            //Reason
            if (string.IsNullOrEmpty(this.txtReason.Text.Trim()))
            {
                this.SetMessage(this.txtReason.ID, M_Message.MSG_REQUIRE, "Reason");
            }
           /* if (this.dtStartDate.Value.HasValue && this.dtEndDate.Value.HasValue)
            {
                if (this.dtStartDate.Value.Value > this.dtEndDate.Value.Value)
                {
                    this.SetMessage(this.dtEndDate.ID, M_Message.MSG_GREATER_THAN_EQUAL, "End Date","Start Date");
                }
            }*/

            //Check regist in weekend or holidays
            if (this.dtPerformDate.Value.HasValue)
            {
                DayOfWeek dayOfWeek = this.dtPerformDate.Value.Value.DayOfWeek;
                if (dayOfWeek == DayOfWeek.Saturday || dayOfWeek == DayOfWeek.Sunday)
                {
                    this.SetMessage(this.dtPerformDate.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                }

                if (!base.HaveError)
                {
                    if (CheckIsHoliday(this.dtPerformDate.Value.Value))
                    {
                        this.SetMessage(this.dtPerformDate.ID, M_Message.MSG_CANT_REGIST_WEEKEND_HOLIDAYS);
                    }
                }

            }
            
            //Check error
            return !base.HaveError;
        }

        /// <summary>
        /// CheckIsHoliday
        /// </summary>
        /// <param name="date"></param>
        /// <returns>true: exist, false: not exist</returns>
        private bool CheckIsHoliday(DateTime date)
        {
            using (DB db = new DB())
            {
                HolidayService holiSer = new HolidayService(db);
                return holiSer.GetDayInfo(date.Year, date.Month, date.Day) != null;
            }            
        }
        
        /// <summary>
        /// GetTypeApplyByID
        /// </summary>
        /// <param name="typeApplyID">ID</param>
        /// <returns></returns>
        private M_TypeApply GetTypeApplyByID(int typeApplyID)
        {
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                return typeSer.GetByID(typeApplyID);
            }
        }

        /// <summary>
        /// Get value of annual day in config
        /// </summary>
        /// <param name="configCD"></param>
        /// <param name="value1"></param>
        /// <returns></returns>
        private string GetValue4(string configCD, int value1)
        {
            using (DB db = new DB())
            {
                Config_DService conSer = new Config_DService(db);
                return conSer.GetValue4(configCD, value1);
            }
        }

        /// <summary>
        /// CheckValidDateType
        /// </summary>
        private bool CheckValidAnnual()
        {            
            int typeApplyID = int.Parse(this.cmbType.SelectedValue.ToString());
            
            M_TypeApply type = this.GetTypeApplyByID(typeApplyID);
            if (type != null /*&& type.SubVacationStatus == (int)SubVacation.DeductingDayOff*/)
            {
                decimal annualDay = 0;
                decimal.TryParse(this.GetValue4(M_Config_H.CONFIG_CD_LIST_TYPE_PERFORM, int.Parse(this.cmbTypePerform.SelectedValue)), out annualDay);
                M_User user = this.GetUserByCD(this.txtUserCD.Text.Trim());
                if (user != null)
                {
                    if (user.AnnualDays < annualDay)
                    {
                        this.txtCurrentAnnual.Text = user.AnnualDays.Value.ToString();
                        this.txtCurrentAnnualDate.Text = user.AnnualDate.Value.ToString(Constants.FMT_DATE);
                        this.SetMessage(this.cmbTypePerform.ID, M_Message.MSG_GREATER_THAN_EQUAL, "Annual Days", annualDay);                        
                    }
                }
            }

            return !base.HaveError;
        }

        /// <summary>
        /// Get data for insert
        /// </summary>
        /// <param name="preID">Previous Vacation ID</param>
        /// <param name="isCancel">is cancel Flag</param>
        /// <returns></returns>
        private T_Vacation GetDataForInsert(int preID = 0, bool isCancel = false)
        {
            T_Vacation app = new T_Vacation();

            app.ApplyStatus = (short)T_Vacation.C_STATUS_APP_NEW;
            int userID = this.LoginInfo.User.ID;
            M_User u = this.GetUserByCD(this.txtUserCD.Text);
            if (u != null)
            {
                userID = u.ID;
            }

            app.UserID = userID;
            app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
            app.VacationDate = this.dtPerformDate.Value;
            app.VacationStatus = short.Parse(this.cmbTypePerform.SelectedValue.ToString());
            app.Reason = this.txtReason.Text;
            if (isCancel)
            {
                app.PreVacationID = preID;
            }
            app.CreateUID = this.LoginInfo.User.ID;
            app.UpdateUID = this.LoginInfo.User.ID;

            return app;
        }

        /// <summary>
        /// GetUserByCD
        /// </summary>
        /// <param name="userCD"></param>
        /// <returns></returns>
        private M_User GetUserByCD(string userCD)
        {
            using (DB db = new DB())
            {
                UserService userSer = new UserService(db);
                return userSer.GetByUserCD(userCD);
            }            
        }
        
        /// <summary>
        /// Get List Vacation Approve User For Insert
        /// </summary>
        /// <param name="lstInput"></param>
        /// <returns></returns>
        private IList<T_Vacation_Approve_List> GetListApproveForInsert(int TypeID, int userID)
        {
            IList<T_Vacation_Approve_List> lstRet = null;
            /*IList<VacationApprove> lstDB = this.GetListApproveWorkFromRoute(TypeID);
            IList<VacationApprove> lstTemp = null;
           
            if (lstDB != null && lstDB.Count != 0)
            {
                var appWorkModel = (from u in lstDB
                                    where u.UserID.Equals(this.LoginInfo.User.ID)
                                    select new VacationApprove
                                    {
                                        RouteLevel = u.RouteLevel,
                                        RouteLevelStr = u.RouteLevelStr,
                                        RouteMethod = u.RouteMethod,
                                        RouteMethodStr = u.RouteMethodStr,
                                        UserID = u.UserID,
                                        UserName = u.UserName,
                                        Department = u.Department,
                                        Position = u.Position
                                    }
                             ).SingleOrDefault();

                if (appWorkModel != null)
                {
                    short userLv = appWorkModel.RouteLevel;
                    lstTemp = (from l in lstDB
                               where l.RouteLevel > userLv | (appWorkModel.RouteMethod.Equals((short)RouteMethods.AND) & l.RouteLevel.Equals(userLv))
                                     & !l.UserID.Equals(this.LoginInfo.User.ID)
                               select new VacationApprove
                               {
                                   ApproveDate = l.ApproveDate,
                                   ApproveDateStr = l.ApproveDateStr,
                                   ApproveFlag = l.ApproveFlag,
                                   ApproveFlagStr = l.ApproveFlagStr,
                                   VacationID = l.VacationID,
                                   RouteLevel = l.RouteLevel,
                                   RouteLevelStr = l.RouteLevelStr,
                                   ApproveName = l.ApproveName,
                                   ApproveUID = l.ApproveUID,
                                   ApproveReason = l.ApproveReason,
                                   RouteMethod = l.RouteMethod,
                                   RouteMethodStr = l.RouteMethodStr,
                                   UserID = l.UserID,
                                   UserName = l.UserName
                               }).ToList();

                    //Current User has Level Max. Get current user
                    if (lstTemp.Count == 0)
                    {
                        lstTemp = (from k in lstDB
                                   where k.UserID.Equals(this.LoginInfo.User.ID)
                                   select new VacationApprove
                                   {
                                       ApproveDate = k.ApproveDate,
                                       ApproveDateStr = k.ApproveDateStr,
                                       ApproveFlag = k.ApproveFlag,
                                       ApproveFlagStr = k.ApproveFlagStr,
                                       VacationID = k.VacationID,
                                       RouteLevel = k.RouteLevel,
                                       RouteLevelStr = k.RouteLevelStr,
                                       ApproveName = k.ApproveName,
                                       ApproveUID = k.ApproveUID,
                                       ApproveReason = k.ApproveReason,
                                       RouteMethod = k.RouteMethod,
                                       RouteMethodStr = k.RouteMethodStr,
                                       UserID = k.UserID,
                                       UserName = k.UserName
                                   }).ToList();
                    }


                }
                //Current User not exist in List Approve in DB
                if (lstTemp == null || lstTemp.Count == 0)
                {
                    lstTemp = new List<VacationApprove>();
                    ((List<VacationApprove>)lstTemp).AddRange(lstDB);
                }
            */
            IList<VacationApprove> lstTemp = this.GetListApproveUser(this.GetListApproveWorkFromRoute(TypeID), userID);

            lstRet = new List<T_Vacation_Approve_List>();
            foreach (VacationApprove item in lstTemp)
            {
                T_Vacation_Approve_List app = new T_Vacation_Approve_List();
                app.RouteUID = item.UserID;
                app.RouteLevel = item.RouteLevel;
                app.RouteMethod = item.RouteMethod;                
                app.ApproveUID = item.ApproveUID;
                app.ApproveDate = item.ApproveDate;
                app.ApproveReason = item.ApproveReason;
                lstRet.Add(app);
            }

            //}
            return lstRet;
        }
                
        /// <summary>
        /// Insert Data
        /// </summary>
        /// <returns></returns>
        private bool InsertData()
        {
            try
            {
                //Create model Vacation
                T_Vacation app = this.GetDataForInsert();
                //Create model Vacation Approve List
                IList<T_Vacation_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID, app.UserID);

                //Get Vacation
                app.VacationNo = (new TNoService()).CreateNo(T_No.VacationNo);

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    VacationService appSer = new VacationService(db);
                    VacationApproveListService appLstSer = new VacationApproveListService(db);
                    //Insert Approve
                    this.VacID = appSer.Insert(app);
                    if (this.VacID != 0 && lstApp != null)
                    {
                        foreach (var appItem in lstApp)
                        {
                            appItem.VacationID = this.VacID;
                            appLstSer.Insert(appItem);
                        }
                    }
                    db.Commit();                    
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                //{
                //    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                //    return false;
                //}

                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Update Data
        /// </summary>
        /// <returns></returns>
        private bool UpdateData()
        {
            try
            {                
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));
                if (app != null)
                {
                    //Create model
                    app.TypeApplyID = short.Parse(this.cmbType.SelectedValue.ToString());
                    if (this.chkRepresentation.Checked && !string.IsNullOrEmpty(this.txtUserCD.Text))
                    {
                        app.UserID = this.GetUserByCD(this.txtUserCD.Text).ID;
                    }
                    else
                    {
                        app.UserID = this.LoginInfo.User.ID;
                    }
                    app.Reason = this.txtReason.Text;
                    app.VacationDate = this.dtPerformDate.Value;
                    app.VacationStatus = short.Parse(this.cmbTypePerform.SelectedValue.ToString());
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    IList<T_Vacation_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID, app.UserID);

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);
                        VacationApproveListService appListSer = new VacationApproveListService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Update(app);

                            //Delete Old List
                            appListSer.DeleteByVacationID(app.ID);
                            //Insert New List
                            foreach (var item in lstApp)
                            {
                                item.VacationID = app.ID;
                                appListSer.Insert(item);
                            }
                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Delete Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool DeleteData()
        {
            try
            {
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));

                if (app != null)
                {
                    if (app.UpdateDate != this.OldUpdateDate)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    if (app.ApplyStatus == (short)StatusApply.Complete)
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_COMPLETE_APPROVED_CANT_DELETE);
                        return false;
                    }
                    //Create model
                    app.StatusFlag = (short)DeleteFlag.Deleted;
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update customer                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);

                        //Update Approve
                        if (app.Status == DataStatus.Changed)
                        {
                            ret = appSer.Delete(app);

                            db.Commit();
                        }
                        else
                        {
                            return true;
                        }
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Delete");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Confirm
        /// </summary>
        /// <returns></returns>
        private bool ConfirmData()
        {
            try
            {
                int ret = 0;
                T_Vacation app = this.GetVacation(int.Parse(this.hdnVacationID.Value));
                if (app != null)
                {
                    //Create model
                    app.ApplyStatus = (int)StatusApply.Confirm;
                    app.UpdateDate = this.OldUpdateDate;
                    app.UpdateUID = this.LoginInfo.User.ID;

                    //Update Approve                    
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        VacationService appSer = new VacationService(db);

                        //Update Vacation                       
                        ret = appSer.Confirm(app);
                        //Update Approve status in List
                        VacationApproveListService approveListSer = new VacationApproveListService(db);
                        approveListSer.Confirm(this.VacID, Constants.DEFAULT_USER_ID, (short)StatusHasAprove.New);
                        db.Commit();
                    }
                }

                //Check result update
                if (ret == 0)
                {
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    return false;
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                //{
                //    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                //    return false;
                //}
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// Cancel Data
        /// </summary>
        /// <returns></returns>
        private bool CancelData()
        {
            try
            {
                //Create model Vacation
                T_Vacation app = this.GetDataForInsert(this.PreVacID.Value, true);
                //Create model Vacation Approve List
                IList<T_Vacation_Approve_List> lstApp = this.GetListApproveForInsert(app.TypeApplyID, app.UserID);

                //Get Vacation
                app.VacationNo = (new TNoService()).CreateNo(T_No.VacationNo);

                //Insert customer
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    VacationService appSer = new VacationService(db);
                    if (appSer.CheckVacationHasCancel(this.PreVacID.Value))
                    {
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_HAD_CANCEL);
                        return false;
                    }

                    VacationApproveListService appLstSer = new VacationApproveListService(db);
                    //Insert Approve
                    this.VacID = appSer.Insert(app);
                    if (this.VacID != 0 && lstApp != null)
                    {
                        foreach (var appItem in lstApp)
                        {
                            appItem.VacationID = this.VacID;
                            appLstSer.Insert(appItem);
                        }
                    }
                    db.Commit();
                }
            }
            catch (SqlException ex)
            {
                Log.Instance.WriteLog(ex);
                //if (ex.Message.Contains(Models.Constant.M_CUSTOMER_UN_TAXCODE))
                //{
                //    this.SetMessage(this.txtTaxCode.ID, M_Message.MSG_EXIST_CODE, "Tax Code");
                //    return false;
                //}

                if (ex.Message.Contains(DailyReport.Models.Constant.T_APPROVE_PK))
                {
                    this.SetMessage(this.cmbType.ID, M_Message.MSG_EXIST_CODE, "Approve");
                    return false;
                }

                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");
                return false;
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Insert");

                Log.Instance.WriteLog(ex);

                return false;
            }

            return true;
        }

        /// <summary>
        /// User Changed
        /// </summary>
        private void UserChanged()
        {
            this.colorStatus = base.GetStatusColorLabel((int)StatusApply.New, ref this.statusNameLbl);
            if (!string.IsNullOrEmpty(this.txtUserCD.Text.Trim()))
            {
                M_User u = this.GetUserByCD(this.txtUserCD.Text.Trim());
                if (u != null)
                {
                    this.txtCurrentAnnualDate.Text = u.AnnualDate.HasValue ? u.AnnualDate.Value.ToString(Constants.FMT_DATE) : string.Empty;
                    this.txtCurrentAnnual.Text = u.AnnualDays.ToString();
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), u.ID);
                }
                else
                {
                    this.txtCurrentAnnualDate.Text = string.Empty;
                    this.txtCurrentAnnual.Text = string.Empty;
                    this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), -1);
                }
            }
            else
            {
                this.txtCurrentAnnualDate.Text = string.Empty;
                this.txtCurrentAnnual.Text = string.Empty;
                this.FillDataApproveList_FromRoute(int.Parse(this.cmbType.SelectedValue), -1);               
            }
        }
        
        #endregion
                
        #region Web Methods

        /// <summary>
        /// Get User Name By User Code
        /// </summary>        
        /// <returns>User Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetUserName(string in1)
        {
            var userCd = in1;
            var userCdShow = in1;
            userCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(userCd, M_User.USER_NAME_1_MAX_LENGTH);
            userCdShow = EditDataUtil.ToFixCodeShow(userCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(userCd);
                    if (model != null && model.ID != Constant.DEFAULT_ID
                                     && model.StatusFlag == 0)
                    {
                        DepartmentService deptSer = new DepartmentService(db);
                        M_Department dept = deptSer.GetByID(model.DepartmentID);
                        string deptNm = dept != null ? dept.DepartmentName : string.Empty;

                        var result = new
                        {
                            userCD = userCdShow,
                            userNm = model.UserName1,
                            departmentNm = deptNm,
                            positionNm = model.Position
                        };
                        
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var ret = new
                    {
                        userCD = userCdShow/*,
                        userNm = string.Empty,
                        departmentNm = string.Empty,
                        positionNm = string.Empty*/
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(ret);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
                
        #endregion

        
    }
}
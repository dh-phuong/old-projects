﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using System.Collections;
using DailyReport.Models;
using DailyReport.DAC;

namespace DailyReport.Vacation
{
    public partial class FrmVacationRegistList : FrmBaseList
    {
        #region Constant

        /// <summary>
        /// Danger text
        /// </summary>
        private const string CONST_DANGER_TEXT = "Deleted";

        /// <summary>
        /// Warning Text
        /// </summary>
        private const string CONST_WARNING_TEXT = "Is Cancel";

        #endregion Constant

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vacation";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.DangerText = CONST_DANGER_TEXT;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);

            //Init Max Length
            this.txtUserCD.MaxLength = M_User.MAX_USER_CODE_SHOW;
            this.txtUserName.MaxLength = M_User.USER_NAME_1_MAX_LENGTH;
        }


        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.VacationRegist);
            if (!this._authority.IsVacRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");

            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];

                        this.ShowCondition(data);
                    }                    
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnNew_Click(object sender, CommandEventArgs e)
        {
            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["ID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtUserCD.ID, this.txtUserCD.Value);
            hash.Add(this.txtUserName.ID, this.txtUserName.Value);
            hash.Add(this.cmbStatus.ID, this.cmbStatus.SelectedValue);
            hash.Add(this.cmbType.ID, this.cmbType.SelectedValue);
            hash.Add(this.cmbInvalid.ID, this.cmbInvalid.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtUserCD.Value = data[this.txtUserCD.ID].ToString();
            this.txtUserName.Value = data[this.txtUserName.ID].ToString();
            this.cmbStatus.SelectedValue = data[this.cmbStatus.ID].ToString();
            this.cmbType.SelectedValue = data[this.cmbType.ID].ToString();
            this.cmbInvalid.SelectedValue = data[this.cmbInvalid.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            //Type
            this.InitComboboxType();

            //Status
            this.InitCombobox(this.cmbStatus, M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED, true);
            // Default Invalid Data
            this.hdInValidDefault.Value = this.GetDefaultValueForDropdownList(M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);

            //Invalid
            this.InitCombobox(this.cmbInvalid, M_Config_H.CONFIG_CD_DEFAULT_LIST_SEARCH_COMBO);
            //Set Default Select index
            this.cmbInvalid.SelectedValue = this.hdInValidDefault.Value;
            // header grid
            this.HeaderGrid.SortDirec = "2";
            this.HeaderGrid.SortField = "3";

            base.DisabledLink(this.btnNew, !base._authority.IsVacRegistNew);
        }

        /// <summary>
        /// GetDefaultValueForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private string GetDefaultValueForDropdownList(string configCD)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDefaultValueDrop(configCD);
            }
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combovbox Type
        /// </summary>
        private void InitComboboxType()
        {
            using (DB db = new DB())
            {
                TypeApplyService typeSer = new TypeApplyService(db);
                IList<DropDownModel> lstDB = typeSer.GetDataForDropDownList((int)TypeFormID.Vacation,true);
                this.cmbType.DataSource = lstDB;
            }
            this.cmbType.DataValueField = "Value";
            this.cmbType.DataTextField = "DisplayName";
            this.cmbType.DataBind();
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            int totalRow = 0;
            this.GetColorClass(1);
            IList<VacationInfo> lstResult = null;

            //Get data
            using (DB db = new DB())
            {
                VacationService appSer = new VacationService(db);
                totalRow = appSer.GetTotalRow_Regist(LoginInfo.User.ID, this.txtUserCD.Value, this.txtUserName.Value, short.Parse(this.cmbStatus.SelectedValue), 
                                              int.Parse(this.cmbType.SelectedValue), int.Parse(this.cmbInvalid.SelectedValue));

                lstResult = appSer.GetListByCond_Regist(LoginInfo.User.ID, this.txtUserCD.Value, this.txtUserName.Value, short.Parse(this.cmbStatus.SelectedValue), 
                                                 int.Parse(this.cmbType.SelectedValue), int.Parse(this.cmbInvalid.SelectedValue), 
                                                 pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
            }

            //Show data
            if (lstResult == null || lstResult.Count == 0)
            {
               // if (this.PagingFooter.CurrentPage > 1)
                if (pageIndex > 1)
                {
                    var curPage = (totalRow % numOnPage) == 0 ? (totalRow / numOnPage) : ((totalRow / numOnPage) + 1);
                    this.LoadDataGrid(curPage, numOnPage);
                }
                else
                {
                    this.rptResult.DataSource = null;
                }
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstResult[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstResult[lstResult.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Vacation No", "User", "Register", "Type", "Type Perform", "Perform Date", "Apply Date", "Reason", "" });

                // detail
                this.rptResult.DataSource = lstResult;
            }

            this.rptResult.DataBind();
        }

        #endregion Method

        #region Web Method
        /// <summary>
        /// Format User Code
        /// </summary>
        /// <param name="in1">User Code</param>
        /// <returns>User Name</returns>
        [System.Web.Services.WebMethod]
        public static string GetUserName(string in1)
        {
            var userCd = in1;
            var userCdShow = in1;
            userCd = DailyReport.Utilities.EditDataUtil.ToFixCodeDB(userCd, M_User.USER_NAME_1_MAX_LENGTH);
            userCdShow = EditDataUtil.ToFixCodeShow(userCd, M_User.MAX_USER_CODE_SHOW);

            try
            {
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    M_User model = userSer.GetByUserCD(userCd);
                    if (model != null && model.ID != Constant.DEFAULT_ID
                                     && model.StatusFlag == 0)
                    {
                        DepartmentService deptSer = new DepartmentService(db);
                        M_Department dept = deptSer.GetByID(model.DepartmentID);
                        string deptNm = dept != null ? dept.DepartmentName : string.Empty;

                        var result = new
                        {
                            userCD = userCdShow,
                            userNm = model.UserName1
                        };

                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                    }
                    var userCD = new
                    {
                        userCD = userCdShow
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(userCD);
                }
            }
            catch (Exception)
            {
                return null;
            }
        }
         

        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.ApprovedView
{
    /// <summary>
    /// UserSearch
    /// TRAM
    /// </summary>
    public partial class FrmVacationView : FrmBaseDetail
    {
        #region Constant

        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_APPLY_VACTION;
        public const int DEFAULT_VALUE = -1;
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        #region variable
        public bool isHasData;
        #endregion

        #region Property

        #endregion
        
        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

        }

        /// <summary>
        /// Load Page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (Request.QueryString["ApplyId"] != null)
                {
                    T_Work_Vacation data = this.GetApplyByID(int.Parse(Request.QueryString["ApplyId"].ToString()));

                    //Check user
                    if (data != null)
                    {
                        //Show data
                        this.ShowData(data);
                    }
                }
            }
        }

        #endregion
        
        #region Methods

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns></returns>
        private T_Work_Vacation GetApplyByID(int AppID)
        {
            using (DB db = new DB())
            {
                T_Work_Vacation apply = new T_Work_Vacation();
                WorkVacationService appSer = new WorkVacationService(db);
                apply = appSer.GetByID(AppID);
                return apply;
            }
        }

        /// <summary>
        /// DisableControl
        /// </summary>
        private void DisableControl()
        {
            this.txtEmployeeCD.SetReadOnly(true);
            this.chkIsAgent.Enabled = false;
            this.txtVactionDtFrm.SetReadOnly(true);
            this.txtVactionDtTo.SetReadOnly(true);
            this.cmbRoute.Enabled = false;
            this.txtReason.SetReadOnly(true);
            this.cmbTypeVacation.Enabled = false;
            this.txtUseDays.SetReadOnly(true);
            this.cmbRoute.Enabled = false;
            base.DisabledLink(this.btnSearchList, true);
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.DisableControl();
            this.txtVactionDtFrm.Value = DateTime.Now;
            this.txtVactionDtTo.Value = DateTime.Now;

            this.txtUseDays.Value = string.Empty;
            this.GetTimesHeader(this.LoginInfo.User.ID);

            this.InitDataDropdownType(this.cmbTypeVacation);            
        }

        /// <summary>
        /// InitTimesHeader
        /// </summary>
        private void GetTimesHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting acc = accSer.GetData();
                if (acc != null)
                {
                    lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
                }

            }
            this.rptTimesHeader.DataSource = lstMonth;
            this.rptTimesHeader.DataBind();

            this.GetTimesValue(lstMonth, userID);
        }

        /// <summary>
        /// Init Times Value
        /// </summary>
        private void GetTimesValue(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();
                foreach (var item in lstMonth)
                {
                    using (DB db = new DB())
                    {
                        AccountingService accSer = new AccountingService(db);
                        M_Accounting data = accSer.GetData();
                        if (data != null)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkVacationService vacSer = new WorkVacationService(db);
                            decimal usedDay = vacSer.GetUsedDaysInMonth(userID, period);
                            if (usedDay != 0m)
                            {
                                lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                            }
                            else
                            {
                                lstMonthVal.Add(new StringModel(string.Empty));
                            }
                        }
                    }
                }

                this.rptTimes.DataSource = lstMonthVal;
                this.rptTimes.DataBind();
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            this.InitDropdownRoute(ddl, list);
        }

        /// <summary>
        /// InitDataDropdownRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        private void InitDropdownRoute(DropDownList ddl, IList<M_Route_H> list)
        {
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
        }

        /// <summary>
        /// InitDataDropdownType
        /// </summary>
        /// <param name="ddl"></param>
        private void InitDataDropdownType(DropDownList ddl)
        {
            //using (DB db = new DB())
            //{
            //    WorkShiftService wrkSer = new WorkShiftService(db);
            //    ddl.DataSource = wrkSer.GetDataForDropDown((int)ShiftType.PaidVacation);
            //}
            //ddl.DataValueField = "Value";
            //ddl.DataTextField = "DisplayName";
            //ddl.DataBind();
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                ddl.DataSource = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="apply"></param>
        /// <param name="isConfirmed">true: Load List Approver from approve list, false: from route</param>
        /// <param name="isGetDaysVacID">is Get Days by VacID</param>
        private void ShowData(T_Work_Vacation apply)
        {
            //Show data
            if (apply != null)
            {
                //Re-Init value for combobox Route
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, apply.UserID);

                M_UserInfo user = new M_UserInfo();
                M_User createUser = new M_User();
                M_User updateUser = new M_User();
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    user = userSer.GetUserInfoByID(apply.UserID);
                    createUser = userSer.GetByID(apply.CreateUID);
                    updateUser = userSer.GetByID(apply.UpdateUID);
                }
                
                this.txtApplyNo.Value = apply.No;
                this.dtApplyDate.Value = apply.ApplyDate;

                if (apply.UserID.Equals(apply.CreateUID) || apply.UserID.Equals(this.LoginInfo.User.ID))
                {
                    this.chkIsAgent.Checked = false;
                }
                else
                {
                    this.chkIsAgent.Checked = true;
                }

                //Get Type Of Apply(Loai nghi phep)
               /* M_Work_Shift wrkShift = this.GetShiftByID(apply.VacationType);
                if (wrkShift != null)
                {
                    this.hdnType.Value = wrkShift.TypeOfDay.ToString();
                }
                */
                this.hdnType.Value = apply.VacationType.ToString();
                if (user != null)
                {
                    using (DB db = new DB())
                    {
                        StaffService staffSer = new StaffService(db);
                        M_Staff s = staffSer.GetByID(user.StaffID);
                        if (s != null)
                        {
                            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                            this.txtEmployeeNm.Value = s.StaffName;

                            this.txtPosition.Value = (new Config_DService(db)).GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                        }
                    }
                    this.txtDepartment.Value = user.DepartmentName;
                    this.ResetValueForHeaderDays(DEFAULT_VALUE, user.ID);
                    this.GetTimesHeader(user.ID);
                }

                this.cmbRoute.SelectedValue = apply.RouteID.ToString();
                this.txtUseDays.Value = apply.Duration.HasValue ? apply.Duration.Value.ToString("N1") : string.Empty;
                this.txtVactionDtFrm.Value = apply.StartDate;
                this.txtVactionDtTo.Value = apply.EndDate;
                this.cmbTypeVacation.SelectedValue = apply.VacationType.ToString();

                this.txtReason.Value = apply.Reason;
               
                if (createUser != null)
                {
                    var createDate = (apply.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }

                if (updateUser != null)
                {
                    var updateDate = (apply.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                this.LoadDataForApproveListFromApproveList(apply.No, true);
                this.DisableControl();
            }
        }

        /// <summary>
        /// GetShiftByID
        /// </summary>
        /// <param name="shiftID"></param>
        /// <returns></returns>
        private M_Work_Shift GetShiftByID(int shiftID)
        {
            using (DB db = new DB())
            {
                WorkShiftService wShiftSer = new WorkShiftService(db);
                return wShiftSer.GetByID(shiftID);
            }
        }

        /// <summary>
        /// ResetValueForHeaderDays
        /// </summary>
        /// <param name="dataID"></param>
        /// <param name="userID"></param>
        private void ResetValueForHeaderDays(int dataID, int userID)
        {
            decimal curRemainDay = 0;
            decimal usedDay = 0;
            decimal planDay = 0;
            using (DB db = new DB())
            {
                WorkVacationService applySer = new WorkVacationService(db);
                curRemainDay = applySer.GetRemainDays(dataID, userID);
                usedDay = applySer.GetUsedDays(userID, DateTime.MinValue, DateTime.MinValue);
                planDay = applySer.GetPlanDays(dataID, userID);
            }
            decimal totalDay = planDay + usedDay + curRemainDay;
            this.lblTotalDays.InnerText = totalDay.ToString("N1");
            this.lblUsedDays.InnerText = usedDay.ToString("N1");
            this.lblPlanDays.InnerText = planDay.ToString("N1");
            decimal expDays = totalDay - 12;
            this.lblExpriedDays.InnerText = (expDays < 0 ? 0 : expDays).ToString("N1");
            this.lblRemainDays.InnerText = curRemainDay.ToString("N1");
        }

        /// <summary>
        /// LoadDataForApproveListFromApproveList
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        private void LoadDataForApproveListFromApproveList(string vacNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);

            if (applyList != null && applyList.Count != 0)
            {
                this.isHasData = true;
                this.rptApproverList.DataSource = applyList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();

        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(vacNo, isIncludeView, includeZeroLV);
            }
        }

        #endregion
    }
 }
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.ApprovedView
{
    public partial class FrmOverTimeView : FrmBaseDetail
    {
        #region Constant

        public const int OT_TEMPLATE = M_Config_D.TEMPLATE_FORM_APPLY_OT;
        public const int DEFAULT_VALUE = -1;
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        #endregion

        #region variable
        public bool isHasData;
        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (Request.QueryString["ApplyId"] != null)
                {
                    T_Work_OT data = this.GetApplyByID(int.Parse(Request.QueryString["ApplyId"].ToString()));

                    //Check user
                    if (data != null)
                    {
                        //Show data
                        this.ShowData(data, false);
                    }
                }
            }
        }

        #endregion

        #region Method

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(bool withBlank = false)
        {
            using (DB db = new DB())
            {
                WorkShiftService otSer = new WorkShiftService(db);
                return otSer.GetDataForDropDown((int)ShiftType.Attendance, withBlank);
            }
        }

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns></returns>
        private T_Work_OT GetApplyByID(int AppID)
        {
            using (DB db = new DB())
            {
                T_Work_OT apply = new T_Work_OT();
                WorkOTService appSer = new WorkOTService(db);
                apply = appSer.GetByID(AppID);
                return apply;
            }
        }

        private void DisableControl()
        {
            this.txtEmployeeCD.SetReadOnly(true);
            this.chkIsAgent.Enabled = false;
            this.dtEffectDate.SetReadOnly(true);
            this.txtReason.SetReadOnly(true);
            this.ddlApprovalRoute.Enabled = false;
            this.dtStartTime.Enabled = false;
            this.dtEndTime.Enabled = false;
            this.dtApplyDate.Enabled = false;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.InitDataForRoute(this.ddlApprovalRoute, OT_TEMPLATE, this.LoginInfo.User.ID);
            this.DisableControl();
            this.dtEffectDate.Value = DateTime.Now;
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            this.InitDropdownRoute(ddl, list);
        }

        /// <summary>
        /// InitDataDropdownRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        private void InitDropdownRoute(DropDownList ddl, IList<M_Route_H> list)
        {
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
        }

        /// <summary>
        /// LoadDataForApproveListFromApproveList
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        private void LoadDataForApproveListFromApproveList(string vacNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);

            if (applyList != null && applyList.Count != 0)
            {
                this.isHasData = true;
                this.rptApproverList.DataSource = applyList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();

        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(vacNo, isIncludeView, includeZeroLV);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Work_OT w, bool isGetDaysVacID = false)
        {
            using (DB db = new DB())
            {
                //Show data
                if (w != null)
                {
                    M_UserInfo user = new M_UserInfo();
                    UserService userSer = new UserService(db);
                    WorkOTService wOT = new WorkOTService(db);
                    M_Work_Shift ws = new M_Work_Shift();

                    //Re-Init value for combobox Route
                    this.InitDataForRoute(this.ddlApprovalRoute, OT_TEMPLATE, w.UserID);
                    ws = wOT.GetWorkingShiftByDate(w.EffectDate);

                    int vactionID = DEFAULT_VALUE;
                    if (isGetDaysVacID)
                    {
                        vactionID = w.ID;
                    }

                    this.txtApplyNo.Value = w.No;
                    this.dtApplyDate.Value = w.ApplyDate;

                    if (w.UserID.Equals(w.CreateUID) || w.UserID.Equals(this.LoginInfo.User.ID))
                    {
                        this.chkIsAgent.Checked = false;
                    }
                    else
                    {
                        this.chkIsAgent.Checked = true;
                    }

                    user = userSer.GetUserInfoByID(w.UserID);
                    if (user != null)
                    {
                        StaffService staffSer = new StaffService(db);
                        M_Staff s = staffSer.GetByID(user.StaffID);
                        if (s != null)
                        {
                            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                            this.txtEmployeeNm.Value = s.StaffName;

                            this.txtPosition.Value = (new Config_DService(db)).GetValue2(M_Config_H.CONFIG_CD_POSITION, s.Position);
                        }

                        this.txtDepartment.Value = user.DepartmentName;
                    }

                    this.txtApplyNo.Value = w.No;
                    this.dtApplyDate.Value = w.ApplyDate;
                    this.dtEffectDate.Value = w.EffectDate;
                    this.dtStartTime.SetTimeValue(w.OTStartHour, w.OTStartMinute);
                    this.dtEndTime.SetTimeValue(w.OTEndHour, w.OTEndMinute);
                    this.lbEarly.Text = EditDataUtil.FixTimeShow(w.EarlyHour, w.EarlyMinute, true);
                    this.lbNormal.Text = EditDataUtil.FixTimeShow(w.Normal1Hour, w.Normal1Minute, true);
                    this.lbNormal2.Text = EditDataUtil.FixTimeShow(w.Normal2Hour, w.Normal2Minute, true);
                    this.lbLateNight.Text = EditDataUtil.FixTimeShow(w.LateHour, w.LateMinute, true);
                    this.lbHoliday1.Text = EditDataUtil.FixTimeShow(w.Holiday1Hour, w.Holiday1Minute, true);
                    this.lbHoliday2.Text = EditDataUtil.FixTimeShow(w.Holiday2Hour, w.Holiday2Minute, true);
                    this.txtReason.Value = w.Reason;
                    this.SetDataForShift(ws, true);
                    this.GetTotalOverTime();

                    M_User createUser = userSer.GetByID(w.CreateUID);
                    if (createUser != null)
                    {
                        var createDate = (w.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : w.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                    }

                    M_User updateUser = userSer.GetByID(w.UpdateUID);
                    if (updateUser != null)
                    {
                        var updateDate = (w.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : w.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                    }
                    this.LoadDataForApproveListFromApproveList(w.No, true);
                    this.DisableControl();
                }
            }
        }

        private void GetTotalOverTime()
        {
            using (DB db = new DB())
            {
                if (this.txtEmployeeCD.IsEmpty)
                {
                    return;
                }

                WorkOTService wSer = new WorkOTService(db);
                AccountingService accSer = new AccountingService(db);
                M_Accounting acc = new M_Accounting();
                WorkTotalOTInfo thismonth = new WorkTotalOTInfo();
                WorkTotalOTInfo lastmonth = new WorkTotalOTInfo();
                StaffService staffSer = new StaffService(db);
                M_Staff staff = staffSer.GetByStaffCD(this.txtEmployeeCD.Value);
                UserService userSer = new UserService(db);
                M_User user = userSer.GetByStaffID(staff.ID);

                AccountingPeriod periodC = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value);
                thismonth = wSer.GetTotalOverTime(periodC.StartDate, periodC.EndDate, user.ID);

                AccountingPeriod period = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value.AddMonths(-1));
                lastmonth = wSer.GetTotalOverTime(period.StartDate, period.EndDate, user.ID);                

                this.SetTime(lastmonth, thismonth);
            }
        }

        private void SetTime(WorkTotalOTInfo lastmonth, WorkTotalOTInfo thismonth)
        {
            this.lbLastEarly.Text = EditDataUtil.FixTimeShow(lastmonth.EarlyHour, lastmonth.EarlyMinute, true);
            this.lbLastNormal.Text = EditDataUtil.FixTimeShow(lastmonth.Normal1Hour, lastmonth.Normal1Minute, true);
            this.lbLastNormal2.Text = EditDataUtil.FixTimeShow(lastmonth.Normal2Hour, lastmonth.Normal2Minute, true);
            this.lbLastLate.Text = EditDataUtil.FixTimeShow(lastmonth.LateHour, lastmonth.LateMinute, true);
            this.lbLastHoliday1.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday1Hour, lastmonth.Holiday1Minute, true);
            this.lbLastHoliday2.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday2Hour, lastmonth.Holiday2Minute, true);
            this.lbLastTotal.Text = EditDataUtil.FixTimeShow(lastmonth.TotalOTHour, lastmonth.TotalOTMinute, true);

            this.lbThisEarly.Text = EditDataUtil.FixTimeShow(thismonth.EarlyHour, thismonth.EarlyMinute, true);
            this.lbThisNormal.Text = EditDataUtil.FixTimeShow(thismonth.Normal1Hour, thismonth.Normal1Minute, true);
            this.lbThisNormal2.Text = EditDataUtil.FixTimeShow(thismonth.Normal2Hour, thismonth.Normal2Minute, true);
            this.lbThisLate.Text = EditDataUtil.FixTimeShow(thismonth.LateHour, thismonth.LateMinute, true);
            this.lbThisHoliday1.Text = EditDataUtil.FixTimeShow(thismonth.Holiday1Hour, thismonth.Holiday1Minute, true);
            this.lbThisHoliday2.Text = EditDataUtil.FixTimeShow(thismonth.Holiday2Hour, thismonth.Holiday2Minute, true);
            this.lbThisTotal.Text = EditDataUtil.FixTimeShow(thismonth.TotalOTHour, thismonth.TotalOTMinute, true);
        }

        private void SetDataForShift(M_Work_Shift ws, bool isEmpty = false)
        {
            if (!isEmpty)
            {
                this.lbShiftName.Text = string.Empty;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = "-1";
                this.hdShiftName.Value = string.Empty;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;
            }
            else
            {
                this.lbShiftName.Text = ws.ShiftName;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = ws.ID.ToString();
                this.hdShiftName.Value = ws.ShiftName;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;

                if (ws.StartHour != null)
                {
                    this.lbStartTime.Text = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.lbEndTime.Text = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                    this.hdStartTime.Value = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.hdEndTime.Value = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                }
            }
        }

        #endregion
    }
}
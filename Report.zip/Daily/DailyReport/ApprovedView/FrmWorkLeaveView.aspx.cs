﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.ApprovedView
{
    public partial class FrmWorkLeaveView : FrmBaseDetail
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                var applyID = Request.QueryString["ApplyId"];
                if (applyID != null)
                {
                    T_Work_Leave data = this.GetApplyByID(int.Parse(applyID));

                    //Check user
                    if (data != null)
                    {
                        //Show data
                        this.ShowData(data);
                    }
                }

                this.LoadRoute(this.txtEmployeeCD.Text);
                this.InitTimesDetail();
            }
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.txtEmployeeCD.SetReadOnly(true);
            this.dtEffect.SetReadOnly(true);
            this.optLate.Disabled = true;
            this.optEarly.Disabled = true;
            this.optOut.Disabled = true;
            this.dtDateFrom.SetReadOnly(true);
            this.dtDateTo.SetReadOnly(true);
            this.txtReason.SetReadOnly(true);
            this.cmbRoute.Enabled = false;
            this.dtDuration.SetReadOnly(true);

            this.InitTimesHeader();
        }

        /// <summary>
        /// set data for header repeater
        /// </summary>
        private void InitTimesHeader()
        {
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                this.rptLateH.DataSource = accSer.GetListMonthName();
                this.rptLateH.DataBind();
                //--------------
                this.rptEarlyH.DataSource = accSer.GetListMonthName();
                this.rptEarlyH.DataBind();
                //--------------
                this.rptOutH.DataSource = accSer.GetListMonthName();
                this.rptOutH.DataBind();
            }
        }

        /// <summary>
        /// set data for detail repeater
        /// </summary>
        private void InitTimesDetail()
        {
            using (DB db = new DB())
            {
                //DateTime dateNow = DateTime.Now.Date;
                AccountingService accSer = new AccountingService(db);

                AccountingPeriod _acc = accSer.GetAccountingYear(DateTime.Now.Date);

                WorkLeaveService leaveSr = new WorkLeaveService(db);
                IList<WorkLeaveDay> lst = leaveSr.GetListMonthAccounting(this.txtEmployeeCD.Value, _acc.StartDate, _acc.EndDate);

                this.rptLateD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Late, lst, _acc);
                this.rptLateD.DataBind();
                //--------------
                this.rptEarlyD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Early, lst, _acc);
                this.rptEarlyD.DataBind();
                //--------------
                this.rptOutD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Out, lst, _acc);
                this.rptOutD.DataBind();
            }
        }

        /// <summary>
        /// s
        /// </summary>
        /// <param name="type"></param>
        /// <param name="lstDay"></param>
        /// <param name="period"></param>
        /// <returns></returns>
        private List<string> GetListMonthValue(int type, IList<WorkLeaveDay> lstDay, AccountingPeriod period)
        {
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting m_acc = accSer.GetData();


                List<string> lstTmp = new List<string>();
                DateTime dtTmp = lstDay[0].WorkDate;
                TimeSpan timeTmp = TimeSpan.Zero;

                for (int i = 0; i < 12; i++)
                {
                    AccountingPeriod periodM = accSer.GetAccountingMonth(period.StartDate.AddMonths(i), m_acc.ClosingDay);
                    foreach (var item in lstDay.Where(m => m.WorkDate >= periodM.StartDate && m.WorkDate <= periodM.EndDate && m.Type == type))
                    {
                        timeTmp = timeTmp.Add(item.Duration);
                    }

                    if (timeTmp != TimeSpan.Zero)
                    {
                        lstTmp.Add(EditDataUtil.FixTimeShow(timeTmp.Hours, timeTmp.Minutes));
                    }
                    else
                    {
                        lstTmp.Add("&nbsp;");
                    }

                    timeTmp = TimeSpan.Zero;
                }

                return lstTmp;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Work_Leave GetApplyByID(int id)
        {
            using (DB db = new DB())
            {
                WorkLeaveService appSer = new WorkLeaveService(db);
                return appSer.GetByID(id);
            }
        }

        private void ShowData(T_Work_Leave apply)
        {
            //Show data
            if (apply != null)
            {
                using (DB db = new DB())
                {
                    //------------------------------
                    this.txtApplyNo.Value = apply.No;
                    //------------------------------
                    this.dtApplyDate.Value = apply.ApplyDate;
                    //------------------------------
                    this.dtEffect.Value = apply.EffectDate;
                    //------------------------------
                    StaffService _staffService = new StaffService(db);
                    M_StaffInfo m_staff = _staffService.GetStaffInfoByUserID(apply.UserID);
                    if (m_staff != null)
                    {
                        this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(m_staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                        this.txtEmployeeNm.Value = m_staff.StaffName;

                        this.txtDepartment.Value = m_staff.DepartmentName;
                        this.txtPosition.Value = m_staff.Position;
                    }

                    //------------------------------              
                    this.dtDateFrom.SetTimeValue(apply.StartHour, apply.StartMinute);
                    this.dtDateTo.SetTimeValue(apply.EndHour, apply.EndMinute);
                    //------------------------------
                    if (apply.Type == (int)TypeWorkLeave.Late)
                    {
                        this.optLate.Checked = true;
                    }
                    //-------------------
                    if (apply.Type == (int)TypeWorkLeave.Early)
                    {
                        this.optEarly.Checked = true;
                    }
                    //-------------------
                    if (apply.Type == (int)TypeWorkLeave.Out)
                    {
                        this.optOut.Checked = true;
                    }
                    //------------------------------
                    this.dtDuration.Text = EditDataUtil.FixTimeShow(apply.DurationHour, apply.DurationMinute, true);
                    //------------------------------
                    WorkLeaveService ser = new WorkLeaveService(db);
                    this.txtReason.Value = apply.Reason;
                    //------------------------------
                    this.cmbRoute.SelectedValue = apply.RouteID.ToString();
                    //------------------------------
                    UserService userSer = new UserService(db);
                    M_User createUser = userSer.GetByID(apply.CreateUID);
                    M_User updateUser = userSer.GetByID(apply.UpdateUID);
                    if (createUser != null)
                    {
                        var createDate = apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        var updateDate = apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                        this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                    }

                    //------------------------------    
                    this.LoadRouteFromApprove(this.txtApplyNo.Value, true);
                }

            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void LoadRoute(int userID)
        {
            using (DB db = new DB())
            {
                Route_HService routeService = new Route_HService(db);
                this.cmbRoute.DataSource = routeService.GetDataForDropdown(M_Config_D.TEMPLATE_FORM_LEAVE, userID);
                this.cmbRoute.DataValueField = "Value";
                this.cmbRoute.DataTextField = "DisplayName";
                this.cmbRoute.DataBind();

                this.cmbRoute.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        private void LoadRoute(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService _StaffService = new StaffService(db);
                M_StaffInfo _staff = _StaffService.GetStaffInfoByStaffCD(staffCD);
                if (_staff != null)
                {
                    this.LoadRoute(_staff.UserID);
                }
            }
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadRouteFromApprove(string vacNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> applyList = new List<WorkApproveModel>();
            applyList = this.GetListApproveUserFromApply(vacNo, isIncludeView);
            if (!isIncludeView)
            {
                this.rptApproverList.DataSource = applyList;
                this.rptApproverList.DataBind();
            }
            else
            {
                this.rptApproverList.DataSource = applyList;
                this.rptApproverList.DataBind();
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string vacNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.txtApplyNo.Value, isIncludeView, includeZeroLV);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.DAC;
using DailyReport.Utilities;

namespace DailyReport.ApprovedView
{
    /// <summary>
    /// FrmAbsenceView Form
    /// TRAM
    /// </summary>
    public partial class FrmAbsenceView : FrmBaseDetail
    {

        #region Constant

        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_ABSENCE;
        public const int DEFAULT_VALUE = -1;
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);

        #endregion

        #region Variable

        public bool isHasData;

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

        }

        /// <summary>
        /// Load Page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (Request.QueryString["ApplyId"] != null)
                {
                    T_Work_Absence data = this.GetAbsenceByID(int.Parse(Request.QueryString["ApplyId"].ToString()));

                    //Check user
                    if (data != null)
                    {
                        //Show data
                        this.ShowData(data);
                    }
                }
            }
        }

        #endregion


        #region Methods

        /// <summary>
        /// GetApplyByID
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns></returns>
        private T_Work_Absence GetAbsenceByID(int absID)
        {
            T_Work_Absence abs = new T_Work_Absence();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                abs = absenceSer.GetByID(absID);
                return abs;
            }
        }

        /// <summary>
        /// Disable controls
        /// </summary>
        private void DisableControl()
        {
            this.txtEmployeeCD.SetReadOnly(true);
            this.chkIsAgent.Enabled = false;
            this.datAbsenceDtFrm.SetReadOnly(true);
            this.datAbsenceDtTo.SetReadOnly(true);
            this.cmbRoute.Enabled = false;
            this.txtReason.SetReadOnly(true);
            this.cmbDayOffType.Enabled = false;
            this.txtTotalDays.SetReadOnly(true);
            this.cmbRoute.Enabled = false;
            this.btnSearchEmployee.Disabled = true;
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.DisableControl();
            this.datAbsenceDtFrm.Value = DateTime.Now;
            this.datAbsenceDtTo.Value = DateTime.Now;
            this.txtTotalDays.Value = string.Empty;
            this.GetRestTimeTableHeader(this.LoginInfo.User.ID);
            this.InitDataDropdownType(this.cmbDayOffType);            
        }

        /// <summary>
        /// GetRestTimeTableHeader
        /// </summary>
        private void GetRestTimeTableHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting acc = accSer.GetData();
                if (acc != null)
                {
                    lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
                }
            }
            this.rptRestTimeHeader.DataSource = lstMonth;
            this.rptRestTimeHeader.DataBind();

            this.GetRestTimeTableContent(lstMonth, userID);
        }

        /// <summary>
        /// Get Rest Time Table Content
        /// </summary>
        private void GetRestTimeTableContent(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();
                foreach (var item in lstMonth)
                {
                    using (DB db = new DB())
                    {
                        AccountingService accSer = new AccountingService(db);
                        M_Accounting data = accSer.GetData();
                        if (data != null)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkAbsenceService absSer = new WorkAbsenceService(db);
                            decimal usedDay = absSer.GetUsedDaysInMonth(userID, period);
                            if (usedDay != 0m)
                            {
                                lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                            }
                            else
                            {
                                lstMonthVal.Add(new StringModel(string.Empty));
                            }
                        }
                    }
                }

                this.rpttRestTimeContent.DataSource = lstMonthVal;
                this.rpttRestTimeContent.DataBind();
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            this.InitDropdownRoute(ddl, list);
        }

        /// <summary>
        /// InitDataDropdownRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="list"></param>
        private void InitDropdownRoute(DropDownList ddl, IList<M_Route_H> list)
        {
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init data for DayOffType dropdown
        /// </summary>
        /// <param name="ddl"></param>
        private void InitDataDropdownType(DropDownList ddl)
        {
            //using (DB db = new DB())
            //{
            //    WorkShiftService wrkSer = new WorkShiftService(db);
            //    ddl.DataSource = wrkSer.GetDataForDropDown((int)ShiftType.PaidVacation);
            //}
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                ddl.DataSource = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

       /// <summary>
        /// Show data
       /// </summary>
        /// <param name="abs">T_Work_Absence</param>
        private void ShowData(T_Work_Absence abs)
        {
            //Show data
            if (abs != null)
            {
                //Re-Init value for combobox Route
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, abs.UserID);

                this.txtApplyNo.Value = abs.No;
                this.dtApplyDate.Value = abs.ApplyDate;

                if (abs.UserID.Equals(abs.CreateUID) || abs.UserID.Equals(this.LoginInfo.User.ID))
                {
                    this.chkIsAgent.Checked = false;
                }
                else
                {
                    this.chkIsAgent.Checked = true;
                }

                //Get Type Of Apply(Loai nghi phep)
                //M_Work_Shift wrkShift = this.GetShiftByID(abs.AbsenceType);
                //if (wrkShift != null)
                //{
                //    this.hdnType.Value = wrkShift.TypeOfDay.ToString();
                //}
                this.hdnType.Value = abs.AbsenceType.ToString();
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                M_StaffInfo staff = new M_StaffInfo();
                M_User createUser = new M_User();
                M_User updateUser = new M_User();

                using (DB db = new DB())
                {
                    StaffService staffSer=new StaffService(db);
                    staff = staffSer.GetStaffInfoByUserID(abs.UserID);

                    UserService userSer = new UserService(db);
                    createUser = userSer.GetByID(abs.CreateUID);
                    updateUser = userSer.GetByID(abs.UpdateUID);
                }

                if (staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = staff.StaffName;
                    this.txtPosition.Value = staff.Position;
                    this.txtDepartment.Value = staff.DepartmentName;

                    this.GetRestTimeTableHeader(staff.UserID);
                }
                
                this.cmbRoute.SelectedValue = abs.RouteID.ToString();
                this.txtTotalDays.Value = abs.Duration.HasValue ? abs.Duration.Value.ToString("N1") : string.Empty;
                this.datAbsenceDtFrm.Value = abs.StartDate;
                this.datAbsenceDtTo.Value = abs.EndDate;
                this.cmbDayOffType.SelectedValue = abs.AbsenceType.ToString();

                this.txtReason.Value = abs.Reason;
                
                if (createUser != null)
                {
                    var createDate = (abs.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }

                if (updateUser != null)
                {
                    var updateDate = (abs.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }

                this.LoadDataForApproveListFromApproveList(abs.No, true);
                this.DisableControl();
            }
        }

        /// <summary>
        /// GetShiftByID
        /// </summary>
        /// <param name="shiftID"></param>
        /// <returns></returns>
        private M_Work_Shift GetShiftByID(int shiftID)
        {
            using (DB db = new DB())
            {
                WorkShiftService wShiftSer = new WorkShiftService(db);
                return wShiftSer.GetByID(shiftID);
            }
        }

        /// <summary>
        /// LoadDataForApproveListFromApproveList
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        private void LoadDataForApproveListFromApproveList(string absNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = this.GetListApproveUserFromApply(absNo, isIncludeView);

            if (approveList != null && approveList.Count != 0)
            {
                this.isHasData = true;
                this.rptApproverList.DataSource = approveList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();

        }

        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <param name="vacNo"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(string absNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(absNo, isIncludeView, includeZeroLV);
            }
        }

        #endregion
    }
 }
﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
//using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.Approve
{
    /// <summary>
    /// TRAM - 2015/06/18
    /// FrmAbsenceApproveDetail form
    /// </summary>
    public partial class FrmAbsenceApproveDetail : FrmBaseDetail
    {
        #region Enum

        /// <summary>
        /// TypeOfButton
        /// </summary>
        enum TypeOfButton
        {
            Approve = 0,
            Ignore = 1,
            PrevLevelBack = 2,
            View = 3
        }

        #endregion

        #region Constants

        private const string URL_LIST = "~/Approve/FrmApproveList.aspx";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_ABSENCE;
        public const int DEFAULT_VALUE = -1;

        #endregion

        #region Variable

        /// <summary>
        /// isApproveUser
        /// </summary>
        public bool isApproveUser;

        /// <summary>
        /// isApproved
        /// </summary>
        public bool isApproved;

        /// <summary>
        /// isDisablePrevBack
        /// </summary>
        public bool isDisablePrevBack;

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData;

        /// <summary>
        /// 2015/06/16
        /// </summary>
        public bool isVisibleApproveButton;
        public bool isVisibleViewButton;
        public bool isVisibleIgnoreButton;
        public bool isVisiblePrevBackButton;
        #endregion

        #region Property

        /// <summary>
        /// Type Apply Form Current
        /// </summary>
        public int CurrenType
        {
            get { return (int)ViewState["CurrenType"]; }
            set { ViewState["CurrenType"] = value; }
        }

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }
        
        /// <summary>
        /// Get or set ApplyUserID
        /// </summary>
        public int ApplyUserID
        {
            get { return (int)ViewState["ApplyUserID"]; }
            set { ViewState["ApplyUserID"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }
        
        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }
        
        /// <summary>
        /// Is Inspected : đã xem xét (approve, remaind)
        /// </summary>
        public bool IsInspected
        {
            get { return (bool)ViewState["IsInspected"]; }
            set { ViewState["IsInspected"] = value; }
        }

        /// <summary>
        /// Get or set AbsenceType
        /// </summary>
        public int AbsenceType
        {
            get { return (int)ViewState["AbsenceType"]; }
            set { ViewState["AbsenceType"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Absence";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtApproveReason.MaxLength = T_Work_Approve.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// Load page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    //Get T_Work_Absence
                    this.DataID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                    T_Work_Absence data = this.GetAbsenceByID(this.DataID);

                    //Check user
                    if (data != null)
                    {
                        //Show data
                        this.ShowData(data);

                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    else
                    {
                        base.RedirectUrl(URL_LIST);
                    }
                }
                else
                {
                    base.RedirectUrl(URL_LIST);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// btnView Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {
            T_Work_Absence abs = this.GetAbsenceByID(this.DataID);
            if (abs != null)
            {
                //View Data
                if (this.ViewData())
                {
                    Server.Transfer(URL_LIST);
                }
                else
                {
                    this.LoadDataForChangedData();
                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get Absence data
            T_Work_Absence data = this.GetAbsenceByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Work_Absence apply = this.GetAbsenceByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Ignore
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Ignore;
            T_Work_Absence apply = this.GetAbsenceByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Ignore);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Work_Absence apply = this.GetAbsenceByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.BackPre);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Submit Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //T_Work_Absence abs = this.GetAbsenceByID(this.DataID);
            //if (abs != null)
            //{
            //    if (this.OldUpdateDate != abs.UpdateDate)
            //    {
            //        this.LoadDataForChangedData();
            //    }
            //    else
            //    {
            //        this.SetRestTimeTableHeader(this.ApplyUserID);
            //        this.LoadDataForApproverList(this.DataNo, true);
            //    }
            //}

            //if (this.Mode == Mode.Approve)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.Yes);
            //}
            //else if (this.Mode == Mode.Ignore)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No);
            //}
            //else if (this.Mode == Mode.BackPre)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.No);
            //}

            this.btnProcessData(sender, e);
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Approve:
                    //Update Data

                    if (this.Approve())
                    {
                        this.ShowData(this.GetAbsenceByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    break;

                case Utilities.Mode.Ignore:
                    //Update Data
                    if (this.Reject((short)StatusApply.Rejected))
                    {
                        this.ShowData(this.GetAbsenceByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                  
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    if (this.Remand((short)StatusApply.Approving))
                    {

                        this.ShowData(this.GetAbsenceByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    break;
            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Absence data = this.GetAbsenceByID(this.DataID);
            if (this.Mode == Utilities.Mode.View)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                this.LoadDataForApproverList(this.DataNo, true);
            }

        }

        #endregion

        #region Method

        #region Init data

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.hdnFormIDDefault.Value = LEAVE_TEMPLATE.ToString();
            this.IsInspected = false;
            this.SetDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.SetRestTimeTableHeader(this.LoginInfo.User.ID);
            this.SetDataForDayOffTypeCbo((int)ShiftType.PaidVacation);
            this.btnViewPreAbsence.Text = string.Empty;
        }

        #endregion

        #region Show data
        
        /// <summary>
        /// Show data
        /// </summary>
        /// <param name="absence">T_Work_Absence</param>
        private void ShowData(T_Work_Absence abs)
        {
            //Show data
            if (abs != null)
            {
                //Set value for Route combobox 
                this.SetDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, abs.UserID);

                this.txtApplyNo.Value = abs.No;
                this.dtApplyDate.Value = abs.ApplyDate;
                this.cmbRoute.SelectedValue = abs.RouteID.ToString();
                this.cmbDayOffType.SelectedValue = abs.AbsenceType.ToString();
                this.hdnPreApplyID.Value = abs.PreApplyID.ToString();

                T_Work_Approve approve = new T_Work_Approve();
                M_StaffInfo staff = new M_StaffInfo();
                T_Work_Absence preApp = new T_Work_Absence();
                M_User createUser = new M_User();
                M_User updateUser = new M_User();
                //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                using (DB db = new DB())
                {
                    WorkApproveService appSer = new WorkApproveService(db);
                    approve = appSer.GetByKey(abs.No, this.LoginInfo.User.ID);

                    StaffService staffSer = new StaffService(db);
                    staff = staffSer.GetStaffInfoByUserID(abs.UserID);

                    UserService userSer = new UserService(db);
                    createUser = userSer.GetByID(abs.CreateUID);
                    updateUser = userSer.GetByID(abs.UpdateUID);
                }

                if (approve != null)
                {
                    this.IsInspected = approve.ApproveStatus != (int)StatusHasAprove.New;
                }

                if (staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = staff.StaffName;
                    this.txtPosition.Value =  staff.Position;
                    this.hdnDepartmentID.Value = staff.DepartmentID.ToString();
                    this.txtDepartment.Value = staff.DepartmentName;
                    this.SetRestTimeTableHeader(abs.UserID);
                    this.ApplyUserID = abs.UserID;
                }

                this.txtApproveReason.Value = string.Empty;
                this.txtTotalDays.Value = abs.Duration.Value.ToString("N1");
                this.DataNo = abs.No;
                this.DataID = abs.ID;
                this.datAbsenceDtFrm.Value = abs.StartDate;
                this.datAbsenceDtTo.Value = abs.EndDate;
                this.ApplyStatus = abs.ApplyStatus;
                this.PreApplyID = abs.PreApplyID;
                
                if (this.PreApplyID.HasValue)
                {
                    using (DB db = new DB())
                    {
                        WorkAbsenceService ser = new WorkAbsenceService(db);
                        preApp = ser.GetByID(this.PreApplyID.Value);

                        if (preApp != null)
                        {
                            this.btnViewPreAbsence.Text = preApp.No;
                            this.txtReason.Value = preApp.Reason;
                            this.txtReasonCancel.Value = abs.Reason;
                        }
                    }
                }
                else
                {
                    this.txtReason.Value = abs.Reason;
                }

                //Set creation and updating info
                
                if (createUser != null)
                {
                    var createDate = (abs.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }

                if (updateUser != null)
                {
                    var updateDate = (abs.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : abs.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }
                
                this.OldUpdateDate = abs.UpdateDate;
                this.LoadDataForApproverList(abs.No, true);
                
                T_Work_Approve workApp = this.GetDataApproveByApplyNoAndUserID(this.DataNo, this.LoginInfo.User.ID);
                this.isVisibleApproveButton = this.IsVisibleButton(workApp, (int)TypeOfButton.Approve);
                this.isVisibleIgnoreButton = this.IsVisibleButton(workApp, (int)TypeOfButton.Ignore);
                this.isVisiblePrevBackButton = this.IsVisibleButton(workApp, (int)TypeOfButton.PrevLevelBack);
                this.isVisibleViewButton = this.IsVisibleButton(workApp, (int)TypeOfButton.View);
                
            }
        }

        #endregion

        #region Check data

        /// <summary>
        /// Check to visible buttons
        /// </summary>
        /// <param name="app"></param>
        /// <param name="typeOfButton"></param>
        /// <returns></returns>
        private bool IsVisibleButton(T_Work_Approve approve, int typeOfButton)
        {
            if (typeOfButton == (int)TypeOfButton.View)
            {
                approve = this.GetDataApproveByApplyNoAndRouteID(this.DataNo, this.LoginInfo.User.ID);

                if (approve != null)
                {
                    if (approve.RouteLevel != 99)
                    {
                        return false;
                    }

                    if (this.ApplyStatus == (short)StatusApply.Approved && approve.GetReadSetting(ReadSetting.ReadAuthor))
                    {
                        return true;
                    }
                }
            }
            else
            {
                if (approve != null)
                {
                    //Only allow to view data
                    if (approve.RouteLevel == 99)
                    {
                        return false;
                    }

                    if (typeOfButton == (int)TypeOfButton.Approve || typeOfButton == (int)TypeOfButton.Ignore || typeOfButton == (int)TypeOfButton.PrevLevelBack)
                    {
                        if (this.ApplyStatus == (short)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Cancel)
                        {
                            return false;
                        }
                    }

                    switch (typeOfButton)
                    {
                        //Approve
                        case (int)TypeOfButton.Approve:
                            return true;

                        //Ignore
                        case (int)TypeOfButton.Ignore:
                            if (approve.GetRejectSetting(RejectSetting.RejectAuthor))
                            {
                                return true;
                            }
                            break;

                        //PrevLevelBack
                        case (int)TypeOfButton.PrevLevelBack:
                            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
                            using (DB db = new DB())
                            {
                                WorkApproveService approveSer = new WorkApproveService(db);
                                if (approve.GetRemandSetting(RemandSetting.RemandAuthor) && approveSer.CheckApproveIsFinishLevel(approve.ApplyNo, approve.RouteLevel - 1))
                                {
                                    return true;
                                }
                            }
                            break;
                    }
                }
            }
            return false;
            
        }

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApproved(IList<WorkApproveModel> approve)
        {
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = (from app in approve
                           where ((app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.BackPrev) || app.ApproveStatus == (short)StatusHasAprove.Ignore)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Work_Absence GetAbsenceByID(int id)
        {
            T_Work_Absence abs = new T_Work_Absence();
            using (DB db = new DB())
            {
                WorkAbsenceService absSer = new WorkAbsenceService(db);
                abs = absSer.GetByID(id);
            }
            return abs;
        }

        /// <summary>
        /// GetListApprovePerson
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprover(int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
                Route_DService service = new Route_DService(db);
                approverList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
                return approverList;
            }
        }
        
        /// <summary>
        /// GetListApproveUserFromApply
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproverFromApply(string absNo, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                return approveSer.GetListByIDOptionLevel(this.DataNo, isIncludeView, includeZeroLV);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ApplyNo"></param>
        /// <param name="loginID"></param>
        /// <param name="typeOfButton"></param>
        /// <returns></returns>
        private T_Work_Approve GetDataApproveByApplyNoAndUserID(string applyNo, int userID)
        {
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                T_Work_Approve approve = new T_Work_Approve();
                approve = approveSer.GetApproveRow(applyNo, userID, (int)ApplyType.Absence); 
                return approve;
            }
           
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ApplyNo"></param>
        /// <param name="loginID"></param>
        /// <param name="typeOfButton"></param>
        /// <returns></returns>
        private T_Work_Approve GetDataApproveByApplyNoAndRouteID(string applyNo, int routeID)
        {
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                T_Work_Approve approve = new T_Work_Approve();
                approve = approveSer.GetByKey(applyNo, routeID);

                return approve;
            }
        }

        /// <summary>
        /// Load data for rptApproverList from ApproveList
        /// </summary>
        private void LoadDataForApproverList(string absNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = this.GetListApproverFromApply(absNo, isIncludeView);

            if (approveList != null && approveList.Count != 0)
            {
                this.isHasData = true;
                this.ApproverList = new List<WorkApproveModel>(approveList);
                this.rptApproverList.DataSource = approveList;
                this.ApproverList = new List<WorkApproveModel>();
                ((List<WorkApproveModel>)this.ApproverList).AddRange(approveList);
            }
            else
            {
                this.isHasData = false;
                this.ApproverList = new List<WorkApproveModel>();
                this.rptApproverList.DataSource = null;
                this.ApproverList = null;
            }
            this.rptApproverList.DataBind();
        }
       
        /// <summary>
        /// 
        /// </summary>
        private void LoadDataForChangedData()
        {
            this.SetRestTimeTableHeader(this.ApplyUserID);
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>(this.ApproverList);

            if (approveList != null && approveList.Count>0)
            {
                this.rptApproverList.DataSource = approveList;
                this.isHasData = true;
            }
            else
            {
                this.rptApproverList.DataSource = null;
                this.isHasData = false;
            }

            this.rptApproverList.DataBind();
        }

        #endregion

        #region Set data

        /// <summary>
        /// Set header of rest time table 
        /// </summary>
        private void SetRestTimeTableHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                M_Accounting acc = accSer.GetData();
                if (acc != null)
                {
                    lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
                }

            }
            this.rptRestTimeHeader.DataSource = lstMonth;
            this.rptRestTimeHeader.DataBind();
            this.SetDataForRestTimeTable(lstMonth, userID);
        }

        /// <summary>
        /// Set data for Rest Time table
        /// </summary>
        private void SetDataForRestTimeTable(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();
                foreach (var item in lstMonth)
                {
                    using (DB db = new DB())
                    {
                        AccountingService accSer = new AccountingService(db);
                        M_Accounting data = accSer.GetData();
                        if (data != null)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkAbsenceService absSer = new WorkAbsenceService(db);
                            decimal usedDay = absSer.GetUsedDaysInMonth(userID, period);
                            if (usedDay != 0m)
                            {
                                lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                            }
                            else
                            {
                                lstMonthVal.Add(new StringModel(string.Empty));
                            }
                        }
                    }
                }

                this.rpttRestTimeContent.DataSource = lstMonthVal;
                this.rpttRestTimeContent.DataBind();
            }
        }

        /// <summary>
        /// Set data for DayOffType Combobox
        /// </summary>
        /// <param name="dayOffType"></param>
        private void SetDataForDayOffTypeCbo(int dayOffType)
        {
           /* IList<DropDownModel> list = new List<DropDownModel>();
            using (DB db = new DB())
            {
                WorkShiftService ser = new WorkShiftService(db);
                list = ser.GetDataForDropDown(dayOffType, false);
            }

            cmbDayOffType.DataSource = list;*/
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                this.cmbDayOffType.DataSource = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }
            this.cmbDayOffType.DataValueField = "Value";
            this.cmbDayOffType.DataTextField = "DisplayName";
            this.cmbDayOffType.DataBind();
        }

        /// <summary>
        /// Set data dor Route
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        /// <param name="hasUser"></param>
        private void SetDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {
            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            if (list != null && list.Count > 0)
            {
                this.GetListApprover(int.Parse(this.cmbRoute.SelectedValue), true);
            }
            else
            {
                this.GetListApprover(DEFAULT_VALUE, true);
            }
        }

        /// <summary>
        /// Set complete status for the ApplyStatus
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private void SetCompleteStatus(IList<WorkApproveModel> approveList)
        {
            IList<WorkApproveModel> completedList = new List<WorkApproveModel>();
            completedList = (from app in approveList
                             where app.ApproveStatus == (short)StatusHasAprove.Approved
                             select app).ToList();

            if (completedList != null && completedList.Count == approveList.Count)
            {
                this.ApplyStatus = (short)StatusApply.Approved;
            }
        }

        /// <summary>
        /// Process mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Approve:
                    this.txtApproveReason.SetReadOnly(false);
                    break;

                case Mode.Confirm:
                    this.LoadDataForApproverList(this.DataNo, true);
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtApproveReason.ReadOnly = this.isApproveUser == false ? true : false;

                    break;
                case Mode.Ignore:
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(false);

                    break;

                case Mode.BackPre:
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(false);

                    break;

                default:
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.datAbsenceDtFrm.SetReadOnly(true);
                    this.datAbsenceDtTo.SetReadOnly(true);
                    this.txtTotalDays.SetReadOnly(true);
                    this.cmbDayOffType.Enabled = false;
                    this.cmbRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    if (this.isApproved)
                    {
                        base.DisabledLink(this.btnApprove, true);
                        base.DisabledLink(this.btnIgnore, true);
                        base.DisabledLink(this.btnPrevBack, true);
                    }
                    else
                    {
                        base.DisabledLink(this.btnApprove, false);
                        base.DisabledLink(this.btnIgnore, false);
                        //base.DisabledLink(this.btnApprove, !base._authority.IsApplyApproveApprove);
                        //base.DisabledLink(this.btnIgnore, !base._authority.IsApplyApproveIgnore);

                        if (this.isDisablePrevBack)
                        {
                            base.DisabledLink(this.btnPrevBack, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnPrevBack, false);
                            //base.DisabledLink(this.btnPrevBack, !base._authority.IsApplyApproveReBack);
                        }
                    }
                    break;
            }
        }

        #endregion

        #region Approve

        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Approve()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.LoginInfo.User, ApplyType.Absence, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Approve(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }

        #endregion

        #region Reject

        /// <summary>
        /// Reject
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Reject(short applyStatus)
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.LoginInfo.User, ApplyType.Absence, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Reject(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region Remand

        /// <summary>
        /// Back previous level
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Remand(short applyStatus)
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.LoginInfo.User, ApplyType.Absence, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Remand(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region View After Approved

        /// <summary>
        /// ViewData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private bool ViewData()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.LoginInfo.User, ApplyType.Absence, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.ViewData();
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region Send mail

        /// <summary>
        /// SendMail
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="empName"></param>
        /// <param name="appType"></param>
        /// <param name="reason"></param>
        /// <param name="mess"></param>
        /// <param name="type"></param>
        private void SendMail(int routeUID, string applyNo, string empName, string appType, string reason, string mess, TypeSettingMail type, bool isFinishApprove = false)
        {
            // IList<string> lstEmail = this.GetListEmail(type, applyID, routeUID, isFinishApprove);
            if (isFinishApprove)
            {
                this.SendMail(routeUID, applyNo, empName, appType, reason, mess, type);
            }
            IList<M_User> lstEmail = this.GetListEmail(type, applyNo, routeUID, isFinishApprove);

            StringBuilder mailBody = new StringBuilder();

            #region Test
            IList<string> lstEmailStr = new List<string>();
            IList<string> lstUserStr = new List<string>();
            foreach (var item in lstEmail)
            {
                lstEmailStr.Add(item.Email);
                lstUserStr.Add(string.Format("{0} {1}", EditDataUtil.ToFixCodeShow(item.UserCD, M_User.MAX_USER_CODE_SHOW), item.UserName2));
            }
            #endregion


            if (lstEmail != null && lstEmail.Count > 0)
            {
                mailBody.AppendLine("All mail: " + lstEmail.Count);
                mailBody.AppendLine("ApplyNo: " + applyNo);
                mailBody.AppendLine("User: " + empName);
                mailBody.AppendLine("Type: " + appType);
                mailBody.AppendLine("Reason: " + reason);
                mailBody.AppendLine("All user received: ");
                foreach (var it in lstUserStr)
                {
                    mailBody.AppendLine(string.Format("● {0}", it));
                }
                switch (type)
                {
                    case TypeSettingMail.Reject:
                        mailBody.AppendLine("Rejected By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Remand:
                        mailBody.AppendLine("Remanded By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Approve:
                        mailBody.AppendLine("Approved By: " + this.LoginInfo.User.UserName2);
                        break;
                    case TypeSettingMail.Read:
                        mailBody.AppendLine("Viewer By: " + this.LoginInfo.User.UserName2);
                        break;
                    default:
                        break;
                }

                string sSubject = string.Empty;
                if (isFinishApprove)
                {
                    sSubject = "This application form has been completed.";
                }
                else
                {
                    sSubject = mess;
                }

                //CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);
                CommonUtil.Sending_Email(lstEmailStr.ToArray(), sSubject, mailBody);
            }
        }

        /// <summary>
        /// GetListEmail
        /// </summary>
        /// <param name="type"></param>
        /// <param name="isFinishApprove"></param>
        /// <returns></returns>
        private IList<M_User> GetListEmail(TypeSettingMail type, string applyNo, int routeUID, bool isFinishApprove = false)
        {
            //IList<string> lstEmail = new List<string>();
            IList<M_User> lstEmail = new List<M_User>();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                T_Work_Approve applicantInfoList = approveSer.GetByKey(applyNo, routeUID);

                if (applicantInfoList != null)
                {

                    #region Test
                    switch (type)
                    {
                        case TypeSettingMail.Reject:
                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Remand:
                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Approve:
                            if (isFinishApprove)
                            {
                                return approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
                            }
                            //Next
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }
                            //Previous
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            //sender
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            //current
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Read:
                            if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                            }
                            else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                            }

                            if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;
                    }
                    #endregion
                }
                return lstEmail;
            }
            
        }

        #endregion

        #endregion

        #region Web method

        /// <summary>
        /// GetUseDays
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetDayOffType(string shiftID)
        {
            try
            {
                var dayOffType = -1;
                if (shiftID == null)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    M_Work_Shift shift = shiftSer.GetByID(int.Parse(shiftID));
                    if (shift != null)
                    {
                        dayOffType = shift.TypeOfDay;
                    }

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(dayOffType);
                }

            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// GetUseDays
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetUseDays(DateTime startDate, DateTime endDate)
        {
            try
            {
                if (endDate < startDate)
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                using (DB db = new DB())
                {
                    WorkVacationService ser = new WorkVacationService(db);
                    decimal days = ser.GetNumberOfDaysByRangeDate(startDate, endDate);

                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(days);
                }

            }
            catch (Exception)
            {
                return null;
            }
        }

        #endregion
    }
}
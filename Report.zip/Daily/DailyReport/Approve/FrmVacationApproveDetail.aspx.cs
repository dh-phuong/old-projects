﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;

namespace DailyReport.Approve
{
    /// <summary>
    /// FrmVacationApproveDetail
    /// ISV-TRUC 2015/06/09
    public partial class FrmVacationApproveDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Approve/FrmApproveList.aspx";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const decimal ZERO_DEC = 0m;
        public const int LEAVE_TEMPLATE = M_Config_D.TEMPLATE_FORM_APPLY_VACTION;
        public const int DEFAULT_VALUE = -1;
        #endregion

        #region Variable
        
        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;

        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;
        
        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData;
                
        /// <summary>
        /// 2015/04/20 ISV-TRUC
        /// </summary>
        public bool isDispApproveButton;
        public bool isDispViewButton;
        public bool isDispIgnoreButton;
        public bool isShowPrevBackButton;
        #endregion

        #region Property
        
        /// <summary>
        /// Type Apply Form Current
        /// </summary>
        public int CurrenType
        {
            get { return (int)ViewState["CurrenType"]; }
            set { ViewState["CurrenType"] = value; }
        }
        
        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }


        /// <summary>
        /// Get or set ApplyUserID
        /// </summary>
        public int ApplyUserID
        {
            get { return (int)ViewState["ApplyUserID"]; }
            set { ViewState["ApplyUserID"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }
        
        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }
        
        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }
        
        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel>  ApproverList
        {     
            get{return (IList<WorkApproveModel>)ViewState["ApproverList"];}
            set { ViewState["ApproverList"] = value; }
        }
        
        /// <summary>
        /// Is Inspected : đã xem xét (approve, remand)
        /// </summary>
        public bool IsInspected
        {
            get { return (bool)ViewState["IsInspected"]; }
            set { ViewState["IsInspected"] = value; }
        }

        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Vacation";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtApproveReason.MaxLength = T_Work_Approve.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyApprove);
            if (!this._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init Data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        base.RedirectUrl(URL_LIST);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_Vacation data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    base.RedirectUrl(URL_LIST);
                }
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// Approve Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {              
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Ignore Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Ignore);             
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// btnView Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                //View Data
                if (this.ViewData())
                {
                    Server.Transfer(URL_LIST);
                }
                else
                {
                    this.LoadDataForChangedData();
                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }
                
        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Work_Vacation apply = this.GetApplyByID(this.DataID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.BackPre);
             
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }
        
        /// <summary>
        /// Submit Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.btnProcessData(sender, e);
            //this.LoadDataForChangedData();
            //this.InitTimesHeader(this.ApplyUserID);
            //if (this.Mode == Mode.Approve)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.Yes);
            //}
            //else if (this.Mode == Mode.Ignore)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No);
            //}
            //else if (this.Mode == Mode.BackPre)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.No);
            //}
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work_Vacation data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Approve:
                    //Update Data
                    
                    if (this.Approve())
                    {

                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    
                    break;

                case Utilities.Mode.Ignore:
                    //Update Data
                    if (this.Reject())
                    {
                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    if (this.Remand())
                    {

                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    break;
            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Vacation data = this.GetApplyByID(this.DataID);
            if (this.Mode == Utilities.Mode.View)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                this.LoadDataForApproveList(this.DataNo,true);
            }
        }

        #endregion

        #region Methods
        
        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.IsInspected = false;
            this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, this.LoginInfo.User.ID);
            this.InitTimesHeader(this.LoginInfo.User.ID);
            this.InitDataDropdownType(this.cmbTypeVacation);
            this.hdnFormIDDefault.Value = LEAVE_TEMPLATE.ToString();
            this.btnViewPreVacation.Text = string.Empty;
        }

        /// <summary>
        /// InitDataDropdownType
        /// </summary>
        /// <param name="ddl"></param>
        private void InitDataDropdownType(DropDownList ddl)
        {
            /*using (DB db = new DB())
            {
                WorkShiftService wrkSer = new WorkShiftService(db);
                ddl.DataSource = wrkSer.GetDataForDropDown((int)ShiftType.PaidVacation);
            }
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();*/
            IList<DropDownModel> list;
            using (DB db = new DB())
            {
                Config_HService ser = new Config_HService(db);
                list = ser.GetDataForDropDownList(M_Config_H.CONFIG_CD_VACATION_TYPE);
            }

             ddl.DataSource=list;
            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind(); 
        }
        
        /// <summary>
        /// InitTimesHeader
        /// </summary>
        private void InitTimesHeader(DB db, int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            M_Accounting acc;
            //using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                acc = accSer.GetData();                
            }

            if (acc != null)
            {
                lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
            }
            this.rptTimesHeader.DataSource = lstMonth;
            this.rptTimesHeader.DataBind();
            this.InitTimesValue(lstMonth, userID);
        }

        /// <summary>
        /// InitTimesHeader
        /// </summary>
        private void InitTimesHeader(int userID)
        {
            IList<StringModel> lstMonth = new List<StringModel>();
            M_Accounting acc;
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                acc = accSer.GetData();
            }

            if (acc != null)
            {
                lstMonth = base.GetListMonthByStartMonth(acc.StartMonth, DateTime.Now.Month, DateTime.Now.Year);
            }
            this.rptTimesHeader.DataSource = lstMonth;
            this.rptTimesHeader.DataBind();
            this.InitTimesValue(lstMonth, userID);
        }

        /// <summary>
        /// Init Times Value
        /// </summary>
        private void InitTimesValue(IList<StringModel> lstMonth, int userID)
        {
            if (lstMonth.Count != 0)
            {
                IList<StringModel> lstMonthVal = new List<StringModel>();

                using (DB db = new DB())
                {
                    AccountingService accSer = new AccountingService(db);
                    M_Accounting data = accSer.GetData();
                        
                    if (data != null)
                    {
                        foreach (var item in lstMonth)
                        {
                            AccountingPeriod period = accSer.GetPeriodMonth(item.Val2, item.Val, data.ClosingDay);
                            WorkVacationService vacSer = new WorkVacationService(db);
                            decimal usedDay = vacSer.GetUsedDaysInMonth(userID, period);

                            if (usedDay != decimal.Zero)
                            {
                                lstMonthVal.Add(new StringModel(usedDay.ToString("N1")));
                            }
                            else
                            {
                                lstMonthVal.Add(new StringModel(string.Empty));
                            }
                        }
                    }
                }                

                this.rptTimes.DataSource = lstMonthVal;
                this.rptTimes.DataBind();
            }
        }

        /// <summary>
        /// GetListApprovePerson
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprovePerson(int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
                Route_DService service = new Route_DService(db);
                approveUserList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
                return approveUserList;
            }
        }
        
        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            if (list != null && list.Count > 0)
            {
                this.GetListApprovePerson(int.Parse(this.cmbRoute.SelectedValue), true);
            }
            else
            {
                this.GetListApprovePerson(DEFAULT_VALUE, true);
            }
        }

        #region Approve

        /// <summary>
        /// GetUserByID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_User GetUserByID(int ID)
        {
            using (DB db = new DB())
            {
                UserService uSer = new UserService(db);
                return uSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Approve()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.Vacation, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Approve(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;                
            }

            #region OLD
            /* bool success = false;
            bool isFinishApp = false;
            //User has been registed in list approve
            int userApproveID = this.LoginInfo.User.ID;
            try
            {
                var ret = 0;
                int nextLevel = 0;
                WorkVacationService appSer;
                WorkApproveService approveListSer;

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    appSer = new WorkVacationService(db);
                    T_Work_Vacation app = appSer.GetByID(this.DataID);
                    if (app != null)
                    {
                        approveListSer = new WorkApproveService(db);
                        T_Work_Approve apLt = approveListSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID);
                        if (apLt != null)
                        {
                            //Approve in list approver
                            userApproveID = apLt.RouteUID;
                            approveListSer.Approve(this.DataNo, userApproveID, this.LoginInfo.User.ID, (short)StatusHasAprove.Approved, this.txtApproveReason.Text.Trim());
                            //Check finish
                            isFinishApp = approveListSer.CheckApproveIsFinish(this.DataNo, userApproveID);
                            if (isFinishApp)//approve lastest
                            {
                                T_Work_Approve appr = approveListSer.GetByKey(this.DataNo, userApproveID);
                                //update status [Approved] for header
                                ret = appSer.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (short)StatusApply.Approved, appr.RouteLevel, this.OldUpdateDate);
                                nextLevel = 99;

                                StaffService staffSer = new StaffService(db);
                                //get Staff 
                                M_Staff staff = null;

                                staff = this.GetStaffForUpdateAnnual(app.UserID, app.Duration.Value, staffSer, this.PreApplyID.HasValue);

                                //update ngay phep trong user--if is vacation
                                if (staff != null)
                                {
                                    if (ret != 0)
                                    {
                                        //Tru phep
                                        ret = staffSer.UpdateAnnualDay(staff);
                                    }
                                }
                                else
                                {
                                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                                    return false;
                                }
                                if (this.PreApplyID.HasValue)
                                {
                                    //Update status of PreApplyID ==> cancel
                                    T_Work_Vacation preApp = appSer.GetByID(this.PreApplyID.Value);
                                    appSer.UpdateApplyStatus(this.PreApplyID.Value, this.LoginInfo.User.ID, (short)StatusApply.Cancel, preApp.ApprovedLevel, preApp.UpdateDate);
                                    WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                                    wrkAppSer.Delete(app.No);
                                }
                            }
                            else//approve normal
                            {
                                bool finishLevel = false;
                                //Send mail
                                T_Work_Approve appr = approveListSer.GetByKey(this.DataNo, userApproveID);
                                if (approveListSer.CheckApproveIsFinishLevel(this.DataNo, appr.RouteLevel))
                                {
                                    nextLevel = appr.RouteLevel + 1;
                                    finishLevel = true;
                                }

                                //update status approve for header
                                ret = appSer.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, (short)StatusApply.Approving, finishLevel ? appr.RouteLevel : app.ApprovedLevel, this.OldUpdateDate);
                                //back next level to new if is remand
                                if (ret != 0)
                                {
                                    //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
                                    approveListSer.UpdateStatusForRemand(this.DataNo, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
                                }
                            }
                            //Check result update
                            if (ret == 0)
                            {
                                //data changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                            db.Commit();
                            success = true;
                            this.IsInspected = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                //LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return false;
            }
             
            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have approved.";
                    this.SendMail(userApproveID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply type", this.txtReason.Text, mess, TypeSettingMail.Approve, isFinishApp);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }*/
            #endregion

            return ret;
        }

        /// <summary>
        /// GetStaffForUpdateAnnual
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="typeApply"></param>
        /// <param name="staffSer"></param>
        /// <param name="isCancel"></param>
        /// <returns></returns>
        private M_Staff GetStaffForUpdateAnnual(int userID, decimal annualDay, StaffService staffSer, bool isCancel = false)
        {
            M_Staff staff = staffSer.GetByUserID(userID);
            if (staff != null)
            {
                if (isCancel)//cancel -> + dayoff
                {
                    staff.AnnualDays = staff.AnnualDays + annualDay;
                }
                else//not cancel -> - dayoff
                {
                    if ((staff.AnnualDays >= annualDay) && (staff.AnnualDays - annualDay >= 0))
                    {
                        staff.AnnualDays = staff.AnnualDays - annualDay;
                    }
                    else
                    {
                        return null;
                    }
                }
                
                staff.UpdateUID = this.LoginInfo.User.ID;
            }
            return staff;
        }

        #endregion

        #region Reject
        /// <summary>
        /// Reject
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Reject()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.Vacation, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Reject(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
            #region OLD
            /* bool success = false;
            int approveUserID = this.LoginInfo.User.ID;
            try
            {   
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    WorkApproveService approveSer = new WorkApproveService(db);
                    T_Work_Approve apLt = approveSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID);
                    if (apLt != null)
                    {
                        approveUserID = apLt.RouteUID;
                        ret = approveSer.Reject(this.DataNo, apLt.RouteUID, this.LoginInfo.User.ID, (int)StatusHasAprove.Ignore, this.txtApproveReason.Value);
                        WorkVacationService service = new WorkVacationService (db);
                        //Update StatusFlag
                        //Chua co level nao duoc duyet nen approve level = 0
                        ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, 0, this.OldUpdateDate);
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        wrkAppSer.Delete(this.DataNo);
                        //Check result update
                        if (ret == 0)
                        {
                            //du lieu da thay doi
                            this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                            return false;
                        }
                        db.Commit();
                        success = true;
                        this.IsInspected = true;
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }

            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have rejected.";
                    this.SendMail(approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Reject);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            
            return true;*/
            #endregion
        }

        #endregion
        
        #region View After Approved
        /// <summary>
        /// ViewData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private bool ViewData()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.Vacation, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.ViewData();
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
            #region OLD
            /*
           /* bool success = false;
            try
            {
                int ret = 0;
                using (DB db = new DB())
                {
                    WorkVacationService service = new WorkVacationService (db);

                    //Update StatusFlag
                    ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, apply.ApplyStatus, apply.ApprovedLevel, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        WorkApproveService approveSer = new WorkApproveService(db);
                        approveSer.UpdateApproveStatus(apply.No, (int)StatusHasAprove.Approved, this.LoginInfo.User.ID, string.Empty);
                    }
                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    db.Commit();
                    success = true;
                }
            }
            catch (Exception ex)
            {
                //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //LoadDataForApproveListFromApproveList();
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                Log.Instance.WriteLog(ex);
                return false;
            }

            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have viewed.";
                    this.SendMail(this.LoginInfo.User.ID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Read);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            return true;*/
            #endregion
        }

        #endregion

        #region Remand

        /// <summary>
        /// Back previous level
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Remand()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.Vacation, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Remand(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
            #region OLD
            /*
            int approveUserID = this.LoginInfo.User.ID;
            bool success = false;
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    WorkVacationService service = new WorkVacationService (db);
                    T_Work_Vacation app = service.GetByID(this.DataID);
                    if (app != null)
                    {
                        WorkApproveService approveSer = new WorkApproveService(db);
                        T_Work_Approve apLt = approveSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID);
                        if (apLt != null)
                        {
                            //1:Update ApproveStatus for the login user 
                            //2:Update New status of the approved users have level = the login user's level or level= the login user's level-1

                            ret = approveSer.Remand(this.DataNo, apLt.RouteUID, this.LoginInfo.User.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New, this.txtApproveReason.Value);
                            ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, app.ApprovedLevel > 1 ? (app.ApprovedLevel - 1) : 0, this.OldUpdateDate);
                            
                            //Check result update
                            if (ret == 0)
                            {
                                //data changed
                                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                                return false;
                            }
                            //else
                            //{
                            //    ApplyApproveListService approveListSer = new ApplyApproveListService(db);
                            //    T_Apply_Approve_List appr = approveListSer.GetByKey2(this.DataID, this.LoginInfo.User.ID);
                            //    IList<string> lstEmail = approveListSer.GetListEmailByLevelRemand2(this.DataID, appr.RouteLevel - 1);
                            //    StringBuilder mailBody = new StringBuilder();
                            //    if (lstEmail.Count > 0)
                            //    {
                            //        mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
                            //        mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
                            //        mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
                            //        mailBody.AppendLine("Reason: " + this.txtReason.Text);
                            //        mailBody.AppendLine("Remain By: " + this.LoginInfo.User.UserName2);

                            //        CommonUtil.Sending_Email(lstEmail.ToArray(), "Has remain apply", mailBody);
                            //    }
                            //}
                            db.Commit();
                            success = true;
                            this.IsInspected = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }
            try
            {
                //Send mail
                if (success)
                {
                    string mess = "I have remanded.";
                    this.SendMail(approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Remand);
                }
            }
            catch (Exception)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                return true;
            }
            
            return true;*/
            #endregion
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Work_Vacation GetApplyByID(int id)
        {
            T_Work_Vacation apply = new T_Work_Vacation();
            using (DB db = new DB())
            {
                WorkVacationService appSer = new WorkVacationService (db);
                apply = appSer.GetByID(id);
            }            
            return apply;
        }

        /// <summary>
        /// GetByApplyNo
        /// </summary>
        /// <returns></returns>
        private T_Work_Vacation GetByApplyNo(string AppNo)
        {
            using (DB db = new DB())
            {
                T_Work_Vacation apply = new T_Work_Vacation();
                WorkVacationService appSer = new WorkVacationService(db);
                apply = appSer.GetByApplyNo(AppNo);
                return apply;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(bool isIncludeView = false)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.DataNo, isGetViewLevel: isIncludeView);
            }
        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        private void LoadDataForApproveList(string applyNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
            approverList = this.GetListApproveUserFromApply(isIncludeView);

            if (approverList != null && approverList.Count != 0)
            {
            
                this.isHasData = true;
                this.ApproverList = new List<WorkApproveModel>(approverList);
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();
        }

        /// <summary>
        /// Load Data For Changed Data
        /// </summary>
        private void LoadDataForChangedData()
        {
            this.InitTimesHeader(this.ApplyUserID);
            IList<WorkApproveModel> applyLst = new List<WorkApproveModel>(this.ApproverList);
            if (applyLst != null)
            {
                this.rptApproverList.DataSource = applyLst;
                this.isHasData = true;
            }
            else
            {
                this.rptApproverList.DataSource = null;
                this.isHasData = false;
            }
            
            this.rptApproverList.DataBind();
            
        }

        #endregion

        #region Set data

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Approve:
                case Mode.Ignore:
                case Mode.BackPre:
                    this.txtApproveReason.SetReadOnly(false);
                    break;

                default:

                    this.txtVactionDtFrm.SetReadOnly(true);
                    this.txtVactionDtTo.SetReadOnly(true);
                    this.txtUseDays.SetReadOnly(true);
                   
                    this.cmbTypeVacation.Enabled = false;
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.cmbRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                   
                    break;
            }
            base.DisabledLink(this.btnSearchList, true);
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Work_Vacation apply)
        {
            //Show data
            if (apply != null)
            {
                //Re-Init value for combobox Route
                this.InitDataForRoute(this.cmbRoute, LEAVE_TEMPLATE, apply.UserID);
                this.txtApplyNo.Value = apply.No;
                this.dtApplyDate.Value = apply.ApplyDate;
                this.cmbRoute.SelectedValue = apply.RouteID.ToString();
                this.cmbTypeVacation.SelectedValue = apply.VacationType.ToString();

                using (DB db = new DB())
                {
                    WorkApproveService appSer = new WorkApproveService(db);
                    T_Work_Approve appLst = appSer.GetByKey(apply.No, this.LoginInfo.User.ID);
                    if (appLst != null)
                    {
                        this.IsInspected = appLst.ApproveStatus != (int)StatusHasAprove.New;
                    }
                    UserService userSer = new UserService(db);
                    M_User user = userSer.GetByID(apply.UserID);
                    if (user != null)
                    {
                        StaffService staffSer = new StaffService(db);
                        M_StaffInfo s = staffSer.GetStaffInfoByStaffID(user.StaffID);
                        if (s != null)
                        {
                            this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                            this.txtEmployeeNm.Value = s.StaffName;
                            this.txtPosition.Value = s.Position;
                            this.txtDepartment.Value = s.DepartmentName;
                            this.hdnDepartmentID.Value = s.DepartmentID.ToString();
                        }
                        this.ResetValueForHeaderDays(db, DEFAULT_VALUE, user.ID);
                        this.InitTimesHeader(db, user.ID);
                        this.ApplyUserID = user.ID;
                    }

                    this.txtApproveReason.Value = string.Empty;
                    this.txtUseDays.Value = apply.Duration.Value.ToString("N1");
                    this.DataNo = apply.No;
                    this.DataID = apply.ID;
                    this.txtVactionDtFrm.Value = apply.StartDate;
                    this.txtVactionDtTo.Value = apply.EndDate;
                    this.ApplyStatus = apply.ApplyStatus;
                    this.PreApplyID = apply.PreApplyID;
                    WorkVacationService ser = new WorkVacationService(db);
                    if (this.PreApplyID.HasValue)
                    {
                        T_Work_Vacation preApp = ser.GetByID(this.PreApplyID.Value);
                        if (preApp != null)
                        {
                            this.txtReason.Value = preApp.Reason;
                            this.txtReasonCancel.Value = apply.Reason;
                            this.btnViewPreVacation.Text = preApp.No;
                            this.hdnApplyID.Value = preApp.ID.ToString();
                        }
                    }
                    else
                    {
                        this.txtReason.Value = apply.Reason;
                    }
                    M_User createUser = userSer.GetByID(apply.CreateUID);
                    if (createUser != null)
                    {                       
                        var createDate = (apply.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                    }

                    M_User updateUser = userSer.GetByID(apply.UpdateUID);
                    if (updateUser != null)
                    {
                        var updateDate = (apply.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                        this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                    }
                }

                this.GetListApprovePerson(apply.RouteID, true);
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveList(this.DataNo, true);

                T_Work_Approve workApprove = null;
                using (DB db = new DB())
                {
                    WorkApproveService appLstSer = new WorkApproveService(db);
                    workApprove = appLstSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID, (int)ApplyType.Vacation);
                }
                this.isDispApproveButton = this.IsDisplayApproveButton(workApprove);
                this.isDispIgnoreButton = this.IsDisplayIgnoreButton(workApprove);
                this.isShowPrevBackButton = this.IsDisplayPreBackButton(workApprove);
                this.isDispViewButton = this.IsDisplayViewButton(workApprove);

            }
        }

        /// <summary>
        /// ResetValueForHeaderDays
        /// </summary>
        /// <param name="dataID"></param>
        /// <param name="userID"></param>
        private void ResetValueForHeaderDays(DB db, int dataID, int userID)
        {
            decimal curRemainDay = 0;
            decimal usedDay = 0;
            decimal planDay = 0;
            //using (DB db = new DB())
            {
                WorkVacationService applySer = new WorkVacationService(db);
                curRemainDay = applySer.GetRemainDays(dataID, userID);
                usedDay = applySer.GetUsedDays(userID, DateTime.MinValue, DateTime.MinValue);
                planDay = applySer.GetPlanDays(dataID, userID);
            }
            decimal totalDay = planDay + usedDay + curRemainDay;
            this.lblTotalDays.InnerText = totalDay.ToString("N1");
            this.lblUsedDays.InnerText = usedDay.ToString("N1");
            this.lblPlanDays.InnerText = planDay.ToString("N1");
            decimal expDays = totalDay - 12;
            this.lblExpriedDays.InnerText = (expDays < 0 ? 0 : expDays).ToString("N1");
            this.lblRemainDays.InnerText = curRemainDay.ToString("N1");
        }
        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayApproveButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }

                return true;
            }
            return false;
        }

        /// <summary>
        /// IsDisplayViewButton
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayViewButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel != 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved && workApp.GetReadSetting(ReadSetting.ReadAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayIgnoreButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }
                if (workApp.GetRejectSetting(RejectSetting.RejectAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayPreBackButton(T_Work_Approve workApp)
        {
            using (DB db = new DB())
            {
                WorkApproveService appLstSer = new WorkApproveService(db);
                if (workApp != null)
                {
                    if (workApp.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                    if (workApp.GetRemandSetting(RemandSetting.RemandAuthor) && appLstSer.CheckApproveIsFinishLevel(workApp.ApplyNo, workApp.RouteLevel - 1))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        /// <summary>
        /// CreateDailyData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private IList<T_Daily> CreateDailyData(T_Work_Vacation apply, int typeOfForm = (int)TypeFormID.Apply)
        {
            IList<T_Daily> dailyList = new List<T_Daily>();
            M_Holiday hld;
            DateTime sDate = apply.StartDate;
            DateTime eDate = apply.EndDate;

            using (DB db = new DB())
            {
                HolidayService hSer = new HolidayService(db);
                hld = hSer.GetByDay(sDate);
            }
            
            while (sDate <= eDate)
            {
              
                T_Daily daily = new T_Daily();
                daily.WorkDate = sDate;
                daily.UserID = apply.UserID;
                daily.ApplyID = apply.ID;
                daily.VacationID = null;
                daily.ApproveID = null;
                daily.Content = apply.Reason;

                daily.DeleteFlag = 0;
                daily.CreateUID = apply.CreateUID;
                daily.UpdateUID = apply.CreateUID;
                dailyList.Add(daily);
                sDate = sDate.AddDays(1);
            }
                
            return dailyList;
        }
       
        #endregion

        #endregion

        #region Web Methods
        /// <summary>
        /// GetTypeVacation
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetTypeVacation(string type)
        {
            try
            {
                if (string.IsNullOrEmpty(type))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                int typeID = int.Parse(type);
                using (DB db = new DB())
                {
                    WorkShiftService wrkSer = new WorkShiftService(db);
                    M_Work_Shift wk = wrkSer.GetByID(typeID);
                    if (wk != null)
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(wk.TypeOfDay);
                    }
                    else
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                    }
                }

            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
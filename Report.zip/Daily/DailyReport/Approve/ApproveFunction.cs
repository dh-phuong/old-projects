﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DailyReport.Utilities;
using DailyReport.Models;
using DailyReport.DAC;
using System.Text;

namespace DailyReport.Approve
{
    public class ApproveFunction
    {
        #region Property
        private int ApplyID { get; set; }
        private M_User LoginUser { get; set; }
        private ApplyType ApplyType { get; set; }
        private DateTime OldUpdateDate { get; set; }
        private M_StaffInfo Staff { get; set; }

        #endregion

        #region Contructor
        /// <summary>
        /// Contructor
        /// </summary>
        private ApproveFunction()
        {
        }
        /// <summary>
        /// Contructor
        /// </summary>
        public ApproveFunction(int applyID, M_User loginUser, ApplyType applyType, DateTime oldUpdateDate, M_StaffInfo staff)
        {
            this.ApplyID = applyID;
            this.LoginUser = loginUser;
            this.ApplyType = applyType;
            this.OldUpdateDate = oldUpdateDate;
            this.Staff = staff;
        }
        #endregion

        #region Approve
        public ProcessResult Approve(string approveReason)
        {
            string applyNo = string.Empty;

            int apprUID = this.LoginUser.ID;
            int applyUID = 0;
            string applyReason = string.Empty;
            int? preApplyID = null;
            string preApplyNo = string.Empty;
            int preApprovedLevel = 0;

            DateTime oldReUpdateDate = new DateTime();
            decimal duration = 0;

            bool isFinishApp = false;
            int approvedLevel = 0;

            string effectTime = string.Empty;
            string type = string.Empty;

            int ret = 0;
            try
            {
                switch (this.ApplyType)
                {
                    case ApplyType.Vacation:
                        using (DB db = new DB())
                        {
                            WorkVacationService vacationSer = new WorkVacationService(db);
                            T_Work_Vacation app = vacationSer.GetByID(this.ApplyID, true);
                            applyNo = app.No;
                            preApplyID = app.PreApplyID;
                            approvedLevel = app.ApprovedLevel;
                            applyUID = app.UserID;
                            duration = app.Duration.Value;
                            applyReason = app.Reason;

                            if (preApplyID.HasValue)
                            {
                                T_Work_Vacation preApp = vacationSer.GetByID(preApplyID.Value);
                                preApplyNo = preApp.No;
                                preApprovedLevel = preApp.ApprovedLevel;
                                oldReUpdateDate = preApp.UpdateDate;
                            }

                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, app.VacationType);

                            if (app.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, app.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString());
                            }
                        }
                        break;

                    case ApplyType.OverTime:
                        using (DB db = new DB())
                        {
                            WorkOTService otSer = new WorkOTService(db);
                            T_Work_OT appOT = otSer.GetByID(this.ApplyID, true);

                            applyNo = appOT.No;
                            preApplyID = appOT.PreApplyID;
                            approvedLevel = appOT.ApprovedLevel;
                            applyReason = appOT.Reason;
                            if (preApplyID.HasValue)
                            {
                                T_Work_OT preApp = otSer.GetByID(preApplyID.Value);
                                preApplyNo = preApp.No;
                                preApprovedLevel = preApp.ApprovedLevel;
                                oldReUpdateDate = preApp.UpdateDate;
                            }

                            effectTime = EditDataUtil.FixTimeShow(appOT.OTStartHour, appOT.OTStartMinute) + " ～ " + EditDataUtil.FixTimeShow(appOT.OTEndHour, appOT.OTEndMinute);
                        }

                        break;

                    case ApplyType.LateEarlyOuting:
                        using (DB db = new DB())
                        {
                            WorkLeaveService leaveSer = new WorkLeaveService(db);
                            T_Work_Leave appLeave = leaveSer.GetByID(this.ApplyID);

                            applyNo = appLeave.No;
                            preApplyID = appLeave.PreApplyID;
                            approvedLevel = appLeave.ApprovedLevel.Value;
                            applyReason = appLeave.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appLeave.StartHour, appLeave.StartMinute) + " ～ " + EditDataUtil.FixTimeShow(appLeave.EndHour, appLeave.EndMinute);

                            if (preApplyID.HasValue)
                            {
                                T_Work_Leave preApp = leaveSer.GetByID(preApplyID.Value);
                                preApplyNo = preApp.No;
                                preApprovedLevel = preApp.ApprovedLevel.Value;
                                oldReUpdateDate = preApp.UpdateDate;
                            }
                        }
                        break;

                    case ApplyType.Absence:
                        using (DB db = new DB())
                        {
                            WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                            T_Work_Absence appAbsence = absenceSer.GetByID(this.ApplyID, true);

                            applyNo = appAbsence.No;
                            preApplyID = appAbsence.PreApplyID;
                            approvedLevel = appAbsence.ApprovedLevel;
                            applyReason = appAbsence.Reason;
                            if (appAbsence.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, appAbsence.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString());
                            }

                            if (preApplyID.HasValue)
                            {
                                T_Work_Absence preApp = absenceSer.GetByID(preApplyID.Value);
                                preApplyNo = preApp.No;
                                preApprovedLevel = preApp.ApprovedLevel;
                                oldReUpdateDate = preApp.UpdateDate;
                            }
                        }
                        break;

                    default:
                        return ProcessResult.ProcessFail;
                }

                T_Work_Approve apprRow = null;
                using (DB db = new DB())
                {
                    WorkApproveService apprSer = new WorkApproveService(db);
                    apprRow = apprSer.GetApproveRow(applyNo, this.LoginUser.ID, (int)this.ApplyType);
                }

                if (apprRow != null)
                {
                    apprUID = apprRow.RouteUID;

                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkApproveService apprSer = new WorkApproveService(db);

                        //----------------- Approve
                        apprSer.Approve(applyNo, apprUID, this.LoginUser.ID, (short)StatusHasAprove.Approved, approveReason);

                        //Check finish Apply
                        isFinishApp = apprSer.CheckApproveIsFinish(applyNo, this.LoginUser.ID);

                        if (isFinishApp)
                        {
                            ret = apprSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, (short)StatusApply.Approved, apprRow.RouteLevel, this.OldUpdateDate);

                            if (this.ApplyType == ApplyType.Vacation && ret != 0)
                            {
                                StaffService staffSer = new StaffService(db);

                                M_Staff staff = this.GetStaffForUpdateAnnual(applyUID, duration, staffSer, this.LoginUser.ID, preApplyID.HasValue);

                                if (staff.AnnualDays >= 0)
                                {
                                    //AnnualDate chua gan trong user
                                    ret = staffSer.UpdateAnnualDay(staff);
                                }
                                else
                                {
                                    return ProcessResult.NotEnoughAnnualDays;
                                }
                            }

                            if (preApplyID.HasValue)
                            {
                                apprSer.UpdateApplyStatus(this.ApplyType, preApplyID.Value, this.LoginUser.ID, (short)StatusApply.Cancel, preApprovedLevel, oldReUpdateDate);

                                WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                                wrkAppSer.Delete(preApplyNo);
                            }
                        }
                        else
                        {
                            if (apprSer.CheckApproveIsFinishLevel(applyNo, apprRow.RouteLevel))
                            {
                                approvedLevel = apprRow.RouteLevel;
                            }
                            else
                            {
                                approvedLevel = apprRow.RouteLevel - 1;
                            }

                            ret = apprSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, (short)StatusApply.Approving, approvedLevel, this.OldUpdateDate);
                            //back next level to new if is remand
                            if (ret != 0)
                            {
                                //3:Check status of approver has next level: Status=BackPrev=> Update Status=New
                                apprSer.UpdateStatusForRemand(applyNo, (int)StatusHasAprove.New, (int)StatusHasAprove.BackPrev);
                            }
                        }

                        if (ret == 0)
                        {
                            //data changed
                            return ProcessResult.DataChanged;
                        }

                        db.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                //LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return ProcessResult.ProcessFail;
            }

            try
            {
                this.SendMail(applyNo, this.ApplyType.ToString(), apprUID, applyReason, effectTime, TypeSettingMail.Approve, isFinishApp);
            }
            catch (Exception)
            {
                return ProcessResult.MailFail;
            }

            return ProcessResult.Success;
        }

        /// <summary>
        /// GetStaffForUpdateAnnual
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="typeApply"></param>
        /// <param name="staffSer"></param>
        /// <param name="isCancel"></param>
        /// <returns></returns>
        private M_Staff GetStaffForUpdateAnnual(int userID, decimal annualDay, StaffService staffSer, int loginUID, bool isCancel = false)
        {
            M_Staff staff = staffSer.GetByUserID(userID);
            if (staff != null)
            {
                if (isCancel)//cancel -> + dayoff
                {
                    staff.AnnualDays = staff.AnnualDays + annualDay;
                }
                else//not cancel -> - dayoff
                {
                    staff.AnnualDays = staff.AnnualDays - annualDay;
                }

                staff.UpdateUID = loginUID;
            }
            return staff;
        }

        #endregion

        #region Reject

        public ProcessResult Reject(string approveReason)
        {
            int approveUserID = this.LoginUser.ID;
            int ret = 0;
            string applyNo = string.Empty;
            int approvedLevel = 0;
            string applyReason = string.Empty;
            string effectTime = string.Empty;
            string type = string.Empty;
            try
            {
                switch (this.ApplyType)
                {
                    case ApplyType.Vacation:
                        using (DB db = new DB())
                        {
                            WorkVacationService vacationSer = new WorkVacationService(db);
                            T_Work_Vacation app = vacationSer.GetByID(this.ApplyID, true);
                            applyNo = app.No;
                            approvedLevel = app.ApprovedLevel;
                            applyReason = app.Reason;

                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, app.VacationType);

                            if (app.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, app.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString());
                            }
                        }
                        break;

                    case ApplyType.OverTime:
                        using (DB db = new DB())
                        {
                            WorkOTService otSer = new WorkOTService(db);
                            T_Work_OT appOT = otSer.GetByID(this.ApplyID, true);
                            applyNo = appOT.No;
                            approvedLevel = appOT.ApprovedLevel;
                            applyReason = appOT.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appOT.OTStartHour, appOT.OTStartMinute) + " ～ " + EditDataUtil.FixTimeShow(appOT.OTEndHour, appOT.OTEndMinute);
                        }
                        break;

                    case ApplyType.LateEarlyOuting:
                        using (DB db = new DB())
                        {
                            WorkLeaveService leaveSer = new WorkLeaveService(db);
                            T_Work_Leave appLeave = leaveSer.GetByID(this.ApplyID);

                            applyNo = appLeave.No;
                            approvedLevel = appLeave.ApprovedLevel.Value;
                            applyReason = appLeave.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appLeave.StartHour, appLeave.StartMinute) + " ～ " + EditDataUtil.FixTimeShow(appLeave.EndHour, appLeave.EndMinute);
                        }
                        break;

                    case ApplyType.Absence:
                        using (DB db = new DB())
                        {
                            WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                            T_Work_Absence appAbsence = absenceSer.GetByID(this.ApplyID, true);

                            applyNo = appAbsence.No;
                            approvedLevel = appAbsence.ApprovedLevel;
                            applyReason = appAbsence.Reason;

                            if (appAbsence.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, appAbsence.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString());
                            }
                        }
                        break;

                    default:
                        return ProcessResult.ProcessFail;
                }

                T_Work_Approve apLt = null;
                using (DB db = new DB())
                {
                    WorkApproveService approveSer = new WorkApproveService(db);
                    apLt = approveSer.GetApproveRow(applyNo, this.LoginUser.ID, (int)this.ApplyType);
                }

                if (apLt != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkApproveService approveSer = new WorkApproveService(db);
                        approveSer.Reject(applyNo, apLt.RouteUID, this.LoginUser.ID, (int)StatusHasAprove.Ignore, approveReason);
                        ret = approveSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, (short)StatusApply.Rejected, approvedLevel, this.OldUpdateDate);

                        //delete work apply time
                        WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
                        wrkAppSer.Delete(applyNo);

                        //Check result update
                        if (ret == 0)
                        {
                            //Data change
                            return ProcessResult.DataChanged;
                        }
                        db.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return ProcessResult.ProcessFail;
            }

            try
            {
                this.SendMail(applyNo, this.ApplyType.ToString(), approveUserID, applyReason, effectTime, TypeSettingMail.Reject);
            }
            catch (Exception)
            {
                return ProcessResult.MailFail;
            }

            return ProcessResult.Success;
        }

        #endregion

        #region Remand

        /// <summary>
        /// Back previous level
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        public ProcessResult Remand(string approveReason)
        {
            int approveUserID = this.LoginUser.ID;
            string applyNo = string.Empty;
            int approvedLevel = 0;
            string applyReason = string.Empty;
            string effectTime = string.Empty;
            string type = string.Empty;
            try
            {
                int ret = 0;
                switch (this.ApplyType)
                {
                    case ApplyType.Vacation:
                        using (DB db = new DB())
                        {
                            WorkVacationService vacationSer = new WorkVacationService(db);
                            T_Work_Vacation app = vacationSer.GetByID(this.ApplyID, true);
                            applyNo = app.No;
                            approvedLevel = app.ApprovedLevel;
                            applyReason = app.Reason;

                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, app.VacationType);

                            if (app.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, app.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString());
                            }
                        }
                        break;

                    case ApplyType.OverTime:
                        using (DB db = new DB())
                        {
                            WorkOTService otSer = new WorkOTService(db);
                            T_Work_OT appOT = otSer.GetByID(this.ApplyID, true);
                            applyNo = appOT.No;
                            approvedLevel = appOT.ApprovedLevel;
                            applyReason = appOT.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appOT.OTStartHour, appOT.OTStartMinute) + " ～ " + EditDataUtil.FixTimeShow(appOT.OTEndHour, appOT.OTEndMinute);
                        }
                        break;

                    case ApplyType.LateEarlyOuting:
                        using (DB db = new DB())
                        {
                            WorkLeaveService leaveSer = new WorkLeaveService(db);
                            T_Work_Leave appLeave = leaveSer.GetByID(this.ApplyID);

                            applyNo = appLeave.No;
                            approvedLevel = appLeave.ApprovedLevel.Value;
                            applyReason = appLeave.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appLeave.StartHour, appLeave.StartMinute) + " ～ " + EditDataUtil.FixTimeShow(appLeave.EndHour, appLeave.EndMinute);
                        }
                        break;

                    case ApplyType.Absence:
                        using (DB db = new DB())
                        {
                            WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                            T_Work_Absence appAbsence = absenceSer.GetByID(this.ApplyID, true);

                            applyNo = appAbsence.No;
                            approvedLevel = appAbsence.ApprovedLevel;
                            applyReason = appAbsence.Reason;

                            if (appAbsence.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, appAbsence.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString());
                            }
                        }
                        break;

                    default:
                        return ProcessResult.ProcessFail;
                }

                T_Work_Approve apLt = null;
                using (DB db = new DB())
                {
                    WorkApproveService approveSer = new WorkApproveService(db);
                    apLt = approveSer.GetApproveRow(applyNo, this.LoginUser.ID, (int)this.ApplyType);
                }

                if (apLt != null)
                {
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        WorkApproveService approveSer = new WorkApproveService(db);
                        approveSer.Remand(applyNo, apLt.RouteUID, this.LoginUser.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New, approveReason);
                        ret = approveSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, (short)StatusApply.Approving, approvedLevel - 1, this.OldUpdateDate);

                        //Check result update
                        if (ret == 0)
                        {
                            //data changed
                            return ProcessResult.DataChanged;
                        }
                        db.Commit();
                    }
                }
            }
            catch (Exception ex)
            {
                // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return ProcessResult.ProcessFail;
            }
            try
            {
                this.SendMail(applyNo, this.ApplyType.ToString(), approveUserID, applyReason, effectTime, TypeSettingMail.Remand);
            }
            catch (Exception)
            {
                return ProcessResult.MailFail;
            }

            return ProcessResult.Success;
        }

        #endregion

        #region View After Approved
        /// <summary>
        /// ViewData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public ProcessResult ViewData()
        {
            string applyNo = string.Empty;
            int approvedLevel = 0;
            short applyStatus = 0;
            string applyReason = string.Empty;
            string type = string.Empty;
            string effectTime = string.Empty;
            try
            {
                int ret = 0;
                switch (this.ApplyType)
                {
                    case ApplyType.Vacation:
                        using (DB db = new DB())
                        {
                            WorkVacationService vacationSer = new WorkVacationService(db);
                            T_Work_Vacation app = vacationSer.GetByID(this.ApplyID, true);
                            applyNo = app.No;
                            approvedLevel = app.ApprovedLevel;
                            applyStatus = app.ApplyStatus;
                            applyReason = app.Reason;
                            Config_DService confSer = new Config_DService(db);
                            type = confSer.GetValue2(M_Config_H.CONFIG_CD_VACATION_TYPE, app.VacationType);

                            if (app.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, app.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, app.StartDate.ToString());
                            }
                        }
                        break;

                    case ApplyType.OverTime:
                        using (DB db = new DB())
                        {
                            WorkOTService otSer = new WorkOTService(db);
                            T_Work_OT appOT = otSer.GetByID(this.ApplyID, true);
                            applyNo = appOT.No;
                            approvedLevel = appOT.ApprovedLevel;
                            applyStatus = appOT.ApplyStatus;
                            applyReason = appOT.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appOT.OTStartHour, appOT.OTStartMinute) + " ～ " + EditDataUtil.FixTimeShow(appOT.OTEndHour, appOT.OTEndMinute);
                        }
                        break;

                    case ApplyType.LateEarlyOuting:
                        using (DB db = new DB())
                        {
                            WorkLeaveService leaveSer = new WorkLeaveService(db);
                            T_Work_Leave appLeave = leaveSer.GetByID(this.ApplyID);

                            applyNo = appLeave.No;
                            applyStatus = appLeave.ApplyStatus;
                            approvedLevel = appLeave.ApprovedLevel.Value;
                            applyReason = appLeave.Reason;
                            effectTime = EditDataUtil.FixTimeShow(appLeave.StartHour, appLeave.StartMinute) + " ～ " + EditDataUtil.FixTimeShow(appLeave.EndHour, appLeave.EndMinute);
                        }
                        break;

                    case ApplyType.Absence:
                        using (DB db = new DB())
                        {
                            WorkAbsenceService absenceSer = new WorkAbsenceService(db);
                            T_Work_Absence appAbsence = absenceSer.GetByID(this.ApplyID, true);

                            applyNo = appAbsence.No;
                            applyStatus = appAbsence.ApplyStatus;
                            approvedLevel = appAbsence.ApprovedLevel;
                            applyReason = appAbsence.Reason;

                            if (appAbsence.Duration > 1)
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString()) + "　～　" + string.Format(Constants.FMT_DATE_DPL, appAbsence.EndDate.ToString());
                            }
                            else
                            {
                                effectTime = type + " - " + string.Format(Constants.FMT_DATE_DPL, appAbsence.StartDate.ToString());
                            }
                        }
                        break;

                    default:
                        return ProcessResult.ProcessFail;
                }

                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    WorkApproveService approveSer = new WorkApproveService(db);
                    //Update StatusFlag
                    ret = approveSer.UpdateApplyStatus(this.ApplyType, this.ApplyID, this.LoginUser.ID, applyStatus, approvedLevel, this.OldUpdateDate);
                    if (ret == 1)
                    {
                        approveSer.UpdateApproveStatus(applyNo, (int)StatusHasAprove.Approved, this.LoginUser.ID, string.Empty);
                    }

                    //Check result update
                    if (ret == 0)
                    {
                        //Data is changed
                        return ProcessResult.DataChanged;
                    }
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.WriteLog(ex);
                return ProcessResult.ProcessFail;
            }

            try
            {
                this.SendMail(applyNo, this.ApplyType.ToString(), this.LoginUser.ID, applyReason, effectTime, TypeSettingMail.Read);
            }
            catch (Exception)
            {
                return ProcessResult.MailFail;
            }
            return ProcessResult.Success;
        }

        #endregion

        #region Send mail

        /// <summary>
        /// SendMail
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="empName"></param>
        /// <param name="appType"></param>
        /// <param name="reason"></param>
        /// <param name="mess"></param>
        /// <param name="type"></param>
        private void SendMail(string applyNo, string appType, int routeUID, string reason, string effectTime ,TypeSettingMail type, bool isFinishApprove = false)
        {
            IList<M_User> lstEmail = this.GetListEmail(type, applyNo, routeUID, isFinishApprove);

            StringBuilder mailBody = new StringBuilder();

            IList<string> lstEmailStr = new List<string>();
            foreach (var item in lstEmail)
            {
                lstEmailStr.Add(item.Email);
            }

            if (lstEmail != null && lstEmail.Count > 0)
            {
                mailBody.AppendLine(this.ApplyType.ToString() + " Application");
                mailBody.AppendLine("------------ooo------------");
                mailBody.AppendLine("ApplyNo       : " + applyNo);
                mailBody.AppendLine("");
                mailBody.AppendLine("Applicant     : " + this.Staff.DepartmentName);
                mailBody.AppendLine("                " + this.Staff.StaffName);
                mailBody.AppendLine("");                                                                

                switch (type)
                {
                    case TypeSettingMail.Reject:
                        mailBody.AppendLine("Rejected By   : " + this.LoginUser.UserName2);
                        break;
                    case TypeSettingMail.Remand:
                        mailBody.AppendLine("Remandes By   : " + this.LoginUser.UserName2);
                        break;
                    case TypeSettingMail.Approve:
                        mailBody.AppendLine("Approved By   : " + this.LoginUser.UserName2);
                        break;
                    case TypeSettingMail.Read:
                        mailBody.AppendLine("Viewer By     : " + this.LoginUser.UserName2);
                        break;
                    default:
                        break;
                }

                mailBody.AppendLine("");
                mailBody.AppendLine("Reason        : " + reason);
                mailBody.AppendLine("---------------------------");
                if (isFinishApprove)
                {
                    mailBody.AppendLine("This application form has been completed.");
                    mailBody.AppendLine("---------------------------");
                }              

                string subject = "[WORKFLOW] : " + this.ApplyType.ToString() + " Application";

                CommonUtil.Sending_Email(lstEmailStr.ToArray(), subject, mailBody);
            }
        }

        /// <summary>
        /// GetListEmail
        /// </summary>
        /// <param name="type"></param>
        /// <param name="isFinishApprove"></param>
        /// <returns></returns>
        //private IList<string> GetListEmail(TypeSettingMail type, int applyID, int routeUID, bool isFinishApprove = false)
        private IList<M_User> GetListEmail(TypeSettingMail type, string applyNo, int routeUID, bool isFinishApprove = false)
        {
            //IList<string> lstEmail = new List<string>();
            IList<M_User> lstEmail = new List<M_User>();
            //------------ISV-HUNG 2015/07/02 - Add using DB----------------//
            using (DB db = new DB())
            {
                WorkApproveService approveSer = new WorkApproveService(db);
                T_Work_Approve applicantInfoList = approveSer.GetByKey(applyNo, routeUID);

                if (applicantInfoList != null)
                {
                    switch (type)
                    {
                        case TypeSettingMail.Reject:
                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Remand:
                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Approve:
                            if (isFinishApprove)
                            {
                                return approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
                            }
                            //Next
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
                            }
                            else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
                            }
                            //Previous
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            //sender
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            //current
                            if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;

                        case TypeSettingMail.Read:
                            if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
                            }
                            else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
                            {
                                lstEmail = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
                            }

                            if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }

                            if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
                            {
                                var lstTemp = approveSer.GetListEmailByLevelAproveTest(applyNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
                                ((List<M_User>)lstEmail).AddRange(lstTemp);
                            }
                            break;
                    }
                }
                return lstEmail;
            }
        }

        #endregion
    }
}
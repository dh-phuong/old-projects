﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;
using System.Text;

namespace DailyReport.Approve
{
    public partial class FrmWorkLeaveApproveDetail : FrmBaseDetail
    {
        #region Constants

        private const string URL_LIST = "~/Approve/FrmApproveList.aspx";
        public const int DEFAULT_VALUE = -1;

        #endregion

        #region Variable

        /// <summary>
        /// isApproved
        /// </summary>
        public bool isApproved;

        /// <summary>
        /// isDisablePrevBack
        /// </summary>
        public bool isDisablePrevBack;

        /// <summary>
        /// 2015/04/20 ISV-TRUC
        /// </summary>
        public bool isDispApproveButton;
        public bool isDispViewButton;
        public bool isDispIgnoreButton;
        public bool isShowPrevBackButton;
        #endregion

        #region Property

        /// <summary>
        /// Get or set ApplyID
        /// </summary>
        public int ApplyID
        {
            get { return (int)ViewState["ApplyID"]; }
            set { ViewState["ApplyID"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }


        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }


        /// <summary>
        /// Is Inspected : đã xem xét (approve, remaind)
        /// </summary>
        public bool IsInspected
        {
            get { return (bool)ViewState["IsInspected"]; }
            set { ViewState["IsInspected"] = value; }
        }

        /// <summary>
        /// Is penalized(Bi tru phep nam)
        /// </summary>
        public bool IsPenalized
        {
            get { return (bool)ViewState["IsPenalized"]; }
            set { ViewState["IsPenalized"] = value; }
        }
        #endregion

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Late Work / Early Leave";
            base.FormSubTitle = "";

            //Init Max Length                        
            this.txtApproveReason.MaxLength = T_Work_Approve.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyApprove);
            if (!this._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init Data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        base.RedirectUrl(URL_LIST);
                    }
                    else
                    {
                        //Get User ID
                        this.ApplyID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_Leave data = this.GetApplyByID(this.ApplyID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    base.RedirectUrl(URL_LIST);
                }

                this.InitTimesDetail();
            }

            //Set init
            this.Success = false;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Ignore);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnView Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                if (this.ViewData(apply))
                {
                    Server.Transfer(URL_LIST);
                }
                else
                {
                    this.LoadDataForChangedData();
                    this.ProcessMode(Mode.View);
                }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Work_Leave apply = this.GetApplyByID(this.ApplyID);
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.BackPre);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }

        }

        /// <summary>
        /// Submit Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.btnProcessData(sender, e);
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Approve:
                    if (this.Approve())
                    {
                        this.ShowData(this.GetApplyByID(this.ApplyID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    break;

                case Utilities.Mode.Ignore:
                    if (this.Reject((short)StatusApply.Rejected))
                    {

                        this.ShowData(this.GetApplyByID(this.ApplyID));
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    if (this.Remand((short)StatusApply.Approving))
                    {

                        this.ShowData(this.GetApplyByID(this.ApplyID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    break;
            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            T_Work_Leave data = this.GetApplyByID(this.ApplyID);
            if (this.Mode == Utilities.Mode.View)
            {
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                this.LoadDataForApproveList(this.txtApplyNo.Value, true);
            }

        }

        #endregion

        #region Methods

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.IsInspected = false;
            this.InitDataForRoute(this.cmbRoute, M_Config_D.TEMPLATE_FORM_LEAVE, this.LoginInfo.User.ID);

            this.InitTimesHeader();

            this.btnViewPreVacation.Text = string.Empty;
        }

        /// <summary>
        /// InitTimesHeader
        /// </summary>
        private void InitTimesHeader()
        {
            IList<string> lstMonthName = new List<string>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                lstMonthName = accSer.GetListMonthName();
            }

            this.rptLateH.DataSource = lstMonthName;
            this.rptLateH.DataBind();
            //--------------
            this.rptEarlyH.DataSource = lstMonthName;
            this.rptEarlyH.DataBind();
            //--------------
            this.rptOutH.DataSource = lstMonthName;
            this.rptOutH.DataBind();
        }

        private void InitTimesDetail()
        {
            AccountingPeriod _acc = new AccountingPeriod();
            IList<WorkLeaveDay> lst = new List<WorkLeaveDay>();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                WorkLeaveService leaveSr = new WorkLeaveService(db);
                _acc = accSer.GetAccountingYear(DateTime.Now.Date);
                lst = leaveSr.GetListMonthAccounting(this.txtEmployeeCD.Value, _acc.StartDate, _acc.EndDate);                
            }

            this.rptLateD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Late, lst, _acc);
            this.rptLateD.DataBind();
            //--------------
            this.rptEarlyD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Early, lst, _acc);
            this.rptEarlyD.DataBind();
            //--------------
            this.rptOutD.DataSource = this.GetListMonthValue((int)TypeWorkLeave.Out, lst, _acc);
            this.rptOutD.DataBind();
        }

        private List<string> GetListMonthValue(int type, IList<WorkLeaveDay> lstDay, AccountingPeriod period)
        {
            M_Accounting m_acc = new M_Accounting();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                m_acc = accSer.GetData();
            }
           
             

            List<string> lstTmp = new List<string>();
            DateTime dtTmp = lstDay[0].WorkDate;
            TimeSpan timeTmp = TimeSpan.Zero;

            for (int i = 0; i < 12; i++)
            {
                AccountingPeriod periodM = new AccountingPeriod();
                using (DB db = new DB())
                {
                    AccountingService accSer = new AccountingService(db);
                    periodM = accSer.GetAccountingMonth(period.StartDate.AddMonths(i), m_acc.ClosingDay);
                }
                foreach (var item in lstDay.Where(m => m.WorkDate >= periodM.StartDate && m.WorkDate <= periodM.EndDate && m.Type == type))
                {
                    timeTmp = timeTmp.Add(item.Duration);
                }

                if (timeTmp != TimeSpan.Zero)
                {
                    lstTmp.Add(EditDataUtil.FixTimeShow(timeTmp.Hours, timeTmp.Minutes));
                }
                else
                {
                    lstTmp.Add("&nbsp;");
                }

                timeTmp = TimeSpan.Zero;
            }

            return lstTmp;
        }


        /// <summary>
        /// GetListApprovePerson
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprovePerson(int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
                Route_DService service = new Route_DService(db);
                approveUserList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
                return approveUserList;
            }
        }


        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            if (list != null && list.Count > 0)
            {
                this.GetListApprovePerson(int.Parse(this.cmbRoute.SelectedValue), true);
            }
            else
            {
                this.GetListApprovePerson(DEFAULT_VALUE, true);
            }
        }

        #region check data

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApproved(IList<WorkApproveModel> applyList)
        {
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = (from app in applyList
                           where ((app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.BackPrev) || app.ApproveStatus == (short)StatusHasAprove.Ignore)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Approve

        /// <summary>
        /// GetUserByID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_User GetUserByID(int ID)
        {
            using (DB db = new DB())
            {
                UserService uSer = new UserService(db);
                return uSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Approve()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.ApplyID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.LateEarlyOuting, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Approve(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region Reject
        /// <summary>
        /// Reject
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Reject(short applyStatus)
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.ApplyID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.LateEarlyOuting, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Reject(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #endregion

        #region View After Approved
        /// <summary>
        /// ViewData
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        private bool ViewData(T_Work_Leave apply)
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.ApplyID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.LateEarlyOuting, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.ViewData();
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region Remand

        /// <summary>
        /// Back previous level
        /// </summary>
        /// <param name="app"></param>
        /// <param name="applyStatus"></param>
        /// <returns></returns>
        private bool Remand(short applyStatus)
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.ApplyID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.LateEarlyOuting, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Remand(this.txtApproveReason.Text);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.NotEnoughAnnualDays:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_ANNUAL_DAY_NOT_ENOUGH);
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }

            return ret;
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private T_Work_Leave GetApplyByID(int id)
        {
            T_Work_Leave apply = new T_Work_Leave();
            using (DB db = new DB())
            {
                WorkLeaveService appSer = new WorkLeaveService(db);
                apply = appSer.GetByID(id);
            }
            return apply;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(bool isIncludeView = false)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.txtApplyNo.Value, isGetViewLevel: isIncludeView);
            }
        }

        /// <summary>
        /// Clear Update Info
        /// </summary>
        private void ClearUpdateInfo()
        {
            this.txtUpdateDate.Value = string.Empty;
            this.txtCreateDate.Value = string.Empty;
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        private void LoadDataForApproveList(string applyNo, bool isIncludeView = false)
        {
            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
            approverList = this.GetListApproveUserFromApply(isIncludeView);

            if (approverList != null && approverList.Count != 0)
            {
                this.ApproverList = new List<WorkApproveModel>(approverList);
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();
            this.isApproved = false;
        }

        /// <summary>
        /// 
        /// </summary>
        private void LoadDataForChangedData()
        {
            this.InitTimesDetail();
            IList<WorkApproveModel> applyLst = new List<WorkApproveModel>(this.ApproverList);
            if (applyLst != null)
            {
                this.rptApproverList.DataSource = applyLst;
            }
            else
            {
                this.rptApproverList.DataSource = null;
            }

            this.rptApproverList.DataBind();

        }

        #endregion

        #region Set data

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            this.dtDuration.SetReadOnly(true);
            //Check model
            switch (mode)
            {
                case Mode.Approve:
                case Mode.Ignore:
                case Mode.BackPre:
                    this.txtApproveReason.SetReadOnly(false);
                    break;

                default:
                    string onclick = "gotoApprovedForm(" + M_Config_D.TEMPLATE_FORM_LEAVE + "," + this.PreApplyID + ") ; return false;";
                    this.btnViewPreVacation.Attributes.Add("onclick", onclick);

                    this.txtEmployeeCD.SetReadOnly(true);
                    this.dtApplyDate.SetReadOnly(true);
                    this.dtDateFrom.SetReadOnly(true);
                    this.dtDateTo.SetReadOnly(true);
                    this.dtEffect.Enabled = false;
                    this.optEarly.Disabled = true;
                    this.optLate.Disabled = true;
                    this.optOut.Disabled = true;
                    this.cmbRoute.Enabled = false;
                    this.txtApplyReason.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(true);
                    
                    if (this.PreApplyID.HasValue)
                    {
                        T_Work_Leave preApp = new T_Work_Leave();
                        using (DB db = new DB())
                        {
                            WorkLeaveService ser = new WorkLeaveService(db);
                             preApp = ser.GetByID(this.PreApplyID.Value);

                        }
                        if (preApp != null)
                        {
                            this.btnViewPreVacation.Text = preApp.No;
                            this.PreApplyID = preApp.ID;
                        }
                        this.txtReasonCancel.SetReadOnly(true);
                        
                    }
                    if (this.isApproved)
                    {
                        base.DisabledLink(this.btnApprove, true);
                        base.DisabledLink(this.btnIgnore, true);
                        base.DisabledLink(this.btnPrevBack, true);
                    }
                    else
                    {
                        base.DisabledLink(this.btnApprove, !base._authority.IsApplyApproveApprove);
                        base.DisabledLink(this.btnIgnore, !base._authority.IsApplyApproveIgnore);

                        if (this.isDisablePrevBack)
                        {
                            base.DisabledLink(this.btnPrevBack, true);
                        }
                        else
                        {
                            base.DisabledLink(this.btnPrevBack, !base._authority.IsApplyApproveReBack);
                        }
                    }
                    break;
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Work_Leave apply)
        {
            //Show data
            if (apply != null)
            {
                //-------------------
                this.txtApplyNo.Value = apply.No;
                this.dtApplyDate.Value = apply.ApplyDate;
                //-------------------
                this.dtEffect.Value = apply.EffectDate;
                //-------------------
                this.dtDateFrom.SetTimeValue(apply.StartHour, apply.StartMinute);
                this.dtDateTo.SetTimeValue(apply.EndHour, apply.EndMinute);
                //------------------------------
                if (apply.Type == (int)TypeWorkLeave.Late)
                {
                    this.optLate.Checked = true;
                }
                //-------------------
                if (apply.Type == (int)TypeWorkLeave.Early)
                {
                    this.optEarly.Checked = true;
                }
                //-------------------
                if (apply.Type == (int)TypeWorkLeave.Out)
                {
                    this.optOut.Checked = true;
                }
                //-------------------      
                this.dtDuration.Text = EditDataUtil.FixTimeShow(apply.DurationHour, apply.DurationMinute , true);
                //-------------------      
                this.InitDataForRoute(this.cmbRoute, M_Config_D.TEMPLATE_FORM_LEAVE, apply.UserID);
                this.cmbRoute.SelectedValue = apply.RouteID.ToString();

                //-------------------
                T_Work_Approve appLst = new T_Work_Approve();
                M_StaffInfo m_staff = new M_StaffInfo();
                using (DB db = new DB())
                {
                    WorkApproveService appSer = new WorkApproveService(db);
                    StaffService _staffService = new StaffService(db);
                    appLst = appSer.GetByKey(apply.No, this.LoginInfo.User.ID);
                     m_staff = _staffService.GetStaffInfoByUserID(apply.UserID);
                }

                if (appLst != null)
                {
                    this.IsInspected = appLst.ApproveStatus != (int)StatusHasAprove.New;
                }
                //---------------------
                if (m_staff != null)
                {
                    this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(m_staff.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                    this.txtEmployeeNm.Value = m_staff.StaffName;

                    this.txtDepartment.Value = m_staff.DepartmentName;
                    this.txtPosition.Value = m_staff.Position;
                }

                //---------------------
                this.txtApproveReason.Value = string.Empty;
                //---------------------
                this.ApplyID = apply.ID;
                this.ApplyStatus = apply.ApplyStatus;
                this.PreApplyID = apply.PreApplyID;
                //---------------------
                
                if (this.PreApplyID.HasValue)
                {
                    T_Work_Leave preApp = new T_Work_Leave();
                    using (DB db = new DB())
                    {
                        WorkLeaveService ser = new WorkLeaveService(db);
                        preApp = ser.GetByID(this.PreApplyID.Value);
                    }
                    if (preApp != null)
                    {
                        this.txtApplyReason.Value = preApp.Reason;
                        this.txtReasonCancel.Value = apply.Reason;
                        this.btnViewPreVacation.Text = preApp.No;
                        this.PreApplyID = preApp.ID;
                    }
                }
                else
                {
                    this.txtApplyReason.Value = apply.Reason;
                }
                //---------------------
                M_User createUser = new M_User();
                M_User updateUser = new M_User();
                using (DB db = new DB())
                {
                    UserService userSer = new UserService(db);
                    createUser = userSer.GetByID(apply.CreateUID);
                    updateUser = userSer.GetByID(apply.UpdateUID);
                }
                
                if (createUser != null)
                {
                    var createDate = apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    var updateDate = apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }

                //---------------------
                this.GetListApprovePerson(apply.RouteID, true);
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveList(this.txtApplyNo.Value, true);

                T_Work_Approve workApprove = null;
                using (DB db = new DB())
                {
                    WorkApproveService appLstSer = new WorkApproveService(db);
                    workApprove = appLstSer.GetApproveRow(this.txtApplyNo.Value, this.LoginInfo.User.ID, (int)ApplyType.LateEarlyOuting);
                }
                this.isDispApproveButton = this.IsDisplayApproveButton(workApprove);
                this.isDispIgnoreButton = this.IsDisplayIgnoreButton(workApprove);
                this.isShowPrevBackButton = this.IsDisplayPreBackButton(workApprove);
                this.isDispViewButton = this.IsDisplayViewButton(workApprove);

                this.InitTimesDetail();
            }
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayApproveButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }

                return true;
            }
            return false;
        }

        /// <summary>
        /// IsDisplayViewButton
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayViewButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel != 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved && workApp.GetReadSetting(ReadSetting.ReadAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayIgnoreButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }
                if (workApp.GetRejectSetting(RejectSetting.RejectAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayPreBackButton(T_Work_Approve workApp)
        {
            using (DB db = new DB())
            {
                WorkApproveService appLstSer = new WorkApproveService(db);
                if (workApp != null)
                {
                    if (workApp.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                    if (workApp.GetRemandSetting(RemandSetting.RemandAuthor) && appLstSer.CheckApproveIsFinishLevel(workApp.ApplyNo, workApp.RouteLevel - 1))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        #endregion

        #region Web Methods
        /// <summary>
        /// GetTypeVacation
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string GetTypeVacation(string type)
        {
            try
            {
                if (string.IsNullOrEmpty(type))
                {
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                }
                int typeID = int.Parse(type);
                using (DB db = new DB())
                {
                    WorkShiftService wrkSer = new WorkShiftService(db);
                    M_Work_Shift wk = wrkSer.GetByID(typeID);
                    if (wk != null)
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(wk.TypeOfDay);
                    }
                    else
                    {
                        return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(null);
                    }
                }

            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}
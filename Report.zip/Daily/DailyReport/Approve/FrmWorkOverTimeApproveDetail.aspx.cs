﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.Models;
using DailyReport.Utilities;
using DailyReport.DAC;
using System.Globalization;
using System.Text;

namespace DailyReport.Approve
{
    public partial class FrmWorkOverTimeApproveDetail : FrmBaseDetail
    {
        #region Constants

        private const string URL_LIST = "~/Approve/FrmApproveList.aspx";
        private const string APPLY_INFO = "This apply is cancellation of";
        private readonly DateTime DEFAULT_DATE_TIME = new DateTime(1900, 1, 1);
        public const decimal ZERO_DEC = 0m;
        public const int DEFAULT_VALUE = -1;

        #endregion

        #region Variable

        /// <summary>
        /// 2015/03/19
        /// color Status
        /// </summary>
        public string colorStatus;

        /// <summary>
        /// 2015/03/19
        /// name of Status
        /// </summary>
        public string statusNameLbl;

        /// <summary>
        /// isApproveUser
        /// </summary>
        public bool isApproveUser;

        /// <summary>
        /// isApproved
        /// </summary>
        public bool isApproved;

        /// <summary>
        /// isDisablePrevBack
        /// </summary>
        public bool isDisablePrevBack;

        /// <summary>
        /// isHasData
        /// </summary>
        public bool isHasData;

        /// <summary>
        /// 
        /// </summary>
        //public string lblApplyInfo = APPLY_INFO;

        /// <summary>
        /// 2015/04/20 ISV-NHAT
        /// </summary>
        public bool isDispApproveButton;
        public bool isDispViewButton;
        public bool isDispIgnoreButton;
        public bool isShowPrevBackButton;
        #endregion

        #region Property

        /// <summary>
        /// Outing row count
        /// </summary>
        public bool PreCalWorkTime
        {
            get { return (bool)ViewState["PreCalWorkTime"]; }
            set { ViewState["PreCalWorkTime"] = value; }
        }

        /// <summary>
        /// Get or set DataID
        /// </summary>
        public int DataID
        {
            get { return (int)ViewState["DataID"]; }
            set { ViewState["DataID"] = value; }
        }


        /// <summary>
        /// Get or set ApplyUserID
        /// </summary>
        public int ApplyUserID
        {
            get { return (int)ViewState["ApplyUserID"]; }
            set { ViewState["ApplyUserID"] = value; }
        }

        /// <summary>
        /// Get or set DataNo
        /// </summary>
        public string DataNo
        {
            get { return (string)ViewState["DataNo"]; }
            set { ViewState["DataNo"] = value; }
        }

        /// <summary>
        /// Get or set ApplyStatus
        /// </summary>
        public short ApplyStatus
        {
            get { return (short)ViewState["ApplyStatus"]; }
            set { ViewState["ApplyStatus"] = value; }
        }

        /// <summary>
        /// Get or set CreateUserCD
        /// </summary>
        public string CreateUserCD
        {
            get { return (string)ViewState["CreateUserCD"]; }
            set { ViewState["CreateUserCD"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyNo
        /// </summary>
        public string PreApplyNo
        {
            get { return (string)ViewState["PreApplyNo"]; }
            set { ViewState["PreApplyNo"] = value; }
        }

        /// <summary>
        /// Get or set PreApplyID
        /// </summary>
        public int? PreApplyID
        {
            get
            {
                if (ViewState["PreApplyID"] != null)
                {
                    return (int)ViewState["PreApplyID"];
                }
                else
                {
                    return null;
                }
            }

            set { ViewState["PreApplyID"] = value; }
        }


        /// <summary>
        /// ApproverList
        /// </summary>
        private IList<WorkApproveModel> ApproverList
        {
            get { return (IList<WorkApproveModel>)ViewState["ApproverList"]; }
            set { ViewState["ApproverList"] = value; }
        }


        /// <summary>
        /// Is Inspected : đã xem xét (approve, remaind)
        /// </summary>
        public bool IsInspected
        {
            get { return (bool)ViewState["IsInspected"]; }
            set { ViewState["IsInspected"] = value; }
        }

        /// <summary>
        /// Is penalized(Bi tru phep nam)
        /// </summary>
        public bool IsPenalized
        {
            get { return (bool)ViewState["IsPenalized"]; }
            set { ViewState["IsPenalized"] = value; }
        }
        #endregion

        #region check data

        /// <summary>
        /// Checking LoginUser has approved or not yet.
        /// </summary>
        /// <param name="applyList"></param>
        /// <returns></returns>
        private bool IsApproved(IList<WorkApproveModel> applyList)
        {
            string loginUserCD = Utilities.EditDataUtil.ToFixCodeShow(LoginInfo.User.UserCD, M_User.MAX_USER_CODE_SHOW);
            IList<WorkApproveModel> approveList = new List<WorkApproveModel>();
            approveList = (from app in applyList
                           where ((app.RouteUID == LoginInfo.User.ID || loginUserCD == this.txtEmployeeCD.Value) && (app.ApproveStatus == (short)StatusHasAprove.Approved || app.ApproveStatus == (short)StatusHasAprove.BackPrev) || app.ApproveStatus == (short)StatusHasAprove.Ignore)
                           select app).ToList();


            if (approveList != null && approveList.Count > 0)
            {
                return true;

            }
            else
            {
                return false;
            }
        }

        #endregion

        #region Approve

        /// <summary>
        /// GetUserByID
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        private M_User GetUserByID(int ID)
        {
            using (DB db = new DB())
            {
                UserService uSer = new UserService(db);
                return uSer.GetByID(ID);
            }
        }

        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Approve()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.OverTime, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Approve(this.txtApproveReason.Value);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }

        #endregion

        #region Remand

        /// <summary>
        /// Remand
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Remand()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.OverTime, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Remand(this.txtApproveReason.Value);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }


        ///// <summary>
        ///// Back previous level
        ///// </summary>
        ///// <param name="app"></param>
        ///// <param name="applyStatus"></param>
        ///// <returns></returns>
        //private bool Remand(short applyStatus)
        //{
        //    int approveUserID = this.LoginInfo.User.ID;
        //    bool success = false;
        //    try
        //    {
        //        using (DB db = new DB(System.Data.IsolationLevel.Serializable))
        //        {
        //            int ret = 0;
        //            WorkOTService service = new WorkOTService(db);
        //            T_Work_OT app = service.GetByID(this.DataID);
        //            if (app != null)
        //            {
        //                WorkApproveService approveSer = new WorkApproveService(db);
        //                T_Work_Approve apLt = approveSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID, (int)ApplyType.OverTime);
        //                if (apLt != null)
        //                {
        //                    //1:Update ApproveStatus for the login user 
        //                    //2:Update New status of the approved users have level = the login user's level or level= the login user's level-1

        //                    ret = approveSer.Remand(this.DataNo, apLt.RouteUID, this.LoginInfo.User.ID, (short)StatusHasAprove.BackPrev, (short)StatusHasAprove.New, this.txtApproveReason.Value);
        //                    ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, app.ApprovedLevel > 1 ? (app.ApprovedLevel - 1) : 0, this.OldUpdateDate);

        //                    //Check result update
        //                    if (ret == 0)
        //                    {
        //                        //data changed
        //                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
        //                        return false;
        //                    }
        //                    /* else
        //                     {
        //                         ApplyApproveListService approveListSer = new ApplyApproveListService(db);
        //                         T_Apply_Approve_List appr = approveListSer.GetByKey2(this.DataID, this.LoginInfo.User.ID);
        //                         IList<string> lstEmail = approveListSer.GetListEmailByLevelRemand2(this.DataID, appr.RouteLevel - 1);
        //                         StringBuilder mailBody = new StringBuilder();
        //                         if (lstEmail.Count > 0)
        //                         {
        //                             mailBody.AppendLine("ApplyNo: " + this.txtApplyNo.Value);
        //                             mailBody.AppendLine("User: " + this.txtEmployeeNm.Value);
        //                             mailBody.AppendLine("Type: " + this.cmbApplyType.SelectedItem.Text);
        //                             mailBody.AppendLine("Reason: " + this.txtReason.Text);
        //                             mailBody.AppendLine("Remain By: " + this.LoginInfo.User.UserName2);

        //                             CommonUtil.Sending_Email(lstEmail.ToArray(), "Has remain apply", mailBody);
        //                         }
        //                     }*/
        //                    db.Commit();
        //                    success = true;
        //                    this.IsInspected = true;
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
        //        // LoadDataGrid();
        //        Log.Instance.WriteLog(ex);

        //        return false;
        //    }
        //    try
        //    {
        //        //Send mail
        //        if (success)
        //        {
        //            string mess = "I have remanded.";
        //            this.SendMail(approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Remand);
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
        //        return true;
        //    }

        //    return true;
        //}

        #endregion

        #region Reject

        /// <summary>
        /// Remand
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool Reject()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.OverTime, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.Reject(this.txtApproveReason.Value);
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }

        ///// <summary>
        ///// Reject
        ///// </summary>
        ///// <param name="app"></param>
        ///// <param name="applyStatus"></param>
        ///// <returns></returns>
        //private bool Reject(short applyStatus)
        //{
        //    bool success = false;
        //    int approveUserID = this.LoginInfo.User.ID;
        //    try
        //    {
        //        using (DB db = new DB(System.Data.IsolationLevel.Serializable))
        //        {
        //            int ret = 0;
        //            WorkApproveService approveSer = new WorkApproveService(db);
        //            T_Work_Approve apLt = approveSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID, (int)ApplyType.OverTime);
        //            if (apLt != null)
        //            {
        //                approveUserID = apLt.RouteUID;
        //                ret = approveSer.Reject(this.DataNo, apLt.RouteUID, this.LoginInfo.User.ID, (int)StatusHasAprove.Ignore, this.txtApproveReason.Value);
        //                WorkOTService service = new WorkOTService(db);
        //                //Update StatusFlag
        //                //Chua co level nao duoc duyet nen approve level = 0
        //                ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, applyStatus, 0, this.OldUpdateDate);
        //                WorkApplyTimeService wrkAppSer = new WorkApplyTimeService(db);
        //                wrkAppSer.Delete(this.DataNo);
        //                //Check result update
        //                if (ret == 0)
        //                {
        //                    //du lieu da thay doi
        //                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
        //                    return false;
        //                }
        //                db.Commit();
        //                success = true;
        //                this.IsInspected = true;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
        //        // LoadDataGrid();
        //        Log.Instance.WriteLog(ex);

        //        return false;
        //    }

        //    try
        //    {
        //        //Send mail
        //        if (success)
        //        {
        //            string mess = "I have rejected.";
        //            this.SendMail(approveUserID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Reject);
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
        //        return true;
        //    }

        //    return true;
        //}

        #endregion

        #region Send mail

        ///// <summary>
        ///// GetListEmail
        ///// </summary>
        ///// <param name="type"></param>
        ///// <param name="isFinishApprove"></param>
        ///// <returns></returns>
        ////private IList<string> GetListEmail(TypeSettingMail type, int applyID, int routeUID, bool isFinishApprove = false)
        //private IList<M_User> GetListEmail(TypeSettingMail type, string applyNo, int routeUID, bool isFinishApprove = false)
        //{
        //    //IList<string> lstEmail = new List<string>();
        //    IList<M_User> lstEmail = new List<M_User>();
        //    WorkApproveService approveSer = new WorkApproveService();
        //    T_Work_Approve applicantInfoList = approveSer.GetByKey(applyNo, routeUID);

        //    if (applicantInfoList != null)
        //    {
        //        #region Comment <-> Right
        //        //switch (type)
        //        //{
        //        //    case TypeSettingMail.Reject:
        //        //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //        //        }
        //        //        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //        //        }

        //        //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }

        //        //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }

        //        //        if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        break;

        //        //    case TypeSettingMail.Remand:
        //        //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //        //        }
        //        //        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //        //        }

        //        //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }

        //        //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }

        //        //        if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        break;

        //        //    case TypeSettingMail.Approve:
        //        //        if (isFinishApprove)
        //        //        {
        //        //            return approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
        //        //        }
        //        //        //Next
        //        //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //        //        }
        //        //        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //        //        }
        //        //        //Previous
        //        //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        //sender
        //        //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        //current
        //        //        if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        break;

        //        //    case TypeSettingMail.Read:
        //        //        if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //        //            return lstEmail;
        //        //        }
        //        //        else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
        //        //        {
        //        //            lstEmail = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //        //        }

        //        //        if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }

        //        //        if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
        //        //        {
        //        //            var lstTemp = approveSer.GetListEmailByLevelAprove2(this.DataID, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //        //            ((List<string>)lstEmail).AddRange(lstTemp);
        //        //        }
        //        //        break;
        //        //}
        //        #endregion

        //        #region Test
        //        switch (type)
        //        {
        //            case TypeSettingMail.Reject:
        //                if (applicantInfoList.GetRejectSetting(RejectSetting.MailNextAll))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //                }
        //                else if (applicantInfoList.GetRejectSetting(RejectSetting.MailNext))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //                }

        //                if (applicantInfoList.GetRejectSetting(RejectSetting.MailPreAll))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                else if (applicantInfoList.GetRejectSetting(RejectSetting.MailPre))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }

        //                if (applicantInfoList.GetRejectSetting(RejectSetting.MailAppliciant))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }

        //                if (applicantInfoList.GetRejectSetting(RejectSetting.MailCurrentLevel))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                break;

        //            case TypeSettingMail.Remand:
        //                if (applicantInfoList.GetRemandSetting(RemandSetting.MailNextAll))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //                }
        //                else if (applicantInfoList.GetRemandSetting(RemandSetting.MailNext))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //                }

        //                if (applicantInfoList.GetRemandSetting(RemandSetting.MailPreAll))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                else if (applicantInfoList.GetRemandSetting(RemandSetting.MailPre))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }

        //                if (applicantInfoList.GetRemandSetting(RemandSetting.MailCurrentLevel))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }

        //                if (applicantInfoList.GetRemandSetting(RemandSetting.MailAppliciant))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                break;

        //            case TypeSettingMail.Approve:
        //                if (isFinishApprove)
        //                {
        //                    return approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.ReaderLevel);
        //                }
        //                //Next
        //                if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNextAll))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.GreaterLevel);
        //                }
        //                else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailNext))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.NextLevel);
        //                }
        //                //Previous
        //                if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPreAll))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                else if (applicantInfoList.GetApproveSetting(ApproveSetting.MailPre))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                //sender
        //                if (applicantInfoList.GetApproveSetting(ApproveSetting.MailAppliciant))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                //current
        //                if (applicantInfoList.GetApproveSetting(ApproveSetting.MailCurrentLevel))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                break;

        //            case TypeSettingMail.Read:
        //                if (applicantInfoList.GetReadSetting(ReadSetting.MailPreAll))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.LessLevel);
        //                }
        //                else if (applicantInfoList.GetReadSetting(ReadSetting.MailPre))
        //                {
        //                    lstEmail = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.PreviousLevel);
        //                }

        //                if (applicantInfoList.GetReadSetting(ReadSetting.MailAppliciant))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.Applicant);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }

        //                if (applicantInfoList.GetReadSetting(ReadSetting.MailGroup))
        //                {
        //                    var lstTemp = approveSer.GetListEmailByLevelAproveTest(this.DataNo, applicantInfoList.RouteLevel, (short)SendMailMode.CurrentLevel, routeUID);
        //                    ((List<M_User>)lstEmail).AddRange(lstTemp);
        //                }
        //                break;
        //        }
        //        #endregion
        //    }
        //    return lstEmail;
        //}

        ///// <summary>
        ///// SendMail
        ///// </summary>
        ///// <param name="applyNo"></param>
        ///// <param name="empName"></param>
        ///// <param name="appType"></param>
        ///// <param name="reason"></param>
        ///// <param name="mess"></param>
        ///// <param name="type"></param>
        //private void SendMail(int routeUID, string applyNo, string empName, string appType, string reason, string mess, TypeSettingMail type, bool isFinishApprove = false)
        //{
        //    // IList<string> lstEmail = this.GetListEmail(type, applyID, routeUID, isFinishApprove);
        //    if (isFinishApprove)
        //    {
        //        this.SendMail(routeUID, applyNo, empName, appType, reason, mess, type);
        //    }
        //    IList<M_User> lstEmail = this.GetListEmail(type, applyNo, routeUID, isFinishApprove);

        //    StringBuilder mailBody = new StringBuilder();

        //    #region Test
        //    IList<string> lstEmailStr = new List<string>();
        //    IList<string> lstUserStr = new List<string>();
        //    foreach (var item in lstEmail)
        //    {
        //        lstEmailStr.Add(item.Email);
        //        lstUserStr.Add(string.Format("{0} {1}", EditDataUtil.ToFixCodeShow(item.UserCD, M_User.MAX_USER_CODE_SHOW), item.UserName2));
        //    }
        //    #endregion


        //    if (lstEmail != null && lstEmail.Count > 0)
        //    {
        //        mailBody.AppendLine("All mail: " + lstEmail.Count);
        //        mailBody.AppendLine("ApplyNo: " + applyNo);
        //        mailBody.AppendLine("User: " + empName);
        //        mailBody.AppendLine("Type: " + appType);
        //        mailBody.AppendLine("Reason: " + reason);
        //        mailBody.AppendLine("All user received: ");
        //        foreach (var it in lstUserStr)
        //        {
        //            mailBody.AppendLine(string.Format("● {0}", it));
        //        }
        //        switch (type)
        //        {
        //            case TypeSettingMail.Reject:
        //                mailBody.AppendLine("Rejected By: " + this.LoginInfo.User.UserName2);
        //                break;
        //            case TypeSettingMail.Remand:
        //                mailBody.AppendLine("Remanded By: " + this.LoginInfo.User.UserName2);
        //                break;
        //            case TypeSettingMail.Approve:
        //                mailBody.AppendLine("Approved By: " + this.LoginInfo.User.UserName2);
        //                break;
        //            case TypeSettingMail.Read:
        //                mailBody.AppendLine("Viewer By: " + this.LoginInfo.User.UserName2);
        //                break;
        //            default:
        //                break;
        //        }

        //        string sSubject = string.Empty;
        //        if (isFinishApprove)
        //        {
        //            sSubject = "This application form has been completed.";
        //        }
        //        else
        //        {
        //            //if (lstEmail.Count == 1)
        //            //{
        //            //    sSubject = string.Format(mess, "is", lstEmail.Count);
        //            //}
        //            //else
        //            //{
        //            //    sSubject = string.Format(mess, "are", lstEmail.Count);
        //            //}
        //            sSubject = mess;
        //        }


        //        //CommonUtil.Sending_Email(lstEmail.ToArray(), sSubject, mailBody);
        //        CommonUtil.Sending_Email(lstEmailStr.ToArray(), sSubject, mailBody);
        //    }
        //}

        #endregion

        #region View After Approved

        /// <summary>
        /// Remand
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private bool ViewData()
        {
            bool ret = false;
            ApproveFunction appFunc = new ApproveFunction(this.DataID, this.GetUserByID(this.LoginInfo.User.ID), ApplyType.OverTime, this.OldUpdateDate, this.GetStaffInfoByStaffCD(this.txtEmployeeCD.Value));

            ProcessResult result = appFunc.ViewData();
            switch (result)
            {
                case ProcessResult.Success:
                    this.IsInspected = true;
                    ret = true;
                    break;
                case ProcessResult.DataChanged:
                    this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    ret = false;
                    break;
                case ProcessResult.ProcessFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                    break;
                case ProcessResult.MailFail:
                    ret = false;
                    this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
                    break;
            }
            return ret;
        }

        ///// <summary>
        ///// ViewData
        ///// </summary>
        ///// <param name="apply"></param>
        ///// <returns></returns>
        //private bool ViewData(T_Work_OT apply)
        //{
        //    bool success = false;
        //    try
        //    {
        //        int ret = 0;
        //        using (DB db = new DB())
        //        {
        //            WorkOTService service = new WorkOTService(db);

        //            //Update StatusFlag
        //            ret = service.UpdateApplyStatus(this.DataID, this.LoginInfo.User.ID, apply.ApplyStatus, apply.ApprovedLevel, this.OldUpdateDate);
        //            if (ret == 1)
        //            {
        //                WorkApproveService approveSer = new WorkApproveService(db);
        //                approveSer.UpdateApproveStatus(apply.No, (int)StatusHasAprove.Approved, this.LoginInfo.User.ID, string.Empty);
        //            }
        //            //Check result update
        //            if (ret == 0)
        //            {
        //                //Data is changed
        //                this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
        //                return false;
        //            }
        //            db.Commit();
        //            success = true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
        //        //LoadDataForApproveListFromApproveList();
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
        //        Log.Instance.WriteLog(ex);
        //        return false;
        //    }

        //    try
        //    {
        //        //Send mail
        //        if (success)
        //        {
        //            string mess = "I have viewed.";
        //            this.SendMail(this.LoginInfo.User.ID, this.txtApplyNo.Value, this.txtEmployeeNm.Value, "Apply Type", this.txtReason.Text, mess, TypeSettingMail.Read);
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Send mail");
        //        return true;
        //    }
        //    return true;
        //}

        #endregion

        #region Method

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffCD"></param>
        /// <returns></returns>
        private M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            using (DB db = new DB())
            {
                StaffService staffSer = new StaffService(db);
                return staffSer.GetStaffInfoByStaffCD(staffCD.Trim());
            }
        }

        private void SetDataForShift(M_Work_Shift ws, bool isEmpty = false)
        {
            if (!isEmpty)
            {
                this.lbShiftName.Text = string.Empty;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = "-1";
                this.hdShiftName.Value = string.Empty;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;
            }
            else
            {
                this.lbShiftName.Text = ws.ShiftName;
                this.lbStartTime.Text = string.Empty;
                this.lbEndTime.Text = string.Empty;
                this.hdShiftID.Value = ws.ID.ToString();
                this.hdShiftName.Value = ws.ShiftName;
                this.hdStartTime.Value = string.Empty;
                this.hdEndTime.Value = string.Empty;

                if (ws.StartHour != null)
                {
                    this.lbStartTime.Text = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.lbEndTime.Text = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                    this.hdStartTime.Value = EditDataUtil.FixTimeShow((int)ws.StartHour, (int)ws.StartMinute, true);
                    this.hdEndTime.Value = EditDataUtil.FixTimeShow((int)ws.EndHour, (int)ws.EndMinute, true);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void LoadDataForChangedData()
        {
            //this.colorStatus = base.GetStatusColorLabel(this.ApplyStatus, ref this.statusNameLbl);
            IList<WorkApproveModel> applyLst = new List<WorkApproveModel>(this.ApproverList);
            //((List<ApplyApproveListModel>)applyLst).AddRange(this.ApproverList);
            if (applyLst != null)
            {
                //  this.SetRowNumForGrid(ref applyLst);
                this.rptApproverList.DataSource = applyLst;
                this.isHasData = true;
            }
            else
            {
                this.rptApproverList.DataSource = null;
                this.isHasData = false;
            }

            this.rptApproverList.DataBind();

        }



        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.IsInspected = false;
            this.hdnFormIDDefault.Value = M_Config_D.TEMPLATE_FORM_APPLY_OT.ToString();
            this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, this.LoginInfo.User.ID);
        }

        /// <summary>
        /// GetListApprovePerson
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="isIncludeView"></param>
        /// <param name="includeZeroLV"></param>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApprovePerson(int routeID, bool isIncludeView = false, EnumGetLevelZero includeZeroLV = EnumGetLevelZero.Exclude)
        {
            using (DB db = new DB())
            {
                IList<WorkApproveModel> approveUserList = new List<WorkApproveModel>();
                Route_DService service = new Route_DService(db);
                approveUserList = service.GetApproverListByRouteIDForWork(routeID, isGetViewLevel: isIncludeView, isGetLVZero: includeZeroLV);
                return approveUserList;
            }
        }

        /// <summary>
        /// InitDataForRoute
        /// </summary>
        /// <param name="ddl"></param>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        private void InitDataForRoute(DropDownList ddl, int formID, int userID, bool hasUser = true)
        {

            IList<M_Route_H> list = new List<M_Route_H>();
            if (hasUser)
            {
                using (DB db = new DB())
                {
                    Route_HService ser = new Route_HService(db);
                    list = ser.GetListByFormIDAndUserID(formID, userID);
                }
            }
            ddl.DataSource = list;
            ddl.DataValueField = "ID";
            ddl.DataTextField = "RouteName";
            ddl.DataBind();
            if (list != null && list.Count > 0)
            {
                this.GetListApprovePerson(int.Parse(this.ddlApprovalRoute.SelectedValue), true);
            }
            else
            {
                this.GetListApprovePerson(DEFAULT_VALUE, true);
            }
        }

        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Approve:
                case Mode.Ignore:
                case Mode.BackPre:
                    this.txtApproveReason.SetReadOnly(false);
                    break;

                default:
                    this.txtApproveReason.SetReadOnly(true);
                    this.dtEffectDate.SetReadOnly(true);
                    this.txtEmployeeCD.SetReadOnly(true);
                    this.ddlApprovalRoute.Enabled = false;
                    this.txtReason.SetReadOnly(true);
                    this.txtApproveReason.SetReadOnly(true);
                    if (this.PreApplyID.HasValue)
                    {
                        this.txtReasonCancel.SetReadOnly(true);
                    }
                    break;
            }
        }

        /// <summary>
        /// ISV-NHAT
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        private void LoadDataForApproveList(string applyNo, bool isIncludeView = false)
        {
            //this.colorStatus = base.GetStatusColorLabel((this.GetApplyByID(DataID)).ApplyStatus, ref this.statusNameLbl);
            IList<WorkApproveModel> approverList = new List<WorkApproveModel>();
            approverList = this.GetListApproveUserFromApply(isIncludeView);

            if (approverList != null && approverList.Count != 0)
            {
                //   IList<WorkApproveModel> allowList = new List<WorkApproveModel>();
                //    if (!isIncludeView)
                //    {
                //        var lstTemp = (from i in approverList
                //                      where !i.RouteLevel.Equals(M_Route_H.LEVEL_READER)
                //                      select i).ToList<WorkApproveModel>();

                //        if (lstTemp != null)
                //        {
                //            //((List<ApplyApproveListModel>)allowList).AddRange(lstTemp);
                //            allowList = new List<WorkApproveModel>(lstTemp);
                //        }

                //    }
                //    else
                //    {
                //        ((List<WorkApproveModel>)allowList).AddRange(approverList);
                //       allowList = new List<WorkApproveModel>(approverList);
                //    }

                this.isHasData = true;
                this.ApproverList = new List<WorkApproveModel>(approverList);
                // ((List<ApplyApproveListModel>)this.ApproverList).AddRange(allowList);             
                //---this.SetRowNumForGrid(ref allowList);
                this.rptApproverList.DataSource = approverList;
            }
            else
            {
                this.isHasData = false;
                this.rptApproverList.DataSource = null;
            }
            this.rptApproverList.DataBind();
            this.isApproved = false;
        }

        /// <summary>
        /// </summary>
        /// <returns></returns>
        private IList<WorkApproveModel> GetListApproveUserFromApply(bool isIncludeView = false)
        {
            using (DB db = new DB())
            {
                WorkApproveService applyApproveSer = new WorkApproveService(db);
                return applyApproveSer.GetListByIDOptionLevel(this.DataNo, isGetViewLevel: isIncludeView);
            }
        }

        /// <summary>
        /// </summary>
        /// <returns></returns>
        private T_Work_OT GetApplyByID(int id)
        {
            T_Work_OT apply = new T_Work_OT();
            using (DB db = new DB())
            {
                WorkOTService appSer = new WorkOTService(db);
                apply = appSer.GetByID(id);
            }
            return apply;
        }

        /// <summary>
        /// GetDataForDropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(bool withBlank = false)
        {
            using (DB db = new DB())
            {
                WorkShiftService otSer = new WorkShiftService(db);
                return otSer.GetDataForDropDown((int)ShiftType.Attendance, withBlank);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="category">T_Daily</param>
        private void ShowData(T_Work_OT apply)
        {
            //Show data
            if (apply != null)
            {
                //Re-Init value for combobox Route
                this.InitDataForRoute(this.ddlApprovalRoute, M_Config_D.TEMPLATE_FORM_APPLY_OT, apply.UserID);
                this.ddlApprovalRoute.SelectedValue = apply.RouteID.ToString();
                this.dtStartTime.SetTimeValue(apply.OTStartHour, apply.OTStartMinute);
                this.dtEndTime.SetTimeValue(apply.OTEndHour, apply.OTEndMinute);
                this.txtApplyNo.Value = apply.No;
                this.dtApplyDate.Value = apply.ApplyDate;
                this.dtEffectDate.Value = apply.EffectDate;
                this.lbEarly.Text = EditDataUtil.FixTimeShow(apply.EarlyHour, apply.EarlyMinute, true);
                this.lbNormal.Text = EditDataUtil.FixTimeShow(apply.Normal1Hour, apply.Normal1Minute, true);
                this.lbNormal2.Text = EditDataUtil.FixTimeShow(apply.Normal2Hour, apply.Normal2Minute, true);
                this.lbLateNight.Text = EditDataUtil.FixTimeShow(apply.LateHour, apply.LateMinute, true);
                this.lbHoliday1.Text = EditDataUtil.FixTimeShow(apply.Holiday1Hour, apply.Holiday1Minute, true);
                this.lbHoliday2.Text = EditDataUtil.FixTimeShow(apply.Holiday2Hour, apply.Holiday2Minute, true);

                T_Work_Approve appLst;
                M_Work_Shift ws;
                M_User user;
                M_StaffInfo s = null;
                T_Work_OT preApp = null;
                M_User createUser;
                M_User updateUser;

                using (DB db = new DB())
                {
                    WorkApproveService appSer = new WorkApproveService(db);
                    UserService userSer = new UserService(db);
                    WorkOTService ser = new WorkOTService(db);
                    StaffService staffSer = new StaffService(db);

                    ws = ser.GetWorkingShiftByDate(apply.EffectDate);
                    appLst = appSer.GetByKey(apply.No, this.LoginInfo.User.ID);
                    user = userSer.GetByID(apply.UserID);

                    if (user != null)
                    {
                        s = staffSer.GetStaffInfoByStaffID(user.StaffID);
                    }

                    if (this.PreApplyID != null && this.PreApplyID.HasValue)
                    {
                        preApp = ser.GetByID(this.PreApplyID.Value);
                    }
                    createUser = userSer.GetByID(apply.CreateUID);
                    updateUser = userSer.GetByID(apply.UpdateUID);
                }

                this.SetDataForShift(ws, true);

                if (appLst != null)
                {
                    this.IsInspected = appLst.ApproveStatus != (int)StatusHasAprove.New;
                    this.txtApproveReason.Value = appLst.ApproveReason;
                }

                if (user != null)
                {
                    if (s != null)
                    {
                        this.txtEmployeeCD.Value = EditDataUtil.ToFixCodeShow(s.StaffCD, M_Staff.MAX_STAFF_CODE_SHOW);
                        this.txtEmployeeNm.Value = s.StaffName;
                        this.txtPosition.Value = s.Position;
                        this.txtDepartment.Value = s.DepartmentName;
                        this.hdnDepartmentID.Value = s.DepartmentID.ToString();
                        this.GetTotalOverTime();
                    }
                    this.ApplyUserID = user.ID;
                }

                //this.txtApproveReason.Value = string.Empty;
                this.DataNo = apply.No;
                this.DataID = apply.ID;
                this.ApplyStatus = apply.ApplyStatus;
                this.PreApplyID = apply.PreApplyID;

                if (this.PreApplyID.HasValue)
                {
                    using (DB db = new DB())
                    {
                        WorkOTService ser = new WorkOTService(db);
                        preApp = ser.GetByID(this.PreApplyID.Value);
                    }

                    if (preApp != null)
                    {
                        this.hdnApplyID.Value = preApp.ID.ToString();
                        this.txtReason.Value = preApp.Reason;
                        this.txtReasonCancel.Value = apply.Reason;
                        this.btnViewPreVacation.Text = preApp.No;
                    }
                }
                else
                {
                    this.txtReason.Value = apply.Reason;
                }


                if (createUser != null)
                {
                    this.CreateUserCD = createUser.UserCD;
                    var createDate = (apply.CreateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.CreateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtCreateDate.Value = string.Format("{0} {1}", createUser.UserName2, createDate);
                }


                if (updateUser != null)
                {
                    var updateDate = (apply.UpdateDate == DEFAULT_DATE_TIME) ? string.Empty : apply.UpdateDate.ToString(Constants.FMT_DATETIME_REPORT_SHOW);
                    this.txtUpdateDate.Value = string.Format("{0} {1}", updateUser.UserName2, updateDate);
                }


                this.GetListApprovePerson(apply.RouteID, true);
                this.OldUpdateDate = apply.UpdateDate;
                this.LoadDataForApproveList(this.DataNo, true);

                T_Work_Approve workApprove = null;
                using (DB db = new DB())
                {
                    WorkApproveService appLstSer = new WorkApproveService(db);
                    workApprove = appLstSer.GetApproveRow(this.DataNo, this.LoginInfo.User.ID, (int)ApplyType.OverTime);
                }
                this.isDispApproveButton = this.IsDisplayApproveButton(workApprove);
                this.isDispIgnoreButton = this.IsDisplayIgnoreButton(workApprove);
                this.isShowPrevBackButton = this.IsDisplayPreBackButton(workApprove);
                this.isDispViewButton = this.IsDisplayViewButton(workApprove);

            }
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-NHAT
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayApproveButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }

                return true;
            }
            return false;
        }

        /// <summary>
        /// IsDisplayViewButton
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayViewButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel != 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (short)StatusApply.Approved && workApp.GetReadSetting(ReadSetting.ReadAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-NHAT
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayIgnoreButton(T_Work_Approve workApp)
        {
            if (workApp != null)
            {
                if (workApp.RouteLevel == 99)
                {
                    return false;
                }
                if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                {
                    return false;
                }
                if (workApp.GetRejectSetting(RejectSetting.RejectAuthor))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// IsDisplayButton
        /// ISV-NHAT
        /// 2015/04/20
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        private bool IsDisplayPreBackButton(T_Work_Approve workApp)
        {
            using (DB db = new DB())
            {
                WorkApproveService appLstSer = new WorkApproveService(db);
                if (workApp != null)
                {
                    if (workApp.RouteLevel == 99)
                    {
                        return false;
                    }
                    if (this.ApplyStatus == (int)StatusApply.Rejected || this.ApplyStatus == (int)StatusApply.Approved || this.ApplyStatus == (int)StatusApply.Cancel)
                    {
                        return false;
                    }
                    if (workApp.GetRemandSetting(RemandSetting.RemandAuthor) && appLstSer.CheckApproveIsFinishLevel(workApp.ApplyNo, workApp.RouteLevel - 1))
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        private void SetTime(WorkTotalOTInfo lastmonth, WorkTotalOTInfo thismonth)
        {
            this.lbLastEarly.Text = EditDataUtil.FixTimeShow(lastmonth.EarlyHour, lastmonth.EarlyMinute, true);
            this.lbLastNormal.Text = EditDataUtil.FixTimeShow(lastmonth.Normal1Hour, lastmonth.Normal1Minute, true);
            this.lbLastNormal2.Text = EditDataUtil.FixTimeShow(lastmonth.Normal2Hour, lastmonth.Normal2Minute, true);
            this.lbLastLate.Text = EditDataUtil.FixTimeShow(lastmonth.LateHour, lastmonth.LateMinute, true);
            this.lbLastHoliday1.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday1Hour, lastmonth.Holiday1Minute, true);
            this.lbLastHoliday2.Text = EditDataUtil.FixTimeShow(lastmonth.Holiday2Hour, lastmonth.Holiday2Minute, true);
            this.lbLastTotal.Text = EditDataUtil.FixTimeShow(lastmonth.TotalOTHour, lastmonth.TotalOTMinute, true);

            this.lbThisEarly.Text = EditDataUtil.FixTimeShow(thismonth.EarlyHour, thismonth.EarlyMinute, true);
            this.lbThisNormal.Text = EditDataUtil.FixTimeShow(thismonth.Normal1Hour, thismonth.Normal1Minute, true);
            this.lbThisNormal2.Text = EditDataUtil.FixTimeShow(thismonth.Normal2Hour, thismonth.Normal2Minute, true);
            this.lbThisLate.Text = EditDataUtil.FixTimeShow(thismonth.LateHour, thismonth.LateMinute, true);
            this.lbThisHoliday1.Text = EditDataUtil.FixTimeShow(thismonth.Holiday1Hour, thismonth.Holiday1Minute, true);
            this.lbThisHoliday2.Text = EditDataUtil.FixTimeShow(thismonth.Holiday2Hour, thismonth.Holiday2Minute, true);
            this.lbThisTotal.Text = EditDataUtil.FixTimeShow(thismonth.TotalOTHour, thismonth.TotalOTMinute, true);
        }

        private void GetTotalOverTime()
        {
            if (this.txtEmployeeCD.IsEmpty)
            {
                return;
            }

            M_Staff staff;
            M_User user;
            WorkTotalOTInfo thismonth = new WorkTotalOTInfo();
            WorkTotalOTInfo lastmonth = new WorkTotalOTInfo();
            using (DB db = new DB())
            {
                AccountingService accSer = new AccountingService(db);
                StaffService staffSer = new StaffService(db);
                UserService userSer = new UserService(db);
                WorkOTService wSer = new WorkOTService(db);

                staff = staffSer.GetByStaffCD(this.txtEmployeeCD.Value);
                user = userSer.GetByStaffID(staff.ID);

                AccountingPeriod periodC = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value);
                thismonth = wSer.GetTotalOverTime(periodC.StartDate, periodC.EndDate, user.ID);

                AccountingPeriod period = accSer.GetAccountingMonth(this.dtEffectDate.Value.Value.AddMonths(-1));
                lastmonth = wSer.GetTotalOverTime(period.StartDate, period.EndDate, user.ID);
            }

            this.SetTime(lastmonth, thismonth);
        }

        #endregion

        #region Event

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            this.Mode = Mode.Approve;
            T_Work_OT apply = this.GetApplyByID(this.DataID);
            this.PreCalWorkTime = true;
            if (apply != null)
            {
                ////  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //  var isOk = true;
                //  if (apply.UpdateDate != this.OldUpdateDate)
                //  {
                //      base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                //      isOk = false;
                //      if (apply.StatusFlag == 1)
                //      {
                //        //  this.LoadDataForApproveListFromApproveList();
                //          base.RedirectUrl(URL_LIST);
                //          return;
                //      }
                //  }

                //  //Set Mode
                //  this.ShowData(apply);
                //  if (isOk)
                //  {
                //      //Set Mode
                //      this.ProcessMode(this.Mode);
                //  }

                //   this.ShowData(apply);
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Approve);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnView Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnView_Click(object sender, EventArgs e)
        {
            T_Work_OT apply = this.GetApplyByID(this.DataID);
            this.PreCalWorkTime = true;
            if (apply != null)
            {
                //View Data
                if (this.ViewData())
                {
                    Server.Transfer(URL_LIST);
                }
                else
                {
                    this.LoadDataForChangedData();
                    //Set Mode
                    this.ProcessMode(Mode.View);
                }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// btnPrevBack_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPrevBack_Click(object sender, EventArgs e)
        {
            T_Work_OT apply = this.GetApplyByID(this.DataID);
            this.PreCalWorkTime = true;
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.BackPre);
                //// this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                // var isOk = true;
                // if (apply.UpdateDate != this.OldUpdateDate)
                // {
                //     base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                //     isOk = false;
                //     if (apply.StatusFlag == 1)
                //     {
                //         this.LoadDataForApproveList(this.DataID);
                //         base.RedirectUrl(URL_LIST);
                //         return;
                //     }
                // }

                // this.ShowData(apply);

                // if (isOk)
                // {
                //     //Set Mode
                //     this.ProcessMode(Mode.BackPre);
                // }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Submit Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            this.btnProcessData(sender, e);
            //this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            //T_Work_OT app = this.GetApplyByID(this.DataID);
            //this.PreCalWorkTime = true;
            //if (app != null)
            //{
            //    if (this.OldUpdateDate != app.UpdateDate)
            //    {
            //        this.LoadDataForChangedData();
            //    }
            //    else
            //    {
            //        this.LoadDataForApproveList(this.DataNo, true);
            //    }
            //}

            //if (this.Mode == Mode.Approve)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.Yes);
            //}
            //else if (this.Mode == Mode.Ignore)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, Models.DefaultButton.No);
            //}
            //else if (this.Mode == Mode.BackPre)
            //{
            //    base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, Models.DefaultButton.No);
            //}
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            //Get User
            T_Work_OT data = this.GetApplyByID(this.DataID);

            //Check user
            if (data != null)
            {
                //Show data
                this.ShowData(data);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            T_Work_OT apply = this.GetApplyByID(this.DataID);
            this.PreCalWorkTime = true;
            if (apply != null)
            {
                this.LoadDataForChangedData();
                this.ProcessMode(Mode.Ignore);
                ////  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                //  var isOk = true;
                //  if (apply.UpdateDate != this.OldUpdateDate)
                //  {
                //      base.SetMessage(string.Empty, M_Message.MSG_CODE_DELETED_UPDATED);
                //      isOk = false;
                //      if (apply.StatusFlag == 1)
                //      {
                //          this.LoadDataForApproveList(this.DataID);
                //          base.RedirectUrl(URL_LIST);
                //          return;
                //      }
                //  }

                //  this.ShowData(apply);

                //  if (isOk)
                //  {
                //      //Set Mode
                //      this.ProcessMode(Mode.Ignore);
                //  }
            }
            else
            {
                base.RedirectUrl(URL_LIST);
            }
        }

        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Approve:
                    //Update Data

                    if (this.Approve())
                    {
                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    //data = this.GetApplyByID(this.DataID);
                    //if (data != null)
                    //{
                    //    data.Reason = this.txtApproveReason.Text;
                    //    this.ApplyStatus = (short)StatusApply.Approving;
                    //    ret = this.Approve(data);
                    //    if (ret)
                    //    {
                    //        //Show data
                    //        data = this.GetApplyByID(this.DataID);

                    //        this.ShowData(data);

                    //        //Set Mode
                    //        this.ProcessMode(Mode.View);

                    //        //Set Success
                    //        this.Success = true;
                    //    }
                    //    else
                    //    {
                    //       // this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //        this.LoadDataForChangedData();
                    //        //du lieu da thay doi
                    //       // this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //        return;

                    //    }
                    //}

                    break;

                case Utilities.Mode.Ignore:
                    //Update Data
                    if (this.Reject())
                    {
                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }
                    //ret = this.Ignore((short)StatusApply.Rejected);
                    //if (ret)
                    //{
                    //    //Get User
                    //    data = this.GetApplyByID(this.DataID);

                    //    //Show data
                    //    this.ShowData(data);

                    //    //Set Mode
                    //    this.ProcessMode(Mode.View);

                    //    //Set Success
                    //    this.Success = true;
                    //}
                    //else
                    //{
                    //  //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //    this.LoadDataForChangedData();
                    //    //du lieu da thay doi
                    // //   this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //    return;

                    //}
                    break;

                case Utilities.Mode.BackPre:
                    //Update Data
                    if (this.Remand())
                    {
                        this.ShowData(this.GetApplyByID(this.DataID));
                        //Set Mode
                        this.ProcessMode(Mode.View);
                        this.Success = true;
                    }
                    else
                    {
                        this.LoadDataForChangedData();
                    }

                    //ret = this.Remand((short)StatusApply.Approving);
                    //if (ret)
                    //{
                    //    //Get User
                    //    data = this.GetApplyByID(this.DataID);

                    //    //Show data
                    //    this.ShowData(data);

                    //    //Set Mode
                    //    this.ProcessMode(Mode.View);

                    //    //Set Success
                    //    this.Success = true;
                    //}
                    //else
                    //{
                    //  //  this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
                    //    this.LoadDataForChangedData();
                    //    //du lieu da thay doi
                    //  //  this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                    //    return;
                    //}
                    break;
            }

        }

        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //   this.colorStatus = this.GetStatusColorLabel((int)this.ApplyStatus, ref this.statusNameLbl);
            T_Work_OT data = this.GetApplyByID(this.DataID);
            if (this.Mode == Utilities.Mode.View)
            {
                //Show data
                this.ShowData(data);
                this.ProcessMode(Mode.View);
            }
            else
            {
                this.LoadDataForApproveList(this.DataNo, true);
            }

        }

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Overtime";
            base.FormSubTitle = "";

            //Init Max Length
            this.txtApproveReason.MaxLength = T_Work_Approve.REASON_MAX_LENGTH;
            this.txtReason.MaxLength = T_Work_Approve.REASON_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);

        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //Check authority of login user
            base.SetAuthority(FormId.ApplyApprove);
            if (!this._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            this.PreCalWorkTime = false;
            if (!this.IsPostBack)
            {
                //Init Data
                this.InitData();
                if (this.PreviousPage != null)
                {

                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ApplyID"] == null)
                    {
                        base.RedirectUrl(URL_LIST);
                    }
                    else
                    {
                        //Get User ID
                        this.DataID = int.Parse(PreviousPageViewState["ApplyID"].ToString());
                        T_Work_OT data = this.GetApplyByID(this.DataID);

                        //Check user
                        if (data != null)
                        {
                            //Show data
                            this.ShowData(data);

                            //Set Mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            base.RedirectUrl(URL_LIST);
                        }
                    }
                }
                else
                {
                    base.RedirectUrl(URL_LIST);
                }
            }

            //Set init
            this.Success = false;
        }

        #endregion

        #region WebMethod

        /// <summary>
        /// Get Employee Name By Employee Code
        /// </summary>
        /// <param name="in1">Start Date</param>
        /// <returns></returns>
        [System.Web.Services.WebMethod]
        public static string CalWorkTime(string processDate, int shiftId, string startTime, string endTime)
        {
            try
            {
                if (string.IsNullOrEmpty(startTime) || string.IsNullOrEmpty(endTime) || endTime.CompareTo(startTime) <= 0)
                {
                    var result = new
                    {
                        earlyOT = "",
                        normal1OT = "",
                        normal2OT = "",
                        lateNightOT = "",
                        holiday1OT = "",
                        holiday2OT = ""
                    };
                    return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(result);
                }

                var arrST = startTime.Split(':');
                var arrET = endTime.Split(':');

                TimeSpan earlyOT = new TimeSpan();
                TimeSpan normal1OT = new TimeSpan();
                TimeSpan normal2OT = new TimeSpan();
                TimeSpan lateNightOT = new TimeSpan();
                TimeSpan holiday1OT = new TimeSpan();
                TimeSpan holiday2OT = new TimeSpan();

                DateTime workST = new DateTime(1, 1, 1).AddHours(int.Parse(arrST[0])).AddMinutes(int.Parse(arrST[1]));
                DateTime workET = new DateTime(1, 1, 1).AddHours(int.Parse(arrET[0])).AddMinutes(int.Parse(arrET[1]));

                DateTime startWorkTime = workST;
                DateTime endWorkTime = workET;

                DateTime workOTBeforeST = new DateTime(1, 1, 1);
                DateTime workOTBeforeET = new DateTime(1, 1, 1);
                DateTime workOTAfterST = new DateTime(1, 1, 1);
                DateTime workOTAfterET = new DateTime(1, 1, 1);

                using (DB db = new DB())
                {
                    WorkShiftService shiftSer = new WorkShiftService(db);
                    HolidayService holidaySer = new HolidayService(db);
                    RestTimeService restTSer = new RestTimeService(db);
                    AccountingService accSer = new AccountingService(db);

                    M_Work_Shift shift = shiftSer.GetByID(shiftId);
                    IList<RestTime> lstRestTime = restTSer.GetListByShiftID(shiftId);
                    M_Accounting accouting = accSer.GetData();

                    DateTime shiftST = new DateTime(1, 1, 1);
                    DateTime shiftET = new DateTime(1, 1, 1);
                    if (shift.StartHour != null)
                    {
                        shiftST = new DateTime(1, 1, 1).AddHours((int)shift.StartHour).AddMinutes((int)shift.StartMinute);
                        shiftET = new DateTime(1, 1, 1).AddHours((int)shift.EndHour).AddMinutes((int)shift.EndMinute);
                    }

                    //over time morning
                    if (startWorkTime < shiftST)
                    {
                        workOTBeforeST = startWorkTime;
                        workOTBeforeET = endWorkTime < shiftST ? endWorkTime : shiftST;
                    }

                    //over time everning
                    if (endWorkTime > shiftET)
                    {
                        workOTAfterST = startWorkTime > shiftET ? startWorkTime : shiftET;
                        workOTAfterET = endWorkTime;
                    }

                    //overtime calculate
                    TimeSpan normalOT = new TimeSpan();
                    if (workOTBeforeST != new DateTime(1, 1, 1) && workOTBeforeET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTBeforeST, workOTBeforeET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }
                    if (workOTAfterST != new DateTime(1, 1, 1) && workOTAfterET != new DateTime(1, 1, 1))
                    {
                        CommonService.ClassifyOTTime(workOTAfterST, workOTAfterET, lstRestTime, accouting, ref earlyOT, ref normalOT, ref lateNightOT);
                    }

                    //round overtime
                    earlyOT = EditDataUtil.RoundTime(earlyOT, accouting.UnitOfTime, accouting.RoundOT);
                    normalOT = EditDataUtil.RoundTime(normalOT, accouting.UnitOfTime, accouting.RoundOT);

                    DateTime pDate = DateTime.ParseExact(processDate, Constants.FMT_DATE, CultureInfo.InvariantCulture);
                    if (holidaySer.GetByDay(pDate) != null)
                    {
                        holiday2OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        holiday1OT = normalOT;
                    }
                    else if (pDate.DayOfWeek == DayOfWeek.Saturday)
                    {
                        normal2OT = normalOT;
                    }
                    else
                    {
                        normal1OT = normalOT;
                    }

                    //Round
                    lateNightOT = EditDataUtil.RoundTime(lateNightOT, accouting.UnitOfTime, accouting.RoundOT);
                }

                var ret = new
                {
                    earlyOT = FormatTimeResult(earlyOT),
                    normal1OT = FormatTimeResult(normal1OT),
                    normal2OT = FormatTimeResult(normal2OT),
                    lateNightOT = FormatTimeResult(lateNightOT),
                    holiday1OT = FormatTimeResult(holiday1OT),
                    holiday2OT = FormatTimeResult(holiday2OT)
                };
                return DailyReport.Utilities.EditDataUtil.JsonSerializer<object>(ret);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Format time result
        /// </summary>
        /// <param name="inVal"></param>
        /// <returns></returns>
        private static string FormatTimeResult(TimeSpan inVal)
        {
            if (inVal.TotalMinutes > 0)
            {
                return string.Format("{0:00}:{1:00}", inVal.Hours, inVal.Minutes);
            }
            else
            {
                return string.Empty;
            }
        }

        #endregion
    }
}
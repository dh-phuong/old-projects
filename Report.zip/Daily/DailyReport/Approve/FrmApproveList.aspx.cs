﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport.DAC;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.ApplyApprove
{
    /// <summary>
    /// FrmApplyRegisterList
    /// VN-Nho 2015.06.10
    /// </summary>
    public partial class FrmApplyApproveList : FrmBaseList
    {
        #region Constant

        /// <summary>
        /// Danger text
        /// </summary>
        private const string CONST_WARNING_TEXT = "Cancellation";
        private const string DEFAULT_NONE_SORT = "S#";
        private const string DEFAULT_SORT_FIELD = "7"/*"8"*/;
        private const string DEFAULT_SORT_DIREC = "2";

        #endregion Constant

        #region Property

        /// <summary>
        /// Get or set Collapse
        /// </summary>
        public string Collapse
        {
            get { return (string)ViewState["Collapse"]; }
            set { ViewState["Collapse"] = value; }
        }

        #endregion Property

        #region Event

        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Approval List";
            base.FormSubTitle = "List";

            // header grid sort
            this.HeaderGrid.OnSortClick += Sort_Click;

            // paging footer
            this.PagingFooter.OnClick += PagingFooter_Click;

            // paging header
            this.PagingHeader.OnClick += PagingHeader_Click;
            this.PagingHeader.OnPagingClick += PagingFooter_Click;
            this.PagingHeader.NumRowOnPage = base.NumRowOnPageDefault;
            this.PagingHeader.CurrentPage = base.CurrentPageDefault;
            this.PagingHeader.IsShowColor = true;
            this.PagingHeader.WarningText = CONST_WARNING_TEXT;

            this.txtEmployeeCD.MaxLength = M_Staff.MAX_STAFF_CODE_SHOW;
            this.txtEmployeeNm.MaxLength = M_Staff.STAFF_NAME_MAX_LENGTH;

            //Search button
            this.btnSearch.ServerClick += new EventHandler(btnSearch_Click);
        }

        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ApplyRegist);
            if (!this._authority.IsApplyRegistView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                //Init data
                this.InitData();

                //Show condition
                if (this.PreviousPage != null)
                {
                    if (this.PreviousPageViewState["Condition"] != null)
                    {
                        Hashtable data = (Hashtable)PreviousPageViewState["Condition"];
                        this.ShowCondition(data);
                    }
                }

                //Show data on grid
                this.LoadDataGrid(this.PagingHeader.CurrentPage, this.PagingHeader.NumRowOnPage);

                this.Collapse = string.Empty;
            }
        }

        /// <summary>
        /// Search
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            // Refresh sort header
            this.HeaderGrid.SortDirec = DEFAULT_SORT_DIREC;
            this.HeaderGrid.SortField = DEFAULT_SORT_FIELD;

            // Refresh load grid
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);

            this.Collapse = "in";
        }

        /// <summary>
        /// Event changed page
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnDetail_Click(object sender, CommandEventArgs e)
        {
            //UserID
            this.ViewState["ApplyID"] = e.CommandArgument;

            //Save condition
            this.SaveCondition();
        }

        /// <summary>
        /// Event Select
        /// </summary>
        /// <param name="sender">object</param>
        /// <param name="e">EventArgs</param>
        protected void btnSelect_Click(object sender, CommandEventArgs e)
        {
            this.SaveCondition();            
        }

        /// <summary>
        /// Click PagingFooter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingFooter_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                int curPage = int.Parse((sender as LinkButton).CommandArgument);
                this.PagingFooter.CurrentPage = curPage;
                this.PagingHeader.CurrentPage = curPage;
                this.LoadDataGrid(curPage, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click PagingHeader
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void PagingHeader_Click(object sender, EventArgs e)
        {
            if (sender != null)
            {
                this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
            }
        }

        /// <summary>
        /// Click Sort
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Sort_Click(object sender, EventArgs e)
        {
            this.LoadDataGrid(1, this.PagingHeader.NumRowOnPage);
        }

        #endregion Event

        #region Method

        /// <summary>
        /// Save condition search
        /// </summary>
        private void SaveCondition()
        {
            Hashtable hash = new Hashtable();
            hash.Add(this.txtEmployeeCD.ID, this.txtEmployeeCD.Value);
            hash.Add(this.txtEmployeeNm.ID, this.txtEmployeeNm.Value);
            /*Phan nay ap dung cho apply date, tam thoi bo di
            hash.Add(this.dtApplyDateFrom.ID, this.dtApplyDateFrom.Value);
            hash.Add(this.dtApplyDateTo.ID, this.dtApplyDateTo.Value);*/
            hash.Add(this.dtEffectDateFrom.ID, this.dtEffectDateFrom.Value);
            hash.Add(this.dtEffectDateTo.ID, this.dtEffectDateTo.Value);
            hash.Add(this.dtApproveDateFrom.ID, this.dtApproveDateFrom.Value);
            hash.Add(this.dtApproveDateTo.ID, this.dtApproveDateTo.Value);

            hash.Add(this.cmbApplyType.ID, this.cmbApplyType.SelectedValue);
            hash.Add(this.cmbApprovedStatus.ID, this.cmbApprovedStatus.SelectedValue);

            hash.Add("NumRowOnPage", this.PagingHeader.NumRowOnPage);
            hash.Add("CurrentPage", this.PagingHeader.CurrentPage);

            hash.Add("SortField", this.HeaderGrid.SortField);
            hash.Add("SortDirec", this.HeaderGrid.SortDirec);

            this.ViewState["Condition"] = hash;
        }

        /// <summary>
        /// Show Condition
        /// </summary>
        private void ShowCondition(Hashtable data)
        {
            this.txtEmployeeCD.Value = data[this.txtEmployeeCD.ID].ToString();
            this.txtEmployeeNm.Value = data[this.txtEmployeeNm.ID].ToString();

            /*Phan nay ap dung cho apply date, tam thoi bo di
                 this.dtApplyDateFrom.Value = null;
            if (data[this.dtApplyDateFrom.ID] != null)
            {
                this.dtApplyDateFrom.Value = (DateTime)data[this.dtApplyDateFrom.ID];
            }

            this.dtApplyDateTo.Value = null;
            if (data[this.dtApplyDateTo.ID] != null)
            {
                this.dtApplyDateTo.Value = (DateTime)data[this.dtApplyDateTo.ID];
            }
            */
            this.dtEffectDateFrom.Value = null;
            if (data[this.dtEffectDateFrom.ID] != null)
            {
                this.dtEffectDateFrom.Value = (DateTime)data[this.dtEffectDateFrom.ID];
            }

            this.dtEffectDateTo.Value = null;
            if (data[this.dtEffectDateTo.ID] != null)
            {
                this.dtEffectDateTo.Value = (DateTime)data[this.dtEffectDateTo.ID];
            }

            this.dtApproveDateFrom.Value = null;
            if (data[this.dtApproveDateFrom.ID] != null)
            {
                this.dtApproveDateFrom.Value = (DateTime)data[this.dtApproveDateFrom.ID];
            }

            this.dtApproveDateTo.Value = null;
            if (data[this.dtApproveDateTo.ID] != null)
            {
                this.dtApproveDateTo.Value = (DateTime)data[this.dtApproveDateTo.ID];
            }

            this.cmbApplyType.SelectedValue = data[this.cmbApplyType.ID].ToString();
            this.cmbApprovedStatus.SelectedValue = data[this.cmbApprovedStatus.ID].ToString();

            int curPage = int.Parse(data["CurrentPage"].ToString());
            this.PagingHeader.CurrentPage = curPage;
            this.PagingFooter.CurrentPage = curPage;

            int rowOfPage = int.Parse(data["NumRowOnPage"].ToString());
            this.PagingHeader.NumRowOnPage = rowOfPage;

            this.HeaderGrid.SortField = data["SortField"].ToString();
            this.HeaderGrid.SortDirec = data["SortDirec"].ToString();
        }

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this.hdnLoginUID.Value = this.LoginInfo.User.ID.ToString();

            //Status
            this.InitCombobox(this.cmbApplyType, M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
            this.InitApproveCombobox();

            // header grid
            this.HeaderGrid.SortDirec = DEFAULT_SORT_DIREC;
            this.HeaderGrid.SortField = DEFAULT_SORT_FIELD;
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitCombobox(DropDownList ddl, string configCD, bool withBlank = false)
        {
            // init combox 
            ddl.DataSource = this.GetDataForDropdownList(configCD, withBlank);

            ddl.DataValueField = "Value";
            ddl.DataTextField = "DisplayName";
            ddl.DataBind();
        }

        /// <summary>
        /// Init Combobox
        /// </summary>
        private void InitApproveCombobox()
        {
            IList<DropDownModel> lstData = new List<DropDownModel>();
            lstData.Add(new DropDownModel() { Value = "0", DisplayName = "Wait Approval" });
            lstData.Add(new DropDownModel() { Value = "1", DisplayName = "Approved" });
            lstData.Add(new DropDownModel() { Value = "2", DisplayName = "All" });

            // init combox 
            this.cmbApprovedStatus.DataSource = lstData;

            this.cmbApprovedStatus.DataValueField = "Value";
            this.cmbApprovedStatus.DataTextField = "DisplayName";
            this.cmbApprovedStatus.DataBind();
        }

        /// <summary>
        /// Get data for DropdownList
        /// </summary>
        /// <param name="configCD"></param>
        /// <returns></returns>
        private IList<DropDownModel> GetDataForDropdownList(string configCD, bool withBlank = false)
        {
            using (DB db = new DB())
            {
                Config_HService configSer = new Config_HService(db);
                return configSer.GetDataForDropDownList(configCD, withBlank);
            }
        }

        /// <summary>
        /// Load data grid
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private void LoadDataGrid(int pageIndex, int numOnPage)
        {
            //Check input data
            if (CheckInput())
            {
                //Has error : end process
                return;
            }
            int totalRow = 0;
            IList<ApplyApproveInfo> lstData;

            /*Phan nay ap dung cho apply date, tam thoi bo di
            DateTime applyDateFrom = this.dtApplyDateFrom.IsEmpty ? new DateTime(1900, 1, 1) : this.dtApplyDateFrom.Value.Value;
            DateTime applyDateTo = this.dtApplyDateTo.IsEmpty ? new DateTime(9999, 12, 31) : this.dtApplyDateTo.Value.Value;
            */
            DateTime effectDtFrom = this.dtEffectDateFrom.IsEmpty ? new DateTime(1900, 1, 1) : this.dtEffectDateFrom.Value.Value;
            DateTime effectDtTo = this.dtEffectDateTo.IsEmpty ? new DateTime(9999, 12, 31) : this.dtEffectDateTo.Value.Value;

            DateTime? approvedDateFrom = this.dtApproveDateFrom.Value;
            DateTime? approvedDateTo = this.dtApproveDateTo.Value;

            //Get data
            using (DB db = new DB())
            {
                WorkService workSer = new WorkService(db);
                totalRow = workSer.GetCountApplyApproveList(this.LoginInfo.User.ID, this.txtEmployeeCD.Value, this.txtEmployeeNm.Value, effectDtFrom, effectDtTo, approvedDateFrom, approvedDateTo, int.Parse(cmbApplyType.SelectedValue), int.Parse(this.cmbApprovedStatus.SelectedValue));

                lstData = workSer.GetApplyApproveListByCond(this.LoginInfo.User.ID, this.txtEmployeeCD.Value, this.txtEmployeeNm.Value, effectDtFrom, effectDtTo, approvedDateFrom, approvedDateTo, int.Parse(cmbApplyType.SelectedValue), int.Parse(this.cmbApprovedStatus.SelectedValue),
                                                         pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));
                /* Phan nay ap dung cho apply date, tam thoi bo di
                 totalRow = workSer.GetCountApplyApproveList(this.LoginInfo.User.ID, this.txtEmployeeCD.Value, this.txtEmployeeNm.Value, applyDateFrom, applyDateTo, approvedDateFrom, approvedDateTo, int.Parse(cmbApplyType.SelectedValue), int.Parse(this.cmbApprovedStatus.SelectedValue));

                lstData = workSer.GetApplyApproveListByCond(this.LoginInfo.User.ID, this.txtEmployeeCD.Value, this.txtEmployeeNm.Value, applyDateFrom, applyDateTo, approvedDateFrom, approvedDateTo, int.Parse(cmbApplyType.SelectedValue), int.Parse(this.cmbApprovedStatus.SelectedValue),
                                                         pageIndex, numOnPage, int.Parse(this.HeaderGrid.SortField), int.Parse(this.HeaderGrid.SortDirec));*/
            }

            //Show data
            if (lstData.Count == 0)
            {
                this.rptResult.DataSource = null;
            }
            else
            {
                // paging header
                this.PagingHeader.RowNumFrom = int.Parse(lstData[0].RowNumber.ToString());
                this.PagingHeader.RowNumTo = int.Parse(lstData[lstData.Count - 1].RowNumber.ToString());
                this.PagingHeader.TotalRow = totalRow;
                this.PagingHeader.CurrentPage = pageIndex;

                // paging footer
                this.PagingFooter.CurrentPage = pageIndex;
                this.PagingFooter.NumberOnPage = numOnPage;
                this.PagingFooter.TotalRow = totalRow;

                // header
                this.HeaderGrid.TotalRow = totalRow;
                this.HeaderGrid.AddColumms(new string[] { "#", "", "Status", "App. No.", "Employee", "App. Type", /*"Apply Date",*/ "Effect Date", DEFAULT_NONE_SORT + "&nbsp;&nbsp;&nbsp;Duration" });

                // detail
                this.rptResult.DataSource = lstData;
            }

            this.rptResult.DataBind();
        }

        /// <summary>
        /// Check data input valid
        /// </summary>
        /// <returns></returns>
        private bool CheckInput()
        {
            /*//Apply Date
            if (this.dtApplyDateFrom.Value != null && this.dtApplyDateTo.Value != null)
            {
                if (this.dtApplyDateFrom.Value.Value.Date > this.dtApplyDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtApplyDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Apply Date From", "Apply Date To");
                }
            }*/

            //Effect Date
            if (this.dtEffectDateFrom.Value != null && this.dtEffectDateTo.Value != null)
            {
                if (this.dtEffectDateFrom.Value.Value.Date > this.dtEffectDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtEffectDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Effect Date From", "Effect Date To");
                }
            }

            //Aproved Date
            if (this.dtApproveDateFrom.Value != null && this.dtApproveDateTo.Value != null)
            {
                if (this.dtApproveDateFrom.Value.Value.Date > this.dtApproveDateTo.Value.Value.Date)
                {
                    this.SetMessage(this.dtApproveDateFrom.ID, M_Message.MSG_LESS_THAN_EQUAL, "Approval Date From", "Approval Date To");
                }
            }
            //Has errors
            if (base.HaveError)
            {
                this.Collapse = "in";
                this.rptResult.DataSource = null;
                this.rptResult.DataBind();
                return true;
            }
            return false;
        }
        
        #endregion Method

    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DailyReport;
using DailyReport.Utilities;
using DailyReport.DAC;
using DailyReport.Models;
using System.Data.SqlClient;
using System.Globalization;

namespace DailyReport.Approve
{
    /// <summary>
    /// Approve Detail
    /// ISV-NHAT
    /// Edit by ISV-TRUC
    /// 2015/03/09
    /// </summary>
    public partial class FrmApproveDetail : FrmBaseDetail
    {
        #region Constants
        private const string URL_LIST = "~/Approve/FrmApproveList.aspx";
        #endregion
        
        #region Variant

        public bool _hasApproveUser;
        public short _approveStatus;
        private bool _isUserApproved;
        public bool _isReloadPage;
        #endregion

        #region Property

        /// <summary>
        /// Get or set ApproveID
        /// </summary>
        public int ApproveID
        {
            get { return (int)ViewState["ID"]; }
            set { ViewState["ID"] = value; }
        }

        /// <summary>
        /// Get or set OldUpdateDate
        /// </summary>
        public DateTime OldUpdateDate
        {
            get { return (DateTime)ViewState["OldUpdateDate"]; }
            set { ViewState["OldUpdateDate"] = value; }
        }

        /// <summary>
        /// Get or Set Has Check Approve (approve or ignore)
        /// </summary>
        public bool HasCheckApprove
        {
            get { return (bool)ViewState["HasCheckApprove"]; }
            set { ViewState["HasCheckApprove"] = value; }
        }

        #endregion

        #region Method

        /// <summary>
        /// Init Data
        /// </summary>
        private void InitData()
        {
            this._isReloadPage = false;
            this._hasApproveUser = false;
            this._isUserApproved = false;
            this.HasCheckApprove = false;
        }

        /// <summary>
        /// GetListApprove(From Approve_List)
        /// </summary>
        /// <param name="wID"></param>
        /// <returns></returns>
        private IList<ApproveWork> GetListApproveByWorkID(int wID)
        {
            using (DB db = new DB())
            {
                ApproveListService appListSer = new ApproveListService(db);
                //Get Approve
                return appListSer.GetListForWork(wID);
            }
        }

        /// <summary>
        /// Show data on form
        /// </summary>
        /// <param name="user">User</param>
        private void ShowData(ApproveDetailInfo approve)
        {
            //Show data
            if (approve != null)
            {
                
                this._isUserApproved = approve.ListApproveStatus == (int)ApproveListStatusFlag.Approved;
                this.txtApproveNo.Value = approve.ApproveNo;
                this.txtStatus.Value = approve.StatusName.ToString();
                this.txtUserName.Value = approve.Username;
                this.txtConfirmDate.Value = approve.ConfirmDateDisp;
                this.txtType.Value = approve.Typename;
                this.txtStartDate.Value = String.Format("{0:dd/MM/yyyy}", approve.StartDate);
                this.txtEndDate.Value = String.Format("{0:dd/MM/yyyy}", approve.EndDate);
                this.txtStartTime.Value = approve.StartHour.ToString().PadLeft(2, '0') + ":" + approve.StartMinute.ToString().PadLeft(2, '0');
                this.txtEndTime.Value = approve.EndHour.ToString().PadLeft(2, '0') + ":" + approve.EndMinute.ToString().PadLeft(2, '0');
                this.txtContent.Value = approve.Content;

                //this.chkStatusFlag.Checked = approve.StatusFlag == 0 ? true : false;
                //Fill Data
                this.FillDataApproveList();

                this._approveStatus = approve.StatusApprove;
                //Save ID and UpdateDate                
                this.ApproveID = approve.ID;
                this.OldUpdateDate = approve.UpdateDate;
                this.HasCheckApprove = this.HasCheckApprove ? this.HasCheckApprove : approve.ListApproveStatus == (int)ApproveListStatusFlag.Approved;
            }
        }

        /// <summary>
        /// FillDataApproveList
        /// </summary>
        private void FillDataApproveList()
        {
            //Get List Approve
            IList<ApproveWork> appLst = this.GetListApproveByWorkID(this.ApproveID);
            if (appLst == null || appLst.Count == 0)
            {
                this._hasApproveUser = false;
                this.rptApproveList.DataSource = null;
            }
            else
            {
                IList<ApproveListWork> appLstWork = this.GetListApproveUser(appLst);
                this._hasApproveUser = true;
                // detail
                this.rptApproveList.DataSource = appLstWork;                
            }
            this.rptApproveList.DataBind();
        }

        /// <summary>
        /// Get approve BY approveID
        /// </summary>
        /// <param name="userID">approveID</param>
        /// <returns>User</returns>
        private ApproveDetailInfo GetApprove(int approveID, int userID)
        {
            using (DB db = new DB())
            {
                ApproveService approveSer = new ApproveService(db);
                return approveSer.GetApproveDetailByID(approveID, userID);
            }
        }

        /// <summary>
        /// Ignore Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        private bool Ignore()
        {
            try
            {
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {
                    int ret = 0;
                    ApproveService approveSer = new ApproveService(db);
                    ret = approveSer.UpdateStatus(ApproveID, LoginInfo.User.ID, (short)StatusApprove.Ignore, OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }
                    ApproveListService approveListSer = new ApproveListService(db);
                    approveListSer.Ignore(ApproveID, LoginInfo.User.ID, (short)StatusApprove.Ignore, txtRemark.Value);
                    this.HasCheckApprove = true;
                    db.Commit();
                }
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
               // LoadDataGrid();
                Log.Instance.WriteLog(ex);

                return false;
            }
            return true;
        }

        /// <summary>
        /// Check Approve Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        ///
        private int CheckApprove(int approveID)
        {
            using (DB db = new DB())
            {
                ApproveListService approveListSer = new ApproveListService(db);
                return approveListSer.CheckApprove(ApproveID);
            }
        }

        /// <summary>
        /// Approve Data
        /// </summary>
        /// <returns>Success:true, Faile:false</returns>
        ///
        private bool Approve_List()
        {
            try
            {
                int ret = 0;
                int countUserApprove = 0;
                ApproveService approveSer;
                using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                {                    
                    approveSer = new ApproveService(db);
                    ret = approveSer.UpdateStatus(ApproveID, LoginInfo.User.ID, (short)StatusApprove.Approve, OldUpdateDate);

                    //Check result update
                    if (ret == 0)
                    {
                        //du lieu da thay doi
                        this.SetMessage(string.Empty, M_Message.MSG_DATA_CHANGED);
                        return false;
                    }

                    this._approveStatus = (short)StatusApprove.Approve;
                    ApproveListService approveListSer = new ApproveListService(db);
                    approveListSer.Approve(ApproveID, LoginInfo.User.ID, (short)StatusApprove.Approve, txtRemark.Value);
                    db.Commit();
                }

                countUserApprove = CheckApprove(ApproveID);

                if (countUserApprove == 0)
                {
                    ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);
                    this.OldUpdateDate = approve.UpdateDate;
                    using (DB db = new DB(System.Data.IsolationLevel.Serializable))
                    {
                        approveSer = new ApproveService(db);
                        Insert_Daily(approve, db);
                        approveSer.UpdateStatus(ApproveID, LoginInfo.User.ID, (short)StatusApprove.Complete, OldUpdateDate);
                        this._approveStatus = (short)StatusApprove.Complete;                        
                        db.Commit();
                    }                    
                }                  
                
            }
            catch (Exception ex)
            {
                this.SetMessage(string.Empty, M_Message.MSG_UPDATE_FAILE, "Update");
                //LoadDataGrid();
                Log.Instance.WriteLog(ex);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Insert T_Daily
        /// </summary>
        /// <param name="pageIndex"></param>
        /// <param name="numOnPage"></param>
        private bool Insert_Daily(ApproveDetailInfo approve, DB db)
        {            
            T_Daily daily;
            DateTime StartDate = DateTime.Parse(txtStartDate.Value, new CultureInfo("en-CA"));
            DateTime EndDate = DateTime.Parse(txtEndDate.Value, new CultureInfo("en-CA"));
            DailyService dailySer = new DailyService(db);

            while (StartDate <= EndDate)
            {
                daily = new T_Daily();
                daily.UserID = approve.UserID;
                daily.WorkDate = StartDate;
                daily.TypeApplyID = approve.TypeApplyID;
                daily.ApproveID = this.ApproveID;

                if (StartDate == DateTime.Parse(txtStartDate.Value, new CultureInfo("en-CA")))
                {
                    string[] time = new string[2];
                    time = txtStartTime.Value.Split(':');
                    daily.StartHour = short.Parse(time[0]);
                    daily.StartMinute = short.Parse(time[1]);
                }
                else
                {
                    daily.StartHour = 8;
                    daily.StartMinute = 0;
                }

                if (StartDate == DateTime.Parse(txtEndDate.Value, new CultureInfo("en-CA")))
                {
                    string[] time = new string[2];
                    time = txtEndTime.Value.Split(':');
                    daily.EndHour = short.Parse(time[0]);
                    daily.EndMinute = short.Parse(time[1]);
                }
                else
                {
                    daily.EndHour = 17;
                    daily.EndMinute = 30;
                }

                daily.Content = approve.Content;
                daily.DeleteFlag = 0;
                daily.CreateUID = LoginInfo.User.ID;
                daily.CreateDate = DateTime.Now;

                dailySer.Insert(daily);
                //Insert_Daily(daily, db);
                StartDate = StartDate.AddDays(1);
            }
            return true;
        }

        /// <summary>
        /// Get List Approve User (Has List Child)
        /// </summary>
        /// <param name="UserID"></param>
        /// <returns></returns>
        private IList<ApproveListWork> GetListApproveUser(IList<ApproveWork> lstDB)
        {
            IList<ApproveListWork> lstRet = null;
            if (lstDB != null)
            {
                lstRet = new List<ApproveListWork>();
                bool onlyUser = lstDB.Count == 1;
                var lstLevel = (from lstI in lstDB
                                group lstI by lstI.ApproveLevel into newGroup
                                select newGroup
                               );
                foreach (var item in lstLevel)
                {
                    ApproveListWork w = new ApproveListWork();
                    w.Level = item.Key;
                    w.LevelStr = onlyUser ? string.Empty : string.Format("Level {0}", w.Level);
                    w.DetailList = new List<ApproveWork>();
                    w.DetailList = (from i in lstDB
                                    where i.ApproveLevel.Equals(w.Level)
                                    select i
                                    ).ToList();
                    if (w.DetailList.Count == 1)
                    {
                        w.DetailList[0].RouteMethodStr = string.Empty;
                    }
                    lstRet.Add(w);
                }
            }
            return lstRet;
        }
        
        /// <summary>
        /// Process Mode
        /// </summary>
        /// <param name="mode">Mode</param>
        private void ProcessMode(Mode mode, bool init = true)
        {
            //Set Model
            this.Mode = mode;

            //Check model
            switch (mode)
            {
                case Mode.Approve:
                case Mode.Ignore:

                    break;
                default:

                    if (init && this._approveStatus != (int)StatusApprove.Complete && !this.HasCheckApprove)
                    {                       
                        this.txtRemark.ReadOnly = false;
                    }
                    else
                    {                        
                        this.txtRemark.ReadOnly = true;
                    }

                    base.DisabledLink(this.btnApprove, !base._authority.IsApplyApproveApprove || this._approveStatus == (int)StatusApprove.Complete || this.HasCheckApprove);
                    base.DisabledLink(this.btnIgnore, !base._authority.IsApplyApproveIgnore || this._approveStatus == (int)StatusApprove.Complete || this.HasCheckApprove);
                    break;
            }
        }


        #endregion

        #region Event
        
        /// <summary>
        /// Event Init
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            //Set Title
            base.FormTitle = "Approve Detail";
            base.FormSubTitle = "Detail";

            // header grid sort
            //this.HeaderGrid.OnSortClick += Sort_Click;           
            //Max_Lenght
            txtRemark.MaxLength = T_Approve_List.REMARK_MAX_LENGTH;

            //Init Event
            LinkButton btnYes = (LinkButton)this.Master.FindControl("btnYes");
            btnYes.Click += new EventHandler(btnProcessData);

            LinkButton btnNo = (LinkButton)this.Master.FindControl("btnNo");
            btnNo.Click += new EventHandler(btnProcessView);
        }
        
        /// <summary>
        /// Page Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            base.SetAuthority(FormId.ApplyApprove);
            if (!base._authority.IsApplyApproveView)
            {
                Response.Redirect("~/Menu/FrmMainMenu.aspx");
            }

            if (!this.IsPostBack)
            {
                this.InitData();
                if (this.PreviousPage != null)
                {
                    //Save condition of previous page
                    this.ViewState["Condition"] = this.PreviousPageViewState["Condition"];

                    if (this.PreviousPageViewState["ID"] == null)
                    {

                        Server.Transfer(URL_LIST);
                    }
                    else
                    {
                        //Get approve ID
                        this.ApproveID = int.Parse(PreviousPageViewState["ID"].ToString());

                        ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);

                        //Check approve
                        if (approve != null)
                        {
                            //Show data                            
                            this.ShowData(approve);
                            //Set mode
                            this.ProcessMode(Mode.View);
                        }
                        else
                        {
                            Server.Transfer(URL_LIST);
                        }
                    }
                }
                else
                {
                    this._isReloadPage = true;
                }
            }
        }

        /// <summary>
        /// Event Update Submit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnIgnore_Click(object sender, EventArgs e)
        {
            ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);

            //Check approve
            if (approve != null)
            {
                this.ProcessMode(Mode.Ignore);
                //Fill Data
                this.FillDataApproveList();
                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_IGNORE, DailyReport.Models.DefaultButton.No, true);
            }
        }

        /// <summary>
        /// Event Approve
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnApprove_Click(object sender, EventArgs e)
        {
            ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);

            //Check approve
            if (approve != null)
            {
                this.ProcessMode(Mode.Approve);

                //Fill Data
                this.FillDataApproveList();

                //Show question update
                base.ShowQuestionMessage(M_Message.MSG_QUESTION_APPROVE_ACCEPT, DailyReport.Models.DefaultButton.No, true);
            }
        }

        /// <summary>
        /// Event Back
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnBack_Click(object sender, EventArgs e)
        {
            ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);

            //Check approve
            if (approve != null)
            {
                //Show data
                this.ShowData(approve);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }
        }
        
        /// <summary>
        /// Process Data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessData(object sender, EventArgs e)
        {
            //Check Mode
            switch (this.Mode)
            {
                case Utilities.Mode.Ignore:
                    //Ignore Data
                    if (this.Ignore())
                    {
                        ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);
                        this.ShowData(approve);

                        //Set Mode
                        this.ProcessMode(Mode.View, false);

                        this.Success = true;
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;

                case Utilities.Mode.Approve:

                    if (this.Approve_List())
                    {
                        //Cuurent User approved
                        this._isUserApproved = true;
                        //Get data
                        ApproveDetailInfo approve = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);
                        this.ShowData(approve);
                        //Set Mode
                        this.ProcessMode(Mode.View, false);

                        this.Success = true;
                    }
                    else
                    {
                        //Set Mode
                        this.ProcessMode(Mode.View);
                    }
                    break;
            }
        }
        
        /// <summary>
        /// Process View Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnProcessView(object sender, EventArgs e)
        {
            //Get Approve
            ApproveDetailInfo app = this.GetApprove(this.ApproveID, this.LoginInfo.User.ID);                        
            //Check Approve
            if (app != null)
            {
                //Show data
                this.ShowData(app);

                //Set Mode
                this.ProcessMode(Mode.View);
            }
            else
            {
                Server.Transfer(URL_LIST);
            }

        }
        
        /// <summary>
        /// Approve List Data bound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void rptApproveList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            //Get data
            ApproveListWork Detail = (ApproveListWork)e.Item.DataItem;

            //Find control
            Repeater rptDetail = (Repeater)e.Item.FindControl("rptApproveChild");

            //----------------Set data detail----------------------//

            rptDetail.DataSource = Detail.DetailList;
            rptDetail.DataBind();
            //----------------End Set data detail-----------------//
        }

        #endregion

    }
}
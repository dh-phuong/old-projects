﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace DailyReport.Utilities
{
    public enum TypeWorkLeave
    {
        Late = 0,
        Early,
        Out
    }

    /// <summary>
    /// Mode
    /// </summary>
    public enum Mode
    {
        View = 0,
        Insert,
        Update,
        Delete,
        Copy,
        Approve,
        Ignore,
        Confirm,
        BackPre,
        Cancel
    }

    /// <summary>
    /// Format Type
    /// </summary>
    public enum TypeFormat
    {
        Int,
        Dec
    }

    /// <summary>
    /// Enum ExchangeRateDecType
    /// </summary>
    public enum ExchangeRateDecType
    {
        NotDecimal = 0,
        Decimal
    }

    /// <summary>
    /// Enum Color List
    /// </summary>
    public enum ColorList
    {
        Danger = 0,
        Warning,
        Info,
        Success,
        Finish
    }

    /// <summary>
    /// ColorOfLevel
    /// </summary>
    public enum ColorOfLevel
    {
        Info = 1,
        Success,
        Warning,
        Danger,
        Finish
    }

    /// <summary>
    /// Enum Issued Flag
    /// </summary>
    public enum IssuedFlagEnum
    {
        Unissued = 0,
        Issued
    }

    /// <summary>
    /// Form ID Master
    /// </summary>
    public enum FormId
    {
        CompanyInfo = 1,
        Department,
        GroupUser,
        Holiday,
        Information,
        Link,
        Province,
        Route,
        Setting,
        Staff,
        Template,
        WorkingShift,
        WorkingDay,
        RestTime,
        Accounting,
        BaseWorkDay,
        User,
        Daily,
        ApplyRegist,
        ApplyApprove,
        TypeApply,
        Overtime
    }

    public enum AuthorRoute
    {
        Remand = 1,
        Reject,
        EmailApprved,
        EmailRmanind,
        EmailApprByOrther,
        ApprToOther

    }

    /// <summary>
    /// Apply setting
    /// </summary>
    public enum ApplySetting
    {
        ProxyAll = 0,
        ProxyDept,
        Mail,
        MailAll
    }

    /// <summary>
    /// Approve setting
    /// </summary>
    public enum ApproveSetting
    {
        SeniorApprove = 0,
        SeniorApproveAll,
        MailAppliciant,
        MailPreAll,
        MailPre,
        MailCurrentLevel,
        MailNext,
        MailNextAll,
        Reader
    }

    /// <summary>
    /// Reject Setting
    /// </summary>
    public enum RejectSetting
    {
        RejectAuthor = 0,
        MailAppliciant,
        MailPreAll,
        MailPre,
        MailCurrentLevel,
        MailNext,
        MailNextAll
    }

    /// <summary>
    /// Remand setting
    /// </summary>
    public enum RemandSetting
    {
        RemandAuthor = 0,
        MailAppliciant,
        MailPreAll,
        MailPre,
        MailCurrentLevel,
        MailNext,
        MailNextAll
    }

    /// <summary>
    /// Read Setting
    /// </summary>
    public enum ReadSetting
    {
        ReadAuthor = 0,
        MailAppliciant,
        MailPreAll,
        MailPre,
        MailGroup
    }

    /// <summary>
    /// Authority Master
    /// </summary>
    public enum AuthorTypeMaster
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete
    }

    /// <summary>
    /// Authority Work
    /// </summary>
    public enum AuthorTypeApplyRegist
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete,
        Confirm
    }

    /// <summary>
    /// Authority Daily
    /// </summary>
    public enum AuthorTypeDaily
    {
        View = 1,
        New,
        Edit,
        Copy,
        Delete
    }

    /// <summary>
    /// Authority Approve
    /// </summary>
    public enum AuthorTypeApplyApprove
    {
        View = 1,
        Approve,
        Reject,
        Remand
    }

    /// <summary>
    /// Language 
    /// </summary>
    /// <remarks></remarks>
    public enum Language
    {
        /// <summary>
        /// Read number with english
        /// </summary>
        /// <remarks></remarks>
        English,

        /// <summary>
        /// Read number with vietnam
        /// </summary>
        /// <remarks></remarks>
        Vietnam,

        /// <summary>
        /// Read number with japan
        /// </summary>
        /// <remarks></remarks>
        Japan

    }

    /// <summary>
    /// Get User result
    /// </summary>
    public enum UserResultStatus
    {
        EmptyUserCD = -2,
        NotExists = -1,
        NotApproved = 0,
        Disabled = 1,
        Sucessed = 2
    }
    
    /// <summary>
    /// Warranty Unit
    /// </summary>
    public enum WarrantyUnit
    {
        None = 0,
        Years,
        Months,
        Weeks,
        Days
    }

    /// <summary>
    /// Status Approve
    /// </summary>
    public enum StatusApprove
    {
        None = 0,
        New = 1,
        Confirm = 2,
        Approve = 3,
        Complete = 4,
        Ignore = 5,
        BackPrev
    }

    /// <summary>
    /// Status Of Apply
    /// </summary>
    public enum StatusApply
    {
        None = 0,
        Draft,
        Approving,
        Approved,
        Rejected,
        Cancel,
        BackPrev
    }

    /// <summary>
    /// Status Has Approve
    /// </summary>
    public enum StatusHasAprove
    {
        New = 0,
        Approved,
        Ignore,
        BackPrev
    }

    /// <summary>
    /// Approve_Ignore
    /// </summary>
    public enum Approve_Ignore
    {
        Cancel = 0,
        OK = 1
    }

    /// <summary>
    /// Status Route Method
    /// </summary>
    public enum RouteMethods
    {
        AND = 1,
        OR
    }

    /// <summary>
    /// During Day Flag
    /// ISV-TRUC
    /// 2015/03/17
    /// </summary>
    public enum DuringDayFlag
    {
        None = 0,
        DuringDay
    }

    /// <summary>
    /// FormID
    /// ISV-NHAT
    /// 2015/03/19
    /// </summary>
    public enum TypeFormID
    {
        Apply = 1,
        Vacation = 2
    }

    /// <summary>
    /// SubVacation
    /// ISV-NHAT
    /// 2015/03/19
    /// </summary>
    public enum SubVacation
    {
        None = 0,
        DeductingSalary = 1,
        DeductingDayOff = 2
    }

    /// <summary>
    /// Daily Total View
    /// ISV-NHAT
    /// 2015/03/19
    /// </summary>
    public enum DailyTotalView
    {
        Invisible = 0,
        Visible = 1
    }

    /// <summary>
    /// Type Perform
    /// ISV-TRUC
    /// 2015/03/24
    /// </summary>
    public enum TypePerform
    {
        Morning = 1,
        Afternoon,
        FullDay
    }

    /// <summary>
    /// TypeOfList
    /// 2015/04/02
    /// </summary>
    public enum EnumTypeOfList
    {
        VacRegist = 1,
        VacApprove = 2
    }

    /// <summary>
    /// TimeOfRule : Leave
    /// </summary>
    public enum TimeOfRuleLeave
    {
        None = 1,
        TruLuong,
        // LamBu,
        // NghiBu,
        TruPhep
    }

    /// <summary>
    /// TimeOfRule :  Time & Attendance 
    /// </summary>
    public enum TimeOfRuleTimeAttendance
    {
        None = 1,
        TruLuong,
        CongLuong,
        LamBu,
        NghiBu
    }

    /// <summary>
    /// EnumGetLevelZero
    /// </summary>
    public enum EnumGetLevelZero
    {
        Exclude = 0,
        Include,
        Only
    }

    /// <summary>
    /// Send Mail Mode
    /// </summary>
    public enum SendMailMode
    {
        Applicant = 0,
        LessLevel,
        PreviousLevel,
        CurrentLevel,
        NextLevel,
        GreaterLevel,
        ReaderLevel
    }

    /// <summary>
    /// Type Of Setting Send Mail
    /// </summary>
    public enum TypeSettingMail
    {
        Apply = 0,
        Reject,
        Remand,
        Approve,
        Read
    }

    /// <summary>
    /// Type Of Vacation
    /// </summary>
    public enum VacationType
    {
        MorningOff = 1,
        AfternoonOff,
        DayOff
    }

    /// <summary>
    /// Type Of Day
    /// </summary>
    public enum TypeOfDay
    {
        WorkDay = 0,
        HalfWorkDay,
        DayOff,
        HalfDayOff
    }

    /// <summary>
    /// Type
    /// </summary>
    public enum ShiftType
    {
        Attendance = 1,
        PaidVacation
    }

    public enum ProcessResult
    {
        Success = 0,
        DataChanged,
        NotEnoughAnnualDays,
        ProcessFail,
        MailFail
    }

    public enum ApplyType
    {
        Vacation = 0,
        OverTime,
        LateEarlyOuting,
        Absence
    }
}
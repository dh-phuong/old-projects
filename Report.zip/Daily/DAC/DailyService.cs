﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// DailyService
    /// ISV-TRAM 2015/03/02
    /// </summary>
    public class DailyService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private DailyService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public DailyService(DB db)
            : base(db)
        {
        }
        #endregion
        #region Get data

        /// <summary>
        /// Get by condition
        /// </summary>
        public IList<DailyInfo> GetByCondition(DateTime workDate, int userID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetByCondition";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkDate", workDate);
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.FindList<DailyInfo>(cmdText, paras);
        }

        public IList<DailyInfo> GetByWeek(DateTime workDate, string groupCd)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetByWeek";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkDate", workDate);
            base.AddParam(paras, "IN_GroupCd", groupCd);

            return this.db.FindList<DailyInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get by ID
        /// </summary>
        /// <param name="dailyID"></param>
        /// <returns>T_Daily model</returns>
        public T_Daily GetByID(int dailyID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DailyID", dailyID);

            return this.db.Find<T_Daily>(cmdText, paras);
        }

        /// <summary>
        /// Get by ApplyID
        /// </summary>
        /// <param name="applyID">ApplyID</param>
        /// <returns>List of T_Daily model</returns>
        public IList<T_Daily> GetByApplyID(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetByApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);

            return this.db.FindList<T_Daily>(cmdText, paras);
        }


        /// <summary>
        /// GetByVacationID
        /// 2015/04/06
        /// ISV-TRUC
        /// </summary>
        /// <param name="vacationID"></param>
        /// <returns></returns>
        public T_Daily GetByVacationID(int vacationID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetByVacationID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);

            return this.db.Find<T_Daily>(cmdText, paras);
        }   

        /// <summary>
        /// Get By Calendar
        /// </summary>
        /// <param name="month">month</param>
        /// <param name="year">year</param>
        /// <returns></returns>
        public IList<CalendarInfo> GetCalendarByDept(DateTime dateForm, DateTime dateTo, string departmentID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetCalendarByDept";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_DepartmentID", departmentID);

            return this.db.FindList<CalendarInfo>(cmdText, paras);
        }

        public IList<CalendarInfo> GetCalendarByUser(DateTime dateForm, DateTime dateTo, string userID)
        {
            //SQL String
            string cmdText = "P_T_Daily_GetCalendarByUser";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.FindList<CalendarInfo>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="daily">T_Daily</param>
        /// <returns></returns>
        public int Insert(T_Daily daily)
        {
            //SQL String
            string cmdText = "P_T_Daily_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", daily.UserID);
            base.AddParam(paras, "IN_WorkDate", daily.WorkDate);
            base.AddParam(paras, "IN_Type", daily.TypeApplyID);
            base.AddParam(paras, "IN_ApplyID", daily.ApplyID);
            base.AddParam(paras, "IN_VacationID", daily.VacationID);
            base.AddParam(paras, "IN_StartHour", daily.StartHour);
            base.AddParam(paras, "IN_StartMinute", daily.StartMinute);
            base.AddParam(paras, "IN_EndHour", daily.EndHour);
            base.AddParam(paras, "IN_EndMinute", daily.EndMinute);
            base.AddParam(paras, "IN_Content", daily.Content);
            base.AddParam(paras, "IN_DeleteFlag", daily.DeleteFlag);
            base.AddParam(paras, "IN_CreateUID", daily.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", daily.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);

        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="daily">T_Daily</param>
        /// <returns></returns>
        public int Update(T_Daily daily)
        {
            //SQL String
            string cmdText = "P_T_Daily_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", daily.ID);
            base.AddParam(paras, "IN_UserID", daily.UserID);
            base.AddParam(paras, "IN_WorkDate", daily.WorkDate);
            base.AddParam(paras, "IN_Type", daily.TypeApplyID);
            base.AddParam(paras, "IN_ApplyID", daily.ApplyID);
            base.AddParam(paras, "IN_VacationID", daily.VacationID);
            base.AddParam(paras, "IN_StartHour", daily.StartHour);
            base.AddParam(paras, "IN_StartMinute", daily.StartMinute);
            base.AddParam(paras, "IN_EndHour", daily.EndHour);
            base.AddParam(paras, "IN_EndMinute", daily.EndMinute);
            base.AddParam(paras, "IN_Content", daily.Content);
            base.AddParam(paras, "IN_DeleteFlag", daily.DeleteFlag);
            base.AddParam(paras, "IN_UpdateDate", daily.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", daily.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update DeleteFlag
        /// </summary>
        /// <param name="daily"></param>
        /// <returns></returns>
        public int UpdateDeleteFlag(T_Daily daily)
        {
            //SQL String
            string cmdText = "P_T_Daily_UpdateDeleteFlag";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ApplyID", daily.ApplyID);
            base.AddParam(paras, "IN_DeleteFlag", daily.DeleteFlag);
            base.AddParam(paras, "IN_UpdateDate", daily.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", daily.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Daily_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// DeleteByApplyID
        /// 2015/04/06
        /// ISV-TRUC
        /// </summary>
        /// <param name="vacationID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int DeleteByApplyID(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Daily_DeleteByApplyID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_DeletedFlg", (int)DeleteFlag.Deleted);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using DailyReport.Models;
using System.Globalization;

namespace DailyReport.DAC
{
    public class AccountingService : BaseService
    {
        #region Constructor

        private AccountingService()
            : base()
        {

        }

        public AccountingService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get data
        /// </summary>
        /// <returns>M_User</returns>
        public M_Accounting GetData()
        {
            //SQL String
            string cmdText = "P_M_Accounting_GetData";
            //Para            
            return this.db.Find<M_Accounting>(cmdText);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public AccountingPeriod GetAccountingMonth(DateTime date)
        {
            M_Accounting acc = this.GetData();
            if (date.Day > acc.ClosingDay)
            {
                date = date.AddMonths(1);
            }
            return this.GetPeriodMonth(date.Year, date.Month, acc.ClosingDay);
        }

        public AccountingPeriod GetAccountingMonth(DateTime date, int closingDay)
        {
            if (date.Day > closingDay)
            {
                date = date.AddMonths(1);
            }
            return this.GetPeriodMonth(date.Year, date.Month, closingDay);
        }

        public IList<string> GetListMonthName()
        {
            M_Accounting acc = this.GetData();
            IList<string> lstMonth = new List<string>();
            DateTime dt = new DateTime(DateTime.Now.Year, acc.StartMonth, 1);
            lstMonth.Add(dt.ToString("MMM", CultureInfo.InvariantCulture));
            for (int i = 0; i < 11; i++)
            {
                dt = dt.AddMonths(1);
                lstMonth.Add(dt.ToString("MMM", CultureInfo.InvariantCulture));
            }

            return lstMonth;
        }

        public AccountingPeriod GetAccountingYear(DateTime date)
        {
            M_Accounting acc = this.GetData();

            int yearFrom = 0;
            if (acc.StartMonth > date.Month)
            {
                yearFrom = date.Year - 1;
            }
            else
            {
                yearFrom = date.Year;
            }
            //-------------------------------                        
            AccountingPeriod periodM = GetPeriodMonth(yearFrom, acc.StartMonth, acc.ClosingDay);

            //-------------------------------  
            AccountingPeriod _periodY = new AccountingPeriod();
            _periodY.StartDate = periodM.StartDate;
            _periodY.EndDate = GetPeriodMonth(periodM.StartDate.AddMonths(11).Year, periodM.EndDate.AddMonths(11).Month, acc.ClosingDay).EndDate;

            return _periodY;
        }

        public AccountingPeriod GetPeriodMonth(int year, int month, int closeday)
        {
            int daysInMonth = DateTime.DaysInMonth(year, month);
            DateTime endDate;
            if (daysInMonth < closeday)
            {
                endDate = new DateTime(year, month, daysInMonth);
            }
            else
            {
                endDate = new DateTime(year, month, closeday);
            }

            DateTime startDate = endDate.AddMonths(-1).AddDays(1);
            while (startDate.Day <= closeday && startDate.Month != endDate.Month)
            {
                startDate = startDate.AddDays(1);
            }

            AccountingPeriod period = new AccountingPeriod();
            period.StartDate = startDate;
            period.EndDate = endDate;

            return period;
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="accounting">M_Accounting</param>
        /// <returns></returns>
        public int Insert(M_Accounting accounting)
        {
            //SQL String
            string cmdText = "P_M_Accounting_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StartMonth", accounting.StartMonth);
            base.AddParam(paras, "IN_ClosingDay", accounting.ClosingDay);
            base.AddParam(paras, "IN_NumOfDay", accounting.NumOfDay);
            base.AddParam(paras, "IN_NumOfTime_H", accounting.NumOfTime_H);
            base.AddParam(paras, "IN_NumOfTime_M", accounting.NumOfTime_M);
            base.AddParam(paras, "IN_UnitOfTime", accounting.UnitOfTime);
            base.AddParam(paras, "IN_RoundLate", accounting.RoundLate);
            base.AddParam(paras, "IN_RoundLeave", accounting.RoundLeave);
            base.AddParam(paras, "IN_RoundOuting", accounting.RoundOuting);
            base.AddParam(paras, "IN_RoundOT", accounting.RoundOT);
            base.AddParam(paras, "IN_EarlyOT_SH", accounting.EarlyOT_SH);
            base.AddParam(paras, "IN_EarlyOT_SM", accounting.EarlyOT_SM);
            base.AddParam(paras, "IN_EarlyOT_EH", accounting.EarlyOT_EH);
            base.AddParam(paras, "IN_EarlyOT_EM", accounting.EarlyOT_EM);
            base.AddParam(paras, "IN_LateOT_SH", accounting.LateOT_SH);
            base.AddParam(paras, "IN_LateOT_SM", accounting.LateOT_SM);
            base.AddParam(paras, "IN_LateOT_EH", accounting.LateOT_EH);
            base.AddParam(paras, "IN_LateOT_EM", accounting.LateOT_EM);
            base.AddParam(paras, "IN_CreateUID", accounting.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", accounting.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="accounting">M_Accounting</param>
        /// <returns></returns>
        public int Update(M_Accounting accounting)
        {
            //SQL String
            string cmdText = "P_M_Accounting_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StartMonth", accounting.StartMonth);
            base.AddParam(paras, "IN_ClosingDay", accounting.ClosingDay);
            base.AddParam(paras, "IN_NumOfDay", accounting.NumOfDay);
            base.AddParam(paras, "IN_NumOfTime_H", accounting.NumOfTime_H);
            base.AddParam(paras, "IN_NumOfTime_M", accounting.NumOfTime_M);
            base.AddParam(paras, "IN_UnitOfTime", accounting.UnitOfTime);
            base.AddParam(paras, "IN_RoundLate", accounting.RoundLate);
            base.AddParam(paras, "IN_RoundLeave", accounting.RoundLeave);
            base.AddParam(paras, "IN_RoundOuting", accounting.RoundOuting);
            base.AddParam(paras, "IN_RoundOT", accounting.RoundOT);
            base.AddParam(paras, "IN_EarlyOT_SH", accounting.EarlyOT_SH);
            base.AddParam(paras, "IN_EarlyOT_SM", accounting.EarlyOT_SM);
            base.AddParam(paras, "IN_EarlyOT_EH", accounting.EarlyOT_EH);
            base.AddParam(paras, "IN_EarlyOT_EM", accounting.EarlyOT_EM);
            base.AddParam(paras, "IN_LateOT_SH", accounting.LateOT_SH);
            base.AddParam(paras, "IN_LateOT_SM", accounting.LateOT_SM);
            base.AddParam(paras, "IN_LateOT_EH", accounting.LateOT_EH);
            base.AddParam(paras, "IN_LateOT_EM", accounting.LateOT_EM);
            base.AddParam(paras, "IN_UpdateDate", accounting.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", accounting.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}



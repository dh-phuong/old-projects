﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using DailyReport.Models;

namespace DailyReport.DAC
{
    public class StaffAllowanceService : BaseService
    {
        #region Contructor

        private StaffAllowanceService()
            : base()
        { }

        public StaffAllowanceService(DB db)
            : base(db)
        { }

        #endregion

        #region GetData

        public IList<M_Staff_Allowance> GetBySalaryID(int salaryID)
        {
            //SQL String
            string cmdText = "P_M_StaffAllowance_GetBySalaryID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalaryID", salaryID);

            return this.db.FindList<M_Staff_Allowance>(cmdText, paras);
        }

        public IList<M_Staff_Allowance> GetByStaffID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_StaffAllowance_GetByStaffID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.FindList<M_Staff_Allowance>(cmdText, paras);
        }

        #endregion

        #region Insert

        public int Insert(M_Staff_Allowance allowance)
        {
            //SQL String
            string cmdText = "P_M_StaffAllowance_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalaryID", allowance.SalaryID);
            base.AddParam(paras, "IN_No", allowance.No);
            base.AddParam(paras, "IN_AllowanceName", allowance.AllowanceName);
            base.AddParam(paras, "IN_Allowance", allowance.Allowance);
            base.AddParam(paras, "IN_AccountingFlag", allowance.AccountingFlag);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region DeleteData

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Delete(int salaryID)
        {
            //SQL String
            string cmdText = "P_M_StaffAllowance_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SalaryID", salaryID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// ISV-TRUC 2015/04/27
    /// Class FormTypeService
    /// </summary>
    public class FormTypeService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of FormTypeService
        /// </summary>
        private FormTypeService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of  Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public FormTypeService(DB db)
            : base(db)
        {
            
        }

        #endregion

        #region Get

        /// <summary>
        /// Get by id
        /// Author: VN-Nho
        /// Create Date: 2015.05.08
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        public M_Form_Type GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_GetByID";
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<M_Form_Type>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// ISV-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<FormTypeInfo> GetListByFormID(int formID)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_GetListByFormID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.FindList<FormTypeInfo>(cmdText, paras);
        }

        /// <summary>
        /// Function: Get data for dropdownlist
        /// Author: VN-Nho
        /// Create date: 2015.05.07
        /// </summary>
        /// <param name="formID">form id</param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdownList(int formID)
        {
            //Command text
            string cmdText = "P_M_Form_Type_GetDataForDropdownList";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_FormID", formID);

            return this.db.FindList<DropDownModel>(cmdText, prms);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="header">M_Form_Type</param>
        /// <returns></returns>
        public int Insert(M_Form_Type header)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", header.FormID);
          //  base.AddParam(paras, "IN_ID", header.ID);            
            base.AddParam(paras, "IN_TypeName", header.TypeName);
            base.AddParam(paras, "IN_TimeOfRule", header.TimeOfRule);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="header">M_Form_Type</param>
        /// <returns></returns>
        public int Update(M_Form_Type header)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_Update";

            //Param
            Hashtable paras = new Hashtable();           
            base.AddParam(paras, "IN_ID", header.ID);            
            base.AddParam(paras, "IN_TypeName", header.TypeName);
            base.AddParam(paras, "IN_TimeOfRule", header.TimeOfRule);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete Data
        /// ISV-TRUC
        /// 2015/05/04
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public int Delete(int formID)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_DeleteByFormID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// DeleteByTypeID
        /// 2015/05/05
        /// ISV-TRUC
        /// </summary>
        /// <param name="typeID"></param>
        /// <returns></returns>
        public int DeleteByTypeID(int typeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Type_DeleteByTypeID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", typeID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

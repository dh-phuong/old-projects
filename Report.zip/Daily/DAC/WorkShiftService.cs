﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using DailyReport.Models;

namespace DailyReport.DAC
{
    public class WorkShiftService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Holiday service
        /// </summary>        
        private WorkShiftService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Holiday service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkShiftService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        public M_Work_Shift GetByID(int workingshiftID)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", workingshiftID);

            return this.db.Find<M_Work_Shift>(cmdText, paras);
        }

        public M_Work_Shift GetByCode(int workingshiftcode)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByShiftCode";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ShiftCode", workingshiftcode);

            return this.db.Find<M_Work_Shift>(cmdText, paras);
        }

        /// <summary>
        /// Get by ShiftCode
        /// TRAM - 2015/06/01
        /// </summary>
        /// <param name="shiftCode"></param>
        /// <returns></returns>
        public M_Work_Shift GetByShiftCode(int? shiftCode)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByShiftCode";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ShiftCode", shiftCode);

            return this.db.Find<M_Work_Shift>(cmdText, paras);
        }

        /// <summary>
        /// Get by woking date
        /// VN-Nho
        /// </summary>
        /// <param name="date">Working date</param>
        /// <returns></returns>
        public M_Work_Shift GetByDate(DateTime date)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByDate";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Date", date);

            return this.db.Find<M_Work_Shift>(cmdText, paras);
        }

        /// <summary>
        /// Get data for drop down list
        /// </summary>
        /// <param name="withBlank">insert blank flag</param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDown(int type, bool withBlank = false)
        {
            string cmdText = "P_M_Work_Shift_GetDataForDropDown";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);

            IList<DropDownModel> lstRet = db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                lstRet.Insert(0, new DropDownModel() { Value = "-1", DisplayName = "---" });
            }
            return lstRet;
        }

        public IList<WorkShiftInfo> GetListByCond(int shiftcode, string shiftname, int typeofday, int type,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            if (shiftcode == -1)
            {
                base.AddParam(paras, "IN_ShiftCode", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ShiftCode", shiftcode);
            }

            base.AddParam(paras, "IN_ShiftName", shiftname);

            if (typeofday == -1)
            {
                base.AddParam(paras, "IN_TypeOfDay", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeOfDay", typeofday);
            }

            if (type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", type);
            }

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<WorkShiftInfo>(cmdText, paras);
        }

        public int GetTotalRow(int shiftcode, string shiftname, int typeofday, int type)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();

            if (shiftcode == -1)
            {
                base.AddParam(paras, "IN_ShiftCode", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ShiftCode", shiftcode);
            }

            base.AddParam(paras, "IN_ShiftName", shiftname);

            if (typeofday == -1)
            {
                base.AddParam(paras, "IN_TypeOfDay", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeOfDay", typeofday);
            }

            if (type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", type);
            }


            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetCountByConditionForSearch
        /// </summary>
        /// <param name="shiftCode">ShiftCode</param>
        /// <param name="shiftName">ShiftName</param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(int? shiftCode, string shiftName)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetCountByConditionForSeach";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ShiftCode", shiftCode, true);
            base.AddParam(paras, "IN_ShiftName", shiftName, true);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="shiftCode"></param>
        /// <param name="shiftName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<WorkingShiftSearchInfo> GetListByConditionForSearch(int? shiftCode, string shiftName, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_GetByConditionsForSearch";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ShiftCode", shiftCode, true);
            base.AddParam(paras, "IN_ShiftName", shiftName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<WorkingShiftSearchInfo>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">M_Work_Shift</param>
        /// <returns></returns>
        public int Insert(M_Work_Shift workingshift)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ShiftCode", workingshift.ShiftCode);

            if (workingshift.StartHour == null || workingshift.StartMinute == null ||
                workingshift.EndHour == null || workingshift.EndMinute == null)
            {
                base.AddParam(paras, "IN_StartHour", DBNull.Value);
                base.AddParam(paras, "IN_StartMinute", DBNull.Value);
                base.AddParam(paras, "IN_EndHour", DBNull.Value);
                base.AddParam(paras, "IN_EndMinute", DBNull.Value);
                base.AddParam(paras, "IN_DurationHour", DBNull.Value);
                base.AddParam(paras, "IN_DurationMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StartHour", workingshift.StartHour);
                base.AddParam(paras, "IN_StartMinute", workingshift.StartMinute);
                base.AddParam(paras, "IN_EndHour", workingshift.EndHour);
                base.AddParam(paras, "IN_EndMinute", workingshift.EndMinute);
                base.AddParam(paras, "IN_DurationHour", workingshift.DurationHour);
                base.AddParam(paras, "IN_DurationMinute", workingshift.DurationMinute);
            }

            base.AddParam(paras, "IN_ShiftName", workingshift.ShiftName);
            base.AddParam(paras, "IN_TypeOfDay", workingshift.TypeOfDay);
            base.AddParam(paras, "IN_Type", workingshift.Type);
            base.AddParam(paras, "IN_CreateUID", workingshift.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", workingshift.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_Work_Shift</param>
        /// <returns></returns>
        public int Delete(int workingshiftID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", workingshiftID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_Work_Shift</param>
        /// <returns></returns>
        public int Update(M_Work_Shift workingshift)
        {
            //SQL String
            string cmdText = "P_M_Work_Shift_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", workingshift.ID);

            if (workingshift.StartHour == null || workingshift.StartMinute == null ||
                workingshift.EndHour == null || workingshift.EndMinute == null)
            {
                base.AddParam(paras, "IN_StartHour", DBNull.Value);
                base.AddParam(paras, "IN_StartMinute", DBNull.Value);
                base.AddParam(paras, "IN_EndHour", DBNull.Value);
                base.AddParam(paras, "IN_EndMinute", DBNull.Value);
                base.AddParam(paras, "IN_DurationHour", DBNull.Value);
                base.AddParam(paras, "IN_DurationMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StartHour", workingshift.StartHour);
                base.AddParam(paras, "IN_StartMinute", workingshift.StartMinute);
                base.AddParam(paras, "IN_EndHour", workingshift.EndHour);
                base.AddParam(paras, "IN_EndMinute", workingshift.EndMinute);
                base.AddParam(paras, "IN_DurationHour", workingshift.DurationHour);
                base.AddParam(paras, "IN_DurationMinute", workingshift.DurationMinute);
            }

            base.AddParam(paras, "IN_ShiftName", workingshift.ShiftName);
            base.AddParam(paras, "IN_TypeOfDay", workingshift.TypeOfDay);
            base.AddParam(paras, "IN_Type", workingshift.Type);
            base.AddParam(paras, "IN_UpdateDate", workingshift.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", workingshift.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

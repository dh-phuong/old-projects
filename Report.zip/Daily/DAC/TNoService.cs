﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class T_No Service
    /// Create Date: 2014/08/11
    /// Create Author: ISV-PHUONG
    /// </summary>
    public sealed class TNoService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of T_No service
        /// </summary>        
        public TNoService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of T_No service
        /// </summary>
        /// <param name="db">Class DB</param>
        public TNoService(DB db)
            : base(db)
        {
        }


        /// <summary>
        /// Create No
        /// </summary>
        public string CreateNo(string ItemNo)
        {
            string cmdText = "P_GetCurrentNo";
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_No", ItemNo);

            var no = base.db.ExecuteScalar(cmdText, paras);
            if (no != null && (int)no >= Utilities.Constants.MAX_NO)
            {
                throw new OverflowException(string.Format("Can't create {0} because of overflowing.", ItemNo));
            }
            cmdText = "P_CreateNo";
            var result = (string)base.db.ExecuteScalar(cmdText, paras);
            return result;
        }

        #endregion
    }
}

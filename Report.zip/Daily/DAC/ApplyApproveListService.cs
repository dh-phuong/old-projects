﻿using System;
using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using DailyReport.Utilities;
using System.Data.Common;

namespace DailyReport.DAC
{
    /// <summary>
    /// ApplyApproveListService
    /// ISV-TRAM
    /// 2015.03.24
    /// </summary>
    public class ApplyApproveListService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private ApplyApproveListService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public ApplyApproveListService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="applyID">applyID</param>
        /// <returns>List of ApplyApproveListInfo model</returns>
        public IList<ApplyApproveListInfo> GetByID(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);

            return this.db.FindList<ApplyApproveListInfo>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// </summary>
        /// <param name="applyID"></param>
        /// <returns></returns>
        public IList<ApplyApproveListModel> GetByID2(int applyID, bool includeLvZero = false)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_GetByID2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            if (includeLvZero)//lay level 0 luon
            {
                base.AddParam(paras, "IN_RouteLvZero", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_RouteLvZero", M_Route_H.LEVEL_APPLICANT);
            }
            return this.db.FindList<ApplyApproveListModel>(cmdText, paras);
        }


        /// <summary>
        /// Get approve list data
        /// </summary>
        /// <param name="applyID">apply id</param>
        /// <param name="userID">user id</param>
        /// <returns></returns>
        public T_Apply_Approve_List GetApproveRow(int applyID, int userID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetApproveRow";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_ApprovedStatus", (int)StatusApply.Approved);
            
            return this.db.Find<T_Apply_Approve_List>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <returns></returns>
        public IList<ApplyApproveListModel> GetListByIDOptionLevel2(int applyID, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_GetListByIDOptionLevel2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            if (isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }

            if (isGetLVZero == EnumGetLevelZero.Only)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
            }
            else if (isGetLVZero == EnumGetLevelZero.Exclude)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
            }
            else if (isGetLVZero == EnumGetLevelZero.Include)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
            }
            base.AddParam(paras, "IN_RouteLvZero", M_Route_H.LEVEL_APPLICANT);
            return this.db.FindList<ApplyApproveListModel>(cmdText, paras);
        }

        /// <summary>
        /// Get Approver List By UserID
        /// ISV-TRUC
        /// 2015/04/16
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public IList<ApplyApproveListInfo> GetApproverListByTypeAndUserID(int formId,int userID, bool isGetViewLevel =false)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetApproverListByTypeAndUserID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_FormID", formId);
            if (isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }
            
            return this.db.FindList<ApplyApproveListInfo>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC New
        /// </summary>
        /// <param name="formId"></param>
        /// <param name="userID"></param>
        /// <param name="isGetViewLevel"></param>
        /// <returns></returns>
        public IList<ApplyApproveListModel> GetApproverListByTypeAndUserID2(int formId, int userID, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetApproverListByTypeAndUserID2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_FormID", formId);
            if (isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }

            if (isGetLVZero == EnumGetLevelZero.Only)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
            }
            else if (isGetLVZero == EnumGetLevelZero.Exclude)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
            }
            else if (isGetLVZero == EnumGetLevelZero.Include)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
            }
            base.AddParam(paras, "IN_ZeroLV", M_Route_H.LEVEL_APPLICANT);
            return this.db.FindList<ApplyApproveListModel>(cmdText, paras);
        }


        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="applyID">applyID</param>
        /// <returns>List of ApplyApproveListInfo model</returns>
        public int GetMinRouteLevelByID(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_GetMinRouteLevelByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }


        /// <summary>
        /// GetByID
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID">applyID</param>
        /// <returns>List of ApplyApproveListInfo model</returns>
        public int GetMinRouteLevelByID2(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_GetMinRouteLevelByID2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get count by UserID
        /// </summary>
        /// <param name="userID">UserID</param>
        /// <returns></returns>
        public int GetCountByUserID(int userID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetCountByUserID";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_StatusReject", (short)StatusApply.Rejected);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_StatusDraft", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_StatusCancel", (short)StatusApply.Cancel);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by Key
        /// </summary>
        /// <param name="applyID">Apply ID</param>
        /// <param name="routeUID">Route User id</param>
        /// <returns></returns>
        public T_Apply_Approve_List GetByKey(int applyID, int routeUID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_RouteUID", routeUID);

            return this.db.Find<T_Apply_Approve_List>(cmdText, paras);
        }

        /// <summary>
        /// Get by Key
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID">Apply ID</param>
        /// <param name="routeUID">Route User id</param>
        /// <returns></returns>
        public T_Apply_Approve_List GetByKey2(int applyID, int routeUID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetByKey2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_RouteUID", routeUID);

            return this.db.Find<T_Apply_Approve_List>(cmdText, paras);
        }

        ///// <summary>
        ///// Get list Email By Level
        ///// </summary>
        ///// <param name="applyID">Apply id</param>
        ///// <param name="level">level</param>
        ///// <returns></returns>
        //public IList<string> GetListEmailByLevelAprove(int applyID, int level)
        //{
        //    string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelAprove";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApplyID", applyID);
        //    base.AddParam(paras, "IN_Level", level);

        //    IList<string> ret = new List<string>();
        //    using (DbCommand cmd = db.con.CreateCommand())
        //    {
        //        cmd.Transaction = db.trans;
        //        db.SetCommand(cmd, cmdText, paras);
        //        using (DbDataReader dr = cmd.ExecuteReader())
        //        {
        //            while (dr.Read())
        //            {
        //                ret.Add(dr["Email"].ToString());
        //            }
        //        }
        //    }

        //    return ret;
        //}

        /// <summary>
        /// TRAM - 2015/05/28
        /// Get list email by level approve 
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="approveStatus"></param>
        /// <returns></returns>
        public IList<string> GetListEmailByLevelAprove(int applyID, int currenLevel, int sendMailMode)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelAprove";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_CurrLevel", currenLevel);
            base.AddParam(paras, "IN_SendMailMode", sendMailMode);
            //base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
          
        }

        ///// <summary>
        ///// Get list Email By Level
        ///// </summary>
        ///// <param name="applyID">Apply id</param>
        ///// <param name="level">level</param>
        ///// <returns></returns>
        //public IList<T_Apply_Approve_List> GetListEmailByLevelAprove(int applyID, int level)
        //{
        //    string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelAprove";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApplyID", applyID);
        //    base.AddParam(paras, "IN_Level", level);

        //    IList<string> ret = new List<string>();
        //    using (DbCommand cmd = db.con.CreateCommand())
        //    {
        //        cmd.Transaction = db.trans;
        //        db.SetCommand(cmd, cmdText, paras);
        //        using (DbDataReader dr = cmd.ExecuteReader())
        //        {
        //            while (dr.Read())
        //            {
        //                ret.Add(dr["Email"].ToString());
        //            }
        //        }
        //    }

        //    return ret;
        //}


        /// <summary>
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        public IList<string> GetListEmailByLevelAprove2(int applyID, int currenLevel, int sendMailMode, int approveUID = -1)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelAprove2";
           
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_CurrLevel", currenLevel);
            base.AddParam(paras, "IN_SendMailMode", sendMailMode);
            if (approveUID == -1)
            {
                base.AddParam(paras, "IN_ApproveUID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApproveUID", approveUID);
            }
            //base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Test 2015/06/02
        /// ISV-TRUC
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="currenLevel"></param>
        /// <param name="sendMailMode"></param>
        /// <param name="approveUID"></param>
        /// <returns></returns>
        public IList<M_User> GetListEmailByLevelAproveTest(int applyID, int currenLevel, int sendMailMode, int approveUID = -1)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelAproveTest";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_CurrLevel", currenLevel);
            base.AddParam(paras, "IN_SendMailMode", sendMailMode);
            if (approveUID == -1)
            {
                base.AddParam(paras, "IN_ApproveUID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApproveUID", approveUID);
            }
            //base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            return this.db.FindList<M_User>(cmdText, paras);
        }


        /// <summary>
        /// Get list Email By Level
        /// </summary>
        /// <param name="applyID">Apply id</param>
        /// <param name="level">level</param>
        /// <returns></returns>
        public IList<string> GetListEmailByLevelRemand(int applyID, int level)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelRemand";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_Level", level);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        public IList<string> GetListEmailByLevelRemand2(int applyID, int level)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailByLevelRemand2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_Level", level);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Get list Email By Level
        /// </summary>
        /// <param name="applyID">Apply id</param>
        /// <param name="level">level</param>
        /// <returns></returns>
        public IList<string> GetListEmailApproveByOthers(int applyID, int routeUID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailApproveByOthers";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_RouteUID", routeUID);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="routeUID"></param>
        /// <returns></returns>
        public IList<string> GetListEmailApproveByOthers2(int applyID, int routeUID)
        {
            string cmdText = "P_T_Apply_Approve_List_GetListEmailApproveByOthers2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_RouteUID", routeUID);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int Insert(T_Apply_Approve_List app)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", app.ApplyID);
            base.AddParam(paras, "IN_RouteUID", app.RouteUID);
            base.AddParam(paras, "IN_RouteLevel", app.RouteLevel);
            base.AddParam(paras, "IN_RouteMethod", app.RouteMethod);
            base.AddParam(paras, "IN_ApproveStatus", app.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", app.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", app.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", app.ApproveReason,true);
            base.AddParam(paras, "IN_RequireNum", app.RequireNum);

            //base.AddParam(paras, "IN_RouteFlag1", app.RouteFlag1);
            //base.AddParam(paras, "IN_RouteFlag2", app.RouteFlag2);
            //base.AddParam(paras, "IN_RouteFlag3", app.RouteFlag3);
            //base.AddParam(paras, "IN_RouteFlag4", app.RouteFlag4);
            //base.AddParam(paras, "IN_RouteFlag5", app.RouteFlag5);
            //base.AddParam(paras, "IN_RouteFlag6", app.RouteFlag6);
            //base.AddParam(paras, "IN_RouteFlag7", app.RouteFlag7);
            //base.AddParam(paras, "IN_RouteFlag8", app.RouteFlag8);
            //base.AddParam(paras, "IN_RouteFlag9", app.RouteFlag9);
            //base.AddParam(paras, "IN_RouteFlag10", app.RouteFlag10);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC Add new
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public int Insert2(T_Apply_Approve_List app)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Insert2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", app.ApplyID);
            base.AddParam(paras, "IN_RouteUID", app.RouteUID);
            base.AddParam(paras, "IN_RouteLevel", app.RouteLevel);
            base.AddParam(paras, "IN_RouteMethod", app.RouteMethod);
            base.AddParam(paras, "IN_ApproveStatus", app.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", app.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", app.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", app.ApproveReason, true);
            base.AddParam(paras, "IN_RequireNum", app.RequireNum);
            base.AddParam(paras, "IN_ProxyApprovalUser", app.ProxyApprovalUser);

            #region Apply Flag
            base.AddParam(paras, "IN_ApplyFlag1", app.ApplyFlag1);
            base.AddParam(paras, "IN_ApplyFlag2", app.ApplyFlag2);
            base.AddParam(paras, "IN_ApplyFlag3", app.ApplyFlag3);
            base.AddParam(paras, "IN_ApplyFlag4", app.ApplyFlag4);
            #endregion
            
            #region RejectFlag
            base.AddParam(paras, "IN_RejectFlag1", app.RejectFlag1);
            base.AddParam(paras, "IN_RejectFlag2", app.RejectFlag2);
            base.AddParam(paras, "IN_RejectFlag3", app.RejectFlag3);
            base.AddParam(paras, "IN_RejectFlag4", app.RejectFlag4);
            base.AddParam(paras, "IN_RejectFlag5", app.RejectFlag5);
            base.AddParam(paras, "IN_RejectFlag6", app.RejectFlag6);
            base.AddParam(paras, "IN_RejectFlag7", app.RejectFlag7);
            #endregion

            #region RemandFlag
            base.AddParam(paras, "IN_RemandFlag1", app.RemandFlag1);
            base.AddParam(paras, "IN_RemandFlag2", app.RemandFlag2);
            base.AddParam(paras, "IN_RemandFlag3", app.RemandFlag3);
            base.AddParam(paras, "IN_RemandFlag4", app.RemandFlag4);
            base.AddParam(paras, "IN_RemandFlag5", app.RemandFlag5);
            base.AddParam(paras, "IN_RemandFlag6", app.RemandFlag6);
            base.AddParam(paras, "IN_RemandFlag7", app.RemandFlag7);
            #endregion

            #region ApproveFlag
            base.AddParam(paras, "IN_ApproveFlag1", app.ApproveFlag1);
            base.AddParam(paras, "IN_ApproveFlag2", app.ApproveFlag2);
            base.AddParam(paras, "IN_ApproveFlag3", app.ApproveFlag3);
            base.AddParam(paras, "IN_ApproveFlag4", app.ApproveFlag4);
            base.AddParam(paras, "IN_ApproveFlag5", app.ApproveFlag5);
            base.AddParam(paras, "IN_ApproveFlag6", app.ApproveFlag6);
            base.AddParam(paras, "IN_ApproveFlag7", app.ApproveFlag7);
            base.AddParam(paras, "IN_ApproveFlag8", app.ApproveFlag8);
            base.AddParam(paras, "IN_ApproveFlag9", app.ApproveFlag9);
            #endregion
            
            #region Read Flag
            base.AddParam(paras, "IN_ReadFlag1", app.ReadFlag1);
            base.AddParam(paras, "IN_ReadFlag2", app.ReadFlag2);
            base.AddParam(paras, "IN_ReadFlag3", app.ReadFlag3);
            base.AddParam(paras, "IN_ReadFlag4", app.ReadFlag4);
            base.AddParam(paras, "IN_ReadFlag5", app.ReadFlag5);
            #endregion

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Approve


        /// <summary>
        /// Approve ApproveStatus
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int Approve(T_Apply_Approve_List applyApproveList,short newStatus, short prevBackStatus)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
            base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
            base.AddParam(paras, "IN_NewStatus", newStatus);
            base.AddParam(paras, "IN_PrevBackStatus", prevBackStatus);
            base.AddParam(paras, "IN_LoginUID", applyApproveList.ApproveUID);
            base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);
           
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Approve 2
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <returns></returns>
        public int Approve2(int inID, int approveUID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Approve_2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", inID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            //base.AddParam(paras, "IN_RouteMethodOR", (short)RouteMethods.OR);
            base.AddParam(paras, "IN_Reason", reason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/28
        /// IT'S RIGHT
        /// </summary>
        /// <param name="inID"></param>
        /// <param name="approveUID"></param>
        /// <param name="statusApprove"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Approve2_2(int inID, int approveUID, int approveUserID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Approve2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", inID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            //base.AddParam(paras, "IN_RouteMethodOR", (short)RouteMethods.OR);
            base.AddParam(paras, "IN_Reason", reason);
            base.AddParam(paras, "IN_ApproveUserID", approveUserID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/05/29
        /// IT'S RIGHT
        /// </summary>
        /// <param name="inID"></param>
        /// <param name="approveUID"></param>
        /// <param name="approveUserID"></param>
        /// <param name="statusApprove"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Reject2(int inID, int approveUID, int approveUserID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Reject2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", inID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            //base.AddParam(paras, "IN_RouteMethodOR", (short)RouteMethods.OR);
            base.AddParam(paras, "IN_ApproveReason", reason, true);
            base.AddParam(paras, "IN_ApproveUserID", approveUserID);
            base.AddParam(paras, "IN_ApproveStatusNew", (int)StatusHasAprove.New);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// CheckApproveIsFinish
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="AppId"></param>
        /// <returns>true: finished, false: not finish </returns>
        public bool CheckApproveIsFinish(int AppId, int loginID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_CheckApproveFinish";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", AppId);
            base.AddParam(paras, "IN_LoginID", loginID);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }


        /// <summary>
        /// CheckApproveIsFinish 2
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="AppId"></param>
        /// <returns>true: finished, false: not finish </returns>
        public bool CheckApproveIsFinish2(int AppId, int loginID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_CheckApproveFinish2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", AppId);
            base.AddParam(paras, "IN_LoginID", loginID);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }

        /// <summary>
        /// CheckDisplayButton
        /// ISV-TRUC
        /// 2015/04/20
        /// true: dislay, false: not display
        /// </summary>
        /// <param name="AppId"></param>
        /// <param name="loginID"></param>
        /// <returns></returns>
        public bool CheckDisplayButton(int AppId, int loginID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_CheckDisplayButton";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", AppId);
            base.AddParam(paras, "IN_LoginID", loginID);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            base.AddParam(paras, "IN_NewStatus", (int)StatusHasAprove.New);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 0;
        }

        

        /// <summary>
        /// Check level finish
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="AppId"></param>
        /// <param name="currentLv"></param>
        /// <returns>true: finished, false: not finish </returns>
        public bool CheckApproveIsFinishLevel(int AppId, int currentLv)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_CheckApproveFinish_Level";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", AppId);
            base.AddParam(paras, "IN_CurLevel", currentLv);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }

        /// <summary>
        /// CheckApproveIsFinishLevel2
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="AppId"></param>
        /// <param name="currentLv"></param>
        /// <returns></returns>
        public bool CheckApproveIsFinishLevel2(int AppId, int currentLv)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_CheckApproveFinish_Level2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", AppId);
            base.AddParam(paras, "IN_CurLevel", currentLv);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update 
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int Update(T_Apply_Approve_List applyApproveList)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
            base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", applyApproveList.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", applyApproveList.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update 
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int Update2(T_Apply_Approve_List applyApproveList)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Update2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
            base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", applyApproveList.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", applyApproveList.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update ApproveStatus
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int UpdateApproveStatus(T_Apply_Approve_List applyApproveList,int loginUserID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_UpdateApproveStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
            base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
            base.AddParam(paras, "IN_LoginUID", loginUserID);
            base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="status"></param>
        /// <param name="loginUserID"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int UpdateApproveStatus(int appID,int status, int loginUserID,string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_UpdateApproveStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", appID);
            base.AddParam(paras, "IN_ApproveStatus", status);
            base.AddParam(paras, "IN_LoginUID", loginUserID);
            base.AddParam(paras, "IN_ApproveReason", reason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }


        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="status"></param>
        /// <param name="loginUserID"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int UpdateApproveStatus2(int appID, int status, int loginUserID, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_UpdateApproveStatus2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", appID);
            base.AddParam(paras, "IN_ApproveStatus", status);
            base.AddParam(paras, "IN_LoginUID", loginUserID);
            base.AddParam(paras, "IN_ApproveReason", reason, true);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update for PrevBack mode
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        //public int UpdateForPrevBack(T_Apply_Approve_List applyApproveList, int loginUserID, int approvedStatus)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Apply_Approve_List_UpdateForPrevBack";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
        //    base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
        //    base.AddParam(paras, "IN_ApprovedStatus", approvedStatus);
        //    base.AddParam(paras, "IN_LoginUID", loginUserID);
        //    //base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);

        //    return this.db.ExecuteNonQuery(cmdText, paras);
        //}

        /// <summary>
        /// ISV-TRUC
        /// 2015/04/20
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="updateUID"></param>
        /// <param name="prevStatus"></param>
        /// <param name="newStatus"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Remand(int appID, int updateUID, short prevStatus, short newStatus, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Remand";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_AppID", appID);
            base.AddParam(paras, "IN_ApproveUID", updateUID);
            base.AddParam(paras, "IN_PreviousStatus", prevStatus);
            base.AddParam(paras, "IN_NewStatus", newStatus);
            base.AddParam(paras, "IN_Reason", reason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Remand2
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="appID"></param>
        /// <param name="approveUID"></param>
        /// <param name="prevStatus"></param>
        /// <param name="newStatus"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Remand2(int appID, int approveUID, int approveUserID, short prevStatus, short newStatus, string reason)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Remand2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_AppID", appID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_PreviousStatus", prevStatus);
            base.AddParam(paras, "IN_NewStatus", newStatus);
            base.AddParam(paras, "IN_Reason", reason, true);
            base.AddParam(paras, "IN_ApproveUserID", approveUserID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update status for PrevBack mode
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int UpdateStatusForPrevBack(int applyID, int approveStatus, int prevApproveStatus)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_UpdateStatusForPrevBack";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_ApproveStatus", approveStatus);
            base.AddParam(paras, "IN_PrevApproveStatus", prevApproveStatus);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// UpdateStatusForPrevBack2
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="approveStatus"></param>
        /// <param name="prevApproveStatus"></param>
        /// <returns></returns>
        public int UpdateStatusForPrevBack2(int applyID, int approveStatus, int prevApproveStatus)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_UpdateStatusForPrevBack2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            base.AddParam(paras, "IN_ApproveStatus", approveStatus);
            base.AddParam(paras, "IN_PrevApproveStatus", prevApproveStatus);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int Delete(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Detele";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// </summary>
        /// <param name="applyID"></param>
        /// <returns></returns>
        public int Delete2(int applyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_Approve_List_Detele2";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", applyID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
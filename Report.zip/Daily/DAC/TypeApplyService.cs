﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    public class TypeApplyService : BaseService
    {
        #region Constructor

        public TypeApplyService()
            : base()
        {
        }

        public TypeApplyService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// GetByID
        /// ISV-NHAT
        /// 2015/03/13
        /// </summary>
        /// <returns></returns>
        public M_TypeApply GetByID(int holidayID)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", holidayID);

            return this.db.Find<M_TypeApply>(cmdText, paras);
        }

        /// <summary>
        /// GetTotalRow
        /// ISV-NHAT
        /// 2015/03/13
        /// </summary>
        /// <returns></returns>
        public int GetTotalRow(string typename, int formID)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_GetTotalRow";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_TypeName", typename);

            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetDisplayList
        /// ISV-TRAM
        /// 2015/03/16
        /// </summary>
        /// <returns></returns>
        public IList<M_TypeApply> GetDisplayList()
        {
            string cmdText = "P_M_TypeApply_GetDisplayList";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_TypeDefault", M_TypeApply.DEFAULT_NORMAL_WORK_ID);

            return this.db.FindList<M_TypeApply>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCond
        /// ISV-NHAT
        /// 2015/03/13
        /// </summary>
        /// <returns></returns>
        public IList<TypeApplyInfo> GetListByCond(string typename, int formID, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            string cmdText = "P_M_TypeApply_GetByCond";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_TypeName", typename);

            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<TypeApplyInfo>(cmdText, paras);
        }

        ///// <summary>
        ///// GetDataForDropDownList
        ///// ISV-TRUC
        ///// 2015/03/13
        ///// </summary>
        ///// <param name="configCd"></param>
        ///// <param name="withBlank"></param>
        ///// <returns></returns>
        //public IList<DropDownModel> GetDataForDropDownList(int typeOfForm, bool withBlank = false)
        //{
        //    //SQL String
        //    string cmdText = "P_M_TypeApply_GetDataForDropDownList";

        //    //Param
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_DefaultID", M_TypeApply.DEFAULT_NORMAL_WORK_ID);
        //    base.AddParam(paras, "IN_TypeOfForm", typeOfForm);
        //    IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

        //    if (withBlank)
        //    {
        //        ret.Insert(0, new DropDownModel("-1", "---"));
        //    }

        //    return ret;
        //}

        public IList<DropDownModel> GetDataForDropDownList(int userId , bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_GetDataForDropDownListAll";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DefaultID", M_TypeApply.DEFAULT_NORMAL_WORK_ID);
            base.AddParam(paras, "IN_UserID", userId);            

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);
            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetDataDefaultWork
        /// ISV-TRUC
        /// 2015/03/13
        /// </summary>
        /// <returns></returns>
        public M_TypeApply GetDataDefaultWork()
        {
            //SQL String
            string cmdText = "P_M_TypeApply_GetDataDefaultWork";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DefaultID", M_TypeApply.DEFAULT_NORMAL_WORK_ID);

            return this.db.Find<M_TypeApply>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// ISV-NHAT
        /// 2015/03/16
        /// </summary>
        /// <param name="user">M_TypeApply</param>
        /// <returns></returns>
        public int Insert(M_TypeApply typeapply)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Name", typeapply.TypeName);
            base.AddParam(paras, "IN_FormID", typeapply.FormID);
            base.AddParam(paras, "IN_SalaryStatus", typeapply.SalaryStatus);
           
            if (typeapply.MinStartHour == -1)
            {
                base.AddParam(paras, "IN_MinStartHour", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MinStartHour", typeapply.MinStartHour);
            }

            if (typeapply.MinStartMinute == -1)
            {
                base.AddParam(paras, "IN_MinStartMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MinStartMinute", typeapply.MinStartMinute);
            }

            if (typeapply.MaxEndHour == -1)
            {
                base.AddParam(paras, "IN_MaxEndHour", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MaxEndHour", typeapply.MaxEndHour);
            }

            if (typeapply.MaxEndMinute == -1)
            {
                base.AddParam(paras, "IN_MaxEndMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MaxEndMinute", typeapply.MaxEndMinute);
            }

            base.AddParam(paras, "IN_CreateUID", typeapply.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", typeapply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// ISV-NHAT
        /// 2015/03/16
        /// </summary>
        /// <param name="user">M_TypeApply</param>
        /// <returns></returns>
        public int Update(M_TypeApply typeapply)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", typeapply.ID);
            base.AddParam(paras, "IN_TypeName", typeapply.TypeName);
            base.AddParam(paras, "IN_FormID", typeapply.FormID);

            base.AddParam(paras, "IN_SalaryStatus", typeapply.SalaryStatus);


            if (typeapply.MinStartHour == -1)
            {
                base.AddParam(paras, "IN_MinStartHour", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MinStartHour", typeapply.MinStartHour);
            }

            if (typeapply.MinStartMinute == -1)
            {
                base.AddParam(paras, "IN_MinStartMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MinStartMinute", typeapply.MinStartMinute);
            }

            if (typeapply.MaxEndHour == -1)
            {
                base.AddParam(paras, "IN_MaxEndHour", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MaxEndHour", typeapply.MaxEndHour);
            }

            if (typeapply.MaxEndMinute == -1)
            {
                base.AddParam(paras, "IN_MaxEndMinute", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_MaxEndMinute", typeapply.MaxEndMinute);
            }

            base.AddParam(paras, "IN_UpdateDate", typeapply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", typeapply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// ISV-NHAT
        /// 2015/03/16
        /// </summary>
        /// <param name="user">M_TypeApply</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_TypeApply_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        public IList<DropDownModel> GetDataForDropDownList(TypeFormID typeFormID)
        {
            throw new NotImplementedException();
        }
    }
}

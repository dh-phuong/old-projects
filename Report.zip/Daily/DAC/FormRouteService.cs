﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// TRAM 2015/04/27
    /// Class FormRoute service
    /// </summary>
    public class FormRouteService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of FormRoute Service
        /// </summary>
        private FormRouteService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of FormRoute Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public FormRouteService(DB db)
            : base(db)
        {
            
        }

        #endregion

        #region Get

        /// <summary>
        /// Get by primary key
        /// TRAM
        /// 2015/05/07
        /// </summary>
        /// <param name="formID">FormID</param>
        /// <param name="routeID">RouteID</param>
        /// <returns></returns>
        public M_Form_Route GetByKey(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);

            return this.db.Find<M_Form_Route>(cmdText, paras);
        }

        /// <summary>
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown(int formID ,bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_GetDataForDropdown";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID, false);
            
            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetListByFormID
        /// ISV-TRUC
        /// 2015/05/04
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<M_Form_Route> GetListByFormID(int formID)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_GetListByFormID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.FindList<M_Form_Route>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="header">M_Form_Route</param>
        /// <returns></returns>
        public int Insert(M_Form_Route header)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", header.FormID);
            base.AddParam(paras, "IN_RouteID", header.RouteID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete Data
        /// ISV-TRUC
        /// 2015/05/04
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public int Delete(int formID)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_DeleteByFormID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

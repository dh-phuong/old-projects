﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using System;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// WorkAbsenceService.cs
    /// TRAM
    /// 2015/06/15
    /// </summary>
    public class WorkAbsenceService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private WorkAbsenceService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public WorkAbsenceService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Absence GetByID(int id, bool isIncludeDelete = false)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", id);
            base.AddParam(paras, "IN_IncludeDelete", isIncludeDelete ? 1 : 0);
            return this.db.Find<T_Work_Absence>(cmdText, paras);
        }


        /// <summary>
        /// Get data by ApplyNo
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Absence GetByApplyNo(string applyNo)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_GetByApplyNo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);

            return this.db.Find<T_Work_Absence>(cmdText, paras);
        }

        /// <summary>
        /// GetByPreApplyID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Absence GetByPreApplyID(int id)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_GetByPreApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PreApplyID", id);

            return this.db.Find<T_Work_Absence>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="period"></param>
        /// <returns></returns>
        public decimal GetUsedDaysInMonth(int userId, AccountingPeriod period)
        {
            //Command text
            string cmdText = "P_T_Work_Absence_GetUsedDaysInMonth";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_DateMonthFrm", period.StartDate);
            base.AddParam(prms, "IN_DateMonthTo", period.EndDate);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);

            base.AddParam(prms, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(prms, "IN_AbsenceDayOff", (int)TypeOfDay.DayOff);
            base.AddParam(prms, "IN_VacationType_DayOff", (int)VacationType.DayOff);
            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public int Insert(T_Work_Absence abs)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", abs.No);
            base.AddParam(paras, "IN_PreApplyID", abs.PreApplyID);
            base.AddParam(paras, "IN_ApplyStatus", abs.ApplyStatus);
            base.AddParam(paras, "IN_ApplyDate", abs.ApplyDate);
            base.AddParam(paras, "IN_UserID", abs.UserID);
            base.AddParam(paras, "IN_Duration", abs.Duration);
            base.AddParam(paras, "IN_AbsenceType", abs.AbsenceType);
            base.AddParam(paras, "IN_StartDate", abs.StartDate);
            base.AddParam(paras, "IN_EndDate", abs.EndDate);
            base.AddParam(paras, "IN_Reason", abs.Reason);
            base.AddParam(paras, "IN_RouteID", abs.RouteID);
            base.AddParam(paras, "IN_StatusFlag", abs.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", abs.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", abs.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Work_Absence>();
            }
            return 0;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="abs"></param>
        /// <returns></returns>
        public int Update(T_Work_Absence abs)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", abs.ID);
            base.AddParam(paras, "IN_UserID", abs.UserID);
            base.AddParam(paras, "IN_ApplyStatus", abs.ApplyStatus);
            base.AddParam(paras, "IN_Duration", abs.Duration);
            base.AddParam(paras, "IN_AbsenceType", abs.AbsenceType);
            base.AddParam(paras, "IN_StartDate", abs.StartDate);
            base.AddParam(paras, "IN_EndDate", abs.EndDate);
            base.AddParam(paras, "IN_Reason", abs.Reason);
            base.AddParam(paras, "IN_RouteID", abs.RouteID);
            base.AddParam(paras, "IN_StatusFlag", abs.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", abs.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", abs.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="updateUID"></param>
        /// <param name="applyStatus"></param>
        /// <param name="curCompleteLevel"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int UpdateApplyStatus(int applyID, int updateUID, short applyStatus, int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(T_Work_Absence apply)
        {
            //SQL String
            string cmdText = "P_T_Work_Absence_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}
﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using System;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// ApproveService
    /// VN-NHO
    /// 2015.03.19
    /// </summary>
    public class ApplyService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public ApplyService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public ApplyService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="templateFormID"></param>
        /// <param name="typeApply"></param>
        /// <returns></returns>
        public IList<ApplyInfo> GetListByCond(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetListByCond1";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<ApplyInfo>(cmdText, paras);
        }
        
        /// <summary>
        /// GetTotalRow
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyDateFrm"></param>
        /// <param name="applyDateTo"></param>
        /// <param name="applyStatus"></param>
        /// <param name="templateFormID"></param>
        /// <param name="typeApply"></param>
        /// <returns></returns>
        public int GetTotalRow(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetTotalRow";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list by PreApplyID
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="preApplyID"></param>
        /// <returns></returns>
        public IList<T_Apply> GetListByPreApplyID(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetListByPreApplyID";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }

            return this.db.FindList<T_Apply>(cmdText, paras);
        }


        /// <summary>
        /// GetTotalRow Of Approve List Form
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public int GetTotalRowForApproveList(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, short newStatus, short cancelStatus, int formID, int typeApply, int approvedFlg)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetTotalRowForApproveList";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }

            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", newStatus);
            //base.AddParam(paras, "IN_IgnoreStatus", ignoreStatus);
            //base.AddParam(paras, "IN_CompleteStatus", completeStatus);
            base.AddParam(paras, "IN_CancelStatus", cancelStatus);
            //base.AddParam(paras, "IN_ApprovedStatus", approvedStatus);

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListByCond Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<ApplyInfo> GetListByCondForApproveList(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, short newStatus, short cancelStatus, int formID, int typeApply, int approvedFlg,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetListByCondForApproveList";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", newStatus);
            //base.AddParam(paras, "IN_IgnoreStatus", ignoreStatus);
            //base.AddParam(paras, "IN_CompleteStatus", completeStatus);
            base.AddParam(paras, "IN_CancelStatus", cancelStatus);
            //base.AddParam(paras, "IN_ApprovedStatus", approvedStatus);
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<ApplyInfo>(cmdText, paras);
        }


        /// <summary>
        /// GetTotalRow Of Approve List Form
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public int GetTotalRowForApproveList2(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, int formID, int typeApply, int approvedFlg)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetTotalRowForApproveList2";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }

            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListByCond Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<ApplyInfo> GetListByCondForApproveList2(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, int formID, int typeApply, int approvedFlg,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetListByCondForApproveList2";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<ApplyInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get remain days
        /// </summary>
        /// <param name="applyId">apply id</param>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        public decimal GetRemainDays(int applyId, int userId)
        {
            //Command text
            string cmdText = "P_T_Apply_GetRemainDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyId);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_ApplyStatus_Rejected", (int)StatusApply.Rejected);
            base.AddParam(prms, "IN_ApplyStatus_Cancel", (int)StatusApply.Cancel);
            base.AddParam(prms, "IN_FormID_Leave", M_Config_D.TEMPLATE_FORM_APPLY_LEAVE);

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetPlanDays
        /// ISV-TRUC
        /// 2015/06/04
        /// </summary>
        /// <param name="applyId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public decimal GetPlanDays(int applyId, int userId)
        {
            //Command text
            string cmdText = "P_T_Apply_GetPlanDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyId);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_ApplyStatus_Rejected", (int)StatusApply.Rejected);
            base.AddParam(prms, "IN_ApplyStatus_Cancel", (int)StatusApply.Cancel);
            base.AddParam(prms, "IN_FormID_Leave", M_Config_D.TEMPLATE_FORM_APPLY_LEAVE);

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetUsedDays
        /// </summary>
        /// <param name="applyId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public decimal GetUsedDays(int userId, DateTime dateFrm, DateTime dateTo)
        {
            //Command text
            string cmdText = "P_T_Apply_GetUsedDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_FormID_Leave", M_Config_D.TEMPLATE_FORM_APPLY_LEAVE);
            if (dateFrm == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateFrom", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateFrom", dateFrm);
            }
            if (dateTo == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateTo", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateTo", dateTo);
            }

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Apply GetByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", id);

            return this.db.Find<T_Apply>(cmdText, paras);
        }

        /// <summary>
        /// GetByPreApplyID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Apply GetByPreApplyID(int id)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetByPreApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PreApplyID", id);

            return this.db.Find<T_Apply>(cmdText, paras);
        }

        /// <summary>
        /// Is Exist Form-Type In Apply
        /// ISV-TRUC
        /// 2015/05/06
        /// </summary>
        /// <param name="TypeID"></param>
        /// <returns></returns>
        public bool IsExistFormType(int TypeID)
        {
            //SQL String
            string cmdText = "P_T_Apply_CheckExistFormType";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_TypeID", TypeID);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;
            
        }

       /// <summary>
        /// Get by UserID and TypeAppy
       /// TRAM 2015/05/12
       /// </summary>
       /// <param name="userID"></param>
       /// <param name="typeApplyID"></param>
       /// <returns></returns>
        public T_Apply GetByUserIDAndTypeAppy(int userID, int typeApplyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetByUserIDAndTypeAppy";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_TypeApplyID", typeApplyID);

            return this.db.Find<T_Apply>(cmdText, paras);

        }

        #endregion

        #region Approve
        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int UpdateStatus(int approveID, int approveUID, int approveStatus, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Approve_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", approveID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_Status", approveStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Insert

        /// <summary>
        /// 
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int Insert(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", apply.ApplyNo);
            base.AddParam(paras, "IN_PreApplyID", apply.PreApplyID);
            base.AddParam(paras, "IN_ApplyStatus", apply.ApplyStatus);
            base.AddParam(paras, "IN_ApplyDate", apply.ApplyDate);
            base.AddParam(paras, "IN_UserID", apply.UserID);
            base.AddParam(paras, "IN_TypeApplyID", apply.TypeApplyID);
            base.AddParam(paras, "IN_StartDate", apply.StartDate);
            base.AddParam(paras, "IN_StartHour", apply.StartHour);
            base.AddParam(paras, "IN_StartMinute", apply.StartMinute);
            base.AddParam(paras, "IN_EndDate", apply.EndDate);
            base.AddParam(paras, "IN_EndHour", apply.EndHour);
            base.AddParam(paras, "IN_EndMinute", apply.EndMinute);
            base.AddParam(paras, "IN_Duration", apply.Duration);
            base.AddParam(paras, "IN_Reason", apply.Reason);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", apply.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Apply>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_UserID", apply.UserID);
            base.AddParam(paras, "IN_TypeApplyID", apply.TypeApplyID);
            base.AddParam(paras, "IN_ApplyStatus", apply.ApplyStatus);
            base.AddParam(paras, "IN_Duration", apply.Duration);
            base.AddParam(paras, "IN_StartDate", apply.StartDate);
            base.AddParam(paras, "IN_StartHour", apply.StartHour);
            base.AddParam(paras, "IN_StartMinute", apply.StartMinute);
            base.AddParam(paras, "IN_EndDate", apply.EndDate);
            base.AddParam(paras, "IN_EndHour", apply.EndHour);
            base.AddParam(paras, "IN_EndMinute", apply.EndMinute);
            base.AddParam(paras, "IN_Reason", apply.Reason);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update ApplyStatus
        /// ISV-TRAM
        /// 2015/03/23
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateApplyStatus(int applyID, int updateUID, short applyStatus,int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Apply_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        /// <summary>
        /// Update StatusFlag
        /// ISV-TRAM
        /// 2015/03/23
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        

        #endregion

        #region Confirm

        /// <summary>
        /// Confirm
        /// </summary>
        /// <param name="apply">T_Apply model</param>
        /// <returns></returns>
        public int Confirm(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Confirm";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_ApplyStatus", apply.ApplyStatus);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int Delete(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check

        /// <summary>
        /// Check duplicate time apply
        /// </summary>
        /// <param name="applyId">apply id</param>
        /// <param name="userId">user id</param>
        /// <param name="startDate">start date</param>
        /// <param name="endDate">end date</param>
        /// <returns></returns>
        public bool IsDuplicateTimeApply(int applyId, int userId, DateTime startDate, DateTime endDate)
        {
            //Command text
            string cmdText = "P_T_Apply_IsDuplicateTimeApply";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyId);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_StartDate", startDate);
            base.AddParam(prms, "IN_EndDate", endDate);
            base.AddParam(prms, "IN_StatusCancel", StatusApply.Cancel);

            return (int)this.db.ExecuteScalar(cmdText, prms) > 0;
        }

        #endregion
    }
}
﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using System;

namespace DailyReport.DAC
{
    /// <summary>
    /// ApproveService
    /// ISV-TRUC
    /// 2015/02/27
    /// </summary>
    public class ApproveService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public ApproveService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public ApproveService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get Data


        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Approve</returns>
        public ApproveDetailInfo GetApproveDetailByID(int id, int userID)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetByID_Detail";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_workID", id);
            base.AddParam(paras, "IN_userID", userID);         
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_DEFAULT_STATUS_APPROVED);

            return this.db.Find<ApproveDetailInfo>(cmdText, paras);
        }
        
        /// <summary>
        /// GetTotalRow Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public int GetTotalRow(int userID, string approveNo, string userCD, string userName, DateTime confirmDtFrom, DateTime confirmDtTo, int type)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetTotalRow_List";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_USERID", userID);
            base.AddParam(paras, "IN_ApproveNo", approveNo);

            if (userCD == string.Empty)
            {
                base.AddParam(paras, "IN_UserCD", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_UserCD", userCD);
            }

            base.AddParam(paras, "IN_UserName", userName);

            if (confirmDtFrom == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", confirmDtFrom);
            }

            if (confirmDtTo == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_ConfirmDtTo", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtTo", confirmDtTo);
            }

            // base.AddParam(paras, "IN_Type", type);           
            if (type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", type);
            }
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListByCond Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<ApprovedResultSearch> GetListByCond(int userID, string approveNo, string userCD, string userName, DateTime confirmDtFrom, DateTime confirmDtTo, int type,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetByCond_List";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_USERID", userID);
            base.AddParam(paras, "IN_ApproveNo", approveNo);

            if (userCD == string.Empty)
            {
                base.AddParam(paras, "IN_UserCD", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_UserCD", userCD);
            }

            base.AddParam(paras, "IN_UserName", userName);


            if (confirmDtFrom == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", confirmDtFrom);
            }

            if (confirmDtTo == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_ConfirmDtTo", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtTo", confirmDtTo);
            }

            //base.AddParam(paras, "IN_Type", type);
            if (type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", type);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<ApprovedResultSearch>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCond
        /// ISV-TRUC
        /// 2015/02/27
        /// </summary>
        /// <param name="inputModel"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<WorkResultSearch> GetListByCond(WorkConditionSearch inputModel,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveNo", inputModel.ApproveNo);
            if (inputModel.ConfirmDateFrm.HasValue)
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", inputModel.ConfirmDateFrm.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", DBNull.Value);
            }

            if (inputModel.ConfirmDateFrm.HasValue)
            {
                base.AddParam(paras, "IN_ConfirmDtTo", inputModel.ConfirmDateTo);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtTo", DBNull.Value);
            }

            base.AddParam(paras, "IN_UserID", inputModel.UserID);
            if (inputModel.Status == -1)
            {
                base.AddParam(paras, "IN_Status", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Status", inputModel.Status);
            }
            if (inputModel.Type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", inputModel.Type);
            }
            base.AddParam(paras, "IN_InValid", inputModel.Invalid);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<WorkResultSearch>(cmdText, paras);
        }

        /// <summary>
        /// Get Total Row By Condition
        /// ISV-TRUC
        /// 2015/02/27
        /// </summary>
        /// <param name="inputModel">WorkConditionSearch</param>
        /// <returns>Total Row</returns>
        public int GetTotalRow(WorkConditionSearch inputModel)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetTotalRow";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveNo", inputModel.ApproveNo);
            if (inputModel.ConfirmDateFrm.HasValue)
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", inputModel.ConfirmDateFrm.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtFrom", DBNull.Value);
            }

            if (inputModel.ConfirmDateFrm.HasValue)
            {
                base.AddParam(paras, "IN_ConfirmDtTo", inputModel.ConfirmDateTo);
            }
            else
            {
                base.AddParam(paras, "IN_ConfirmDtTo", DBNull.Value);
            }

            base.AddParam(paras, "IN_UserID", inputModel.UserID);
            if (inputModel.Status == -1)
            {
                base.AddParam(paras, "IN_Status", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Status", inputModel.Status);
            }
            if (inputModel.Type == -1)
            {
                base.AddParam(paras, "IN_Type", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Type", inputModel.Type);
            }
            base.AddParam(paras, "IN_InValid", inputModel.Invalid);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }
        
        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Approve</returns>
        public T_Approve GetByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_workID", id);

            return this.db.Find<T_Approve>(cmdText, paras);
        }

        /// <summary>
        /// GetByApproveNo
        /// </summary>
        /// <param name="approveNo"></param>
        /// <returns></returns>
        public T_Approve GetByApproveNo(string approveNo)
        {
            //SQL String
            string cmdText = "P_T_Approve_GetByApproveNo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveNo", approveNo);

            return this.db.Find<T_Approve>(cmdText, paras);
        }

        /*
        /// <summary>
        /// Count file
        /// Create Date: 2014/09/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerId"></param>
        /// <param name="formType"></param>
        /// <returns></returns>
        public int CountFile(int headerId, int formType)
        {
            //SQL String
            string cmdText = "P_T_Attached_CountFile";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_HID", headerId);
            base.AddParam(paras, "@IN_FormType", formType);

            return (int)this.db.ExecuteScalar(cmdText, paras);
        }*/
        #endregion

        #region Approve
        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int UpdateStatus(int approveID, int approveUID, int approveStatus, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Approve_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", approveID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_Status", approveStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="attached">M_Customer</param>
        /// <returns></returns>
        public int Insert(T_Approve app)
        {
            //SQL String
            string cmdText = "P_T_Approve_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveNo", app.ApproveNo);
            base.AddParam(paras, "IN_UserID", app.UserID);
            base.AddParam(paras, "IN_StatusApprove", app.StatusApprove);
            base.AddParam(paras, "IN_Type", app.TypeApplyID);
            base.AddParam(paras, "IN_StartDate", app.StartDate);
            base.AddParam(paras, "IN_StartHour", app.StartHour);
            base.AddParam(paras, "IN_StartMinute", app.StartMinute);

            base.AddParam(paras, "IN_EndDate", app.EndDate);
            base.AddParam(paras, "IN_EndHour", app.EndHour);
            base.AddParam(paras, "IN_EndMinute", app.EndMinute);
            base.AddParam(paras, "IN_Content", app.Content);
            base.AddParam(paras, "IN_AllUserFlag", app.AllUserFlag);
            base.AddParam(paras, "IN_CreateUID", app.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Approve>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Approve app)
        {
            //SQL String
            string cmdText = "P_T_Approve_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_Type", app.TypeApplyID);
            base.AddParam(paras, "IN_StartDate", app.StartDate);
            base.AddParam(paras, "IN_StartHour", app.StartHour);
            base.AddParam(paras, "IN_StartMinute", app.StartMinute);

            base.AddParam(paras, "IN_EndDate", app.EndDate);
            base.AddParam(paras, "IN_EndHour", app.EndHour);
            base.AddParam(paras, "IN_EndMinute", app.EndMinute);
            base.AddParam(paras, "IN_Content", app.Content);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// UpdateStatusFlag
        /// ISV-TRUC
        /// 2015/03/05
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(T_Approve app)
        {
            //SQL String
            string cmdText = "P_T_Approve_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_Status", app.StatusApprove);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
       
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(T_Approve app)
        {
            //SQL String
            string cmdText = "P_T_Approve_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_DeleteFlag", app.DeleteFlag);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
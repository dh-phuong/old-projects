﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    public class StaffContractService : BaseService
    {
        #region Contructor

        private StaffContractService()
            : base()
        { }

        public StaffContractService(DB db)
            : base(db)
        { }

        #endregion

        #region GetData

        public IList<M_Staff_Contract> GetByStaffID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_StaffContract_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.FindList<M_Staff_Contract>(cmdText, paras);
        }

        #endregion

        #region Insert

        public int Insert(M_Staff_Contract contract)
        {
            //SQL String
            string cmdText = "P_M_StaffContract_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", contract.StaffID);
            base.AddParam(paras, "IN_ContractNo", contract.ContractNo);
            base.AddParam(paras, "IN_ContractType", contract.ContractType);
            base.AddParam(paras, "IN_StartDate", contract.StartDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Delete(int staffID)
        {
            //SQL String
            string cmdText = "P_M_StaffContract_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using DailyReport.Models;
using System.Globalization;

///
/// ISV-TRUC
/// 2015/06/23
///
namespace DailyReport.DAC
{
    public class TemplateWorkDayService : BaseService
    {
        #region Constructor

        private TemplateWorkDayService()
            : base()
        {

        }

        public TemplateWorkDayService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get data
        /// </summary>
        /// <returns>M_Template_WorkDay</returns>
        public M_Template_WorkDay GetData()
        {
            //SQL String
            string cmdText = "P_M_Template_WorkDay_GetData";
            //Para            
            return this.db.Find<M_Template_WorkDay>(cmdText);
        }

        /// <summary>
        /// GetDataModel
        /// </summary>
        /// <returns></returns>
        public TemplateWorkDayInfo GetDataModel()
        {
            //SQL String
            string cmdText = "P_M_Template_WorkDay_GetDataModel";
            //Para            
            return this.db.Find<TemplateWorkDayInfo>(cmdText);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="workDay">M_Template_WorkDay</param>
        /// <returns></returns>
        public int Insert(M_Template_WorkDay workDay)
        {
            //SQL String
            string cmdText = "P_M_Template_WorkDay_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SunShiftID", workDay.SunShiftID, true);
            base.AddParam(paras, "IN_MonShiftID", workDay.MonShiftID, true);
            base.AddParam(paras, "IN_TueShiftID", workDay.TueShiftID, true);
            base.AddParam(paras, "IN_WedShiftID", workDay.WedShiftID, true);
            base.AddParam(paras, "IN_ThuShiftID", workDay.ThuShiftID, true);
            base.AddParam(paras, "IN_FriShiftID", workDay.FriShiftID, true);
            base.AddParam(paras, "IN_SatShiftID", workDay.SatShiftID, true);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="workDay">M_Template_WorkDay</param>
        /// <returns></returns>
        public int Update(M_Template_WorkDay workDay)
        {
            //SQL String
            string cmdText = "P_M_Template_WorkDay_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SunShiftID", workDay.SunShiftID, true);
            base.AddParam(paras, "IN_MonShiftID", workDay.MonShiftID, true);
            base.AddParam(paras, "IN_TueShiftID", workDay.TueShiftID, true);
            base.AddParam(paras, "IN_WedShiftID", workDay.WedShiftID, true);
            base.AddParam(paras, "IN_ThuShiftID", workDay.ThuShiftID, true);
            base.AddParam(paras, "IN_FriShiftID", workDay.FriShiftID, true);
            base.AddParam(paras, "IN_SatShiftID", workDay.SatShiftID, true);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}



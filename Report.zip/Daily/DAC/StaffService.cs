﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;


namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_User DAC
    /// </summary>
    public class StaffService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of User service
        /// </summary>        
        private StaffService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of User service
        /// </summary>
        /// <param name="db">Class DB</param>
        public StaffService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get data for drop down list
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown(int deptID, DateTime? invalidDate, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetDataForDropdown";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentID", deptID);
            if (invalidDate.HasValue)
            {
                base.AddParam(paras, "IN_InvalidDate", invalidDate);
            }
            else
            {
                base.AddParam(paras, "IN_InvalidDate", DBNull.Value);
            }

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetListByCond
        /// ISV-NHAT
        /// </summary>
        /// <param name="staffName"></param>
        /// <param name="inValid"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<StaffInfo> GetListByCond(string staffName, string inValid,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffName", staffName, true);
            base.AddParam(paras, "IN_InValid", inValid);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<StaffInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get by staff ID
        /// ISV-NHAT
        /// </summary>
        /// <param name="userID">staffID</param>
        /// <returns></returns>
        public M_Staff GetByID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.Find<M_Staff>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public M_StaffInfo GetStaffInfoByUserID(int userID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetStaffInfoByUserID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.Find<M_StaffInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public M_StaffInfo GetStaffInfoByStaffCD(string staffCD)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetStaffInfoByStaffCD";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffCD", EditDataUtil.ToFixCodeDB(staffCD, M_Staff.STAFF_CODE_MAX_LENGTH));

            return this.db.Find<M_StaffInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public M_StaffInfo GetStaffInfoByStaffID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetStaffInfoByStaffID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.Find<M_StaffInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get By Staff Code
        /// ISV-NHAT
        /// </summary>
        /// <param name="StaffCD">StaffCD</param>
        /// <returns></returns>
        public M_Staff GetByStaffCD(string StaffCD, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetByStaffCD";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffCD", EditDataUtil.ToFixCodeDB(StaffCD, M_Staff.STAFF_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.Find<M_Staff>(cmdText, paras);
        }

        /// <summary>
        /// GetByUserID
        /// ISV-TRUC
        /// 2015/05/14
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public M_Staff GetByUserID(int userID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetByUserID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.Find<M_Staff>(cmdText, paras);
        }

        /// <summary>
        /// getTotalRow
        /// ISV-NHAT
        /// </summary>
        /// <param name="staffName"></param>
        /// <param name="inValid"></param>
        /// <returns></returns>
        public int getTotalRow(string staffName, string inValid)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffName", staffName, true);
            base.AddParam(paras, "IN_InValid", inValid);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list of annual day by DepartmentID
        /// </summary>
        /// <param name="deptID">DepartmentID</param>
        /// <returns>List of AnnualDayInfo model</returns>
        public IList<AnnualDayInfo> GetListAnnualByDeptID(int deptID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetListAnnualByDeptID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentID", deptID);
            return this.db.FindList<AnnualDayInfo>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/03
        /// </summary>
        /// <param name="staffCD"></param>
        /// <param name="staffNm"></param>
        /// <param name="deptCD"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<StaffSearchResult> GetListByConditionForSearch(string staffCD, string staffNm, string deptCD, int deptID, int routeID, int formID, int loginUID, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetByConditionsForSearch";

            //Para
            Hashtable paras = new Hashtable();
            if (CheckDataUtil.IsInteger(staffCD))
            {
                base.AddParam(paras, "IN_StaffCD", staffCD.PadLeft(M_Staff.STAFF_CODE_MAX_LENGTH - M_Staff.MAX_STAFF_CODE_SHOW + staffCD.Length, '0'), true);
            }
            else
            {
                base.AddParam(paras, "IN_StaffCD", staffCD, true);
            }
            base.AddParam(paras, "IN_StaffNm", staffNm, true);
            base.AddParam(paras, "IN_DeptCD", EditDataUtil.ToFixCodeDB(deptCD, M_Department.DEPARTRMENT_CODE_MAX_LENGTH), true);
            if (routeID != -1)
            {
                base.AddParam(paras, "IN_RouteID", routeID);
            }
            else
            {
                base.AddParam(paras, "IN_RouteID", DBNull.Value);
            }

            if (deptID != -1)
            {
                base.AddParam(paras, "IN_DeptID", deptID);
            }
            else
            {
                base.AddParam(paras, "IN_DeptID", DBNull.Value);
            }

            if (formID != -1)
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }

            if (loginUID != -1)
            {
                base.AddParam(paras, "IN_LoginUID", loginUID);
            }
            else
            {
                base.AddParam(paras, "IN_LoginUID", DBNull.Value);
            }

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<StaffSearchResult>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/03
        /// </summary>
        /// <param name="staffCD"></param>
        /// <param name="staffNm"></param>
        /// <param name="deptCD"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string staffCD, string staffNm, string deptCD, int deptID, int routeID, int formID, int loginUID)
        {
            //SQL String
            string cmdText = "P_M_Staff_GetCountByConditionForSeach";

            //Para
            Hashtable paras = new Hashtable();
           
            if (CheckDataUtil.IsInteger(staffCD))
            {
                base.AddParam(paras, "IN_StaffCD", staffCD.PadLeft(M_Staff.STAFF_CODE_MAX_LENGTH - M_Staff.MAX_STAFF_CODE_SHOW + staffCD.Length, '0'), true);
            }
            else
            {
                base.AddParam(paras, "IN_StaffCD", staffCD, true);
            }
            base.AddParam(paras, "IN_StaffNm", staffNm, true);
            base.AddParam(paras, "IN_DeptCD", EditDataUtil.ToFixCodeDB(deptCD, M_Department.DEPARTRMENT_CODE_MAX_LENGTH), true);
            if (routeID != -1)
            {
                base.AddParam(paras, "IN_RouteID", routeID);
            }
            else
            {
                base.AddParam(paras, "IN_RouteID", DBNull.Value);
            }

            if (deptID != -1)
            {
                base.AddParam(paras, "IN_DeptID", deptID);
            }
            else
            {
                base.AddParam(paras, "IN_DeptID", DBNull.Value);
            }

            if (formID != -1)
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }

            if (loginUID != -1)
            {
                base.AddParam(paras, "IN_LoginUID", loginUID);
            }
            else
            {
                base.AddParam(paras, "IN_LoginUID", DBNull.Value);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        public IList<RouteDetailListInfo> GetListSortBy(int routeId, int sortField, int sortDirec)
        {
            // Command text
            string cmdText = "P_M_Staff_GetListSortBy";
            //Para
            Hashtable paras = new Hashtable();

            //base.AddParam(paras, "IN_RootCD", Constant.CATEGORY_ROOT_CODE);

            base.AddParam(paras, "IN_RouteID", routeId);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<RouteDetailListInfo>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="staff">M_User</param>
        /// <returns></returns>
        public int Insert(M_Staff staff)
        {
            //SQL String
            string cmdText = "P_M_Staff_Insert";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffCD", EditDataUtil.ToFixCodeDB(staff.StaffCD, M_Staff.STAFF_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_StaffName", staff.StaffName);
            base.AddParam(paras, "IN_Image", staff.Image);
            base.AddParam(paras, "IN_TypeofStaff", staff.TypeOfStaff);
            base.AddParam(paras, "IN_AnnualDays", staff.AnnualDays);
            base.AddParam(paras, "IN_DepartmentID", staff.DepartmentID);
            base.AddParam(paras, "IN_Position", staff.Position);
            base.AddParam(paras, "IN_Sex", staff.Sex);
            base.AddParam(paras, "IN_BirthDay", staff.Birthday);
            base.AddParam(paras, "IN_BirthPlace", staff.Birthplace);
            base.AddParam(paras, "IN_IDNo", staff.IdNo);
            base.AddParam(paras, "IN_IssueDate", staff.IssueDate);
            base.AddParam(paras, "IN_IssuePlace", staff.Issueplace);
            base.AddParam(paras, "IN_Tel", staff.Tel);
            base.AddParam(paras, "IN_Tel2", staff.Tel2);
            base.AddParam(paras, "IN_Email", staff.Email);
            base.AddParam(paras, "IN_Address1", staff.Address1);
            base.AddParam(paras, "IN_Province1", staff.Province1);
            base.AddParam(paras, "IN_District1", staff.District1);
            base.AddParam(paras, "IN_Ward1", staff.Ward1);
            base.AddParam(paras, "IN_Address2", staff.Address2);

            if (staff.Province2 == -1)
            {
                base.AddParam(paras, "IN_Province2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Province2", staff.Province2);
            }

            if (staff.District2 == -1)
            {
                base.AddParam(paras, "IN_District2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_District2", staff.District2);
            }

            if (staff.Ward2 == -1)
            {
                base.AddParam(paras, "IN_Ward2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Ward2", staff.Ward2);
            }

            base.AddParam(paras, "IN_AccountNo", staff.AccountNo);
            base.AddParam(paras, "IN_BankName", staff.Bankname);
            base.AddParam(paras, "IN_StartWorkDate", staff.StartWorkDate);

            if (staff.EndWorkDate == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_EndWorkDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_EndWorkDate", staff.EndWorkDate);
            }

            base.AddParam(paras, "IN_SocialInsurNo", staff.SocailinsurNo);
            base.AddParam(paras, "IN_TaxNo", staff.TaxNo);
            base.AddParam(paras, "IN_StatusFlag", staff.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", staff.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", staff.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="staff">M_User</param>
        /// <returns></returns>
        public int Update(M_Staff staff)
        {
            //SQL String
            string cmdText = "P_M_Staff_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", staff.ID);
            base.AddParam(paras, "IN_StaffCD", EditDataUtil.ToFixCodeDB(staff.StaffCD, M_Staff.STAFF_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_StaffName", staff.StaffName);
            base.AddParam(paras, "IN_Image", staff.Image);
            base.AddParam(paras, "IN_TypeofStaff", staff.TypeOfStaff);
            base.AddParam(paras, "IN_AnnualDays", staff.AnnualDays);
            base.AddParam(paras, "IN_DepartmentID", staff.DepartmentID);
            base.AddParam(paras, "IN_Position", staff.Position);
            base.AddParam(paras, "IN_Sex", staff.Sex);
            base.AddParam(paras, "IN_BirthDay", staff.Birthday);
            base.AddParam(paras, "IN_BirthPlace", staff.Birthplace);
            base.AddParam(paras, "IN_IDNo", staff.IdNo);
            base.AddParam(paras, "IN_IssueDate", staff.IssueDate);
            base.AddParam(paras, "IN_IssuePlace", staff.Issueplace);
            base.AddParam(paras, "IN_Tel", staff.Tel);
            base.AddParam(paras, "IN_Tel2", staff.Tel2);
            base.AddParam(paras, "IN_Email", staff.Email);
            base.AddParam(paras, "IN_Address1", staff.Address1);
            base.AddParam(paras, "IN_Province1", staff.Province1);
            base.AddParam(paras, "IN_District1", staff.District1);
            base.AddParam(paras, "IN_Ward1", staff.Ward1);
            base.AddParam(paras, "IN_Address2", staff.Address2);

            if (staff.Province2 == -1)
            {
                base.AddParam(paras, "IN_Province2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Province2", staff.Province2);
            }

            if (staff.District2 == -1)
            {
                base.AddParam(paras, "IN_District2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_District2", staff.District2);
            }

            if (staff.Ward2 == -1)
            {
                base.AddParam(paras, "IN_Ward2", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Ward2", staff.Ward2);
            }

            base.AddParam(paras, "IN_AccountNo", staff.AccountNo);
            base.AddParam(paras, "IN_BankName", staff.Bankname);
            base.AddParam(paras, "IN_StartWorkDate", staff.StartWorkDate);

            if (staff.EndWorkDate == DateTime.MinValue)
            {
                base.AddParam(paras, "IN_EndWorkDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_EndWorkDate", staff.EndWorkDate);
            }

            base.AddParam(paras, "IN_SocialInsurNo", staff.SocailinsurNo);
            base.AddParam(paras, "IN_TaxNo", staff.TaxNo);
            base.AddParam(paras, "IN_StatusFlag", staff.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", staff.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", staff.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update annual day
        /// </summary>
        /// <param name="staff">Staff</param>
        /// <returns></returns>
        public int UpdateAnnualDay(M_Staff staff)
        {
            //SQL String
            string cmdText = "P_M_Staff_UpdateAnnualDay";
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", staff.ID);
            base.AddParam(paras, "IN_AnnualDays", staff.AnnualDays);
            base.AddParam(paras, "IN_AnnualDate", staff.AnnualToDate);
            base.AddParam(paras, "IN_UpdateDate", staff.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", staff.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

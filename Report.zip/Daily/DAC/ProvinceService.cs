﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// Province service
    /// VN-Nho
    /// 2015.03.30
    /// </summary>
    public class ProvinceService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        private ProvinceService()
            : base()
        { }

        /// <summary>
        /// Contructor with BD
        /// </summary>
        /// <param name="db"></param>
        public ProvinceService(DB db)
            : base(db)
        { }

        #endregion

        #region Get

        /// <summary>
        /// Get by ID
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns>Province modek</returns>
        public M_Province GetByID(int id)
        {
            //command text
            string cmdText = "P_M_Province_GetByID";

            //Parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ID", id);

            return this.db.Find<M_Province>(cmdText, prms);
        }

        /// <summary>
        /// Get by code
        /// </summary>
        /// <param name="provinceCD">Province code</param>
        /// <returns>Province model</returns>
        public M_Province GetByCD(string provinceCD)
        {
            string cmdText = "P_M_Province_GetByCD";

            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ProvinceCD", EditDataUtil.ToFixCodeDB(provinceCD, M_Province.PROVINCE_CODE_MAX_LEN_DB));
            return this.db.Find<M_Province>(cmdText, prms);
        }

        /// <summary>
        /// Get list by condition
        /// </summary>
        /// <param name="provinceCD">province code</param>
        /// <param name="provinceName">province name</param>
        /// <param name="pageIndex">page index</param>
        /// <param name="pageSize">page size</param>
        /// <param name="sortField">sort field</param>
        /// <param name="sortDirec">sort direction</param>
        /// <returns>list province information</returns>
        public IList<ProvinceInfo> GetListByCond(string provinceCD, string provinceName,
                                                int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Province_GetByCond";

            //parameter
            Hashtable paras = new Hashtable();

            //Add parameter
            base.AddParam(paras, "IN_ProvinceCD", provinceCD);
            base.AddParam(paras, "IN_ProvinceName", provinceName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ProvinceInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="provinceCD">province code</param>
        /// <param name="provinceName">province name</param>
        /// <returns></returns>
        public int GetTotalRow(string provinceCD, string provinceName)
        {
            //Store procedure name
            string cmdText = "P_M_Province_GetTotalRow";

            //Parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ProvinceCD",provinceCD);
            base.AddParam(prms, "IN_ProvinceName", provinceName);

            return int.Parse(this.db.ExecuteScalar(cmdText, prms).ToString());
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/03/30
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Province_GetDataForDropDownList";
            IList<DropDownModel> list = this.db.FindList<DropDownModel>(cmdText);

            if (withBlank)
            {
                list.Insert(0, new DropDownModel("-1", "---"));
            }

            return list;
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">Province data</param>
        /// <returns></returns>
        public int Insert(M_Province data)
        {
            //SQL String
            string cmdText = "P_M_Province_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceCD", EditDataUtil.ToFixCodeDB(data.ProvinceCD, M_Province.PROVINCE_CODE_MAX_LEN_DB));
            base.AddParam(paras, "IN_ProvinceName", data.ProvinceName);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">province data</param>
        /// <returns></returns>
        public int Update(M_Province data)
        {
            //SQL String
            string cmdText = "P_M_Province_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", data.ID);
            base.AddParam(paras, "IN_ProvinceCD", EditDataUtil.ToFixCodeDB(data.ProvinceCD, M_Province.PROVINCE_CODE_MAX_LEN_DB));
            base.AddParam(paras, "IN_ProvinceName", data.ProvinceName);
            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID">ID</param>
        /// <param name="updateDate">Update date</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Province_Delete";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

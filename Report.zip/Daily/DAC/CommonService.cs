﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    public class CommonService
    {
        /// <summary>
        /// Classify overtime time
        /// </summary>
        /// <param name="stOT">start time</param>
        /// <param name="etOT">end time</param>
        /// <param name="lstRestTime">list rest time</param>
        /// <param name="accouting">accounting data</param>
        /// <param name="earlyOT">ref early overtim</param>
        /// <param name="normalOT">ref normal overtim</param>
        /// <param name="lateOT">ref late night overtim</param>
        public static void ClassifyOTTime(DateTime stOT, DateTime etOT, IList<RestTime> lstRestTime, M_Accounting accouting, ref TimeSpan earlyOT, ref TimeSpan normalOT, ref TimeSpan lateOT)
        {
            while (stOT < etOT)
            {
                bool isRestTime = false;
                foreach (var item in lstRestTime)
                {
                    if (stOT >= item.RestTimeS && stOT < item.RestTimeE)
                    {
                        isRestTime = true;
                        break;
                    }
                }

                if (!isRestTime)
                {
                    if (stOT >= accouting.EarlyOT_ST && stOT < accouting.EarlyOT_ET)
                    {
                        earlyOT = earlyOT.Add(new TimeSpan(0, 1, 0));
                    }
                    else if (accouting.LateOT_ST < accouting.LateOT_ET && stOT >= accouting.LateOT_ST && stOT < accouting.LateOT_ET)
                    {
                        lateOT = lateOT.Add(new TimeSpan(0, 1, 0));
                    }
                    else if (accouting.LateOT_ST >= accouting.LateOT_ET
                             &&
                                (
                                    (stOT >= accouting.LateOT_ST && stOT <= new DateTime(1, 1, 1, 23, 59, 0))
                                    ||
                                    (stOT >= new DateTime(1, 1, 1) && stOT < accouting.LateOT_ET)
                                ))
                    {
                        lateOT = lateOT.Add(new TimeSpan(0, 1, 0));
                    }
                    else
                    {
                        normalOT = normalOT.Add(new TimeSpan(0, 1, 0));
                    }
                }
                stOT = stOT.AddMinutes(1);
            }
        }

        /// <summary>
        /// Calculate work time
        /// </summary>
        /// <param name="startTime">start time</param>
        /// <param name="endTime">end time</param>
        /// <param name="lstRestTime">list rest time</param>
        /// <returns></returns>
        public static TimeSpan CalDurationWorkTime(DateTime startTime, DateTime endTime, IList<RestTime> lstRestTime)
        {

            lstRestTime = lstRestTime.OrderBy(m => m.RestTimeS).ToList();
            TimeSpan ret = new TimeSpan();
            if (endTime <= startTime)
            {
                return ret;
            }

            while (startTime <= endTime)
            {
                DateTime sTime = new DateTime(1, 1, 1).AddHours(startTime.Hour).AddMinutes(startTime.Minute);
                DateTime eTime = new DateTime(1, 1, 1).AddHours(24);
                if (startTime.Date == endTime.Date)
                {
                    eTime = new DateTime(1, 1, 1).AddHours(endTime.Hour).AddMinutes(endTime.Minute);
                }

                foreach (var item in lstRestTime)
                {
                    if (sTime < item.RestTimeS)
                    {
                        if (eTime <= item.RestTimeS)
                        {
                            break;
                        }
                        else if (eTime > item.RestTimeS && eTime <= item.RestTimeE)
                        {
                            eTime = item.RestTimeS;
                            break;
                        }
                        else
                        {
                            ret = ret.Add(item.RestTimeS.Subtract(sTime));
                            sTime = item.RestTimeE;
                        }
                    }
                    else if (sTime >= item.RestTimeS && sTime < item.RestTimeE)
                    {
                        sTime = item.RestTimeE;
                    }

                    if (sTime >= eTime)
                    {
                        break;
                    }
                }

                if (eTime > sTime)
                {
                    ret = ret.Add(eTime.Subtract(sTime));
                }

                startTime = startTime.AddDays(1);
            }
            return ret;
        }

        
    }
}

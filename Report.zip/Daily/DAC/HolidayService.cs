﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;


namespace DailyReport.DAC
{
    public class HolidayService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Holiday service
        /// </summary>        
        private HolidayService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Holiday service
        /// </summary>
        /// <param name="db">Class DB</param>
        public HolidayService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        public M_Holiday GetByID(int holidayID)
        {
            //SQL String
            string cmdText = "P_M_Holiday_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", holidayID);

            return this.db.Find<M_Holiday>(cmdText, paras);
        }      

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public IList<M_Holiday> GetHolidayInfo(DateTime dateForm, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_M_Holiday_GetHolidayInfo";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateForm", dateForm, true);
            base.AddParam(paras, "IN_DateTo", dateTo, true);

            return this.db.FindList<M_Holiday>(cmdText, paras);
        }

        public M_Holiday GetByDay(DateTime date)
        {
            //SQL String
            string cmdText = "P_M_Holiday_GetByDay";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Date", date);

            return this.db.Find<M_Holiday>(cmdText, paras);
        }

        public IList<HolidayInfo> GetListByCond(DateTime? dateFrom, DateTime? dateTo, string info, 
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Holiday_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateFrom", dateFrom);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_Name", info, true);            

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<HolidayInfo>(cmdText, paras);
        }

        public int getTotalRow(DateTime? dateFrom, DateTime? dateTo, string info)
        {
            //SQL String
            string cmdText = "P_M_Holiday_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateFrom", dateFrom);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_Name", info, true);            

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">M_Holiday</param>
        /// <returns></returns>
        public int Insert(M_Holiday holiday)
        {
            //SQL String
            string cmdText = "P_M_Holiday_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Date", holiday.Date);
            base.AddParam(paras, "IN_Name1", holiday.Name1);
            base.AddParam(paras, "IN_Name2", holiday.Name2);            
            base.AddParam(paras, "IN_Color", holiday.Color);
            base.AddParam(paras, "IN_Repeats", holiday.Repeats);
            base.AddParam(paras, "IN_Replace", holiday.Replace);
            base.AddParam(paras, "IN_CreateUID", holiday.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", holiday.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Update(M_Holiday holiday)
        {
            //SQL String
            string cmdText = "P_M_Holiday_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", holiday.ID);
            base.AddParam(paras, "IN_Date", holiday.Date);
            base.AddParam(paras, "IN_Name1", holiday.Name1);
            base.AddParam(paras, "IN_Name2", holiday.Name2);
            base.AddParam(paras, "IN_Color", holiday.Color);
            base.AddParam(paras, "IN_Repeats", holiday.Repeats);
            base.AddParam(paras, "IN_Replace", holiday.Replace);
            base.AddParam(paras, "IN_UpdateDate", holiday.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", holiday.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Delete(int holidayID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Holiday_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", holidayID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    /// <summary>
    /// Create  :ISV-NHAT
    /// Date    :2015/03/30
    /// Class District DAC
    /// </summary>
    public class DistrictService : BaseService
    {

        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        private DistrictService()
            : base()
        {
        }

        /// <summary>
        /// Contructor with db
        /// </summary>
        /// <param name="db"></param>
        public DistrictService(DB db)
            : base(db)
        { }

        #endregion

        #region get

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_District GetByID(int id)
        {
            // Command text
            string cmdText = "P_M_District_GetByID";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return this.db.Find<M_District>(cmdText, paras);
        }

        /// <summary>
        /// Get by key
        /// </summary>
        /// <returns></returns>
        public M_District GetByKey(int provinceID, string districtCD)
        {
            // Command text
            string cmdText = "P_M_District_GetByKey";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceID", provinceID);
            base.AddParam(paras, "IN_DistrictCD", districtCD);
            return this.db.Find<M_District>(cmdText, paras);
        }

        /// <summary>
        /// Get list district info by condition
        /// </summary>
        /// <param name="provinceID">province id</param>
        /// <param name="districtCD">district code</param>
        /// <param name="dictrictName">district name</param>
        /// <param name="pageIndex">page index</param>
        /// <param name="pageSize">page size</param>
        /// <param name="sortField">sort field</param>
        /// <param name="sortDirec">sort direction</param>
        /// <returns></returns>
        public IList<DistrictInfo> GetListByCond(int provinceID, string districtCD, string dictrictName,
                                                    int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_District_GetByCond";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ProvinceID", provinceID);
            base.AddParam(paras, "IN_DistrictCD", districtCD);
            base.AddParam(paras, "IN_DistrictName", dictrictName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<DistrictInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="provinceID">province id</param>
        /// <param name="districtCD">district code</param>
        /// <param name="dictrictName">dictrict name</param>
        /// <returns></returns>
        public int GetTotalRow(int provinceID, string districtCD, string dictrictName)
        {
            //SQL String
            string cmdText = "P_M_District_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceID", provinceID);
            base.AddParam(paras, "IN_DistrictCD", districtCD);
            base.AddParam(paras, "IN_DistrictName", dictrictName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/03/30
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(int provinceID, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_District_GetDataForDropDownList";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceID", provinceID);

            IList<DropDownModel> ret = new List<DropDownModel>();
            if (provinceID != -1)
            {
                ret = this.db.FindList<DropDownModel>(cmdText, paras);
            }

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">district data</param>
        /// <returns></returns>
        public int Insert(M_District data)
        {
            //SQL String
            string cmdText = "P_M_District_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceID", data.ProvinceID);
            base.AddParam(paras, "IN_DistrictCD", data.DistrictCD);
            base.AddParam(paras, "IN_DistrictName", data.DistrictName);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">district data</param>
        /// <returns></returns>
        public int Update(M_District data)
        {
            //SQL String
            string cmdText = "P_M_District_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", data.ID);

            base.AddParam(paras, "IN_ProvinceID", data.ProvinceID);
            base.AddParam(paras, "IN_DistrictCD", data.DistrictCD);
            base.AddParam(paras, "IN_DistrictName", data.DistrictName);

            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">update date</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_District_Delete";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

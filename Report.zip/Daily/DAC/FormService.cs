﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_Form Service
    /// ISV-TRUC
    /// 2015/04/23
    /// </summary>
    public class FormService: BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of M_Form Service
        /// </summary>
        private FormService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of M_Form Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public FormService(DB db)
            : base(db)
        {
            
        }

        #endregion

        #region Get Data
                      
        /// <summary>
        /// GetListByCond
        /// ISV-TRUC
        /// 2015/04/23
        /// </summary>
        /// <param name="name"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<FormListInfo> GetListByCond(string name,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Form_GetByCond_FrmConfig";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
            base.AddParam(paras, "IN_Name", name, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<FormListInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row for list
        /// ISV-TRUC
        /// 2015/04/23
        /// </summary>
        /// <param name="configCD">Config Code</param>
        /// <param name="name">Config Name</param>
        /// <returns></returns>
        public int getTotalRow(string name)
        {
            //SQL String
            string cmdText = "P_M_Form_GetTotalRow_FrmConfig";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
            base.AddParam(paras, "IN_Name", name, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }


        /// <summary>
        /// Get by ID
        /// Create Author: ISV-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public M_Form GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_Form_GetByID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", id);

            return this.db.Find<M_Form>(cmdText, paras);
        }

        /// <summary>
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown(bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Form_GetDataForDropdown";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }



        //**********************************************************************
        
        #endregion

        #region Check data
        /// <summary>
        /// Check exist Config by Config Code
        /// </summary>
        /// <param name="configCode">Config Code</param>
        /// <returns></returns>
        public bool IsExistConfigCode(string configCode)
        {
            //SQL String
            string cmdText = "P_M_Config_H_IsExistConfigCode";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", configCode);

            int count = int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());

            return count > 0;
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="header">M_Form</param>
        /// <returns></returns>
        public int Insert(M_Form header)
        {
            //SQL String
            string cmdText = "P_M_Form_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", header.FormID);

            base.AddParam(paras, "IN_CreateUID", header.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="header">M_Form</param>
        /// <returns></returns>
        public int Update(M_Form header)
        {
            //SQL String
            string cmdText = "P_M_Form_Update";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", header.FormID);
            base.AddParam(paras, "IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int Delete(int formID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Form_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

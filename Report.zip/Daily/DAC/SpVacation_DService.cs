﻿using System;
using System.Collections;
using System.Collections.Generic;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// TRAM - 2015/06/10
    /// SpVacation_DService class
    /// </summary>
    public class SpVacation_DService: BaseService
    {
        
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private SpVacation_DService()
            : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public SpVacation_DService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get data

        /// <summary>
        /// GetByListByHeaderID
        /// </summary>
        /// <param name="headerID"></param>
        /// <returns></returns>
        public IList<M_SpecialVacation_D> GetByListByHeaderID(int headerID)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_D_GetByListByHeaderID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<M_SpecialVacation_D>(cmdText, paras);
        }

        #endregion

        #region Insert
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="detailItem"></param>
        /// <returns></returns>
        public int Insert(M_SpecialVacation_D detailItem)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_D_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", detailItem.HID);
            base.AddParam(paras, "IN_EffectDate", detailItem.EffectDate);
            base.AddParam(paras, "IN_ExpireDate", detailItem.ExpireDate);
            base.AddParam(paras, "IN_NumOfDays", detailItem.NumOfTime);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// 
        /// </summary>
        /// <param name="headerID"></param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_D_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="hid"></param>
       /// <param name="baseDate"></param>
       /// <returns></returns>
        public int Delete(int hid, DateTime baseDate)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_D_Delete_ByKey";

            //Param
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_HID", hid);
            this.AddParam(paras, "IN_EffectDate", baseDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}

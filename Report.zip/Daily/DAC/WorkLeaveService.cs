﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    public class WorkLeaveService : BaseService
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        private WorkLeaveService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public WorkLeaveService(DB db)
            : base()
        {
            this.db = db;
        }

        #endregion

        public IList<WorkLeaveDay> GetListMonthAccounting(string staffCD, DateTime dateFrom, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_GetListMonthAccounting";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_DateFrom", dateFrom);
            if (!string.IsNullOrEmpty(staffCD))
            {
                base.AddParam(paras, "IN_StaffCD", EditDataUtil.ToFixCodeDB(staffCD, M_Staff.STAFF_CODE_MAX_LENGTH));
            }
            else
            {
                base.AddParam(paras, "IN_StaffCD", string.Empty);
            }


            return this.db.FindList<WorkLeaveDay>(cmdText, paras);
        }

        public T_Work_Leave GetByID(int id, bool isIncludeDelete = false)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", id);
            base.AddParam(paras, "IN_IncludeDelete", isIncludeDelete ? 1 : 0);

            return this.db.Find<T_Work_Leave>(cmdText, paras);
        }

        public int UpdateApplyStatus(int applyID, int updateUID, short applyStatus, int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        public int UpdateStatusFlag(T_Work_Leave apply)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        public T_Work_Leave GetByPreApplyID(int id)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_GetByPreApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PreApplyID", id);

            return this.db.Find<T_Work_Leave>(cmdText, paras);
        }

        #region Insert

        public int Insert(T_Work_Leave item)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", item.No);
            base.AddParam(paras, "IN_PreApplyID", item.PreApplyID);
            base.AddParam(paras, "IN_ApplyStatus", item.ApplyStatus);
            base.AddParam(paras, "IN_ApplyDate", item.ApplyDate);
            base.AddParam(paras, "IN_UserID", item.UserID);
            base.AddParam(paras, "IN_EffectDate", item.EffectDate);
            base.AddParam(paras, "IN_StartHour", item.StartHour);
            base.AddParam(paras, "IN_StartMinute", item.StartMinute);
            base.AddParam(paras, "IN_EndHour", item.EndHour);
            base.AddParam(paras, "IN_EndMinute", item.EndMinute);
            base.AddParam(paras, "IN_DurationHour", item.DurationHour);
            base.AddParam(paras, "IN_DurationMinute", item.DurationMinute);
            base.AddParam(paras, "IN_Type", item.Type);
            base.AddParam(paras, "IN_Reason", item.Reason);
            base.AddParam(paras, "IN_RouteID", item.RouteID);
            base.AddParam(paras, "IN_StatusFlag", item.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", item.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", item.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Work_Leave>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Work_Leave item)
        {
            //SQL String
            string cmdText = "P_T_Work_Leave_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", item.ID);
            base.AddParam(paras, "IN_Type", item.Type);
            base.AddParam(paras, "IN_UserID", item.UserID);
            base.AddParam(paras, "IN_EffectDate", item.EffectDate);
            base.AddParam(paras, "IN_StartHour", item.StartHour);
            base.AddParam(paras, "IN_StartMinute", item.StartMinute);
            base.AddParam(paras, "IN_EndHour", item.EndHour);
            base.AddParam(paras, "IN_EndMinute", item.EndMinute);
            base.AddParam(paras, "IN_DurationHour", item.DurationHour);
            base.AddParam(paras, "IN_DurationMinute", item.DurationMinute);
            base.AddParam(paras, "IN_Reason", item.Reason);
            base.AddParam(paras, "IN_RouteID", item.RouteID);
            base.AddParam(paras, "IN_StatusFlag", item.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", item.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", item.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using DailyReport.Utilities;
using System.Data.Common;

namespace DailyReport.DAC
{
    /// <summary>
    /// TRAM 2015/04/24
    /// Class FormLink service
    /// </summary>
    public class FormLinkService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of FormLink Service
        /// </summary>
        private FormLinkService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of FormLink Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public FormLinkService(DB db)
            : base(db)
        {
            
        }

        #endregion

        #region Get

        /// <summary>
        /// GetByFormIDAndRouteID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public M_Form_Link GetByKey(int formID, int userID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_UserID", userID);
            return this.db.Find<M_Form_Link>(cmdText, paras);
        }

        /// <summary>
        /// Get user list by FormID and RouteID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<string> GetUserListByFormIDAndRouteID(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetUserListByFormIDAndRouteID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["StaffCD"].ToString());
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// Get data list by FormID and RouteID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<M_Form_Link> GetListByFormIDAndRouteID(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetListByFormIDAndRouteID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);

            return this.db.FindList<M_Form_Link>(cmdText, paras);
        }


        /// <summary>
        /// Get RouteID list by FormID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<int> GetRouteIDByFormID(int formID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetRouteIDByFormID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            
            IList<int> ret = new List<int>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(int.Parse( dr["RouteID"].ToString()));
                    }
                }
            }

            return ret;
        }

        /// <summary>
        /// GetByFormIDAndRouteID
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public FormLinkMaster GetByFormIDAndRouteID(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetByFormIDAndRouteID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);
            return this.db.Find<FormLinkMaster>(cmdText, paras);
        }
      
        /// <summary>
        /// Get list by conditions
        /// TRAM-2015/04/24
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="routeID"></param>
        /// <returns>List of FormLinkInfo model</returns>
        public IList<FormLinkInfo> GetListByCond(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetListByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);

            return this.db.FindList<FormLinkInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown1(int userID, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetDataForDropdown";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCD", M_Config_H.CONFIG_CD_TEMPLATE_TYPE, true);
            base.AddParam(paras, "IN_UserID", userID);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// Get user by conditions
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="routeID"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<UserInfoForFormLink> GetUserByCond(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_GetUserByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);
            base.AddParam(paras, "IN_ApplyStatus", StatusApply.Draft);
           return this.db.FindList<UserInfoForFormLink>(cmdText, paras);
       }

        /// <summary>
        /// Is Exist Form-Route In Form_Link
        /// ISV-TRUC
        /// 2015/05/06
        /// </summary>
        /// <param name="TypeID"></param>
        /// <returns></returns>
        public bool IsExistFormRoute(int FormID,int RouteID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_CheckExistRoute";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", FormID);
            base.AddParam(paras, "IN_RouteID", RouteID);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;

        }
        #endregion

        #region Insert

        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="formLink">M_Form_Link</param>
        /// <returns></returns>
        public int Insert(M_Form_Link formLink)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formLink.FormID);
            base.AddParam(paras, "UserID", formLink.UserID);            
            base.AddParam(paras, "IN_RouteID", formLink.RouteID);
            base.AddParam(paras, "IN_CreateUID", formLink.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", formLink.UpdateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

       /// <summary>
        /// Delete
       /// </summary>
        /// <param name="formID">FormID</param>
        /// <param name="userID">UserID</param>
       /// <returns></returns>
        public int Delete(int formID, int userID)
        {
            //SQL String
            string cmdText = "P_M_Form_Link_Delete";         

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_UserID", userID);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

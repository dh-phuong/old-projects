﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    public class VacationApproveListService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public VacationApproveListService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public VacationApproveListService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region GET

        /// <summary>
        /// ISV-TRUC 2015/03/20
        /// Get List By ApproveID for Work
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IList<VacationApprove> GetListForVacation(int id)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_GetListByVacationID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", id);
            return this.db.FindList<VacationApprove>(cmdText, paras);
        }

        /// <summary>
        /// Get count by UserID
        /// </summary>
        /// <param name="userID">UserID</param>
        /// <returns></returns>
        public int GetCountByUserID(int userID)
        {
            string cmdText = "P_T_Vacation_Approve_List_GetCountByUserID";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion

        #region Check

        /// <summary>
        /// ISV-TRUC
        /// 2015/03/23
        /// </summary>
        /// <param name="VacId"></param>
        /// <returns></returns>
        public bool CheckLoginUserIsApproveUser(int VacId, int LoginUserID)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_CheckLoginUserIsApproveUser";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", VacId);
            base.AddParam(paras, "IN_LoginUserID", LoginUserID);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;            
        }

        /// <summary>
        /// GetStatusByHID
        /// </summary>
        /// <param name="VacId"></param>
        /// <param name="UserID"></param>
        /// <returns>Approve status</returns>
        //public int GetStatusByHID(int VacId, int UserID)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Vacation_Approve_List_GetStatusByHID";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ID", VacId);
        //    base.AddParam(paras, "IN_UserUID", UserID);            
        //    var ret = this.db.ExecuteScalar(cmdText, paras);
        //    if (ret == null)
        //    {
        //        return -1;
        //    }
        //    else if (ret != null && int.Parse(ret.ToString()) == 99)
        //    {
        //        return 0; 
        //    }
        //    return int.Parse(ret.ToString());
        //}

        /// <summary>
        /// Check Approve Is Finish
        /// </summary>
        /// <param name="VacId"></param>
        /// <returns></returns>
        public bool CheckApproveIsFinish(int VacId)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_CheckApproveFinish";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", VacId);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 0;
        }


        /// <summary>
        /// Check Approve
        /// </summary>
        /// <param name="attached">T_Approve_List</param>
        /// <returns></returns>
        //public int CheckApprove(int approveID)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Approve_List_CheckUserNotApprove";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApproveID", approveID);

        //    return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        //}


        /// <summary>
        /// Check Check Has User Approved(less level than)
        /// 2015/03/26
        /// </summary>        
        /// <returns>true: finish, false: don't finish yet</returns>
        public bool CheckPreviousLevelFinish(int vacID, int userID)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_CheckPreLevelFinish";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacID);
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 0;
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="attached">T_Vacation_Approve_List</param>
        /// <returns></returns>
        public int Insert(T_Vacation_Approve_List app)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", app.VacationID);
            base.AddParam(paras, "IN_RouteUID", app.RouteUID);
            base.AddParam(paras, "IN_RouteLevel", app.RouteLevel);
            base.AddParam(paras, "IN_RouteMethod", app.RouteMethod);
            base.AddParam(paras, "IN_ApproveStatus", app.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", app.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", app.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", app.ApproveReason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete list by VacationID
        /// </summary>
        /// <param name="VacID"></param>
        /// <returns></returns>
        public int DeleteByVacationID(int VacID)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_DeleteByVacationID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", VacID);

            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        #endregion

        #region Ignore

        /// <summary>
        /// Ignore
        /// </summary>
        /// <returns></returns>
        public int Ignore(int vacationID, int updateUID, short ignoreStatus, string reason)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_Ignore";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);
            base.AddParam(paras, "IN_ApproveUID", updateUID);
            base.AddParam(paras, "IN_IgnoreStatus", ignoreStatus);
            base.AddParam(paras, "IN_Reason", reason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Back Previous

        /// <summary>
        /// Previous
        /// </summary>
        /// <returns></returns>
        public int Previous(int vacationID, int updateUID, short prevStatus, short newStatus, string reason)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_Previous";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);
            base.AddParam(paras, "IN_ApproveUID", updateUID);
            base.AddParam(paras, "IN_PreviousStatus", prevStatus);
            base.AddParam(paras, "IN_NewStatus", newStatus);
            base.AddParam(paras, "IN_Reason", reason);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Approve

        /// <summary>
        /// Approve
        /// </summary>
        /// <returns></returns>
        public int Approve(int vactionID, int approveUID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vactionID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            base.AddParam(paras, "IN_RouteMethodOR", (short)RouteMethods.OR);
            base.AddParam(paras, "IN_Reason", reason);
                        
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        ///  Update data from status back previous to status new
        /// </summary>
        /// <param name="vacationID"></param>
        /// <param name="userID"></param>
        /// <param name="prevStatus"></param>
        /// <param name="newStatus"></param>
        /// <returns></returns>
        public int BackPreviousToNew(int vacationID, int userID, short prevStatus, short newStatus)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_UpdateBackPreviousLevelToNew";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "@IN_ApproveStatusNew", newStatus);
            base.AddParam(paras, "@IN_ApproveStatusBack", prevStatus);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// UpdateApproveStatus
        /// </summary>
        /// <param name="vacationID"></param>
        /// <param name="updateUID"></param>
        /// <param name="approveStatus"></param>
        /// <returns></returns>
        public int Confirm(int vacationID, int routeUID, short approveStatus)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Approve_List_Confirm";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);
            if (routeUID == Constants.DEFAULT_USER_ID)
            {
                base.AddParam(paras, "IN_RouteUID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_RouteUID", routeUID);
            }

            base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

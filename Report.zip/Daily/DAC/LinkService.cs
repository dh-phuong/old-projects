﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_Config_H Service
    /// </summary>
    public class LinkService: BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of M_Setting_H Service
        /// </summary>
        public LinkService(): base()
        {
        }

        /// <summary>
        /// Contructor of M_Setting_H Service
        /// </summary>
        /// <param name="db">Class DB</param>
        public LinkService(DB db): base(db)
        {
            
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <param name="userCD">user code</param>
        /// <param name="userName">user name</param>
        /// <param name="typeName">type name</param>
        /// <param name="routeCD">route code</param>
        /// <param name="pageIndex">page index</param>
        /// <param name="pageSize">page size</param>
        /// <param name="sortField">sort field</param>
        /// <param name="sortDirec">sort direction</param>
        /// <returns></returns>
        public IList<LinkInfo> GetListByCond(string userCD, string userName, string typeName,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Link_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", userCD, true);
            base.AddParam(paras, "IN_UserName", userName, true);
            base.AddParam(paras, "IN_TypeName", typeName, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<LinkInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row for list
        /// </summary>
        /// <param name="userCD">user code</param>
        /// <param name="userName">user name</param>
        /// <param name="typeName">type name</param>
        /// <param name="routeCD">route code</param>
        /// <returns></returns>
        public int getTotalRow(string userCD, string userName, string typeName)
        {
            //SQL String
            string cmdText = "P_M_Link_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", userCD, true);
            base.AddParam(paras, "IN_UserName", userName, true);
            base.AddParam(paras, "IN_TypeName", typeName, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public M_Link GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_Link_GetByID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<M_Link>(cmdText, paras);
        }

        /// <summary>
        /// Get by unique key
        /// </summary>
        /// <param name="userID">user id</param>
        /// <param name="typeApplyID">type apply id</param>
        /// <returns></returns>
        public M_Link GetByKey(int userID, int typeApplyID)
        {
            //SQL String
            string cmdText = "P_M_Link_GetByKey";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_TypeApplyID", typeApplyID);

            return this.db.Find<M_Link>(cmdText, paras);
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="data">M_Link</param>
        /// <returns></returns>
        public int Insert(M_Link data)
        {
            //SQL String
            string cmdText = "P_M_Link_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_UserID", data.UserID);
            base.AddParam(paras, "IN_TypeApplyID", data.TypeApplyID);
            base.AddParam(paras, "IN_RouteID", data.RouteID);

            base.AddParam(paras,"IN_CreateUID", data.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update data
        /// </summary>
        /// <param name="data">M_Link</param>
        /// <returns></returns>
        public int Update(M_Link data)
        {
            //SQL String
            string cmdText = "P_M_Link_Update";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", data.ID);
            base.AddParam(paras,"IN_RouteID", data.RouteID);

            base.AddParam(paras,"IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras,"IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">updateDate</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Link_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", ID);
            base.AddParam(paras,"IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

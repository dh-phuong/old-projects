﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_Config_D Service
    /// </summary>
    public class Config_DService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor M_Config_DSetting Service
        /// </summary>
        private Config_DService()
            : base()
        {
        }

        /// <summary>
        /// Contructor M_Config_DSetting Service
        /// </summary>
        /// <param name="db"></param>
        public Config_DService(DB db) :base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get List By Config Cd
        /// </summary>
        /// <param name="configCd"></param>
        /// <returns></returns>
        public IList<M_Config_D> GetListByConfigCd(string configCd)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetListByConfigCd";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ConfigCd", configCd);

            return this.db.FindList<M_Config_D>(cmdText, paras);
        }

        /// <summary>
        /// Get list by header ID
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public IList<M_Config_D> GetByListByHeaderID(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetByListByHeaderID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<M_Config_D>(cmdText, paras);
        }

        /// <summary>
        /// Get list by conditions
        /// Create Author: ISV-TRAM
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <param name="No">No</param>
        /// <returns>M_Config_D model</returns>
        public M_Config_D GetByCondition(int headerID, int No)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetByCondition";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);
            base.AddParam(paras, "IN_No", No);

            return this.db.Find<M_Config_D>(cmdText, paras);
        }


        /// <summary>
        /// Get Value
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="configCd">ConfigCd</param>
        /// <param name="value1">Value1</param>
        /// <returns></returns>
        public int? GetValue(string configCd, int value1)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetValue";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCd", configCd);
            base.AddParam(paras, "IN_Value1", value1);

            //---------------Add 2015/01/06 ISV-HUNG-----------------//
            var ret = string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
            if (string.IsNullOrEmpty(ret))
            {
                return null;
            }
            else
            {
                return Convert.ToInt32(this.db.ExecuteScalar(cmdText, paras));
            }
            //---------------Add 2015/01/06 ISV-HUNG-----------------//
        }


        /// <summary>
        /// Get Value2 by value1
        /// Create Author: ISV-GIAM
        /// </summary>
        /// <param name="configCd">ConfigCd</param>
        /// <param name="value1">Value1</param>
        /// <returns></returns>
        public string GetValue2(string configCd, int value1)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetValue2";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCd", configCd);
            base.AddParam(paras, "IN_Value1", value1);

            return string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
        }

        /// <summary>
        /// Get value 4 by Config Code and Value1
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="value1"></param>
        /// <returns></returns>
        public string GetValue4(string configCd, int value1)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetValue4";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCd", configCd);
            base.AddParam(paras, "IN_Value1", value1);

            return string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
        }

        /// <summary>
        /// Get value 3 by Config Code and Value1
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="value1"></param>
        /// <returns></returns>
        public string GetValue3(string configCd, int value1)
        {
            //SQL String
            string cmdText = "P_M_Config_D_GetValue3";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ConfigCd", configCd);
            base.AddParam(paras, "IN_Value1", value1);

            return string.Format("{0}", this.db.ExecuteScalar(cmdText, paras));
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="detailItem">M_Config_D</param>
        /// <returns></returns>
        public int Insert(M_Config_D detailItem)
        {
            //SQL String
            string cmdText = "P_M_Config_D_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", detailItem.HID);
            base.AddParam(paras,"IN_No", detailItem.No);
            base.AddParam(paras,"IN_Value1", detailItem.Value1);
            base.AddParam(paras,"IN_Value2", detailItem.Value2);
            base.AddParam(paras,"IN_Value3", detailItem.Value3);
            base.AddParam(paras,"IN_Value4", detailItem.Value4);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete by headerID
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Config_D_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

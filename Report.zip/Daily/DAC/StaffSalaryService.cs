﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    public class StaffSalaryService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of User service
        /// </summary>        
        private StaffSalaryService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of User service
        /// </summary>
        /// <param name="db">Class DB</param>
        public StaffSalaryService(DB db)
            : base(db)
        {
        }

        #endregion

        #region GetData
        /// <summary>
        /// Get by UserID
        /// </summary>
        /// <returns>M_User</returns>
        public IList<M_Staff_Salary> GetByStaffID(int userID)
        {
            //SQL String
            string cmdText = "P_M_StaffSalary_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.FindList<M_Staff_Salary>(cmdText, paras);
        }
        #endregion

        #region Insert

        public int Insert(M_Staff_Salary salary)
        {
            //SQL String
            string cmdText = "P_M_StaffSalary_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", salary.UserID);
            base.AddParam(paras, "IN_StartDate", salary.StartDate);
            base.AddParam(paras, "IN_BasicSalary", salary.BasicSalary);
            base.AddParam(paras, "IN_Allowance", salary.Allowance);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Delete(int userID)
        {
            //SQL String
            string cmdText = "P_M_StaffSalary_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

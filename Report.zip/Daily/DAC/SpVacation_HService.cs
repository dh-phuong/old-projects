﻿using System;
using System.Collections;
using System.Collections.Generic;
using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// 
    /// </summary>
     public class SpVacation_HService: BaseService
    {
        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
         private SpVacation_HService()
             : base()
        {
        }

        /// <summary>
        /// Constructor with param
        /// </summary>
        /// <param name="db">Database</param>
        public SpVacation_HService(DB db)
            : base(db)
        {
            
        }

        #endregion

        #region Get data

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        public M_SpecialVacation_H GetByID(int id)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_GetByID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);

            return this.db.Find<M_SpecialVacation_H>(cmdText, paras);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="spVacationCD"></param>
        /// <param name="spVacationNameUS"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<SpVacationInfo> GetList(string spVacationCD, string spVacationNameUS, string spVacationNameVN, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_GetList";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SpVacationCD", spVacationCD, true);
            base.AddParam(paras, "IN_SpVacationNameUS", spVacationNameUS, true);
            base.AddParam(paras, "IN_SpVacationNameVN", spVacationNameVN, true);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<SpVacationInfo>(cmdText, paras);
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="moneyCode"></param>
       /// <param name="moneyNameUS"></param>
       /// <returns></returns>
        public int GetTotalRow(string spVacationCD, string spVacationNameUS, string spVacationNameVN)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_GetTotalRow";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SpVacationCD", spVacationCD, true);
            base.AddParam(paras, "IN_SpVacationNameUS", spVacationNameUS, true);
            base.AddParam(paras, "IN_SpVacationNameVN", spVacationNameVN, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }
         
        #endregion

        #region Check data

        /// <summary>
        /// Check existing of SpVacationCD
        /// </summary>
        /// <param name="spVacationCD">SpVacationCD</param>
        /// <returns></returns>
        public bool IsExistSpVacationCD(string spVacationCD)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_IsExistSpVacationCD";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SpVacationCD", spVacationCD);

            int count = int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());

            return count > 0;
        }

        #endregion

        #region Insert

        /// <summary>
        /// 
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        public int Insert(M_SpecialVacation_H header)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_SpVacationCD", header.SpVacationCD);
            base.AddParam(paras, "IN_SpVacationNameUS", header.SpVacationNameUS);
            base.AddParam(paras, "IN_SpVacationNameVN", header.SpVacationNameVN);
            
            base.AddParam(paras, "IN_CreateUID", header.CreateUID);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// 
        /// </summary>
        /// <param name="header"></param>
        /// <returns></returns>
        public int Update(M_SpecialVacation_H header)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_Update";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", header.ID);
            base.AddParam(paras, "IN_SpVacationCD", header.SpVacationCD);
            base.AddParam(paras, "IN_SpVacationNameUS", header.SpVacationNameUS);
            base.AddParam(paras, "IN_SpVacationNameVN", header.SpVacationNameVN);
            
            base.AddParam(paras, "IN_UpdateDate", header.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", header.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
        
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_SpecialVacation_H_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

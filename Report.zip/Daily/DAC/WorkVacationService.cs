﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using System;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// WorkVacationService.cs
    /// ISV-TRUC
    /// 2015/06/05
    /// </summary>
    public class WorkVacationService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private WorkVacationService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public WorkVacationService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="templateFormID"></param>
        /// <param name="typeApply"></param>
        /// <returns></returns>
        public IList<VacationInfo> GetListByCond(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetListByCond";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VacationInfo>(cmdText, paras);
        }
        
        /// <summary>
        /// GetTotalRow
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyDateFrm"></param>
        /// <param name="applyDateTo"></param>
        /// <param name="applyStatus"></param>
        /// <param name="templateFormID"></param>
        /// <param name="typeApply"></param>
        /// <returns></returns>
        public int GetTotalRow(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetTotalRow";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list by PreApplyID
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="preApplyID"></param>
        /// <returns></returns>
        public IList<T_Apply> GetListByPreApplyID(int loginId, string userCD, string userName, DateTime? applyDateFrm, DateTime? applyDateTo, short applyStatus, int templateFormID, int typeApply)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetListByPreApplyID";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            base.AddParam(paras, "IN_ApplyDateFrm", applyDateFrm);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);

            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            if (templateFormID == -1)
            {
                base.AddParam(paras, "IN_TemplateFormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TemplateFormID", templateFormID);
            }

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }

            return this.db.FindList<T_Apply>(cmdText, paras);
        }


        /// <summary>
        /// GetTotalRow Of Approve List Form
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public int GetTotalRowForApprove(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, int formID, int typeApply, int approvedFlg)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetTotalRowForApprove";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }

            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);

            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListByCond Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VacationInfo> GetListByCondForApprove(int loginId, DateTime? applyDate, string userCD, string userName, short applyStatus, int formID, int typeApply, int approvedFlg,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetListByCondForApprove";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            if (applyDate == null)
            {
                base.AddParam(paras, "IN_ApplyDate", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyDate", applyDate);
            }
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }

            //approvedFlg
            if (approvedFlg == -1)
            {
                base.AddParam(paras, "IN_ApprovedFlag", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApprovedFlag", approvedFlg);
            }

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (formID == -1)
            {
                base.AddParam(paras, "IN_FormID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_FormID", formID);
            }
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VacationInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get remain days
        /// </summary>
        /// <param name="applyId">apply id</param>
        /// <param name="userId">user id</param>
        /// <returns></returns>
        public decimal GetRemainDays(int applyId, int userId)
        {
            
            //Command text
            string cmdText = "P_T_Work_Vacation_GetRemainDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyId);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_ApplyStatus_Rejected", (int)StatusApply.Rejected);
            base.AddParam(prms, "IN_ApplyStatus_Cancel", (int)StatusApply.Cancel);

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetPlanDays
        /// ISV-TRUC
        /// 2015/06/04
        /// </summary>
        /// <param name="applyId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public decimal GetPlanDays(int applyId, int userId)
        {
            //Command text
            string cmdText = "P_T_Work_Vacation_GetPlanDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyId);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_ApplyStatus_Rejected", (int)StatusApply.Rejected);
            base.AddParam(prms, "IN_ApplyStatus_Cancel", (int)StatusApply.Cancel);

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetUsedDays
        /// </summary>
        /// <param name="applyId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public decimal GetUsedDays(int userId, DateTime dateFrm, DateTime dateTo)
        {
            
            //Command text
            string cmdText = "P_T_Work_Vacation_GetUsedDays";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            if (dateFrm == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateFrom", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateFrom", dateFrm);
            }
            if (dateTo == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateTo", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateTo", dateTo);
            }

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetNumberOfDaysByRangeDate
        /// ISV-TRUC
        /// 2015/06/12
        /// </summary>
        /// <param name="dateFrm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public decimal GetNumberOfDaysByRangeDate(DateTime dateFrm, DateTime dateTo)
        {

            //Command text
            string cmdText = "P_T_Work_Vacation_GetNumberOfDaysByRangeDate";

            //Add parameter
            Hashtable prms = new Hashtable();
            if (dateFrm == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateFrom", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateFrom", dateFrm);
            }
            if (dateTo == DateTime.MinValue)
            {
                base.AddParam(prms, "IN_DateTo", DBNull.Value);
            }
            else
            {
                base.AddParam(prms, "IN_DateTo", dateTo);
            }
            var ret = this.db.ExecuteScalar(cmdText, prms);
            if (ret == DBNull.Value)
            {
                return decimal.Zero;
            }
            else
            {
                return (decimal)ret;
            }
        }

        /// <summary>
        /// GetUsedDaysInMonth
        /// 2015/06/11
        /// ISV-TRUC
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="month"></param>
        /// <returns></returns>
        public decimal GetUsedDaysInMonth(int userId, AccountingPeriod period)
        {
            //Command text
            string cmdText = "P_T_Work_Vacation_GetUsedDaysInMonth";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_DateMonthFrm", period.StartDate);
            base.AddParam(prms, "IN_DateMonthTo", period.EndDate);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_ApplyStatus_Approved", (int)StatusApply.Approved);
            base.AddParam(prms, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(prms, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(prms, "IN_VacationType_DayOff", (int)VacationType.DayOff);

            return (decimal)this.db.ExecuteScalar(cmdText, prms);
        }

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Vacation GetByID(int id, bool isIncludeDelete = false)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", id);
            base.AddParam(paras, "IN_IncludeDelete", isIncludeDelete ? 1 : 0);

            return this.db.Find<T_Work_Vacation>(cmdText, paras);
        }


        /// <summary>
        /// GetByApplyNo
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Vacation GetByApplyNo(string applyNo)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetByApplyNo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);

            return this.db.Find<T_Work_Vacation>(cmdText, paras);
        }

        /// <summary>
        /// GetByPreApplyID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_Vacation GetByPreApplyID(int id)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_GetByPreApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PreApplyID", id);

            return this.db.Find<T_Work_Vacation>(cmdText, paras);
        }

        /// <summary>
        /// Is Exist Form-Type In Apply
        /// ISV-TRUC
        /// 2015/05/06
        /// </summary>
        /// <param name="TypeID"></param>
        /// <returns></returns>
        public bool IsExistFormType(int TypeID)
        {
            //SQL String
            string cmdText = "P_T_Apply_CheckExistFormType";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_TypeID", TypeID);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) > 0;
            
        }

       /// <summary>
        /// Get by UserID and TypeAppy
       /// TRAM 2015/05/12
       /// </summary>
       /// <param name="userID"></param>
       /// <param name="typeApplyID"></param>
       /// <returns></returns>
        public T_Apply GetByUserIDAndTypeAppy(int userID, int typeApplyID)
        {
            //SQL String
            string cmdText = "P_T_Apply_GetByUserIDAndTypeAppy";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_TypeApplyID", typeApplyID);

            return this.db.Find<T_Apply>(cmdText, paras);

        }

        #endregion

        #region Approve
        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int UpdateStatus(int approveID, int approveUID, int approveStatus, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Approve_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyID", approveID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_Status", approveStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Insert

        /// <summary>
        /// ISV-TRUC
        /// Insert
        /// 2015/06/05
        /// ----------------Checked----------------
        /// </summary>
        /// <param name="vac"></param>
        /// <returns></returns>
        public int Insert(T_Work_Vacation vac)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", vac.No);
            base.AddParam(paras, "IN_PreApplyID", vac.PreApplyID);
            base.AddParam(paras, "IN_ApplyStatus", vac.ApplyStatus);
            base.AddParam(paras, "IN_ApplyDate", vac.ApplyDate);
            base.AddParam(paras, "IN_VacationType", vac.VacationType);
            base.AddParam(paras, "IN_UserID", vac.UserID);
            base.AddParam(paras, "IN_StartDate", vac.StartDate);
            base.AddParam(paras, "IN_EndDate", vac.EndDate);
            base.AddParam(paras, "IN_Duration", vac.Duration);
            base.AddParam(paras, "IN_Reason", vac.Reason);
            base.AddParam(paras, "IN_RouteID", vac.RouteID);
            base.AddParam(paras, "IN_StatusFlag", vac.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", vac.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", vac.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Work_Vacation>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Work_Vacation vac)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", vac.ID);
            base.AddParam(paras, "IN_UserID", vac.UserID);
            base.AddParam(paras, "IN_ApplyStatus", vac.ApplyStatus);
            base.AddParam(paras, "IN_Duration", vac.Duration);
            base.AddParam(paras, "IN_StartDate", vac.StartDate);
            base.AddParam(paras, "IN_EndDate", vac.EndDate);
            base.AddParam(paras, "IN_VacationType", vac.VacationType);
            base.AddParam(paras, "IN_Reason", vac.Reason);
            base.AddParam(paras, "IN_RouteID", vac.RouteID);
            base.AddParam(paras, "IN_StatusFlag", vac.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", vac.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", vac.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update ApplyStatus
        /// ISV-TRAM
        /// 2015/03/23
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateApplyStatus(int applyID, int updateUID, short applyStatus,int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        /// <summary>
        /// Update StatusFlag
        /// ISV-TRUC
        /// 2015/06/08
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(T_Work_Vacation apply)
        {
            //SQL String
            string cmdText = "P_T_Work_Vacation_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_StatusFlag", apply.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        

        #endregion

        #region Confirm

        /// <summary>
        /// Confirm
        /// </summary>
        /// <param name="apply">T_Apply model</param>
        /// <returns></returns>
        public int Confirm(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Confirm";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_ApplyStatus", apply.ApplyStatus);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int Delete(T_Apply apply)
        {
            //SQL String
            string cmdText = "P_T_Apply_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", apply.ID);
            base.AddParam(paras, "IN_UpdateDate", apply.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", apply.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check

        /// <summary>
        /// Check duplicate time apply
        /// </summary>
        /// <param name="applyNo">apply id</param>
        /// <param name="userId">user id</param>
        /// <param name="startDate">start date</param>
        /// <param name="endDate">end date</param>
        /// <returns></returns>
        public bool IsDuplicateTimeApply(string applyNo, int userId, DateTime startDate, DateTime endDate)
        {
            
            //Command text
            string cmdText = "P_T_Work_Vacation_IsDuplicateTimeApply";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyID", applyNo);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_StartDate", startDate);
            base.AddParam(prms, "IN_EndDate", endDate);
            base.AddParam(prms, "IN_StatusCancel", StatusApply.Cancel);
           // base.AddParam(prms, "IN_VacationDayOff", (short)VacationType.DayOff);
            
            return (int)this.db.ExecuteScalar(cmdText, prms) > 0;
        }

        #endregion
    }
}
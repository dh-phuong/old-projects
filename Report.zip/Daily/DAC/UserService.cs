﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;


namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_User DAC
    /// </summary>
    public class UserService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of User service
        /// </summary>        
        private UserService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of User service
        /// </summary>
        /// <param name="db">Class DB</param>
        public UserService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        public IList<M_User> GetListAdmin() {
            //SQL String
            string cmdText = "P_M_User_GetListAdmin";            
            return this.db.FindList<M_User>(cmdText);
        }

        public IList<DropDownModel> GetDataForDropdownByCd(int deptID, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_User_GetDataForDropdownByCd";

            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_DepartmentID", deptID);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, prms);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown(int deptID, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_User_GetDataForDropdown";

            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_DepartmentID", deptID);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, prms);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// Get data by DepartmentID
        /// </summary>
        /// <param name="deparmentID">DeparmentID</param>
        /// <returns></returns>
        public IList<M_User> GetByDepartmentID(string deparmentID)
        {
            string cmdText = "P_M_User_GetByDepartmentID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentID", deparmentID, true);

            return this.db.FindList<M_User>(cmdText, paras);
        }

        /// <summary>
        /// Get by LoginID
        /// </summary>
        /// <returns>M_User</returns>
        public M_User GetByLoginID(string loginID)
        {
            //SQL String
            string cmdText = "P_M_User_GetByLoginID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginID);

            return this.db.Find<M_User>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCond
        /// ISV-TRUC
        /// </summary>
        /// <param name="userName1"></param>
        /// <param name="userName2"></param>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="inValid"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<UserInfo> GetListByCond(string userName1, string groupCD, string groupName, string inValid,
                                            int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_User_GetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserName1", userName1, true);
            base.AddParam(paras, "IN_GroupCD", EditDataUtil.ToFixCodeDB(groupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH), true);
            base.AddParam(paras, "IN_GroupName", groupName, true);
            base.AddParam(paras, "IN_InValid", inValid);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<UserInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get list by conditions for the search form
        /// </summary>
        /// <returns>UserSearchInfo</returns>
        public IList<UserSearchInfo> GetListByConditionForSearch(string userCd, string loginID, string userName1, string groupCD, int? departmentID, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_User_GetByConditionsForSearch";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", userCd, true);
            base.AddParam(paras, "IN_LoginID", loginID, true);
            base.AddParam(paras, "IN_UserName1", userName1, true);
            base.AddParam(paras, "IN_GroupCD", groupCD, true);
            base.AddParam(paras, "IN_DepartmentID", departmentID, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<UserSearchInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userCd"></param>
        /// <param name="userName1"></param>
        /// <param name="userName2"></param>
        /// <param name="groupCD"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string userCd, string loginID, string userName1, string groupCD, int? departmentID)
        {
            //SQL String
            string cmdText = "P_M_User_GetCountByConditionForSeach";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", userCd, true);
            base.AddParam(paras, "IN_LoginID", loginID, true);
            base.AddParam(paras, "IN_UserName1", userName1, true);
            base.AddParam(paras, "IN_GroupCD", groupCD, true);
            base.AddParam(paras, "IN_DepartmentID", departmentID, true);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by user ID
        /// ISV-TRUC
        /// </summary>
        /// <param name="userID">userID</param>
        /// <returns></returns>
        public M_User GetByID(int userID)
        {
            //SQL String
            string cmdText = "P_M_User_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.Find<M_User>(cmdText, paras);
        }

        /// <summary>
        /// Get By User Code
        /// ISV-TRUC
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <returns></returns>
        public M_UserInfo GetUserInfo(string userCD, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_User_GetUserInfo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", EditDataUtil.ToFixCodeDB(userCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.Find<M_UserInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get By User id
        /// ISV-TRUC
        /// </summary>
        /// <param name="userID">User id</param>
        /// <returns></returns>
        public M_UserInfo GetUserInfoByID(int userID, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_User_GetUserInfoByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.Find<M_UserInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetUserInfoByStaffID
        /// ISV-TRUC
        /// 2015/06/08
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="includeDelete"></param>
        /// <returns></returns>
        public M_UserInfo GetUserInfoByStaffID(int staffID, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_User_GetUserInfoByStaffID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.Find<M_UserInfo>(cmdText, paras);
        }

        /// <summary>
        /// get by department id
        /// </summary>
        /// <param name="deptID"></param>
        /// <param name="includeDelete"></param>
        /// <returns></returns>
        public IList<M_UserInfo> GetUserInfoByDeptID(int deptID, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_User_GetUserInfoByDeptID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", deptID);
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.FindList<M_UserInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get By User Code
        /// ISV-TRUC
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <returns></returns>
        public M_User GetByUserCD(string userCD, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_M_User_GetByUserCD";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", EditDataUtil.ToFixCodeDB(userCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_Invalid", includeDelete ? 1 : 0);

            return this.db.Find<M_User>(cmdText, paras);
        }

        /// <summary>
        /// Get By Staff ID
        /// ISV-TRUC
        /// </summary>
        /// <param name="staffID">StaffID</param>
        /// <returns></returns>
        public M_User GetByStaffID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_User_GetByStaffID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.Find<M_User>(cmdText, paras);
        }

        /// <summary>
        /// getTotalRow
        /// ISV-TRUC
        /// </summary>
        /// <param name="userName1"></param>
        /// <param name="userName2"></param>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="inValid"></param>
        /// <returns></returns>
        public int getTotalRow(string userName1, string groupCD, string groupName, string inValid)
        {
            //SQL String
            string cmdText = "P_M_User_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserName1", userName1, true);
            base.AddParam(paras, "IN_GroupCD", EditDataUtil.ToFixCodeDB(groupCD, M_GroupUser_H.GROUP_CODE_DB_MAX_LENGTH), true);
            base.AddParam(paras, "IN_GroupName", groupName, true);
            base.AddParam(paras, "IN_InValid", inValid);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get By Key
        /// ISV-TRUC
        /// </summary>
        /// <param name="userCD">userCD</param>
        /// <param name="loginID">loginID</param>
        /// <returns></returns>
        public M_User GetByKey(string userCD, string loginID)
        {
            //SQL String
            string cmdText = "P_M_User_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", EditDataUtil.ToFixCodeDB(userCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_LoginID", loginID);

            return this.db.Find<M_User>(cmdText, paras);
        }

        /// <summary>
        /// GetCountActiveUser
        /// </summary>
        /// <returns></returns>
        public int GetCountActiveUser()
        {
            //SQL String
            string cmdText = "P_M_User_GetCountActiveUser";

            //Para
            Hashtable paras = new Hashtable();

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get all user
        /// Author: TRAM
        /// </summary>
        /// <returns></returns>
        public IList<DropDownModel> GetAll()
        {
            //SQL String
            string cmdText = "P_M_User_GetAll";

            //Para
            Hashtable paras = new Hashtable();
            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);
            return ret;
        }

        /// <summary>
        /// GetUserNoApprover
        /// Author: TRAM
        /// </summary>
        /// <returns></returns>
        public IList<UserInfoForFormLink> GetListUserNotApprove(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_User_GetListUserNotApprove";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);

            IList<UserInfoForFormLink> ret = this.db.FindList<UserInfoForFormLink>(cmdText, paras);
            return ret;
        }

        /// <summary>
        /// GetTotalRowForNotApprove
        /// Author: TRAM
        /// <param name="formID"></param>
        /// <param name="routeID"></param>
        /// <returns></returns>
        public int GetTotalRowForNotApprove(int formID, int routeID)
        {
            //SQL String
            string cmdText = "P_M_User_GetTotalRowForNotApprove";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_RouteID", routeID);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Insert(M_User user)
        {
            //SQL String
            string cmdText = "P_M_User_Insert";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserCD", EditDataUtil.ToFixCodeDB(user.UserCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_LoginID", user.LoginID);
            base.AddParam(paras, "IN_UserName1", user.UserName1);
            base.AddParam(paras, "IN_UserName2", user.UserName2);

            base.AddParam(paras, "IN_Position1", user.Position1);
            base.AddParam(paras, "IN_Position2", user.Position2);
            base.AddParam(paras, "IN_Email", user.Email);
            base.AddParam(paras, "IN_Password", sec.Encrypt(user.Password));
            base.AddParam(paras, "IN_StaffID", user.StaffID);
            base.AddParam(paras, "IN_GroupID", user.GroupID);
            base.AddParam(paras, "IN_StatusFlag", user.StatusFlag);
            base.AddParam(paras, "IN_InvalidDate", user.InvalidDate);
            base.AddParam(paras, "IN_CreateUID", user.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", user.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Update(M_User user)
        {
            //SQL String
            string cmdText = "P_M_User_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", user.ID);
            base.AddParam(paras, "IN_UserCD", EditDataUtil.ToFixCodeDB(user.UserCD, M_User.USER_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_LoginID", user.LoginID);
            base.AddParam(paras, "IN_UserName1", user.UserName1);
            base.AddParam(paras, "IN_UserName2", user.UserName2);
            base.AddParam(paras, "IN_Position1", user.Position1);
            base.AddParam(paras, "IN_Position2", user.Position2);
            base.AddParam(paras, "IN_Email", user.Email);
            base.AddParam(paras, "IN_Password", sec.Encrypt(user.Password));
            base.AddParam(paras, "IN_GroupID", user.GroupID);
            base.AddParam(paras, "IN_StaffID", user.StaffID);
            base.AddParam(paras, "IN_StatusFlag", user.StatusFlag);
            base.AddParam(paras, "IN_InvalidDate", user.InvalidDate);
            base.AddParam(paras, "IN_UpdateDate", user.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", user.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update Password
        /// ISV-GIAM
        /// </summary>
        /// <param name="user">M_User</param>
        /// <param name="userPassword">new Password</param>
        /// <returns></returns>
        public int UpdatePassword(M_User user, string userPassword)
        {
            //SQL String
            string cmdText = "P_M_User_UpdatePassword";
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", user.ID);
            base.AddParam(paras, "IN_UserPassword", userPassword);
            base.AddParam(paras, "IN_UpdateDate", user.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", user.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Add New Code For Category
        public IList<RouteDetailListInfo> GetListSortBy(int routeId, int sortField, int sortDirec)
        {
            // Command text
            string cmdText = "P_M_User_GetListSortBy";
            //Para
            Hashtable paras = new Hashtable();

            //base.AddParam(paras, "IN_RootCD", Constant.CATEGORY_ROOT_CODE);

            base.AddParam(paras, "IN_RouteID", routeId);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<RouteDetailListInfo>(cmdText, paras);
        }
        #endregion
    }
}

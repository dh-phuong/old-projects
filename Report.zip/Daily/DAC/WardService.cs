﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// Create  :ISV-NHAT
    /// Date    :2015/03/30
    /// Class District DAC
    /// </summary>
    public class WardService : BaseService
    {

        #region Constructor

        /// <summary>
        /// Contructor
        /// </summary>
        private WardService()
            : base()
        { }

        /// <summary>
        /// Contructor with db
        /// </summary>
        /// <param name="db"></param>
        public WardService(DB db)
            : base(db)
        { }

        #endregion

        #region Get

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_Ward GetByID(int id)
        {
            // Command text
            string cmdText = "P_M_Ward_GetByID";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return this.db.Find<M_Ward>(cmdText, paras);
        }

        /// <summary>
        /// Get by key
        /// </summary>
        /// <returns></returns>
        public M_Ward GetByKey(int districtID, string wardCD)
        {
            // Command text
            string cmdText = "P_M_Ward_GetByKey";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DistrictID", districtID);
            base.AddParam(paras, "IN_WardCD", EditDataUtil.ToFixCodeDB(wardCD, M_Ward.WARD_CODE_MAX_LEN_DB));
            return this.db.Find<M_Ward>(cmdText, paras);
        }

        /// <summary>
        /// Get list district info by condition
        /// </summary>
        /// <param name="provinceID">province id</param>
        /// <param name="districtID">district id</param>
        /// <param name="wardCD">ward code</param>
        /// <param name="wardName">ward name</param>
        /// <param name="pageIndex">page index</param>
        /// <param name="pageSize">page size</param>
        /// <param name="sortField">sort field</param>
        /// <param name="sortDirec">sort direction</param>
        /// <returns></returns>
        public IList<WardInfo> GetListByCond(int provinceID, int districtID, string wardCD, string wardName,
                                                    int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Ward_GetByCond";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ProvinceID", provinceID);
            base.AddParam(paras, "IN_DistrictID", districtID);
            base.AddParam(paras, "IN_WardCD", wardCD);
            base.AddParam(paras, "IN_WardName", wardName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<WardInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get total row
        /// </summary>
        /// <param name="provinceID">province id</param>
        /// <param name="districtID">district id</param>
        /// <param name="wardCD">ward code</param>
        /// <param name="wardName">ward name</param>
        /// <returns></returns>
        public int GetTotalRow(int provinceID, int districtID,  string wardCD, string wardName)
        {
            //SQL String
            string cmdText = "P_M_Ward_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ProvinceID", provinceID);
            base.AddParam(paras, "IN_DistrictID", districtID);
            base.AddParam(paras, "IN_WardCD", wardCD);
            base.AddParam(paras, "IN_WardName", wardName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/03/30
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropDownList(int districtID, bool withBlank = false)
        {
            string cmdText = "P_M_Ward_GetDataForDropDownList";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DistrictID", districtID);
            IList<DropDownModel> list = new List<DropDownModel>();
            if (districtID != -1)
            {
                list = this.db.FindList<DropDownModel>(cmdText, paras);
            }
            if (withBlank)
            {
                list.Insert(0, new DropDownModel("-1", "---"));
            }

            return list;
        }

        #endregion

        #region Insert
        
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">ward data</param>
        /// <returns></returns>
        public int Insert(M_Ward data)
        {
            //SQL String
            string cmdText = "P_M_Ward_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DistrictID", data.DistrictID);
            base.AddParam(paras, "IN_WardCD", EditDataUtil.ToFixCodeDB(data.WardCD, M_Ward.WARD_CODE_MAX_LEN_DB));
            base.AddParam(paras, "IN_WardName", data.WardName);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">ward data</param>
        /// <returns></returns>
        public int Update(M_Ward data)
        {
            //SQL String
            string cmdText = "P_M_Ward_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", data.ID);

            base.AddParam(paras, "IN_DistrictID", data.DistrictID);
            base.AddParam(paras, "IN_WardCD", EditDataUtil.ToFixCodeDB(data.WardCD, M_Ward.WARD_CODE_MAX_LEN_DB));
            base.AddParam(paras, "IN_WardName", data.WardName);

            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID">id</param>
        /// <param name="updateDate">update date</param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Ward_Delete";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

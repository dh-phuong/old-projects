﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    public class ApproveListService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private ApproveListService()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public ApproveListService(DB db)
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_ApproveList</returns>
        /// 

        public IList<ApproveListInfo> GetApproveListByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", id);  
            return this.db.FindList<ApproveListInfo>(cmdText, paras);
        }

        public int GetTotalRow(int id)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_GetTotalRow";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", id);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get count by UserID
        /// </summary>
        /// <param name="userID">UserID</param>
        /// <returns></returns>
        public int GetCountByUserID(int userID)
        {
            string cmdText = "P_T_Approve_List_GetCountByUserID";
            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// ISV-TRUC 2015/03/03
        /// Get List By ApproveID for Work
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public IList<ApproveWork> GetListForWork(int id)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_GetListByApproveID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", id);
            return this.db.FindList<ApproveWork>(cmdText, paras);
        }

        #endregion

        #region Ignore

        /// <summary>
        /// Ignore
        /// </summary>
        /// <param name="attached">T_Approve_List</param>
        /// <returns></returns>
        public int Ignore(int approveID, int approveUID, short status, string remark)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_Ignore";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ApproveID", approveID);
            base.AddParam(paras, "@IN_ApproveUID", approveUID);
            base.AddParam(paras, "@IN_Status", status);
            base.AddParam(paras, "@IN_Remark", remark);

            return this.db.ExecuteNonQuery(cmdText, paras);     
        }

        #endregion

        #region Approve

        /// <summary>
        /// Approve
        /// </summary>
        /// <param name="attached">T_Approve_List</param>
        /// <returns></returns>
        public int Approve(int approveID, int approveUID, short status, string remark)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", approveID);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_Status", status);
            base.AddParam(paras, "IN_Remark", remark);            

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Check Approve
        /// </summary>
        /// <param name="attached">T_Approve_List</param>
        /// <returns></returns>
        public int CheckApprove(int approveID)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_CheckUserNotApprove";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", approveID);            

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion

        #region Insert

        public int Insert(T_Approve_List app)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", app.ApproveID);
            base.AddParam(paras, "IN_UserID", app.UserID);
            base.AddParam(paras, "IN_ApproveUID", app.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", app.ApproveDate);
            base.AddParam(paras, "IN_Remark", app.Remark);
            base.AddParam(paras, "IN_ApproveLevel", app.ApproveLevel);
            base.AddParam(paras, "IN_RouteMethod", app.RouteMethod);
            base.AddParam(paras, "IN_ApproveFlag", app.ApproveFlag);
                        
            return this.db.ExecuteNonQuery(cmdText, paras);
            
        }
        #endregion
        
        #region Delete

        public int DeleteByApproveID(int AppID)
        {
            //SQL String
            string cmdText = "P_T_Approve_List_DeleteByApproveID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApproveID", AppID);
          
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    public class WorkStepService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Work step service
        /// </summary>        
        private WorkStepService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Work step service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkStepService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        /// <summary>
        /// Get list work info by work id
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public IList<DailyWorkInfo> GetListWorkByWorkID(int workID)
        {
            //comand text
            string cmdText = "P_T_Work_Step_GetListByWorkID";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_WorkID", workID);

            return db.FindList<DailyWorkInfo>(cmdText, prms);
        }

        /// <summary>
        /// Get list step by work id
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public IList<T_Work_Step> GetListByWorkID(int workID)
        {
            //comand text
            string cmdText = "P_T_Work_Step_GetListByWorkID";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_WorkID", workID);

            return db.FindList<T_Work_Step>(cmdText, prms);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="workStep"></param>
        /// <returns></returns>
        public int Insert(T_Work_Step workStep)
        {
            //SQL String
            string cmdText = "P_T_Work_Step_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkID", workStep.WorkID);
            base.AddParam(paras, "IN_WorkName", workStep.WorkName);
            base.AddParam(paras, "IN_WorkHour", workStep.WorkHour);
            base.AddParam(paras, "IN_WorkMinute", workStep.WorkMinute);
            base.AddParam(paras, "IN_Remark", workStep.Remark);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public int Delete(int workID)
        {
            //SQL String
            string cmdText = "P_T_Work_Step_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkID", workID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using System;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// ApproveService
    /// VN-NHO
    /// 2015.03.19
    /// </summary>
    public class VacationService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public VacationService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public VacationService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// GetTotalRow Of Approve List Form
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public int GetTotalRow(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetTotalRow";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if(applyStatus==-1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
            base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetListByCond Of Approve List Form
        /// Author by:ISV-NHAT
        /// Edit by: ISV-TRUC
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="approveNo"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="confirmDtFrom"></param>
        /// <param name="confirmDtTo"></param>
        /// <param name="type"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VacationInfo> GetListByCond(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetListByCond";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
            base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VacationInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetByID
        /// ISV-TRUC
        /// 2015/03/20
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Vacation</returns>
        public T_Vacation GetByID(int id, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            if (includeDelete)//Get include deleted data
            {
                base.AddParam(paras, "IN_StatusFlg", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StatusFlg",(int)DeleteFlag.NotDelete);
            }
            return this.db.Find<T_Vacation>(cmdText, paras);
        }


        //***********************************************************
        #region TRUC ADD 1/4/2015

        /// <summary>
        /// GetListByCond Regist
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="validData"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VacationInfo> GetListByCond_Regist(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData,
                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetListByCond_Regist";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
            //base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            //base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);            
            base.AddParam(paras, "IN_ApplyStatusCancel", (int)StatusApply.Cancel);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VacationInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetTotalRow Regist
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="validData"></param>
        /// <returns></returns>
        public int GetTotalRow_Regist(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetTotalRow_Regist";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
           // base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            //base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);
            base.AddParam(paras, "IN_ApplyStatusCancel", (int)StatusApply.Cancel);
            
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }


        /// <summary>
        /// GetListByCond Approve
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="validData"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<VacationInfo> GetListByCond_Approve(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData,
                                                int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetListByCond_Approve";

            //Parameter
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
            base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);
            
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<VacationInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetTotalRow Approve
        /// </summary>
        /// <param name="loginId"></param>
        /// <param name="userCD"></param>
        /// <param name="userName"></param>
        /// <param name="applyStatus"></param>
        /// <param name="typeApply"></param>
        /// <param name="validData"></param>
        /// <returns></returns>
        public int GetTotalRow_Approve(int loginId, string userCD, string userName, short applyStatus, int typeApply, int validData)
        {
            //SQL String
            string cmdText = "P_T_Vacation_GetTotalRow_Approve";

            //Parameter
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_LoginID", loginId);
            base.AddParam(paras, "IN_UserCD", userCD);
            base.AddParam(paras, "IN_UserName", userName);
            if (applyStatus == -1)
            {
                base.AddParam(paras, "IN_ApplyStatus", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            }
            if (typeApply == -1)
            {
                base.AddParam(paras, "IN_TypeApply", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_TypeApply", typeApply);
            }
            if (validData == -1)
            {
                base.AddParam(paras, "IN_Valid", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_Valid", validData);
            }
            base.AddParam(paras, "IN_ApplyStatusNew", (int)StatusApply.New);
            base.AddParam(paras, "IN_ApplyStatusIgnore", (int)StatusApply.Ignore);
            
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion
        //***********************************************************

        /// <summary>
        /// Get Info ByID
        /// ISV-TRUC
        /// 2015/03/20
        /// </summary>
        /// <returns>VacationInfoDetail</returns>
        public VacationInfoDetail GetVacationInfoByID(int id, int userID, bool includeDelete = true)
        {
            //SQL String
            string cmdText = "P_T_VacationInfo_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_UserID", userID);
            if (includeDelete)//Get include deleted data
            {
                base.AddParam(paras, "IN_StatusFlg", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_StatusFlg", (int)DeleteFlag.NotDelete);
            }
            return this.db.Find<VacationInfoDetail>(cmdText, paras);
        }

        #endregion

        #region UpdateStatus [Approve-Ignore]
        /// <summary>
        /// Approve
        /// </summary>
        /// <returns></returns>
        public int UpdateStatus(int vacationID, int updateUID, int applyStatus, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Vacation_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", vacationID);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="attached">T_Vacation</param>
        /// <returns></returns>
        public int Insert(T_Vacation app)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyStatus", app.ApplyStatus);
            base.AddParam(paras, "IN_VacationNo", app.VacationNo);
            base.AddParam(paras, "IN_PreVacationID", app.PreVacationID);            
            base.AddParam(paras, "IN_UserID", app.UserID);
            base.AddParam(paras, "IN_TypeApplyID", app.TypeApplyID);
            base.AddParam(paras, "IN_VacationDate", app.VacationDate);
            base.AddParam(paras, "IN_VacationStatus", app.VacationStatus);
            base.AddParam(paras, "IN_Reason", app.Reason);            
            base.AddParam(paras, "IN_CreateUID", app.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Vacation>();
            }
            return 0;
        }
        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="app">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Vacation app)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_TypeApplyID", app.TypeApplyID);
            base.AddParam(paras, "IN_UserID", app.UserID);
            base.AddParam(paras, "IN_VacationDate", app.VacationDate);
            base.AddParam(paras, "IN_VacationStatus", app.VacationStatus);

            base.AddParam(paras, "IN_Reason", app.Reason);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// UpdateStatusFlag
        /// ISV-TRUC
        /// 2015/03/05
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public int Confirm(T_Vacation app)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Confirm";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_Status", app.ApplyStatus);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
       
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(T_Vacation app)
        {
            //SQL String
            string cmdText = "P_T_Vacation_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", app.ID);
            base.AddParam(paras, "IN_DeleteFlag", app.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", app.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", app.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check

        /// <summary>
        /// CheckVacationHasCancel
        /// </summary>
        /// <param name="VacId"></param>
        /// <returns>true: exist cancel, false: not exist </returns>
        public bool CheckVacationHasCancel(int VacId)
        {
            //SQL String
            string cmdText = "P_T_Vacation_CheckVacationHasCancel";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_VacationID", VacId);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) != 0;//=0: not exist cancel, #0: exist cancel
        }
        #endregion
    }
}
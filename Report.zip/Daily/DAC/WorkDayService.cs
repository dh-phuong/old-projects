﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// TRAM - 2015/05/29
    /// WorkingDayService class
    /// </summary>
    public class WorkDayService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of WorkingDay service
        /// </summary>        
        private WorkDayService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of WorkingDay service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkDayService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get data by WorkDate
        /// </summary>
        /// <param name="WorkDate">WorkDate</param>
        /// <returns></returns>
        public IList<WorkDayInfo> GetListByWorkDate(DateTime startDate, DateTime endDate)
        {
            string cmdText = "P_M_Work_Day_GetListByWorkDate";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StartDate", startDate, true);
            base.AddParam(paras, "IN_EndDate", endDate, true);

            return this.db.FindList<WorkDayInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get data by WorkDate
        /// </summary>
        /// <param name="WorkDate">WorkDate</param>
        /// <returns></returns>
        public M_Work_Day GetByWorkDate(DateTime workDate)
        {
            string cmdText = "P_M_Work_Day_GetByWorkDate";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkDate", workDate, true);

            return this.db.Find<M_Work_Day>(cmdText, paras);
        }

        /// <summary>
        /// Get count by WorkingDay
        /// </summary>
        /// <param name="startDate">StartDate</param>
        /// <param name="endDate">EndDate</param>
        /// <returns></returns>

        public int GetCountByWorkDate(DateTime startDate, DateTime endDate)
        {
            string cmdText = "P_M_Work_Day_GetCountByWorkDate";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StartDate", startDate);
            base.AddParam(paras, "IN_EndDate", endDate);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="WorkDate">M_Work_Day</param>
        /// <returns></returns>
        public int Insert(M_Work_Day workingDay)
        {
            //SQL String
            string cmdText = "P_M_Work_Day_Insert";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_WorkDate", workingDay.WorkDate);
            base.AddParam(paras, "IN_ShiftID", workingDay.ShiftID);
            base.AddParam(paras, "IN_CreateUID", workingDay.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", workingDay.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="workingDay">M_Work_Day</param>
        /// <returns></returns>
        public int Update(M_Work_Day workingDay)
        {
            //SQL String
            string cmdText = "P_M_Work_Day_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ID", workingDay.ID);
            base.AddParam(paras, "IN_ShiftID", workingDay.ShiftID);
            base.AddParam(paras, "IN_UpdateDate", workingDay.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", workingDay.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// DepartmentService
    /// </summary>
    public class DepartmentService : BaseService
    {
        
        #region Constructor

        private DepartmentService()
            : base()
        {

        }

        public DepartmentService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get data

        /// <summary>
        /// Get by id
        /// </summary>
        /// <returns></returns>
        public M_Department GetByID(int id)
        {
            // Command text
            string cmdText = "P_M_Department_GetByID";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            return this.db.Find<M_Department>(cmdText, paras);
        }

        /// <summary>
        /// Get by DepartmentCd
        /// </summary>
        /// <returns></returns>
        public M_Department GetByCD(string departmentCd)
        {
            // Command text
            string cmdText = "P_M_Department_GetByCD";
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentCD", EditDataUtil.ToFixCodeDB(departmentCd,M_Department.DEPARTRMENT_CODE_MAX_LENGTH));
            return this.db.Find<M_Department>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="departmentCD"></param>
        /// <param name="departmentName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<DepartmentInfo> GetListByCond(string departmentCD, string departmentName,
                                                    int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Department_GetByCond";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_DepartmentCD", EditDataUtil.ToFixCodeDB(departmentCD,M_Department.DEPARTRMENT_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_DepartmentName", departmentName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<DepartmentInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="departmentCD"></param>
        /// <param name="departmentName"></param>
        /// <returns></returns>
        public int GetTotalRow(string departmentCD, string departmentName)
        {
            //SQL String
            string cmdText = "P_M_Department_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentCD", EditDataUtil.ToFixCodeDB(departmentCD,M_Department.DEPARTRMENT_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_DepartmentName", departmentName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Create  :TRAM
        /// Date    :2015/03/20
        /// Get Data For DropDownList
        /// </summary>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public IList<DropDownModel> GetDataForDropdown(bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Department_GetDataForDropdown";

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetListByConditionForSearch
        /// ISV-TRUC
        /// 2015/04/16
        /// </summary>
        /// <param name="deptCD"></param>
        /// <param name="deptNm"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<DepartmentSearchInfo> GetListByConditionForSearch(string deptCD, string deptNm, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Department_GetByConditionsForSearch";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeptCD", deptCD, true);
            base.AddParam(paras, "IN_DeptNm", deptNm, true);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<DepartmentSearchInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetCountByConditionForSearch
        /// ISV-TRUC
        /// 2015/04/16
        /// </summary>
        /// <param name="deptCD"></param>
        /// <param name="deptNm"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string deptCD, string deptNm)
        {
            //SQL String
            string cmdText = "P_M_Department_GetCountByConditionForSeach";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DeptCD", deptCD, true);
            base.AddParam(paras, "IN_DeptNm", deptNm, true);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data">M_Department</param>
        /// <returns></returns>
        public int Insert(M_Department data)
        {
            //SQL String
            string cmdText = "P_M_Department_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_DepartmentCD", EditDataUtil.ToFixCodeDB(data.DepartmentCD,M_Department.DEPARTRMENT_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_DepartmentName", data.DepartmentName);
            base.AddParam(paras, "IN_CreateUID", data.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="data">M_Department</param>
        /// <returns></returns>
        public int Update(M_Department data)
        {
            //SQL String
            string cmdText = "P_M_Department_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", data.ID);

            base.AddParam(paras, "IN_DepartmentCD", EditDataUtil.ToFixCodeDB(data.DepartmentCD, M_Department.DEPARTRMENT_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_DepartmentName", data.DepartmentName);
            
            base.AddParam(paras, "IN_UpdateDate", data.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", data.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="updateDate"></param>
        /// <returns></returns>
        public int Delete(int ID, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_M_Department_Delete";

            //Params
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", ID);
            base.AddParam(paras, "IN_UpdateDate", updateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

    }
}

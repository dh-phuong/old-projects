﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    public class RestTimeService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor
        /// </summary>
        private RestTimeService()
            : base()
        { }

        /// <summary>
        /// Contructor with BD
        /// </summary>
        /// <param name="db"></param>
        public RestTimeService(DB db)
            : base(db)
        { }

        #endregion

        #region Get

        /// <summary>
        /// Get by shiftID
        /// </summary>
        /// <param name="shiftID">ShiftID</param>
        /// <returns>M_RestTime model</returns>
        public M_RestTime GetByShiftID(int shiftID)
        {
            //command text
            string cmdText = "P_M_RestTime_GetByShiftID";

            //Parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ShiftID", shiftID);

            return this.db.Find<M_RestTime>(cmdText, prms);
        }

        public IList<RestTime> GetListByShiftID(int shiftID)
        {
            //command text
            string cmdText = "P_M_RestTime_GetListByShiftID";

            //Parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ShiftID", shiftID);

            return this.db.FindList<RestTime>(cmdText, prms);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="restTime">M_RestTime</param>
        /// <returns></returns>
        public int Insert(M_RestTime restTime)
        {
            //SQL String
            string cmdText = "P_M_RestTime_Insert";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ShiftID", restTime.ShiftID);

            base.AddParam(paras, "IN_RestTimeSH1", restTime.RestTimeSH1);
            base.AddParam(paras, "IN_RestTimeSM1", restTime.RestTimeSM1);
            base.AddParam(paras, "IN_RestTimeEH1", restTime.RestTimeEH1);
            base.AddParam(paras, "IN_RestTimeEM1", restTime.RestTimeEM1);

            base.AddParam(paras, "IN_RestTimeSH2", restTime.RestTimeSH2);
            base.AddParam(paras, "IN_RestTimeSM2", restTime.RestTimeSM2);
            base.AddParam(paras, "IN_RestTimeEH2", restTime.RestTimeEH2);
            base.AddParam(paras, "IN_RestTimeEM2", restTime.RestTimeEM2);

            base.AddParam(paras, "IN_RestTimeSH3", restTime.RestTimeSH3);
            base.AddParam(paras, "IN_RestTimeSM3", restTime.RestTimeSM3);
            base.AddParam(paras, "IN_RestTimeEH3", restTime.RestTimeEH3);
            base.AddParam(paras, "IN_RestTimeEM3", restTime.RestTimeEM3);

            base.AddParam(paras, "IN_RestTimeSH4", restTime.RestTimeSH4);
            base.AddParam(paras, "IN_RestTimeSM4", restTime.RestTimeSM4);
            base.AddParam(paras, "IN_RestTimeEH4", restTime.RestTimeEH4);
            base.AddParam(paras, "IN_RestTimeEM4", restTime.RestTimeEM4);

            base.AddParam(paras, "IN_RestTimeSH5", restTime.RestTimeSH5);
            base.AddParam(paras, "IN_RestTimeSM5", restTime.RestTimeSM5);
            base.AddParam(paras, "IN_RestTimeEH5", restTime.RestTimeEH5);
            base.AddParam(paras, "IN_RestTimeEM5", restTime.RestTimeEM5);

            base.AddParam(paras, "IN_RestTimeSH6", restTime.RestTimeSH6);
            base.AddParam(paras, "IN_RestTimeSM6", restTime.RestTimeSM6);
            base.AddParam(paras, "IN_RestTimeEH6", restTime.RestTimeEH6);
            base.AddParam(paras, "IN_RestTimeEM6", restTime.RestTimeEM6);

            base.AddParam(paras, "IN_CreateUID", restTime.CreateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="restTime">restTime</param>
        /// <returns></returns>
        public int Update(M_RestTime restTime)
        {
            //SQL String
            string cmdText = "P_M_RestTime_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_ShiftID", restTime.ShiftID);

            base.AddParam(paras, "IN_RestTimeSH1", restTime.RestTimeSH1);
            base.AddParam(paras, "IN_RestTimeSM1", restTime.RestTimeSM1);
            base.AddParam(paras, "IN_RestTimeEH1", restTime.RestTimeEH1);
            base.AddParam(paras, "IN_RestTimeEM1", restTime.RestTimeEM1);

            base.AddParam(paras, "IN_RestTimeSH2", restTime.RestTimeSH2);
            base.AddParam(paras, "IN_RestTimeSM2", restTime.RestTimeSM2);
            base.AddParam(paras, "IN_RestTimeEH2", restTime.RestTimeEH2);
            base.AddParam(paras, "IN_RestTimeEM2", restTime.RestTimeEM2);

            base.AddParam(paras, "IN_RestTimeSH3", restTime.RestTimeSH3);
            base.AddParam(paras, "IN_RestTimeSM3", restTime.RestTimeSM3);
            base.AddParam(paras, "IN_RestTimeEH3", restTime.RestTimeEH3);
            base.AddParam(paras, "IN_RestTimeEM3", restTime.RestTimeEM3);

            base.AddParam(paras, "IN_RestTimeSH4", restTime.RestTimeSH4);
            base.AddParam(paras, "IN_RestTimeSM4", restTime.RestTimeSM4);
            base.AddParam(paras, "IN_RestTimeEH4", restTime.RestTimeEH4);
            base.AddParam(paras, "IN_RestTimeEM4", restTime.RestTimeEM4);

            base.AddParam(paras, "IN_RestTimeSH5", restTime.RestTimeSH5);
            base.AddParam(paras, "IN_RestTimeSM5", restTime.RestTimeSM5);
            base.AddParam(paras, "IN_RestTimeEH5", restTime.RestTimeEH5);
            base.AddParam(paras, "IN_RestTimeEM5", restTime.RestTimeEM5);

            base.AddParam(paras, "IN_RestTimeSH6", restTime.RestTimeSH6);
            base.AddParam(paras, "IN_RestTimeSM6", restTime.RestTimeSM6);
            base.AddParam(paras, "IN_RestTimeEH6", restTime.RestTimeEH6);
            base.AddParam(paras, "IN_RestTimeEM6", restTime.RestTimeEM6);

            base.AddParam(paras, "IN_UpdateDate", restTime.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", restTime.UpdateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Method

        #endregion
    }
}

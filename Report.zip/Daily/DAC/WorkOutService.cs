﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;

namespace DailyReport.DAC
{
    public class WorkOutService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Work out service
        /// </summary>        
        private WorkOutService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Work out service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkOutService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        /// <summary>
        /// Get list outing info by work id
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public IList<DailyOutingInfo> GetListOutingByWorkID(int workID)
        {
            //comand text
            string cmdText = "P_T_Work_Out_GetListByWorkID";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_WorkID", workID);

            return db.FindList<DailyOutingInfo>(cmdText, prms);
        }

        /// <summary>
        /// Get list outing by work id
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public IList<T_Work_Out> GetListByWorkID(int workID)
        {
            //comand text
            string cmdText = "P_T_Work_Out_GetListByWorkID";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_WorkID", workID);

            return db.FindList<T_Work_Out>(cmdText, prms);
        }

        #endregion

        #region Insert
        
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="workOut"></param>
        /// <returns></returns>
        public int Insert(T_Work_Out workOut)
        {
            //SQL String
            string cmdText = "P_T_Work_Out_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkID", workOut.WorkID);
            base.AddParam(paras, "IN_StartHour", workOut.StartHour);
            base.AddParam(paras, "IN_StartMinute", workOut.StartMinute);
            base.AddParam(paras, "IN_EndHour", workOut.EndHour);
            base.AddParam(paras, "IN_EndMinute", workOut.EndMinute);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public int Delete(int workID)
        {
            //SQL String
            string cmdText = "P_T_Work_Out_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_WorkID", workID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using System.Data.Common;

namespace DailyReport.DAC
{
    public class StaffDependentService : BaseService
    {
        #region Contructor

        private StaffDependentService()
            : base()
        { 
        }

        public StaffDependentService(DB db)
            : base(db)
        {
        }

        #endregion

        #region GetData

        /// <summary>
        /// Get by UserID
        /// </summary>
        /// <returns>M_User</returns>
        public IList<M_Staff_Dependent> GetByStaffID(int staffID)
        {
            //SQL String
            string cmdText = "P_M_StaffDependent_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.FindList<M_Staff_Dependent>(cmdText, paras);
        }

        #endregion

        #region Insert

        public int Insert(M_Staff_Dependent dependent)
        {
            //SQL String
            string cmdText = "P_M_StaffDependent_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", dependent.StaffID);
            base.AddParam(paras, "IN_RegistDate", dependent.RegistDate);
            base.AddParam(paras, "IN_Dependent", dependent.Dependent);
            base.AddParam(paras, "IN_Total", dependent.Total);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Delete(int staffID)
        {
            //SQL String
            string cmdText = "P_M_StaffDependent_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

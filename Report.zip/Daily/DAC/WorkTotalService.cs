﻿using System;
using System.Collections.Generic;
using System.Collections;

using DailyReport.Models;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class WorkTotalService
    /// </summary>
    public class WorkTotalService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private WorkTotalService()
            : base()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public WorkTotalService(DB db)
            : base(db)
        {
        }
        #endregion

        #region Get Data
        /// <summary>
        /// Get data by condition
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="EffectDateFrom"></param>
        /// <param name="EffectDateTo"></param>
        /// <returns></returns>
        public IList<T_Work_Total> GetByCond(int userID, DateTime EffectDateFrom, DateTime EffectDateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_Total_GetListGetByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_EffectDateFrom", EffectDateFrom);
            base.AddParam(paras, "IN_EffectDateTo", EffectDateTo);

            return this.db.FindList<T_Work_Total>(cmdText, paras);
        }

        /// <summary>
        /// Get by key
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="MonthWork"></param>
        /// <returns></returns>
        public WorkTotalInfo GetByKey(int staffID, DateTime MonthWork)
        {
            //SQL String
            string cmdText = "P_T_Work_Total_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_MonthWork", MonthWork);

            return this.db.Find<WorkTotalInfo>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="vac"></param>
        /// <returns></returns>
        public int Insert(T_Work_Total vac)
        {
            //SQL String
            string cmdText = "P_T_Work_Total_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", vac.UserID);
            base.AddParam(paras, "IN_MonthWork", vac.MonthWork);
            base.AddParam(paras, "IN_DateFrom", vac.DateFrom);
            base.AddParam(paras, "IN_DateTo", vac.DateTo);
            base.AddParam(paras, "IN_TimeWorkHour", vac.TimeWorkHour);
            base.AddParam(paras, "IN_TimeWorkMinute", vac.TimeWorkMinute);
            base.AddParam(paras, "IN_TimeLateHour", vac.TimeLateHour);
            base.AddParam(paras, "IN_TimeLateMinute", vac.TimeLateMinute);
            base.AddParam(paras, "IN_TimeEarlyHour", vac.TimeEarlyHour);
            base.AddParam(paras, "IN_TimeEarlyMinute", vac.TimeEarlyMinute);
            base.AddParam(paras, "IN_TimeOutHour", vac.TimeOutHour);
            base.AddParam(paras, "IN_TimeOutMinute", vac.TimeOutMinute);
            base.AddParam(paras, "IN_VacationLeaves", vac.VacationLeaves);
            base.AddParam(paras, "IN_AbsenceLeaves", vac.AbsenceLeaves);
            base.AddParam(paras, "IN_OTEarlyHour", vac.OTEarlyHour);
            base.AddParam(paras, "IN_OTEarlyMinute", vac.OTEarlyMinute);
            base.AddParam(paras, "IN_OTNormal1Hour", vac.OTNormal1Hour);
            base.AddParam(paras, "IN_OTNormal1Minute", vac.OTNormal1Minute);
            base.AddParam(paras, "IN_OTNormal2Hour", vac.OTNormal2Hour);
            base.AddParam(paras, "IN_OTNormal2Minute", vac.OTNormal2Minute);
            base.AddParam(paras, "IN_OTLateHour", vac.OTLateHour);
            base.AddParam(paras, "IN_OTLateMinute", vac.OTLateMinute);
            base.AddParam(paras, "IN_OTHoliday1Hour", vac.OTHoliday1Hour);
            base.AddParam(paras, "IN_OTHoliday1Minute", vac.OTHoliday1Minute);
            base.AddParam(paras, "IN_OTHoliday2Hour", vac.OTHoliday2Hour);
            base.AddParam(paras, "IN_OTHoliday2Minute", vac.OTHoliday2Minute);
            base.AddParam(paras, "IN_TotalOTHour", vac.TotalOTHour);
            base.AddParam(paras, "IN_TotalOTMinute", vac.TotalOTMinute);
            base.AddParam(paras, "IN_TotalWorkHour", vac.TotalWorkHour);
            base.AddParam(paras, "IN_TotalWorkMinute", vac.TotalWorkMinute);
            base.AddParam(paras, "IN_CreateUID", vac.CreateUID);


            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Work_Vacation>();
            }
            return 0;
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="UserID"></param>
        /// <param name="MonthWork"></param>
        /// <returns></returns>
        public int Delete(int UserID, DateTime MonthWork)
        {
            //SQL string
            string cmdText = "P_T_Work_Total_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", UserID);
            base.AddParam(paras, "IN_MonthWork", MonthWork);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
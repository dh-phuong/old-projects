﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;


namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_User DAC
    /// </summary>
    public class Route_HService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of User service
        /// </summary>        
        private Route_HService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of User service
        /// </summary>
        /// <param name="db">Class DB</param>
        public Route_HService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        public IList<DropDownModel> GetDataForDropdown(int formId, int userId, bool withBlank = false)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetDataForDropdown";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_FormID", formId);
            base.AddParam(paras, "IN_UserID", userId);

            IList<DropDownModel> ret = this.db.FindList<DropDownModel>(cmdText, paras);

            if (withBlank)
            {
                ret.Insert(0, new DropDownModel("-1", "---"));
            }

            return ret;
        }

        /// <summary>
        /// GetListByCond
        /// ISV-Nho
        /// </summary>
        /// <param name="userName1"></param>
        /// <param name="userName2"></param>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="inValid"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<RouteInfo> GetListByCond(string routeCD, string routeName, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetByCond";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_RouteCD", routeCD);
            base.AddParam(paras, "IN_RouteName", routeName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<RouteInfo>(cmdText, paras);
        }

        /// <summary>
        /// Get by user ID
        /// ISV-TRUC
        /// </summary>
        /// <param name="userID">userID</param>
        /// <returns></returns>
        public M_Route_H GetByID(int RouteID)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", RouteID);

            return this.db.Find<M_Route_H>(cmdText, paras);
        }

        /// <summary>
        /// getTotalRow
        /// ISV-TRUC
        /// </summary>
        /// <param name="userName1"></param>
        /// <param name="userName2"></param>
        /// <param name="groupCD"></param>
        /// <param name="groupName"></param>
        /// <param name="inValid"></param>
        /// <returns></returns>
        public int getTotalRow(string routeCD, string routeName)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetTotalRow";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteCD", routeCD);
            base.AddParam(paras, "IN_RouteName", routeName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// GetByRouteCD
        /// </summary>
        /// <param name="RouteCD">RouteCD</param>
        /// <returns></returns>
        public M_Route_H GetByRouteCD(string RouteCD)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetByRouteCD";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteCD", RouteCD);

            return this.db.Find<M_Route_H>(cmdText, paras);
        }

        /// <summary>
        /// GetListByConditionForSearch
        /// ISV-TRUC
        /// 2015/03/13
        /// </summary>
        /// <param name="routeCD"></param>
        /// <param name="routeName"></param>
        /// <param name="pageIndex"></param>
        /// <param name="pageSize"></param>
        /// <param name="sortField"></param>
        /// <param name="sortDirec"></param>
        /// <returns></returns>
        public IList<RouteInfo> GetListByConditionForSearch(string routeCD, string routeName, int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetByCondForSearch";

            //Para
            Hashtable paras = new Hashtable();

            base.AddParam(paras, "IN_RouteCD", EditDataUtil.ToFixCodeDB(routeCD, M_Route_H.ROUTE_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_RouteName", routeName);
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<RouteInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetCountByConditionForSearch
        /// ISV-TRUC
        /// 2015/03/13
        /// </summary>
        /// <param name="routeCD"></param>
        /// <param name="routeName"></param>
        /// <returns></returns>
        public int GetCountByConditionForSearch(string routeCD, string routeName)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetTotalRowForSearch";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteCD", EditDataUtil.ToFixCodeDB(routeCD, M_Route_H.ROUTE_CODE_MAX_LENGTH));
            base.AddParam(paras, "IN_RouteName", routeName);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get list
        /// ISV-TRUC
        /// 2015/04/24
        /// </summary>
        /// <returns></returns>
        public IList<RouteModel> GetList()
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetList";

            //Para
            Hashtable paras = new Hashtable();
            return this.db.FindList<RouteModel>(cmdText, paras);
        }

        /// <summary>
        /// 2015/06/10
        /// ISV-TRUC
        /// GetByTypeAndUserIDForWork
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public M_Route_H GetByTypeAndUserIDForWork(int formID, int userID)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetByTypeAndUserIDForWork";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_FormID", formID);

            return this.db.Find<M_Route_H>(cmdText, paras);
        }


        /// <summary>
        /// GetListByFormID
        /// ISV-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<M_Route_H> GetListByFormID(int formID)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetListByFormID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            return this.db.FindList<M_Route_H>(cmdText, paras);
        }

        /// <summary>
        /// GetListRouteBy2UserCD
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="userCD1"></param>
        /// <param name="userCD2"></param>
        /// <returns></returns>
        public IList<M_Route_H> GetListRouteBy2UserCD(int formID, string userCD1, string userCD2)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetListRouteBy2UserCD";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormVacation", formID);
            base.AddParam(paras, "IN_UserCD1", userCD1);
            base.AddParam(paras, "IN_UserCD2", userCD2);
            return this.db.FindList<M_Route_H>(cmdText, paras);
        }


        /// <summary>
        /// GetListRouteBy2UserID
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="userID1"></param>
        /// <param name="userID2"></param>
        /// <returns></returns>
        public IList<M_Route_H> GetListRouteBy2UserID(int formID, int userID1, int userID2)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetListRouteBy2UserID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormVacation", formID);
            base.AddParam(paras, "IN_UserID1", userID1);
            base.AddParam(paras, "IN_UserID2", userID2);
            return this.db.FindList<M_Route_H>(cmdText, paras);
        }

        /// <summary>
        /// GetListByFormID has sort fields
        /// ISV-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<RouteFormInfo> GetListByFormIDHasSort(int formID, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetListByFormIDHasSort";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<RouteFormInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetListOtherByFormID(not insert into m_form_route)
        /// ISv-TRUC
        /// 2015/04/27
        /// </summary>
        /// <param name="formID"></param>
        /// <returns></returns>
        public IList<RouteModel> GetListOtherByFormID(int formID)
        {
            //SQL String
            string cmdText = "P_M_Route_H_GetListRouteOtherByFormID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            return this.db.FindList<RouteModel>(cmdText, paras);
        }

        /// <summary>
        /// GetListByFormIDAndUserID
        /// ISV-TRUC
        /// 2015/06/04
        /// </summary>
        /// <param name="formID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public IList<M_Route_H> GetListByFormIDAndUserID(int formID, int userID)
        {
            //SQL String
            string cmdText = "P_M_Form_Route_GetListByFormIDUserID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_FormID", formID);
            base.AddParam(paras, "IN_UserID", userID);

            return this.db.FindList<M_Route_H>(cmdText, paras);
        }


        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Insert(M_Route_H Route)
        {
            //SQL String
            string cmdText = "P_M_Route_H_Insert";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteCD", Route.RouteCD);
            base.AddParam(paras, "IN_RouteName", Route.RouteName);
            base.AddParam(paras, "IN_CreateUID", Route.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int Update(M_Route_H route)
        {
            //SQL String
            string cmdText = "P_M_Route_H_Update";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", route.ID);
            base.AddParam(paras, "IN_RouteCD", route.RouteCD);
            base.AddParam(paras, "IN_RouteName", route.RouteName);
            base.AddParam(paras, "IN_UpdateDate", route.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", route.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="route"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(M_Route_H route)
        {
            //SQL String
            string cmdText = "P_M_Route_H_UpdateStatusFlag";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", route.ID);
            base.AddParam(paras, "IN_StatusFlag", route.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", route.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", route.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="user">M_User</param>
        /// <returns></returns>
        public int DeleteRoute(int routeID)
        {
            //SQL String
            string cmdText = "P_M_Route_H_DeleteRoute";

            ISecurity sec = Security.Instance;

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", routeID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Check

        public bool IsExist(string routeCd)
        {
            return this.GetByRouteCD(routeCd) != null;
        }

        #endregion
    }
}

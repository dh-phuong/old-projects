﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    public class WorkOTService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Holiday service
        /// </summary>        
        private WorkOTService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Holiday service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkOTService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/06/08
        /// Get Data By Day
        /// </summary>
        /// <param name="configCd"></param>
        /// <param name="withBlank"></param>
        /// <returns></returns>
        public M_Work_Shift GetWorkingShiftByDate(DateTime date)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_GetWorkingShiftByDay";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Date", date);

            return this.db.Find<M_Work_Shift>(cmdText, paras);
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/06/10
        /// GetByPreApplyID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_OT GetByPreApplyID(int id)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_GetByPreApplyID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_PreApplyID", id);

            return this.db.Find<T_Work_OT>(cmdText, paras);
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/06/10
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_OT GetByID(int id, bool isIncludeDelete = false)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", id);
            base.AddParam(paras, "IN_IncludeDelete", isIncludeDelete ? 1 : 0);

            return this.db.Find<T_Work_OT>(cmdText, paras);
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/06/10
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public WorkTotalOTInfo GetTotalOverTime(DateTime startday, DateTime endday, int userID)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_GetTotalOverTime";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StartDay", startday);
            base.AddParam(paras, "IN_EndDay", endday);
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_ApproveStatus", (short)StatusApply.Approved);

            return this.db.Find<WorkTotalOTInfo>(cmdText, paras);
        }

        /// <summary>
        /// Create  :ISV-NHAT
        /// Date    :2015/06/10
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Apply</returns>
        public T_Work_OT GetByNo(string no)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_GetByNo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", no);

            return this.db.Find<T_Work_OT>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="user">T_Work_OT</param>
        /// <returns></returns>
        public int Insert(T_Work_OT wOT)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", wOT.No);
            base.AddParam(paras, "IN_PreApplyID", wOT.PreApplyID);
            base.AddParam(paras, "IN_ApplyStatus", wOT.ApplyStatus);
            base.AddParam(paras, "IN_ApplyDate", wOT.ApplyDate);
            base.AddParam(paras, "IN_UserID", wOT.UserID);
            base.AddParam(paras, "IN_EffectDate", wOT.EffectDate);
            base.AddParam(paras, "IN_ShiftID", wOT.ShiftID);
            base.AddParam(paras, "IN_ShiftName", wOT.ShiftName);
            base.AddParam(paras, "IN_StartHour", wOT.StartHour);
            base.AddParam(paras, "IN_StartMinute", wOT.StartMinute);
            base.AddParam(paras, "IN_EndHour", wOT.EndHour);
            base.AddParam(paras, "IN_EndMinute", wOT.EndMinute);
            base.AddParam(paras, "IN_OTStartHour", wOT.OTStartHour);
            base.AddParam(paras, "IN_OTStartMinute", wOT.OTStartMinute);
            base.AddParam(paras, "IN_OTEndHour", wOT.OTEndHour);
            base.AddParam(paras, "IN_OTEndMinute", wOT.OTEndMinute);
            base.AddParam(paras, "IN_EarlyHour", wOT.EarlyHour);
            base.AddParam(paras, "IN_EarlyMinute", wOT.EarlyMinute);
            base.AddParam(paras, "IN_Normal1Hour", wOT.Normal1Hour);
            base.AddParam(paras, "IN_Normal1Minute", wOT.Normal1Minute);
            base.AddParam(paras, "IN_Normal2Hour", wOT.Normal2Hour);
            base.AddParam(paras, "IN_Normal2Minute", wOT.Normal2Minute);
            base.AddParam(paras, "IN_LateHour", wOT.LateHour);
            base.AddParam(paras, "IN_LateMinute", wOT.LateMinute);
            base.AddParam(paras, "IN_Holiday1Hour", wOT.Holiday1Hour);
            base.AddParam(paras, "IN_Holiday1Minute", wOT.Holiday1Minute);
            base.AddParam(paras, "IN_Holiday2Hour", wOT.Holiday2Hour);
            base.AddParam(paras, "IN_Holiday2Minute", wOT.Holiday2Minute);
            base.AddParam(paras, "IN_Reason", wOT.Reason);
            base.AddParam(paras, "IN_RouteID", wOT.RouteID);
            base.AddParam(paras, "IN_ApprovedLevel", wOT.ApprovedLevel);
            base.AddParam(paras, "IN_StatusFlag", wOT.StatusFlag);
            base.AddParam(paras, "IN_CreateUID", wOT.CreateUID);
            base.AddParam(paras, "IN_UpdateUID", wOT.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="user">T_Work_OT</param>
        /// <returns></returns>
        public int Update(T_Work_OT wOT)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", wOT.ID);
            base.AddParam(paras, "IN_NO", wOT.No);
            base.AddParam(paras, "IN_UserID", wOT.UserID);
            base.AddParam(paras, "IN_EffectDate", wOT.EffectDate);
            base.AddParam(paras, "IN_ShiftID", wOT.ShiftID);
            base.AddParam(paras, "IN_ShiftName", wOT.ShiftName);
            base.AddParam(paras, "IN_StartHour", wOT.StartHour);
            base.AddParam(paras, "IN_StartMinute", wOT.StartMinute);
            base.AddParam(paras, "IN_EndHour", wOT.EndHour);
            base.AddParam(paras, "IN_EndMinute", wOT.EndMinute);
            base.AddParam(paras, "IN_OTStartHour", wOT.OTStartHour);
            base.AddParam(paras, "IN_OTStartMinute", wOT.OTStartMinute);
            base.AddParam(paras, "IN_OTEndHour", wOT.OTEndHour);
            base.AddParam(paras, "IN_OTEndMinute", wOT.OTEndMinute);
            base.AddParam(paras, "IN_EarlyHour", wOT.EarlyHour);
            base.AddParam(paras, "IN_EarlyMinute", wOT.EarlyMinute);
            base.AddParam(paras, "IN_Normal1Hour", wOT.Normal1Hour);
            base.AddParam(paras, "IN_Normal1Minute", wOT.Normal1Minute);
            base.AddParam(paras, "IN_Normal2Hour", wOT.Normal2Hour);
            base.AddParam(paras, "IN_Normal2Minute", wOT.Normal2Minute);
            base.AddParam(paras, "IN_LateHour", wOT.LateHour);
            base.AddParam(paras, "IN_LateMinute", wOT.LateMinute);
            base.AddParam(paras, "IN_Holiday1Hour", wOT.Holiday1Hour);
            base.AddParam(paras, "IN_Holiday1Minute", wOT.Holiday1Minute);
            base.AddParam(paras, "IN_Holiday2Hour", wOT.Holiday2Hour);
            base.AddParam(paras, "IN_Holiday2Minute", wOT.Holiday2Minute);
            base.AddParam(paras, "IN_Reason", wOT.Reason);
            base.AddParam(paras, "IN_RouteID", wOT.RouteID);
            base.AddParam(paras, "IN_UpdateDate", wOT.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", wOT.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update ApplyStatus
        /// ISV-NHAT
        /// 2015/06/15
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateApplyStatus(int applyID, int updateUID, short applyStatus, int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_UpdateApplyStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        /// <summary>
        /// Update StatusFlag
        /// ISV-TRUC
        /// 2015/06/08
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateStatusFlag(T_Work_OT w)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_Update_StatusFlag";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", w.ID);
            base.AddParam(paras, "IN_StatusFlag", w.StatusFlag);
            base.AddParam(paras, "IN_UpdateDate", w.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", w.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        public int Delete(int wID)
        {
            //SQL String
            string cmdText = "P_T_Work_OT_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", wID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

    }
}

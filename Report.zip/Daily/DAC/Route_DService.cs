﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// Class M_Route_D Service
    /// </summary>
    public class Route_DService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor Route_DService Service
        /// </summary>
        private Route_DService()
            : base()
        {
        }

        /// <summary>
        /// Contructor Route_DService Service
        /// </summary>
        /// <param name="db"></param>
        public Route_DService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get Data

        /// <summary>
        /// Get List By RouteCD
        /// </summary>
        /// <param name="RouteCD"></param>
        /// <returns></returns>
        public IList<M_Route_D> GetListByRouteCD(string RouteCD)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetListByRouteCD";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteCD", RouteCD);

            return this.db.FindList<M_Route_D>(cmdText, paras);
        }

        /// <summary>
        /// Get by header id and user id
        /// </summary>
        /// <param name="hid">header id</param>
        /// <param name="userID">user id</param>
        /// <returns></returns>
        public M_Route_D GetByHidAndUserID(int hid, int userID)
        {
            //command text
            string cmdText = "P_M_Route_D_GetByHidAndUserID";
            
            //add parameters
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_HID", hid);
            base.AddParam(prms, "IN_UserID", userID);

            return this.db.Find<M_Route_D>(cmdText, prms);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/09
        /// GetByRouteIDForWork
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="isGetViewLevel"></param>
        /// <param name="isGetLVZero"></param>
        /// <returns></returns>
        public IList<M_Route_D> GetByRouteIDForWork(int routeID, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        {
            //command text
            string cmdText = "P_M_Route_D_GetByRouteIDForWork";

            //add parameters
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteID", routeID);
            if (isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }

            if (isGetLVZero == EnumGetLevelZero.Only)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
            }
            else if (isGetLVZero == EnumGetLevelZero.Exclude)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
            }
            else if (isGetLVZero == EnumGetLevelZero.Include)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
            }
            base.AddParam(paras, "IN_ZeroLV", M_Route_H.LEVEL_APPLICANT);

            return this.db.FindList<M_Route_D>(cmdText, paras);
        }

        /// <summary>
        /// Get list by header ID
        /// </summary>
        /// <param name="headerID">HeaderID</param>
        /// <returns></returns>
        public IList<M_Route_D> GetByListByHeaderID(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetByListByHeaderID";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.FindList<M_Route_D>(cmdText, paras);
        }

        public IList<RouteDetailListInfo> GetListDetailInfo(int headerID, int level)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetListDetailInfo";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);
            if (level == -1)
            {
                base.AddParam(paras, "IN_RouteLevel", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_RouteLevel", level);
            }
            return this.db.FindList<RouteDetailListInfo>(cmdText, paras);
        }


        /// <summary>
        /// GetVacationListByVacation
        /// 2015/03/25
        /// ISV-TRUC
        /// </summary>
        /// <param name="type"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public int GetLevelByVacationUserID(int type, int userID)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetLevelByUser_Type";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Type", type);
            base.AddParam(paras, "IN_UserID", userID);
            var ret = this.db.ExecuteScalar(cmdText, paras);
            if (ret == null)
            {
                return 0;
            }
            else
            {
                return int.Parse(ret.ToString());
            }
        }

        ///// <summary>
        ///// GetApproverListByTypeAndUserIDForWork
        ///// ISV-TRUC
        ///// 2015/06/08
        ///// </summary>
        ///// <param name="userID"></param>
        ///// <param name="isGetViewLevel"></param>
        ///// <param name="isGetLVZero"></param>
        ///// <returns></returns>
        //public IList<WorkApproveModel> GetApproverListByTypeAndUserIDForWork(int userID, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        //{
        //    //SQL String
        //    string cmdText = "P_M_Route_D_GetApproverListByTypeAndUserIDForWork";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_UserID", userID);
        //    base.AddParam(paras, "IN_FormID", M_Config_D.TEMPLATE_FORM_APPLY_LEAVE);
        //    if (isGetViewLevel)
        //    {
        //        base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
        //    }
        //    else
        //    {
        //        base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
        //    }

        //    if (isGetLVZero == EnumGetLevelZero.Only)
        //    {
        //        base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
        //    }
        //    else if (isGetLVZero == EnumGetLevelZero.Exclude)
        //    {
        //        base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
        //    }
        //    else if (isGetLVZero == EnumGetLevelZero.Include)
        //    {
        //        base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
        //    }
        //    base.AddParam(paras, "IN_ZeroLV", M_Route_H.LEVEL_APPLICANT);
        //    return this.db.FindList<WorkApproveModel>(cmdText, paras);
        //}

        /// <summary>
        /// GetApproverListByRouteIDForWork
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="userID"></param>
        /// <param name="isGetViewLevel"></param>
        /// <param name="isGetLVZero"></param>
        /// <returns></returns>
        public IList<WorkApproveModel> GetApproverListByRouteIDForWork(int routeID, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        {
            //SQL String
            string cmdText = "P_M_Route_D_GetApproverListByRouteIDForWork";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteID", routeID);
            
            if (!isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }

            if (isGetLVZero == EnumGetLevelZero.Only)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
            }
            else if (isGetLVZero == EnumGetLevelZero.Exclude)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
            }
            else if (isGetLVZero == EnumGetLevelZero.Include)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
            }
            base.AddParam(paras, "IN_ZeroLV", M_Route_H.LEVEL_APPLICANT);
            return this.db.FindList<WorkApproveModel>(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert data
        /// </summary>
        /// <param name="detailItem">M_Config_D</param>
        /// <returns></returns>
        public int Insert(M_Route_D detailItem)
        {
            //SQL String
            string cmdText = "P_M_Route_D_Insert";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", detailItem.HID);
            base.AddParam(paras, "IN_UserID", detailItem.UserID);
            base.AddParam(paras, "IN_RouteLevel", detailItem.RouteLevel);
            base.AddParam(paras, "IN_ProxyApprovalUser", detailItem.ProxyApprovalUser);

            base.AddParam(paras, "IN_RouteMethod", detailItem.RouteMethod);
            base.AddParam(paras, "IN_RequireNum", detailItem.RequireNum);

            base.AddParam(paras, "IN_ApplyFlag1", detailItem.ApplyFlag1);
            base.AddParam(paras, "IN_ApplyFlag2", detailItem.ApplyFlag2);
            base.AddParam(paras, "IN_ApplyFlag3", detailItem.ApplyFlag3);
            base.AddParam(paras, "IN_ApplyFlag4", detailItem.ApplyFlag4);

            base.AddParam(paras, "IN_RejectFlag1", detailItem.RejectFlag1);
            base.AddParam(paras, "IN_RejectFlag2", detailItem.RejectFlag2);
            base.AddParam(paras, "IN_RejectFlag3", detailItem.RejectFlag3);
            base.AddParam(paras, "IN_RejectFlag4", detailItem.RejectFlag4);
            base.AddParam(paras, "IN_RejectFlag5", detailItem.RejectFlag5);
            base.AddParam(paras, "IN_RejectFlag6", detailItem.RejectFlag6);
            base.AddParam(paras, "IN_RejectFlag7", detailItem.RejectFlag7);

            base.AddParam(paras, "IN_RemandFlag1", detailItem.RemandFlag1);
            base.AddParam(paras, "IN_RemandFlag2", detailItem.RemandFlag2);
            base.AddParam(paras, "IN_RemandFlag3", detailItem.RemandFlag3);
            base.AddParam(paras, "IN_RemandFlag4", detailItem.RemandFlag4);
            base.AddParam(paras, "IN_RemandFlag5", detailItem.RemandFlag5);
            base.AddParam(paras, "IN_RemandFlag6", detailItem.RemandFlag6);
            base.AddParam(paras, "IN_RemandFlag7", detailItem.RemandFlag7);

            base.AddParam(paras, "IN_ApproveFlag1", detailItem.ApproveFlag1);
            base.AddParam(paras, "IN_ApproveFlag2", detailItem.ApproveFlag2);
            base.AddParam(paras, "IN_ApproveFlag3", detailItem.ApproveFlag3);
            base.AddParam(paras, "IN_ApproveFlag4", detailItem.ApproveFlag4);
            base.AddParam(paras, "IN_ApproveFlag5", detailItem.ApproveFlag5);
            base.AddParam(paras, "IN_ApproveFlag6", detailItem.ApproveFlag6);
            base.AddParam(paras, "IN_ApproveFlag7", detailItem.ApproveFlag7);
            base.AddParam(paras, "IN_ApproveFlag8", detailItem.ApproveFlag8);
            base.AddParam(paras, "IN_ApproveFlag9", detailItem.ApproveFlag9);

            base.AddParam(paras, "IN_ReadFlag1", detailItem.ReadFlag1);
            base.AddParam(paras, "IN_ReadFlag2", detailItem.ReadFlag2);
            base.AddParam(paras, "IN_ReadFlag3", detailItem.ReadFlag3);
            base.AddParam(paras, "IN_ReadFlag4", detailItem.ReadFlag4);
            base.AddParam(paras, "IN_ReadFlag5", detailItem.ReadFlag5);            

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete by headerID
        /// </summary>
        /// <param name="headerID">Header ID</param>
        /// <returns></returns>
        public int Delete(int headerID)
        {
            //SQL String
            string cmdText = "P_M_Route_D_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_HID", headerID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}

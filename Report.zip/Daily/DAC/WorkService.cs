﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DailyReport.Models;
using System.Collections;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// Work Service
    /// </summary>
    public class WorkService : BaseService
    {
        #region Contructor
        /// <summary>
        /// Contructor of Holiday service
        /// </summary>        
        private WorkService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Holiday service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get data        

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public IList<WorkInfo> GetListByCond(int staffID, DateTime dateForm, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_GetListByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);

            return this.db.FindList<WorkInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCondForExcel
        /// </summary>
        /// <param name="staffID">staffID</param>
        /// <param name="dateForm">dateForm</param>
        /// <param name="dateTo">dateTo</param>
        /// <returns></returns>
        public IList<EmployeeDetailInMonthList> GetListByCondForEmployeeDetailInMonth(int staffID, DateTime dateForm, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_GetListByCondForEmployeeDetailInMonth";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);

            return this.db.FindList<EmployeeDetailInMonthList>(cmdText, paras);
        }
        
        /// <summary>
        /// GetListByCondForListEmployeeInMonthExcel
        /// </summary>
        /// <param name="staffID">staffID</param>
        /// <param name="dateForm">dateForm</param>
        /// <param name="dateTo">dateTo</param>
        /// <returns></returns>
        public IList<ListEmployeeInMonthExcelList> GetListByCondForListEmployeeInMonthExcel(int Month, int Year)
        {
            //SQL String
            string cmdText = "P_T_Work_GetListEmployeeInMonth";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Month", Month);
            base.AddParam(paras, "IN_Year", Year);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);

            return this.db.FindList<ListEmployeeInMonthExcelList>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCondForListEmployeeInYearExcel
        /// </summary>
        /// <param name="staffID">staffID</param>
        /// <param name="dateForm">dateForm</param>
        /// <param name="dateTo">dateTo</param>
        /// <returns></returns>
        public IList<ListEmployeeInYearExcelList> GetListByCondForListEmployeeInYearExcel(int Year)
        {
            //SQL String
            string cmdText = "P_T_Work_GetListEmployeeInYear";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_Year", Year);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);

            return this.db.FindList<ListEmployeeInYearExcelList>(cmdText, paras);
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public WorkTotalInfo GetTotalByCond(int staffID, DateTime dateForm, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_GetTotalByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);

            return this.db.Find<WorkTotalInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public IList<WorkAppliedList> GetAppliedList(int userID, DateTime workDate)
        {
            //SQL String
            string cmdText = "P_T_Work_GetAppliedList";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_WorkDate", workDate);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);             //Day Off
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(paras, "IN_TypeOfDay_HalfDayOff", (int)TypeOfDay.HalfDayOff);     // Morning Off,Afternoon Off

            return this.db.FindList<WorkAppliedList>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public IList<ApplyRegisterInfo> GetApplyRegisterListByCond(int userID, string applyNo, DateTime? applyDateFrom, DateTime? applyDateTo, DateTime effectDateFrom, DateTime effectDateTo, int applyType, int applyStatus,
                                                                    int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Work_GetApplyRegisterListByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_ApplyDateFrom", applyDateFrom);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);
            base.AddParam(paras, "IN_EffectDateFrom", effectDateFrom);
            base.AddParam(paras, "IN_EffectDateTo", effectDateTo);
            base.AddParam(paras, "IN_ApplyType", applyType);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);

            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ApplyRegisterInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public int GetCountApplyRegisterList(int userID, string applyNo, DateTime? applyDateFrom, DateTime? applyDateTo, DateTime effectDateFrom, DateTime effectDateTo, int applyType, int applyStatus)
        {
            //SQL String
            string cmdText = "P_T_Work_GetCountApplyRegisterList";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_ApplyDateFrom", applyDateFrom);
            base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);
            base.AddParam(paras, "IN_EffectDateFrom", effectDateFrom);
            base.AddParam(paras, "IN_EffectDateTo", effectDateTo);
            base.AddParam(paras, "IN_ApplyType", applyType);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);

            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public IList<ApplyApproveInfo> GetApplyApproveListByCond(int userID, string staffCD, string staffNm, /*DateTime applyDateFrom, DateTime applyDateTo,*/DateTime effectDtFrom, DateTime effectDtTo, DateTime? approvedDateFrom, DateTime? approvedDateTo, int applyType, int approvedType,
                                                                 int pageIndex, int pageSize, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Work_GetApplyApproveListByCond";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            if(CheckDataUtil.IsInteger(staffCD))
            {
                base.AddParam(paras, "IN_StaffCD", staffCD.PadLeft(M_Staff.STAFF_CODE_MAX_LENGTH - M_Staff.MAX_STAFF_CODE_SHOW + staffCD.Length, '0'));
            }else
            {
                base.AddParam(paras, "IN_StaffCD",staffCD);
            }
            base.AddParam(paras, "IN_StaffNm", staffNm);
            //base.AddParam(paras, "IN_ApplyDateFrom", applyDateFrom);
            //base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);
            base.AddParam(paras, "IN_EffectDtFrom", effectDtFrom);
            base.AddParam(paras, "IN_EffectDtTo", effectDtTo);
            base.AddParam(paras, "IN_ApproveDateFrom", approvedDateFrom);
            base.AddParam(paras, "IN_ApproveDateTo", approvedDateTo);
            base.AddParam(paras, "IN_ApplyType", applyType);
            base.AddParam(paras, "IN_ApprovedType", approvedType);

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);
            
            base.AddParam(paras, "IN_PageIndex", pageIndex);
            base.AddParam(paras, "IN_PageSize", pageSize);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);

            return this.db.FindList<ApplyApproveInfo>(cmdText, paras);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="staffID"></param>
        /// <param name="dateForm"></param>
        /// <param name="dateTo"></param>
        /// <returns></returns>
        public int GetCountApplyApproveList(int userID, string staffCD, string staffNm, /*DateTime applyDateFrom, DateTime applyDateTo,*/DateTime effectDtFrom, DateTime effectDtTo, DateTime? approvedDateFrom, DateTime? approvedDateTo, int applyType, int approvedType)
        {
            //SQL String
            string cmdText = "P_T_Work_GetCountApplyApproveList";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);

            if (CheckDataUtil.IsInteger(staffCD))
            {
                base.AddParam(paras, "IN_StaffCD", staffCD.PadLeft(M_Staff.STAFF_CODE_MAX_LENGTH - M_Staff.MAX_STAFF_CODE_SHOW + staffCD.Length, '0'));
            }
            else
            {
                base.AddParam(paras, "IN_StaffCD", staffCD);
            }
            base.AddParam(paras, "IN_StaffNm", staffNm);
            //base.AddParam(paras, "IN_ApplyDateFrom", applyDateFrom);
            //base.AddParam(paras, "IN_ApplyDateTo", applyDateTo);
            base.AddParam(paras, "IN_EffectDtFrom", effectDtFrom);
            base.AddParam(paras, "IN_EffectDtTo", effectDtTo);
            base.AddParam(paras, "IN_ApproveDateFrom", approvedDateFrom);
            base.AddParam(paras, "IN_ApproveDateTo", approvedDateTo);
            base.AddParam(paras, "IN_ApplyType", applyType);
            base.AddParam(paras, "IN_ApprovedType", approvedType);

            base.AddParam(paras, "IN_NewStatus", (short)StatusApply.Draft);
            base.AddParam(paras, "IN_CancelStatus", (short)StatusApply.Cancel);
            base.AddParam(paras, "IN_ApprovedStatus", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_RejectStatus", (short)StatusApply.Rejected);


            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString());
        }

        /// <summary>
        /// Get by Unique key
        /// </summary>
        /// <param name="userID">staff id</param>
        /// <param name="workDate">work date</param>
        /// <returns></returns>
        public T_Work GetByKey(int userID, DateTime workDate)
        {
            //SQL String
            string cmdText = "P_T_Work_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_WorkDate", workDate);

            return this.db.Find<T_Work>(cmdText, paras);
        }

        /// <summary>
        /// GetListByCondForExcel
        /// </summary>
        /// <param name="staffID">staffID</param>
        /// <returns></returns>
        public IList<EmployeeDetailInYearExcelList> GetListByCondForEmployeeDetailInYearExcel(int staffID, int year)
        {
            //SQL String
            string cmdText = "P_T_Work_GetListTotalInYearForEmployee";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_Year", year);
            base.AddParam(paras, "IN_StatusApproved", (short)StatusApply.Approved);
            base.AddParam(paras, "IN_TypeOfDay_DayOff", (int)TypeOfDay.DayOff);
            base.AddParam(paras, "IN_TypeOfDay_WorkDay", (int)TypeOfDay.WorkDay);
            base.AddParam(paras, "IN_VacationType_DayOff", (int)VacationType.DayOff);

            return this.db.FindList<EmployeeDetailInYearExcelList>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="work"></param>
        /// <returns></returns>
        public int Insert(T_Work work)
        {
            //SQL String
            string cmdText = "P_T_Work_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_UserID", work.UserID);
            base.AddParam(paras, "IN_WorkDate", work.WorkDate);
            base.AddParam(paras, "IN_WorkShiftID", work.WorkShiftID);
            base.AddParam(paras, "IN_StartWorkHour", work.StartWorkHour);
            base.AddParam(paras, "IN_StartWorkMinute", work.StartWorkMinute);
            base.AddParam(paras, "IN_EndWorkHour", work.EndWorkHour);
            base.AddParam(paras, "IN_EndWorkMinute", work.EndWorkMinute);
            base.AddParam(paras, "IN_TimeWorkHour", work.TimeWorkHour);
            base.AddParam(paras, "IN_TimeWorkMinute", work.TimeWorkMinute);
            base.AddParam(paras, "IN_TimeLateHour", work.TimeLateHour);
            base.AddParam(paras, "IN_TimeLateMinute", work.TimeLateMinute);
            base.AddParam(paras, "IN_TimeEarlyHour", work.TimeEarlyHour);
            base.AddParam(paras, "IN_TimeEarlyMinute", work.TimeEarlyMinute);
            base.AddParam(paras, "IN_TimeOutHour", work.TimeOutHour);
            base.AddParam(paras, "IN_TimeOutMinute", work.TimeOutMinute);
            base.AddParam(paras, "IN_OTEarlyHour", work.OTEarlyHour);
            base.AddParam(paras, "IN_OTEarlyMinute", work.OTEarlyMinute);
            base.AddParam(paras, "IN_OTNormal1Hour", work.OTNormal1Hour);
            base.AddParam(paras, "IN_OTNormal1Minute", work.OTNormal1Minute);
            base.AddParam(paras, "IN_OTNormal2Hour", work.OTNormal2Hour);
            base.AddParam(paras, "IN_OTNormal2Minute", work.OTNormal2Minute);
            base.AddParam(paras, "IN_OTLateHour", work.OTLateHour);
            base.AddParam(paras, "IN_OTLateMinute", work.OTLateMinute);
            base.AddParam(paras, "IN_OTHoliday1Hour", work.OTHoliday1Hour);
            base.AddParam(paras, "IN_OTHoliday1Minute", work.OTHoliday1Minute);
            base.AddParam(paras, "IN_OTHoliday2Hour", work.OTHoliday2Hour);
            base.AddParam(paras, "IN_OTHoliday2Minute", work.OTHoliday2Minute);
            base.AddParam(paras, "IN_TotalOTHour", work.TotalOTHour);
            base.AddParam(paras, "IN_TotalOTMinute", work.TotalOTMinute);
            base.AddParam(paras, "IN_TotalWorkHour", work.TotalWorkHour);
            base.AddParam(paras, "IN_TotalWorkMinute", work.TotalWorkMinute);
            base.AddParam(paras, "IN_Remark", work.Remark);
            base.AddParam(paras, "IN_CreateUID", work.CreateUID);

            if (this.db.ExecuteNonQuery(cmdText, paras) > 0)
            {
                return base.db.GetIdentityId<T_Work_Vacation>();
            }
            return 0;
        }

        #endregion

        #region Update

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="work">T_Approve</param>
        /// <returns></returns>
        public int Update(T_Work work)
        {
            //SQL String
            string cmdText = "P_T_Work_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", work.ID);
            base.AddParam(paras, "IN_WorkShiftID", work.WorkShiftID);
            base.AddParam(paras, "IN_StartWorkHour", work.StartWorkHour);
            base.AddParam(paras, "IN_StartWorkMinute", work.StartWorkMinute);
            base.AddParam(paras, "IN_EndWorkHour", work.EndWorkHour);
            base.AddParam(paras, "IN_EndWorkMinute", work.EndWorkMinute);
            base.AddParam(paras, "IN_TimeWorkHour", work.TimeWorkHour);
            base.AddParam(paras, "IN_TimeWorkMinute", work.TimeWorkMinute);
            base.AddParam(paras, "IN_TimeLateHour", work.TimeLateHour);
            base.AddParam(paras, "IN_TimeLateMinute", work.TimeLateMinute);
            base.AddParam(paras, "IN_TimeEarlyHour", work.TimeEarlyHour);
            base.AddParam(paras, "IN_TimeEarlyMinute", work.TimeEarlyMinute);
            base.AddParam(paras, "IN_TimeOutHour", work.TimeOutHour);
            base.AddParam(paras, "IN_TimeOutMinute", work.TimeOutMinute);
            base.AddParam(paras, "IN_OTEarlyHour", work.OTEarlyHour);
            base.AddParam(paras, "IN_OTEarlyMinute", work.OTEarlyMinute);
            base.AddParam(paras, "IN_OTNormal1Hour", work.OTNormal1Hour);
            base.AddParam(paras, "IN_OTNormal1Minute", work.OTNormal1Minute);
            base.AddParam(paras, "IN_OTNormal2Hour", work.OTNormal2Hour);
            base.AddParam(paras, "IN_OTNormal2Minute", work.OTNormal2Minute);
            base.AddParam(paras, "IN_OTLateHour", work.OTLateHour);
            base.AddParam(paras, "IN_OTLateMinute", work.OTLateMinute);
            base.AddParam(paras, "IN_OTHoliday1Hour", work.OTHoliday1Hour);
            base.AddParam(paras, "IN_OTHoliday1Minute", work.OTHoliday1Minute);
            base.AddParam(paras, "IN_OTHoliday2Hour", work.OTHoliday2Hour);
            base.AddParam(paras, "IN_OTHoliday2Minute", work.OTHoliday2Minute);
            base.AddParam(paras, "IN_TotalOTHour", work.TotalOTHour);
            base.AddParam(paras, "IN_TotalOTMinute", work.TotalOTMinute);
            base.AddParam(paras, "IN_TotalWorkHour", work.TotalWorkHour);
            base.AddParam(paras, "IN_TotalWorkMinute", work.TotalWorkMinute);
            base.AddParam(paras, "IN_Remark", work.Remark);
            base.AddParam(paras, "IN_UpdateDate", work.UpdateDate);
            base.AddParam(paras, "IN_UpdateUID", work.UpdateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// Update
        /// </summary>
        /// <param name="workID">work id</param>
        /// <param name="oldUpdateDate">old update date</param>
        /// <returns></returns>
        public int Delete(int workID, DateTime oldUpdateDate)
        {
            //SQL String
            string cmdText = "P_T_Work_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", workID);
            base.AddParam(paras, "IN_UpdateDate", oldUpdateDate);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion
    }
}

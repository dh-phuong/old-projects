﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using DailyReport.Models;

namespace DailyReport.DAC
{
    public class WorkApplyTimeService : BaseService
    {
        #region Contructor

        /// <summary>
        /// Contructor of Work out service
        /// </summary>        
        private WorkApplyTimeService()
            : base()
        {
        }

        /// <summary>
        /// Contructor of Work out service
        /// </summary>
        /// <param name="db">Class DB</param>
        public WorkApplyTimeService(DB db)
            : base(db)
        {
        }

        #endregion

        #region Get

        #endregion

        #region Insert
        
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public int Insert(T_Work_ApplyTime data)
        {
            //SQL String
            string cmdText = "P_T_Work_ApplyTime_Insert";
            
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", data.ApplyNo);
            base.AddParam(paras, "IN_UserID", data.UserID);
            base.AddParam(paras, "IN_StartTime", data.StartTime);
            base.AddParam(paras, "IN_EndTime", data.EndTime);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Update
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="workOut"></param>
        /// <returns></returns>
        public int Update(T_Work_ApplyTime data)
        {
            //SQL String
            string cmdText = "P_T_Work_ApplyTime_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", data.ApplyNo);
            base.AddParam(paras, "IN_UserID", data.UserID);
            base.AddParam(paras, "IN_StartTime", data.StartTime);
            base.AddParam(paras, "IN_EndTime", data.EndTime);

            return this.db.ExecuteNonQuery(cmdText, paras);

        }
        #endregion

        #region Delete

        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="workID"></param>
        /// <returns></returns>
        public int Delete(string applyNo)
        {
            //SQL String
            string cmdText = "P_T_Work_ApplyTime_Delete";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Check

        /// <summary>
        /// Check duplicate time apply
        /// </summary>
        /// <param name="applyId">apply id</param>
        /// <param name="userId">user id</param>
        /// <param name="startDate">start date</param>
        /// <param name="endDate">end date</param>
        /// <returns></returns>
        public bool IsDuplicateTimeApply(string applyNo, int userId, DateTime startTime, DateTime endTime)
        {
            //Command text
            string cmdText = "P_T_Work_ApplyTime_IsDuplicateTimeApply";

            //Add parameter
            Hashtable prms = new Hashtable();
            base.AddParam(prms, "IN_ApplyNo", applyNo);
            base.AddParam(prms, "IN_UserID", userId);
            base.AddParam(prms, "IN_StartTime", startTime);
            base.AddParam(prms, "IN_EndTime", endTime);

            return (int)this.db.ExecuteScalar(cmdText, prms) > 0;
        }

        #endregion
    }
}

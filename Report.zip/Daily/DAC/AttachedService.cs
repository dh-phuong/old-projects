﻿using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using DailyReport.Utilities;

namespace DailyReport.DAC
{
    /// <summary>
    /// AttachedService
    /// </summary>
    public class AttachedService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private AttachedService()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public AttachedService(DB db)
        {
            this.db = db;
        }
        #endregion

        #region Get Data

        /// <summary>
        /// Get list by conditions
        /// </summary>
        /// <returns>IList<AttachedInfo></returns>
        public IList<AttachedInfo> GetListByCond(string id, int sortField, int sortDirec)
        {
            //SQL String
            string cmdText = "P_T_Attached_GetList";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", id);
            base.AddParam(paras, "IN_SortField", sortField);
            base.AddParam(paras, "IN_SortDirec", sortDirec);
            return this.db.FindList<AttachedInfo>(cmdText, paras);
        }

        /// <summary>
        /// GetByID
        /// </summary>
        /// <param name="no">id</param>
        /// <returns>T_Attached</returns>
        public T_Attached GetByID(int id)
        {
            //SQL String
            string cmdText = "P_T_Attached_GetByID";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "@IN_ID", id);

            return this.db.Find<T_Attached>(cmdText, paras);
        }

        /// <summary>
        /// Count file
        /// Create Date: 2014/09/11
        /// Create Author: ISV-HUNG
        /// </summary>
        /// <param name="headerId"></param>
        /// <param name="formType"></param>
        /// <returns></returns>
        public int CountFile(string headerId)
        {
            //SQL String
            string cmdText = "P_T_Attached_CountFile";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_No", headerId);

            return (int)this.db.ExecuteScalar(cmdText, paras);
        }
        #endregion

        #region Insert
        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="attached">M_Customer</param>
        /// <returns></returns>
        public int Insert(AttachedInfo attached)
        {
            //SQL String
            string cmdText = "P_T_Attached_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_No", attached.No);
            base.AddParam(paras,"IN_Path", attached.Path);
            base.AddParam(paras,"IN_CreateUID", attached.CreateUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Delete
        /// <summary>
        /// Delete data
        /// </summary>
        /// <param name="id">id</param>
        /// <returns></returns>
        public int Delete(int id)
        {
            //SQL String
            string cmdText = "P_T_Attached_Delete";

            //Param
            Hashtable paras = new Hashtable();
            base.AddParam(paras,"IN_ID", id);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}
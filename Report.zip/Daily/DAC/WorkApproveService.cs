﻿using System;
using System.Collections;
using System.Collections.Generic;

using DailyReport.Models;
using DailyReport.Utilities;
using System.Data.Common;

namespace DailyReport.DAC
{
    /// <summary>
    /// WorkApproveService
    /// ISV-TRUC
    /// 2015/06/08
    /// </summary>
    public class WorkApproveService : BaseService
    {
        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private WorkApproveService()
            : base()
        {

        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="db"></param>
        public WorkApproveService(DB db)
            : base()
        {
            this.db = db;
        }
        #endregion

        #region Get

        public IList<ApproveNextInfo> GetListNextApprove(int staffID, DateTime dateForm, DateTime dateTo)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_GetListNextApprove";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_StaffID", staffID);
            base.AddParam(paras, "IN_DateFrom", dateForm);
            base.AddParam(paras, "IN_DateTo", dateTo);
            base.AddParam(paras, "IN_ApplyStatus", StatusApply.Approving);
            base.AddParam(paras, "IN_ApproveStatus", StatusApprove.None);

            return this.db.FindList<ApproveNextInfo>(cmdText, paras);
        }


        /// <summary>
        /// Get approve list data
        /// </summary>
        /// <param name="applyNo">apply id</param>
        /// <param name="userID">user id</param>
        /// <returns></returns>
        public T_Work_Approve GetApproveRow(string applyNo, int userID, int applyType)
        {
            string cmdText = "P_T_Work_Approve_GetApproveRow";

            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_UserID", userID);
            base.AddParam(paras, "IN_ApprovedStatus", (int)StatusApply.Approved);
            base.AddParam(paras, "IN_ApplyType", applyType);

            return this.db.Find<T_Work_Approve>(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/08
        /// </summary>
        /// <param name="applyID"></param>
        /// <returns></returns>
        public IList<WorkApproveModel> GetListByIDOptionLevel(string applyNo, bool isGetViewLevel = false, EnumGetLevelZero isGetLVZero = EnumGetLevelZero.Exclude)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_GetListByIDOptionLevel";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            if (!isGetViewLevel)
            {
                base.AddParam(paras, "IN_ViewLevel", M_Route_H.LEVEL_READER);
            }
            else
            {
                base.AddParam(paras, "IN_ViewLevel", DBNull.Value);
            }

            if (isGetLVZero == EnumGetLevelZero.Only)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Only);
            }
            else if (isGetLVZero == EnumGetLevelZero.Exclude)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Exclude);
            }
            else if (isGetLVZero == EnumGetLevelZero.Include)
            {
                base.AddParam(paras, "IN_GetLVZero", (int)EnumGetLevelZero.Include);
            }
            base.AddParam(paras, "IN_RouteLvZero", M_Route_H.LEVEL_APPLICANT);
            return this.db.FindList<WorkApproveModel>(cmdText, paras);
        }        
        
        /// <summary>
        /// GetListEmailByLevelAprove
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="level"></param>
        /// <returns></returns>
        public IList<string> GetListEmailByLevelAprove(string applyNo, int currenLevel, int sendMailMode, int approveUID = -1)
        {
            string cmdText = "P_T_Work_Vacation_GetListEmailByLevelAprove";
           
            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_CurrLevel", currenLevel);
            base.AddParam(paras, "IN_SendMailMode", sendMailMode);
            if (approveUID == -1)
            {
                base.AddParam(paras, "IN_ApproveUID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApproveUID", approveUID);
            }
            //base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            IList<string> ret = new List<string>();
            using (DbCommand cmd = db.con.CreateCommand())
            {
                cmd.Transaction = db.trans;
                db.SetCommand(cmd, cmdText, paras);
                using (DbDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ret.Add(dr["Email"].ToString());
                    }
                }
            }

            return ret;
        }        
        
        /// <summary>
        /// GetListEmailByLevelAprove Test
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="currenLevel"></param>
        /// <param name="sendMailMode"></param>
        /// <param name="approveUID"></param>
        /// <returns></returns>
        public IList<M_User> GetListEmailByLevelAproveTest(string applyNo, int currenLevel, int sendMailMode, int approveUID = -1)
        {
            string cmdText = "P_T_Work_Approve_GetListEmailByLevelApproveTest";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_CurrLevel", currenLevel);
            base.AddParam(paras, "IN_SendMailMode", sendMailMode);
            if (approveUID == -1)
            {
                base.AddParam(paras, "IN_ApproveUID", DBNull.Value);
            }
            else
            {
                base.AddParam(paras, "IN_ApproveUID", approveUID);
            }
            //base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            return this.db.FindList<M_User>(cmdText, paras);
        }

        /// <summary>
        /// GetByKey
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="routeUID"></param>
        /// <returns></returns>
        public T_Work_Approve GetByKey(string applyNo, int routeUID)
        {
            string cmdText = "P_T_Work_Approve_GetByKey";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_RouteUID", routeUID);

            return this.db.Find<T_Work_Approve>(cmdText, paras);
        }

        #endregion

        #region Insert

        /// <summary>
        /// ISV-TRUC Add new
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public int Insert(T_Work_Approve app)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_Insert";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", app.ApplyNo);
            base.AddParam(paras, "IN_RouteUID", app.RouteUID);
            base.AddParam(paras, "IN_RouteLevel", app.RouteLevel);
            base.AddParam(paras, "IN_RouteMethod", app.RouteMethod);
            base.AddParam(paras, "IN_ApproveStatus", app.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", app.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", app.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", app.ApproveReason, true);
            base.AddParam(paras, "IN_RequireNum", app.RequireNum);
            base.AddParam(paras, "IN_ProxyApprovalUser", app.ProxyApprovalUser);

            #region Apply Flag
            base.AddParam(paras, "IN_ApplyFlag1", app.ApplyFlag1);
            base.AddParam(paras, "IN_ApplyFlag2", app.ApplyFlag2);
            base.AddParam(paras, "IN_ApplyFlag3", app.ApplyFlag3);
            base.AddParam(paras, "IN_ApplyFlag4", app.ApplyFlag4);
            #endregion

            #region RejectFlag
            base.AddParam(paras, "IN_RejectFlag1", app.RejectFlag1);
            base.AddParam(paras, "IN_RejectFlag2", app.RejectFlag2);
            base.AddParam(paras, "IN_RejectFlag3", app.RejectFlag3);
            base.AddParam(paras, "IN_RejectFlag4", app.RejectFlag4);
            base.AddParam(paras, "IN_RejectFlag5", app.RejectFlag5);
            base.AddParam(paras, "IN_RejectFlag6", app.RejectFlag6);
            base.AddParam(paras, "IN_RejectFlag7", app.RejectFlag7);
            #endregion

            #region RemandFlag
            base.AddParam(paras, "IN_RemandFlag1", app.RemandFlag1);
            base.AddParam(paras, "IN_RemandFlag2", app.RemandFlag2);
            base.AddParam(paras, "IN_RemandFlag3", app.RemandFlag3);
            base.AddParam(paras, "IN_RemandFlag4", app.RemandFlag4);
            base.AddParam(paras, "IN_RemandFlag5", app.RemandFlag5);
            base.AddParam(paras, "IN_RemandFlag6", app.RemandFlag6);
            base.AddParam(paras, "IN_RemandFlag7", app.RemandFlag7);
            #endregion

            #region ApproveFlag
            base.AddParam(paras, "IN_ApproveFlag1", app.ApproveFlag1);
            base.AddParam(paras, "IN_ApproveFlag2", app.ApproveFlag2);
            base.AddParam(paras, "IN_ApproveFlag3", app.ApproveFlag3);
            base.AddParam(paras, "IN_ApproveFlag4", app.ApproveFlag4);
            base.AddParam(paras, "IN_ApproveFlag5", app.ApproveFlag5);
            base.AddParam(paras, "IN_ApproveFlag6", app.ApproveFlag6);
            base.AddParam(paras, "IN_ApproveFlag7", app.ApproveFlag7);
            base.AddParam(paras, "IN_ApproveFlag8", app.ApproveFlag8);
            base.AddParam(paras, "IN_ApproveFlag9", app.ApproveFlag9);
            #endregion

            #region Read Flag
            base.AddParam(paras, "IN_ReadFlag1", app.ReadFlag1);
            base.AddParam(paras, "IN_ReadFlag2", app.ReadFlag2);
            base.AddParam(paras, "IN_ReadFlag3", app.ReadFlag3);
            base.AddParam(paras, "IN_ReadFlag4", app.ReadFlag4);
            base.AddParam(paras, "IN_ReadFlag5", app.ReadFlag5);
            #endregion

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Insert
        /// </summary>
        /// <param name="routeID"></param>
        /// <param name="appNo"></param>
        /// <param name="routeUID"></param>
        /// <param name="approveStatus"></param>
        /// <returns></returns>
        public int Insert(int routeID, string appNo, int routeUID, short approveStatus)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_InsertFromRoute";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_RouteID", routeID);
            base.AddParam(paras, "IN_ApplyNo", appNo);
            base.AddParam(paras, "IN_RouteUID", routeUID);
            base.AddParam(paras, "IN_ApproveStatus", approveStatus);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion

        #region Approve

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/09       
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="defaultApprUID"></param>
        /// <param name="actualApprUID"></param>
        /// <param name="statusApprove"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Approve(string applyNo, int defaultApprUID, int actualApprUID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_Approve";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_ApproveUID", defaultApprUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            //base.AddParam(paras, "IN_RouteMethodOR", (short)RouteMethods.OR);
            base.AddParam(paras, "IN_Reason", reason);
            base.AddParam(paras, "IN_LoginID", actualApprUID);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update ApplyStatus        
        /// </summary>
        /// <param name="apply"></param>
        /// <returns></returns>
        public int UpdateApplyStatus(ApplyType applyType, int applyID, int updateUID, short applyStatus, int curCompleteLevel, DateTime updateDate)
        {
            //SQL String
            string cmdText = string.Empty;

            switch (applyType)
            {
                case ApplyType.Vacation:

                    cmdText = "P_T_Work_Vacation_UpdateApplyStatus";
                    break;
                case ApplyType.OverTime:
                    cmdText = "P_T_Work_OT_UpdateApplyStatus";
                    break;
                case ApplyType.LateEarlyOuting:
                    cmdText = "P_T_Work_Leave_UpdateApplyStatus";
                    break;
                case ApplyType.Absence:
                    cmdText = "P_T_Work_Absence_UpdateApplyStatus";
                    break;
                default:
                    break;
            }

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ID", applyID);
            base.AddParam(paras, "IN_ApplyStatus", applyStatus);
            base.AddParam(paras, "IN_UpdateDate", updateDate);
            //ApprovedLevel
            base.AddParam(paras, "IN_CurCompleteLV", curCompleteLevel);
            base.AddParam(paras, "IN_UpdateUID", updateUID);
            return this.db.ExecuteNonQuery(cmdText, paras);

        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="inID"></param>
        /// <param name="approveUID"></param>
        /// <param name="approveUserID"></param>
        /// <param name="statusApprove"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Reject(string applyNo, int approveUID, int approveUserID, short statusApprove, string reason)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_Reject";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_ApproveStatus", statusApprove);
            base.AddParam(paras, "IN_ApproveReason", reason, true);
            base.AddParam(paras, "IN_ApproveUserID", approveUserID);
            base.AddParam(paras, "IN_ApproveStatusNew", (int)StatusHasAprove.New);
            
            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        
        /// <summary>
        /// CheckApproveIsFinish
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="AppNo"></param>
        /// <returns>true: finished, false: not finish </returns>
        public bool CheckApproveIsFinish(string AppNo, int loginUID)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_CheckApproveFinish";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", AppNo);
            base.AddParam(paras, "IN_LoginID", loginUID);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }        

        /// <summary>
        /// CheckApproveIsFinishLevel
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="AppNo"></param>
        /// <param name="currentLv"></param>
        /// <returns></returns>
        public bool CheckApproveIsFinishLevel(string AppNo, int currentLv)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_CheckApproveFinish_Level";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", AppNo);
            base.AddParam(paras, "IN_CurLevel", currentLv);
            base.AddParam(paras, "IN_ApproveStatus", (int)StatusHasAprove.Approved);
            return int.Parse(this.db.ExecuteScalar(cmdText, paras).ToString()) == 1;
        }
        #endregion

        #region Update
        
        /// <summary>
        /// Update 
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        public int Update(T_Work_Approve applyApproveList)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_Update";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyApproveList.ApplyNo);
            base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
            base.AddParam(paras, "IN_ApproveUID", applyApproveList.ApproveUID);
            base.AddParam(paras, "IN_ApproveDate", applyApproveList.ApproveDate);
            base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="appNo"></param>
        /// <param name="status"></param>
        /// <param name="loginUserID"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int UpdateApproveStatus(string appNo, int status, int loginUserID, string reason)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_UpdateApproveStatus";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", appNo);
            base.AddParam(paras, "IN_ApproveStatus", status);
            base.AddParam(paras, "IN_LoginUID", loginUserID);
            base.AddParam(paras, "IN_ApproveReason", reason, true);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        /// <summary>
        /// Update for PrevBack mode
        /// </summary>
        /// <param name="applyApproveList"></param>
        /// <returns></returns>
        //public int UpdateForPrevBack(T_Apply_Approve_List applyApproveList, int loginUserID, int approvedStatus)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Apply_Approve_List_UpdateForPrevBack";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApplyID", applyApproveList.ApplyID);
        //    base.AddParam(paras, "IN_ApproveStatus", applyApproveList.ApproveStatus);
        //    base.AddParam(paras, "IN_ApprovedStatus", approvedStatus);
        //    base.AddParam(paras, "IN_LoginUID", loginUserID);
        //    //base.AddParam(paras, "IN_ApproveReason", applyApproveList.ApproveReason);

        //    return this.db.ExecuteNonQuery(cmdText, paras);
        //}

        /// <summary>
        /// Remand
        /// ISV-TRUC
        /// 2015/06/09
        /// </summary>
        /// <param name="applyNo"></param>
        /// <param name="approveUID"></param>
        /// <param name="prevStatus"></param>
        /// <param name="newStatus"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        public int Remand(string applyNo, int approveUID, int approveUserID, short prevStatus, short newStatus, string reason)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_Remand";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_AppNo", applyNo);
            base.AddParam(paras, "IN_ApproveUID", approveUID);
            base.AddParam(paras, "IN_PreviousStatus", prevStatus);
            base.AddParam(paras, "IN_NewStatus", newStatus);
            base.AddParam(paras, "IN_Reason", reason, true);
            base.AddParam(paras, "IN_ApproveUserID", approveUserID);
            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        ///// <summary>
        ///// Update status for PrevBack mode
        ///// </summary>
        ///// <param name="applyApproveList"></param>
        ///// <returns></returns>
        //public int UpdateStatusForPrevBack(int applyID, int approveStatus, int prevApproveStatus)
        //{
        //    //SQL String
        //    string cmdText = "P_T_Apply_Approve_List_UpdateStatusForPrevBack";

        //    //Para
        //    Hashtable paras = new Hashtable();
        //    base.AddParam(paras, "IN_ApplyID", applyID);
        //    base.AddParam(paras, "IN_ApproveStatus", approveStatus);
        //    base.AddParam(paras, "IN_PrevApproveStatus", prevApproveStatus);

        //    return this.db.ExecuteNonQuery(cmdText, paras);
        //}

        /// <summary>
        /// UpdateStatusForPrevBack2
        /// ISV-TRUC
        /// 2015/05/28
        /// </summary>
        /// <param name="applyID"></param>
        /// <param name="approveStatus"></param>
        /// <param name="prevApproveStatus"></param>
        /// <returns></returns>
        public int UpdateStatusForRemand(string applyNo, int approveStatus, int prevApproveStatus)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_UpdateStatusForRemand";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);
            base.AddParam(paras, "IN_ApproveStatus", approveStatus);
            base.AddParam(paras, "IN_PrevApproveStatus", prevApproveStatus);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }

        #endregion

        #region Delete

        /// <summary>
        /// ISV-TRUC
        /// Delete
        /// </summary>
        /// <param name="applyNo"></param>
        /// <returns></returns>
        public int Delete(string applyNo)
        {
            //SQL String
            string cmdText = "P_T_Work_Approve_DeteleByApplyNo";

            //Para
            Hashtable paras = new Hashtable();
            base.AddParam(paras, "IN_ApplyNo", applyNo);

            return this.db.ExecuteNonQuery(cmdText, paras);
        }
        #endregion
    }
}